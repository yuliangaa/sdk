/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_process_id.h>
#include <complib/cl_dbg.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_emad_parser_shspm.h>
#include <sx/sxd/sxd_emad_parser_acl.h>
#include <sx/sxd/sxd_emad_parser_vlan.h>
#include <sx/sxd/sxd_emad_parser_fdb.h>
#include <sx/sxd/sxd_emad_parser_router.h>
#include <sx/sxd/sxd_emad_parser_lag.h>
#include <sx/sxd/sxd_emad_parser_span.h>
#include <sx/sxd/sxd_emad_parser_flow_counter.h>
#include <sx/sxd/sxd_emad_parser_port.h>
#include <sx/sxd/sxd_emad_parser_cos.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/kernel_user.h>
#include <unistd.h>
#include "dpt.h"

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif

#include "reg_access/sxd_access_reg_infra.h"

/************************************************
 *  Local variables
 ***********************************************/

#undef  __MODULE__
#define __MODULE__ ACCESS_REG
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/
extern sxd_dpt_t    *dpt_ptr;
sxd_access_reg_hw_t *hw_p = NULL;
static boolean_t     g_health_fatal_failure_detection_is_active = FALSE;

/************************************************
 *  Local Type definitions
 ***********************************************/

#define SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, reg, reg_max_size, reg_name_lower, reg_name_upper)                    \
    ({                                                                                                                \
        sxd_status_t __st = SXD_STATUS_SUCCESS;                                                                       \
        do {                                                                                                          \
            uint8_t raw_buff[(reg_max_size)] = { 0 };                                                                 \
            struct ku_raw_reg raw_reg = { .buff = raw_buff, .size = sizeof(raw_buff) };                               \
            sxd_emad_ ## reg_name_lower ## _data_t reg_data = { .reg_data = (reg) };                                  \
                                                                                                                      \
            __st = sxd_emad_parse_ ## reg_name_lower(&reg_data, (sxd_emad_ ## reg_name_lower ## _reg_t *)raw_buff);   \
            if (__st != SXD_STATUS_SUCCESS) {                                                                         \
                SX_LOG_ERR("Failed parsing " #reg_name_upper " register through CMD IFC (err=%d)\n", __st);           \
                return __st;                                                                                          \
            }                                                                                                         \
                                                                                                                      \
            __st = sxd_command_ifc_access_raw_reg(hw_p->cmd_ifc_hw_p,                                                 \
                                                  (access_cmd),                                                       \
                                                  (dev_id),                                                           \
                                                  SXD_REG_ID_ ## reg_name_upper ## _E,                                \
                                                  &raw_reg);                                                          \
            if (__st != SXD_STATUS_SUCCESS) {                                                                         \
                SX_LOG_ERR("Failed accessing " #reg_name_upper " register through CMD IFC (err=%d)\n", __st);         \
                return __st;                                                                                          \
            }                                                                                                         \
                                                                                                                      \
            __st = sxd_emad_deparse_ ## reg_name_lower(&reg_data, (sxd_emad_ ## reg_name_lower ## _reg_t *)raw_buff); \
            if (__st != SXD_STATUS_SUCCESS) {                                                                         \
                SX_LOG_ERR("Failed deparsing " #reg_name_upper " register through CMD IFC (err=%d)\n", __st);         \
                return __st;                                                                                          \
            }                                                                                                         \
        } while (0);                                                                                                  \
        __st;                                                                                                         \
    })

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_access_register_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sxd_status_t sxd_access_register_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return status;
}


sxd_status_t sxd_access_reg_local_port_to_swid_set(sxd_dev_id_t dev_id, sxd_port_phy_id_t local_port, sxd_swid_t swid)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_local_to_swid(hw_p->cmd_ifc_hw_p, dev_id, local_port, swid);
}

sxd_status_t sxd_access_reg_lag_oper_state_set(uint16_t lag_id, uint8_t oper_state)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_lag_oper_state_set(hw_p->cmd_ifc_hw_p, lag_id, oper_state);
}

sxd_status_t sxd_access_reg_port_ber_monitor_state_set(sxd_dev_id_t      dev_id,
                                                       sxd_port_phy_id_t local_port,
                                                       uint8_t           ber_monitor_state)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_port_ber_monitor_state_set(hw_p->cmd_ifc_hw_p,
                                                      dev_id,
                                                      local_port,
                                                      ber_monitor_state);
}

sxd_status_t sxd_access_reg_port_sample_rate_update(sxd_port_phy_id_t local_port, uint32_t sample_rate)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_port_sample_rate_update(hw_p->cmd_ifc_hw_p, local_port, sample_rate);
}

sxd_status_t sxd_access_reg_port_ber_monitor_bitmask_set(sxd_dev_id_t dev_id, uint16_t local_port, uint8_t bitmask)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_port_ber_monitor_bitmask_set(hw_p->cmd_ifc_hw_p, dev_id, local_port, bitmask);
}

sxd_status_t sxd_access_reg_tele_threshold_set(sxd_port_phy_id_t local_port, uint8_t dir_ing, uint64_t tc_vec)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_tele_threshold_set(hw_p->cmd_ifc_hw_p, local_port, dir_ing, tc_vec);
}

sxd_status_t sxd_access_reg_set_default_vid(sxd_dev_id_t      dev_id,
                                            uint8_t           is_lag,
                                            sxd_port_sys_id_t sysport,
                                            uint16_t          lag_id,
                                            sxd_vid_t         default_vid)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_default_vid(hw_p->cmd_ifc_hw_p,
                                           dev_id, is_lag, sysport, lag_id, default_vid);
}

sxd_status_t sxd_access_sdk_fatal_failure_detection_info_set(
    ku_dbg_health_check_params_t* ku_dbg_health_check_params_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_fatal_failure_detection_info_set(hw_p->cmd_ifc_hw_p,
                                                ku_dbg_health_check_params_p);
}

sxd_status_t sxd_access_sysfs_sniffer_mode_set(ku_sysfs_sniffer_params_t* ku_sysfs_sniffer_params_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_sysfs_sniffer_mode_set(hw_p->cmd_ifc_hw_p,
                                      ku_sysfs_sniffer_params_p);
}


sxd_status_t sxd_access_sdk_update_thread_status_changed(cl_thread_status_changed_t* thread_status_info)
{
    sxd_status_t                 sxd_status = SXD_STATUS_SUCCESS;
    ku_dbg_health_check_params_t ku_dbg_health_check_params;

    SX_LOG_ENTER();

    if (thread_status_info->thread_id == 0) {
        SX_LOG_ERR("Health check : during reading SDK  "
                   "changed entry OS thread_id is missing/zero\n");
        sxd_status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (CL_DBG_NUM_OF_THREADS_BITS < thread_status_info->bit_index) {
        SX_LOG_ERR("Health check : during update thread status changed SDK thread ['%s'}  "
                   " with bit_index= %u is out of range\n,",
                   thread_status_info->name, thread_status_info->bit_index);
        sxd_status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }
    memset(&ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed, 0,
           sizeof(ku_thread_status_changed_t));

    ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.bit_index = thread_status_info->bit_index;
    ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.thread_id = thread_status_info->thread_id;
    ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.cmd = thread_status_info->cmd;
    strncpy(ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.name,
            thread_status_info->name, THREAD_NAME_SIZE);
    ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.max_expected_thread_duration_sec =
        thread_status_info->max_expected_thread_duration_sec;
    /* for safe side */
    ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.name[THREAD_NAME_SIZE - 1] = 0;

    ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd =
        SXD_HEALTH_FATAL_FAILURE_UPDATE_SDK_THREAD_STATUS_CHANGED_E;
    ku_dbg_health_check_params.dev_id = 1;        /* TODO need to collect the dev id and not hard coded*/

    sxd_status = sxd_access_sdk_fatal_failure_detection_info_set(&ku_dbg_health_check_params);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR(
            "Fatal failure detection set failed with cmd : SXD_HEALTH_FATAL_FAILURE_UPDATE_SDK_THREAD_STATUS_CHANGED_E,"
            " thread '%s' os_thread_id %lu bit index: %d ,is_new_thread = %d and SXD return value: (%d) on device (%d)\n",
            ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.name,
            ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.thread_id,
            ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.bit_index,
            ku_dbg_health_check_params.params.sdk_threads_info.thread_status_changed.cmd,
            sxd_status,
            ku_dbg_health_check_params.dev_id);
    }
out:
    SX_LOG_EXIT();
    return sxd_status;
}

sxd_status_t sxd_access_sdk_update_thread_monitor(uint64_t                   last_sent_threads_existing,
                                                  uint64_t                   running_threads_status,
                                                  thread_monitoring_status_e thread_monitoring_status)
{
    sxd_status_t                 sxd_status = SXD_STATUS_SUCCESS;
    ku_dbg_health_check_params_t ku_dbg_health_check_params;

    SX_LOG_ENTER();


    if (thread_monitoring_status == THREAD_MONITOR_ACTIVE_E) {
        /* for safe side */
        ku_dbg_health_check_params.params.sdk_threads_info.threads_monitor_info.last_sent_threads_existing =
            last_sent_threads_existing;
        ku_dbg_health_check_params.params.sdk_threads_info.threads_monitor_info.running_threads_status =
            running_threads_status;
    }

    ku_dbg_health_check_params.params.sdk_threads_info.threads_monitor_info.thread_monitoring_status =
        thread_monitoring_status;

    ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd =
        SXD_HEALTH_FATAL_FAILURE_UPDATE_SDK_THREAD_MONITOR_E;
    ku_dbg_health_check_params.dev_id = 1;     /* TODO need to collect the dev id and not hard coded*/

    sxd_status = sxd_access_sdk_fatal_failure_detection_info_set(&ku_dbg_health_check_params);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR(
            "Fatal failure detection set failed with cmd :SXD_HEALTH_FATAL_FAILURE_UPDATE_SDK_THREAD_MONITOR_E"
            " last_sent_threads_existing (0x%lx) running_threads_status: (0x%lx) ,is and SXD return value: (%d) on device (%d)\n",
            ku_dbg_health_check_params.params.sdk_threads_info.threads_monitor_info.last_sent_threads_existing,
            ku_dbg_health_check_params.params.sdk_threads_info.threads_monitor_info.running_threads_status,
            sxd_status,
            ku_dbg_health_check_params.dev_id);
    }

    SX_LOG_EXIT();
    return sxd_status;
}

void sxd_health_check_active_set(boolean_t is_active)
{
    g_health_fatal_failure_detection_is_active = is_active;
}

boolean_t sxd_health_check_active_get(void)
{
    return g_health_fatal_failure_detection_is_active;
}

#ifdef SW_PUDE_EMULATION
/* PUDE WA for NOS (PUDE events are handled by SDK). Needed for BU. */
sxd_status_t sxd_access_reg_set_admin_status(sxd_dev_id_t            dev_id,
                                             sxd_port_sys_id_t       sysport,
                                             sxd_paos_admin_status_t admin_status)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_admin_status(hw_p->cmd_ifc_hw_p,
                                            dev_id,
                                            sysport,
                                            admin_status);
}
#endif /* SW_PUDE_EMULATION */

sxd_status_t sxd_access_reg_set_vid_membership(sxd_dev_id_t      dev_id,
                                               uint8_t           is_lag,
                                               sxd_port_phy_id_t phy_port,
                                               uint16_t          lag_id,
                                               sxd_vid_t         vid,
                                               uint8_t           is_tagged)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_vid_membership(hw_p->cmd_ifc_hw_p,
                                              dev_id, is_lag, phy_port, lag_id, vid, is_tagged);
}

sxd_status_t sxd_access_reg_set_prio_tagging(sxd_dev_id_t      dev_id,
                                             uint8_t           is_lag,
                                             sxd_port_phy_id_t phy_port,
                                             uint16_t          lag_id,
                                             uint8_t           is_prio_tagged)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_prio_tagging(hw_p->cmd_ifc_hw_p,
                                            dev_id, is_lag, phy_port, lag_id, is_prio_tagged);
}

sxd_status_t sxd_access_reg_set_prio_to_tc(sxd_dev_id_t            dev_id,
                                           uint8_t                 is_lag,
                                           sxd_port_phy_id_t       phy_port,
                                           uint16_t                lag_id,
                                           sxd_cos_port_priority_t priority,
                                           sxd_cos_traffic_class_t traffic_class)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_prio_to_tc(hw_p->cmd_ifc_hw_p,
                                          dev_id, is_lag, phy_port, lag_id, priority, traffic_class);
}

sxd_status_t sxd_access_reg_issu_fw(sxd_dev_id_t dev_id)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_issu_fw(hw_p->cmd_ifc_hw_p, dev_id);
}

sxd_status_t sxd_access_reg_send_issu_notification(boolean_t is_issu_start)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_send_issu_notification(hw_p->cmd_ifc_hw_p, is_issu_start);
}

sxd_status_t sxd_access_reg_query_rsrc_info(struct ku_query_rsrc *rsrc_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }
    return sxd_command_ifc_query_rsrc_info(hw_p->cmd_ifc_hw_p, rsrc_p);
}

sxd_status_t sxd_access_reg_query_fw_info(query_fw_t *fw_info_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_query_fw_info(hw_p->cmd_ifc_hw_p, fw_info_p);
}

sxd_status_t sxd_access_reg_query_board_info(struct ku_query_board_info *board_info_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_query_board_info(hw_p->cmd_ifc_hw_p, board_info_p);
}

sxd_status_t sxd_access_reg_sw_rate_limiter_set(struct ku_set_rdq_rate_limiter *rate_limiter_params)
{
    UNUSED_PARAM(rate_limiter_params);

    SX_LOG_INF("rate limiter is obsolete\n");
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_access_reg_truncate_size_set(struct ku_set_truncate_params *truncate_params)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_truncate_size_set(hw_p->cmd_ifc_hw_p, truncate_params);
}

sxd_status_t sxd_access_reg_pci_profile_get(struct sx_pci_profile *pci_profile_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_pci_profile_get(hw_p->cmd_ifc_hw_p, pci_profile_p);
}

sxd_status_t sxd_access_reg_device_profile_access(sxd_access_cmd_t access_cmd, struct ku_profile   *profile_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if ((access_cmd == SXD_ACCESS_CMD_SET) && (!DEFAULT_DEVICE_ID_CHECK(profile_p->dev_id)) &&
        ((dpt_ptr->device_access_control[profile_p->dev_id] == READ_ONLY) ||
         (dpt_ptr->device_access_control[profile_p->dev_id] == NO_ACCESS))) {
        return SXD_STATUS_SUCCESS;
    }

    return sxd_command_ifc_device_profile_access(hw_p->cmd_ifc_hw_p, access_cmd, profile_p);
}

sxd_status_t sxd_access_reg_cpu_memory_access(sxd_access_cmd_t access_cmd, struct ku_map_memory *map_memory_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_cpu_memory_access(hw_p->cmd_ifc_hw_p, access_cmd, map_memory_p);
}

sxd_status_t sxd_access_reg_profile_kvh_params_access(sxd_access_cmd_t           access_cmd,
                                                      struct profile_kvh_params *kvh_params_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_kvh_cache_params_access(hw_p->cmd_ifc_hw_p, access_cmd, kvh_params_p);
}

sxd_status_t sxd_access_reg_system_m_key_access(sxd_access_cmd_t access_cmd, struct ku_system_m_key *system_m_key_p)
{
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;

    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        sxd_err = SXD_STATUS_NOT_INITIALIZED;
        goto out_err;
    }

    if ((access_cmd == SXD_ACCESS_CMD_SET) && (!DEFAULT_DEVICE_ID_CHECK(system_m_key_p->dev_id)) &&
        ((dpt_ptr->device_access_control[system_m_key_p->dev_id] == READ_ONLY) ||
         (dpt_ptr->device_access_control[system_m_key_p->dev_id] == NO_ACCESS))) {
        /* skip FW system_m_key config but config the DPT.
         * So each SMP mad will be sent with system_m_key */
        goto out;
    }

    sxd_err = sxd_command_ifc_system_m_key_access(hw_p->cmd_ifc_hw_p, access_cmd, system_m_key_p);
    if (sxd_err != 0) {
        SX_LOG(SX_LOG_ERROR, "sxd_command_ifc_system_m_key_access error: [err: %d]\n",
               sxd_err);
        goto out_err;
    }

out:
    if (access_cmd == SXD_ACCESS_CMD_SET) {
        sxd_err = dpt_set_system_m_key(system_m_key_p->dev_id,
                                       &system_m_key_p->system_m_key);
        if (sxd_err != 0) {
            SX_LOG(SX_LOG_ERROR, "dpt_set_system_m_key error: [err: %d]\n",
                   sxd_err);
            goto out_err;
        }
    }

out_err:
    return sxd_err;
}

sxd_status_t sxd_access_reg_sx_core_db_save(struct ku_sx_core_db *sx_core_db_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_sx_core_db_access(hw_p->cmd_ifc_hw_p, SXD_ACCESS_CMD_GET, sx_core_db_p);
}

sxd_status_t sxd_access_reg_sx_core_db_restore_allowed(sxd_boolean_t *is_restore_allowed_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_sx_core_db_restore_allowed(hw_p->cmd_ifc_hw_p, is_restore_allowed_p);
}


sxd_status_t sxd_access_reg_sx_core_db_restore(struct ku_sx_core_db *sx_core_db_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_sx_core_db_access(hw_p->cmd_ifc_hw_p, SXD_ACCESS_CMD_SET, sx_core_db_p);
}


void build_emad_common(const sxd_reg_meta_t *meta, uint16_t sys_port, sxd_emad_common_data_t *common)
{
    common->dev_id = meta->dev_id;
    common->access_cmd = meta->access_cmd;
    common->mode = meta->mode;
    common->route_type = SYS_PORT_ROUTE_E;
    common->route_info.sys_port_route_info.sys_port = sys_port;
}

sxd_status_t sxd_access_reg_pcnr(struct ku_pcnr_reg      *pcnr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pcnr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PCNR_E);
}

sxd_status_t sxd_access_reg_ppaos(struct ku_ppaos_reg     *ppaos_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppaos_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPAOS_E);
}

sxd_status_t sxd_access_reg_mrrr(struct ku_mrrr_reg      *mrrr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mrrr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MRRR_E);
}

sxd_status_t sxd_access_reg_htac(struct ku_htac_reg      *htac_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(htac_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTAC_E);
}

sxd_status_t sxd_access_reg_pvlc(struct ku_pvlc_reg      *pvlc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pvlc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PVLC_E);
}

sxd_status_t sxd_access_reg_pspa(struct ku_pspa_reg      *pspa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pspa_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;
    sxd_port_phy_id_t      local_port = 0;
    boolean_t              skip_driver = FALSE;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pspa_reg *curr_reg_data = pspa_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;


        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (curr_reg_data->sub_port == SXD_SUP_PORT_TYPE_PROFILE_E) {
            skip_driver = TRUE;
            curr_reg_data->sub_port = SXD_SUP_PORT_TYPE_PHY_E;
        } else {
            skip_driver = FALSE;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            goto update_driver; /* even if FW is not updated, must update driver's DB (ISSU case) */
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);
            if ((access_cmd == SXD_ACCESS_CMD_SET) || (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pspa_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pspa_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PSPA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PSPA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pspa_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PSPA register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pspa_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pspa_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PSPA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PSPA register through IBMAD "
                           "dev %d port %d. \n", reg_meta->dev_id, pspa_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PSPA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }

update_driver: /* we are still in the for-loop */

        /* WA for incorrect swid */
        if ((access_cmd != SXD_ACCESS_CMD_GET) && !skip_driver) {
            SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                              curr_reg_data->local_port,
                                              curr_reg_data->lp_msb);

            status = sxd_command_ifc_set_local_to_swid(hw_p->cmd_ifc_hw_p,
                                                       curr_reg_meta->dev_id,
                                                       local_port,
                                                       curr_reg_data->swid);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed sxd_command_ifc_set_local_to_swid: lp:0x%x swid:%d, status: %d\n",
                           local_port,
                           curr_reg_data->swid,
                           status);
                return status;
            }
        }
    } /* end of for-loop [ for (i = 0; i < data_num; i++) ] */

    return status;
}

sxd_status_t sxd_access_reg_pmlp(struct ku_pmlp_reg      *pmlp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t             encapsulation = CMD_IFC_PATH;
    internal_path_params_t          params;
    sxd_status_t                    status = SXD_STATUS_SUCCESS;
    sxd_emad_pmlp_data_t            reg_data;
    swid_type_t                     swid_type;
    uint32_t                        i;
    sxd_reg_meta_t                 *curr_reg_meta = NULL;
    struct ku_pmlp_reg             *curr_reg_data = NULL;
    sxd_access_cmd_t                access_cmd;
    sxd_dev_id_t                    dev_id;
    sxd_swid_t                      swid;
    sxd_port_phy_id_t               local_port = 0;
    sxd_ctrl_pack_t                 ctrl_pack;
    ku_port_module_map_set_params_t port_module_map_set_params;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        curr_reg_meta = reg_meta + i;
        curr_reg_data = pmlp_reg_data + i;
        access_cmd = curr_reg_meta->access_cmd;
        dev_id = curr_reg_meta->dev_id;
        swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }


        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);
            if ((access_cmd == SXD_ACCESS_CMD_SET) || (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pmlp_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pmlp_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PMLP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMLP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pmlp_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMLP register through CMD IFC dev %d, local_port %d, lp_msb %d \n",
                           reg_meta->dev_id,
                           pmlp_reg_data->local_port,
                           pmlp_reg_data->lp_msb);
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pmlp_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pmlp_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PMLP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PMLP register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, pmlp_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PMLP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    if (status == SXD_STATUS_SUCCESS) {
        for (i = 0; i < data_num; i++) {
            curr_reg_meta = reg_meta + i;
            curr_reg_data = pmlp_reg_data + i;
            access_cmd = curr_reg_meta->access_cmd;
            dev_id = curr_reg_meta->dev_id;
            swid = curr_reg_meta->swid;

            SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                              curr_reg_data->local_port,
                                              curr_reg_data->lp_msb);

            if ((access_cmd == SXD_ACCESS_CMD_SET) || (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                if (curr_reg_data->width != 0) {
                    status = sxd_dpt_port_module_map_set(SXD_ACCESS_CMD_SET,
                                                         dev_id,
                                                         curr_reg_data->slot[0],
                                                         curr_reg_data->module[0],
                                                         local_port);
                    if (status != SXD_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Failed setting port module shared memory,cmd %d dev %d slot %u module %d port %d \n",
                            SXD_ACCESS_CMD_SET,
                            dev_id,
                            curr_reg_data->slot[0],
                            curr_reg_data->module[0],
                            local_port);
                        return status;
                    }
                    port_module_map_set_params.is_set = TRUE;
                } else {
                    status = sxd_dpt_port_module_map_set(SXD_ACCESS_CMD_DELETE,
                                                         dev_id,
                                                         curr_reg_data->slot[0],
                                                         curr_reg_data->module[0],
                                                         local_port);
                    if (status != SXD_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Failed setting port module shared memory,cmd %d dev %d slot %u module %d port %d \n",
                            SXD_ACCESS_CMD_SET,
                            dev_id,
                            curr_reg_data->slot[0],
                            curr_reg_data->module[0],
                            local_port);
                        return status;
                    }
                    port_module_map_set_params.is_set = FALSE;
                }

                port_module_map_set_params.dev_id = dev_id;
                port_module_map_set_params.local_port = local_port;
                port_module_map_set_params.slot_id = curr_reg_data->slot[0];
                port_module_map_set_params.module_id = curr_reg_data->module[0];
                ctrl_pack.ctrl_cmd = CTRL_CMD_PORT_MODULE_MAP_SET;
                ctrl_pack.cmd_body = &port_module_map_set_params;
                status = sxd_ioctl(hw_p->cmd_ifc_hw_p->dev, &ctrl_pack);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed setting port module by ioctl, cmd %d dev %d slot %u module %d port %d \n",
                        access_cmd,
                        dev_id,
                        curr_reg_data->slot[0],
                        curr_reg_data->module[0],
                        local_port);
                    return status;
                }
            }

#if defined(PD_BU) && defined(PD_BU_PMLP_STUB)
            /* Stub for PMLP - FW stub will return 0 for port width, setting expected number here */
            if (access_cmd == SXD_ACCESS_CMD_GET) {
                pmlp_reg_data->width = 4;
            }
#endif
        }
    }
    return status;
}

sxd_status_t sxd_access_reg_plib(struct ku_plib_reg      *plib_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_plib_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;
    sxd_port_phy_id_t      local_port = 0;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_plib_reg *curr_reg_data = plib_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);
            if ((access_cmd == SXD_ACCESS_CMD_SET) || (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_plib_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_plib_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PLIB register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PLIB register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_plib_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PLIB register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_plib_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_plib_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PLIB register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PLIB register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, plib_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PLIB register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    /* WA for incorrect swid */
    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_plib_reg *curr_reg_data = plib_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;

        if (status != SXD_STATUS_SUCCESS) {
            break;
        }

        if (access_cmd == SXD_ACCESS_CMD_GET) {
            continue;
        }

        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          curr_reg_data->local_port,
                                          curr_reg_data->lp_msb);

        status = sxd_command_ifc_set_ib_to_local_port(hw_p->cmd_ifc_hw_p,
                                                      curr_reg_meta->dev_id,
                                                      curr_reg_data->ib_port,
                                                      local_port);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed sxd_command_ifc_set_ib_to_local_port(ib %d, lp %d). status: %d\n",
                       curr_reg_data->ib_port,
                       local_port,
                       status);
            return status;
        }

        /* Add ib to local mapping to dpt db */
        status = sxd_dpt_set_uc_route(curr_reg_data->ib_port,
                                      curr_reg_meta->dev_id,
                                      local_port,
                                      TRUE);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed sxd_dpt_set_uc_route: "
                       "ib sysport:0x%x dev_id:%d local_port:%d, status: %d\n",
                       curr_reg_data->ib_port,
                       curr_reg_meta->dev_id,
                       local_port,
                       status);
            return status;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mjtag(struct ku_mjtag_reg     *mjtag_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t          encapsulation = CMD_IFC_PATH;
    internal_path_params_t       params;
    sxd_status_t                 status = SXD_STATUS_SUCCESS;
    static sxd_emad_mjtag_data_t reg_data;
    swid_type_t                  swid_type;
    uint32_t                     i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_mjtag_reg *curr_reg_data = mjtag_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mjtag_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mjtag_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MJTAG register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MJTAG register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mjtag_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MJTAG register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mjtag_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mjtag_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MJTAG register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MJTAG register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MJTAG register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pmpr(struct ku_pmpr_reg      *pmpr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pmpr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pmpr_reg *curr_reg_data = pmpr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pmpr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pmpr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PMPR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMPR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pmpr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMPR register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pmpr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pmpr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PMPR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PMPR register through IBMAD "
                           "dev %d module %d attenuation %d.\n",
                           reg_meta->dev_id, pmpr_reg_data->module, pmpr_reg_data->attenuation5g);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PMPR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pmpc(struct ku_pmpc_reg      *pmpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pmpc_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pmpc_reg *curr_reg_data = pmpc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pmpc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pmpc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PMPC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMPC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pmpc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PMPC register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pmpc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pmpc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PMPC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PMPC register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PMPC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pfsc(struct ku_pfsc_reg      *pfsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pfsc_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pfsc_reg *curr_reg_data = pfsc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_pfsc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pfsc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PFSC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFSC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pfsc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFSC register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing pfsc register dev %d local_port %d lp_msb %d\n",
                       reg_meta->dev_id,
                       pfsc_reg_data->local_port,
                       pfsc_reg_data->lp_msb);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_hopf(struct ku_hopf_reg      *hopf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hopf_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HOPF_E);
}


sxd_status_t sxd_access_reg_hcap(struct ku_hcap_reg      *hcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_hcap_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_hcap_reg *curr_reg_data = hcap_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) ||
            (access_cmd == SXD_ACCESS_CMD_ADD) ||
            (access_cmd == SXD_ACCESS_CMD_DELETE)) {
            SX_LOG_ERR("HCAP register only supports a get operation\n");
            return SXD_STATUS_CMD_UNSUPPORTED;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_hcap_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of HCAP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HCAP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_hcap_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, hcap_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HCAP register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing HCAP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_hctr(struct ku_hctr_reg      *hctr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_hctr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_hctr_reg *curr_reg_data = hctr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_hctr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_hctr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of HCTR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HCTR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_hctr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, hctr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HCTR register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing HCTR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_hdrt(struct ku_hdrt_reg      *hdrt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_hdrt_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_hdrt_reg *curr_reg_data = hdrt_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_hdrt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_hdrt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of HDRT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HDRT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_hdrt_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, hdrt_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HDRT register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing HDRT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mfba(struct ku_mfba_reg      *mfba_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mfba_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mfba_reg *curr_reg_data = mfba_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if ((!DEFAULT_DEVICE_ID_CHECK(dev_id))) {
            if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
                SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
                return SXD_STATUS_NOT_INITIALIZED;
            }

            if (((access_cmd == SXD_ACCESS_CMD_SET) ||
                 (access_cmd == SXD_ACCESS_CMD_ADD) ||
                 (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
                (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
                continue;
            }

            status = dpt_get_swid_type(swid, &swid_type);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get swid type from the DPT\n");
                return status;
            }

            if (swid_type == SWID_TYPE_EN) {
                status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
            } else if (swid_type == SWID_TYPE_IB) {
                status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, FALSE);
            }
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mfba_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mfba_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MFBA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFBA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mfba_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFBA register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mfba_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mfba_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MFBA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MFBA register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MFBA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mfbe(struct ku_mfbe_reg      *mfbe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mfbe_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mfbe_reg *curr_reg_data = mfbe_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if ((!DEFAULT_DEVICE_ID_CHECK(dev_id))) {
            if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
                SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
                return SXD_STATUS_NOT_INITIALIZED;
            }

            if (((access_cmd == SXD_ACCESS_CMD_SET) ||
                 (access_cmd == SXD_ACCESS_CMD_ADD) ||
                 (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
                (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
                continue;
            }

            status = dpt_get_swid_type(swid, &swid_type);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get swid type from the DPT\n");
                return status;
            }

            if (swid_type == SWID_TYPE_EN) {
                status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
            } else if (swid_type == SWID_TYPE_IB) {
                status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, FALSE);
            }
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mfbe_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mfbe_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MFBE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFBE register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mfbe_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFBE register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mfbe_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mfbe_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MFBE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MFBE register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MFBE register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mfpa(struct ku_mfpa_reg      *mfpa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mfpa_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mfpa_reg *curr_reg_data = mfpa_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if ((!DEFAULT_DEVICE_ID_CHECK(dev_id))) {
            if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
                SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
                return SXD_STATUS_NOT_INITIALIZED;
            }

            if (((access_cmd == SXD_ACCESS_CMD_SET) ||
                 (access_cmd == SXD_ACCESS_CMD_ADD) ||
                 (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
                (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
                continue;
            }

            status = dpt_get_swid_type(swid, &swid_type);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get swid type from the DPT\n");
                return status;
            }

            if (swid_type == SWID_TYPE_EN) {
                status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
            } else if (swid_type == SWID_TYPE_IB) {
                status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
            }
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mfpa_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mfpa_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MFPA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFPA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mfpa_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MFPA register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mfpa_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mfpa_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MFPA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MFPA register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MFPA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pelc(struct ku_pelc_reg      *pelc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    sxd_emad_pelc_data_t   reg_data;
    internal_path_params_t params;
    swid_type_t            swid_type;
    uint32_t               i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pelc_reg *curr_reg_data = pelc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pelc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pelc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PELC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PELC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pelc_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PELC register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pelc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pelc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PELC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PELC register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, pelc_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PELC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mcia(struct ku_mcia_reg      *mcia_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    uint32_t               i;
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    swid_type_t            swid_type;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mcia_reg *curr_reg_data = mcia_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH: /* EMAD path is used with the new register infra. that's why 'return' is used here */
            return sxd_access_reg_common(mcia_reg_data, reg_meta, data_num, handler, context, SXD_REG_ID_MCIA_E);

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mcia_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                if (status == SXD_STATUS_FW_BUSY) {
                    /* FW FSM may be busy. In this case NOS can retry. So return busy without error log */
                    SX_LOG_NTC("FW is BUSY accessing MCIA register through CMD IFC\n. Retry after some time\n");
                } else {
                    SX_LOG_ERR("Failed accessing MCIA register through CMD IFC\n");
                }
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mcia_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mcia_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MCIA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MCIA register through IBMAD "
                           "dev %d module %d with error %s.\n", reg_meta->dev_id,
                           curr_reg_data->module, SXD_STATUS_MSG(status));
                return status;
            }

            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PMPC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mfcr(struct ku_mfcr_reg      *mfcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint32_t     i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mfcr_reg *curr_reg_data = mfcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = sxd_command_ifc_access_mfcr_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed accessing MFCR register through CMD IFC\n");
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_mfm(struct ku_mfm_reg       *mfm_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context)
{
    return sxd_access_reg_common(mfm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFM_E);
}

sxd_status_t sxd_access_reg_mfsc(struct ku_mfsc_reg      *mfsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfsc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFSC_E);
}

sxd_status_t sxd_access_reg_mfsl(struct ku_mfsl_reg      *mfsl_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint32_t     i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mfsl_reg *curr_reg_data = mfsl_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = sxd_command_ifc_access_mfsl_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed accessing MFSL register through CMD IFC\n");
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mfsm(struct ku_mfsm_reg      *mfsm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfsm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFSM_E);
}

sxd_status_t sxd_access_reg_ibsni(struct ku_ibsni_reg     *ibsni_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ibsni_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IBSNI_E);
}


sxd_status_t sxd_access_reg_qprt(struct ku_qprt_reg      *qprt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qprt_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qprt_reg *curr_reg_data = qprt_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qprt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qprt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPRT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPRT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 8, qprt, QPRT);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing QPRT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_fore(struct ku_fore_reg      *fore_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint32_t     i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_fore_reg *curr_reg_data = fore_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = sxd_command_ifc_access_fore_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed accessing FORE register through CMD IFC\n");
        }
    }

    return status;
}

/*
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 */
sxd_status_t sxd_access_reg_raw(struct ku_raw_reg       *raw_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                uint16_t                 register_id,
                                sxd_completion_handler_t handler,
                                void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_raw_data_t    reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t    *curr_reg_meta = reg_meta + i;
        struct ku_raw_reg *curr_reg_data = raw_reg_data + i;
        sxd_access_cmd_t   access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t       dev_id = curr_reg_meta->dev_id;
        sxd_swid_t         swid = curr_reg_meta->swid;

        if ((!DEFAULT_DEVICE_ID_CHECK(dev_id))) {
            if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
                SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
                return SXD_STATUS_NOT_INITIALIZED;
            }

            if (((access_cmd == SXD_ACCESS_CMD_SET) ||
                 (access_cmd == SXD_ACCESS_CMD_ADD) ||
                 (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
                (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
                continue;
            }

            status = dpt_get_swid_type(swid, &swid_type);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get swid type from the DPT\n");
                return status;
            }

            if (swid_type == SWID_TYPE_EN) {
                status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
            } else if (swid_type == SWID_TYPE_IB) {
                status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, FALSE);
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
                return status;
            }
        }

        switch (encapsulation) {
        case EMAD_PATH:
            memset(&reg_data, 0, sizeof(reg_data));
            reg_data.reg_data = curr_reg_data;
            reg_data.register_id = register_id;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_raw_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_raw_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of raw register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAW register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_raw_reg(hw_p->sport, dev_id, &params.dr_params,
                                         register_id, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_raw_reg(hw_p->sport, dev_id, &params.dr_params,
                                         register_id, curr_reg_data);
            } else {
                SX_LOG_ERR("There is no valid path for accessing RAW register\n");
                return SXD_STATUS_ERROR;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RAW register through IBMAD.\n");
                return status;
            }

            break;

#endif
        case CMD_IFC_PATH:
            status =
                sxd_command_ifc_access_raw_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, register_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAW register through CMD IFC\n");
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RAW register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

/*
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 */
sxd_status_t sxd_access_reg_raw_ext(struct ku_raw_reg_ext   *raw_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    uint16_t                 register_id,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    dpt_encapsulation_t     encapsulation = CMD_IFC_PATH;
    internal_path_params_t  params;
    sxd_status_t            status = SXD_STATUS_SUCCESS;
    sxd_emad_raw_ext_data_t reg_data;
    swid_type_t             swid_type;
    uint32_t                i;

    UNUSED_PARAM(context);

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t        *curr_reg_meta = reg_meta + i;
        struct ku_raw_reg_ext *curr_reg_data = raw_reg_data + i;
        sxd_access_cmd_t       access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t           dev_id = curr_reg_meta->dev_id;
        sxd_swid_t             swid = curr_reg_meta->swid;

        if ((!DEFAULT_DEVICE_ID_CHECK(dev_id))) {
            if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
                SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
                return SXD_STATUS_NOT_INITIALIZED;
            }

            if (((access_cmd == SXD_ACCESS_CMD_SET) ||
                 (access_cmd == SXD_ACCESS_CMD_ADD) ||
                 (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
                (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
                continue;
            }

            status = dpt_get_swid_type(swid, &swid_type);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get swid type from the DPT\n");
                return status;
            }

            if (swid_type == SWID_TYPE_EN) {
                status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
            } else if (swid_type == SWID_TYPE_IB) {
                status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, FALSE);
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
                return status;
            }
        }

        switch (encapsulation) {
        case EMAD_PATH:
            memset(&reg_data, 0, sizeof(reg_data));
            reg_data.reg_data = curr_reg_data;
            reg_data.register_id = register_id;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_raw_ext_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_raw_ext_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of raw register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAW_EXT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_raw_reg(hw_p->sport, dev_id, &params.dr_params,
                                         register_id, (struct ku_raw_reg *)curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_raw_reg(hw_p->sport, dev_id, &params.dr_params,
                                         register_id, (struct ku_raw_reg *)curr_reg_data);
            } else {
                SX_LOG_ERR("There is no valid path for accessing RAW register\n");
                return SXD_STATUS_ERROR;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RAW register through IBMAD.\n");
                return status;
            }

            break;

#endif
        case CMD_IFC_PATH:
            status =
                sxd_command_ifc_access_raw_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, register_id,
                                               (struct ku_raw_reg *)curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAW register through CMD IFC\n");
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RAW register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_hespr(struct ku_hespr_reg     *hespr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_hespr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_hespr_reg *curr_reg_data = hespr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_hespr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_hespr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of HESPR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing HESPR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing HESPR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spmcr(struct ku_spmcr_reg     *spmcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spmcr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_spmcr_reg *curr_reg_data = spmcr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spmcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spmcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPMCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPMCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_spmcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPMCR register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPMCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pifr(struct ku_pifr_reg      *pifr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pifr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pifr_reg *curr_reg_data = pifr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pifr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pifr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PIFR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PIFR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PIFR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ppsc(struct ku_ppsc_reg      *ppsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ppsc_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (ppsc_reg_data->wrps_admin > 2) {
        ppsc_reg_data->wrps_admin = 0;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ppsc_reg *curr_reg_data = ppsc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ppsc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ppsc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PPSC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PPSC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_ppsc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PPSC register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_ppsc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_ppsc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PPSC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PPSC register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PPSC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}
sxd_status_t sxd_access_reg_pbmc(struct ku_pbmc_reg      *pbmc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pbmc_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pbmc_reg *curr_reg_data = pbmc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pbmc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pbmc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PBMC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PBMC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x6c, pbmc, PBMC);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PBMC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

#if defined(PD_BU) && defined(PD_BU_PBMC_STUB)
    /* Stub for PBMC - FW stub will return 0 for max port headroom, setting expected number here */
    if (reg_meta->access_cmd == SXD_ACCESS_CMD_GET) {
        pbmc_reg_data->port_buffer_size = 7004; /* 1970KB / 288b SB cell */
    }
#endif
    return status;
}

sxd_status_t sxd_access_reg_pptb(struct ku_pptb_reg      *pptb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t         encapsulation = CMD_IFC_PATH;
    internal_path_params_t      params;
    sxd_status_t                status = SXD_STATUS_SUCCESS;
    static sxd_emad_pptb_data_t reg_data;
    uint32_t                    i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pptb_reg *curr_reg_data = pptb_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pptb_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pptb_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PPTB register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PPTB register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x10, pptb, PPTB);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PPTB register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pcap(struct ku_pcap_reg      *pcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pcap_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pcap_reg *curr_reg_data = pcap_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) ||
            (access_cmd == SXD_ACCESS_CMD_ADD) ||
            (access_cmd == SXD_ACCESS_CMD_DELETE)) {
            SX_LOG_ERR("PCAP register only supports a get operation\n");
            return SXD_STATUS_CMD_UNSUPPORTED;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pcap_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PCAP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PCAP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PCAP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pfcc(struct ku_pfcc_reg      *pfcc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pfcc_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pfcc_reg *curr_reg_data = pfcc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pfcc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pfcc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PFCC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFCC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_pfcc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFCC register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PFCC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_pfca(struct ku_pfca_reg      *pfca_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pfca_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pfca_reg *curr_reg_data = pfca_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pfca_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pfca_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PFCA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFCA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PFCA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_pfcnt(struct ku_pfcnt_reg     *pfcnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pfcnt_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_pfcnt_reg *curr_reg_data = pfcnt_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pfcnt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pfcnt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PFCNT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PFCNT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PFCNT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mgpc(struct ku_mgpc_reg      *mgpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mgpc_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mgpc_reg *curr_reg_data = mgpc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD)) {
                status = sxd_emad_mgpc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mgpc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MGPC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MGPC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x18, mgpc, MGPC);
        } else {
            SX_LOG_ERR("There is no valid path for accessing MGPC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpdp(struct ku_qpdp_reg      *qpdp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpdp_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qpdp_reg *curr_reg_data = qpdp_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpdp_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpdp_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPDP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPDP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 8, qpdp, QPDP);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPDP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpts(struct ku_qpts_reg      *qpts_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpts_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qpts_reg *curr_reg_data = qpts_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpts_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpts_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPTS register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPTS register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 8, qpts, QPTS);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPTS register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpcr(struct ku_qpcr_reg      *qpcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpcr_data_t   reg_data;
    swid_type_t            swid_type = SWID_TYPE_UNKNOWN;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qpcr_reg *curr_reg_data = qpcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_qpcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPCR register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_qpcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_qpcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of QPCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing QPCR register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, qpcr_reg_data->port);
                return status;
            }

            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing QPCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpbr(struct ku_qpbr_reg      *qpbr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpbr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qpbr_reg *curr_reg_data = qpbr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpbr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpbr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPBR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPBR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_qpbr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPBR register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_qpbr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_qpbr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("There is no valid path for accessing QPBR register\n");
                return SXD_STATUS_ERROR;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing QPBR register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, qpbr_reg_data->port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing QPBR register dev %d port %d \n",
                       reg_meta->dev_id,
                       qpbr_reg_data->port);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sldr(struct ku_sldr_reg      *sldr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sldr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sldr_reg *curr_reg_data = sldr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sldr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sldr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SLDR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLDR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x108, sldr, SLDR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SLDR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_slcr(struct ku_slcr_reg      *slcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_slcr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_slcr_reg *curr_reg_data = slcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_slcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_slcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SLCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_slcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLCR register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SLCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_slcr_v2(struct ku_slcr_v2_reg   *slcr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(slcr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SLCR_V2_E);
}

sxd_status_t sxd_access_reg_slcor(struct ku_slcor_reg     *slcor_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_slcor_data_t  reg_data;
    uint32_t               i;
    sxd_port_phy_id_t      local_port = 0;
    struct ku_slcor_reg    cmd_ifc_slcor_reg_data;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_slcor_reg *curr_reg_data = slcor_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;
        uint8_t              is_lag;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        /* Copy the slcor_reg_data.
         * sxd_emad_slcor_set changes slcor_reg_data values,
         * and we need the original values to update the driver DB using
         * sxd_command_ifc_set_local_port_to_lag */
        memcpy(&cmd_ifc_slcor_reg_data, curr_reg_data, sizeof(cmd_ifc_slcor_reg_data));

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            goto update_driver; /* even if FW is not updated, must update driver's DB (ISSU case) */
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }


        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_slcor_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_slcor_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SLCOR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLCOR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x10, slcor, SLCOR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SLCOR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }

update_driver: /* we are still in the for-loop */
        /* WA for incorrect swid */
        /* Case add / remove port to / from LAG:
         * Update mapping (lag_id, port_index) -> local port in driver DB */
        if (access_cmd == SXD_ACCESS_CMD_GET) {
            continue;
        }

        switch (cmd_ifc_slcor_reg_data.collector) {
        case SXD_EMAD_SLDR_COLLECTOR_ADD_PORT_E:
            is_lag = 1;
            break;

        case SXD_EMAD_SLDR_COLLECTOR_REMOVE_PORT_E:
            is_lag = 0;
            break;

        default:
            continue;
        }

        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          cmd_ifc_slcor_reg_data.local_port,
                                          cmd_ifc_slcor_reg_data.lp_msb);

        status = sxd_command_ifc_set_local_port_to_lag(hw_p->cmd_ifc_hw_p,
                                                       dev_id,
                                                       is_lag,
                                                       cmd_ifc_slcor_reg_data.lag_id,
                                                       cmd_ifc_slcor_reg_data.port_index,
                                                       local_port);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed sxd_command_ifc_set_local_port_to_lag: "
                       "is_lag:%d lad_id:%d, port_index:%d loc_port:%d status: %d\n",
                       is_lag,
                       cmd_ifc_slcor_reg_data.lag_id,
                       cmd_ifc_slcor_reg_data.port_index,
                       local_port,
                       status);
            return status;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spms(struct ku_spms_reg      *spms_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spms_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_spms_reg *curr_reg_data = spms_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }
        /* This register is not supported through CMD IFC in the kernel
         * because it's bigger then the kernel stack */
        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spms_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spms_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPMS register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPMS register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_spms_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPMS register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPMS register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_scar(struct ku_scar_reg      *scar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_scar_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_scar_reg *curr_reg_data = scar_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) ||
            (access_cmd == SXD_ACCESS_CMD_ADD) ||
            (access_cmd == SXD_ACCESS_CMD_DELETE)) {
            SX_LOG_ERR("SCAR register only supports a get operation\n");
            return SXD_STATUS_CMD_UNSUPPORTED;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_scar_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SCAR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SCAR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SCAR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sspr(struct ku_sspr_reg      *sspr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sspr_data_t   reg_data;
    uint32_t               i;
    sxd_port_phy_id_t      local_port = 0;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sspr_reg *curr_reg_data = sspr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sspr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sspr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SSPR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SSPR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_sspr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SSPR register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SSPR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    /* WA for incorrect swid */
    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sspr_reg *curr_reg_data = sspr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;

        if (status != SXD_STATUS_SUCCESS) {
            break;
        }

        if (access_cmd == SXD_ACCESS_CMD_GET) {
            continue;
        }

        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          curr_reg_data->local_port,
                                          curr_reg_data->lp_msb);

        status = sxd_command_ifc_set_system_to_local_port(hw_p->cmd_ifc_hw_p,
                                                          curr_reg_meta->dev_id,
                                                          curr_reg_data->system_port,
                                                          local_port);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed sxd_command_ifc_set_system_to_local_port: "
                       "system_port: 0x%x, local_port: 0x%x, status: %d.\n",
                       curr_reg_data->system_port,
                       local_port,
                       status);
            return status;
        }

        /* add to dpt db */
        status = sxd_dpt_set_uc_route(curr_reg_data->system_port,
                                      curr_reg_meta->dev_id,
                                      local_port,
                                      FALSE);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed dpt_set_uc_route: "
                       "sysport:0x%x dev_id:%d local_port:%d , status: %d\n",
                       curr_reg_data->system_port,
                       curr_reg_meta->dev_id,
                       local_port,
                       status);
            return status;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spvid(struct ku_spvid_reg     *spvid_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spvid_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_spvid_reg *curr_reg_data = spvid_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spvid_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spvid_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPVID register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVID register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 8, spvid, SPVID);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPVID register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_spvc(struct ku_spvc_reg      *spvc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spvc_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_spvc_reg *curr_reg_data = spvc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spvc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spvc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPVC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_spvc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVC register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPVC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sver(struct ku_sver_reg      *sver_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sver_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sver_reg *curr_reg_data = sver_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sver_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sver_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SVER register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SVER register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SVER register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spvm(struct ku_spvm_reg      *spvm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spvm_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_spvm_reg *curr_reg_data = spvm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spvm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spvm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPVM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x400, spvm, SPVM);
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spvtr(struct ku_spvtr_reg     *spvtr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spvtr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_spvtr_reg *curr_reg_data = spvtr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spvtr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spvtr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPVTR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVTR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_spvtr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVTR register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPVTR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sfd(struct ku_sfd_reg       *sfd_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sfd_data_t    reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t    *curr_reg_meta = reg_meta + i;
        struct ku_sfd_reg *curr_reg_data = sfd_reg_data + i;
        sxd_access_cmd_t   access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t       dev_id = curr_reg_meta->dev_id;
        sxd_swid_t         swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        /* This register is not supported through CMD IFC in the kernel
         * because it's bigger then the kernel stack */
        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sfd_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sfd_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SFD register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SFD register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x410, sfd, SFD);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SFD register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sfn(struct ku_sfn_reg       *sfn_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sfn_data_t    reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t    *curr_reg_meta = reg_meta + i;
        struct ku_sfn_reg *curr_reg_data = sfn_reg_data + i;
        sxd_access_cmd_t   access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t       dev_id = curr_reg_meta->dev_id;
        sxd_swid_t         swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) ||
            (access_cmd == SXD_ACCESS_CMD_ADD) ||
            (access_cmd == SXD_ACCESS_CMD_DELETE)) {
            SX_LOG_ERR("SFN register only supports a get operation\n");
            return SXD_STATUS_CMD_UNSUPPORTED;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sfn_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SFN register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SFN register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_sfn_reg(hw_p->cmd_ifc_hw_p,
                                                    access_cmd,
                                                    dev_id,
                                                    curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SFN register through CMD IFC\n");
                return SXD_STATUS_NO_PATH_TO_DEVICE;
            }
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spgt(struct ku_spgt_reg      *spgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spgt_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_spgt_reg *curr_reg_data = spgt_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spgt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spgt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPGT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPGT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPGT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_svmlr(struct ku_svmlr_reg     *svmlr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_svmlr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_svmlr_reg *curr_reg_data = svmlr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_svmlr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_svmlr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SVMLR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SVMLR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SVMLR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spmlr(struct ku_spmlr_reg     *spmlr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spmlr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_spmlr_reg *curr_reg_data = spmlr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spmlr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spmlr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPMLR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPMLR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPMLR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_spvmlr(struct ku_spvmlr_reg    *spvmlr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_spvmlr_data_t reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t       *curr_reg_meta = reg_meta + i;
        struct ku_spvmlr_reg *curr_reg_data = spvmlr_reg_data + i;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_spvmlr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_spvmlr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SPVMLR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SPVMLR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x400, spvmlr, SPVMLR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SPVMLR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_slecr(struct ku_slecr_reg     *slecr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_slecr_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_slecr_reg *curr_reg_data = slecr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_slecr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_slecr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SLECR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLECR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_slecr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SLECR register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SLECR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_svpe(struct ku_svpe_reg      *svpe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_svpe_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_svpe_reg *curr_reg_data = svpe_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_svpe_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_svpe_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SVPE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SVPE register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 4, svpe, SVPE);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SVPE register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sftr(struct ku_sftr_reg      *sftr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sftr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sftr_reg *curr_reg_data = sftr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sftr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sftr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SFTR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SFTR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SFTR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_smid(struct ku_smid_reg      *smid_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_smid_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_smid_reg *curr_reg_data = smid_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_smid_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_smid_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SMID register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SMID register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            SX_LOG_ERR("SMID register is not supported by CMD_IFC\n");
            status = SXD_STATUS_CMD_UNSUPPORTED;

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SMID register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing SMID register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_pagt(struct ku_pagt_reg      *pagt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pagt_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pagt_reg *curr_reg_data = pagt_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pagt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pagt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PAGT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PAGT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x100, pagt, PAGT);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PAGT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ptce(struct ku_ptce_reg      *ptce_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ptce_data_t   reg_data;
    uint32_t               i;


    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ptce_reg *curr_reg_data = ptce_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ptce_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ptce_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PTCE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PTCE register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PTCE register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ptce2(struct ku_ptce2_reg     *ptce2_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ptce2_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_ptce2_reg *curr_reg_data = ptce2_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }
        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }
        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ptce2_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ptce2_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PTCE2 register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PTCE2 register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PTCE2 register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_prbt(struct ku_prbt_reg      *prbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_prbt_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_prbt_reg *curr_reg_data = prbt_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }
        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }
        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_prbt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_prbt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PRBT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PRBT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x14, prbt, PRBT);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PRBT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_pecb(struct ku_pecb_reg      *pecb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pecb_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pecb_reg *curr_reg_data = pecb_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }
        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }
        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pecb_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pecb_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of pecb register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PECB register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing pecb register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pemb(struct ku_pemb_reg      *pemb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pemb_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pemb_reg *curr_reg_data = pemb_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }
        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }
        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pemb_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pemb_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of pemb register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PEMB register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing pemb register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_pefa(struct ku_pefa_reg      *pefa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pefa_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pefa_reg *curr_reg_data = pefa_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }
        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }
        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pefa_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pefa_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PEFA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PEFA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x100, pefa, PEFA);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PEFA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_prcr(struct ku_prcr_reg      *prcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_prcr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_prcr_reg *curr_reg_data = prcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_prcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_prcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PRCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PRCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing PRCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pacl(struct ku_pacl_reg      *pacl_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pacl_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pacl_reg *curr_reg_data = pacl_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pacl_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pacl_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PACL register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PACL register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x108, pacl, PACL);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PACL register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ptar(struct ku_ptar_reg      *ptar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ptar_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ptar_reg *curr_reg_data = ptar_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ptar_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ptar_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PTAR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PTAR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x100, ptar, PTAR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing PTAR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_puet(struct ku_puet_reg      *puet_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_puet_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_puet_reg *curr_reg_data = puet_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_puet_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_puet_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PUET register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PUET register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing puet register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ratr(struct ku_ratr_reg      *ratr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ratr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ratr_reg *curr_reg_data = ratr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ratr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ratr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RATR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RATR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_ratr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_ratr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RATR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RATR register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RATR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ratrad(struct ku_ratrad_reg    *ratrad_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ratrad_data_t reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t       *curr_reg_meta = reg_meta + i;
        struct ku_ratrad_reg *curr_reg_data = ratrad_reg_data + i;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_ratrad_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ratrad_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RATRAD register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RATRAD register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing RATRAD register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ruft(struct ku_ruft_reg      *ruft_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ruft_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ruft_reg *curr_reg_data = ruft_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ruft_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ruft_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RUFT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RUFT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_ruft_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RUFT register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RUFT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_ruht(struct ku_ruht_reg      *ruht_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ruht_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ruht_reg *curr_reg_data = ruht_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ruht_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ruht_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RUHT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RUHT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RUHT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rauht(struct ku_rauht_reg     *rauht_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    sxd_emad_rauht_data_t  reg_data;
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_rauht_reg *curr_reg_data = rauht_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rauht_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rauht_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RAUHT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAUHT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x74, rauht, RAUHT);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RAUHT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rauhtd(struct ku_rauhtd_reg    *rauhtd_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    sxd_emad_rauhtd_data_t reg_data;
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t       *curr_reg_meta = reg_meta + i;
        struct ku_rauhtd_reg *curr_reg_data = rauhtd_reg_data + i;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rauhtd_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rauhtd_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RAUHTD register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RAUHTD register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RAUHTD register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rdpm(struct ku_rdpm_reg      *rdpm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rdpm_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rdpm_reg *curr_reg_data = rdpm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rdpm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rdpm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RDPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RDPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rdpm_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rdpm_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RDPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RDPM register through IBMAD\n");
                return status;
            }
            break;

#endif
        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_rdpm_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RDPM register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RDPM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_rica(struct ku_rica_reg      *rica_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rica_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rica_reg *curr_reg_data = rica_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rica_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rica_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RICA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RICA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rica_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rica_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RICA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RICA register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RICA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rrcr(struct ku_rrcr_reg      *rrcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rrcr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rrcr_reg *curr_reg_data = rrcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rrcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rrcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RRCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RRCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rrcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rrcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RRCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RRCR register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RRCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_rtca(struct ku_rtca_reg      *rtca_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rtca_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rtca_reg *curr_reg_data = rtca_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rtca_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rtca_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RTCA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RTCA register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_rtca_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RTCA register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rtca_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rtca_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RTCA register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RTCA register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RTCA register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_rtps(struct ku_rtps_reg      *rtps_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rtps_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rtps_reg *curr_reg_data = rtps_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rtps_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rtps_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RTPS register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RTPS register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_rtps_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RTPS register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rtps_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rtps_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RTPS register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RTPS register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RTPS register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rigr(struct ku_rigr_reg      *rigr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rigr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rigr_reg *curr_reg_data = rigr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rigr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rigr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RIGR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RIGR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RIGR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rmeir(struct ku_rmeir_reg     *rmeir_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rmeir_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_rmeir_reg *curr_reg_data = rmeir_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_rmeir_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rmeir_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMEIR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMEIR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMEIR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rmid(struct ku_rmid_reg      *rmid_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rmid_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rmid_reg *curr_reg_data = rmid_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_rmid_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rmid_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMID register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMID register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMID register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rmpu(struct ku_rmpu_reg      *rmpu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rmpu_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rmpu_reg *curr_reg_data = rmpu_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_rmpu_set(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMPU register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMPU register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMPU register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ricnt(struct ku_ricnt_reg     *ricnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ricnt_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_ricnt_reg *curr_reg_data = ricnt_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ricnt_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ricnt_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RICNT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RICNT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x100, ricnt, RICNT);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RICNT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_recr(struct ku_recr_reg      *recr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_recr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_recr_reg *curr_reg_data = recr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_recr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_recr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RECR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RECR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_recr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_recr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RECR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RECR register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RECR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_recr_v2(struct ku_recr_v2_reg   *recr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    dpt_encapsulation_t     encapsulation = INVALID_PATH;
    internal_path_params_t  params;
    sxd_status_t            status = SXD_STATUS_SUCCESS;
    sxd_emad_recr_v2_data_t reg_data;
    swid_type_t             swid_type;
    uint32_t                i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t        *curr_reg_meta = reg_meta + i;
        struct ku_recr_v2_reg *curr_reg_data = recr_v2_reg_data + i;
        sxd_access_cmd_t       access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t           dev_id = curr_reg_meta->dev_id;
        sxd_swid_t             swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_recr_v2_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_recr_v2_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RECRv2 register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RECRv2 register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x50, recr_v2, RECRV2);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RECRv2 register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_rtar(struct ku_rtar_reg      *rtar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rtar_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rtar_reg *curr_reg_data = rtar_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rtar_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rtar_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RTAR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RTAR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rtar_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rtar_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RTAR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RTAR register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RTAR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ritr(struct ku_ritr_reg      *ritr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ritr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;
    struct ku_ritr_reg     cmd_ifc_ritr_reg_data;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_ritr_reg *curr_reg_data = ritr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        /* Copy the ritr_reg_data.
         * sxd_emad_ritr_set changes ritr_reg_data values,
         * and we need the original values to update the driver DB using
         * sxd_command_ifc_set_port_rp_mode */
        memcpy(&cmd_ifc_ritr_reg_data, curr_reg_data, sizeof(cmd_ifc_ritr_reg_data));

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            goto update_driver; /* even if FW is not updated, must update driver's DB (ISSU case) */
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_ritr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ritr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RITR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RITR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x100, ritr, RITR);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RITR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }

update_driver: /* we are still in the for-loop */

        /* WA for incorrect swid */
        /* Case add / delete port rif
         * Update mapping (port, vlan) -> rif in driver DB */

        if (access_cmd == SXD_ACCESS_CMD_GET) {
            continue;
        }

        if (cmd_ifc_ritr_reg_data.type != SUB_PORT_INTERFACE) {
            continue;
        }

        status = sxd_command_ifc_set_port_rp_mode(hw_p->cmd_ifc_hw_p,
                                                  dev_id,
                                                  cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.lag,
                                                  cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.system_port,
                                                  cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.vlan_id,
                                                  cmd_ifc_ritr_reg_data.valid,
                                                  access_cmd,
                                                  cmd_ifc_ritr_reg_data.router_interface,
                                                  cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.efid);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed sxd_command_ifc_set_port_rp_mode: "
                       "is_lag:%d sys_port:%d, valid:%d status: %d\n",
                       cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.lag,
                       cmd_ifc_ritr_reg_data.rif_properties.sub_port_interface.system_port,
                       cmd_ifc_ritr_reg_data.valid,
                       status);
            return status;
        }
    } /* end of for-loop [ for (i = 0; i < data_num; i++) ] */

    return status;
}


sxd_status_t sxd_access_reg_rgcr(struct ku_rgcr_reg      *rgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rgcr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rgcr_reg *curr_reg_data = rgcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rgcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rgcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RGCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RGCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_rgcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RGCR register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rgcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rgcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RGCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RGCR register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RGCR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rmft(struct ku_rmft_reg      *rmft_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rmft_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rmft_reg *curr_reg_data = rmft_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rmft_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rmft_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMFT register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMFT register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMFT register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rmft_v2(struct ku_rmft_v2_reg   *rmft_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    dpt_encapsulation_t     encapsulation = INVALID_PATH;
    internal_path_params_t  params;
    sxd_status_t            status = SXD_STATUS_SUCCESS;
    sxd_emad_rmft_v2_data_t reg_data;
    swid_type_t             swid_type;
    uint32_t                i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t        *curr_reg_meta = reg_meta + i;
        struct ku_rmft_v2_reg *curr_reg_data = rmft_v2_reg_data + i;
        sxd_access_cmd_t       access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t           dev_id = curr_reg_meta->dev_id;
        sxd_swid_t             swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_rmft_v2_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rmft_v2_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMFTv2 register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMFTv2 register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMFTv2 register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_rcap(struct ku_rcap_reg      *rcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rcap_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_rcap_reg *curr_reg_data = rcap_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rcap_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RCAP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RCAP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_rcap_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_rcap_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of RCAP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing RCAP register through IBMAD\n");
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing RCAP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_mpar(struct ku_mpar_reg      *mpar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mpar_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mpar_reg *curr_reg_data = mpar_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mpar_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mpar_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of mpar register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPAR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0xc, mpar, MPAR);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing mpar register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sbib(struct ku_sbib_reg      *sbib_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbib_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbib_reg *curr_reg_data = sbib_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbib_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbib_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of sbib register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBIB register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x10, sbib, SBIB);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing sbib register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_plbf(struct ku_plbf_reg      *plbf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_plbf_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_plbf_reg *curr_reg_data = plbf_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE) ||
                (access_cmd == SXD_ACCESS_CMD_GET)) {
                status = sxd_emad_plbf_access(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PLBF register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PLBF register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_plbf_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing plbf register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_plbf_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_plbf_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PLBF register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PLBF register through IBMAD"
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PLBF register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mhsr(struct ku_mhsr_reg      *mhsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context __attribute__((unused)))
{
    return sxd_access_reg_common(mhsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MHSR_E);
}

sxd_status_t sxd_access_reg_msci(struct ku_msci_reg      *msci_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_msci_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_msci_reg *curr_reg_data = msci_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_msci_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_msci_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MSCI register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MSCI register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_msci_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing plbf register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_msci_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_msci_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MSCI register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MSCI register through IBMAD"
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MSCI register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mrsr(struct ku_mrsr_reg      *mrsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mrsr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mrsr_reg *curr_reg_data = mrsr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mrsr_set(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MRSR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MRSR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mrsr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing plbf register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing MRSR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

static sxd_status_t sxd_access_reg_mtbr_basic(struct ku_mtbr_reg      *mtbr_reg_data,
                                              sxd_reg_meta_t          *reg_meta,
                                              uint32_t                 data_num,
                                              sxd_completion_handler_t handler,
                                              void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mtbr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    UNUSED_PARAM(context);

    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mtbr_reg *curr_reg_data = mtbr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mtbr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mtbr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MTBR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MTBR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mtbr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mtbr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("There is no valid path for accessing MTBR register\n");
                return SXD_STATUS_ERROR;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MTBR register through IBMAD "
                           "dev id %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        case CMD_IFC_PATH:
            if (curr_reg_data->num_rec > MTBR_MAX_TEMPERATURE_RECORDS) {
                SX_LOG_ERR("MTBR number of records (%u) exceeds max range (%u) \n",
                           curr_reg_data->num_rec,
                           MTBR_MAX_TEMPERATURE_RECORDS);
                return SXD_STATUS_PARAM_ERROR;
            }
            status = sxd_command_ifc_access_mtbr_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MTBR register through CMD IFC\n");
                printf("Failed accessing MTBR register through CMD IFC for device %d\n", dev_id);
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing MTBR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

static void mtbr_temperature_to_celsius(uint16_t utemperature, struct temperature_double *temp_celsius)
{
    int16_t signed_temperature = 0;
    int32_t temp_to_calculate = 0;
    int16_t diff = 0;

    memset(temp_celsius, 0, sizeof(*temp_celsius));

    switch (utemperature) {
    case 0:
        utemperature = SXD_MTBR_NO_SENSOR;

    /* fall through */
    case SXD_MTBR_READ_FAILED:
    case SXD_MTBR_NO_CABLE:
    case SXD_MTBR_NO_READ:
    case SXD_MTBR_INVALID_INDEX:
        temp_celsius->integer_part = utemperature;
        break;

    case 1:
        utemperature = 0;

    /* fall through */
    default:
        if (((int16_t)utemperature) < 0) {
            signed_temperature = (0xFFFF + ((int16_t)utemperature) + 1);

            temp_to_calculate = (int32_t)signed_temperature * SXD_MTBR_TEMPERATURE_MULT * SXD_MTBR_TEMPERATURE_UNIT;
            temp_celsius->integer_part = (int16_t)(temp_to_calculate / SXD_MTBR_TEMPERATURE_MULT);

            diff = (temp_celsius->integer_part / SXD_MTBR_TEMPERATURE_UNIT - signed_temperature);
            temp_to_calculate = diff * SXD_MTBR_TEMPERATURE_MULT * SXD_MTBR_TEMPERATURE_UNIT;
            temp_celsius->fractional_part = (int16_t)(temp_to_calculate % SXD_MTBR_TEMPERATURE_MULT);
        } else {
            signed_temperature = (int16_t)utemperature;

            temp_to_calculate = (int32_t)signed_temperature * SXD_MTBR_TEMPERATURE_MULT * SXD_MTBR_TEMPERATURE_UNIT;
            temp_celsius->integer_part = (int16_t)(temp_to_calculate / SXD_MTBR_TEMPERATURE_MULT);
            temp_celsius->fractional_part = (int16_t)(temp_to_calculate % SXD_MTBR_TEMPERATURE_MULT);
        }
    }
    return;
}

sxd_status_t sxd_access_reg_mtbr(struct ku_mtbr_reg_ext  *mtbr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    struct ku_mtbr_reg mtbr_data;
    uint32_t           i = 0, j = 0;
    sxd_status_t       status = SXD_STATUS_SUCCESS;

    /* convert _ext type to array of ku_mtbr_reg */
    for (i = 0; i < data_num; i++) {
        memset(&mtbr_data, 0, sizeof(mtbr_data));
        mtbr_data.base_sensor_index = mtbr_reg_data[i].base_sensor_index;
        mtbr_data.num_rec = mtbr_reg_data[i].num_rec;

        status = sxd_access_reg_mtbr_basic(&mtbr_data, reg_meta, 1, handler, context);
        if (SXD_STATUS_SUCCESS != status) {
            SX_LOG_ERR("failed to access mtbr_basic() in iteration %u status=%u\n", i, status);
            break;
        }

        /* convert results to temperature in Celsius */
        mtbr_reg_data[i].num_rec = mtbr_data.num_rec;
        for (j = 0; j < mtbr_data.num_rec; j++) {
            mtbr_temperature_to_celsius(mtbr_data.temperature_record[j].max_temperature,
                                        &mtbr_reg_data[i].temperature_record[j].max_temperature);
            mtbr_temperature_to_celsius(mtbr_data.temperature_record[j].temperature,
                                        &mtbr_reg_data[i].temperature_record[j].temperature);
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_sbpr(struct ku_sbpr_reg      *sbpr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbpr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbpr_reg *curr_reg_data = sbpr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbpr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbpr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SBPR register is not valid [cmd=%d]\n", access_cmd);
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBPR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x18, sbpr, SBPR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SBPR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sbsr(struct ku_sbsr_reg      *sbsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbsr_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbsr_reg *curr_reg_data = sbsr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbsr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbsr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SBSR register is not valid [cmd=%d]\n", access_cmd);
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBSR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x41c, sbsr, SBSR);
        } else {
            SX_LOG_ERR("There is no valid path for accessing SBSR register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_sbcm(struct ku_sbcm_reg      *sbcm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = EMAD_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbcm_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbcm_reg *curr_reg_data = sbcm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbcm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbcm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SBCM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBCM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x30, sbcm, SBCM);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing SBCM register dev %d local_port %d lp_msb %d\n",
                       reg_meta->dev_id,
                       sbcm_reg_data->local_port,
                       sbcm_reg_data->lp_msb);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sbpm(struct ku_sbpm_reg      *sbpm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = EMAD_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbpm_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbpm_reg *curr_reg_data = sbpm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbpm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbpm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SBPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x20, sbpm, SBPM);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing SBPM register dev %d local_port %d lp_msb %d \n",
                       reg_meta->dev_id,
                       sbpm_reg_data->local_port,
                       sbpm_reg_data->lp_msb);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_sbmm(struct ku_sbmm_reg      *sbmm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = EMAD_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_sbmm_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_sbmm_reg *curr_reg_data = sbmm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_sbmm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_sbmm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of SBMM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBMM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_sbmm_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing SBMM register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing SBMM register dev %d switch prio %d \n",
                       reg_meta->dev_id,
                       sbmm_reg_data->prio);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpdpm(struct ku_qpdpm_reg     *qpdpm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpdpm_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_qpdpm_reg *curr_reg_data = qpdpm_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpdpm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpdpm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPDPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPDPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x84, qpdpm, QPDPM);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPDPM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qepm(struct ku_qepm_reg      *qepm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qepm_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qepm_reg *curr_reg_data = qepm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qepm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qepm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QEPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QEPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x14, qepm, QEPM);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QEPM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qrwe(struct ku_qrwe_reg      *qrwe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qrwe_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qrwe_reg *curr_reg_data = qrwe_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qrwe_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qrwe_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QRWE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QRWE register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 8, qrwe, QRWE);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QRWE register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpem(struct ku_qpem_reg      *qpem_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpem_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qpem_reg *curr_reg_data = qpem_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpem_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpem_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPEM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPEM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_qpem_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPEM register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPEM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qpdsm(struct ku_qpdsm_reg     *qpdsm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qpdsm_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_qpdsm_reg *curr_reg_data = qpdsm_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qpdsm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qpdsm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPDSM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPDSM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x44, qpdsm, QPDSM);
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPDSM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_qppm(struct ku_qppm_reg      *qppm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_qppm_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_qppm_reg *curr_reg_data = qppm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_qppm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_qppm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of QPPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_qppm_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing QPPM register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing QPPM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

/**
 *  This function performs access register CWCP operations.
 *
 * @param[in] cwtp_reg_data		 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwtp(struct ku_cwtp_reg      *cwtp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_cwtp_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_cwtp_reg *curr_reg_data = cwtp_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_cwtp_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_cwtp_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of CWTP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing CWTP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else if (CMD_IFC_PATH == encapsulation) {
            status = sxd_command_ifc_access_cwtp_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing CWTP register through CMD IFC\n");
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing CWTP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

/**
 *  This function performs access register CWPP operations.
 *
 * @param[in] cwpp_reg_data		 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwpp(struct ku_cwpp_reg      *cwpp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_cwpp_data_t   reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_cwpp_reg *curr_reg_data = cwpp_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_cwpp_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_cwpp_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of CWPP register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing CWPP register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing CWPP register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


/**
 *  This function performs access register CWPPM operations.
 *
 * @param[in] cwppm_reg_data	 - The registers data
 * @param[in] reg_meta           - The registers meta data
 * @param[in] data_num           - Number of access operations to perform
 * @param[in] handler            - Handler function for calling when the operation completes
 * @param[in] context                    - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_cwppm(struct ku_cwppm_reg     *cwppm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_cwppm_data_t  reg_data;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_cwppm_reg *curr_reg_data = cwppm_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP,
                                       &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        if (EMAD_PATH == encapsulation) {
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_cwppm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_cwppm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of CWPPM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing CWPPM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }
        } else {
            SX_LOG_ERR("There is no valid path for accessing CWPPM register encapsulation = %d\n", encapsulation);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ralue(struct ku_ralue_reg     *ralue_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ralue_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_ralue_reg *curr_reg_data = ralue_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_ralue_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ralue_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RALUE register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RALUE register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = SXD_REG_CMD_IFC_IMP(dev_id, access_cmd, curr_reg_data, 0x3c, ralue, RALUE);
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RALUE register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ralbu(struct ku_ralbu_reg     *ralbu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ralbu_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_ralbu_reg *curr_reg_data = ralbu_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_ralbu_set(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RALBU register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RALBU register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RALBU register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_plpc(struct ku_plpc_reg      *plpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_plpc_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_plpc_reg *curr_reg_data = plpc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_plpc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_plpc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PLPC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PLPC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_plpc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PLPC register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_plpc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_plpc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PLPC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PLPC register through IBMAD "
                           "dev %d.\n", reg_meta->dev_id);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PLPC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_pplm(struct ku_pplm_reg      *pplm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_pplm_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_pplm_reg *curr_reg_data = pplm_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_pplm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_pplm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PPLM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PPLM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_pplm_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PPLM register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_pplm_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_pplm_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of PPLM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing PPLM register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, pplm_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing PPLM register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_mpsc(struct ku_mpsc_reg      *mpsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mpsc_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mpsc_reg *curr_reg_data = mpsc_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mpsc_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mpsc_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MPSC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPSC register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mpsc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPSC register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mpsc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mpsc_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("The access command of MPSC register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MPSC register through IBMAD "
                           "dev %d port %d. Moving to CMD IFC\n", reg_meta->dev_id, mpsc_reg_data->local_port);
                status = sxd_command_ifc_access_mpsc_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                         dev_id, curr_reg_data);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed accessing MPSC register through CMD IFC\n");
                    return status;
                }
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MPSC register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mlcr(struct ku_mlcr_reg      *mlcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mlcr_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mlcr_reg *curr_reg_data = mlcr_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mlcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mlcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MLCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MLCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mlcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MLCR register through CMD IFC\n");
            }
            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = mad_set_mlcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = mad_get_mlcr_reg(hw_p->sport, dev_id, &params.dr_params, curr_reg_data);
            } else {
                SX_LOG_ERR("There is no valid path for accessing MLCR register\n");
                return SXD_STATUS_ERROR;
            }
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_WRN("Failed accessing MLCR register through IBMAD "
                           "dev %d port %d.\n", reg_meta->dev_id, mlcr_reg_data->local_port);
                return status;
            }
            break;

#endif
        default:
            SX_LOG_ERR("There is no valid path for accessing MLCR register dev %d, local_port %d, lp_msb %d \n",
                       reg_meta->dev_id,
                       mlcr_reg_data->local_port,
                       mlcr_reg_data->lp_msb);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mdri(struct ku_mdri_reg      *mdri_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mdri_data_t   reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t     *curr_reg_meta = reg_meta + i;
        struct ku_mdri_reg *curr_reg_data = mdri_reg_data + i;
        sxd_access_cmd_t    access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t        dev_id = curr_reg_meta->dev_id;
        sxd_swid_t          swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET)) {
                status = sxd_emad_mdri_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mdri_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MDRI register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MDRI register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mdri_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                     dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MDRI register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing MDRI register dev %d \n",
                       reg_meta->dev_id);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mpgcr(struct ku_mpgcr_reg     *mpgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mpgcr_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_mpgcr_reg *curr_reg_data = mpgcr_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mpgcr_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mpgcr_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MPGCR register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPGCR register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mpgcr_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPGCR register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing MPGCR register dev %d\n",
                       reg_meta->dev_id);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_mpilm(struct ku_mpilm_reg     *mpilm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_mpilm_data_t  reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t      *curr_reg_meta = reg_meta + i;
        struct ku_mpilm_reg *curr_reg_data = mpilm_reg_data + i;
        sxd_access_cmd_t     access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t         dev_id = curr_reg_meta->dev_id;
        sxd_swid_t           swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_mpilm_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_mpilm_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of MPILM register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPILM register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        case CMD_IFC_PATH:
            status = sxd_command_ifc_access_mpilm_reg(hw_p->cmd_ifc_hw_p, access_cmd,
                                                      dev_id, curr_reg_data);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing MPILM register through CMD IFC\n");
            }
            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing MPILM register dev %d port\n",
                       reg_meta->dev_id);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_mpibe(struct ku_mpibe_reg     *mpibe_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mpibe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPIBE_E);
}


sxd_status_t sxd_access_reg_sbdcc(struct ku_sbdcc_reg     *sbdcc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbdcc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBDCC_E);
}

sxd_status_t sxd_access_reg_sbdcm(struct ku_sbdcm_reg     *sbdcm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbdcm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBDCM_E);
}

sxd_status_t sxd_access_reg_sbhbr(struct ku_sbhbr_reg     *sbhbr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbhbr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBHBR_E);
}

sxd_status_t sxd_access_reg_sbhrr(struct ku_sbhrr_reg     *sbhrr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbhrr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBHRR_E);
}

sxd_status_t sxd_access_reg_sbctc(struct ku_sbctc_reg     *sbctc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    sxd_status_t      rc = SXD_STATUS_SUCCESS;
    sxd_port_phy_id_t local_port = 0;


    if ((reg_meta->access_cmd == SXD_ACCESS_CMD_SET) && (sbctc_reg_data->is_port_profile == FALSE)) {
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          sbctc_reg_data->local_port,
                                          sbctc_reg_data->lp_msb);

        rc = sxd_access_reg_tele_threshold_set(local_port,
                                               sbctc_reg_data->dir_ing,
                                               sbctc_reg_data->tclass_en);
        if (rc != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to set sbctc configuration in driver (rc=%d).\n", rc);
            return rc;
        }
    }


    return sxd_access_reg_common(sbctc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBCTC_E);
}

sxd_status_t sxd_access_reg_ppbmi(struct ku_ppbmi_reg     *ppbmi_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppbmi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBMI_E);
}

sxd_status_t sxd_access_reg_ppbmp(struct ku_ppbmp_reg     *ppbmp_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppbmp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBMP_E);
}

sxd_status_t sxd_access_reg_ppbmc(struct ku_ppbmc_reg     *ppbmc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    sxd_status_t      rc = SXD_STATUS_SUCCESS;
    sxd_port_phy_id_t ppbmc_local_port = 0;

    SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(ppbmc_local_port,
                                      ppbmc_reg_data->local_port,
                                      ppbmc_reg_data->lp_msb);

    if (reg_meta->access_cmd == SXD_ACCESS_CMD_SET) {
        rc = sxd_access_reg_port_ber_monitor_bitmask_set(reg_meta->dev_id,
                                                         ppbmc_local_port,
                                                         ppbmc_reg_data->event_ctrl);
        if (rc != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to set ppbmc configuration in driver (rc=%d).\n", rc);
            return rc;
        }
    }

    return sxd_access_reg_common(ppbmc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBMC_E);
}

sxd_status_t sxd_access_reg_qpsc(struct ku_qpsc_reg      *qpsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qpsc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QPSC_E);
}

sxd_status_t sxd_access_reg_qhll(struct ku_qhll_reg      *qhll_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qhll_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QHLL_E);
}

sxd_status_t sxd_access_reg_mtpptr(struct ku_mtpptr_reg    *mtpptr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtpptr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPPTR_E);
}

sxd_status_t sxd_access_reg_ptce3(struct ku_ptce3_reg     *ptce3_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ptce3_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PTCE3_E);
}

sxd_status_t sxd_access_reg_mtpppc(struct ku_mtpppc_reg    *mtpppc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtpppc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPPPC_E);
}

sxd_status_t sxd_access_reg_perpt(struct ku_perpt_reg     *perpt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(perpt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERPT_E);
}

sxd_status_t sxd_access_reg_percr(struct ku_percr_reg     *percr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(percr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERCR_E);
}

sxd_status_t sxd_access_reg_pererp(struct ku_pererp_reg    *pererp_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pererp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERERP_E);
}

sxd_status_t sxd_access_reg_peabfe(struct ku_peabfe_reg    *peabfe_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(peabfe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEABFE_E);
}

#define MNVDA_VALID_DATA                 2
#define MNVDA_TYPE_CLASS_OFFSET_IN_DWORD 24

sxd_status_t sxd_access_reg_nv_switch_conf(ku_nv_switch_conf_t     *nv_switch_conf,
                                           sxd_reg_meta_t          *reg_meta,
                                           uint32_t                 data_num,
                                           sxd_completion_handler_t handler,
                                           void                    *context)
{
    sxd_status_t                       rc;
    struct ku_mnvda_nv_switch_conf_reg nv_switch_conf_reg_data;

    nv_switch_conf_reg_data.nv_switch_conf = *nv_switch_conf;
    nv_switch_conf_reg_data.length = SXD_MNVDA_LENGTH_NV_SWITCH_CONF;
    nv_switch_conf_reg_data.type_class_index =
        (SXD_MNVDA_TYPE_CLASS_NV_SWITCH_CONF <<
            MNVDA_TYPE_CLASS_OFFSET_IN_DWORD) | SXD_MNVDA_TYPE_INDEX_NV_SWITCH_CONF;
    rc = sxd_access_reg_common(&nv_switch_conf_reg_data,
                               reg_meta,
                               data_num,
                               handler,
                               context,
                               SXD_REG_ID_MNVDA_E);
    SX_LOG_DBG("sxd_access_reg_nv_switch_conf MNVDA return values: valid %u, length %u, type_class_index 0x%x\n",
               nv_switch_conf_reg_data.valid,
               nv_switch_conf_reg_data.length,
               nv_switch_conf_reg_data.type_class_index);
    *nv_switch_conf = nv_switch_conf_reg_data.nv_switch_conf;
    if ((reg_meta->access_cmd == SXD_ACCESS_CMD_GET) && (nv_switch_conf_reg_data.valid != MNVDA_VALID_DATA)) {
        rc = SXD_STATUS_ERROR;
        SX_LOG_ERR("sxd_access_reg_nv_switch_conf error - MNVDA returned bad valid data value - %u\n",
                   nv_switch_conf_reg_data.valid);
    }
    return rc;
}

sxd_status_t sxd_access_reg_rmftad(struct ku_rmftad_reg    *rmftad_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_rmftad_data_t reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t       *curr_reg_meta = reg_meta + i;
        struct ku_rmftad_reg *curr_reg_data = rmftad_reg_data + i;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if (((access_cmd == SXD_ACCESS_CMD_SET) ||
             (access_cmd == SXD_ACCESS_CMD_ADD) ||
             (access_cmd == SXD_ACCESS_CMD_DELETE)) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if ((access_cmd == SXD_ACCESS_CMD_SET) ||
                (access_cmd == SXD_ACCESS_CMD_ADD) ||
                (access_cmd == SXD_ACCESS_CMD_DELETE)) {
                status = sxd_emad_rmftad_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_rmftad_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of RMFTAD register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing RMFTAD register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing RMFTAD register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}

sxd_status_t sxd_access_reg_ptcead(struct ku_ptcead_reg    *ptcead_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    internal_path_params_t params;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    sxd_emad_ptcead_data_t reg_data;
    swid_type_t            swid_type;
    uint32_t               i;

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    for (i = 0; i < data_num; i++) {
        sxd_reg_meta_t       *curr_reg_meta = reg_meta + i;
        struct ku_ptcead_reg *curr_reg_data = ptcead_reg_data + i;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
            SX_LOG_ERR("The access control for device %u was not set\n", dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        if ((access_cmd == SXD_ACCESS_CMD_SET) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get swid type from the DPT\n");
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, THIRD_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            reg_data.reg_data = curr_reg_data;
            build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);

            if (access_cmd == SXD_ACCESS_CMD_SET) {
                status = sxd_emad_ptcead_set(&reg_data, 1, handler, context);
            } else if (access_cmd == SXD_ACCESS_CMD_GET) {
                status = sxd_emad_ptcead_get(&reg_data, 1, handler, context);
            } else {
                SX_LOG_ERR("The access command of PTCEAD register is not valid\n");
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed accessing PTCEAD register through EMAD (iteration %u) for device %u (err=%d)\n",
                           i,
                           dev_id,
                           status);
                return status;
            }

            break;

        default:
            SX_LOG_ERR("There is no valid path for accessing PTCEAD register\n");
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}


sxd_status_t sxd_access_reg_svfa_kdb_set(sxd_dev_id_t      dev_id,
                                         sxd_port_phy_id_t local_port,
                                         uint16_t          vid,
                                         uint8_t           is_mapped_to_fid,
                                         uint16_t          fid)
{
    return sxd_command_ifc_set_port_vid_to_fid_map(hw_p->cmd_ifc_hw_p, dev_id, local_port,
                                                   vid, is_mapped_to_fid, fid);
}


sxd_status_t sxd_set_device_info(struct ku_dev_info *dev_info_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_set_device_info(hw_p->cmd_ifc_hw_p, dev_info_p);
}

sxd_status_t sxd_get_device_info(struct ku_dev_info *dev_info_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_get_device_info(hw_p->cmd_ifc_hw_p, dev_info_p);
}

/* sometimes we need to use direct sxd_ioctl() call and not via sxd_get_device_info()
 * because this API the caller might be called in a very early stage, before
 * sxd_access_reg_init() call that initializes hw_p. Moreover, sxd_access_reg_init()
 * might not be called at all on SDK client side.
 */
sxd_status_t sxd_get_device_info_with_handle(sxd_handle handle, struct ku_dev_info *dev_info_p)
{
    sxd_ctrl_pack_t ctrl_pack;

    if (!dev_info_p) {
        return SXD_STATUS_PARAM_ERROR;
    }

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));
    ctrl_pack.ctrl_cmd = CTRL_CMD_GET_DEV_INFO;
    ctrl_pack.cmd_body = dev_info_p;
    return (sxd_ioctl(handle, &ctrl_pack) == 0) ? SXD_STATUS_SUCCESS : SXD_STATUS_ERROR;
}

sxd_status_t sxd_host_mem_page_get(struct ku_host_mem_read_page *host_mem_page_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_host_mem_page_get(hw_p->cmd_ifc_hw_p, host_mem_page_p);
}

sxd_status_t sxd_set_mad_demux(sxd_dev_id_t dev_id, uint8_t enable)
{
    return sxd_command_ifc_set_mad_demux(hw_p->cmd_ifc_hw_p, dev_id, enable);
}


sxd_status_t sxd_set_sw_ib_node_description(struct ku_ib_node_description *node_desc)
{
    return sxd_command_ifc_set_sw_ib_node_description(hw_p->cmd_ifc_hw_p, node_desc);
}


sxd_status_t sxd_access_sdk_health_state_set(uint8_t dev_id, boolean_t sdk_health_state)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_sdk_health_state_set(hw_p->cmd_ifc_hw_p, dev_id, sdk_health_state);
}

sxd_status_t sxd_access_sdk_health_state_get(uint8_t dev_id, boolean_t test_and_disable,
                                             boolean_t  *sdk_health_state_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_sdk_health_state_get(hw_p->cmd_ifc_hw_p, dev_id,  test_and_disable, sdk_health_state_p);
}

void sxd_access_sdk_ptys_eth_proto_cap_for_pd_set(struct ku_ptys_reg * ptys_reg_data)
{
    ptys_reg_data->ext_eth_proto_capability = 0x97f2;
}

sxd_status_t sxd_access_bulk_stateful_db_keys_set(ku_stateful_db_translated_entry_t *translated_entry_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        return SXD_STATUS_NOT_INITIALIZED;
    }
    return sxd_command_ifc_bulk_stateful_db_keys_set(hw_p->cmd_ifc_hw_p, translated_entry_p);
}
