/*
 * Copyright (C) 2001-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/cr_access.h>
#include <complib/sx_log.h>
#include <sys/mman.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sxd_handle handle = 0;
static int        initialized = 0;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

int sx_cr_access_init(void)
{
    int      err = 0, i = 0, ret = 0;
    char     dev_name[MAX_SX_DEVS][MAX_NAME_LEN];
    char    *dev_name_p[MAX_SX_DEVS];
    uint32_t dev_num = MAX_SX_DEVS;

    /* Print here that we are running */
    if (initialized) {
        goto bail;
    }

    for (i = 0; i < MAX_SX_DEVS; ++i) {
        dev_name_p[i] = dev_name[i];
    }

    ret = sxd_get_dev_list(dev_name_p, &dev_num);
    if (ret < 0) {
        /* SX_LOG(SX_LOG_ERROR, "sxd_get_dev_list error: %s\n", strerror(errno)); */
        err = -1;
        goto bail;
    } else if (ret > 0) {
        /* SX_LOG(SX_LOG_ERROR, "Unsupported SX device number: %u\n", dev_num); */
        err = -1;
        goto bail;
    }

    /* there should be only 1 char device - use the first one*/
    ret = sxd_open_device(dev_name[0], &handle);
    if (ret) {
        /* SX_LOG(SX_LOG_ERROR, "sxd_open_device error: %s\n", strerror(errno)); */
        err = -1;
        goto bail;
    }
bail:
    if (!err) {
        initialized = 1;
    }
    return err;
}


int sx_cr_access_deinit(void)
{
    int err = 0;

    /* SX_LOG_ENTER(); */
    if (!initialized) {
        goto bail;
    }

    err = sxd_close_device(handle);
    if (err) {
        /* SX_LOG(SX_LOG_ERROR, "sxd_close_device error: %s\n", strerror(errno)); */
        err = -1;
        goto bail;
    }

bail:
    if (!err) {
        initialized = 0;
    }
    return err;
}


sxd_status_t sx_cr_access_read(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len)
{
    sxd_status_t            err = SXD_STATUS_SUCCESS;
    struct ku_cr_space_read cr_space_read_data;
    sxd_ctrl_pack_t         ctrl_pack = { .ctrl_cmd = CTRL_CMD_CR_SPACE_READ,
                                          .cmd_body = NULL};

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!data || (byte_len <= 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    cr_space_read_data.address = offset;
    cr_space_read_data.data = data;
    cr_space_read_data.dev_id = dev_id;
    cr_space_read_data.size = byte_len;
    ctrl_pack.cmd_body = (void*)&cr_space_read_data;
    err = sxd_ioctl(handle, &ctrl_pack);

    if (err) {
        /* SX_LOG_ERR("could not read device:[%d] offset:[%0xlx] length:[%d] code:[%d, %s]\n",
         *          dev_id, offset, byte_len, errno, strerror(errno)); */
        err = SXD_STATUS_ERROR;
        goto bail;
    }

bail:
    return err;
}


sxd_status_t sx_cr_access_write(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len)
{
    sxd_status_t             err = SXD_STATUS_SUCCESS;
    struct ku_cr_space_write cr_space_write_data;
    sxd_ctrl_pack_t          ctrl_pack = { .ctrl_cmd = CTRL_CMD_CR_SPACE_WRITE,
                                           .cmd_body = NULL};

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!data || (byte_len <= 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    cr_space_write_data.address = offset;
    cr_space_write_data.data = data;
    cr_space_write_data.dev_id = dev_id;
    cr_space_write_data.size = byte_len;
    ctrl_pack.cmd_body = (void*)&cr_space_write_data;
    err = sxd_ioctl(handle, &ctrl_pack);

    if (err) {
        /* SX_LOG_ERR("could not write device:[%d] offset:[%0xlx] length:[%d] code:[%d, %s]\n",
         *          dev_id, offset, byte_len, errno, strerror(errno)); */
        err = SXD_STATUS_ERROR;
        goto bail;
    }

bail:
    return err;
}

sxd_status_t sx_cr_dump_get_pid(pid_t *pid)
{
    sxd_status_t             err = SXD_STATUS_SUCCESS;
    struct ku_client_pid_get client_pid;
    sxd_ctrl_pack_t          ctrl_pack;

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!pid) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_CLIENT_PID_GET;
    ctrl_pack.cmd_body = &client_pid;
    err = sxd_ioctl(handle, &ctrl_pack);
    if (err != SXD_STATUS_SUCCESS) {
        goto bail;
    }
    *pid = client_pid.pid;

bail:
    return err;
}

sxd_status_t sx_cr_dump_set_mem_alloc_scheme_kmalloc(void)
{
    sxd_status_t             err = SXD_STATUS_SUCCESS;
    ku_mmap_mem_alloc_data_t mem_alloc_data;
    sxd_ctrl_pack_t          ctrl_pack;

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    memset(&mem_alloc_data, 0, sizeof(mem_alloc_data));
    mem_alloc_data.alloc_scheme = KU_MMAP_MEM_ALLOC_SCHEME_KMALLOC;

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_MMAP_MEM_ALLOC_SCHEME;
    ctrl_pack.cmd_body = &mem_alloc_data;
    err = sxd_ioctl(handle, &ctrl_pack);
    if (err != SXD_STATUS_SUCCESS) {
        goto bail;
    }

bail:
    return err;
}

sxd_status_t sx_cr_dump(u_int8_t               dev_id,
                        u_int8_t               opcode,
                        pid_t                  pid,
                        unsigned int           dumped_size,
                        u_int8_t              *data,
                        int                    byte_len,
                        struct sx_cr_dump_ret *ret)
{
    sxd_status_t      err = SXD_STATUS_SUCCESS;
    struct ku_cr_dump cr_dump_read_data;
    sxd_ctrl_pack_t   ctrl_pack = { .ctrl_cmd = CTRL_CMD_CR_DUMP,
                                    .cmd_body = NULL};

    memset(&cr_dump_read_data, 0, sizeof(cr_dump_read_data));

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!data && (opcode != SX_CR_DUMP_OP_GET_GDB_DUMP_LIMIT)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    cr_dump_read_data.dumped_size = dumped_size;
    cr_dump_read_data.data = data;
    cr_dump_read_data.dev_id = dev_id;
    cr_dump_read_data.opcode = opcode;
    cr_dump_read_data.pid = pid;
    cr_dump_read_data.size = byte_len;
    ctrl_pack.cmd_body = (void*)&cr_dump_read_data;
    err = sxd_ioctl(handle, &ctrl_pack);
    memcpy(ret, &cr_dump_read_data.ret, sizeof(*ret));

bail:
    return err;
}

sxd_status_t sx_cr_dump_notify_dump_complete(u_int8_t dev_id, boolean_t query, fw_dump_completion_state_t *state)
{
    sxd_status_t                       err = SXD_STATUS_SUCCESS;
    struct ku_cr_dump_completion_state cr_dump_completion_state;
    sxd_ctrl_pack_t                    ctrl_pack = { .ctrl_cmd = CTRL_CMD_CR_DUMP_NOTIFY_DUMP_COMPLETE,
                                                     .cmd_body = NULL};
    boolean_t                          cr_access_inited = FALSE;

    if (!initialized) {
        err = sx_cr_access_init(); /* Initialize cr_access if needed */
        cr_access_inited = TRUE;
    }

    if (err) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    memset(&cr_dump_completion_state, 0, sizeof(cr_dump_completion_state));

    cr_dump_completion_state.dev_id = dev_id;
    cr_dump_completion_state.query = query;
    cr_dump_completion_state.state = *state;
    ctrl_pack.cmd_body = (void*)&cr_dump_completion_state;

    err = sxd_ioctl(handle, &ctrl_pack);
    memcpy(state, &cr_dump_completion_state.state, sizeof(*state));
    if (cr_access_inited) {
        err = sx_cr_access_deinit();
    }

bail:
    return err;
}

sxd_status_t sx_cr_dump_mmap(void **data, int byte_len)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!data || (byte_len <= 0) || (byte_len % SXD_CR_DUMP_HOST_MEM_ALIGN)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    /* create a shared memory between driver and user process */
    err = sxd_memory_map(handle, byte_len, data);
    if (err) {
        goto bail;
    }
    /* Some mismatch may occur in sxd_memory_map if big memory is allocated: data could be invalid while error being 0 */
    if ((*data == NULL) || (*data == MAP_FAILED)) {
        err = SXD_STATUS_NO_MEMORY;
    }

bail:
    return err;
}

sxd_status_t sx_cr_dump_munmap(u_int8_t *data, int byte_len)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if (!initialized) {
        err = SXD_STATUS_NOT_INITIALIZED;
        goto bail;
    }

    if (!data || (byte_len <= 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto bail;
    }

    /* create a shared memory between driver and user process */
    err = sxd_memory_unmap(data, byte_len);
    if (err) {
        goto bail;
    }

bail:
    return err;
}

int sx_cr_access_is_initialized(void)
{
    return initialized;
}
