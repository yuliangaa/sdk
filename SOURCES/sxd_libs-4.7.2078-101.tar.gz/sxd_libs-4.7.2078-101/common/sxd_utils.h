/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_UTILS_H__
#define __SXD_UTILS_H__

#include <complib/cl_spinlock.h>
#include <complib/sx_log.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

void sxd_set_last_fw_status(uint8_t fw_status, uint16_t register_id, uint8_t access_cmd, const char *emad_str);

/************************************************
 *  Defines
 ***********************************************/


/*
 * The macro uses cl_spinlock_acquire function to lock a spin lock
 */
#define M_SXD_UTILS_MUTEX_LOCK(mtx_p) cl_spinlock_acquire(mtx_p)

/*
 * The macro uses cl_spinlock_release function to release a spin lock
 */
#define M_SXD_UTILS_MUTEX_UNLOCK(mtx_p) cl_spinlock_release(mtx_p)

/*
 * The macro uses cl_spinlock_destroy function to deinitialize a spin lock
 */
#define M_SXD_UTILS_MUTEX_DEINIT(mtx_p) cl_spinlock_destroy(mtx_p)

/*
 * The macro check whether a spin lock has been initialized
 */
#define M_SXD_UTILS_MUTEX_IS_INITIALIZED(mtx_p) ((mtx_p)->state == CL_INITIALIZED)


/************************************************
 *  Macros
 ***********************************************/

/*
 * The macro uses cl_spinlock_init function to initialize a spin lock for use
 */
#define M_SXD_UTILS_MUTEX_INIT(mtx_p)         \
    if (cl_spinlock_init(mtx_p)) {            \
        SX_LOG_ERR("Failed to init mutex\n"); \
        return -errno;                        \
    }                                         \


#endif /* __SXD_UTILS_H__ */
