/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_passivelock.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_cos.h>
#include <sx/sxd/sxd_emad_fdb.h>
#include <sx/sxd/sxd_emad_host.h>
#include <sx/sxd/sxd_emad_lag.h>
#include <sx/sxd/sxd_emad_mstp.h>
#include <sx/sxd/sxd_emad_port.h>
#include <sx/sxd/sxd_emad_mpls.h>
#include <sx/sxd/sxd_emad_redecn.h>
#include <sx/sxd/sxd_emad_system.h>
#include <sx/sxd/sxd_emad_vlan.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_emad_tunnel.h>
#include <sx/sxd/sxd_emad_rm.h>
#ifdef SNIFFER_PRESENT
#include <sxd_sniffer/sniffer/sxd_sniffer.h>
#endif
#include "emad.h"
#include "emad_transaction.h"
#include "emad_transport.h"


#undef  __MODULE__
#define __MODULE__ EMAD

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/************************************************
 *  Global variables
 ***********************************************/

#if defined(PD_BU)
#define DEFAULT_EMAD_TIMEOUT_USEC (5000000 * 400) /* Default EMAD timeout is 2000sec */
#else
#define DEFAULT_EMAD_TIMEOUT_USEC (20000000)      /* Default EMAD timeout is 20sec (due to PSPA that takes very long time on split x4 on SPC2) */
#endif

#if (DEFAULT_EMAD_TIMEOUT_USEC > SXD_MAX_EMAD_TIMEOUT_USEC)
#error Default EMAD timeout is greater than the maximum allowed!
#endif

static uint32_t __emad_timeout_usec = DEFAULT_EMAD_TIMEOUT_USEC;

struct reg_hook {
    sxd_emad_hook_cb_t hook_cb;
    void              *hook_cb_context;
};

static cl_plock_t      __reg_hook_lock;
static struct reg_hook __reg_hook_table[SXD_MAX_REGISTERS];


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        /* set all emad components verbosity level */
        err = emad_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_transaction_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD TRANSACTION COS verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_transport_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD TRANSPORT verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_cos_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD COS verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_fdb_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD FDB verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_host_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD HOST verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_lag_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD LAG verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_mstp_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD MSTP verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_port_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD PORT verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_system_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD SYSTEM verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_vlan_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set SXD EMAD VLAN verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_parser_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_tunnel_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD TUNNEL verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_emad_rm_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD RM verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }

        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_init(uint32_t app_id)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_plock_init(&__reg_hook_lock);
    err = emad_init(app_id);
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "EMAD DB initialization failed\n");
        goto out;
    }

    err = emad_transaction_init(app_id);
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "EMAD Transaction DB initialization failed\n");
        emad_deinit();
        goto out;
    }

    err = emad_transport_init();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "EMAD Transport DB initialization failed\n");
        emad_transaction_deinit();
        emad_deinit();
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deinit()
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = emad_transport_deinit();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "EMAD Transport DB de-initialization failed.\n");
        goto out;
    }

    emad_transaction_deinit();

    err = emad_deinit();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "EMAD DB de-initialization failed.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_timeout_set(uint32_t timeout_usec)
{
    SX_LOG_NTC("setting emad-timeout to %u\n", timeout_usec);
    __emad_timeout_usec = timeout_usec;
    return SXD_STATUS_SUCCESS;
}


void sxd_emad_timeout_get(uint32_t *timeout_usec)
{
    *timeout_usec = __emad_timeout_usec;
}

/**
 *  This function register callback for latest tid notification.
 *
 * @param[in] tx_cb - emad notify latest tx tid.
 * @param[in] rx_cb - emad notify latest rx tid.
 * @param[in] context - context to pass to cb function
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_register_notify_latest_tx_rx_tid_cb(sxd_emad_notify_latest_tx_tid_cb tx_cb,
                                                          sxd_emad_notify_latest_rx_tid_cb rx_cb,
                                                          void                            *context)
{
    emad_transaction_register_tx_cb(tx_cb, context);
    emad_transaction_register_rx_cb(rx_cb, context);

    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_emad_hook_register(sxd_reg_id_e reg_id, sxd_emad_hook_cb_t hook_cb, void *hook_context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if ((reg_id >= SXD_MAX_REGISTERS) || (!hook_cb && hook_context)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    cl_plock_excl_acquire(&__reg_hook_lock);

    if (__reg_hook_table[reg_id].hook_cb) {
        err = SXD_STATUS_ERROR;
    } else {
        __reg_hook_table[reg_id].hook_cb = hook_cb;
        __reg_hook_table[reg_id].hook_cb_context = hook_context;
    }

    cl_plock_release(&__reg_hook_lock);
    return err;
}

void sxd_emad_hook_unregister(sxd_reg_id_e reg_id)
{
    if (reg_id >= SXD_MAX_REGISTERS) {
        return;
    }

    cl_plock_excl_acquire(&__reg_hook_lock);
    __reg_hook_table[reg_id].hook_cb = NULL;
    __reg_hook_table[reg_id].hook_cb_context = NULL;
    cl_plock_release(&__reg_hook_lock);
}

void sxd_emad_call_hook(sxd_dev_id_t dev_id, sxd_reg_id_e reg_id, uint8_t fw_status, const void *reg_data, /* struct ku_XXX_reg */
                        const void *operation_tlv, const void *reg_tlv, const void *latency_tlv)
{
    static uint8_t                   __reg_data[SXD_EMAD_BUFFER_MAX_SIZE];
    struct sxd_emad_general_reg_data emad_gen_data;
    uint16_t                         indexes[] = { reg_id, 0 };
    unsigned int                     i;

    if (reg_id >= SXD_MAX_REGISTERS) {
        return;
    }

    cl_plock_acquire(&__reg_hook_lock); /* read lock */

    for (i = 0; i < sizeof(indexes) / sizeof(indexes[0]); i++) {
        if (!__reg_hook_table[indexes[i]].hook_cb) {
            continue;
        }

        if (reg_data == NULL) { /* register called in async mode, need to deparse it before the hook ... */
            memset(&emad_gen_data.common, 0, sizeof(emad_gen_data.common));
            emad_gen_data.reg_data = __reg_data;

            memset(__reg_data, 0, sizeof(__reg_data));
#ifdef SNIFFER_PRESENT
            sxd_emad_deparse_rx(reg_id, &emad_gen_data, ((uint8_t*)reg_tlv) + 4 /* skip type/value */, NULL,
                                sxd_sniffer_is_activated(reg_id) ? sxd_sniffer_print_data : NULL);
#else
            sxd_emad_deparse_rx(reg_id, &emad_gen_data, ((uint8_t*)reg_tlv) + 4 /* skip type/value */, NULL,
                                NULL);
#endif


            reg_data = __reg_data;
        }

        __reg_hook_table[indexes[i]].hook_cb(dev_id,
                                             reg_id,
                                             fw_status,
                                             reg_data,
                                             operation_tlv,
                                             reg_tlv,
                                             latency_tlv,
                                             __reg_hook_table[indexes[i]].hook_cb_context);
    }

    cl_plock_release(&__reg_hook_lock);
}
