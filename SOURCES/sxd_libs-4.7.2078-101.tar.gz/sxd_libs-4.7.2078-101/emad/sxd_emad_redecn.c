/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/cl_types.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_redecn.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_REDECN

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t sxd_emad_redecn_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_cwtp_set(sxd_emad_cwtp_data_t         *cwtp_data_arr,
                               uint32_t                      cwtp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwtp_data_arr == NULL) || (cwtp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwtp_data_arr, cwtp_data_num,
                          SXD_REG_ID_CWTP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_cwtp_get(sxd_emad_cwtp_data_t         *cwtp_data_arr,
                               uint32_t                      cwtp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwtp_data_arr == NULL) || (cwtp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwtp_data_arr, cwtp_data_num,
                          SXD_REG_ID_CWTP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_cwpp_set(sxd_emad_cwpp_data_t         *cwpp_data_arr,
                               uint32_t                      cwpp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwpp_data_arr == NULL) || (cwpp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwpp_data_arr, cwpp_data_num,
                          SXD_REG_ID_CWPP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_cwpp_get(sxd_emad_cwpp_data_t         *cwpp_data_arr,
                               uint32_t                      cwpp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwpp_data_arr == NULL) || (cwpp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwpp_data_arr, cwpp_data_num,
                          SXD_REG_ID_CWPP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_cwppm_set(sxd_emad_cwppm_data_t        *cwppm_data_arr,
                                uint32_t                      cwppm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwppm_data_arr == NULL) || (cwppm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwppm_data_arr, cwppm_data_num,
                          SXD_REG_ID_CWPPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_cwppm_get(sxd_emad_cwppm_data_t        *cwppm_data_arr,
                                uint32_t                      cwppm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cwppm_data_arr == NULL) || (cwppm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)cwppm_data_arr, cwppm_data_num,
                          SXD_REG_ID_CWPPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
