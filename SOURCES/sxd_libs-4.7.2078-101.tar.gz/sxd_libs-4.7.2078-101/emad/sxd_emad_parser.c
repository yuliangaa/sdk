/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_types.h>
#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_emad_parser_acl.h>
#include <sx/sxd/sxd_emad_parser_cos.h>
#include <sx/sxd/sxd_emad_parser_fdb.h>
#include <sx/sxd/sxd_emad_parser_host.h>
#include <sx/sxd/sxd_emad_parser_lag.h>
#include <sx/sxd/sxd_emad_parser_mstp.h>
#include <sx/sxd/sxd_emad_parser_policer.h>
#include <sx/sxd/sxd_emad_parser_port.h>
#include <sx/sxd/sxd_emad_parser_mpls.h>
#include <sx/sxd/sxd_emad_parser_system.h>
#include <sx/sxd/sxd_emad_parser_vlan.h>
#include <sx/sxd/sxd_emad_parser_span.h>
#include <sx/sxd/sxd_emad_parser_redecn.h>
#include <sx/sxd/sxd_emad_parser_tunnel.h>
#include <sx/sxd/sxd_emad_parser_router.h>
#include <sx/sxd/sxd_emad_parser_shspm.h>
#include <sx/sxd/sxd_emad_parser_flow_counter.h>
#include <sx/sxd/sxd_emad_parser_rm.h>
#include <reg_access/sxd_access_reg_infra.h>
#ifdef SNIFFER_PRESENT
#include <sxd_sniffer/sniffer/sxd_sniffer.h>
#endif
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
struct reg_callbacks {
    sxd_emad_parse_cb_t   parse_cb;
    sxd_emad_deparse_cb_t deparse_cb;
};

/* PARSE TABLE (for registers with old implementation) */
#define PARSE_FUNC_ADAPTOR(reg_name)                                            \
    static sxd_status_t __parse_adaptor_ ## reg_name(                           \
        const struct sxd_emad_general_reg_data *reg_common_data,                \
        void *reg_buff,                                                         \
        uint32_t *reg_size,                                                     \
        void *context,                                                          \
        sxd_sniffer_print_data_cb_t print_data)                                 \
    {                                                                           \
        sxd_emad_ ## reg_name ## _data_t * reg_name ## _data;                   \
        sxd_emad_ ## reg_name ## _reg_t * reg_name ## _reg;                     \
        sxd_status_t err = SXD_STATUS_SUCCESS;                                  \
        UNUSED_PARAM(context);                                                  \
        UNUSED_PARAM(print_data);                                               \
        reg_name ## _data = (sxd_emad_ ## reg_name ## _data_t*)reg_common_data; \
        reg_name ## _reg = (sxd_emad_ ## reg_name ## _reg_t*)reg_buff;          \
        err = sxd_emad_parse_ ## reg_name(reg_name ## _data, reg_name ## _reg); \
        if (err != SXD_STATUS_SUCCESS) {                                        \
            goto out;                                                           \
        }                                                                       \
        *reg_size = sizeof(sxd_emad_ ## reg_name ## _reg_t);                    \
out:                                                                            \
        return err;                                                             \
    }

#define DEPARSE_FUNC_ADAPTOR(reg_name)                                             \
    static sxd_status_t __deparse_adaptor_ ## reg_name(                            \
        struct sxd_emad_general_reg_data *reg_common_data,                         \
        const void *reg_buff,                                                      \
        void *context,                                                             \
        sxd_sniffer_print_data_cb_t print_data)                                    \
    {                                                                              \
        sxd_emad_ ## reg_name ## _data_t * reg_name ## _data;                      \
        sxd_emad_ ## reg_name ## _reg_t * reg_name ## _reg;                        \
        UNUSED_PARAM(context);                                                     \
        UNUSED_PARAM(print_data);                                                  \
        reg_name ## _data = (sxd_emad_ ## reg_name ## _data_t*)reg_common_data;    \
        reg_name ## _reg = (sxd_emad_ ## reg_name ## _reg_t*)reg_buff;             \
        return sxd_emad_deparse_ ## reg_name(reg_name ## _data, reg_name ## _reg); \
    }

#define DEFINE_REG_CALLBACKS(reg_name) \
    PARSE_FUNC_ADAPTOR(reg_name)       \
    DEPARSE_FUNC_ADAPTOR(reg_name)

DEFINE_REG_CALLBACKS(sbib)
DEFINE_REG_CALLBACKS(mpar)
DEFINE_REG_CALLBACKS(mfba)
DEFINE_REG_CALLBACKS(mfbe)
DEFINE_REG_CALLBACKS(mfpa)
DEFINE_REG_CALLBACKS(scar)
DEFINE_REG_CALLBACKS(pspa)
DEFINE_REG_CALLBACKS(qpdp)
DEFINE_REG_CALLBACKS(qprt)
DEFINE_REG_CALLBACKS(sspr)
DEFINE_REG_CALLBACKS(sfn)
DEFINE_REG_CALLBACKS(spgt)
DEFINE_REG_CALLBACKS(smid)
DEFINE_REG_CALLBACKS(spms)
DEFINE_REG_CALLBACKS(spvid)
DEFINE_REG_CALLBACKS(spvc)
DEFINE_REG_CALLBACKS(sver)
DEFINE_REG_CALLBACKS(spvtr)
DEFINE_REG_CALLBACKS(sftr)
DEFINE_REG_CALLBACKS(svpe)
DEFINE_REG_CALLBACKS(slcr)
DEFINE_REG_CALLBACKS(slcor)
DEFINE_REG_CALLBACKS(slecr)
DEFINE_REG_CALLBACKS(spmlr)
DEFINE_REG_CALLBACKS(svmlr)
DEFINE_REG_CALLBACKS(spmcr)
DEFINE_REG_CALLBACKS(ppsc)
DEFINE_REG_CALLBACKS(mjtag)
DEFINE_REG_CALLBACKS(qpts)
DEFINE_REG_CALLBACKS(qpcr)
DEFINE_REG_CALLBACKS(qpbr)
DEFINE_REG_CALLBACKS(pcap)
DEFINE_REG_CALLBACKS(pelc)
DEFINE_REG_CALLBACKS(pmlp)
DEFINE_REG_CALLBACKS(pfcc)
DEFINE_REG_CALLBACKS(pmpr)
DEFINE_REG_CALLBACKS(plib)
DEFINE_REG_CALLBACKS(pplm)
DEFINE_REG_CALLBACKS(pptb)
DEFINE_REG_CALLBACKS(pbmc)
DEFINE_REG_CALLBACKS(pmpc)
DEFINE_REG_CALLBACKS(pfsc)
DEFINE_REG_CALLBACKS(rcap)
DEFINE_REG_CALLBACKS(rgcr)
DEFINE_REG_CALLBACKS(ritr)
DEFINE_REG_CALLBACKS(rigr)
DEFINE_REG_CALLBACKS(rtar)
DEFINE_REG_CALLBACKS(recr)
DEFINE_REG_CALLBACKS(recr_v2)
DEFINE_REG_CALLBACKS(ruft)
DEFINE_REG_CALLBACKS(ruht)
DEFINE_REG_CALLBACKS(rauht)
DEFINE_REG_CALLBACKS(rauhtd)
DEFINE_REG_CALLBACKS(rmft)
DEFINE_REG_CALLBACKS(rmft_v2)
DEFINE_REG_CALLBACKS(rmftad)
DEFINE_REG_CALLBACKS(ptcead)
DEFINE_REG_CALLBACKS(ratr)
DEFINE_REG_CALLBACKS(ratrad)
DEFINE_REG_CALLBACKS(rdpm)
DEFINE_REG_CALLBACKS(rrcr)
DEFINE_REG_CALLBACKS(rica)
DEFINE_REG_CALLBACKS(ricnt)
DEFINE_REG_CALLBACKS(rtca)
DEFINE_REG_CALLBACKS(rtps)
DEFINE_REG_CALLBACKS(ralue)
DEFINE_REG_CALLBACKS(ralbu)
DEFINE_REG_CALLBACKS(rmeir)
DEFINE_REG_CALLBACKS(rmid)
DEFINE_REG_CALLBACKS(rmpu)
DEFINE_REG_CALLBACKS(hcap)
DEFINE_REG_CALLBACKS(hdrt)
DEFINE_REG_CALLBACKS(hctr)
DEFINE_REG_CALLBACKS(hespr)
DEFINE_REG_CALLBACKS(ptar)
DEFINE_REG_CALLBACKS(pacl)
DEFINE_REG_CALLBACKS(ptce)
DEFINE_REG_CALLBACKS(ptce2)
DEFINE_REG_CALLBACKS(pefa)
DEFINE_REG_CALLBACKS(pecb)
DEFINE_REG_CALLBACKS(pemb)
DEFINE_REG_CALLBACKS(prbt)
DEFINE_REG_CALLBACKS(prcr)
DEFINE_REG_CALLBACKS(pfca)
DEFINE_REG_CALLBACKS(pfcnt)
DEFINE_REG_CALLBACKS(pagt)
DEFINE_REG_CALLBACKS(plbf)
DEFINE_REG_CALLBACKS(puet)
DEFINE_REG_CALLBACKS(pifr)
DEFINE_REG_CALLBACKS(msci)
DEFINE_REG_CALLBACKS(mtbr)
DEFINE_REG_CALLBACKS(sbpr)
DEFINE_REG_CALLBACKS(sbsr)
DEFINE_REG_CALLBACKS(sbcm)
DEFINE_REG_CALLBACKS(sbpm)
DEFINE_REG_CALLBACKS(sbmm)
DEFINE_REG_CALLBACKS(cwtp)
DEFINE_REG_CALLBACKS(cwpp)
DEFINE_REG_CALLBACKS(cwppm)
DEFINE_REG_CALLBACKS(qpdpm)
DEFINE_REG_CALLBACKS(qepm)
DEFINE_REG_CALLBACKS(qrwe)
DEFINE_REG_CALLBACKS(qpem)
DEFINE_REG_CALLBACKS(qpdsm)
DEFINE_REG_CALLBACKS(qppm)
DEFINE_REG_CALLBACKS(mgpc)
DEFINE_REG_CALLBACKS(mpsc)
DEFINE_REG_CALLBACKS(mlcr)
DEFINE_REG_CALLBACKS(mdri)
DEFINE_REG_CALLBACKS(mpgcr)
DEFINE_REG_CALLBACKS(mpilm)

static sxd_status_t __parse_adaptor_sfd(const struct sxd_emad_general_reg_data *reg_common_data,
                                        void                                   *reg_buff,
                                        uint32_t                               *reg_size,
                                        void                                   *parser_context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    sxd_emad_sfd_data_t *sfd_data = (sxd_emad_sfd_data_t*)reg_common_data;
    sxd_emad_sfd_reg_t  *sfd_reg = (sxd_emad_sfd_reg_t*)reg_buff;
    uint32_t             records_size;
    sxd_status_t         err;

    UNUSED_PARAM(parser_context);
    UNUSED_PARAM(print_data);

    err = sxd_emad_parse_sfd(sfd_data, sfd_reg);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    err = sxd_emad_sfd_reg_records_size(sfd_data, &records_size);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    *reg_size = sizeof(sxd_emad_sfd_reg_t) + records_size;
    return SXD_STATUS_SUCCESS;
}

DEPARSE_FUNC_ADAPTOR(sfd)

static sxd_status_t __parse_adaptor_spvm(const struct sxd_emad_general_reg_data *reg_common_data,
                                         void                                   *reg_buff,
                                         uint32_t                               *reg_size,
                                         void                                   *parser_context,
                                         sxd_sniffer_print_data_cb_t             print_data)
{
    sxd_emad_spvm_data_t *spvm_data = (sxd_emad_spvm_data_t*)reg_common_data;
    sxd_emad_spvm_reg_t  *spvm_reg = (sxd_emad_spvm_reg_t*)reg_buff;
    uint32_t              records_size;
    sxd_status_t          err;

    UNUSED_PARAM(parser_context);
    UNUSED_PARAM(print_data);

    err = sxd_emad_parse_spvm(spvm_data, spvm_reg);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    err = sxd_emad_spvm_reg_vlans_size(spvm_data, &records_size);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    *reg_size = sizeof(sxd_emad_spvm_reg_t) + records_size;
    return SXD_STATUS_SUCCESS;
}

DEPARSE_FUNC_ADAPTOR(spvm)


static sxd_status_t __parse_adaptor_sldr(const struct sxd_emad_general_reg_data *reg_common_data,
                                         void                                   *reg_buff,
                                         uint32_t                               *reg_size,
                                         void                                   *parser_context,
                                         sxd_sniffer_print_data_cb_t             print_data)
{
    sxd_emad_sldr_data_t *sldr_data = (sxd_emad_sldr_data_t*)reg_common_data;
    sxd_emad_sldr_reg_t  *sldr_reg = (sxd_emad_sldr_reg_t*)reg_buff;
    uint32_t              records_size;
    sxd_status_t          err;

    UNUSED_PARAM(parser_context);
    UNUSED_PARAM(print_data);

    err = sxd_emad_parse_sldr(sldr_data, sldr_reg);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    err = sxd_emad_sldr_reg_ports_size(sldr_data, &records_size);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    *reg_size = sizeof(sxd_emad_sldr_reg_t) + records_size;
    return SXD_STATUS_SUCCESS;
}

DEPARSE_FUNC_ADAPTOR(sldr)


static sxd_status_t __parse_adaptor_spvmlr(const struct sxd_emad_general_reg_data *reg_common_data,
                                           void                                   *reg_buff,
                                           uint32_t                               *reg_size,
                                           void                                   *parser_context,
                                           sxd_sniffer_print_data_cb_t             print_data)
{
    sxd_emad_spvmlr_data_t *spvmlr_data = (sxd_emad_spvmlr_data_t*)reg_common_data;
    sxd_emad_spvmlr_reg_t  *spvmlr_reg = (sxd_emad_spvmlr_reg_t*)reg_buff;
    uint32_t                records_size;
    sxd_status_t            err;

    UNUSED_PARAM(parser_context);
    UNUSED_PARAM(print_data);

    err = sxd_emad_parse_spvmlr(spvmlr_data, spvmlr_reg);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    err = sxd_emad_spvmlr_reg_vlans_size(spvmlr_data, &records_size);
    if (err != SXD_STATUS_SUCCESS) {
        return err;
    }

    *reg_size = sizeof(sxd_emad_spvmlr_reg_t) + records_size;
    return SXD_STATUS_SUCCESS;
}

DEPARSE_FUNC_ADAPTOR(spvmlr)


static sxd_status_t __parse_adaptor_raw(const struct sxd_emad_general_reg_data *reg_common_data,
                                        void                                   *reg_buff,
                                        uint32_t                               *reg_size,
                                        void                                   *parser_context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    struct sxd_emad_raw_reg_data *raw_reg_data = (struct sxd_emad_raw_reg_data*)reg_common_data->reg_data;

    UNUSED_PARAM(parser_context);
    UNUSED_PARAM(print_data);

    memcpy(reg_buff, raw_reg_data->raw->buff, raw_reg_data->raw->size);
    *reg_size = raw_reg_data->raw->size;
    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __deparse_adaptor_raw(struct sxd_emad_general_reg_data *reg_common_data,
                                          const void                       *reg_buff,
                                          void                             *context,
                                          sxd_sniffer_print_data_cb_t       print_data)
{
    struct sxd_emad_raw_reg_data *raw_data = (struct sxd_emad_raw_reg_data*)reg_common_data->reg_data;
    sxd_emad_raw_reg_t           *raw_reg = (sxd_emad_raw_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    memcpy(raw_data->raw->buff, raw_reg->buff, raw_data->raw->size);
    return SXD_STATUS_SUCCESS;
}


#define REG_CALLBACKS_TABLE_ENTRY(reg_type, reg_name) \
    [SXD_REG_ID_ ## reg_type ## _E] = {               \
        .parse_cb = __parse_adaptor_ ## reg_name,     \
        .deparse_cb = __deparse_adaptor_ ## reg_name  \
    }

static const struct reg_callbacks __reg_cb_table[SXD_MAX_REGISTERS] = {
    REG_CALLBACKS_TABLE_ENTRY(SBIB, sbib),
    REG_CALLBACKS_TABLE_ENTRY(MPAR, mpar),
    REG_CALLBACKS_TABLE_ENTRY(MFBA, mfba),
    REG_CALLBACKS_TABLE_ENTRY(MFBE, mfbe),
    REG_CALLBACKS_TABLE_ENTRY(MFPA, mfpa),
    REG_CALLBACKS_TABLE_ENTRY(SCAR, scar),
    REG_CALLBACKS_TABLE_ENTRY(PSPA, pspa),
    REG_CALLBACKS_TABLE_ENTRY(QPDP, qpdp),
    REG_CALLBACKS_TABLE_ENTRY(QPRT, qprt),
    REG_CALLBACKS_TABLE_ENTRY(SSPR, sspr),
    REG_CALLBACKS_TABLE_ENTRY(SFN, sfn),
    REG_CALLBACKS_TABLE_ENTRY(SPGT, spgt),
    REG_CALLBACKS_TABLE_ENTRY(SMID, smid),
    REG_CALLBACKS_TABLE_ENTRY(SPMS, spms),
    REG_CALLBACKS_TABLE_ENTRY(SPVID, spvid),
    REG_CALLBACKS_TABLE_ENTRY(SPVC, spvc),
    REG_CALLBACKS_TABLE_ENTRY(SVER, sver),
    REG_CALLBACKS_TABLE_ENTRY(SPVTR, spvtr),
    REG_CALLBACKS_TABLE_ENTRY(SFTR, sftr),
    REG_CALLBACKS_TABLE_ENTRY(SVPE, svpe),
    REG_CALLBACKS_TABLE_ENTRY(SLCR, slcr),
    REG_CALLBACKS_TABLE_ENTRY(SLCOR, slcor),
    REG_CALLBACKS_TABLE_ENTRY(SLECR, slecr),
    REG_CALLBACKS_TABLE_ENTRY(SPMLR, spmlr),
    REG_CALLBACKS_TABLE_ENTRY(SVMLR, svmlr),
    REG_CALLBACKS_TABLE_ENTRY(SPMCR, spmcr),
    REG_CALLBACKS_TABLE_ENTRY(PPSC, ppsc),
    REG_CALLBACKS_TABLE_ENTRY(MJTAG, mjtag),
    REG_CALLBACKS_TABLE_ENTRY(QPTS, qpts),
    REG_CALLBACKS_TABLE_ENTRY(QPCR, qpcr),
    REG_CALLBACKS_TABLE_ENTRY(QPBR, qpbr),
    REG_CALLBACKS_TABLE_ENTRY(PCAP, pcap),
    REG_CALLBACKS_TABLE_ENTRY(PELC, pelc),
    REG_CALLBACKS_TABLE_ENTRY(PMLP, pmlp),
    REG_CALLBACKS_TABLE_ENTRY(PFCC, pfcc),

    REG_CALLBACKS_TABLE_ENTRY(PMPR, pmpr),
    REG_CALLBACKS_TABLE_ENTRY(PLIB, plib),
    REG_CALLBACKS_TABLE_ENTRY(PPLM, pplm),
    REG_CALLBACKS_TABLE_ENTRY(PPTB, pptb),
    REG_CALLBACKS_TABLE_ENTRY(PBMC, pbmc),
    REG_CALLBACKS_TABLE_ENTRY(PMPC, pmpc),
    REG_CALLBACKS_TABLE_ENTRY(PFSC, pfsc),
    REG_CALLBACKS_TABLE_ENTRY(RCAP, rcap),
    REG_CALLBACKS_TABLE_ENTRY(RGCR, rgcr),
    REG_CALLBACKS_TABLE_ENTRY(RITR, ritr),
    REG_CALLBACKS_TABLE_ENTRY(RIGR, rigr),
    REG_CALLBACKS_TABLE_ENTRY(RTAR, rtar),
    REG_CALLBACKS_TABLE_ENTRY(RECR, recr),
    REG_CALLBACKS_TABLE_ENTRY(RECRV2, recr_v2),
    REG_CALLBACKS_TABLE_ENTRY(RUFT, ruft),
    REG_CALLBACKS_TABLE_ENTRY(RUHT, ruht),
    REG_CALLBACKS_TABLE_ENTRY(RAUHT, rauht),
    REG_CALLBACKS_TABLE_ENTRY(RAUHTD, rauhtd),
    REG_CALLBACKS_TABLE_ENTRY(RMFT, rmft),
    REG_CALLBACKS_TABLE_ENTRY(RMFTV2, rmft_v2),
    REG_CALLBACKS_TABLE_ENTRY(RMFTAD, rmftad),
    REG_CALLBACKS_TABLE_ENTRY(PTCEAD, ptcead),
    REG_CALLBACKS_TABLE_ENTRY(RATR, ratr),
    REG_CALLBACKS_TABLE_ENTRY(RATRAD, ratrad),
    REG_CALLBACKS_TABLE_ENTRY(RDPM, rdpm),
    REG_CALLBACKS_TABLE_ENTRY(RRCR, rrcr),
    REG_CALLBACKS_TABLE_ENTRY(RICA, rica),
    REG_CALLBACKS_TABLE_ENTRY(RICNT, ricnt),
    REG_CALLBACKS_TABLE_ENTRY(RTCA, rtca),
    REG_CALLBACKS_TABLE_ENTRY(RTPS, rtps),
    REG_CALLBACKS_TABLE_ENTRY(RALUE, ralue),
    REG_CALLBACKS_TABLE_ENTRY(RALBU, ralbu),
    REG_CALLBACKS_TABLE_ENTRY(RMEIR, rmeir),
    REG_CALLBACKS_TABLE_ENTRY(RMID, rmid),
    REG_CALLBACKS_TABLE_ENTRY(RMPU, rmpu),
    REG_CALLBACKS_TABLE_ENTRY(HCAP, hcap),
    REG_CALLBACKS_TABLE_ENTRY(HDRT, hdrt),
    REG_CALLBACKS_TABLE_ENTRY(HCTR, hctr),
    REG_CALLBACKS_TABLE_ENTRY(HESPR, hespr),
    REG_CALLBACKS_TABLE_ENTRY(PTAR, ptar),
    REG_CALLBACKS_TABLE_ENTRY(PACL, pacl),
    REG_CALLBACKS_TABLE_ENTRY(PTCE, ptce),
    REG_CALLBACKS_TABLE_ENTRY(PTCE2, ptce2),
    REG_CALLBACKS_TABLE_ENTRY(PEFA, pefa),
    REG_CALLBACKS_TABLE_ENTRY(PECB, pecb),
    REG_CALLBACKS_TABLE_ENTRY(PEMB, pemb),
    REG_CALLBACKS_TABLE_ENTRY(PRBT, prbt),
    REG_CALLBACKS_TABLE_ENTRY(PRCR, prcr),
    REG_CALLBACKS_TABLE_ENTRY(PFCA, pfca),
    REG_CALLBACKS_TABLE_ENTRY(PFCNT, pfcnt),
    REG_CALLBACKS_TABLE_ENTRY(PAGT, pagt),
    REG_CALLBACKS_TABLE_ENTRY(PLBF, plbf),
    REG_CALLBACKS_TABLE_ENTRY(PUET, puet),
    REG_CALLBACKS_TABLE_ENTRY(PIFR, pifr),
    REG_CALLBACKS_TABLE_ENTRY(MSCI, msci),
    REG_CALLBACKS_TABLE_ENTRY(MTBR, mtbr),
    REG_CALLBACKS_TABLE_ENTRY(SBPR, sbpr),
    REG_CALLBACKS_TABLE_ENTRY(SBSR, sbsr),
    REG_CALLBACKS_TABLE_ENTRY(SBCM, sbcm),
    REG_CALLBACKS_TABLE_ENTRY(SBPM, sbpm),
    REG_CALLBACKS_TABLE_ENTRY(SBMM, sbmm),
    REG_CALLBACKS_TABLE_ENTRY(CWTP, cwtp),
    REG_CALLBACKS_TABLE_ENTRY(CWPP, cwpp),
    REG_CALLBACKS_TABLE_ENTRY(CWPPM, cwppm),
    REG_CALLBACKS_TABLE_ENTRY(QPDPM, qpdpm),
    REG_CALLBACKS_TABLE_ENTRY(QEPM, qepm),
    REG_CALLBACKS_TABLE_ENTRY(QRWE, qrwe),
    REG_CALLBACKS_TABLE_ENTRY(QPEM, qpem),
    REG_CALLBACKS_TABLE_ENTRY(QPDSM, qpdsm),
    REG_CALLBACKS_TABLE_ENTRY(QPPM, qppm),
    REG_CALLBACKS_TABLE_ENTRY(MGPC, mgpc),
    REG_CALLBACKS_TABLE_ENTRY(MPSC, mpsc),
    REG_CALLBACKS_TABLE_ENTRY(MLCR, mlcr),
    REG_CALLBACKS_TABLE_ENTRY(MDRI, mdri),
    REG_CALLBACKS_TABLE_ENTRY(MPGCR, mpgcr),
    REG_CALLBACKS_TABLE_ENTRY(MPILM, mpilm),
    REG_CALLBACKS_TABLE_ENTRY(SFD, sfd),
    REG_CALLBACKS_TABLE_ENTRY(SPVM, spvm),
    REG_CALLBACKS_TABLE_ENTRY(SLDR, sldr),
    REG_CALLBACKS_TABLE_ENTRY(SPVMLR, spvmlr),
    REG_CALLBACKS_TABLE_ENTRY(RAW, raw)
};


sxd_status_t sxd_emad_parser_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];

        /* set all emad components verbosity level */
        err = emad_parser_cos_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER COS verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_fdb_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER FDB verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_host_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER HOST verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_lag_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER LAG verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_mstp_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER MSTP verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_port_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER PORT verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_system_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER SYSTEM verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_vlan_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER VLAN verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_tunnel_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER TUNNEL verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = emad_parser_rm_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Unable to set EMAD PARSER RM verbosity level: [%s]\n", SXD_STATUS_MSG(err));
        }

        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


sxd_status_t sxd_emad_get_reg_parser(sxd_reg_id_e reg_id, sxd_emad_parse_cb_t *reg_parser)
{
    if (reg_id >= SXD_MAX_REGISTERS) {
        return SXD_STATUS_PARAM_ERROR;
    }

    if (__reg_cb_table[reg_id].parse_cb == NULL) {
        return SXD_STATUS_CMD_UNSUPPORTED;
    }

    *reg_parser = __reg_cb_table[reg_id].parse_cb;
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_emad_deparse_single(sxd_emad_data_t *data_p, const uint8_t *buff_p, sxd_reg_id_e reg_id)
{
    const sxd_emad_reg_t             *reg_p = (sxd_emad_reg_t*)buff_p;
    const sxd_emad_reg_data_t        *reg_data_p = reg_p->data;
    struct sxd_emad_general_reg_data *gen_reg_data_p = (struct sxd_emad_general_reg_data*)data_p;

    return sxd_emad_deparse_rx(reg_id, gen_reg_data_p, reg_data_p, NULL, NULL);
}

sxd_status_t sxd_emad_deparse(sxd_emad_data_t *data, const uint8_t *buff, uint32_t buffsize, sxd_reg_id_e *reg_id)
{
    const sxd_emad_operation_t       *operation = NULL;
    const sxd_emad_reg_t             *reg = NULL;
    const sxd_emad_reg_data_t        *reg_data = NULL;
    const uint8_t                    *orig_buff = buff;
    struct sxd_emad_general_reg_data *gen_reg_data;
    sxd_status_t                      sxd_st = SXD_STATUS_ERROR;

    if (buffsize < sizeof(sxd_emad_header_t) + sizeof(sxd_emad_operation_t)) {
        goto out;
    }

    buff += sizeof(sxd_emad_header_t);

    operation = (sxd_emad_operation_t*)buff;
    *reg_id = cl_ntoh16(operation->register_id);
    buff += sizeof(sxd_emad_operation_t);

    reg = (sxd_emad_reg_t*)buff;
    reg_data = reg->data;

    gen_reg_data = (struct sxd_emad_general_reg_data*)data;
#ifdef SNIFFER_PRESENT
    sxd_st = sxd_emad_deparse_rx(*reg_id, gen_reg_data, reg_data, NULL,
                                 sxd_sniffer_is_activated(*reg_id) ? sxd_sniffer_print_data : NULL);
#else
    sxd_st = sxd_emad_deparse_rx(*reg_id, gen_reg_data, reg_data, NULL, NULL);
#endif

out:
    if (SXD_CHECK_FAIL(sxd_st)) {
        SX_HEXDUMP(SX_LOG_ERROR, orig_buff, buffsize);
    }

    return sxd_st;
}

sxd_status_t sxd_emad_deparse_rx(sxd_reg_id_e                      reg_id,
                                 struct sxd_emad_general_reg_data *reg_common_data,
                                 const void                       *reg_buff,
                                 void                             *context,
                                 sxd_sniffer_print_data_cb_t       print_data)
{
    if (reg_id >= SXD_MAX_REGISTERS) {
        return SXD_STATUS_PARAM_ERROR;
    }

    /* register is implemented the old way */
    if (__reg_cb_table[reg_id].deparse_cb) {
        return __reg_cb_table[reg_id].deparse_cb(reg_common_data, reg_buff, context, print_data);
    }

    /* register is maybe implemented the new way */
    return sxd_register_deparse(reg_id, reg_common_data, reg_buff, print_data);
}
