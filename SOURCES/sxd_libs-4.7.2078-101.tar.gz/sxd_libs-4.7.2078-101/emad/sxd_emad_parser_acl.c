/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_acl.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_ACL

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t emad_parser_acl_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_ptar(sxd_emad_ptar_data_t *ptar_data, sxd_emad_ptar_reg_t *ptar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ptar_reg->op_dir = (ptar_data->reg_data->op << 4) | (ptar_data->reg_data->direction << 3);
    ptar_reg->action_set_type = ptar_data->reg_data->action_type;
    ptar_reg->key_type = ptar_data->reg_data->key_type;
    ptar_reg->stateful_db_region = (ptar_data->reg_data->stateful_db_region & 0x1) << 7;
    ptar_reg->region_size = cl_hton16(ptar_data->reg_data->region_size);
    ptar_reg->region_id = cl_hton16(ptar_data->reg_data->region_id);
    ptar_reg->atcam_dup = ptar_data->reg_data->atcam_dup & 0x7;
    ptar_reg->ctcam_dup_op_type =
        ((ptar_data->reg_data->ctcam_dup & 0x7) << 4) | (ptar_data->reg_data->op_type & 0x3);
    ptar_reg->packet_rate = ptar_data->reg_data->packet_rate;
    memcpy(ptar_reg->tcam_region_info, ptar_data->reg_data->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(ptar_reg->flexible_key_id, ptar_data->reg_data->flexible_key_id, SXD_FLEXIBLE_KEY_BLOCK_REG_SIZE_BYTES);
    ptar_reg->region_id_dup_1 = cl_hton16(ptar_data->reg_data->region_id_dup[0]);
    ptar_reg->region_id_dup_2 = cl_hton16(ptar_data->reg_data->region_id_dup[1]);
    ptar_reg->region_id_dup_3 = cl_hton16(ptar_data->reg_data->region_id_dup[2]);
    ptar_reg->region_id_dup_4 = cl_hton16(ptar_data->reg_data->region_id_dup[3]);
    ptar_reg->region_id_dup_5 = cl_hton16(ptar_data->reg_data->region_id_dup[4]);
    ptar_reg->region_id_dup_6 = cl_hton16(ptar_data->reg_data->region_id_dup[5]);
    ptar_reg->region_id_dup_7 = cl_hton16(ptar_data->reg_data->region_id_dup[6]);
    ptar_reg->region_id_dup_8 = cl_hton16(ptar_data->reg_data->region_id_dup[7]);
    ptar_reg->region_id_dup_9 = cl_hton16(ptar_data->reg_data->region_id_dup[8]);
    ptar_reg->region_id_dup_10 = cl_hton16(ptar_data->reg_data->region_id_dup[9]);
    ptar_reg->region_id_dup_11 = cl_hton16(ptar_data->reg_data->region_id_dup[10]);
    ptar_reg->region_id_dup_12 = cl_hton16(ptar_data->reg_data->region_id_dup[11]);
    ptar_reg->region_id_dup_13 = cl_hton16(ptar_data->reg_data->region_id_dup[12]);
    ptar_reg->region_id_dup_14 = cl_hton16(ptar_data->reg_data->region_id_dup[13]);
    ptar_reg->region_id_dup_15 = cl_hton16(ptar_data->reg_data->region_id_dup[14]);


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ptar(sxd_emad_ptar_data_t *ptar_data, sxd_emad_ptar_reg_t *ptar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    ptar_data->reg_data->op = (ptar_reg->op_dir >> 4) & 0xf;
    ptar_data->reg_data->packet_rate = ptar_reg->packet_rate;
    ptar_data->reg_data->stateful_db_region = (ptar_reg->stateful_db_region >> 7) & 0x1;
    memcpy(ptar_data->reg_data->tcam_region_info, ptar_reg->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(ptar_data->reg_data->flexible_key_id, ptar_reg->flexible_key_id, SXD_FLEXIBLE_KEY_BLOCK_REG_SIZE_BYTES);
    ptar_data->reg_data->region_size = cl_hton16(ptar_reg->region_size);
    ptar_data->reg_data->atcam_dup = ptar_reg->atcam_dup & 0x7;
    ptar_data->reg_data->ctcam_dup = (ptar_data->reg_data->ctcam_dup >> 4) & 0x7;

    SX_LOG_EXIT();
    return err;
}


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pacl_data - register data struct.
 * @param[out] pacl_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pacl(sxd_emad_pacl_data_t *pacl_data, sxd_emad_pacl_reg_t *pacl_reg)
{
    pacl_reg->acl_id = cl_hton16(pacl_data->reg_data->acl_id);
    pacl_reg->acl_type = pacl_data->reg_data->acl_type;
    pacl_reg->e_v = pacl_data->reg_data->egress << 7;
    pacl_reg->e_v |= pacl_data->reg_data->valid & 0x01;
    memcpy(pacl_reg->tcam_region_info0, pacl_data->reg_data->tcam_region_info[0], SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_reg->tcam_region_info1, pacl_data->reg_data->tcam_region_info[1], SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_reg->tcam_region_info2, pacl_data->reg_data->tcam_region_info[2], SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_reg->tcam_region_info3, pacl_data->reg_data->tcam_region_info[3], SXD_TCAM_REGION_INFO_SIZE_BYTES);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pacl_data - register data struct.
 * @param[in] pacl_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pacl(sxd_emad_pacl_data_t *pacl_data, sxd_emad_pacl_reg_t *pacl_reg)
{
    pacl_data->reg_data->acl_type = pacl_reg->acl_type;
    pacl_data->reg_data->valid = pacl_reg->e_v & 0x01;
    pacl_data->reg_data->egress = (pacl_reg->e_v & 0x80) ? 1 : 0;
    memcpy(pacl_data->reg_data->tcam_region_info[0], pacl_reg->tcam_region_info0, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_data->reg_data->tcam_region_info[1], pacl_reg->tcam_region_info1, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_data->reg_data->tcam_region_info[2], pacl_reg->tcam_region_info2, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(pacl_data->reg_data->tcam_region_info[3], pacl_reg->tcam_region_info3, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    return SXD_STATUS_SUCCESS;
}


void __parse_ptce_ipv4_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    ptce_reg->key.ipv4.dst_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv4.dst_ip);
    ptce_reg->key.ipv4.src_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv4.src_ip);
    ptce_reg->key.ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.src_l4_port);
    ptce_reg->key.ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.dst_l4_port);
    ptce_reg->key.ipv4.ttl = ptce_data->reg_data->sxd_ptce_key.ipv4.ttl;
    ptce_reg->key.ipv4.tcp_flags = ptce_data->reg_data->sxd_ptce_key.ipv4.tcp_flags;
    ptce_reg->key.ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_key.ipv4.ip_proto;
    ptce_reg->key.ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_key.ipv4.ip_tos;
    ptce_reg->key.ipv4.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.dst_sys_port);
    ptce_reg->key.ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.src_sys_port);
    ptce_reg->key.ipv4.flags = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.flags);
    ptce_reg->key.ipv4.l4_port_range = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv4.l4_port_range);
    /* Mask update*/
    ptce_reg->mask.ipv4.dst_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv4.dst_ip);
    ptce_reg->mask.ipv4.src_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv4.src_ip);
    ptce_reg->mask.ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.src_l4_port);
    ptce_reg->mask.ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.dst_l4_port);
    ptce_reg->mask.ipv4.ttl = ptce_data->reg_data->sxd_ptce_mask.ipv4.ttl;
    ptce_reg->mask.ipv4.tcp_flags = ptce_data->reg_data->sxd_ptce_mask.ipv4.tcp_flags;
    ptce_reg->mask.ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_mask.ipv4.ip_proto;
    ptce_reg->mask.ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_mask.ipv4.ip_tos;
    ptce_reg->mask.ipv4.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.dst_sys_port);
    ptce_reg->mask.ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.src_sys_port);
    ptce_reg->mask.ipv4.flags = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.flags);
    ptce_reg->mask.ipv4.l4_port_range = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv4.l4_port_range);
}

void __parse_ptce_ipv6_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    ptce_reg->key.ipv4.dst_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_ip[3]);
    ptce_reg->key.ipv4.dst_ip_63_32 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_ip[2]);
    ptce_reg->key.ipv4.dst_ip_95_64 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_ip[1]);
    ptce_reg->key.ipv4.dst_ip_127_96 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_ip[0]);
    ptce_reg->key.ipv4.src_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.src_ip[3]);
    ptce_reg->key.ipv4.src_ip_63_32 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.src_ip[2]);
    ptce_reg->key.ipv4.src_ip_95_64 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.src_ip[1]);
    ptce_reg->key.ipv4.src_ip_127_96 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.src_ip[0]);
    ptce_reg->key.ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.src_l4_port);
    ptce_reg->key.ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_l4_port);
    ptce_reg->key.ipv4.ttl = ptce_data->reg_data->sxd_ptce_key.ipv6.ttl;
    ptce_reg->key.ipv4.tcp_flags = ptce_data->reg_data->sxd_ptce_key.ipv6.tcp_flags;
    ptce_reg->key.ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_key.ipv6.ip_proto;
    ptce_reg->key.ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_key.ipv6.ip_tos;
    ptce_reg->key.ipv4.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.dst_sys_port);
    ptce_reg->key.ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.src_sys_port);
    ptce_reg->key.ipv4.flags = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.flags);
    ptce_reg->key.ipv4.l4_port_range = cl_hton16(ptce_data->reg_data->sxd_ptce_key.ipv6.l4_port_range);
    ptce_reg->key.ipv4.flow_label = cl_hton32(ptce_data->reg_data->sxd_ptce_key.ipv6.flow_label);
    ptce_reg->key.ipv4.ipv6_ext = ptce_data->reg_data->sxd_ptce_key.ipv6.ipv6_ext;
    /* Mask update*/
    ptce_reg->mask.ipv4.dst_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_ip[3]);
    ptce_reg->mask.ipv4.dst_ip_63_32 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_ip[2]);
    ptce_reg->mask.ipv4.dst_ip_95_64 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_ip[1]);
    ptce_reg->mask.ipv4.dst_ip_127_96 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_ip[0]);
    ptce_reg->mask.ipv4.src_ip_31_0 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_ip[3]);
    ptce_reg->mask.ipv4.src_ip_63_32 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_ip[2]);
    ptce_reg->mask.ipv4.src_ip_95_64 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_ip[1]);
    ptce_reg->mask.ipv4.src_ip_127_96 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_ip[0]);
    ptce_reg->mask.ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_l4_port);
    ptce_reg->mask.ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_l4_port);
    ptce_reg->mask.ipv4.ttl = ptce_data->reg_data->sxd_ptce_mask.ipv6.ttl;
    ptce_reg->mask.ipv4.tcp_flags = ptce_data->reg_data->sxd_ptce_mask.ipv6.tcp_flags;
    ptce_reg->mask.ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_mask.ipv6.ip_proto;
    ptce_reg->mask.ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_mask.ipv6.ip_tos;
    ptce_reg->mask.ipv4.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.dst_sys_port);
    ptce_reg->mask.ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.src_sys_port);
    ptce_reg->mask.ipv4.flags = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.flags);
    ptce_reg->mask.ipv4.l4_port_range = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.ipv6.l4_port_range);
    ptce_reg->mask.ipv4.flow_label = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.ipv6.flow_label);
    ptce_reg->mask.ipv4.ipv6_ext = ptce_data->reg_data->sxd_ptce_mask.ipv6.ipv6_ext;
}


void __parse_ptce_mac_ipv4_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    uint16_t tmp16;

    memcpy(ptce_reg->key.mac_ipv4.dmac, ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.dmac, 6);
    memcpy(ptce_reg->key.mac_ipv4.smac, ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.smac, 6);
    ptce_reg->key.mac_ipv4.ethertype = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.ethertype);
    tmp16 = ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.prio << 13;
    tmp16 |= (ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.vid & 0xFFF);
    ptce_reg->key.mac_ipv4.vlan_prio = cl_hton16(tmp16);
    ptce_reg->key.mac_ipv4.vlan_type_slag = (ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.vlan_type & 0x3) << 6;
    ptce_reg->key.mac_ipv4.vlan_type_slag |= (ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.slag & 0x1) << 5;
    ptce_reg->key.mac_ipv4.vlan_valid = ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.vlan_valid ? TRUE : FALSE;
    ptce_reg->key.mac_ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.src_sys_port);
    ptce_reg->key.mac_ipv4.dst_ipv4 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.dst_ip);
    ptce_reg->key.mac_ipv4.src_ipv4 = cl_hton32(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.src_ip);
    ptce_reg->key.mac_ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.src_l4_port);
    ptce_reg->key.mac_ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.dst_l4_port);
    ptce_reg->key.mac_ipv4.ip_flags = ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.ip_flags;
    ptce_reg->key.mac_ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.ip_proto;
    ptce_reg->key.mac_ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_key.mac_ipv4_full.ip_tos;
    /* Mask update*/
    memcpy(ptce_reg->mask.mac_ipv4.dmac, ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.dmac, 6);
    memcpy(ptce_reg->mask.mac_ipv4.smac, ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.smac, 6);
    ptce_reg->mask.mac_ipv4.ethertype = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.ethertype);
    tmp16 = ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.prio << 13;
    tmp16 |= (ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.vid & 0xFFF);
    ptce_reg->mask.mac_ipv4.vlan_prio = cl_hton16(tmp16);
    ptce_reg->mask.mac_ipv4.vlan_type_slag = (ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.vlan_type << 6) & 0xc0;
    ptce_reg->mask.mac_ipv4.vlan_type_slag |= (ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.slag << 5) & 0x20;
    ptce_reg->mask.mac_ipv4.vlan_valid = ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.vlan_valid & 0x1;
    ptce_reg->mask.mac_ipv4.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.src_sys_port);
    ptce_reg->mask.mac_ipv4.dst_ipv4 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.dst_ip);
    ptce_reg->mask.mac_ipv4.src_ipv4 = cl_hton32(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.src_ip);
    ptce_reg->mask.mac_ipv4.src_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.src_l4_port);
    ptce_reg->mask.mac_ipv4.dst_l4_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.dst_l4_port);
    ptce_reg->mask.mac_ipv4.ip_flags = ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.ip_flags;
    ptce_reg->mask.mac_ipv4.ip_proto = ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.ip_proto;
    ptce_reg->mask.mac_ipv4.ip_tos = ptce_data->reg_data->sxd_ptce_mask.mac_ipv4_full.ip_tos;
}

void __parse_ptce_mac_full_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    uint32_t tmp32;
    uint16_t tmp16;

    /* Key fields */
    memcpy(ptce_reg->key.mac_full.dmac, ptce_data->reg_data->sxd_ptce_key.mac_full.dmac, 6);
    memcpy(ptce_reg->key.mac_full.smac, ptce_data->reg_data->sxd_ptce_key.mac_full.smac, 6);
    ptce_reg->key.mac_full.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_full.dst_sys_port);
    ptce_reg->key.mac_full.ethertype = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_full.ethertype);
    tmp32 =
        ((ptce_data->reg_data->sxd_ptce_key.mac_full.slag &
          0x1) << 29) | ((ptce_data->reg_data->sxd_ptce_key.mac_full.dmac_type & 0x3) << 30);
    ptce_reg->key.mac_full.slag_dmac_type = cl_hton32(tmp32);
    ptce_reg->key.mac_full.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_full.src_sys_port);
    ptce_reg->key.mac_full.vlan_flags = ptce_data->reg_data->sxd_ptce_key.mac_full.vlan_tagged |
                                        (ptce_data->reg_data->sxd_ptce_key.mac_full.vlan_valid << 1);
    tmp16 =
        (ptce_data->reg_data->sxd_ptce_key.mac_full.cfi <<
            12) + (ptce_data->reg_data->sxd_ptce_key.mac_full.prio << 13);
    tmp16 |= (ptce_data->reg_data->sxd_ptce_key.mac_full.vid & 0xFFF);
    ptce_reg->key.mac_full.vlan_prio = cl_hton16(tmp16);
    /* Mask fields */
    ptce_reg->mask.mac_full.dst_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_full.dst_sys_port);
    ptce_reg->mask.mac_full.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_full.src_sys_port);
    memcpy(ptce_reg->mask.mac_full.dmac, ptce_data->reg_data->sxd_ptce_mask.mac_full.dmac, 6);
    memcpy(ptce_reg->mask.mac_full.smac, ptce_data->reg_data->sxd_ptce_mask.mac_full.smac, 6);
    ptce_reg->mask.mac_full.ethertype = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_full.ethertype);
    tmp32 =
        ((ptce_data->reg_data->sxd_ptce_mask.mac_full.slag &
          0x1) << 29) | ((ptce_data->reg_data->sxd_ptce_mask.mac_full.dmac_type & 0x3) << 30);
    ptce_reg->mask.mac_full.slag_dmac_type = cl_hton32(tmp32);
    ptce_reg->mask.mac_full.vlan_flags = ptce_data->reg_data->sxd_ptce_mask.mac_full.vlan_tagged |
                                         (ptce_data->reg_data->sxd_ptce_mask.mac_full.vlan_valid << 1);
    tmp16 =
        (ptce_data->reg_data->sxd_ptce_mask.mac_full.cfi <<
            12) + (ptce_data->reg_data->sxd_ptce_mask.mac_full.prio << 13);
    tmp16 |= (ptce_data->reg_data->sxd_ptce_mask.mac_full.vid & 0xFFF);
    ptce_reg->mask.mac_full.vlan_prio = cl_hton16(tmp16);
}

void __parse_ptce_mac_short_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    uint32_t tmp32;
    uint16_t tmp16;

    /* Key fields */
    memcpy(ptce_reg->key.mac_short.dmac, ptce_data->reg_data->sxd_ptce_key.mac_short.dmac, 6);
    memcpy(ptce_reg->key.mac_short.smac, ptce_data->reg_data->sxd_ptce_key.mac_short.smac, 6);
    tmp32 =
        ((ptce_data->reg_data->sxd_ptce_key.mac_short.slag &
          0x1) << 29) | ((ptce_data->reg_data->sxd_ptce_key.mac_short.dmac_type & 0x3) << 30);
    ptce_reg->key.mac_short.slag_dmac_type = cl_hton32(tmp32);
    ptce_reg->key.mac_short.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.mac_short.src_sys_port);
    ptce_reg->key.mac_short.vlan_flags = ptce_data->reg_data->sxd_ptce_key.mac_short.vlan_tagged |
                                         (ptce_data->reg_data->sxd_ptce_key.mac_short.vlan_valid << 1);
    tmp16 =
        (ptce_data->reg_data->sxd_ptce_key.mac_short.cfi <<
            12) + (ptce_data->reg_data->sxd_ptce_key.mac_short.prio << 13);
    tmp16 |= (ptce_data->reg_data->sxd_ptce_key.mac_short.vid & 0xFFF);
    ptce_reg->key.mac_short.vlan_prio = cl_hton16(tmp16);
    /* Mask fields */
    ptce_reg->mask.mac_short.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.mac_short.src_sys_port);
    memcpy(ptce_reg->mask.mac_short.dmac, ptce_data->reg_data->sxd_ptce_mask.mac_short.dmac, 6);
    memcpy(ptce_reg->mask.mac_short.smac, ptce_data->reg_data->sxd_ptce_mask.mac_short.smac, 6);
    tmp32 =
        ((ptce_data->reg_data->sxd_ptce_mask.mac_short.slag &
          0x1) << 29) | ((ptce_data->reg_data->sxd_ptce_mask.mac_short.dmac_type & 0x3) << 30);
    ptce_reg->mask.mac_short.slag_dmac_type = cl_hton32(tmp32);
    ptce_reg->mask.mac_short.vlan_flags = ptce_data->reg_data->sxd_ptce_mask.mac_short.vlan_tagged |
                                          (ptce_data->reg_data->sxd_ptce_mask.mac_short.vlan_valid << 1);
    tmp16 =
        (ptce_data->reg_data->sxd_ptce_mask.mac_short.cfi <<
            12) + (ptce_data->reg_data->sxd_ptce_mask.mac_short.prio << 13);
    tmp16 |= (ptce_data->reg_data->sxd_ptce_mask.mac_short.vid & 0xFFF);
    ptce_reg->mask.mac_short.vlan_prio = cl_hton16(tmp16);
}

void __parse_ptce_fcoe_key(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    uint16_t tmp16;

    memcpy(ptce_reg->key.fcoe.dmac, ptce_data->reg_data->sxd_ptce_key.fcoe_full.dmac, 6);
    memcpy(ptce_reg->key.fcoe.smac, ptce_data->reg_data->sxd_ptce_key.fcoe_full.smac, 6);
    tmp16 = ptce_data->reg_data->sxd_ptce_key.fcoe_full.prio << 13;
    tmp16 |= (ptce_data->reg_data->sxd_ptce_key.fcoe_full.vid & 0xFFF);
    ptce_reg->key.fcoe.prio_vid = cl_hton16(tmp16);
    ptce_reg->key.fcoe.vlan_type_slag = (ptce_data->reg_data->sxd_ptce_key.fcoe_full.vlan_type & 0x3) << 6;
    ptce_reg->key.fcoe.vlan_type_slag |= (ptce_data->reg_data->sxd_ptce_key.fcoe_full.slag & 0x1) << 5;
    ptce_reg->key.fcoe.vlan_valid = ptce_data->reg_data->sxd_ptce_key.fcoe_full.vlan_valid ? TRUE : FALSE;
    ptce_reg->key.fcoe.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_key.fcoe_full.src_sys_port);
    memcpy(ptce_reg->key.fcoe.d_id, ptce_data->reg_data->sxd_ptce_key.fcoe_full.d_id, 3);
    memcpy(ptce_reg->key.fcoe.s_id, ptce_data->reg_data->sxd_ptce_key.fcoe_full.s_id, 3);
    ptce_reg->key.fcoe.ox_id = cl_hton16(ptce_data->reg_data->sxd_ptce_key.fcoe_full.ox_id);
    ptce_reg->key.fcoe.rx_id = cl_hton16(ptce_data->reg_data->sxd_ptce_key.fcoe_full.rx_id);
    ptce_reg->key.fcoe.is_fc = (ptce_data->reg_data->sxd_ptce_key.fcoe_full.is_fc & 0x1) << 7;
    ptce_reg->key.fcoe.r_ctl = ptce_data->reg_data->sxd_ptce_key.fcoe_full.r_ctl;
    ptce_reg->key.fcoe.type = ptce_data->reg_data->sxd_ptce_key.fcoe_full.type;
    /* Mask update */
    memcpy(ptce_reg->mask.fcoe.dmac, ptce_data->reg_data->sxd_ptce_mask.fcoe_full.dmac, 6);
    memcpy(ptce_reg->mask.fcoe.smac, ptce_data->reg_data->sxd_ptce_mask.fcoe_full.smac, 6);
    tmp16 = ptce_data->reg_data->sxd_ptce_mask.fcoe_full.prio << 13;
    tmp16 |= (ptce_data->reg_data->sxd_ptce_mask.fcoe_full.vid & 0xFFF);
    ptce_reg->mask.fcoe.prio_vid = cl_hton16(tmp16);
    ptce_reg->mask.fcoe.vlan_type_slag = (ptce_data->reg_data->sxd_ptce_mask.fcoe_full.vlan_type << 6) & 0xc0;
    ptce_reg->mask.fcoe.vlan_type_slag |= (ptce_data->reg_data->sxd_ptce_mask.fcoe_full.slag << 5) & 0x20;
    ptce_reg->mask.fcoe.vlan_valid = ptce_data->reg_data->sxd_ptce_mask.fcoe_full.vlan_valid & 0x1;
    ptce_reg->mask.fcoe.src_sys_port = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.fcoe_full.src_sys_port);
    memcpy(ptce_reg->mask.fcoe.d_id, ptce_data->reg_data->sxd_ptce_mask.fcoe_full.d_id, 3);
    memcpy(ptce_reg->mask.fcoe.s_id, ptce_data->reg_data->sxd_ptce_mask.fcoe_full.s_id, 3);
    ptce_reg->mask.fcoe.ox_id = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.fcoe_full.ox_id);
    ptce_reg->mask.fcoe.rx_id = cl_hton16(ptce_data->reg_data->sxd_ptce_mask.fcoe_full.rx_id);
    ptce_reg->mask.fcoe.is_fc = (ptce_data->reg_data->sxd_ptce_mask.fcoe_full.is_fc << 7) & 0x80;
    ptce_reg->mask.fcoe.r_ctl = ptce_data->reg_data->sxd_ptce_mask.fcoe_full.r_ctl;
    ptce_reg->mask.fcoe.type = ptce_data->reg_data->sxd_ptce_mask.fcoe_full.type;
}

void __parse_ptce_default(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_action_default_t *dflt_action)
{
    uint16_t vid_prio;

    dflt_action->trap = ptce_data->reg_data->sxd_ptce_action_set.default_action.trap << 4;
    dflt_action->trap_grp = ptce_data->reg_data->sxd_ptce_action_set.default_action.trap_group;
    dflt_action->trap_id = cl_hton16(ptce_data->reg_data->sxd_ptce_action_set.default_action.trap_id);
    dflt_action->m_dst = ptce_data->reg_data->sxd_ptce_action_set.default_action.mirror << 7;
    dflt_action->m_dst |= (ptce_data->reg_data->sxd_ptce_action_set.default_action.mirror_dst & 0x7);
    dflt_action->vlan_prio_tcls_op = ptce_data->reg_data->sxd_ptce_action_set.default_action.vlan_prio_tclass_op;
    vid_prio = ((ptce_data->reg_data->sxd_ptce_action_set.default_action.vid & 0xFFF) << 4);
    vid_prio |= ptce_data->reg_data->sxd_ptce_action_set.default_action.prio & 0x7;
    dflt_action->vid_prio = cl_hton16(vid_prio);
    dflt_action->flow_counter = cl_hton32(ptce_data->reg_data->sxd_ptce_action_set.default_action.flow_counter);
    dflt_action->et_st_class = ptce_data->reg_data->sxd_ptce_action_set.default_action.etclass << 4 |
                               ptce_data->reg_data->sxd_ptce_action_set.default_action.stclass;
    dflt_action->policer_port = ptce_data->reg_data->sxd_ptce_action_set.default_action.policer_port;
    dflt_action->g_policer = (ptce_data->reg_data->sxd_ptce_action_set.default_action.g_policer & 0x1) << 7;
    dflt_action->pid = ptce_data->reg_data->sxd_ptce_action_set.default_action.pid;
    /* nr on 1st bit */
    dflt_action->nr_nl = ptce_data->reg_data->sxd_ptce_action_set.default_action.nr & 0x1;
    /* no learning on 3ed bit */
    dflt_action->nr_nl |= (ptce_data->reg_data->sxd_ptce_action_set.default_action.no_learning & 0x1) << 2;
}

void __parse_ptce_extended_action(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    __parse_ptce_default(ptce_data, (sxd_emad_ptce_action_default_t*)&(ptce_reg->action.extended_action));
    ptce_reg->action.extended_action.pbse =
        (ptce_data->reg_data->sxd_ptce_action_set.extended_action.pbs_en & 0x1) << 7;
    ptce_reg->action.extended_action.pbs_table_index = cl_hton16(
        ptce_data->reg_data->sxd_ptce_action_set.extended_action.pbs_index);
}

void __parse_ptce_default_action(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    __parse_ptce_default(ptce_data, &(ptce_reg->action.dflt_action));
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ptce_data - register data struct.
 * @param[out] ptce_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptce(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    ptce_reg->v_a = ((ptce_data->reg_data->valid & 0x1) << 7) | ((ptce_data->reg_data->activity & 0x1) << 6);
    ptce_reg->op = ((ptce_data->reg_data->op & 0x7) << 4);
    ptce_reg->offset = cl_hton16(ptce_data->reg_data->offset);
    ptce_reg->term_asbind = ptce_data->reg_data->terminate << 7;
    ptce_reg->term_asbind |= ptce_data->reg_data->asbind << 6;

    memcpy(ptce_reg->tcam_region_info, ptce_data->reg_data->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    ptce_reg->acl_id_grp_id = cl_hton16(ptce_data->reg_data->next_acl_id_grp_id);

    switch (ptce_data->reg_data->key_type) {
    case SXD_PTCE_KEY_TYPE_IPV4_FULL_E:
        __parse_ptce_ipv4_key(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_KEY_TYPE_IPV6_FULL_E:
        __parse_ptce_ipv6_key(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_KEY_TYPE_MAC_FULL_E:
        __parse_ptce_mac_full_key(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_KEY_TYPE_MAC_SHORT_E:
        __parse_ptce_mac_short_key(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_KEY_TYPE_MAC_IPV4_FULL_E:
        __parse_ptce_mac_ipv4_key(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_KEY_TYPE_FCOE_FULL_E:
        __parse_ptce_fcoe_key(ptce_data, ptce_reg);
        break;

    default:
        return SXD_STATUS_PARAM_ERROR;
    }

    switch (ptce_data->reg_data->action_set_type) {
    case SXD_PTCE_ACTION_TYPE_EXTENDED_E:
        __parse_ptce_extended_action(ptce_data, ptce_reg);
        break;

    case SXD_PTCE_ACTION_TYPE_DEFAULT_E:
        __parse_ptce_default_action(ptce_data, ptce_reg);
        break;

    default:
        return SXD_STATUS_PARAM_ERROR;
    }
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ptce_data - register data struct.
 * @param[in] ptce_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_ptce(sxd_emad_ptce_data_t *ptce_data, sxd_emad_ptce_reg_t *ptce_reg)
{
    ptce_data->reg_data->valid = (ptce_reg->v_a >> 7) & 0x1;
    ptce_data->reg_data->activity = (ptce_reg->v_a >> 6) & 0x1;
    ptce_data->reg_data->op = (ptce_reg->op >> 4) & 0x7;

    ptce_data->reg_data->offset = cl_ntoh16(ptce_reg->offset);

    memcpy(ptce_data->reg_data->tcam_region_info, ptce_reg->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);

    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] prcr_data - register data struct.
 * @param[out] prcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_prcr(sxd_emad_prcr_data_t *prcr_data, sxd_emad_prcr_reg_t *prcr_reg)
{
    prcr_reg->op = (prcr_data->reg_data->op & 0x0F) << 4;
    prcr_reg->offset = cl_hton16(prcr_data->reg_data->offset);
    prcr_reg->size = cl_hton16(prcr_data->reg_data->size);
    prcr_reg->dest_offset = cl_hton16(prcr_data->reg_data->dest_offset);
    memcpy(prcr_reg->tcam_region_info, prcr_data->reg_data->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(prcr_reg->dest_tcam_region_info, prcr_data->reg_data->dest_tcam_region_info,
           SXD_TCAM_REGION_INFO_SIZE_BYTES);

    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] prcr_data - register data struct.
 * @param[in] prcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_prcr(sxd_emad_prcr_data_t *prcr_data, sxd_emad_prcr_reg_t *prcr_reg)
{
    prcr_data->reg_data->op = prcr_reg->op >> 4;
    prcr_data->reg_data->offset = cl_ntoh16(prcr_reg->offset);
    prcr_data->reg_data->size = cl_ntoh16(prcr_reg->size);
    prcr_data->reg_data->dest_offset = cl_ntoh16(prcr_reg->dest_offset);
    memcpy(prcr_data->reg_data->tcam_region_info, prcr_reg->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(prcr_data->reg_data->dest_tcam_region_info, prcr_reg->dest_tcam_region_info,
           SXD_TCAM_REGION_INFO_SIZE_BYTES);

    return SXD_STATUS_SUCCESS;
}


/**
 *  This function Parses sxd_mac_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_mac_flex_action
 * @param[out] action_reg - sxd_mac_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_mac(struct sxd_mac_flex_action* action_data, sxd_mac_flex_action_reg_t* action_reg)
{
    action_reg->ttl_cmd = action_data->ttl_cmd << 5;
    action_reg->ttl = action_data->ttl_value;
    action_reg->defer = action_data->defer & 0x1;
    action_reg->mac_cmd = action_data->mac_cmd << 6;
    memcpy(action_reg->mac, action_data->mac, 6);
}

/**
 *  This function Parses sxd_vlan_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_vlan_flex_action
 * @param[out] action_reg - sxd_vlan_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_vlan(struct sxd_vlan_flex_action* action_data, sxd_vlan_flex_action_reg_t*  action_reg)
{
    action_reg->v_tag_cmd = action_data->v_tag_cmd << 5;
    action_reg->defer = action_data->defer & 0x1;
    action_reg->vid_cmd = action_data->vid_cmd << 5;
    action_reg->vid = cl_hton16(action_data->vid_val);
    action_reg->ethertype_cmd_ethertype = action_data->ethertype_cmd << 5;
    action_reg->ethertype_cmd_ethertype |= (action_data->ethertype_val & 0x7);
    action_reg->pcp_cmd_pcp = action_data->pcp_cmd << 5;
    action_reg->pcp_cmd_pcp |= (action_data->pcp_val & 0x7);
    action_reg->dei_cmd_dei = action_data->dei_cmd << 5;
    action_reg->dei_cmd_dei |= (action_data->dei_val & 0x1);
}

/**
 *  This function Parses sxd_trap_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_vlan_flex_action
 * @param[out] action_reg - sxd_trap_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_trap(struct sxd_trap_flex_action* action_data, sxd_trap_flex_action_reg_t * action_reg)
{
    uint32_t tmp32 = 0;

    action_reg->trap_action = action_data->trap_action & 0xf;
    action_reg->forward_action = action_data->forward_action & 0xf;
    action_reg->trap_id = cl_hton16(action_data->trap_id);
    action_reg->mirror_agent_enable = action_data->mirror_agent << 5;
    action_reg->mirror_agent_enable |= (action_data->mirror_enable & 0x1);

    /* Set defer bit 31 and user_def_val */
    tmp32 = action_data->defer;
    tmp32 <<= 31;
    action_reg->defer_preserve_user_def = cl_hton32(tmp32 | (action_data->user_def_val & 0xFFFFF));

    /* Set preserve_cookie bit 30 */
    tmp32 = action_data->preserve_user_def_val & 1;
    tmp32 <<= 30;
    action_reg->defer_preserve_user_def |= cl_hton32(tmp32);
}

/**
 *  This function Parses sxd_port_filter_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_port_filter_flex_action
 * @param[out] action_reg - sxd_port_filter_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_port(struct sxd_port_filter_flex_action* action_data,
                                     sxd_port_filter_flex_action_reg_t * action_reg)
{
    action_reg->egress_port_list_64 = (action_data->egress_port_list_64 & 0x1);
    action_reg->egress_port_list_63_32 = cl_hton32(action_data->egress_port_list_32_63);
    action_reg->egress_port_list_31_0 = cl_hton32(action_data->egress_port_list_0_31);
}

/**
 *  This function Parses sxd_port_filter_ext_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_port_filter_ext_flex_action
 * @param[out] action_reg - sxd_port_filter_ext_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_port_ext(struct sxd_port_filter_ext_flex_action* action_data,
                                         sxd_port_filter_ext_flex_action_reg_t * action_reg)
{
    action_reg->egress_port_list_128_97 = cl_hton32(action_data->egress_port_list_97_128);
    action_reg->egress_port_list_96_65 = cl_hton32(action_data->egress_port_list_65_96);
}

/**
 *  This function Parses sxd_port_filter_ext2_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_port_filter_ext2_flex_action
 * @param[out] action_reg - sxd_port_filter_ext2_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_port_ext2(struct sxd_port_filter_ext2_flex_action* action_data,
                                          sxd_port_filter_ext2_flex_action_reg_t * action_reg)
{
    action_reg->page = (action_data->page & 0xF);
    action_reg->egress_port_list_63_32 = cl_hton32(action_data->egress_port_list_32_63);
    action_reg->egress_port_list_31_0 = cl_hton32(action_data->egress_port_list_0_31);
}

/**
 *  This function Parses sxd_qos_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_qos_flex_action
 * @param[out] action_reg - sxd_qos_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_qos(struct sxd_qos_flex_action * action_data
                                    , sxd_qos_flex_action_reg_t* action_reg)
{
    action_reg->defer = action_data->defer & 0x1;
    action_reg->ecn_cmd_ecn = action_data->ecn_cmd << 5;
    action_reg->ecn_cmd_ecn |= (action_data->ecn_val & 0x3);
    action_reg->color_cmd_color = action_data->color_cmd << 6;
    action_reg->color_cmd_color |= (action_data->color_val & 0x7);
    action_reg->dscp_cmd = action_data->dscp_cmd << 6;
    action_reg->dscp = action_data->dscp_val & 0x3f;
    action_reg->switch_prio_cmd = action_data->switch_prio_cmd << 6;
    action_reg->switch_prio = action_data->switch_prio_val & 0xf;
    action_reg->dscp_rw_pcp_rw = action_data->rewrite_dscp_cmd << 6;
    action_reg->dscp_rw_pcp_rw |= ((action_data->rewrite_pcp_cmd & 0x3) << 4);
    action_reg->tc_cmd_tc_val = action_data->traffic_class_cmd << 7;
    action_reg->tc_cmd_tc_val |= action_data->tc & 0xf;
}


/**
 *  This function Parses sxd_forward_flex_action  Data -> EMAD .
 *
 * @param[in] action_data -  sxd_forward_flex_action
 * @param[out] action_reg - sxd_forward_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_forward(struct sxd_forward_flex_action* action_data,
                                        sxd_forward_flex_action_reg_t * action_reg)
{
    action_reg->type = action_data->type;
    if (action_data->type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) {
        action_reg->pbs_ptr = cl_hton32(action_data->record.pbs_ptr);
    } else {
        action_reg->pbs_ptr = cl_hton32(action_data->record.output.pbs_ptr);
        action_reg->defer = action_data->record.output.defer;
        action_reg->port = action_data->record.output.in_port;
    }
}

/**
 *  This function Parses sxd_policing_monitoring_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_policing_monitoring_flex_action
 * @param[out] action_reg - sxd_policing_monitoring_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_policing(struct sxd_policing_monitoring_flex_action* action_data,
                                         sxd_policing_monitoring_flex_action_reg_t * action_reg)
{
    uint32_t temp32;

    action_reg->c_p = action_data->c_p << 7;
    temp32 = (action_data->counter_set.type & 0xff) << 24;
    action_reg->counter_set = cl_hton32(temp32 |
                                        (action_data->counter_set.index & 0xffffff));
    action_reg->pid = cl_hton16(action_data->pid);
}

/**
 *  This function Parses sxd_flow_estimator_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_flow_estimator_flex_action
 * @param[out] action_reg - sxd_flow_estimator_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_flow_estimator(struct sxd_flow_estimator_flex_action* action_data,
                                               sxd_flow_estimator_flex_action_reg_t * action_reg)
{
    action_reg->profile = action_data->profile_key.profile_id & 0x7;
    action_reg->counter_index = cl_hton32(action_data->bulk_counter.index & 0xffffff);
}


/**
 *  This function Parses sxd_metadata_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_metadata_flex_action
 * @param[out] action_reg - sxd_metadata_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_meta_data(struct sxd_metadata_flex_action* action_data,
                                          sxd_metadata_flex_action_reg_t * action_reg)
{
    action_reg->meta_data = cl_hton16(action_data->meta_data);
    action_reg->mask = cl_hton16(action_data->mask);
}

/**
 *  This function Parses sxd_policing_monitoring_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_policing_monitoring_by_ref_flex_action
 * @param[out] action_reg - sxd_policing_monitoring_by_ref_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_policing_by_ref(struct sxd_policing_monitoring_by_ref_flex_action* action_data,
                                                sxd_policing_monitoring_by_ref_flex_action_reg_t * action_reg)
{
    action_reg->type = action_data->type & 0x0f;
    action_reg->cbset = action_data->cbset & 0x0f;
}

/**
 *  This function Parses sxd_uc_router_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_uc_router_flex_action
 * @param[out] action_reg - sxd_uc_router_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_uc_router(struct sxd_uc_router_flex_action* action_data,
                                          sxd_uc_router_flex_action_reg_t * action_reg)
{
    action_reg->type = action_data->type;
    switch (action_data->type) {
    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
        action_reg->ip_remote.adjacency_index = cl_hton32(action_data->structs.ip_remote.adjacency_index);
        action_reg->ip_remote.ecmp_size = cl_hton16(action_data->structs.ip_remote.ecmp_size);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E:
        action_reg->ip_local.local_erif = cl_hton16(action_data->structs.ip_local.local_erif);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
        action_reg->tunnel_termination.tunnel_ptr = cl_hton32(action_data->structs.tunnul_termination.tunnul_ptr);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
        action_reg->mpls_ilm.ilm_ptr = cl_hton32(action_data->structs.mpls_ilm.ilm_ptr);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_NHLFE_E:
        action_reg->mpls_nhlfe.nhlfe_ptr = cl_hton32(action_data->structs.mpls_nhlfe.nhlfe_ptr);
        action_reg->mpls_nhlfe.ecmp_size = cl_hton16(action_data->structs.mpls_nhlfe.ecmp_size);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
        action_reg->ar_uc_route.ar_lookup_prof_id = action_data->structs.ar_uc_route.ar_lookup_prof_id;
        action_reg->ar_uc_route.ecmp_size = cl_hton16(action_data->structs.ar_uc_route.ecmp_size);
        action_reg->ar_uc_route.arlpgt_pointer = cl_hton16(action_data->structs.ar_uc_route.arlpgt_pointer);
        action_reg->ar_uc_route.arft_pointer = cl_hton32(action_data->structs.ar_uc_route.arft_pointer);
        break;

    default:
        break;
    }
}

/**
 *  This function Parses sxd_vni_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_vni_flex_action
 * @param[out] action_reg - sxd_vni_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_vxlan(struct sxd_vni_flex_action* action_data, sxd_vni_flex_action_reg_t* action_reg)
{
    uint32_t tmp32 = 0;

    tmp32 = action_data->set_vni;
    tmp32 <<= 31;

    action_reg->set_vni_vni = cl_hton32(tmp32 | action_data->vni);
}

/**
 *  This function Parses sxd_mpls_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_mpls_flex_action
 * @param[out] action_reg - sxd_mpls_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_mpls(struct sxd_mpls_flex_action* action_data, sxd_mpls_flex_action_reg_t* action_reg)
{
    action_reg->ttl_cmd = (action_data->ttl_cmd & 0x7) << 5;
    action_reg->ttl = action_data->ttl;
    action_reg->exp_cmd = (action_data->exp_cmd & 0x3) << 6;
    action_reg->exp = action_data->exp & 0x7;
    action_reg->exp_rw = (action_data->exp_rw & 0x3) << 6;
}

/**
 *  This function Parses sxd_hash_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_hash_flex_action
 * @param[out] action_reg - sxd_hash_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_hash(struct sxd_hash_flex_action* action_data, sxd_hash_flex_action_reg_t* action_reg)
{
    action_reg->type = action_data->type << 6;
    action_reg->hash_cmd = action_data->hash_cmd;
    action_reg->hash_value = cl_hton16(action_data->hash_value);
    action_reg->hash_fields = action_data->hash_fields;
    action_reg->hash_mask = cl_hton32(action_data->hash_mask);
}

/**
 *  This function Parses sxd_virtual_forward_flax_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_virtual_forward_flax_action
 * @param[out] action_reg - sxd_virtual_forward_flax_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_virtual_forwarding(struct sxd_virtual_forward_flax_action * action_data
                                                   , sxd_virtual_forward_flax_action_reg_t* action_reg)
{
    action_reg->vr_cmd = action_data->vr_cmd << 5;
    action_reg->virtual_router = cl_hton16(action_data->virtual_router);
    action_reg->fid_cmd = action_data->fid_cmd << 5;
    action_reg->fid = cl_hton16(action_data->fid);
}

/**
 *  This function Parses sxd_ignore_flex_action  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_ignore_flex_action
 * @param[out] action_reg - sxd_ignore_flex_action_reg_t
 *
 */
void sxd_emad_parse_flex_action_ignore(struct sxd_ignore_flex_action* action_data,
                                       sxd_ignore_flex_action_reg_t * action_reg)
{
    action_reg->is_iv_dl = ((action_data->ignore_stp & 0x1) << 7);
    action_reg->is_iv_dl |= ((action_data->ignore_vl_filter & 0x1) << 6);
    action_reg->is_iv_dl |= ((action_data->disable_learning & 0x1) << 5);
    action_reg->is_iv_dl |= ((action_data->disable_fdb_security & 0x1) << 4);
    action_reg->set_elephant = action_data->set_elephant_flow & 0x3;
    action_reg->ar_packet_prof = action_data->ar_packet_prof_id & 0x3;
    action_reg->ar_packet_prof |= ((action_data->ar_packet_prof_cmd & 0x1) << 4);
    action_reg->disable_ovl_learning = action_data->disable_ovl_learning << 7;
    action_reg->cond_mirroring_mask = cl_hton16(action_data->cond_mirror.cond_mirroring_mask);
    action_reg->cond_mirroring_val = cl_hton16(action_data->cond_mirror.cond_mirroring_val);
}


/**
 *  This function Parses sxd_mac_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_mac_flex_action
 * @param[in] action_reg - sxd_mac_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_mac(struct sxd_mac_flex_action* action_data, sxd_mac_flex_action_reg_t* action_reg)
{
    action_data->ttl_cmd = action_reg->ttl_cmd >> 5;
    action_data->ttl_value = action_reg->ttl;
    action_data->defer = action_reg->defer & 0x1;
    action_data->mac_cmd = action_reg->mac_cmd >> 6;
    memcpy(action_data->mac, action_reg->mac, 6);
}

/**
 *  This function Parses sxd_vlan_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_vlan_flex_action
 * @param[in] action_reg - sxd_vlan_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_vlan(struct sxd_vlan_flex_action* action_data,
                                       sxd_vlan_flex_action_reg_t * action_reg)
{
    action_data->v_tag_cmd = action_reg->v_tag_cmd >> 5;
    action_data->defer = action_reg->defer & 0x1;
    action_data->vid_cmd = action_reg->vid_cmd >> 5;
    action_data->vid_val = cl_ntoh16(action_reg->vid);
    action_data->ethertype_cmd = action_reg->ethertype_cmd_ethertype >> 5;
    action_data->ethertype_val = action_reg->ethertype_cmd_ethertype & 0x7;
    action_data->pcp_cmd = action_reg->pcp_cmd_pcp >> 5;
    action_data->pcp_val = action_reg->pcp_cmd_pcp & 0x7;
    action_data->dei_cmd = action_reg->dei_cmd_dei >> 5;
    action_data->dei_val = action_reg->dei_cmd_dei & 0x1;
}

/**
 *  This function Parses sxd_trap_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_vlan_flex_action
 * @param[in] action_reg - sxd_trap_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_trap(struct sxd_trap_flex_action* action_data,
                                       sxd_trap_flex_action_reg_t * action_reg)
{
    uint32_t tmp32 = 0x80000000;

    action_data->trap_action = action_reg->trap_action;
    action_data->forward_action = action_reg->forward_action;
    action_data->trap_id = cl_ntoh16(action_reg->trap_id);
    action_data->mirror_agent = action_reg->mirror_agent_enable >> 5;
    action_data->mirror_enable = action_reg->mirror_agent_enable & 0x1;
    action_data->user_def_val = cl_ntoh32(action_reg->defer_preserve_user_def);

    tmp32 &= action_data->user_def_val;
    tmp32 >>= 31;
    action_data->defer = tmp32;

    tmp32 = action_data->user_def_val;
    tmp32 >>= 30;
    action_data->preserve_user_def_val = tmp32 & 1;

    action_data->user_def_val &= 0xfffff;
}

/**
 *  This function Parses sxd_port_filter_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_port_filter_flex_action
 * @param[in] action_reg - sxd_port_filter_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_port(struct sxd_port_filter_flex_action* action_data,
                                       sxd_port_filter_flex_action_reg_t * action_reg)
{
    action_data->egress_port_list_64 = (action_reg->egress_port_list_64 & 0x1);
    action_data->egress_port_list_32_63 = cl_ntoh32(action_reg->egress_port_list_63_32);
    action_data->egress_port_list_0_31 = cl_ntoh32(action_reg->egress_port_list_31_0);
}

/**
 *  This function Parses sxd_port_filter_ext_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_port_filter_ext_flex_action
 * @param[in] action_reg - sxd_port_filter_ext_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_port_ext(struct sxd_port_filter_ext_flex_action* action_data,
                                           sxd_port_filter_ext_flex_action_reg_t * action_reg)
{
    action_data->egress_port_list_97_128 = cl_ntoh32(action_reg->egress_port_list_128_97);
    action_data->egress_port_list_65_96 = cl_ntoh32(action_reg->egress_port_list_96_65);
}

/**
 *  This function Parses sxd_port_filter_ext2_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_port_filter_ext2_flex_action
 * @param[in] action_reg - sxd_port_filter_ext2_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_port_ext2(struct sxd_port_filter_ext2_flex_action* action_data,
                                            sxd_port_filter_ext2_flex_action_reg_t * action_reg)
{
    action_data->page = (action_reg->page & 0xF);
    action_data->egress_port_list_32_63 = cl_ntoh32(action_reg->egress_port_list_63_32);
    action_data->egress_port_list_0_31 = cl_ntoh32(action_reg->egress_port_list_31_0);
}

/**
 *  This function Parses sxd_qos_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_qos_flex_action
 * @param[in] action_reg - sxd_qos_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_qos(struct sxd_qos_flex_action * action_data
                                      , sxd_qos_flex_action_reg_t* action_reg)
{
    action_data->defer = action_reg->defer;
    action_data->ecn_cmd = action_reg->ecn_cmd_ecn >> 5;
    action_data->ecn_val = action_reg->ecn_cmd_ecn & 0x3;
    action_data->color_cmd = action_reg->color_cmd_color >> 6;
    action_data->color_val = action_reg->color_cmd_color & 0x7;
    action_data->dscp_cmd = action_reg->dscp_cmd >> 6;
    action_data->dscp_val = action_reg->dscp;
    action_data->switch_prio_cmd = action_reg->switch_prio_cmd >> 6;
    action_data->switch_prio_val = action_reg->switch_prio;
    action_data->rewrite_dscp_cmd = action_reg->dscp_rw_pcp_rw >> 6;
    action_data->rewrite_pcp_cmd = (action_reg->dscp_rw_pcp_rw >> 4) & 0x3;
    action_data->traffic_class_cmd = action_reg->tc_cmd_tc_val >> 7;
    action_data->tc = action_reg->tc_cmd_tc_val & 0xf;
}


/**
 *  This function Parses sxd_forward_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_forward_flex_action
 * @param[in] action_reg - sxd_forward_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_forward(struct sxd_forward_flex_action* action_data,
                                          sxd_forward_flex_action_reg_t * action_reg)
{
    action_data->type = action_reg->type;
    if (action_data->type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) {
        action_data->record.pbs_ptr = cl_ntoh32(action_reg->pbs_ptr);
    } else {
        action_data->record.output.pbs_ptr = cl_ntoh32(action_reg->pbs_ptr);
        action_data->record.output.defer = action_reg->defer;
        action_data->record.output.in_port = action_reg->port;
    }
}

/**
 *  This function Parses sxd_policing_monitoring_by_ref_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_policing_monitoring_by_ref_flex_action
 * @param[in] action_reg - sxd_policing_monitoring_by_ref_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_policing_by_ref(struct sxd_policing_monitoring_by_ref_flex_action* action_data,
                                                  sxd_policing_monitoring_by_ref_flex_action_reg_t * action_reg)
{
    action_data->type = action_reg->type & 0x0f;
    action_data->cbset = action_reg->cbset & 0x0f;
}

/**
 *  This function Parses sxd_policing_monitoring_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_policing_monitoring_flex_action
 * @param[in] action_reg - sxd_policing_monitoring_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_policing(struct sxd_policing_monitoring_flex_action* action_data,
                                           sxd_policing_monitoring_flex_action_reg_t * action_reg)
{
    uint32_t tmp32;

    action_data->c_p = action_reg->c_p >> 7;
    tmp32 = cl_ntoh32(action_reg->counter_set);
    action_data->counter_set.type = (tmp32 >> 24) & 0xff;
    action_data->counter_set.index = tmp32 & 0xffffff;
    action_data->pid = cl_ntoh16(action_reg->pid);
}

/**
 *  This function Parses sxd_flow_estimator_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_flow_estimator_flex_action
 * @param[in] action_reg - sxd_flow_estimator_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_flow_estimator(struct sxd_flow_estimator_flex_action* action_data,
                                                 sxd_flow_estimator_flex_action_reg_t * action_reg)
{
    action_data->profile_key.profile_id = action_reg->profile & 0x7;
    action_data->bulk_counter.index = cl_ntoh32(action_reg->counter_index & 0xffffff);
}

/**
 *  This function Parses sxd_metadata_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_metadata_flex_action
 * @param[in] action_reg - sxd_metadata_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_meta_data(struct sxd_metadata_flex_action* action_data,
                                            sxd_metadata_flex_action_reg_t * action_reg)
{
    action_data->meta_data = cl_ntoh16(action_reg->meta_data);
    action_data->mask = cl_ntoh16(action_reg->mask);
}
/**
 *  This function Parses sxd_uc_router_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_uc_router_flex_action
 * @param[in] action_reg - sxd_uc_router_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_uc_router(struct sxd_uc_router_flex_action* action_data,
                                            sxd_uc_router_flex_action_reg_t * action_reg)
{
    action_data->type = action_reg->type;
    switch (action_data->type) {
    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
        action_data->structs.ip_remote.adjacency_index = cl_ntoh32(action_reg->ip_remote.adjacency_index);
        action_data->structs.ip_remote.ecmp_size = cl_ntoh16(action_reg->ip_remote.ecmp_size);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E:
        action_data->structs.ip_local.local_erif = cl_ntoh16(action_reg->ip_local.local_erif);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
        action_data->structs.tunnul_termination.tunnul_ptr = cl_ntoh32(action_reg->tunnel_termination.tunnel_ptr);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
        action_data->structs.mpls_ilm.ilm_ptr = cl_ntoh32(action_reg->mpls_ilm.ilm_ptr);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_NHLFE_E:
        action_data->structs.mpls_nhlfe.nhlfe_ptr = cl_ntoh32(action_reg->mpls_nhlfe.nhlfe_ptr);
        action_data->structs.mpls_nhlfe.ecmp_size = cl_ntoh16(action_reg->mpls_nhlfe.ecmp_size);
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
        action_data->structs.ar_uc_route.ar_lookup_prof_id = action_reg->ar_uc_route.ar_lookup_prof_id;
        action_data->structs.ar_uc_route.ecmp_size = cl_ntoh16(action_reg->ar_uc_route.ecmp_size);
        action_data->structs.ar_uc_route.arlpgt_pointer = cl_ntoh16(action_reg->ar_uc_route.arlpgt_pointer);
        action_data->structs.ar_uc_route.arft_pointer = cl_ntoh32(action_reg->ar_uc_route.arft_pointer);
        break;

    default:
        break;
    }
}

/**
 *  This function Parses sxd_vni_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_vni_flex_action
 * @param[in] action_reg - sxd_vni_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_vxlan(struct sxd_vni_flex_action* action_data, sxd_vni_flex_action_reg_t* action_reg)
{
    uint32_t tmp32 = 0x80000000;

    action_data->vni = cl_ntoh32(action_reg->set_vni_vni);
    tmp32 &= action_data->vni;
    tmp32 >>= 31;
    action_data->set_vni = tmp32 & 1;
    action_data->vni &= 0x7fffffff;
}

/**
 *  This function Parses sxd_mpls_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_mpls_flex_action
 * @param[in] action_reg - sxd_mpls_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_mpls(struct sxd_mpls_flex_action* action_data,
                                       sxd_mpls_flex_action_reg_t * action_reg)
{
    action_data->ttl_cmd = (action_reg->ttl_cmd >> 5) & 0x7;
    action_data->ttl = action_reg->ttl;
    action_data->exp_cmd = (action_reg->exp_cmd >> 6) & 0x3;
    action_data->exp = action_reg->exp & 0x7;
    action_data->exp_rw = (action_reg->exp_rw >> 6) & 0x3;
}

/**
 *  This function Parses sxd_hash_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_hash_flex_action
 * @param[in] action_reg - sxd_hash_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_hash(struct sxd_hash_flex_action* action_data,
                                       sxd_hash_flex_action_reg_t * action_reg)
{
    action_data->type = action_reg->type >> 6;
    action_data->hash_cmd = action_reg->hash_cmd;
    action_data->hash_value = cl_ntoh16(action_reg->hash_value);
    action_data->hash_fields = action_reg->hash_fields;
    action_data->hash_mask = cl_ntoh32(action_reg->hash_mask);
}

/**
 *  This function Parses sxd_virtual_forward_flax_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_virtual_forward_flax_action
 * @param[in] action_reg - sxd_virtual_forward_flax_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_virtual_forwarding(struct sxd_virtual_forward_flax_action * action_data
                                                     , sxd_virtual_forward_flax_action_reg_t* action_reg)
{
    action_data->vr_cmd = action_reg->vr_cmd >> 5;
    action_data->virtual_router = cl_ntoh16(action_reg->virtual_router);
    action_data->fid_cmd = action_reg->fid_cmd >> 5;
    action_data->fid = cl_ntoh16(action_reg->fid);
}

/**
 *  This function Parses sxd_ignore_flex_action  EMAD -> Data struct.
 *
 * @param[out] action_data -  sxd_ignore_flex_action
 * @param[in] action_reg - sxd_ignore_flex_action_reg_t
 *
 */
void sxd_emad_deparse_flex_action_ignore(struct sxd_ignore_flex_action* action_data,
                                         sxd_ignore_flex_action_reg_t * action_reg)
{
    action_data->ignore_stp = action_reg->is_iv_dl >> 7;
    action_data->ignore_vl_filter = (action_reg->is_iv_dl >> 6) & 0x1;
    action_data->disable_learning = (action_reg->is_iv_dl >> 5) & 0x1;
    action_data->disable_fdb_security = (action_reg->is_iv_dl >> 4) & 0x1;
    action_data->set_elephant_flow = action_reg->set_elephant & 0x3;
    action_data->ar_packet_prof_id = action_reg->ar_packet_prof & 0x3;
    action_data->ar_packet_prof_cmd = (action_reg->ar_packet_prof >> 4) & 0x1;
    action_data->disable_ovl_learning = action_reg->disable_ovl_learning >> 7;
    action_data->cond_mirror.cond_mirroring_mask = cl_ntoh16(action_reg->cond_mirroring_mask);
    action_data->cond_mirror.cond_mirroring_val = cl_ntoh16(action_reg->cond_mirroring_val);
}

void sxd_emad_deparse_flex_action_mc(struct sxd_mc_flex_action* action_data, sxd_mc_flex_action_reg_t* action_reg)
{
    uint32_t tmp32;

    action_data->expected_irif = cl_ntoh16(action_reg->expected_irif);
    action_data->expected_irif_list_index = cl_ntoh32(action_reg->expected_irif_list_index) & 0xFFFFFF;
    action_data->min_mtu = cl_ntoh16(action_reg->min_mtu);

    action_data->rpf_action = (action_reg->rpf_action_eir_type >> 4) & 0x7;
    action_data->eir_type = action_reg->rpf_action_eir_type & 0x1;
    tmp32 = cl_ntoh32(action_reg->vrmid_rigr_rmid_index);
    action_data->vrmid = tmp32 >> 31;
    action_data->rigr_rmid_index = tmp32 & 0xFFFFFF;
}

void sxd_emad_parse_flex_action_mc(struct sxd_mc_flex_action* action_data, sxd_mc_flex_action_reg_t* action_reg)
{
    uint32_t tmp32;

    action_reg->expected_irif = cl_hton16(action_data->expected_irif);
    action_reg->expected_irif_list_index = cl_hton32(action_data->expected_irif_list_index & 0xFFFFFF);
    action_reg->min_mtu = cl_hton16(action_data->min_mtu);
    action_reg->rpf_action_eir_type = (action_data->rpf_action & 0x7) << 4;
    action_reg->rpf_action_eir_type |= (action_data->eir_type & 0x1);
    tmp32 = action_data->vrmid;
    tmp32 <<= 31;
    action_reg->vrmid_rigr_rmid_index = cl_hton32(tmp32 | (action_data->rigr_rmid_index & 0xffffff));
}

void sxd_emad_parse_flex_action_sip_dip(struct sxd_sip_dip_flex_action* action_data,
                                        sxd_sip_dip_flex_action_reg_t * action_reg)
{
    action_reg->defer = action_data->defer & 0x1;
    action_reg->ip_63_32 = cl_hton32(action_data->ip_63_32);
    action_reg->ip_31_0 = cl_hton32(action_data->ip_31_0);
    action_reg->source_destination_byte = (action_data->direction & 0x1) << 7;
    action_reg->source_destination_byte |= (action_data->bytes & 0x1) << 6;
}

void sxd_emad_deparse_flex_action_sip_dip(struct sxd_sip_dip_flex_action* action_data,
                                          sxd_sip_dip_flex_action_reg_t * action_reg)
{
    action_data->defer = action_reg->defer & 0x1;
    action_data->ip_63_32 = cl_ntoh32(action_reg->ip_63_32);
    action_data->ip_31_0 = cl_ntoh32(action_reg->ip_31_0);
    action_data->direction = (action_reg->source_destination_byte >> 7) & 0x1;
    action_data->bytes = (action_reg->source_destination_byte >> 6) & 0x1;
}


void sxd_emad_parse_flex_action_l4_port(struct sxd_l4_port_flex_action* action_data,
                                        sxd_l4_port_flex_action_reg_t * action_reg)
{
    action_reg->defer = action_data->defer & 0x1;
    action_reg->l4_port = cl_hton16(action_data->l4_port);
    action_reg->hash = action_data->hash & 0x3;
    action_reg->source_destination = (action_data->direction & 0x1) << 7;
}

void sxd_emad_deparse_flex_action_l4_port(struct sxd_l4_port_flex_action* action_data,
                                          sxd_l4_port_flex_action_reg_t * action_reg)
{
    action_data->defer = action_reg->defer & 0x1;
    action_data->l4_port = cl_ntoh16(action_reg->l4_port);
    action_data->hash = action_reg->hash & 0x3;
    action_data->direction = (action_reg->source_destination >> 7) & 0x1;
}

void sxd_emad_parse_flex_action_truncation(sxd_trucation_flex_action_t      * action_data,
                                           sxd_truncation_flex_action_reg_t * action_reg)
{
    action_reg->en = action_data->trunc_en & 0x1;
    action_reg->tr_prof = action_data->trunc_profile_id & 0x3;
}

void sxd_emad_deparse_flex_action_truncation(sxd_trucation_flex_action_t      * action_data,
                                             sxd_truncation_flex_action_reg_t * action_reg)
{
    action_data->trunc_en = action_reg->en & 0x1;
    action_data->trunc_profile_id = action_reg->tr_prof & 3;
}

void sxd_emad_parse_flex_action_mirror_sampler(sxd_mirror_sampler_flex_action_t     * action_data,
                                               sxd_mirror_sampler_flex_action_reg_t * action_reg)
{
    action_reg->mirror_agent = action_data->mirror_agent & 0x7;
    action_reg->mirror_probability_rate = cl_hton32(action_data->mirror_probability_rate & 0xFFFFFF);
}

void sxd_emad_deparse_flex_action_mirror_sampler(sxd_mirror_sampler_flex_action_t     * action_data,
                                                 sxd_mirror_sampler_flex_action_reg_t * action_reg)
{
    action_data->mirror_agent = action_reg->mirror_agent & 0x7;
    action_data->mirror_probability_rate = cl_ntoh32(action_reg->mirror_probability_rate) & 0xFFFFFF;
}

void sxd_emad_parse_flex_action_custom_bytes_alu_imm(sxd_custom_bytes_alu_imm_flex_action_t     * action_data,
                                                     sxd_custom_bytes_alu_imm_flex_action_reg_t * action_reg)
{
    action_reg->opcode = action_data->opcode;
    action_reg->dest_cbset = action_data->dest_cbset;
    action_reg->imm = cl_hton16(action_data->imm);
    action_reg->mask = cl_hton16(action_data->mask);
}

void sxd_emad_deparse_flex_action_custom_bytes_alu_imm(sxd_custom_bytes_alu_imm_flex_action_t     * action_data,
                                                       sxd_custom_bytes_alu_imm_flex_action_reg_t * action_reg)
{
    action_data->opcode = action_reg->opcode;
    action_data->dest_cbset = action_reg->dest_cbset;
    action_data->imm = cl_ntoh16(action_reg->imm);
    action_data->mask = cl_ntoh16(action_reg->mask);
}

void sxd_emad_parse_flex_action_custom_bytes_alu_reg(sxd_custom_bytes_alu_reg_flex_action_t     * action_data,
                                                     sxd_custom_bytes_alu_reg_flex_action_reg_t * action_reg)
{
    action_reg->opcode = action_data->opcode;
    action_reg->dest_cbset = action_data->dest_cbset;
    action_reg->src_cbset = action_data->src_cbset;
    action_reg->mask = cl_hton16(action_data->mask);
    action_reg->shr = action_data->shr & 0xF;
}

void sxd_emad_deparse_flex_action_custom_bytes_alu_reg(sxd_custom_bytes_alu_reg_flex_action_t     * action_data,
                                                       sxd_custom_bytes_alu_reg_flex_action_reg_t * action_reg)
{
    action_data->opcode = action_reg->opcode;
    action_data->dest_cbset = action_reg->dest_cbset;
    action_data->src_cbset = action_reg->src_cbset;
    action_data->mask = cl_ntoh16(action_reg->mask);
    action_data->shr = action_reg->shr & 0xF;
}

void sxd_emad_parse_flex_action_custom_bytes_alu_field(sxd_custom_bytes_alu_field_flex_action_t     * action_data,
                                                       sxd_custom_bytes_alu_field_flex_action_reg_t * action_reg)
{
    action_reg->opcode = action_data->opcode;
    action_reg->cbset = action_data->cbset;
    action_reg->field_select = action_data->field_select;
    action_reg->mask = cl_hton16(action_data->mask);
    action_reg->shr = action_data->shr & 0xF;
}

void sxd_emad_deparse_flex_action_custom_bytes_alu_field(sxd_custom_bytes_alu_field_flex_action_t     * action_data,
                                                         sxd_custom_bytes_alu_field_flex_action_reg_t * action_reg)
{
    action_data->opcode = action_reg->opcode;
    action_data->cbset = action_reg->cbset;
    action_data->field_select = action_reg->field_select;
    action_data->mask = cl_ntoh16(action_reg->mask);
    action_data->shr = action_reg->shr & 0xF;
}

void sxd_emad_parse_flex_action_custom_bytes_move(sxd_custom_bytes_move_flex_action_t     * action_data,
                                                  sxd_custom_bytes_move_flex_action_reg_t * action_reg)
{
    action_reg->defer = (action_data->defer & 0x1) << 7;
    action_reg->opcode = action_data->opcode;
    action_reg->size = action_data->size;
    action_reg->dest_cbset = action_data->dest_cbset;
    action_reg->src_cbset = action_data->src_cbset;
    action_reg->field_select = action_data->field_select;
}

void sxd_emad_deparse_flex_action_custom_bytes_move(sxd_custom_bytes_move_flex_action_t     * action_data,
                                                    sxd_custom_bytes_move_flex_action_reg_t * action_reg)
{
    action_data->defer = (action_reg->defer >> 7) & 0x1;
    action_data->opcode = action_reg->opcode;
    action_data->size = action_reg->size;
    action_data->dest_cbset = action_reg->dest_cbset;
    action_data->src_cbset = action_reg->src_cbset;
    action_data->field_select = action_reg->field_select;
}

void sxd_emad_parse_flex_action_fields_set_imm(sxd_fields_set_imm_action_t     * action_data,
                                               sxd_fields_set_imm_action_reg_t * action_reg)
{
    action_reg->defer = (action_data->defer & 0x1) << 7;
    action_reg->size = action_data->size;
    action_reg->imm = cl_hton16(action_data->imm);
    action_reg->dest_field_select = action_data->dest_field_select;
}

void sxd_emad_deparse_flex_action_fields_set_imm(sxd_fields_set_imm_action_t     * action_data,
                                                 sxd_fields_set_imm_action_reg_t * action_reg)
{
    action_data->defer = (action_reg->defer >> 7) & 0x1;
    action_data->size = action_reg->size;
    action_data->imm = cl_ntoh16(action_reg->imm);
    action_data->dest_field_select = action_reg->dest_field_select;
}

void sxd_emad_parse_flex_action_fields_move(sxd_fields_move_action_t     * action_data,
                                            sxd_fields_move_action_reg_t * action_reg)
{
    action_reg->defer = (action_data->defer & 0x1) << 7;
    action_reg->size = action_data->size;
    action_reg->dest_field_select = action_data->dest_field_select;
    action_reg->src_field_select = action_data->src_field_select;
}

void sxd_emad_deparse_flex_action_fields_move(sxd_fields_move_action_t     * action_data,
                                              sxd_fields_move_action_reg_t * action_reg)
{
    action_data->defer = (action_reg->defer >> 7) & 0x1;
    action_data->size = action_reg->size;
    action_data->dest_field_select = action_reg->dest_field_select;
    action_data->src_field_select = action_reg->src_field_select;
}

void sxd_emad_parse_flex_action_flex_modifier_emt(sxd_flex_modifier_emt_action_t          * action_data,
                                                  sxd_flex_modifier_emt_flex_action_reg_t * action_reg)
{
    action_reg->emt_bind0 = action_data->emt_record[0].emt_opcode & 0xf;
    action_reg->emt_bind0 |= (action_data->emt_record[0].offset_type & 0x1) << 6;
    action_reg->emt_pointer0 = action_data->emt_record[0].emt_pointer;
    action_reg->modify_offset0 = action_data->emt_record[0].modify_offset;
    action_reg->modifier_base0 = action_data->emt_record[0].modifier_base & 0xf;
    action_reg->emt_bind1 = action_data->emt_record[1].emt_opcode & 0xf;
    action_reg->emt_bind1 |= (action_data->emt_record[1].offset_type & 0x1) << 6;
    action_reg->emt_pointer1 = action_data->emt_record[1].emt_pointer;
    action_reg->modify_offset1 = action_data->emt_record[1].modify_offset;
    action_reg->modifier_base1 = action_data->emt_record[1].modifier_base & 0xf;
}

void sxd_emad_deparse_flex_action_flex_modifier_emt(sxd_flex_modifier_emt_action_t          * action_data,
                                                    sxd_flex_modifier_emt_flex_action_reg_t * action_reg)
{
    action_data->emt_record[0].emt_opcode = action_reg->emt_bind0 & 0xf;
    action_data->emt_record[0].offset_type = (action_reg->emt_bind0 >> 6) & 0x1;
    action_data->emt_record[0].emt_pointer = action_reg->emt_pointer0;
    action_data->emt_record[0].modify_offset = action_reg->modify_offset0;
    action_data->emt_record[0].modifier_base = action_reg->modifier_base0 & 0xf;
    action_data->emt_record[1].emt_opcode = action_reg->emt_bind1 & 0xf;
    action_data->emt_record[1].offset_type = (action_reg->emt_bind1 >> 6) & 0x1;
    action_data->emt_record[1].emt_pointer = action_reg->emt_pointer1;
    action_data->emt_record[1].modify_offset = action_reg->modify_offset1;
    action_data->emt_record[1].modifier_base = action_reg->modifier_base1 & 0xf;
}

void sxd_emad_parse_flex_action_buffer_snap(sxd_buffer_snap_flex_action_t     * action_data,
                                            sxd_buffer_snap_flex_action_reg_t * action_reg)
{
    action_reg->snap_id = action_data->snap_id & 0x7;
}

void sxd_emad_deparse_flex_action_buffer_snap(sxd_buffer_snap_flex_action_t     * action_data,
                                              sxd_buffer_snap_flex_action_reg_t * action_reg)
{
    action_data->snap_id = action_reg->snap_id & 0x7;
}

void sxd_emad_parse_flex_action_stateful_db(sxd_flex_stateful_db_action_t          * action_data,
                                            sxd_flex_stateful_db_flex_action_reg_t * action_reg)
{
    action_reg->key_id = cl_hton16(action_data->key_id);
    action_reg->key_type = action_data->key_type & 0x1;
    action_reg->cbs_index = action_data->cbs_index & 0xF;
    action_reg->ticket_op = action_data->ticket_op & 0x3;
    action_reg->partition_id = action_data->partition_id & 0x7;
    action_reg->db_sem_op = ((action_data->db_op) & 0x7) << 4;
    action_reg->db_sem_op |= action_data->sem_op & 0x3;
}

void sxd_emad_deparse_flex_action_stateful_db(sxd_flex_stateful_db_action_t          * action_data,
                                              sxd_flex_stateful_db_flex_action_reg_t * action_reg)
{
    action_data->key_id = cl_ntoh16(action_reg->key_id);
    action_data->key_type = action_reg->key_type & 0x1;
    action_data->cbs_index = action_reg->cbs_index & 0xF;
    action_data->ticket_op = action_reg->ticket_op & 0x3;
    action_data->partition_id = action_reg->partition_id & 0x7;
    action_data->db_op = (action_reg->db_sem_op >> 4) & 0x7;
    action_data->sem_op = action_reg->db_sem_op & 0x3;
}

void sxd_emad_parse_flex_action(struct sxd_flex_action_set* action_data, sxd_emad_flex_action_set_reg_t* action_reg)
{
    uint8_t index = 0;

    for (index = 0; index < SXD_ACL_NUM_OF_ACTION_SLOTS; ++index) {
        action_reg->action_set[index].type = action_data->action_slots[index].type & 0x3f;
        switch (action_data->action_slots[index].type) { \

        case SXD_ACTION_TYPE_MAC_E:
            sxd_emad_parse_flex_action_mac(&action_data->action_slots[index].fields.action_mac
                                           , &action_reg->action_set[index].fields_reg_t.action_mac);
            break;

        case SXD_ACTION_TYPE_VLAN_E:
            sxd_emad_parse_flex_action_vlan(&action_data->action_slots[index].fields.action_vlan
                                            , &action_reg->action_set[index].fields_reg_t.action_vlan);
            break;

        case SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E:
        case SXD_ACTION_TYPE_TRAP_E:
            sxd_emad_parse_flex_action_trap(&action_data->action_slots[index].fields.action_trap
                                            , &action_reg->action_set[index].fields_reg_t.action_trap);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_E:
            sxd_emad_parse_flex_action_port(&action_data->action_slots[index].fields.action_port_filter
                                            , &action_reg->action_set[index].fields_reg_t.action_port_filter);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_EXT_E:
            sxd_emad_parse_flex_action_port_ext(&action_data->action_slots[index].fields.action_port_filter_ext
                                                , &action_reg->action_set[index].fields_reg_t.action_port_filter_ext);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_EXT2_E:
            sxd_emad_parse_flex_action_port_ext2(&action_data->action_slots[index].fields.action_port_filter_ext2
                                                 , &action_reg->action_set[index].fields_reg_t.action_port_filter_ext2);
            break;

        case SXD_ACTION_TYPE_QOS_E:
            sxd_emad_parse_flex_action_qos(&action_data->action_slots[index].fields.action_qos
                                           , &action_reg->action_set[index].fields_reg_t.action_qos);
            break;

        case SXD_ACTION_TYPE_FORWARD_E:
            sxd_emad_parse_flex_action_forward(&action_data->action_slots[index].fields.action_forward
                                               , &action_reg->action_set[index].fields_reg_t.action_forward);
            break;

        case SXD_ACTION_TYPE_POLICING_COUNTING_E:
            sxd_emad_parse_flex_action_policing(
                &action_data->action_slots[index].fields.action_policing_monitoring
                , &action_reg->action_set[index].fields_reg_t.action_policing_monitoring);
            break;

        case SXD_ACTION_TYPE_POLICING_COUNTING_BY_REF_E:
            sxd_emad_parse_flex_action_policing_by_ref(
                &action_data->action_slots[index].fields.action_policing_monitoring_by_ref
                , &action_reg->action_set[index].fields_reg_t.action_policing_monitoring_by_ref);
            break;

        case SXD_ACTION_TYPE_META_DATA_E:
            sxd_emad_parse_flex_action_meta_data(&action_data->action_slots[index].fields.action_metadata
                                                 , &action_reg->action_set[index].fields_reg_t.action_metadata);
            break;

        case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
            sxd_emad_parse_flex_action_uc_router(&action_data->action_slots[index].fields.action_uc_router
                                                 , &action_reg->action_set[index].fields_reg_t.action_uc_router);
            break;

        case SXD_ACTION_TYPE_VXLAN_E:
            sxd_emad_parse_flex_action_vxlan(&action_data->action_slots[index].fields.action_vni
                                             , &action_reg->action_set[index].fields_reg_t.action_vni);
            break;

        case SXD_ACTION_TYPE_MPLS_E:
            sxd_emad_parse_flex_action_mpls(&action_data->action_slots[index].fields.action_mpls
                                            , &action_reg->action_set[index].fields_reg_t.action_mpls);
            break;

        case SXD_ACTION_TYPE_HASH_E:
            sxd_emad_parse_flex_action_hash(&action_data->action_slots[index].fields.action_hash
                                            , &action_reg->action_set[index].fields_reg_t.action_hash);
            break;

        case SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E:
            sxd_emad_parse_flex_action_virtual_forwarding(
                &action_data->action_slots[index].fields.action_virtual_forward
                , &action_reg->action_set[index].fields_reg_t.action_virtual_forward);
            break;

        case SXD_ACTION_TYPE_IGNORE_E:
            sxd_emad_parse_flex_action_ignore(&action_data->action_slots[index].fields.action_ignore
                                              , &action_reg->action_set[index].fields_reg_t.action_ignore);
            break;

        case SXD_ACTION_TYPE_MC_E:
            sxd_emad_parse_flex_action_mc(&action_data->action_slots[index].fields.action_mc
                                          , &action_reg->action_set[index].fields_reg_t.action_mc);
            break;

        case SXD_ACTION_TYPE_SIP_DIP_E:
            sxd_emad_parse_flex_action_sip_dip(&action_data->action_slots[index].fields.action_sip_dip
                                               , &action_reg->action_set[index].fields_reg_t.action_sip_dip);
            break;

        case SXD_ACTION_TYPE_L4_PORT_E:
            sxd_emad_parse_flex_action_l4_port(&action_data->action_slots[index].fields.action_l4_port
                                               , &action_reg->action_set[index].fields_reg_t.action_l4_port);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E:
            sxd_emad_parse_flex_action_custom_bytes_alu_imm(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_imm,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_imm);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E:
            sxd_emad_parse_flex_action_custom_bytes_alu_reg(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_reg,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_reg);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E:
            sxd_emad_parse_flex_action_custom_bytes_alu_field(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_field,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_field);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E:
            sxd_emad_parse_flex_action_custom_bytes_move(
                &action_data->action_slots[index].fields.action_custom_bytes_move,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_move);
            break;

        case SXD_ACTION_TYPE_MIRROR_SAMPLER_E:
            sxd_emad_parse_flex_action_mirror_sampler(&action_data->action_slots[index].fields.action_mirror_sampler,
                                                      &action_reg->action_set[index].fields_reg_t.action_mirror_sampler);
            break;

        case SXD_ACTION_TYPE_FIELDS_SET_IMM_E:
            sxd_emad_parse_flex_action_fields_set_imm(
                &action_data->action_slots[index].fields.action_fields_set_imm,
                &action_reg->action_set[index].fields_reg_t.action_fields_set_imm);
            break;

        case SXD_ACTION_TYPE_FIELDS_MOVE_E:
            sxd_emad_parse_flex_action_fields_move(
                &action_data->action_slots[index].fields.action_fields_move,
                &action_reg->action_set[index].fields_reg_t.action_fields_move);
            break;

        case SXD_ACTION_TYPE_FLEX_MODIFIER_EMT_E:
            sxd_emad_parse_flex_action_flex_modifier_emt(
                &action_data->action_slots[index].fields.action_flex_modifier_emt,
                &action_reg->action_set[index].fields_reg_t.action_flex_modifier_emt);
            break;

        case SXD_ACTION_TYPE_BUFFER_SNAP_E:
            sxd_emad_parse_flex_action_buffer_snap(
                &action_data->action_slots[index].fields.action_buffer_snap,
                &action_reg->action_set[index].fields_reg_t.action_buffer_snap);
            break;

        case SXD_ACTION_TYPE_FS_DB_E:
            sxd_emad_parse_flex_action_stateful_db(
                &action_data->action_slots[index].fields.action_flex_stateful_db,
                &action_reg->action_set[index].fields_reg_t.action_flex_stateful_db);
            break;

        case SXD_ACTION_TYPE_TRUNCATION_E:
            sxd_emad_parse_flex_action_truncation(&action_data->action_slots[index].fields.action_truncation,
                                                  &action_reg->action_set[index].fields_reg_t.action_truncation);
            break;

        case SXD_ACTION_TYPE_FLOW_ESTIMATOR_E:
            sxd_emad_parse_flex_action_flow_estimator(
                &action_data->action_slots[index].fields.action_flow_estimator
                , &action_reg->action_set[index].fields_reg_t.action_flow_estimator);
            break;

        case SXD_ACTION_TYPE_NULL_E:
        default:
            break;
        }
    }
    action_reg->type = action_data->next_type << 4;

    if (action_data->next_type == SXD_FLEX_NEXT_POINTER_RECORD_E) {
        action_reg->next_goto_record.next_action_set_ptr =
            cl_hton32(action_data->next_goto_record.next_action_set_ptr);
    } else {
        action_reg->next_goto_record.goto_set_action.next_binding = cl_hton16(
            action_data->next_goto_record.goto_set_action.next_binding);
        action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd =
            (action_data->next_goto_record.goto_set_action.commit & 0x1) << 7;
        action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd |=
            ((action_data->next_goto_record.goto_set_action.group_binding & 0x1) << 5);
        action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd |=
            (action_data->next_goto_record.goto_set_action.binding_cmd & 0x7);
        action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd |=
            (action_data->next_goto_record.goto_set_action.clear & 0x7) << 6;
    }
}

void sxd_emad_deparse_flex_action(struct sxd_flex_action_set* action_data, sxd_emad_flex_action_set_reg_t* action_reg)
{
    uint8_t index = 0;

    for (index = 0; index < SXD_ACL_NUM_OF_ACTION_SLOTS; ++index) {
        action_data->action_slots[index].type = action_reg->action_set[index].type;
        switch (action_data->action_slots[index].type) {
        case SXD_ACTION_TYPE_MAC_E:
            sxd_emad_deparse_flex_action_mac(&action_data->action_slots[index].fields.action_mac
                                             , &action_reg->action_set[index].fields_reg_t.action_mac);
            break;

        case SXD_ACTION_TYPE_VLAN_E:
            sxd_emad_deparse_flex_action_vlan(&action_data->action_slots[index].fields.action_vlan
                                              , &action_reg->action_set[index].fields_reg_t.action_vlan);
            break;

        case SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E:
        case SXD_ACTION_TYPE_TRAP_E:
            sxd_emad_deparse_flex_action_trap(&action_data->action_slots[index].fields.action_trap
                                              , &action_reg->action_set[index].fields_reg_t.action_trap);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_E:
            sxd_emad_deparse_flex_action_port(&action_data->action_slots[index].fields.action_port_filter
                                              , &action_reg->action_set[index].fields_reg_t.action_port_filter);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_EXT_E:
            sxd_emad_deparse_flex_action_port_ext(&action_data->action_slots[index].fields.action_port_filter_ext
                                                  , &action_reg->action_set[index].fields_reg_t.action_port_filter_ext);
            break;

        case SXD_ACTION_TYPE_PORT_FILTER_EXT2_E:
            sxd_emad_deparse_flex_action_port_ext2(&action_data->action_slots[index].fields.action_port_filter_ext2,
                                                   &action_reg->action_set[index].fields_reg_t.action_port_filter_ext2);
            break;

        case SXD_ACTION_TYPE_QOS_E:
            sxd_emad_deparse_flex_action_qos(&action_data->action_slots[index].fields.action_qos
                                             , &action_reg->action_set[index].fields_reg_t.action_qos);
            break;

        case SXD_ACTION_TYPE_FORWARD_E:
            sxd_emad_deparse_flex_action_forward(&action_data->action_slots[index].fields.action_forward
                                                 , &action_reg->action_set[index].fields_reg_t.action_forward);
            break;

        case SXD_ACTION_TYPE_POLICING_COUNTING_E:
            sxd_emad_deparse_flex_action_policing(
                &action_data->action_slots[index].fields.action_policing_monitoring
                , &action_reg->action_set[index].fields_reg_t.action_policing_monitoring);
            break;

        case SXD_ACTION_TYPE_POLICING_COUNTING_BY_REF_E:
            sxd_emad_deparse_flex_action_policing_by_ref(
                &action_data->action_slots[index].fields.action_policing_monitoring_by_ref
                , &action_reg->action_set[index].fields_reg_t.action_policing_monitoring_by_ref);
            break;


        case SXD_ACTION_TYPE_META_DATA_E:
            sxd_emad_deparse_flex_action_meta_data(&action_data->action_slots[index].fields.action_metadata
                                                   , &action_reg->action_set[index].fields_reg_t.action_metadata);
            break;

        case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
            sxd_emad_deparse_flex_action_uc_router(&action_data->action_slots[index].fields.action_uc_router
                                                   , &action_reg->action_set[index].fields_reg_t.action_uc_router);
            break;

        case SXD_ACTION_TYPE_VXLAN_E:
            sxd_emad_deparse_flex_action_vxlan(&action_data->action_slots[index].fields.action_vni
                                               , &action_reg->action_set[index].fields_reg_t.action_vni);
            break;

        case SXD_ACTION_TYPE_MPLS_E:
            sxd_emad_deparse_flex_action_mpls(&action_data->action_slots[index].fields.action_mpls
                                              , &action_reg->action_set[index].fields_reg_t.action_mpls);
            break;

        case SXD_ACTION_TYPE_HASH_E:
            sxd_emad_deparse_flex_action_hash(&action_data->action_slots[index].fields.action_hash
                                              , &action_reg->action_set[index].fields_reg_t.action_hash);
            break;

        case SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E:
            sxd_emad_deparse_flex_action_virtual_forwarding(
                &action_data->action_slots[index].fields.action_virtual_forward
                , &action_reg->action_set[index].fields_reg_t.action_virtual_forward);
            break;

        case SXD_ACTION_TYPE_IGNORE_E:
            sxd_emad_deparse_flex_action_ignore(&action_data->action_slots[index].fields.action_ignore
                                                , &action_reg->action_set[index].fields_reg_t.action_ignore);
            break;

        case SXD_ACTION_TYPE_MC_E:
            sxd_emad_deparse_flex_action_mc(&action_data->action_slots[index].fields.action_mc
                                            , &action_reg->action_set[index].fields_reg_t.action_mc);
            break;

        case SXD_ACTION_TYPE_SIP_DIP_E:
            sxd_emad_deparse_flex_action_sip_dip(&action_data->action_slots[index].fields.action_sip_dip
                                                 , &action_reg->action_set[index].fields_reg_t.action_sip_dip);
            break;

        case SXD_ACTION_TYPE_L4_PORT_E:
            sxd_emad_deparse_flex_action_l4_port(&action_data->action_slots[index].fields.action_l4_port
                                                 , &action_reg->action_set[index].fields_reg_t.action_l4_port);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E:
            sxd_emad_deparse_flex_action_custom_bytes_alu_imm(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_imm,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_imm);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E:
            sxd_emad_deparse_flex_action_custom_bytes_alu_reg(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_reg,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_reg);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E:
            sxd_emad_deparse_flex_action_custom_bytes_alu_field(
                &action_data->action_slots[index].fields.action_custom_bytes_alu_field,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_alu_field);
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E:
            sxd_emad_deparse_flex_action_custom_bytes_move(
                &action_data->action_slots[index].fields.action_custom_bytes_move,
                &action_reg->action_set[index].fields_reg_t.action_custom_bytes_move);
            break;

        case SXD_ACTION_TYPE_MIRROR_SAMPLER_E:
            sxd_emad_deparse_flex_action_mirror_sampler(&action_data->action_slots[index].fields.action_mirror_sampler,
                                                        &action_reg->action_set[index].fields_reg_t.action_mirror_sampler);
            break;

        case SXD_ACTION_TYPE_TRUNCATION_E:
            sxd_emad_deparse_flex_action_truncation(&action_data->action_slots[index].fields.action_truncation,
                                                    &action_reg->action_set[index].fields_reg_t.action_truncation);
            break;

        case SXD_ACTION_TYPE_FIELDS_SET_IMM_E:
            sxd_emad_deparse_flex_action_fields_set_imm(
                &action_data->action_slots[index].fields.action_fields_set_imm,
                &action_reg->action_set[index].fields_reg_t.action_fields_set_imm);
            break;

        case SXD_ACTION_TYPE_FIELDS_MOVE_E:
            sxd_emad_deparse_flex_action_fields_move(
                &action_data->action_slots[index].fields.action_fields_move,
                &action_reg->action_set[index].fields_reg_t.action_fields_move);
            break;

        case SXD_ACTION_TYPE_FLEX_MODIFIER_EMT_E:
            sxd_emad_deparse_flex_action_flex_modifier_emt(
                &action_data->action_slots[index].fields.action_flex_modifier_emt,
                &action_reg->action_set[index].fields_reg_t.action_flex_modifier_emt);
            break;

        case SXD_ACTION_TYPE_BUFFER_SNAP_E:
            sxd_emad_deparse_flex_action_buffer_snap(
                &action_data->action_slots[index].fields.action_buffer_snap,
                &action_reg->action_set[index].fields_reg_t.action_buffer_snap);
            break;

        case SXD_ACTION_TYPE_FS_DB_E:
            sxd_emad_deparse_flex_action_stateful_db(
                &action_data->action_slots[index].fields.action_flex_stateful_db,
                &action_reg->action_set[index].fields_reg_t.action_flex_stateful_db);
            break;

        case SXD_ACTION_TYPE_FLOW_ESTIMATOR_E:
            sxd_emad_deparse_flex_action_flow_estimator(
                &action_data->action_slots[index].fields.action_flow_estimator
                , &action_reg->action_set[index].fields_reg_t.action_flow_estimator);

        case SXD_ACTION_TYPE_NULL_E:
        default:
            break;
        }
    }

    action_data->next_type = action_reg->type >> 4;

    if (action_data->next_type == SXD_FLEX_NEXT_POINTER_RECORD_E) {
        action_data->next_goto_record.next_action_set_ptr =
            cl_ntoh32(action_reg->next_goto_record.next_action_set_ptr);
    } else {
        action_data->next_goto_record.goto_set_action.next_binding = cl_ntoh16(
            action_reg->next_goto_record.goto_set_action.next_binding);
        action_data->next_goto_record.goto_set_action.commit =
            (action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd >> 7);
        action_data->next_goto_record.goto_set_action.group_binding =
            (action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd >> 5) & 0x1;
        action_data->next_goto_record.goto_set_action.clear =
            (action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd >> 6) & 0x1;
        action_data->next_goto_record.goto_set_action.binding_cmd =
            action_reg->next_goto_record.goto_set_action.commit__clear_g_binding_cmd & 0x7;
    }
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] prbt_data - register data struct.
 * @param[out] prbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_prbt(sxd_emad_prbt_data_t *prbt_data, sxd_emad_prbt_reg_t *prbt_reg)
{
    prbt_reg->e_op = prbt_data->reg_data->egress_indication << 7;
    prbt_reg->e_op |= ((prbt_data->reg_data->op & 7) << 4);
    prbt_reg->rif = cl_hton16(prbt_data->reg_data->rif);
    prbt_reg->g = ((prbt_data->reg_data->group_binding & 1) << 7);
    prbt_reg->acl_id_grp_id = cl_hton16(prbt_data->reg_data->acl_id_grp_id);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] prbt_data - register data struct.
 * @param[in] prbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_prbt(sxd_emad_prbt_data_t *prbt_data, sxd_emad_prbt_reg_t *prbt_reg)
{
    prbt_data->reg_data->op = (prbt_reg->e_op >> 4) & 7;
    prbt_data->reg_data->group_binding = (prbt_reg->g >> 7) & 1;
    prbt_data->reg_data->acl_id_grp_id = cl_ntoh16(prbt_reg->acl_id_grp_id);
    return SXD_STATUS_SUCCESS;
}


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pefa_data - register data struct.
 * @param[out] pefa_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pefa(sxd_emad_pefa_data_t *pefa_data, sxd_emad_pefa_reg_t *pefa_reg)
{
    pefa_reg->pind_index = cl_hton32(pefa_data->reg_data->index & 0x00ffffff);
    pefa_reg->pind_index |= cl_hton32((pefa_data->reg_data->pind & 0x3) << 30);
    pefa_reg->activity = (pefa_data->reg_data->ca & 0x3);
    pefa_reg->activity |= ((pefa_data->reg_data->a & 0x1) << 5);
    pefa_reg->activity |= ((pefa_data->reg_data->a1 & 0x1) << 4);
    pefa_reg->ddd_en = ((pefa_data->reg_data->ddd_en & 0x1) << 4);
    pefa_reg->as_user_val |= cl_hton16(pefa_data->reg_data->as_user_val & 0x3FF);
    sxd_emad_parse_flex_action(&pefa_data->reg_data->action_set, &pefa_reg->flex_action_set);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pefa_data - register data struct.
 * @param[in] pefa_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pefa(sxd_emad_pefa_data_t *pefa_data, sxd_emad_pefa_reg_t *pefa_reg)
{
    pefa_data->reg_data->index = cl_ntoh32(pefa_reg->pind_index) & 0x00ffffff;
    pefa_data->reg_data->pind = (cl_ntoh32(pefa_reg->pind_index) >> 30) & 0x3;
    pefa_data->reg_data->ca = (pefa_reg->activity & 0x3);
    pefa_data->reg_data->a = ((pefa_reg->activity >> 5) & 0x1);
    pefa_data->reg_data->a1 = ((pefa_reg->activity >> 4) & 0x1);
    pefa_data->reg_data->ddd_en = (pefa_reg->ddd_en >> 4) & 0x1;
    pefa_data->reg_data->as_user_val = cl_ntoh16(pefa_reg->as_user_val) & 0x3FF;
    sxd_emad_deparse_flex_action(&pefa_data->reg_data->action_set, &pefa_reg->flex_action_set);
    return SXD_STATUS_SUCCESS;
}


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ptce2_data - register data struct.
 * @param[out] ptce2_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptce2(sxd_emad_ptce2_data_t *ptce2_data, sxd_emad_ptce2_reg_t *ptce2_reg)
{
    ptce2_reg->v_a = ((ptce2_data->reg_data->valid & 0x1) << 7);
    ptce2_reg->op = ((ptce2_data->reg_data->op & 0x7) << 4);
    ptce2_reg->offset = cl_hton16(ptce2_data->reg_data->offset);
    ptce2_reg->priority = cl_hton32(ptce2_data->reg_data->priority & 0xffffff);
    memcpy(ptce2_reg->tcam_region_info, ptce2_data->reg_data->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(ptce2_reg->flex_key_blocks, ptce2_data->reg_data->flex_key_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    memcpy(ptce2_reg->mask, ptce2_data->reg_data->flex_mask_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    sxd_emad_parse_flex_action(&ptce2_data->reg_data->action_set, &ptce2_reg->flex_action_set);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ptce2_data - register data struct.
 * @param[in] ptce2_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_ptce2(sxd_emad_ptce2_data_t *ptce2_data, sxd_emad_ptce2_reg_t *ptce2_reg)
{
    ptce2_data->reg_data->valid = (ptce2_reg->v_a >> 7) & 0x1;
    ptce2_data->reg_data->activity = (ptce2_reg->v_a >> 6) & 0x1;
    ptce2_data->reg_data->op = (ptce2_reg->op >> 4);
    ptce2_data->reg_data->priority = cl_ntoh32(ptce2_reg->priority & 0xffffff);
    memcpy(ptce2_data->reg_data->flex_key_blocks, ptce2_reg->flex_key_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    memcpy(ptce2_data->reg_data->flex_mask_blocks, ptce2_reg->mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    sxd_emad_deparse_flex_action(&ptce2_data->reg_data->action_set, &ptce2_reg->flex_action_set);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pagt_data - register data struct.
 * @param[out] pagt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pagt(sxd_emad_pagt_data_t *pagt_data, sxd_emad_pagt_reg_t *pagt_reg)
{
    uint8_t i;

    pagt_reg->e = pagt_data->reg_data->egress << 7;
    pagt_reg->size = pagt_data->reg_data->size;
    pagt_reg->acl_group_id = cl_hton16(pagt_data->reg_data->acl_group_id);
    for (i = 0; i < pagt_data->reg_data->size; i++) {
        pagt_reg->acl_ids[i].acl_id = cl_hton16(pagt_data->reg_data->acl_ids[i].acl_id);
        pagt_reg->acl_ids[i].multi_commit = (pagt_data->reg_data->acl_ids[i].multi & 0x1) << 7;
        pagt_reg->acl_ids[i].multi_commit |= (pagt_data->reg_data->acl_ids[i].commit & 0x1) << 6;
    }
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pagt_data - register data struct.
 * @param[in] pagt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pagt(sxd_emad_pagt_data_t *pagt_data, sxd_emad_pagt_reg_t *pagt_reg)
{
    uint8_t i;

    pagt_data->reg_data->size = pagt_reg->size;
    for (i = 0; i < pagt_data->reg_data->size; i++) {
        pagt_data->reg_data->acl_ids[i].acl_id = cl_ntoh16(pagt_reg->acl_ids[i].acl_id);
        pagt_data->reg_data->acl_ids[i].commit = (pagt_reg->acl_ids[i].multi_commit >> 6) & 0x1;
        pagt_data->reg_data->acl_ids[i].multi = (pagt_reg->acl_ids[i].multi_commit >> 7) & 0x1;
    }
    return SXD_STATUS_SUCCESS;
}


sxd_status_t sxd_emad_pagt_acl_info_size(sxd_emad_pagt_data_t *pagt_data, uint32_t *pagt_acl_info_size)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *pagt_acl_info_size = pagt_data->reg_data->size * sizeof(pagt_data->reg_data->acl_ids[0]);

    SX_LOG_EXIT();
    return err;
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] puet_data - register data struct.
 * @param[out] puet_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_puet(sxd_emad_puet_data_t *puet_data, sxd_emad_puet_reg_t *puet_reg)
{
    puet_reg->index = puet_data->reg_data->index & 0xf;
    puet_reg->ethertype = cl_hton16(puet_data->reg_data->ethertype);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] puet_data - register data struct.
 * @param[in] puet_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_puet(sxd_emad_puet_data_t *puet_data, sxd_emad_puet_reg_t *puet_reg)
{
    puet_data->reg_data->index = puet_reg->index & 0xf;
    puet_data->reg_data->ethertype = cl_ntoh16(puet_reg->ethertype);
    return SXD_STATUS_SUCCESS;
}

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pecb_data - register data struct.
 * @param[out] pecb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pecb(sxd_emad_pecb_data_t *pecb_data, sxd_emad_pecb_reg_t  *pecb_reg)
{
    uint32_t i = 0;

    pecb_reg->cbset = pecb_data->reg_data->cbset;
    for (i = 0; i < SXD_ACL_NUM_OF_EXTRACTION_POINT; ++i) {
        pecb_reg->extraction_points[i].enable = pecb_data->reg_data->extraction_points[i].enable << 7;
        pecb_reg->extraction_points[i].offset = pecb_data->reg_data->extraction_points[i].offset;
    }
    return SXD_STATUS_SUCCESS;
}
/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pecb_data - register data struct.
 * @param[in] pecb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pecb(sxd_emad_pecb_data_t *pecb_data, sxd_emad_pecb_reg_t  *pecb_reg)
{
    uint32_t i = 0;

    pecb_data->reg_data->cbset = pecb_reg->cbset;
    for (i = 0; i < SXD_ACL_NUM_OF_EXTRACTION_POINT; ++i) {
        pecb_data->reg_data->extraction_points[i].enable = pecb_reg->extraction_points[i].enable >> 7;
        pecb_data->reg_data->extraction_points[i].offset = pecb_reg->extraction_points[i].offset;
    }
    return SXD_STATUS_SUCCESS;
}


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pemb_data - register data struct.
 * @param[out] pemb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pemb(sxd_emad_pemb_data_t *pemb_data, sxd_emad_pemb_reg_t  *pemb_reg)
{
    pemb_reg->type = (pemb_data->reg_data->type & 0x3) << 4;
    if (pemb_data->reg_data->type == KU_PEMB_ENTRY_TYPE_EGRESS_ACL_MULTICAST_E) {
        pemb_reg->record.multicast_egress.valid = pemb_data->reg_data->record.multicast_egress.valid & 0x1;
        pemb_reg->record.multicast_egress.group_id =
            (pemb_data->reg_data->record.multicast_egress.group_id & 0x3) << 6;
        pemb_reg->record.multicast_egress.egress_port_list_63_32 = cl_hton32(
            pemb_data->reg_data->record.multicast_egress.egress_port_list_63_32);
        pemb_reg->record.multicast_egress.egress_port_list_31_0 = cl_hton32(
            pemb_data->reg_data->record.multicast_egress.egress_port_list_31_0);
    }
    return SXD_STATUS_SUCCESS;
}
/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pemb_data - register data struct.
 * @param[in] pemb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pemb(sxd_emad_pemb_data_t *pemb_data, sxd_emad_pemb_reg_t  *pemb_reg)
{
    pemb_data->reg_data->type = (pemb_reg->type >> 4) & 0x3;
    if (pemb_data->reg_data->type == KU_PEMB_ENTRY_TYPE_EGRESS_ACL_MULTICAST_E) {
        pemb_data->reg_data->record.multicast_egress.valid = pemb_reg->record.multicast_egress.valid & 0x1;
        pemb_data->reg_data->record.multicast_egress.group_id =
            (pemb_reg->record.multicast_egress.group_id >> 6) & 0x3;
        pemb_data->reg_data->record.multicast_egress.egress_port_list_63_32 = cl_ntoh32(
            pemb_reg->record.multicast_egress.egress_port_list_63_32);
        pemb_data->reg_data->record.multicast_egress.egress_port_list_31_0 = cl_ntoh32(
            pemb_reg->record.multicast_egress.egress_port_list_31_0);
    }
    return SXD_STATUS_SUCCESS;
}
