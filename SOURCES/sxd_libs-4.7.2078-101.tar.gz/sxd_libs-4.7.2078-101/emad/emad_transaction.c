/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include <complib/cl_passivelock.h>
#include <complib/cl_semaphore.h>
#include <sx/utils/bit_vector.h>

#include "emad_transaction.h"
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_TRANSACTION

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_spinlock_t                    __notif_tid_lock;
static bit_vector_t                     __emad_disabled; /* EMAD_NUM_DEV_ID bits */
static cl_qlist_t                       __emad_tid_list[EMAD_NUM_DEV_ID];
static cl_spinlock_t                    __emad_tid_list_lock;
static boolean_t                        __transaction_mode = FALSE;
static cl_plock_t                       __transaction_mode_lock;
static sxd_emad_notify_latest_tx_tid_cb __emad_tx_cb;
static void                            *__emad_tx_cb_context;
static sxd_emad_notify_latest_rx_tid_cb __emad_rx_cb;
static void                            *__emad_rx_cb_context;
static cl_semaphore_t                   __emad_in_flight_sem;
static boolean_t                        __emad_in_debug_dump = FALSE;
static uint32_t                         __pre_debug_dump_emad_timeout = 0;

/* should be called under __emad_tid_list_lock */
static void __emad_dev_id_enable_all(void)
{
    sx_utils_status_t utils_st = SX_UTILS_STATUS_SUCCESS;
    uint32_t          dev_id;

    utils_st = bit_vector_find_first_set(__emad_disabled, &dev_id);
    while (utils_st == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_INF("enabling EMAD on device %u\n", dev_id);
        bit_vector_clear(__emad_disabled, dev_id);
        utils_st = bit_vector_find_next_set(__emad_disabled, &dev_id);
    }
}

/* should be called under __emad_tid_list_lock */
static void __emad_dev_id_disable(sxd_dev_id_t dev_id)
{
    SX_LOG_INF("disabling EMAD on device %u\n", dev_id);
    bit_vector_set(__emad_disabled, dev_id);
}

sxd_status_t emad_transaction_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        emad_rx_thread_log_verbosity_level_set(verbosity_level_p[0]);
        emad_tx_thread_log_verbosity_level_set(verbosity_level_p[0]);
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


sxd_status_t emad_transaction_init(uint32_t app_id)
{
    sxd_status_t      sxd_st = SXD_STATUS_SUCCESS;
    cl_status_t       cl_st = CL_SUCCESS;
    sx_utils_status_t utils_st = SX_UTILS_STATUS_SUCCESS;
    int               dev_id;

    cl_st = cl_plock_init(&__transaction_mode_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to create transaction-mode lock (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto tr_mode_lock_failed;
    }

    sxd_st = emad_buffer_init();
    if (sxd_st != SXD_STATUS_SUCCESS) {
        goto emad_buffer_failed;
    }

    emad_set_tid_base(app_id);

    cl_st = cl_spinlock_init(&__notif_tid_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to initialize notification tid lock (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto notif_tid_lock_failed;
    }

    utils_st = bit_vector_allocate(EMAD_NUM_DEV_ID, &__emad_disabled);
    if (utils_st != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to allocate bit-vector for EMAD devices (err=%d)\n", utils_st);
        sxd_st = SXD_STATUS_ERROR;
        goto bit_vector_failed;
    }

    for (dev_id = 0; dev_id < EMAD_NUM_DEV_ID; dev_id++) {
        cl_qlist_init(&__emad_tid_list[dev_id]);
    }

    cl_st = cl_spinlock_init(&__emad_tid_list_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to initialize emad tid list lock (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto tid_list_lock_failed;
    }

    /* fill up to 95% of the RDQ capacity so there no chance of EMAD drops in RDQ */
    cl_semaphore_init(&__emad_in_flight_sem, (1024 * 95) / 100);

    return SXD_STATUS_SUCCESS;

tid_list_lock_failed:
    bit_vector_free(__emad_disabled);

bit_vector_failed:
    cl_spinlock_destroy(&__notif_tid_lock);

notif_tid_lock_failed:
    emad_buffer_deinit();

emad_buffer_failed:
    cl_plock_destroy(&__transaction_mode_lock);

tr_mode_lock_failed:
    return sxd_st;
}


void emad_transaction_deinit(void)
{
    cl_semaphore_destroy(&__emad_in_flight_sem);
    cl_spinlock_destroy(&__emad_tid_list_lock);
    cl_spinlock_destroy(&__notif_tid_lock);
    bit_vector_free(__emad_disabled);
    emad_buffer_deinit();
    cl_plock_destroy(&__transaction_mode_lock);
}


uint64_t emad_transaction_alloc_notification_id(void)
{
    /*
     * Notification Transaction ID for Async Infra (64 bit) ==> all 64bit are running-counter
     * right now async-infra assumes that Notification ID is incrementing all the time and this is
     * why we separate it from real EMAD transaction-id.
     *
     */

    static uint64_t notification_tid = 0;
    uint64_t        ret;

    cl_spinlock_acquire(&__notif_tid_lock);
    ret = ++notification_tid;
    cl_spinlock_release(&__notif_tid_lock);

    return ret;
}


static boolean_t __emad_transaction_in_range(uint64_t tid, uint64_t head_tid, uint64_t tail_tid)
{
    /*
     * this function tries to figure out if a certain transaction ID 'tid' exists in a list of
     * in-flight transaction IDs. the first tid in the list is 'head_tid'. the last tid in the list
     * is 'tail_tid'.
     *
     * the most common and simple case is [head_tid <= tid <= tail_tid].
     *
     * the corner case is when we have a wrap-around in the list:
     * [head_tid, ..., MAX_TID_VALUE, ZERO_TID_VALUE, ..., tail_tid]
     * the tid is in this list if [head_tid <= tid <= MAX_TID_VALUE] or [ZERO_TID_VALUE <= tid <= tail_tid]
     * where ZERO_TID_VALUE=(0x<__emad_tid_base> | 0x00000000), MAX_TID_VALUE=(0x<__emad_tid_base> | 0xffffffff)
     */

    if (head_tid <= tail_tid) {
        /* most of the time, head_tid <= tail_tid */
        return (tid >= head_tid && tid <= tail_tid);
    }

    /* if we're here (tid wrap-around), head_tid >= tail_tid */
    return (tid >= head_tid || tid <= tail_tid);
}


sxd_status_t emad_transaction_add(struct emad_buffer *emad_buffer)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;

    cl_semaphore_wait_on(&__emad_in_flight_sem, SEMAPHORE_NO_TIMEOUT);

    cl_spinlock_acquire(&__emad_tid_list_lock);

    if (emad_buffer->tr_state == EMAD_TR_STATE_TIMED_OUT) {
        /* main thread got timed-out before the TX thread even put the buffer on its queue */
        emad_buffer_dealloc(emad_buffer);
        st = SXD_STATUS_TIMEOUT;
    } else {
        emad_buffer->tr_state = EMAD_TR_STATE_IN_TX_QUEUE;
        cl_qlist_insert_tail(&__emad_tid_list[EMAD_BUFFER_DEV_ID(emad_buffer)], &emad_buffer->tid_list);
        if (EMAD_BUFFER_MODE(emad_buffer) != SXD_ACCESS_MODE_ASYNC) {
            sync_emad_bpf_stub_func_req();
        } else {
            async_emad_bpf_stub_func_req(emad_buffer->reg_id, emad_buffer->emad_tid);
        }
    }

    cl_spinlock_release(&__emad_tid_list_lock);
    return st;
}


sxd_status_t emad_transaction_delete(uint64_t             tid,
                                     uint32_t             emad_latency,
                                     uint32_t             cache_read_time,
                                     struct emad_buffer **buffer)
{
    cl_list_item_t           *head, *tail;
    const struct emad_buffer *head_buff, *tail_buff;
    struct emad_buffer       *emad_buffer;
    sxd_status_t              sxd_st = SXD_STATUS_ERROR;
    boolean_t                 cont = TRUE;
    sxd_dev_id_t              dev_id = EMAD_TID_GET_DEV_ID(tid);

    cl_spinlock_acquire(&__emad_tid_list_lock);

    if (cl_is_qlist_empty(&__emad_tid_list[dev_id])) {
        SX_LOG_ERR("EMAD TID 0x%" PRIx64 " is unsolicited: there is no in-flight transaction (dev_id=%u)\n",
                   tid, dev_id);
        goto unlock;
    }

    head = cl_qlist_head(&__emad_tid_list[dev_id]);
    tail = cl_qlist_tail(&__emad_tid_list[dev_id]);

    head_buff = PARENT_STRUCT(head, struct emad_buffer, tid_list);
    tail_buff = PARENT_STRUCT(tail, struct emad_buffer, tid_list);

    if (!__emad_transaction_in_range(tid, head_buff->emad_tid, tail_buff->emad_tid)) {
        SX_LOG_ERR("EMAD TID 0x%" PRIx64 " is unsolicited: transaction is out of in-flight range "
                   "(dev_id=%u, head_tid=0x%" PRIx64 ", tail_tid=0x%" PRIx64 ")\n",
                   tid, dev_id, head_buff->emad_tid, tail_buff->emad_tid);
        goto unlock;
    }

    while (cont) {
        cont = (head != tail); /* when we get to 'tail' we know it is the last iteration in the loop */

        /* detach the first entry from the list, keep it in 'emad_buffer' and assign a new head */
        emad_buffer = PARENT_STRUCT(head, struct emad_buffer, tid_list);
        cl_qlist_remove_item(&__emad_tid_list[dev_id], head);
        head = cl_qlist_head(&__emad_tid_list[dev_id]);

        cl_semaphore_release(&__emad_in_flight_sem);

        /* we expect that requested tid will be at the beginning of the tid-list.
         * in this case, we just change the state of the transaction and go out.
         */
        if (emad_buffer->emad_tid == tid) {
            emad_buffer->emad_latency = emad_latency;
            emad_buffer->cache_read_time = cache_read_time;
            emad_buffer->tr_state = EMAD_TR_STATE_RX_RECEIVED;
            *buffer = emad_buffer;
            sxd_st = SXD_STATUS_SUCCESS;
            if (EMAD_BUFFER_MODE(emad_buffer) != SXD_ACCESS_MODE_ASYNC) {
                sync_emad_bpf_stub_func_resp(emad_latency);
            } else {
                async_emad_bpf_stub_func_resp(emad_buffer->reg_id, emad_buffer->emad_tid, emad_latency);
            }
            break;
        }

        /* if we get here, it means that we have at least one unexpected transaction(s) in the
         * tid-list that comes before the expected one. it can be one of these cases:
         * 1) FW replies come in a different order than the requests we've sent (which is not good).
         * 2) user is working in transaction mode (no one waits for EMAD replies) and one or more
         *    of the requests did not get any reply for some reason.
         *
         * anyhow, we're going to ignore this reply and put an error for this.
         * */
        SX_LOG_ERR("EMAD transaction reply is out-of-order! "
                   "(curr_tid=0x%" PRIx64 ", expected_tid (head_tid)=0x%" PRIx64 ", tail_tid=0x%" PRIx64 " "
                   "reg_id=0x%x [%s], dev_id=%u, access_cmd=%u)\n",
                   tid,
                   emad_buffer->emad_tid,
                   tail_buff->emad_tid,
                   emad_buffer->reg_id,
                   REG_ID_TO_NAME(emad_buffer->reg_id),
                   EMAD_BUFFER_DEV_ID(emad_buffer),
                   EMAD_BUFFER_ACCESS_CMD(emad_buffer));

        /* if no one waits for the transaction (sync_event is NULL), let's deallocate the buffer.
         * if the main thread waited for this transaction and already timed out, the main thread
         * is responsible for deallocating the transaction (emad_transaction_timeout()).
         */
        if (!emad_buffer->sync_event) {
            emad_buffer_dealloc(emad_buffer);
        }
    }

unlock:

    cl_spinlock_release(&__emad_tid_list_lock);
    return sxd_st;
}


void emad_transaction_timeout(struct emad_buffer *emad_buffer, uint32_t waited_usec)
{
    boolean_t   should_wait = FALSE;
    boolean_t   in_tx_queue = FALSE;
    boolean_t   deallocate_buffer = FALSE;
    cl_status_t cl_st;

    cl_spinlock_acquire(&__emad_tid_list_lock);
    should_wait = (emad_buffer->tr_state == EMAD_TR_STATE_RX_RECEIVED); /* maybe in between we got a reply */
    in_tx_queue = (emad_buffer->tr_state == EMAD_TR_STATE_IN_TX_QUEUE); /* transaction may be timed-out before
                                                                         *  even entering the TX queue */

    deallocate_buffer = (should_wait || in_tx_queue); /* we don't deallocate only in case we got timed-out
                                                       *  before even entering the TX queue. buffer will be
                                                       *  deallocated in emad_transaction_add() in this case. */

    if (!should_wait && __emad_in_debug_dump) {
        SX_LOG_WRN("Timeout during debug-dump on device %u. Temporarily disabling device.\n",
                   EMAD_BUFFER_DEV_ID(emad_buffer));
        __emad_dev_id_disable(EMAD_BUFFER_DEV_ID(emad_buffer));
    }

    switch (emad_buffer->tr_state) {
    case EMAD_TR_STATE_ALLOCATED:
        SX_LOG_ERR(
            "ACCESS_REG TIMEOUT (before even being placed in TX queue): "
            "timeout_usec=%u, reg=0x%x [%s], dev_id=%u, access_cmd=%u\n",
            waited_usec,
            emad_buffer->reg_id,
            REG_ID_TO_NAME(emad_buffer->reg_id),
            EMAD_BUFFER_DEV_ID(emad_buffer),
            EMAD_BUFFER_ACCESS_CMD(emad_buffer));
        break;

    case EMAD_TR_STATE_IN_TX_QUEUE:
        SX_HEXDUMP(SX_LOG_WARNING, emad_buffer->prm_reg_buff, emad_buffer->reg_size);
        SX_LOG_ERR(
            "ACCESS_REG TIMEOUT (sent to FW but there was no reply): "
            "timeout_usec=%u, tid=0x%" PRIx64 ", reg=0x%x [%s], dev_id=%u, access_cmd=%u\n",
            waited_usec,
            emad_buffer->emad_tid,
            emad_buffer->reg_id,
            REG_ID_TO_NAME(emad_buffer->reg_id),
            EMAD_BUFFER_DEV_ID(emad_buffer),
            EMAD_BUFFER_ACCESS_CMD(emad_buffer));
        break;

    case EMAD_TR_STATE_RX_RECEIVED:
        SX_HEXDUMP(SX_LOG_WARNING, emad_buffer->prm_reg_buff, emad_buffer->reg_size);
        SX_LOG_ERR(
            "ACCESS_REG TIMEOUT (received after timeout expiration): timeout_usec=%u, tid=0x%" PRIx64 ", reg=0x%x [%s], emad_latency_usec=%u, cache_read_time=%u, dev_id=%u, access_cmd=%u\n",
            waited_usec,
            emad_buffer->emad_tid,
            emad_buffer->reg_id,
            REG_ID_TO_NAME(emad_buffer->reg_id),
            emad_buffer->emad_latency,
            emad_buffer->cache_read_time,
            EMAD_BUFFER_DEV_ID(emad_buffer),
            EMAD_BUFFER_ACCESS_CMD(emad_buffer));
        break;

    default:
        /* we should not get here ... */
        SX_HEXDUMP(SX_LOG_WARNING, emad_buffer->prm_reg_buff, emad_buffer->reg_size);
        SX_LOG_ERR(
            "ACCESS_REG TIMEOUT (unexpected transaction state): "
            "timeout_usec=%u, tid=0x%" PRIx64 ", reg=0x%x [%s], state=%d, dev_id=%u, access_cmd=%u\n",
            waited_usec,
            emad_buffer->emad_tid,
            emad_buffer->reg_id,
            REG_ID_TO_NAME(emad_buffer->reg_id),
            emad_buffer->tr_state,
            EMAD_BUFFER_DEV_ID(emad_buffer),
            EMAD_BUFFER_ACCESS_CMD(emad_buffer));
        break;
    }

    emad_buffer->tr_state = EMAD_TR_STATE_TIMED_OUT; /* anyhow, we mark this transaction as 'timed-out' */

    if (in_tx_queue) { /* reply was not received & transaction is in TX queue */
        cl_qlist_remove_item(&__emad_tid_list[EMAD_BUFFER_DEV_ID(emad_buffer)], &emad_buffer->tid_list);
    }

    cl_spinlock_release(&__emad_tid_list_lock);

    /* we might get into a situation where the timeout expired for an EMAD transaction but the
     * reply from FW received a very-short time after.
     * in this case, we MUST wait for it to complete because RX thread uses some data that
     * was allocated on our own thread's stack (emad_buffer->sync_event, emad_buffer->reg_data).
     * we will wait on the very same sync_event that was timed-out and caused us to get into
     * this function.
     */

    if (should_wait) {
        do {
            cl_st = cl_event_wait_on(emad_buffer->sync_event, EVENT_NO_TIMEOUT, TRUE);
        } while (cl_st == CL_NOT_DONE);
    }

    if (deallocate_buffer) {
        emad_buffer_dealloc(emad_buffer);
    }
}


sxd_status_t sxd_emad_transaction_mode_set(boolean_t enable)
{
    cl_plock_excl_acquire(&__transaction_mode_lock);
    __transaction_mode = enable;
    cl_plock_release(&__transaction_mode_lock);

    return SXD_STATUS_SUCCESS;
}


sxd_status_t sxd_emad_transaction_mode_get(boolean_t *enable)
{
    cl_plock_acquire(&__transaction_mode_lock);
    *enable = __transaction_mode;
    cl_plock_release(&__transaction_mode_lock);

    return SXD_STATUS_SUCCESS;
}


void emad_transaction_register_tx_cb(sxd_emad_notify_latest_tx_tid_cb cb, void *context)
{
    __emad_tx_cb = cb;
    __emad_tx_cb_context = context;
}


void emad_transaction_register_rx_cb(sxd_emad_notify_latest_rx_tid_cb cb, void *context)
{
    __emad_rx_cb = cb;
    __emad_rx_cb_context = context;
}


sxd_status_t emad_transaction_call_tx_callback(uint64_t notif_tid)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if (__emad_tx_cb) {
        err = __emad_tx_cb(&notif_tid, __emad_tx_cb_context);
        if (err != SXD_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Error calling TX latest tid cb err [%d]-[%s]\n", err, SXD_STATUS_MSG(err));
        }
    }

    return err;
}


sxd_status_t emad_transaction_call_rx_callback(uint64_t notif_tid)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if (__emad_rx_cb) {
        err = __emad_rx_cb(&notif_tid, __emad_rx_cb_context);
        if (err != SXD_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Error calling RX latest tid cb err [%d]-[%s]\n", err, SXD_STATUS_MSG(err));
        }
    }

    return err;
}


boolean_t emad_dev_id_is_disabled(sxd_dev_id_t dev_id)
{
    boolean_t ret = TRUE;

    cl_spinlock_acquire(&__emad_tid_list_lock);
    /* coverity[check_return] */
    bit_vector_get(__emad_disabled, dev_id, &ret);
    cl_spinlock_release(&__emad_tid_list_lock);
    return ret;
}


sxd_status_t sxd_emad_debug_dump_start(uint32_t timeout_usec)
{
    sxd_status_t ret = SXD_STATUS_SUCCESS;

    cl_spinlock_acquire(&__emad_tid_list_lock);
    if (__emad_in_debug_dump) {
        SX_LOG_ERR("already in debug-dump context\n");
        ret = SXD_STATUS_ERROR;
        goto out;
    }

    sxd_emad_timeout_get(&__pre_debug_dump_emad_timeout);
    ret = sxd_emad_timeout_set(timeout_usec);
    if (ret != SXD_STATUS_SUCCESS) {
        goto out;
    }

    __emad_in_debug_dump = TRUE;

out:
    cl_spinlock_release(&__emad_tid_list_lock);
    return ret;
}


sxd_status_t sxd_emad_debug_dump_stop(void)
{
    sxd_status_t ret = SXD_STATUS_SUCCESS;

    cl_spinlock_acquire(&__emad_tid_list_lock);
    if (!__emad_in_debug_dump) {
        SX_LOG_ERR("not in debug-dump context\n");
        ret = SXD_STATUS_ERROR;
        goto out;
    }

    __emad_dev_id_enable_all();

    ret = sxd_emad_timeout_set(__pre_debug_dump_emad_timeout);
    if (ret != SXD_STATUS_SUCCESS) {
        goto out;
    }

    __emad_in_debug_dump = FALSE;

out:
    cl_spinlock_release(&__emad_tid_list_lock);
    return ret;
}
