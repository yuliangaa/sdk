/*
 * Copyright (C) 2015-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_shspm.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_SHSPM


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_shspm_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_ralue(sxd_emad_ralue_data_t *ralue_data, sxd_emad_ralue_reg_t *ralue_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i;

    SX_LOG_ENTER();

    ralue_reg->protocol = (ralue_data->reg_data->protocol & 0x0f);
    ralue_reg->operation_activity = ((ralue_data->reg_data->operation & 0x07) << 4) |
                                    (ralue_data->reg_data->activity & 0x01);
    ralue_reg->virtual_router = cl_hton16(ralue_data->reg_data->router);
    ralue_reg->update_mask = ((ralue_data->reg_data->update_entry_type & 0x01) << 0) |
                             ((ralue_data->reg_data->update_bmp_len & 0x01) << 1) |
                             ((ralue_data->reg_data->update_action_fields & 0x01) << 2);
    ralue_reg->prefix_length = ralue_data->reg_data->prefix_len;
    if (ralue_data->reg_data->protocol == SXD_ROUTER_ROUTE_TYPE_IPV4) {
        ralue_reg->destination_ip[3] = cl_hton32(ralue_data->reg_data->destination_ip[0]);
    } else if (ralue_data->reg_data->protocol == SXD_ROUTER_ROUTE_TYPE_IPV6) {
        for (i = 0; i < 4; i++) {
            ralue_reg->destination_ip[i] = cl_hton32(ralue_data->reg_data->destination_ip[i]);
        }
    }
    ralue_reg->entry_type = (ralue_data->reg_data->entry_type & 0x03) << 6;
    ralue_reg->bmp_len = ralue_data->reg_data->bmp_len;
    ralue_reg->action_type = ralue_data->reg_data->action_type & 0x03;
    switch (ralue_data->reg_data->action_type) {
    case SXD_RALUE_ACTION_TYPE_REMOTE:
        ralue_reg->action.remote.trap_action = (ralue_data->reg_data->action.remote.trap_action & 0x0f) << 4;
        ralue_reg->action.remote.trap_id = cl_hton16(ralue_data->reg_data->action.remote.trap_id & 0x1ff);
        ralue_reg->action.remote.adjacency_index = cl_hton32(
            ralue_data->reg_data->action.remote.adjacency_index & 0xffffff);
        ralue_reg->action.remote.ecmp_size = cl_hton16(ralue_data->reg_data->action.remote.ecmp_size & 0x1fff);
        break;

    case SXD_RALUE_ACTION_TYPE_LOCAL:
        ralue_reg->action.local.trap_action = (ralue_data->reg_data->action.local.trap_action & 0x0f) << 4;
        ralue_reg->action.local.trap_id = cl_hton16(ralue_data->reg_data->action.local.trap_id & 0x1ff);
        ralue_reg->action.local.local_egress_rif = cl_hton16(ralue_data->reg_data->action.local.egress_rif);
        break;

    case SXD_RALUE_ACTION_TYPE_IP2ME:
        ralue_reg->action.ip2me.valid_tunnel_ptr = cl_hton32(((ralue_data->reg_data->action.ip2me.valid & 0x01) << 31) |
                                                             (ralue_data->reg_data->action.ip2me.tunnel_ptr &
                                                              0xffffff));
        break;

    case SXD_RALUE_ACTION_TYPE_AR:
        ralue_reg->action.ar.trap_action = (ralue_data->reg_data->action.ar.trap_action & 0x0f) << 4;
        ralue_reg->action.ar.trap_id = cl_hton16(ralue_data->reg_data->action.ar.trap_id & 0x1ff);
        ralue_reg->action.ar.ar_lookup_prof_id = (ralue_data->reg_data->action.ar.ar_lookup_prof_id & 0x0f);
        ralue_reg->action.ar.arft_ptr = cl_hton32(ralue_data->reg_data->action.ar.arft_ptr & 0xfffff);
        ralue_reg->action.ar.ecmp_size = cl_hton16(ralue_data->reg_data->action.ar.ecmp_size & 0x1fff);
        ralue_reg->action.ar.arlpgt_ptr = cl_hton16(ralue_data->reg_data->action.ar.arlpgt_ptr);
        break;
    }
    ralue_reg->counter_set = cl_hton32(((ralue_data->reg_data->counter_set.type & 0xff) << 24) |
                                       (ralue_data->reg_data->counter_set.index & 0xffffff));
    ralue_reg->arn_gen_ptr = cl_hton32(((ralue_data->reg_data->arn_ptr_v & 0x1) << 31) |
                                       (ralue_data->reg_data->arn_gen_ptr & 0xffffff));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ralue(sxd_emad_ralue_data_t *ralue_data, sxd_emad_ralue_reg_t *ralue_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ralue_data->reg_data->activity = ralue_reg->operation_activity & 0x01;
    ralue_data->reg_data->entry_type = (ralue_reg->entry_type >> 6) & 0x03;
    ralue_data->reg_data->bmp_len = ralue_reg->bmp_len;
    ralue_data->reg_data->action_type = ralue_reg->action_type & 0x03;
    switch (ralue_data->reg_data->action_type) {
    case SXD_RALUE_ACTION_TYPE_REMOTE:
        ralue_data->reg_data->action.remote.trap_action = (ralue_reg->action.remote.trap_action >> 4) & 0x0f;
        ralue_data->reg_data->action.remote.trap_id = cl_ntoh16(ralue_reg->action.remote.trap_id & 0x1ff);
        ralue_data->reg_data->action.remote.adjacency_index = cl_ntoh32(ralue_reg->action.remote.adjacency_index) &
                                                              0xffffff;
        ralue_data->reg_data->action.remote.ecmp_size = cl_ntoh16(ralue_reg->action.remote.ecmp_size) & 0x1fff;
        break;

    case SXD_RALUE_ACTION_TYPE_LOCAL:
        ralue_data->reg_data->action.local.trap_action = (ralue_reg->action.local.trap_action >> 4) & 0x0f;
        ralue_data->reg_data->action.local.trap_id = cl_ntoh16(ralue_reg->action.local.trap_id & 0x1ff);
        ralue_data->reg_data->action.local.egress_rif = cl_ntoh16(ralue_reg->action.local.local_egress_rif);
        break;

    case SXD_RALUE_ACTION_TYPE_IP2ME:
        ralue_data->reg_data->action.ip2me.valid = (cl_ntoh32(ralue_reg->action.ip2me.valid_tunnel_ptr) >> 31) & 0x01;
        ralue_data->reg_data->action.ip2me.tunnel_ptr = cl_ntoh32(ralue_reg->action.ip2me.valid_tunnel_ptr) & 0xffffff;
        break;

    case SXD_RALUE_ACTION_TYPE_AR:
        ralue_data->reg_data->action.ar.trap_action = (ralue_reg->action.ar.trap_action >> 4) & 0x0f;
        ralue_data->reg_data->action.ar.trap_id = cl_ntoh16(ralue_reg->action.ar.trap_id & 0x1ff);
        ralue_data->reg_data->action.ar.ar_lookup_prof_id = (ralue_reg->action.ar.ar_lookup_prof_id & 0x0f);
        ralue_data->reg_data->action.ar.arft_ptr = cl_ntoh32(ralue_reg->action.ar.arft_ptr) & 0xfffff;
        ralue_data->reg_data->action.ar.ecmp_size = cl_ntoh16(ralue_reg->action.ar.ecmp_size) & 0x1fff;
        ralue_data->reg_data->action.ar.arlpgt_ptr = cl_ntoh16(ralue_reg->action.ar.arlpgt_ptr);
        break;
    }
    ralue_data->reg_data->counter_set.type = (cl_ntoh32(ralue_reg->counter_set) >> 24) & 0xff;
    ralue_data->reg_data->counter_set.index = cl_ntoh32(ralue_reg->counter_set) & 0xffffff;
    ralue_data->reg_data->arn_ptr_v = cl_ntoh32(ralue_reg->arn_gen_ptr) >> 31;
    ralue_data->reg_data->arn_gen_ptr = cl_ntoh32(ralue_reg->arn_gen_ptr) & 0xffffff;
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ralbu(sxd_emad_ralbu_data_t *ralbu_data, sxd_emad_ralbu_reg_t *ralbu_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i;

    SX_LOG_ENTER();

    ralbu_reg->protocol = ralbu_data->reg_data->protocol & 0x0f;
    ralbu_reg->virtual_router = cl_hton16(ralbu_data->reg_data->router);
    ralbu_reg->old_bmp_len = ralbu_data->reg_data->old_bmp;
    ralbu_reg->bin = ralbu_data->reg_data->bin;
    ralbu_reg->new_bmp_len = ralbu_data->reg_data->new_bmp;
    ralbu_reg->prefix_len = ralbu_data->reg_data->prefix_len;
    if (ralbu_data->reg_data->protocol == SXD_ROUTER_ROUTE_TYPE_IPV4) {
        ralbu_reg->destination_ip[3] = cl_hton32(ralbu_data->reg_data->destination_ip[0]);
    } else if (ralbu_data->reg_data->protocol == SXD_ROUTER_ROUTE_TYPE_IPV6) {
        for (i = 0; i < 4; i++) {
            ralbu_reg->destination_ip[i] = cl_hton32(ralbu_data->reg_data->destination_ip[i]);
        }
    }
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ralbu(sxd_emad_ralbu_data_t *ralbu_data, sxd_emad_ralbu_reg_t *ralbu_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    UNUSED_PARAM(ralbu_data);
    UNUSED_PARAM(ralbu_reg);

    SX_LOG_ENTER();

    SX_LOG_EXIT();
    return err;
}
