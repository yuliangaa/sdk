/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_span.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_SPAN

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_span_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_mpar(sxd_emad_mpar_data_t *mpar_data, sxd_emad_mpar_reg_t *mpar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((NULL == mpar_data) || (NULL == mpar_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    mpar_reg->mngr_type = mpar_data->reg_data->mngr_type;
    mpar_reg->local_port = mpar_data->reg_data->local_port;
    mpar_reg->i_e_lp_msb = mpar_data->reg_data->i_e & 0xF;
    mpar_reg->i_e_lp_msb |= (mpar_data->reg_data->lp_msb & 0x03) << 4;
    mpar_reg->enable = mpar_data->reg_data->enable ? (1 << 7) : 0;
    mpar_reg->pa_id = mpar_data->reg_data->pa_id;
    mpar_reg->probability_rate = cl_hton32(mpar_data->reg_data->probability_rate);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mpar(sxd_emad_mpar_data_t *mpar_data, sxd_emad_mpar_reg_t *mpar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((NULL == mpar_data) || (NULL == mpar_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    mpar_data->reg_data->mngr_type = mpar_reg->mngr_type;
    mpar_data->reg_data->local_port = mpar_reg->local_port;
    mpar_data->reg_data->i_e = mpar_reg->i_e_lp_msb & 0x0F;
    mpar_data->reg_data->lp_msb = (mpar_reg->i_e_lp_msb >> 4) & 0x03;
    mpar_data->reg_data->enable = mpar_reg->enable ? 1 : 0;
    mpar_data->reg_data->pa_id = mpar_reg->pa_id;
    mpar_data->reg_data->probability_rate = cl_ntoh32(mpar_reg->probability_rate);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sbib(sxd_emad_sbib_data_t *sbib_data, sxd_emad_sbib_reg_t *sbib_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((NULL == sbib_data) || (NULL == sbib_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    sbib_reg->type = ((sbib_data->reg_data->type & 0x0F) << 4);
    sbib_reg->local_port = sbib_data->reg_data->local_port;
    sbib_reg->lp_msb = (sbib_data->reg_data->lp_msb & 0x3) << 4;
    sbib_reg->int_buff_index = sbib_data->reg_data->int_buff_index;
    sbib_reg->status = ((sbib_data->reg_data->status & 0x0F) << 4);
    sbib_reg->buff_size = cl_hton32(sbib_data->reg_data->buff_size);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbib(sxd_emad_sbib_data_t *sbib_data, sxd_emad_sbib_reg_t *sbib_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((NULL == sbib_data) || (NULL == sbib_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    sbib_data->reg_data->type = (sbib_reg->type >> 4) & 0x0F;
    sbib_data->reg_data->local_port = sbib_reg->local_port;
    sbib_data->reg_data->lp_msb = ((sbib_reg->lp_msb >> 4) & 0x3);
    sbib_data->reg_data->int_buff_index = sbib_reg->int_buff_index;
    sbib_data->reg_data->status = (sbib_reg->status >> 4) & 0x0F;
    sbib_data->reg_data->buff_size = cl_ntoh32(sbib_reg->buff_size) & 0x00FFFFFF;

    SX_LOG_EXIT();
    return err;
}
