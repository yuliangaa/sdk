/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
/*#include <sx/sxd/sxd_registers.h>*/
/*#include "../common/sxd_registers.h"*/
#include <sx/sxd/sxd_emad_port.h>
#include <sx/sxd/sxd_emad_port_data.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_PORT

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_port_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_spmcr_set(sxd_emad_spmcr_data_t        *spmcr_data_arr,
                                uint32_t                      spmcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((spmcr_data_arr == NULL) || (spmcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)spmcr_data_arr, spmcr_data_num,
                          SXD_REG_ID_SPMCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_spmcr_get(sxd_emad_spmcr_data_t        *spmcr_data_arr,
                                uint32_t                      spmcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((spmcr_data_arr == NULL) || (spmcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)spmcr_data_arr, spmcr_data_num,
                          SXD_REG_ID_SPMCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pcap_get(sxd_emad_pcap_data_t         *pcap_data_arr,
                               uint32_t                      pcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pcap_data_arr == NULL) || (pcap_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pcap_data_arr, pcap_data_num,
                          SXD_REG_ID_PCAP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmlp_set(sxd_emad_pmlp_data_t         *pmlp_data_arr,
                               uint32_t                      pmlp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmlp_data_arr == NULL) || (pmlp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmlp_data_arr, pmlp_data_num,
                          SXD_REG_ID_PMLP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmlp_get(sxd_emad_pmlp_data_t         *pmlp_data_arr,
                               uint32_t                      pmlp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmlp_data_arr == NULL) || (pmlp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmlp_data_arr, pmlp_data_num,
                          SXD_REG_ID_PMLP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbcm_set(sxd_emad_sbcm_data_t         *sbcm_data_arr,
                               uint32_t                      sbcm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbcm_data_arr == NULL) || (sbcm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbcm_data_arr, sbcm_data_num,
                          SXD_REG_ID_SBCM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbcm_get(sxd_emad_sbcm_data_t         *sbcm_data_arr,
                               uint32_t                      sbcm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbcm_data_arr == NULL) || (sbcm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbcm_data_arr, sbcm_data_num,
                          SXD_REG_ID_SBCM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbpm_set(sxd_emad_sbpm_data_t         *sbpm_data_arr,
                               uint32_t                      sbpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbpm_data_arr == NULL) || (sbpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbpm_data_arr, sbpm_data_num,
                          SXD_REG_ID_SBPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbpm_get(sxd_emad_sbpm_data_t         *sbpm_data_arr,
                               uint32_t                      sbpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbpm_data_arr == NULL) || (sbpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbpm_data_arr, sbpm_data_num,
                          SXD_REG_ID_SBPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmpr_set(sxd_emad_pmpr_data_t         *pmpr_data_arr,
                               uint32_t                      pmpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmpr_data_arr == NULL) || (pmpr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmpr_data_arr, pmpr_data_num,
                          SXD_REG_ID_PMPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmpr_get(sxd_emad_pmpr_data_t         *pmpr_data_arr,
                               uint32_t                      pmpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmpr_data_arr == NULL) || (pmpr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmpr_data_arr, pmpr_data_num,
                          SXD_REG_ID_PMPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pplm_set(sxd_emad_pplm_data_t         *pplm_data_arr,
                               uint32_t                      pplm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pplm_data_arr == NULL) || (pplm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pplm_data_arr, pplm_data_num,
                          SXD_REG_ID_PPLM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pplm_get(sxd_emad_pplm_data_t         *pplm_data_arr,
                               uint32_t                      pplm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pplm_data_arr == NULL) || (pplm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pplm_data_arr, pplm_data_num,
                          SXD_REG_ID_PPLM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_plpc_set(sxd_emad_plpc_data_t         *plpc_data_arr,
                               uint32_t                      plpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((plpc_data_arr == NULL) || (plpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)plpc_data_arr, plpc_data_num,
                          SXD_REG_ID_PLPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_plpc_get(sxd_emad_plpc_data_t         *plpc_data_arr,
                               uint32_t                      plpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((plpc_data_arr == NULL) || (plpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)plpc_data_arr, plpc_data_num,
                          SXD_REG_ID_PLPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pelc_set(sxd_emad_pelc_data_t         *pelc_data_arr,
                               uint32_t                      pelc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pelc_data_arr == NULL) || (pelc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pelc_data_arr, pelc_data_num,
                          SXD_REG_ID_PELC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pelc_get(sxd_emad_pelc_data_t         *pelc_data_arr,
                               uint32_t                      pelc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pelc_data_arr == NULL) || (pelc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pelc_data_arr, pelc_data_num,
                          SXD_REG_ID_PELC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfcc_set(sxd_emad_pfcc_data_t         *pfcc_data_arr,
                               uint32_t                      pfcc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfcc_data_arr == NULL) || (pfcc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfcc_data_arr, pfcc_data_num,
                          SXD_REG_ID_PFCC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfcc_get(sxd_emad_pfcc_data_t         *pfcc_data_arr,
                               uint32_t                      pfcc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfcc_data_arr == NULL) || (pfcc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfcc_data_arr, pfcc_data_num,
                          SXD_REG_ID_PFCC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_plib_set(sxd_emad_plib_data_t         *plib_data_arr,
                               uint32_t                      plib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((plib_data_arr == NULL) || (plib_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)plib_data_arr, plib_data_num,
                          SXD_REG_ID_PLIB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_plib_get(sxd_emad_plib_data_t         *plib_data_arr,
                               uint32_t                      plib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((plib_data_arr == NULL) || (plib_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)plib_data_arr, plib_data_num,
                          SXD_REG_ID_PLIB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pptb_set(sxd_emad_pptb_data_t         *pptb_data_arr,
                               uint32_t                      pptb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if ((pptb_data_arr == NULL) || (pptb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pptb_data_arr, pptb_data_num,
                          SXD_REG_ID_PPTB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pptb_get(sxd_emad_pptb_data_t         *pptb_data_arr,
                               uint32_t                      pptb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if ((pptb_data_arr == NULL) || (pptb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pptb_data_arr, pptb_data_num,
                          SXD_REG_ID_PPTB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pbmc_set(sxd_emad_pbmc_data_t         *pbmc_data_arr,
                               uint32_t                      pbmc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pbmc_data_arr == NULL) || (pbmc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pbmc_data_arr, pbmc_data_num,
                          SXD_REG_ID_PBMC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pbmc_get(sxd_emad_pbmc_data_t         *pbmc_data_arr,
                               uint32_t                      pbmc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pbmc_data_arr == NULL) || (pbmc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pbmc_data_arr, pbmc_data_num,
                          SXD_REG_ID_PBMC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbpr_set(sxd_emad_sbpr_data_t         *sbpr_data_arr,
                               uint32_t                      sbpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbpr_data_arr == NULL) || (sbpr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbpr_data_arr, sbpr_data_num,
                          SXD_REG_ID_SBPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbpr_get(sxd_emad_sbpr_data_t         *sbpr_data_arr,
                               uint32_t                      sbpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbpr_data_arr == NULL) || (sbpr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbpr_data_arr, sbpr_data_num,
                          SXD_REG_ID_SBPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pspa_set(sxd_emad_pspa_data_t         *pspa_data_arr,
                               uint32_t                      pspa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pspa_data_arr == NULL) || (pspa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pspa_data_arr, pspa_data_num,
                          SXD_REG_ID_PSPA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pspa_get(sxd_emad_pspa_data_t         *pspa_data_arr,
                               uint32_t                      pspa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pspa_data_arr == NULL) || (pspa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pspa_data_arr, pspa_data_num,
                          SXD_REG_ID_PSPA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpbr_set(sxd_emad_qpbr_data_t         *qpbr_data_arr,
                               uint32_t                      qpbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpbr_data_arr == NULL) || (qpbr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpbr_data_arr, qpbr_data_num,
                          SXD_REG_ID_QPBR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpbr_get(sxd_emad_qpbr_data_t         *qpbr_data_arr,
                               uint32_t                      qpbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpbr_data_arr == NULL) || (qpbr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpbr_data_arr, qpbr_data_num,
                          SXD_REG_ID_QPBR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_plbf_access(sxd_emad_plbf_data_t         *plbf_data_arr,
                                  uint32_t                      plbf_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((plbf_data_arr == NULL) || (plbf_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)plbf_data_arr, plbf_data_num,
                          SXD_REG_ID_PLBF_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pifr_set(sxd_emad_pifr_data_t         *pifr_data_arr,
                               uint32_t                      pifr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pifr_data_arr == NULL) || (pifr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pifr_data_arr, pifr_data_num,
                          SXD_REG_ID_PIFR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pifr_get(sxd_emad_pifr_data_t         *pifr_data_arr,
                               uint32_t                      pifr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pifr_data_arr == NULL) || (pifr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pifr_data_arr, pifr_data_num,
                          SXD_REG_ID_PIFR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmpc_set(sxd_emad_pmpc_data_t         *pmpc_data_arr,
                               uint32_t                      pmpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmpc_data_arr == NULL) || (pmpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmpc_data_arr, pmpc_data_num,
                          SXD_REG_ID_PMPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmpc_get(sxd_emad_pmpc_data_t         *pmpc_data_arr,
                               uint32_t                      pmpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmpc_data_arr == NULL) || (pmpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmpc_data_arr, pmpc_data_num,
                          SXD_REG_ID_PMPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mpsc_set(sxd_emad_mpsc_data_t         *mpsc_data_arr,
                               uint32_t                      mpsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpsc_data_arr == NULL) || (mpsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpsc_data_arr, mpsc_data_num,
                          SXD_REG_ID_MPSC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mpsc_get(sxd_emad_mpsc_data_t         *mpsc_data_arr,
                               uint32_t                      mpsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpsc_data_arr == NULL) || (mpsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpsc_data_arr, mpsc_data_num,
                          SXD_REG_ID_MPSC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mlcr_set(sxd_emad_mlcr_data_t         *mlcr_data_arr,
                               uint32_t                      mlcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mlcr_data_arr == NULL) || (mlcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mlcr_data_arr, mlcr_data_num,
                          SXD_REG_ID_MLCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mlcr_get(sxd_emad_mlcr_data_t         *mlcr_data_arr,
                               uint32_t                      mlcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mlcr_data_arr == NULL) || (mlcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mlcr_data_arr, mlcr_data_num,
                          SXD_REG_ID_MLCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfsc_set(sxd_emad_pfsc_data_t         *pfsc_data_arr,
                               uint32_t                      pfsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfsc_data_arr == NULL) || (pfsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfsc_data_arr, pfsc_data_num,
                          SXD_REG_ID_PFSC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfsc_get(sxd_emad_pfsc_data_t         *pfsc_data_arr,
                               uint32_t                      pfsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfsc_data_arr == NULL) || (pfsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfsc_data_arr, pfsc_data_num,
                          SXD_REG_ID_PFSC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmmp_set(sxd_emad_pmmp_data_t         *pmmp_data_arr,
                               uint32_t                      pmmp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmmp_data_arr == NULL) || (pmmp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmmp_data_arr, pmmp_data_num,
                          SXD_REG_ID_PMMP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmmp_get(sxd_emad_pmmp_data_t         *pmmp_data_arr,
                               uint32_t                      pmmp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmmp_data_arr == NULL) || (pmmp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmmp_data_arr, pmmp_data_num,
                          SXD_REG_ID_PMMP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mdri_set(sxd_emad_mdri_data_t         *mdri_data_arr,
                               uint32_t                      mdri_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mdri_data_arr == NULL) || (mdri_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mdri_data_arr, mdri_data_num,
                          SXD_REG_ID_MDRI_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mdri_get(sxd_emad_mdri_data_t         *mdri_data_arr,
                               uint32_t                      mdri_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mdri_data_arr == NULL) || (mdri_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mdri_data_arr, mdri_data_num,
                          SXD_REG_ID_MDRI_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pmaos_set(sxd_emad_pmaos_data_t        *pmaos_data_arr,
                                uint32_t                      pmaos_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmaos_data_arr == NULL) || (pmaos_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmaos_data_arr, pmaos_data_num,
                          SXD_REG_ID_PMAOS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pmaos_get(sxd_emad_pmaos_data_t        *pmaos_data_arr,
                                uint32_t                      pmaos_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pmaos_data_arr == NULL) || (pmaos_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pmaos_data_arr, pmaos_data_num,
                          SXD_REG_ID_PMAOS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
