/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_router.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_ROUTER

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_router_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_rcap_get(sxd_emad_rcap_data_t         *rcap_data_arr,
                               uint32_t                      rcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rcap_data_arr == NULL) || (rcap_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rcap_data_arr, rcap_data_num,
                          SXD_REG_ID_RCAP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_rgcr_set(sxd_emad_rgcr_data_t         *rgcr_data_arr,
                               uint32_t                      rgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rgcr_data_arr == NULL) || (rgcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rgcr_data_arr, rgcr_data_num,
                          SXD_REG_ID_RGCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rgcr_get(sxd_emad_rgcr_data_t         *rgcr_data_arr,
                               uint32_t                      rgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rgcr_data_arr == NULL) || (rgcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rgcr_data_arr, rgcr_data_num,
                          SXD_REG_ID_RGCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ritr_set(sxd_emad_ritr_data_t         *ritr_data_arr,
                               uint32_t                      ritr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ritr_data_arr == NULL) || (ritr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ritr_data_arr, ritr_data_num,
                          SXD_REG_ID_RITR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ritr_get(sxd_emad_ritr_data_t         *ritr_data_arr,
                               uint32_t                      ritr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ritr_data_arr == NULL) || (ritr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ritr_data_arr, ritr_data_num,
                          SXD_REG_ID_RITR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rigr_set(sxd_emad_rigr_data_t         *rigr_data_arr,
                               uint32_t                      rigr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rigr_data_arr == NULL) || (rigr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rigr_data_arr, rigr_data_num,
                          SXD_REG_ID_RIGR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rigr_get(sxd_emad_rigr_data_t         *rigr_data_arr,
                               uint32_t                      rigr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rigr_data_arr == NULL) || (rigr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rigr_data_arr, rigr_data_num,
                          SXD_REG_ID_RIGR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtar_set(sxd_emad_rtar_data_t         *rtar_data_arr,
                               uint32_t                      rtar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtar_data_arr == NULL) || (rtar_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtar_data_arr, rtar_data_num,
                          SXD_REG_ID_RTAR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtar_get(sxd_emad_rtar_data_t         *rtar_data_arr,
                               uint32_t                      rtar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtar_data_arr == NULL) || (rtar_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtar_data_arr, rtar_data_num,
                          SXD_REG_ID_RTAR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_recr_set(sxd_emad_recr_data_t         *recr_data_arr,
                               uint32_t                      recr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((recr_data_arr == NULL) || (recr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)recr_data_arr, recr_data_num,
                          SXD_REG_ID_RECR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_recr_get(sxd_emad_recr_data_t         *recr_data_arr,
                               uint32_t                      recr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((recr_data_arr == NULL) || (recr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)recr_data_arr, recr_data_num,
                          SXD_REG_ID_RECR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_recr_v2_set(sxd_emad_recr_v2_data_t      *recr_v2_data_arr,
                                  uint32_t                      recr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((recr_v2_data_arr == NULL) || (recr_v2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)recr_v2_data_arr, recr_v2_data_num,
                          SXD_REG_ID_RECRV2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_recr_v2_get(sxd_emad_recr_v2_data_t      *recr_v2_data_arr,
                                  uint32_t                      recr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((recr_v2_data_arr == NULL) || (recr_v2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)recr_v2_data_arr, recr_v2_data_num,
                          SXD_REG_ID_RECRV2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ruft_set(sxd_emad_ruft_data_t         *ruft_data_arr,
                               uint32_t                      ruft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ruft_data_arr == NULL) || (ruft_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ruft_data_arr, ruft_data_num,
                          SXD_REG_ID_RUFT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ruft_get(sxd_emad_ruft_data_t         *ruft_data_arr,
                               uint32_t                      ruft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ruft_data_arr == NULL) || (ruft_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ruft_data_arr, ruft_data_num,
                          SXD_REG_ID_RUFT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ruht_set(sxd_emad_ruht_data_t         *ruht_data_arr,
                               uint32_t                      ruht_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ruht_data_arr == NULL) || (ruht_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ruht_data_arr, ruht_data_num,
                          SXD_REG_ID_RUHT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ruht_get(sxd_emad_ruht_data_t         *ruht_data_arr,
                               uint32_t                      ruht_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ruht_data_arr == NULL) || (ruht_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ruht_data_arr, ruht_data_num,
                          SXD_REG_ID_RUHT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_rauht_set(sxd_emad_rauht_data_t        *rauht_data_arr,
                                uint32_t                      rauht_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rauht_data_arr == NULL) || (rauht_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rauht_data_arr, rauht_data_num,
                          SXD_REG_ID_RAUHT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rauht_get(sxd_emad_rauht_data_t        *rauht_data_arr,
                                uint32_t                      rauht_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rauht_data_arr == NULL) || (rauht_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rauht_data_arr, rauht_data_num,
                          SXD_REG_ID_RAUHT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rauhtd_set(sxd_emad_rauhtd_data_t       *rauhtd_data_arr,
                                 uint32_t                      rauhtd_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rauhtd_data_arr == NULL) || (rauhtd_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rauhtd_data_arr, rauhtd_data_num,
                          SXD_REG_ID_RAUHTD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rauhtd_get(sxd_emad_rauhtd_data_t       *rauhtd_data_arr,
                                 uint32_t                      rauhtd_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rauhtd_data_arr == NULL) || (rauhtd_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rauhtd_data_arr, rauhtd_data_num,
                          SXD_REG_ID_RAUHTD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmft_set(sxd_emad_rmft_data_t         *rmft_data_arr,
                               uint32_t                      rmft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmft_data_arr == NULL) || (rmft_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmft_data_arr, rmft_data_num,
                          SXD_REG_ID_RMFT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmft_get(sxd_emad_rmft_data_t         *rmft_data_arr,
                               uint32_t                      rmft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmft_data_arr == NULL) || (rmft_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmft_data_arr, rmft_data_num,
                          SXD_REG_ID_RMFT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmft_v2_set(sxd_emad_rmft_v2_data_t      *rmft_v2_data_arr,
                                  uint32_t                      rmft_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmft_v2_data_arr == NULL) || (rmft_v2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmft_v2_data_arr, rmft_v2_data_num,
                          SXD_REG_ID_RMFTV2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmft_v2_get(sxd_emad_rmft_v2_data_t      *rmft_v2_data_arr,
                                  uint32_t                      rmft_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmft_v2_data_arr == NULL) || (rmft_v2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmft_v2_data_arr, rmft_v2_data_num,
                          SXD_REG_ID_RMFTV2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmftad_set(sxd_emad_rmftad_data_t       *rmftad_data_arr,
                                 uint32_t                      rmftad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmftad_data_arr == NULL) || (rmftad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmftad_data_arr, rmftad_data_num,
                          SXD_REG_ID_RMFTAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmftad_get(sxd_emad_rmftad_data_t       *rmftad_data_arr,
                                 uint32_t                      rmftad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmftad_data_arr == NULL) || (rmftad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmftad_data_arr, rmftad_data_num,
                          SXD_REG_ID_RMFTAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptcead_set(sxd_emad_ptcead_data_t       *ptcead_data_arr,
                                 uint32_t                      ptcead_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptcead_data_arr == NULL) || (ptcead_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptcead_data_arr, ptcead_data_num,
                          SXD_REG_ID_PTCEAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptcead_get(sxd_emad_ptcead_data_t       *ptcead_data_arr,
                                 uint32_t                      ptcead_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptcead_data_arr == NULL) || (ptcead_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptcead_data_arr, ptcead_data_num,
                          SXD_REG_ID_PTCEAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ratr_set(sxd_emad_ratr_data_t         *ratr_data_arr,
                               uint32_t                      ratr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ratr_data_arr == NULL) || (ratr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ratr_data_arr, ratr_data_num,
                          SXD_REG_ID_RATR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ratr_get(sxd_emad_ratr_data_t         *ratr_data_arr,
                               uint32_t                      ratr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ratr_data_arr == NULL) || (ratr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ratr_data_arr, ratr_data_num,
                          SXD_REG_ID_RATR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ratrad_set(sxd_emad_ratrad_data_t       *ratrad_data_arr,
                                 uint32_t                      ratrad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ratrad_data_arr == NULL) || (ratrad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ratrad_data_arr, ratrad_data_num,
                          SXD_REG_ID_RATRAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ratrad_get(sxd_emad_ratrad_data_t       *ratrad_data_arr,
                                 uint32_t                      ratrad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ratrad_data_arr == NULL) || (ratrad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ratrad_data_arr, ratrad_data_num,
                          SXD_REG_ID_RATRAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rdpm_set(sxd_emad_rdpm_data_t         *rdpm_data_arr,
                               uint32_t                      rdpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rdpm_data_arr == NULL) || (rdpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rdpm_data_arr, rdpm_data_num,
                          SXD_REG_ID_RDPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rdpm_get(sxd_emad_rdpm_data_t         *rdpm_data_arr,
                               uint32_t                      rdpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rdpm_data_arr == NULL) || (rdpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rdpm_data_arr, rdpm_data_num,
                          SXD_REG_ID_RDPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rrcr_set(sxd_emad_rrcr_data_t         *rrcr_data_arr,
                               uint32_t                      rrcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rrcr_data_arr == NULL) || (rrcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rrcr_data_arr, rrcr_data_num,
                          SXD_REG_ID_RRCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rrcr_get(sxd_emad_rrcr_data_t         *rrcr_data_arr,
                               uint32_t                      rrcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rrcr_data_arr == NULL) || (rrcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rrcr_data_arr, rrcr_data_num,
                          SXD_REG_ID_RRCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rica_set(sxd_emad_rica_data_t         *rica_data_arr,
                               uint32_t                      rica_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rica_data_arr == NULL) || (rica_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rica_data_arr, rica_data_num,
                          SXD_REG_ID_RICA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rica_get(sxd_emad_rica_data_t         *rica_data_arr,
                               uint32_t                      rica_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rica_data_arr == NULL) || (rica_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rica_data_arr, rica_data_num,
                          SXD_REG_ID_RICA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ricnt_get(sxd_emad_ricnt_data_t        *ricnt_data_arr,
                                uint32_t                      ricnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ricnt_data_arr == NULL) || (ricnt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ricnt_data_arr, ricnt_data_num,
                          SXD_REG_ID_RICNT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ricnt_set(sxd_emad_ricnt_data_t        *ricnt_data_arr,
                                uint32_t                      ricnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ricnt_data_arr == NULL) || (ricnt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ricnt_data_arr, ricnt_data_num,
                          SXD_REG_ID_RICNT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtca_get(sxd_emad_rtca_data_t         *rtca_data_arr,
                               uint32_t                      rtca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtca_data_arr == NULL) || (rtca_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtca_data_arr, rtca_data_num,
                          SXD_REG_ID_RTCA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtca_set(sxd_emad_rtca_data_t         *rtca_data_arr,
                               uint32_t                      rtca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtca_data_arr == NULL) || (rtca_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtca_data_arr, rtca_data_num,
                          SXD_REG_ID_RTCA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtps_get(sxd_emad_rtps_data_t         *rtps_data_arr,
                               uint32_t                      rtps_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtps_data_arr == NULL) || (rtps_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtps_data_arr, rtps_data_num,
                          SXD_REG_ID_RTPS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rtps_set(sxd_emad_rtps_data_t         *rtps_data_arr,
                               uint32_t                      rtps_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rtps_data_arr == NULL) || (rtps_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rtps_data_arr, rtps_data_num,
                          SXD_REG_ID_RTPS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmeir_get(sxd_emad_rmeir_data_t        *rmeir_data_arr,
                                uint32_t                      rmeir_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmeir_data_arr == NULL) || (rmeir_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmeir_data_arr, rmeir_data_num,
                          SXD_REG_ID_RMEIR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmeir_set(sxd_emad_rmeir_data_t        *rmeir_data_arr,
                                uint32_t                      rmeir_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmeir_data_arr == NULL) || (rmeir_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmeir_data_arr, rmeir_data_num,
                          SXD_REG_ID_RMEIR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmid_get(sxd_emad_rmid_data_t         *rmid_data_arr,
                               uint32_t                      rmid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmid_data_arr == NULL) || (rmid_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmid_data_arr, rmid_data_num,
                          SXD_REG_ID_RMID_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmid_set(sxd_emad_rmid_data_t         *rmid_data_arr,
                               uint32_t                      rmid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmid_data_arr == NULL) || (rmid_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmid_data_arr, rmid_data_num,
                          SXD_REG_ID_RMID_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmpu_get(sxd_emad_rmpu_data_t         *rmpu_data_arr,
                               uint32_t                      rmpu_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmpu_data_arr == NULL) || (rmpu_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmpu_data_arr, rmpu_data_num,
                          SXD_REG_ID_RMPU_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_rmpu_set(sxd_emad_rmpu_data_t         *rmpu_data_arr,
                               uint32_t                      rmpu_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((rmpu_data_arr == NULL) || (rmpu_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)rmpu_data_arr, rmpu_data_num,
                          SXD_REG_ID_RMPU_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
