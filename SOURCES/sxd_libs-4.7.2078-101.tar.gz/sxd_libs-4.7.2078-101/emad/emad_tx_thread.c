/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <unistd.h>

#include <complib/sx_log.h>
#include <complib/cl_event.h>
#include <complib/cl_thread.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_dbg.h>
#include <complib/cl_math.h>

#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_dpt.h>

#include "emad.h"
#include "emad_transaction.h"

#ifdef SNIFFER_PRESENT
#include "sniffer/sxd_sniffer.h"
#endif

#undef  __MODULE__
#define __MODULE__ EMAD_TX_THREAD

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/* Headers (not only TLVs) that we send in each EMAD frame:
 * 1) EMAD header (Ethernet header with EMAD ethertype) (mandatory)
 * 2) Operation TLV (mandatory)
 * 3) String TLV (optional)
 * 4) Latency TLV (optional)
 * 5) Register TLV - header (mandatory) - only Type/Length, not the register itself.
 * 6) Register layout (mandatory) - the register itself.
 * 7) End TLV (mandatory)
 *
 * So all in all, we have 5 TLVs and two extra headers (EMAD header & register layout).
 */
#define SXD_EMAD_MAX_TX_HEADERS (SXD_EMAD_MAX_TLV_HEADERS + 2)

#define EMAD_ETCLASS 6

static cl_thread_t   __thread_h;
static int           __thread_notif_fd = -1;
static boolean_t     __thread_is_alive = FALSE;
static cl_qlist_t    __emad_queue[2]; /* double-queue mechanism */
static cl_qlist_t   *__emad_queue_enqueue;
static cl_qlist_t   *__emad_queue_dequeue;
static cl_spinlock_t __emad_queue_lock;
static uint32_t      __queue_size = 0;

/*
 * EMAD transaction ID is a 64bit. For more details see comments in __emad_transaction_alloc_tid().
 * __emad_tid_base is 64bit value that holds only MSB-32bit and LSB-32bit are all 0.
 */
static uint64_t __emad_tid_base;

void emad_set_tid_base(uint32_t app_id)
{
    __emad_tid_base = ((uint64_t)app_id) << 32;
}

static void __init_emad_tx(sxd_emad_header_t    *emad_hdr,
                           sxd_emad_operation_t *operation_tlv,
                           sxd_emad_string_t    *string_tlv,
                           sxd_emad_latency_t   *latency_tlv,
                           sxd_emad_end_t       *end_tlv)
{
    /* these are static EMAD ethernet frame SMAC/DMAC as defined in PRM */
    const uint8_t dmac[] = { 0x01, 0x02, 0xc9, 0x00, 0x00, 0x01 };
    const uint8_t smac[] = { 0x00, 0x02, 0xc9, 0x01, 0x02, 0x03 };

    memset(emad_hdr, 0, sizeof(*emad_hdr));
    memset(operation_tlv, 0, sizeof(*operation_tlv));
    memset(string_tlv, 0, sizeof(*string_tlv));
    memset(latency_tlv, 0, sizeof(*latency_tlv));
    memset(end_tlv, 0, sizeof(*end_tlv));

    /* EMAD Header */
    memcpy(emad_hdr->dmac, dmac, sizeof(emad_hdr->dmac));
    memcpy(emad_hdr->smac, smac, sizeof(emad_hdr->smac));
    emad_hdr->et = cl_hton16(EMAD_HEADER_ET);
    emad_hdr->mlx_proto = 0;
    emad_hdr->ver = 0;

    /* Operation TLV */
    operation_tlv->type_len = EMAD_TLV_BUILD_TYPE_LEN(EMAD_TLV_TYPE_OPERATION_E, EMAD_TLV_LEN_OPERATION);
    operation_tlv->class = 0x01;

    string_tlv->type_len = EMAD_TLV_BUILD_TYPE_LEN(EMAD_TLV_TYPE_STRING_E, EMAD_TLV_LEN_STRING);
    latency_tlv->type_len = EMAD_TLV_BUILD_TYPE_LEN(EMAD_TLV_TYPE_LATENCY_E, EMAD_TLV_LEN_LATENCY);
    end_tlv->type_len = EMAD_TLV_BUILD_TYPE_LEN(EMAD_TLV_TYPE_END_E, EMAD_TLV_LEN_END);
}


static void __mgir_hook(sxd_dev_id_t                dev_id,
                        sxd_reg_id_e                reg_id,
                        uint8_t                     fw_status,
                        const void                 *reg_data,
                        const sxd_emad_operation_t *operation_tlv,
                        const sxd_emad_reg_t       *reg_tlv,
                        const sxd_emad_latency_t   *latency_tlv,
                        void                       *context)
{
    const struct ku_mgir_reg *mgir_reg = (struct ku_mgir_reg*)reg_data;
    boolean_t                 string_tlv_enabled;
    boolean_t                 latency_tlv_enabled;

    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(operation_tlv);
    UNUSED_PARAM(reg_tlv);
    UNUSED_PARAM(latency_tlv);
    UNUSED_PARAM(context);

    if (fw_status != 0) {
        SX_LOG_NTC("MGIR failed (dev-id %u) - turning off string and latency TLVs\n", dev_id);
        return;
    }

    string_tlv_enabled = (mgir_reg->fw_info.string_tlv == 1) ? TRUE : FALSE;

    /* In older FW versions the latency_tlv header may not be supported */
    latency_tlv_enabled = (mgir_reg->fw_info.latency_tlv == 1) ? TRUE : FALSE;

    if (sxd_dpt_set_string_tlv_cap(dev_id, string_tlv_enabled) == SXD_STATUS_SUCCESS) {
        SX_LOG_DBG("dev-id %u supports String-TLV: %s\n", dev_id, ((string_tlv_enabled) ? "true" : "false"));
    }

    if (sxd_dpt_set_latency_tlv_cap(dev_id, latency_tlv_enabled) == SXD_STATUS_SUCCESS) {
        SX_LOG_DBG("dev-id %u supports Latency-TLV: %s\n", dev_id, ((latency_tlv_enabled) ? "true" : "false"));
    }
}


static uint64_t __emad_transaction_alloc_tid(sxd_dev_id_t dev_id)
{
    /*
     * =======================================================================================
     * This function has no locks because it is called ONLY from the context of the TX thread!
     * =======================================================================================
     *
     *
     * __emad_tid_base is 64bit value that holds only MSB-32bit and LSB-32bit are all 0.
     *
     * EMAD Transaction ID (64bit):
     *       6         5         4         3         2         1
     *    3210987654321098765432109876543210987654321098765432109876543210
     *    |                               |       |
     *    |                               |       +--------- bits 00-23 (24bits) --> running counter
     *    |                               |                                          (no problem of wrap-around)
     *    |                               +----------------- bits 24-31 (8bits)  --> device-id
     *    +------------------------------------------------- bits 32-63 (32bits) --> application-id (__emad_tid_base)
     */

    static uint32_t emad_tid_lsb[EMAD_NUM_DEV_ID] = { 0 };

    ++emad_tid_lsb[dev_id];
    emad_tid_lsb[dev_id] &= 0xffffff;
    return EMAD_TID_SET_DEV_ID(__emad_tid_base | emad_tid_lsb[dev_id], dev_id);
}


static void __emad_tx_thread(void *context)
{
    struct ku_iovec                 emad_iov[SXD_EMAD_MAX_TX_HEADERS];
    struct ku_write                 ku_write;
    sxd_emad_header_t               emad_hdr;
    sxd_emad_operation_t            operation_tlv;
    sxd_emad_string_t               string_tlv;
    sxd_emad_latency_t              latency_tlv;
    sxd_emad_reg_t                  reg_tlv;
    sxd_emad_end_t                  end_tlv;
    uint16_t                        reg_tlv_size;
    cl_qlist_t                     *tmp = NULL;
    cl_list_item_t                 *list_item;
    struct emad_buffer             *emad_buffer;
    const emad_local_device_data_t *local_dev = NULL;
    cl_event_t                     *start_ev = (cl_event_t*)context;
    sxd_status_t                    err = SXD_STATUS_SUCCESS;
    boolean_t                       str_tlv_enabled, latency_tlv_enabled;
    int                             sxd_fd, hc_fd = -1, max_fd;
    fd_set                          read_fds;
    int                             rc;
    cl_status_t                     cl_st = CL_SUCCESS;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    FD_ZERO(&read_fds);
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);
    cl_event_signal(start_ev);

    err = emad_local_device_get(&local_dev);
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get emad local device (err=%s)\n", SXD_STATUS_MSG(err));
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        return;
    }

    rc = sxd_fd_get(local_dev->handle, &sxd_fd);
    if (rc) {
        SX_LOG_ERR("failed to get fd from sxd handle (rc=%d)\n", rc);
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        return;
    }

    memset(&reg_tlv, 0, sizeof(reg_tlv));
    __init_emad_tx(&emad_hdr,
                   &operation_tlv,
                   &string_tlv,
                   &latency_tlv,
                   &end_tlv);

    /* ISX header (ku_w->meta) */
    memset(&ku_write, 0, sizeof(ku_write));
    ku_write.meta.etclass = EMAD_ETCLASS;
    ku_write.meta.swid = 0xff;
    ku_write.meta.to_cpu = 0;
    ku_write.meta.rdq = 0x1f;
    ku_write.meta.system_port_mid = 0;
    ku_write.meta.lp = 1;
    ku_write.meta.type = SX_PKT_TYPE_EMAD_CTL;
    ku_write.iov = emad_iov;

    max_fd = __thread_notif_fd;

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
        max_fd = MAX(max_fd, hc_fd);
    }


    while (1) {
        FD_ZERO(&read_fds);
        cl_spinlock_acquire(&__emad_queue_lock);
        __queue_size = 0;
        cl_spinlock_release(&__emad_queue_lock);

        FD_SET(__thread_notif_fd, &read_fds);
        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
        }

        cl_fd_wait_on(max_fd, &read_fds, NULL, NULL, &rc);
        if (rc < 0) {
            SX_LOG_ERR("EMAD TX thread: select() failed [err=%d]\n", rc);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }

        if (!__thread_is_alive) {
            break;
        }
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        if (hc_fd >= 0) {
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        }

        if (FD_ISSET(__thread_notif_fd, &read_fds)) {
            cl_st = cl_fd_read(__thread_notif_fd);
            if (cl_st != CL_SUCCESS) {
                SX_LOG_ERR("EMAD tx thread: error in reading from notification pipe [err=%d]\n", cl_st);
            }

            if (!__thread_is_alive) {
                break;
            }
        }


        /* exchange queues */
        cl_spinlock_acquire(&__emad_queue_lock);
        __queue_size = cl_qlist_count(__emad_queue_enqueue);
        tmp = __emad_queue_enqueue;
        __emad_queue_enqueue = __emad_queue_dequeue;
        __emad_queue_dequeue = tmp;
        cl_spinlock_release(&__emad_queue_lock);

        while (!cl_is_qlist_empty(__emad_queue_dequeue)) {
            list_item = cl_qlist_remove_head(__emad_queue_dequeue);
            emad_buffer = PARENT_STRUCT(list_item, struct emad_buffer, list_item);

            emad_buffer->emad_tid = __emad_transaction_alloc_tid(EMAD_BUFFER_DEV_ID(emad_buffer));

            /*
             * ELEMENTS THAT NEED TO BE CHANGED IN EACH EMAD TRANSACTION:
             *     ku_write: meta.dev_id
             *     ku_write.vec_entries (depends on optional headers)
             *     ku_write.iov (depends on optional headers)
             *
             *     operation_tlv: register_id, method, tid
             *     string_tlv:    nothing
             *     latency_tlv:   nothing
             *     reg_tlv:       TLV len (size of register in dwords)
             *     end_tlv:       nothing
             */

            if (sxd_dpt_get_string_tlv_cap(EMAD_BUFFER_DEV_ID(emad_buffer), &str_tlv_enabled) != SXD_STATUS_SUCCESS) {
                str_tlv_enabled = FALSE;
            }

            if (sxd_dpt_get_latency_tlv_cap(EMAD_BUFFER_DEV_ID(emad_buffer),
                                            &latency_tlv_enabled) != SXD_STATUS_SUCCESS) {
                latency_tlv_enabled = FALSE;
            }

            ku_write.vec_entries = 0;

#define INIT_EMAD_IOV(len, base)                                                   \
    do {                                                                           \
        if (ku_write.vec_entries >= sizeof(emad_iov) / sizeof(emad_iov[0])) {      \
            SX_LOG_ERR("Too many EMAD headers (idx=%u)!\n", ku_write.vec_entries); \
            break;                                                                 \
        }                                                                          \
        emad_iov[ku_write.vec_entries].iov_len = (len);                            \
        emad_iov[ku_write.vec_entries].iov_base = (base);                          \
        ku_write.vec_entries++;                                                    \
    }                                                                              \
    while (0)

            INIT_EMAD_IOV(sizeof(emad_hdr), &emad_hdr);
            INIT_EMAD_IOV(sizeof(operation_tlv), &operation_tlv);

            if (str_tlv_enabled) {
                INIT_EMAD_IOV(sizeof(string_tlv), &string_tlv);
            }

            if (latency_tlv_enabled) {
                INIT_EMAD_IOV(sizeof(latency_tlv), &latency_tlv);
            }

            INIT_EMAD_IOV(sizeof(reg_tlv), &reg_tlv);
            INIT_EMAD_IOV(emad_buffer->reg_size, emad_buffer->prm_reg_buff);
            INIT_EMAD_IOV(sizeof(end_tlv), &end_tlv);

            ku_write.meta.dev_id = EMAD_BUFFER_DEV_ID(emad_buffer);
            operation_tlv.register_id = cl_hton16(emad_buffer->reg_id);
            operation_tlv.r_method = (EMAD_BUFFER_ACCESS_CMD(emad_buffer) == SXD_ACCESS_CMD_GET ||
                                      EMAD_BUFFER_ACCESS_CMD(emad_buffer) == SXD_ACCESS_CMD_GET_ALL) ?
                                     0x01 : 0x02;
            operation_tlv.tid = cl_hton64(emad_buffer->emad_tid);
            reg_tlv_size = sizeof(reg_tlv) + emad_buffer->reg_size;
            reg_tlv.type_len = EMAD_TLV_BUILD_TYPE_LEN(EMAD_TLV_TYPE_REG_E, reg_tlv_size / 4);

            err = emad_transaction_add(emad_buffer);
            if (err != SXD_STATUS_SUCCESS) { /* emad_buffer no longer exists ... */
                SX_LOG_ERR(
                    "EMAD transaction (TID 0x%" PRIx64 ", dev_id=%u, reg=0x%04x [%s]) is timed-out before it was sent\n",
                    cl_ntoh64(operation_tlv.tid),
                    ku_write.meta.dev_id,
                    cl_ntoh16(operation_tlv.register_id),
                    REG_ID_TO_NAME(cl_ntoh16(operation_tlv.register_id)));
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                continue;
            }

#ifdef SNIFFER_PRESENT
            sxd_sniffer_emad_prm_record_tx(ku_write.iov,
                                           ku_write.vec_entries,
                                           EMAD_BUFFER_ACCESS_CMD(emad_buffer),
                                           emad_buffer->reg_id);
#endif

            rc = write(sxd_fd, &ku_write, sizeof(ku_write));
            if (rc != sizeof(ku_write)) {
                SX_LOG_ERR("failed to write emad (rc=%d)\n", rc);
            }
        }
    }
}


uint32_t emad_tx_thread_enqueue(struct emad_buffer *emad_buffer)
{
    uint32_t queue_size;

    cl_spinlock_acquire(&__emad_queue_lock);
    cl_qlist_insert_tail(__emad_queue_enqueue, &emad_buffer->list_item);
    queue_size = __queue_size + cl_qlist_count(__emad_queue_enqueue);
    if (cl_fd_signal(__thread_notif_fd)) {
        SX_LOG_ERR("Failed writing to the PIPE of EMAD Tx thread \n");
    }
    cl_spinlock_release(&__emad_queue_lock);

    return queue_size;
}


sxd_status_t emad_open_tx_thread(void)
{
    cl_status_t cl_st = CL_SUCCESS;
    sxd_status_t sxd_st = SXD_STATUS_SUCCESS;
    cl_event_t start_ev;

    __thread_is_alive = TRUE;

    cl_st = cl_event_init(&start_ev, FALSE);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to create start-event for emad tx thread (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto start_ev_err;
    }

    cl_st = cl_fd_init(&__thread_notif_fd);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to create pipe for emad tx thread (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto notif_ev_err;
    }

    __emad_queue_enqueue = &__emad_queue[0];
    __emad_queue_dequeue = &__emad_queue[1];
    cl_qlist_init(__emad_queue_enqueue);
    cl_qlist_init(__emad_queue_dequeue);

    cl_st = cl_spinlock_init(&__emad_queue_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to initialize emad queue lock (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto queue_lock_err;
    }

    sxd_emad_hook_register(SXD_REG_ID_MGIR_E, __mgir_hook, NULL);

    cl_st = cl_thread_init(&__thread_h, __emad_tx_thread, &start_ev, "emadTx", 30);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to open emad tx thread (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_NO_RESOURCES;
        goto thread_err;
    }

    cl_event_wait_on(&start_ev, EVENT_NO_TIMEOUT, TRUE);
    return SXD_STATUS_SUCCESS;

thread_err:
    cl_spinlock_destroy(&__emad_queue_lock);

queue_lock_err:
    close(__thread_notif_fd);

notif_ev_err:
    cl_event_destroy(&start_ev);

start_ev_err:
    __thread_is_alive = FALSE;
    return sxd_st;
}


void emad_close_tx_thread(void)
{
    __thread_is_alive = FALSE;

    if (cl_fd_signal(__thread_notif_fd)) {
        SX_LOG_ERR("Failed writing to the PIPE of EMAD Tx thread in order to close him \n");
    }
    cl_thread_destroy(&__thread_h);
    close(__thread_notif_fd);
}

sxd_status_t emad_tx_thread_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sxd_status_t emad_tx_thread_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return status;
}
