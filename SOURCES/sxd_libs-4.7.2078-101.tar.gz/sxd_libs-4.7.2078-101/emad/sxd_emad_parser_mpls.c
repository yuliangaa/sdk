/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_mpls.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_MPGCR

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sxd_status_t sxd_emad_parse_mpgcr(sxd_emad_mpgcr_data_t *mpgcr_data, sxd_emad_mpgcr_reg_t *mpgcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpgcr_reg->mpls_et = (mpgcr_data->reg_data->mpls_et & 0x03) << 4;
    mpgcr_reg->mpls_pcp_ler_exp_rw = (mpgcr_data->reg_data->mpls_pcp_rw & 0x03) << 6;
    mpgcr_reg->mpls_pcp_ler_exp_rw |= (mpgcr_data->reg_data->ler_exp_rw & 0x03) << 4;
    mpgcr_reg->ingress_egress_ler_lsr_egress_ttl = (mpgcr_data->reg_data->ingress_ler_ttl & 0x01) << 6;
    mpgcr_reg->ingress_egress_ler_lsr_egress_ttl |= (mpgcr_data->reg_data->egress_ler_ttl & 0x03) << 4;
    mpgcr_reg->ingress_egress_ler_lsr_egress_ttl |= mpgcr_data->reg_data->lsr_egress_ttl & 0x03;
    mpgcr_reg->ingress_ler_ttl_value = mpgcr_data->reg_data->ingress_ler_ttl_value;
    mpgcr_reg->hrlsn = mpgcr_data->reg_data->hrlsn;
    mpgcr_reg->label_id_min = cl_hton32(mpgcr_data->reg_data->label_id_min & 0xfffff);
    mpgcr_reg->label_id_max = cl_hton32(mpgcr_data->reg_data->label_id_max & 0xfffff);
    mpgcr_reg->entropy_msb = mpgcr_data->reg_data->entropy_msb;
    mpgcr_reg->irif_vr_en = mpgcr_data->reg_data->irif_vr_en & 0x01;
    mpgcr_reg->activity_dis_mpnhlfe = (mpgcr_data->reg_data->activity_dis_mpnhlfe & 0x01);


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mpgcr(sxd_emad_mpgcr_data_t *mpgcr_data, sxd_emad_mpgcr_reg_t *mpgcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpgcr_data->reg_data->mpls_et = (mpgcr_reg->mpls_et >> 4) & 0x03;
    mpgcr_data->reg_data->mpls_pcp_rw = (mpgcr_reg->mpls_pcp_ler_exp_rw >> 6) & 0x03;
    mpgcr_data->reg_data->ler_exp_rw = (mpgcr_reg->mpls_pcp_ler_exp_rw >> 4) & 0x03;
    mpgcr_data->reg_data->ingress_ler_ttl = (mpgcr_reg->ingress_egress_ler_lsr_egress_ttl >> 6) & 0x01;
    mpgcr_data->reg_data->egress_ler_ttl = (mpgcr_reg->ingress_egress_ler_lsr_egress_ttl >> 4) & 0x03;
    mpgcr_data->reg_data->lsr_egress_ttl = mpgcr_reg->ingress_egress_ler_lsr_egress_ttl & 0x03;
    mpgcr_data->reg_data->ingress_ler_ttl_value = mpgcr_reg->ingress_ler_ttl_value;
    mpgcr_data->reg_data->hrlsn = mpgcr_reg->hrlsn;
    mpgcr_data->reg_data->label_id_min = cl_ntoh32(mpgcr_reg->label_id_min) & 0xfffff;
    mpgcr_data->reg_data->label_id_max = cl_ntoh32(mpgcr_reg->label_id_max) & 0xfffff;
    mpgcr_data->reg_data->entropy_msb = mpgcr_reg->entropy_msb;
    mpgcr_data->reg_data->irif_vr_en = mpgcr_reg->irif_vr_en & 0x01;
    mpgcr_data->reg_data->activity_dis_mpnhlfe = mpgcr_reg->activity_dis_mpnhlfe & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mpilm(sxd_emad_mpilm_data_t *mpilm_data, sxd_emad_mpilm_reg_t *mpilm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpilm_reg->op = (mpilm_data->reg_data->op & 0x07) << 4;
    mpilm_reg->label_space = mpilm_data->reg_data->label_space;
    mpilm_reg->label_id = cl_hton32(mpilm_data->reg_data->label_id & 0xfffff);
    mpilm_reg->nhlfe_index = cl_hton32(mpilm_data->reg_data->nhlfe_ptr & 0xffffff);
    mpilm_reg->npop = (mpilm_data->reg_data->npop & 0x03);
    mpilm_reg->ecmp_size = cl_hton16(mpilm_data->reg_data->ecmp_size & 0x1fff);
    mpilm_reg->trap_action = (mpilm_data->reg_data->trap_action & 0xf) << 4;
    mpilm_reg->trap_id = cl_hton16(mpilm_data->reg_data->trap_id & 0x1ff);
    mpilm_reg->counter_set = cl_hton32((mpilm_data->reg_data->counter_set.type & 0xff) << 24);
    mpilm_reg->counter_set |= cl_hton32(mpilm_data->reg_data->counter_set.index & 0xffffff);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mpilm(sxd_emad_mpilm_data_t *mpilm_data, sxd_emad_mpilm_reg_t *mpilm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpilm_data->reg_data->op = (mpilm_reg->op >> 4) & 0x07;
    mpilm_data->reg_data->label_space = (mpilm_reg->label_space);
    mpilm_data->reg_data->label_id = cl_ntoh32(mpilm_reg->label_id) & 0xfffff;
    mpilm_data->reg_data->nhlfe_ptr = cl_ntoh32(mpilm_reg->nhlfe_index) & 0xffffff;
    mpilm_data->reg_data->npop = (mpilm_reg->npop) & 0x03;
    mpilm_data->reg_data->ecmp_size = cl_ntoh16(mpilm_reg->ecmp_size) & 0x1fff;
    mpilm_data->reg_data->trap_action = (mpilm_reg->trap_action >> 4) & 0xf;
    mpilm_data->reg_data->trap_id = cl_ntoh16(mpilm_reg->trap_id) & 0x1ff;
    mpilm_data->reg_data->counter_set.type = ((cl_ntoh32(mpilm_reg->counter_set) >> 24) & 0xff);
    mpilm_data->reg_data->counter_set.index = cl_ntoh32(mpilm_reg->counter_set) & 0xffffff;

    SX_LOG_EXIT();
    return err;
}
