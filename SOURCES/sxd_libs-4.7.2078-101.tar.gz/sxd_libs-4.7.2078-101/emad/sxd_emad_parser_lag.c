/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_lag.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_LAG

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_lag_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_sldr(sxd_emad_sldr_data_t *sldr_data, sxd_emad_sldr_reg_t *sldr_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sldr_reg->op = (sldr_data->reg_data->operation & 0x07) << 5;
    sldr_reg->lag_id = cl_hton16(sldr_data->reg_data->lag_id & 0x03FF);
    if ((sldr_data->reg_data->operation == SLDR_OPERATION_FINE_GRAIN_LAG_ENABLE) ||
        (sldr_data->reg_data->operation == SLDR_OPERATION_FINE_GRAIN_LAG_DISABLE)) {
        sldr_reg->dst_lag_fgl_ptr = cl_hton16(sldr_data->reg_data->fgl_ptr & 0xFFFF);
        sldr_reg->base_system_ports_fgl_size[i] = cl_hton32(sldr_data->reg_data->fgl_size & 0xFFFF);
    } else {
        sldr_reg->num_ports = sldr_data->reg_data->num_ports;
        sldr_reg->dst_lag_fgl_ptr = cl_hton16(sldr_data->reg_data->dst_lag & 0x03FF);
        for (i = 0; i < sldr_data->reg_data->num_ports; ++i) {
            sldr_reg->base_system_ports_fgl_size[i] = cl_hton32(sldr_data->reg_data->ports[i] & 0xFFFF);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sldr(sxd_emad_sldr_data_t *sldr_data, sxd_emad_sldr_reg_t *sldr_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sldr_reg->op == SLDR_OPERATION_FINE_GRAIN_LAG_ENABLE) ||
        (sldr_reg->op == SLDR_OPERATION_FINE_GRAIN_LAG_DISABLE)) {
        sldr_data->reg_data->fgl_ptr = cl_ntoh16(sldr_reg->dst_lag_fgl_ptr);
        sldr_data->reg_data->fgl_size = (uint16_t)cl_ntoh32((*sldr_reg->base_system_ports_fgl_size) & 0xFFFF);
    } else {
        sldr_data->reg_data->num_ports = sldr_reg->num_ports;
        for (i = 0; i < sldr_reg->num_ports; ++i) {
            sldr_data->reg_data->ports[i] = cl_ntoh32(sldr_reg->base_system_ports_fgl_size[i]) & 0xFFFF;
        }
        sldr_data->reg_data->dst_lag = cl_ntoh16(sldr_reg->dst_lag_fgl_ptr) & 0x03FF;
    }
    sldr_data->reg_data->operation = sldr_reg->op;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sldr_reg_ports_size(sxd_emad_sldr_data_t *sldr_data, uint32_t *sldr_reg_ports_size)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sldr_data->reg_data->operation == SLDR_OPERATION_FINE_GRAIN_LAG_ENABLE) ||
        (sldr_data->reg_data->operation == SLDR_OPERATION_FINE_GRAIN_LAG_DISABLE)) {
        *sldr_reg_ports_size = sizeof(net32_t);
    } else {
        *sldr_reg_ports_size = sldr_data->reg_data->num_ports * sizeof(net32_t);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_slcr(sxd_emad_slcr_data_t *slcr_data, sxd_emad_slcr_reg_t *slcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slcr_reg->sh = slcr_data->reg_data->sh & 0x1;
    slcr_reg->type = slcr_data->reg_data->hash_type & 0x0F;
    slcr_reg->lag_hash = cl_hton32(slcr_data->reg_data->hash_configuration & 0x000FFFFF);
    slcr_reg->seed = cl_hton32(slcr_data->reg_data->seed);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_slcr(sxd_emad_slcr_data_t *slcr_data, sxd_emad_slcr_reg_t *slcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slcr_data->reg_data->sh = slcr_reg->sh & 0x1;
    slcr_data->reg_data->hash_type = slcr_reg->type & 0x0F;
    slcr_data->reg_data->hash_configuration = cl_ntoh32(slcr_reg->lag_hash) & 0x000FFFFF;
    slcr_data->reg_data->seed = cl_ntoh32(slcr_reg->seed);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_slcor(sxd_emad_slcor_data_t *slcor_data, sxd_emad_slcor_reg_t *slcor_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slcor_reg->col = (slcor_data->reg_data->collector & 0x03) << 6;
    slcor_reg->local_port = slcor_data->reg_data->local_port;
    slcor_reg->lag_id_lp_msb = ((uint16_t)(slcor_data->reg_data->lp_msb & 0x03)) << 12;
    slcor_reg->lag_id_lp_msb |= (slcor_data->reg_data->lag_id & 0x03FF);
    slcor_reg->lag_id_lp_msb = cl_hton16(slcor_reg->lag_id_lp_msb);
    slcor_reg->port_index = slcor_data->reg_data->port_index;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_slcor(sxd_emad_slcor_data_t *slcor_data, sxd_emad_slcor_reg_t *slcor_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slcor_data->reg_data->collector = (slcor_reg->col >> 6) & 0x03;
    slcor_data->reg_data->port_index = slcor_reg->port_index;
    slcor_data->reg_data->lag_id = cl_ntoh16(slcor_reg->lag_id_lp_msb & 0x03FF);

    SX_LOG_EXIT();
    return err;
}
