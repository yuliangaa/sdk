/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_fdb.h>
#include <sx/sxd/auto_registers/reg.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_FDB

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_fdb_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_sfd(sxd_emad_sfd_data_t *sfd_data, sxd_emad_sfd_reg_t *sfd_reg)
{
    sxd_status_t               err = SXD_STATUS_SUCCESS;
    uint8_t                    rec_idx;
    uint8_t                    offset = sfd_data->reg_data->offset;
    sxd_emad_sfd_fdb_record_t *cur_rec = NULL;

    SX_LOG_ENTER();

    sfd_reg->swid = sfd_data->reg_data->swid;

    sfd_reg->rec_type = (sfd_data->reg_data->rec_type & 0x01) << 4;

    switch (sfd_data->common.access_cmd) {
    case SXD_ACCESS_CMD_ADD:
        sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_OPERATION_ADD_E << 30);
        break;

    case SXD_ACCESS_CMD_DELETE:
        sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_OPERATION_DELETE_E << 30);
        if (sfd_data->reg_data->operation == SXD_OPERATION_REMOVE_NOTIFICATION) {
            sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_REMOVE_NOTIFICATION_E << 30);
        }
        break;

    case SXD_ACCESS_CMD_TEST:
        sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_OPERATION_TEST_E << 30);
        break;

    case SXD_ACCESS_CMD_GET:
        sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_OPERATION_QUERY_E << 30);
        if (sfd_data->reg_data->operation == SXD_OPERATION_QUERY_AND_CLEAR_ACTIVITY) {
            sfd_reg->op_record_locator = cl_hton32(SXD_EMAD_SFD_QUERY_AND_CLEAR_ACTIVITY_E << 30);
        }
        break;

    case SXD_ACCESS_CMD_GET_ALL:
        sfd_reg->op_record_locator = cl_hton32((SXD_EMAD_SFD_OPERATION_DUMP_FDB_E << 30) |
                                               ((sfd_data->reg_data->record_locator) & 0x3FFFFFFF));
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported access command: %u\n", sfd_data->common.access_cmd);
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    sfd_reg->num_rec = sfd_data->reg_data->num_records - offset;

    for (rec_idx = offset; rec_idx < sfd_data->reg_data->num_records && rec_idx < SXD_EMAD_SFD_MAX_RECORDS;
         rec_idx++) {
        cur_rec =
            (sfd_data->reg_data->rec_type ==
             SFD_REC_TYPE_1) ? (&sfd_reg->records.records_32[rec_idx - offset].record_16) :
            (&sfd_reg->records.records_16[rec_idx - offset]);

        switch (sfd_data->reg_data->sfd_type[rec_idx]) {
        case SXD_EMAD_SFD_TYPE_UNICAST_E:
            cur_rec->uc.swid = sfd_data->reg_data->swid;
            cur_rec->uc.type_policy = (SXD_EMAD_SFD_TYPE_UNICAST_E <<
                                       4) | ((sfd_data->reg_data->sfd_data_type[rec_idx].uc.policy & 0x03) << 2);
            memcpy(cur_rec->uc.mac,
                   sfd_data->reg_data->sfd_data_type[rec_idx].uc.mac.ether_addr_octet,
                   sizeof(sxd_mac_addr_t));
            cur_rec->uc.set_vid = sfd_data->reg_data->sfd_data_type[rec_idx].uc.set_vid << 7;
            cur_rec->uc.sub_port = sfd_data->reg_data->sfd_data_type[rec_idx].uc.sub_port;
            cur_rec->uc.fid_vid =
                cl_hton16((sfd_data->reg_data->sfd_data_type[rec_idx].uc.policy == SFD_POLICY_STATIC ?
                           sfd_data->reg_data->sfd_data_type[rec_idx].uc.fid_vid_type.vid : sfd_data->reg_data->
                           sfd_data_type[rec_idx].uc.fid_vid_type.fid) & 0xFFFF);
            cur_rec->uc.action_vid = cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].uc.action << 12
                                               | (sfd_data->reg_data->sfd_data_type[rec_idx].uc.vid & 0x0FFF));
            cur_rec->uc.system_port = cl_hton16(
                sfd_data->reg_data->sfd_data_type[rec_idx].uc.system_port);
            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_reg->records.records_32[rec_idx - offset].counter_set_type_index =
                    cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].uc.counter_set.type & 0xFF) << 24 |
                              (sfd_data->reg_data->sfd_data_type[rec_idx].uc.counter_set.index & 0xFFFFFF));
            }

            break;

        case SXD_EMAD_SFD_TYPE_UNICAST_LAG_E:
            cur_rec->uc_lag.swid = sfd_data->reg_data->swid;
            cur_rec->uc_lag.type_policy =
                (SXD_EMAD_SFD_TYPE_UNICAST_LAG_E <<
                    4) | ((sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.policy & 0x03) << 2);
            memcpy(cur_rec->uc_lag.mac,
                   sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.mac.ether_addr_octet,
                   sizeof(sxd_mac_addr_t));
            cur_rec->uc_lag.set_vid = sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.set_vid << 7;
            cur_rec->uc_lag.sub_port = sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.sub_port;
            cur_rec->uc_lag.fid_vid =
                cl_hton16((sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.policy == SFD_POLICY_STATIC ?
                           sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.fid_vid_type.vid : sfd_data->reg_data->
                           sfd_data_type[rec_idx].uc_lag.fid_vid_type.fid) & 0xFFFF);
            cur_rec->uc_lag.action_lag_vid =
                cl_hton16((sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.action << 12) |
                          (sfd_data->reg_data->sfd_data_type[rec_idx].
                           uc_lag.lag_vid & 0xFFF));
            cur_rec->uc_lag.lag_id = cl_hton16(
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.lag_id & 0x03FF);
            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_reg->records.records_32[rec_idx - offset].counter_set_type_index =
                    cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.counter_set.type & 0xFF) << 24 |
                              (sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.counter_set.index & 0xFFFFFF));
            }

            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_E:
            cur_rec->mc.swid = sfd_data->reg_data->swid;
            cur_rec->mc.type_policy = ((SXD_EMAD_SFD_TYPE_MULTICAST_E << 4) |
                                       ((sfd_data->reg_data->sfd_data_type[rec_idx].mc.policy & 0x1) << 1));

            memcpy(cur_rec->mc.mac,
                   sfd_data->reg_data->sfd_data_type[rec_idx].mc.mac.ether_addr_octet,
                   sizeof(sxd_mac_addr_t));
            cur_rec->mc.pgi = cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].mc.pgi & 0x1FFF);
            cur_rec->mc.vid = cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].mc.vid & 0xFFFF);
            cur_rec->mc.action = sfd_data->reg_data->sfd_data_type[rec_idx].mc.action << 4;
            cur_rec->mc.mid = cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].mc.mid);
            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_reg->records.records_32[rec_idx - offset].counter_set_type_index =
                    cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].mc.counter_set.type & 0xFF) << 24 |
                              (sfd_data->reg_data->sfd_data_type[rec_idx].mc.counter_set.index & 0xFFFFFF));
            }

            break;

        case SXD_EMAD_SFD_TYPE_UNICAST_TUNNEL_E:
            cur_rec->uc_tunnel.swid = sfd_data->reg_data->swid;
            cur_rec->uc_tunnel.type_policy_a = ((SXD_EMAD_SFD_TYPE_UNICAST_TUNNEL_E << 4) |
                                                ((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel
                                                  .policy & 0x03) << 2));
            memcpy(cur_rec->uc_tunnel.mac,
                   sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.mac.ether_addr_octet,
                   sizeof(sxd_mac_addr_t));

            if ((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.gen_enc == 0) &&
                (SFD_UC_TUNNEL_PROTOCOL_IPV4 == (sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.protocol))) {
                cur_rec->uc_tunnel.udip_msb = sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.udip_msb;
            }

            cur_rec->uc_tunnel.fid = cl_hton16(
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.fid & 0xFFFF);
            cur_rec->uc_tunnel.action_protocol_gen_enc_udip_lsb =
                cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.action << 28) |
                          ((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.protocol & 0x01) << 27) |
                          ((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.gen_enc & 0x01) << 26) |
                          (sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.udip_lsb & 0x00FFFFFF));
            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_reg->records.records_32[rec_idx - offset].counter_set_type_index =
                    cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.counter_set.type & 0xFF) << 24 |
                              (sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.counter_set.index & 0xFFFFFF));

                sfd_reg->records.records_32[rec_idx - offset].ecmp_size =
                    cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.ecmp_size & 0x1FFF);

                sfd_reg->records.records_32[rec_idx - offset].tunnel_port_lbf_bitmap =
                    cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.tunnel_port_lbf_bitmap & 0xFFFF);
            }

            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_TUNNEL_E:
            cur_rec->mc_tunnel.swid = sfd_data->reg_data->swid;
            cur_rec->mc_tunnel.type_policy_a = ((SXD_EMAD_SFD_TYPE_MULTICAST_TUNNEL_E << 4) |
                                                ((sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel
                                                  .policy & 0x1) << 1));
            memcpy(cur_rec->mc_tunnel.mac,
                   sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.mac.ether_addr_octet,
                   sizeof(sxd_mac_addr_t));
            cur_rec->mc_tunnel.mid = cl_hton16(
                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.mid);
            cur_rec->mc_tunnel.fid = cl_hton16(
                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.fid & 0xFFFF);
            cur_rec->mc_tunnel.action_underlay_mc_ptr =
                cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.action << 28) |
                          (sfd_data->reg_data->sfd_data_type[
                               rec_idx].mc_tunnel.
                           underlay_mc_ptr & 0x00FFFFFF));
            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_reg->records.records_32[rec_idx - offset].counter_set_type_index =
                    cl_hton32((sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.counter_set.type & 0xFF) << 24 |
                              (sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.counter_set.index & 0xFFFFFF));

                sfd_reg->records.records_32[rec_idx - offset].ecmp_size =
                    cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.ecmp_size & 0x1FFF);

                sfd_reg->records.records_32[rec_idx - offset].tunnel_port_lbf_bitmap =
                    cl_hton16(sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.tunnel_port_lbf_bitmap & 0xFFFF);
            }
            break;

        default:
            SX_LOG(SX_LOG_ERROR, "Unsupported SFD type %u\n", sfd_data->reg_data->sfd_type[rec_idx]);
            err = SXD_STATUS_PARAM_ERROR;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sfd(sxd_emad_sfd_data_t *sfd_data, sxd_emad_sfd_reg_t *sfd_reg)
{
    sxd_status_t               err = SXD_STATUS_SUCCESS;
    uint8_t                    rec_idx;
    sxd_emad_sfd_fdb_record_t *cur_rec = NULL;

    SX_LOG_ENTER();

    sfd_data->reg_data->rec_type = (sfd_reg->rec_type >> 4) & 0x01;

    sfd_data->reg_data->record_locator = cl_ntoh32(sfd_reg->op_record_locator) & 0x3FFFFFFF;

    sfd_data->reg_data->num_records = sfd_reg->num_rec;

    for (rec_idx = 0; rec_idx < sfd_data->reg_data->num_records && rec_idx < SXD_EMAD_SFD_MAX_RECORDS; rec_idx++) {
        cur_rec =
            (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) ? (&sfd_reg->records.records_32[rec_idx].record_16) :
            (&sfd_reg->records.records_16[rec_idx]);

        sfd_data->reg_data->sfd_type[rec_idx] = (cur_rec->uc.type_policy >> 4) & 0x0F;

        switch (sfd_data->reg_data->sfd_type[rec_idx]) {
        case SXD_EMAD_SFD_TYPE_UNICAST_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.policy =
                (cur_rec->uc.type_policy >> 2) & 0x03;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.activity = cur_rec->uc.type_policy & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.sub_port = cur_rec->uc.sub_port;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.set_vid = cur_rec->uc.set_vid >> 7;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.action = (cl_ntoh16(cur_rec->uc.action_vid) >> 12) & 0x0F;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.vid = cl_ntoh16(cur_rec->uc.action_vid) & 0x0FFF;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.system_port = cl_ntoh16(
                cur_rec->uc.system_port);
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.fid_vid_type.vid = cl_ntoh16(
                cur_rec->uc.fid_vid);
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].uc.mac.ether_addr_octet,
                   cur_rec->uc.mac, sizeof(sxd_mac_addr_t));

            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_data->reg_data->sfd_data_type[rec_idx].uc.counter_set.type =
                    (cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) >> 24) & 0xFF;
                sfd_data->reg_data->sfd_data_type[rec_idx].uc.counter_set.index =
                    cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFD_TYPE_UNICAST_LAG_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.policy =
                (cur_rec->uc_lag.type_policy >> 2) & 0x03;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.activity = cur_rec->uc_lag.type_policy & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.sub_port = cur_rec->uc_lag.sub_port;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.set_vid = cur_rec->uc_lag.set_vid >> 7;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.action =
                (cl_ntoh16(cur_rec->uc_lag.action_lag_vid) >> 12) & 0x0F;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.lag_vid =
                cl_ntoh16(cur_rec->uc_lag.action_lag_vid) & 0xFFF;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.lag_id = cl_ntoh16(
                cur_rec->uc_lag.lag_id) & 0x03FF;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.fid_vid_type.vid = cl_ntoh16(
                cur_rec->uc_lag.fid_vid);
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.mac.ether_addr_octet,
                   cur_rec->uc_lag.mac, sizeof(sxd_mac_addr_t));

            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.counter_set.type =
                    (cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) >> 24) & 0xFF;
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.counter_set.index =
                    cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.activity = cur_rec->mc.type_policy & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.policy = (cur_rec->mc.type_policy >> 1) & 0x1;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.pgi = cl_ntoh16(cur_rec->mc.pgi) & 0x1FFF;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.action = (cur_rec->mc.action >> 4) & 0x0F;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.mid = cl_ntoh16(cur_rec->mc.mid);
            sfd_data->reg_data->sfd_data_type[rec_idx].mc.vid = cl_ntoh16(cur_rec->mc.vid);
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].mc.mac.ether_addr_octet,
                   cur_rec->mc.mac, sizeof(sxd_mac_addr_t));

            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_data->reg_data->sfd_data_type[rec_idx].mc.counter_set.type =
                    (cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) >> 24) & 0xFF;
                sfd_data->reg_data->sfd_data_type[rec_idx].mc.counter_set.index =
                    cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_TUNNEL_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_TUNNEL_E:
        case SXD_EMAD_SFD_TYPE_UNICAST_TUNNEL_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.policy =
                (cur_rec->uc_tunnel.type_policy_a >> 2) & 0x03;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.activity =
                cur_rec->uc_tunnel.type_policy_a & 0x01;
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.mac.ether_addr_octet,
                   cur_rec->uc_tunnel.mac,
                   sizeof(sxd_mac_addr_t));

            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.fid = cl_ntoh16(
                cur_rec->uc_tunnel.fid);
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.action =
                (cl_ntoh32(cur_rec->uc_tunnel.action_protocol_gen_enc_udip_lsb) >> 28) & 0x0F;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.protocol =
                (cl_ntoh32(cur_rec->uc_tunnel.action_protocol_gen_enc_udip_lsb) >> 27) & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.gen_enc =
                (cl_ntoh32(cur_rec->uc_tunnel.action_protocol_gen_enc_udip_lsb) >> 26) & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.udip_lsb = cl_ntoh32(
                cur_rec->uc_tunnel.action_protocol_gen_enc_udip_lsb) & 0x00FFFFFF;

            if (SFD_UC_TUNNEL_PROTOCOL_IPV4 == sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.protocol) {
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.udip_msb =
                    cur_rec->uc_tunnel.udip_msb;
            }

            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.counter_set.type =
                    (cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) >> 24) & 0xFF;
                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.counter_set.index =
                    cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) & 0xFFFFFFF;

                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.ecmp_size =
                    cl_ntoh16(sfd_reg->records.records_32[rec_idx].ecmp_size & 0x1FFF);

                sfd_data->reg_data->sfd_data_type[rec_idx].uc_tunnel.tunnel_port_lbf_bitmap =
                    cl_ntoh16(sfd_reg->records.records_32[rec_idx].tunnel_port_lbf_bitmap & 0xFFFF);
            }

            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_TUNNEL_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.activity =
                cur_rec->mc_tunnel.type_policy_a & 0x01;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.policy =
                (cur_rec->mc_tunnel.type_policy_a >> 1) & 0x1;
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.mac.ether_addr_octet,
                   cur_rec->mc_tunnel.mac, sizeof(sxd_mac_addr_t));
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.mid = cl_ntoh16(
                cur_rec->mc_tunnel.mid);
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.fid = cl_ntoh16(
                cur_rec->mc_tunnel.fid);
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.action =
                (cl_ntoh32(cur_rec->mc_tunnel.action_underlay_mc_ptr) >> 28) & 0x0F;
            sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.underlay_mc_ptr = cl_ntoh32(
                cur_rec->mc_tunnel.action_underlay_mc_ptr) & 0x00FFFFFF;

            /*
             *  Case for 32B records
             */
            if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.counter_set.type =
                    (cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) >> 24) & 0xFF;
                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.counter_set.index =
                    cl_ntoh32(sfd_reg->records.records_32[rec_idx].counter_set_type_index) & 0xFFFFFFF;

                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.ecmp_size =
                    cl_ntoh16(sfd_reg->records.records_32[rec_idx].ecmp_size & 0x1FFF);

                sfd_data->reg_data->sfd_data_type[rec_idx].mc_tunnel.tunnel_port_lbf_bitmap =
                    cl_ntoh16(sfd_reg->records.records_32[rec_idx].tunnel_port_lbf_bitmap & 0xFFFF);
            }
            break;

        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.system_port = cl_ntoh16(
                cur_rec->uc.system_port);
            sfd_data->reg_data->sfd_data_type[rec_idx].uc.fid_vid_type.vid = cl_ntoh16(
                cur_rec->uc.fid_vid);
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].uc.mac.ether_addr_octet,
                   cur_rec->uc.mac, sizeof(sxd_mac_addr_t));
            break;

        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_LAG_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_LAG_E:
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.lag_id = cl_ntoh16(
                cur_rec->uc_lag.lag_id) & 0x03FF;
            sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.fid_vid_type.vid = cl_ntoh16(
                cur_rec->uc_lag.fid_vid);
            memcpy(sfd_data->reg_data->sfd_data_type[rec_idx].uc_lag.mac.ether_addr_octet,
                   cur_rec->uc_lag.mac, sizeof(sxd_mac_addr_t));
            break;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sfd_reg_records_size(sxd_emad_sfd_data_t *sfd_data, uint32_t *sfd_reg_records_size)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (sfd_data->common.access_cmd != SXD_ACCESS_CMD_GET_ALL) {
        switch (sfd_data->reg_data->sfd_type[0]) {
        case SXD_EMAD_SFD_TYPE_UNICAST_E:
        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_E:
            *sfd_reg_records_size = sizeof(sxd_emad_fdb_record_unicast_t);
            break;

        case SXD_EMAD_SFD_TYPE_UNICAST_LAG_E:
        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_LAG_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_LAG_E:
            *sfd_reg_records_size = sizeof(sxd_emad_fdb_record_unicast_lag_t);
            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_E:
            *sfd_reg_records_size = sizeof(sxd_emad_fdb_record_multicast_t);
            break;

        case SXD_EMAD_SFD_TYPE_LEARNT_MAC_TUNNEL_E:
        case SXD_EMAD_SFD_TYPE_AGED_MAC_TUNNEL_E:
        case SXD_EMAD_SFD_TYPE_UNICAST_TUNNEL_E:
            *sfd_reg_records_size = sizeof(sxd_emad_fdb_record_uc_tunnel_t);
            break;

        case SXD_EMAD_SFD_TYPE_MULTICAST_TUNNEL_E:
            *sfd_reg_records_size = sizeof(sxd_emad_fdb_record_mc_tunnel_t);
            break;
        }

        if (sfd_data->reg_data->rec_type == SFD_REC_TYPE_1) {
            *sfd_reg_records_size = sizeof(sxd_emad_sfd_fdb_record_32_t);
        }

        *sfd_reg_records_size *= (sfd_data->reg_data->num_records - sfd_data->reg_data->offset);
    } else {
        *sfd_reg_records_size = 0;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sfn(sxd_emad_sfn_data_t *sfn_data, sxd_emad_sfn_reg_t *sfn_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;


    sfn_reg->swid = sfn_data->reg_data->swid;
    sfn_reg->rec_type = (sfn_data->reg_data->rec_type & 0x01) << 4;
    sfn_reg->end = (sfn_data->reg_data->end & 0x01) << 4;
    sfn_reg->num_rec = sfn_data->reg_data->num_records;

    return err;
}

sxd_status_t sxd_emad_deparse_sfn(sxd_emad_sfn_data_t *sfn_data, sxd_emad_sfn_reg_t *sfn_reg)
{
    uint32_t                   i = 0;
    sxd_emad_sfn_fdb_record_t *cur_rec = NULL;
    sxd_status_t               err = SXD_STATUS_SUCCESS;


    sfn_data->reg_data->swid = sfn_reg->swid;
    sfn_data->reg_data->rec_type = (sfn_reg->rec_type >> 4) & 0x01;
    sfn_data->reg_data->num_records = sfn_reg->num_rec;

    for (i = 0; i < sfn_data->reg_data->num_records; ++i) {
        cur_rec = (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) ? (&sfn_reg->records.records_32[i].record_16) :
                  (&sfn_reg->records.records_16[i]);

        sfn_data->reg_data->records[i].sfn_type = (cur_rec->lrnt_mac.type >> 4) & 0x0F;

        switch (sfn_data->reg_data->records[i].sfn_type) {
        case SXD_EMAD_SFN_TYPE_LEARNT_MAC_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.mac.ether_addr_octet,
                   cur_rec->lrnt_mac.mac, sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.sub_port =
                cur_rec->lrnt_mac.sub_port;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.fid =
                cl_ntoh16(cur_rec->lrnt_mac.fid) & 0xFFFF;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.system_port =
                cl_ntoh16(cur_rec->lrnt_mac.system_port);

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFN_TYPE_LEARNT_MAC_LAG_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.mac.ether_addr_octet,
                   cur_rec->lrnt_mac_lag.mac, sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.sub_port =
                cur_rec->lrnt_mac_lag.sub_port;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.fid =
                cl_ntoh16(cur_rec->lrnt_mac_lag.fid) & 0xFFFF;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.lag_id =
                cl_ntoh16(cur_rec->lrnt_mac_lag.lag_id) & 0x03FF;

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_mac_lag.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFN_TYPE_LEARNT_UC_TUNNEL_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.mac.ether_addr_octet,
                   cur_rec->lrnt_uc_tunnel.mac, sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.udip_msb =
                cur_rec->lrnt_uc_tunnel.udip_msb;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.fid =
                cl_ntoh16(cur_rec->lrnt_uc_tunnel.fid) & 0xFFFF;
            sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.udip_lsb =
                cl_ntoh32(cur_rec->lrnt_uc_tunnel.udip_lsb) & 0x0FFFFFF;

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.lrnt_uc_tunnel.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFN_TYPE_AGED_MAC_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.mac.ether_addr_octet,
                   cur_rec->aged_mac.mac, sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.sub_port =
                cur_rec->aged_mac.sub_port;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.fid =
                cl_ntoh16(cur_rec->aged_mac.fid) & 0xFFFF;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.system_port =
                cl_ntoh16(cur_rec->aged_mac.system_port);

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.aged_mac.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFN_TYPE_AGED_MAC_LAG_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.mac.ether_addr_octet,
                   cur_rec->aged_mac_lag.mac, sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.sub_port =
                cur_rec->aged_mac_lag.sub_port;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.fid =
                cl_ntoh16(cur_rec->aged_mac_lag.fid) & 0xFFFF;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.lag_id =
                cl_ntoh16(cur_rec->aged_mac_lag.lag_id) & 0x03FF;

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.aged_mac_lag.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;

        case SXD_EMAD_SFN_TYPE_AGED_UC_TUNNEL_E:
            memcpy(sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.mac.ether_addr_octet,
                   cur_rec->aged_uc_tunnel.mac,
                   sizeof(sxd_mac_addr_t));
            sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.udip_msb =
                cur_rec->aged_uc_tunnel.udip_msb;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.fid =
                cl_ntoh16(cur_rec->aged_uc_tunnel.fid);
            sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.protocol =
                (cl_ntoh32(cur_rec->aged_uc_tunnel.protocol_udip_lsb) >> 27) & 0x01;
            sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.udip_lsb =
                cl_ntoh32(cur_rec->aged_uc_tunnel.protocol_udip_lsb) & 0xFFFFFF;

            /*
             *  Case for 32B records
             */
            if (sfn_data->reg_data->rec_type == SFD_REC_TYPE_1) {
                sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.counter_set.type =
                    (cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) >> 24) & 0xFF;
                sfn_data->reg_data->records[i].sx_sfn_type.aged_uc_tunnel.counter_set.index =
                    cl_ntoh32(sfn_reg->records.records_32[i].counter_set_type_index) & 0xFFFFFFF;
            }

            break;
        }
    }

    return err;
}

sxd_status_t sxd_emad_parse_spgt(sxd_emad_spgt_data_t *spgt_data, sxd_emad_spgt_reg_t *spgt_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0, vepa_offset = 0;
    uint32_t     i = 0, j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spgt_reg->op = (spgt_data->reg_data->operation & 0x03) << 6;
    spgt_reg->pgi = cl_hton16(spgt_data->reg_data->pgi & 0x1FFF);

    for (i = 0; i <= (0x0000000F); ++i) {
        vepa_offset = i << 3;
        for (j = 0; j < SPGT_MAX_PORTS;) {
            offset = (SPGT_MAX_PORTS - 1 - j) >> 5;
            value = 0;
            mask_value = 0;
            for (k = 0; k < 32; ++k, ++j) {
                bit = (spgt_data->reg_data->ports_bitmap[j] >> i) & 0x01;
                value |= bit << k;
                bit = (spgt_data->reg_data->mask_bitmap[j] >> i) & 0x01;
                mask_value |= bit << k;
            }
            spgt_reg->ports_bitmap[vepa_offset + offset] = cl_hton32(value);
            spgt_reg->mask_bitmap[vepa_offset + offset] = cl_hton32(mask_value);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spgt(sxd_emad_spgt_data_t *spgt_data, sxd_emad_spgt_reg_t *spgt_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0, vepa_offset = 0;
    uint32_t     i = 0, j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(spgt_data->reg_data->ports_bitmap, 0, sizeof(spgt_data->reg_data->ports_bitmap));
    memset(spgt_data->reg_data->mask_bitmap, 0, sizeof(spgt_data->reg_data->mask_bitmap));

    for (i = 0; i <= (0x0000000F); ++i) {
        vepa_offset = i << 3;
        for (j = 0; j < SPGT_MAX_PORTS;) {
            offset = (SPGT_MAX_PORTS - 1 - j) >> 5;
            value = cl_ntoh32(spgt_reg->ports_bitmap[vepa_offset + offset]);
            mask_value = cl_ntoh32(spgt_reg->mask_bitmap[vepa_offset + offset]);
            for (k = 0; k < 32; ++k, ++j) {
                bit = (value >> k) & 0x01;
                spgt_data->reg_data->ports_bitmap[j] |= bit << i;
                bit = (mask_value >> k) & 0x01;
                spgt_data->reg_data->mask_bitmap[j] |= bit << i;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_smid(sxd_emad_smid_data_t *smid_data, sxd_emad_smid_reg_t *smid_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0;
    uint32_t     j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    smid_reg->swid = smid_data->reg_data->swid;
    smid_reg->mid = cl_hton16(smid_data->reg_data->mid);
    smid_reg->op = (smid_data->reg_data->op & 0x0F);
    smid_reg->smpe_valid = (smid_data->reg_data->smpe_valid & 0x1) << 4;
    smid_reg->smpe = cl_hton16(smid_data->reg_data->smpe);

    for (j = 0; j < SMID_MAX_PORTS;) {
        offset = (SMID_MAX_PORTS - 1 - j) >> 5;
        value = 0;
        mask_value = 0;
        for (k = 0; k < 32; ++k, ++j) {
            bit = (smid_data->reg_data->ports_bitmap[j]) & 0x01;
            value |= bit << k;
            bit = (smid_data->reg_data->mask_bitmap[j]) & 0x01;
            mask_value |= bit << k;
        }
        smid_reg->ports_bitmap[offset] = cl_hton32(value);
        smid_reg->mask_bitmap[offset] = cl_hton32(mask_value);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_smid(sxd_emad_smid_data_t *smid_data, sxd_emad_smid_reg_t *smid_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0;
    uint32_t     j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    smid_data->reg_data->swid = smid_reg->swid;
    smid_data->reg_data->mid = cl_ntoh16(smid_reg->mid);
    smid_data->reg_data->op = (smid_reg->op & 0x0F);
    smid_data->reg_data->smpe_valid = (smid_reg->smpe_valid >> 4) & 0x1;
    smid_data->reg_data->smpe = cl_ntoh16(smid_reg->smpe);

    memset(smid_data->reg_data->ports_bitmap, 0, sizeof(smid_data->reg_data->ports_bitmap));
    memset(smid_data->reg_data->mask_bitmap, 0, sizeof(smid_data->reg_data->mask_bitmap));

    for (j = 0; j < SMID_MAX_PORTS;) {
        offset = (SMID_MAX_PORTS - 1 - j) >> 5;
        value = cl_ntoh32(smid_reg->ports_bitmap[offset]);
        mask_value = cl_ntoh32(smid_reg->mask_bitmap[offset]);
        for (k = 0; k < 32; ++k, ++j) {
            bit = (value >> k) & 0x01;
            smid_data->reg_data->ports_bitmap[j] = bit;
            bit = (mask_value >> k) & 0x01;
            smid_data->reg_data->mask_bitmap[j] = bit;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sftr(sxd_emad_sftr_data_t * sftr_data, sxd_emad_sftr_reg_t * sftr_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0, vepa_offset = 0;
    uint32_t     i = 0, j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if ((NULL == sftr_data) || (NULL == sftr_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    SX_LOG_ENTER();

    sftr_reg->swid = sftr_data->reg_data->swid;
    sftr_reg->flood_table = sftr_data->reg_data->flood_table & 0x3F;
    sftr_reg->index = cl_hton16(sftr_data->reg_data->index & 0xFFFF);
    sftr_reg->table_type = sftr_data->reg_data->table_type & 0x7;
    sftr_reg->range = cl_hton16(sftr_data->reg_data->range & 0xFFFF);

    for (i = 0; i <= (0x0000000F); ++i) {
        vepa_offset = i << 3;
        for (j = 0; j < SFTR_MAX_PORTS;) {
            offset = (SFTR_MAX_PORTS - 1 - j) >> 5;
            value = 0;
            mask_value = 0;
            for (k = 0; k < 32; ++k, ++j) {
                bit = (sftr_data->reg_data->ports_bitmap[j] >> i) & 0x01;
                value |= bit << k;
                bit = (sftr_data->reg_data->mask_bitmap[j] >> i) & 0x01;
                mask_value |= bit << k;
            }
            sftr_reg->ports_bitmap[vepa_offset + offset] = cl_hton32(value);
            sftr_reg->mask_bitmap[vepa_offset + offset] = cl_hton32(mask_value);
        }
    }
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_deparse_sftr(sxd_emad_sftr_data_t *sftr_data, sxd_emad_sftr_reg_t *sftr_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0, vepa_offset = 0;
    uint32_t     i = 0, j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if ((NULL == sftr_data) || (NULL == sftr_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    SX_LOG_ENTER();

    sftr_data->reg_data->swid = sftr_reg->swid;
    sftr_data->reg_data->flood_table = sftr_reg->flood_table & 0x3F;
    sftr_data->reg_data->index = cl_ntoh16(sftr_reg->index & 0xFFFF);
    sftr_data->reg_data->table_type = sftr_reg->table_type & 0x7;
    sftr_data->reg_data->range = cl_ntoh16(sftr_reg->range & 0xFFFF);

    memset(sftr_data->reg_data->ports_bitmap, 0, sizeof(sftr_data->reg_data->ports_bitmap));
    memset(sftr_data->reg_data->mask_bitmap, 0, sizeof(sftr_data->reg_data->mask_bitmap));

    for (i = 0; i <= (0x0000000F); ++i) {
        vepa_offset = i << 3;
        for (j = 0; j < SFTR_MAX_PORTS;) {
            offset = (SFTR_MAX_PORTS - 1 - j) >> 5;
            value = cl_ntoh32(sftr_reg->ports_bitmap[vepa_offset + offset]);
            mask_value = cl_ntoh32(sftr_reg->mask_bitmap[vepa_offset + offset]);
            for (k = 0; k < 32; ++k, ++j) {
                bit = (value >> k) & 0x01;
                sftr_data->reg_data->ports_bitmap[j] |= bit << i;
                bit = (mask_value >> k) & 0x01;
                sftr_data->reg_data->mask_bitmap[j] |= bit << i;
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_svpe(sxd_emad_svpe_data_t *svpe_data, sxd_emad_svpe_reg_t *svpe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    svpe_reg->local_port = svpe_data->reg_data->local_port;
    svpe_reg->vp_en_lp_msb = svpe_data->reg_data->vp_en & 0x0001;
    svpe_reg->vp_en_lp_msb |= (svpe_data->reg_data->lp_msb << 4) & 0x30;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_svpe(sxd_emad_svpe_data_t *svpe_data, sxd_emad_svpe_reg_t *svpe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    svpe_data->reg_data->local_port = svpe_reg->local_port;
    svpe_data->reg_data->vp_en = svpe_reg->vp_en_lp_msb & 0x0001;
    svpe_data->reg_data->lp_msb = (svpe_reg->vp_en_lp_msb & 0x30) >> 4;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_slecr(sxd_emad_slecr_data_t *slecr_data, sxd_emad_slecr_reg_t *slecr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slecr_reg->swid = slecr_data->reg_data->swid;
    slecr_reg->il_re = (((slecr_data->reg_data->independent_learning == TRUE) << 3) |
                        ((slecr_data->reg_data->roaming_enable == TRUE) << 2));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_slecr(sxd_emad_slecr_data_t *slecr_data, sxd_emad_slecr_reg_t *slecr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    slecr_data->reg_data->independent_learning = (slecr_reg->il_re >> 3) & 0x01;
    slecr_data->reg_data->roaming_enable = (slecr_reg->il_re >> 2) & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_spmlr(sxd_emad_spmlr_data_t *spmlr_data, sxd_emad_spmlr_reg_t *spmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spmlr_reg->local_port = spmlr_data->reg_data->local_port;
    spmlr_reg->lp_msb = (spmlr_data->reg_data->lp_msb << 4) & 0x30;
    spmlr_reg->learn_enable = (spmlr_data->reg_data->learn_enable == TRUE) << 7;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spmlr(sxd_emad_spmlr_data_t *spmlr_data, sxd_emad_spmlr_reg_t *spmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spmlr_data->reg_data->learn_enable = (spmlr_reg->learn_enable >> 7) & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_svmlr(sxd_emad_svmlr_data_t *svmlr_data, sxd_emad_svmlr_reg_t *svmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    svmlr_reg->swid = svmlr_data->reg_data->swid;
    svmlr_reg->vid = cl_hton16(svmlr_data->reg_data->vid & 0x0FFF);
    svmlr_reg->learn_enable = (svmlr_data->reg_data->learn_enable == TRUE) << 7;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_svmlr(sxd_emad_svmlr_data_t *svmlr_data, sxd_emad_svmlr_reg_t *svmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    svmlr_data->reg_data->learn_enable = (svmlr_reg->learn_enable >> 7) & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_spvmlr(sxd_emad_spvmlr_data_t *spvmlr_data, sxd_emad_spvmlr_reg_t *spvmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    spvmlr_reg->local_port = spvmlr_data->reg_data->local_port;
    spvmlr_reg->lp_msb = (spvmlr_data->reg_data->lp_msb << 4) & 0x30;
    spvmlr_reg->num_rec = spvmlr_data->reg_data->num_rec;
    for (i = 0; i < spvmlr_data->reg_data->num_rec; ++i) {
        spvmlr_reg->records[i].vid = cl_hton16(spvmlr_data->reg_data->vlan_data[i].vid & 0x0FFF);
        spvmlr_reg->records[i].learn_enable = (spvmlr_data->reg_data->vlan_data[i].learn_enable == TRUE) << 7;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spvmlr(sxd_emad_spvmlr_data_t *spvmlr_data, sxd_emad_spvmlr_reg_t *spvmlr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    spvmlr_data->reg_data->num_rec = spvmlr_reg->num_rec;
    spvmlr_data->reg_data->local_port = spvmlr_reg->local_port;
    spvmlr_data->reg_data->lp_msb = (spvmlr_reg->lp_msb >> 4) & 0x3;
    for (i = 0; i < spvmlr_reg->num_rec; ++i) {
        spvmlr_data->reg_data->vlan_data[i].vid = \
            (cl_ntoh16(spvmlr_reg->records[i].vid) & 0x0FFF);
        spvmlr_data->reg_data->vlan_data[i].learn_enable = \
            (spvmlr_reg->records[i].learn_enable >> 7) & 0x01;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_spvmlr_reg_vlans_size(sxd_emad_spvmlr_data_t *spvmlr_data, uint32_t *spvmlr_reg_vlans_size)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *spvmlr_reg_vlans_size = spvmlr_data->reg_data->num_rec * sizeof(net32_t);

    SX_LOG_EXIT();
    return err;
}
