/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __EMAD_H__
#define __EMAD_H__

#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_data.h>
#include <sx/sxd/sxd_emad_buffer.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_reg.h>

#include <reg_access/sxd_access_reg_infra.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * emad_local_device_data_t structure is used to store date for
 * local device.
 */
typedef struct emad_local_device_data {
    sxd_handle handle;
} emad_local_device_data_t;

/**
 * sxd_emad_tlv_headers_t structure is for TLV markers of an EMAD buffer
 */
typedef struct sxd_emad_tlv_markers {
    sxd_emad_operation_t *operation_tlv;
    sxd_emad_string_t    *string_tlv;
    sxd_emad_latency_t   *latency_tlv;
    sxd_emad_reg_t       *reg_tlv;
    sxd_emad_end_t       *end_tlv;
} sxd_emad_tlv_markers_t;

#define SXD_EMAD_MAX_TLV_HEADERS (sizeof(sxd_emad_tlv_markers_t) / sizeof(void*))

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t emad_init(uint32_t app_id);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t emad_deinit(void);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t emad_local_device_get(const emad_local_device_data_t **dev_data);

/* get register parser callback */
sxd_status_t sxd_emad_get_reg_parser(sxd_reg_id_e         reg_id,
                                     sxd_emad_parse_cb_t *reg_parser);

/* deparse emad register */
sxd_status_t sxd_emad_deparse_rx(sxd_reg_id_e                      reg_id,
                                 struct sxd_emad_general_reg_data *reg_common_data,
                                 const void                       *reg_buff,
                                 void                             *context,
                                 sxd_sniffer_print_data_cb_t       print_data);

void sxd_emad_call_hook(sxd_dev_id_t dev_id,
                        sxd_reg_id_e reg_id,
                        uint8_t      fw_status,
                        const void  *reg_data, /* struct ku_XXX_reg */
                        const void  *operation_tlv,
                        const void  *reg_tlv,
                        const void  *latency_tlv);

/* special 'emad_common_set' for raw register */
sxd_status_t emad_common_raw_set(struct sxd_emad_general_reg_data *data_arr,
                                 uint32_t                          data_num,
                                 sxd_reg_id_e                      reg_id,
                                 sxd_emad_completion_handler_t     handler,
                                 void                             *context);


/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t emad_common_set(sxd_emad_data_t              *data_arr,
                             uint32_t                      data_num,
                             sxd_reg_id_e                  reg_id,
                             sxd_emad_completion_handler_t handler,
                             void                         *context);

struct sxd_emad_general_reg_data;
struct access_reg_emad_params;
sxd_status_t emad_common_set_ex(struct sxd_emad_general_reg_data    *data_arr,
                                uint32_t                             data_num,
                                sxd_reg_id_e                         reg_id,
                                sxd_emad_completion_handler_t        handler,
                                void                                *context,
                                const struct access_reg_emad_params* access_reg_emad_params);

sxd_status_t emad_get_tlv_headers(uint8_t                *orig_buff,
                                  uint32_t                orig_buff_size,
                                  sxd_emad_tlv_markers_t *tlv_markers);

void emad_trigger_notification(uint8_t dev_id, sxd_trap_id_t trap_id, void *buf_p, size_t buf_length);
void sync_emad_bpf_stub_func_req(void);
void sync_emad_bpf_stub_func_resp(uint32_t time);
void async_emad_bpf_stub_func_req(uint32_t reg_id, uint64_t emad_tid);
void async_emad_bpf_stub_func_resp(uint32_t reg_id, uint64_t emad_tid, uint32_t emad_latency);

#endif /* __EMAD_H__ */
