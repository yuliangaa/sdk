/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_policer.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_POLICER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_parse_qpcr(sxd_emad_qpcr_data_t *qpcr_data, sxd_emad_qpcr_reg_t *qpcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpcr_reg->lp_msb = (qpcr_data->reg_data->lp_msb & 0x03);
    qpcr_reg->port = qpcr_data->reg_data->port;
    qpcr_reg->global_pid = (qpcr_data->reg_data->global_policer & 0x03) << 14;
    qpcr_reg->global_pid |= (qpcr_data->reg_data->pid & 0x3FFF);
    qpcr_reg->global_pid = cl_hton16(qpcr_reg->global_pid);
    qpcr_reg->clear_add_counter = (qpcr_data->reg_data->clear_counter & 0x01) << 7;
    qpcr_reg->clear_add_counter |= (qpcr_data->reg_data->add_counter & 0x01) << 6;
    qpcr_reg->color_aware_bytes_ir_units_type = ((qpcr_data->reg_data->color_aware & 0x01) << 7);
    qpcr_reg->color_aware_bytes_ir_units_type |= ((qpcr_data->reg_data->use_bytes & 0x01) << 6);
    qpcr_reg->color_aware_bytes_ir_units_type |= ((qpcr_data->reg_data->ir_units & 0x01) << 4);
    qpcr_reg->color_aware_bytes_ir_units_type |= (qpcr_data->reg_data->type & 0x03);
    qpcr_reg->mode = qpcr_data->reg_data->mode & 0x03;
    qpcr_reg->cbs = qpcr_data->reg_data->committed_burst_size & 0x3F;
    qpcr_reg->ebs = qpcr_data->reg_data->extended_burst_size & 0x3F;
    qpcr_reg->cir = cl_hton32(qpcr_data->reg_data->committed_information_rate);
    qpcr_reg->eir = cl_hton32(qpcr_data->reg_data->excess_information_rate);
    qpcr_reg->exceed_action = qpcr_data->reg_data->exceed_action & 0x0F;
    qpcr_reg->violate_action = qpcr_data->reg_data->violate_action & 0x0F;
    qpcr_reg->violate_count = cl_hton64(qpcr_data->reg_data->violate_count);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpcr(sxd_emad_qpcr_data_t *qpcr_data, sxd_emad_qpcr_reg_t *qpcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpcr_data->reg_data->color_aware = (qpcr_reg->color_aware_bytes_ir_units_type >> 7) & 0x01;
    qpcr_data->reg_data->use_bytes = (qpcr_reg->color_aware_bytes_ir_units_type >> 6) & 0x01;
    qpcr_data->reg_data->ir_units = (qpcr_reg->color_aware_bytes_ir_units_type >> 4) & 0x01;
    qpcr_data->reg_data->type = qpcr_reg->color_aware_bytes_ir_units_type & 0x03;
    qpcr_data->reg_data->mode = qpcr_reg->mode & 0x03;
    qpcr_data->reg_data->committed_burst_size = (qpcr_reg->cbs) & 0x3F;
    qpcr_data->reg_data->extended_burst_size = (qpcr_reg->ebs) & 0x3F;
    qpcr_data->reg_data->committed_information_rate = cl_ntoh32(qpcr_reg->cir);
    qpcr_data->reg_data->excess_information_rate = cl_ntoh32(qpcr_reg->eir);
    qpcr_data->reg_data->exceed_action = (qpcr_reg->exceed_action) & 0x0F;
    qpcr_data->reg_data->violate_action = (qpcr_reg->violate_action) & 0x0F;
    qpcr_data->reg_data->violate_count = cl_ntoh64(qpcr_reg->violate_count);

    SX_LOG_EXIT();
    return err;
}
