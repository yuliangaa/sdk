/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __EMAD_TRANSPORT_H__
#define __EMAD_TRANSPORT_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_access_cmd.h>
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxd_emad.h>

struct emad_buffer;

/**
 * This function sets the log verbosity level of EMAD TRANSPORT MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t emad_transport_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);


/* initialize EMAD transport module */
sxd_status_t emad_transport_init(void);

/* deinitialize EMAD transport module */
sxd_status_t emad_transport_deinit(void);

/* open EMAD TX thread */
sxd_status_t emad_open_tx_thread(void);

/* close EMAD TX thread */
sxd_status_t emad_close_tx_thread(void);

/* enqueue buffer to TX thread */
uint32_t emad_tx_thread_enqueue(struct emad_buffer *emad_buffer);

/* open EMAD RX thread */
sxd_status_t emad_open_rx_thread(void);

/* close EMAD RX thread */
sxd_status_t emad_close_rx_thread(void);

#endif /* __EMAD_TRANSPORT_H__ */
