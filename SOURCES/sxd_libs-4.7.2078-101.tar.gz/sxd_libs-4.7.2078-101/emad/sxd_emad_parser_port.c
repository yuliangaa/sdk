/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_port.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_PORT

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_port_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_spmcr(sxd_emad_spmcr_data_t *spmcr_data, sxd_emad_spmcr_reg_t *spmcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spmcr_reg->swid = spmcr_data->reg_data->swid;
    spmcr_reg->local_port = spmcr_data->reg_data->local_port;
    spmcr_reg->max_sub_port = spmcr_data->reg_data->max_sub_port;
    spmcr_reg->base_stag_vid = cl_hton16(spmcr_data->reg_data->base_stag_vid & 0x0FFF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spmcr(sxd_emad_spmcr_data_t *spmcr_data, sxd_emad_spmcr_reg_t *spmcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spmcr_data->reg_data->base_stag_vid = cl_ntoh16(spmcr_reg->base_stag_vid) & 0x0FFF;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pcap(sxd_emad_pcap_data_t *pcap_data, sxd_emad_pcap_reg_t *pcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pcap_reg->local_port = pcap_data->reg_data->local_port;
    pcap_reg->lp_msb = (pcap_data->reg_data->lp_msb & 0x03) << 4;
    memcpy(pcap_reg->port_capability_mask, pcap_data->reg_data->port_capability_mask,
           sizeof(pcap_reg->port_capability_mask));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pcap(sxd_emad_pcap_data_t *pcap_data, sxd_emad_pcap_reg_t *pcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memcpy(pcap_data->reg_data->port_capability_mask, pcap_reg->port_capability_mask,
           sizeof(pcap_data->reg_data->port_capability_mask));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pmlp(sxd_emad_pmlp_data_t *pmlp_data, sxd_emad_pmlp_reg_t *pmlp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Since rx_tx and autosplit take the same byte we should OR them. */
    pmlp_reg->use_different_rx_tx = 0;
    pmlp_reg->use_different_rx_tx |= (pmlp_data->reg_data->use_different_rx_tx << 7);
    pmlp_reg->use_different_rx_tx |= (pmlp_data->reg_data->autosplit << 6);

    pmlp_reg->local_port = pmlp_data->reg_data->local_port;
    pmlp_reg->lp_msb = (pmlp_data->reg_data->lp_msb & 0x03) << 4;
    pmlp_reg->width = pmlp_data->reg_data->width;

    /* rx_lanes */
    pmlp_reg->rx_lane0 = pmlp_data->reg_data->rx_lane[0] & 0x07;
    pmlp_reg->rx_lane1 = pmlp_data->reg_data->rx_lane[1] & 0x07;
    pmlp_reg->rx_lane2 = pmlp_data->reg_data->rx_lane[2] & 0x07;
    pmlp_reg->rx_lane3 = pmlp_data->reg_data->rx_lane[3] & 0x07;
    pmlp_reg->rx_lane4 = pmlp_data->reg_data->rx_lane[4] & 0x07;
    pmlp_reg->rx_lane5 = pmlp_data->reg_data->rx_lane[5] & 0x07;
    pmlp_reg->rx_lane6 = pmlp_data->reg_data->rx_lane[6] & 0x07;
    pmlp_reg->rx_lane7 = pmlp_data->reg_data->rx_lane[7] & 0x07;

    /* tx_lanes */
    pmlp_reg->lane0 = pmlp_data->reg_data->lane[0] & 0x07;
    pmlp_reg->lane1 = pmlp_data->reg_data->lane[1] & 0x07;
    pmlp_reg->lane2 = pmlp_data->reg_data->lane[2] & 0x07;
    pmlp_reg->lane3 = pmlp_data->reg_data->lane[3] & 0x07;
    pmlp_reg->lane4 = pmlp_data->reg_data->lane[4] & 0x07;
    pmlp_reg->lane5 = pmlp_data->reg_data->lane[5] & 0x07;
    pmlp_reg->lane6 = pmlp_data->reg_data->lane[6] & 0x07;
    pmlp_reg->lane7 = pmlp_data->reg_data->lane[7] & 0x07;

    /* slot */
    pmlp_reg->slot0 = pmlp_data->reg_data->slot[0] & 0x0F;
    pmlp_reg->slot1 = pmlp_data->reg_data->slot[1] & 0x0F;
    pmlp_reg->slot2 = pmlp_data->reg_data->slot[2] & 0x0F;
    pmlp_reg->slot3 = pmlp_data->reg_data->slot[3] & 0x0F;
    pmlp_reg->slot4 = pmlp_data->reg_data->slot[4] & 0x0F;
    pmlp_reg->slot5 = pmlp_data->reg_data->slot[5] & 0x0F;
    pmlp_reg->slot6 = pmlp_data->reg_data->slot[6] & 0x0F;
    pmlp_reg->slot7 = pmlp_data->reg_data->slot[7] & 0x0F;

    /* modules */
    pmlp_reg->module0 = pmlp_data->reg_data->module[0];
    pmlp_reg->module1 = pmlp_data->reg_data->module[1];
    pmlp_reg->module2 = pmlp_data->reg_data->module[2];
    pmlp_reg->module3 = pmlp_data->reg_data->module[3];
    pmlp_reg->module4 = pmlp_data->reg_data->module[4];
    pmlp_reg->module5 = pmlp_data->reg_data->module[5];
    pmlp_reg->module6 = pmlp_data->reg_data->module[6];
    pmlp_reg->module7 = pmlp_data->reg_data->module[7];

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pmlp(sxd_emad_pmlp_data_t *pmlp_data, sxd_emad_pmlp_reg_t *pmlp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pmlp_data->reg_data->use_different_rx_tx = (pmlp_reg->use_different_rx_tx & 0x80) >> 7;
    pmlp_data->reg_data->autosplit = (pmlp_reg->use_different_rx_tx & 0x40) >> 6;
    pmlp_data->reg_data->width = pmlp_reg->width;

    /* rx_lanes */
    pmlp_data->reg_data->rx_lane[0] = pmlp_reg->rx_lane0 & 0x07;
    pmlp_data->reg_data->rx_lane[1] = pmlp_reg->rx_lane1 & 0x07;
    pmlp_data->reg_data->rx_lane[2] = pmlp_reg->rx_lane2 & 0x07;
    pmlp_data->reg_data->rx_lane[3] = pmlp_reg->rx_lane3 & 0x07;
    pmlp_data->reg_data->rx_lane[4] = pmlp_reg->rx_lane4 & 0x07;
    pmlp_data->reg_data->rx_lane[5] = pmlp_reg->rx_lane5 & 0x07;
    pmlp_data->reg_data->rx_lane[6] = pmlp_reg->rx_lane6 & 0x07;
    pmlp_data->reg_data->rx_lane[7] = pmlp_reg->rx_lane7 & 0x07;

    /* tx_lanes */
    pmlp_data->reg_data->lane[0] = pmlp_reg->lane0 & 0x07;
    pmlp_data->reg_data->lane[1] = pmlp_reg->lane1 & 0x07;
    pmlp_data->reg_data->lane[2] = pmlp_reg->lane2 & 0x07;
    pmlp_data->reg_data->lane[3] = pmlp_reg->lane3 & 0x07;
    pmlp_data->reg_data->lane[4] = pmlp_reg->lane4 & 0x07;
    pmlp_data->reg_data->lane[5] = pmlp_reg->lane5 & 0x07;
    pmlp_data->reg_data->lane[6] = pmlp_reg->lane6 & 0x07;
    pmlp_data->reg_data->lane[7] = pmlp_reg->lane7 & 0x07;

    /* slot */
    pmlp_data->reg_data->slot[0] = pmlp_reg->slot0 & 0x0F;
    pmlp_data->reg_data->slot[1] = pmlp_reg->slot1 & 0x0F;
    pmlp_data->reg_data->slot[2] = pmlp_reg->slot2 & 0x0F;
    pmlp_data->reg_data->slot[3] = pmlp_reg->slot3 & 0x0F;
    pmlp_data->reg_data->slot[4] = pmlp_reg->slot4 & 0x0F;
    pmlp_data->reg_data->slot[5] = pmlp_reg->slot5 & 0x0F;
    pmlp_data->reg_data->slot[6] = pmlp_reg->slot6 & 0x0F;
    pmlp_data->reg_data->slot[7] = pmlp_reg->slot7 & 0x0F;

    /* modules */
    pmlp_data->reg_data->module[0] = pmlp_reg->module0;
    pmlp_data->reg_data->module[1] = pmlp_reg->module1;
    pmlp_data->reg_data->module[2] = pmlp_reg->module2;
    pmlp_data->reg_data->module[3] = pmlp_reg->module3;
    pmlp_data->reg_data->module[4] = pmlp_reg->module4;
    pmlp_data->reg_data->module[5] = pmlp_reg->module5;
    pmlp_data->reg_data->module[6] = pmlp_reg->module6;
    pmlp_data->reg_data->module[7] = pmlp_reg->module7;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pfsc(sxd_emad_pfsc_data_t *pfsc_data, sxd_emad_pfsc_reg_t *pfsc_reg)
{
    sxd_status_t rc = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfsc_reg->local_port = pfsc_data->reg_data->local_port;
    pfsc_reg->lp_msb = ((pfsc_data->reg_data->lp_msb & 0x03) << 4);
    pfsc_reg->fwd_admin = pfsc_data->reg_data->fwd_admin & 0x0F;

    SX_LOG_EXIT();
    return rc;
}

sxd_status_t sxd_emad_deparse_pfsc(sxd_emad_pfsc_data_t *pfsc_data, sxd_emad_pfsc_reg_t *pfsc_reg)
{
    sxd_status_t rc = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfsc_data->reg_data->fwd_admin = pfsc_reg->fwd_admin & 0xF;
    pfsc_data->reg_data->fwd_oper = pfsc_reg->fwd_oper & 0xF;

    SX_LOG_EXIT();
    return rc;
}


sxd_status_t sxd_emad_parse_sbcm(sxd_emad_sbcm_data_t *sbcm_data, sxd_emad_sbcm_reg_t *sbcm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbcm_reg->desc = sbcm_data->reg_data->desc << 7;
    sbcm_reg->local_port = sbcm_data->reg_data->local_port;
    sbcm_reg->pg_buff = sbcm_data->reg_data->pg_buff;
    sbcm_reg->msb_dir = ((sbcm_data->reg_data->lp_msb & 0x03) << 4);
    sbcm_reg->msb_dir |= sbcm_data->reg_data->dir & 0x03;
    sbcm_reg->clr_max_buff_occupancy = cl_hton32(sbcm_data->reg_data->clr << 31);
    sbcm_reg->min_buff = cl_hton32(sbcm_data->reg_data->min_buff);
    sbcm_reg->infinite_size_max_buff =
        cl_hton32(((sbcm_data->reg_data->infinite_size & 0x01) << 31) |
                  (sbcm_data->reg_data->max_buff & 0x00FFFFFF));
    sbcm_reg->pool = sbcm_data->reg_data->pool & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbcm(sxd_emad_sbcm_data_t *sbcm_data, sxd_emad_sbcm_reg_t *sbcm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbcm_data->reg_data->desc = sbcm_reg->desc >> 7;
    sbcm_data->reg_data->local_port = sbcm_reg->local_port;
    sbcm_data->reg_data->lp_msb = (sbcm_reg->msb_dir >> 4) & 0x03;
    sbcm_data->reg_data->dir = sbcm_reg->msb_dir & 0x03;
    sbcm_data->reg_data->buff_occupancy = cl_ntoh32(sbcm_reg->buff_occupancy);
    sbcm_data->reg_data->clr = cl_ntoh32(sbcm_reg->clr_max_buff_occupancy) >> 31;
    /* mask to have the register value cleared of clr bit */
    sbcm_data->reg_data->max_buff_occupancy = cl_ntoh32(sbcm_reg->clr_max_buff_occupancy) & 0x00FFFFFF;
    sbcm_data->reg_data->min_buff = cl_ntoh32(sbcm_reg->min_buff) & 0x00FFFFFF;
    sbcm_data->reg_data->pool = sbcm_reg->pool & 0x0F;

    sbcm_data->reg_data->max_buff = cl_ntoh32(sbcm_reg->infinite_size_max_buff) & 0x00FFFFFF;
    sbcm_data->reg_data->infinite_size = (cl_ntoh32(sbcm_reg->infinite_size_max_buff) >> 31) & 0x1;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sbpm(sxd_emad_sbpm_data_t *sbpm_data, sxd_emad_sbpm_reg_t *sbpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbpm_reg->desc = sbpm_data->reg_data->desc << 7;
    sbpm_reg->local_port = sbpm_data->reg_data->local_port;
    sbpm_reg->msb_and_pool = 0;
    sbpm_reg->msb_and_pool |= (sbpm_data->reg_data->lp_msb & 0x03) << 4;
    sbpm_reg->msb_and_pool |= sbpm_data->reg_data->pool & 0xF;
    sbpm_reg->dir = sbpm_data->reg_data->dir & 0x03;
    sbpm_reg->clr_max_buff_occupancy = cl_hton32((sbpm_data->reg_data->clr) << 31);
    sbpm_reg->min_buff = cl_hton32(sbpm_data->reg_data->min_buff);

    sbpm_reg->infinite_size_max_buff =
        cl_hton32(((sbpm_data->reg_data->infinite_size & 0x01) << 31) |
                  (sbpm_data->reg_data->max_buff & 0x00FFFFFF));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbpm(sxd_emad_sbpm_data_t *sbpm_data, sxd_emad_sbpm_reg_t *sbpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbpm_data->reg_data->desc = sbpm_reg->desc >> 7;
    sbpm_data->reg_data->local_port = sbpm_reg->local_port;
    sbpm_data->reg_data->lp_msb = (sbpm_reg->msb_and_pool >> 4) & 0x03;
    sbpm_data->reg_data->pool = sbpm_reg->msb_and_pool & 0x0F;
    sbpm_data->reg_data->dir = sbpm_reg->dir & 0x03;
    sbpm_data->reg_data->buff_occupancy = cl_ntoh32(sbpm_reg->buff_occupancy);
    sbpm_data->reg_data->clr = cl_ntoh32(sbpm_reg->clr_max_buff_occupancy) >> 31;
    /* mask to have the register value cleared of clr bit */
    sbpm_data->reg_data->max_buff_occupancy = cl_ntoh32(sbpm_reg->clr_max_buff_occupancy) & 0x00FFFFFF;
    sbpm_data->reg_data->min_buff = cl_ntoh32(sbpm_reg->min_buff) & 0x00FFFFFF;

    sbpm_data->reg_data->max_buff = cl_ntoh32(sbpm_reg->infinite_size_max_buff) & 0x00FFFFFF;
    sbpm_data->reg_data->infinite_size = (cl_ntoh32(sbpm_reg->infinite_size_max_buff) >> 31) & 0x1;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pmpr(sxd_emad_pmpr_data_t *pmpr_data, sxd_emad_pmpr_reg_t *pmpr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pmpr_reg->module = pmpr_data->reg_data->module;
    pmpr_reg->attenuation5g = pmpr_data->reg_data->attenuation5g;
    pmpr_reg->attenuation7g = pmpr_data->reg_data->attenuation7g;
    pmpr_reg->attenuation12g = pmpr_data->reg_data->attenuation12g;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pmpr(sxd_emad_pmpr_data_t *pmpr_data, sxd_emad_pmpr_reg_t *pmpr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pmpr_data->reg_data->module = pmpr_reg->module;
    pmpr_data->reg_data->attenuation5g = pmpr_reg->attenuation5g;
    pmpr_data->reg_data->attenuation7g = pmpr_reg->attenuation7g;
    pmpr_data->reg_data->attenuation12g = pmpr_reg->attenuation12g;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pplm(sxd_emad_pplm_data_t *pplm_data, sxd_emad_pplm_reg_t *pplm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pplm_reg->local_port = pplm_data->reg_data->local_port;
    pplm_reg->lp_msb = (pplm_data->reg_data->lp_msb & 0x03) << 4;
    pplm_reg->port_profile_mode = pplm_data->reg_data->port_profile_mode;
    pplm_reg->static_port_profile = pplm_data->reg_data->static_port_profile;
    pplm_reg->rs_fec_correction_bypass_admin_reserved =
        (pplm_data->reg_data->rs_fec_correction_bypass_admin & 0xF) << 4;
    pplm_reg->reserved_fec_override_admin_56g = pplm_data->reg_data->fec_override_admin_56g & 0xF;
    pplm_reg->fec_override_admin_100g_fec_override_admin_50g =
        (pplm_data->reg_data->fec_override_admin_100g & 0xF) << 4;
    pplm_reg->fec_override_admin_100g_fec_override_admin_50g |= (pplm_data->reg_data->fec_override_admin_50g & 0xF);
    pplm_reg->fec_override_admin_25g_fec_override_admin_10g_40g =
        (pplm_data->reg_data->fec_override_admin_25g & 0xF) << 4;
    pplm_reg->fec_override_admin_25g_fec_override_admin_10g_40g |=
        (pplm_data->reg_data->fec_override_admin_10g_40g & 0xF);
    pplm_reg->fec_override_admin_50g_1x = cl_hton16(pplm_data->reg_data->fec_override_admin_50g_1x);
    pplm_reg->fec_override_admin_100g_2x = cl_hton16(pplm_data->reg_data->fec_override_admin_100g_2x);
    pplm_reg->fec_override_admin_200g_4x = cl_hton16(pplm_data->reg_data->fec_override_admin_200g_4x);
    pplm_reg->fec_override_admin_400g_8x = cl_hton16(pplm_data->reg_data->fec_override_admin_400g_8x);
    pplm_reg->ib_fec_override_admin_edr = cl_hton16(pplm_data->reg_data->ib_fec_override_admin_edr);
    pplm_reg->ib_fec_override_admin_fdr = cl_hton16(pplm_data->reg_data->ib_fec_override_admin_fdr);
    pplm_reg->ib_fec_override_admin_hdr = cl_hton16(pplm_data->reg_data->ib_fec_override_admin_hdr);
    pplm_reg->ib_fec_override_admin_ndr = cl_hton16(pplm_data->reg_data->ib_fec_override_admin_ndr);
    pplm_reg->ib_fec_override_admin_xdr = cl_hton16(pplm_data->reg_data->ib_fec_override_admin_xdr);
    pplm_reg->fec_override_admin_100g_1x = cl_hton16(pplm_data->reg_data->fec_override_admin_100g_1x);
    pplm_reg->fec_override_admin_200g_2x = cl_hton16(pplm_data->reg_data->fec_override_admin_200g_2x);
    pplm_reg->fec_override_admin_400g_4x = cl_hton16(pplm_data->reg_data->fec_override_admin_400g_4x);
    pplm_reg->fec_override_admin_800g_8x = cl_hton16(pplm_data->reg_data->fec_override_admin_800g_8x);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pplm(sxd_emad_pplm_data_t *pplm_data, sxd_emad_pplm_reg_t *pplm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pplm_data->reg_data->local_port = pplm_reg->local_port;
    pplm_data->reg_data->lp_msb = (pplm_reg->lp_msb >> 4) & 0x03;
    pplm_data->reg_data->port_profile_mode = pplm_reg->port_profile_mode;
    pplm_data->reg_data->static_port_profile = pplm_reg->static_port_profile;
    pplm_data->reg_data->active_port_profile = pplm_reg->active_port_profile;
    pplm_data->reg_data->retransmission_active =
        (cl_ntoh32(pplm_reg->retransmission_active_fec_mode_active) & 0xFF000000) >> 24;
    pplm_data->reg_data->fec_mode_active = (cl_ntoh32(pplm_reg->retransmission_active_fec_mode_active) & 0xFFFFFF);
    pplm_data->reg_data->rs_fec_correction_bypass_cap = (pplm_reg->rs_fec_correction_bypass_cap_reserved & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_cap_56g = pplm_reg->reserved_fec_override_cap_56g & 0x0F;
    pplm_data->reg_data->fec_override_cap_100g = (pplm_reg->fec_override_cap_100g_fec_override_cap_50g & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_cap_50g = (pplm_reg->fec_override_cap_100g_fec_override_cap_50g & 0x0F);
    pplm_data->reg_data->fec_override_cap_25g = (pplm_reg->fec_override_cap_25g_fec_override_cap_10g_40g & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_cap_10g_40g = (pplm_reg->fec_override_cap_25g_fec_override_cap_10g_40g & 0x0F);
    pplm_data->reg_data->fec_override_cap_50g_1x = cl_ntoh16(pplm_reg->fec_override_cap_50g_1x);
    pplm_data->reg_data->fec_override_cap_100g_2x = cl_ntoh16(pplm_reg->fec_override_cap_100g_2x);
    pplm_data->reg_data->fec_override_cap_200g_4x = cl_ntoh16(pplm_reg->fec_override_cap_200g_4x);
    pplm_data->reg_data->fec_override_cap_400g_8x = cl_ntoh16(pplm_reg->fec_override_cap_400g_8x);
    pplm_data->reg_data->fec_override_cap_100g_1x = cl_ntoh16(pplm_reg->fec_override_cap_100g_1x);
    pplm_data->reg_data->fec_override_cap_200g_2x = cl_ntoh16(pplm_reg->fec_override_cap_200g_2x);
    pplm_data->reg_data->fec_override_cap_400g_4x = cl_ntoh16(pplm_reg->fec_override_cap_400g_4x);
    pplm_data->reg_data->fec_override_cap_800g_8x = cl_ntoh16(pplm_reg->fec_override_cap_800g_8x);
    pplm_data->reg_data->rs_fec_correction_bypass_admin =
        (pplm_reg->rs_fec_correction_bypass_admin_reserved & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_admin_56g = pplm_reg->reserved_fec_override_admin_56g & 0x0F;
    pplm_data->reg_data->fec_override_admin_100g =
        (pplm_reg->fec_override_admin_100g_fec_override_admin_50g & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_admin_50g = (pplm_reg->fec_override_admin_100g_fec_override_admin_50g & 0x0F);
    pplm_data->reg_data->fec_override_admin_25g =
        (pplm_reg->fec_override_admin_25g_fec_override_admin_10g_40g & 0xF0) >> 4;
    pplm_data->reg_data->fec_override_admin_10g_40g =
        (pplm_reg->fec_override_admin_25g_fec_override_admin_10g_40g & 0x0F);
    pplm_data->reg_data->fec_override_admin_50g_1x = cl_ntoh16(pplm_reg->fec_override_admin_50g_1x);
    pplm_data->reg_data->fec_override_admin_100g_2x = cl_ntoh16(pplm_reg->fec_override_admin_100g_2x);
    pplm_data->reg_data->fec_override_admin_200g_4x = cl_ntoh16(pplm_reg->fec_override_admin_200g_4x);
    pplm_data->reg_data->fec_override_admin_400g_8x = cl_ntoh16(pplm_reg->fec_override_admin_400g_8x);
    pplm_data->reg_data->fec_override_admin_100g_1x = cl_ntoh16(pplm_reg->fec_override_admin_100g_1x);
    pplm_data->reg_data->fec_override_admin_200g_2x = cl_ntoh16(pplm_reg->fec_override_admin_200g_2x);
    pplm_data->reg_data->fec_override_admin_400g_4x = cl_ntoh16(pplm_reg->fec_override_admin_400g_4x);
    pplm_data->reg_data->fec_override_admin_800g_8x = cl_ntoh16(pplm_reg->fec_override_admin_800g_8x);
    pplm_data->reg_data->ib_fec_override_admin_edr = cl_ntoh16(pplm_reg->ib_fec_override_admin_edr);
    pplm_data->reg_data->ib_fec_override_admin_fdr = cl_ntoh16(pplm_reg->ib_fec_override_admin_fdr);
    pplm_data->reg_data->ib_fec_override_admin_hdr = cl_ntoh16(pplm_reg->ib_fec_override_admin_hdr);
    pplm_data->reg_data->ib_fec_override_admin_ndr = cl_ntoh16(pplm_reg->ib_fec_override_admin_ndr);
    pplm_data->reg_data->ib_fec_override_admin_xdr = cl_ntoh16(pplm_reg->ib_fec_override_admin_xdr);

    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_parse_pelc(sxd_emad_pelc_data_t *pelc_data, sxd_emad_pelc_reg_t *pelc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pelc_reg->op = (pelc_data->reg_data->op & 0xF) << 4;
    pelc_reg->local_port = pelc_data->reg_data->local_port;
    pelc_reg->lp_msb = (pelc_data->reg_data->lp_msb & 0x03) << 4;
    pelc_reg->op_admin = pelc_data->reg_data->op_admin;
    pelc_reg->op_capability = pelc_data->reg_data->op_capability;
    pelc_reg->op_request = pelc_data->reg_data->op_request;
    pelc_reg->op_active = pelc_data->reg_data->op_active;
    pelc_reg->admin = cl_hton64(pelc_data->reg_data->admin);
    pelc_reg->capability = cl_hton64(pelc_data->reg_data->capability);
    pelc_reg->request = cl_hton64(pelc_data->reg_data->request);
    pelc_reg->active = cl_hton64(pelc_data->reg_data->active);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pelc(sxd_emad_pelc_data_t *pelc_data, sxd_emad_pelc_reg_t *pelc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pelc_data->reg_data->op_admin = pelc_reg->op_admin;
    pelc_data->reg_data->op_capability = pelc_reg->op_capability;
    pelc_data->reg_data->op_request = pelc_reg->op_request;
    pelc_data->reg_data->op_active = pelc_reg->op_active;
    pelc_data->reg_data->admin = cl_ntoh64(pelc_reg->admin);
    pelc_data->reg_data->capability = cl_ntoh64(pelc_reg->capability);
    pelc_data->reg_data->request = cl_ntoh64(pelc_reg->request);
    pelc_data->reg_data->active = cl_ntoh64(pelc_reg->active);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pfcc(sxd_emad_pfcc_data_t *pfcc_data, sxd_emad_pfcc_reg_t *pfcc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfcc_reg->local_port = pfcc_data->reg_data->local_port;
    pfcc_reg->lp_msb = ((pfcc_data->reg_data->lp_msb & 0x03) << 4);
    pfcc_reg->prio_mask_tx = pfcc_data->reg_data->prio_mask_tx;
    pfcc_reg->prio_mask_rx = pfcc_data->reg_data->prio_mask_rx;
    pfcc_reg->pcftx = pfcc_data->reg_data->prio_policy_tx;
    pfcc_reg->cbftx = pfcc_data->reg_data->cb_policy_tx;
    pfcc_reg->pptx = (pfcc_data->reg_data->pause_policy_tx << 7) & 0x80;
    pfcc_reg->pptx |= ((pfcc_data->reg_data->patx << 3) & 0x18);
    pfcc_reg->pcfrx = pfcc_data->reg_data->prio_policy_rx;
    pfcc_reg->cbfrx = pfcc_data->reg_data->cb_policy_rx;
    pfcc_reg->pprx = (pfcc_data->reg_data->pause_policy_rx << 7) & 0x80;
    pfcc_reg->pprx |= ((pfcc_data->reg_data->parx << 3) & 0x18);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pfcc(sxd_emad_pfcc_data_t *pfcc_data, sxd_emad_pfcc_reg_t *pfcc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfcc_data->reg_data->prio_mask_tx = pfcc_reg->prio_mask_tx;
    pfcc_data->reg_data->prio_policy_tx = pfcc_reg->pcftx;
    pfcc_data->reg_data->pause_policy_tx = (pfcc_reg->pptx >> 7) & 0x01;
    pfcc_data->reg_data->patx = (pfcc_reg->pptx >> 3) & 0x03;
    pfcc_data->reg_data->cb_policy_tx = pfcc_reg->cbftx;
    pfcc_data->reg_data->prio_mask_rx = pfcc_reg->prio_mask_rx;
    pfcc_data->reg_data->prio_policy_rx = pfcc_reg->pcfrx;
    pfcc_data->reg_data->cb_policy_rx = pfcc_reg->cbfrx;
    pfcc_data->reg_data->pause_policy_rx = (pfcc_reg->pprx >> 7) & 0x01;
    pfcc_data->reg_data->parx = (pfcc_reg->pprx >> 3) & 0x03;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_plib(sxd_emad_plib_data_t *plib_data, sxd_emad_plib_reg_t *plib_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    plib_reg->local_port = plib_data->reg_data->local_port;
    plib_reg->lp_msb = (plib_data->reg_data->lp_msb & 0x03) << 4;
    plib_reg->ib_port = plib_data->reg_data->ib_port;
    plib_reg->split_num = plib_data->reg_data->split_num;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_plib(sxd_emad_plib_data_t *plib_data, sxd_emad_plib_reg_t *plib_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    plib_data->reg_data->ib_port = plib_reg->ib_port;
    plib_data->reg_data->local_port = plib_reg->local_port;
    plib_data->reg_data->lp_msb = (plib_reg->lp_msb >> 4) & 0x3;
    plib_data->reg_data->split_num = plib_reg->split_num;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pptb(sxd_emad_pptb_data_t *pptb_data, sxd_emad_pptb_reg_t *pptb_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pptb_reg->mapping_mode = pptb_data->reg_data->mapping_mode;
    pptb_reg->local_port = pptb_data->reg_data->local_port;
    pptb_reg->msb_cm_um = ((pptb_data->reg_data->lp_msb & 0x03) << 4);
    pptb_reg->msb_cm_um |= (pptb_data->reg_data->cm ? (1 << 1) : 0);
    pptb_reg->msb_cm_um |= (pptb_data->reg_data->um ? 1 : 0);
    pptb_reg->pm = pptb_data->reg_data->pm;
    pptb_reg->prio_15_14_buff = (pptb_data->reg_data->prio_15_buff << 4) & 0xF0;
    pptb_reg->prio_15_14_buff |= (pptb_data->reg_data->prio_14_buff & 0x0F);
    pptb_reg->prio_13_12_buff = (pptb_data->reg_data->prio_13_buff << 4) & 0xF0;
    pptb_reg->prio_13_12_buff |= (pptb_data->reg_data->prio_12_buff & 0x0F);
    pptb_reg->prio_11_10_buff = (pptb_data->reg_data->prio_11_buff << 4) & 0xF0;
    pptb_reg->prio_11_10_buff |= (pptb_data->reg_data->prio_10_buff & 0x0F);
    pptb_reg->prio_9_8_buff = (pptb_data->reg_data->prio_9_buff << 4) & 0xF0;
    pptb_reg->prio_9_8_buff |= pptb_data->reg_data->prio_8_buff & 0x0F;
    pptb_reg->prio_7_6_buff = (pptb_data->reg_data->prio_7_buff << 4) & 0xF0;
    pptb_reg->prio_7_6_buff |= (pptb_data->reg_data->prio_6_buff & 0x0F);
    pptb_reg->prio_5_4_buff = (pptb_data->reg_data->prio_5_buff << 4) & 0xF0;
    pptb_reg->prio_5_4_buff |= (pptb_data->reg_data->prio_4_buff & 0x0F);
    pptb_reg->prio_3_2_buff = (pptb_data->reg_data->prio_3_buff << 4) & 0xF0;
    pptb_reg->prio_3_2_buff |= (pptb_data->reg_data->prio_2_buff & 0x0F);
    pptb_reg->prio_1_0_buff = (pptb_data->reg_data->prio_1_buff << 4) & 0xF0;
    pptb_reg->prio_1_0_buff |= pptb_data->reg_data->prio_0_buff & 0x0F;
    pptb_reg->ctrl_untagged_buff = (pptb_data->reg_data->ctrl_buff << 4) & 0xF0;
    pptb_reg->ctrl_untagged_buff |= pptb_data->reg_data->untagged_buff & 0x0F;

    pptb_reg->prio_buff_msb = pptb_data->reg_data->prio_buff_msb;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pptb(sxd_emad_pptb_data_t *pptb_data, sxd_emad_pptb_reg_t *pptb_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pptb_data->reg_data->mapping_mode = pptb_reg->mapping_mode;
    pptb_data->reg_data->local_port = pptb_reg->local_port;
    pptb_data->reg_data->lp_msb = (pptb_reg->msb_cm_um >> 4) & 0x03;
    pptb_data->reg_data->cm = (pptb_reg->msb_cm_um >> 1) & 0x1;
    pptb_data->reg_data->um = pptb_reg->msb_cm_um & 0x1;
    pptb_data->reg_data->pm = pptb_reg->prio_buff_msb;
    pptb_data->reg_data->prio_15_buff = (pptb_reg->prio_15_14_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_14_buff = pptb_reg->prio_15_14_buff & 0x0F;
    pptb_data->reg_data->prio_13_buff = (pptb_reg->prio_13_12_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_12_buff = pptb_reg->prio_13_12_buff & 0x0F;
    pptb_data->reg_data->prio_11_buff = (pptb_reg->prio_11_10_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_10_buff = pptb_reg->prio_11_10_buff & 0x0F;
    pptb_data->reg_data->prio_9_buff = (pptb_reg->prio_9_8_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_8_buff = pptb_reg->prio_9_8_buff & 0x0F;
    pptb_data->reg_data->prio_7_buff = (pptb_reg->prio_7_6_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_6_buff = pptb_reg->prio_7_6_buff & 0x0F;
    pptb_data->reg_data->prio_5_buff = (pptb_reg->prio_5_4_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_4_buff = pptb_reg->prio_5_4_buff & 0x0F;
    pptb_data->reg_data->prio_3_buff = (pptb_reg->prio_3_2_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_2_buff = pptb_reg->prio_3_2_buff & 0x0F;
    pptb_data->reg_data->prio_1_buff = (pptb_reg->prio_1_0_buff >> 4) & 0x0F;
    pptb_data->reg_data->prio_0_buff = pptb_reg->prio_1_0_buff & 0x0F;
    pptb_data->reg_data->ctrl_buff = (pptb_reg->ctrl_untagged_buff >> 4) & 0x0F;
    pptb_data->reg_data->untagged_buff = pptb_reg->ctrl_untagged_buff & 0x0F;
    pptb_data->reg_data->prio_buff_msb = pptb_reg->prio_buff_msb;


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pbmc(sxd_emad_pbmc_data_t *pbmc_data, sxd_emad_pbmc_reg_t *pbmc_reg)
{
    uint8_t      i;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pbmc_reg->local_port = pbmc_data->reg_data->local_port;
    pbmc_reg->lp_msb = (pbmc_data->reg_data->lp_msb & 0x03) << 4;
    pbmc_reg->xof_timer_value = cl_hton16(pbmc_data->reg_data->xof_timer_value);
    pbmc_reg->xof_refresh = cl_hton16(pbmc_data->reg_data->xof_refresh);

    for (i = 0; i < SXD_PORT_PBMC_NUM_BUFF; ++i) {
        pbmc_reg->buffer[i].lossy_epsb = (((pbmc_data->reg_data->buffer[i].lossy & 0x1) << 1) |
                                          (pbmc_data->reg_data->buffer[i].epsb & 0x1));
        pbmc_reg->buffer[i].size = cl_hton16(pbmc_data->reg_data->buffer[i].size & 0xFFFF);
        pbmc_reg->buffer[i].xof_threshold = cl_hton16(pbmc_data->reg_data->buffer[i].xof_threshold);
        pbmc_reg->buffer[i].xon_threshold = cl_hton16(pbmc_data->reg_data->buffer[i].xon_threshold);
    }

    pbmc_reg->port_shared_buffer.size = cl_hton16(pbmc_data->reg_data->port_shared_buffer.size & 0xFFFF);
    pbmc_reg->port_shared_buffer.xof_threshold = cl_hton16(pbmc_data->reg_data->port_shared_buffer.xof_threshold);
    pbmc_reg->port_shared_buffer.xon_threshold = cl_hton16(pbmc_data->reg_data->port_shared_buffer.xon_threshold);

    pbmc_reg->shared_headroom_pool.size = cl_hton16(pbmc_data->reg_data->shared_headroom_pool.size & 0xFFFF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pbmc(sxd_emad_pbmc_data_t *pbmc_data, sxd_emad_pbmc_reg_t *pbmc_reg)
{
    uint8_t      i;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pbmc_data->reg_data->xof_timer_value = cl_ntoh16(pbmc_reg->xof_timer_value);
    pbmc_data->reg_data->xof_refresh = cl_ntoh16(pbmc_reg->xof_refresh);
    pbmc_data->reg_data->port_buffer_size = cl_ntoh16(pbmc_reg->port_buffer_size);

    for (i = 0; i < SXD_PORT_PBMC_NUM_BUFF; ++i) {
        pbmc_data->reg_data->buffer[i].size = cl_ntoh16(pbmc_reg->buffer[i].size);
        pbmc_data->reg_data->buffer[i].xof_threshold = cl_ntoh16(pbmc_reg->buffer[i].xof_threshold);
        pbmc_data->reg_data->buffer[i].xon_threshold = cl_ntoh16(pbmc_reg->buffer[i].xon_threshold);
        pbmc_data->reg_data->buffer[i].lossy = (pbmc_reg->buffer[i].lossy_epsb >> 1) & 0x1;
        pbmc_data->reg_data->buffer[i].epsb = pbmc_reg->buffer[i].lossy_epsb & 0x1;
    }

    pbmc_data->reg_data->port_shared_buffer.size = cl_ntoh16(pbmc_reg->port_shared_buffer.size);
    pbmc_data->reg_data->port_shared_buffer.xof_threshold = cl_ntoh16(pbmc_reg->port_shared_buffer.xof_threshold);
    pbmc_data->reg_data->port_shared_buffer.xon_threshold = cl_ntoh16(pbmc_reg->port_shared_buffer.xon_threshold);

    pbmc_data->reg_data->shared_headroom_pool.size = cl_ntoh16(pbmc_reg->shared_headroom_pool.size);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sbpr(sxd_emad_sbpr_data_t *sbpr_data, sxd_emad_sbpr_reg_t *sbpr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbpr_reg->desc_and_dir = (sbpr_data->reg_data->desc << 7) | (sbpr_data->reg_data->direction & 0x03);
    sbpr_reg->pool_id = sbpr_data->reg_data->pool_id & 0x0F;
    sbpr_reg->infi_size_and_size =
        cl_hton32(((sbpr_data->reg_data->infinite_size & 0x01) << 31) | (sbpr_data->reg_data->size & 0x00FFFFFF));
    sbpr_reg->mode = sbpr_data->reg_data->mode & 0x0F;
    sbpr_reg->clr_and_max_buff_occupancy = cl_hton32(sbpr_data->reg_data->clear << 31);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbpr(sxd_emad_sbpr_data_t *sbpr_data, sxd_emad_sbpr_reg_t *sbpr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbpr_data->reg_data->desc = sbpr_reg->desc_and_dir >> 7;
    sbpr_data->reg_data->direction = sbpr_reg->desc_and_dir & 0x03;
    sbpr_data->reg_data->pool_id = sbpr_reg->pool_id & 0x0F;
    sbpr_data->reg_data->size = cl_ntoh32(sbpr_reg->infi_size_and_size) & 0x00FFFFFF;
    sbpr_data->reg_data->infinite_size = (cl_ntoh32(sbpr_reg->infi_size_and_size) >> 31) & 0x1;
    sbpr_data->reg_data->mode = sbpr_reg->mode & 0x0F;
    sbpr_data->reg_data->current_occupancy = cl_ntoh32(sbpr_reg->curr_buff_occupancy) & 0x00FFFFFF;
    sbpr_data->reg_data->current_ext_occupancy = cl_ntoh32(sbpr_reg->ext_buff_occupancy) & 0x00FFFFFF;
    sbpr_data->reg_data->clear = cl_ntoh32(sbpr_reg->clr_and_max_buff_occupancy) >> 31;
    sbpr_data->reg_data->max_occupancy = cl_ntoh32(sbpr_reg->clr_and_max_buff_occupancy) & 0x00FFFFFF;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pspa(sxd_emad_pspa_data_t *pspa_data, sxd_emad_pspa_reg_t *pspa_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pspa_reg->swid = pspa_data->reg_data->swid;
    pspa_reg->local_port = pspa_data->reg_data->local_port;
    pspa_reg->sub_port = pspa_data->reg_data->sub_port;
    pspa_reg->lp_msb = pspa_data->reg_data->lp_msb;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pspa(sxd_emad_pspa_data_t *pspa_data, sxd_emad_pspa_reg_t *pspa_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pspa_data->reg_data->swid = pspa_reg->swid;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qpbr(sxd_emad_qpbr_data_t *qpbr_data, sxd_emad_qpbr_reg_t *qpbr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpbr_reg->op_and_lp_msb = (qpbr_data->reg_data->operation & 0x03) << 6;
    qpbr_reg->op_and_lp_msb |= (qpbr_data->reg_data->lp_msb & 0x03);
    qpbr_reg->port = qpbr_data->reg_data->port;
    qpbr_reg->g_pid = (qpbr_data->reg_data->global_policer & 0x1) << 15;
    qpbr_reg->g_pid |= (qpbr_data->reg_data->pid & 0x3FFF);
    qpbr_reg->g_pid = cl_hton16(qpbr_reg->g_pid);
    qpbr_reg->flow_metering_buff = qpbr_data->reg_data->unicast & 0x1;
    qpbr_reg->flow_metering_buff |= (qpbr_data->reg_data->multicast ? (1 << 1) : 0);
    qpbr_reg->flow_metering_buff |= (qpbr_data->reg_data->broadcast ? (1 << 2) : 0);
    qpbr_reg->flow_metering_buff |= (qpbr_data->reg_data->unknown_unicast ? (1 << 3) : 0);
    qpbr_reg->flow_metering_buff |= (qpbr_data->reg_data->unregistered_multicast ? (1 << 4) : 0);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpbr(sxd_emad_qpbr_data_t *qpbr_data, sxd_emad_qpbr_reg_t *qpbr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpbr_data->reg_data->operation = (qpbr_reg->op_and_lp_msb >> 6) & 0x03;
    qpbr_data->reg_data->lp_msb = (qpbr_reg->op_and_lp_msb) & 0x03;
    qpbr_data->reg_data->port = qpbr_reg->port;
    qpbr_data->reg_data->global_policer = (cl_ntoh16(qpbr_reg->g_pid) >> 15) & 0x1;
    qpbr_data->reg_data->pid = cl_ntoh16(qpbr_reg->g_pid) & 0x3FFF;
    qpbr_data->reg_data->unicast = qpbr_reg->flow_metering_buff & 0x1;
    qpbr_data->reg_data->multicast = (qpbr_reg->flow_metering_buff >> 1) & 0x1;
    qpbr_data->reg_data->broadcast = (qpbr_reg->flow_metering_buff >> 2) & 0x1;
    qpbr_data->reg_data->unknown_unicast = (qpbr_reg->flow_metering_buff >> 3) & 0x1;
    qpbr_data->reg_data->unregistered_multicast = (qpbr_reg->flow_metering_buff >> 4) & 0x1;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_plbf(sxd_emad_plbf_data_t *plbf_data, sxd_emad_plbf_reg_t *plbf_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    plbf_reg->lbf_mode = plbf_data->reg_data->lbf_mode;
    plbf_reg->port = plbf_data->reg_data->port;
    plbf_reg->lp_msb = ((plbf_data->reg_data->lp_msb & 0x03) << 4);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_plbf(sxd_emad_plbf_data_t *plbf_data, sxd_emad_plbf_reg_t *plbf_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    plbf_data->reg_data->lbf_mode = plbf_reg->lbf_mode;
    plbf_data->reg_data->port = plbf_reg->port;
    plbf_data->reg_data->lp_msb = (plbf_reg->lp_msb >> 4) & 0x3;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pifr(sxd_emad_pifr_data_t *pifr_data, sxd_emad_pifr_reg_t *pifr_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0;
    uint32_t     j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pifr_reg->table_id = (pifr_data->reg_data->table_id & 0x0f) << 4;
    pifr_reg->local_port = pifr_data->reg_data->local_port;
    pifr_reg->lp_msb = ((pifr_data->reg_data->lp_msb & 0x03) << 4);

    for (j = 0; j < PIFR_MAX_PORTS;) {
        offset = (PIFR_MAX_PORTS - 1 - j) >> 5;
        value = 0;
        mask_value = 0;
        for (k = 0; k < 32; ++k, ++j) {
            bit = (pifr_data->reg_data->ports_bitmap[j]) & 0x01;
            value |= bit << k;
            bit = (pifr_data->reg_data->mask_bitmap[j]) & 0x01;
            mask_value |= bit << k;
        }
        pifr_reg->ports_bitmap[offset] = cl_hton32(value);
        pifr_reg->mask_bitmap[offset] = cl_hton32(mask_value);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pifr(sxd_emad_pifr_data_t *pifr_data, sxd_emad_pifr_reg_t *pifr_reg)
{
    uint32_t     value = 0, mask_value = 0, bit = 0, offset = 0;
    uint32_t     j = 0, k = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pifr_data->reg_data->table_id = (pifr_reg->table_id >> 4) & 0x0f;
    pifr_data->reg_data->local_port = pifr_reg->local_port;
    pifr_data->reg_data->lp_msb = ((pifr_reg->lp_msb >> 4) & 0x03);

    memset(pifr_data->reg_data->ports_bitmap, 0, sizeof(pifr_data->reg_data->ports_bitmap));
    memset(pifr_data->reg_data->mask_bitmap, 0, sizeof(pifr_data->reg_data->mask_bitmap));

    for (j = 0; j < PIFR_MAX_PORTS;) {
        offset = (PIFR_MAX_PORTS - 1 - j) >> 5;
        value = cl_ntoh32(pifr_reg->ports_bitmap[offset]);
        mask_value = cl_ntoh32(pifr_reg->mask_bitmap[offset]);
        for (k = 0; k < 32; ++k, ++j) {
            bit = (value >> k) & 0x01;
            pifr_data->reg_data->ports_bitmap[j] = bit;
            bit = (mask_value >> k) & 0x01;
            pifr_data->reg_data->mask_bitmap[j] = bit;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_pmpc(sxd_emad_pmpc_data_t *pmpc_data, sxd_emad_pmpc_reg_t *pmpc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < 8; i++) {
        pmpc_reg->module_state_updated_bitmap[i] = cl_hton32(pmpc_data->reg_data->module_state_updated_bitmap[i]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pmpc(sxd_emad_pmpc_data_t *pmpc_data, sxd_emad_pmpc_reg_t *pmpc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < 8; i++) {
        pmpc_data->reg_data->module_state_updated_bitmap[i] = cl_ntoh32(pmpc_reg->module_state_updated_bitmap[i]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mpsc(sxd_emad_mpsc_data_t *mpsc_data, sxd_emad_mpsc_reg_t *mpsc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpsc_reg->port = mpsc_data->reg_data->local_port;
    mpsc_reg->lp_msb = (mpsc_data->reg_data->lp_msb & 0x03) << 4;
    mpsc_reg->c_e = (mpsc_data->reg_data->clear_count & 0x01) << 7;
    mpsc_reg->c_e |= (mpsc_data->reg_data->enable & 0x01) << 6;
    mpsc_reg->c_e |= (mpsc_data->reg_data->cong & 0x01) << 5;
    mpsc_reg->rate = cl_hton32(mpsc_data->reg_data->rate);
    mpsc_reg->count_sample_drops = cl_hton64(mpsc_data->reg_data->count_drops);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mpsc(sxd_emad_mpsc_data_t *mpsc_data, sxd_emad_mpsc_reg_t *mpsc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mpsc_data->reg_data->local_port = mpsc_reg->port;
    mpsc_data->reg_data->lp_msb = (mpsc_reg->lp_msb >> 4) & 0x03;
    mpsc_data->reg_data->clear_count = (mpsc_reg->c_e >> 7) & 0x01;
    mpsc_data->reg_data->enable = (mpsc_reg->c_e >> 6) & 0x01;
    mpsc_data->reg_data->cong = (mpsc_reg->c_e >> 5) & 0x01;
    mpsc_data->reg_data->rate = cl_ntoh32(mpsc_reg->rate);
    mpsc_data->reg_data->count_drops = cl_ntoh64(mpsc_reg->count_sample_drops);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mlcr(sxd_emad_mlcr_data_t *mlcr_data, sxd_emad_mlcr_reg_t *mlcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mlcr_reg->local_port = mlcr_data->reg_data->local_port;
    mlcr_reg->lp_msb = mlcr_data->reg_data->lp_msb & 0x3;
    mlcr_reg->cap_local_led_type = (mlcr_data->reg_data->led_type) & 0xf;
    mlcr_reg->beacon_duration = cl_hton16(mlcr_data->reg_data->beacon_duration);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mlcr(sxd_emad_mlcr_data_t *mlcr_data, sxd_emad_mlcr_reg_t *mlcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mlcr_data->reg_data->local_port = mlcr_reg->local_port;
    mlcr_data->reg_data->lp_msb = mlcr_reg->lp_msb & 0x3;
    mlcr_data->reg_data->led_type = mlcr_reg->cap_local_led_type & 0xf;
    mlcr_data->reg_data->cap_local_or_uid_only = ((mlcr_reg->cap_local_led_type >> 4) & 0x01);
    mlcr_data->reg_data->beacon_duration = cl_ntoh16(mlcr_reg->beacon_duration);
    mlcr_data->reg_data->beacon_remain = cl_ntoh16(mlcr_reg->beacon_remain);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mdri(sxd_emad_mdri_data_t *mdri_data, sxd_emad_mdri_reg_t *mdri_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mdri_reg->clear = mdri_data->reg_data->clear;
    mdri_reg->read = mdri_data->reg_data->read;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mdri(sxd_emad_mdri_data_t *mdri_data, sxd_emad_mdri_reg_t *mdri_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    mdri_data->reg_data->clear = mdri_reg->clear;
    mdri_data->reg_data->read = mdri_reg->read;
    for (i = 0; i < 8; i++) {
        mdri_data->reg_data->global_reasons[i] = cl_ntoh32(mdri_reg->global_reasons[i]);
        mdri_data->reg_data->port_reasons[i] = cl_ntoh32(mdri_reg->port_reasons[i]);
        mdri_data->reg_data->buffer_reasons[i] = cl_ntoh32(mdri_reg->buffer_reasons[i]);
        mdri_data->reg_data->ethernet_reasons[i] = cl_ntoh32(mdri_reg->ethernet_reasons[i]);
        mdri_data->reg_data->ip_reasons[i] = cl_ntoh32(mdri_reg->ip_reasons[i]);
        mdri_data->reg_data->mpls_reasons[i] = cl_ntoh32(mdri_reg->mpls_reasons[i]);
        mdri_data->reg_data->tunnel_reasons[i] = cl_ntoh32(mdri_reg->tunnel_reasons[i]);
        mdri_data->reg_data->host_reasons[i] = cl_ntoh32(mdri_reg->host_reasons[i]);
    }

    SX_LOG_EXIT();
    return err;
}
