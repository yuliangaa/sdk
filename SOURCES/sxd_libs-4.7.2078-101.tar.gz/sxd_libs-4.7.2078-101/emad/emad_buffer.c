/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "emad_transport.h"
#include "emad_transaction.h"
#include "emad_buffer.h"
#include "emad.h"
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ EMAD_BUFFER


static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t    __emad_buffer_pool;
static cl_spinlock_t __emad_buffer_pool_lock;

static cl_status_t __emad_buffer_construct(void *const p_object, void *context, cl_pool_item_t **const pp_pool_item)
{
    struct emad_buffer *emad_buffer = (struct emad_buffer*)p_object;

    UNUSED_PARAM(context);

    memset(emad_buffer->prm_reg_buff, 0, sizeof(emad_buffer->prm_reg_buff));
    *pp_pool_item = &emad_buffer->pool_item;
    return 0;
}


sxd_status_t emad_buffer_init(void)
{
    cl_status_t cl_st = CL_SUCCESS;

    cl_st = cl_spinlock_init(&__emad_buffer_pool_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to initialize emad buffer pool lock (err=%d)\n", cl_st);
        goto pool_lock_failed;
    }

    cl_st = CL_QPOOL_INIT(&__emad_buffer_pool,
                          1024,
                          CL_POOL_UNLIMITED_MAX_SIZE,
                          1024,
                          sizeof(struct emad_buffer),
                          __emad_buffer_construct,
                          NULL,
                          NULL);

    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to initialize emad buffer pool (err=%d)\n", cl_st);
        goto pool_failed;
    }

    return SXD_STATUS_SUCCESS;

pool_failed:
    cl_spinlock_destroy(&__emad_buffer_pool_lock);

pool_lock_failed:
    return SXD_STATUS_ERROR;
}


void emad_buffer_deinit(void)
{
    cl_spinlock_destroy(&__emad_buffer_pool_lock);
    CL_QPOOL_DESTROY(&__emad_buffer_pool);
}


sxd_status_t emad_buffer_alloc(sxd_reg_id_e                      reg_id,
                               boolean_t                         is_raw_reg,
                               struct sxd_emad_general_reg_data *general_reg_data,
                               struct emad_buffer              **buffer)
{
    struct emad_buffer *emad_buffer;
    cl_pool_item_t     *pool_item;
    sxd_status_t        sxd_st;
    boolean_t           transaction_mode;

    cl_spinlock_acquire(&__emad_buffer_pool_lock);
    pool_item = cl_qpool_get(&__emad_buffer_pool);
    cl_spinlock_release(&__emad_buffer_pool_lock);

    if (pool_item == NULL) {
        return SXD_STATUS_NO_MEMORY;
    }

    emad_buffer = PARENT_STRUCT(pool_item, struct emad_buffer, pool_item);
    emad_buffer->tr_state = EMAD_TR_STATE_ALLOCATED;
    EMAD_BUFFER_DEV_ID(emad_buffer) = general_reg_data->common.dev_id;
    EMAD_BUFFER_ACCESS_CMD(emad_buffer) = general_reg_data->common.access_cmd;
    EMAD_BUFFER_MODE(emad_buffer) = general_reg_data->common.mode;

    if ((((int)EMAD_BUFFER_MODE(emad_buffer)) < SXD_ACCESS_MODE_MIN) ||
        (((int)EMAD_BUFFER_MODE(emad_buffer)) > SXD_ACCESS_MODE_MAX)) {
        SX_LOG_NTC("reg-meta-mode is not initialized! (reg=0x%x)!\n", reg_id);
        EMAD_BUFFER_MODE(emad_buffer) = SXD_ACCESS_MODE_DEFAULT;
    }

    emad_buffer->gen_reg_data.reg_data = general_reg_data->reg_data;
    emad_buffer->reg_id = reg_id;
    emad_buffer->is_raw_reg = is_raw_reg;
    emad_buffer->emad_latency = 0;
    emad_buffer->cache_read_time = 0;

    if ((EMAD_BUFFER_ACCESS_CMD(emad_buffer) == SXD_ACCESS_CMD_GET) ||
        (EMAD_BUFFER_ACCESS_CMD(emad_buffer) == SXD_ACCESS_CMD_GET_ALL) ||
        is_raw_reg) {
        EMAD_BUFFER_MODE(emad_buffer) = SXD_ACCESS_MODE_SYNC_DEPARSE; /* 'GET' command or RAW-register are always sync & deparse */
    } else if (EMAD_BUFFER_MODE(emad_buffer) == SXD_ACCESS_MODE_DEFAULT) { /* 'SET' command with SXD_ACCESS_MODE_DEFAULT */
        sxd_st = sxd_emad_transaction_mode_get(&transaction_mode);
        if (sxd_st != SXD_STATUS_SUCCESS) {
            transaction_mode = FALSE; /* sync mode (classic) */
        }

        if (transaction_mode) {
            EMAD_BUFFER_MODE(emad_buffer) = SXD_ACCESS_MODE_ASYNC;
        } else {
            EMAD_BUFFER_MODE(emad_buffer) = SXD_ACCESS_MODE_SYNC_NO_DEPARSE;
        }
    }

    *buffer = emad_buffer;
    return SXD_STATUS_SUCCESS;
}


void emad_buffer_dealloc(struct emad_buffer *emad_buffer)
{
    /* EMAD reg-parser do not put 0 for reserved fields so we have to clear the buffer before some other
     * register will use it and leave reserved fields uninitialized */
    if ((emad_buffer->reg_size > 0) && (emad_buffer->reg_size <= sizeof(emad_buffer->prm_reg_buff))) {
        memset(emad_buffer->prm_reg_buff, 0, emad_buffer->reg_size);
    }

    cl_spinlock_acquire(&__emad_buffer_pool_lock);
    cl_qpool_put(&__emad_buffer_pool, &emad_buffer->pool_item);
    cl_spinlock_release(&__emad_buffer_pool_lock);
}


static uint32_t __get_emad_wait_timeout(uint32_t queue_size)
{
    uint32_t emad_timeout;

    /* sxd_emad_timeout_get() returns a global variable that can be changed in other flow.
     * let's copy it to local variable so the current function will have consistent value
     * of EMAD timeout and we don't have to worry about races.
     */

    sxd_emad_timeout_get(&emad_timeout);

    if (queue_size == 1) { /* 99.99% of the times */
        goto out;
    }

    if (emad_timeout > SXD_MAX_EMAD_TIMEOUT_USEC) {
        /* for debug purpose, one can set the EMAD timeout to a large value.
         * in this case, we'll just respect it and return this value as is.
         */
        goto out;
    }

    /* check uint32_t overflow for (emad_timeout * queue_size) */
    if (emad_timeout > (SXD_MAX_EMAD_TIMEOUT_USEC) / queue_size) {
        /* in this case, we're going to wait as long as we allowed to */
        emad_timeout = SXD_MAX_EMAD_TIMEOUT_USEC;
    } else {
        emad_timeout *= queue_size; /* still not exceed the maximum allowed timeout */
    }

out:
    return emad_timeout;
}

static void __notify_emad_timeout(uint8_t dev_id)
{
    sxd_event_health_notification_t sdk_health;

    memset(&sdk_health, 0, sizeof(sdk_health));

    sdk_health.device_id = dev_id;
    sdk_health.cause = SXD_HEALTH_CAUSE_EMAD_TIMEOUT;
    sdk_health.severity = SXD_HEALTH_SEVERITY_WARN;
    sdk_health.irisc_id = DBG_ALL_IRISCS;
    sdk_health.was_debug_started = FALSE;
    emad_trigger_notification(dev_id, SXD_TRAP_ID_SDK_HEALTH_EVENT, &sdk_health, sizeof(sdk_health));
}

sxd_status_t emad_buffer_enqueue(struct emad_buffer *emad_buffer)
{
    sxd_status_t                 sxd_st = SXD_STATUS_SUCCESS;
    cl_status_t                  cl_st = CL_SUCCESS;
    cl_event_t                   sync_event;
    uint32_t                     emad_timeout;
    uint32_t                     queue_size;
    boolean_t                    sdk_health_en = FALSE;
    ku_dbg_health_check_params_t ku_dbg_health_check_params;

    if ((EMAD_BUFFER_MODE(emad_buffer) == SXD_ACCESS_MODE_SYNC_DEPARSE) ||
        (EMAD_BUFFER_MODE(emad_buffer) == SXD_ACCESS_MODE_SYNC_NO_DEPARSE)) {
        emad_buffer->sync_event = &sync_event;
        cl_st = cl_event_init(emad_buffer->sync_event, FALSE);
        if (cl_st != CL_SUCCESS) {
            sxd_st = SXD_STATUS_ERROR;
            goto out;
        }
    } else {
        emad_buffer->sync_event = NULL;
    }

    emad_buffer->notif_tid = emad_transaction_alloc_notification_id();
    sxd_st = emad_transaction_call_tx_callback(emad_buffer->notif_tid);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        emad_buffer_dealloc(emad_buffer);
        goto out;
    }

    queue_size = emad_tx_thread_enqueue(emad_buffer);

    if (emad_buffer->sync_event) {
        emad_timeout = __get_emad_wait_timeout(queue_size);

        do {
            /* the duration we're going to wait depends on two parameters:
             * 1. the configured timeout for a single EMAD
             * 2. the number of EMAD buffers currently in the queue and waiting for reply
             */
            cl_st = cl_event_wait_on(emad_buffer->sync_event, emad_timeout, TRUE);
        } while (cl_st == CL_NOT_DONE);

        if (cl_st == CL_TIMEOUT) {
            sxd_st = sxd_access_sdk_health_state_get(EMAD_BUFFER_DEV_ID(emad_buffer), TRUE, &sdk_health_en);
            if (sxd_st != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Fail to read sdk_health status in driver, no sdk_health trap will be called\n");
                sdk_health_en = FALSE;
            }
            if (TRUE == sxd_health_check_active_get()) {
                memset(&ku_dbg_health_check_params, 0, sizeof(ku_dbg_health_check_params));
                ku_dbg_health_check_params.dev_id = EMAD_BUFFER_DEV_ID(emad_buffer);
                ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd =
                    SXD_HEALTH_FATAL_FAILURE_ADD_EMAD_TIMEOUT_FAILURE_E;
                ku_dbg_health_check_params.params.emad_timeout_info.reg_id = emad_buffer->reg_id;
                ku_dbg_health_check_params.params.emad_timeout_info.usecs = emad_timeout;

                sxd_st = sxd_access_sdk_fatal_failure_detection_info_set(&ku_dbg_health_check_params);
                if (sxd_st != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to set failure detection information to the driver with emad timeout cmd, error (%d)\n",
                        sxd_st);
                    goto out;
                }
            }
            /* this 2 enables  are mutually exclusive!, and only one can be used
             * in a single SDK life cycle.*/
            else if (sdk_health_en) {
                __notify_emad_timeout(EMAD_BUFFER_DEV_ID(emad_buffer));
            }


            /*
             * if we get here, there are two options:
             * 1. TX thread has not yet pulled the buffer from the queue.
             * 2. RX thread did not signal the event for this TID.
             */
            emad_transaction_timeout(emad_buffer, emad_timeout);
            sxd_st = SXD_STATUS_TIMEOUT;
            /* buffer is deallocated elsewhere [by emad_transaction_timeout(), RX or TX thread] */
        } else {
            sxd_st = emad_buffer->status;
            emad_buffer_dealloc(emad_buffer);
        }
    }

out:
    return sxd_st;
}
