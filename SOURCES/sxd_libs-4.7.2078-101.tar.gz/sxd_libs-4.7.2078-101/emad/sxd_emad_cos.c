/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_cos.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_COS

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t sxd_emad_cos_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_qpdp_set(sxd_emad_qpdp_data_t         *qpdp_data_arr,
                               uint32_t                      qpdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdp_data_arr == NULL) || (qpdp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdp_data_arr, qpdp_data_num,
                          SXD_REG_ID_QPDP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpdp_get(sxd_emad_qpdp_data_t         *qpdp_data_arr,
                               uint32_t                      qpdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdp_data_arr == NULL) || (qpdp_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdp_data_arr, qpdp_data_num,
                          SXD_REG_ID_QPDP_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qprt_set(sxd_emad_qprt_data_t         *qprt_data_arr,
                               uint32_t                      qprt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qprt_data_arr == NULL) || (qprt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qprt_data_arr, qprt_data_num,
                          SXD_REG_ID_QPRT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qprt_get(sxd_emad_qprt_data_t         *qprt_data_arr,
                               uint32_t                      qprt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qprt_data_arr == NULL) || (qprt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qprt_data_arr, qprt_data_num,
                          SXD_REG_ID_QPRT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpts_set(sxd_emad_qpts_data_t         *qpts_data_arr,
                               uint32_t                      qpts_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpts_data_arr == NULL) || (qpts_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpts_data_arr, qpts_data_num,
                          SXD_REG_ID_QPTS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpts_get(sxd_emad_qpts_data_t         *qpts_data_arr,
                               uint32_t                      qpts_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpts_data_arr == NULL) || (qpts_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpts_data_arr, qpts_data_num,
                          SXD_REG_ID_QPTS_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbmm_set(sxd_emad_sbmm_data_t         *sbmm_data_arr,
                               uint32_t                      sbmm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbmm_data_arr == NULL) || (sbmm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbmm_data_arr, sbmm_data_num,
                          SXD_REG_ID_SBMM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbmm_get(sxd_emad_sbmm_data_t         *sbmm_data_arr,
                               uint32_t                      sbmm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbmm_data_arr == NULL) || (sbmm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbmm_data_arr, sbmm_data_num,
                          SXD_REG_ID_SBMM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbsr_set(sxd_emad_sbsr_data_t         *sbsr_data_arr,
                               uint32_t                      sbsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbsr_data_arr == NULL) || (sbsr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbsr_data_arr, sbsr_data_num,
                          SXD_REG_ID_SBSR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sbsr_get(sxd_emad_sbsr_data_t         *sbsr_data_arr,
                               uint32_t                      sbsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sbsr_data_arr == NULL) || (sbsr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sbsr_data_arr, sbsr_data_num,
                          SXD_REG_ID_SBSR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpdpm_set(sxd_emad_qpdpm_data_t        *qpdpm_data_arr,
                                uint32_t                      qpdpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdpm_data_arr == NULL) || (qpdpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdpm_data_arr, qpdpm_data_num,
                          SXD_REG_ID_QPDPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpdpm_get(sxd_emad_qpdpm_data_t        *qpdpm_data_arr,
                                uint32_t                      qpdpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdpm_data_arr == NULL) || (qpdpm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdpm_data_arr, qpdpm_data_num,
                          SXD_REG_ID_QPDPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qepm_set(sxd_emad_qepm_data_t         *qepm_data_arr,
                               uint32_t                      qepm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qepm_data_arr == NULL) || (qepm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qepm_data_arr, qepm_data_num,
                          SXD_REG_ID_QEPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
sxd_status_t sxd_emad_qepm_get(sxd_emad_qepm_data_t         *qepm_data_arr,
                               uint32_t                      qepm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qepm_data_arr == NULL) || (qepm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qepm_data_arr, qepm_data_num,
                          SXD_REG_ID_QEPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qrwe_set(sxd_emad_qrwe_data_t         *qrwe_data_arr,
                               uint32_t                      qrwe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qrwe_data_arr == NULL) || (qrwe_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qrwe_data_arr, qrwe_data_num,
                          SXD_REG_ID_QRWE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qrwe_get(sxd_emad_qrwe_data_t         *qrwe_data_arr,
                               uint32_t                      qrwe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qrwe_data_arr == NULL) || (qrwe_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qrwe_data_arr, qrwe_data_num,
                          SXD_REG_ID_QRWE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpem_set(sxd_emad_qpem_data_t         *qpem_data_arr,
                               uint32_t                      qpem_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpem_data_arr == NULL) || (qpem_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpem_data_arr, qpem_data_num,
                          SXD_REG_ID_QPEM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpem_get(sxd_emad_qpem_data_t         *qpem_data_arr,
                               uint32_t                      qpem_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpem_data_arr == NULL) || (qpem_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpem_data_arr, qpem_data_num,
                          SXD_REG_ID_QPEM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpdsm_set(sxd_emad_qpdsm_data_t        *qpdsm_data_arr,
                                uint32_t                      qpdsm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdsm_data_arr == NULL) || (qpdsm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdsm_data_arr, qpdsm_data_num,
                          SXD_REG_ID_QPDSM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qpdsm_get(sxd_emad_qpdsm_data_t        *qpdsm_data_arr,
                                uint32_t                      qpdsm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qpdsm_data_arr == NULL) || (qpdsm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qpdsm_data_arr, qpdsm_data_num,
                          SXD_REG_ID_QPDSM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qppm_set(sxd_emad_qppm_data_t         *qppm_data_arr,
                               uint32_t                      qppm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qppm_data_arr == NULL) || (qppm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qppm_data_arr, qppm_data_num,
                          SXD_REG_ID_QPPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_qppm_get(sxd_emad_qppm_data_t         *qppm_data_arr,
                               uint32_t                      qppm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((qppm_data_arr == NULL) || (qppm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)qppm_data_arr, qppm_data_num,
                          SXD_REG_ID_QPPM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
