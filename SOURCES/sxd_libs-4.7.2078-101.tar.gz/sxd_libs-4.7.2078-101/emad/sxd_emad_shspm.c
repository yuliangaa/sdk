/*
 * Copyright (C) 2015-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_shspm.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_SHSPM

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_shspm_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_ralue_set(sxd_emad_ralue_data_t        *ralue_data_arr,
                                uint32_t                      ralue_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ralue_data_arr == NULL) || (ralue_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ralue_data_arr, ralue_data_num,
                          SXD_REG_ID_RALUE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ralue_get(sxd_emad_ralue_data_t        *ralue_data_arr,
                                uint32_t                      ralue_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ralue_data_arr == NULL) || (ralue_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ralue_data_arr, ralue_data_num,
                          SXD_REG_ID_RALUE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ralbu_set(sxd_emad_ralbu_data_t        *ralbu_data_arr,
                                uint32_t                      ralbu_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ralbu_data_arr == NULL) || (ralbu_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ralbu_data_arr, ralbu_data_num,
                          SXD_REG_ID_RALBU_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
