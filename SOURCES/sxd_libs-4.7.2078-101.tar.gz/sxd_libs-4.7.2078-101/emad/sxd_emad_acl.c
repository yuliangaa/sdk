/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_parser_acl.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_ACL

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t sxd_emad_acl_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_ptar_set(sxd_emad_ptar_data_t         *ptar_data_arr,
                               uint32_t                      ptar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptar_data_arr == NULL) || (ptar_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptar_data_arr, ptar_data_num,
                          SXD_REG_ID_PTAR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptar_get(sxd_emad_ptar_data_t         *ptar_data_arr,
                               uint32_t                      ptar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptar_data_arr == NULL) || (ptar_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptar_data_arr, ptar_data_num,
                          SXD_REG_ID_PTAR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pacl_set(sxd_emad_pacl_data_t         *pacl_data_arr,
                               uint32_t                      pacl_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pacl_data_arr == NULL) || (pacl_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pacl_data_arr, pacl_data_num,
                          SXD_REG_ID_PACL_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pacl_get(sxd_emad_pacl_data_t         *pacl_data_arr,
                               uint32_t                      pacl_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pacl_data_arr == NULL) || (pacl_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pacl_data_arr, pacl_data_num,
                          SXD_REG_ID_PACL_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_ptce_set(sxd_emad_ptce_data_t         *ptce_data_arr,
                               uint32_t                      ptce_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptce_data_arr == NULL) || (ptce_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptce_data_arr, ptce_data_num,
                          SXD_REG_ID_PTCE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptce_get(sxd_emad_ptce_data_t         *ptce_data_arr,
                               uint32_t                      ptce_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptce_data_arr == NULL) || (ptce_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptce_data_arr, ptce_data_num,
                          SXD_REG_ID_PTCE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptce2_set(sxd_emad_ptce2_data_t        *ptce2_data_arr,
                                uint32_t                      ptce2_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptce2_data_arr == NULL) || (ptce2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptce2_data_arr, ptce2_data_num,
                          SXD_REG_ID_PTCE2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ptce2_get(sxd_emad_ptce2_data_t        *ptce2_data_arr,
                                uint32_t                      ptce2_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ptce2_data_arr == NULL) || (ptce2_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ptce2_data_arr, ptce2_data_num,
                          SXD_REG_ID_PTCE2_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_prbt_set(sxd_emad_prbt_data_t         *prbt_data_arr,
                               uint32_t                      prbt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((prbt_data_arr == NULL) || (prbt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)prbt_data_arr, prbt_data_num,
                          SXD_REG_ID_PRBT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_prbt_get(sxd_emad_prbt_data_t         *prbt_data_arr,
                               uint32_t                      prbt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((prbt_data_arr == NULL) || (prbt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)prbt_data_arr, prbt_data_num,
                          SXD_REG_ID_PRBT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pefa_set(sxd_emad_pefa_data_t         *pefa_data_arr,
                               uint32_t                      pefa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pefa_data_arr == NULL) || (pefa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pefa_data_arr, pefa_data_num,
                          SXD_REG_ID_PEFA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pefa_get(sxd_emad_pefa_data_t         *pefa_data_arr,
                               uint32_t                      pefa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pefa_data_arr == NULL) || (pefa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pefa_data_arr, pefa_data_num,
                          SXD_REG_ID_PEFA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_prcr_set(sxd_emad_prcr_data_t         *prcr_data_arr,
                               uint32_t                      prcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((prcr_data_arr == NULL) || (prcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)prcr_data_arr, prcr_data_num,
                          SXD_REG_ID_PRCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_prcr_get(sxd_emad_prcr_data_t         *prcr_data_arr,
                               uint32_t                      prcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((prcr_data_arr == NULL) || (prcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)prcr_data_arr, prcr_data_num,
                          SXD_REG_ID_PRCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pagt_set(sxd_emad_pagt_data_t         *pagt_data_arr,
                               uint32_t                      pagt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pagt_data_arr == NULL) || (pagt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pagt_data_arr, pagt_data_num,
                          SXD_REG_ID_PAGT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pagt_get(sxd_emad_pagt_data_t         *pagt_data_arr,
                               uint32_t                      pagt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pagt_data_arr == NULL) || (pagt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pagt_data_arr, pagt_data_num,
                          SXD_REG_ID_PAGT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pecb_set(sxd_emad_pecb_data_t         *pecb_data_arr,
                               uint32_t                      pecb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pecb_data_arr == NULL) || (pecb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pecb_data_arr, pecb_data_num,
                          SXD_REG_ID_PECB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pecb_get(sxd_emad_pecb_data_t         *pecb_data_arr,
                               uint32_t                      pecb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pecb_data_arr == NULL) || (pecb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pecb_data_arr, pecb_data_num,
                          SXD_REG_ID_PECB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pemb_set(sxd_emad_pemb_data_t         *pemb_data_arr,
                               uint32_t                      pemb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pemb_data_arr == NULL) || (pemb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pemb_data_arr, pemb_data_num,
                          SXD_REG_ID_PEMB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_pemb_get(sxd_emad_pemb_data_t         *pemb_data_arr,
                               uint32_t                      pemb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pemb_data_arr == NULL) || (pemb_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pemb_data_arr, pemb_data_num,
                          SXD_REG_ID_PEMB_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_puet_set(sxd_emad_puet_data_t         *puet_data_arr,
                               uint32_t                      puet_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((puet_data_arr == NULL) || (puet_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)puet_data_arr, puet_data_num,
                          SXD_REG_ID_PUET_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_puet_get(sxd_emad_puet_data_t         *puet_data_arr,
                               uint32_t                      puet_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((puet_data_arr == NULL) || (puet_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)puet_data_arr, puet_data_num,
                          SXD_REG_ID_PUET_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
