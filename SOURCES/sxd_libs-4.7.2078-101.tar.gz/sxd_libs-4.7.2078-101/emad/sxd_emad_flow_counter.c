/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
/*#include <sx/sxd/sxd_registers.h>*/
/*#include "../common/sxd_registers.h"*/

#include <sx/sxd/sxd_emad_parser_flow_counter.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_FLOW_COUNTER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_flow_counter_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                       IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


sxd_status_t sxd_emad_pfca_get(sxd_emad_pfca_data_t         *pfca_data_arr,
                               uint32_t                      pfca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfca_data_arr == NULL) || (pfca_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfca_data_arr, pfca_data_num,
                          SXD_REG_ID_PFCA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfca_set(sxd_emad_pfca_data_t         *pfca_data_arr,
                               uint32_t                      pfca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if ((pfca_data_arr == NULL) || (pfca_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfca_data_arr, pfca_data_num,
                          SXD_REG_ID_PFCA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfcnt_get(sxd_emad_pfcnt_data_t        *pfcnt_data_arr,
                                uint32_t                      pfcnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((pfcnt_data_arr == NULL) || (pfcnt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfcnt_data_arr, pfcnt_data_num,
                          SXD_REG_ID_PFCNT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_pfcnt_set(sxd_emad_pfcnt_data_t        *pfcnt_data_arr,
                                uint32_t                      pfcnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if ((pfcnt_data_arr == NULL) || (pfcnt_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)pfcnt_data_arr, pfcnt_data_num,
                          SXD_REG_ID_PFCNT_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mgpc_get(sxd_emad_mgpc_data_t         *mgpc_data_arr,
                               uint32_t                      mgpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mgpc_data_arr == NULL) || (mgpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mgpc_data_arr, mgpc_data_num,
                          SXD_REG_ID_MGPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mgpc_set(sxd_emad_mgpc_data_t         *mgpc_data_arr,
                               uint32_t                      mgpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if ((mgpc_data_arr == NULL) || (mgpc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mgpc_data_arr, mgpc_data_num,
                          SXD_REG_ID_MGPC_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
