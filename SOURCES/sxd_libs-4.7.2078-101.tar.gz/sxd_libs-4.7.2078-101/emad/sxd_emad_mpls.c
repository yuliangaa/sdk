/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
/*#include <sx/sxd/sxd_registers.h>*/
/*#include "../common/sxd_registers.h"*/
#include <sx/sxd/sxd_emad_mpls.h>
#include <sx/sxd/sxd_emad_mpls_data.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_MPLS

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_emad_mpgcr_set(sxd_emad_mpgcr_data_t        *mpgcr_data_arr,
                                uint32_t                      mpgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpgcr_data_arr == NULL) || (mpgcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpgcr_data_arr, mpgcr_data_num,
                          SXD_REG_ID_MPGCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mpgcr_get(sxd_emad_mpgcr_data_t        *mpgcr_data_arr,
                                uint32_t                      mpgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpgcr_data_arr == NULL) || (mpgcr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpgcr_data_arr, mpgcr_data_num,
                          SXD_REG_ID_MPGCR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mpilm_set(sxd_emad_mpilm_data_t        *mpilm_data_arr,
                                uint32_t                      mpilm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpilm_data_arr == NULL) || (mpilm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpilm_data_arr, mpilm_data_num,
                          SXD_REG_ID_MPILM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mpilm_get(sxd_emad_mpilm_data_t        *mpilm_data_arr,
                                uint32_t                      mpilm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mpilm_data_arr == NULL) || (mpilm_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mpilm_data_arr, mpilm_data_num,
                          SXD_REG_ID_MPILM_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
