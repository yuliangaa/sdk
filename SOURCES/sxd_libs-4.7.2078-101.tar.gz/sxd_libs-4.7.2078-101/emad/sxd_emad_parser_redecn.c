/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_byteswap.h>
#include <sx/sxd/sxd_emad_redecn_data.h>
#include <sx/sxd/sxd_emad_redecn_reg.h>
#include <sx/sxd/sxd_emad_parser_redecn.h>


#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_REDECN

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t emad_parser_redecn_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwtp(sxd_emad_cwtp_data_t *cwtp_data, sxd_emad_cwtp_reg_t  *cwtp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cwtp_reg->local_port = cwtp_data->reg_data->local_port;
    cwtp_reg->lp_msb = (cwtp_data->reg_data->lp_msb & 0x03) << 4;

    cwtp_reg->traffic_class = cwtp_data->reg_data->traffic_class;

    cwtp_reg->mode = cwtp_data->reg_data->mode & 0x1;

    cwtp_reg->profile1_min = cl_hton32(cwtp_data->reg_data->profiles[0].profile_i_min & 0xFFFFF);
    cwtp_reg->profile1_percent_profile1_max = ((cwtp_data->reg_data->profiles[0].profile_i_percent & 0x7F) << 24) |
                                              (cwtp_data->reg_data->profiles[0].profile_i_max & 0xFFFFF);
    cwtp_reg->profile1_percent_profile1_max = cl_hton32(cwtp_reg->profile1_percent_profile1_max);

    cwtp_reg->profile2_min = cl_hton32(cwtp_data->reg_data->profiles[1].profile_i_min & 0xFFFFF);
    cwtp_reg->profile2_percent_profile2_max = ((cwtp_data->reg_data->profiles[1].profile_i_percent & 0x7F) << 24) |
                                              (cwtp_data->reg_data->profiles[1].profile_i_max & 0xFFFFF);
    cwtp_reg->profile2_percent_profile2_max = cl_hton32(cwtp_reg->profile2_percent_profile2_max);

    cwtp_reg->profile3_min = cl_hton32(cwtp_data->reg_data->profiles[2].profile_i_min & 0xFFFFF);
    cwtp_reg->profile3_percent_profile3_max = ((cwtp_data->reg_data->profiles[2].profile_i_percent & 0x7F) << 24) |
                                              (cwtp_data->reg_data->profiles[2].profile_i_max & 0xFFFFF);
    cwtp_reg->profile3_percent_profile3_max = cl_hton32(cwtp_reg->profile3_percent_profile3_max);

    SX_LOG_EXIT();
    return err;
}


/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwtp(sxd_emad_cwtp_data_t *cwtp_data, sxd_emad_cwtp_reg_t  *cwtp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cwtp_data->reg_data->local_port = cwtp_reg->local_port;
    cwtp_data->reg_data->lp_msb = (cwtp_reg->lp_msb >> 4) & 0x03;

    cwtp_data->reg_data->traffic_class = cwtp_reg->traffic_class;

    cwtp_data->reg_data->mode = cwtp_reg->mode & 0x1;


    cwtp_data->reg_data->profiles[0].profile_i_min = cl_ntoh32(cwtp_reg->profile1_min) & 0xFFFFF;
    cwtp_data->reg_data->profiles[0].profile_i_max = cl_ntoh32(cwtp_reg->profile1_percent_profile1_max) & 0xFFFFF;
    cwtp_data->reg_data->profiles[0].profile_i_percent =
        (cl_ntoh32(cwtp_reg->profile1_percent_profile1_max) & 0x7F000000) >> 24;

    cwtp_data->reg_data->profiles[1].profile_i_min = cl_ntoh32(cwtp_reg->profile2_min) & 0xFFFFF;
    cwtp_data->reg_data->profiles[1].profile_i_max = cl_ntoh32(cwtp_reg->profile2_percent_profile2_max) & 0xFFFFF;
    cwtp_data->reg_data->profiles[1].profile_i_percent =
        (cl_ntoh32(cwtp_reg->profile2_percent_profile2_max) & 0x7F000000) >> 24;

    cwtp_data->reg_data->profiles[2].profile_i_min = cl_ntoh32(cwtp_reg->profile3_min) & 0xFFFFF;
    cwtp_data->reg_data->profiles[2].profile_i_max = cl_ntoh32(cwtp_reg->profile3_percent_profile3_max) & 0xFFFFF;
    cwtp_data->reg_data->profiles[2].profile_i_percent =
        (cl_ntoh32(cwtp_reg->profile3_percent_profile3_max) & 0x7F000000) >> 24;

    SX_LOG_EXIT();

    return err;
}

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwpp(sxd_emad_cwpp_data_t *cwpp_data, sxd_emad_cwpp_reg_t  *cwpp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    net32_t      tmp;

    SX_LOG_ENTER();

    cwpp_reg->pool = cwpp_data->reg_data->pool & 0xF;

    tmp = cl_hton32(cwpp_data->reg_data->profiles[0].profile_i_min);
    memcpy(cwpp_reg->profile1_min, &tmp, 3);
    tmp = cl_hton32(cwpp_data->reg_data->profiles[0].profile_i_max);
    memcpy(cwpp_reg->profile1_max, &tmp, 3);
    cwpp_reg->profile1_percent = cwpp_data->reg_data->profiles[0].profile_i_percent & 0x7F;

    tmp = cl_hton32(cwpp_data->reg_data->profiles[1].profile_i_min);
    memcpy(cwpp_reg->profile2_min, &tmp, 3);
    tmp = cl_hton32(cwpp_data->reg_data->profiles[1].profile_i_max);
    memcpy(cwpp_reg->profile2_max, &tmp, 3);
    cwpp_reg->profile2_percent = cwpp_data->reg_data->profiles[1].profile_i_percent & 0x7F;

    tmp = cl_hton32(cwpp_data->reg_data->profiles[2].profile_i_min);
    memcpy(cwpp_reg->profile3_min, &tmp, 3);
    tmp = cl_hton32(cwpp_data->reg_data->profiles[2].profile_i_max);
    memcpy(cwpp_reg->profile3_max, &tmp, 3);
    cwpp_reg->profile3_percent = cwpp_data->reg_data->profiles[2].profile_i_percent & 0x7F;

    SX_LOG_EXIT();
    return err;
}

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwpp(sxd_emad_cwpp_data_t *cwpp_data, sxd_emad_cwpp_reg_t  *cwpp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    net32_t      tmp;

    SX_LOG_ENTER();

    cwpp_data->reg_data->pool = cwpp_reg->pool & 0xF;

    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile1_min, 3);
    cwpp_data->reg_data->profiles[0].profile_i_min = cl_ntoh32(tmp);
    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile1_max, 3);
    cwpp_data->reg_data->profiles[0].profile_i_max = cl_ntoh32(tmp);
    cwpp_data->reg_data->profiles[0].profile_i_percent = cwpp_reg->profile1_percent & 0x7F;

    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile2_min, 3);
    cwpp_data->reg_data->profiles[1].profile_i_min = cl_ntoh32(tmp);
    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile2_max, 3);
    cwpp_data->reg_data->profiles[1].profile_i_max = cl_ntoh32(tmp);
    cwpp_data->reg_data->profiles[1].profile_i_percent = cwpp_reg->profile2_percent & 0x7F;

    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile3_min, 3);
    cwpp_data->reg_data->profiles[2].profile_i_min = cl_ntoh32(tmp);
    tmp = 0;
    memcpy(&tmp, cwpp_reg->profile3_max, 3);
    cwpp_data->reg_data->profiles[2].profile_i_max = cl_ntoh32(tmp);
    cwpp_data->reg_data->profiles[2].profile_i_percent = cwpp_reg->profile3_percent & 0x7F;

    SX_LOG_EXIT();

    return err;
}

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwppm(sxd_emad_cwppm_data_t *cwppm_data, sxd_emad_cwppm_reg_t  *cwppm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cwppm_reg->pool = cwppm_data->reg_data->pool & 0xF;

    cwppm_reg->tcp_g = cwppm_data->reg_data->tcp_g & 0x3;
    cwppm_reg->tcp_r = cwppm_data->reg_data->tcp_r & 0x3;
    cwppm_reg->tcp_y = cwppm_data->reg_data->tcp_y & 0x3;
    cwppm_reg->ntcp_g = cwppm_data->reg_data->ntcp_g & 0x3;
    cwppm_reg->ntcp_r = cwppm_data->reg_data->ntcp_r & 0x3;
    cwppm_reg->ntcp_y = cwppm_data->reg_data->ntcp_y & 0x3;

    SX_LOG_EXIT();
    return err;
}


/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwppm(sxd_emad_cwppm_data_t *cwppm_data, sxd_emad_cwppm_reg_t  *cwppm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cwppm_data->reg_data->pool = cwppm_reg->pool & 0xF;

    cwppm_data->reg_data->tcp_g = cwppm_reg->tcp_g & 0x3;
    cwppm_data->reg_data->tcp_r = cwppm_reg->tcp_r & 0x3;
    cwppm_data->reg_data->tcp_y = cwppm_reg->tcp_y & 0x3;
    cwppm_data->reg_data->ntcp_g = cwppm_reg->ntcp_g & 0x3;
    cwppm_data->reg_data->ntcp_r = cwppm_reg->ntcp_r & 0x3;
    cwppm_data->reg_data->ntcp_y = cwppm_reg->ntcp_y & 0x3;

    SX_LOG_EXIT();
    return err;
}
