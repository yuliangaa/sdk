/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_cos.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_COS

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define SWITCHEN_SWITCH_PRIO_NUM 16

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sxd_status_t emad_parser_cos_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_qpdp(sxd_emad_qpdp_data_t *qpdp_data, sxd_emad_qpdp_reg_t *qpdp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpdp_reg->local_port = qpdp_data->reg_data->local_port;
    qpdp_reg->lp_msb = (qpdp_data->reg_data->lp_msb & 0x03) << 4;
    qpdp_reg->color = qpdp_data->reg_data->color & 0x03;
    qpdp_reg->pprio = qpdp_data->reg_data->default_priority & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpdp(sxd_emad_qpdp_data_t *qpdp_data, sxd_emad_qpdp_reg_t *qpdp_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpdp_data->reg_data->color = qpdp_reg->color & 0x03;
    qpdp_data->reg_data->default_priority = qpdp_reg->pprio & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qprt(sxd_emad_qprt_data_t *qprt_data, sxd_emad_qprt_reg_t *qprt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qprt_reg->local_port = qprt_data->reg_data->local_port;
    qprt_reg->lp_msb_and_dei_and_pcp = (qprt_data->reg_data->lp_msb & 0x03) << 4;
    qprt_reg->lp_msb_and_dei_and_pcp |= ((qprt_data->reg_data->dei & 0x01) << 3);
    qprt_reg->lp_msb_and_dei_and_pcp |= (qprt_data->reg_data->prio & 0x07);
    qprt_reg->color = qprt_data->reg_data->color & 0x03;
    qprt_reg->rprio = qprt_data->reg_data->rprio & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qprt(sxd_emad_qprt_data_t *qprt_data, sxd_emad_qprt_reg_t *qprt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qprt_data->reg_data->color = qprt_reg->color & 0x03;
    qprt_data->reg_data->rprio = qprt_reg->rprio & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qpts(sxd_emad_qpts_data_t *qpts_data, sxd_emad_qpts_reg_t *qpts_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpts_reg->local_port = qpts_data->reg_data->port;
    qpts_reg->lp_msb = ((qpts_data->reg_data->lp_msb & 0x3) << 4);
    qpts_reg->trust_level = qpts_data->reg_data->trust_level & 0x07;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpts(sxd_emad_qpts_data_t *qpts_data, sxd_emad_qpts_reg_t *qpts_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qpts_data->reg_data->trust_level = qpts_reg->trust_level & 0x07;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sbmm(sxd_emad_sbmm_data_t *sbmm_data, sxd_emad_sbmm_reg_t *sbmm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbmm_reg->prio = sbmm_data->reg_data->prio & 0xf;
    sbmm_reg->pool = sbmm_data->reg_data->pool & 0xf;

    sbmm_reg->clr_max_buff_occupancy = cl_hton32((sbmm_data->reg_data->clr) << 31);
    sbmm_reg->min_buff = cl_hton32(sbmm_data->reg_data->min_buff);
    sbmm_reg->infinite_size_max_buff =
        cl_hton32(((sbmm_data->reg_data->infinite_size & 0x01) << 31) |
                  (sbmm_data->reg_data->max_buff & 0x00FFFFFF));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sbsr(sxd_emad_sbsr_data_t *sbsr_data, sxd_emad_sbsr_reg_t *sbsr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i;

    SX_LOG_ENTER();

    sbsr_reg->clr = (sbsr_data->reg_data->clr << 7) & 0x80;
    sbsr_reg->desc = (sbsr_data->reg_data->desc << 7) & 0x80;
    sbsr_reg->port_page = sbsr_data->reg_data->port_page & 0x0F;
    for (i = 0; i < SXD_EMAD_SBSR_PORT_MASK_SIZE; i++) {
        sbsr_reg->ingress_port_mask[i] = cl_hton32(sbsr_data->reg_data->ingress_port_mask[i]);
        sbsr_reg->egress_port_mask[i] = cl_hton32(sbsr_data->reg_data->egress_port_mask[i]);
    }
    sbsr_reg->pg_buff_mask = cl_hton16(sbsr_data->reg_data->pg_buff_mask & 0x03FF);
    for (i = 0; i < SXD_EMAD_SBSR_TC_MASK_SIZE; i++) {
        sbsr_reg->tclass_mask[i] = cl_hton32(sbsr_data->reg_data->tclass_mask[i]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbmm(sxd_emad_sbmm_data_t *sbmm_data, sxd_emad_sbmm_reg_t *sbmm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sbmm_data->reg_data->prio = sbmm_reg->prio & 0xf;
    sbmm_data->reg_data->pool = sbmm_reg->pool & 0xf;

    sbmm_data->reg_data->buff_occupancy = cl_ntoh32(sbmm_reg->buff_occupancy);
    sbmm_data->reg_data->clr = cl_ntoh32(sbmm_reg->clr_max_buff_occupancy) >> 31;
    /* mask to have the register value cleared of clr bit */
    sbmm_data->reg_data->max_buff_occupancy = cl_ntoh32(sbmm_reg->clr_max_buff_occupancy) & 0x00FFFFFF;
    sbmm_data->reg_data->min_buff = cl_ntoh32(sbmm_reg->min_buff);

    sbmm_data->reg_data->max_buff = cl_ntoh32(sbmm_reg->infinite_size_max_buff) & 0x00FFFFFF;
    sbmm_data->reg_data->infinite_size = (cl_ntoh32(sbmm_reg->infinite_size_max_buff) >> 31) & 0x1;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sbsr(sxd_emad_sbsr_data_t *sbsr_data, sxd_emad_sbsr_reg_t *sbsr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i;

    SX_LOG_ENTER();

    sbsr_data->reg_data->desc = sbsr_reg->desc >> 7;
    sbsr_data->reg_data->port_page = sbsr_reg->port_page & 0x0F;

    for (i = 0; i < (SXD_EMAD_SBSR_PORT_MASK_SIZE); i++) {
        sbsr_data->reg_data->ingress_port_mask[i] = cl_ntoh32(sbsr_reg->ingress_port_mask[i]);
        sbsr_data->reg_data->egress_port_mask[i] = cl_ntoh32(sbsr_reg->egress_port_mask[i]);
    }
    sbsr_data->reg_data->pg_buff_mask = cl_ntoh16(sbsr_reg->pg_buff_mask) & 0x03FF;

    for (i = 0; i < (SXD_EMAD_SBSR_TC_MASK_SIZE); i++) {
        sbsr_data->reg_data->tclass_mask[i] = cl_ntoh32(sbsr_reg->tclass_mask[i]);
    }

    for (i = 0; i < SXD_EMAD_SBSR_MAX_RET_SIZE /*120*/; i++) {
        sbsr_data->reg_data->sbstatus[i].buff_occupancy = cl_ntoh32(sbsr_reg->sbstatus[i].buff_occupancy) & 0x00FFFFFF;
        sbsr_data->reg_data->sbstatus[i].max_buff_occupancy = cl_ntoh32(sbsr_reg->sbstatus[i].max_buff_occupancy) &
                                                              0x00FFFFFF;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qpdpm(sxd_emad_qpdpm_data_t *qpdpm_data, sxd_emad_qpdpm_reg_t  *qpdpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     dscp;

    SX_LOG_ENTER();

    qpdpm_reg->port = qpdpm_data->reg_data->local_port;
    qpdpm_reg->lp_msb = (qpdpm_data->reg_data->lp_msb & 0x03) << 4;

    for (dscp = 0; dscp < DSCP_CODES_NUMBER; dscp++) {
        qpdpm_reg->priority_update[dscp] = qpdpm_data->reg_data->priority[dscp] & 0xF;
        qpdpm_reg->priority_update[dscp] |= ((qpdpm_data->reg_data->color[dscp] & 0x3) << 8);
        qpdpm_reg->priority_update[dscp] |= ((qpdpm_data->reg_data->dscp_update[dscp] & 0x1) << 15);
        qpdpm_reg->priority_update[dscp] = cl_hton16(qpdpm_reg->priority_update[dscp]);
    }

    SX_LOG_EXIT();
    return err;
}
sxd_status_t sxd_emad_deparse_qpdpm(sxd_emad_qpdpm_data_t *qpdpm_data, sxd_emad_qpdpm_reg_t  *qpdpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     dscp;

    SX_LOG_ENTER();

    qpdpm_data->reg_data->local_port = qpdpm_reg->port;
    qpdpm_data->reg_data->lp_msb = (qpdpm_reg->lp_msb >> 4) & 0x03;

    for (dscp = 0; dscp < DSCP_CODES_NUMBER; dscp++) {
        qpdpm_reg->priority_update[dscp] = cl_ntoh16(qpdpm_reg->priority_update[dscp]);
        qpdpm_data->reg_data->priority[dscp] = qpdpm_reg->priority_update[dscp] & 0x0F;
        qpdpm_data->reg_data->color[dscp] = ((qpdpm_reg->priority_update[dscp] >> 8) & 0x03);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qepm(sxd_emad_qepm_data_t *qepm_data, sxd_emad_qepm_reg_t  *qepm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     exp;

    SX_LOG_ENTER();

    qepm_reg->port = qepm_data->reg_data->local_port;
    qepm_reg->lp_msb = (qepm_data->reg_data->lp_msb & 0x03) << 4;

    for (exp = 0; exp < EXP_CODES_NUMBER; exp++) {
        qepm_reg->exp[exp] = qepm_data->reg_data->priority[exp] & 0x0F;
        qepm_reg->exp[exp] |= ((qepm_data->reg_data->color[exp] & 0x3) << 8);
        qepm_reg->exp[exp] |= ((qepm_data->reg_data->ecn[exp] & 0x3) << 10);
        qepm_reg->exp[exp] |= ((qepm_data->reg_data->exp_update[exp] & 0x1) << 15);
        qepm_reg->exp[exp] = cl_hton16(qepm_reg->exp[exp]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qepm(sxd_emad_qepm_data_t *qepm_data, sxd_emad_qepm_reg_t  *qepm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     exp;
    uint16_t     exp_val = 0;

    SX_LOG_ENTER();

    qepm_data->reg_data->local_port = qepm_reg->port;
    qepm_data->reg_data->lp_msb = (qepm_reg->lp_msb >> 4) & 0x03;

    for (exp = 0; exp < EXP_CODES_NUMBER; exp++) {
        exp_val = cl_ntoh16(qepm_reg->exp[exp]);
        qepm_data->reg_data->priority[exp] = exp_val & 0x0F;
        qepm_data->reg_data->color[exp] = (exp_val >> 8) & 0x03;
        qepm_data->reg_data->ecn[exp] = (exp_val >> 10) & 0x03;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qrwe(sxd_emad_qrwe_data_t *qrwe_data, sxd_emad_qrwe_reg_t  *qrwe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qrwe_reg->local_port = qrwe_data->reg_data->local_port;
    qrwe_reg->lp_msb = (qrwe_data->reg_data->lp_msb & 0x03) << 4;
    qrwe_reg->rewrite = (qrwe_data->reg_data->exp_rewrite & 0x01) << 2;
    qrwe_reg->rewrite |= (qrwe_data->reg_data->dscp_rewrite & 0x01) << 1;
    qrwe_reg->rewrite |= qrwe_data->reg_data->pcp_rewrite & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qrwe(sxd_emad_qrwe_data_t *qrwe_data, sxd_emad_qrwe_reg_t  *qrwe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    qrwe_data->reg_data->exp_rewrite = (qrwe_reg->rewrite >> 2) & 0x01;
    qrwe_data->reg_data->dscp_rewrite = (qrwe_reg->rewrite >> 1) & 0x01;
    qrwe_data->reg_data->pcp_rewrite = qrwe_reg->rewrite & 0x01;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qpem(sxd_emad_qpem_data_t *qpem_data, sxd_emad_qpem_reg_t  *qpem_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j, k;

    SX_LOG_ENTER();

    qpem_reg->local_port = qpem_data->reg_data->local_port;
    qpem_reg->lp_msb = (qpem_data->reg_data->lp_msb & 0x03) << 4;
    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < ECN_CODES_NUMBER; j++) { /* ECN loop */
            for (k = 0; k < COLOR_CODES_NUMBER; k++) { /* Color loop */
                qpem_reg->switch_prio[i].ecn[j].color[k] =
                    (qpem_data->reg_data->switch_prio[i].ecn[j].color[k].enable_exp & 0x01) << 7;
                qpem_reg->switch_prio[i].ecn[j].color[k] |= qpem_data->reg_data->switch_prio[i].ecn[j].color[k].exp &
                                                            0x07;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpem(sxd_emad_qpem_data_t *qpem_data, sxd_emad_qpem_reg_t  *qpem_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j, k;

    SX_LOG_ENTER();

    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < ECN_CODES_NUMBER; j++) { /* ECN loop */
            for (k = 0; k < COLOR_CODES_NUMBER; k++) { /* Color loop */
                qpem_data->reg_data->switch_prio[i].ecn[j].color[k].exp = qpem_reg->switch_prio[i].ecn[j].color[k] &
                                                                          0x07;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qpdsm(sxd_emad_qpdsm_data_t *qpdsm_data, sxd_emad_qpdsm_reg_t  *qpdsm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j;

    SX_LOG_ENTER();

    qpdsm_reg->local_port = qpdsm_data->reg_data->local_port;
    qpdsm_reg->lp_msb = (qpdsm_data->reg_data->lp_msb & 0x03) << 4;
    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < COLOR_CODES_NUMBER; j++) { /* color loop */
            qpdsm_reg->switch_prio[i].color[j] =
                (qpdsm_data->reg_data->switch_prio[i].color[j].enable_dscp & 0x01) << 7;
            qpdsm_reg->switch_prio[i].color[j] |= qpdsm_data->reg_data->switch_prio[i].color[j].dscp & 0x3F;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qpdsm(sxd_emad_qpdsm_data_t *qpdsm_data, sxd_emad_qpdsm_reg_t  *qpdsm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j;

    SX_LOG_ENTER();

    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < COLOR_CODES_NUMBER; j++) { /* color loop */
            qpdsm_data->reg_data->switch_prio[i].color[j].dscp = qpdsm_reg->switch_prio[i].color[j] & 0x3F;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_qppm(sxd_emad_qppm_data_t *qppm_data, sxd_emad_qppm_reg_t  *qppm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j;

    SX_LOG_ENTER();

    qppm_reg->local_port = qppm_data->reg_data->local_port;
    qppm_reg->lp_msb = (qppm_data->reg_data->lp_msb & 0x03) << 4;
    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < COLOR_CODES_NUMBER; j++) { /* color loop */
            qppm_reg->switch_prio[i].color[j] = (qppm_data->reg_data->switch_prio[i].color[j].enable_pcp & 0x01) << 7;
            qppm_reg->switch_prio[i].color[j] |= (qppm_data->reg_data->switch_prio[i].color[j].dei & 0x01) << 4;
            qppm_reg->switch_prio[i].color[j] |= qppm_data->reg_data->switch_prio[i].color[j].pcp & 0x07;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_qppm(sxd_emad_qppm_data_t *qppm_data, sxd_emad_qppm_reg_t  *qppm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i, j;

    SX_LOG_ENTER();

    for (i = 0; i < SWITCHEN_SWITCH_PRIO_NUM; i++) { /* Switch prio loop */
        for (j = 0; j < COLOR_CODES_NUMBER; j++) { /* Color loop */
            qppm_data->reg_data->switch_prio[i].color[j].dei = (qppm_reg->switch_prio[i].color[j] >> 4) & 0x01;
            qppm_data->reg_data->switch_prio[i].color[j].pcp = qppm_reg->switch_prio[i].color[j] & 0x07;
        }
    }

    SX_LOG_EXIT();
    return err;
}
