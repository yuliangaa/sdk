/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#define _GNU_SOURCE /* unistd.h --> TEMP_FAILURE_RETRY */

#include <unistd.h>
#include <errno.h>

#include <complib/sx_log.h>
#include <complib/cl_thread.h>
#include <complib/cl_list.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_dbg.h>
#include <complib/cl_math.h>
#include <complib/cl_timer.h>

#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad_parser.h>

#include "emad_transaction.h"
#include "emad.h"
#include "../common/sxd_utils.h"

#ifdef SNIFFER_PRESENT
#include "sniffer/sxd_sniffer.h"
#endif

#undef  __MODULE__
#define __MODULE__ EMAD_RX_THREAD

/* Values are taken from PRM */
enum {
    EMAD_FW_STATUS_SUCCESS_E                = 0x0,
    EMAD_FW_STATUS_BUSY_E                   = 0x1,
    EMAD_FW_STATUS_BAD_BASE_VER_E           = 0x2,
    EMAD_FW_STATUS_BAD_TLV_E                = 0x3,
    EMAD_FW_STATUS_NOT_SUPP_REG_E           = 0x4,
    EMAD_FW_STATUS_NOT_SUPP_CLASS_E         = 0x5,
    EMAD_FW_STATUS_NOT_SUPP_METHOD_E        = 0x6,
    EMAD_FW_STATUS_BAD_PARAM_E              = 0x7,
    EMAD_FW_STATUS_RESOURCE_NOT_AVAILABLE_E = 0x8,
    EMAD_FW_STATUS_LONG_PROCESS_E           = 0x9,
    EMAD_FW_STATUS_RETRY_E                  = 0xA,
    EMAD_FW_STATUS_PERIPHERAL_ERR_E         = 0xB,
    EMAD_FW_STATUS_PROFILE_NO_MEMORY_E      = 0xC,
    EMAD_FW_STATUS_ISSU_ONGOING_E           = 0xD,
    EMAD_FW_STATUS_INTERNAL_ERROR_E         = 0x70,
    EMAD_FW_STATUS_BAD_CONFIG_E             = 0x20,
    EMAD_FW_STATUS_ERASE_EXCEEDED_E         = 0x21,
    EMAD_FW_STATUS_FATAL_ERROR_E            = 0x22,
    EMAD_FW_STATUS_REG_LENGTH_TOO_SMALL_E   = 0x24,
    EMAD_FW_STATUS_DROP_E                   = 0x7F
};

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_thread_t                     __thread_h;
static int                             __thread_notif_pipe[2] = { -1, -1 };
static boolean_t                       __thread_is_alive = FALSE;
static const emad_local_device_data_t *__local_dev = NULL;

static sxd_status_t __fw_status_to_sxd_status(uint8_t fw_status)
{
    switch (fw_status) {
    case EMAD_FW_STATUS_SUCCESS_E:
        return SXD_STATUS_SUCCESS;

    case EMAD_FW_STATUS_BUSY_E:
        return SXD_STATUS_FW_BUSY;

    case EMAD_FW_STATUS_RESOURCE_NOT_AVAILABLE_E:
        return SXD_STATUS_FW_NO_RESOURCES;

    case EMAD_FW_STATUS_PROFILE_NO_MEMORY_E:
        return SXD_STATUS_FW_PROFILE_NO_MEMORY;

    default:
        return SXD_STATUS_FW_ERROR;
    }

    return SXD_STATUS_FW_ERROR;
}

static boolean_t __is_fw_error_fatal(uint8_t fw_status)
{
    return (fw_status != EMAD_FW_STATUS_BUSY_E &&
            fw_status != EMAD_FW_STATUS_RESOURCE_NOT_AVAILABLE_E);
}

static void __notify_fw_error(uint8_t dev_id, uint64_t tid, uint16_t reg_id, uint8_t fw_status)
{
    emad_transport_failure_data_t fail_msg = {
        .tid = tid,
        .emad_id = reg_id,
        .fw_status = fw_status
    };

    emad_trigger_notification(dev_id, SXD_TRAP_ID_TRANSACTION_ERROR, &fail_msg, sizeof(fail_msg));
}

static void __emad_rx_thread(void *context)
{
    uint8_t                read_buff[sizeof(struct ku_read) + SXD_EMAD_BUFFER_MAX_SIZE];
    const struct ku_read  *ku_read = (struct ku_read*)read_buff;
    sxd_emad_tlv_markers_t tlv_markers;
    struct emad_buffer    *emad_buffer;
    const uint8_t         *prm_reg;
    const char            *emad_str;
    net64_t                tid;
    uint8_t                byte;
    uint8_t                fw_status;
    sxd_reg_id_e           deparse_reg_id;
    const void            *ku_reg_buff;
    cl_event_t            *start_ev = (cl_event_t*)context;
    sxd_status_t           sxd_st = SXD_STATUS_SUCCESS;
    fd_set                 read_fds;
    int                    sxd_fd;
    int                    notif_fd, hc_fd = -1, max_fd;
    int                    rc;
    uint32_t               emad_latency = 0;
    uint32_t               cache_read_time = 0;
    sx_log_severity_t      fw_error_sev = SX_LOG_NONE;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

#define EMAD_MIN_BUFFER_SIZE (sizeof(struct ku_read) + sizeof(sxd_emad_header_t) + sizeof(sxd_emad_operation_t))
    FD_ZERO(&read_fds);

    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);
    sxd_st = emad_local_device_get(&__local_dev);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get emad local device (err=%s)\n", SXD_STATUS_MSG(sxd_st));
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        return;
    }

    rc = sxd_fd_get(__local_dev->handle, &sxd_fd);
    if (rc) {
        SX_LOG_ERR("failed to get fd from sxd handle (rc=%d)\n", rc);
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        return;
    }

    notif_fd = __thread_notif_pipe[0];
    max_fd = MAX(sxd_fd, notif_fd);

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
        max_fd = MAX(hc_fd, max_fd);
    }

    cl_event_signal(start_ev);

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(notif_fd, &read_fds);
        FD_SET(sxd_fd, &read_fds);
        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
        }

        cl_fd_wait_on(max_fd, &read_fds, NULL, NULL, &rc);
        if (rc < 0) {
            SX_LOG_ERR("EMAD RX thread: select() failed [err=%d]\n", errno);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        if (hc_fd >= 0) {
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        }

        if (FD_ISSET(notif_fd, &read_fds)) {
            rc = TEMP_FAILURE_RETRY(read(notif_fd, &byte, 1));
            if (rc != 1) {
                SX_LOG_ERR("EMAD rx thread: error in reading from notification pipe [err=%d]\n", errno);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            }

            if (!__thread_is_alive) {
                break;
            }
        }

        /* sxd_fd is ready for read. it means that there are EMADs to read from the descriptor ... */
        if (FD_ISSET(sxd_fd, &read_fds)) {
            rc = TEMP_FAILURE_RETRY(read(sxd_fd, read_buff, sizeof(read_buff)));
            if ((uint32_t)rc < sizeof(struct ku_read)) {
                SX_LOG_ERR("received EMAD with error or too-short buffer (rc=%d) < ku_read size\n", rc);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                continue;
            }

            /* This trap should actually only be received after the signal is issued.
             * Anyway we ignore this trap if we receive it */
            if (ku_read->trap_id == SXD_TRAP_ID_SIGNAL) {
                continue;
            }

            if ((uint32_t)rc < EMAD_MIN_BUFFER_SIZE) {
                SX_LOG_ERR("received EMAD with error or too-short buffer (rc=%d), EMAD_MIN_BUFFER_SIZE %lu, \n",
                           rc, EMAD_MIN_BUFFER_SIZE);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                continue;
            }


            sxd_st = emad_get_tlv_headers(read_buff + sizeof(struct ku_read),
                                          (uint32_t)rc - sizeof(struct ku_read),
                                          &tlv_markers);
            if (sxd_st != SXD_STATUS_SUCCESS) {
                continue;
            }

            prm_reg = ((uint8_t*)tlv_markers.reg_tlv) + 4; /* 4 = Reg TLV header */

            tid = cl_ntoh64(tlv_markers.operation_tlv->tid);

            emad_str = "N/A";

            /* trying to get string_tlv which is optional */
            if (tlv_markers.string_tlv) {
                /* make sure string is NULL terminated */
                tlv_markers.string_tlv->string[sizeof(tlv_markers.string_tlv->string) - 1] = '\0';
                if (tlv_markers.string_tlv->string[0]) { /* if returned string from FW is not empty */
                    emad_str = tlv_markers.string_tlv->string;
                }
            }

            /* trying to get latency_tlv which is optional */
            if (tlv_markers.latency_tlv) {
                emad_latency = cl_ntoh32(tlv_markers.latency_tlv->latency_time);
                if (tlv_markers.latency_tlv->ccrt_v) {
                    cache_read_time = cl_ntoh32(tlv_markers.latency_tlv->code_cache_read_time);
                }
            } else {
                emad_latency = 0;
                cache_read_time = 0;
            }

            fw_status = tlv_markers.operation_tlv->dr_status & 0x7f;

            if (fw_status != 0) {
                sxd_set_last_fw_status(fw_status, cl_ntoh16(tlv_markers.operation_tlv->register_id),
                                       (tlv_markers.operation_tlv->r_method) & 0x3f, emad_str);
            }

#ifdef SNIFFER_PRESENT
            sxd_sniffer_emad_prm_record_rx(read_buff + sizeof(struct ku_read),
                                           rc - sizeof(struct ku_read),
                                           tlv_markers.operation_tlv->r_method & 0x3,
                                           &tlv_markers);

#endif

            sxd_st = emad_transaction_delete(tid, emad_latency, cache_read_time, &emad_buffer);
            if (sxd_st != SXD_STATUS_SUCCESS) {
                SX_HEXDUMP(SX_LOG_ERROR, (read_buff + sizeof(struct ku_read)), (rc - sizeof(struct ku_read)));
                continue;
            }

            emad_transaction_call_rx_callback(emad_buffer->notif_tid);

            /* if we get here, we found the EMAD buffer that holds the received TID */

            deparse_reg_id = (emad_buffer->is_raw_reg) ? SXD_REG_ID_RAW_E : emad_buffer->reg_id;
            ku_reg_buff = (EMAD_BUFFER_MODE(emad_buffer) == SXD_ACCESS_MODE_SYNC_DEPARSE) ?
                          emad_buffer->gen_reg_data.reg_data : NULL;

            if (fw_status != EMAD_FW_STATUS_SUCCESS_E) {
                __notify_fw_error(EMAD_BUFFER_DEV_ID(emad_buffer), tid, emad_buffer->reg_id, fw_status);
                if (__is_fw_error_fatal(fw_status)) {
                    /* hexdump will be printed in NOTICE, so '--fatal_error' SDK option will not
                     * terminate here but in the following error message (a few lines ahead).
                     */
                    SX_HEXDUMP(SX_LOG_WARNING, (read_buff + sizeof(struct ku_read)), (rc - sizeof(struct ku_read)));
                    fw_error_sev = SX_LOG_ERROR;
                } else {
                    fw_error_sev = SX_LOG_WARNING;
                }

                SX_LOG(fw_error_sev,
                       "EMAD transaction FW error "
                       "(tid=0x%" PRIx64 ", reg_id=0x%x [%s], dev_id=%u, access_cmd=%u, fw_status=%u, fw_cause='%s')\n",
                       tid,
                       emad_buffer->reg_id,
                       REG_ID_TO_NAME(emad_buffer->reg_id),
                       EMAD_BUFFER_DEV_ID(emad_buffer),
                       EMAD_BUFFER_ACCESS_CMD(emad_buffer),
                       fw_status,
                       emad_str);
            } else {
                if (EMAD_BUFFER_MODE(emad_buffer) == SXD_ACCESS_MODE_SYNC_DEPARSE) {
#ifdef SNIFFER_PRESENT
                    sxd_emad_deparse_rx(deparse_reg_id, &emad_buffer->gen_reg_data, prm_reg, NULL,
                                        sxd_sniffer_is_activated(deparse_reg_id) ? sxd_sniffer_print_data : NULL);
#else
                    sxd_emad_deparse_rx(deparse_reg_id, &emad_buffer->gen_reg_data, prm_reg, NULL, NULL);
#endif
                }
            }

            sxd_emad_call_hook(EMAD_BUFFER_DEV_ID(emad_buffer),
                               deparse_reg_id,
                               fw_status,
                               ku_reg_buff,
                               tlv_markers.operation_tlv,
                               tlv_markers.reg_tlv,
                               tlv_markers.latency_tlv);

            if (emad_buffer->sync_event) {
                emad_buffer->status = __fw_status_to_sxd_status(fw_status);
                cl_event_signal(emad_buffer->sync_event);
            } else {
                emad_buffer_dealloc(emad_buffer);
            }
        }
    }
}


sxd_status_t emad_open_rx_thread(void)
{
    cl_status_t  cl_st = CL_SUCCESS;
    sxd_status_t sxd_st = SXD_STATUS_SUCCESS;
    cl_event_t   start_ev;
    int          rc;

    __thread_is_alive = TRUE;

    cl_st = cl_event_init(&start_ev, FALSE);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to create start-event for emad rx thread (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_ERROR;
        goto start_ev_err;
    }

    rc = pipe(__thread_notif_pipe);
    if (rc) {
        SX_LOG_ERR("failed to create notification-pipe for emad rx thread (err=%d)\n", errno);
        sxd_st = SXD_STATUS_ERROR;
        goto notif_pipe_err;
    }

    cl_st = cl_thread_init(&__thread_h, __emad_rx_thread, &start_ev, "emadRx", 30);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("failed to open emad rx thread (err=%d)\n", cl_st);
        sxd_st = SXD_STATUS_NO_RESOURCES;
        goto thread_err;
    }

    cl_event_wait_on(&start_ev, EVENT_NO_TIMEOUT, TRUE);
    return SXD_STATUS_SUCCESS;

thread_err:
    close(__thread_notif_pipe[0]);
    close(__thread_notif_pipe[1]);

notif_pipe_err:
    cl_event_destroy(&start_ev);

start_ev_err:
    __thread_is_alive = FALSE;
    return sxd_st;
}


void emad_close_rx_thread(void)
{
    uint8_t byte = 1;
    int     rc;

    __thread_is_alive = FALSE;

    rc = TEMP_FAILURE_RETRY(write(__thread_notif_pipe[1], &byte, 1));
    if (rc != 1) {
        SX_LOG_ERR("failed to signal rx thread to terminate (rc=%d, err=%d)\n", rc, errno);
    }

    cl_thread_destroy(&__thread_h);
    close(__thread_notif_pipe[0]);
    close(__thread_notif_pipe[1]);
}

sxd_status_t emad_rx_thread_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sxd_status_t emad_rx_thread_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return status;
}
