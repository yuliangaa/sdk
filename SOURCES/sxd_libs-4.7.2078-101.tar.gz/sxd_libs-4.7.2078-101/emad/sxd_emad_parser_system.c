/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_system.h>
#include <sx/sxd/sxd_mac.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_SYSTEM

/************************************************
 *  Local variables
 ***********************************************/
#define ETH_ALEN 6                    /* Octets in one ethernet addr	 */

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_system_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_scar(sxd_emad_scar_data_t *scar_data, sxd_emad_scar_reg_t *scar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    scar_reg->cap_log2_fdb_sz = scar_data->reg_data->log2_fdb_size & 0x1F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_scar(sxd_emad_scar_data_t *scar_data, sxd_emad_scar_reg_t *scar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    scar_data->reg_data->log2_fdb_size = scar_reg->cap_log2_fdb_sz & 0x1F;

    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_parse_ppsc(sxd_emad_ppsc_data_t *ppsc_data, sxd_emad_ppsc_reg_t *ppsc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ppsc_reg->local_port = ppsc_data->reg_data->local_port;
    ppsc_reg->lp_msb = (ppsc_data->reg_data->lp_msb & 0x03) << 4;
    ppsc_reg->wrps_admin = (ppsc_data->reg_data->wrps_admin & 0x0F);
    ppsc_reg->wrps_status = (ppsc_data->reg_data->wrps_status & 0x0F);
    ppsc_reg->up_threshold = ppsc_data->reg_data->up_threshold;
    ppsc_reg->down_threshold = ppsc_data->reg_data->down_threshold;
    ppsc_reg->srps_admin = (ppsc_data->reg_data->srps_admin & 0x0F);
    ppsc_reg->srps_status = (ppsc_data->reg_data->srps_status & 0x0F);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ppsc(sxd_emad_ppsc_data_t *ppsc_data, sxd_emad_ppsc_reg_t *ppsc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ppsc_data->reg_data->local_port = ppsc_reg->local_port;
    ppsc_data->reg_data->lp_msb = (ppsc_reg->lp_msb >> 4) & 0x03;
    ppsc_data->reg_data->wrps_admin = ppsc_reg->wrps_admin;
    ppsc_data->reg_data->wrps_status = ppsc_reg->wrps_status;
    ppsc_data->reg_data->up_threshold = ppsc_reg->up_threshold;
    ppsc_data->reg_data->down_threshold = ppsc_reg->down_threshold;
    ppsc_data->reg_data->srps_admin = ppsc_reg->srps_admin;
    ppsc_data->reg_data->srps_status = ppsc_reg->srps_status;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mjtag(sxd_emad_mjtag_data_t *mjtag_data, sxd_emad_mjtag_reg_t *mjtag_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    int          i = 0;

    SX_LOG_ENTER();

    mjtag_reg->cmd_seq_num = (mjtag_data->reg_data->cmd & 0x03) << 6 | (mjtag_data->reg_data->seq_num & 0x0F);
    mjtag_reg->size = mjtag_data->reg_data->size;
    while (i < mjtag_reg->size) {
        mjtag_reg->jtag_transaction_sets[i].tdo_tdi_tms =
            ((mjtag_data->reg_data->jtag_transaction_sets[i].tdo & 0x01) << 3) |
            ((mjtag_data->reg_data->jtag_transaction_sets[i].tdi & 0x01) << 1) |
            (mjtag_data->reg_data->jtag_transaction_sets[i].tms & 0x01);
        i++;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mjtag(sxd_emad_mjtag_data_t *mjtag_data, sxd_emad_mjtag_reg_t *mjtag_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    int          i = 0;

    SX_LOG_ENTER();

    mjtag_data->reg_data->cmd = (mjtag_reg->cmd_seq_num & 0xC0) >> 6;
    mjtag_data->reg_data->seq_num = (mjtag_reg->cmd_seq_num & 0x0F);
    mjtag_data->reg_data->size = mjtag_reg->size;
    while (i < mjtag_reg->size) {
        mjtag_data->reg_data->jtag_transaction_sets[i].tms = mjtag_reg->jtag_transaction_sets[i].tdo_tdi_tms & 0x01;
        mjtag_data->reg_data->jtag_transaction_sets[i].tdi =
            (mjtag_reg->jtag_transaction_sets[i].tdo_tdi_tms & 0x02) >> 1;
        mjtag_data->reg_data->jtag_transaction_sets[i].tdo =
            (mjtag_reg->jtag_transaction_sets[i].tdo_tdi_tms & 0x08) >> 3;
        i++;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sspr(sxd_emad_sspr_data_t *sspr_data, sxd_emad_sspr_reg_t *sspr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sspr_reg->m = (sspr_data->reg_data->is_master << 7) & 0x80;
    sspr_reg->local_port = sspr_data->reg_data->local_port;
    sspr_reg->lp_msb = (sspr_data->reg_data->lp_msb & 0x03) << 4;
    sspr_reg->system_port = cl_hton16(sspr_data->reg_data->system_port);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sspr(sxd_emad_sspr_data_t *sspr_data, sxd_emad_sspr_reg_t *sspr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sspr_data->reg_data->is_master = (sspr_reg->m >> 7) & 0x01;
    sspr_data->reg_data->local_port = sspr_reg->local_port;
    sspr_data->reg_data->lp_msb = (sspr_reg->lp_msb >> 4) & 0x03;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mfba(sxd_emad_mfba_data_t *mfba_data, sxd_emad_mfba_reg_t *mfba_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

/*	printf("mfba_data->reg_data->p = %u\n", mfba_data->reg_data->p);
 *   printf("mfba_data->reg_data->fs = %u\n", mfba_data->reg_data->fs);
 *   printf("mfba_data->reg_data->size = %u\n", mfba_data->reg_data->size);
 *   printf("mfba_data->reg_data->address = %u\n", mfba_data->reg_data->address);
 */ mfba_reg->p = (mfba_data->reg_data->p) & 0x1;
    mfba_reg->fs = (mfba_data->reg_data->fs << 4) & 0x30;
    mfba_reg->size = cl_hton16(mfba_data->reg_data->size);
    mfba_reg->address = cl_hton32(mfba_data->reg_data->address);
    memcpy(mfba_reg->data, mfba_data->reg_data->data, mfba_data->reg_data->size);
/*	printf("mfba_reg->p = %u\n", mfba_reg->p);
 *   printf("mfba_reg->fs = %u\n", mfba_reg->fs);
 *   printf("mfba_reg->size = %u\n", mfba_reg->size);
 *   printf("mfba_reg->address = %u\n", mfba_reg->address);
 */
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mfba(sxd_emad_mfba_data_t *mfba_data, sxd_emad_mfba_reg_t *mfba_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mfba_data->reg_data->p = mfba_reg->p;
    mfba_data->reg_data->fs = (mfba_reg->fs >> 4) & 0x01;
    mfba_data->reg_data->size = cl_ntoh16(mfba_reg->size);
    mfba_data->reg_data->address = cl_ntoh32(mfba_reg->address);
    memcpy(mfba_data->reg_data->data, mfba_reg->data, mfba_data->reg_data->size);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mfbe(sxd_emad_mfbe_data_t *mfbe_data, sxd_emad_mfbe_reg_t *mfbe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mfbe_reg->p = (mfbe_data->reg_data->p) & 0x1;
    mfbe_reg->fs = (mfbe_data->reg_data->fs << 4) & 0x30;
    mfbe_reg->address = cl_hton32(mfbe_data->reg_data->address);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mfbe(sxd_emad_mfbe_data_t *mfbe_data, sxd_emad_mfbe_reg_t *mfbe_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mfbe_data->reg_data->p = mfbe_reg->p;
    mfbe_data->reg_data->fs = (mfbe_reg->fs >> 4) & 0x01;
    mfbe_data->reg_data->address = cl_ntoh32(mfbe_reg->address);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mfpa(sxd_emad_mfpa_data_t *mfpa_data, sxd_emad_mfpa_reg_t *mfpa_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mfpa_reg->p = (mfpa_data->reg_data->p) & 0x1;
    mfpa_reg->fs = (mfpa_data->reg_data->fs << 4) & 0x30;
    mfpa_reg->boot_address = cl_hton32(mfpa_data->reg_data->boot_address);
    mfpa_reg->flash_num = (mfpa_data->reg_data->flash_num) & 0xf;
    mfpa_reg->jedec_id = cl_hton32(mfpa_data->reg_data->jedec_id);
    mfpa_reg->block_allignment = mfpa_data->reg_data->block_allignment;
    mfpa_reg->sector_size = cl_hton16(mfpa_data->reg_data->sector_size);
    mfpa_reg->capability_mask = (mfpa_data->reg_data->capability_mask << 7) & 0x80;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mfpa(sxd_emad_mfpa_data_t *mfpa_data, sxd_emad_mfpa_reg_t *mfpa_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mfpa_data->reg_data->p = mfpa_reg->p;
    mfpa_data->reg_data->fs = (mfpa_reg->fs >> 4) & 0x1;
    mfpa_data->reg_data->boot_address = cl_ntoh32(mfpa_reg->boot_address);
    mfpa_data->reg_data->flash_num = mfpa_reg->flash_num;
    mfpa_data->reg_data->jedec_id = cl_ntoh32(mfpa_reg->jedec_id);
    mfpa_data->reg_data->block_allignment = mfpa_reg->block_allignment;
    mfpa_data->reg_data->sector_size = cl_ntoh16(mfpa_reg->sector_size);
    mfpa_data->reg_data->capability_mask = (mfpa_reg->capability_mask >> 7) & 0x1;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_msci(sxd_emad_msci_data_t *msci_data, sxd_emad_msci_reg_t *msci_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    msci_reg->index = (msci_data->reg_data->index & 0xF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_msci(sxd_emad_msci_data_t *msci_data, sxd_emad_msci_reg_t *msci_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    msci_data->reg_data->index = (msci_reg->index & 0xF);
    msci_data->reg_data->version = cl_ntoh32(msci_reg->version);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mtbr(sxd_emad_mtbr_data_t *mtbr_data, sxd_emad_mtbr_reg_t *mtbr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if ((NULL == mtbr_data) || (NULL == mtbr_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    SX_LOG_ENTER();

    mtbr_reg->base_sensor_index = cl_hton16(mtbr_data->reg_data->base_sensor_index & 0xFFF);
    mtbr_reg->num_rec = mtbr_data->reg_data->num_rec;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mtbr(sxd_emad_mtbr_data_t *mtbr_data, sxd_emad_mtbr_reg_t *mtbr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    int          i = 0;

    if ((NULL == mtbr_data) || (NULL == mtbr_reg)) {
        return SXD_STATUS_PARAM_ERROR;
    }

    SX_LOG_ENTER();

    while (i < mtbr_reg->num_rec) {
        mtbr_data->reg_data->temperature_record[i].max_temperature =
            cl_ntoh16(mtbr_reg->temperature_record[i].max_temperature);
        mtbr_data->reg_data->temperature_record[i].temperature =
            cl_ntoh16(mtbr_reg->temperature_record[i].temperature);
        i++;
    }

    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_parse_mrsr(sxd_emad_mrsr_data_t *mrsr_data, sxd_emad_mrsr_reg_t *mrsr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mrsr_reg->command = (mrsr_data->reg_data->command & 0xF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mrsr(sxd_emad_mrsr_data_t *mrsr_data, sxd_emad_mrsr_reg_t *mrsr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(mrsr_data);
    UNUSED_PARAM(mrsr_reg);

    SX_LOG_EXIT();
    return err;
}
