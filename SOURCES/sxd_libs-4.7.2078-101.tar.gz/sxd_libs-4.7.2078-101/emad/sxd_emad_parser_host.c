/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_host.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_HOST

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_host_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_hcap(sxd_emad_hcap_data_t *hcap_data, sxd_emad_hcap_reg_t *hcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    UNUSED_PARAM(hcap_data);
    UNUSED_PARAM(hcap_reg);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_hcap(sxd_emad_hcap_data_t *hcap_data, sxd_emad_hcap_reg_t *hcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hcap_data->reg_data->max_cpu_egress_tclass = hcap_reg->max_cpu_egress_tclass;
    hcap_data->reg_data->max_cpu_ingress_tclass = hcap_reg->max_cpu_ingress_tclass;
    hcap_data->reg_data->max_num_trap_groups = hcap_reg->max_num_trap_groups;
    hcap_data->reg_data->max_num_dr_paths = hcap_reg->max_num_dr_paths & 0x0F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_hespr(sxd_emad_hespr_data_t *hespr_data, sxd_emad_hespr_reg_t *hespr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hespr_reg->stacking_tclass = hespr_data->reg_data->stacking_tclass & 0x07;
    hespr_reg->cpu_tclass = hespr_data->reg_data->cpu_tclass & 0x0F;
    hespr_reg->rdq = hespr_data->reg_data->rdq & 0x1F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_hespr(sxd_emad_hespr_data_t *hespr_data, sxd_emad_hespr_reg_t *hespr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hespr_data->reg_data->stacking_tclass = hespr_reg->stacking_tclass & 0x07;
    hespr_data->reg_data->cpu_tclass = hespr_reg->cpu_tclass & 0x0F;
    hespr_data->reg_data->rdq = hespr_reg->rdq & 0x1F;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_hdrt(sxd_emad_hdrt_data_t *hdrt_data, sxd_emad_hdrt_reg_t *hdrt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hdrt_reg->drp_index = hdrt_data->reg_data->dr_index & 0x0F;
    hdrt_reg->hop_cnt = hdrt_data->reg_data->hop_cnt & 0x7F;
    memcpy(hdrt_reg->path, hdrt_data->reg_data->path, sizeof(hdrt_reg->path));
    memcpy(hdrt_reg->rpath, hdrt_data->reg_data->rpath, sizeof(hdrt_reg->rpath));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_hdrt(sxd_emad_hdrt_data_t *hdrt_data, sxd_emad_hdrt_reg_t *hdrt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hdrt_data->reg_data->dr_index = hdrt_reg->drp_index & 0x0F;
    hdrt_data->reg_data->hop_cnt = hdrt_reg->hop_cnt & 0x7F;
    memcpy(hdrt_data->reg_data->path, hdrt_reg->path, sizeof(hdrt_data->reg_data->path));
    memcpy(hdrt_data->reg_data->rpath, hdrt_reg->rpath, sizeof(hdrt_data->reg_data->rpath));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_hctr(sxd_emad_hctr_data_t *hctr_data, sxd_emad_hctr_reg_t *hctr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hctr_reg->custom_trap_index = hctr_data->reg_data->custom_trap_index & 0x0F;
    hctr_reg->tcp_dport_sport_udp_dport = (hctr_data->reg_data->tcp_dport & 0x01) << 3;
    hctr_reg->tcp_dport_sport_udp_dport |= (hctr_data->reg_data->tcp_sport & 0x01) << 2;
    hctr_reg->tcp_dport_sport_udp_dport |= (hctr_data->reg_data->udp_dport & 0x01) << 1;
    hctr_reg->range_min = cl_hton16(hctr_data->reg_data->range_min);
    hctr_reg->range_max = cl_hton16(hctr_data->reg_data->range_max);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_hctr(sxd_emad_hctr_data_t *hctr_data, sxd_emad_hctr_reg_t *hctr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    hctr_data->reg_data->custom_trap_index = hctr_reg->custom_trap_index & 0x0F;
    hctr_data->reg_data->tcp_dport = (hctr_reg->tcp_dport_sport_udp_dport >> 3) & 0x01;
    hctr_data->reg_data->tcp_sport = (hctr_reg->tcp_dport_sport_udp_dport >> 2) & 0x01;
    hctr_data->reg_data->udp_dport = (hctr_reg->tcp_dport_sport_udp_dport >> 1) & 0x01;
    hctr_data->reg_data->range_min = cl_ntoh16(hctr_reg->range_min);
    hctr_data->reg_data->range_max = cl_ntoh16(hctr_reg->range_max);

    SX_LOG_EXIT();
    return err;
}
