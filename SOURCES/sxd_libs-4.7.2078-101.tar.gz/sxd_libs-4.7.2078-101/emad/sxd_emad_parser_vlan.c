/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_vlan.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_VLAN

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_vlan_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_parse_spvid(sxd_emad_spvid_data_t *spvid_data, sxd_emad_spvid_reg_t *spvid_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvid_reg->tport = spvid_data->reg_data->tport & 0x01;
    spvid_reg->local_port = spvid_data->reg_data->local_port;
    spvid_reg->lp_msb = (spvid_data->reg_data->lp_msb & 0x03) << 4;
    spvid_reg->egr_et_set = spvid_data->reg_data->egr_et_set & 0x01;
    spvid_reg->et_vlan = (spvid_data->reg_data->et_vlan) & 0X3;
    spvid_reg->pvid = cl_hton16(spvid_data->reg_data->port_default_vid & 0x0FFF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spvid(sxd_emad_spvid_data_t *spvid_data, sxd_emad_spvid_reg_t *spvid_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    spvid_data->reg_data->egr_et_set = spvid_reg->egr_et_set;
    spvid_data->reg_data->et_vlan = spvid_reg->et_vlan;
    spvid_data->reg_data->port_default_vid = cl_ntoh16(spvid_reg->pvid) & 0x0FFF;
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_sver(sxd_emad_sver_data_t *sver_data, sxd_emad_sver_reg_t *sver_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    sver_reg->ether_type0 = cl_hton16(sver_data->reg_data->ether_type[0]);
    sver_reg->ether_type1 = cl_hton16(sver_data->reg_data->ether_type[1]);
    sver_reg->ether_type2 = cl_hton16(sver_data->reg_data->ether_type[2]);


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_sver(sxd_emad_sver_data_t *sver_data, sxd_emad_sver_reg_t *sver_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    sver_data->reg_data->ether_type[0] = cl_ntoh16(sver_reg->ether_type0);
    sver_data->reg_data->ether_type[1] = cl_ntoh16(sver_reg->ether_type1);
    sver_data->reg_data->ether_type[2] = cl_ntoh16(sver_reg->ether_type2);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_spvc(sxd_emad_spvc_data_t *spvc_data, sxd_emad_spvc_reg_t *spvc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvc_reg->local_port = spvc_data->reg_data->local_port;
    spvc_reg->lp_msb = (spvc_data->reg_data->lp_msb << 4) & 0x30;
    spvc_reg->inner_et2_et2 = (spvc_data->reg_data->inner_et[2] & 0x1) << 1;
    spvc_reg->inner_et2_et2 |= (spvc_data->reg_data->et[2] & 0x1);
    spvc_reg->inner_et1_et1 = (spvc_data->reg_data->inner_et[1] & 0x1) << 1;
    spvc_reg->inner_et1_et1 |= (spvc_data->reg_data->et[1] & 0x1);
    spvc_reg->inner_et0_et0 = (spvc_data->reg_data->inner_et[0] & 0x1) << 1;
    spvc_reg->inner_et0_et0 |= (spvc_data->reg_data->et[0] & 0x1);
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spvc(sxd_emad_spvc_data_t *spvc_data, sxd_emad_spvc_reg_t *spvc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    spvc_data->reg_data->inner_et[2] = (spvc_reg->inner_et2_et2 & 0x2) >> 1;
    spvc_data->reg_data->et[2] = (spvc_reg->inner_et2_et2 & 0x1);
    spvc_data->reg_data->inner_et[1] = (spvc_reg->inner_et1_et1 & 0x2) >> 1;
    spvc_data->reg_data->et[1] = (spvc_reg->inner_et1_et1 & 0x1);
    spvc_data->reg_data->inner_et[0] = (spvc_reg->inner_et0_et0 & 0x2) >> 1;
    spvc_data->reg_data->et[0] = (spvc_reg->inner_et0_et0 & 0x1);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_spvm(sxd_emad_spvm_data_t *spvm_data, sxd_emad_spvm_reg_t *spvm_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvm_reg->local_port = spvm_data->reg_data->local_port;
    spvm_reg->lp_msb = (spvm_data->reg_data->lp_msb << 4) & 0x30;

    if (0 == spvm_data->reg_data->num_vlans) { /* port's untagged attribute setting */
        if (spvm_data->common.access_cmd == SXD_ACCESS_CMD_SET) {
            spvm_reg->prio_tagged = ((spvm_data->reg_data->prio_tagged) << 7) | 0x40;
        }
        spvm_reg->num_rec = 0;
    } else { /* vlan membership setting */
        spvm_reg->prio_tagged = 0; /* do not change port's untagged attribute setting */
        spvm_reg->num_rec = spvm_data->reg_data->num_vlans;
        for (i = 0; i < spvm_data->reg_data->num_vlans; ++i) {
            spvm_reg->records[i].ieu_vid =
                cl_hton16(((spvm_data->reg_data->vlan_data[i].ingress_membership == TRUE) << 14) |
                          ((spvm_data->reg_data->vlan_data[i].egress_membership == TRUE) << 13) |
                          ((spvm_data->reg_data->vlan_data[i].untagged_membership == TRUE) << 12) |
                          ((spvm_data->reg_data->vlan_data[i].vid & 0x0FFF)));
        }
    }
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spvm(sxd_emad_spvm_data_t *spvm_data, sxd_emad_spvm_reg_t *spvm_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvm_data->reg_data->num_vlans = spvm_reg->num_rec;
    spvm_data->reg_data->prio_tagged = (spvm_reg->prio_tagged >> 7) & 0x01;
    for (i = 0; i < spvm_data->reg_data->num_vlans; ++i) {
        uint16_t ieu_vid = cl_ntoh16(spvm_reg->records[i].ieu_vid);
        spvm_data->reg_data->vlan_data[i].ingress_membership = (ieu_vid >> 14) & 0x01;
        spvm_data->reg_data->vlan_data[i].egress_membership = (ieu_vid >> 13) & 0x01;
        spvm_data->reg_data->vlan_data[i].untagged_membership = (ieu_vid >> 12) & 0x01;
        spvm_data->reg_data->vlan_data[i].vid = ieu_vid & 0x0FFF;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_spvm_reg_vlans_size(sxd_emad_spvm_data_t *spvm_data, uint32_t *spvm_reg_vlans_size)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *spvm_reg_vlans_size = spvm_data->reg_data->num_vlans * sizeof(net32_t);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_spvtr(sxd_emad_spvtr_data_t *spvtr_data, sxd_emad_spvtr_reg_t *spvtr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvtr_reg->tport = spvtr_data->reg_data->tport & 0x01;
    spvtr_reg->local_port = spvtr_data->reg_data->local_port;
    spvtr_reg->lp_msb = (spvtr_data->reg_data->lp_msb << 4) & 0x30;
    spvtr_reg->ipvid_ipprio_mode = (((spvtr_data->reg_data->ipprio_mode & 0xF) << 4) |
                                    (spvtr_data->reg_data->ipvid_mode & 0xF));
    spvtr_reg->epvid_mode = (spvtr_data->reg_data->epvid_mode) & 0xF;
    spvtr_reg->enable_bits = (((spvtr_data->reg_data->ipprio_enable == TRUE) << 7) |
                              ((spvtr_data->reg_data->ipvid_enable == TRUE) << 6) |
                              ((spvtr_data->reg_data->epvid_enable == TRUE) << 5));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_spvtr(sxd_emad_spvtr_data_t *spvtr_data, sxd_emad_spvtr_reg_t *spvtr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    spvtr_data->reg_data->ipprio_mode = (spvtr_reg->ipvid_ipprio_mode & 0xF0) >> 4;
    spvtr_data->reg_data->ipvid_mode = (spvtr_reg->ipvid_ipprio_mode) & 0xF;
    spvtr_data->reg_data->epvid_mode = (spvtr_reg->epvid_mode) & 0xF;
    spvtr_data->reg_data->ipprio_enable = (spvtr_reg->enable_bits >> 7) & 0x01;
    spvtr_data->reg_data->ipvid_enable = (spvtr_reg->enable_bits >> 6) & 0x01;
    spvtr_data->reg_data->epvid_enable = (spvtr_reg->enable_bits >> 5) & 0x01;

    SX_LOG_EXIT();
    return err;
}
