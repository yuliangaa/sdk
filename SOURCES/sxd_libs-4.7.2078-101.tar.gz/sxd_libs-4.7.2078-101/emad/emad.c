/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/utils/debug_cmd.h>
#include "emad.h"
#include "emad_transaction.h"
#include "emad_transport.h"

#ifdef SNIFFER_PRESENT
#include "sniffer/sxd_sniffer.h"
#endif

#undef  __MODULE__
#define __MODULE__ EMAD

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static emad_local_device_data_t emad_local_device;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
static sxd_status_t __init_local_device(uint32_t app_id);
static sxd_status_t __deinit_local_device(void);

/************************************************
 *  Functions implementation
 ***********************************************/
static sxd_status_t __init_local_device(uint32_t app_id)
{
    char                 dev_name[MAX_SX_DEVS][MAX_NAME_LEN];
    char                *dev_name_p[MAX_SX_DEVS];
    uint32_t             dev_num = MAX_SX_DEVS;
    sxd_ctrl_pack_t      ctrl_pack = {   .ctrl_cmd = 0,
                                         .cmd_body = NULL};
    struct ku_synd_ioctl ku_synd_ioctl;
    int                  i = 0, ret = 0;
    sxd_status_t         err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));
    memset(&ku_synd_ioctl, 0, sizeof(struct ku_synd_ioctl));
    for (i = 0; i < MAX_SX_DEVS; ++i) {
        dev_name_p[i] = dev_name[i];
    }

    ret = sxd_get_dev_list(dev_name_p, &dev_num);
    if (ret < 0) {
        SX_LOG(SX_LOG_ERROR, "sxd_get_dev_list error: %s\n", strerror(errno));
        err = SXD_STATUS_DEVICE_GET_ERROR;
        goto out;
    } else if (ret > 0) {
        SX_LOG(SX_LOG_ERROR, "Unsupported SX device number: %u\n", dev_num);
        err = SXD_STATUS_DEVICE_GET_ERROR;
        goto out;
    }

    /* there should be only 1 char device - use the first one*/
    ret = sxd_open_device(dev_name[0], &(emad_local_device.handle));
    if (ret) {
        SX_LOG(SX_LOG_ERROR, "sxd_open_device error: %s\n", strerror(errno));
        err = SXD_STATUS_DEVICE_OPEN_ERROR;
        goto out;
    }

    ku_synd_ioctl.syndrome_num = SXD_TRAP_ID_GENERAL_ETH_EMAD;
    ku_synd_ioctl.swid = SWID_NUM_DONT_CARE;
    ku_synd_ioctl.type = SX_KU_L2_TYPE_ETH;
    ku_synd_ioctl.is_default = 0;
    ku_synd_ioctl.is_register = 1;
    ku_synd_ioctl.critireas.eth.ethtype = 0;
    ku_synd_ioctl.critireas.eth.dmac = 0;
    ku_synd_ioctl.critireas.eth.emad_tid = app_id;

    ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_SYND;
    ctrl_pack.cmd_body = (void*)&ku_synd_ioctl;

    ret = sxd_ioctl(emad_local_device.handle, &ctrl_pack);
    if (ret) {
        SX_LOG(SX_LOG_ERROR, "sxd_ioctl error: %s\n", strerror(errno));
        err = SXD_STATUS_DEVICE_IOCTL_ERROR;
        goto out;
    }

    ku_synd_ioctl.syndrome_num = SXD_TRAP_ID_SIGNAL;
    ku_synd_ioctl.critireas.eth.emad_tid = 0;
    ret = sxd_ioctl(emad_local_device.handle, &ctrl_pack);
    if (ret) {
        SX_LOG(SX_LOG_WARNING, "Failed registering on signal event. "
               "sxd_ioctl error: %s\n", strerror(errno));
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sxd_status_t __deinit_local_device()
{
    int          ret = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ret = sxd_close_device(emad_local_device.handle);
    if (ret) {
        SX_LOG(SX_LOG_ERROR, "sxd_close_device error: %s\n", strerror(errno));
        err = SXD_STATUS_DEVICE_CLOSE_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t emad_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


static void __change_emad_timeout_set_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sxd_status_t  st;
    unsigned long usec64;
    uint32_t      usec32;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        return;
    }

    usec64 = atol(argv[0]);
    if ((usec64 == 0) || (usec64 > UINT_MAX)) { /* must be positive 32bit value */
        fprintf(stream, "failed to set EMAD timeout, invalid value\n");
    } else {
        usec32 = (uint32_t)usec64;
        st = sxd_emad_timeout_set(usec32);
        if (st == SXD_STATUS_SUCCESS) {
            fprintf(stream, "EMAD timeout changed successfully to %u usec\n", usec32);
        } else {
            fprintf(stream, "failed to set EMAD timeout, status: %u\n", st);
        }
    }
}


static void __change_emad_timeout_get_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    uint32_t emad_timeout;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);
    sxd_emad_timeout_get(&emad_timeout);
    fprintf(stream, "EMAD timeout is currently configured to %u usec\n", emad_timeout);
}


static void __change_emad_string_tlv_mode_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sxd_dev_id_t dev_id;
    const char  *option;

    UNUSED_PARAM(handler_context);

    if (argc != 2) {
        return;
    }

    dev_id = atoi(argv[0]);
    option = argv[1];

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        fprintf(stream, "invalid dev-id (%u)\n", dev_id);
        return;
    }

    if (strcmp(option, "enable") == 0) {
        sxd_dpt_set_string_tlv_cap(dev_id, TRUE);
    } else if (strcmp(option, "disable") == 0) {
        sxd_dpt_set_string_tlv_cap(dev_id, FALSE);
    } else {
        fprintf(stream, "invalid option (%s)\n", option);
    }
}


static void __change_emad_latency_tlv_mode_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sxd_dev_id_t dev_id;
    const char  *option;

    UNUSED_PARAM(handler_context);

    if (argc != 2) {
        return;
    }

    dev_id = atoi(argv[0]);
    option = argv[1];

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        fprintf(stream, "invalid dev-id (%u)\n", dev_id);
        return;
    }

    if (strcmp(option, "enable") == 0) {
        sxd_dpt_set_latency_tlv_cap(dev_id, TRUE);
    } else if (strcmp(option, "disable") == 0) {
        sxd_dpt_set_latency_tlv_cap(dev_id, FALSE);
    } else {
        fprintf(stream, "invalid option (%s)\n", option);
    }
}


sxd_status_t emad_init(uint32_t app_id)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(&emad_local_device, 0, sizeof(emad_local_device_data_t));

    err = __init_local_device(app_id);
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Local device initialization failed.\n");
        goto out;
    }

    sx_utils_debug_cmd_register_path("debug emad timeout set <usec>", __change_emad_timeout_set_cb, NULL);
    sx_utils_debug_cmd_register_path("debug emad timeout get", __change_emad_timeout_get_cb, NULL);
    sx_utils_debug_cmd_register_path("debug emad string_tlv <dev-id> <enable|disable>",
                                     __change_emad_string_tlv_mode_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("debug emad latency_tlv <dev-id> <enable|disable>",
                                     __change_emad_latency_tlv_mode_cb,
                                     NULL);
    #ifdef SNIFFER_PRESENT
    register_debug_cmd_prm_sniffer_activation();
    #endif

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t emad_deinit()
{
    SX_LOG_ENTER();

    __deinit_local_device();

    #ifdef SNIFFER_PRESENT
    unregister_debug_cmd_prm_sniffer_activation();
    #endif

    SX_LOG_EXIT();
    return SXD_STATUS_SUCCESS;
}

sxd_status_t emad_local_device_get(const emad_local_device_data_t **dev_data)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *dev_data = &emad_local_device;

    SX_LOG_EXIT();
    return err;
}

#if defined(PD_BU)

static sxd_reg_id_e last_reg_id_print_s = 0;
static uint16_t     last_reg_id_print_cnt_s = 0;

/*static*/
sxd_status_t __emad_is_reg_supported(sxd_reg_id_e reg_id, boolean_t       *is_supported)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    boolean_t    quiet_mode = TRUE; /* Change to FALSE for verbose printing of not supported register */

    *is_supported = TRUE;
/*
 *   Example how to add limited registers support to PD :
 *
 *   switch (reg_id) {
 *   case SXD_REG_ID_PLD_E:
 *       *is_supported = TRUE;
 *       break;
 *   default:
 *       *is_supported = FALSE;
 *       break;
 *   }
 */

    if (quiet_mode == FALSE) {
        if (*is_supported != TRUE) {
            if (last_reg_id_print_s == reg_id) {
                last_reg_id_print_cnt_s++;
            } else {
                if (last_reg_id_print_cnt_s > 1) {
                    SX_LOG_NTC("__emad_is_reg_supported last print repeated %d times\n", last_reg_id_print_cnt_s);
                }
                SX_LOG_NTC("__emad_is_reg_supported reg_id 0x%x not supported\n", reg_id);
                last_reg_id_print_s = reg_id;
                last_reg_id_print_cnt_s = 1;
            }
        }
    }

    return err;
}
#endif /* #if defined(PD_BU) */


static sxd_status_t __emad_send_single(struct sxd_emad_general_reg_data *reg_data,
                                       sxd_reg_id_e                      reg_id,
                                       sxd_emad_completion_handler_t     handler,
                                       void                             *handler_context,
                                       boolean_t                         is_raw_reg,
                                       sxd_emad_parse_cb_t               parse_cb,
                                       void                             *parse_cb_context)
{
    struct emad_buffer *emad_buffer;
    sxd_status_t        sxd_st;

    UNUSED_PARAM(handler);
    UNUSED_PARAM(handler_context);

#if defined(PD_BU)
    do {
        boolean_t    is_reg_supported = FALSE;
        sxd_status_t err;

        err = __emad_is_reg_supported(reg_id, &is_reg_supported);
        if (err != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Error while checking if reg_id 0x%x supported\n", reg_id);
            return err;
        }

        if (is_reg_supported == FALSE) {
            return err;
        }
    } while (0);
#endif /* #if defined(PD_BU) */

    sxd_st = emad_buffer_alloc(reg_id, is_raw_reg, reg_data, &emad_buffer);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        return sxd_st;
    }

#ifdef SNIFFER_PRESENT
    sxd_st = parse_cb(&emad_buffer->gen_reg_data,
                      emad_buffer->prm_reg_buff,
                      &emad_buffer->reg_size,
                      parse_cb_context,
                      sxd_sniffer_is_activated(reg_id) ? sxd_sniffer_print_data : NULL);
#else
    sxd_st = parse_cb(&emad_buffer->gen_reg_data,
                      emad_buffer->prm_reg_buff,
                      &emad_buffer->reg_size,
                      parse_cb_context,
                      NULL);
#endif

    if (sxd_st != SXD_STATUS_SUCCESS) {
        return sxd_st;
    }

    return emad_buffer_enqueue(emad_buffer);
}


static sxd_status_t __emad_send(struct sxd_emad_general_reg_data *data_arr,
                                uint32_t                          data_num,
                                sxd_reg_id_e                      reg_id,
                                sxd_emad_completion_handler_t     handler,
                                void                             *handler_context,
                                boolean_t                         is_raw_reg,
                                sxd_emad_parse_cb_t               parse_cb,
                                void                             *parse_cb_context)
{
    sxd_status_t sxd_st = SXD_STATUS_SUCCESS;
    boolean_t    dev_id_disabled;
    uint32_t     i;

    for (i = 0; i < data_num; i++) {
        dev_id_disabled = emad_dev_id_is_disabled(data_arr[i].common.dev_id);
        if (dev_id_disabled) {
            sxd_st = SXD_STATUS_TIMEOUT;
            break;
        }

        sxd_st = __emad_send_single(&data_arr[i],
                                    reg_id,
                                    handler,
                                    handler_context,
                                    is_raw_reg,
                                    parse_cb,
                                    parse_cb_context);
        if ((sxd_st != SXD_STATUS_SUCCESS) &&
            (sxd_st != SXD_STATUS_FW_NO_RESOURCES)) {
            SX_LOG_ERR("emad-send failed on register 0x%x, iteration %u, status=%u\n", reg_id, i, sxd_st);
            break;
        }
    }

    return sxd_st;
}


static sxd_status_t __emad_common_set(struct sxd_emad_general_reg_data *data_arr,
                                      uint32_t                          data_num,
                                      sxd_reg_id_e                      reg_id,
                                      sxd_emad_completion_handler_t     handler,
                                      void                             *context,
                                      boolean_t                         is_raw_reg,
                                      sxd_emad_parse_cb_t               parse_cb,
                                      void                             *parse_context)
{
#ifdef SNIFFER_PRESENT
    return sxd_sniffer_emad_common_set(data_arr,
                                       data_num,
                                       reg_id,
                                       handler,
                                       context,
                                       is_raw_reg,
                                       parse_cb,
                                       parse_context,
                                       __emad_send);
#else
    return __emad_send(data_arr,
                       data_num,
                       reg_id,
                       handler,
                       context,
                       is_raw_reg,
                       parse_cb,
                       parse_context);
#endif
}


sxd_status_t emad_common_raw_set(struct sxd_emad_general_reg_data *data_arr,
                                 uint32_t                          data_num,
                                 sxd_reg_id_e                      reg_id,
                                 sxd_emad_completion_handler_t     handler,
                                 void                             *context)
{
    sxd_emad_parse_cb_t parse_cb;
    sxd_status_t        sxd_st;

    sxd_st = sxd_emad_get_reg_parser(SXD_REG_ID_RAW_E, &parse_cb);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        return sxd_st;
    }

    return __emad_common_set(data_arr,
                             data_num,
                             reg_id,
                             handler,
                             context,
                             TRUE,
                             parse_cb,
                             NULL);
}


sxd_status_t emad_common_set(sxd_emad_data_t              *data_arr,
                             uint32_t                      data_num,
                             sxd_reg_id_e                  reg_id,
                             sxd_emad_completion_handler_t handler,
                             void                         *context)
{
    sxd_emad_parse_cb_t parse_cb;
    sxd_status_t        sxd_st;

    sxd_st = sxd_emad_get_reg_parser(reg_id, &parse_cb);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        return sxd_st;
    }

    return __emad_common_set((struct sxd_emad_general_reg_data*)data_arr,
                             data_num,
                             reg_id,
                             handler,
                             context,
                             FALSE,
                             parse_cb,
                             NULL);
}

sxd_status_t emad_common_set_ex(struct sxd_emad_general_reg_data    *data_arr,
                                uint32_t                             data_num,
                                sxd_reg_id_e                         reg_id,
                                sxd_emad_completion_handler_t        handler,
                                void                                *context,
                                const struct access_reg_emad_params* access_reg_emad_params)
{
    return __emad_common_set(data_arr,
                             data_num,
                             reg_id,
                             handler,
                             context,
                             FALSE,
                             access_reg_emad_params->parse_cb,
                             access_reg_emad_params->parse_context);
}

sxd_status_t emad_get_tlv_headers(uint8_t *orig_buff, uint32_t orig_buff_size, sxd_emad_tlv_markers_t *tlv_markers)
{
    uint8_t *buff;
    uint32_t buff_size;
    uint32_t tlv_len;
    int      emad_tlv_type;
    int      budget = SXD_EMAD_MAX_TLV_HEADERS; /* we expect up to 'SXD_EMAD_MAX_HEADERS' TLV headers in the EMAD frame.
                                                 *  'budget' is to make sure we're not in infinite loop here  */
    const char *reason = NULL;

    if (orig_buff_size < sizeof(sxd_emad_header_t)) {
        reason = "Buffer does not even hold the EMAD header!";
        goto bad_emad_frame;
    }

    buff = orig_buff + sizeof(sxd_emad_header_t);
    buff_size = orig_buff_size - sizeof(sxd_emad_header_t);
    memset(tlv_markers, 0, sizeof(*tlv_markers));

    while (budget > 0 && !tlv_markers->end_tlv) {
        emad_tlv_type = EMAD_TLV_TYPE(buff);

        switch (emad_tlv_type) {
        case EMAD_TLV_TYPE_OPERATION_E:
            tlv_markers->operation_tlv = (sxd_emad_operation_t*)buff;
            break;

        case EMAD_TLV_TYPE_STRING_E:
            tlv_markers->string_tlv = (sxd_emad_string_t*)buff;
            break;

        case EMAD_TLV_TYPE_LATENCY_E:
            tlv_markers->latency_tlv = (sxd_emad_latency_t*)buff;
            break;

        case EMAD_TLV_TYPE_REG_E:
            tlv_markers->reg_tlv = (sxd_emad_reg_t*)buff;
            break;

        case EMAD_TLV_TYPE_END_E:
            tlv_markers->end_tlv = (sxd_emad_end_t*)buff;
            break;

        default:
            reason = "Bad TLV type";
            goto bad_emad_frame;
            break;
        }

        tlv_len = EMAD_TLV_LEN(buff) * 4;

        if (tlv_len > buff_size) {
            reason = "Buffer is too short";
            goto bad_emad_frame;
        }

        buff += tlv_len;
        buff_size -= tlv_len;
        budget--;
    }

    /* check that all mandatory TLVs are there */
    if (!tlv_markers->operation_tlv || !tlv_markers->reg_tlv || !tlv_markers->end_tlv) {
        reason = "Mandatory TLV header is missing";
        goto bad_emad_frame;
    }

    return SXD_STATUS_SUCCESS;

bad_emad_frame:
    /* Dump buffer as warning, before logging error - To avoid crash on fatal error mode, before actually dumping the buffer */
    SX_HEXDUMP(SX_LOG_WARNING, orig_buff, orig_buff_size);
    SX_LOG_ERR("Bad EMAD frame [%s]!\n", reason);
    return SXD_STATUS_ERROR;
}

void emad_trigger_notification(uint8_t dev_id, sxd_trap_id_t trap_id, void *buf_p, size_t buf_length)
{
    int             rc = 0;
    struct ku_write ku_write;
    struct ku_iovec iov;

    memset(&ku_write, 0, sizeof(ku_write));
    memset(&iov, 0, sizeof(iov));
    ku_write.meta.swid = 0;
    ku_write.meta.system_port_mid = 0;
    ku_write.meta.to_cpu = 0;
    ku_write.meta.type = SX_PKT_TYPE_LOOPBACK_CTL;
    ku_write.meta.rdq = 0;
    ku_write.meta.lp = 0;
    ku_write.meta.dev_id = dev_id;
    ku_write.meta.etclass = 6;
    ku_write.meta.loopback_data.trap_id = trap_id;
    ku_write.meta.loopback_data.is_lag = 0;
    ku_write.meta.loopback_data.lag_subport = 0;
    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    ku_write.iov->iov_base = buf_p;
    ku_write.iov->iov_len = buf_length;

    rc = sxd_send(emad_local_device.handle, &ku_write, sizeof(struct ku_write));
    if (rc != sizeof(ku_write)) {
        SX_LOG_ERR("Failed sending notification\n");
    }
}

void sync_emad_bpf_stub_func_req(void)
{
    return;
}

void sync_emad_bpf_stub_func_resp(uint32_t time)
{
    UNUSED_PARAM(time);
}

void async_emad_bpf_stub_func_req(uint32_t reg_id, uint64_t emad_tid)
{
    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(emad_tid);
}
void async_emad_bpf_stub_func_resp(uint32_t reg_id, uint64_t emad_tid, uint32_t emad_latency)
{
    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(emad_tid);
    UNUSED_PARAM(emad_latency);
}
