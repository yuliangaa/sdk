/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "emad_transport.h"

#undef  __MODULE__
#define __MODULE__ EMAD_TRANSPORT

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sxd_status_t emad_transport_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


sxd_status_t emad_transport_init(void)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    err = emad_open_tx_thread();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed opening EMAD TX thread\n");
        goto tx_failed;
    }

    err = emad_open_rx_thread();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed opening EMAD RX thread\n");
        goto rx_failed;
    }

    goto out;

rx_failed:
    emad_close_tx_thread();

tx_failed:
out:
    return err;
}


sxd_status_t emad_transport_deinit(void)
{
    emad_close_tx_thread();
    emad_close_rx_thread();

    return SXD_STATUS_SUCCESS;
}
