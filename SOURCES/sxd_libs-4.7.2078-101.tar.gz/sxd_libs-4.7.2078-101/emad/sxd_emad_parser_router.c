/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_router.h>
#include <sx/sxd/sxd_emad_parser_acl.h>
#include <sx/sxd/auto_registers/reg.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_ROUTER


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_router_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

static void sxd_emad_router_ip_ku_to_emad(sxd_router_route_type_t route_type, net32_t* emad_ip, const uint32_t* ku_ip)
{
    uint32_t i;

    if (route_type == SXD_ROUTER_ROUTE_TYPE_IPV4) {
        emad_ip[3] = cl_hton32(ku_ip[0]);
    } else if (route_type == SXD_ROUTER_ROUTE_TYPE_IPV6) {
        for (i = 0; i < 4; i++) {
            emad_ip[i] = cl_hton32(ku_ip[i]);
        }
    }
}

static void sxd_emad_router_ip_emad_to_ku(sxd_router_route_type_t route_type, const net32_t* emad_ip, uint32_t* ku_ip)
{
    uint32_t i;

    if (route_type == SXD_ROUTER_ROUTE_TYPE_IPV4) {
        ku_ip[0] = cl_ntoh32(emad_ip[3]);
    } else if (route_type == SXD_ROUTER_ROUTE_TYPE_IPV6) {
        for (i = 0; i < 4; i++) {
            ku_ip[i] = cl_ntoh32(emad_ip[i]);
        }
    }
}
static void sxd_emad_mc_router_ip_ku_to_emad(sxd_router_mc_route_type_t route_type,
                                             net32_t                  * emad_ip,
                                             const uint32_t           * ku_ip)
{
    uint32_t i;

    if ((route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G0) || (route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G1)) {
        emad_ip[3] = cl_hton32(ku_ip[0]);
    } else if ((route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G0) || (route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G1)) {
        for (i = 0; i < 4; i++) {
            emad_ip[i] = cl_hton32(ku_ip[i]);
        }
    }
}

static void sxd_emad_mc_router_ip_emad_to_ku(sxd_router_mc_route_type_t route_type,
                                             const net32_t            * emad_ip,
                                             uint32_t                 * ku_ip)
{
    uint32_t i;

    if ((route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G0) || (route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G1)) {
        ku_ip[0] = cl_ntoh32(emad_ip[3]);
    } else if ((route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G0) || (route_type == SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G1)) {
        for (i = 0; i < 4; i++) {
            ku_ip[i] = cl_ntoh32(emad_ip[i]);
        }
    }
}
sxd_status_t sxd_emad_parse_rcap(sxd_emad_rcap_data_t *rcap_data, sxd_emad_rcap_reg_t *rcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    rcap_reg->rif = cl_hton16(rcap_data->reg_data->rif);
    rcap_reg->vir_router = rcap_data->reg_data->vir_router;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rcap(sxd_emad_rcap_data_t *rcap_data, sxd_emad_rcap_reg_t *rcap_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    rcap_data->reg_data->rif = cl_ntoh16(rcap_reg->rif);
    rcap_data->reg_data->vir_router = rcap_reg->vir_router;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rgcr(sxd_emad_rgcr_data_t *rgcr_data, sxd_emad_rgcr_reg_t *rgcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rgcr_reg->ipv4_ipv6_mpls = ((rgcr_data->reg_data->ipv4_enable == TRUE) << 7) |
                               ((rgcr_data->reg_data->ipv6_enable == TRUE) << 6) |
                               ((rgcr_data->reg_data->mpls_enable == TRUE) << 5);
    rgcr_reg->max_vlan_router_interfaces = cl_hton16(rgcr_data->reg_data->max_vlan_router_interfaces);
    rgcr_reg->max_port_router_interfaces = cl_hton16(rgcr_data->reg_data->max_port_router_interfaces);
    rgcr_reg->max_pkey_router_interfaces = cl_hton16(rgcr_data->reg_data->max_pkey_router_interfaces);
    rgcr_reg->max_router_interfaces = cl_hton16(rgcr_data->reg_data->max_router_interfaces);
    rgcr_reg->max_virtual_routers = cl_hton16(rgcr_data->reg_data->max_virtual_routers);
    rgcr_reg->grht = rgcr_data->reg_data->grht & 0x0F;
    rgcr_reg->usp_pcprw = ((rgcr_data->reg_data->usp & 0x01) << 4) | (rgcr_data->reg_data->pcp_rw & 0x03);
    rgcr_reg->ipb_allr = (rgcr_data->reg_data->allr == TRUE) | ((rgcr_data->reg_data->ipb == TRUE) << 1);
    rgcr_reg->mcsi_rpf = (rgcr_data->reg_data->rpf == TRUE) | ((rgcr_data->reg_data->mcsi == TRUE) << 4);
    rgcr_reg->ipv6_op_type = rgcr_data->reg_data->ipv6_op_type & 0x3;
    rgcr_reg->ipv6_packet_rate = rgcr_data->reg_data->ipv6_packet_rate & 0x1F;
    rgcr_reg->ipv4_op_type = rgcr_data->reg_data->ipv4_op_type & 0x3;
    rgcr_reg->ipv4_packet_rate = rgcr_data->reg_data->ipv4_packet_rate & 0x1F;
    rgcr_reg->grh_hop_limit = rgcr_data->reg_data->grh_hop_limit;
    rgcr_reg->activity_dis = (rgcr_data->reg_data->activity_dis_uc_route_entry & 0x01) |
                             ((rgcr_data->reg_data->activity_dis_host_entry & 0x01) << 1) |
                             ((rgcr_data->reg_data->activity_dis_adjacency_entry & 0x01) << 2);
    rgcr_reg->expected_irif_list_index_base = cl_hton32(rgcr_data->reg_data->expected_irif_list_index_base) & 0xffffff;
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rgcr(sxd_emad_rgcr_data_t *rgcr_data, sxd_emad_rgcr_reg_t *rgcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rgcr_data->reg_data->ipv4_enable = (rgcr_reg->ipv4_ipv6_mpls >> 7) & 0x01;
    rgcr_data->reg_data->ipv6_enable = (rgcr_reg->ipv4_ipv6_mpls >> 6) & 0x01;
    rgcr_data->reg_data->mpls_enable = (rgcr_reg->ipv4_ipv6_mpls >> 5) & 0x01;
    rgcr_data->reg_data->max_vlan_router_interfaces = cl_ntoh16(rgcr_reg->max_vlan_router_interfaces);
    rgcr_data->reg_data->max_port_router_interfaces = cl_ntoh16(rgcr_reg->max_port_router_interfaces);
    rgcr_data->reg_data->max_pkey_router_interfaces = cl_ntoh16(rgcr_reg->max_pkey_router_interfaces);
    rgcr_data->reg_data->max_router_interfaces = cl_ntoh16(rgcr_reg->max_router_interfaces);
    rgcr_data->reg_data->max_virtual_routers = cl_ntoh16(rgcr_reg->max_virtual_routers);
    rgcr_data->reg_data->grht = rgcr_reg->grht & 0x0F;
    rgcr_data->reg_data->usp = (rgcr_reg->usp_pcprw >> 4) & 0x01;
    rgcr_data->reg_data->pcp_rw = (rgcr_reg->usp_pcprw) & 0x03;
    rgcr_data->reg_data->allr = rgcr_reg->ipb_allr & 0x01;
    rgcr_data->reg_data->ipb = (rgcr_reg->ipb_allr >> 1) & 0x01;
    rgcr_data->reg_data->rpf = rgcr_reg->mcsi_rpf & 0x01;
    rgcr_data->reg_data->mcsi = (rgcr_reg->mcsi_rpf >> 4) & 0x01;
    rgcr_data->reg_data->ipv6_op_type = rgcr_reg->ipv6_op_type & 0x3;
    rgcr_data->reg_data->ipv6_packet_rate = rgcr_reg->ipv6_packet_rate & 0x1F;
    rgcr_data->reg_data->ipv4_op_type = rgcr_reg->ipv4_op_type & 0x3;
    rgcr_data->reg_data->ipv4_packet_rate = rgcr_reg->ipv4_packet_rate & 0x1F;
    rgcr_data->reg_data->grh_hop_limit = rgcr_reg->grh_hop_limit;
    rgcr_data->reg_data->activity_dis_uc_route_entry = rgcr_reg->activity_dis & 0x01;
    rgcr_data->reg_data->activity_dis_host_entry = (rgcr_reg->activity_dis >> 1) & 0x01;
    rgcr_data->reg_data->activity_dis_adjacency_entry = (rgcr_reg->activity_dis >> 2) & 0x01;
    rgcr_data->reg_data->expected_irif_list_index_base = cl_ntoh32(rgcr_reg->expected_irif_list_index_base) &
                                                         0xffffff;
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ritr(sxd_emad_ritr_data_t *ritr_data, sxd_emad_ritr_reg_t *ritr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint8_t      i = 0;

    SX_LOG_ENTER();

    ritr_reg->en_ipv4_ipv6_mc_type_op_mpls = cl_hton16(
        ((ritr_data->reg_data->enable == TRUE) << 15) |
        ((ritr_data->reg_data->valid == TRUE) << 14) |
        ((ritr_data->reg_data->ipv4_enable == TRUE) << 13) |
        ((ritr_data->reg_data->ipv6_enable == TRUE) << 12) |
        ((ritr_data->reg_data->ipv4_mc == TRUE) << 11) |
        ((ritr_data->reg_data->ipv6_mc == TRUE) << 10) |
        ((ritr_data->reg_data->type & 0x0f) << 6) |
        ((ritr_data->reg_data->op & 0x03) << 4) |
        ((ritr_data->reg_data->mpls == TRUE) << 3));
    ritr_reg->router_interface_index = cl_hton16(ritr_data->reg_data->router_interface);
    ritr_reg->ipv4_ipv6_fe_urpf = cl_hton16(
        ((ritr_data->reg_data->ipv4_forward_enable == TRUE) << 13) |
        ((ritr_data->reg_data->ipv6_forward_enable == TRUE) << 12) |
        ((ritr_data->reg_data->ipv4_forward_mc == TRUE) << 11) |
        ((ritr_data->reg_data->ipv6_forward_mc == TRUE) << 10) |
        ((ritr_data->reg_data->lb_en == TRUE) << 8) |
        ((ritr_data->reg_data->urpf_en_ipv4 == TRUE) << 7) |
        ((ritr_data->reg_data->urpf_en_ipv6 == TRUE) << 6) |
        ((ritr_data->reg_data->urpf_strict == TRUE) << 5) |
        ((ritr_data->reg_data->urpf_ad == TRUE) << 4) |
        ((ritr_data->reg_data->mpls_forward == TRUE) << 3));
    ritr_reg->virtual_router = cl_hton16(ritr_data->reg_data->router);
    switch (ritr_data->reg_data->type & 0xF) {
    case VLAN_INTERFACE:
        ritr_reg->rif_properties.router_vlan_interface_properties.swid =
            ritr_data->reg_data->rif_properties.vlan_interface.swid;
        ritr_reg->rif_properties.router_vlan_interface_properties.vlan_id = cl_hton16(
            ritr_data->reg_data->rif_properties.vlan_interface.vlan_id & 0x0FFF);
        ritr_reg->rif_properties.router_vlan_interface_properties.efid = cl_hton16(
            ritr_data->reg_data->rif_properties.vlan_interface.efid);
        ritr_reg->rif_properties.router_vlan_interface_properties.mac_profile_id =
            ritr_data->reg_data->rif_properties.vlan_interface.mac_profile_id & 0x0F;
        memcpy(ritr_reg->rif_properties.router_vlan_interface_properties.router_interface_mac,
               ritr_data->reg_data->rif_properties.vlan_interface.router_interface_mac, 6);
        ritr_reg->rif_properties.router_vlan_interface_properties.vrrp_id_ipv6 =
            ritr_data->reg_data->rif_properties.vlan_interface.vrrp_id_ipv6;
        ritr_reg->rif_properties.router_vlan_interface_properties.vrrp_id_ipv4 =
            ritr_data->reg_data->rif_properties.vlan_interface.vrrp_id_ipv4;
        break;

    case FID_INTERFACE:
        ritr_reg->rif_properties.router_fid_interface_properties.swid =
            ritr_data->reg_data->rif_properties.fid_interface.swid;
        ritr_reg->rif_properties.router_fid_interface_properties.fid = cl_hton16(
            ritr_data->reg_data->rif_properties.fid_interface.fid);
        ritr_reg->rif_properties.router_fid_interface_properties.mac_profile_id =
            ritr_data->reg_data->rif_properties.fid_interface.mac_profile_id & 0x0F;
        memcpy(ritr_reg->rif_properties.router_fid_interface_properties.router_interface_mac,
               ritr_data->reg_data->rif_properties.fid_interface.router_interface_mac, 6);
        ritr_reg->rif_properties.router_fid_interface_properties.vrrp_id_ipv6 =
            ritr_data->reg_data->rif_properties.fid_interface.vrrp_id_ipv6;
        ritr_reg->rif_properties.router_fid_interface_properties.vrrp_id_ipv4 =
            ritr_data->reg_data->rif_properties.fid_interface.vrrp_id_ipv4;
        break;


    case SUB_PORT_INTERFACE:
        ritr_reg->rif_properties.router_sub_port_interface_properties.lag_ar =
            ritr_data->reg_data->rif_properties.sub_port_interface.lag & 0x01;
        ritr_reg->rif_properties.router_sub_port_interface_properties.lag_ar |=
            (ritr_data->reg_data->rif_properties.sub_port_interface.ar & 0x01) << 1;
        ritr_reg->rif_properties.router_sub_port_interface_properties.system_port = cl_hton16(
            ritr_data->reg_data->rif_properties.sub_port_interface.system_port);
        ritr_reg->rif_properties.router_sub_port_interface_properties.efid = cl_hton16(
            ritr_data->reg_data->rif_properties.sub_port_interface.efid);
        ritr_reg->rif_properties.router_sub_port_interface_properties.mac_profile_id =
            ritr_data->reg_data->rif_properties.sub_port_interface.mac_profile_id & 0x0F;
        memcpy(ritr_reg->rif_properties.router_sub_port_interface_properties.router_interface_mac,
               ritr_data->reg_data->rif_properties.sub_port_interface.router_interface_mac, 6);
        ritr_reg->rif_properties.router_sub_port_interface_properties.vlan_id = cl_hton16(
            ritr_data->reg_data->rif_properties.sub_port_interface.vlan_id & 0x0FFF);

        ritr_reg->rif_properties.router_sub_port_interface_properties.vrrp_id_ipv6 =
            ritr_data->reg_data->rif_properties.sub_port_interface.vrrp_id_ipv6;
        ritr_reg->rif_properties.router_sub_port_interface_properties.vrrp_id_ipv4 =
            ritr_data->reg_data->rif_properties.sub_port_interface.vrrp_id_ipv4;

        break;

    case LOOPBACK_INTERFACE:
        ritr_reg->rif_properties.router_loopback_interface_properties.protocol =
            (ritr_data->reg_data->rif_properties.loopback_interface.protocol & 0x0F) << 4;

        switch (ritr_data->reg_data->rif_properties.loopback_interface.protocol) {
        case SXD_ROUTER_LOOPBACK_PROTOCOL_IPV4:
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.ipip_type
                =
                    ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.type & 0x0F;
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.options =
                (ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.options &
                 0x0F) << 4;
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.uvr =
                cl_hton16(ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.uvr);
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
            underlay_router_interface =
                cl_hton16(
                    ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.underlay_router_interface);
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.usip[3] =
                cl_hton32(ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.usip[0]);
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.gre_key =
                cl_hton32(ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.gre_key);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_IPV6:
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.ipip_type
                =
                    ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.type & 0x0F;
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.options =
                (ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.options &
                 0x0F) << 4;
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.uvr =
                cl_hton16(ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.uvr);
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
            underlay_router_interface =
                cl_hton16(
                    ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.underlay_router_interface);
            for (i = 0; i < 4; i++) {
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.usip[i
                ] =
                    cl_hton32(
                        ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.usip[i]);
            }
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.gre_key =
                cl_hton32(ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.gre_key);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_USIP_IPV4:
            ritr_reg->rif_properties.router_loopback_interface_properties.properties.usip_tunnel_interface.usip[3] =
                cl_hton32(ritr_data->reg_data->rif_properties.loopback_interface.properties.usip_tunnel_interface.usip[
                              0]);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_USIP_IPV6:
            for (i = 0; i < 4; i++) {
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.usip_tunnel_interface.usip[i]
                    =
                        cl_hton32(
                            ritr_data->reg_data->rif_properties.loopback_interface.properties.usip_tunnel_interface.usip[
                                i]);
            }
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_GENERIC:
        default:
            /* Other types not supported yet */
            break;
        }
        break;

    case PKEY_INTERFACE:
        ritr_reg->rif_properties.router_pkey_interface_properties.swid =
            ritr_data->reg_data->rif_properties.pkey_interface.swid;
        ritr_reg->rif_properties.router_pkey_interface_properties.pkey = cl_hton16(
            ritr_data->reg_data->rif_properties.pkey_interface.pkey);
        ritr_reg->rif_properties.router_pkey_interface_properties.scope =
            (ritr_data->reg_data->rif_properties.pkey_interface.scope) & 0x0F;
        ritr_reg->rif_properties.router_pkey_interface_properties.qkey = cl_hton32(
            ritr_data->reg_data->rif_properties.pkey_interface.qkey);
        ritr_reg->rif_properties.router_pkey_interface_properties.qpn = cl_hton32(
            ritr_data->reg_data->rif_properties.pkey_interface.qpn & 0x00FFFFFF);
        break;

    case IB_SWID_INTERFACE:
        ritr_reg->rif_properties.router_ib_swid_interface_properties.swid =
            ritr_data->reg_data->rif_properties.ib_swid_interface.swid;
        ritr_reg->rif_properties.router_ib_swid_interface_properties.lid = cl_hton16(
            ritr_data->reg_data->rif_properties.ib_swid_interface.lid);
        ritr_reg->rif_properties.router_ib_swid_interface_properties.lmc =
            ritr_data->reg_data->rif_properties.ib_swid_interface.lmc;
        ritr_reg->rif_properties.router_ib_swid_interface_properties.guid = cl_hton64(
            ritr_data->reg_data->rif_properties.ib_swid_interface.guid);
        break;

    default:
        /* Other types not supported yet */
        break;
    }

    ritr_reg->ttl_threshold = ritr_data->reg_data->ttl_threshold;
    ritr_reg->mtu = cl_hton16(ritr_data->reg_data->mtu);
    ritr_reg->ingress_counter_set = cl_hton32(((ritr_data->reg_data->ingress_counter_set.type & 0xff) << 24) |
                                              (ritr_data->reg_data->ingress_counter_set.index & 0xffffff));
    ritr_reg->egress_counter_set = cl_hton32(((ritr_data->reg_data->egress_counter_set.type & 0xff) << 24) |
                                             (ritr_data->reg_data->egress_counter_set.index & 0xffffff));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ritr(sxd_emad_ritr_data_t * ritr_data, sxd_emad_ritr_reg_t * ritr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint8_t      i = 0;

    SX_LOG_ENTER();

    ritr_data->reg_data->enable = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 15) & 0x01;
    ritr_data->reg_data->valid = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 14) & 0x01;
    ritr_data->reg_data->ipv4_enable = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 13) & 0x01;
    ritr_data->reg_data->ipv6_enable = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 12) & 0x01;
    ritr_data->reg_data->ipv4_mc = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 11) & 0x01;
    ritr_data->reg_data->ipv6_mc = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 10) & 0x01;
    ritr_data->reg_data->type = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 6) & 0x0f;
    ritr_data->reg_data->op = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 4) & 0x03;
    ritr_data->reg_data->mpls = (cl_ntoh16(ritr_reg->en_ipv4_ipv6_mc_type_op_mpls) >> 3) & 0x01;

    ritr_data->reg_data->ipv4_forward_enable = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 13) & 0x01;
    ritr_data->reg_data->ipv6_forward_enable = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 12) & 0x01;
    ritr_data->reg_data->ipv4_forward_mc = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 11) & 0x01;
    ritr_data->reg_data->ipv6_forward_mc = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 10) & 0x01;
    ritr_data->reg_data->lb_en = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 8) & 0x01;
    ritr_data->reg_data->urpf_en_ipv4 = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 7) & 0x01;
    ritr_data->reg_data->urpf_en_ipv6 = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 6) & 0x01;
    ritr_data->reg_data->urpf_strict = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 5) & 0x01;
    ritr_data->reg_data->urpf_ad = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 4) & 0x01;
    ritr_data->reg_data->mpls_forward = (cl_ntoh16(ritr_reg->ipv4_ipv6_fe_urpf) >> 3) & 0x01;


    ritr_data->reg_data->router = cl_ntoh16(ritr_reg->virtual_router);
    switch (ritr_data->reg_data->type) {
    case VLAN_INTERFACE:
        ritr_data->reg_data->rif_properties.vlan_interface.swid =
            ritr_reg->rif_properties.router_vlan_interface_properties.swid;
        ritr_data->reg_data->rif_properties.vlan_interface.vlan_id = cl_ntoh16(
            ritr_reg->rif_properties.router_vlan_interface_properties.vlan_id) & 0x0FFF;
        ritr_data->reg_data->rif_properties.vlan_interface.efid = cl_ntoh16(
            ritr_reg->rif_properties.router_vlan_interface_properties.efid);
        ritr_data->reg_data->rif_properties.vlan_interface.mac_profile_id =
            ritr_reg->rif_properties.router_vlan_interface_properties.mac_profile_id & 0x0F;
        memcpy(ritr_data->reg_data->rif_properties.vlan_interface.router_interface_mac,
               ritr_reg->rif_properties.router_vlan_interface_properties.router_interface_mac, 6);
        ritr_data->reg_data->rif_properties.vlan_interface.vrrp_id_ipv6 =
            ritr_reg->rif_properties.router_vlan_interface_properties.vrrp_id_ipv6;
        ritr_data->reg_data->rif_properties.vlan_interface.vrrp_id_ipv4 =
            ritr_reg->rif_properties.router_vlan_interface_properties.vrrp_id_ipv4;
        break;

    case FID_INTERFACE:
        ritr_data->reg_data->rif_properties.fid_interface.swid =
            ritr_reg->rif_properties.router_fid_interface_properties.swid;
        ritr_data->reg_data->rif_properties.fid_interface.fid = cl_ntoh16(
            ritr_reg->rif_properties.router_fid_interface_properties.fid);
        ritr_data->reg_data->rif_properties.fid_interface.mac_profile_id =
            ritr_reg->rif_properties.router_fid_interface_properties.mac_profile_id & 0x0F;
        memcpy(ritr_data->reg_data->rif_properties.fid_interface.router_interface_mac,
               ritr_reg->rif_properties.router_fid_interface_properties.router_interface_mac, 6);
        ritr_data->reg_data->rif_properties.fid_interface.vrrp_id_ipv6 =
            ritr_reg->rif_properties.router_fid_interface_properties.vrrp_id_ipv6;
        ritr_data->reg_data->rif_properties.fid_interface.vrrp_id_ipv4 =
            ritr_reg->rif_properties.router_fid_interface_properties.vrrp_id_ipv4;
        break;

    case SUB_PORT_INTERFACE:
        ritr_data->reg_data->rif_properties.sub_port_interface.lag =
            ritr_reg->rif_properties.router_sub_port_interface_properties.lag_ar & 0x01;
        ritr_data->reg_data->rif_properties.sub_port_interface.ar =
            (ritr_reg->rif_properties.router_sub_port_interface_properties.lag_ar >> 1) & 0x01;
        ritr_data->reg_data->rif_properties.sub_port_interface.system_port = cl_ntoh16(
            ritr_reg->rif_properties.router_sub_port_interface_properties.system_port);
        ritr_data->reg_data->rif_properties.sub_port_interface.efid = cl_ntoh16(
            ritr_reg->rif_properties.router_sub_port_interface_properties.efid);
        ritr_data->reg_data->rif_properties.sub_port_interface.mac_profile_id =
            ritr_reg->rif_properties.router_sub_port_interface_properties.mac_profile_id & 0x0F;
        memcpy(ritr_data->reg_data->rif_properties.sub_port_interface.router_interface_mac,
               ritr_reg->rif_properties.router_sub_port_interface_properties.router_interface_mac, 6);
        ritr_data->reg_data->rif_properties.sub_port_interface.vlan_id = cl_ntoh16(
            ritr_reg->rif_properties.router_sub_port_interface_properties.vlan_id) & 0x0FFF;
        ritr_data->reg_data->rif_properties.sub_port_interface.vrrp_id_ipv6 =
            ritr_reg->rif_properties.router_sub_port_interface_properties.vrrp_id_ipv6;
        ritr_data->reg_data->rif_properties.sub_port_interface.vrrp_id_ipv4 =
            ritr_reg->rif_properties.router_sub_port_interface_properties.vrrp_id_ipv4;
        break;

    case LOOPBACK_INTERFACE:

        ritr_data->reg_data->rif_properties.loopback_interface.protocol =
            (ritr_reg->rif_properties.router_loopback_interface_properties.protocol >> 4) & 0x0F;

        switch (ritr_data->reg_data->rif_properties.loopback_interface.protocol) {
        case SXD_ROUTER_LOOPBACK_PROTOCOL_IPV4:
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.type =
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
                ipip_type & 0x0F;
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.options =
                (ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
                 options >> 4) & 0x0F;
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.uvr = cl_ntoh16(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.uvr);
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.
            underlay_router_interface = cl_ntoh16(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.underlay_router_interface);
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.usip[0] = cl_ntoh32(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.usip[3]);
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.gre_key = cl_ntoh32(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.gre_key);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_IPV6:
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.type =
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
                ipip_type & 0x0F;
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.options =
                (ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.
                 options >> 4) & 0x0F;
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.uvr = cl_ntoh16(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.uvr);
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.
            underlay_router_interface = cl_ntoh16(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.underlay_router_interface);
            for (i = 0; i < 4; i++) {
                ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.usip[i] =
                    cl_ntoh32(
                        ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.usip[
                            i]);
            }
            ritr_data->reg_data->rif_properties.loopback_interface.properties.l3_tunnel_interface.gre_key = cl_ntoh32(
                ritr_reg->rif_properties.router_loopback_interface_properties.properties.ipinip_tunnel_interface.gre_key);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_USIP_IPV4:
            ritr_data->reg_data->rif_properties.loopback_interface.properties.usip_tunnel_interface.usip[0] =
                cl_ntoh32(
                    ritr_reg->rif_properties.router_loopback_interface_properties.properties.usip_tunnel_interface.usip[
                        3]);
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_USIP_IPV6:
            for (i = 0; i < 4; i++) {
                ritr_data->reg_data->rif_properties.loopback_interface.properties.usip_tunnel_interface.usip[i] =
                    cl_ntoh32(
                        ritr_reg->rif_properties.router_loopback_interface_properties.properties.usip_tunnel_interface.usip[
                            i]);
            }
            break;

        case SXD_ROUTER_LOOPBACK_PROTOCOL_GENERIC:
        default:
            /* Other types not supported yet */
            break;
        }
        break;

    case PKEY_INTERFACE:
        ritr_data->reg_data->rif_properties.pkey_interface.swid =
            ritr_reg->rif_properties.router_pkey_interface_properties.swid;
        ritr_data->reg_data->rif_properties.pkey_interface.pkey = cl_ntoh16(
            ritr_reg->rif_properties.router_pkey_interface_properties.pkey);
        ritr_data->reg_data->rif_properties.pkey_interface.scope =
            (ritr_reg->rif_properties.router_pkey_interface_properties.scope) & 0x0F;
        ritr_data->reg_data->rif_properties.pkey_interface.qkey = cl_ntoh32(
            ritr_reg->rif_properties.router_pkey_interface_properties.qkey);
        ritr_data->reg_data->rif_properties.pkey_interface.qpn = cl_ntoh32(
            ritr_reg->rif_properties.router_pkey_interface_properties.qpn) & 0x00FFFFFF;
        break;

    case IB_SWID_INTERFACE:
        ritr_data->reg_data->rif_properties.ib_swid_interface.swid =
            ritr_reg->rif_properties.router_ib_swid_interface_properties.swid;
        ritr_data->reg_data->rif_properties.ib_swid_interface.lid = cl_ntoh16(
            ritr_reg->rif_properties.router_ib_swid_interface_properties.lid);
        ritr_data->reg_data->rif_properties.ib_swid_interface.lmc =
            ritr_reg->rif_properties.router_ib_swid_interface_properties.lmc;
        ritr_data->reg_data->rif_properties.ib_swid_interface.guid = cl_ntoh64(
            ritr_reg->rif_properties.router_ib_swid_interface_properties.guid);
        break;

    default:
        /* Other types not supported yet */
        break;
    }

    ritr_data->reg_data->mtu = cl_ntoh16(ritr_reg->mtu);
    ritr_data->reg_data->ttl_threshold = ritr_reg->ttl_threshold;
    ritr_data->reg_data->ingress_counter_set.type = (cl_ntoh32(ritr_reg->ingress_counter_set) >> 24) & 0xff;
    ritr_data->reg_data->ingress_counter_set.index = cl_ntoh32(ritr_reg->ingress_counter_set) & 0xffffff;
    ritr_data->reg_data->egress_counter_set.type = (cl_ntoh32(ritr_reg->egress_counter_set) >> 24) & 0xff;
    ritr_data->reg_data->egress_counter_set.index = cl_ntoh32(ritr_reg->egress_counter_set) & 0xffffff;

    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_parse_rigr(sxd_emad_rigr_data_t * rigr_data, sxd_emad_rigr_reg_t * rigr_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    rigr_reg->type_op = (rigr_data->reg_data->op & 0x07) | ((rigr_data->reg_data->types & 0x03) << 4);
    rigr_reg->en = (rigr_data->reg_data->enc & 0x03) << 6;
    rigr_reg->offset = cl_hton16(rigr_data->reg_data->offset & 0x1FFF);
    switch ((rigr_reg->en) >> 6) {
    case ETH_ONLY:
        for (i = 0; i < SXD_RIGR_RIF_MAX; i++) {
            rigr_reg->rif_list.eth_only_rif_list.rif_list[i] = cl_hton32(
                rigr_data->reg_data->rif_list.eth_only_rif_list.rif_list[i]);
        }
        break;

    case ETH_AND_PKEY:
        rigr_reg->rif_list.eth_pkey_rif_list.size = rigr_data->reg_data->rif_list.eth_pkey_rif_list.size;

        for (i = 0; i <= rigr_reg->rif_list.eth_pkey_rif_list.size; i++) {
            rigr_reg->rif_list.eth_pkey_rif_list.adj_list[i].rif_table = cl_hton16(
                rigr_data->reg_data->rif_list.eth_pkey_rif_list.adj_list[i].rif_table);
            rigr_reg->rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index = cl_hton16(
                rigr_data->reg_data->rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index);
        }
        break;
    }
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rigr(sxd_emad_rigr_data_t * rigr_data, sxd_emad_rigr_reg_t * rigr_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rigr_reg->en = (rigr_data->reg_data->enc >> 6) & 0x03;
    switch (rigr_reg->en) {
    case ETH_ONLY:
        for (i = 0; i < SXD_RIGR_RIF_MAX; i++) {
            rigr_data->reg_data->rif_list.eth_only_rif_list.rif_list[i] = cl_ntoh32(
                rigr_reg->rif_list.eth_only_rif_list.rif_list[i]);
        }
        break;

    case ETH_AND_PKEY:
        rigr_data->reg_data->rif_list.eth_pkey_rif_list.size = rigr_reg->rif_list.eth_pkey_rif_list.size;
        for (i = 0; i <= rigr_data->reg_data->rif_list.eth_pkey_rif_list.size; i++) {
            rigr_data->reg_data->rif_list.eth_pkey_rif_list.adj_list[i].rif_table = cl_ntoh16(
                rigr_reg->rif_list.eth_pkey_rif_list.adj_list[i].rif_table >> 4) |
                                                                                    (rigr_reg->rif_list.
                                                                                     eth_pkey_rif_list.adj_list[i].
                                                                                     rif_table & 0x07);
            rigr_data->reg_data->rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index = cl_ntoh16(
                rigr_reg->rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index);
        }
        break;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rtar(sxd_emad_rtar_data_t * rtar_data, sxd_emad_rtar_reg_t * rtar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtar_reg->op_eb = (rtar_data->reg_data->operation & 0x0F) << 4;
    rtar_reg->op_eb |= (rtar_data->reg_data->external_bind == TRUE) ? 1 : 0;
    rtar_reg->key_type = rtar_data->reg_data->type;
    rtar_reg->region_size = cl_hton16(rtar_data->reg_data->tcam_size);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rtar(sxd_emad_rtar_data_t * rtar_data, sxd_emad_rtar_reg_t * rtar_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtar_data->reg_data->operation = (rtar_reg->op_eb >> 4) & 0x0F;
    rtar_data->reg_data->external_bind = (rtar_reg->op_eb & 0x01);
    rtar_data->reg_data->type = rtar_reg->key_type;
    rtar_data->reg_data->tcam_size = cl_ntoh16(rtar_reg->region_size);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_recr(sxd_emad_recr_data_t * recr_data, sxd_emad_recr_reg_t * recr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    recr_reg->sh = (recr_data->reg_data->symmetric_hash == TRUE);
    recr_reg->type = recr_data->reg_data->hash_type & 0x0F;
    recr_reg->ecmp_hash = cl_hton32(recr_data->reg_data->hash_configuration & 0x000FFFFF);
    recr_reg->seed = cl_hton32(recr_data->reg_data->seed);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_recr(sxd_emad_recr_data_t * recr_data, sxd_emad_recr_reg_t * recr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    recr_data->reg_data->symmetric_hash = recr_reg->sh & 0x01;
    recr_data->reg_data->hash_type = recr_reg->type & 0x0F;
    recr_data->reg_data->hash_configuration = cl_ntoh32(recr_reg->ecmp_hash) & 0x000FFFFF;
    recr_data->reg_data->seed = cl_ntoh32(recr_reg->seed);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_recr_v2(sxd_emad_recr_v2_data_t * recr_v2_data, sxd_emad_recr_v2_reg_t * recr_v2_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    recr_v2_reg->pp = recr_v2_data->reg_data->per_port_configuration & 0x01;
    recr_v2_reg->local_port = recr_v2_data->reg_data->local_port;
    recr_v2_reg->lp_msb_and_sh = (recr_v2_data->reg_data->lp_msb & 0x03) << 4;
    recr_v2_reg->lp_msb_and_sh |= recr_v2_data->reg_data->symmetric_hash & 0x01;
    recr_v2_reg->type = recr_v2_data->reg_data->hash_type & 0x0F;
    recr_v2_reg->seed = cl_hton32(recr_v2_data->reg_data->seed);
    recr_v2_reg->general_fields = cl_hton32(recr_v2_data->reg_data->general_fields);
    recr_v2_reg->outer_header_enables = cl_hton16(recr_v2_data->reg_data->outer_header_enables);
    for (i = 0; i < 5; i++) {
        recr_v2_reg->outer_header_field_enables[i] =
            cl_hton32(recr_v2_data->reg_data->outer_header_field_enables[4 - i]);
    }
    recr_v2_reg->inner_header_enables = cl_hton16(recr_v2_data->reg_data->inner_header_enables);
    recr_v2_reg->inner_header_field_enables = cl_hton64(recr_v2_data->reg_data->inner_header_field_enables);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_recr_v2(sxd_emad_recr_v2_data_t * recr_v2_data, sxd_emad_recr_v2_reg_t * recr_v2_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    recr_v2_data->reg_data->per_port_configuration = recr_v2_reg->pp & 0x01;
    recr_v2_data->reg_data->local_port = recr_v2_reg->local_port;
    recr_v2_data->reg_data->lp_msb = (recr_v2_reg->lp_msb_and_sh >> 4) & 0x03;
    recr_v2_data->reg_data->symmetric_hash = recr_v2_reg->lp_msb_and_sh & 0x01;
    recr_v2_data->reg_data->hash_type = recr_v2_reg->type & 0xF;
    recr_v2_data->reg_data->seed = cl_ntoh32(recr_v2_reg->seed);
    recr_v2_data->reg_data->general_fields = cl_ntoh32(recr_v2_reg->general_fields);
    recr_v2_data->reg_data->outer_header_enables = cl_ntoh16(recr_v2_reg->outer_header_enables);
    for (i = 0; i < 5; i++) {
        recr_v2_data->reg_data->outer_header_field_enables[i] =
            cl_ntoh32(recr_v2_reg->outer_header_field_enables[4 - i]);
    }
    recr_v2_data->reg_data->inner_header_enables = cl_ntoh16(recr_v2_reg->inner_header_enables);
    recr_v2_data->reg_data->inner_header_field_enables = cl_ntoh64(recr_v2_reg->inner_header_field_enables);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ruft(sxd_emad_ruft_data_t * ruft_data, sxd_emad_ruft_reg_t * ruft_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ruft_reg->v_type = ((ruft_data->reg_data->valid == TRUE) << 7) |
                       (ruft_data->reg_data->route_type & 0x03);
    ruft_reg->op_a = ((ruft_data->reg_data->operation & 0x07) << 4) |
                     (ruft_data->reg_data->activity == TRUE);
    ruft_reg->offset = cl_hton16(ruft_data->reg_data->offset);
    ruft_reg->virtual_router = cl_hton16(ruft_data->reg_data->router);

    sxd_emad_router_ip_ku_to_emad(ruft_data->reg_data->route_type, ruft_reg->dip, ruft_data->reg_data->destination_ip);
    sxd_emad_router_ip_ku_to_emad(ruft_data->reg_data->route_type,
                                  ruft_reg->dip_mask,
                                  ruft_data->reg_data->destination_ip_mask);

    ruft_reg->ecmp_hash = cl_hton32(ruft_data->reg_data->ecmp_hash);
    ruft_reg->ecmp_hash_mask = cl_hton32(ruft_data->reg_data->ecmp_hash_mask);
    ruft_reg->trap = (ruft_data->reg_data->route_action & 0x0F) << 4;
    ruft_reg->trap_group = ruft_data->reg_data->trap_group;
    ruft_reg->trap_id = cl_hton16((ruft_data->reg_data->trap_id & 0x01FF) | 0x1C0);
    ruft_reg->m_mirror_dst = ((ruft_data->reg_data->mirror_enable == TRUE) << 7) |
                             (ruft_data->reg_data->mirror_dst & 0x07);
    ruft_reg->prio_qos = ((ruft_data->reg_data->prio & 0x07) << 4) |
                         (ruft_data->reg_data->qos & 0x03);
    ruft_reg->ecmp_size = ruft_data->reg_data->ecmp_size;
    ruft_reg->table = ruft_data->reg_data->table & 0x07;
    ruft_reg->adjacency_index = cl_hton16(ruft_data->reg_data->adjacency_index & 0xFFFF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ruft(sxd_emad_ruft_data_t * ruft_data, sxd_emad_ruft_reg_t * ruft_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ruft_data->reg_data->valid = (ruft_reg->v_type >> 7) & 0x01;
    ruft_data->reg_data->activity = ruft_reg->op_a & 0x01;
    ruft_data->reg_data->router = cl_ntoh16(ruft_reg->virtual_router);

    sxd_emad_router_ip_emad_to_ku(ruft_data->reg_data->route_type, ruft_reg->dip, ruft_data->reg_data->destination_ip);
    sxd_emad_router_ip_emad_to_ku(ruft_data->reg_data->route_type,
                                  ruft_reg->dip_mask,
                                  ruft_data->reg_data->destination_ip_mask);

    ruft_data->reg_data->ecmp_hash = cl_ntoh32(ruft_reg->ecmp_hash);
    ruft_data->reg_data->ecmp_hash_mask = cl_ntoh32(ruft_reg->ecmp_hash_mask);
    ruft_data->reg_data->route_action = (ruft_reg->trap >> 4) & 0x0F;
    ruft_data->reg_data->trap_group = ruft_reg->trap_group;
    ruft_data->reg_data->trap_id = cl_ntoh16(ruft_reg->trap_id) & 0x01FF;
    ruft_data->reg_data->mirror_enable = (ruft_reg->m_mirror_dst >> 7) & 0x01;
    ruft_data->reg_data->mirror_dst = ruft_reg->m_mirror_dst & 0x07;
    ruft_data->reg_data->prio = (ruft_reg->prio_qos >> 4) & 0x07;
    ruft_data->reg_data->qos = ruft_reg->prio_qos & 0x03;
    ruft_data->reg_data->ecmp_size = ruft_reg->ecmp_size;
    ruft_data->reg_data->table = ruft_reg->table & 0x07;
    ruft_data->reg_data->adjacency_index = cl_ntoh16(ruft_reg->adjacency_index);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ruht(sxd_emad_ruht_data_t * ruht_data, sxd_emad_ruht_reg_t * ruht_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ruht_reg->v_type = ((ruht_data->reg_data->valid == TRUE) << 7) |
                       ((ruht_data->reg_data->offset_enable == TRUE) << 6) |
                       (ruht_data->reg_data->route_type & 0x03);
    ruht_reg->op_a = ((ruht_data->reg_data->operation & 0x07) << 4) |
                     (ruht_data->reg_data->activity == TRUE);
    ruht_reg->offset = cl_hton16(ruht_data->reg_data->offset);
    ruht_reg->virtual_router = ruht_data->reg_data->router;

    sxd_emad_router_ip_ku_to_emad(ruht_data->reg_data->route_type, ruht_reg->dip, ruht_data->reg_data->destination_ip);

    ruht_reg->ecmp_hash = cl_hton32(ruht_data->reg_data->ecmp_hash);
    ruht_reg->ecmp_hash_mask = cl_hton32(ruht_data->reg_data->ecmp_hash_mask);
    ruht_reg->trap = (ruht_data->reg_data->route_action & 0x0F) << 4;
    ruht_reg->trap_group = ruht_data->reg_data->trap_group;
    ruht_reg->trap_id = cl_hton16((ruht_data->reg_data->trap_id & 0x01FF) | 0x1C0);
    ruht_reg->prio_qos = ruht_data->reg_data->qos & 0x3;
    ruht_reg->table = ruht_data->reg_data->table & 0x07;
    ruht_reg->adjacency_index = cl_hton16(ruht_data->reg_data->adjacency_index & 0xFFFF);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ruht(sxd_emad_ruht_data_t * ruht_data, sxd_emad_ruht_reg_t * ruht_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ruht_data->reg_data->valid = (ruht_reg->v_type >> 7) & 0x01;
    ruht_data->reg_data->offset_enable = (ruht_reg->v_type >> 6) & 0x01;
    ruht_data->reg_data->activity = ruht_reg->op_a & 0x01;
    ruht_data->reg_data->offset = cl_ntoh16(ruht_reg->offset);
    ruht_data->reg_data->router = ruht_reg->virtual_router;

    sxd_emad_router_ip_emad_to_ku(ruht_data->reg_data->route_type, ruht_reg->dip, ruht_data->reg_data->destination_ip);
    ruht_data->reg_data->ecmp_hash = cl_ntoh32(ruht_reg->ecmp_hash);
    ruht_data->reg_data->ecmp_hash_mask = cl_ntoh32(ruht_reg->ecmp_hash_mask);
    ruht_data->reg_data->route_action = (ruht_reg->trap >> 4) & 0x0F;
    ruht_data->reg_data->trap_group = ruht_reg->trap_group;
    ruht_data->reg_data->trap_id = cl_ntoh16(ruht_reg->trap_id) & 0x01FF;
    ruht_data->reg_data->qos = ruht_reg->prio_qos & 0x3;
    ruht_data->reg_data->table = ruht_reg->table & 0x07;
    ruht_data->reg_data->adjacency_index = cl_ntoh16(ruht_reg->adjacency_index);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rauht(sxd_emad_rauht_data_t *rauht_data, sxd_emad_rauht_reg_t *rauht_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rauht_reg->type = (rauht_data->reg_data->route_type & 0x03);
    rauht_reg->op_a = ((rauht_data->reg_data->operation & 0x07) << 4) |
                      (rauht_data->reg_data->activity & 0x01);
    rauht_reg->rif = cl_hton16(rauht_data->reg_data->rif);

    sxd_emad_router_ip_ku_to_emad(rauht_data->reg_data->route_type,
                                  rauht_reg->dip,
                                  rauht_data->reg_data->destination_ip);

    rauht_reg->trap_action = ((rauht_data->reg_data->trap_action & 0x0F) << 4);
    rauht_reg->trap_id = rauht_data->reg_data->trap_id;
    rauht_reg->counter_set = cl_hton32(((rauht_data->reg_data->counter_set.type & 0xff) << 24) |
                                       (rauht_data->reg_data->counter_set.index & 0xffffff));

    memcpy(rauht_reg->mac_addr, rauht_data->reg_data->mac_addr.ether_addr_octet, 6);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rauht(sxd_emad_rauht_data_t *rauht_data, sxd_emad_rauht_reg_t *rauht_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rauht_data->reg_data->route_type = rauht_reg->type & 0x03;
    rauht_data->reg_data->operation = (rauht_reg->op_a >> 4) & 0x07;
    rauht_data->reg_data->activity = rauht_reg->op_a & 0x01;
    rauht_data->reg_data->rif = cl_ntoh16(rauht_reg->rif);

    sxd_emad_router_ip_emad_to_ku(rauht_data->reg_data->route_type,
                                  rauht_reg->dip,
                                  rauht_data->reg_data->destination_ip);

    rauht_data->reg_data->trap_action = (rauht_reg->trap_action >> 4) & 0xF;
    rauht_data->reg_data->trap_id = rauht_reg->trap_id;
    rauht_data->reg_data->counter_set.type = (cl_ntoh32(rauht_reg->counter_set) >> 24) & 0xff;
    rauht_data->reg_data->counter_set.index = cl_ntoh32(rauht_reg->counter_set) & 0xffffff;

    memcpy(rauht_data->reg_data->mac_addr.ether_addr_octet, rauht_reg->mac_addr, 6);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rauhtd(sxd_emad_rauhtd_data_t *rauhtd_data, sxd_emad_rauhtd_reg_t *rauhtd_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rauhtd_reg->filter_fields = rauhtd_data->reg_data->filter_fields;
    rauhtd_reg->op = (rauhtd_data->reg_data->op & 0x03);
    rauhtd_reg->num_rec = rauhtd_data->reg_data->num_of_rec;
    rauhtd_reg->entry_a = (rauhtd_data->reg_data->entry_a & 0x01);
    rauhtd_reg->entry_type = (rauhtd_data->reg_data->entry_type & 0x0F);
    rauhtd_reg->entry_rif = cl_hton16(rauhtd_data->reg_data->entry_rif);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rauhtd(sxd_emad_rauhtd_data_t *rauhtd_data, sxd_emad_rauhtd_reg_t *rauhtd_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;
    uint32_t     j = 0;

    SX_LOG_ENTER();

    rauhtd_data->reg_data->filter_fields = rauhtd_reg->filter_fields;
    rauhtd_data->reg_data->op = (rauhtd_reg->op & 0x03);
    rauhtd_data->reg_data->num_of_rec = rauhtd_reg->num_rec;
    rauhtd_data->reg_data->entry_a = (rauhtd_reg->entry_a & 0x01);
    rauhtd_data->reg_data->entry_type = (rauhtd_reg->entry_type & 0x0F);
    rauhtd_data->reg_data->entry_rif = cl_ntoh16(rauhtd_reg->entry_rif);

    if (rauhtd_data->reg_data->entry_type == SXD_ROUTER_ROUTE_TYPE_IPV4) {
        for (i = 0; i < rauhtd_data->reg_data->num_of_rec; i++) {
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.num_entries =
                ((rauhtd_reg->dump_record[i].ipv4_dump_record.num_entries_type >> 4) & 0x03);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.type = SXD_ROUTER_ROUTE_TYPE_IPV4;
            /*Retrieve first entry*/
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[0].a =
                (rauhtd_reg->dump_record[i].ipv4_dump_record.a0 & 0x01);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[0].rif =
                cl_ntoh16(rauhtd_reg->dump_record[i].ipv4_dump_record.rif0);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[0].dip =
                cl_ntoh32(rauhtd_reg->dump_record[i].ipv4_dump_record.dip0);
            /*Retrieve second entry*/
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[1].a =
                (rauhtd_reg->dump_record[i].ipv4_dump_record.a1 & 0x01);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[1].rif =
                cl_ntoh16(rauhtd_reg->dump_record[i].ipv4_dump_record.rif1);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[1].dip =
                cl_ntoh32(rauhtd_reg->dump_record[i].ipv4_dump_record.dip1);
            /*Retrieve third entry*/
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[2].a =
                (rauhtd_reg->dump_record[i].ipv4_dump_record.a2 & 0x01);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[2].rif =
                cl_ntoh16(rauhtd_reg->dump_record[i].ipv4_dump_record.rif2);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[2].dip =
                cl_ntoh32(rauhtd_reg->dump_record[i].ipv4_dump_record.dip2);
            /*Retrieve forth entry*/
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[3].a =
                (rauhtd_reg->dump_record[i].ipv4_dump_record.a3 & 0x01);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[3].rif =
                cl_ntoh16(rauhtd_reg->dump_record[i].ipv4_dump_record.rif3);
            rauhtd_data->reg_data->dump_record[i].ipv4_entry.entry[3].dip =
                cl_ntoh32(rauhtd_reg->dump_record[i].ipv4_dump_record.dip3);
        }
    } else if (rauhtd_data->reg_data->entry_type == SXD_ROUTER_ROUTE_TYPE_IPV6) {
        for (i = 0; i < rauhtd_data->reg_data->num_of_rec; i++) {
            rauhtd_data->reg_data->dump_record[i].ipv6_entry.type = SXD_ROUTER_ROUTE_TYPE_IPV6;
            rauhtd_data->reg_data->dump_record[i].ipv6_entry.a =
                (rauhtd_reg->dump_record[i].ipv6_dump_record.a & 0x01);
            rauhtd_data->reg_data->dump_record[i].ipv6_entry.rif =
                cl_ntoh16(rauhtd_reg->dump_record[i].ipv6_dump_record.rif);
            for (j = 0; j < 4; j++) {
                rauhtd_data->reg_data->dump_record[i].ipv6_entry.dip[j] =
                    cl_hton32(rauhtd_reg->dump_record[i].ipv6_dump_record.dip[j]);
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmft(sxd_emad_rmft_data_t *rmft_data, sxd_emad_rmft_reg_t *rmft_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmft_reg->v_type = ((rmft_data->reg_data->valid == TRUE) << 7) |
                       ((rmft_data->reg_data->route_type & 0x03) << 4);
    rmft_reg->op_a = ((rmft_data->reg_data->operation & 0x07) << 4) |
                     (rmft_data->reg_data->activity == TRUE ? 1 : 0);
    rmft_reg->offset = cl_hton16(rmft_data->reg_data->offset);
    rmft_reg->virtual_router = rmft_data->reg_data->router;

    sxd_emad_router_ip_ku_to_emad(rmft_data->reg_data->route_type, rmft_reg->dip, rmft_data->reg_data->destination_ip);
    sxd_emad_router_ip_ku_to_emad(rmft_data->reg_data->route_type,
                                  rmft_reg->dip_mask,
                                  rmft_data->reg_data->destination_ip_mask);
    sxd_emad_router_ip_ku_to_emad(rmft_data->reg_data->route_type, rmft_reg->sip, rmft_data->reg_data->source_ip);
    sxd_emad_router_ip_ku_to_emad(rmft_data->reg_data->route_type,
                                  rmft_reg->sip_mask,
                                  rmft_data->reg_data->source_ip_mask);

    rmft_reg->ecmp_hash = cl_hton32(rmft_data->reg_data->ecmp_hash);
    rmft_reg->ecmp_hash_mask = cl_hton32(rmft_data->reg_data->ecmp_hash_mask);
    rmft_reg->trap = (rmft_data->reg_data->route_action & 0x0F) << 4;
    rmft_reg->trap_group = rmft_data->reg_data->trap_group & 0x0F;
    rmft_reg->trap_id = cl_hton16((rmft_data->reg_data->trap_id & 0x01FF) | 0x1C0);
    rmft_reg->prio_qos = rmft_data->reg_data->qos & 0x3;
    rmft_reg->ttl_cmd = (rmft_data->reg_data->ttl_cmd & 0x03);
    rmft_reg->ttl_value = rmft_data->reg_data->ttl_value;
    rmft_reg->rpf_assert = ((rmft_data->reg_data->rpf & 0x07) << 4) |
                           ((rmft_data->reg_data->assert_check == TRUE) << 7);
    rmft_reg->expected_ingress_rif = cl_hton16(rmft_data->reg_data->expected_ingress_rif);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmft(sxd_emad_rmft_data_t * rmft_data, sxd_emad_rmft_reg_t * rmft_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmft_data->reg_data->valid = (rmft_reg->v_type >> 7) & 0x01;
    rmft_data->reg_data->activity = (rmft_reg->op_a & 0x01);
    rmft_data->reg_data->router = rmft_reg->virtual_router;
    sxd_emad_router_ip_emad_to_ku(rmft_data->reg_data->route_type, rmft_reg->dip, rmft_data->reg_data->destination_ip);
    sxd_emad_router_ip_emad_to_ku(rmft_data->reg_data->route_type,
                                  rmft_reg->dip_mask,
                                  rmft_data->reg_data->destination_ip_mask);
    sxd_emad_router_ip_emad_to_ku(rmft_data->reg_data->route_type, rmft_reg->sip, rmft_data->reg_data->source_ip);
    sxd_emad_router_ip_emad_to_ku(rmft_data->reg_data->route_type,
                                  rmft_reg->sip_mask,
                                  rmft_data->reg_data->source_ip_mask);
    rmft_data->reg_data->ecmp_hash = cl_ntoh32(rmft_reg->ecmp_hash);
    rmft_data->reg_data->ecmp_hash_mask = cl_ntoh32(rmft_reg->ecmp_hash_mask);
    rmft_data->reg_data->route_action = (rmft_reg->trap >> 4) & 0x0F;
    rmft_data->reg_data->trap_group = rmft_reg->trap_group;
    rmft_data->reg_data->trap_id = cl_ntoh16(rmft_reg->trap_id) & 0x01FF;
    rmft_data->reg_data->qos = rmft_reg->prio_qos & 0x3;
    rmft_data->reg_data->ttl_cmd = (rmft_reg->ttl_cmd == TRUE) << 1;
    rmft_data->reg_data->ttl_value = rmft_reg->ttl_value;
    rmft_data->reg_data->rpf = (rmft_reg->rpf_assert >> 7) & 0x01;
    rmft_data->reg_data->assert_check = (rmft_reg->rpf_assert >> 6) & 0x01;
    rmft_data->reg_data->expected_ingress_rif = cl_ntoh16(rmft_reg->expected_ingress_rif);


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmft_v2(sxd_emad_rmft_v2_data_t *rmft_v2_data, sxd_emad_rmft_v2_reg_t *rmft_v2_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmft_v2_reg->v_type = ((rmft_v2_data->reg_data->valid & 0x1) << 7) |
                          ((rmft_v2_data->reg_data->route_type & 0x03) << 4);
    rmft_v2_reg->op_a = ((rmft_v2_data->reg_data->operation & 0x07) << 4) |
                        (rmft_v2_data->reg_data->activity & 0x1);
    rmft_v2_reg->offset = cl_hton16(rmft_v2_data->reg_data->offset);
    rmft_v2_reg->virtual_router = cl_hton16(rmft_v2_data->reg_data->router);
    rmft_v2_reg->irif = cl_hton16(rmft_v2_data->reg_data->irif);
    rmft_v2_reg->irif_mask = rmft_v2_data->reg_data->irif_mask & 0x1;

    sxd_emad_mc_router_ip_ku_to_emad(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->dip,
                                     rmft_v2_data->reg_data->destination_ip);
    sxd_emad_mc_router_ip_ku_to_emad(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->dip_mask,
                                     rmft_v2_data->reg_data->destination_ip_mask);
    sxd_emad_mc_router_ip_ku_to_emad(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->sip,
                                     rmft_v2_data->reg_data->source_ip);
    sxd_emad_mc_router_ip_ku_to_emad(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->sip_mask,
                                     rmft_v2_data->reg_data->source_ip_mask);

    sxd_emad_parse_flex_action(&rmft_v2_data->reg_data->flexible_action_set, &rmft_v2_reg->flexible_action_set);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmft_v2(sxd_emad_rmft_v2_data_t * rmft_v2_data, sxd_emad_rmft_v2_reg_t * rmft_v2_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmft_v2_data->reg_data->valid = (rmft_v2_reg->v_type >> 7) & 0x01;
    rmft_v2_data->reg_data->activity = (rmft_v2_reg->op_a & 0x01);
    rmft_v2_data->reg_data->router = cl_ntoh16(rmft_v2_reg->virtual_router);
    rmft_v2_data->reg_data->irif = cl_ntoh16(rmft_v2_reg->irif);
    rmft_v2_data->reg_data->irif_mask = (rmft_v2_reg->irif_mask & 0x01) ? TRUE : FALSE;
    sxd_emad_mc_router_ip_emad_to_ku(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->dip,
                                     rmft_v2_data->reg_data->destination_ip);
    sxd_emad_mc_router_ip_emad_to_ku(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->dip_mask,
                                     rmft_v2_data->reg_data->destination_ip_mask);
    sxd_emad_mc_router_ip_emad_to_ku(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->sip,
                                     rmft_v2_data->reg_data->source_ip);
    sxd_emad_mc_router_ip_emad_to_ku(rmft_v2_data->reg_data->route_type,
                                     rmft_v2_reg->sip_mask,
                                     rmft_v2_data->reg_data->source_ip_mask);

    sxd_emad_deparse_flex_action(&rmft_v2_data->reg_data->flexible_action_set, &rmft_v2_reg->flexible_action_set);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmftad(sxd_emad_rmftad_data_t *rmftad_data, sxd_emad_rmftad_reg_t *rmftad_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mlxsw_reg_rmftad_op_set(rmftad_reg->reg, rmftad_data->reg_data->operation);
    mlxsw_reg_rmftad_type_set(rmftad_reg->reg, rmftad_data->reg_data->route_type);
    mlxsw_reg_rmftad_offset_set(rmftad_reg->reg, rmftad_data->reg_data->offset);
    mlxsw_reg_rmftad_num_rec_set(rmftad_reg->reg, rmftad_data->reg_data->num_entries);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmftad(sxd_emad_rmftad_data_t *rmftad_data, sxd_emad_rmftad_reg_t *rmftad_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    int          index = 0;

    SX_LOG_ENTER();

    rmftad_data->reg_data->operation = mlxsw_reg_rmftad_op_get(rmftad_reg->reg);
    rmftad_data->reg_data->route_type = mlxsw_reg_rmftad_type_get(rmftad_reg->reg);
    rmftad_data->reg_data->offset = mlxsw_reg_rmftad_offset_get(rmftad_reg->reg);
    rmftad_data->reg_data->num_entries = mlxsw_reg_rmftad_num_rec_get(rmftad_reg->reg);

    for (index = 0; index < SXD_RMFTAD_ACTIVITIES_VECTOR_SIZE; index++) {
        rmftad_data->reg_data->activities[index] = mlxsw_reg_rmftad_activity_vector_get(rmftad_reg->reg, 0, index);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ptcead(sxd_emad_ptcead_data_t *ptcead_data, sxd_emad_ptcead_reg_t *ptcead_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mlxsw_reg_ptcead_op_set(ptcead_reg->reg, (uint32_t)ptcead_data->reg_data->operation);
    mlxsw_reg_ptcead_offset_set(ptcead_reg->reg, (uint32_t)ptcead_data->reg_data->offset);
    mlxsw_reg_ptcead_num_rec_set(ptcead_reg->reg, (uint32_t)ptcead_data->reg_data->num_entries);
    mlxsw_reg_ptcead_tcam_region_info_memcpy_to(ptcead_reg->reg, (char*)ptcead_data->reg_data->tcam_region_info);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ptcead(sxd_emad_ptcead_data_t *ptcead_data, sxd_emad_ptcead_reg_t *ptcead_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    int          index = 0;

    SX_LOG_ENTER();

    ptcead_data->reg_data->operation = mlxsw_reg_ptcead_op_get(ptcead_reg->reg);
    ptcead_data->reg_data->offset = mlxsw_reg_ptcead_offset_get(ptcead_reg->reg);
    ptcead_data->reg_data->num_entries = mlxsw_reg_ptcead_num_rec_get(ptcead_reg->reg);
    for (index = 0; index < SXD_PTCEAD_ACTIVITIES_VECTOR_SIZE; index++) {
        ptcead_data->reg_data->activities[index] = mlxsw_reg_ptcead_activity_vector_get(ptcead_reg->reg, 0, index);
    }
    mlxsw_reg_ptcead_tcam_region_info_memcpy_from(ptcead_reg->reg, (char*)ptcead_data->reg_data->tcam_region_info);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ratr(sxd_emad_ratr_data_t * ratr_data, sxd_emad_ratr_reg_t * ratr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ratr_reg->op_valid = (ratr_data->reg_data->operation & 0x0F) << 4;
    ratr_reg->op_valid = ratr_reg->op_valid | (ratr_data->reg_data->valid & 0x01);
    ratr_reg->activity = ratr_data->reg_data->activity & 0x01;
    ratr_reg->size = cl_hton16(ratr_data->reg_data->size);
    ratr_reg->type = (ratr_data->reg_data->type & 0x0F) << 4;
    ratr_reg->table = ratr_data->reg_data->table & 0x07;
    ratr_reg->adjacency_index = cl_hton16(ratr_data->reg_data->adjacency_index);
    ratr_reg->egress_rif = cl_hton16(ratr_data->reg_data->egress_rif);
    ratr_reg->trap_action = (ratr_data->reg_data->trap_action & 0x0F) << 4;
    ratr_reg->adj_idx_msb = ratr_data->reg_data->adjacency_index_msb;
    ratr_reg->trap_id = cl_hton16(ratr_data->reg_data->trap_id & 0x1FF);
    switch ((ratr_reg->type) >> 4) {
    case ETHERNET:
        memcpy(ratr_reg->adj_parameters.eth_adj_parameters.destination_mac,
               ratr_data->reg_data->adj_parameters.eth_adj_parameters.destination_mac,
               6);
        break;

    case PKEY_UNI_WITHOUT_GRH:
        ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.sl =
            (ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.sl & 0x0F) << 4;
        ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.dlid = cl_hton16(
            ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.dlid);
        ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.dqpn = cl_hton32(
            ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.dqpn & 0x00FFFFFF);
        ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.my_lid =
            ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.my_lid & 0x7F;
        break;

    case PKEY_UNI_WITH_GRH:
        ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.my_lid =
            ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.my_lid & 0x7F;
        ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.sl =
            (ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.sl & 0x0F) << 4;
        ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dlid = cl_hton16(
            ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dlid);
        ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dqpn = cl_hton32(
            ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dqpn & 0x00FFFFFF);
        memcpy(ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dgid,
               ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet, 16);
        break;

    case PKEY_MULTI:
        ratr_reg->adj_parameters.pkey_multi_parameters.sl =
            (ratr_data->reg_data->adj_parameters.pkey_multi_parameters.sl & 0x0F) << 4;
        ratr_reg->adj_parameters.pkey_multi_parameters.dlid = cl_hton16(
            ratr_data->reg_data->adj_parameters.pkey_multi_parameters.dlid);
        ratr_reg->adj_parameters.pkey_multi_parameters.tclass =
            ratr_data->reg_data->adj_parameters.pkey_multi_parameters.tclass;
        break;

    case MPLS:
        ratr_reg->adj_parameters.mpls_parameters.nhlfe_ptr =
            cl_hton32(ratr_data->reg_data->adj_parameters.mpls_adj_parameters.nhlfe_ptr & 0x00FFFFFF);
        ratr_reg->adj_parameters.mpls_parameters.tqos_profile =
            ratr_data->reg_data->adj_parameters.mpls_adj_parameters.tqos_profile & 0x0F;
        ratr_reg->adj_parameters.mpls_parameters.ecmp_size =
            cl_hton16(ratr_data->reg_data->adj_parameters.mpls_adj_parameters.ecmp_size & 0x1FFF);
        ratr_reg->adj_parameters.mpls_parameters.underlay_router_interface =
            cl_hton16(ratr_data->reg_data->adj_parameters.mpls_adj_parameters.underlay_router_interface & 0xFFFF);
        break;

    case L3_TUNNEL_ENCAP:
        ratr_reg->adj_parameters.l3_tunnel_encap_parameters.udip_type =
            cl_hton16(ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.udip_type & 0x000F);

        switch (ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.udip_type) {
        case SXD_UDIP_TYPE_IPV4:
            ratr_reg->adj_parameters.l3_tunnel_encap_parameters.ipv4_udip =
                cl_hton32(ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.prefix.ipv4_udip);
            break;

        case SXD_UDIP_TYPE_IPV6:
            ratr_reg->adj_parameters.l3_tunnel_encap_parameters.ipv6_ptr =
                cl_hton32(
                    ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.prefix.ipv6_ptr & 0x00FFFFFF);
            break;

        default:
            break;
        }
        break;

    case NAT4TO6:
        ratr_reg->adj_parameters.nat4to6_adj_parameters.new_header_type =
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.new_header_type;
        ratr_reg->adj_parameters.nat4to6_adj_parameters.ingress_rif = cl_hton16(
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.ingress_rif);
        ratr_reg->adj_parameters.nat4to6_adj_parameters.qos_profile =
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.qos_profile;
        ratr_reg->adj_parameters.nat4to6_adj_parameters.exp_l3 =
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.exp_l3;

        switch (ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.new_header_type) {
        case SXD_NAT4TO6_NEW_HEADER_TYPE_IPV4:
            ratr_reg->adj_parameters.nat4to6_adj_parameters.new_ipv4_udip =
                cl_hton32(ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.udip.ipv4_udip);
            break;

        case SXD_NAT4TO6_NEW_HEADER_TYPE_IPV6:
            ratr_reg->adj_parameters.nat4to6_adj_parameters.new_ipv6_ptr =
                cl_hton32(
                    ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.udip.ipv6_ptr & 0x00FFFFFF);
            break;

        default:
            break;
        }
        break;

    case RELOOKUP_ECMP:
        ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.next_adjacency_ptr =
            cl_hton32(ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.next_adjacency_ptr
                      & 0x00FFFFFF);
        ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.next_ecmp_size =
            cl_hton16(ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.next_ecmp_size & 0x1FFF);
        ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.rd =
            cl_hton16(ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.rd & 0x0001);
        ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.rehash_seed =
            cl_hton16(ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.rehash_seed & 0xFFFF);
        break;

    case RELOOKUP_LPM:
        ratr_reg->adj_parameters.relookup_lpm_adj_parameters.virtual_router =
            cl_hton32(ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.virtual_router & 0x0000FFFF);
        ratr_reg->adj_parameters.relookup_lpm_adj_parameters.rd =
            cl_hton16(ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.rd & 0x0001);
        ratr_reg->adj_parameters.relookup_lpm_adj_parameters.rehash_seed =
            cl_hton16(ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.rehash_seed & 0xFFFF);
        break;

    case ARN_ENCAP:
        ratr_reg->adj_parameters.arn_encap_adj_parameters.dip_type =
            (ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.dip_type) & 0x3;
        ratr_reg->adj_parameters.arn_encap_adj_parameters.tqos_profile =
            (ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.tqos_profile) & 0xF;
        ratr_reg->adj_parameters.arn_encap_adj_parameters.uirif =
            cl_hton16(ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.uirif);

        switch (ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.dip_type) {
        case SXD_ARN_ENCAP_HEADER_TYPE_IPV4_E:
            ratr_reg->adj_parameters.arn_encap_adj_parameters.ipv4_udip =
                cl_hton32(ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.ipv4_udip);
            break;

        case SXD_ARN_ENCAP_HEADER_TYPE_IPV6_E:
            ratr_reg->adj_parameters.arn_encap_adj_parameters.ipv6_ptr =
                cl_hton32(ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.ipv6_ptr & 0xFFFFFF);
            break;

        default:
            break;
        }
        ratr_reg->adj_parameters.arn_encap_adj_parameters.next_arn_ptr =
            cl_hton32((ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.next_arn_ptr & 0xFFFFFF) |
                      (ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.vnext << 31));

        break;
    }
    ratr_reg->counter_set = cl_hton32(((ratr_data->reg_data->counter_set.type & 0xff) << 24) |
                                      (ratr_data->reg_data->counter_set.index & 0xffffff));

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ratr(sxd_emad_ratr_data_t * ratr_data, sxd_emad_ratr_reg_t * ratr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();
    ratr_data->reg_data->valid = ratr_reg->op_valid & 0x01;
    ratr_data->reg_data->activity = ratr_reg->activity;
    ratr_data->reg_data->size = cl_ntoh16(ratr_reg->size);
    ratr_data->reg_data->type = (ratr_reg->type >> 4) & 0x0F;
    ratr_data->reg_data->table = ratr_reg->table & 7;
    ratr_data->reg_data->adjacency_index = cl_ntoh16(ratr_reg->adjacency_index);
    ratr_data->reg_data->egress_rif = cl_ntoh16(ratr_reg->egress_rif);
    ratr_data->reg_data->trap_action = (ratr_reg->trap_action >> 4) & 0x0F;
    ratr_data->reg_data->adjacency_index_msb = ratr_reg->adj_idx_msb;
    ratr_data->reg_data->trap_id = cl_ntoh16(ratr_reg->trap_id) & 0x1FF;

    switch (ratr_data->reg_data->type) {
    case ETHERNET:
        memcpy(ratr_data->reg_data->adj_parameters.eth_adj_parameters.destination_mac,
               ratr_reg->adj_parameters.eth_adj_parameters.destination_mac,
               6);
        break;

    case PKEY_UNI_WITHOUT_GRH:
        ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.sl =
            (ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.sl >> 4) & 0x0F;
        ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.dlid = cl_ntoh16(
            ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.dlid);
        ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.dqpn = cl_ntoh32(
            ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.dqpn & 0x00FFFFFF);
        ratr_data->reg_data->adj_parameters.pkey_uni_without_grh_parameters.my_lid =
            ratr_reg->adj_parameters.pkey_uni_without_grh_parameters.my_lid & 0x7F;
        break;

    case PKEY_UNI_WITH_GRH:

        ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.my_lid =
            ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.my_lid & 0x7F;
        ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.sl =
            (ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.sl >> 4) & 0x0F;
        ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dlid = cl_ntoh16(
            ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dlid);
        ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dqpn = cl_ntoh32(
            ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dqpn & 0x00FFFFFF);
        memcpy(ratr_data->reg_data->adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet,
               ratr_reg->adj_parameters.pkey_uni_with_grh_parameters.dgid,
               16);
        break;

    case PKEY_MULTI:
        ratr_data->reg_data->adj_parameters.pkey_multi_parameters.sl =
            (ratr_reg->adj_parameters.pkey_multi_parameters.sl >> 4) & 0x0F;
        ratr_data->reg_data->adj_parameters.pkey_multi_parameters.dlid = cl_ntoh16(
            ratr_reg->adj_parameters.pkey_multi_parameters.dlid);
        ratr_data->reg_data->adj_parameters.pkey_multi_parameters.tclass =
            ratr_reg->adj_parameters.pkey_multi_parameters.tclass;
        break;

    case MPLS:
        ratr_data->reg_data->adj_parameters.mpls_adj_parameters.nhlfe_ptr =
            cl_ntoh32(ratr_reg->adj_parameters.mpls_parameters.nhlfe_ptr & 0x00FFFFFF);
        ratr_data->reg_data->adj_parameters.mpls_adj_parameters.tqos_profile =
            ratr_reg->adj_parameters.mpls_parameters.tqos_profile & 0x0F;
        ratr_data->reg_data->adj_parameters.mpls_adj_parameters.ecmp_size =
            cl_ntoh16(ratr_reg->adj_parameters.mpls_parameters.ecmp_size & 0x1FFF);
        ratr_data->reg_data->adj_parameters.mpls_adj_parameters.underlay_router_interface =
            cl_ntoh16(ratr_reg->adj_parameters.mpls_parameters.underlay_router_interface & 0xFFFF);
        break;

    case L3_TUNNEL_ENCAP:
        ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.udip_type =
            cl_ntoh16(ratr_reg->adj_parameters.l3_tunnel_encap_parameters.udip_type) & 0x000F;

        switch (ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.udip_type) {
        case SXD_UDIP_TYPE_IPV4:
            ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.prefix.ipv4_udip =
                cl_ntoh32(ratr_reg->adj_parameters.l3_tunnel_encap_parameters.ipv4_udip);
            break;

        case SXD_UDIP_TYPE_IPV6:
            ratr_data->reg_data->adj_parameters.l3_tunnel_encap_adj_parameters.prefix.ipv6_ptr =
                cl_ntoh32(ratr_reg->adj_parameters.l3_tunnel_encap_parameters.ipv6_ptr & 0x00FFFFFF);
            break;

        default:
            break;
        }
        break;

    case NAT4TO6:
        ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.new_header_type =
            ratr_reg->adj_parameters.nat4to6_adj_parameters.new_header_type;
        ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.ingress_rif = cl_ntoh16(
            ratr_reg->adj_parameters.nat4to6_adj_parameters.ingress_rif);
        ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.qos_profile =
            ratr_reg->adj_parameters.nat4to6_adj_parameters.qos_profile;
        ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.exp_l3 =
            ratr_reg->adj_parameters.nat4to6_adj_parameters.exp_l3;

        switch (ratr_reg->adj_parameters.nat4to6_adj_parameters.new_header_type) {
        case SXD_NAT4TO6_NEW_HEADER_TYPE_IPV4:
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.udip.ipv4_udip =
                cl_ntoh32(ratr_reg->adj_parameters.nat4to6_adj_parameters.new_ipv4_udip);
            break;

        case SXD_NAT4TO6_NEW_HEADER_TYPE_IPV6:
            ratr_data->reg_data->adj_parameters.nat4to6_adj_parameters.udip.ipv6_ptr =
                cl_ntoh32(ratr_reg->adj_parameters.nat4to6_adj_parameters.new_ipv6_ptr) & 0x00FFFFFF;
            break;

        default:
            break;
        }
        break;

    case RELOOKUP_ECMP:
        ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.next_adjacency_ptr =
            cl_ntoh32(ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.next_adjacency_ptr) & 0x00FFFFFF;
        ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.next_ecmp_size =
            cl_ntoh16(ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.next_ecmp_size) & 0x1FFF;
        ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.rd =
            cl_ntoh16(ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.rd) & 0x0001;
        ratr_data->reg_data->adj_parameters.relookup_ecmp_adj_parameters.rehash_seed =
            cl_ntoh16(ratr_reg->adj_parameters.relookup_ecmp_adj_parameters.rehash_seed) & 0xFFFF;
        break;

    case RELOOKUP_LPM:
        ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.virtual_router =
            cl_ntoh32(ratr_reg->adj_parameters.relookup_lpm_adj_parameters.virtual_router) & 0x0000FFFF;
        ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.rd =
            cl_ntoh16(ratr_reg->adj_parameters.relookup_lpm_adj_parameters.rd) & 0x0001;
        ratr_data->reg_data->adj_parameters.relookup_lpm_adj_parameters.rehash_seed =
            cl_ntoh16(ratr_reg->adj_parameters.relookup_lpm_adj_parameters.rehash_seed) & 0xFFFF;
        break;

    case ARN_ENCAP:
        ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.dip_type =
            ratr_reg->adj_parameters.arn_encap_adj_parameters.dip_type & 0x3;
        ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.tqos_profile =
            (ratr_reg->adj_parameters.arn_encap_adj_parameters.tqos_profile) & 0xF;
        ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.uirif =
            cl_ntoh16(ratr_reg->adj_parameters.arn_encap_adj_parameters.uirif);

        switch (ratr_reg->adj_parameters.arn_encap_adj_parameters.dip_type) {
        case SXD_ARN_ENCAP_HEADER_TYPE_IPV4_E:
            ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.ipv4_udip =
                cl_ntoh32(ratr_reg->adj_parameters.arn_encap_adj_parameters.ipv4_udip);
            break;

        case SXD_ARN_ENCAP_HEADER_TYPE_IPV6_E:
            ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.ipv6_ptr =
                cl_ntoh32(ratr_reg->adj_parameters.arn_encap_adj_parameters.ipv6_ptr) & 0xFFFFFF;
            break;

        default:
            break;
        }
        ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.vnext =
            (cl_ntoh32(ratr_reg->adj_parameters.arn_encap_adj_parameters.next_arn_ptr) >> 31) & 0x1;
        ratr_data->reg_data->adj_parameters.arn_encap_adj_parameters.next_arn_ptr =
            cl_ntoh32(ratr_reg->adj_parameters.arn_encap_adj_parameters.next_arn_ptr) & 0xFFFFFF;
        break;
    }

    ratr_data->reg_data->counter_set.type = (cl_ntoh32(ratr_reg->counter_set) >> 24) & 0xff;
    ratr_data->reg_data->counter_set.index = cl_ntoh32(ratr_reg->counter_set) & 0xffffff;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ratrad(sxd_emad_ratrad_data_t *ratrad_data, sxd_emad_ratrad_reg_t *ratrad_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ratrad_reg->op = ((ratrad_data->reg_data->op & 0x03) << 6);
    ratrad_reg->ecmp_size = cl_hton16(ratrad_data->reg_data->ecmp_size & 0x1fff);
    ratrad_reg->adjacency_index = cl_hton32(ratrad_data->reg_data->adjacency_index & 0xffffff);


    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ratrad(sxd_emad_ratrad_data_t *ratrad_data, sxd_emad_ratrad_reg_t *ratrad_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0, offset = 0;
    uint32_t     value = 0;
    int          j = 0;

    SX_LOG_ENTER();

    for (i = 0; i < SXD_RATRAD_MAX_REC_NUM;) {
        offset = (SXD_RATRAD_MAX_REC_NUM / 32) - (i / 32) - 1;
        value = cl_ntoh32(ratrad_reg->activity_vector[offset]);
        for (j = 0; j < 32; j++, i++) {
            ratrad_data->reg_data->activity_record[i] = (value >> j) & 0x01;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rdpm(sxd_emad_rdpm_data_t * rdpm_data, sxd_emad_rdpm_reg_t * rdpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     dscp, offset;

    SX_LOG_ENTER();


    for (dscp = 0; dscp < DSCP_CODES_NUMBER; dscp++) {
        offset = (DSCP_CODES_NUMBER - 1) - dscp;
        rdpm_reg->priority_update[offset] = rdpm_data->reg_data->priority[dscp] & 0xF;
        rdpm_reg->priority_update[offset] |= ((rdpm_data->reg_data->color[dscp] & 0x3) << 5);
        rdpm_reg->priority_update[offset] |= ((rdpm_data->reg_data->dscp_update[dscp] & 0x1) << 7);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rdpm(sxd_emad_rdpm_data_t * rdpm_data, sxd_emad_rdpm_reg_t * rdpm_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     dscp, offset;

    SX_LOG_ENTER();

    for (dscp = 0; dscp < DSCP_CODES_NUMBER; dscp++) {
        offset = (DSCP_CODES_NUMBER - 1) - dscp;
        rdpm_data->reg_data->priority[dscp] = rdpm_reg->priority_update[offset] & 0x0F;
        rdpm_data->reg_data->color[dscp] = ((rdpm_reg->priority_update[offset] >> 5) & 0x03);
        rdpm_data->reg_data->dscp_update[dscp] = ((rdpm_reg->priority_update[offset] >> 7) & 0x01);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rrcr(sxd_emad_rrcr_data_t * rrcr_data, sxd_emad_rrcr_reg_t * rrcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rrcr_reg->op = (rrcr_data->reg_data->op & 0x0f) << 4;
    rrcr_reg->offset = cl_hton16(rrcr_data->reg_data->offset);
    rrcr_reg->size = cl_hton16(rrcr_data->reg_data->size);
    rrcr_reg->key_type = (rrcr_data->reg_data->table_id & 0x0F);
    rrcr_reg->dest_offset = cl_hton16(rrcr_data->reg_data->dest_offset);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rrcr(sxd_emad_rrcr_data_t * rrcr_data, sxd_emad_rrcr_reg_t * rrcr_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rrcr_data->reg_data->op = (rrcr_reg->op >> 4) & 0x0f;
    rrcr_data->reg_data->offset = cl_ntoh16(rrcr_reg->offset);
    rrcr_data->reg_data->size = cl_ntoh16(rrcr_reg->size);
    rrcr_data->reg_data->table_id = (rrcr_reg->key_type & 0x0F);
    rrcr_data->reg_data->dest_offset = cl_ntoh16(rrcr_reg->dest_offset);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rica(sxd_emad_rica_data_t * rica_data, sxd_emad_rica_reg_t * rica_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rica_reg->op = (rica_data->reg_data->operation & 0x03) << 6;
    rica_reg->index = rica_data->reg_data->index;
    rica_reg->ingress_counter_set = cl_hton32(rica_data->reg_data->ingress_counter_set.index);
    rica_reg->egress_counter_set = cl_hton32(rica_data->reg_data->egress_counter_set.index);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rica(sxd_emad_rica_data_t * rica_data, sxd_emad_rica_reg_t * rica_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rica_data->reg_data->ingress_counter_set.index = cl_ntoh32(rica_reg->ingress_counter_set);
    rica_data->reg_data->ingress_counter_set.type = cl_ntoh32(rica_reg->ingress_counter_set) >> 24;
    rica_data->reg_data->egress_counter_set.index = cl_ntoh32(rica_reg->egress_counter_set);
    rica_data->reg_data->egress_counter_set.type = cl_ntoh32(rica_reg->egress_counter_set) >> 24;

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_ricnt(sxd_emad_ricnt_data_t * ricnt_data, sxd_emad_ricnt_reg_t * ricnt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    ricnt_reg->clr_add_flush = (ricnt_data->reg_data->clr & 0x01) << 7;
    ricnt_reg->clr_add_flush |= (ricnt_data->reg_data->add & 0x01) << 4;
    ricnt_reg->clr_add_flush |= (ricnt_data->reg_data->flush & 0x01) << 5;
    ricnt_reg->gl = ricnt_data->reg_data->gl & 0x03;
    ricnt_reg->counter_handle = cl_hton32(((ricnt_data->reg_data->cntr_handle.type & 0xff) << 24) |
                                          (ricnt_data->reg_data->cntr_handle.index & 0xffffff));

    if (ricnt_data->reg_data->add) {
        for (i = 0; i < SXD_ROUTER_COUNTER_SET_MAX; ++i) {
            ricnt_reg->counter_set[i] = cl_hton64(ricnt_data->reg_data->cntr[i]);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_ricnt(sxd_emad_ricnt_data_t * ricnt_data, sxd_emad_ricnt_reg_t * ricnt_reg)
{
    uint32_t     i = 0;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (i = 0; i < SXD_ROUTER_COUNTER_SET_MAX; ++i) {
        ricnt_data->reg_data->cntr[i] = cl_ntoh64(ricnt_reg->counter_set[i]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rtca(sxd_emad_rtca_data_t * rtca_data, sxd_emad_rtca_reg_t * rtca_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtca_reg->swid = rtca_data->reg_data->swid;
    rtca_reg->lmc = rtca_data->reg_data->lmc & 0x07;
    rtca_reg->lid = cl_hton16(rtca_data->reg_data->lid);
    memcpy(rtca_reg->gid, rtca_data->reg_data->gid.addr_octet, 16);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rtca(sxd_emad_rtca_data_t * rtca_data, sxd_emad_rtca_reg_t * rtca_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtca_data->reg_data->swid = rtca_reg->swid;
    rtca_data->reg_data->lmc = rtca_reg->lmc & 0x07;
    rtca_data->reg_data->lid = cl_ntoh16(rtca_reg->lid);
    memcpy(rtca_data->reg_data->gid.addr_octet, rtca_reg->gid, 16);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rtps(sxd_emad_rtps_data_t * rtps_data, sxd_emad_rtps_reg_t * rtps_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtps_reg->swid = rtps_data->reg_data->swid;
    rtps_reg->tca_log_phy_pstate = (rtps_data->reg_data->tca_phy_pstate & 0x0F) |
                                   (rtps_data->reg_data->tca_log_pstate << 4);
    rtps_reg->switch_log_phy_pstate = (rtps_data->reg_data->switch_log_pstate & 0x0F) |
                                      (rtps_data->reg_data->switch_phy_pstate << 4);
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rtps(sxd_emad_rtps_data_t * rtps_data, sxd_emad_rtps_reg_t * rtps_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rtps_data->reg_data->swid = rtps_reg->swid;
    rtps_data->reg_data->tca_log_pstate = (rtps_reg->tca_log_phy_pstate >> 4) & 0x0F;
    rtps_data->reg_data->tca_phy_pstate = rtps_reg->tca_log_phy_pstate & 0x0F;
    rtps_data->reg_data->switch_log_pstate = (rtps_reg->switch_log_phy_pstate >> 4) & 0x0F;
    rtps_data->reg_data->switch_phy_pstate = rtps_reg->switch_log_phy_pstate & 0x0F;
    SX_LOG_EXIT();
    return err;
}

static sxd_status_t __sxd_emad_rmeir_set_bitmask(sxd_rmeir_bit_vector_t       *expected_irif_boolean,
                                                 sxd_emad_rmeir_bit_verctor_t *expected_irif_bit)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     bit = 0;
    uint32_t     word = 0;
    uint32_t     h32 = 0;

    SX_LOG_ENTER();

    for (word = 0; word < 8; word++) {
        h32 = 0;

        for (bit = 0; bit < 32; bit++) {
            if (expected_irif_boolean->bit_vector[SXD_RMEIR_BIT_VECTOR_MAX - 1 - (word * 32 + bit)]) {
                h32 |= (1 << (32 - 1 - bit));
            }
        }

        expected_irif_bit->bit_vector[word] = cl_hton32(h32);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmeir(sxd_emad_rmeir_data_t *rmeir_data, sxd_emad_rmeir_reg_t *rmeir_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     entry_idx = 0;
    uint32_t     num_entries = 0;

    SX_LOG_ENTER();

    rmeir_reg->expected_irif_list_index = cl_hton32(rmeir_data->reg_data->expected_irif_list_index & 0xFFFFFF);
    rmeir_reg->num_entries = rmeir_data->reg_data->num_entries;

    /* Backward compatibility:
     * SPC-1 doesn't support num_entries field - value of 0 means 1 entry */
    num_entries = (rmeir_data->reg_data->num_entries < 2) ? 1 : rmeir_data->reg_data->num_entries;

    for (entry_idx = 0; entry_idx < num_entries; entry_idx++) {
        err = __sxd_emad_rmeir_set_bitmask(&rmeir_data->reg_data->expected_irif_bit_vector[entry_idx],
                                           &rmeir_reg->expected_irif_bit_vector[entry_idx]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmeir(sxd_emad_rmeir_data_t *rmeir_data, sxd_emad_rmeir_reg_t *rmeir_reg)
{
    uint32_t     bit, word, h32;
    sxd_status_t err = SXD_STATUS_SUCCESS;
    uint32_t     entry_idx = 0;
    uint32_t     num_entries = 0;

    SX_LOG_ENTER();

    rmeir_data->reg_data->num_entries = rmeir_reg->num_entries;

    /* Backward compatibility:
     * SPC-1 doesn't support num_entries field - value of 0 means 1 entry */
    num_entries = (rmeir_reg->num_entries < 2) ? 1 : rmeir_reg->num_entries;

    for (entry_idx = 0; entry_idx < num_entries; entry_idx++) {
        for (word = 0; word < 8; word++) {
            h32 = cl_ntoh32(rmeir_reg->expected_irif_bit_vector[entry_idx].bit_vector[word]);
            for (bit = 0; bit < 32; bit++) {
                rmeir_data->reg_data->expected_irif_bit_vector[entry_idx].bit_vector[(word *
                                                                                      32) + bit] = (h32 >> bit) & 0x1;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmid(sxd_emad_rmid_data_t * rmid_data, sxd_emad_rmid_reg_t * rmid_reg)
{
    uint32_t     bit, word, h32;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmid_reg->rmid_index = cl_hton16(rmid_data->reg_data->rmid_index);
    rmid_reg->rmpe_index = cl_hton16(rmid_data->reg_data->rmpe_index);
    for (word = 0; word < 8; word++) {
        h32 = 0;
        for (bit = 0; bit < 32; bit++) {
            if (rmid_data->reg_data->egress_port[(word * 32) + bit]) {
                h32 |= (1 << bit);
            }
        }
        rmid_reg->egress_port[7 - word] = cl_hton32(h32);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmid(sxd_emad_rmid_data_t * rmid_data, sxd_emad_rmid_reg_t * rmid_reg)
{
    uint32_t     bit, word, h32;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmid_data->reg_data->rmpe_index = cl_ntoh16(rmid_reg->rmpe_index);
    for (word = 0; word < 8; word++) {
        h32 = cl_ntoh32(rmid_reg->egress_port[7 - word]);
        for (bit = 0; bit < 32; bit++) {
            rmid_data->reg_data->egress_port[(word * 32) + bit] = (h32 >> bit) & 0x1;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_rmpu(sxd_emad_rmpu_data_t * rmpu_data, sxd_emad_rmpu_reg_t * rmpu_reg)
{
    uint32_t     i;
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rmpu_reg->local_port = rmpu_data->reg_data->local_port;
    rmpu_reg->lp_msb = (rmpu_data->reg_data->lp_msb & 0x03) << 4;
    rmpu_reg->op = (rmpu_data->reg_data->op & 0x3) << 6;
    rmpu_reg->size = rmpu_data->reg_data->size;
    for (i = 0; i < SXD_RMPU_MAX; i++) {
        rmpu_reg->entries[i].rmid_index = cl_hton16(rmpu_data->reg_data->rmid_index[i]);
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_rmpu(sxd_emad_rmpu_data_t * rmpu_data, sxd_emad_rmpu_reg_t * rmpu_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    UNUSED_PARAM(rmpu_data);
    UNUSED_PARAM(rmpu_reg);

    SX_LOG_ENTER();

    SX_LOG_EXIT();
    return err;
}
