/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_system.h>
#include "emad.h"

#undef  __MODULE__
#define __MODULE__ EMAD_SYSTEM

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sxd_status_t sxd_emad_system_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_emad_scar_get(sxd_emad_scar_data_t         *scar_data_arr,
                               uint32_t                      scar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((scar_data_arr == NULL) || (scar_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)scar_data_arr, scar_data_num,
                          SXD_REG_ID_SCAR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_spad_set(sxd_emad_spad_data_t         *spad_data_arr,
                               uint32_t                      spad_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((spad_data_arr == NULL) || (spad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)spad_data_arr, spad_data_num,
                          SXD_REG_ID_SPAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_spad_get(sxd_emad_spad_data_t         *spad_data_arr,
                               uint32_t                      spad_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((spad_data_arr == NULL) || (spad_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)spad_data_arr, spad_data_num,
                          SXD_REG_ID_SPAD_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ppsc_set(sxd_emad_ppsc_data_t         *ppsc_data_arr,
                               uint32_t                      ppsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ppsc_data_arr == NULL) || (ppsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ppsc_data_arr, ppsc_data_num,
                          SXD_REG_ID_PPSC_E, handler, context);
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_ppsc_get(sxd_emad_ppsc_data_t         *ppsc_data_arr,
                               uint32_t                      ppsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((ppsc_data_arr == NULL) || (ppsc_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)ppsc_data_arr, ppsc_data_num,
                          SXD_REG_ID_PPSC_E, handler, context);
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mjtag_set(sxd_emad_mjtag_data_t        *mjtag_data_arr,
                                uint32_t                      mjtag_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mjtag_data_arr == NULL) || (mjtag_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mjtag_data_arr, mjtag_data_num,
                          SXD_REG_ID_MJTAG_E, handler, context);
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mjtag_get(sxd_emad_mjtag_data_t        *mjtag_data_arr,
                                uint32_t                      mjtag_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mjtag_data_arr == NULL) || (mjtag_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }


    err = emad_common_set((sxd_emad_data_t*)mjtag_data_arr, mjtag_data_num,
                          SXD_REG_ID_MJTAG_E, handler, context);
out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_sspr_set(sxd_emad_sspr_data_t         *sspr_data_arr,
                               uint32_t                      sspr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sspr_data_arr == NULL) || (sspr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sspr_data_arr, sspr_data_num,
                          SXD_REG_ID_SSPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_sspr_get(sxd_emad_sspr_data_t         *sspr_data_arr,
                               uint32_t                      sspr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sspr_data_arr == NULL) || (sspr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)sspr_data_arr, sspr_data_num,
                          SXD_REG_ID_SSPR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mfba_set(sxd_emad_mfba_data_t         *mfba_data_arr,
                               uint32_t                      mfba_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfba_data_arr == NULL) || (mfba_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfba_data_arr, mfba_data_num,
                          SXD_REG_ID_MFBA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_mfba_get(sxd_emad_mfba_data_t         *mfba_data_arr,
                               uint32_t                      mfba_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfba_data_arr == NULL) || (mfba_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfba_data_arr, mfba_data_num,
                          SXD_REG_ID_MFBA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mfbe_set(sxd_emad_mfbe_data_t         *mfbe_data_arr,
                               uint32_t                      mfbe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfbe_data_arr == NULL) || (mfbe_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfbe_data_arr, mfbe_data_num,
                          SXD_REG_ID_MFBE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_mfbe_get(sxd_emad_mfbe_data_t         *mfbe_data_arr,
                               uint32_t                      mfbe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfbe_data_arr == NULL) || (mfbe_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfbe_data_arr, mfbe_data_num,
                          SXD_REG_ID_MFBE_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mfpa_set(sxd_emad_mfpa_data_t         *mfpa_data_arr,
                               uint32_t                      mfpa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfpa_data_arr == NULL) || (mfpa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfpa_data_arr, mfpa_data_num,
                          SXD_REG_ID_MFPA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_mfpa_get(sxd_emad_mfpa_data_t         *mfpa_data_arr,
                               uint32_t                      mfpa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mfpa_data_arr == NULL) || (mfpa_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mfpa_data_arr, mfpa_data_num,
                          SXD_REG_ID_MFPA_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_msci_set(sxd_emad_msci_data_t         *msci_data_arr,
                               uint32_t                      msci_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((msci_data_arr == NULL) || (msci_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)msci_data_arr, msci_data_num,
                          SXD_REG_ID_MSCI_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_msci_get(sxd_emad_msci_data_t         *msci_data_arr,
                               uint32_t                      msci_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((msci_data_arr == NULL) || (msci_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)msci_data_arr, msci_data_num,
                          SXD_REG_ID_MSCI_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mtbr_set(sxd_emad_mtbr_data_t         *mtbr_data_arr,
                               uint32_t                      mtbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mtbr_data_arr == NULL) || (mtbr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mtbr_data_arr, mtbr_data_num,
                          SXD_REG_ID_MTBR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mtbr_get(sxd_emad_mtbr_data_t         *mtbr_data_arr,
                               uint32_t                      mtbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mtbr_data_arr == NULL) || (mtbr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mtbr_data_arr, mtbr_data_num,
                          SXD_REG_ID_MTBR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

static void __raw_ext_hook(sxd_dev_id_t                dev_id,
                           sxd_reg_id_e                reg_id,
                           uint8_t                     fw_status,
                           const void                 *reg_data,
                           const sxd_emad_operation_t *operation_tlv,
                           const sxd_emad_reg_t       *reg_tlv,
                           const sxd_emad_latency_t   *latency_tlv,
                           void                       *context)
{
    struct sxd_emad_raw_reg_ext_data *raw_reg_ext = (struct sxd_emad_raw_reg_ext_data *)reg_data;
    uint32_t                          emad_latency = 0;
    uint32_t                          cache_read_time = 0;

    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(operation_tlv);
    UNUSED_PARAM(reg_tlv);
    UNUSED_PARAM(context);

    if (fw_status != 0) {
        SX_LOG_NTC("RAW register failed (dev-id %u) fw_status: %d\n", dev_id, fw_status);
        return;
    }

    if (latency_tlv) {
        emad_latency = cl_ntoh32(latency_tlv->latency_time);
        if (latency_tlv->ccrt_v) {
            cache_read_time = cl_ntoh32(latency_tlv->code_cache_read_time);
        }
    }

    raw_reg_ext->raw->fw_emad_latency = emad_latency;
    raw_reg_ext->raw->fw_cache_read_time = cache_read_time;
}

static sxd_status_t __sxd_emad_raw_ext(sxd_emad_raw_ext_data_t      *raw_data_arr,
                                       uint32_t                      raw_data_num,
                                       sxd_emad_completion_handler_t handler,
                                       void                         *context)
{
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    struct sxd_emad_general_reg_data general_data;
    struct sxd_emad_raw_reg_ext_data raw_reg_ext_data;
    uint32_t                         i;
    boolean_t                        hook_registerd = FALSE;

    SX_LOG_ENTER();
    sxd_status = sxd_emad_hook_register(SXD_REG_ID_RAW_E, __raw_ext_hook, NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        goto out;
    }

    hook_registerd = TRUE;

    for (i = 0; i < raw_data_num; i++) {
        raw_reg_ext_data.reg_id = (sxd_reg_id_e)raw_data_arr[i].register_id;
        raw_reg_ext_data.raw = raw_data_arr[i].reg_data;

        memcpy(&general_data.common, &raw_data_arr[i].common, sizeof(general_data.common));
        general_data.reg_data = &raw_reg_ext_data;

        sxd_status = emad_common_raw_set(&general_data,
                                         1,
                                         raw_reg_ext_data.reg_id,
                                         handler,
                                         context);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to access RAW_EXT register (reg_id=0x%04x, iteration %u, status=%u)\n",
                       raw_reg_ext_data.reg_id, i, sxd_status);
            break;
        }
    }

out:
    if (hook_registerd) {
        sxd_emad_hook_unregister(SXD_REG_ID_RAW_E);
    }

    SX_LOG_EXIT();
    return sxd_status;
}

static sxd_status_t __sxd_emad_raw(sxd_emad_raw_data_t          *raw_data_arr,
                                   uint32_t                      raw_data_num,
                                   sxd_emad_completion_handler_t handler,
                                   void                         *context)
{
    struct sxd_emad_general_reg_data general_data;
    struct sxd_emad_raw_reg_data     raw_reg_data;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                         i;

    for (i = 0; i < raw_data_num; i++) {
        raw_reg_data.reg_id = (sxd_reg_id_e)raw_data_arr[i].register_id;
        raw_reg_data.raw = raw_data_arr[i].reg_data;

        memcpy(&general_data.common, &raw_data_arr[i].common, sizeof(general_data.common));
        general_data.reg_data = &raw_reg_data;

        sxd_status = emad_common_raw_set(&general_data,
                                         1,
                                         raw_reg_data.reg_id,
                                         handler,
                                         context);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to access RAW register (reg_id=0x%04x, iteration %u, status=%u)\n",
                       raw_reg_data.reg_id, i, sxd_status);
            break;
        }
    }

    return sxd_status;
}

sxd_status_t sxd_emad_raw_ext_set(sxd_emad_raw_ext_data_t      *raw_data_arr,
                                  uint32_t                      raw_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    return __sxd_emad_raw_ext(raw_data_arr, raw_data_num, handler, context);
}


sxd_status_t sxd_emad_raw_ext_get(sxd_emad_raw_ext_data_t      *raw_data_arr,
                                  uint32_t                      raw_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context)
{
    return __sxd_emad_raw_ext(raw_data_arr, raw_data_num, handler, context);
}

sxd_status_t sxd_emad_raw_set(sxd_emad_raw_data_t          *raw_data_arr,
                              uint32_t                      raw_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context)
{
    return __sxd_emad_raw(raw_data_arr, raw_data_num, handler, context);
}


sxd_status_t sxd_emad_raw_get(sxd_emad_raw_data_t          *raw_data_arr,
                              uint32_t                      raw_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context)
{
    return __sxd_emad_raw(raw_data_arr, raw_data_num, handler, context);
}


sxd_status_t sxd_emad_mrsr_set(sxd_emad_mrsr_data_t         *mrsr_data_arr,
                               uint32_t                      mrsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mrsr_data_arr == NULL) || (mrsr_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mrsr_data_arr, mrsr_data_num,
                          SXD_REG_ID_MRSR_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mcion_set(sxd_emad_mcion_data_t        *mcion_data_arr,
                                uint32_t                      mcion_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mcion_data_arr == NULL) || (mcion_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mcion_data_arr, mcion_data_num,
                          SXD_REG_ID_MCION_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_mcion_get(sxd_emad_mcion_data_t        *mcion_data_arr,
                                uint32_t                      mcion_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((mcion_data_arr == NULL) || (mcion_data_num == 0)) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    err = emad_common_set((sxd_emad_data_t*)mcion_data_arr, mcion_data_num,
                          SXD_REG_ID_MCION_E, handler, context);

out:
    SX_LOG_EXIT();
    return err;
}
