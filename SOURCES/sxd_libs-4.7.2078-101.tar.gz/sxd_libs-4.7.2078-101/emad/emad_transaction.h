/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __EMAD_TRANSACTION_H__
#define __EMAD_TRANSACTION_H__

#include <complib/cl_pool.h>
#include <complib/cl_list.h>
#include <complib/cl_event.h>
#include <complib/cl_spinlock.h>

#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_dev.h>
#include <sx/sxd/sxd_access_cmd.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_status.h>

#include <reg_access/sxd_access_reg_infra.h>

#include "emad_buffer.h"

/*
 * __emad_tid_base is 64bit value that holds only MSB-32bit and LSB-32bit are all 0.
 *
 * EMAD Transaction ID (64bit):
 *       6         5         4         3         2         1
 *    3210987654321098765432109876543210987654321098765432109876543210
 *    |                               |       |
 *    |                               |       +--------- bits 00-23 (24bits) --> running counter
 *    |                               |                                          (no problem of wrap-around)
 *    |                               +----------------- bits 24-31 (8bits)  --> device-id
 *    +------------------------------------------------- bits 32-63 (32bits) --> application-id (__emad_tid_base)
 */
#define EMAD_NUM_DEV_ID (256)
#define EMAD_TID_GET_DEV_ID(tid)         ((sxd_dev_id_t)(((tid) & 0xffffffff) >> 24))
#define EMAD_TID_SET_DEV_ID(tid, dev_id) ((tid) | (((uint64_t)(dev_id)) << 24))

/**
 * This function sets the log verbosity level of EMAD TRANSACTION MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *         SX_STATUS_ERROR   general error
 */
sxd_status_t emad_transaction_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);


/* initialize EMAD transaction module */
sxd_status_t emad_transaction_init(uint32_t app_id);

/* deinitialize EMAD transaction module */
void emad_transaction_deinit(void);

/* set EMAD transaction-id 32bit MSBs */
void emad_set_tid_base(uint32_t app_id);

uint64_t emad_transaction_alloc_notification_id(void);

/* add transaction to db */
sxd_status_t emad_transaction_add(struct emad_buffer *emad_buffer);

/* delete transaction from db */
sxd_status_t emad_transaction_delete(uint64_t             tid,
                                     uint32_t             emad_latency,
                                     uint32_t             cache_read_time,
                                     struct emad_buffer **buffer);

/* terminate in-flight transaction */
void emad_transaction_timeout(struct emad_buffer *emad_buffer, uint32_t waited_usec);

/* set transaction mode (TRUE=async, FALSE=sync) */
sxd_status_t sxd_emad_transaction_mode_get(boolean_t *enable);

/* register callback for TX transaction */
void emad_transaction_register_tx_cb(sxd_emad_notify_latest_tx_tid_cb cb, void *context);

/* register callback for RX transaction */
void emad_transaction_register_rx_cb(sxd_emad_notify_latest_rx_tid_cb cb, void *context);

/* call TX callback (if registered) */
sxd_status_t emad_transaction_call_tx_callback(uint64_t notif_tid);

/* call RX callback (if registered) */
sxd_status_t emad_transaction_call_rx_callback(uint64_t notif_tid);

/* check if EMAD is disabled on a device */
boolean_t emad_dev_id_is_disabled(sxd_dev_id_t dev_id);

#endif /* __EMAD_TRANSACTION_H__ */
