/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __EMAD_BUFFER_H__
#define __EMAD_BUFFER_H__

#include <complib/cl_pool.h>
#include <complib/cl_list.h>
#include <complib/cl_event.h>

#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxd_dev.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_cmd.h>
#include <sx/sxd/sxd_access_register.h>

#include <reg_access/sxd_access_reg_infra.h>

enum transaction_state {
    EMAD_TR_STATE_ALLOCATED,
    EMAD_TR_STATE_IN_TX_QUEUE,
    EMAD_TR_STATE_RX_RECEIVED,
    EMAD_TR_STATE_TIMED_OUT
};
struct emad_buffer {
    cl_pool_item_t                   pool_item;  /* allocation pool */
    cl_list_item_t                   list_item;  /* EMAD queue to tx/rx thread */
    cl_list_item_t                   tid_list;
    enum transaction_state           tr_state;
    cl_event_t                      *sync_event;
    sxd_status_t                     status;
    sxd_reg_id_e                     reg_id;
    boolean_t                        is_raw_reg;
    uint32_t                         reg_size;
    uint64_t                         emad_tid;
    uint64_t                         notif_tid;
    struct sxd_emad_general_reg_data gen_reg_data;
    uint8_t                          prm_reg_buff[SXD_EMAD_BUFFER_MAX_SIZE];
    uint32_t                         emad_latency;
    uint32_t                         cache_read_time;
};

#define EMAD_BUFFER_DEV_ID(emad_buffer)     ((emad_buffer)->gen_reg_data.common.dev_id)
#define EMAD_BUFFER_ACCESS_CMD(emad_buffer) ((emad_buffer)->gen_reg_data.common.access_cmd)
#define EMAD_BUFFER_MODE(emad_buffer)       ((emad_buffer)->gen_reg_data.common.mode)

/* initialize emad_buffer module */
sxd_status_t emad_buffer_init(void);

/* deinitialize emad_buffer module */
void emad_buffer_deinit(void);

/* allocate an emad buffer */
sxd_status_t emad_buffer_alloc(sxd_reg_id_e                      reg_id,
                               boolean_t                         is_raw_reg,
                               struct sxd_emad_general_reg_data *reg_data,
                               struct emad_buffer              **buffer);

/* deallocate an emad buffer */
void emad_buffer_dealloc(struct emad_buffer *emad_buffer);

/* enqueue an emad buffer to tx queue */
sxd_status_t emad_buffer_enqueue(struct emad_buffer *emad_buffer);

#endif /* __EMAD_BUFFER_H__ */
