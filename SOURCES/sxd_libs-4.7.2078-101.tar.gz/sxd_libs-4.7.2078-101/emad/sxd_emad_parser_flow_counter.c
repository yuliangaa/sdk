/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_emad_parser_flow_counter.h>

#undef  __MODULE__
#define __MODULE__ EMAD_PARSER_FLOW_COUNTER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_parser_flow_counter_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                          IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


sxd_status_t sxd_emad_parse_pfca(sxd_emad_pfca_data_t *pfca_data, sxd_emad_pfca_reg_t *pfca_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfca_reg->op_type = ((pfca_data->reg_data->op & 0x03) << 6) |
                        (pfca_data->reg_data->type & 0x03);
    pfca_reg->index = pfca_data->reg_data->index;
    pfca_reg->flow_counter_handle = cl_hton32(pfca_data->reg_data->flow_counter_handle);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pfca(sxd_emad_pfca_data_t *pfca_data, sxd_emad_pfca_reg_t *pfca_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfca_data->reg_data->op = (pfca_reg->op_type >> 6) & 0x03;
    pfca_data->reg_data->type = pfca_reg->op_type & 0x03;
    pfca_data->reg_data->index = pfca_reg->index;
    pfca_data->reg_data->flow_counter_handle = cl_ntoh32(pfca_reg->flow_counter_handle);

    SX_LOG_EXIT();
    return err;
}


sxd_status_t sxd_emad_parse_pfcnt(sxd_emad_pfcnt_data_t *pfcnt_data, sxd_emad_pfcnt_reg_t *pfcnt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfcnt_reg->clr = ((pfcnt_data->reg_data->clr & 0x01) << 7);
    pfcnt_reg->flow_counter_handle = cl_hton32(pfcnt_data->reg_data->flow_counter_handle);
    pfcnt_reg->flow_counter = cl_hton64(pfcnt_data->reg_data->flow_counter);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_pfcnt(sxd_emad_pfcnt_data_t *pfcnt_data, sxd_emad_pfcnt_reg_t *pfcnt_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    pfcnt_data->reg_data->clr = (pfcnt_reg->clr >> 7) & 0x01;
    pfcnt_data->reg_data->flow_counter_handle = cl_ntoh32(pfcnt_reg->flow_counter_handle);
    pfcnt_data->reg_data->flow_counter = cl_ntoh64(pfcnt_reg->flow_counter);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_parse_mgpc(sxd_emad_mgpc_data_t *mgpc_data, sxd_emad_mgpc_reg_t *mgpc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mgpc_reg->counter_set = cl_hton32(((mgpc_data->reg_data->counter_set.type & 0xff) << 24) |
                                      (mgpc_data->reg_data->counter_set.index & 0xffffff));
    mgpc_reg->counter_opcode = (mgpc_data->reg_data->counter_opcode & 0x0F) << 4;
    mgpc_reg->byte_counter = cl_hton64(mgpc_data->reg_data->byte_counter);
    mgpc_reg->packet_counter = cl_hton64(mgpc_data->reg_data->packet_counter);

    SX_LOG_EXIT();
    return err;
}

sxd_status_t sxd_emad_deparse_mgpc(sxd_emad_mgpc_data_t *mgpc_data, sxd_emad_mgpc_reg_t *mgpc_reg)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    mgpc_data->reg_data->byte_counter = cl_ntoh64(mgpc_reg->byte_counter);
    mgpc_data->reg_data->packet_counter = cl_ntoh64(mgpc_reg->packet_counter);

    SX_LOG_EXIT();
    return err;
}
