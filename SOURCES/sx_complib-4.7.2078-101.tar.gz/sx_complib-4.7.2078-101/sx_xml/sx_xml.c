/*
 * Copyright © 2022-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <complib/cl_mem.h>

#include <complib/sx_xml.h>

#include <libxml/parser.h>
#include <libxml/tree.h>

/************************************************
 *  Defines
 ***********************************************/
#undef  __MODULE__
#define __MODULE__ SX_XML

#define SX_XML_FILE_PATH 1024

/************************************************
 *  Macros
 ***********************************************/
#define SX_XML_LOG(level, format, ...)             \
    do                                             \
    {                                              \
        if (sx_xml_log_initialized_g) {            \
            SX_LOG(level, format, ## __VA_ARGS__); \
        }                                          \
    } while (0)

#define SX_XML_CHECK_NULL(parameter, parameter_str)                \
    do                                                             \
    {                                                              \
        if ((parameter) == NULL) {                                 \
            SX_XML_LOG(SX_LOG_ERROR, parameter_str " is NULL.\n"); \
            goto out;                                              \
        }                                                          \
    } while (0)

/************************************************
 *  Type definitions
 ***********************************************/
struct sx_xml_parser {
    boolean_t ignore_whitespaces;
};

struct sx_xml_reader {
    char xml_path[SX_XML_FILE_PATH];
};

/**
 *  A callback that is used by __sx_xml_list_element_find to find a specific XML xml_element_p.
 *  It must return TRUE if the xml_element_p matches the search criteria.
 */
typedef boolean_t (*sx_xml_element_compare_pfn)(void const * xml_element_p, void const * search_criteria_p);

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t sx_xml_log_initialized_g = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static boolean_t __sx_xml_element_name_matches(void const *xml_element_p, void const *xml_element_name_p);

static sx_xml_list_t * __sx_xml_list_element_find(sx_xml_list_t             *xml_list_p,
                                                  sx_xml_element_compare_pfn compare_pfn,
                                                  void const                *search_criteria_p);
static sx_xml_list_t * __sx_xml_list_last_element_get(sx_xml_list_t *xml_list_p);

static sx_xml_list_t * __sx_xml_shallow_list_create(sx_xml_element_t * xml_element_p);
static sx_xml_list_t * __sx_xml_shallow_list_append(sx_xml_list_t *xml_list_p, sx_xml_element_t *xml_element_p);
static void __sx_xml_shallow_list_free(sx_xml_list_t *xml_list_p);

/************************************************
 *  Local function definitions
 ***********************************************/
boolean_t __sx_xml_element_name_matches(void const *xml_element_p, void const *xml_element_name_p)
{
    int       str_cmp_rc = 0;
    boolean_t is_equal = FALSE;

    str_cmp_rc = strcmp((char const *)((sx_xml_element_t *)xml_element_p)->name, (char *)xml_element_name_p);
    if (str_cmp_rc == 0) {
        is_equal = TRUE;
    }

    return is_equal;
}

sx_xml_list_t * __sx_xml_list_last_element_get(sx_xml_list_t *xml_list_p)
{
    while (xml_list_p->next != NULL) {
        xml_list_p = xml_list_p->next;
    }

    return xml_list_p;
}

sx_xml_list_t * __sx_xml_list_element_find(sx_xml_list_t             *xml_list_p,
                                           sx_xml_element_compare_pfn compare_pfn,
                                           void const                *search_criteria_p)
{
    while (xml_list_p != NULL) {
        if (compare_pfn(xml_list_p, search_criteria_p)) {
            break;
        }
        xml_list_p = xml_list_p->next;
    }

    return xml_list_p;
}

sx_xml_list_t * __sx_xml_shallow_list_create(sx_xml_element_t * xml_element_p)
{
    sx_xml_list_t *xml_list_p = NULL;

    xml_list_p = cl_calloc(1, sizeof(sx_xml_list_t));

    if (xml_list_p != NULL) {
        memcpy(xml_list_p, xml_element_p, sizeof(sx_xml_list_t));
        xml_list_p->next = NULL;
        xml_list_p->prev = NULL;
    }

    return xml_list_p;
}

sx_xml_list_t* __sx_xml_shallow_list_append(sx_xml_list_t *xml_list_p, sx_xml_element_t *xml_element_p)
{
    sx_xml_list_t *new_list_item_p = NULL;
    sx_xml_list_t *last_list_item_p = NULL;

    new_list_item_p = __sx_xml_shallow_list_create(xml_element_p);

    if ((new_list_item_p != NULL) && (xml_list_p != NULL)) {
        last_list_item_p = __sx_xml_list_last_element_get(xml_list_p);
        last_list_item_p->next = new_list_item_p;
        new_list_item_p->prev = last_list_item_p;
    }

    return new_list_item_p;
}

void __sx_xml_shallow_list_free(sx_xml_list_t *xml_list_p)
{
    sx_xml_list_t * list_item_p = NULL;

    while (xml_list_p != NULL) {
        list_item_p = xml_list_p;
        xml_list_p = xml_list_p->next;
        cl_free(list_item_p);
    }
}

/************************************************
 *  Function definitions
 ***********************************************/
cl_status_t sx_xml_log_function_set(sx_log_cb_t log_cb)
{
    sx_log_init(TRUE, NULL, log_cb);
    sx_xml_log_initialized_g = TRUE;
    return CL_SUCCESS;
}

cl_status_t sx_xml_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return CL_SUCCESS;
}

cl_status_t sx_xml_log_verbosity_level_get(sx_verbosity_level_t * verbosity_level_p)
{
    cl_status_t cl_status = CL_ERROR;

    SX_XML_CHECK_NULL(verbosity_level_p, "verbosity_level_p");

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    cl_status = CL_SUCCESS;

out:
    return cl_status;
}

sx_xml_parser_t * sx_xml_parser_create(void)
{
    sx_xml_parser_t *parser_p = NULL;

    parser_p = (sx_xml_parser_t*)cl_malloc(sizeof(*parser_p));
    if (parser_p == NULL) {
        SX_XML_LOG(SX_LOG_ERROR, "Failed to allocate a new XML parser\n");
        goto out;
    }

    memset(parser_p, 0, sizeof(*parser_p));

out:
    return parser_p;
}

void sx_xml_parser_free(sx_xml_parser_t * xml_parser_p)
{
    SX_XML_CHECK_NULL(xml_parser_p, "xml_parser_p");

    cl_free(xml_parser_p);

out:
    return;
}

void sx_xml_parser_ignore_whitespaces(sx_xml_parser_t * xml_parser_p)
{
    SX_XML_CHECK_NULL(xml_parser_p, "xml_parser_p");

    xml_parser_p->ignore_whitespaces = TRUE;

out:
    return;
}

sx_xml_reader_t * sx_xml_reader_create(char const * xml_file_path_p)
{
    sx_xml_reader_t *reader_p = NULL;

    SX_XML_CHECK_NULL(xml_file_path_p, "xml_file_path_p");

    reader_p = (sx_xml_reader_t *)cl_malloc(sizeof(*reader_p));
    if (reader_p == NULL) {
        SX_XML_LOG(SX_LOG_ERROR, "Failed to allocate a new XML reader for the file %s \n", xml_file_path_p);
        goto out;
    }

    strncpy(reader_p->xml_path, xml_file_path_p, SX_XML_FILE_PATH - 1);

out:
    return reader_p;
}

void sx_xml_reader_free(sx_xml_reader_t * xml_reader_p)
{
    SX_XML_CHECK_NULL(xml_reader_p, "xml_reader_p");

    cl_free(xml_reader_p);

out:
    return;
}

sx_xml_tree_t * sx_xml_tree_create(sx_xml_parser_t * xml_parser_p, sx_xml_reader_t * xml_reader_p)
{
    sx_xml_tree_t *tree_p = NULL;
    int            options = 0;

    SX_XML_CHECK_NULL(xml_parser_p, "xml_parser_p");
    SX_XML_CHECK_NULL(xml_reader_p, "xml_reader_p");

    if (xml_parser_p->ignore_whitespaces) {
        options = XML_PARSE_NOBLANKS;
    }

    tree_p = xmlReadFile(xml_reader_p->xml_path, NULL, options);
    if (tree_p == NULL) {
        SX_XML_LOG(SX_LOG_WARNING, "Unable to load and parse file (%s)\n", xml_reader_p->xml_path);
        goto out;
    }

out:
    return tree_p;
}

void sx_xml_tree_free(sx_xml_tree_t * xml_tree_p)
{
    SX_XML_CHECK_NULL(xml_tree_p, "xml_tree_p");

    xmlFreeDoc(xml_tree_p);

out:
    return;
}

sx_xml_element_t * sx_xml_tree_root_element_get(sx_xml_tree_t * xml_tree_p)
{
    sx_xml_element_t * xml_element_p = NULL;

    SX_XML_CHECK_NULL(xml_tree_p, "xml_tree_p");

    xml_element_p = xmlDocGetRootElement(xml_tree_p);

out:
    return xml_element_p;
}

sx_xml_element_t * sx_xml_element_by_name_get(sx_xml_element_t const * xml_element_p, char const * xml_element_name_p)
{
    sx_xml_element_t *matched_child_p = NULL;
    sx_xml_element_t *children_p = NULL;
    sx_xml_element_t *child_p = NULL;

    SX_XML_CHECK_NULL(xml_element_p, "xml_element_p");
    SX_XML_CHECK_NULL(xml_element_name_p, "xml_element_name_p");

    children_p = xml_element_p->children;
    while (children_p != NULL) {
        child_p = children_p;

        if (__sx_xml_element_name_matches(child_p, xml_element_name_p)) {
            matched_child_p = child_p;
            break;
        }

        children_p = children_p->next;
    }

    if (matched_child_p == NULL) {
        SX_XML_LOG(SX_LOG_INFO, "Failed to find an XML element with the name %s\n", xml_element_name_p);
        goto out;
    }

out:
    return matched_child_p;
}

char const * sx_xml_element_content_get(sx_xml_element_t const * xml_element_p)
{
    char const * content_p = NULL;

    SX_XML_CHECK_NULL(xml_element_p, "xml_element_p");

    if (xml_element_p->children) {
        content_p = (char const *)xml_element_p->children->content;
    }

out:
    return content_p;
}

sx_xml_list_t * sx_xml_element_list_get(sx_xml_element_t const * xml_element_p)
{
    sx_xml_list_t * xml_list_p = NULL;

    SX_XML_CHECK_NULL(xml_element_p, "xml_element_p");

    xml_list_p = xml_element_p->children;

out:
    return xml_list_p;
}

sx_xml_element_t * sx_xml_element_list_data(sx_xml_list_t * xml_list_p)
{
    sx_xml_element_t * xml_element_p = NULL;

    SX_XML_CHECK_NULL(xml_list_p, "xml_list_p");

    xml_element_p = xml_list_p;

out:
    return xml_element_p;
}

sx_xml_list_t * sx_xml_element_list_next(sx_xml_list_t * xml_list_p)
{
    sx_xml_list_t * next_list_item_p = NULL;

    SX_XML_CHECK_NULL(xml_list_p, "xml_list_p");

    next_list_item_p = xml_list_p->next;

out:
    return next_list_item_p;
}

sx_xml_list_t * sx_xml_element_shallow_list_by_name_get(sx_xml_element_t const * xml_element_p,
                                                        char const             * xml_element_name_p)
{
    sx_xml_list_t* xml_list_p = NULL;
    sx_xml_list_t *last_item_p = NULL;
    sx_xml_list_t *current_item_p = NULL;

    SX_XML_CHECK_NULL(xml_element_p, "xml_element_p");
    SX_XML_CHECK_NULL(xml_element_name_p, "xml_element_name_p");

    current_item_p = xml_element_p->children;
    while (current_item_p != NULL) {
        current_item_p = __sx_xml_list_element_find(current_item_p,
                                                    __sx_xml_element_name_matches,
                                                    xml_element_name_p);
        if (current_item_p != NULL) {
            last_item_p = __sx_xml_shallow_list_append(last_item_p, current_item_p);
            if (NULL == xml_list_p) {
                xml_list_p = last_item_p;
            }
            current_item_p = current_item_p->next;
        }
    }

out:
    return xml_list_p;
}

void sx_xml_element_shallow_list_free(sx_xml_list_t * xml_list_p)
{
    /* There is an old code that relies on such behavior */
    if (xml_list_p) {
        __sx_xml_shallow_list_free(xml_list_p);
    }
}
