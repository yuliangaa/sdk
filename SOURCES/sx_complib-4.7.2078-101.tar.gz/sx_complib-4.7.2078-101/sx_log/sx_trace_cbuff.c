/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

#include <complib/cl_circular_buffer.h>
#include <complib/cl_fcntl.h>
#include <complib/cl_process_id.h>
#include <complib/cl_spinlock.h>
#include <complib/sx_trace_cbuff.h>

/***** LOCAL VARIABLES *****/

static boolean_t      g_init = FALSE;
static sx_circ_buff_t g_trace_cbuff;
static cl_spinlock_t  g_lock;

/***** APIs *****/

int sx_trace_cbuff_init(uint32_t log_lines_max)
{
    uint32_t log_lines = 0;

    if (g_init) {
        return 0;
    }

    log_lines = (log_lines_max == 0) ? TRACE_CBUFF_LOG_SIZE_MAX : log_lines_max;

    if (cl_spinlock_init(&g_lock)) {
        return -1;
    }

    if (cl_circ_buff_allocate(TRACE_CBUFF_LINE_SIZE_MAX * sizeof(char), log_lines, &g_trace_cbuff)) {
        return -1;
    }

    g_init = TRUE;

    return 0;
}

void sx_trace_cbuff_deinit()
{
    if (!g_init) {
        return;
    }

    g_init = FALSE;

    cl_spinlock_acquire(&g_lock);
    cl_circ_buff_free(g_trace_cbuff, TRUE);
    cl_spinlock_release(&g_lock);

    cl_spinlock_destroy(&g_lock);
}

void sx_trace_cbuff_log(char const *p_str, ...)
{
    va_list        args;
    char           new_line[TRACE_CBUFF_LINE_SIZE_MAX] = "";
    char           tmp_line[TRACE_CBUFF_LINE_SIZE_MAX] = "";
    struct timeval tv;
    struct tm     *nowtm = NULL;
    char           tmbuf[64] = "";
    int            tid = 0;

    if (!g_init) {
        return;
    }

    tv.tv_sec = (time_t)0;
    tv.tv_usec = 0L;

    gettimeofday(&tv, NULL);
    nowtm = localtime(&tv.tv_sec);
    strftime(tmbuf, sizeof(tmbuf), "%d-%m-%Y %H:%M:%S", nowtm);
    cl_get_thread_id(&tid);
    va_start(args, p_str);
    vsnprintf(tmp_line, TRACE_CBUFF_LINE_SIZE_MAX, p_str, args);
    snprintf(new_line, TRACE_CBUFF_LINE_SIZE_MAX, "[%s] tid:[%u] %s", tmbuf, (uint32_t)tid, tmp_line);
    new_line[TRACE_CBUFF_LINE_SIZE_MAX - 1] = '\0';
    va_end(args);

    cl_spinlock_acquire(&g_lock);
    cl_circ_buff_overwrite(g_trace_cbuff, new_line);
    cl_spinlock_release(&g_lock);
}

void sx_trace_cbuff_dump(const char *path_to_dump)
{
    FILE * dump_file = NULL;
    char   tmp_line[TRACE_CBUFF_LINE_SIZE_MAX];

    if (!g_init) {
        return;
    }
    if (path_to_dump == NULL) {
        dump_file = cl_fopen(TRACE_CBUFF_DEFAULT_DUMP_PATH, "w");
    } else {
        dump_file = cl_fopen(path_to_dump, "w");
    }
    if (dump_file == NULL) {
        return;
    }

    cl_spinlock_acquire(&g_lock);
    while (!cl_circ_buff_empty(g_trace_cbuff)) {
        if (cl_circ_buff_read(g_trace_cbuff, tmp_line)) {
            break;
        }
        fwrite(tmp_line, sizeof(char), strlen(tmp_line), dump_file);
        if (ferror(dump_file)) {
            break;
        }
    }
    cl_spinlock_release(&g_lock);
    /* coverity[check_return] */
    cl_fclose(dump_file);
}
