/*
 * Copyright © 2022-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __SX_XML_H__
#define __SX_XML_H__

#include <complib/cl_types.h>
#include <complib/sx_log.h>

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct sx_xml_parser sx_xml_parser_t;
typedef struct sx_xml_reader sx_xml_reader_t;
typedef struct _xmlDoc sx_xml_tree_t;
typedef struct _xmlNode sx_xml_element_t;
typedef struct _xmlNode sx_xml_list_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/**
 * This API initializes the sx_log module if needed and
 * enables log messages of the sx_xml module.
 *
 * @param[in] logging_cb - Optional log messages callback
 *
 * @return CL_SUCCESS
 */
cl_status_t sx_xml_log_function_set(sx_log_cb_t log_cb);

/**
 * This API sets the log verbosity level of the sx_xml module.
 *
 * @param[in] verbosity_level      - verbosity level
 *
 * @return CL_SUCCESS
 */
cl_status_t sx_xml_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

/**
 * This API gets the log verbosity level of the sx_xml module.
 *
 * @param[out] verbosity_level_p    - verbosity level
 *
 * @return CL_SUCCESS
 */
cl_status_t sx_xml_log_verbosity_level_get(sx_verbosity_level_t * verbosity_level_p);

/**
 * This API creates a new XML parser.
 *
 * @return a new XML parser if operation completes successfully
 * @return NULL if operation fails
 */
sx_xml_parser_t * sx_xml_parser_create(void);

/**
 * This API frees an XML parser.
 *
 * @param[in] xml_parser_p      - an XML parser
 */
void sx_xml_parser_free(sx_xml_parser_t * xml_parser_p);

/**
 * This API tells an XML parser to ignore white spaces.
 *
 * @param[in] xml_parser_p      - an XML parser
 */
void sx_xml_parser_ignore_whitespaces(sx_xml_parser_t * xml_parser_p);

/**
 * This API creates a new XML reader for the given file name.
 *
 * @param[in] xml_file_path      - the path to an XML file
 *
 * @return a new XML reader if operation completes successfully
 * @return NULL if operation fails
 */
sx_xml_reader_t * sx_xml_reader_create(char const * xml_file_path_p);

/**
 * This API frees an XML reader.
 *
 * @param[in] xml_reader_p      - an XML reader
 */
void sx_xml_reader_free(sx_xml_reader_t * xml_reader_p);

/**
 * This API creates an XML tree using the given XML parser and XML reader.
 *
 * @param[in] xml_parser_p      - an XML parser
 * @param[in] xml_reader_p      - an XML reader
 *
 * @return an XML tree if operation completes successfully
 * @return NULL if operation fails
 */
sx_xml_tree_t * sx_xml_tree_create(sx_xml_parser_t * xml_parser_p,
                                   sx_xml_reader_t * xml_reader_p);

/**
 * This API frees an XML tree.
 *
 * @param[in] xml_tree_p      - an XML tree
 */
void sx_xml_tree_free(sx_xml_tree_t * xml_tree_p);

/**
 * This API returns the root element of the given XML tree.
 *
 * @param[in] xml_tree_p      - an XML tree
 *
 * @return the root element if operation completes successfully
 * @return NULL if operation fails
 */
sx_xml_element_t * sx_xml_tree_root_element_get(sx_xml_tree_t * xml_tree_p);

/**
 * This API returns the first child from the given XML element.
 *
 * @param[in] xml_element_p      - an XML element
 * @param[in] xml_element_name_p - the name of the child
 *
 * @return an XML element if operation completes successfully
 * @return NULL if no element is found
 */
sx_xml_element_t * sx_xml_element_by_name_get(sx_xml_element_t const * xml_element_p,
                                              char const             * xml_element_name_p);

/**
 * This API returns the content of the given XML element.
 *
 * @param[in] xml_element_p      - an XML element
 *
 * @return the content of the given XML element if operation completes successfully
 * @return NULL if the given XML element has no content
 */
char const * sx_xml_element_content_get(sx_xml_element_t const * xml_element_p);

/**
 * This API returns the list of children from the given XML element.
 *
 * Note:
 * This list should not be modified.
 *
 * @param[in] xml_element_p      - an XML element
 *
 * @return the list of children if operation completes successfully
 * @return NULL if the given XML element has no children
 */
sx_xml_list_t * sx_xml_element_list_get(sx_xml_element_t const * xml_element_p);

/**
 * This API returns the XML element from the given XML list pointer.
 * IOW, it converts a list item to an XML element, so it can be used
 * to get the content of the list item / XML element or to find a specific
 * child or any other valid operation on an XML element.
 *
 * @param[in] xml_list_p      - an XML list
 *
 * @return an XML element
 */
sx_xml_element_t * sx_xml_element_list_data(sx_xml_list_t * xml_list_p);

/**
 * This API returns the next item of the given XML list pointer.
 *
 * @param[in] xml_list_p      - an XML list
 *
 * @return the next list item if operation completes successfully
 * @return NULL if the given XML list pointer is the last item
 */
sx_xml_list_t * sx_xml_element_list_next(sx_xml_list_t * xml_list_p);

/**
 * This API returns an XML list of children from the given XML element that
 * matches the given name.
 *
 * Note:
 * This list must be freed using sx_xml_element_shallow_list_free.
 *
 * @param[in] xml_element_p      - an XML element
 * @param[in] xml_element_name_p - the name of the child
 *
 * @return an XML list if operation completes successfully
 * @return NULL if no element is found
 */
sx_xml_list_t * sx_xml_element_shallow_list_by_name_get(sx_xml_element_t const * xml_element_p,
                                                        char const             * xml_element_name_p);

/**
 * This API frees an XML list allocated by sx_xml_element_shallow_list_by_name_get.
 *
 * @param[in] xml_list_p      - an XML list
 */
void sx_xml_element_shallow_list_free(sx_xml_list_t * xml_list_p);

#endif /* __SX_XML_H__ */
