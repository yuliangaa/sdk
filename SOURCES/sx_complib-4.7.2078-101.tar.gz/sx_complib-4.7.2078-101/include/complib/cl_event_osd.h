/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Declaration of event object.
 */

#ifndef _CL_EVENT_OSD_H_
#define _CL_EVENT_OSD_H_

#include <complib/cl_types.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#include <pthread.h>        /* usr/include */
/*
 * Linux user mode specific data structure for the event object.
 * Users should not access these variables directly.
 */
typedef struct _cl_event_t {
    pthread_condattr_t condattr;
    pthread_cond_t     condvar;
    pthread_mutex_t    mutex;
    boolean_t          signaled;
    boolean_t          manual_reset;
    cl_state_t         state;
} cl_event_t;

END_C_DECLS
#endif              /* _CL_EVENT_OSD_H_ */
