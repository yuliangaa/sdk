/*
 * Copyright (c) 2004-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Declaration of event abstraction.
 */

#ifndef _CL_EVENT_H_
#define _CL_EVENT_H_

/* Indicates that waiting on an event should never timeout */
#define EVENT_NO_TIMEOUT 0xFFFFFFFF

#include <complib/cl_event_osd.h>
#include <sys/select.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
/****h* Component Library/Event
 * NAME
 *	Event
 *
 * DESCRIPTION
 *	The Event provides the ability to suspend and wakeup a thread.
 *
 *	The event functions operates on a cl_event_t structure which should be
 *	treated as opaque and should be manipulated only through the provided
 *	functions.
 *
 * SEE ALSO
 *	Structures:
 *		cl_event_t
 *
 *	Initialization/Destruction:
 *		cl_event_construct, cl_event_init, cl_event_destroy
 *
 *	Manipulation:
 *		cl_event_signal, cl_event_reset, cl_event_wait_on
 *********/
/****f* Component Library: Event/cl_event_construct
 * NAME
 *	cl_event_construct
 *
 * DESCRIPTION
 *	The cl_event_construct function constructs an event.
 *
 * SYNOPSIS
 */
void cl_event_construct(IN cl_event_t * const p_event);
/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure to construct.
 *
 * RETURN VALUE
 *	This function does not return a value.
 *
 * NOTES
 *	Allows calling cl_event_destroy without first calling cl_event_init.
 *
 *	Calling cl_event_construct is a prerequisite to calling any other event
 *	function except cl_event_init.
 *
 * SEE ALSO
 *	Event, cl_event_init, cl_event_destroy
 *********/

/****f* Component Library: Event/cl_event_init
 * NAME
 *	cl_event_init
 *
 * DESCRIPTION
 *	The cl_event_init function initializes an event for use.
 *
 * SYNOPSIS
 */
cl_status_t cl_event_init(IN cl_event_t * const p_event, IN const boolean_t manual_reset);
/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure to initialize.
 *
 *	manual_reset
 *		[in] If FALSE, indicates that the event resets itself after releasing
 *		a single waiter.  If TRUE, the event remains in the signalled state
 *		until explicitly reset by a call to cl_event_reset.
 *
 * RETURN VALUES
 *	CL_SUCCESS if event initialization succeeded.
 *
 *	CL_ERROR otherwise.
 *
 * NOTES
 *	Allows calling event manipulation functions, such as cl_event_signal,
 *	cl_event_reset, and cl_event_wait_on.
 *
 *	The event is initially in a reset state.
 *
 * SEE ALSO
 *	Event, cl_event_construct, cl_event_destroy, cl_event_signal,
 *	cl_event_reset, cl_event_wait_on
 *********/

/****f* Component Library: Event/cl_event_destroy
 * NAME
 *	cl_event_destroy
 *
 * DESCRIPTION
 *	The cl_event_destroy function performs any necessary cleanup of an event.
 *
 * SYNOPSIS
 */
void cl_event_destroy(IN cl_event_t * const p_event);

/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure to destroy.
 *
 * RETURN VALUE
 *	This function does not return a value.
 *
 * NOTES
 *	This function should only be called after a call to cl_event_construct
 *	or cl_event_init.
 *
 * SEE ALSO
 *	Event, cl_event_construct, cl_event_init
 *********/

/****f* Component Library: Event/cl_event_signal
 * NAME
 *	cl_event_signal
 *
 * DESCRIPTION
 *	The cl_event_signal function sets an event to the signalled state and
 *	releases at most one waiting thread.
 *
 * SYNOPSIS
 */
cl_status_t cl_event_signal(IN cl_event_t * const p_event);
/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure to set.
 *
 * RETURN VALUES
 *	CL_SUCCESS if the event was successfully signalled.
 *
 *	CL_ERROR otherwise.
 *
 * NOTES
 *	For auto-reset events, the event is reset automatically once a wait
 *	operation is satisfied.
 *
 *	Triggering the event multiple times does not guarantee that the same
 *	number of wait operations are satisfied. This is because events are
 *	either in a signalled on non-signalled state, and triggering an event
 *	that is already in the signalled state has no effect.
 *
 * SEE ALSO
 *	Event, cl_event_reset, cl_event_wait_on
 *********/

/****f* Component Library: Event/cl_event_reset
 * NAME
 *	cl_event_reset
 *
 * DESCRIPTION
 *	The cl_event_reset function sets an event to the non-signalled state.
 *
 * SYNOPSIS
 */
cl_status_t cl_event_reset(IN cl_event_t * const p_event);
/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure to reset.
 *
 * RETURN VALUES
 *	CL_SUCCESS if the event was successfully reset.
 *
 *	CL_ERROR otherwise.
 *
 * SEE ALSO
 *	Event, cl_event_signal, cl_event_wait_on
 *********/

/****f* Component Library: Event/cl_event_wait_on
 * NAME
 *	cl_event_wait_on
 *
 * DESCRIPTION
 *	The cl_event_wait_on function waits for the specified event to be
 *	triggered for a minimum amount of time.
 *
 * SYNOPSIS
 */
cl_status_t cl_event_wait_on(IN cl_event_t * const p_event,
                             IN const uint32_t wait_us, IN const boolean_t interruptible);
/*
 * PARAMETERS
 *	p_event
 *		[in] Pointer to an cl_event_t structure on which to wait.
 *
 *	wait_us
 *		[in] Number of microseconds to wait.
 *
 *	interruptible
 *		[in] Indicates whether the wait operation can be interrupted
 *		by external signals.
 *
 * RETURN VALUES
 *	CL_SUCCESS if the wait operation succeeded in response to the event
 *	being set.
 *
 *	CL_TIMEOUT if the specified time period elapses.
 *
 *	CL_NOT_DONE if the wait was interrupted by an external signal.
 *
 *	CL_ERROR if the wait operation failed.
 *
 * NOTES
 *	If wait_us is set to EVENT_NO_TIMEOUT, the function will wait until the
 *	event is triggered and never timeout.
 *
 *	If the timeout value is zero, this function simply tests the state of
 *	the event.
 *
 *	If the event is already on the signalled state at the time of the call
 *	to cl_event_wait_on, the call completes immediately with CL_SUCCESS.
 *
 * SEE ALSO
 *	Event, cl_event_signal, cl_event_reset
 *********/

/***** Component Library: Event/cl_event_wait_on_seconds
 * NAME
 *             cl_event_wait_on_seconds
 *
 * DESCRIPTION
 *             Same functionality as cl_event_wait_on.
 *             The cl_event_wait_on_seconds function gets wait time in seconds.
 *             For additional information, please see cl_event_wait_on synopsis
 *
 * SYNOPSIS
 */
cl_status_t cl_event_wait_on_seconds(IN cl_event_t * const p_event,
                                     IN const uint32_t     wait_second,
                                     IN const boolean_t    interruptible);


/****
 * NAME
 *  cl_fd_init
 *
 * DESCRIPTION
 *  The cl_fd_init function creates a PIPE with 2 file descriptors.
 *  The first element fd_arr[0] will hold the read end of the PIPE
 *  and the second element will hold the write end of the PIPE.
 *
 * SYNOPSIS
 */
cl_status_t cl_fd_init(int *fd_arr);
/*
 * PARAMETERS
 *  fd_arr
 *      [in] Array of 2 integers to be used with PIPE function to create 2 file descriptors.
 *
 * RETURN VALUES
 *  CL_SUCCESS if the PIPE was created successfully.
 *
 *  CL_ERROR otherwise.
 *
 *********/

/****f*
 * NAME
 *  cl_fd_wait_on
 *
 * DESCRIPTION
 *  The cl_fd_wait_on function waits until one or more of the read file descriptors receives
 *  data to read from the write end of the pipe or timeout occurred.
 *
 *
 * SYNOPSIS
 */
cl_status_t cl_fd_wait_on(IN int const       max_fd,
                          fd_set           * read_fds_p,
                          fd_set           * except_fds_p,
                          IN struct timeval *timeout_p,
                          int               *ret);
/*
 * PARAMETERS
 *  max_fd
 *      [in] maximum file descriptor identifier.
 *
 *  read_fds_p
 *      [in] Pointer to set of file descriptors to be checked for read readiness.
 *
 *  except_fds_p
 *      [in] Pointer to set of file descriptors to be checked for exceptional conditions.
 *
 *  timeout_p
 *      [in] Pointer to an timeval structure that specifies the maximum time the function
 *      will be blocked. NULL means the function will be blocked until an event occurred.
 *
 *  ret
 *      [in/out] The value returned from the function.
 *
 * RETURN VALUES
 *  CL_SUCCESS if the operation succeeded.
 *
 *  CL_ERROR otherwise.
 *
 *********/

/****f* Component Library: Event/cl_fd_signal
 * NAME
 *  cl_fd_signal
 *
 * DESCRIPTION
 *  The cl_fd_signal function writes to the given file descriptor and signal
 *  the read end of the PIPE that waits in cl_fd_wait_on function
 *
 * SYNOPSIS
 */
cl_status_t cl_fd_signal(IN int write_fd);
/*
 * PARAMETERS
 *  write_fd
 *      [in] The write file descriptor to use in order to signal the read end of the pipe
 *      which is waiting on the function cl_fd_wait_on.
 *
 * RETURN VALUES
 *  CL_SUCCESS if the write operation succeeded.
 *
 *  CL_ERROR otherwise.
 *
 *********/

/****f* Component Library: Event/cl_fd_read
 * NAME
 *  cl_fd_read
 *
 * DESCRIPTION
 *  The cl_fd_read function reads from the given file descriptor
 *
 * SYNOPSIS
 */
cl_status_t cl_fd_read(IN int read_fd);
/*
 * PARAMETERS
 *  read_fd
 *      [in] The read file descriptor in order to read from the read end of the pipe
 *
 * RETURN VALUES
 *  CL_SUCCESS if the read operation succeeded.
 *
 *  CL_ERROR otherwise.
 *
 *********/

END_C_DECLS
#endif              /* _CL_EVENT_H_ */
