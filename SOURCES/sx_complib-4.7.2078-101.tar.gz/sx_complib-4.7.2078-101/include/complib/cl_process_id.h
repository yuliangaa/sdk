/*
 * Copyright © 2002-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	This file contains the process ID.
 */

#ifndef _CL_PROCESS_ID_H_
#define _CL_PROCESS_ID_H_

#include <complib/cl_types.h>
#include <unistd.h>
#include <pthread.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

static inline cl_status_t cl_get_process_id(OUT int *pid)
{
    CL_ASSERT(pid);

    *pid = getpid();

    return (CL_SUCCESS);
}

static inline cl_status_t cl_get_thread_id(OUT int *tid)
{
    CL_ASSERT(tid);

    *tid = pthread_self();

    return (CL_SUCCESS);
}


END_C_DECLS
#endif              /* _CL_PROCESS_ID_H_ */
