/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Declaration of functions for reporting debug output.
 */

#ifndef _CL_INIT_H_
#define _CL_INIT_H_

#include <complib/cl_types.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

void complib_init(void);

void complib_exit(void);

/****f* Component Library: Debug Output/cl_is_debug
 * NAME
 *	cl_is_debug
 *
 * DESCRIPTION
 *	The cl_is_debug function returns TRUE if the complib was compiled
 *  in debug mode, and FALSE otherwise.
 *
 * SYNOPSIS
 */
boolean_t cl_is_debug(void);
/*
 * PARAMETERS
 *    None
 *
 * RETURN VALUE
 *	  TRUE if compiled in debug version. FALSE otherwise.
 *
 * NOTES
 *
 *********/

END_C_DECLS
#endif              /* _CL_INIT_H_ */
