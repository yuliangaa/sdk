/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *  Turns on byte packing, which is necessary for passing information from
 *	system to system over a network to ensure no padding by the compiler has
 *	taken place.
 */

/****h* Component Library/Structure Packing
 * NAME
 *	Structure Packing
 *
 * DESCRIPTION
 *	The structure packing header files allow packing structures on byte
 *	boundaries.
 *
 *	Structure packing should be used whenever a structure is transmitted
 *	between systems, as different platforms pad structures differently if
 *	they are not packed.  Packing a structure that is not transmitted between
 *	systems can be detrimental to performance, as fields in the structure may
 *	not align properly for some platforms. Care must be taken when creating
 *	packed structures that the alignment rules for all platforms are followed.
 *
 *	To pack a structure, include ipackon.h before defining the structure, and
 *	include ipackoff.h after the structure definition.  Multiple structures
 *	can be packed between the two include statements if desired.
 *
 *	The structure definition itself must use the PACK_SUFFIX keyword.
 *
 * EXAMPLE
 *	#include <complib/ipackon.h>
 *
 *	typedef _my_struct_t
 *	{
 *	    uint64 large;
 *	    uint32 medium;
 *	    uint16 small;
 *
 *	} PACK_SUFFIX my_struct_t;
 *	#include <complib/ipackoff.h>
 *********/

#ifndef PACK_SUFFIX
#define PACK_SUFFIX __attribute__((packed))
#endif

#ifdef _MSC_VER
#pragma pack (push, 1)
#endif
