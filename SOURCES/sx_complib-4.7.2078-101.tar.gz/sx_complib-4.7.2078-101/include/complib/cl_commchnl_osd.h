/*
 * Copyright © 2010-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Implementation of communication channel object.
 */

#ifndef _CL_COMMCHNL_OSD_H_
#define _CL_COMMCHNL_OSD_H_

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#include <complib/cl_types.h>
#include <sys/socket.h>

/****d* Component Library: Communication Channel/cl_commchnl_side_t
 * NAME
 *	cl_commchnl_side_t
 *
 * DESCRIPTION
 *	The cl_commchnl_side_t enumerated type is used to note the side
 *	of the communication channel.
 *
 * SYNOPSIS
 */
typedef enum _cl_commchnl_side {
    CL_COMMCHNL_SIDE_CLIENT = 0,
    CL_COMMCHNL_SIDE_SERVER,

    CL_COMMCHNL_SIDE_COUNT      /* should be the last value */
} cl_commchnl_side_t;
/*
 * SEE ALSO
 *	Communication Channel
 *********/

/****d* Component Library: Communication Channel/cl_commchnl_t
 * NAME
 *	cl_commchnl_t
 *
 * DESCRIPTION
 *	Communication Channel structure.
 *
 *	The cl_commchnl_t structure should be treated as opaque and should be
 *	manipulated only through the provided functions.
 *
 * SYNOPSIS
 */
typedef struct _cl_commchnl {
    int                socket;
    cl_commchnl_side_t side;
    cl_state_t         state;
    pid_t              pid;
} cl_commchnl_t;
/*
 * FIELDS
 *	socket
 *		File descriptor that holds unix domain socket.
 *
 *	side
 *		Side of the communication channel.
 *
 *	state
 *		State of the communication channel.
 *
 * SEE ALSO
 *	Communication Channel
 *********/

END_C_DECLS
#endif              /* _CL_COMMCHNL_OSD_H_ */
