/*
 * Copyright © 2010-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __SX_WORK_QUEUEP_H__
#define __SX_WORK_QUEUEP_H__

#include <complib/cl_types.h>
#include <complib/cl_qlist.h>
#include <complib/sx_log.h>
#include <sys/types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum sx_work_queuep_status {
    SX_WORK_QUEUEP_STATUS_SUCCESS,
    SX_WORK_QUEUEP_STATUS_ERROR,
    SX_WORK_QUEUEP_STATUS_NO_RESOURCES,
    SX_WORK_QUEUEP_STATUS_NO_MEMORY,
    SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED,
    SX_WORK_QUEUEP_STATUS_PARAM_NULL,
    SX_WORK_QUEUEP_STATUS_PARAM_ERROR,
    SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE,
    SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED,
    SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED,
    SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND,
    SX_WORK_QUEUEP_STATUS_ALREADY_EXISTS,
    /****************************************************/
    SX_WORK_QUEUEP_STATUS_MIN = SX_WORK_QUEUEP_STATUS_SUCCESS,
    SX_WORK_QUEUEP_STATUS_MAX = SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND,
} sx_work_queuep_status_t;


#define SX_WORK_QUEUE_PSTATUS_CHECK_RANGE(STATUS) (STATUS <= SX_WORK_QUEUEP_STATUS_MAX)

#define SX_WORK_QUEUEP_STATUS_MSG(STATUS)                                      \
    SX_WORK_QUEUE_PSTATUS_CHECK_RANGE(STATUS) ? sx_work_queuep_status2str_arr[ \
        STATUS] : "Unknown return code"

static __attribute__((__used__)) const char *sx_work_queuep_status2str_arr[] = {
    /*SX_WORK_QUEUEP_STATUS_SUCCESS = 0*/
    "Success",

    /*SX_WORK_QUEUEP_STATUS_ERROR = 1*/
    "Internal Error",

    /*SX_WORK_QUEUEP_STATUS_NO_RESOURCES = 2*/
    "No More Resources",

    /*SX_WORK_QUEUEP_STATUS_NO_MEMORY = 3*/
    "No More Memory",

    /*SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED = 4*/
    "Command Unsupported",

    /*SX_WORK_QUEUEP_STATUS_PARAM_NULL = 5*/
    "Parameter NULL",

    /*SX_WORK_QUEUEP_STATUS_PARAM_ERROR = 6*/
    "Parameter Error",

    /*SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE = 7*/
    "Parameter Exceeds Range",

    /*SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED = 8*/
    "Already initialized",

    /*SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED = 9*/
    "Module is uninitialized",

    /*SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND = 10*/
    "Entry Not Found",

    /*SX_WORK_QUEUEP_STATUS_ALREADY_EXISTS = 11*/
    "Entry Already Exists",
};

typedef enum sx_work_queuep_cmd {
    SX_WORK_QUEUEP_CMD_ADD,
    SX_WORK_QUEUEP_CMD_DELETE,
    SX_WORK_QUEUEP_CMD_GET,
    SX_WORK_QUEUEP_CMD_GET_COUNT,
    SX_WORK_QUEUEP_CMD_GET_FIRST,
    SX_WORK_QUEUEP_CMD_GET_NEXT,
    SX_WORK_QUEUEP_CMD_MAX
} sx_work_queuep_cmd_t;

typedef struct sx_work_queuep_params {
    uint32_t reserved1;
} sx_work_queuep_params_t;

typedef struct sx_work_queuep_module_thread_attr {
    uint32_t reserved1;
} sx_work_queuep_module_thread_attr_t;

typedef enum sx_work_queue_type {
    SX_WORK_QUEUE_TYPE_PRIVATE_E, /* No scheduling is being done */
    SX_WORK_QUEUE_TYPE_ORDERED_E, /* Scheduler cb run in thread context and select queue from ordered and best effort queues */
    SX_WORK_QUEUE_TYPE_BEST_EFFORT_E, /* Scheduler cb run in thread context and select queue */
    SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E, /* Wait for jobs in private queue and execute job cb in Thread context */
    SX_WORK_QUEUE_TYPE_MIN_E = SX_WORK_QUEUE_TYPE_PRIVATE_E,
    SX_WORK_QUEUE_TYPE_MAX_E = SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E
} sx_work_queue_type_e;

typedef enum sx_work_queuep_completion_notification_type {
    SX_WORK_QUEUEP_COMPLETION_TYPE_PRE_E,
    SX_WORK_QUEUEP_COMPLETION_TYPE_POST_E,
    SX_WORK_QUEUEP_COMPLETION_MIN_E = SX_WORK_QUEUEP_COMPLETION_TYPE_PRE_E,
    SX_WORK_QUEUEP_COMPLETION_MAX_E = SX_WORK_QUEUEP_COMPLETION_TYPE_POST_E
} sx_work_completion_notification_type_e;

typedef uint32_t sx_work_queue_id_t;
typedef uint16_t sx_work_queuep_job_type_id_t;
typedef uint16_t sx_work_queuep_module_id_t;

typedef struct sx_work_queue_pair_info {
    sx_work_queue_id_t   queue_id;    /* queue id*/
    sx_work_queue_id_t   completion_queue_id;    /* completion queue id. Applicable when Queue type is SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E */
    int32_t              queue_fd[2];    /* queue pipe fd */
    int32_t              completion_queue_fd[2];    /* completion queue pipe fd */
    sx_work_queue_type_e queue_pair_type;
} sx_work_queue_pair_info_t;

/* Info for job cb function */
typedef struct sx_work_queuep_job_cb_info {
    void                      *context;             /* context of this job */
    void                      *completion_context;  /* completion context of this job */
    void                      *job_data;            /* job data */
    sx_work_queuep_module_id_t module_id;           /* module id of this job*/
    sx_work_queue_id_t         trigerred_queue_id_p; /* queue id which triggered this job */
    cl_qlist_t                *queue_pair_qlist_p; /* item is sx_work_queuep_module_info_queue_pair_list_item_t*/
    void                      *infra_internal_ctx; /* internal infrastructure context - not for external used*/
} sx_work_queuep_job_cb_info_t;

/* callback to the executed function job */
typedef sx_work_queuep_status_t (*sx_work_queuep_job_cb)(sx_work_queuep_job_cb_info_t* job_cb_info_p);

typedef struct sx_work_queuep_scheduler_queue_info {
    sx_work_queue_id_t   queue_id;
    sx_work_queue_type_e queue_type;
} sx_work_queuep_scheduler_queue_info_t;

#define SX_WORK_QUEUEP_MAX_SCHEDULER_CB_QUEUE_SIZE 100

/* Params for scheduler logic function */
typedef struct sx_work_queuep_scheduler_decision_params {
    sx_work_queuep_scheduler_queue_info_t queue_info[SX_WORK_QUEUEP_MAX_SCHEDULER_CB_QUEUE_SIZE];
    uint32_t                              num_of_queues;
} sx_work_queuep_scheduler_decision_params_t;

typedef struct sx_work_queuep_scheduler_decision_result {
    sx_work_queue_id_t selected_queue;
} sx_work_queuep_scheduler_decision_result_t;

/*
 * This callback function implement the scheduler logic
 *
 * @param[in] params_p - input params to the scheduler logic
 * @param[out] result_p - scheduler logic result - selected queue - where to retrieve the next job to be executed.
 *
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
typedef sx_work_queuep_status_t (*sx_work_queuep_scheduler_logic_cb)(sx_work_queuep_scheduler_decision_params_t *
                                                                     params_p,
                                                                     sx_work_queuep_scheduler_decision_result_t *
                                                                     result_p,
                                                                     void *ctx);

typedef struct sx_work_queuep_job_info {
    sx_work_queuep_job_type_id_t           job_type_id;    /* job type id. In */
    sx_work_completion_notification_type_e completion_notif_type;
    void                                  *job_data;
    sx_work_queuep_job_cb                  job_handler_cb;  /* callback to the executed function job */
    void                                  *job_handler_cb_context;  /* job context */
    uint64_t                               ctx;        /* internal context of job info */
    sx_work_queuep_module_id_t             module_id;  /*  module to which the job belongs */
    boolean_t                              should_push_post_completion;  /* should push post completion element to the completion queue */
    boolean_t                              should_push_pre_completion;  /* should push post completion element before execution job */
    boolean_t                              should_call_pre_completion_cb;  /* should call completion cb before execution job */
    boolean_t                              should_call_post_completion_cb;  /* should call completion cb after execution job */
} sx_work_queuep_job_info_t;

/* Info for completion job cb function */
typedef struct sx_work_queuep_completion_cb_params_t {
    sx_work_queue_id_t               completion_queue_id; /* original queue id*/
    const sx_work_queuep_job_info_t *job_info_p; /* completed job info */
} sx_work_queuep_completion_cb_params_t;

/* callback to completion job. This callback will be called before executed function is called and job pushed to completion queue*/
typedef sx_work_queuep_status_t (*sx_work_queuep_pre_completion_cb)(const sx_work_queuep_completion_cb_params_t *params,
                                                                    void                                        *
                                                                    context);

/* callback to completion job. This callback will be called after executed function is called and job pushed to completion queue*/
typedef sx_work_queuep_status_t (*sx_work_queuep_post_completion_cb)(const sx_work_queuep_completion_cb_params_t *
                                                                     params, void *context);

typedef struct sx_work_queuep_module_params {
    uint32_t private_queue_max_num;                             /* Max num of private queues - 0 = Don't care */
    uint32_t ordered_queue_max_num;                             /* Max num of ordered_queue_max_num queues - 0 = Don't care */
    uint32_t best_effort_queue_max_num;                            /* Max num of best effort queues - 0 = Don't care */
    uint32_t private_queue_with_thread_max_num;                             /* Max num of private queue + threads - 0 = Don't care */
    /* max thread count configured by the user*/
    sx_work_queuep_module_thread_attr_t module_thread_attr; /* module thread attributes */
    sx_work_queuep_pre_completion_cb    pre_completion_cb;
    void                               *pre_completion_cb_context;
    sx_work_queuep_post_completion_cb   post_completion_cb;
    void                               *post_completion_cb_context;
    sx_work_queuep_scheduler_logic_cb   scheduler_cb;
    void                               *scheduler_cb_cb_context;
} sx_work_queuep_module_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*
 * This function initializes the async infrastructures.
 *
 * @param[in] thread_cnt - Max number of threads in the system
 * @param[in] params - async infrastructure parameters
 * @param[in] g_ctx - Global context that will be pass in each job
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_MEMORY if no memory is available.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_init(uint32_t                       max_thread_cnt,
                                            const sx_work_queuep_params_t *params,
                                            void                          *g_ctx);

/*
 * This function deinitializes the async infra and stops all the workers
 * threads.
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the module hasn't been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_deinit(void);


/*
 * This function initialize a module at the async infra.
 *
 * @param[in] module - module to be registered
 * @param[in] module_name - module name
 * @param[in] pre_completion_cb - callback to be called before job is executed. not applied to private queue type. Applicable when Queue type is SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E
 * @param[in] pre_completion_cb_context
 * @param[in] post_completion_cb - callback to be called before/after job is executed. not applied to private queue type. Applicable when Queue type is SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E
 * @param[in] post_completion_cb_context
 * @param[in] scheduler_cb - scheduler callback to select between ordered queues and best effort queues
 * @param[in] scheduler_cb_cb_context*
 * @param[in] module_params_p - module params.Configures callback to be called before/after job is executed , scheduler cb, queue numbers limits.
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if the maximum number of modules has
 * already registered.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra has not been
 * initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_module_init(sx_work_queuep_module_id_t            module,
                                                   const char                           *module_name,
                                                   const sx_work_queuep_module_params_t *module_params_p);

/*
 * This function registers a module to the async infra.
 * Module can create a private queue + thread and several private queues.
 * Module can register to a private queue+thread only once.
 *
 * When a module register a Private queue + Thread:
 * 1. Main thread is created with main listener select loop. Handler callback is called for each element.
 *    handle callback see all the module's registered queue.(refer to sx_work_job_cb_info_t)
 * 2. Private queue is created. module can pushed jobs to the queue using the provided queue id.
 * 3. Completion queue is created. Module can decide  per job if it is pushed to completion queue (refer to sx_work_job_info_t)
 *
 * When a module register a Private queue:
 * 1. A queue and a pipe is created . module can add the queue to the listener loop using the command sx_work_module_listener_set.
 *
 * @param[in] module - module to be registered
 * @param[in] queue_type - queue type: - Best Effort / Private / Private Q + Thread
 * @param[in] queue_size - queue size
 * @param[out] queue_pair_info_p - queue pair info
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if the maximum number of modules has
 * already registered.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra has not been
 * initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_module_register(const sx_work_queuep_module_id_t module,
                                                       const sx_work_queue_type_e       queue_type,
                                                       const uint32_t                   queue_size,
                                                       sx_work_queue_pair_info_t       *queue_pair_info_p);

/*
 * This function get queue fd from queue id.
 *
 * @param[in] queue_id                  - queue id
 * @param[out] queue_event_fd_p - queue event fd
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if the maximum number of modules has
 * already registered.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra has not been
 * initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_get_queue_fd(sx_work_queue_id_t queue_id,
                                                    int32_t           *queue_event_fd_p);

/*
 * This function used to add/delete a queue to the module main thread listener loop.
 *
 * @param[in] command - ADD/DELETE
 * @param[in] module - module id
 * @param[in] queue_id - queue id
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if the maximum number of modules has
 * already registered.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra has not been
 * initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_module_listener_set(const sx_work_queuep_cmd_t cmd,
                                                           sx_work_queuep_module_id_t module,
                                                           sx_work_queue_id_t         queue_id);

/*
 * This function set the thread params per module
 *
 * @param[in] module - module to configure
 * @param[in] module_thread_attr - module thread attribute
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if the maximum number of modules has
 * already registered.
 * @return SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED if the module has already been
 * initialized.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra has not been
 * initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_module_thread_params_set(sx_work_queuep_module_id_t                 module,
                                                                const sx_work_queuep_module_thread_attr_t *module_thread_attr);

/*
 * This function unregisters a module from the async infra.
 * The module threads and all its queues will be destroyed
 *
 * @param[in] module - module to be unregistered
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queuep_unregister_module(sx_work_queuep_module_id_t module);

/*
 * This function pushes a job to the work queue of its module.Module can pushed a job async or synced(wait for completion)
 *
 * @param[in] queue_id - job queue to push the job to
 * @param[in] job_info - job info struct.
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_push_job(const sx_work_queue_id_t         queue_id,
                                               const sx_work_queuep_job_info_t *job_info_p);

/*
 * This function returns job from beginning of the Queue and remove it
 *
 * @param[in] queue_id - queue id to pop job from
 * @param[out] job_info_p - job from the beginning of the queue.
 *                                                  The job is removed from the queue
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_pop(sx_work_queue_id_t         queue_id,
                                          sx_work_queuep_job_info_t *job_info_p);

/*
 * This function returns job from beginning of the Queue without removing it
 *
 * @param[in] queue_id - queue id to pop job from
 * @param[out] job_info_p - job from the beginning of the queue
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_peak(sx_work_queue_id_t         queue_id,
                                           sx_work_queuep_job_info_t *job_info_p);

/*
 * This function return list of a all module's queue pairs..
 *
 * @param[in] module - module to which the job belongs
 * @param[out] queue_list_p - list array of all queue pairs of the modules
 * @param[out] num_of_queues_p - number of the queue that belong to the module
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_pairs_list_get(sx_work_queuep_module_id_t module,
                                                     sx_work_queue_pair_info_t *queue_list_p,
                                                     uint32_t                  *num_of_queues_p);

/*
 * This function check if the Queue is empty
 *
 * @param[in] queue_id - queue id to pop job from
 * @param[out] job_info_p - job from the beginning of the queue
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_is_empty(sx_work_queue_id_t queue_id,
                                               boolean_t         *is_empty_p);

/*
 * This function return the Queue size
 *
 * @param[in] queue_id - queue id to pop job from
 * @param[out] size_p - size the queue
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_size_get(sx_work_queue_id_t queue_id,
                                               uint32_t          *size_p);

/*
 * This function return a list of jobs in a queue
 *
 * @param[in] queue_id - queue id to pop job from
 * @param[out] job_info_p - return list of job info in the queue
 * @param[in,out] job_info_cnt_p - [in] number of jobs info to get. If count=0: return the total number of jobs in the queue
 *                                                                 [out number of jobs returned
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_NO_RESOURCES if there is no room in the work queue for
 * the job
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_iter_get(const sx_work_queuep_cmd_t   cmd,
                                               sx_work_queue_id_t           queue_id,
                                               sx_work_queuep_job_type_id_t key,
                                               sx_work_queuep_job_info_t   *job_info_list_p,
                                               uint32_t                    *job_info_cnt_p);


/* Block on a a specified queue . Do not return till element are pushed in to the queue */
sx_work_queuep_status_t sx_work_queuep_wait_on_queue(sx_work_queue_id_t queue_id);

/* wake up a specified queue */
sx_work_queuep_status_t sx_work_queuep_wake_up_queue(sx_work_queue_id_t queue_id);

/*
 * This function wake up module scheduler
 *
 * @param[in] module - Module id to wake up
 *
 * @return SX_WORK_QUEUEP_STATUS_SUCCESS if operation completes successfully.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_WORK_QUEUEP_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED if the async infra or module has
 * not been initialized yet.
 * @return SX_WORK_QUEUEP_STATUS_ERROR general error.
 */
sx_work_queuep_status_t sx_work_queue_wake_up_scheduler(const sx_work_queuep_module_id_t module);

/*
 * This function construct parameters for job handling callback function from a given Job info parameters.
 *
 * @param[in] job_info_p - Job info params structure
 * @param[out] job_cb_info_out_p - job callback info params structure
 *
 */
void sx_work_queuep_build_job_cb_info(sx_work_queuep_job_info_t    *job_info_p,
                                      sx_work_queuep_job_cb_info_t* job_cb_info_out_p);
/*
 * This function cleans up the queue pair associated with a module & queue_id
 *
 * @param[in] module - Module Id
 * @param[out] queue_id - The queue for which we doing the cleanup
 *
 */
sx_work_queuep_status_t sx_work_queuep_module_qpair_list_item_delete(sx_work_queuep_module_id_t module,
                                                                     sx_work_queue_id_t         queue_id);


#endif /* __SX_WORK_QUEUEP_H__ */
