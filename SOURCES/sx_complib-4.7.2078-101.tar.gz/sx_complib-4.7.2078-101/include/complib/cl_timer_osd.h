/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Declaration of timer object.
 */

#ifndef _CL_TIMER_OSD_H_
#define _CL_TIMER_OSD_H_

#include <complib/cl_types.h>
#include <complib/cl_spinlock.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#include <complib/cl_qlist.h>
#include <pthread.h>
typedef enum _cl_timer_state {
    CL_TIMER_IDLE,
    CL_TIMER_QUEUED,
    CL_TIMER_RUNNING
} cl_timer_state_t;

typedef struct _cl_timer_t {
    cl_list_item_t          list_item;
    cl_timer_state_t        timer_state;
    cl_state_t              state;
    cl_pfn_timer_callback_t pfn_callback;
    const void             *context;
    pthread_cond_t          cond;
    struct timespec         timeout;
} cl_timer_t;

/* Internal functions to create the timer provider. */
cl_status_t __cl_timer_prov_create(void);

/* Internal function to destroy the timer provider. */
void __cl_timer_prov_destroy(void);

END_C_DECLS
#endif              /* _CL_TIMER_OSD_H_ */
