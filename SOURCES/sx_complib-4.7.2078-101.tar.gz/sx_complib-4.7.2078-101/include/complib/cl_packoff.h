/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *  Turns off byte packing, which is necessary for passing information from
 *	system to system over a network to ensure no padding by the compiler has
 *	taken place.
 */

#ifdef PACK_SUFFIX
#undef PACK_SUFFIX
#endif

#ifdef _MSC_VER
#pragma pack (pop)
#endif
