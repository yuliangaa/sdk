/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Declaration of semaphore abstraction and semaphore related operations.
 */

#ifndef _CL_SEMAPHORE_OSD_H_
#define _CL_SEMAPHORE_OSD_H_

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#include <complib/cl_types.h>
#include <sys/time.h>
#include <semaphore.h>

typedef struct _cl_semaphore {
    sem_t sem;
} cl_semaphore_t;

END_C_DECLS
#endif              /* _CL_SEMAPHORE_OSD_H_ */
