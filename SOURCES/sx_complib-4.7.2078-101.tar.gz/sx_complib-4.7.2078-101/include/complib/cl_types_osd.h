/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Defines sized datatypes for Linux User mode
 *  exported sizes are int8_t, uint8_t, int16_t, uint16_t, int32_t, uint32_t
 *  int64_t, uint64_t.
 */

#ifndef _CL_TYPES_OSD_H_
#define _CL_TYPES_OSD_H_

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#if defined (_DEBUG_)
#ifdef __IA64__
#define cl_break() asm ("   break 0")
#else               /* __IA64__ */
#define cl_break() asm ("   int $3")
#endif              /* __IA64__ */
#else               /* _DEBUG_ */
#define cl_break
#endif
#include <inttypes.h>
#include <assert.h>
#include <string.h>
/*
 * Types not explicitly defined are native to the platform.
 */
typedef int boolean_t;
typedef volatile int32_t atomic32_t;

#ifndef NULL
#define NULL (void*)0
#endif

#ifndef UNUSED_PARAM
#define UNUSED_PARAM(P) ((void)(P))
#endif

END_C_DECLS
#endif              /* _CL_TYPES_OSD_H_ */
