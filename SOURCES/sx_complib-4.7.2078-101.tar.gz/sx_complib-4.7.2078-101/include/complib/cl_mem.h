/*
 * Copyright © 2004-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef _CL_MEM_H_
#define _CL_MEM_H_

#include <complib/cl_qcomppool.h>
/****f* Component Library: Memory/cl_malloc
 * NAME
 *   cl_malloc
 *
 * DESCRIPTION
 *   The cl_malloc allocates a memory block of requested size for the user.
 *   for more details, see malloc
 * SYNOPSIS
 */
void* cl_malloc(const size_t size);
/*
 * PARAMETERS
 *   size
 *       [in] size of requested memory block in bytes.
 *
 * RETURN VALUE
 *   a pointer to the allocated block upon success. NULL in case of failure
 *
 * SEE ALSO
 *   cl_free
 *********/

/****f* Component Library: Memory/cl_calloc
 * NAME
 *   cl_malloc
 *
 * DESCRIPTION
 *   The cl_malloc allocates a zero filled memory block of requested size for the user.
 *   for more details, see calloc
 * SYNOPSIS
 */
void* cl_calloc(const size_t count, const size_t size);
/*
 * PARAMETERS
 *   count
 *       [in] number of blocks.
 *   size
 *       [in] size of each memory block in bytes.
 *
 * RETURN VALUE
 *   a pointer to the allocated block upon success. NULL in case of failure
 *
 * SEE ALSO
 *   cl_free
 *********/

/****f* Component Library: Memory/cl_free
 * NAME
 *   cl_malloc
 *
 * DESCRIPTION
 *   The cl_free frees a memory block created by cl_malloc/cl_calloc.
 *   for more details, see free
 * SYNOPSIS
 */
cl_status_t cl_free(void* mem_p);
/*
 * PARAMETERS
 *   mem_p
 *       [in] pointer to the beginning of the memory block to free.
 *
 *
 * RETURN VALUE
 *   none
 *
 * SEE ALSO
 *   cl_malloc, cl_calloc
 *********/


/****f* Component Library: Memory/cl_trim
 * NAME
 *   cl_trim
 *
 * DESCRIPTION
 *   The cl_trim function attempts to release free memory from
 *       the heap for more details, see malloc_trim()
 * SYNOPSIS
 */
cl_status_t cl_trim(size_t size);
/*
 * PARAMETERS
 *   size
 *       [in] the amount of free space to leave untrimmed at the top of the heap
 *
 * RETURN VALUE
 *   returns CL_SUCCESS if memory was actually released back to the system, or CL_NOT_DONE if it was not possible to
 *   release any memory.
 *
 *********/


#endif
