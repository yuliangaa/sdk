/*
 * Copyright (c) 2004-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef _CL_BITOPS_H_
#define _CL_BITOPS_H_


#include <complib/cl_types.h>


#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

/****f* Component Library: Bitops/cl_set_bit32
 * NAME
 *  cl_set_bit32
 *
 * DESCRIPTION
 *  The cl_set_bit32 function sets the bit at the specified offset to 1.
 *
 * SYNOPSIS
 */
static inline void cl_set_bit32(uint32_t *addr, uint32_t bit_num)
{
    addr[bit_num >> 5] |= (UINT32_C(1) << (bit_num & 0x1f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint32_t in which to set the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be set.
 *
 * RETURN VALUE
 *  None.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_set_bit64, cl_clear_bit32
 *********/

/****f* Component Library: Bitops/cl_clear_bit32
 * NAME
 *  cl_clear_bit32
 *
 * DESCRIPTION
 *  The cl_clear_bit32 function clears the bit at the specified offset to 0.
 *
 * SYNOPSIS
 */
static inline void cl_clear_bit32(uint32_t *addr, uint32_t bit_num)
{
    addr[bit_num >> 5] &= ~(UINT32_C(1) << (bit_num & 0x1f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint32_t in which to clear the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be cleared.
 *
 * RETURN VALUE
 *  None.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_clear_bit64, cl_set_bit32
 *********/

/****f* Component Library: Bitops/cl_test_bit32
 * NAME
 *  cl_test_bit32
 *
 * DESCRIPTION
 *  The cl_test_bit32 function returns the bit value at the specified offset.
 *
 * SYNOPSIS
 */
static inline uint32_t cl_test_bit32(uint32_t *addr, uint32_t bit_num)
{
    return UINT32_C(1) & (addr[bit_num >> 5] >> (bit_num & 0x1f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint32_t in which to test the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be tested.
 *
 * RETURN VALUE
 *  The value of the bit at the location specified by bit_num.
 *  It's always 0 or 1.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_set_bit32, cl_clear_bit32
 *********/

/****f* Component Library: Bitops/cl_set_bit64
 * NAME
 *  cl_set_bit32
 *
 * DESCRIPTION
 *  The cl_set_bit64 function sets the bit at the specified offset to 1.
 *
 * SYNOPSIS
 */
static inline void cl_set_bit64(uint64_t *addr, uint64_t bit_num)
{
    addr[bit_num >> 6] |= (UINT64_C(1) << (bit_num & 0x3f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint64_t in which to set the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be set.
 *
 * RETURN VALUE
 *  None.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_set_bit32, cl_clear_bit64
 *********/

/****f* Component Library: Bitops/cl_clear_bit64
 * NAME
 *  cl_clear_bit64
 *
 * DESCRIPTION
 *  The cl_clear_bit64 function clears the bit at the specified offset to 0.
 *
 * SYNOPSIS
 */
static inline void cl_clear_bit64(uint64_t *addr, uint64_t bit_num)
{
    addr[bit_num >> 6] &= ~(UINT64_C(1) << (bit_num & 0x3f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint64_t in which to clear the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be cleared.
 *
 * RETURN VALUE
 *  None.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_set_bit64, cl_clear_bit32
 *********/

/****f* Component Library: Bitops/cl_test_bit64
 * NAME
 *  cl_test_bit64
 *
 * DESCRIPTION
 *  The cl_test_bit64 function returns the bit value at the specified offset.
 *
 * SYNOPSIS
 */
static inline uint64_t cl_test_bit64(uint64_t *addr, uint64_t bit_num)
{
    return UINT64_C(1) & (addr[bit_num >> 6] >> (bit_num & 0x3f));
}
/*
 * PARAMETERS
 *  addr
 *      [in] Pointer to an array of uint64_t in which to test the bit.
 *
 *  bit_num
 *      [in] The location of the bit in the array which should be tested.
 *
 * RETURN VALUE
 *  The value of the bit at the location specified by bit_num.
 *  It's always 0 or 1.
 *
 * NOTES
 *
 * SEE ALSO
 *  cl_set_bit64, cl_clear_bit64
 *********/
END_C_DECLS
#endif              /* _CL_BITOPS_H_ */
