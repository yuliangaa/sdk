/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef _CL_FCNTL_H_
#define _CL_FCNTL_H_

#include <stdio.h>
#include <complib/cl_types.h>

FILE* cl_fopen(const char *filename, const char *mode);
cl_status_t cl_fclose(FILE *stream);
cl_status_t cl_remove(const char* filename);
size_t cl_fread(void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t cl_fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t cl_feof(FILE *stream);
cl_status_t cl_file_size(FILE *stream, size_t *file_size_p);
cl_status_t cl_frename(const char* old_filename, const char* new_filename);
cl_status_t cl_sync(void);
cl_status_t cl_fsync(FILE *stream);
cl_status_t cl_fflush(FILE *stream);

#endif
