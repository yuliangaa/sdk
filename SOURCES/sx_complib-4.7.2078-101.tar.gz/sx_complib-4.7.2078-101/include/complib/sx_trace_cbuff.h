/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __SX_TRACE_CBUFF_H__
#define __SX_TRACE_CBUFF_H__

#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <complib/cl_types.h>
#include <complib/sx_log.h>

#ifndef __MODULE__
#define __MODULE__ TRACE_CBUFF
#endif

#define TRACE_CBUFF_DEFAULT_DUMP_PATH "/tmp/sx_trace_cbuff_dump.txt"
#define TRACE_CBUFF_LINE_SIZE_MAX     1024
#define TRACE_CBUFF_LOG_SIZE_MAX      10000


/***** APIs *****/

int sx_trace_cbuff_init(uint32_t log_lines_max);

void sx_trace_cbuff_deinit(void);

void sx_trace_cbuff_dump(const char *path_to_dump);

void sx_trace_cbuff_log(char const *p_str, ...);

#define SX_TRACE_CBUFF(fmt, arg ...)                        \
    do {                                                    \
        sx_trace_cbuff_log("%s[%d]: " fmt,                  \
                           __FUNCTION__, __LINE__, ## arg); \
    } while (0)

#endif /* __SX_TRACE_CBUFF_H__ */
