/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Provides common macros for dealing with byte swapping issues.
 */

#ifndef _CL_BYTESWAP_OSD_H_
#define _CL_BYTESWAP_OSD_H_

/*
 * This provides defines __LITTLE_ENDIAN, __BIG_ENDIAN and __BYTE_ORDER
 */
#include <endian.h>
#include <byteswap.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define cl_ntoh16(x) bswap_16(x)
#define cl_hton16(x) bswap_16(x)
#define cl_ntoh32(x) bswap_32(x)
#define cl_hton32(x) bswap_32(x)
#define cl_ntoh64(x) (uint64_t)bswap_64(x)
#define cl_hton64(x) (uint64_t)bswap_64(x)
#else               /* Big Endian */
#define cl_ntoh16(x) (x)
#define cl_hton16(x) (x)
#define cl_ntoh32(x) (x)
#define cl_hton32(x) (x)
#define cl_ntoh64(x) (x)
#define cl_hton64(x) (x)
#endif
END_C_DECLS
#endif              /* _CL_BYTESWAP_OSD_H_ */
