/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Defines standard math related macros and functions.
 */

#ifndef _CL_MATH_H_
#define _CL_MATH_H_

#include <complib/cl_types.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS
/****d* Component Library: Math/MAX
 * NAME
 *	MAX
 *
 * DESCRIPTION
 *	The MAX macro returns the greater of two values.
 *
 * SYNOPSIS
 *	MAX( x, y );
 *
 * PARAMETERS
 *	x
 *		[in] First of two values to compare.
 *
 *	y
 *		[in] Second of two values to compare.
 *
 * RETURN VALUE
 *	Returns the greater of the x and y parameters.
 *
 * SEE ALSO
 *	MIN, ROUNDUP
 *********/
#ifndef MAX
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#endif
/****d* Component Library: Math/MIN
 * NAME
 *	MIN
 *
 * DESCRIPTION
 *	The MIN macro returns the greater of two values.
 *
 * SYNOPSIS
 *	MIN( x, y );
 *
 * PARAMETERS
 *	x
 *		[in] First of two values to compare.
 *
 *	y
 *		[in] Second of two values to compare.
 *
 * RETURN VALUE
 *	Returns the lesser of the x and y parameters.
 *
 * SEE ALSO
 *	MAX, ROUNDUP
 *********/
#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif
/****d* Component Library: Math/ROUNDUP
 * NAME
 *	ROUNDUP
 *
 * DESCRIPTION
 *	The ROUNDUP macro rounds a value up to a given multiple.
 *
 * SYNOPSIS
 *	ROUNDUP( val, align );
 *
 * PARAMETERS
 *	val
 *		[in] Value that is to be rounded up. The type of the value is
 *		indeterminate, but must be at most the size of a natural integer
 *		for the platform.
 *
 *	align
 *		[in] Multiple to which the val parameter must be rounded up.
 *
 * RETURN VALUE
 *	Returns a value that is the input value specified by val rounded up to
 *	the nearest multiple of align.
 *
 * NOTES
 *	The value provided must be of a type at most the size of a natural integer.
 *********/
#ifndef ROUNDUP
#define ROUNDUP(val, align) \
    ((((val) / (align)) * (align)) + (((val) % (align)) ? (align) : 0))
#endif

#ifndef CEILING
#define CEILING(x, y) (((x) + (y) - 1) / (y))
#endif

#ifndef CEIL_POS
#define CEIL_POS(X) ((X - (int)(X)) > 0 ? (int)(X + 1) : (int)(X))
#endif
END_C_DECLS
#endif              /* _CL_MATH_H_ */
