/*
 * Copyright © 2002-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	This file contains the shared memory.
 */

#ifndef _CL_SHARED_MEMORY_H_
#define _CL_SHARED_MEMORY_H_

#include <complib/cl_types.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

static inline cl_status_t cl_shm_create(IN char * const path, OUT int *shmid)
{
    CL_ASSERT(path);
    CL_ASSERT(shmid);

    *shmid = shm_open(path, O_CREAT | O_EXCL | O_RDWR, 0666);
    if (*shmid < 0) {
        return CL_ERROR;
    }

    return (CL_SUCCESS);
}

static inline cl_status_t cl_shm_open(IN char * const path, OUT int *shmid)
{
    CL_ASSERT(path);

    *shmid = shm_open(path, O_RDWR, 0666);
    if (*shmid < 0) {
        return CL_ERROR;
    }

    return (CL_SUCCESS);
}

static inline cl_status_t cl_shm_destroy(IN char * const path)
{
    int err;

    CL_ASSERT(path);

    err = shm_unlink(path);
    if (err == -1) {
        return CL_ERROR;
    }

    return (CL_SUCCESS);
}

END_C_DECLS
#endif              /* _CL_SHARED_MEMORY_H_ */
