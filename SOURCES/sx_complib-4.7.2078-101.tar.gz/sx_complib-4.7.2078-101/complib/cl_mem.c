/*
 * Copyright © 2004-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <complib/cl_mem.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>


void* cl_malloc(const size_t size)
{
    return (malloc(size));
}

void* cl_calloc(const size_t count, const size_t size)
{
    return (calloc(count, size));
}

cl_status_t cl_free(void* mem_p)
{
    free(mem_p);
    return (CL_SUCCESS);
}

cl_status_t cl_trim(size_t size)
{
    int status = 0;

    status = malloc_trim(size);
    return (status == 1) ? CL_SUCCESS : CL_NOT_DONE;
}
