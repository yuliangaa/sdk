/*
 * Copyright © 2004-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */


#include <complib/cl_event.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <unistd.h>
#include <sys/eventfd.h>

enum time_type {
    TIME_TYPE_MICRO_SECOND,
    TIME_TYPE_SECOND
};


void cl_event_construct(IN cl_event_t * p_event)
{
    CL_ASSERT(p_event);

    p_event->state = CL_UNINITIALIZED;
}

cl_status_t cl_event_init(IN cl_event_t * const p_event, IN const boolean_t manual_reset)
{
    CL_ASSERT(p_event);

    cl_event_construct(p_event);

    pthread_condattr_init(&p_event->condattr);
    pthread_condattr_setclock(&p_event->condattr, CLOCK_MONOTONIC);
    pthread_cond_init(&p_event->condvar, &p_event->condattr);
    pthread_mutex_init(&p_event->mutex, NULL);
    p_event->signaled = FALSE;
    p_event->manual_reset = manual_reset;
    p_event->state = CL_INITIALIZED;

    return CL_SUCCESS;
}

void cl_event_destroy(IN cl_event_t * const p_event)
{
    CL_ASSERT(cl_is_state_valid(p_event->state));

    /* Destroy only if the event was constructed */
    if (p_event->state == CL_INITIALIZED) {
        pthread_cond_broadcast(&p_event->condvar);
        pthread_cond_destroy(&p_event->condvar);
        pthread_condattr_destroy(&p_event->condattr);
        pthread_mutex_destroy(&p_event->mutex);
    }

    p_event->state = CL_UNINITIALIZED;
}

cl_status_t cl_event_signal(IN cl_event_t * const p_event)
{
    /* Make sure that the event was started */
    CL_ASSERT(p_event->state == CL_INITIALIZED);

    pthread_mutex_lock(&p_event->mutex);
    p_event->signaled = TRUE;
    /* Wake up one or all depending on whether the event is auto-resetting. */
    if (p_event->manual_reset) {
        pthread_cond_broadcast(&p_event->condvar);
    } else {
        pthread_cond_signal(&p_event->condvar);
    }

    pthread_mutex_unlock(&p_event->mutex);

    return CL_SUCCESS;
}

cl_status_t cl_event_reset(IN cl_event_t * const p_event)
{
    /* Make sure that the event was started */
    CL_ASSERT(p_event->state == CL_INITIALIZED);

    pthread_mutex_lock(&p_event->mutex);
    p_event->signaled = FALSE;
    pthread_mutex_unlock(&p_event->mutex);

    return CL_SUCCESS;
}

static
cl_status_t cl_event_wait_on_general(IN cl_event_t * const p_event,
                                     IN const uint32_t     wait_time,
                                     IN enum time_type     wait_time_type)
{
    cl_status_t        status;
    int                wait_ret, rc;
    struct timespec    timeout, curtime;
    unsigned long long n_sec;

    /* Make sure that the event was Started */
    CL_ASSERT(p_event->state == CL_INITIALIZED);

    pthread_mutex_lock(&p_event->mutex);

    /* Return immediately if the event is signalled. */
    if (p_event->signaled) {
        if (!p_event->manual_reset) {
            p_event->signaled = FALSE;
        }

        pthread_mutex_unlock(&p_event->mutex);
        return CL_SUCCESS;
    }

    /* If just testing the state, return CL_TIMEOUT. */
    if (wait_time == 0) {
        pthread_mutex_unlock(&p_event->mutex);
        return CL_TIMEOUT;
    }

    if (wait_time == EVENT_NO_TIMEOUT) {
        /* Wait for condition variable to be signaled or broadcast. */
        if (pthread_cond_wait(&p_event->condvar, &p_event->mutex)) {
            status = CL_NOT_DONE;
        } else {
            status = CL_SUCCESS;
        }
    } else {
        /* Get the current time */
        rc = clock_gettime(CLOCK_MONOTONIC, &curtime);
        if (rc == 0) {
            switch (wait_time_type) {
            case TIME_TYPE_MICRO_SECOND:
                n_sec = curtime.tv_nsec + ((wait_time % 1000000)) * 1000;
                timeout.tv_sec =
                    curtime.tv_sec + (wait_time / 1000000) +
                    (n_sec / 1000000000);
                timeout.tv_nsec = n_sec % 1000000000;
                break;

            case TIME_TYPE_SECOND:
                timeout.tv_sec = curtime.tv_sec + wait_time;
                timeout.tv_nsec = curtime.tv_nsec;
                break;

            default:
                status = CL_ERROR;
                goto bail;
            }

            wait_ret = pthread_cond_timedwait(&p_event->condvar,
                                              &p_event->mutex,
                                              &timeout);
            if (wait_ret == 0) {
                status = (p_event->signaled ? CL_SUCCESS : CL_NOT_DONE);
            } else if (wait_ret == ETIMEDOUT) {
                status = CL_TIMEOUT;
            } else {
                status = CL_NOT_DONE;
            }
        } else {
            status = CL_ERROR;
        }
    }

bail:
    if (!p_event->manual_reset) {
        p_event->signaled = FALSE;
    }

    pthread_mutex_unlock(&p_event->mutex);
    return status;
}

cl_status_t cl_event_wait_on(IN cl_event_t * const p_event, IN const uint32_t wait_us,
                             IN const boolean_t interruptible)
{
    UNUSED_PARAM(interruptible);

    return cl_event_wait_on_general(p_event, wait_us, TIME_TYPE_MICRO_SECOND);
}

cl_status_t cl_event_wait_on_seconds(IN cl_event_t * const p_event,
                                     IN const uint32_t     wait_second,
                                     IN const boolean_t    interruptible)
{
    UNUSED_PARAM(interruptible);

    return cl_event_wait_on_general(p_event, wait_second, TIME_TYPE_SECOND);
}

cl_status_t cl_fd_init(int *fd)
{
    cl_status_t status = CL_SUCCESS;

    *fd = eventfd(0, EFD_SEMAPHORE);
    if (*fd < 0) {
        status = CL_ERROR;
    }

    return status;
}

cl_status_t cl_fd_wait_on(IN int              max_fd,
                          fd_set            * read_fds_p,
                          fd_set            * except_fds_p,
                          IN struct timeval * timeout_p,
                          int                *ret)
{
    cl_status_t status = CL_SUCCESS;

    *ret = TEMP_FAILURE_RETRY(select(max_fd + 1, read_fds_p, NULL, except_fds_p, timeout_p));
    if (*ret < 0) {
        status = CL_ERROR;
    }

    return status;
}

cl_status_t cl_fd_signal(IN int fd)
{
    cl_status_t status = CL_SUCCESS;
    uint64_t    wake_up = 1;

    if ((TEMP_FAILURE_RETRY(write(fd, &wake_up, sizeof(wake_up)))) != sizeof(wake_up)) {
        status = CL_ERROR;
    }

    return status;
}

cl_status_t cl_fd_read(IN int fd)
{
    cl_status_t status = CL_SUCCESS;
    uint64_t    wake_up;

    if ((TEMP_FAILURE_RETRY(read(fd, &wake_up, sizeof(wake_up)))) != sizeof(wake_up)) {
        status = CL_ERROR;
    }

    return status;
}
