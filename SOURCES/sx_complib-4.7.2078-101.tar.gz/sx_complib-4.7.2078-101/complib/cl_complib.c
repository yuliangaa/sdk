/*
 * Copyright (c) 2004-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */

#include <complib/cl_types.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_init.h>
#include <complib/cl_dbg.h>

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

/*
 *  Prototypes
 */

extern cl_status_t __cl_timer_prov_create(void);

extern void __cl_timer_prov_destroy(void);

cl_spinlock_t cl_atomic_spinlock;

void complib_init(void)
{
    cl_status_t status = CL_SUCCESS;

    status = cl_spinlock_init(&cl_atomic_spinlock);
    if (status != CL_SUCCESS) {
        goto _error;
    }

    cl_dbg_bp_ctl_db_init();

    status = cl_dbg_health_check_thread_db_init();
    if (status != CL_SUCCESS) {
        goto _error;
    }

    status = __cl_timer_prov_create();
    if (status != CL_SUCCESS) {
        goto _error;
    }

    return;

_error:
    exit(1);
}

void complib_exit(void)
{
    cl_dbg_pool_db_force_deinit();
    __cl_timer_prov_destroy();
    cl_dbg_bp_ctl_db_deinit();
    cl_dbg_health_check_thread_db_deinit();
    cl_spinlock_destroy(&cl_atomic_spinlock);
}

boolean_t cl_is_debug(void)
{
#if defined(_DEBUG_)
    return TRUE;
#else
    return FALSE;
#endif              /* defined( _DEBUG_ ) */
}
