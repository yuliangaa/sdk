/*
 * Copyright © 2004-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <errno.h>
#include <complib/cl_fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


FILE* cl_fopen(const char *filename, const char *mode)
{
    return (fopen(filename, mode));
}

cl_status_t cl_fclose(FILE *stream)
{
    if (fclose(stream) == 0) {
        return (CL_SUCCESS);
    } else {
        return CL_ERROR;
    }
}

cl_status_t cl_remove(const char* filename)
{
    if (remove(filename) == 0) {
        return CL_SUCCESS;
    }
    return CL_ERROR;
}

size_t cl_fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    return (fread(ptr, size, nmemb, stream));
}

size_t cl_fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    return (fwrite(ptr, size, nmemb, stream));
}

size_t cl_feof(FILE *stream)
{
    return (feof(stream));
}

cl_status_t cl_file_size(FILE *stream, size_t *file_size_p)
{
    long int size = 0;
    long int pos = 0;

    if (file_size_p == NULL) {
        return CL_INVALID_PARAMETER;
    }

    *file_size_p = 0;

    /* Save stream position */
    pos = ftell(stream);
    if (pos == -1) {
        return CL_ERROR;
    }

    /* Goto end of stream */
    if (fseek(stream, 0, SEEK_END) != 0) {
        return CL_ERROR;
    }

    /* Check if beginning and End are the same (empty file) */
    size = ftell(stream);
    if (size == -1) {
        return CL_ERROR;
    }

    /* restore stream position */
    if (pos >= 0) {
        if (fseek(stream, pos, SEEK_SET) != 0) {
            return CL_ERROR;
        }
    }

    *file_size_p = (size_t)size;

    return CL_SUCCESS;
}

cl_status_t cl_frename(const char* old_filename, const char* new_filename)
{
    int err = 0;

    if (old_filename == NULL) {
        return CL_INVALID_PARAMETER;
    }

    if (new_filename == NULL) {
        return CL_INVALID_PARAMETER;
    }

    err = rename(old_filename, new_filename);
    if (err) {
        switch (errno) {
        case EACCES:
        case EBUSY:
        case ENOTEMPTY:
        case EEXIST:
        case EINVAL:
        case EISDIR:
        case EMLINK:
        case ENOENT:
        case ENOSPC:
        case EROFS:
        case EXDEV:
        default:
            sx_log(SX_LOG_ERROR, "COMP_LIB", "failed to rename file:[%s] to:[%s] code:[%d,%s]\n",
                   old_filename, new_filename, errno, strerror(errno));
            /* In case (EXDEV) is  returned, files are not mounted on the same system.
             * Workaround would be:
             * (1) allocate a buffer
             * (2) cl_fopen(old_filename "r")
             * (3) cl_fopen(new_filename "w")
             * (4) allocate buffer = cl_file_size(old_filename)
             * while !cl_feof(old_filename) do {
             * cl_fread(buffer, buffer_size, 1 ,old_filename)
             * cl_fwrite(buffer, buffer_size, 1 ,new_filename)
             * }*/
            break;
        }
        return CL_ERROR;
    }
    return CL_SUCCESS;
}

cl_status_t cl_sync(void)
{
    sync();
    return CL_SUCCESS;
}

cl_status_t cl_fsync(FILE *stream)
{
    int rc = 0;
    int fd = 0;

    fd = fileno(stream);
    if (fd == -1) {
        return CL_ERROR;
    }

    rc = fsync(fd);
    if (rc == 0) {
        return CL_SUCCESS;
    } else {
        return CL_ERROR;
    }
}

cl_status_t cl_fflush(FILE *stream)
{
    int rc = 0;

    rc = fflush(stream);
    if (rc == 0) {
        return CL_SUCCESS;
    } else {
        return CL_ERROR;
    }
}
