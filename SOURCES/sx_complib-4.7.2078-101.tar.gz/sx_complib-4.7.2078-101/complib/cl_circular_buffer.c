/*
 * Copyright © 2010-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <unistd.h>
#include "complib/cl_mem.h"
#include "complib/cl_circular_buffer.h"


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

cl_status_t cl_circ_buff_allocate(uint32_t obj_size, uint32_t max_num_entries, sx_circ_buff_t *buff_p)
{
    circ_buff_data_t *new_buffer_p = NULL;
    uint32_t          allocation_size = 0;

    if ((buff_p == NULL) || (obj_size == 0) || (max_num_entries == 0)) {
        return CL_INVALID_PARAMETER;
    }

    allocation_size = sizeof(new_buffer_p[0]) + (obj_size * max_num_entries);

    new_buffer_p = cl_malloc(allocation_size);
    if (new_buffer_p == NULL) {
        return CL_INSUFFICIENT_MEMORY;
    }
    memset(new_buffer_p, 0, allocation_size);

    new_buffer_p->obj_size = obj_size;
    new_buffer_p->max_num_entries = max_num_entries;
    new_buffer_p->read_index = 0;
    new_buffer_p->write_index = 0;
    new_buffer_p->full = FALSE;
    *buff_p = (sx_circ_buff_t)new_buffer_p;

    return CL_SUCCESS;
}

cl_status_t cl_circ_buff_free(sx_circ_buff_t buffer, boolean_t force)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);

    if (force == FALSE) {
        if ((buffer_p->full == TRUE) || (buffer_p->read_index != buffer_p->write_index)) {
            return CL_INVALID_OPERATION;
        }
    }

    cl_free(buffer_p);

    return CL_SUCCESS;
}


void cl_circ_buff_reset(sx_circ_buff_t buffer)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);

    buffer_p->read_index = 0;
    buffer_p->write_index = 0;
    buffer_p->full = FALSE;
    memset(buffer_p->buffer, 0, buffer_p->obj_size * buffer_p->max_num_entries);
}

cl_status_t cl_circ_buff_write(sx_circ_buff_t buffer, void *new_entry_p)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);
    CL_ASSERT(new_entry_p);

    if (buffer_p->full == TRUE) {
        return CL_INSUFFICIENT_RESOURCES;
    }

    memcpy(buffer_p->buffer + (buffer_p->write_index * buffer_p->obj_size), new_entry_p, buffer_p->obj_size);
    buffer_p->write_index = (buffer_p->write_index + 1) % buffer_p->max_num_entries;
    buffer_p->full = (buffer_p->write_index == buffer_p->read_index);

    return CL_SUCCESS;
}

void cl_circ_buff_overwrite(sx_circ_buff_t buffer, void *new_entry_p)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);
    CL_ASSERT(new_entry_p);

    memcpy(buffer_p->buffer + (buffer_p->write_index * buffer_p->obj_size), new_entry_p, buffer_p->obj_size);
    if (buffer_p->full) {
        buffer_p->read_index = (buffer_p->read_index + 1) % buffer_p->max_num_entries;
    }
    buffer_p->write_index = (buffer_p->write_index + 1) % buffer_p->max_num_entries;
    buffer_p->full = (buffer_p->write_index == buffer_p->read_index);
}

cl_status_t cl_circ_buff_read(sx_circ_buff_t buffer, void *entry_p)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);
    CL_ASSERT(entry_p);

    if (cl_circ_buff_peek(buffer, entry_p)) {
        return CL_NOT_FOUND;
    }

    buffer_p->read_index = (buffer_p->read_index + 1) % buffer_p->max_num_entries;
    buffer_p->full = FALSE;

    return CL_SUCCESS;
}

cl_status_t cl_circ_buff_peek(sx_circ_buff_t buffer, void *entry_p)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;
    void             *read_pointer = NULL;

    CL_ASSERT(buffer_p);
    CL_ASSERT(entry_p);

    if (cl_circ_buff_empty(buffer)) {
        return CL_NOT_FOUND;
    }

    read_pointer = buffer_p->buffer + (buffer_p->read_index * buffer_p->obj_size);
    memcpy(entry_p, read_pointer, buffer_p->obj_size);

    return CL_SUCCESS;
}

boolean_t cl_circ_buff_empty(sx_circ_buff_t buffer)
{
    circ_buff_data_t *buffer_p = (circ_buff_data_t*)buffer;

    CL_ASSERT(buffer_p);

    return (buffer_p->full == FALSE && (buffer_p->read_index == buffer_p->write_index));
}
