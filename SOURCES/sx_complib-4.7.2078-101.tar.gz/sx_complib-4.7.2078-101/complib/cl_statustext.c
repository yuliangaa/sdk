/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 *	Defines string to decode cl_status_t return values.
 *
 */

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */

#include <complib/cl_types.h>

/* Status values above converted to text for easier printing. */
const char *cl_status_text[] = {
    "CL_SUCCESS",
    "CL_ERROR",
    "CL_INVALID_STATE",
    "CL_INVALID_OPERATION",
    "CL_INVALID_SETTING",
    "CL_INVALID_PARAMETER",
    "CL_INSUFFICIENT_RESOURCES",
    "CL_INSUFFICIENT_MEMORY",
    "CL_INVALID_PERMISSION",
    "CL_COMPLETED",
    "CL_NOT_DONE",
    "CL_PENDING",
    "CL_TIMEOUT",
    "CL_CANCELED",
    "CL_REJECT",
    "CL_OVERRUN",
    "CL_NOT_FOUND",
    "CL_UNAVAILABLE",
    "CL_BUSY",
    "CL_DISCONNECT",
    "CL_DUPLICATE"
};
