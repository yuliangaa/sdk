/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

/******************************************
* Includes
******************************************/

#if HAVE_CONFIG_H
#include <config.h>
#endif /* HAVE_CONFIG_H */

#include <complib/cl_dbg.h>
#include <complib/cl_qcomppool.h>
#include <complib/cl_comppool.h>
#include <complib/cl_qpool.h>
#include <complib/cl_pool.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_qlist.h>
#include <complib/cl_mem.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_thread.h>
#include <complib/cl_bitops.h>
#include <complib/cl_timer.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/******************************************
* Defines
******************************************/
#define CL_DBG_POOL_DB_NOT_INITED   (0u)
#define CL_DBG_POOL_DB_INITED       (1u)
#define CL_DBG_POOL_DB_FAIL_TO_INIT (2u)
#define CL_DBG_POOL_DB_FORCE_DEINIT (3u)

#define CL_THREAD_UPDATE_STATUS_DB_NOT_INITIALIZED   (0u)
#define CL_THRCL_THREAD_UPDATE_STATUS_DB_INITIALIZED (1u)

#define CL_DBG_POOL_DB_MIN_SIZE  (200)
#define CL_DBG_POOL_DB_MAX_SIZE  CL_POOL_UNLIMITED_MAX_SIZE
#define CL_DBG_POOL_DB_GROW_SIZE (100u)

#define CL_DBG_POOL_DB_BUCKET_MIN_SIZE  (200u)
#define CL_DBG_POOL_DB_BUCKET_MAX_SIZE  CL_POOL_UNLIMITED_MAX_SIZE
#define CL_DBG_POOL_DB_BUCKET_GROW_SIZE (100u)

#define CL_DBG_BP_CTL_DB_MIN_SIZE  (16u)
#define CL_DBG_BP_CTL_DB_MAX_SIZE  CL_POOL_UNLIMITED_MAX_SIZE
#define CL_DBG_BP_CTL_DB_GROW_SIZE (5u)

#define ADD_THREAD    1
#define DELETE_THREAD 0

/******************************************
*  Local variables
******************************************/
/* Pool DB */
static cl_fmap_t     g_dbg_pool_db;
static cl_qpool_t    g_pool_db_entry_pool;
static cl_qpool_t    g_pool_db_bucket_pool;
static cl_spinlock_t g_dbg_pool_db_spinlock;
static uint32_t      g_dbg_pool_db_reg_num = 0;
static uint8_t       g_dbg_pool_db_inited = CL_DBG_POOL_DB_NOT_INITED;
/* Background processes control */
static cl_qpool_t    cl_dbg_bp_ctl_db_pool_g;
static cl_qlist_t    cl_dbg_bp_ctl_db_g;
static cl_spinlock_t cl_dbg_bp_ctl_spinlock_g;
static boolean_t     cl_dbg_bp_ctl_is_inited_g = FALSE;
/* Health check thread monitor DB */
static uint32_t __cl_dbg_thread_status_db_entries_num = 0;
static uint64_t __cl_dbg_running_threads_bm;
static uint64_t __cl_dbg_cmd_cli_not_running_threads_bm;
static uint64_t __cl_dbg_last_sent_threads_bm;
static uint64_t __cl_dbg_new_threads_bm;

/* This lock is to sync __cl_dbg_running_threads_bm __cl_dbg_last_sent_threads_bm and __cl_dbg_new_threads_bm */
static pthread_mutex_t __monitor_threads_bitmap_lock;
static uint8_t         __cl_thread_status_db_initialized = CL_THREAD_UPDATE_STATUS_DB_NOT_INITIALIZED;


static pthread_mutex_t            __health_threads_status_lock;
static cl_thread_status_changed_t __cl_health_thread_status_arr[CL_DBG_NUM_OF_THREADS_BITS];


/******************************************
*  Local function declarations
******************************************/
/* Pool DB */
static int __cl_dbg_pool_db_key_fmap_cmp(IN const void *const p_key1, IN const void *const p_key2);
static cl_status_t cl_dbg_pool_db_init(void);
static void cl_dbg_pool_db_destroy(boolean_t forced);
static void cl_dbg_pool_db_clear_db(void);
static void cl_dbg_pool_db_clear_bucket(cl_dbg_pool_db_bucket_t *bucket_p);
/* Background processes control */
static cl_status_t __cl_dbg_bp_ctl_db_entry_tid_list_cmp(IN const cl_list_item_t * const list_item_p,
                                                         IN void                        *context);
static cl_status_t __cl_dbg_bp_ctl_db_entry_name_list_cmp(IN const cl_list_item_t * const list_item_p,
                                                          IN void                        *context);
static cl_status_t __cl_dbg_bp_ctl_db_entry_id_list_cmp(IN const cl_list_item_t * const list_item_p, IN void *context);
static cl_status_t __cl_dbg_bp_ctl_db_entry_thread_bit_index_list_cmp(IN const cl_list_item_t * const list_item_p,
                                                                      IN void                        *context);
static cl_dbg_bp_ctl_db_entry_t * __cl_dbg_bp_ctl_db_entry_cache(cl_dbg_bp_ctl_db_entry_t **entry_pp);

/******************************************
* Getters
******************************************/

/**
 * Pool DB
 */

cl_fmap_t * cl_dbg_pool_db_get(void)
{
    return &g_dbg_pool_db;
}

cl_spinlock_t * cl_dbg_pool_db_spinlock_get(void)
{
    return &g_dbg_pool_db_spinlock;
}

/**
 * Background processes control
 */

/******************************************
* Setters
******************************************/
uint64_t cl_dbg_get_sdk_threads_bm(cl_dbg_thread_monitor_bm_e get_thread_bm, boolean_t get_all_bm, uint32_t index)
{
    uint64_t result = 0;

    pthread_mutex_lock(&__monitor_threads_bitmap_lock);

    if (CL_DBG_LAST_SENT_THREADS_BM == get_thread_bm) {
        if (get_all_bm) {
            result = __cl_dbg_last_sent_threads_bm;
        } else {
            /* coverity[callee_ptr_arith] */
            result = cl_test_bit64(&__cl_dbg_last_sent_threads_bm, index);
        }
    } else if (CL_DBG_CMD_CLI_NOT_RUNNING_THREADS_BM == get_thread_bm) {
        if (get_all_bm) {
            result = __cl_dbg_cmd_cli_not_running_threads_bm;
        } else {
            /* coverity[callee_ptr_arith] */
            result = cl_test_bit64(&__cl_dbg_cmd_cli_not_running_threads_bm, index);
        }
    } else if (CL_DBG_NEW_THREADS_BM == get_thread_bm) {
        if (get_all_bm) {
            result = __cl_dbg_new_threads_bm;
        } else {
            /* coverity[callee_ptr_arith] */
            result = cl_test_bit64(&__cl_dbg_new_threads_bm, index);
        }
    }
    /* CL_DBG_RUNNING_THREADS_BM */
    else {
        if (get_all_bm) {
            result = __cl_dbg_running_threads_bm;
        } else {
            /* coverity[callee_ptr_arith] */
            result = cl_test_bit64(&__cl_dbg_running_threads_bm, index);
        }
    }

    pthread_mutex_unlock(&__monitor_threads_bitmap_lock);
    return result;
}
void cl_dbg_clear_sdk_threads_bm(cl_dbg_thread_monitor_bm_e clear_thread_bm, boolean_t clear_all_bm, uint32_t index)
{
    pthread_mutex_lock(&__monitor_threads_bitmap_lock);

    switch (clear_thread_bm) {
    case CL_DBG_LAST_SENT_THREADS_BM:
        if (clear_all_bm) {
            __cl_dbg_last_sent_threads_bm = 0;
        } else {
            /* coverity[callee_ptr_arith] */
            cl_clear_bit64(&__cl_dbg_last_sent_threads_bm, index);
            /* coverity[callee_ptr_arith] */
            cl_clear_bit64(&__cl_dbg_new_threads_bm, index);
        }
        break;

    case CL_DBG_RUNNING_THREADS_BM:
        if (clear_all_bm) {
            __cl_dbg_running_threads_bm = 0;
        } else {
            /* coverity[callee_ptr_arith] */
            cl_clear_bit64(&__cl_dbg_running_threads_bm, index);
        }
        break;

    case CL_DBG_CMD_CLI_NOT_RUNNING_THREADS_BM:
        if (clear_all_bm) {
            __cl_dbg_cmd_cli_not_running_threads_bm = 0;
        } else {
            /* coverity[callee_ptr_arith] */
            cl_clear_bit64(&__cl_dbg_cmd_cli_not_running_threads_bm, index);
        }
        break;

    case CL_DBG_NEW_THREADS_BM:
        if (clear_all_bm) {
            __cl_dbg_new_threads_bm = 0;
        } else {
            /* coverity[callee_ptr_arith] */
            cl_clear_bit64(&__cl_dbg_new_threads_bm, index);
        }
        break;

    default:
        sx_log(SX_LOG_ERROR, "COMP_LIB", "Health check: bitmap isn't supported in clear threads bitmap function");
        break;
    }

    pthread_mutex_unlock(&__monitor_threads_bitmap_lock);
}

void cl_dbg_set_sdk_threads_bm(cl_dbg_thread_monitor_bm_e set_thread_bm, boolean_t set_all_bm, uint32_t index)
{
    pthread_mutex_lock(&__monitor_threads_bitmap_lock);

    switch (set_thread_bm) {
    case CL_DBG_LAST_SENT_THREADS_BM:
        if (set_all_bm) {
            __cl_dbg_last_sent_threads_bm = -1;
        } else {
            /* coverity[callee_ptr_arith] */
            cl_set_bit64(&__cl_dbg_last_sent_threads_bm, index);
        }
        break;

    case CL_DBG_CMD_CLI_NOT_RUNNING_THREADS_BM:
        /* coverity[callee_ptr_arith] */
        cl_set_bit64(&__cl_dbg_cmd_cli_not_running_threads_bm, index);
        break;

    case CL_DBG_RUNNING_THREADS_BM:
        if (set_all_bm) {
            __cl_dbg_running_threads_bm = -1;
        } else {
            if (cl_test_bit64(&__cl_dbg_cmd_cli_not_running_threads_bm, index)) {
                /* debug CLI - don't update running bm to simulate the thread is stuck */
                sx_log(SX_LOG_DEBUG, "COMP_LIB", "HEALTH CHECK DEBUG CLI - don't update running bm.\n");
            } else {
                /* coverity[callee_ptr_arith] */
                cl_set_bit64(&__cl_dbg_running_threads_bm, index);
            }
        }
        break;

    default:
        sx_log(SX_LOG_ERROR, "COMP_LIB", "Health check: bitmap isn't supported in set threads bitmap function");
        break;
    }

    pthread_mutex_unlock(&__monitor_threads_bitmap_lock);
}

int cl_dbg_find_free_thread_bit(void)
{
    uint32_t idx = 0;

    pthread_mutex_lock(&__monitor_threads_bitmap_lock);


    for (idx = 0; idx < CL_DBG_NUM_OF_THREADS_BITS; idx++) {
        /* coverity[callee_ptr_arith] */
        if ((cl_test_bit64(&__cl_dbg_last_sent_threads_bm, idx) == 0) &&
            /* coverity[callee_ptr_arith] */
            (cl_test_bit64(&__cl_dbg_new_threads_bm, idx) == 0)) {
            /* Sing under tamp bm that this bit is taken from now to avoid other new thread to use it  */
            /* coverity[callee_ptr_arith] */
            cl_set_bit64(&__cl_dbg_new_threads_bm, idx);
            goto out;
        }
    }

    sx_log(SX_LOG_WARNING, "COMP_LIB", "Health check: new thread will not be monitor due to too small"
           " bit map that contain %d bits .\n", CL_DBG_NUM_OF_THREADS_BITS);
    idx = -1;

out:
    pthread_mutex_unlock(&__monitor_threads_bitmap_lock);
    return idx;
}

cl_status_t cl_dbg_health_check_thread_db_init(void)
{
    cl_status_t status = CL_SUCCESS;

    memset(&__cl_dbg_running_threads_bm, 0, sizeof(__cl_dbg_running_threads_bm));
    memset(&__cl_dbg_cmd_cli_not_running_threads_bm, 0, sizeof(__cl_dbg_cmd_cli_not_running_threads_bm));
    memset(&__cl_dbg_last_sent_threads_bm, 0, sizeof(__cl_dbg_last_sent_threads_bm));
    memset(&__cl_dbg_new_threads_bm, 0, sizeof(__cl_dbg_new_threads_bm));
    __cl_dbg_thread_status_db_entries_num = 0;

    if (pthread_mutex_init(&__monitor_threads_bitmap_lock, NULL)) {
        status = CL_ERROR;
        goto out;
    }
    if (pthread_mutex_init(&__health_threads_status_lock, NULL)) {
        pthread_mutex_destroy(&__monitor_threads_bitmap_lock);
        status = CL_ERROR;
        goto out;
    }

    pthread_mutex_lock(&__health_threads_status_lock);

    memset(__cl_health_thread_status_arr, 0,
           sizeof(cl_thread_status_changed_t) * CL_DBG_NUM_OF_THREADS_BITS);

    __cl_thread_status_db_initialized = CL_THRCL_THREAD_UPDATE_STATUS_DB_INITIALIZED;
    pthread_mutex_unlock(&__health_threads_status_lock);

out:
    return status;
}

/**
 * Destructs health check thread DB infrastructure
 */
void cl_dbg_health_check_thread_db_deinit(void)
{
    if (__cl_thread_status_db_initialized == CL_THRCL_THREAD_UPDATE_STATUS_DB_INITIALIZED) {
        pthread_mutex_destroy(&__monitor_threads_bitmap_lock);
        pthread_mutex_destroy(&__health_threads_status_lock);

        __cl_thread_status_db_initialized = CL_THREAD_UPDATE_STATUS_DB_NOT_INITIALIZED;
        __cl_dbg_thread_status_db_entries_num = 0;
        memset(&__cl_dbg_cmd_cli_not_running_threads_bm, 0, sizeof(__cl_dbg_cmd_cli_not_running_threads_bm));
    } else {
        sx_log(SX_LOG_WARNING, "COMP_LIB", "Health check: try to deinit thread monitor but feature not initialized");
    }
}
/**
 * Insert new thread status entry to array threads DB
 */
cl_status_t cl_health_check_thread_status_changed_db_insert(IN const cl_thread_status_changed_t* thread_status_info)
{
    cl_status_t status = CL_SUCCESS;
    uint32_t    arr_index = 0;


    /* Check if if not inited */
    if (CL_THREAD_UPDATE_STATUS_DB_NOT_INITIALIZED == __cl_thread_status_db_initialized) {
        sx_log(SX_LOG_ERROR,
               "COMP_LIB",
               "Health check: thread status DB not initialized when trying to insert a new thread");
        return CL_INVALID_OPERATION;
    }

    if (NULL == thread_status_info) {
        sx_log(SX_LOG_WARNING, "COMP_LIB", "Health check: thread_status_info is NULL and not initialized");
        return CL_INVALID_PARAMETER;
    }

    pthread_mutex_lock(&__health_threads_status_lock);

    if (thread_status_info->bit_index >= CL_DBG_NUM_OF_THREADS_BITS) {
        sx_log(SX_LOG_ERROR, "COMP_LIB", "Health check: thread bit_index =%u is "
               "out of range", thread_status_info->bit_index);
        status = CL_INVALID_PARAMETER;
        goto out;
    }
    /*Go over all new/delete threads that created while main thread sleep.
     *  stop condition -thread id = 0 indicate empty entry */
    while ((arr_index < CL_DBG_NUM_OF_THREADS_BITS) && __cl_health_thread_status_arr[arr_index].thread_id) {
        if (thread_status_info->bit_index == __cl_health_thread_status_arr[arr_index].bit_index) {
            /*Overwrite this entry with the latest updated entry */
            /* This print is for debug usage */
            sx_log(SX_LOG_NOTICE,
                   "COMP_LIB",
                   "Health check: Before Overwrite the old sdk thread entry %s"
                   "on change array index [%d] , the new entry has bit index [%d] ,  with cmd %s "
                   "num of entries in array [%d] ",
                   __cl_health_thread_status_arr[arr_index].name,
                   arr_index,
                   __cl_health_thread_status_arr[arr_index].bit_index,
                   (__cl_health_thread_status_arr[arr_index].cmd) ? "ADD" : "DELETE",
                   __cl_dbg_thread_status_db_entries_num);
            memcpy(&__cl_health_thread_status_arr[arr_index], thread_status_info,
                   sizeof(cl_thread_status_changed_t));
            /* This print is for debug usage */
            sx_log(SX_LOG_NOTICE,
                   "COMP_LIB",
                   "Health check: After Overwrite the new sdk thread entry %s "
                   "on change array index [%d] , the new entry has bit index [%d] ,  with cmd %s "
                   "num of entries in array [%d] ",
                   __cl_health_thread_status_arr[arr_index].name,
                   arr_index,
                   __cl_health_thread_status_arr[arr_index].bit_index,
                   (__cl_health_thread_status_arr[arr_index].cmd) ? "ADD" : "DELETE",
                   __cl_dbg_thread_status_db_entries_num);
            goto out;
        }
        arr_index++;
    }
    /*In case its a thread that connect to a new bit new entry will be write */
    if (arr_index < CL_DBG_NUM_OF_THREADS_BITS) {
        memcpy(&__cl_health_thread_status_arr[arr_index], thread_status_info,
               sizeof(cl_thread_status_changed_t));
        __cl_dbg_thread_status_db_entries_num++;
        /* This print is for debug usage */
        sx_log(SX_LOG_NOTICE, "COMP_LIB", "Health check: new entry in array thread entry %s "
               "on change array index [%d] , the new entry has bit index [%d] ,  with cmd %s "
               "num of entries in array [%d] ", __cl_health_thread_status_arr[arr_index].name,
               arr_index, __cl_health_thread_status_arr[arr_index].bit_index,
               (__cl_health_thread_status_arr[arr_index].cmd) ? "ADD" : "DELETE",
               __cl_dbg_thread_status_db_entries_num);
    }
    /* Internal error if we got here its mean we have 2 entries on the same bit*/
    else {
        sx_log(SX_LOG_ERROR, "COMP_LIB", "Health check: Internal error SDK a sing 2 "
               "entries with the same bit and because of that "
               "thread bit_index =%u is not part of the array DB ", thread_status_info->bit_index);
        status = CL_CANCELED;
        goto out;
    }

out:
    pthread_mutex_unlock(&__health_threads_status_lock);
    return status;
}
cl_status_t cl_health_check_thread_db_get_and_remove(INOUT cl_thread_status_changed_t* thread_status_info,
                                                     OUT int                         * array_output_size)
{
    cl_status_t status = CL_SUCCESS;
    uint32_t    index = 0;

    pthread_mutex_lock(&__health_threads_status_lock);

    /* Check if if not inited */
    if (CL_THREAD_UPDATE_STATUS_DB_NOT_INITIALIZED == __cl_thread_status_db_initialized) {
        sx_log(SX_LOG_ERROR, "COMP_LIB",
               "Health check: thread status DB not initialized when trying to remove thread");
        status = CL_INVALID_OPERATION;
        goto out;
    }

    CL_ASSERT(NULL != thread_status_info);
    memset(thread_status_info, 0, sizeof(cl_thread_status_changed_t) * __cl_dbg_thread_status_db_entries_num);

    while (index < CL_DBG_NUM_OF_THREADS_BITS) {
        if (__cl_health_thread_status_arr[index].thread_id != 0) {
            memcpy(&thread_status_info[index], &__cl_health_thread_status_arr[index],
                   sizeof(cl_thread_status_changed_t));
            /* Clear the entry in Array*/
            memset(&__cl_health_thread_status_arr[index], 0, sizeof(cl_thread_status_changed_t));
            __cl_dbg_thread_status_db_entries_num--;
            index++;
        } else {
            if (__cl_dbg_thread_status_db_entries_num != 0) {
                sx_log(SX_LOG_ERROR, "COMP_LIB",
                       "Health check: After copy all threads the counter of amount of entries in array should be 0"
                       "but __cl_dbg_thread_status_db_entries_num = [%d]"
                       "and last entry with index [%d] contain thread name [%s] checked is entry  with "
                       "thread_id [%lu] and cmd [%d] ",
                       __cl_dbg_thread_status_db_entries_num, index, __cl_health_thread_status_arr[index].name,
                       __cl_health_thread_status_arr[index].thread_id,
                       __cl_health_thread_status_arr[index].cmd);
            }
            break;
        }
    }


out:
    *array_output_size = index;
    pthread_mutex_unlock(&__health_threads_status_lock);
    return status;
}


/******************************************
* Pool DB API
******************************************/
/**
 * Set the state of Pool DB to Force Deinit
 */
boolean_t cl_dbg_pool_db_disable(void)
{
    switch (g_dbg_pool_db_inited) {
    case CL_DBG_POOL_DB_NOT_INITED:
        /* spinlock is not init-ed at this moment */
        g_dbg_pool_db_inited = CL_DBG_POOL_DB_FAIL_TO_INIT;
        return FALSE;

    case CL_DBG_POOL_DB_INITED:
        cl_spinlock_acquire(&g_dbg_pool_db_spinlock);
        g_dbg_pool_db_inited = CL_DBG_POOL_DB_FORCE_DEINIT;
        cl_spinlock_release(&g_dbg_pool_db_spinlock);
        return TRUE;

    case CL_DBG_POOL_DB_FAIL_TO_INIT:
        return FALSE;

    case CL_DBG_POOL_DB_FORCE_DEINIT:
        return TRUE;

    default:
        return FALSE;
    }
}
/**
 * Initializes Pool DB infrastructure
 */
static cl_status_t cl_dbg_pool_db_init(void)
{
    cl_status_t status = CL_SUCCESS;

    if (CL_DBG_POOL_DB_NOT_INITED != g_dbg_pool_db_inited) {
        return CL_DUPLICATE;
    }
    g_dbg_pool_db_inited = CL_DBG_POOL_DB_INITED;

    memset(&g_dbg_pool_db, 0, sizeof(g_dbg_pool_db));
    memset(&g_pool_db_entry_pool, 0, sizeof(g_pool_db_entry_pool));
    memset(&g_pool_db_bucket_pool, 0, sizeof(g_pool_db_bucket_pool));
    memset(&g_dbg_pool_db_spinlock, 0, sizeof(g_dbg_pool_db_spinlock));

    status = cl_spinlock_init(&g_dbg_pool_db_spinlock);
    CL_ASSERT(CL_SUCCESS == status);

    cl_fmap_init(&g_dbg_pool_db, __cl_dbg_pool_db_key_fmap_cmp);
    status = cl_qpool_init(&g_pool_db_entry_pool,
                           CL_DBG_POOL_DB_MIN_SIZE,
                           CL_DBG_POOL_DB_MAX_SIZE,
                           CL_DBG_POOL_DB_GROW_SIZE,
                           sizeof(cl_dbg_pool_db_entry_t),
                           NULL,
                           NULL,
                           NULL);
    if (CL_SUCCESS != status) {
        g_dbg_pool_db_inited = CL_DBG_POOL_DB_FAIL_TO_INIT;
        cl_spinlock_destroy(&g_dbg_pool_db_spinlock);
        /* Ignore not inited pool */
        return CL_ERROR;
    }
    status = cl_qpool_init(&g_pool_db_bucket_pool, CL_DBG_POOL_DB_BUCKET_MIN_SIZE, CL_DBG_POOL_DB_BUCKET_MAX_SIZE,
                           CL_DBG_POOL_DB_BUCKET_GROW_SIZE, sizeof(cl_dbg_pool_db_bucket_t), NULL, NULL, NULL);
    if (CL_SUCCESS != status) {
        g_dbg_pool_db_inited = CL_DBG_POOL_DB_FAIL_TO_INIT;
        cl_qpool_destroy(&g_pool_db_entry_pool);
        cl_spinlock_destroy(&g_dbg_pool_db_spinlock);
        /* Ignore not inited pool */
        return CL_ERROR;
    }
    return CL_SUCCESS;
}

/**
 * Destructs Pool DB infrastructure
 */
static void cl_dbg_pool_db_destroy(boolean_t forced)
{
    /* Spinlock should be already acquired */
    /* cl_spinlock_acquire(&g_dbg_pool_db_spinlock); */
    if (forced) {
        cl_dbg_pool_db_clear_db();
    }
    cl_qpool_destroy(&g_pool_db_entry_pool);
    cl_qpool_destroy(&g_pool_db_bucket_pool);
    if (!forced) {
        g_dbg_pool_db_inited = CL_DBG_POOL_DB_NOT_INITED;
    }
    cl_spinlock_release(&g_dbg_pool_db_spinlock);
    cl_spinlock_destroy(&g_dbg_pool_db_spinlock);
}

/**
 *  Clears the DB and call all destructors.
 */
void cl_dbg_pool_db_force_deinit(void)
{
    if (cl_dbg_pool_db_disable()) {
        cl_spinlock_acquire(&g_dbg_pool_db_spinlock);
        cl_dbg_pool_db_destroy(TRUE);
    }
}

/**
 * Delete and deallocates all buckets and their entries from Pool DB
 */
static void cl_dbg_pool_db_clear_db(void)
{
    cl_fmap_item_t          *fmap_item_p = NULL;
    const cl_fmap_item_t    *fmap_end_p = NULL;
    cl_dbg_pool_db_bucket_t *fmap_entry_p = NULL;

    fmap_item_p = cl_fmap_head(&g_dbg_pool_db);
    fmap_end_p = cl_fmap_end(&g_dbg_pool_db);
    while (fmap_item_p != fmap_end_p) {
        fmap_entry_p = PARENT_STRUCT(fmap_item_p, cl_dbg_pool_db_bucket_t, map_item);
        fmap_item_p = cl_fmap_next(fmap_item_p);

        cl_dbg_pool_db_clear_bucket(fmap_entry_p);
        cl_fmap_remove_item(&g_dbg_pool_db, &fmap_entry_p->map_item);
        cl_qpool_put(&g_pool_db_bucket_pool, &fmap_entry_p->pool_item);
    }
}

/**
 * Delete and deallocates all entries from Pool DB bucket
 */
static void cl_dbg_pool_db_clear_bucket(cl_dbg_pool_db_bucket_t *bucket_p)
{
    cl_list_item_t         *list_item_p = NULL;
    const cl_list_item_t   *list_end_p = NULL;
    cl_dbg_pool_db_entry_t *list_entry_p = NULL;

    list_item_p = cl_qlist_head(&bucket_p->list);
    list_end_p = cl_qlist_end(&bucket_p->list);
    while (list_item_p != list_end_p) {
        list_entry_p = PARENT_STRUCT(list_item_p, cl_dbg_pool_db_entry_t, list_item);
        list_item_p = cl_qlist_next(list_item_p);

        cl_qlist_remove_item(&bucket_p->list, &list_entry_p->list_item);
        cl_qpool_put(&g_pool_db_entry_pool, &list_entry_p->pool_item);
    }
}

/**
 * Insert a pool entry into Pool DB
 */
cl_status_t cl_dbg_pool_db_insert(IN cl_qcpool_t *pool_p, IN const char *p_name, IN const uint32_t file_line)
{
    cl_status_t              status = CL_SUCCESS;
    cl_pool_item_t          *pool_item_p = NULL;
    cl_dbg_pool_db_entry_t  *new_entry_p = NULL;
    cl_dbg_pool_db_bucket_t *bucket_p = NULL;
    cl_fmap_item_t          *map_item_p = NULL;

    /* Init Pool DB if not inited */
    if (CL_DBG_POOL_DB_NOT_INITED == g_dbg_pool_db_inited) {
        status = cl_dbg_pool_db_init();
        if ((CL_SUCCESS != status) && (CL_DUPLICATE != status)) {
            return CL_UNAVAILABLE;
        }
    }
    if (CL_DBG_POOL_DB_INITED != g_dbg_pool_db_inited) {
        return CL_UNAVAILABLE;
    }

    CL_ASSERT(NULL != p_name);

    cl_spinlock_acquire(&g_dbg_pool_db_spinlock);

    /* Check if Pool DB is still available */
    if (CL_DBG_POOL_DB_INITED != g_dbg_pool_db_inited) {
        status = CL_UNAVAILABLE;
        goto out;
    }

    /* Request memory */
    pool_item_p = cl_qpool_get(&g_pool_db_entry_pool);
    if (!pool_item_p) {
        /* Do not fail if we do not have memory for Pool DB entries */
        status = CL_INSUFFICIENT_MEMORY;
        goto out;
    }

    new_entry_p = PARENT_STRUCT(pool_item_p, cl_dbg_pool_db_entry_t, pool_item);
    new_entry_p->pool_p = pool_p;

    /* Fill pool entry with extra data */
    new_entry_p->key.f_line = file_line;
    new_entry_p->key.p_name = p_name;

    /* Store a pointer to this debug entry in the pool itself */
    pool_p->dbg_context = (void*)new_entry_p;

    /* Find bucket */
    map_item_p = cl_fmap_match(&g_dbg_pool_db, (void *)&new_entry_p->key, __cl_dbg_pool_db_key_fmap_cmp);
    if (map_item_p == cl_fmap_end(&g_dbg_pool_db)) {
        /* Create bucket */
        pool_item_p = cl_qpool_get(&g_pool_db_bucket_pool);
        if (!pool_item_p) {
            cl_qpool_put(&g_pool_db_entry_pool, &new_entry_p->pool_item);
            /* Do not fail if we do not have memory for Pool DB entries */
            status = CL_INSUFFICIENT_MEMORY;
            goto out;
        }

        bucket_p = PARENT_STRUCT(pool_item_p, cl_dbg_pool_db_bucket_t, pool_item);
        cl_qlist_init(&bucket_p->list);
        bucket_p->key = new_entry_p->key;
        cl_fmap_insert(&g_dbg_pool_db, (void *)&bucket_p->key, &bucket_p->map_item);
    } else {
        bucket_p = PARENT_STRUCT(map_item_p, cl_dbg_pool_db_bucket_t, map_item);
    }

    /* Insert entry into bucket */
    cl_qlist_insert_tail(&bucket_p->list, &new_entry_p->list_item);
    ++g_dbg_pool_db_reg_num;

out:
    cl_spinlock_release(&g_dbg_pool_db_spinlock);
    return status;
}

/**
 * Remove the pool entry from  Pool DB
 */
cl_status_t cl_dbg_pool_db_remove(IN cl_qcpool_t * const pool_p)
{
    cl_status_t              status = CL_SUCCESS;
    cl_fmap_item_t          *map_item_p = NULL;
    cl_dbg_pool_db_bucket_t *bucket_p = NULL;
    cl_dbg_pool_db_entry_t  *db_obj_p = NULL;
    uint8_t                  removed_item_b = FALSE;

    /* Check if Pool DB is inited */
    if (CL_DBG_POOL_DB_INITED != g_dbg_pool_db_inited) {
        return CL_UNAVAILABLE;
    }

    cl_spinlock_acquire(&g_dbg_pool_db_spinlock);

    /* Check if Pool DB is still available */
    if (CL_DBG_POOL_DB_INITED != g_dbg_pool_db_inited) {
        cl_spinlock_release(&g_dbg_pool_db_spinlock);
        return CL_UNAVAILABLE;
    }
    /* Get a pointer to the db object which we previously stored in the debug context */
    db_obj_p = (cl_dbg_pool_db_entry_t*)pool_p->dbg_context;

    /* Find the relevant bucket in DB */
    map_item_p = cl_fmap_get(&g_dbg_pool_db, &db_obj_p->key);
    if (map_item_p == cl_fmap_end(&g_dbg_pool_db)) {
        /* Do not fail if we do not have a record of the pool in the Pool DB */
        status = CL_NOT_FOUND;
        goto out;
    }

    bucket_p = PARENT_STRUCT(map_item_p, cl_dbg_pool_db_bucket_t, map_item);
    /* Remove this entry from the bucket list */
    cl_qlist_remove_item(&bucket_p->list, &db_obj_p->list_item);

    cl_qpool_put(&g_pool_db_entry_pool, &db_obj_p->pool_item);
    --g_dbg_pool_db_reg_num;
    removed_item_b = TRUE;

    if (0 == cl_qlist_count(&bucket_p->list)) {
        cl_fmap_remove_item(&g_dbg_pool_db, map_item_p);
        cl_qpool_put(&g_pool_db_bucket_pool, &bucket_p->pool_item);
    }

    pool_p->dbg_context = NULL;

out:
    if (removed_item_b && (0 == g_dbg_pool_db_reg_num)) {
        /* requires locked spinlock,
         *  it will unlock and destroy the spinlock, once
         *  DB is destroyed. */
        cl_dbg_pool_db_destroy(FALSE);
    } else {
        cl_spinlock_release(&g_dbg_pool_db_spinlock);
    }
    /* coverity[missing_unlock] */
    return status;
}

/**
 *  Apply the the pfn_func to every bucket in the Pool DB.
 */
void cl_dbg_pool_db_bucket_apply(IN cl_pfn_fmap_apply_t pfn_func, IN const void *const context)
{
    cl_spinlock_acquire(&g_dbg_pool_db_spinlock);
    cl_fmap_apply_func(&g_dbg_pool_db, pfn_func, context);
    cl_spinlock_release(&g_dbg_pool_db_spinlock);
}

/******************************************
* Background processes control API
******************************************/

void cl_dbg_bp_ctl_db_init(void)
{
    cl_spinlock_init(&cl_dbg_bp_ctl_spinlock_g);
    CL_QPOOL_INIT(&cl_dbg_bp_ctl_db_pool_g, CL_DBG_BP_CTL_DB_MIN_SIZE, CL_DBG_BP_CTL_DB_MAX_SIZE,
                  CL_DBG_BP_CTL_DB_GROW_SIZE, sizeof(cl_dbg_bp_ctl_db_entry_t),
                  NULL, NULL, NULL);
    cl_qlist_init(&cl_dbg_bp_ctl_db_g);
    cl_dbg_bp_ctl_is_inited_g = TRUE;
}

cl_status_t cl_dbg_bp_ctl_db_deinit(void)
{
    cl_dbg_bp_ctl_is_inited_g = FALSE;
    cl_list_item_t           *list_item_p = NULL;
    cl_dbg_bp_ctl_db_entry_t *entry_p = NULL;

    if (cl_qlist_count(&cl_dbg_bp_ctl_db_g)) {
        sx_log(SX_LOG_NOTICE, "COMP_LIB", "BP DB is not empty on deinit.\n");
        list_item_p = cl_qlist_head(&cl_dbg_bp_ctl_db_g);

        while (list_item_p != cl_qlist_end(&cl_dbg_bp_ctl_db_g)) {
            entry_p = PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);
            list_item_p = cl_qlist_next(list_item_p);
            cl_qlist_remove_item(&cl_dbg_bp_ctl_db_g, &entry_p->list_item);
            cl_qpool_put(&cl_dbg_bp_ctl_db_pool_g, &entry_p->pool_item);
        }
    }

    CL_QPOOL_DESTROY(&cl_dbg_bp_ctl_db_pool_g);
    cl_spinlock_destroy(&cl_dbg_bp_ctl_spinlock_g);
    return CL_SUCCESS;
}

cl_status_t cl_dbg_bp_ctl_thread_register(cl_thread_t* thread_p)
{
    /* Id generator protected by cl_dbg_bp_ctl_spinlock_g */
    static uint64_t            id_generator = 0u;
    cl_status_t                status = CL_SUCCESS;
    cl_dbg_bp_ctl_db_entry_t  *entry_p = NULL;
    cl_pool_item_t            *pool_item_p = NULL;
    pthread_t                  self_thread_id = pthread_self();
    cl_thread_status_changed_t thread_status_info;
    uint64_t                   last_sent_bm = 0;
    uint64_t                   new_bm = 0;

    if (!cl_dbg_bp_ctl_is_inited_g) {
        /* Expected behavior */
        status = CL_SUCCESS;
        goto out;
    }

    memset(&thread_status_info, 0, sizeof(cl_thread_status_changed_t));

    /* Request memory */
    cl_dbg_bp_ctl_db_lock();
    pool_item_p = cl_qpool_get(&cl_dbg_bp_ctl_db_pool_g);
    cl_dbg_bp_ctl_db_unlock();
    if (!pool_item_p) {
        /* Do not fail if we do not have memory for Pool DB entries */
        status = CL_SUCCESS;
        goto out;
    }
    entry_p = PARENT_STRUCT(pool_item_p, cl_dbg_bp_ctl_db_entry_t, pool_item);

    /* Fill the entry with data*/
    status = cl_event_init(&entry_p->event, FALSE);
    if (CL_SUCCESS != status) {
        cl_dbg_bp_ctl_db_lock();
        cl_qpool_put(&cl_dbg_bp_ctl_db_pool_g, pool_item_p);
        cl_dbg_bp_ctl_db_unlock();
        goto out;
    }
    entry_p->thread_id = self_thread_id;
    strncpy(entry_p->thread_name, thread_p->name, CL_THREAD_THREAD_NAME_SIZE);


    if (IS_VALID_FOR_MONITOR(thread_p)) {
        status = cl_fd_init(&entry_p->health_check_fd);
        if (status != 0) {   /* cl_fd_init/pipe returns a "0" for success */
            goto out;
        }

        entry_p->max_expected_thread_duration_sec = thread_p->max_allowed_time_sec;
        entry_p->monitor_last_timestamp_sec = cl_get_time_stamp() / 1000000;
        /*This logic use for debug - temporary  */
        last_sent_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_LAST_SENT_THREADS_BM, TRUE, 0);
        new_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_NEW_THREADS_BM, TRUE, 0);
        sx_log(SX_LOG_NOTICE, "COMP_LIB", "NEW SDK thread [%s] monitor BEFORE find new bit last_bm = [0x%lx]"
               "new_bm = [0x%lx] \n", entry_p->thread_name, last_sent_bm, new_bm);
        /* end of debug logic */
        thread_status_info.bit_index = cl_dbg_find_free_thread_bit();
        entry_p->thread_bit_index = thread_status_info.bit_index;
        entry_p->is_valid_for_monitor = TRUE;
        strncpy(thread_status_info.name, thread_p->name, CL_THREAD_THREAD_NAME_SIZE);
        thread_status_info.thread_id = self_thread_id;
        thread_status_info.cmd = ADD_THREAD;
        thread_status_info.max_expected_thread_duration_sec = thread_p->max_allowed_time_sec;
        /*This logic use for debug - temporary  */
        last_sent_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_LAST_SENT_THREADS_BM, TRUE, 0);
        new_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_NEW_THREADS_BM, TRUE, 0);
        sx_log(SX_LOG_NOTICE,
               "COMP_LIB",
               "NEW SDK thread [%s] monitor AFTER find new bit [%d] cmd [%d] last_bm = [0x%lx]"
               "new_bm = [0x%lx] \n",
               entry_p->thread_name,
               thread_status_info.bit_index,
               thread_status_info.cmd,
               last_sent_bm,
               new_bm);
        /* end of debug logic */
        cl_health_check_thread_status_changed_db_insert(&thread_status_info);
    } else {
        entry_p->is_valid_for_monitor = FALSE;
        entry_p->health_check_fd = -1; /* -1 is invalid file-descriptor, this way we know the thread is not monitored*/
    }
    cl_dbg_bp_ctl_db_lock();
    entry_p->db_entry_id = ++id_generator;
    /* Insert entry to the DB */
    cl_qlist_insert_tail(&cl_dbg_bp_ctl_db_g, &entry_p->list_item);
    cl_dbg_bp_ctl_db_unlock();

out:
    if ((CL_SUCCESS != status) && (IS_VALID_FOR_MONITOR(thread_p))) {
        sx_log(SX_LOG_ERROR, "COMP_LIB", "thread [%s] is not monitored \n", entry_p->thread_name);
    }
    return status;
}

cl_status_t cl_dbg_bp_ctl_thread_unregister(void)
{
    cl_status_t                status = CL_SUCCESS;
    cl_dbg_bp_ctl_db_entry_t  *entry_p = NULL;
    pthread_t                  self_thread_id = pthread_self();
    cl_thread_status_changed_t thread_status_info;
    uint64_t                   last_sent_bm = 0;
    uint64_t                   new_bm = 0;

    if (!cl_dbg_bp_ctl_is_inited_g) {
        /* Expected behavior */
        status = CL_SUCCESS;
        goto out;
    }
    memset(&thread_status_info, 0, sizeof(cl_thread_status_changed_t));

    /* Remove entry from DB */
    cl_dbg_bp_ctl_db_lock();
    entry_p = cl_dbg_bp_ctl_db_entry_by_tid_get(self_thread_id);
    if (NULL == entry_p) {
        sx_log(SX_LOG_DEBUG, "COMP_LIB", "BP DB is not inited. Thread[%#010lx] is not unregistered\n",
               (long unsigned int)self_thread_id);
        status = CL_NOT_FOUND;
        cl_dbg_bp_ctl_db_unlock();
        goto out;
    }
    if (entry_p->is_valid_for_monitor) {
        /*This logic use for debug - temporary  */
        last_sent_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_LAST_SENT_THREADS_BM, TRUE, 0);
        new_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_NEW_THREADS_BM, TRUE, 0);
        sx_log(SX_LOG_NOTICE, "COMP_LIB", "DELETE SDK thread [%s] monitor BEFORE find new bit last_bm = [0x%lx]"
               "new_bm = [0x%lx] \n", entry_p->thread_name, last_sent_bm, new_bm);
        /* end of debug logic */
        thread_status_info.bit_index = entry_p->thread_bit_index;
        strcpy(thread_status_info.name, entry_p->thread_name);
        thread_status_info.thread_id = self_thread_id;
        thread_status_info.cmd = DELETE_THREAD;
        cl_health_check_thread_status_changed_db_insert(&thread_status_info);
        cl_dbg_clear_sdk_threads_bm(CL_DBG_LAST_SENT_THREADS_BM, FALSE, entry_p->thread_bit_index);
        /* coverity[callee_ptr_arith] */
        if (cl_test_bit64(&__cl_dbg_cmd_cli_not_running_threads_bm, entry_p->thread_bit_index)) {
            cl_dbg_clear_sdk_threads_bm(CL_DBG_CMD_CLI_NOT_RUNNING_THREADS_BM, FALSE, entry_p->thread_bit_index);
            sx_log(SX_LOG_NOTICE,
                   "COMP_LIB",
                   "HEALTH CHECK DEBUG CLI - thread [%s] won't be monitored because the thread isn't exist (unregistered).\n",
                   entry_p->thread_name);
        }
        /*This logic use for debug - temporary  */
        last_sent_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_LAST_SENT_THREADS_BM, TRUE, 0);
        new_bm = cl_dbg_get_sdk_threads_bm(CL_DBG_NEW_THREADS_BM, TRUE, 0);
        sx_log(SX_LOG_NOTICE, "COMP_LIB", "DELETE SDK thread [%s] monitor AFTER clear  bit %d last_bm = [0x%lx]"
               "new_bm = [0x%lx] \n", entry_p->thread_name, entry_p->thread_bit_index, last_sent_bm, new_bm);
        /* end of debug logic */
        close(entry_p->health_check_fd);
    }

    cl_qlist_remove_item(&cl_dbg_bp_ctl_db_g, &entry_p->list_item);
    cl_dbg_bp_ctl_db_unlock();

    /* Deinit entry members and free memory */
    cl_event_destroy(&entry_p->event);
    cl_dbg_bp_ctl_db_lock();
    cl_qpool_put(&cl_dbg_bp_ctl_db_pool_g, &entry_p->pool_item);
    cl_dbg_bp_ctl_db_unlock();

out:
    return status;
}

cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_tid_get(pthread_t thread_id)
{
    cl_list_item_t *list_item_p = NULL;

    list_item_p = cl_qlist_find_from_tail(&cl_dbg_bp_ctl_db_g, __cl_dbg_bp_ctl_db_entry_tid_list_cmp,
                                          &thread_id);
    if (list_item_p == cl_qlist_end(&cl_dbg_bp_ctl_db_g)) {
        return NULL;
    }
    return PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);
}

cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_thread_bit_index_get(uint32_t thread_bit_idx)
{
    cl_list_item_t *list_item_p = NULL;

    list_item_p = cl_qlist_find_from_tail(&cl_dbg_bp_ctl_db_g, __cl_dbg_bp_ctl_db_entry_thread_bit_index_list_cmp,
                                          &thread_bit_idx);
    if (list_item_p == cl_qlist_end(&cl_dbg_bp_ctl_db_g)) {
        return NULL;
    }
    return PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);
}

cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_id_get(uint64_t db_entry_id)
{
    cl_list_item_t *list_item_p = NULL;

    list_item_p = cl_qlist_find_from_tail(&cl_dbg_bp_ctl_db_g, __cl_dbg_bp_ctl_db_entry_id_list_cmp,
                                          &db_entry_id);
    if (list_item_p == cl_qlist_end(&cl_dbg_bp_ctl_db_g)) {
        return NULL;
    }
    return PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);
}

cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_name_get(const char *thread_name)
{
    cl_list_item_t *list_item_p = NULL;

    list_item_p = cl_qlist_find_from_tail(&cl_dbg_bp_ctl_db_g, __cl_dbg_bp_ctl_db_entry_name_list_cmp,
                                          thread_name);
    if (list_item_p == cl_qlist_end(&cl_dbg_bp_ctl_db_g)) {
        return NULL;
    }
    return PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);
}

void cl_dbg_bp_ctl_thread_sync(cl_dbg_bp_ctl_db_entry_t **entry_pp)
{
    uint64_t                   max_thread_duration_default = 0;
    cl_dbg_bp_ctl_db_entry_t  *entry_p = NULL;
    cl_thread_status_changed_t thread_status_info;

    memset(&thread_status_info, 0, sizeof(cl_thread_status_changed_t));

    if (!cl_dbg_bp_ctl_is_inited_g) {
        return;
    }
    entry_p = __cl_dbg_bp_ctl_db_entry_cache(entry_pp);
    if (NULL == entry_p) {
        /** Invalid flow. Silently return because of performance concerns
         * The bad flow is signaled through register/unregister functions */
        return;
    }
    if (entry_p->is_muted) {
        max_thread_duration_default = entry_p->max_expected_thread_duration_sec;
        /* (max_thread_duration_default is zero mean that this thread is not monitored) */
        if (max_thread_duration_default) {
            thread_status_info.bit_index = entry_p->thread_bit_index;
            strncpy(thread_status_info.name, entry_p->thread_name, CL_THREAD_THREAD_NAME_SIZE - 1);
            thread_status_info.name[CL_THREAD_THREAD_NAME_SIZE - 1] = '\0';
            thread_status_info.thread_id = entry_p->thread_id;
            thread_status_info.cmd = ADD_THREAD;
            thread_status_info.max_expected_thread_duration_sec = -1;
            cl_health_check_thread_status_changed_db_insert(&thread_status_info);
        }
        cl_event_wait_on(&entry_p->event, EVENT_NO_TIMEOUT, TRUE);
        /* (max_thread_duration_default is zero mean that this thread is not monitored) */
        if (max_thread_duration_default) {
            thread_status_info.max_expected_thread_duration_sec = max_thread_duration_default;
            cl_health_check_thread_status_changed_db_insert(&thread_status_info);
        }
    }
}

void cl_dbg_bp_ctl_db_lock(void)
{
    cl_spinlock_acquire(&cl_dbg_bp_ctl_spinlock_g);
}

void cl_dbg_bp_ctl_db_unlock(void)
{
    cl_spinlock_release(&cl_dbg_bp_ctl_spinlock_g);
}

void cl_dbg_bp_ctl_thread_lock_set(cl_dbg_bp_ctl_db_entry_t *entry_p, boolean_t lock)
{
    if ((entry_p->is_muted == lock) || !entry_p->is_mutable) {
        return;
    }
    entry_p->is_muted = lock;
    if (!lock) {
        cl_event_signal(&entry_p->event);
    }
}

void cl_dbg_bp_ctl_thread_mutable_set(cl_dbg_bp_ctl_db_entry_t **entry_pp, boolean_t is_mutable)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = NULL;

    if (!cl_dbg_bp_ctl_is_inited_g) {
        return;
    }
    entry_p = __cl_dbg_bp_ctl_db_entry_cache(entry_pp);
    if (NULL == entry_p) {
        sx_log(SX_LOG_DEBUG, "COMP_LIB", "BP DB can not set thread to mutable state\n");
        return;
    }
    entry_p->is_mutable = is_mutable;
}

void cl_dbg_bp_ctl_thread_period_register(cl_dbg_bp_ctl_db_entry_t **entry_pp,
                                          uint32_t                  *default_interval_p,
                                          uint32_t                   interval_div)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = NULL;

    if (!cl_dbg_bp_ctl_is_inited_g) {
        return;
    }
    entry_p = __cl_dbg_bp_ctl_db_entry_cache(entry_pp);
    if (NULL == entry_p) {
        sx_log(SX_LOG_DEBUG, "COMP_LIB", "BP DB can not register period for thread\n");
        return;
    }
    entry_p->default_interval_p = default_interval_p;
    entry_p->interval_div = interval_div;
    entry_p->time_based = TRUE;
}

void cl_dbg_bp_ctl_thread_period_set(cl_dbg_bp_ctl_db_entry_t *entry_p, uint32_t period)
{
    if (entry_p->time_based) {
        entry_p->interval = period / entry_p->interval_div;
        entry_p->interval_mod = period % entry_p->interval_div;
        entry_p->interval_is_set = TRUE;
    }
}

void cl_dbg_bp_ctl_thread_period_reset(cl_dbg_bp_ctl_db_entry_t *entry_p)
{
    if (entry_p->time_based) {
        entry_p->interval_is_set = FALSE;
    }
}

uint32_t cl_dbg_bp_ctl_thread_period_get(cl_dbg_bp_ctl_db_entry_t *entry_p, uint32_t default_period)
{
    if (!cl_dbg_bp_ctl_is_inited_g || !entry_p) {
        return default_period;
    }
    if (entry_p->interval_is_set) {
        return entry_p->interval;
    } else {
        return *entry_p->default_interval_p;
    }
}

uint32_t cl_dbg_bp_ctl_thread_period_us_get(cl_dbg_bp_ctl_db_entry_t *entry_p)
{
    if (entry_p->interval_is_set) {
        return entry_p->interval * entry_p->interval_div + entry_p->interval_mod;
    } else {
        return *entry_p->default_interval_p * entry_p->interval_div;
    }
}

uint32_t cl_dbg_bp_ctl_thread_period_mod_get(cl_dbg_bp_ctl_db_entry_t *entry_p)
{
    if (!cl_dbg_bp_ctl_is_inited_g || !entry_p || !entry_p->interval_is_set) {
        return 0u;
    }
    return entry_p->interval_mod;
}

void cl_dbg_bp_ctl_db_apply(cl_pfn_qlist_apply_t pfn_func, const void *const context)
{
    cl_qlist_apply_func(&cl_dbg_bp_ctl_db_g, pfn_func, context);
}

void cl_dbg_bp_hc_thread_update(cl_dbg_bp_ctl_db_entry_t *entry_p,
                                int                       hc_fd,
                                fd_set                  * read_fds,
                                boolean_t                 its_a_thread_failure)
{
    cl_status_t status = CL_SUCCESS;

    if ((entry_p != NULL) && entry_p->is_valid_for_monitor) {
        /* By entering to infinite loop we will let the HC kernel mechanism
         * know that this thread is on failure state */
        if (its_a_thread_failure) {
            sx_log(SX_LOG_ERROR, "COMP_LIB", "Thread '%s' with thread id =%lu failed "
                   "and will be stuck on infinite loop \n",
                   entry_p->thread_name, entry_p->thread_id);
            while (1) {
                sleep(1);
            }
        }
        if (FD_ISSET(hc_fd, read_fds)) {
            cl_dbg_set_sdk_threads_bm(CL_DBG_RUNNING_THREADS_BM, FALSE, entry_p->thread_bit_index);
            entry_p->monitor_last_timestamp_sec = cl_get_time_stamp() / 1000000;
            status = cl_fd_read(hc_fd);
            if (status != CL_SUCCESS) {
                sx_log(SX_LOG_ERROR, "COMP_LIB", "failed to read from hc FD %s\n", CL_STATUS_MSG(status));
                while (1) {
                    sleep(1);
                }
            }
        }
    }
}

/******************************************
* Wrappers
******************************************/
cl_status_t cl_qcpool_init_wrap(IN cl_qcpool_t * const                  p_pool,
                                IN const size_t                         min_size,
                                IN const size_t                         max_size,
                                IN const size_t                         grow_size,
                                IN const size_t * const                 component_sizes,
                                IN const uint32_t                       num_components,
                                IN cl_pfn_qcpool_init_t pfn_initializer OPTIONAL,
                                IN cl_pfn_qcpool_dtor_t pfn_destructor  OPTIONAL,
                                IN const void *const                    context,
                                IN const char                          *func_name,
                                IN const uint32_t                       file_line)
{
    cl_status_t status = cl_qcpool_init(p_pool, min_size, max_size, grow_size, component_sizes, num_components,
                                        pfn_initializer, pfn_destructor, context);

    if (CL_SUCCESS == status) {
        cl_dbg_pool_db_insert(p_pool, func_name, file_line);
    }
    return status;
}

cl_status_t cl_qpool_init_wrap(IN cl_qpool_t * const                  p_pool,
                               IN const size_t                        min_size,
                               IN const size_t                        max_size,
                               IN const size_t                        grow_size,
                               IN const size_t                        object_size,
                               IN cl_pfn_qpool_init_t pfn_initializer OPTIONAL,
                               IN cl_pfn_qpool_dtor_t pfn_destructor  OPTIONAL,
                               IN const void *const                   context,
                               IN const char                         *func_name,
                               IN const uint32_t                      file_line)
{
    cl_status_t status = cl_qpool_init(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,
                                       pfn_destructor, context);

    if (CL_SUCCESS == status) {
        cl_dbg_pool_db_insert(&p_pool->qcpool, func_name, file_line);
    }
    return status;
}

cl_status_t cl_cpool_init_wrap(IN cl_cpool_t * const                  p_pool,
                               IN const size_t                        min_size,
                               IN const size_t                        max_size,
                               IN const size_t                        grow_size,
                               IN size_t * const                      component_sizes,
                               IN const uint32_t                      num_components,
                               IN cl_pfn_cpool_init_t pfn_initializer OPTIONAL,
                               IN cl_pfn_cpool_dtor_t pfn_destructor  OPTIONAL,
                               IN const void *const                   context,
                               IN const char                         *func_name,
                               IN const uint32_t                      file_line)
{
    cl_status_t status = cl_cpool_init(p_pool, min_size, max_size, grow_size, component_sizes, num_components,
                                       pfn_initializer, pfn_destructor, context);

    if (CL_SUCCESS == status) {
        cl_dbg_pool_db_insert(&p_pool->qcpool, func_name, file_line);
    }
    return status;
}

cl_status_t cl_pool_init_wrap(IN cl_pool_t * const                  p_pool,
                              IN const size_t                       min_size,
                              IN const size_t                       max_size,
                              IN const size_t                       grow_size,
                              IN const size_t                       object_size,
                              IN cl_pfn_pool_init_t pfn_initializer OPTIONAL,
                              IN cl_pfn_pool_dtor_t pfn_destructor  OPTIONAL,
                              IN const void *const                  context,
                              IN const char                        *func_name,
                              IN const uint32_t                     file_line)
{
    cl_status_t status = cl_pool_init(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,
                                      pfn_destructor, context);

    if (CL_SUCCESS == status) {
        cl_dbg_pool_db_insert(&p_pool->qcpool, func_name, file_line);
    }
    return status;
}

void cl_qcpool_destroy_wrap(IN cl_qcpool_t * const p_pool)
{
    cl_dbg_pool_db_remove(p_pool);
    cl_qcpool_destroy(p_pool);
}

void cl_qpool_destroy_wrap(IN cl_qpool_t * const p_pool)
{
    cl_dbg_pool_db_remove(&p_pool->qcpool);
    cl_qpool_destroy(p_pool);
}

void cl_cpool_destroy_wrap(IN cl_cpool_t * const p_pool)
{
    cl_dbg_pool_db_remove(&p_pool->qcpool);
    cl_cpool_destroy(p_pool);
}

void cl_pool_destroy_wrap(IN cl_pool_t * const p_pool)
{
    cl_dbg_pool_db_remove(&p_pool->qcpool);
    cl_pool_destroy(p_pool);
}

/******************************************
* Implementation
******************************************/

/**
 * Pool DB
 */

static int __cl_dbg_pool_db_key_fmap_cmp(IN const void *const p_key1, IN const void *const p_key2)
{
    const cl_dbg_pool_db_map_key_t *map_key_1_p = p_key1;
    const cl_dbg_pool_db_map_key_t *map_key_2_p = p_key2;
    int                             res = 0;
    int                             str_cmp = strcmp(map_key_1_p->p_name, map_key_2_p->p_name);

    if (0 != str_cmp) {
        res = str_cmp;
    } else if (map_key_1_p->f_line != map_key_2_p->f_line) {
        if (map_key_1_p->f_line > map_key_2_p->f_line) {
            res = 1;
        } else {
            res = -1;
        }
    } else {
        res = 0;
    }
    return res;
}

/**
 * Background processes control
 */

static cl_status_t __cl_dbg_bp_ctl_db_entry_tid_list_cmp(IN const cl_list_item_t * const list_item_p, IN void *context)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);

    if (pthread_equal(entry_p->thread_id, *(pthread_t *)context)) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}

static cl_status_t __cl_dbg_bp_ctl_db_entry_id_list_cmp(IN const cl_list_item_t * const list_item_p, IN void *context)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);

    if (entry_p->db_entry_id == *(uint64_t *)context) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}

static cl_status_t __cl_dbg_bp_ctl_db_entry_thread_bit_index_list_cmp(IN const cl_list_item_t * const list_item_p,
                                                                      IN void                        *context)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);

    if (entry_p->thread_bit_index == *(uint32_t *)context) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}


static cl_status_t __cl_dbg_bp_ctl_db_entry_name_list_cmp(IN const cl_list_item_t * const list_item_p,
                                                          IN void                        *context)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = PARENT_STRUCT(list_item_p, cl_dbg_bp_ctl_db_entry_t, list_item);

    if (0 == strcmp((const char *)entry_p->thread_name, (const char *)context)) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}

/* Caching the bp_ctl DB entry for this thread */
static cl_dbg_bp_ctl_db_entry_t * __cl_dbg_bp_ctl_db_entry_cache(cl_dbg_bp_ctl_db_entry_t **entry_pp)
{
    cl_dbg_bp_ctl_db_entry_t *entry_p = NULL;

    /* Caching the bp_ctl DB entry for this thread */
    cl_dbg_bp_ctl_db_lock();
    if (NULL == entry_pp) {
        entry_p = cl_dbg_bp_ctl_db_entry_by_tid_get(pthread_self());
    } else if (NULL == *entry_pp) {
        entry_p = cl_dbg_bp_ctl_db_entry_by_tid_get(pthread_self());
        *entry_pp = entry_p;
    } else {
        entry_p = *entry_pp;
    }
    cl_dbg_bp_ctl_db_unlock();

    return entry_p;
}
