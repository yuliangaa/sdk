/*
 * SPDX-FileCopyrightText: Copyright (c) 2004-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */

#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <complib/cl_thread.h>
#include <complib/cl_dbg.h>

/*
 * Internal function to run a new user mode thread.
 * This function is always run as a result of creation a new user mode thread.
 * Its main job is to synchronize the creation and running of the new thread.
 */
static void * __cl_thread_wrapper(void *arg)
{
    cl_thread_t *p_thread = (cl_thread_t*)arg;

    CL_ASSERT(p_thread);
    CL_ASSERT(p_thread->pfn_callback);

    cl_event_wait_on(&p_thread->init_completed, EVENT_NO_TIMEOUT, TRUE);

    cl_dbg_bp_ctl_thread_register(p_thread);
    p_thread->pfn_callback((void*)p_thread->context);
    cl_dbg_bp_ctl_thread_unregister();

    return (NULL);
}

void cl_thread_construct(IN cl_thread_t * const p_thread)
{
    CL_ASSERT(p_thread);

    p_thread->osd.state = CL_UNINITIALIZED;
}

cl_status_t cl_thread_init(IN cl_thread_t * const      p_thread,
                           IN cl_pfn_thread_callback_t pfn_callback,
                           IN const void *const        context,
                           IN const char *const        name,
                           IN const int                max_allowed_time)
{
    int         ret = 0;
    cl_status_t cl_err = CL_SUCCESS;

    CL_ASSERT(p_thread);

    cl_thread_construct(p_thread);

    /* Initialize the thread structure */
    p_thread->pfn_callback = pfn_callback;
    p_thread->context = context;
    p_thread->max_allowed_time_sec = max_allowed_time;

    if (!name) {
        /* Thread must get name  */
        return (CL_INVALID_PARAMETER);
    }
    strncpy(p_thread->name, name, sizeof(p_thread->name) - 1);

    cl_err = cl_event_init(&p_thread->init_completed, FALSE);
    if (cl_err != CL_SUCCESS) {
        goto out;
    }

    ret = pthread_create(&p_thread->osd.id, NULL,
                         __cl_thread_wrapper, (void*)p_thread);
    if (ret != 0) {
        cl_event_destroy(&p_thread->init_completed);

        /*
         * Insufficient resources to create another thread.
         * A system-imposed limit on the number of threads was encountered.
         */
        if (ret == EAGAIN) {
            cl_err = CL_INSUFFICIENT_RESOURCES;
            goto out;
        }

        /* Skipping EINVAL and EPERM as the attr is always NULL. */

        /* Something else happened. */
        cl_err = CL_ERROR;
        goto out;
    }

    p_thread->osd.state = CL_INITIALIZED;

    ret = pthread_setname_np(p_thread->osd.id, p_thread->name);
    if (ret != 0) {
        cl_thread_destroy(p_thread);

        /* The length of the string specified pointed to by name exceeds the allowed limit. */
        if (ret == ERANGE) {
            cl_err = CL_OVERRUN;
            goto out;
        }

        /*
         * Something else, maybe it fails to open /proc/self/task/tid/comm,
         * then the call may fail with one of the errors described in open().
         */
        cl_err = CL_NOT_FOUND;
        goto out;
    }

    cl_err = cl_event_signal(&p_thread->init_completed);
    if (cl_err != CL_SUCCESS) {
        cl_thread_destroy(p_thread);
        goto out;
    }

out:
    return cl_err;
}

void cl_thread_destroy(IN cl_thread_t * const p_thread)
{
    CL_ASSERT(p_thread);
    CL_ASSERT(cl_is_state_valid(p_thread->osd.state));

    if (p_thread->osd.state == CL_INITIALIZED) {
        pthread_join(p_thread->osd.id, NULL);
        cl_event_destroy(&p_thread->init_completed);
    }

    p_thread->osd.state = CL_UNINITIALIZED;
}

void cl_thread_detach_n_destroy(IN cl_thread_t * const p_thread)
{
    CL_ASSERT(p_thread);
    CL_ASSERT(cl_is_state_valid(p_thread->osd.state));

    if (p_thread->osd.state == CL_INITIALIZED) {
        pthread_detach(p_thread->osd.id);
    }

    p_thread->osd.state = CL_UNINITIALIZED;
}

void cl_thread_suspend(IN const uint32_t pause_ms)
{
    /* Convert to micro seconds */
    usleep(pause_ms * 1000);
}

void cl_thread_stall(IN const uint32_t pause_us)
{
    /*
     * Not quite a busy wait, but Linux is lacking in terms of high
     * resolution time stamp information in user mode.
     */
    usleep(pause_us);
}

int cl_proc_count(void)
{
    uint32_t ret;

    ret = get_nprocs();
    if (!ret) {
        return 1;   /* Workaround for PPC where get_nprocs() returns 0 */
    }
    return ret;
}

boolean_t cl_is_current_thread(IN const cl_thread_t * const p_thread)
{
    pthread_t current;

    CL_ASSERT(p_thread);
    CL_ASSERT(p_thread->osd.state == CL_INITIALIZED);

    current = pthread_self();
    return (pthread_equal(current, p_thread->osd.id));
}
