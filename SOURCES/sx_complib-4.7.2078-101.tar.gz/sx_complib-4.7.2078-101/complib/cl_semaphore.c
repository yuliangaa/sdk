/*
 * Copyright © 2004-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */

#include <complib/cl_semaphore.h>
#include <pthread.h>
#include <sys/errno.h>

cl_status_t cl_semaphore_init(IN cl_semaphore_t * const p_sem, IN const uint32_t value)
{
    int rc;

    CL_ASSERT(p_sem);

    rc = sem_init(&p_sem->sem, 0, value);
    return (rc == 0) ? CL_SUCCESS : CL_ERROR;
}


cl_status_t cl_semaphore_destroy(IN cl_semaphore_t * const p_sem)
{
    int rc;

    CL_ASSERT(p_sem);

    rc = sem_destroy(&p_sem->sem);
    return (rc == 0) ? CL_SUCCESS : CL_ERROR;
}


cl_status_t cl_semaphore_release(IN cl_semaphore_t * const p_sem)
{
    int rc;

    CL_ASSERT(p_sem);

    rc = sem_post(&p_sem->sem);
    return (rc == 0) ? CL_SUCCESS : CL_ERROR;
}


static cl_status_t __cl_semaphore_wait_on(IN cl_semaphore_t * const p_sem, IN const struct timespec *ts)
{
    if (ts == NULL) {
        return (sem_wait(&p_sem->sem) == 0) ? CL_SUCCESS : CL_ERROR;
    }

    if ((ts->tv_sec == 0) && (ts->tv_nsec == 0)) {
        return (sem_trywait(&p_sem->sem) == 0) ? CL_SUCCESS : CL_TIMEOUT;
    }

    return (sem_timedwait(&p_sem->sem, ts) == 0) ? CL_SUCCESS : CL_TIMEOUT;
}


cl_status_t cl_semaphore_wait_on(IN cl_semaphore_t * const p_sem, IN const uint32_t wait_us)
{
    struct timespec ts, *ts_p = NULL;
    long            nsec;
    int             rc;

    CL_ASSERT(p_sem);

    if (wait_us != SEMAPHORE_NO_TIMEOUT) {
        ts_p = &ts;

        if (wait_us == 0) {
            ts.tv_sec = 0;
            ts.tv_nsec = 0;
        } else {
            rc = clock_gettime(CLOCK_MONOTONIC, &ts);
            if (rc) {
                return CL_ERROR;
            }

            nsec = ts.tv_nsec + (wait_us % 1000000) * 1000;
            ts.tv_sec += (wait_us / 1000000) + (nsec / 1000000000);
            ts.tv_nsec = nsec % 1000000000;
        }
    }

    return __cl_semaphore_wait_on(p_sem, ts_p);
}


cl_status_t cl_semaphore_wait_on_seconds(IN cl_semaphore_t * const p_sem, IN const uint32_t wait_second)
{
    if (wait_second == SEMAPHORE_NO_TIMEOUT) {
        return cl_semaphore_wait_on(p_sem, SEMAPHORE_NO_TIMEOUT);
    }

    return cl_semaphore_wait_on(p_sem, wait_second * 1000000);
}
