/*
 * Copyright (c) 2004-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/*
 * Abstract:
 * Abstraction of Timer create, destroy functions.
 *
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#if HAVE_CONFIG_H
#  include <config.h>
#endif              /* HAVE_CONFIG_H */

#include <stdlib.h>
#include <string.h>
#include <complib/cl_timer.h>
#include <complib/cl_thread.h>
#include <complib/cl_mem.h>
#include <complib/cl_dbg.h>
#include <complib/cl_math.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <stdio.h>
#include <unistd.h>

/* Timer provider (emulates timers in user mode). */
typedef struct _cl_timer_prov {
    cl_thread_t        thread;
    pthread_mutex_t    mutex;
    pthread_condattr_t attr;
    int                timer_fd;
    cl_qlist_t         queue;
    boolean_t          exit;
} cl_timer_prov_t;

#define __cl_timespecadd(tsp, usp, vsp)                   \
    do {                                                  \
        (vsp)->tv_sec = (tsp)->tv_sec + (usp)->tv_sec;    \
        (vsp)->tv_nsec = (tsp)->tv_nsec + (usp)->tv_nsec; \
        if ((vsp)->tv_nsec >= 1000000000L) {              \
            (vsp)->tv_sec++;                              \
            (vsp)->tv_nsec -= 1000000000L;                \
        }                                                 \
    } while (0)

/* Global timer provider. */
static cl_timer_prov_t *gp_timer_prov = NULL;

void __cl_timer_prov_rollback(boolean_t condattr_initialized)
{
    if (condattr_initialized) {
        pthread_condattr_destroy(&gp_timer_prov->attr);
    }
    pthread_mutex_destroy(&gp_timer_prov->mutex);
    cl_free(gp_timer_prov);
    gp_timer_prov = NULL;
}

static void __cl_timer_prov_cb(IN void * context);

static __inline void __cl_timer_calc_abs_to_relative(IN const struct timespec * timer_abs_p,
                                                     OUT struct timeval       * timer_rel_p);

/*
 * Creates the process global timer provider.  Must be called by the shared
 * object framework to solve all serialization issues.
 */
cl_status_t __cl_timer_prov_create(void)
{
    cl_status_t cl_st = CL_SUCCESS;

    CL_ASSERT(gp_timer_prov == NULL);

    gp_timer_prov = cl_malloc(sizeof(cl_timer_prov_t));
    if (!gp_timer_prov) {
        return (CL_INSUFFICIENT_MEMORY);
    } else {
        memset(gp_timer_prov, 0, sizeof(cl_timer_prov_t));
    }

    cl_qlist_init(&gp_timer_prov->queue);

    pthread_mutex_init(&gp_timer_prov->mutex, NULL);

    if (pthread_condattr_init(&gp_timer_prov->attr)) {
        __cl_timer_prov_rollback(FALSE);
        return (CL_ERROR);
    }

    if (pthread_condattr_setclock(&gp_timer_prov->attr, CLOCK_MONOTONIC)) {
        __cl_timer_prov_rollback(TRUE);
        return (CL_ERROR);
    }

    cl_st = cl_fd_init(&gp_timer_prov->timer_fd);
    if (cl_st != CL_SUCCESS) {
        __cl_timer_prov_rollback(TRUE);
        return cl_st;
    }

    gp_timer_prov->exit = FALSE;

    if (CL_SUCCESS !=
        cl_thread_init(&gp_timer_prov->thread, __cl_timer_prov_cb, NULL, "clTimer", 30)) {
        __cl_timer_prov_destroy();
        return (CL_ERROR);
    }

    return cl_st;
}

void __cl_timer_prov_destroy(void)
{
    if (!gp_timer_prov) {
        return;
    }

    pthread_mutex_lock(&gp_timer_prov->mutex);
    gp_timer_prov->exit = TRUE;
    if (cl_fd_signal(gp_timer_prov->timer_fd)) {
        sx_log(SX_LOG_ERROR, "COMP_LIB", "cl_fd_signal failed in cl timer thread\n");
        pthread_mutex_unlock(&gp_timer_prov->mutex);
        return;
    }
    pthread_mutex_unlock(&gp_timer_prov->mutex);
    cl_thread_destroy(&gp_timer_prov->thread);

    /* Destroy the mutex and condition variable. */
    pthread_mutex_destroy(&gp_timer_prov->mutex);
    close(gp_timer_prov->timer_fd);

    /* Free the memory and reset the global pointer. */
    cl_free(gp_timer_prov);
    gp_timer_prov = NULL;
}


pthread_t cl_timer_prov_get_tid(void)
{
    return gp_timer_prov->thread.osd.id;
}


/*
 * This is the internal work function executed by the timer's thread.
 */
static void __cl_timer_prov_cb(IN void * context)
{
    int            ret;
    cl_timer_t    *p_timer;
    cl_status_t    cl_st = CL_SUCCESS;
    int            hc_fd = -1, max_fd;
    fd_set         read_fds;
    struct timeval timeout;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    UNUSED_PARAM(context);

    max_fd = gp_timer_prov->timer_fd;
    memset(&timeout, 0, sizeof(timeout));

    pthread_mutex_lock(&gp_timer_prov->mutex);
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);
    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
        max_fd = MAX(max_fd, hc_fd);
    }
    while (!gp_timer_prov->exit) {
        FD_ZERO(&read_fds);
        FD_SET(gp_timer_prov->timer_fd, &read_fds);
        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
        }
        if (cl_is_qlist_empty(&gp_timer_prov->queue)) {
            /* Wait until we exit or a timer is queued. */
            /* cond wait does:
             * pthread_cond_wait atomically unlocks the mutex (as per
             * pthread_unlock_mutex) and waits for the condition variable
             * cond to be signaled. The thread execution is suspended and
             * does not consume any CPU time until the condition variable is
             * signaled. The mutex must be locked by the calling thread on
             * entrance to pthread_cond_wait. Before RETURNING TO THE
             * CALLING THREAD, PTHREAD_COND_WAIT RE-ACQUIRES MUTEX (as per
             * pthread_lock_mutex).
             */

            pthread_mutex_unlock(&gp_timer_prov->mutex);
            cl_fd_wait_on(max_fd, &read_fds, NULL, NULL, &ret);
            pthread_mutex_lock(&gp_timer_prov->mutex);

            if (ret < 0) {
                sx_log(SX_LOG_ERROR, "COMP_LIB", "CL TIMER PROV CB: select() failed \n");
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                break;
            }
            if (hc_fd >= 0) {
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
            }

            if (FD_ISSET(gp_timer_prov->timer_fd, &read_fds)) {
                cl_st = cl_fd_read(gp_timer_prov->timer_fd);
                if (cl_st != CL_SUCCESS) {
                    sx_log(SX_LOG_ERROR, "COMP_LIB", "CL TIMER PROV CB: cl_fd_read() failed \n");
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                }
            }
            /* In case the timer did not expire so nothing should be done. Go back to while */
        } else {
            /*
             * The timer elements are on the queue in expiration order.
             * Get the first in the list to determine how long to wait.
             */

            p_timer =
                (cl_timer_t*)cl_qlist_head(&gp_timer_prov->queue);
            __cl_timer_calc_abs_to_relative(&(p_timer->timeout), &timeout);
            pthread_mutex_unlock(&gp_timer_prov->mutex);
            cl_fd_wait_on(max_fd, &read_fds, NULL, &timeout, &ret);
            pthread_mutex_lock(&gp_timer_prov->mutex);
            if (ret < 0) {
                sx_log(SX_LOG_ERROR,
                       "COMP_LIB",
                       "CL TIMER PROV CB: select() failed ret =%d, when cl_is_qlist_empty = false\n",
                       ret);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                break;
            }
            if (hc_fd >= 0) {
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
            }

            if (FD_ISSET(gp_timer_prov->timer_fd, &read_fds)) {
                cl_st = cl_fd_read(gp_timer_prov->timer_fd);
                if (cl_st != CL_SUCCESS) {
                    sx_log(SX_LOG_ERROR, "COMP_LIB", "CL TIMER PROV CB: cl_fd_read() failed \n");
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                }

                continue;
            }

            /*
             * The timer expired.  Check the state in case it was canceled
             * after it expired but before we got a chance to invoke the
             * callback.
             */
            if (p_timer->timer_state != CL_TIMER_QUEUED) {
                continue;
            }
            cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

            /*
             * Mark the timer as running to synchronize with its
             * cancellation since we can't hold the mutex during the
             * callback.
             */
            p_timer->timer_state = CL_TIMER_RUNNING;

            /* Remove the item from the timer queue. */
            cl_qlist_remove_item(&gp_timer_prov->queue,
                                 &p_timer->list_item);
            pthread_mutex_unlock(&gp_timer_prov->mutex);
            /* Invoke the callback. */
            p_timer->pfn_callback((void*)p_timer->context);

            /* Acquire the mutex again. */
            pthread_mutex_lock(&gp_timer_prov->mutex);
            /*
             * Only set the state to idle if the timer has not been accessed
             * from the callback
             */
            if (p_timer->timer_state == CL_TIMER_RUNNING) {
                p_timer->timer_state = CL_TIMER_IDLE;
            }

            /*
             * Signal any thread trying to manipulate the timer
             * that expired.
             */
            if (p_timer->state != CL_UNINITIALIZED) {
                pthread_cond_signal(&p_timer->cond);
            }
        }     /* if qlist is not empty */
    }     /* while */

    pthread_mutex_unlock(&gp_timer_prov->mutex);
    return;
}


/* Timer implementation. */
void cl_timer_construct(IN cl_timer_t * const p_timer)
{
    memset(p_timer, 0, sizeof(cl_timer_t));
    p_timer->state = CL_UNINITIALIZED;
}

cl_status_t cl_timer_init(IN cl_timer_t * const      p_timer,
                          IN cl_pfn_timer_callback_t pfn_callback,
                          IN const void *const       context)
{
    CL_ASSERT(p_timer);
    CL_ASSERT(pfn_callback);

    cl_timer_construct(p_timer);

    if (!gp_timer_prov) {
        return (CL_ERROR);
    }

    /* Store timer parameters. */
    p_timer->pfn_callback = pfn_callback;
    p_timer->context = context;

    /* Mark the timer as idle. */
    p_timer->timer_state = CL_TIMER_IDLE;

    /* Create the condition variable that is used when canceling a timer. */
    pthread_cond_init(&p_timer->cond, NULL);

    p_timer->state = CL_INITIALIZED;

    return (CL_SUCCESS);
}

void cl_timer_destroy(IN cl_timer_t * const p_timer)
{
    CL_ASSERT(p_timer);
    CL_ASSERT(cl_is_state_valid(p_timer->state));

    if (p_timer->state == CL_INITIALIZED) {
        cl_timer_stop(p_timer);
    }
    p_timer->state = CL_UNINITIALIZED;

    /* is it possible we have some threads waiting on the cond now? */
    pthread_cond_broadcast(&p_timer->cond);

    pthread_mutex_lock(&gp_timer_prov->mutex);
    pthread_cond_destroy(&p_timer->cond);
    pthread_mutex_unlock(&gp_timer_prov->mutex);
}

/*
 * Return TRUE if timeout value 1 is earlier than timeout value 2.
 */
static __inline boolean_t __cl_timer_is_earlier(IN struct timespec *p_timeout1, IN struct timespec *p_timeout2)
{
    return ((p_timeout1->tv_sec < p_timeout2->tv_sec) ||
            ((p_timeout1->tv_sec == p_timeout2->tv_sec) &&
             (p_timeout1->tv_nsec < p_timeout2->tv_nsec)));
}

/*
 * Search for a timer with an earlier timeout than the one provided by
 * the context.  Both the list item and the context are pointers to
 * a cl_timer_t structure with valid timeouts.
 */
static cl_status_t __cl_timer_find(IN const cl_list_item_t * const p_list_item, IN void *const context)
{
    cl_timer_t *p_in_list;
    cl_timer_t *p_new;

    CL_ASSERT(p_list_item);
    CL_ASSERT(context);

    p_in_list = (cl_timer_t*)p_list_item;
    p_new = (cl_timer_t*)context;

    CL_ASSERT(p_in_list->state == CL_INITIALIZED);
    CL_ASSERT(p_new->state == CL_INITIALIZED);

    CL_ASSERT(p_in_list->timer_state == CL_TIMER_QUEUED);

    if (__cl_timer_is_earlier(&p_in_list->timeout, &p_new->timeout)) {
        return (CL_SUCCESS);
    }

    return (CL_NOT_FOUND);
}

/*
 * Calculate 'struct timespec' value that is the
 * current time plus the 'time_ms' milliseconds.
 */
static __inline void __cl_timer_calculate(IN const uint32_t time_ms, OUT struct timespec * const p_timer)
{
    int             rc;
    struct timespec currtimespec, deltatime;

    rc = clock_gettime(CLOCK_MONOTONIC, &currtimespec);
    if (rc == -1) {
        memset(&currtimespec, 0, sizeof(currtimespec));
    }

    deltatime.tv_sec = time_ms / 1000;
    deltatime.tv_nsec = (time_ms % 1000) * 1000000;

    __cl_timespecadd(&currtimespec, &deltatime, p_timer);
}

static __inline void __cl_timer_calc_abs_to_relative(IN const struct timespec * timer_abs_p,
                                                     OUT struct timeval       * timer_rel_p)
{
    int             rc;
    struct timespec currtimespec;

    rc = clock_gettime(CLOCK_MONOTONIC, &currtimespec);
    if (rc == -1) {
        memset(&currtimespec, 0, sizeof(currtimespec));
    }

    if ((timer_abs_p->tv_sec < currtimespec.tv_sec) ||
        ((timer_abs_p->tv_sec == currtimespec.tv_sec) && (timer_abs_p->tv_nsec < currtimespec.tv_nsec))) {
        timer_rel_p->tv_sec = 0;
        timer_rel_p->tv_usec = 0;
    } else {
        timer_rel_p->tv_sec = timer_abs_p->tv_sec - currtimespec.tv_sec;
        if (timer_abs_p->tv_nsec >= currtimespec.tv_nsec) {
            timer_rel_p->tv_usec = (timer_abs_p->tv_nsec - currtimespec.tv_nsec) / 1000;
        } else {
            timer_rel_p->tv_sec--;
            timer_rel_p->tv_usec = 1000000 - ((currtimespec.tv_nsec - timer_abs_p->tv_nsec) / 1000);
        }
    }
}

cl_status_t cl_timer_start(IN cl_timer_t * const p_timer, IN const uint32_t time_ms)
{
    cl_list_item_t *p_list_item;

    CL_ASSERT(p_timer);
    CL_ASSERT(p_timer->state == CL_INITIALIZED);

    pthread_mutex_lock(&gp_timer_prov->mutex);
    /* Signal the timer provider thread to wake up. */
    if (cl_fd_signal(gp_timer_prov->timer_fd)) {
        sx_log(SX_LOG_ERROR, "COMP_LIB", "cl_fd_signal failed in cl timer thread\n");
    }

    /* Remove the timer from the queue if currently queued. */
    if (p_timer->timer_state == CL_TIMER_QUEUED) {
        cl_qlist_remove_item(&gp_timer_prov->queue,
                             &p_timer->list_item);
    }

    __cl_timer_calculate(time_ms, &p_timer->timeout);

    /* Add the timer to the queue. */
    if (cl_is_qlist_empty(&gp_timer_prov->queue)) {
        /* The timer list is empty.  Add to the head. */
        cl_qlist_insert_head(&gp_timer_prov->queue,
                             &p_timer->list_item);
    } else {
        /* Find the correct insertion place in the list for the timer. */
        p_list_item = cl_qlist_find_from_tail(&gp_timer_prov->queue,
                                              __cl_timer_find, p_timer);

        /* Insert the timer. */
        cl_qlist_insert_next(&gp_timer_prov->queue, p_list_item,
                             &p_timer->list_item);
    }
    /* Set the state. */
    p_timer->timer_state = CL_TIMER_QUEUED;
    pthread_mutex_unlock(&gp_timer_prov->mutex);

    return (CL_SUCCESS);
}

void cl_timer_stop(IN cl_timer_t * const p_timer)
{
    CL_ASSERT(p_timer);
    CL_ASSERT(p_timer->state == CL_INITIALIZED);

    pthread_mutex_lock(&gp_timer_prov->mutex);
    switch (p_timer->timer_state) {
    case CL_TIMER_RUNNING:
        /* Wait for the callback to complete. */
        pthread_cond_wait(&p_timer->cond, &gp_timer_prov->mutex);
        /* Timer could have been queued while we were waiting. */
        if (p_timer->timer_state != CL_TIMER_QUEUED) {
            break;
        }

    /* fall through */

    case CL_TIMER_QUEUED:
        /* Change the state of the timer. */
        p_timer->timer_state = CL_TIMER_IDLE;
        /* Remove the timer from the queue. */
        cl_qlist_remove_item(&gp_timer_prov->queue,
                             &p_timer->list_item);
        /*
         * Signal the timer provider thread to move onto the
         * next timer in the queue.
         */
        if (cl_fd_signal(gp_timer_prov->timer_fd)) {
            sx_log(SX_LOG_ERROR, "COMP_LIB", "cl_fd_signal failed in cl timer thread\n");
        }
        break;

    case CL_TIMER_IDLE:
        break;
    }
    pthread_mutex_unlock(&gp_timer_prov->mutex);
}

cl_status_t cl_timer_trim(IN cl_timer_t * const p_timer, IN const uint32_t time_ms)
{
    struct timespec newtime;
    cl_status_t     status;

    CL_ASSERT(p_timer);
    CL_ASSERT(p_timer->state == CL_INITIALIZED);

    pthread_mutex_lock(&gp_timer_prov->mutex);

    __cl_timer_calculate(time_ms, &newtime);

    if (p_timer->timer_state == CL_TIMER_QUEUED) {
        /* If the old time is earlier, do not trim it.  Just return. */
        if (__cl_timer_is_earlier(&p_timer->timeout, &newtime)) {
            pthread_mutex_unlock(&gp_timer_prov->mutex);
            return (CL_SUCCESS);
        }
    }

    /* Reset the timer to the new timeout value. */

    pthread_mutex_unlock(&gp_timer_prov->mutex);
    status = cl_timer_start(p_timer, time_ms);

    return (status);
}

uint64_t cl_get_time_stamp(void)
{
    uint64_t       tstamp;
    struct timeval tv;

    gettimeofday(&tv, NULL);

    /* Convert the time of day into a microsecond timestamp. */
    tstamp = ((uint64_t)tv.tv_sec * 1000000) + (uint64_t)tv.tv_usec;

    return (tstamp);
}

uint32_t cl_get_time_stamp_sec(void)
{
    struct timeval tv;

    gettimeofday(&tv, NULL);

    return (tv.tv_sec);
}
