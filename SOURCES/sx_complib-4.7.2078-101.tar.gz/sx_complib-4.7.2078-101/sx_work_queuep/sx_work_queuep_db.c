/*
 * Copyright © 2017-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <complib/sx_work_queuep.h>
#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>

#include "sx_work_queuep_db.h"
#include <unistd.h>

#undef  __MODULE__
#define __MODULE__ SX_WORK_QUEUEP_DB

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/* Map queue_id <-> sx_work_queue_t */
static cl_qpool_t queue_pool;

/* Max queue in the system */
static uint32_t max_queue_num = SX_WORK_QUEUES_NUM_MAX;

/**
 * Queue id to work queue mapping entry
 */
typedef struct queue_id_to_work_queue_map_item {
    sx_work_queue_id_t queue_id;    /* key */
    sx_work_queue_t   *work_queue_p;     /* value */
} queue_id_to_work_queue_map_item_t;

typedef struct queue_id_to_work_queue_db {
    queue_id_to_work_queue_map_item_t arr[TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX];
    uint32_t                          cnt; /* counter which count the total valid items in the array */
} queue_id_to_work_queue_db_t;

/* Queue id to work queue db array */
static queue_id_to_work_queue_db_t queue_id_to_work_queue_arr_s;

sx_work_queuep_status_t sx_work_queuep_db_init(void)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_status_t             cl_status = CL_SUCCESS;
    int                     idx = 0;

    memset(queue_id_to_work_queue_arr_s.arr, 0x0, sizeof(queue_id_to_work_queue_arr_s.arr));
    queue_id_to_work_queue_arr_s.cnt = 0;

    for (idx = 0; idx < TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX; idx++) {
        queue_id_to_work_queue_arr_s.arr[idx].work_queue_p = NULL;
        queue_id_to_work_queue_arr_s.arr[idx].queue_id = 0;
    }

    cl_status = CL_QPOOL_INIT(&queue_pool,
                              max_queue_num,
                              max_queue_num,
                              0,
                              sizeof(sx_work_queue_t),
                              NULL,
                              NULL,
                              NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate queue pool.\n");
        goto out;
    }

out:
    return err;
}


sx_work_queuep_status_t sx_work_queuep_db_deinit(void)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                i = 0;

    /* Clear queue id to work queue map DB */
    for (i = 0; i < TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX; i++) {
        if (queue_id_to_work_queue_arr_s.arr[i].work_queue_p != NULL) {
            sx_work_queuep_db_queue_id_to_work_queue_mapping_delete(i);
        }
        queue_id_to_work_queue_arr_s.arr[i].work_queue_p = NULL;
        queue_id_to_work_queue_arr_s.arr[i].queue_id = 0;
    }

    if (cl_is_state_valid(queue_pool.qcpool.state)) {
        CL_QPOOL_DESTROY(&queue_pool);
    }

    return err;
}


sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_add(sx_work_queue_id_t key,
                                                                             sx_work_queue_t   *item_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Add queue id to work queue map item\n");

    if (key >= TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX) {
        SX_LOG(SX_LOG_ERROR, "Could not find free map_entry in queue id to work queue db array.\n");
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        goto out;
    }

    if (queue_id_to_work_queue_arr_s.arr[key].work_queue_p != NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find free map_entry in queue id to work queue db array.\n");
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        goto out;
    }

    queue_id_to_work_queue_arr_s.arr[key].queue_id = key;
    queue_id_to_work_queue_arr_s.arr[key].work_queue_p = item_p;
    queue_id_to_work_queue_arr_s.cnt++;

out:
    SX_LOG_EXIT();
    return err;
}


sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_get(sx_work_queue_id_t key,
                                                                             sx_work_queue_t  **item_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    if (key >= TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX) {
        SX_LOG(SX_LOG_ERROR, "Error Invalid Key work queue db array.\n");
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        goto out;
    }

    if ((queue_id_to_work_queue_arr_s.arr[key].queue_id == 0) ||
        (queue_id_to_work_queue_arr_s.arr[key].work_queue_p == NULL)) {
        err = SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *item_p = queue_id_to_work_queue_arr_s.arr[key].work_queue_p;

out:
    return err;
}


sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_delete(sx_work_queue_id_t key)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    if (key >= TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX) {
        SX_LOG(SX_LOG_ERROR, "Error Invalid Key work queue db array key [%d].\n", key);
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        goto out;
    }

    if ((queue_id_to_work_queue_arr_s.arr[key].queue_id == 0) ||
        (queue_id_to_work_queue_arr_s.arr[key].work_queue_p == NULL)) {
        SX_LOG(SX_LOG_ERROR, "Error Key already removed from work queue db array. key [%d]\n", key);
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }
    queue_id_to_work_queue_arr_s.arr[key].queue_id = 0;
    queue_id_to_work_queue_arr_s.arr[key].work_queue_p = NULL;
    queue_id_to_work_queue_arr_s.cnt--;

out:
    return err;
}

sx_work_queue_t * sx_work_queuep_db_obtain_queue_item(void)
{
    cl_pool_item_t  *pool_item_p = NULL;
    sx_work_queue_t *item_p = NULL;


    pool_item_p = cl_qpool_get(&queue_pool);

    if (!pool_item_p) {
        SX_LOG_ERR("queue pool returned nothing\n");
        goto out;
    }

    item_p = PARENT_STRUCT(pool_item_p, sx_work_queue_t, pool_item);


out:
    return item_p;
}


/* Delete queue item and return it to the pool */
sx_work_queuep_status_t sx_work_queuep_db_delete_queue_item(sx_work_queue_t *item_p)
{
    cl_qpool_put(&queue_pool,
                 &item_p->pool_item);


    return SX_WORK_QUEUEP_STATUS_SUCCESS;
}

sx_work_queuep_status_t sx_work_queuep_db_free_queue_id_get(sx_work_queue_id_t *queue_id_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                idx = 0;
    boolean_t               found = FALSE;

    for (idx = 1; idx < TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX; idx++) {
        if (queue_id_to_work_queue_arr_s.arr[idx].work_queue_p == NULL) {
            found = TRUE;
            break;
        }
    }

    if (found == TRUE) {
        *queue_id_p = idx;
    } else {
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
    }

    return err;
}
