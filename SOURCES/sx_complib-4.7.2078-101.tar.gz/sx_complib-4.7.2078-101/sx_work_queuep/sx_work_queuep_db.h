/*
 * Copyright © 2010-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __SX_WORK_QUEUEP_DB_H__
#define __SX_WORK_QUEUEP_DB_H__

#include <complib/cl_pool.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_event.h>
#include <complib/cl_semaphore.h>

/************************************************
 *  Local Defines
 ***********************************************/

/* We need at least two times the number of queues (max_queue_num) */
#define SX_WORK_QUEUES_NUM_MAX 100

/* We need at least two times the number of queues (max_queue_num) */
#define TOTAL_QUEUE_ID_TO_WORK_QUEUE_ENTRY_MAX (SX_WORK_QUEUES_NUM_MAX)

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sx_work_queue {
    cl_pool_item_t             pool_item;
    cl_spinlock_t              queue_lock;
    sx_work_queuep_job_info_t *queue_entry;
    uint32_t                   work_queue_cons;
    uint32_t                   work_queue_prod;
    uint32_t                   work_queue_size;
    int32_t                    event_fd;
    cl_semaphore_t             delete_queue_sem; /* semaphore to protect destroy the queue (and his FD) while using it*/
    sx_work_queue_id_t         id;        /* queue id */
    sx_work_queue_id_t         completion_queue_id;        /* completion queue id of this queue. 0 means this is queue */
    cl_event_t                 work_queue_event;
    sx_work_queue_type_e       queue_type;
    uint32_t                   write_cnt;         /* debug counter: write count */
    uint32_t                   write_err_cnt;         /* debug counter: write error count */
    uint32_t                   read_cnt;          /* debug counter: read count */
    uint32_t                   read_err_cnt;          /* debug counter: read err count */
    uint32_t                   max_queue_items;         /* debug counter: max items in queue*/
    cl_semaphore_t             in_flight_sem; /* The in-flight semaphore */
} sx_work_queue_t;


/************************************************
 *  Function declarations
 ***********************************************/


sx_work_queuep_status_t sx_work_queuep_db_init(void);

sx_work_queuep_status_t sx_work_queuep_db_deinit(void);

sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_add(sx_work_queue_id_t key,
                                                                             sx_work_queue_t   *item_p);

sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_get(sx_work_queue_id_t key,
                                                                             sx_work_queue_t  **item_p);

sx_work_queuep_status_t sx_work_queuep_db_queue_id_to_work_queue_mapping_delete(sx_work_queue_id_t key);


sx_work_queue_t * sx_work_queuep_db_obtain_queue_item(void);

/* Delete queue item and return it to the pool */
sx_work_queuep_status_t sx_work_queuep_db_delete_queue_item(sx_work_queue_t *item_p);

sx_work_queuep_status_t sx_work_queuep_db_free_queue_id_get(sx_work_queue_id_t *queue_id_p);


#endif /* __SX_WORK_QUEUEP_DB_H__ */
