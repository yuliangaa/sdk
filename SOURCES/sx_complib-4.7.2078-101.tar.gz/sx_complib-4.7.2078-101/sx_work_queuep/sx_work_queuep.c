/*
 * Copyright (c) 2013-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <complib/sx_work_queuep.h>
#include <complib/cl_event.h>
#include <complib/cl_thread.h>
#include <complib/cl_list.h>
#include <complib/cl_pool.h>
#include <complib/cl_qlist.h>
#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_mem.h>

#include "sx_work_queuep_db.h"


#include <errno.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/eventfd.h>

#undef  __MODULE__
#define __MODULE__ SX_WORK_QUEUEP

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/*************************************************
 *  Local variables
 ************************************************/
#define SX_WORK_QUEUEP_MAX_THREAD_NUM           10
#define SX_WORK_QUEUEP_MAX_QUEUE_SIZE           (1024 * 256)
#define SX_WORK_QUEUEP_MODULE_NAME_LEN          100
#define SX_WORK_QUEUEP_COMPLETION_QUEUE_ID_NONE 0

#define RELEASE_DELETE_QUEUE_SEMAPHORE                             \
    do {                                                           \
        for (i = 0; i < queue_arr_num_of_elem; ++i) {              \
            /* coverity[lock_order] */                             \
            cl_semaphore_release(&queue_arr[i]->delete_queue_sem); \
        }                                                          \
        queue_arr_num_of_elem = 0;                                 \
    } while (0)

typedef struct {
    /* max thread count configured by the user*/
    uint32_t                max_thread_cnt;
    uint32_t                thread_cnt;
    sx_work_queuep_params_t params;
} sx_work_queuep_db;

static sx_work_queuep_db sx_work_queuep_db_s;

/* Map queue ID <-> sx_work_queue_t */

/**
 * sx_work_queuep_td_data_t structure is used to store worker
 * threads data.
 */
typedef struct sx_td_pool_worker_data {
    boolean_t     active;                                           /* is thread active */
    boolean_t     free;                                             /* Is thread free to execute jobs - currently unused */
    cl_thread_t   thread;                                           /* cl_thread object */
    cl_event_t    work_queue_event;                                 /* listening event to wake up*/
    boolean_t     worker_exit_signal_issued;
    cl_spinlock_t data_lock;                                        /* spinlock to protect data variables */
    int32_t       event_fd;                                       /* event fd */
} sx_work_queuep_td_data_t;

#define MAX_MODULE_QUEUE 10

#define SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST_POOL_MIN_SIZE   0
#define SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST_POOL_MAX_SIZE   5
#define SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST__POOL_GROW_SIZE 10

typedef struct {
    cl_pool_item_t     pool_item;
    cl_list_item_t     list_item;
    sx_work_queue_id_t queue_id;
} sx_work_queuep_module_info_listener_queues_list_item_t;

#define SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST_POOL_MIN_SIZE   0
#define SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST_POOL_MAX_SIZE   CL_POOL_UNLIMITED_MAX_SIZE
#define SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST__POOL_GROW_SIZE 10

typedef struct {
    cl_pool_item_t            pool_item;
    cl_list_item_t            list_item;
    sx_work_queue_pair_info_t qpair_info;
} sx_work_queuep_module_info_queue_pair_list_item_t;

typedef struct sx_work_queuep_module_queue_cnt {
    uint32_t private_queue_cnt_;                             /* Max num of private queues - 0 = Don't care */
    uint32_t ordered_queue_cnt;                             /* Max num of ordered_queue_max_num queues - 0 = Don't care */
    uint32_t best_effort_queue_cnt;                            /* Max num of best effort queues - 0 = Don't care */
    uint32_t private_queue_with_thread_cnt;                             /* Max num of private queue + threads - 0 = Don't care */
} sx_work_queuep_module_queue_cnt_t;

typedef struct {
    sx_work_queuep_module_id_t        id;
    char                              name[SX_WORK_QUEUEP_MODULE_NAME_LEN];           /* For debug */
    sx_work_queuep_pre_completion_cb  pre_completion_cb;
    void                             *pre_completion_cb_context;
    sx_work_queuep_post_completion_cb post_completion_cb;
    void                             *post_completion_cb_context;
    sx_work_queuep_scheduler_logic_cb scheduler_cb;
    void                             *scheduler_cb_cb_context;
    sx_work_queuep_td_data_t          thread_data;          /* Is thread active */
    cl_qpool_t                        queue_pair_list_pool;
    cl_qlist_t                        queue_pair_list;
    cl_qpool_t                        listener_queues_list_pool;
    cl_qlist_t                        listener_queues_list;
    cl_spinlock_t                     listener_queues_list_mutex;
    boolean_t                         is_initialized;
    sx_work_queuep_module_params_t    module_params;
    sx_work_queuep_module_queue_cnt_t queue_cnt;
    uint32_t                          read_err_cnt; /* debug counter: read err count */
} sx_work_queuep_module_info;

#define SX_WORK_QUEUEP_MAX_MODULE_ID 100
static sx_work_queuep_module_info sx_work_queuep_module_info_s[SX_WORK_QUEUEP_MAX_MODULE_ID];

/* global context */
static void     *g_ctx_s = NULL;
static boolean_t queue_in_deinit_flow[SX_WORK_QUEUES_NUM_MAX];


/************************************************
 *  Local function declarations
 ***********************************************/

sx_work_queuep_status_t __sx_work_queuep_module_qpair_set(const sx_work_queuep_cmd_t cmd,
                                                          sx_work_queuep_module_id_t module_id,
                                                          sx_work_queue_pair_info_t *qpair_info);

static sx_work_queuep_status_t __work_queue_is_empty(sx_work_queue_t *queue_p, boolean_t *is_empty_p);
static sx_work_queuep_status_t __work_queue_cnt_get(sx_work_queue_t *queue_p, uint32_t* queue_cnt_p);

/* Increment producer index */
static sx_work_queuep_status_t __work_queue_producer_inc(sx_work_queue_t *queue_p);

/* Increment consumer index */
static sx_work_queuep_status_t __work_queue_consumer_inc(sx_work_queue_t *queue_p);
static sx_work_queuep_status_t __open_module_td(sx_work_queuep_module_id_t module_id);
static void __module_thread(void *context);
static boolean_t is_initialized_s = FALSE;

/************************************************
 *  Function implementations
 ***********************************************/
sx_work_queuep_status_t sx_work_queuep_init(uint32_t                       max_thread_cnt,
                                            const sx_work_queuep_params_t *params_p,
                                            void                          *g_ctx)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (is_initialized_s) {
        SX_LOG_INF("SX Work Queue Pair - SX Work Queue Pair infrastructure is already initialized\n");
        err = SX_WORK_QUEUEP_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    memset(&sx_work_queuep_db_s, 0x0, sizeof(sx_work_queuep_db));
    memset(sx_work_queuep_module_info_s, 0x0, sizeof(sx_work_queuep_module_info_s));

    /* Validation */
    if (max_thread_cnt > SX_WORK_QUEUEP_MAX_THREAD_NUM) {
        SX_LOG_INF("SX Work Queue Pair init error - max thread count [%d] > SX_WORK_QUEUEP_MAX_THREAD_NUM [%d]\n",
                   max_thread_cnt,
                   SX_WORK_QUEUEP_MAX_THREAD_NUM);
        err = SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validation max thread count */
    if (params_p == NULL) {
        SX_LOG_ERR("SX work queue pair init error - params is NULL\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_work_queuep_db_init();
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("SX work queue db init error\n");
        goto out;
    }

    g_ctx_s = g_ctx;

    /* Keep the max thread count */
    sx_work_queuep_db_s.max_thread_cnt = max_thread_cnt;
    sx_work_queuep_db_s.thread_cnt = 0;
    /* Store params */
    sx_work_queuep_db_s.params = *params_p;

    is_initialized_s = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_work_queuep_status_t sx_work_queuep_deinit(void)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                i = 0;

    SX_LOG_ENTER();

    if (!is_initialized_s) {
        SX_LOG_INF("SX Work Queue Pair infra - SX Work Queue pair infra is not initialized\n");
        err = SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    for (i = 0; i < SX_WORK_QUEUEP_MAX_MODULE_ID; i++) {
        if (sx_work_queuep_module_info_s[i].is_initialized == TRUE) {
            SX_LOG_WRN("Found initialized module during deinit- [%d] - [%s] \n",
                       i, sx_work_queuep_module_info_s[i].name);
            err = sx_work_queuep_unregister_module(i);
            if (err) {
                SX_LOG_WRN("Could not unregister module [%d] - [%s] during deinit\n",  i,
                           sx_work_queuep_module_info_s[i].name);
            }
        }
    }

    err = sx_work_queuep_db_deinit();
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("SX work queue db deinit error\n");
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    is_initialized_s = FALSE;
out:

    SX_LOG_EXIT();
    return err;
}


/* Initialize a queue */
sx_work_queuep_status_t __sx_work_queuep_init_queue(uint32_t             queue_size,
                                                    sx_work_queue_type_e queue_type,
                                                    sx_work_queue_id_t   completion_queue_id_p,
                                                    sx_work_queue_id_t  *queue_id_p,
                                                    int32_t             *queue_event_fd_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    int32_t                 fd;
    sx_work_queue_t        *queue = NULL;
    cl_status_t             cl_err = CL_SUCCESS;
    sx_work_queue_id_t      queue_id;

    /* Initialize job Queue */

    queue = sx_work_queuep_db_obtain_queue_item();
    if (queue == NULL) {
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        SX_LOG_ERR("Error allocating queue memory\n");
        goto out;
    }

    /* Creating an event FD for job queue */
    fd = eventfd(0, EFD_SEMAPHORE);
    if (fd < 0) {
        SX_LOG_ERR("SX work queue pair module register error - Failure in creating an event FD\n");
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    err = sx_work_queuep_db_free_queue_id_get(&queue_id);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting free Queue ID[%s]\n",
                   SX_WORK_QUEUEP_STATUS_MSG(err));
        goto out;
    }
    queue_in_deinit_flow[queue_id] = FALSE;
    queue->id = queue_id;
    queue->queue_type = queue_type;
    queue->event_fd = fd;
    queue->completion_queue_id = completion_queue_id_p;
    /*  Thread-safety using look ahead method:
     *  We are incrementing by 1 in order to use entire queue size user has requested.
     *  As the last element is used to differentiate between empty and full cases.
     *  We reserve one cell empty. By using a single empty cell to detect the "full" case */
    queue->work_queue_size = queue_size + 1;
    queue->queue_entry = cl_malloc(sizeof(sx_work_queuep_job_info_t) * queue->work_queue_size);
    if (queue->queue_entry == NULL) {
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        SX_LOG_ERR("Error allocating queue entries\n");
        goto out;
    }

    memset(queue->queue_entry, 0x0, sizeof(sx_work_queuep_job_info_t) * queue->work_queue_size);

    /* Initialize producer consumer counters */
    queue->work_queue_cons = 0;
    queue->work_queue_prod = 0;

    cl_spinlock_init(&(queue->queue_lock));

    cl_semaphore_init(&(queue->in_flight_sem), queue_size);
    cl_semaphore_init(&(queue->delete_queue_sem), 1);

    cl_err = cl_event_init(&(queue->work_queue_event), FALSE);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not initialize work queue event. queue id [%d]\n", queue->id);
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    /* Add to mapping */
    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_add(queue->id, queue);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error mapping queue id [%d] to work queue err [%d]-[%s]\n",
                   queue->id,
                   err,
                   SX_WORK_QUEUEP_STATUS_MSG(err));
        goto out;
    }
    /* Return queue to caller */
    *queue_id_p = queue->id;
    *queue_event_fd_p = queue->event_fd;

out:
    return err;
}

/* DeInitialized a queue */
sx_work_queuep_status_t __sx_work_queuep_deinit_queue(sx_work_queue_id_t queue_id)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_t        *queue = NULL;
    cl_status_t             cl_status = CL_SUCCESS;

    /* Get queue object*/
    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_NOTICE,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    queue_in_deinit_flow[queue->id] = TRUE;

    /* Signal the queue FD. Otherwise might wait forever in the select */
    cl_status = cl_fd_signal(queue->event_fd);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("sx_work_queuep: cl_fd_signal failed %s\n", CL_STATUS_MSG(cl_status));
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    /* Before closing the queue FD, waiting until finish using it and release the semaphore. */
    /* coverity[lock_order] */
    cl_semaphore_wait_on(&(queue->delete_queue_sem), SEMAPHORE_NO_TIMEOUT);

    close(queue->event_fd);

    /* Free queue entry memory */
    cl_free(queue->queue_entry);

    cl_spinlock_destroy(&(queue->queue_lock));
    cl_semaphore_destroy(&(queue->in_flight_sem));
    cl_semaphore_destroy(&(queue->delete_queue_sem));

    /* Destroy work queue event */
    cl_event_destroy(&(queue->work_queue_event));

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_delete(queue_id);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error unmap queue id [%d] from work queue\n", queue->id);
        goto out;
    }

    /* put the queue back to the qpool */
    err = sx_work_queuep_db_delete_queue_item(queue);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error deleting work queue queue id [%d]\n", queue_id);
        goto out;
    }

out:
    return err;
}


sx_work_queuep_status_t sx_work_queuep_module_init(sx_work_queuep_module_id_t            module,
                                                   const char                           *module_name,
                                                   const sx_work_queuep_module_params_t *module_params_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!is_initialized_s) {
        SX_LOG_INF("SX Work Queue Pair infra - SX Work Queue pair infra is not initialized\n");
        err = SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }


    if (module >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        SX_LOG_ERR("SX work queue pair module register error - Module id is out of range\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (module_params_p != NULL) {
        memcpy(&sx_work_queuep_module_info_s[module].module_params, module_params_p, sizeof(*module_params_p));

        /* Set completion CB */

        if (module_params_p->pre_completion_cb != NULL) {
            sx_work_queuep_module_info_s[module].pre_completion_cb = module_params_p->pre_completion_cb;
            sx_work_queuep_module_info_s[module].pre_completion_cb_context =
                module_params_p->pre_completion_cb_context;
        }

        if (module_params_p->post_completion_cb != NULL) {
            sx_work_queuep_module_info_s[module].post_completion_cb = module_params_p->post_completion_cb;
            sx_work_queuep_module_info_s[module].post_completion_cb_context =
                module_params_p->post_completion_cb_context;
        }

        if (module_params_p->scheduler_cb != NULL) {
            sx_work_queuep_module_info_s[module].scheduler_cb = module_params_p->scheduler_cb;
            sx_work_queuep_module_info_s[module].scheduler_cb_cb_context = module_params_p->scheduler_cb_cb_context;
        }
    }


    if (sx_work_queuep_module_info_s[module].is_initialized == FALSE) {
        cl_status_t cl_rc = CL_SUCCESS;
        /* init listener queues list pool */
        cl_rc = CL_QPOOL_INIT(&(sx_work_queuep_module_info_s[module].listener_queues_list_pool),
                              SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST_POOL_MIN_SIZE,
                              SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST_POOL_MAX_SIZE,
                              SX_WORK_QUEUEP_MODULE_INFO_LISTENER_QUEUES_LIST__POOL_GROW_SIZE,
                              sizeof(sx_work_queuep_module_info_listener_queues_list_item_t),
                              NULL, NULL, NULL);

        if (cl_rc != CL_SUCCESS) {
            SX_LOG_ERR("Failed to init listener queues list pool Error: (%s).\n", CL_STATUS_MSG(cl_rc));
            err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
            goto out;
        }

        cl_qlist_init(&(sx_work_queuep_module_info_s[module].listener_queues_list));

        cl_rc = cl_spinlock_init(&(sx_work_queuep_module_info_s[module].listener_queues_list_mutex));
        if (cl_rc != CL_SUCCESS) {
            SX_LOG_ERR("Could not open reg bulk db job data mutex.\n");
            err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
            goto out;
        }

        /* init listener queues list pool */
        cl_rc = CL_QPOOL_INIT(&(sx_work_queuep_module_info_s[module].queue_pair_list_pool),
                              SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST_POOL_MIN_SIZE,
                              SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST_POOL_MAX_SIZE,
                              SX_WORK_QUEUEP_MODULE_INFO_QPAIR_LIST__POOL_GROW_SIZE,
                              sizeof(sx_work_queuep_module_info_queue_pair_list_item_t),
                              NULL, NULL, NULL);

        if (cl_rc != CL_SUCCESS) {
            SX_LOG_ERR("Failed to init queue pair list pool Error: (%s).\n", CL_STATUS_MSG(cl_rc));
            err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
            goto out;
        }

        cl_qlist_init(&(sx_work_queuep_module_info_s[module].queue_pair_list));

        sx_work_queuep_module_info_s[module].id = module;
        strncpy(sx_work_queuep_module_info_s[module].name, module_name, SX_WORK_QUEUEP_MODULE_NAME_LEN - 1);
        sx_work_queuep_module_info_s[module].name[SX_WORK_QUEUEP_MODULE_NAME_LEN - 1] = '\0';

        sx_work_queuep_module_info_s[module].is_initialized = TRUE;
    }


out:

    SX_LOG_EXIT();
    return err;
}


sx_work_queuep_status_t sx_work_queuep_module_register(const sx_work_queuep_module_id_t module,
                                                       const sx_work_queue_type_e       queue_type,
                                                       const uint32_t                   queue_size,
                                                       sx_work_queue_pair_info_t       *queue_pair_info_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queuep_status_t rollback_err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t               completion_queue_init = FALSE;
    boolean_t               queue_init = FALSE;


    SX_LOG_ENTER();

    if (!is_initialized_s) {
        SX_LOG_INF("SX Work Queue Pair infra - SX Work Queue pair infra is not initialized\n");
        err = SX_WORK_QUEUEP_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }


    /* Validation */
    /* queue type validation */
    if (queue_type > SX_WORK_QUEUE_TYPE_MAX_E) {
        SX_LOG_ERR("SX work queue pair module register error - Invalid queue type [%d]\n", queue_type);
        err = SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* queue size validation */
    if (queue_size > SX_WORK_QUEUEP_MAX_QUEUE_SIZE) {
        SX_LOG_ERR("SX work queue pair module register error -Queue size [%d] exceed max size [%d]\n",
                   queue_size,
                   SX_WORK_QUEUEP_MAX_QUEUE_SIZE);
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        goto out;
    }

    /* queue_pair_info_p validation */
    if (queue_pair_info_p == NULL) {
        SX_LOG_ERR("SX work queue pair module register error -queue_pair_info_p is NULL!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    memset(queue_pair_info_p, 0x0, sizeof(*queue_pair_info_p));

    if (module >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        SX_LOG_ERR("SX work queue pair module register error - Module id is out of range\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }


    /* Validate only one p.q + thread per module */
    if ((queue_type == SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E) &&
        (sx_work_queuep_module_info_s[module].thread_data.active == TRUE)) {
        SX_LOG_ERR("SX work queue pair module register error - module can have only one p.q + thread!\n");
        err = SX_WORK_QUEUEP_STATUS_ALREADY_EXISTS;
        goto out;
    }

    /* Validate only max num of private queues + thread */
    if (queue_type == SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E) {
        if (sx_work_queuep_db_s.thread_cnt > sx_work_queuep_db_s.max_thread_cnt) {
            SX_LOG_ERR("SX work queue pair module register error - Reached thread limits. Max thread allowed [%d]!\n",
                       sx_work_queuep_db_s.max_thread_cnt);
            err = SX_WORK_QUEUEP_STATUS_NO_RESOURCES;
            goto out;
        }

        if ((sx_work_queuep_module_info_s[module].module_params.private_queue_with_thread_max_num != 0) &&
            (sx_work_queuep_module_info_s[module].module_params.private_queue_with_thread_max_num ==
             sx_work_queuep_module_info_s[module].queue_cnt.private_queue_with_thread_cnt)) {
            SX_LOG_ERR(
                "SX work queue pair module register error - Reached queue limit. Max private queue+thread allowed [%d]\n",
                sx_work_queuep_module_info_s[module].module_params.ordered_queue_max_num);
            err = SX_WORK_QUEUEP_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    /* Validate only max num of private queues */
    if ((queue_type == SX_WORK_QUEUE_TYPE_PRIVATE_E) &&
        (sx_work_queuep_module_info_s[module].module_params.private_queue_max_num != 0) &&
        (sx_work_queuep_module_info_s[module].module_params.private_queue_max_num ==
         sx_work_queuep_module_info_s[module].queue_cnt.private_queue_cnt_)) {
        SX_LOG_ERR("SX work queue pair module register error - Reached queue limit. Max private queue allowed [%d]\n",
                   sx_work_queuep_module_info_s[module].module_params.ordered_queue_max_num);
        err = SX_WORK_QUEUEP_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Validate only max num of ordered queues */
    if ((queue_type == SX_WORK_QUEUE_TYPE_ORDERED_E) &&
        (sx_work_queuep_module_info_s[module].module_params.ordered_queue_max_num != 0) &&
        (sx_work_queuep_module_info_s[module].module_params.ordered_queue_max_num ==
         sx_work_queuep_module_info_s[module].queue_cnt.ordered_queue_cnt)) {
        SX_LOG_ERR("SX work queue pair module register error - Reached queue limit. Max ordered queue allowed [%d]\n",
                   sx_work_queuep_module_info_s[module].module_params.ordered_queue_max_num);
        err = SX_WORK_QUEUEP_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Validate only max num of best effort queues */
    if ((queue_type == SX_WORK_QUEUE_TYPE_BEST_EFFORT_E) &&
        (sx_work_queuep_module_info_s[module].module_params.best_effort_queue_max_num != 0) &&
        (sx_work_queuep_module_info_s[module].module_params.best_effort_queue_max_num ==
         sx_work_queuep_module_info_s[module].queue_cnt.best_effort_queue_cnt)) {
        SX_LOG_ERR(
            "SX work queue pair module register error - Reached queue limit. Max best effort queue allowed [%d]\n",
            sx_work_queuep_module_info_s[module].module_params.best_effort_queue_max_num);
        err = SX_WORK_QUEUEP_STATUS_NO_RESOURCES;
        goto out;
    }
    queue_pair_info_p->queue_pair_type = queue_type;

    /* Initialize completion job queue */
    err = __sx_work_queuep_init_queue(queue_size,
                                      queue_type,
                                      0,
                                      &queue_pair_info_p->completion_queue_id,
                                      queue_pair_info_p->completion_queue_fd);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error initializing completion queue for module [%d]\n", module);
        goto out;
    }
    completion_queue_init = TRUE;


    /* Initialize job queue */
    err = __sx_work_queuep_init_queue(queue_size,
                                      queue_type,
                                      queue_pair_info_p->completion_queue_id,
                                      &queue_pair_info_p->queue_id,
                                      queue_pair_info_p->queue_fd);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error initializing job queue for module [%d]\n", module);
        goto out;
    }

    queue_init = TRUE;

    err = __sx_work_queuep_module_qpair_set(SX_WORK_QUEUEP_CMD_ADD,
                                            module, queue_pair_info_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error adding queue pair info to module [%d] queue pair list err[%d]-[%s]\n",
                   module,
                   err,
                   SX_WORK_QUEUEP_STATUS_MSG(err));
        goto out;
    }

    switch (queue_type) {
    case SX_WORK_QUEUE_TYPE_PRIVATE_E:
        /* No scheduling is being done */
        /* Queue has been initialized and stored in DB*/
        /* Scheduler cb can run in thread context and select queue */
        sx_work_queuep_module_info_s[module].queue_cnt.private_queue_cnt_++;
        break;

    case SX_WORK_QUEUE_TYPE_BEST_EFFORT_E:
        /* No scheduling is being done */
        /* Queue has been initialized and stored in DB*/
        /* Scheduler cb run in thread context and select queue */
        sx_work_queuep_module_info_s[module].queue_cnt.best_effort_queue_cnt++;
        break;

    case SX_WORK_QUEUE_TYPE_ORDERED_E:     /* Scheduler cb run in thread context and select queue from ordered and best effort queues */
        /* No scheduling is being done */
        /* Queue has been initialized and stored in DB*/
        /* Scheduler cb can run in thread context and select queue */
        sx_work_queuep_module_info_s[module].queue_cnt.ordered_queue_cnt++;
        break;

    case SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E:     /* Wait for jobs in private queue and execute job cb in Thread context */
        /* Create Queue using event fd
         * Create thread and select on the private queue . execute job cb in thread context.
         * internal stop message kill the thread */

        err = sx_work_queuep_module_listener_set(
            SX_WORK_QUEUEP_CMD_ADD, module, queue_pair_info_p->queue_id);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG_ERR("Error adding queue id[%d] to listener set. module [%d]-[%s]\n",
                       queue_pair_info_p->queue_id,
                       module,
                       sx_work_queuep_module_info_s[module].name);
            goto out;
        }

        err = __open_module_td(module);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG_ERR("Error creating module [%d] thread err [%d]-[%s]\n", module, err,
                       SX_WORK_QUEUEP_STATUS_MSG(err));
            goto out;
        }
        sx_work_queuep_module_info_s[module].queue_cnt.private_queue_with_thread_cnt++;
        sx_work_queuep_db_s.thread_cnt++;
        break;
    }
    /* Thread is created per module */
out:
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        if (queue_init == TRUE) {
            rollback_err = __sx_work_queuep_deinit_queue(queue_pair_info_p->queue_id);
            if (rollback_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                SX_LOG_ERR("Error de initializing job queue for module [%d] rollback error [%d [%s]\n",
                           module, rollback_err, SX_WORK_QUEUEP_STATUS_MSG(rollback_err));
            }
        }

        if (completion_queue_init == TRUE) {
            rollback_err = __sx_work_queuep_deinit_queue(queue_pair_info_p->completion_queue_id);
            if (rollback_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                SX_LOG_ERR("Error de initializing completion job queue for module [%d] rollback error [%d [%s]\n",
                           module, rollback_err, SX_WORK_QUEUEP_STATUS_MSG(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}


/* destroy listener queues list */
static void __sx_work_queuep_module_listener_queues_list_item_dtor(sx_work_queuep_module_id_t module)
{
    sx_work_queuep_module_info_listener_queues_list_item_t *item_p = NULL;
    cl_list_item_t                                         *iter = NULL;
    cl_list_item_t                                         *list_item = NULL;
    cl_qlist_t                                             *qlist_p =
        &sx_work_queuep_module_info_s[module].listener_queues_list;
    cl_qpool_t *qpool_p =
        &sx_work_queuep_module_info_s[module].listener_queues_list_pool;

    /* Remove all items in listener queues list and put them back to pool */
    iter = cl_qlist_head(qlist_p);

    while (iter != cl_qlist_end(qlist_p)) {
        item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_listener_queues_list_item_t, list_item);
        list_item = iter;
        iter = cl_qlist_next(iter);
        cl_qlist_remove_item(qlist_p, list_item);
        cl_qpool_put(qpool_p, &(item_p->pool_item));
    }

    CL_QPOOL_DESTROY(qpool_p);
    cl_spinlock_destroy(&(sx_work_queuep_module_info_s[module].listener_queues_list_mutex));
}

/* destroy listener queues list */
static void __sx_work_queuep_module_qpair_list_item_dtor(sx_work_queuep_module_id_t module)
{
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = NULL;
    cl_list_item_t                                    *iter = NULL;
    cl_list_item_t                                    *list_item = NULL;
    sx_work_queuep_status_t                            err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_id_t                                 queue_id;
    cl_qlist_t                                        *qlist_p = &sx_work_queuep_module_info_s[module].queue_pair_list;
    cl_qpool_t                                        *qpool_p =
        &sx_work_queuep_module_info_s[module].queue_pair_list_pool;


    /* Remove all items in queue pair list and put them back to pool */
    iter = cl_qlist_head(qlist_p);

    while (iter != cl_qlist_end(qlist_p)) {
        item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_queue_pair_list_item_t, list_item);

        /* Deinit queue id */
        queue_id = item_p->qpair_info.queue_id;
        err = __sx_work_queuep_deinit_queue(queue_id);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Error deinit queue id [%d]\n", queue_id);
        }
        /* Destroy completion queue */
        queue_id = item_p->qpair_info.completion_queue_id;
        err = __sx_work_queuep_deinit_queue(queue_id);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Error deinit completion queue id [%d]\n", queue_id);
        }

        list_item = iter;
        iter = cl_qlist_next(iter);
        cl_qlist_remove_item(qlist_p, list_item);
        cl_qpool_put(qpool_p, &(item_p->pool_item));
    }

    CL_QPOOL_DESTROY(qpool_p);
}

/* create scheduler thread */
static sx_work_queuep_status_t __open_module_td(sx_work_queuep_module_id_t module_id)
{
    cl_status_t             cl_err = CL_SUCCESS;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    int32_t                 fd = 0;

    SX_LOG_ENTER();

    sx_work_queuep_td_data_t *thread_data_p = &sx_work_queuep_module_info_s[module_id].thread_data;

    memset(thread_data_p, 0x0, sizeof(*thread_data_p));

    /* Creating an event FD for job queue */
    fd = eventfd(0, EFD_SEMAPHORE);
    if (fd < 0) {
        SX_LOG_ERR("__open_module_td - Failure in creating an event FD, status [%d] errno [%d]-[%s]\n",
                   fd,
                   errno,
                   strerror(errno));
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }
    thread_data_p->event_fd = fd;

    cl_err = cl_spinlock_init(&(thread_data_p->data_lock));
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not initialize spin lock\n");
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    /* Validation thread can be initialized only once.. */

    cl_err = cl_event_init(&(thread_data_p->work_queue_event), FALSE);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not initialize work queue event\n");
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    void *context = (void*)(&sx_work_queuep_module_info_s[module_id]);

    /* 70 sec because of scale scenario */
    cl_err = cl_thread_init(&(thread_data_p->thread),
                            __module_thread,
                            context,
                            sx_work_queuep_module_info_s[module_id].name, 90);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not create thread\n");
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        goto out;
    }

    thread_data_p->active = TRUE;

    SX_LOG(SX_LOG_INFO, "Module Id [%d]-[%s] thread opened\n", module_id,
           sx_work_queuep_module_info_s[module_id].name);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_work_queuep_status_t __work_queuep_dequeue_job_from_queue(sx_work_queuep_module_info *module_info,
                                                                    sx_work_queue_t            *module_queue)
{
    sx_work_queuep_status_t               status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queuep_job_info_t            *queue_entry = NULL;
    sx_work_queuep_job_info_t             queue_entry_obj;
    sx_work_queuep_pre_completion_cb      pre_completion_cb = NULL;
    sx_work_queuep_post_completion_cb     post_completion_cb = NULL;
    void                                 *comp_cb_context = NULL; /* used to store pre/post completed cb context */
    sx_work_queuep_completion_cb_params_t comp_cb_params;
    sx_work_queuep_job_cb_info_t          job_cb_info;
    boolean_t                             is_empty = FALSE;

    memset(&comp_cb_params, 0x0, sizeof(comp_cb_params));

    cl_spinlock_acquire(&module_queue->queue_lock);

    status = __work_queue_is_empty(module_queue, &is_empty);

    if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        cl_spinlock_release(&module_queue->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Error checking if queue is empty. module_id [%d]-[%s] queue id [%d]\n"
               , module_info->id, module_info->name, module_queue->id);
        goto out;
    }

    memset(&queue_entry_obj, 0x0, sizeof(queue_entry_obj));

    /* De queue job from job queue */
    if (is_empty == FALSE) {
        SX_LOG(SX_LOG_FRAMES,
               "Queue entry #%u buffer taken by module id [%d]-[%s]\n",
               module_queue->work_queue_cons, module_info->id, module_info->name);


        memcpy(&queue_entry_obj, &module_queue->queue_entry[module_queue->work_queue_cons],
               sizeof(sx_work_queuep_job_info_t));
        queue_entry = &queue_entry_obj;

        /* Increment module queue consumer counter */
        status = __work_queue_consumer_inc(module_queue);
        if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            cl_spinlock_release(&module_queue->queue_lock);
            SX_LOG(SX_LOG_ERROR,
                   "Error increment consumer index. status [%s] queue id [%d]\n", SX_WORK_QUEUEP_STATUS_MSG(
                       status), module_queue->id);
            goto out;
        }

        cl_spinlock_release(&module_queue->queue_lock);

        cl_semaphore_release(&(module_queue->in_flight_sem));


        SX_LOG(SX_LOG_FRAMES,
               "Work queue for Module id [%d]-[%s] (cons, prod) - (%u, %u)\n",
               module_info->id,
               module_info->name,
               module_queue->work_queue_cons,
               module_queue->work_queue_prod);

        memset(&job_cb_info, 0x0, sizeof(sx_work_queuep_job_cb_info_t));
        memset(&comp_cb_params, 0x0, sizeof(comp_cb_params));

        comp_cb_params.completion_queue_id = module_queue->completion_queue_id;
        comp_cb_params.job_info_p = queue_entry;
        job_cb_info.context = queue_entry->job_handler_cb_context;
        job_cb_info.job_data = queue_entry->job_data;
        job_cb_info.module_id = queue_entry->module_id;
        job_cb_info.trigerred_queue_id_p = module_queue->id;
        job_cb_info.queue_pair_qlist_p = &module_info->queue_pair_list; /* Note: The list is not thread safe. should be protected by the caller */

        /* Check if this is not a completion queue */
        if (module_queue->completion_queue_id != SX_WORK_QUEUEP_COMPLETION_QUEUE_ID_NONE) {
            /* not a completion queue */
            if (queue_entry->should_push_pre_completion) {
                queue_entry->completion_notif_type = SX_WORK_QUEUEP_COMPLETION_TYPE_PRE_E;
                /* push pre notification message to completion queue */
                status = sx_work_queue_push_job(module_queue->completion_queue_id, queue_entry);
                if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR,
                           "Error Push pre completion job to completion queue module_id [%d] queue id [%d]\n"
                           , module_info->id, module_queue->id);
                }
            }

            if (queue_entry->should_call_pre_completion_cb) {
                /* call pre completion call back */
                pre_completion_cb = module_info->pre_completion_cb;
                comp_cb_context = module_info->pre_completion_cb_context;
                if (pre_completion_cb != NULL) {
                    status = pre_completion_cb(&comp_cb_params, comp_cb_context);
                    if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Error Executing pre completion callback module_id [%d] queue id [%d]\n"
                               , module_info->id, module_queue->id);
                    }
                }
            }
        }

        job_cb_info.infra_internal_ctx = (void*)queue_entry;
        /* Execute job handler callback */
        status = queue_entry->job_handler_cb(&job_cb_info);
        if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Error at job handler cb module_id [%d]-[%s] queue ID [%d]\n",
                   module_info->id, module_info->name, module_queue->id);
        }

        if (module_queue->completion_queue_id != SX_WORK_QUEUEP_COMPLETION_QUEUE_ID_NONE) {
            /* not a completion queue */
            if (queue_entry->should_push_post_completion) {
                /* push post notification message to completion queue */
                status = sx_work_queue_push_job(module_queue->completion_queue_id, queue_entry /*&job_info*/);
                if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR,
                           "Error Push post completion job to completion queue module_id [%d] queue id [%d]\n"
                           , module_info->id, module_queue->id);
                }
            }

            if (queue_entry->should_call_post_completion_cb) {
                /* call post completion call back */
                post_completion_cb = module_info->post_completion_cb;
                comp_cb_context = module_info->post_completion_cb_context;
                if (post_completion_cb != NULL) {
                    status = post_completion_cb(&comp_cb_params, comp_cb_context);
                    if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Error Executing post completion callback module_id [%d] queue id [%d]\n"
                               , module_info->id, module_queue->id);
                    }
                }
            }
        }
    } else {    /*  if (module_queue->work_queue_cons != module_queue->work_queue_prod) */
        cl_spinlock_release(&module_queue->queue_lock);
        if (queue_in_deinit_flow[module_queue->id] == FALSE) {
            SX_LOG(SX_LOG_ERROR,
                   "Error nothing to de queue module_id [%d] queue id [%d]\n"
                   , module_info->id, module_queue->id);
        }
    }


out:
    return status;
}


static void __module_thread(void *context)
{
    sx_work_queuep_module_info                             *module_info = (sx_work_queuep_module_info*)context;
    sx_work_queuep_status_t                                 err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_t                                       * module_queue = NULL;
    sx_work_queuep_scheduler_decision_params_t              scheduler_decision_params;
    sx_work_queuep_scheduler_decision_result_t              scheduler_decision_result;
    sx_work_queue_id_t                                      queue_id;
    cl_qlist_t                                             *qlist_p = NULL;
    cl_list_item_t                                         *iter = NULL;
    const cl_list_item_t                                   *iter_end = NULL;
    sx_work_queuep_module_info_listener_queues_list_item_t *item_p = NULL;
    sx_work_queue_t                                        *queue_p = NULL;
    sx_work_queue_t                                       **queue_arr = NULL; /* array of queue pointers to release the semaphore when required*/
    uint32_t                                                queue_arr_size = 0; /* size of allocation of queue_arr */
    uint32_t                                                queue_arr_num_of_elem = 0; /* actual number of queue pointers in the array*/
    uint32_t                                                new_arr_size = 0;
    /* Select variables */
    int       result = 0;
    fd_set    readset;
    boolean_t scheduler_check = FALSE;
    uint32_t  i = 0;
    int       fd = 0, hc_fd = -1;
    int       max_fd = -1;
    ssize_t   efd_ret = 0;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    qlist_p = &module_info->listener_queues_list;

    uint64_t buffer;

    SX_LOG_ENTER();

    memset(&scheduler_decision_params, 0x0, sizeof(scheduler_decision_params));
    memset(&scheduler_decision_result, 0x0, sizeof(scheduler_decision_result));
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);

    while (TRUE) {
        FD_ZERO(&readset);
        max_fd = -1;

        if (module_info->scheduler_cb != NULL) {
            memset(&scheduler_decision_params, 0x0, sizeof(scheduler_decision_params));
            memset(&scheduler_decision_result, 0x0, sizeof(scheduler_decision_result));
        }

        queue_arr_num_of_elem = 0;

        /* the lock is needed to prevent access to the list during list entries deletion */
        cl_spinlock_acquire(&(module_info->listener_queues_list_mutex));

        /* New allocation of the queue pointers array is required if the new list size is higher then the previous iteration */
        new_arr_size = cl_qlist_count(qlist_p);
        if (new_arr_size > queue_arr_size) {
            cl_free(queue_arr);
            queue_arr = (sx_work_queue_t**)cl_malloc(sizeof(sx_work_queue_t*) * new_arr_size);
            if (!queue_arr) {
                err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
                SX_LOG_ERR("Error allocating queue pointers array err [%d]-[%s]\n", err,
                           SX_WORK_QUEUEP_STATUS_MSG(err));
                cl_spinlock_release(&(module_info->listener_queues_list_mutex));
                goto out;
            }
            queue_arr_size = new_arr_size;
        }

        iter = cl_qlist_head(qlist_p);
        iter_end = cl_qlist_end(qlist_p);

        for (; iter != iter_end; iter = cl_qlist_next(iter)) {
            item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_listener_queues_list_item_t, list_item);
            /* Get FD From Queue FD */
            err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(item_p->queue_id, &queue_p);
            if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                if (queue_in_deinit_flow[item_p->queue_id] == FALSE) {
                    SX_LOG(SX_LOG_ERROR,
                           "__module_thread Error getting work queue from queue id [%d] module id [%d]-[%s]\n",
                           item_p->queue_id, module_info->id, module_info->name);
                }
                continue;
            }

            fd = queue_p->event_fd;

            /* Taking semaphore so avoid destroy the queue (and his FD) while using it in  'cl_fd_wait_on' function */
            /* Coverity warning is that we acquire semaphore inside the mutex for qlist.
             * This is the sequence in which the locks/unlocks happen. Note that there is a mutex per module and a semaphore per queue
             * tdWorker calls for example router_async_deinit -> lock qlist mutex (inside sx_work_queuep_module_listener_set) -> release qlist mutex (sx_work_queuep_module_listener_set) -> acquire semaphore (__sx_work_queuep_deinit_queue) -> release semaphore
             * module thread (router) -> acquire qlist mutex -> in side loop of all queues try-acquire semaphore (if fail continue in loop) -> if acquire release semaphore -> release mutex
             * There cannot be a deadlock in this scenario.
             */
            /* coverity[lock_order] */
            if (cl_semaphore_wait_on(&(queue_p->delete_queue_sem), 0) == CL_TIMEOUT) {
                continue;
            }

            queue_arr[queue_arr_num_of_elem++] = queue_p;

            FD_SET(fd, &readset);
            if (max_fd < fd) {
                max_fd = fd;
            }

            if (module_info->scheduler_cb != NULL) {
                scheduler_decision_params.queue_info[scheduler_decision_params.num_of_queues].queue_type =
                    queue_p->queue_type;
                scheduler_decision_params.queue_info[scheduler_decision_params.num_of_queues].queue_id =
                    queue_p->id;
                scheduler_decision_params.num_of_queues++;
            }
        }

        cl_spinlock_release(&(module_info->listener_queues_list_mutex));

        /* Add thread event fd to read set to listen on stop message*/
        fd = module_info->thread_data.event_fd;
        FD_SET(fd, &readset);
        if (max_fd < fd) {
            max_fd = fd;
        }

        if (bp_ctl_db_entry_p != NULL) {
            hc_fd = bp_ctl_db_entry_p->health_check_fd;
        }

        if (hc_fd >= 0) {
            max_fd = (max_fd > hc_fd) ? max_fd : hc_fd;
            FD_SET(hc_fd, &readset);
        }

        /* Wait for job on one of the listener queues */
        cl_fd_wait_on(max_fd, &readset, NULL, NULL, &result); /* Don't change the timeout_p parameter. if doing so, need to release 'delete_queue_sem' semaphore also when result = 0 */
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        /* release the semaphore after using the queue FD in order to allow deinit the queue and his FD */
        if (module_info->scheduler_cb == NULL) {
            RELEASE_DELETE_QUEUE_SEMAPHORE;
        }

        if (result > 0) {
            fd = module_info->thread_data.event_fd;
            if (FD_ISSET(fd, &readset)) {
                /* The event FD has data available to be read */
                efd_ret = read(fd, &buffer, sizeof(buffer));
                if (efd_ret != sizeof(buffer)) {
                    SX_LOG(SX_LOG_ERROR,
                           "__module_thread Error remote side closed the socket module id [%d]-[%s] result [%zd] errno [%s]\n",
                           module_info->id,
                           module_info->name,
                           efd_ret,
                           strerror(errno));
                } else {
                    if (module_info->thread_data.worker_exit_signal_issued == TRUE) {
                        SX_LOG_DBG("Thread __module_thread is gracefully ending.\n");
                        module_info->thread_data.active = FALSE;
                        cl_event_signal(&(module_info->thread_data.work_queue_event));
                        RELEASE_DELETE_QUEUE_SEMAPHORE;
                        cl_free(queue_arr);
                        return;
                    }
                }
            }
            if (hc_fd >= 0) {
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &readset, FALSE);
            }

            /* Call scheduler */
            if (module_info->scheduler_cb != NULL) {
                /* Read all FDs */
                for (i = 0; i < scheduler_decision_params.num_of_queues; i++) {
                    queue_id = scheduler_decision_params.queue_info[i].queue_id;
                    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &module_queue);
                    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_DEBUG,
                               "__module_thread Error getting work queue from queue id [%d] module id [%d]-[%s]\n",
                               item_p->queue_id, module_info->id, module_info->name);
                        continue;
                    }
                    fd = module_queue->event_fd;

                    if (FD_ISSET(fd, &readset) && !queue_in_deinit_flow[module_queue->id]) {
                        /* The event FD has data available to be read */
                        efd_ret = read(fd, &buffer, sizeof(buffer));
                        if (efd_ret != sizeof(buffer)) {
                            /* If result < 0 and qpair isn't in deinit flow , print an error */
                            SX_LOG(SX_LOG_ERROR,
                                   "__module_thread Error remote side closed the socket %d module id [%d]-[%s] queue id [%d] result [%zd] errno [%s]\n",
                                   fd,
                                   module_info->id,
                                   module_info->name,
                                   module_queue->id,
                                   efd_ret,
                                   strerror(errno));
                            module_queue->read_err_cnt++;
                        } else {
                            module_queue->read_cnt++;
                        }
                    }
                }
                scheduler_check = TRUE;
                while (scheduler_check == TRUE) {
                    err = module_info->scheduler_cb(&scheduler_decision_params,
                                                    &scheduler_decision_result,
                                                    module_info->scheduler_cb_cb_context);
                    if (err == SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND) {
                        scheduler_check = FALSE;
                        continue;
                    } else if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "error at scheduler module id [%d]-[%s] err [%d]-[%s]\n",
                               module_info->id, module_info->name, err, SX_WORK_QUEUEP_STATUS_MSG(err));
                        scheduler_check = FALSE;
                        continue;
                    }

                    /* Send internal message to perform another scheduler cycle till no queues are found */

                    /* Execute job from selected queue */

                    /* Get queue object */
                    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(
                        scheduler_decision_result.selected_queue,
                        &module_queue);
                    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        if (queue_in_deinit_flow[scheduler_decision_result.selected_queue] == FALSE) {
                            SX_LOG(SX_LOG_ERROR,
                                   "__module_thread Error getting work queue from scheduler selected queue id [%d] module id [%d]-[%s] err [%d]-[%s]\n",
                                   scheduler_decision_result.selected_queue,
                                   module_info->id,
                                   module_info->name,
                                   err,
                                   SX_WORK_QUEUEP_STATUS_MSG(err));
                        }
                        scheduler_check = FALSE;
                        continue;
                    }

                    err = __work_queuep_dequeue_job_from_queue(module_info, module_queue);
                    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "__module_thread Error de queue job from selected queue id [%d] module id [%d]-[%s]\n",
                               scheduler_decision_result.selected_queue, module_info->id, module_info->name);
                        scheduler_check = FALSE;
                    }

                    /* no need to iterate in a while loop, if there another job the select will pop up again */
                    scheduler_check = FALSE;
                }

                /* release the semaphore also in the case that: module_info->scheduler_cb != NULL */
                RELEASE_DELETE_QUEUE_SEMAPHORE;

                goto need_to_wait;
            }

            /* the lock is needed to prevent access to the list during list entries deletion */
            cl_spinlock_acquire(&(module_info->listener_queues_list_mutex));

            /* in case of no scheduler , iterate through the queues */
            iter = cl_qlist_head(qlist_p);
            iter_end = cl_qlist_end(qlist_p);

            for (; iter != iter_end; iter = cl_qlist_next(iter)) {
                item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_listener_queues_list_item_t, list_item);
                /* Get FD From Queue FD */
                err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(item_p->queue_id, &module_queue);
                if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                    if (queue_in_deinit_flow[item_p->queue_id] == FALSE) {
                        SX_LOG(SX_LOG_ERROR,
                               "__module_thread Error getting work queue from queue id [%d] module id [%d]-[%s]\n",
                               item_p->queue_id, module_info->id, module_info->name);
                    }
                    continue;
                }
                fd = module_queue->event_fd;

                if (FD_ISSET(fd, &readset) && !queue_in_deinit_flow[module_queue->id]) {
                    /* The event FD has data available to be read */
                    efd_ret = read(fd, &buffer, sizeof(buffer));
                    if (efd_ret != sizeof(buffer)) {
                        SX_LOG(SX_LOG_ERROR,
                               "__module_thread Error remote side closed the socket module id [%d]-[%s] queue id [%d] result [%zd] errno [%s]\n",
                               module_info->id,
                               module_info->name,
                               module_queue->id,
                               efd_ret,
                               strerror(errno));
                        module_queue->read_err_cnt++;
                    } else {
                        module_queue->read_cnt++;
                        /* Received data on queue id */
                        /* De queue job from job queue */
                        err = __work_queuep_dequeue_job_from_queue(module_info, module_queue);
                        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                            SX_LOG(SX_LOG_ERROR,
                                   "__module_thread Error de queue job from queue id [%d] module id [%d]-[%s]\n",
                                   item_p->queue_id, module_info->id, module_info->name);
                        }
                    }
                } /* if */
            } /* for */

            cl_spinlock_release(&(module_info->listener_queues_list_mutex));
        } else if (result < 0) {
            /* An error occurred, just print it to stdout */
            SX_LOG(SX_LOG_ERROR, "Error on select(): [%s]\n", strerror(errno));
            goto out;
        }
need_to_wait:
        /* check if time to die (in case need to wait) */
        if (module_info->thread_data.worker_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __module_thread is gracefully ending.\n");
            module_info->thread_data.active = FALSE;
            cl_event_signal(&(module_info->thread_data.work_queue_event));
            cl_free(queue_arr);
            return;
        }
    } /* forever */

out:
    SX_LOG_ERR("Thread __module_thread Unexpected ending.\n");
    cl_free(queue_arr);
    CL_ASSERT(FALSE);
    SX_LOG_EXIT();
    return;
}


sx_work_queuep_status_t sx_work_queuep_get_queue_fd(sx_work_queue_id_t queue_id, int32_t *queue_event_fd_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_t        *queue_p = NULL;

    /* Validation */
    if (queue_event_fd_p == NULL) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "Error param queue_event_fd_p is NULL queue ID [%d]\n", queue_id);
        goto out;
    }

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_NOTICE,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    *queue_event_fd_p = queue_p->event_fd;

out:
    return err;
}


/* module listener queues list comparison function */
cl_status_t __sx_work_queuep_module_listener_queues_list_cmp(const cl_list_item_t * const list_item_p, void *context)
{
    sx_work_queuep_module_info_listener_queues_list_item_t *item_p = PARENT_STRUCT(list_item_p,
                                                                                   sx_work_queuep_module_info_listener_queues_list_item_t,
                                                                                   list_item);

    if ((*(sx_work_queue_id_t*)context) == item_p->queue_id) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}


sx_work_queuep_status_t sx_work_queuep_module_listener_set(const sx_work_queuep_cmd_t cmd,
                                                           sx_work_queuep_module_id_t module_id,
                                                           sx_work_queue_id_t         queue_id)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_qpool_t             *qpool_p =
        &sx_work_queuep_module_info_s[module_id].listener_queues_list_pool;
    cl_qlist_t *qlist_p =
        &sx_work_queuep_module_info_s[module_id].listener_queues_list;
    cl_pool_item_t                                         *pool_item_p = NULL;
    cl_list_item_t                                         *list_item_p = NULL;
    sx_work_queuep_module_info_listener_queues_list_item_t *item_p = NULL;

    /* Validation */
    if (module_id >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Error exceed range module_id [%d] is bigger than max module id\n", module_id);
        goto out;
    }

    switch (cmd) {
    case SX_WORK_QUEUEP_CMD_ADD:
        pool_item_p = cl_qpool_get(qpool_p);
        if (pool_item_p == NULL) {
            err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to add listener queue id:[%u] to listener queues list, module_id:[%u]. err=[%s]\n",
                       queue_id,
                       module_id,
                       SX_WORK_QUEUEP_STATUS_MSG(err));
            goto out;
        }
        /*update listener list*/
        item_p = PARENT_STRUCT(pool_item_p, sx_work_queuep_module_info_listener_queues_list_item_t, pool_item);
        item_p->queue_id = queue_id;
        cl_spinlock_acquire(&(sx_work_queuep_module_info_s[module_id].listener_queues_list_mutex));
        cl_qlist_insert_tail(qlist_p, &(item_p->list_item));
        cl_spinlock_release(&(sx_work_queuep_module_info_s[module_id].listener_queues_list_mutex));
        break;

    case SX_WORK_QUEUEP_CMD_DELETE:

        cl_spinlock_acquire(&(sx_work_queuep_module_info_s[module_id].listener_queues_list_mutex));

        /* Remove rule from listener queue list */
        list_item_p = cl_qlist_find_from_head(qlist_p,
                                              __sx_work_queuep_module_listener_queues_list_cmp,
                                              (void*)&queue_id);
        if (list_item_p == cl_qlist_end(qlist_p)) {
            cl_spinlock_release(&(sx_work_queuep_module_info_s[module_id].listener_queues_list_mutex));
            err = SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to delete queue id:[%u] from listener queues list, module id:[%u]. err=[%s]\n",
                       queue_id,
                       module_id,
                       SX_WORK_QUEUEP_STATUS_MSG(err));
            goto out;
        }

        item_p = PARENT_STRUCT(list_item_p, sx_work_queuep_module_info_listener_queues_list_item_t, list_item);
        cl_qlist_remove_item(qlist_p, list_item_p);
        cl_qpool_put(qpool_p, &(item_p->pool_item));

        cl_spinlock_release(&(sx_work_queuep_module_info_s[module_id].listener_queues_list_mutex));

        break;

    default:
        err = SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR,
               "Error unexpected cmd [%d]\n", cmd);
        goto out;
    }

out:
    return err;
}


/* module listener queues list comparison function */
cl_status_t __sx_work_queuep_module_queue_pair_list_cmp(const cl_list_item_t * const list_item_p, void *context)
{
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = PARENT_STRUCT(list_item_p,
                                                                              sx_work_queuep_module_info_queue_pair_list_item_t,
                                                                              list_item);
    sx_work_queue_pair_info_t* qpair_info_p = (sx_work_queue_pair_info_t*)context;

    if ((qpair_info_p->completion_queue_fd == item_p->qpair_info.completion_queue_fd) &&
        (qpair_info_p->completion_queue_id == item_p->qpair_info.completion_queue_id) &&
        (qpair_info_p->queue_fd == item_p->qpair_info.queue_fd) &&
        (qpair_info_p->queue_id == item_p->qpair_info.queue_id)
        ) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}


sx_work_queuep_status_t __sx_work_queuep_module_qpair_set(const sx_work_queuep_cmd_t cmd,
                                                          sx_work_queuep_module_id_t module_id,
                                                          sx_work_queue_pair_info_t *qpair_info)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_qpool_t             *qpool_p =
        &sx_work_queuep_module_info_s[module_id].queue_pair_list_pool;
    cl_qlist_t *qlist_p =
        &sx_work_queuep_module_info_s[module_id].queue_pair_list;
    cl_pool_item_t                                    *pool_item_p = NULL;
    cl_list_item_t                                    *list_item_p = NULL;
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = NULL;

    /* Validation */
    if (module_id >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Error exceed range module_id [%d] is bigger than max module id\n", module_id);
        goto out;
    }

    switch (cmd) {
    case SX_WORK_QUEUEP_CMD_ADD:
        pool_item_p = cl_qpool_get(qpool_p);
        if (pool_item_p == NULL) {
            err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to add queue pair info. queue id:[%u] to queue pair list, module_id:[%u]. rc=[%s]\n",
                       qpair_info->queue_id,
                       module_id,
                       SX_WORK_QUEUEP_STATUS_MSG(err));
            goto out;
        }
        /*update queue pair list*/
        item_p = PARENT_STRUCT(pool_item_p, sx_work_queuep_module_info_queue_pair_list_item_t, pool_item);
        memcpy(&item_p->qpair_info, qpair_info, sizeof(*qpair_info));
        cl_qlist_insert_tail(qlist_p, &(item_p->list_item));
        break;

    case SX_WORK_QUEUEP_CMD_DELETE:
        /* Remove queue pair info from queue pair list */
        list_item_p = cl_qlist_find_from_head(qlist_p, __sx_work_queuep_module_queue_pair_list_cmp, (void*)qpair_info);
        if (list_item_p == cl_qlist_end(qlist_p)) {
            err = SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to delete queue id:[%u] from queue pair list, module id:[%u]. err=[%s]\n",
                       qpair_info->queue_id,
                       module_id,
                       SX_WORK_QUEUEP_STATUS_MSG(err));
            goto out;
        }

        item_p = PARENT_STRUCT(list_item_p, sx_work_queuep_module_info_queue_pair_list_item_t, list_item);
        cl_qlist_remove_item(qlist_p, list_item_p);
        cl_qpool_put(qpool_p, &(item_p->pool_item));

        break;

    default:
        err = SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR,
               "Error unexpected cmd [%d]\n", cmd);
        goto out;
    }

out:
    return err;
}

sx_work_queuep_status_t sx_work_queuep_module_thread_params_set(sx_work_queuep_module_id_t                 module,
                                                                const sx_work_queuep_module_thread_attr_t *module_thread_attr)
{
    UNUSED_PARAM(module);
    UNUSED_PARAM(module_thread_attr);
    return SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED;
}

sx_work_queuep_status_t sx_work_queuep_unregister_module(sx_work_queuep_module_id_t module_id)
{
    sx_work_queuep_status_t   err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    int                       fd = 0;
    uint64_t                  wake_up_msg = 0;
    sx_work_queuep_td_data_t *thread_data_p = NULL;
    cl_status_t               cl_err = CL_SUCCESS;
    ssize_t                   ret = 0;

    /* Validation */
    if (module_id >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Error exceed range module_id [%d] is bigger than max module id\n", module_id);
        goto out;
    }

    if (sx_work_queuep_module_info_s[module_id].thread_data.active == TRUE) {
        /* Thread is active. Deinit threads and all related structures */

        thread_data_p = &sx_work_queuep_module_info_s[module_id].thread_data;
        fd = thread_data_p->event_fd;
        thread_data_p->worker_exit_signal_issued = TRUE;

        /* Write wake up message to the event FD */
        wake_up_msg = 1;
        ret = write(fd, &wake_up_msg, sizeof(wake_up_msg));
        if (ret != sizeof(wake_up_msg)) {
            SX_LOG(SX_LOG_ERROR,
                   "sx_work_queuep_unregister_module Error write internal message to thread module id [%d] fd [%d] ret [%zd] errno [%s].\n",
                   module_id,
                   fd,
                   ret,
                   strerror(errno));
            err = SX_WORK_QUEUEP_STATUS_ERROR;
            goto out;
        }

        /* Wait on kill message to finish */
        cl_err = cl_event_wait_on(&(thread_data_p->work_queue_event), EVENT_NO_TIMEOUT, TRUE);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "sx_work_queuep_unregister_module Error at work queue event wait\n");
            goto out;
        }

        close(thread_data_p->event_fd);

        cl_thread_destroy(&(thread_data_p->thread));

        cl_event_destroy(&(thread_data_p->work_queue_event));
    }
    /* Destroy Module Queues */

    /* Destroy module's listener queues list */
    __sx_work_queuep_module_listener_queues_list_item_dtor(module_id);

    /* Destroy module's queue pair list */
    __sx_work_queuep_module_qpair_list_item_dtor(module_id);

    sx_work_queuep_module_info_s[module_id].is_initialized = FALSE;

    if (sx_work_queuep_module_info_s[module_id].queue_cnt.private_queue_with_thread_cnt > 0) {
        CL_ASSERT(
            sx_work_queuep_db_s.thread_cnt >=
            sx_work_queuep_module_info_s[module_id].queue_cnt.private_queue_with_thread_cnt);
        sx_work_queuep_db_s.thread_cnt -=
            sx_work_queuep_module_info_s[module_id].queue_cnt.private_queue_with_thread_cnt;
    }
    memset(&sx_work_queuep_module_info_s[module_id], 0x0, sizeof(sx_work_queuep_module_info_s[module_id]));

out:
    return err;
}

sx_work_queuep_status_t sx_work_queue_push_job(const sx_work_queue_id_t         queue_id,
                                               const sx_work_queuep_job_info_t *job_info_p)
{
    uint32_t                   index = 0;
    sx_work_queuep_job_info_t *entry = NULL;
    sx_work_queue_t           *queue_p = NULL;
    sx_work_queuep_status_t    err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint64_t                   wake_up_msg;
    ssize_t                    ret = 0;

    if (job_info_p == NULL) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "Error job_info_p is NULL! queue id [%d]\n", queue_id);
        goto out;
    }

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }


    cl_semaphore_wait_on(&(queue_p->in_flight_sem), SEMAPHORE_NO_TIMEOUT);
    cl_spinlock_acquire(&queue_p->queue_lock);

    /* Push entry to queue */
    index = queue_p->work_queue_prod;
    entry = &queue_p->queue_entry[index];

    /*entry = job_info_p;*/
    memcpy(entry, job_info_p, sizeof(sx_work_queuep_job_info_t));

    /* Increment producer */
    err = __work_queue_producer_inc(queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        cl_spinlock_release(&queue_p->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Error increment producer index. queue id [%d]\n", queue_id);
        goto out;
    }

    /* Write wake up message to the event FD */
    wake_up_msg = 1;
    ret = write(queue_p->event_fd, &wake_up_msg, sizeof(wake_up_msg));
    if (ret != sizeof(wake_up_msg)) {
        cl_spinlock_release(&queue_p->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Failed to push job to queue id [%d] cons [%d] prod [%d] size [%d] ret [%zd]. write error [%s].\n",
               queue_id,
               queue_p->work_queue_cons,
               queue_p->work_queue_prod,
               queue_p->work_queue_size,
               ret,
               strerror(errno));
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        queue_p->write_err_cnt++;
        goto out;
    }

    queue_p->write_cnt++;
    cl_spinlock_release(&queue_p->queue_lock);
out:
    return err;
}


sx_work_queuep_status_t sx_work_queue_wake_up_scheduler(const sx_work_queuep_module_id_t module_id)
{
    sx_work_queuep_status_t                            err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                                           qpair_cnt = 0;
    cl_qlist_t                                        *qlist_p = NULL;
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = NULL;
    cl_list_item_t                                    *iter = NULL;
    sx_work_queue_t                                   *queue_p = NULL;
    uint64_t                                           wake_up_msg;
    ssize_t                                            ret = 0;
    sx_work_queue_id_t                                 queue_id;


    /* Validation */
    if (module_id >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "sx_work_queue_wake_up_scheduler Error Unknown module_id [%d]\n", module_id);
        goto out;
    }


    qpair_cnt = cl_qlist_count(&sx_work_queuep_module_info_s[module_id].queue_pair_list);
    if (qpair_cnt == 0) {
        SX_LOG(SX_LOG_ERROR,
               "sx_work_queue_wake_up_scheduler Error empty queue pair list for module_id [%d]\n", module_id);
        goto out;
    }
    qlist_p = &sx_work_queuep_module_info_s[module_id].queue_pair_list;

    /* Return all items in queue pair list and put them back to pool */
    iter = cl_qlist_head(qlist_p);
    item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_queue_pair_list_item_t, list_item);
    queue_id = item_p->qpair_info.queue_id;

    /* Get queue of the module */
    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    cl_spinlock_acquire(&queue_p->queue_lock);

    /* Write wake up message to the event FD */
    wake_up_msg = 1;
    ret = write(queue_p->event_fd, &wake_up_msg, sizeof(wake_up_msg));
    if (ret != sizeof(wake_up_msg)) {
        cl_spinlock_release(&queue_p->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Failed to push job to queue id [%d] cons [%d] prod [%d] size [%d] ret [%zd]. write error [%s].\n",
               queue_id,
               queue_p->work_queue_cons,
               queue_p->work_queue_prod,
               queue_p->work_queue_size,
               ret,
               strerror(errno));
        err = SX_WORK_QUEUEP_STATUS_ERROR;
        queue_p->write_err_cnt++;

        goto out;
    }

    queue_p->write_cnt++;
    cl_spinlock_release(&queue_p->queue_lock);
out:
    return err;
}

sx_work_queuep_status_t __sx_work_queue_pop_peak(boolean_t                  is_pop,
                                                 sx_work_queue_id_t         queue_id,
                                                 sx_work_queuep_job_info_t *job_info_p)
{
    sx_work_queue_t        *queue_p = NULL;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t               is_empty = FALSE;
    uint64_t                buffer;
    ssize_t                 result;


    if (job_info_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Error job_info_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    cl_spinlock_acquire(&queue_p->queue_lock);

    /* Check if queue is not empty */
    err = __work_queue_is_empty(queue_p, &is_empty);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        cl_spinlock_release(&queue_p->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Error checking if work queue is empty. queue id [%d]\n", queue_id);
        goto out;
    }
    if (is_empty == FALSE) {
        /* Lock the queue */

        /* Read item from the queue */
        /* job_info_p = &queue_p->queue_entry[queue_p->work_queue_cons]; */
        memcpy(job_info_p, &queue_p->queue_entry[queue_p->work_queue_cons], sizeof(sx_work_queuep_job_info_t));
        /* check if pop or peak operation */
        if (is_pop == TRUE) {
            /* pop operation, remove item from queue */

            /* Increment module queue producer counter */
            err = __work_queue_consumer_inc(queue_p);
            if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR,
                       "Error increment consumer index. queue id [%d]\n", queue_id);
            }

            cl_semaphore_release(&(queue_p->in_flight_sem));

            /* For completion queues, their event FDs need to be read here.
             * For job queues, their event FDs are read in _module_thread.
             */
            if (queue_p->completion_queue_id == 0) {
                result = read(queue_p->event_fd, &buffer, sizeof(buffer));
                if (result != sizeof(buffer)) {
                    SX_LOG(SX_LOG_ERROR,
                           "__sx_work_queue_pop_peak - Error on read: queue id [%d] fd [%d] errno [%zd] [%s].\n",
                           queue_p->id,
                           queue_p->event_fd,
                           result,
                           strerror(errno));
                    queue_p->read_err_cnt++;
                } else {
                    queue_p->read_cnt++;
                }
            }
        }    /* else this is peak operation */
    } else {
        err = SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND;
    }

    cl_spinlock_release(&queue_p->queue_lock);

out:

    return err;
}

sx_work_queuep_status_t sx_work_queue_pop(sx_work_queue_id_t queue_id, sx_work_queuep_job_info_t *job_info_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t               is_pop = TRUE;


    err = __sx_work_queue_pop_peak(is_pop, queue_id, job_info_p);
    if ((err != SX_WORK_QUEUEP_STATUS_SUCCESS) && (err != SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG(SX_LOG_ERROR,
               "Error pop item from  queue id [%d] err [%s]\n", queue_id, SX_WORK_QUEUEP_STATUS_MSG(err));
        goto out;
    }

out:
    return err;
}

sx_work_queuep_status_t sx_work_queue_peak(sx_work_queue_id_t queue_id, sx_work_queuep_job_info_t *job_info_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t               is_pop = FALSE;


    err = __sx_work_queue_pop_peak(is_pop, queue_id, job_info_p);
    if ((err != SX_WORK_QUEUEP_STATUS_SUCCESS) &&
        (err != SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG(SX_LOG_ERROR,
               "Error peak item from queue id [%d]\n", queue_id);
        goto out;
    }

out:
    return err;
}

/* This function return list of a all module's queues.. */
sx_work_queuep_status_t sx_work_queue_pairs_list_get(sx_work_queuep_module_id_t module_id,
                                                     sx_work_queue_pair_info_t *queue_list_p,
                                                     uint32_t                  *num_of_queues_p)
{
    sx_work_queuep_status_t                            err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                                           qpair_cnt = 0;
    cl_qlist_t                                        *qlist_p = NULL;
    uint32_t                                           cnt = 0;
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = NULL;
    cl_list_item_t                                    *iter = NULL;
    const cl_list_item_t                              *iter_end = NULL;


    SX_LOG_ENTER();

    /* Validation */
    if (module_id >= SX_WORK_QUEUEP_MAX_MODULE_ID) {
        err = SX_WORK_QUEUEP_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Error Unknown module_id [%d]\n", module_id);
        goto out;
    }

    if (num_of_queues_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Error num_of_queues_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    qpair_cnt = cl_qlist_count(&sx_work_queuep_module_info_s[module_id].queue_pair_list);
    if (*num_of_queues_p == 0) {
        /* return number of queues */
        *num_of_queues_p = qpair_cnt;
        goto out;
    }

    if (queue_list_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Error queue_list_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    qlist_p = &sx_work_queuep_module_info_s[module_id].queue_pair_list;

    /* Return all items in queue pair list and put them back to pool */
    iter = cl_qlist_head(qlist_p);
    iter_end = cl_qlist_end(qlist_p);

    for (; iter != iter_end; iter = cl_qlist_next(iter)) {
        item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_queue_pair_list_item_t, list_item);
        memcpy(&queue_list_p[cnt], &item_p->qpair_info, sizeof(queue_list_p[cnt]));

        cnt++;
        /* check if we reached max items of queue_list_p */
        if (cnt == *num_of_queues_p) {
            break;
        }
    }

    *num_of_queues_p = cnt;

out:
    SX_LOG_EXIT();
    return err;
}

/* Increment producer index */
sx_work_queuep_status_t __work_queue_producer_inc(sx_work_queue_t *queue_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    /* Increment producer */
    queue_p->work_queue_prod = (queue_p->work_queue_prod + 1) % queue_p->work_queue_size;


    return err;
}

/* Increment consumer index */
sx_work_queuep_status_t __work_queue_consumer_inc(sx_work_queue_t *queue_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    queue_p->work_queue_cons = (queue_p->work_queue_cons + 1) % queue_p->work_queue_size;


    return err;
}


sx_work_queuep_status_t __work_queue_is_empty(sx_work_queue_t *queue_p, boolean_t *is_empty_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    *is_empty_p = TRUE;

    /* Check if queue is not empty */
    if (queue_p->work_queue_cons != queue_p->work_queue_prod) {
        *is_empty_p = FALSE;
    }

    return err;
}

sx_work_queuep_status_t __work_queue_cnt_get(sx_work_queue_t *queue_p, uint32_t* queue_cnt_p)
{
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t               is_full = TRUE;
    uint32_t                size = 0;

    if (queue_p->work_queue_cons != (queue_p->work_queue_prod + 1) % queue_p->work_queue_size) {
        is_full = FALSE;
    }

    if (is_full == FALSE) {
        if (queue_p->work_queue_prod >= queue_p->work_queue_cons) {
            size = queue_p->work_queue_prod - queue_p->work_queue_cons;
        } else {
            size = (queue_p->work_queue_size + queue_p->work_queue_prod - queue_p->work_queue_cons);
        }
    } else {
        size = queue_p->work_queue_size;
    }

    *queue_cnt_p = size;

    return err;
}


sx_work_queuep_status_t sx_work_queue_size_get(sx_work_queue_id_t queue_id, uint32_t *size_p)
{
    sx_work_queue_t        *queue_p = NULL;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (size_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "sx_work_queue_is_empty Error is_empty_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    *size_p = 0;

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_NOTICE,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }
    *size_p = queue_p->work_queue_size;


out:
    SX_LOG_EXIT();
    return err;
}

sx_work_queuep_status_t sx_work_queue_is_empty(sx_work_queue_id_t queue_id, boolean_t *is_empty_p)
{
    sx_work_queue_t        *queue_p = NULL;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;


    if (is_empty_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "sx_work_queue_is_empty Error is_empty_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    *is_empty_p = TRUE;

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        if (queue_in_deinit_flow[queue_id] == TRUE) {
            err = SX_WORK_QUEUEP_STATUS_SUCCESS;
        } else {
            SX_LOG(SX_LOG_ERROR,
                   "Error getting work queue from queue id [%d]\n", queue_id);
        }

        goto out;
    }

    cl_spinlock_acquire(&queue_p->queue_lock);

    err = __work_queue_is_empty(queue_p, is_empty_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        cl_spinlock_release(&queue_p->queue_lock);
        SX_LOG(SX_LOG_ERROR,
               "Error checking if work queue is empty. queue id [%d]\n", queue_id);
        goto out;
    }

    cl_spinlock_release(&queue_p->queue_lock);
out:

    return err;
}

/**
 *  This function retrieves a job info queue list
 *  The following use case scenarios apply with different input parameters
 *  X = don't-care
 *   - 1) cmd = SX_ACCESS_CMD_GET, key = X, key_list = X
 *        key_cnt = 0:
 *        In this case the API will return the total number of jobs in the queue.
 *
 *   - 2) cmd = SX_ACCESS_CMD_GET, swid = valid, key = valid/invalid, filter = valid/invalid,
 *        key_list = valid, key_cnt = 1:
 *        The queue job key will be returned in the key_list along with a key_cnt of 1 in the
 *        following conditions:
 *            a) the key exists, a filter is provided and the key matches the filter
 *            b) the key exists, no filter is provided
 *        An empty list will be returned with key_cnt = 0 in the following conditions:
 *            a) the key doesn't exist
 *            b) the key exists, a filter is provided and the key doesn't match the filter
 *        A non-NULL key_list pointer must be provided in this case.
 *
 *   - 3) cmd = SX_ACCESS_CMD_GET, swid = valid, key = valid/invalid, filter = valid/invalid,
 *        key_list = valid, job_info_cnt_p > 1:
 *        An key_cnt > 1 will be treated as a key_cnt of 1 and the behavior will be
 *        same as the earlier GET use cases.
 *
 *   - 4) cmd = SX_ACCESS_CMD_GET_FIRST/SX_ACCESS_CMD_GETNEXT, swid = X, key = X,
 *        filter = X, key_list = NULL, job_info_cnt_p = 0:
 *        A zero key_cnt and an empty key_list will be returned.
 *
 *   - 5) cmd = SX_ACCESS_CMD_GET_FIRST, swid = valid, key = X, filter = valid/invalid,
 *        key_list = valid, key_cnt > 0:
 *        In this case the API will return a list of jobs (max job_info_cnt_p) starting
 *        with first key of the internal DB and matching the filter if present. The input
 *        MC MAC key is ignored in this case.
 *        A non-NULL key_list pointer must be provided in this case.
 *
 *   - 6) cmd = SX_ACCESS_CMD_GETNEXT, swid = valid, key = valid/invalid, filter = valid/invalid,
 *        key_list = valid, key_cnt > 0:
 *        In this case the API will return a list of jobs (max job_info_cnt_p) starting with
 *        the next key after the input key and matching the filter if present.
 *        A non-NULL key_list pointer must be provided in this case.
 */
sx_work_queuep_status_t sx_work_queue_iter_get(const sx_work_queuep_cmd_t   cmd,
                                               sx_work_queue_id_t           queue_id,
                                               sx_work_queuep_job_type_id_t key,
                                               sx_work_queuep_job_info_t   *job_info_list_p,
                                               uint32_t                    *job_info_cnt_p)
{
    sx_work_queuep_status_t    err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_t            queue;
    sx_work_queue_t           *queue_p = NULL;
    sx_work_queue_t           *orig_queue_p = NULL;
    uint32_t                   j = 0;
    uint32_t                   queue_cnt = 0;
    uint32_t                   idx = 0;
    boolean_t                  is_empty = FALSE;
    sx_work_queuep_job_info_t *job_info_p = NULL;
    uint32_t                   i = 0;
    boolean_t                  found_key = FALSE;

    SX_LOG_ENTER();

    memset(&queue, 0x0, sizeof(queue));
    queue_p = &queue;
    /* In order to be thread safe we clone the queue:
     *  1. Lock the queue
     *  2. clone the queue */
    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &orig_queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    cl_spinlock_acquire(&orig_queue_p->queue_lock);
    memcpy(queue_p, orig_queue_p, sizeof(*queue_p));
    cl_spinlock_release(&orig_queue_p->queue_lock);

    /* copy queue */
    queue_p->queue_entry = cl_malloc(sizeof(sx_work_queuep_job_info_t) * (queue_p->work_queue_size));
    if (queue_p->queue_entry == NULL) {
        err = SX_WORK_QUEUEP_STATUS_NO_MEMORY;
        SX_LOG_ERR("Error allocating queue entries err [%d]-[%s]\n", err, SX_WORK_QUEUEP_STATUS_MSG(err));
        goto out;
    }


    /* In order to be thread safe we clone the queue */
    if (job_info_cnt_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Error job_info_cnt_p parameter is null!\n");
        err = SX_WORK_QUEUEP_STATUS_PARAM_NULL;
        goto out;
    }

    err = __work_queue_is_empty(queue_p, &is_empty);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error checking if work queue is empty!!\n");
        goto out;
    }
    if (is_empty == FALSE) {
        err = __work_queue_cnt_get(queue_p, &queue_cnt);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Error checking work queue count!\n");
            goto out;
        }
    }

    switch (cmd) {
    case SX_WORK_QUEUEP_CMD_GET:
        if (*job_info_cnt_p == 0) {
            /*In this case the API will return the total number of jobs in the queue.*/
            *job_info_cnt_p = queue_cnt;
            goto out;
        }
        /*        The queue job key will be returned in the key_list along with a key_cnt of 1 in the
         *        following conditions:
         *            a) the key exists, a filter is provided and the key matches the filter
         *            b) the key exists, no filter is provided
         *        An empty list will be returned with key_cnt = 0 in the following conditions:
         *            a) the key doesn't exist
         *            b) the key exists, a filter is provided and the key doesn't match the filter
         *        A non-NULL key_list pointer must be provided in this case.*/

        /*An key_cnt > 1 will be treated as a key_cnt of 1 and the behavior will be*/
        /* lookup for key */
        *job_info_cnt_p = 0;
        if (is_empty == FALSE) {
            idx = queue_p->work_queue_cons;
            i = 0;
            /* This is thread safe since we cloned the queue at start of the function*/
            for (i = 0; i < queue_cnt; i++) {
                job_info_p = &queue_p->queue_entry[idx];

                if (job_info_p->job_type_id == key) {
                    memcpy(&job_info_list_p[i], job_info_p, sizeof(*job_info_p));
                    /* Found key */
                    *job_info_cnt_p = 1;
                    break;
                }
                idx = (idx + 1) % queue_p->work_queue_size;
            }
        }
        break;

    case SX_WORK_QUEUEP_CMD_GET_COUNT:
        *job_info_cnt_p = queue_cnt;
        goto out;
        break;

    /*   - 5) cmd = SX_ACCESS_CMD_GET_FIRST, swid = valid, key = X, filter = valid/invalid,
     *        key_list = valid, key_cnt > 0:
     *        In this case the API will return a list of MC MAC keys (max key_cnt) starting
     *        with first key of the internal DB and matching the filter if present. The input
     *        MC MAC key is ignored in this case.
     *        A non-NULL key_list pointer must be provided in this case.*/
    case SX_WORK_QUEUEP_CMD_GET_FIRST:
        *job_info_cnt_p = 0;
        if (is_empty == FALSE) {
            idx = queue_p->work_queue_cons;
            i = 0;
            for (i = 0; i < queue_cnt; i++) {
                if (i == *job_info_cnt_p) {
                    break;
                }
                job_info_p = &queue_p->queue_entry[idx];
                memcpy(&job_info_list_p[i], job_info_p, sizeof(*job_info_p));
                idx = (idx + 1) % queue_p->work_queue_size;
            }
            *job_info_cnt_p = i;
        }
        break;

    /*   - 6) cmd = SX_ACCESS_CMD_GETNEXT, swid = valid, key = valid/invalid, filter = valid/invalid,
     *        key_list = valid, key_cnt > 0:
     *        In this case the API will return a list of jobs (max key_cnt) starting with
     *        the next key after the input key and matching the filter if present.
     *        A non-NULL key_list pointer must be provided in this case.*/
    case SX_WORK_QUEUEP_CMD_GET_NEXT:
        *job_info_cnt_p = 0;
        if (is_empty == FALSE) {
            idx = queue_p->work_queue_cons;
            i = 0;
            j = 0;
            found_key = FALSE;

            for (i = 0; i < queue_cnt; i++) {
                if (j == *job_info_cnt_p) {
                    break;
                }
                job_info_p = &queue_p->queue_entry[idx];
                if (found_key == FALSE) {
                    if (job_info_p->job_type_id == key) {
                        found_key = TRUE;
                    }
                } else {
                    /* key found. start filling the array */
                    memcpy(&job_info_list_p[j], job_info_p, sizeof(*job_info_p));
                    j++;
                }

                idx = (idx + 1) % queue_p->work_queue_size;
            }
            *job_info_cnt_p = j;
        }
        break;

    default:
        err = SX_WORK_QUEUEP_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR,
               "Error unexpected cmd [%d]\n", cmd);
        goto out;
    }

out:
    /* Free resource of cloned queue */
    if (queue_p->queue_entry != NULL) {
        cl_free(queue_p->queue_entry);
    }

    SX_LOG_EXIT();
    return err;
}

sx_work_queuep_status_t sx_work_queuep_wait_on_queue(sx_work_queue_id_t queue_id)
{
    sx_work_queue_t        *queue_p = NULL;
    cl_status_t             cl_err = CL_SUCCESS;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    /* Wait till event is signaled */
    cl_err = cl_event_wait_on(&(queue_p->work_queue_event), EVENT_NO_TIMEOUT, TRUE);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error at work queue event wait\n");
        goto out;
    }

out:
    return err;
}

sx_work_queuep_status_t sx_work_queuep_wake_up_queue(sx_work_queue_id_t queue_id)
{
    sx_work_queue_t        *queue_p = NULL;
    cl_status_t             cl_err = CL_SUCCESS;
    sx_work_queuep_status_t err = SX_WORK_QUEUEP_STATUS_SUCCESS;

    err = sx_work_queuep_db_queue_id_to_work_queue_mapping_get(queue_id, &queue_p);
    if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error getting work queue from queue id [%d]\n", queue_id);
        goto out;
    }

    /* Signal to to wake up */
    cl_err = cl_event_signal(&(queue_p->work_queue_event));
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error at work queue event signal\n");
        goto out;
    }

out:
    return err;
}

void sx_work_queuep_build_job_cb_info(sx_work_queuep_job_info_t    *job_info_p,
                                      sx_work_queuep_job_cb_info_t* job_cb_info_out_p)
{
    job_cb_info_out_p->job_data = job_info_p->job_data;
    job_cb_info_out_p->context = job_info_p->job_handler_cb_context;
    job_cb_info_out_p->infra_internal_ctx = (void*)job_info_p;
}


sx_work_queuep_status_t sx_work_queuep_module_qpair_list_item_delete(sx_work_queuep_module_id_t module,
                                                                     sx_work_queue_id_t         queue_id)
{
    sx_work_queuep_module_info_queue_pair_list_item_t *item_p = NULL;
    cl_list_item_t                                    *iter = NULL;
    cl_list_item_t                                    *list_item = NULL;
    sx_work_queuep_status_t                            err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queue_id_t                                 tmp_queue_id;
    cl_qlist_t                                        *qlist_p = &sx_work_queuep_module_info_s[module].queue_pair_list;
    cl_qpool_t                                        *qpool_p =
        &sx_work_queuep_module_info_s[module].queue_pair_list_pool;


    /* Remove all items in queue pair list and put them back to pool */
    iter = cl_qlist_head(qlist_p);

    while (iter != cl_qlist_end(qlist_p)) {
        item_p = PARENT_STRUCT(iter, sx_work_queuep_module_info_queue_pair_list_item_t, list_item);
        list_item = iter;
        iter = cl_qlist_next(iter);

        /* Deinit queue id */
        tmp_queue_id = item_p->qpair_info.queue_id;
        if (tmp_queue_id != queue_id) {
            continue;
        }
        err = __sx_work_queuep_deinit_queue(tmp_queue_id);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Error deinit queue id [%d]\n", tmp_queue_id);
            goto out;
        }
        /* Destroy completion queue */
        tmp_queue_id = item_p->qpair_info.completion_queue_id;
        err = __sx_work_queuep_deinit_queue(tmp_queue_id);
        if (err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Error deinit completion queue id [%d]\n", tmp_queue_id);
            goto out;
        }


        cl_qlist_remove_item(qlist_p, list_item);
        cl_qpool_put(qpool_p, &(item_p->pool_item));
    }

out:
    return err;
}
