/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HASH_CALC_LIB_H__
#define __HASH_CALC_LIB_H__

#include <stdint.h>

typedef struct _hash_calc_packet {
    uint8_t  smac[6];
    uint8_t  dmac[6];
    uint16_t ethertype;
    uint16_t vid;
    uint8_t  pcp;
    uint8_t  dei;
    uint16_t inner_vid;
    uint8_t  inner_pcp;
    uint8_t  inner_dei;
    uint8_t  ip_version;
    uint8_t  sip[16];
    uint8_t  dip[16];
    uint8_t  arp_spa[4];
    uint8_t  arp_tpa[4];
    uint8_t  ipv4_proto;
    uint8_t  next_header;
    uint32_t flow_label;
    uint8_t  mflag;
    uint8_t  dscp;
    uint8_t  ecn;
    uint16_t l3_length;
    uint32_t mpls_labels[6];
    uint8_t  mpls_stack_size;
    uint16_t sport;
    uint16_t dport;
    uint32_t vni;
    uint16_t gre_proto;
    uint32_t gre_key;
    uint8_t  inner_smac[6];
    uint8_t  inner_dmac[6];
    uint16_t inner_ethertype;
    uint8_t  inner_ip_version;
    uint8_t  inner_sip[16];
    uint8_t  inner_dip[16];
    uint8_t  inner_ipv4_proto;
    uint8_t  inner_next_header;
    uint32_t inner_flow_label;
    uint8_t  inner_mflag;
    uint16_t inner_sport;
    uint16_t inner_dport;
} hash_calc_packet_t;

typedef struct _hash_calc_packet_meta {
    uint16_t local_port;
    uint8_t  custom_bytes[16];
} hash_calc_packet_meta_t;

typedef enum _hash_calc_asic_type {
    HASH_CALC_ASIC_TYPE_SPC_1_E,
    HASH_CALC_ASIC_TYPE_SPC_2_E,
    HASH_CALC_ASIC_TYPE_SPC_3_E,
    HASH_CALC_ASIC_TYPE_SPC_4_E,
    HASH_CALC_ASIC_TYPE_SPC_5_E,
} hash_calc_asic_type_e;

typedef struct _hash_calc_extra_info {
    hash_calc_asic_type_e asic;
    uint32_t              size;
    uint16_t              nve_udp_dport;
    uint16_t              pvid;
} hash_calc_extra_info_t;

typedef struct _hash_calc_hash_result {
    uint32_t value;
    uint32_t index;
    uint32_t lag_mc_index;
} hash_calc_hash_result_t;

typedef enum _hash_calc_hash_type {
    HASH_CALC_HASH_TYPE_CRC_E,
    HASH_CALC_HASH_TYPE_XOR_E,
    HASH_CALC_HASH_TYPE_RANDOM_E,
    HASH_CALC_HASH_TYPE_CRC2_E
} hash_calc_hash_type_t;

/* Follows RECR_V2 and SLCR_V2 */
typedef struct _hash_calc_hash_config {
    uint8_t               sh;                   /**< sh - Symmetric Hash */
    hash_calc_hash_type_t type;                 /**< type - Hash Type */
    uint32_t              seed;                 /**< seed - seed value */
    uint32_t              general_fields;       /**< general_fields - bitmask enabling fields */
    uint16_t              outer_header_enables;
    uint32_t              outer_header_fields_enable[5];
    uint16_t              inner_header_enables;
    uint64_t              inner_header_fields_enable;
} hash_calc_hash_config_t;

typedef struct _hash_calc_rehash_param {
    hash_calc_hash_type_t type;                 /**< type - Hash Type */
    uint32_t              seed;                 /**< seed - seed value */
    uint32_t              old_hash_value;
} hash_calc_rehash_param_t;

typedef enum _hash_calc_log_level {
    HASH_CALC_LOG_LEVEL_ERROR,               /**<! Print only error messages               */
    HASH_CALC_LOG_LEVEL_WARNING,             /**<! Print only warning messages             */
    HASH_CALC_LOG_LEVEL_NOTICE,              /**<! Print only notice messages              */
    HASH_CALC_LOG_LEVEL_INFO,                /**<! Print only information messages         */
    HASH_CALC_LOG_LEVEL_DEBUG,               /**<! Print only debug messages               */
} hash_calc_log_level_t;

int hash_calc_ecmp_hash(const hash_calc_hash_config_t *hash_config_p,
                        const hash_calc_packet_t      *packet_p,
                        const hash_calc_packet_meta_t *packet_meta_p,
                        const hash_calc_extra_info_t  *extra_info_p,
                        hash_calc_hash_result_t       *hash_result_p);

int hash_calc_lag_hash(const hash_calc_hash_config_t *hash_config_p,
                       const hash_calc_packet_t      *packet_p,
                       const hash_calc_packet_meta_t *packet_meta_p,
                       const hash_calc_extra_info_t  *extra_info_p,
                       hash_calc_hash_result_t       *hash_result_p);

int hash_calc_rehash(const hash_calc_rehash_param_t *rehash_param_p,
                     const hash_calc_extra_info_t   *extra_info_p,
                     hash_calc_hash_result_t        *hash_result_p);

int hash_calc_set_log_level(hash_calc_log_level_t level);

#endif /* ifndef __HASH_CALC_LIB_H__ */
