#!/usr/bin/env python3

import os
import sys
import argparse
from python_sdk_api.sx_api import *
import json
import ipaddress
import subprocess
import socket
import struct

type_dict = {0: 'VLAN', 1: 'PORT_VLAN', 2: 'VPORT', 3: 'PKEY', 4: 'BRIDGE_PORT', 5: 'BRIDGE', 6: 'LOOPBACK'}
swid = 0

hash_calculator_tool_file_path = '/usr/bin/sx_hash_calculator'
hash_calculator_tool_input_file_path = "/tmp/hash_calculator_input.json"
hash_calculator_tool_output_file_path = "/tmp/hash_calculator_output.json"

packet_dict = {}

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def get_port_type(port_id):
    return (port_id & 0xF0000000) >> 28


def get_vlan_id_from_vport(port_id):
    return (port_id & 0x0FFF0000) >> 16


def get_port_id_from_vport(port_id):
    ret_port = port_id & 0x000003FF
    ret_port = ret_port | (1 << 16)
    return ret_port


def get_lag_id_from_vlag(port_id):
    ret_port = port_id & 0x000003FF
    ret_port = ret_port | (1 << 28)
    return ret_port


def get_local_port_from_port(port_id):
    return (port_id & 0x000003FF)


def get_ip_type(address):
    ip_version = 0
    try:
        ip = ipaddress.ip_address(address)
        ip_version = ip.version
    except ValueError:
        print("{} is an invalid IP address".format(address))

    return ip_version


def __packet_to_hash_calculator_tool_dict(packet):
    dictionary = {"outer": {}}

    dictionary["outer"]["layer2"] = {}
    dictionary["outer"]["layer2"]["smac"] = "00:01:02:03:04:05"
    dictionary["outer"]["layer2"]["dmac"] = "00:01:02:03:04:06"

    sip_version = get_ip_type(packet["sip"])
    dip_version = get_ip_type(packet["dip"])

    if sip_version != dip_version:
        print("sip and dip are diffrent ip version")
        return dictionary

    if sip_version == 4:
        dictionary["outer"]["ipv4"] = {}
        dictionary["outer"]["layer2"]["ethertype"] = 0x0800
        dictionary["outer"]["ipv4"]["sip"] = packet["sip"]
        dictionary["outer"]["ipv4"]["dip"] = packet["dip"]
        dictionary["outer"]["ipv4"]["proto"] = packet["proto"]

    if sip_version == 6:
        dictionary["outer"]["ipv6"] = {}
        dictionary["outer"]["layer2"]["ethertype"] = 0x86DD
        dictionary["outer"]["ipv6"]["sip"] = packet["sip"]
        dictionary["outer"]["ipv6"]["dip"] = packet["dip"]
        dictionary["outer"]["ipv6"]["next_header"] = packet["proto"]

    dictionary["outer"]["tcp_udp"] = {}
    dictionary["outer"]["tcp_udp"]["sport"] = packet["sport"]
    dictionary["outer"]["tcp_udp"]["dport"] = packet["dport"]

    return dictionary


def __hash_calculator(input_dict):
    """
    Args:
        input_dict: a dictionary. Input for the hash calculator tool

    Returns:
        a dictionary. Output of the hash calculator tool
    """
    with open(hash_calculator_tool_input_file_path, "w") as outfile:
        json.dump(input_dict, outfile)

    cmd = "{} -c {} -o {}".format(hash_calculator_tool_file_path,
                                  hash_calculator_tool_input_file_path,
                                  hash_calculator_tool_output_file_path)

    out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True, text=True, timeout=10).strip()

    print(out)

    with open(hash_calculator_tool_output_file_path, 'r') as openfile:
        output_dict = json.loads(openfile.read())

    return output_dict


def ecmp_hash_calculator(ingress_port, packet, ecmp_size):
    ecmp_hash = {
        "ingress_port": ingress_port,
        "packet_info": __packet_to_hash_calculator_tool_dict(packet),
        "ecmp_size": ecmp_size,
    }

    hash_result = __hash_calculator({"ecmp_hash": ecmp_hash})
    ecmp_hash_result = hash_result["ecmp_hash"]

    return ecmp_hash_result["hash_value"], ecmp_hash_result.get("ecmp_index", None)


def lag_hash_calculator(ingress_port, packet, lag_size):
    lag_hash = {
        "ingress_port": ingress_port,
        "packet_info": __packet_to_hash_calculator_tool_dict(packet),
        "lag_size": lag_size,
    }

    hash_result = __hash_calculator({"lag_hash": lag_hash})
    lag_hash_result = hash_result["lag_hash"]

    return lag_hash_result["hash_value"], lag_hash_result.get("lag_index", None), lag_hash_result.get("lag_mc_index", None)


def get_bridge_vports(bridge_id):
    vports = []
    bridge_vport_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(bridge_vport_cnt_p, 0)
    rc = sx_api_bridge_vport_get(handle, bridge_id, None, bridge_vport_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_bridge_vport_get failed, rc = %d" % (rc))
        sys.exit(rc)
    bridge_vport_cnt = uint32_t_p_value(bridge_vport_cnt_p)
    bridge_vport_list_p = new_sx_port_log_id_t_arr(bridge_vport_cnt)
    rc = sx_api_bridge_vport_get(handle, bridge_id, bridge_vport_list_p, bridge_vport_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_bridge_vport_get failed, rc = %d" % (rc))
        sys.exit(rc)
    bridge_vport_cnt = uint32_t_p_value(bridge_vport_cnt_p)

    for i in range(0, bridge_vport_cnt):
        vport = sx_port_log_id_t_arr_getitem(bridge_vport_list_p, i)
        vports.append(vport)

    return vports, bridge_vport_cnt


def get_vlan_ports(vid):
    ports = []
    port_cnt_p = new_uint32_t_p()
    rc = sx_api_vlan_ports_get(handle, swid, vid, None, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)
    vlan_port_list_p = new_sx_vlan_ports_t_arr(port_cnt)

    rc = sx_api_vlan_ports_get(handle, swid, vid, vlan_port_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)

    for i in range(0, port_cnt):
        vlan_port = sx_vlan_ports_t_arr_getitem(vlan_port_list_p, i)
        ports.append(vlan_port.log_port)

    return ports, port_cnt


def get_router_interface(ingress_port, vid, dmac):
    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, 0)
    ifc_param_p = sx_router_interface_param_t()
    ifc_attr_p = sx_interface_attributes_t()
    ifc_state_p = sx_router_interface_state_t()
    rif_cnt_p = new_uint32_t_p()

    uint32_t_p_assign(rif_cnt_p, 0)
    rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, rif_cnt_p)
    if rc == SX_STATUS_MODULE_UNINITIALIZED:
        print("The router module is not initialized.")
        sys.exit(0)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rif_cnt = uint32_t_p_value(rif_cnt_p)

    rif_list_p = new_sx_router_interface_t_arr(rif_cnt)
    rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, None, None, rif_list_p, rif_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rif_cnt = uint32_t_p_value(rif_cnt_p)

    for i in range(0, rif_cnt):
        rif = sx_router_interface_t_arr_getitem(rif_list_p, i)
        rc1 = sx_api_router_interface_get(handle, rif, vrid_p, ifc_param_p, ifc_attr_p)
        if rc1 == SX_STATUS_MODULE_UNINITIALIZED:
            print("# Router is not initialized ")
            sys.exit()
        rc2 = sx_api_router_interface_state_get(handle, rif, ifc_state_p)
        vrid = sx_router_id_t_p_value(vrid_p)
        ifc_param = sx_router_interface_param_t_p_value(ifc_param_p)
        ifc_attr = sx_interface_attributes_t_p_value(ifc_attr_p)
        ifc_state = sx_router_interface_state_t_p_value(ifc_state_p)
        mac = ifc_attr.mac_addr.to_str()

        if (rc1 == 0 and rc2 == 0 and dmac == mac):
            type = type_dict[ifc_param.type]

            if (type == "VLAN"):
                vlan = ifc_param.ifc.vlan.vlan
                if vlan == vid:
                    return rif, vrid
            elif (type == "PORT_VLAN"):
                port = ifc_param.ifc.port_vlan.port
                vlan = ifc_param.ifc.port_vlan.vlan
                if port == ingress_port and vlan == vid:
                    return rif, vrid
            elif (type == "VPORT"):
                vport = ifc_param.ifc.vport.vport
                port = get_port_id_from_vport(vport)
                vlan = get_vlan_id_from_vport(vport)
                if port == ingress_port and vlan == vid:
                    return rif, vrid
            elif (type == "BRIDGE"):
                swid = ifc_param.ifc.bridge.swid
                bridge = ifc_param.ifc.bridge.bridge
                vport_arr, vport_cnt = get_bridge_vports(bridge)
                for vport in vport_arr:
                    port = get_port_id_from_vport(vport)
                    vlan = get_vlan_id_from_vport(vport)
                    if port == ingress_port and vlan == vid:
                        return rif, vrid
            else:
                print("Rif type is not supported")
                sys.exit()

    print("Failed to get ingress router interface")
    sys.exit()


def ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))
    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]
    # Finally, convert back to bytes
    out = struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])
    return [i for i in out]


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "
    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "
    addr = ipv6_str_to_bytes(str(addr))
    mask = ipv6_str_to_bytes(str(mask))

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


def ip_addr_to_str(ip_addr):
    if ip_addr.version == SX_IP_VERSION_IPV4:
        return socket.inet_ntop(socket.AF_INET, struct.pack('!I', ip_addr.addr.ipv4.s_addr))
    else:
        bytes = ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8
        byte_arr = []
        for i in range(0, 16):
            byte_arr.append(uint8_t_arr_getitem(bytes, i))
        if sys.byteorder == "little":
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[3], byte_arr[2], byte_arr[1], byte_arr[0], byte_arr[7], byte_arr[6], byte_arr[5], byte_arr[4], byte_arr[11], byte_arr[10], byte_arr[9], byte_arr[8], byte_arr[15], byte_arr[14], byte_arr[13], byte_arr[12])
        else:
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[0], byte_arr[1], byte_arr[2], byte_arr[3], byte_arr[4], byte_arr[5], byte_arr[6], byte_arr[7], byte_arr[8], byte_arr[9], byte_arr[10], byte_arr[11], byte_arr[12], byte_arr[13], byte_arr[14], byte_arr[15])
        return socket.inet_ntop(socket.AF_INET6, dwords)


def get_uc_route(vrid, dip):
    ip = ipaddress.ip_address(dip)
    ip_int = int(ip)

    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    uc_route_arr = new_sx_uc_route_get_entry_t_arr(1)

    network_addr = sx_ip_prefix_t()
    network_addr_p = new_sx_ip_prefix_t_p()

    if ip.version == 4:
        mask = 0xFFFFFFFF
        network_addr.version = SX_IP_VERSION_IPV4
        # Prefix len can be 0 to 32
        for i in range(0, 33):
            network_addr = make_sx_ip_prefix_v4(str(ipaddress.IPv4Address(ip_int)), str(ipaddress.IPv4Address(mask)))
            mask = mask & ~(1 << i)
            ip_int = ip_int & mask
            sx_ip_prefix_t_p_assign(network_addr_p, network_addr)
            rc = sx_api_router_uc_route_get(handle, SX_ACCESS_CMD_GET, vrid, network_addr_p, None, uc_route_arr, data_cnt_p)
            if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
                print("sx_api_router_uc_route_get failed")
                sys.exit(rc)
            data_cnt = uint32_t_p_value(data_cnt_p)
            if rc == SX_STATUS_SUCCESS and data_cnt == 1:
                uc_route = sx_uc_route_get_entry_t_arr_getitem(uc_route_arr, 0)
                return uc_route
    else:
        mask = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
        network_addr.version = SX_IP_VERSION_IPV6
        # Prefix len can be 0 to 128
        for i in range(0, 129):
            network_addr = make_sx_ip_prefix_v6(str(ipaddress.IPv6Address(ip_int)), str(ipaddress.IPv6Address(mask)))
            mask = mask & ~(1 << i)
            ip_int = ip_int & mask
            sx_ip_prefix_t_p_assign(network_addr_p, network_addr)
            rc = sx_api_router_uc_route_get(handle, SX_ACCESS_CMD_GET, vrid, network_addr_p, None, uc_route_arr, data_cnt_p)
            if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
                print("sx_api_router_uc_route_get failed")
                sys.exit(rc)
            data_cnt = uint32_t_p_value(data_cnt_p)
            if rc == SX_STATUS_SUCCESS and data_cnt == 1:
                uc_route = sx_uc_route_get_entry_t_arr_getitem(uc_route_arr, 0)
                return uc_route

    print("Failed to get uc route")
    sys.exit()


def get_next_hops(vrid, dip):
    next_hops = []
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 4096)
    next_hop_arr = new_sx_next_hop_t_arr(4096)

    uc_route = get_uc_route(vrid, dip)

    if uc_route is not None:
        if uc_route.route_data.type == SX_UC_ROUTE_TYPE_NEXT_HOP:
            ecmp_id = uc_route.route_data.uc_route_param.ecmp_id

        rc = sx_api_router_operational_ecmp_get(handle, ecmp_id, next_hop_arr, next_hop_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get operational ecmp")
            sys.exit()
        next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)

        for i in range(0, next_hop_cnt):
            nh = sx_next_hop_t_arr_getitem(next_hop_arr, i)
            next_hops.append(nh)

    return next_hops


def get_ports_from_fdb(type, fid, dmac):
    ports = []
    flood = False

    mac_entry_arr = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    key_p = new_sx_fdb_uc_mac_addr_params_t_p()
    key_filter_p = new_sx_fdb_uc_key_filter_t_p()
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    key_p.fid_vid = fid
    key_p.mac_addr = dmac

    if type == "VLAN" or type == "BRIDGE":
        rc = sx_api_fdb_uc_mac_addr_get(handle, swid, SX_ACCESS_CMD_GET, SX_FDB_UC_ALL, key_p, key_filter_p, mac_entry_arr, data_cnt_p)
        if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
            print("sx_api_fdb_uc_mac_addr_get failed, rc = %d" % (rc))
            sys.exit(rc)

        data_cnt = uint32_t_p_value(data_cnt_p)
        if rc == SX_STATUS_ENTRY_NOT_FOUND or data_cnt == 0:
            print("No FDB entries found, packet will be flood to all ports in fid {}".format(fid))
            flood = True
            if type == "VLAN":
                ports, port_cnt = get_vlan_ports(fid)
            else:
                vport_arr, vport_cnt = get_bridge_vports(fid)
                for vport in vport_arr:
                    port = get_port_id_from_vport(vport)
                    ports.append(port)
        else:
            mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, 0)
            if mac_entry.dest_type != SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT:
                print("MAC entry destination is {}, not logical port".format(mac_entry.dest_type))
            if type == "VLAN":
                port = mac_entry.log_port
            else:
                port = get_port_id_from_vport(mac_entry.log_port)
            ports = [port]

    return ports, flood


def get_neighbor(rif, addr):
    neighbors = []
    neigh_entry_arr = new_sx_neigh_get_entry_t_arr(1)
    neigh_key_p = new_sx_ip_addr_t_p()
    neigh_key = addr

    sx_ip_addr_t_p_assign(neigh_key_p, neigh_key)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)

    rc = sx_api_router_neigh_get(handle, SX_ACCESS_CMD_GET, rif, neigh_key_p, None, neigh_entry_arr, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        # check if router module initialize
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("# Router is not initialized ")
            sys.exit(0)
        if rc == SX_STATUS_ENTRY_NOT_FOUND:
            print("Failed to get neighbor entry for destination ip {}".format(ip_addr_to_str(addr)))
            sys.exit(0)
        print("An error was found in sx_api_router_neigh_get. rc: %d" % (rc))
        sys.exit(rc)

    if data_cnt != 1:
        print("Failed to get neighbor entry for destination ip {}".format(ip_addr_to_str(addr)))
        sys.exit(rc)

    neigh_entry = sx_neigh_get_entry_t_arr_getitem(neigh_entry_arr, 0)

    return neigh_entry


def get_ecmp_egress_ports(vrid, next_hop):
    egress_ports = []
    flood = False
    egress_rif = next_hop.next_hop_key.next_hop_key_entry.ip_next_hop.rif
    addr = next_hop.next_hop_key.next_hop_key_entry.ip_next_hop.address
    print("Egress rif: {}".format(egress_rif))

    neigh = get_neighbor(egress_rif, addr)
    dmac = neigh.neigh_data.mac_addr

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    ifc_param_p = sx_router_interface_param_t()
    ifc_attr_p = sx_interface_attributes_t()

    rc = sx_api_router_interface_get(handle, egress_rif, vrid_p, ifc_param_p, ifc_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to get router interface information")
        sys.exit(rc)

    ifc_param = sx_router_interface_param_t_p_value(ifc_param_p)
    ifc_attr = sx_interface_attributes_t_p_value(ifc_attr_p)

    type = type_dict[ifc_param.type]

    if (type == "VLAN"):
        vlan = ifc_param.ifc.vlan.vlan
        egress_ports, flood = get_ports_from_fdb(type, vlan, dmac)

    elif (type == "PORT_VLAN"):
        port = ifc_param.ifc.port_vlan.port
        vlan = ifc_param.ifc.port_vlan.vlan
        egress_ports.append(port)

    elif (type == "VPORT"):
        port = ifc_param.ifc.vport.vport
        egress_ports.append(get_port_id_from_vport(port))

    elif (type == "BRIDGE"):
        swid = ifc_param.ifc.bridge.swid
        bridge = ifc_param.ifc.bridge.bridge
        egress_ports, flood = get_ports_from_fdb(type, bridge, dmac)

    else:
        print("Egress rif type is not supported")

    return egress_ports, flood


def get_lag_hash(config_file):
    return hash_value, lag_index, lag_mc_index


def get_lag_member_port(lag_id, ingress_port, packet, flood):
    ports = []

    port_list_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_list_cnt_p, 0)
    rc = sx_api_lag_port_group_get(handle, swid, lag_id, None, port_list_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to get lag port list")
        sys.exit(rc)
    port_list_cnt = uint32_t_p_value(port_list_cnt_p)

    port_list = new_sx_port_log_id_t_arr(port_list_cnt)
    rc = sx_api_lag_port_group_get(handle, swid, lag_id, port_list, port_list_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to get lag port list")
        sys.exit(rc)
    port_list_cnt = uint32_t_p_value(port_list_cnt_p)

    for i in range(0, port_list_cnt):
        log_port = sx_port_log_id_t_arr_getitem(port_list, i)
        distr_state_p = new_sx_distributor_mode_t_p()
        rc = sx_api_lag_port_distributor_get(handle, lag_id, log_port, distr_state_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get lag port distributor state")
            sys.exit(rc)
        distr_state = sx_distributor_mode_t_p_value(distr_state_p)
        if distr_state == DISTRIBUTOR_ENABLE:
            ports.append(log_port)

    ports.sort()

    hash_value, lag_index, lag_mc_index = lag_hash_calculator(ingress_port, packet, len(ports))
    if flood:
        port = ports[lag_mc_index]
    else:
        port = ports[lag_index]

    return port


parser = argparse.ArgumentParser(description='sx_hash_calc_example')
parser.add_argument('--smac', help='Source mac', required=True)
parser.add_argument('--dmac', help='Destination mac', required=True)
parser.add_argument('--vlan', help='Vlan', required=True)
parser.add_argument('--sip', help='Source IP', required=True)
parser.add_argument('--dip', help='Destination IP', required=True)
parser.add_argument('--proto', help='IP protocol', required=True)
parser.add_argument('--sport', help='L4 source port', required=True)
parser.add_argument('--dport', help='L4 destination port', required=True)
parser.add_argument('--ingress_port', help='Ingress logic physical port in hex', required=True)
args = parser.parse_args()

packet = {}
packet["smac"] = args.smac
packet["dmac"] = args.dmac
packet["vlan"] = int(args.vlan)
packet["sip"] = args.sip
packet["dip"] = args.dip
packet["proto"] = int(args.proto)
packet["sport"] = int(args.sport)
packet["dport"] = int(args.dport)

ingress_port = int(args.ingress_port, 16)

rif, vrid = get_router_interface(ingress_port, packet["vlan"], packet["dmac"])

next_hops = get_next_hops(vrid, packet["dip"])

ecmp_size = len(next_hops)

if ecmp_size > 0:
    hash_value, hash_index = ecmp_hash_calculator(args.ingress_port, packet, ecmp_size)

    if next_hops[hash_index].next_hop_key.type == SX_NEXT_HOP_TYPE_IP:
        egress_ports, flood = get_ecmp_egress_ports(vrid, next_hops[hash_index])
        if len(egress_ports) == 0:
            sys.exit(0)

        for egress_port in egress_ports:
            if get_port_type(egress_port) == SX_PORT_TYPE_LAG:
                port = get_lag_member_port(egress_port, args.ingress_port, packet, flood)
                egress_ports.remove(egress_port)
                egress_ports.append(port)

        print('Egress ports: [{}]'.format(', '.join(hex(x) for x in egress_ports)))

sx_api_close(handle)
