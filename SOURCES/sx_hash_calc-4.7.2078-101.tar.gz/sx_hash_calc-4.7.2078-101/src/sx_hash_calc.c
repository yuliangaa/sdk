/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <unistd.h>
#include <assert.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <stddef.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/utils/cJSON.h>

#include "../include/hash_calc_lib.h"

#undef  __MODULE__
#define __MODULE__ SX_HASH_CALC

#define DEFAULT_ECMP_HASH_RESULT_FILE   "/tmp/ecmp_hash_result.json"
#define DEFAULT_ECMP_REHASH_RESULT_FILE "/tmp/ecmp_rehash_result.json"
#define DEFAULT_LAG_HASH_RESULT_FILE    "/tmp/lag_hash_result.json"

#define MAX_INPUT_JSON_FILE_LEN (1 * 1024 * 1024)

#define NVE_UDP_DPORT_DEFAULT 4789

#ifndef UINT32_MAX
#define UINT32_MAX (4294967295U)
#endif

/* From lag.c */
#define SX_LAG_PORT_HASH_FIELD_ENABLE_CHECK_RANGE(field) \
    (SX_CHECK_RANGE(SX_LAG_HASH_FIELD_ENABLE_MIN,        \
                    field, SX_LAG_HASH_FIELD_ENABLE_MAX))

#define SX_LAG_PORT_HASH_FIELD_CHECK_RANGE(field)         \
    (SX_CHECK_RANGE(SX_LAG_HASH_FIELDS_MIN,               \
                    field,                                \
                    SX_LAG_HASH_OUTER_IPV6_FLOW_LABEL) || \
     SX_CHECK_RANGE(SX_LAG_HASH_OUTER_MPLS_LABEL_0,       \
                    field,                                \
                    SX_LAG_HASH_OUTER_LAST) ||            \
     SX_CHECK_RANGE(SX_LAG_HASH_INNER_SMAC,               \
                    field,                                \
                    SX_LAG_HASH_INNER_LAST) ||            \
     SX_CHECK_RANGE(SX_LAG_HASH_GENERAL_FIELDS_FIRST,     \
                    field,                                \
                    SX_LAG_HASH_GENERAL_FIELDS_LAST))


#define LAG_PORT_HASH_OUTER_FIELD_OFFSET_1 32
#define LAG_PORT_HASH_OUTER_FIELD_OFFSET_2 64
#define LAG_PORT_HASH_OUTER_FIELD_OFFSET_3 96

#define LAG_PORT_HASH_IS_FIELD_ENABLE_OUTER(field) \
    ((SX_LAG_HASH_INNER_ENABLES_OFFSET > field) && \
     (SX_LAG_HASH_OUTER_ENABLES_OFFSET <= field))
#define LAG_PORT_HASH_IS_FIELD_ENABLE_INNER(field)        \
    ((SX_LAG_HASH_FIELD_ENABLE_INNER_L4_IPV6 >= field) && \
     (SX_LAG_HASH_INNER_ENABLES_OFFSET <= field))
#define LAG_PORT_HASH_IS_FIELD_OUTER(field) \
    ((SX_LAG_HASH_OUTER_LAST >= field) &&   \
     (SX_LAG_HASH_OUTER_FIELDS_OFFSET <= field))
#define LAG_PORT_HASH_IS_FIELD_INNER(field) \
    ((SX_LAG_HASH_INNER_LAST >= field) &&   \
     (SX_LAG_HASH_INNER_FIELDS_OFFSET <= field))
#define LAG_PORT_HASH_IS_FIELD_GENERAL(field)        \
    ((SX_LAG_HASH_GENERAL_FIELDS_OFFSET <= field) && \
     (SX_LAG_HASH_GENERAL_FIELDS_LAST >= field))
#define LAG_PORT_HASH_GP_REGISTER_TO_OFFSET(field) \
    (field - SX_LAG_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET + 2)

#define HASH_ENABLE_BITS_SIZE ((SX_LAG_HASH_FIELD_ENABLE_MAX - SX_LAG_HASH_FIELD_ENABLE_MIN) / 8 + 1)
#define HASH_FIELD_BITS_SIZE  ((SX_LAG_HASH_FIELDS_MAX - SX_LAG_HASH_FIELDS_MIN) / 8 + 1)
/* From lag.c - END */

/* From lag.h */
#define LAG_PORT_HASH_IS_FIELD_CUSTOM_BYTE(field)           \
    ((SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_0 <= field) && \
     (SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST >= field))
#define LAG_PORT_HASH_IS_FIELD_GP_REGISTER(field)                \
    ((SX_LAG_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET <= field) && \
     (SX_LAG_HASH_GENERAL_FIELDS_GP_REGISTER_LAST >= field))
#define LAG_PORT_HASH_FIELD_GP_REGISTER_GET(field) \
    ((field - SX_LAG_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET) / 2)
/* From lag.h - END */

/* From hwd_router.c */
#define ECMP_HASH_OUTER_FIELD_OFFSET_1 32
#define ECMP_HASH_OUTER_FIELD_OFFSET_2 64
#define ECMP_HASH_OUTER_FIELD_OFFSET_3 96

#define ECMP_HASH_IS_FIELD_ENABLE_OUTER(field)             \
    ((SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET > field) && \
     (SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET <= field))
#define ECMP_HASH_IS_FIELD_ENABLE_INNER(field)                    \
    ((SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV6 >= field) && \
     (SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET <= field))
#define ECMP_HASH_IS_FIELD_OUTER(field)           \
    ((SX_ROUTER_ECMP_HASH_OUTER_LAST >= field) && \
     (SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET <= field))
#define ECMP_HASH_IS_FIELD_INNER(field)           \
    ((SX_ROUTER_ECMP_HASH_INNER_LAST >= field) && \
     (SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET <= field))
#define ECMP_HASH_IS_FIELD_GENERAL(field)                    \
    ((SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET <= field) && \
     (SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_LAST >= field))
#define ECMP_HASH_GP_REGISTER_TO_OFFSET(field) \
    (field - SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET + 2)
/* From hwd_router.c - END */

/* From sdk_router_be.h */
#define ECMP_HASH_IS_FIELD_CUSTOM_BYTE(field)                       \
    ((SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_0 <= field) && \
     (SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST >= field))
#define ECMP_HASH_IS_FIELD_GP_REGISTER(field)                            \
    ((SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET <= field) && \
     (SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_GP_REGISTER_LAST >= field))
#define ECMP_HASH_FIELD_GP_REGISTER_GET(field) \
    ((field - SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_GP_REGISTER_OFFSET) / 2)
/* From sdk_router_be.h - END */

typedef struct enum_str_map {
    int   enum_val;
    char *enum_str;
} enum_str_map_t;

typedef enum hash_calc_status {
    HASH_CALC_STATUS_SUCCESS,
    HASH_CALC_STATUS_PARAM_ERR,
    HASH_CALC_STATUS_PARSE_ERR,
    HASH_CALC_STATUS_NOT_FOUND,
    HASH_CALC_STATUS_ERROR,
} hash_calc_status_t;

#ifndef HASH_CALC_CHECK_FAIL
#define HASH_CALC_CHECK_FAIL(STATUS) (HASH_CALC_STATUS_SUCCESS != (STATUS))
#endif

typedef enum _input_json_file_type {
    CONFIG_ECMP_HASH_E,
    CONFIG_ECMP_REHASH_E,
    CONFIG_LAG_HASH_E,
} input_json_file_type_e;

#define SAFE_GET_CJSON_OBJ_ITEM(P_JSON_PARENT, ITEM_STR, PP_JSON_ITEM)         \
    if (__safe_get_cjson_object_item(P_JSON_PARENT, ITEM_STR, PP_JSON_ITEM)) { \
        SX_LOG_ERR("Fail to parse '%s'.\n", ITEM_STR);                         \
        goto out;                                                              \
    }

#define ENUM_TO_STRING(ENUM_PREFIX, STR, ENUM_POSTFIX) {ENUM_PREFIX ## STR ## ENUM_POSTFIX, #STR}


#define HASH_CALC_TYPE_STR(type) \
    ((type) < HASH_CALC_TYPE_NUM_E) ? hash_calc_type_str_s[type] : "Unknown"

#define MAC_STR_FMT "xx:xx:xx:xx:xx:xx"

#define KEY_STR_ECMP_HASH              "ecmp_hash"
#define KEY_STR_ECMP_REHASH            "ecmp_rehash"
#define KEY_STR_LAG_HASH               "lag_hash"
#define KEY_STR_OFFLINE                "offline"
#define KEY_STR_ECMP_HASH_CONFIG       "ecmp_hash_config"
#define KEY_STR_LAG_HASH_CONFIG        "lag_hash_config"
#define KEY_STR_PACKET_INFO            "packet_info"
#define KEY_STR_PER_PORT               "per_port"
#define KEY_STR_GLOBAL                 "global"
#define KEY_STR_PORT                   "port"
#define KEY_STR_HASH                   "hash"
#define KEY_STR_SYMMETRIC_HASH         "symmetric_hash"
#define KEY_STR_HASH_TYPE              "hash_type"
#define KEY_STR_SEED                   "seed"
#define KEY_STR_HASH_PARAM             "hash_param"
#define KEY_STR_HASH_FIELD_ENABLE_LIST "hash_field_enable_list"
#define KEY_STR_HASH_FIELD_LIST        "hash_field_list"
#define KEY_STR_OUTER                  "outer"
#define KEY_STR_INNER                  "inner"
#define KEY_STR_LAYER2                 "layer2"
#define KEY_STR_SMAC                   "smac"
#define KEY_STR_DMAC                   "dmac"
#define KEY_STR_ETHERTYPE              "ethertype"
#define KEY_STR_IPV4                   "ipv4"
#define KEY_STR_IPV6                   "ipv6"
#define KEY_STR_SIP                    "sip"
#define KEY_STR_DIP                    "dip"
#define KEY_STR_PROTO                  "proto"
#define KEY_STR_MFLAG                  "mflag"
#define KEY_STR_NEXT_HEADER            "next_header"
#define KEY_STR_FLOW_LABEL             "flow_label"
#define KEY_STR_TCP_UDP                "tcp_udp"
#define KEY_STR_SPORT                  "sport"
#define KEY_STR_DPORT                  "dport"
#define KEY_STR_OUTER_VID              "outer_vid"
#define KEY_STR_OUTER_PCP              "outer_pcp"
#define KEY_STR_OUTER_DEI              "outer_dei"
#define KEY_STR_INNER_VID              "inner_vid"
#define KEY_STR_INNER_PCP              "inner_pcp"
#define KEY_STR_INNER_DEI              "inner_dei"
#define KEY_STR_ARP                    "arp"
#define KEY_STR_SPA                    "spa"
#define KEY_STR_TPA                    "tpa"
#define KEY_STR_DSCP                   "dscp"
#define KEY_STR_ECN                    "ecn"
#define KEY_STR_L3_LENGTH              "l3_length"
#define KEY_STR_MPLS                   "mpls"
#define KEY_STR_LABEL_ID               "label_id"
#define KEY_STR_VXLAN_NVGRE            "vxlan_nvgre"
#define KEY_STR_VNI                    "vni"
#define KEY_STR_GRE                    "gre"
#define KEY_STR_KEY                    "key"
#define KEY_STR_INGRESS_PORT           "ingress_port"
#define KEY_STR_CUSTOM_BYTES           "custom_bytes"
#define KEY_STR_ASIC_TYPE              "asic_type"
#define KEY_STR_ECMP_SIZE              "ecmp_size"
#define KEY_STR_LAG_SIZE               "lag_size"
#define KEY_STR_NVE_UDP_DPORT          "nve_udp_dport"
#define KEY_STR_PVID                   "pvid"
#define KEY_STR_HASH_VALUE             "hash_value"

#define KEY_STR_RET_ECMP_HASH    "ecmp_hash"
#define KEY_STR_RET_LAG_HASH     "lag_hash"
#define KEY_STR_RET_HASH_VALUE   "hash_value"
#define KEY_STR_RET_ECMP_INDEX   "ecmp_index"
#define KEY_STR_RET_LAG_INDEX    "lag_index"
#define KEY_STR_RET_LAG_MC_INDEX "lag_mc_index"

#define STR_ASIC_TYPE_SPC1       "SPC-1"
#define STR_ASIC_TYPE_SPC1_ALIAS "SPC"
#define STR_ASIC_TYPE_SPC2       "SPC-2"
#define STR_ASIC_TYPE_SPC3       "SPC-3"
#define STR_ASIC_TYPE_SPC4       "SPC-4"

enum_str_map_t __hash_type_str_dict[] = {
    ENUM_TO_STRING(HASH_CALC_HASH_TYPE_, CRC,    _E),
    ENUM_TO_STRING(HASH_CALC_HASH_TYPE_, XOR,    _E),
    ENUM_TO_STRING(HASH_CALC_HASH_TYPE_, RANDOM, _E),
    ENUM_TO_STRING(HASH_CALC_HASH_TYPE_, CRC2,   _E)
};
int            __hash_type_str_dict_len = sizeof(__hash_type_str_dict) / sizeof(__hash_type_str_dict[0]);

enum_str_map_t __lag_hash_bit_str_dict[] = {
    ENUM_TO_STRING(SX_LAG_HASH_, INGRESS_PORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, SMAC_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, SMAC_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, DMAC_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, DMAC_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, ETHER_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, ETHER_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, VID_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, VID_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, S_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, D_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, L4_SPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, L4_DPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, L3_PROTO, ),
    ENUM_TO_STRING(SX_LAG_HASH_, IPV6_FLOW_LABEL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, SID, ),
    ENUM_TO_STRING(SX_LAG_HASH_, DID, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OXID, ),
    ENUM_TO_STRING(SX_LAG_HASH_, D_QP, )
};
int            __lag_hash_bit_str_dict_len = sizeof(__lag_hash_bit_str_dict) / sizeof(__lag_hash_bit_str_dict[0]);

enum_str_map_t __lag_hash_field_enable_str_dict[] = {
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_L2_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_L2_IPV4, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_L2_IPV6, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_IPV4_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_IPV4_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_IPV6_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_IPV6_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_L4_IPV4, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_L4_IPV6, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_FIRST, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, OUTER_LAST, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_L2_NON_IP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_L2_IPV4, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_L2_IPV6, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_IPV4_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_IPV4_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_IPV6_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_IPV6_TCP_UDP, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_L4_IPV4, ),
    ENUM_TO_STRING(SX_LAG_HASH_FIELD_ENABLE_, INNER_L4_IPV6, )
};
int            __lag_hash_field_enable_str_dict_len = sizeof(__lag_hash_field_enable_str_dict) /
                                                      sizeof(__lag_hash_field_enable_str_dict[0]);

enum_str_map_t __lag_hash_field_str_dict[] = {
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_SMAC, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_DMAC, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_ETHERTYPE, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_OVID, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_OPCP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_ODEI, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IVID, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPCP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IDEI, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_SIP_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_SIP_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_SIP_BYTE_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_SIP_BYTE_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_DIP_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_DIP_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_DIP_BYTE_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_DIP_BYTE_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_PROTOCOL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_DSCP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_ECN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV4_IP_L3_LENGTH, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_8, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_9, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_10, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_11, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_12, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_13, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_14, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_SIP_BYTE_15, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_8, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_9, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_10, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_11, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_12, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_13, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_14, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DIP_BYTE_15, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_NEXT_HEADER, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_DSCP, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_ECN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_IP_L3_LENGTH, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_IPV6_FLOW_LABEL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_4, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_MPLS_LABEL_5, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_TCP_UDP_SPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_TCP_UDP_DPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_BTH_DQPN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_BTH_PKEY, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_BTH_OPCODE, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_DETH_QKEY, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_DETH_SQPN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_VNI, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_NVGRE_FLOW, ),
    ENUM_TO_STRING(SX_LAG_HASH_, OUTER_NVGRE_PROTOCOL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_SMAC, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_DMAC, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ETHERTYPE, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_SIP_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_SIP_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_SIP_BYTE_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_SIP_BYTE_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_DIP_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_DIP_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_DIP_BYTE_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_DIP_BYTE_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV4_PROTOCOL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_8, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_9, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_10, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_11, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_12, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_13, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_14, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_SIP_BYTE_15, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_8, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_9, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_10, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_11, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_12, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_13, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_14, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_DIP_BYTE_15, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_NEXT_HEADER, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_IPV6_FLOW_LABEL, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_TCP_UDP_SPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_TCP_UDP_DPORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ROCE_BTH_DQPN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ROCE_BTH_PKEY, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ROCE_BTH_OPCODE, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ROCE_DETH_QKEY, ),
    ENUM_TO_STRING(SX_LAG_HASH_, INNER_ROCE_DETH_SQPN, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_INGRESS_PORT, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_2, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_3, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_4, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_5, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_6, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_7, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_8, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_9, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_10, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_11, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_12, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_13, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_14, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_15, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_0_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_0_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_1_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_1_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_2_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_2_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_3_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_3_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_4_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_4_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_5_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_5_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_6_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_6_BYTE_1, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_7_BYTE_0, ),
    ENUM_TO_STRING(SX_LAG_HASH_, GENERAL_FIELDS_GP_REGISTER_7_BYTE_1, )
};
int            __lag_hash_field_str_dict_len = sizeof(__lag_hash_field_str_dict) /
                                               sizeof(__lag_hash_field_str_dict[0]);

enum_str_map_t __ecmp_hash_bit_str_dict[] = {
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, SRC_IP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, DST_IP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, TCLASS, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, FLOW_LABEL, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, TCP_UDP_SRC_PORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, TCP_UDP_DST_PORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, SMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, DMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, ETH_TYPE, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, VID, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, PCP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, DEI, )
};
int            __ecmp_hash_bit_str_dict_len = sizeof(__ecmp_hash_bit_str_dict) / sizeof(__ecmp_hash_bit_str_dict[0]);

enum_str_map_t __ecmp_hash_field_enable_str_dict[] = {
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_L2_NON_IP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_L2_IPV4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_L2_IPV6, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_IPV4_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_IPV4_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_IPV6_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_IPV6_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_L4_IPV4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, OUTER_L4_IPV6, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_L2_NON_IP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_L2_IPV4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_L2_IPV6, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_IPV4_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_IPV4_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_IPV6_NON_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_IPV6_TCP_UDP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_L4_IPV4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_FIELD_ENABLE_, INNER_L4_IPV6, )
};
int            __ecmp_hash_field_enable_str_dict_len = sizeof(__ecmp_hash_field_enable_str_dict) /
                                                       sizeof(__ecmp_hash_field_enable_str_dict[0]);

enum_str_map_t __ecmp_hash_field_str_dict[] = {
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_SMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_DMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_ETHERTYPE, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_OVID, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_OPCP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_ODEI, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IVID, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPCP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IDEI, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_SIP_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_SIP_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_SIP_BYTE_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_SIP_BYTE_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_DIP_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_DIP_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_DIP_BYTE_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_DIP_BYTE_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_PROTOCOL, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_DSCP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_ECN, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV4_IP_L3_LENGTH, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_8, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_9, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_10, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_11, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_12, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_13, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_14, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_SIP_BYTE_15, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_8, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_9, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_10, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_11, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_12, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_13, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_14, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DIP_BYTE_15, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_NEXT_HEADER, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_DSCP, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_ECN, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_IP_L3_LENGTH, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_IPV6_FLOW_LABEL, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_MPLS_LABEL_5, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_TCP_UDP_SPORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_TCP_UDP_DPORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, OUTER_VNI, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_SMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_DMAC, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_ETHERTYPE, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_SIP_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_SIP_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_SIP_BYTE_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_SIP_BYTE_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_DIP_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_DIP_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_DIP_BYTE_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_DIP_BYTE_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV4_PROTOCOL, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_8, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_9, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_10, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_11, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_12, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_13, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_14, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_SIP_BYTE_15, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTES_0_TO_7, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_8, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_9, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_10, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_11, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_12, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_13, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_14, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_DIP_BYTE_15, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_NEXT_HEADER, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_IPV6_FLOW_LABEL, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_TCP_UDP_SPORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, INNER_TCP_UDP_DPORT, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_2, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_3, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_4, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_5, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_6, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_7, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_8, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_9, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_10, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_11, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_12, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_13, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_14, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_CUSTOM_BYTE_15, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_0_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_0_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_1_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_1_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_2_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_2_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_3_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_3_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_4_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_4_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_5_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_5_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_6_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_6_BYTE_1, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_7_BYTE_0, ),
    ENUM_TO_STRING(SX_ROUTER_ECMP_HASH_, GENERAL_FIELDS_GP_REGISTER_7_BYTE_1, )
};
int            __ecmp_hash_field_str_dict_len = sizeof(__ecmp_hash_field_str_dict) /
                                                sizeof(__ecmp_hash_field_str_dict[0]);

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE; /* log verbosity level */

#define SX_MEM_CLR(src) (memset(&(src), 0, sizeof(src)))

static int __str_to_int(char *str, long int *val, int base)
{
    int      err = 0;
    long int t = 0;

    errno = 0;
    t = strtol(str, NULL, base);
    if (((errno == ERANGE) && ((t == LONG_MAX) || (t == LONG_MIN)))
        || ((errno != 0) && (t == 0))) {
        SX_LOG_ERR("Fails to convert '%s' to integer \n", str);
        err = -1;
        goto out;
    }
    *val = t;
out:
    return err;
}

static int __str_to_mac(const char *strmac, uint8_t *mac)
{
    uint32_t values[6];
    int      err = 0;
    int      ret = 0;
    int      len = 0;

    len = strlen(strmac);
    if (len != strlen(MAC_STR_FMT)) {
        err = -1;
        goto out;
    }

    ret = sscanf(strmac,
                 "%2x:%2x:%2x:%2x:%2x:%2x",
                 &values[0],
                 &values[1],
                 &values[2],
                 &values[3],
                 &values[4],
                 &values[5]);
    if (ret != 6) {
        err = -2;
        goto out;
    }

    for (ret = 0; ret < 6; ret++) {
        mac[ret] = (uint8_t)values[ret];
    }
out:
    if (err < 0) {
        SX_LOG_ERR("bad MAC address passed, err: %d\n", err);
    }
    return err;
}

static int __str_to_enum(const char *str, const enum_str_map_t *enum_str_dict, const int dict_size, int *type)
{
    int err = 0;
    int i = 0;

    for (i = 0; i < dict_size; i++) {
        if (!strcmp(str, enum_str_dict[i].enum_str)) {
            *type = enum_str_dict[i].enum_val;
            goto out;
        }
    }
    SX_LOG_ERR("enum type '%s' is not found.\n", str);
    err = -1;
out:
    return err;
}

/* If the json object is a json object or array && has duplicated children: return FALSE; otherwise, return TRUE. */
boolean_t is_valid_json_obj(cJSON *p_obj)
{
    cJSON *element_i = NULL;
    cJSON *element_j = NULL;

    if (p_obj) {
        if (cJSON_IsObject(p_obj)) {
            cJSON_ArrayForEach(element_i, p_obj)
            {
                for (element_j = element_i->next; element_j != NULL; element_j = element_j->next) {
                    if (!strcmp(element_i->string, element_j->string)) {
                        SX_LOG_ERR("Invalid json element: duplicated items ('%s').\n", element_i->string);
                        return FALSE;
                    }
                }
            }
        }
    }
    return TRUE;
}

static int __safe_get_cjson_object_item(const cJSON * const object, const char * const string, cJSON **pp_element)
{
    int err = 0;

    *pp_element = cJSON_GetObjectItem(object, string);
    if (*pp_element) {
        if (!is_valid_json_obj(*pp_element)) {
            err = -1;
            SX_LOG_ERR("Fail due to invalid json content.\n");
            goto out;
        }
    }

out:
    return err;
}

static int __safe_get_cjson_u32_number_item(const cJSON * const object, uint32_t *value)
{
    int err = 0;

    if (object->valuedouble > UINT32_MAX) {
        err = -1;
        SX_LOG_ERR("Fail due to too big value %ld for UINT32 type.\n", (long)(object->valuedouble));
        goto out;
    }

    *value = (uint32_t)(object->valuedouble);
out:
    return err;
}

static int __hash_bits_get(uint32_t *enum_array, uint32_t *enum_size_p, uint8_t* bits_array, uint32_t bits_size)
{
    int      err = 0;
    uint32_t enum_index = 0;
    uint32_t byte_idx;
    uint32_t bit_idx;

    for (byte_idx = 0; byte_idx < bits_size; byte_idx++) {
        for (bit_idx = 0; bit_idx < 8; bit_idx++) {
            if (bits_array[byte_idx] & (1 << bit_idx)) {
                enum_array[enum_index++] = 8 * byte_idx + bit_idx;
            }
        }
    }

    if (enum_index > *enum_size_p) {
        SX_LOG_ERR("enum_index (%d) is greater than *enum_size_p (%d).\n", enum_index, *enum_size_p);
        err = -1;
        goto out;
    }
    *enum_size_p = enum_index;
out:
    return err;
}

static int __hash_bits_set(uint8_t* bits_array, uint32_t bits_size, uint32_t enum_val)
{
    int err = 0;

    if (enum_val / 8 > bits_size) {
        SX_LOG_ERR("enum_val(%d) / 8 is greater than bits_size (%d).\n", bits_size, enum_val);
        err = -1;
        goto out;
    }
    bits_array[enum_val / 8] |= (1 << (enum_val % 8));

out:
    return err;
}

static hash_calc_status_t __fetch_hash_type_seed_from_json_obj(cJSON                * p_parent_json_obj,
                                                               hash_calc_hash_type_t *type,
                                                               uint32_t              *seed)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                err = 0;
    cJSON             *p_hash_param = p_parent_json_obj;
    cJSON             *p_hash_type = NULL;
    cJSON             *p_seed = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_HASH_TYPE;
    p_hash_type = cJSON_GetObjectItem(p_hash_param, json_elem_str);
    if (p_hash_type) {
        err = __str_to_enum(p_hash_type->valuestring,
                            __hash_type_str_dict,
                            __hash_type_str_dict_len,
                            (int*)type);
        if (err) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

    p_seed = cJSON_GetObjectItem(p_hash_param, KEY_STR_SEED);
    if (p_seed) {
        err = __safe_get_cjson_u32_number_item(p_seed, seed);
        if (err) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }
out:
    return status;
}

static hash_calc_status_t __fetch_hash_param_from_json_obj(cJSON                  * p_parent_json_obj,
                                                           hash_calc_hash_config_t *hash_config_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_hash_param = p_parent_json_obj;
    cJSON             *p_symmetric_hash = NULL;

    p_symmetric_hash = cJSON_GetObjectItem(p_hash_param, KEY_STR_SYMMETRIC_HASH);
    if (p_symmetric_hash) {
        hash_config_p->sh = p_symmetric_hash->valueint;
    }

    status = __fetch_hash_type_seed_from_json_obj(p_hash_param, &(hash_config_p->type), &(hash_config_p->seed));
    return status;
}

/*
 *   if succeed, caller function should consider to release memory referred by enum_list_p.
 */
static hash_calc_status_t __fetch_enum_list_from_json_obj(cJSON                *p_json_arr,
                                                          const char           *json_elem_str,
                                                          const enum_str_map_t *enum_str_dict,
                                                          int                   enum_str_dict_size,
                                                          int                 **enum_list_p,
                                                          uint32_t             *enum_list_cnt)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                err = 0;
    int                i = 0;
    int                arr_size = 0;
    cJSON             *p_json_elem = NULL;
    int               *enum_l = NULL;
    int                enum_val = 0;

    if (!cJSON_IsArray(p_json_arr)) {
        SX_LOG_ERR("Fails to parse '%s': not a JSON array.\n", json_elem_str);
        status = HASH_CALC_STATUS_PARSE_ERR;
        goto out;
    }

    arr_size = cJSON_GetArraySize(p_json_arr);
    enum_l = (int *)calloc(arr_size, sizeof(int));
    for (i = 0; i < arr_size; i++) {
        p_json_elem = cJSON_GetArrayItem(p_json_arr, i);
        err = __str_to_enum(p_json_elem->valuestring,
                            enum_str_dict,
                            enum_str_dict_size,
                            (int*)&enum_val);
        if (err) {
            SX_LOG_ERR("Fails to parse '%s', err %d.\n", json_elem_str, err);
            status = HASH_CALC_STATUS_PARSE_ERR;
            goto out;
        }
        enum_l[i] = enum_val;
    }

    *enum_list_p = enum_l;
    *enum_list_cnt = arr_size;

out:
    if (HASH_CALC_CHECK_FAIL(status) && enum_l) {
        free(enum_l);
    }
    return status;
}

static hash_calc_status_t __fetch_hash_config_from_hash_fields(
    const sx_router_ecmp_hash_field_enable_t *hash_field_enable_list_p,
    const uint32_t                            hash_field_enable_list_cnt,
    const sx_router_ecmp_hash_field_t        *hash_field_list_p,
    const uint32_t                            hash_field_list_cnt,
    hash_calc_hash_config_t                  *ret_hash_config)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    uint32_t           offset;
    uint32_t           field_idx;

    for (field_idx = 0; field_idx < hash_field_enable_list_cnt; field_idx++) {
        if (ECMP_HASH_IS_FIELD_ENABLE_OUTER(hash_field_enable_list_p[field_idx])) {
            offset = hash_field_enable_list_p[field_idx] - SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET;
            ret_hash_config->outer_header_enables |= (1 << offset);
        } else if (ECMP_HASH_IS_FIELD_ENABLE_INNER(hash_field_enable_list_p[field_idx])) {
            offset = hash_field_enable_list_p[field_idx] - SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET;
            ret_hash_config->inner_header_enables |= (1 << offset);
        } else {
            status = HASH_CALC_STATUS_PARSE_ERR;
            SX_LOG_ERR("hash field enable [%u] is not in range.\n", hash_field_enable_list_p[field_idx]);
            goto out;
        }
    }

    for (field_idx = 0; field_idx < hash_field_list_cnt; field_idx++) {
        if (ECMP_HASH_IS_FIELD_OUTER(hash_field_list_p[field_idx])) {
            offset = hash_field_list_p[field_idx] - SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET;
            if (offset < ECMP_HASH_OUTER_FIELD_OFFSET_1) {
                ret_hash_config->outer_header_fields_enable[0] |= (1 << offset);
            } else if (offset < ECMP_HASH_OUTER_FIELD_OFFSET_2) {
                offset -= ECMP_HASH_OUTER_FIELD_OFFSET_1;
                ret_hash_config->outer_header_fields_enable[1] |= (1 << offset);
            } else {
                offset -= ECMP_HASH_OUTER_FIELD_OFFSET_2;
                ret_hash_config->outer_header_fields_enable[2] |= (1 << offset);
            }
        } else if (ECMP_HASH_IS_FIELD_INNER(hash_field_list_p[field_idx])) {
            offset = hash_field_list_p[field_idx] - SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET;
            ret_hash_config->inner_header_fields_enable |= (UINT64_C(1) << offset);
        } else if (ECMP_HASH_IS_FIELD_GENERAL(hash_field_list_p[field_idx])) {
            if (ECMP_HASH_IS_FIELD_GP_REGISTER(hash_field_list_p[field_idx])) {
                offset = ECMP_HASH_GP_REGISTER_TO_OFFSET(hash_field_list_p[field_idx]);
            } else {
                offset = hash_field_list_p[field_idx] - SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET;
            }
            ret_hash_config->general_fields |= (1 << offset);
        } else {
            status = HASH_CALC_STATUS_PARSE_ERR;
            SX_LOG_ERR("hash field [%u] is not in range.\n", hash_field_list_p[field_idx]);
            goto out;
        }
    }
out:
    return status;
}

static void __general_hash_to_pp_ecmp_hash_params(const sx_router_ecmp_hash_t         hash_bits,
                                                  sx_router_ecmp_hash_field_enable_t *enables_list_p,
                                                  uint32_t                           *enables_cnt_p,
                                                  sx_router_ecmp_hash_field_t        *fields_list_p,
                                                  uint32_t                           *fields_cnt_p)
{
    boolean_t ipv4_enabled = FALSE;
    boolean_t ipv6_enabled = FALSE;
    boolean_t l4_enable = FALSE;
    boolean_t l2_outer_enable = FALSE;
    boolean_t l2_inner_enable = FALSE;

    if ((hash_bits & SX_ROUTER_ECMP_HASH_SMAC) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        l2_inner_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_SMAC;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_SMAC;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_DMAC) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        l2_inner_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_DMAC;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_DMAC;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_ETH_TYPE) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        l2_inner_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_ETHERTYPE;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_ETHERTYPE;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_VID) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_OVID;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IVID;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_PCP) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_OPCP;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPCP;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_DEI) != 0) {
        /*enables*/
        l2_outer_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_ODEI;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IDEI;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_SRC_IP) != 0) {
        /*enables*/
        ipv4_enabled = TRUE;
        ipv6_enabled = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_0;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_1;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_2;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_3;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_8;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_9;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_10;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_11;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_12;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_13;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_14;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_15;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_0;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_1;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_2;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_3;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTES_0_TO_7;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_8;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_9;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_10;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_11;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_12;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_13;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_14;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_15;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_DST_IP) != 0) {
        /*enables*/
        ipv4_enabled = TRUE;
        ipv6_enabled = TRUE;

        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_0;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_1;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_2;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_3;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_8;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_9;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_10;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_11;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_12;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_13;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_14;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_15;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_0;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_1;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_2;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_3;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTES_0_TO_7;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_8;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_9;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_10;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_11;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_12;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_13;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_14;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_15;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_TCLASS)) {
        /*enables*/
        ipv6_enabled = TRUE;
        ipv4_enabled = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_ECN;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_ECN;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_ECN;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_DSCP;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_DSCP;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_DSCP;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_FLOW_LABEL)) {
        /*enables*/
        ipv6_enabled = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_FLOW_LABEL;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_FLOW_LABEL;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_TCP_UDP) != 0) {
        /*enables*/
        ipv6_enabled = TRUE;
        ipv4_enabled = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV6_NEXT_HEADER;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV6_NEXT_HEADER;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_IPV4_PROTOCOL;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_IPV4_PROTOCOL;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_TCP_UDP_SRC_PORT) != 0) {
        /*enables*/
        l4_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_TCP_UDP_SPORT;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_TCP_UDP_SPORT;
    }

    if ((hash_bits & SX_ROUTER_ECMP_HASH_TCP_UDP_DST_PORT) != 0) {
        /*enables*/
        l4_enable = TRUE;
        /*fields*/
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_INNER_TCP_UDP_DPORT;
        fields_list_p[(*fields_cnt_p)++] = SX_ROUTER_ECMP_HASH_OUTER_TCP_UDP_DPORT;
    }

    if (l2_outer_enable) {
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_NON_IP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV6;
    }

    if (l2_inner_enable) {
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_NON_IP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_IPV4;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_IPV6;
    }

    if (ipv4_enabled) {
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV4_NON_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV4_TCP_UDP;
    }

    if (ipv6_enabled) {
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV6_NON_TCP_UDP;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV6_TCP_UDP;
    }

    if (l4_enable) {
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV4;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV6;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L4_IPV4;
        enables_list_p[(*enables_cnt_p)++] = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L4_IPV6;
    }
}

static hash_calc_status_t __fetch_lag_hash_config_from_hash_fields(
    const sx_lag_hash_field_enable_t *field_enable_list_p,
    const uint32_t                    field_enable_list_cnt,
    const sx_lag_hash_field_t        *field_list_p,
    const uint32_t                    field_list_cnt,
    hash_calc_hash_config_t          *ret_hash_config)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    uint32_t           offset;
    uint32_t           field_idx;

    for (field_idx = 0; field_idx < field_enable_list_cnt; field_idx++) {
        if (LAG_PORT_HASH_IS_FIELD_ENABLE_OUTER(field_enable_list_p[field_idx])) {
            offset = field_enable_list_p[field_idx] - SX_LAG_HASH_OUTER_ENABLES_OFFSET;
            ret_hash_config->outer_header_enables |= (1 << offset);
        } else if (LAG_PORT_HASH_IS_FIELD_ENABLE_INNER(field_enable_list_p[field_idx])) {
            offset = field_enable_list_p[field_idx] - SX_LAG_HASH_INNER_ENABLES_OFFSET;
            ret_hash_config->inner_header_enables |= (1 << offset);
        } else {
            status = HASH_CALC_STATUS_PARSE_ERR;
            SX_LOG_ERR("hash field enable [%u] is not in range.\n",
                       field_enable_list_p[field_idx]);
            goto out;
        }
    }

    for (field_idx = 0; field_idx < field_list_cnt; field_idx++) {
        if (LAG_PORT_HASH_IS_FIELD_OUTER(field_list_p[field_idx])) {
            offset = field_list_p[field_idx] - SX_LAG_HASH_OUTER_FIELDS_OFFSET;
            ret_hash_config->outer_header_fields_enable[offset / 32] |= (1 << (offset % 32));
        } else if (LAG_PORT_HASH_IS_FIELD_INNER(field_list_p[field_idx])) {
            offset = field_list_p[field_idx] - SX_LAG_HASH_INNER_FIELDS_OFFSET;
            ret_hash_config->inner_header_fields_enable |= (UINT64_C(1) << offset);
        } else if (LAG_PORT_HASH_IS_FIELD_GENERAL(
                       field_list_p[field_idx])) {
            if (LAG_PORT_HASH_IS_FIELD_GP_REGISTER(field_list_p[field_idx])) {
                offset = LAG_PORT_HASH_GP_REGISTER_TO_OFFSET(field_list_p[field_idx]);
            } else {
                offset = field_list_p[field_idx] - SX_LAG_HASH_GENERAL_FIELDS_OFFSET;
            }
            ret_hash_config->general_fields |= (1 << offset);
        } else {
            status = HASH_CALC_STATUS_PARSE_ERR;
            SX_LOG_ERR("hash field [%u] is not in range.\n", field_list_p[field_idx]);
            goto out;
        }
    }

out:
    return status;
}

static hash_calc_status_t __general_hash_to_pp_lag_hash_params(sx_lag_hash_t               lag_hash_bits,
                                                               sx_lag_hash_field_t        *lag_port_hash_fields,
                                                               uint32_t                   *lag_port_hash_fields_cnt_p,
                                                               sx_lag_hash_field_enable_t *lag_port_hash_enables,
                                                               uint32_t                   *lag_port_hash_enables_cnt_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                err = 0;
    sx_lag_hash_t      lag_hash;
    uint32_t           bit_num;
    uint8_t            enable_bits[HASH_ENABLE_BITS_SIZE];
    uint8_t            field_bits[HASH_FIELD_BITS_SIZE];

    memset(enable_bits, 0, sizeof(enable_bits));
    memset(field_bits, 0, sizeof(field_bits));

    lag_hash = lag_hash_bits;
    for (bit_num = 0; (bit_num <= sizeof(lag_hash) * 8) && (lag_hash > 0); bit_num++) {
        if (lag_hash & 0x1) {
            switch ((sx_lag_hash_bit_number_t)bit_num) {
            case SX_LAG_HASH_INGRESS_PORT:
                /* Not supported in enables */
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_GENERAL_FIELDS_INGRESS_PORT);
                break;

            case SX_LAG_HASH_SMAC_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_SMAC);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV6);
                break;

            case SX_LAG_HASH_SMAC_NON_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_SMAC);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP);

                break;

            case SX_LAG_HASH_DMAC_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_DMAC);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV6);
                break;

            case SX_LAG_HASH_DMAC_NON_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_DMAC);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP);
                break;

            case SX_LAG_HASH_ETHER_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_ETHERTYPE);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV6);
                break;

            case SX_LAG_HASH_ETHER_NON_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_ETHERTYPE);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP);
                break;

            case SX_LAG_HASH_VID_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_OVID);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV6);
                break;

            case SX_LAG_HASH_VID_NON_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_OVID);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP);
                break;

            case SX_LAG_HASH_S_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_0);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_1);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_2);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_3);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_8);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_9);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_10);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_11);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_12);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_13);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_14);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_15);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP);
                break;

            case SX_LAG_HASH_D_IP:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_0);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_1);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_2);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_3);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_8);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_9);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_10);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_11);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_12);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_13);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_14);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_15);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP);
                break;

            case SX_LAG_HASH_L4_SPORT:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_TCP_UDP_SPORT);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV6);
                break;

            case SX_LAG_HASH_L4_DPORT:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_TCP_UDP_DPORT);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV4);
                __hash_bits_set(enable_bits, HASH_ENABLE_BITS_SIZE,
                                SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV6);
                break;

            case SX_LAG_HASH_L3_PROTO:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV4_PROTOCOL);
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_NEXT_HEADER);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP);
                break;

            case SX_LAG_HASH_IPV6_FLOW_LABEL:
                __hash_bits_set(field_bits, HASH_FIELD_BITS_SIZE,
                                SX_LAG_HASH_OUTER_IPV6_FLOW_LABEL);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP);
                __hash_bits_set(
                    enable_bits, HASH_ENABLE_BITS_SIZE,
                    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP);
                break;

            case SX_LAG_HASH_SID:
            case SX_LAG_HASH_DID:
            case SX_LAG_HASH_OXID:
            case SX_LAG_HASH_D_QP:
            default:
                /* Nothing - unsupported bits */
                break;
            }
        }
        lag_hash = lag_hash >> 1;
    }

    err = __hash_bits_get(lag_port_hash_fields, lag_port_hash_fields_cnt_p,
                          field_bits, HASH_FIELD_BITS_SIZE);
    if (err) {
        SX_LOG_ERR("Fail to get lag hash fields.\n");
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }
    err = __hash_bits_get(lag_port_hash_enables, lag_port_hash_enables_cnt_p,
                          enable_bits, HASH_ENABLE_BITS_SIZE);
    if (err) {
        SX_LOG_ERR("Fail to get lag hash enable fields.\n");
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

out:
    return status;
}

static hash_calc_status_t __fetch_hash_per_port_config_from_json_obj(cJSON                  * p_parent_json_obj,
                                                                     boolean_t                is_ecmp,
                                                                     hash_calc_hash_config_t *hash_config_p)
{
    hash_calc_status_t                  status = HASH_CALC_STATUS_SUCCESS;
    cJSON                              *p_per_port_config = p_parent_json_obj;
    cJSON                              *p_hash_param = NULL;
    cJSON                              *p_hash_field_enable_list = NULL;
    cJSON                              *p_hash_field_list = NULL;
    char                               *json_elem_str = NULL;
    sx_router_ecmp_hash_field_enable_t *hash_field_enable_list_p = NULL;
    uint32_t                            hash_field_enable_list_cnt = 0;
    sx_router_ecmp_hash_field_t        *hash_field_list_p = NULL;
    uint32_t                            hash_field_list_cnt = 0;
    enum_str_map_t                     *field_enable_dict = __ecmp_hash_field_enable_str_dict;
    int                                 field_enable_dict_len = __ecmp_hash_field_enable_str_dict_len;
    enum_str_map_t                     *field_dict = __ecmp_hash_field_str_dict;
    int                                 field_dict_len = __ecmp_hash_field_str_dict_len;

    if (!is_ecmp) {
        field_enable_dict = __lag_hash_field_enable_str_dict;
        field_enable_dict_len = __lag_hash_field_enable_str_dict_len;
        field_dict = __lag_hash_field_str_dict;
        field_dict_len = __lag_hash_field_str_dict_len;
    }

    json_elem_str = KEY_STR_HASH_PARAM;
    SAFE_GET_CJSON_OBJ_ITEM(p_per_port_config, json_elem_str, &p_hash_param);
    if (p_hash_param) {
        status = __fetch_hash_param_from_json_obj(p_hash_param, hash_config_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
    }

    json_elem_str = KEY_STR_HASH_FIELD_ENABLE_LIST;
    SAFE_GET_CJSON_OBJ_ITEM(p_per_port_config, json_elem_str, &p_hash_field_enable_list);
    if (p_hash_field_enable_list) {
        status = __fetch_enum_list_from_json_obj(p_hash_field_enable_list,
                                                 json_elem_str,
                                                 field_enable_dict,
                                                 field_enable_dict_len,
                                                 (int**)&hash_field_enable_list_p,
                                                 &hash_field_enable_list_cnt);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
    }

    json_elem_str = KEY_STR_HASH_FIELD_LIST;
    SAFE_GET_CJSON_OBJ_ITEM(p_per_port_config, json_elem_str, &p_hash_field_list);
    if (p_hash_field_list) {
        status = __fetch_enum_list_from_json_obj(p_hash_field_list,
                                                 json_elem_str,
                                                 field_dict,
                                                 field_dict_len,
                                                 (int**)&hash_field_list_p,
                                                 &hash_field_list_cnt);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s', status %d.\n", json_elem_str, status);
            goto out;
        }
    }

    if (hash_field_enable_list_p && hash_field_list_p) {
        status = __fetch_hash_config_from_hash_fields(hash_field_enable_list_p,
                                                      hash_field_enable_list_cnt,
                                                      hash_field_list_p,
                                                      hash_field_list_cnt,
                                                      hash_config_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s', status %d.\n", json_elem_str, status);
            goto out;
        }
    }

out:
    if (hash_field_enable_list_p) {
        free(hash_field_enable_list_p);
    }
    if (hash_field_list_p) {
        free(hash_field_list_p);
    }

    return status;
}

static hash_calc_status_t __fetch_hash_global_config_from_json_obj(cJSON                  * p_parent_json_obj,
                                                                   boolean_t                is_ecmp,
                                                                   hash_calc_hash_config_t *hash_config_p)
{
    hash_calc_status_t                 status = HASH_CALC_STATUS_SUCCESS;
    uint32_t                           i = 0;
    cJSON                             *p_ecmp_hash_global_config = p_parent_json_obj;
    cJSON                             *p_hash_arr = NULL;
    char                              *json_elem_str = NULL;
    uint32_t                           hash_field_enable_list_cnt = 0;
    uint32_t                           hash_field_list_cnt = 0;
    sx_router_ecmp_hash_field_enable_t hash_field_enable_list_p[FIELDS_ENABLES_NUM];
    sx_router_ecmp_hash_field_t        hash_field_list_p[FIELDS_NUM];
    sx_lag_hash_field_t                lag_port_hash_fields_p[SX_LAG_HASH_FIELDS_NUM];
    sx_lag_hash_field_enable_t         lag_port_hash_enables_p[SX_LAG_HASH_FIELD_ENABLES_NUM];
    sx_router_ecmp_hash_t             *hash_bit_list_p = NULL;
    sx_router_ecmp_hash_t              hash_bit_list_cnt = 0;
    sx_router_ecmp_hash_t              hash_bits = 0;
    enum_str_map_t                    *hash_bit_dict = __ecmp_hash_bit_str_dict;
    int                                hash_bit_dict_len = __ecmp_hash_bit_str_dict_len;


    if (!is_ecmp) {
        hash_bit_dict = __lag_hash_bit_str_dict;
        hash_bit_dict_len = __lag_hash_bit_str_dict_len;
    }

    status = __fetch_hash_param_from_json_obj(p_ecmp_hash_global_config, hash_config_p);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fails to parse global 'symmetric_hash|hash_type|seed'.\n");
        goto out;
    }

    json_elem_str = KEY_STR_HASH;
    SAFE_GET_CJSON_OBJ_ITEM(p_ecmp_hash_global_config, json_elem_str, &p_hash_arr);
    if (p_hash_arr) {
        status = __fetch_enum_list_from_json_obj(p_hash_arr,
                                                 json_elem_str,
                                                 hash_bit_dict,
                                                 hash_bit_dict_len,
                                                 (int**)&hash_bit_list_p,
                                                 &hash_bit_list_cnt);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }

        if (is_ecmp) {
            for (i = 0; i < hash_bit_list_cnt; i++) {
                hash_bits |= hash_bit_list_p[i];
            }
            __general_hash_to_pp_ecmp_hash_params(hash_bits,
                                                  hash_field_enable_list_p,
                                                  &hash_field_enable_list_cnt,
                                                  hash_field_list_p,
                                                  &hash_field_list_cnt);

            status = __fetch_hash_config_from_hash_fields(hash_field_enable_list_p,
                                                          hash_field_enable_list_cnt,
                                                          hash_field_list_p,
                                                          hash_field_list_cnt,
                                                          hash_config_p);
            if (HASH_CALC_CHECK_FAIL(status)) {
                SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
                goto out;
            }
        } else {
            for (i = 0; i < hash_bit_list_cnt; i++) {
                hash_bits |= 1 << hash_bit_list_p[i];
            }
            hash_field_list_cnt = SX_LAG_HASH_FIELDS_NUM;
            hash_field_enable_list_cnt = SX_LAG_HASH_FIELD_ENABLES_NUM;
            __general_hash_to_pp_lag_hash_params(hash_bits,
                                                 lag_port_hash_fields_p,
                                                 &hash_field_list_cnt,
                                                 lag_port_hash_enables_p,
                                                 &hash_field_enable_list_cnt);

            status = __fetch_lag_hash_config_from_hash_fields(lag_port_hash_enables_p,
                                                              hash_field_enable_list_cnt,
                                                              lag_port_hash_fields_p,
                                                              hash_field_list_cnt,
                                                              hash_config_p);
            if (HASH_CALC_CHECK_FAIL(status)) {
                SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
                goto out;
            }
        }
    }

out:
    if (hash_bit_list_p) {
        free(hash_bit_list_p);
    }
    return status;
}

static hash_calc_status_t __fetch_hash_config_from_json_obj(cJSON                  * p_parent_json_obj,
                                                            boolean_t                is_ecmp,
                                                            hash_calc_hash_config_t *hash_config_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                is_per_port = 0;
    cJSON             *p_hash_config = p_parent_json_obj;
    cJSON             *p_is_per_port = NULL;
    cJSON             *p_global = NULL;
    cJSON             *p_per_port = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_PER_PORT;
    p_is_per_port = cJSON_GetObjectItem(p_hash_config, json_elem_str);
    if (p_is_per_port) {
        is_per_port = p_is_per_port->valueint;
    }

    if (is_per_port == 0) {
        json_elem_str = KEY_STR_GLOBAL;
        SAFE_GET_CJSON_OBJ_ITEM(p_hash_config, json_elem_str, &p_global);
        if (!p_global) {
            SX_LOG_ERR("Fails to parse hash config: no entry '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_NOT_FOUND;
            goto out;
        }
        status = __fetch_hash_global_config_from_json_obj(p_global, is_ecmp, hash_config_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
    } else {
        json_elem_str = KEY_STR_PORT;
        SAFE_GET_CJSON_OBJ_ITEM(p_hash_config, json_elem_str, &p_per_port);
        if (!p_per_port) {
            SX_LOG_ERR("Fails to parse hash config: no entry '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_NOT_FOUND;
            goto out;
        }
        status = __fetch_hash_per_port_config_from_json_obj(p_per_port, is_ecmp, hash_config_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
    }

out:
    return status;
}

static hash_calc_status_t __fetch_outer_inner_common_packet_info_from_json_obj(cJSON             * p_parent_json_obj,
                                                                               hash_calc_packet_t *packet_p,
                                                                               boolean_t           is_inner)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_json_elem = NULL;
    cJSON             *p_layer2 = NULL;
    cJSON             *p_ipv4 = NULL;
    cJSON             *p_ipv6 = NULL;
    cJSON             *p_sip = NULL;
    cJSON             *p_dip = NULL;
    cJSON             *p_ipv4_proto = NULL;
    cJSON             *p_next_header = NULL;
    cJSON             *p_flow_label = NULL;
    cJSON             *p_mflag = NULL;
    cJSON             *p_sport = NULL;
    cJSON             *p_dport = NULL;
    cJSON             *p_tcp_udp = NULL;
    char              *json_elem_str = NULL;
    char              *in_out_str = NULL;
    uint8_t           *smac;
    uint8_t           *dmac;
    uint16_t          *ethertype;
    uint8_t           *ip_version;
    uint8_t           *sip;
    uint8_t           *dip;
    uint8_t           *ipv4_proto;
    uint8_t           *next_header;
    uint32_t          *flow_label;
    uint8_t           *mflag;
    uint16_t          *sport;
    uint16_t          *dport;

    if (is_inner) {
        smac = &(packet_p->inner_smac[0]);
        dmac = &(packet_p->inner_dmac[0]);
        ethertype = &(packet_p->inner_ethertype);
        ip_version = &(packet_p->inner_ip_version);
        sip = &(packet_p->inner_sip[0]);
        dip = &(packet_p->inner_dip[0]);
        ipv4_proto = &(packet_p->inner_ipv4_proto);
        next_header = &(packet_p->inner_next_header);
        flow_label = &(packet_p->inner_flow_label);
        mflag = &(packet_p->inner_mflag);
        sport = &(packet_p->inner_sport);
        dport = &(packet_p->inner_dport);
        in_out_str = KEY_STR_INNER;
    } else {
        smac = &(packet_p->smac[0]);
        dmac = &(packet_p->dmac[0]);
        ethertype = &(packet_p->ethertype);
        ip_version = &(packet_p->ip_version);
        sip = &(packet_p->sip[0]);
        dip = &(packet_p->dip[0]);
        ipv4_proto = &(packet_p->ipv4_proto);
        next_header = &(packet_p->next_header);
        flow_label = &(packet_p->flow_label);
        mflag = &(packet_p->mflag);
        sport = &(packet_p->sport);
        dport = &(packet_p->dport);
        in_out_str = KEY_STR_OUTER;
    }

    json_elem_str = KEY_STR_LAYER2;
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, json_elem_str, &p_layer2);

    p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_SMAC);
    if (p_json_elem) {
        if (__str_to_mac(p_json_elem->valuestring, smac) < 0) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

    p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_DMAC);
    if (p_json_elem) {
        if (__str_to_mac(p_json_elem->valuestring, dmac) < 0) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

    /* ethertype : no further IP check now, e.g., 0x800 (IPv4), 0x86DD (IPv6), etc. */
    p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_ETHERTYPE);
    if (p_json_elem) {
        *ethertype = p_json_elem->valueint;
    }

    /* we assume that 'ipv4' and 'ipv6' should not co-exist, otherwise warning and take 'ipv4'. */
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_IPV4, &p_ipv4);
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_IPV6, &p_ipv6);
    if (p_ipv4) {
        if (p_ipv6) {
            SX_LOG_WRN(
                "Parse packet_info '%s': both '%s' and '%s' exist in json file, '%s' info will be ignored.\n",
                in_out_str,
                KEY_STR_IPV4,
                KEY_STR_IPV6,
                KEY_STR_IPV6);
        }
        *ip_version = 4;
        p_sip = cJSON_GetObjectItem(p_ipv4, KEY_STR_SIP);
        if (p_sip && (inet_pton(AF_INET, p_sip->valuestring, sip) <= 0)) {
            SX_LOG_ERR("Fails to parse '%s': '%s' sip address %s.\n", in_out_str, KEY_STR_IPV4, p_sip->valuestring);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
        p_dip = cJSON_GetObjectItem(p_ipv4, KEY_STR_DIP);
        if (p_dip && (inet_pton(AF_INET, p_dip->valuestring, dip) <= 0)) {
            SX_LOG_ERR("Fails to parse '%s': '%s' dip address %s.\n", in_out_str, KEY_STR_IPV4, p_dip->valuestring);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
        p_ipv4_proto = cJSON_GetObjectItem(p_ipv4, KEY_STR_PROTO);
        if (p_ipv4_proto) {
            *ipv4_proto = p_ipv4_proto->valueint;
        }
        p_mflag = cJSON_GetObjectItem(p_ipv4, KEY_STR_MFLAG);
        if (p_mflag) {
            *mflag = p_mflag->valueint;
        }
    } else {
        if (p_ipv6) {
            *ip_version = 6;
            p_sip = cJSON_GetObjectItem(p_ipv6, KEY_STR_SIP);
            if (p_sip && (inet_pton(AF_INET6, p_sip->valuestring, sip) <= 0)) {
                SX_LOG_ERR("Fails to parse '%s': 'ipv6' sip address %s.\n", in_out_str, p_sip->valuestring);
                status = HASH_CALC_STATUS_PARSE_ERR;
                goto out;
            }
            p_dip = cJSON_GetObjectItem(p_ipv6, KEY_STR_DIP);
            if (p_dip && (inet_pton(AF_INET6, p_dip->valuestring, dip) <= 0)) {
                SX_LOG_ERR("Fails to parse '%s': 'ipv6' dip address %s.\n", in_out_str, p_dip->valuestring);
                status = HASH_CALC_STATUS_PARSE_ERR;
                goto out;
            }
            p_next_header = cJSON_GetObjectItem(p_ipv6, KEY_STR_NEXT_HEADER);
            if (p_next_header) {
                *next_header = p_next_header->valueint;
            }
            p_flow_label = cJSON_GetObjectItem(p_ipv6, KEY_STR_FLOW_LABEL);
            if (p_flow_label) {
                *flow_label = p_flow_label->valueint;
            }
            p_mflag = cJSON_GetObjectItem(p_ipv6, KEY_STR_MFLAG);
            if (p_mflag) {
                *mflag = p_mflag->valueint;
            }
        }
    }

    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_TCP_UDP, &p_tcp_udp);
    if (p_tcp_udp) {
        p_sport = cJSON_GetObjectItem(p_tcp_udp, KEY_STR_SPORT);
        if (p_sport) {
            *sport = p_sport->valueint;
        }
        p_dport = cJSON_GetObjectItem(p_tcp_udp, KEY_STR_DPORT);
        if (p_dport) {
            *dport = p_dport->valueint;
        }
    }

out:
    return status;
}

static hash_calc_status_t __fetch_remaining_outer_packet_info_from_json_obj(cJSON             * p_parent_json_obj,
                                                                            hash_calc_packet_t *packet_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                i = 0, arr_size = 0;
    cJSON             *p_json_elem = NULL;
    cJSON             *p_json_arr = NULL;
    cJSON             *p_layer2 = NULL;
    cJSON             *p_arp = NULL;
    cJSON             *p_ipv4 = NULL;
    cJSON             *p_ipv6 = NULL;
    cJSON             *p_mpls = NULL;
    cJSON             *p_vxlan_nvgre = NULL;
    cJSON             *p_gre = NULL;
    char              *json_elem_str = NULL;

    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_LAYER2, &p_layer2);
    if (p_layer2) {
        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_OUTER_VID);
        if (p_json_elem) {
            packet_p->vid = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_OUTER_PCP);
        if (p_json_elem) {
            packet_p->pcp = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_OUTER_DEI);
        if (p_json_elem) {
            packet_p->dei = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_INNER_VID);
        if (p_json_elem) {
            packet_p->inner_vid = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_INNER_PCP);
        if (p_json_elem) {
            packet_p->inner_pcp = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_layer2, KEY_STR_INNER_DEI);
        if (p_json_elem) {
            packet_p->inner_dei = p_json_elem->valueint;
        }
    }

    json_elem_str = KEY_STR_ARP;
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, json_elem_str, &p_arp);
    if (p_arp) {
        p_json_elem = cJSON_GetObjectItem(p_arp, KEY_STR_SPA);
        if (p_json_elem) {
            if (inet_pton(AF_INET, p_json_elem->valuestring, &(packet_p->arp_spa[0])) <= 0) {
                SX_LOG_ERR("Fails to parse '%s': '%s' %s.\n", json_elem_str, KEY_STR_SPA, p_json_elem->valuestring);
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
        }
        p_json_elem = cJSON_GetObjectItem(p_arp, KEY_STR_TPA);
        if (p_json_elem) {
            if (inet_pton(AF_INET, p_json_elem->valuestring, &(packet_p->arp_tpa[0])) <= 0) {
                SX_LOG_ERR("Fails to parse '%s': '%s' %s.\n", json_elem_str, KEY_STR_TPA, p_json_elem->valuestring);
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
        }
    }

    /* we assume that 'ipv4' and 'ipv6' should not co-exist, otherwise warning and take 'ipv4'. */
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_IPV4, &p_ipv4);
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_IPV6, &p_ipv6);
    if (p_ipv4) {
        p_json_elem = cJSON_GetObjectItem(p_ipv4, KEY_STR_DSCP);
        if (p_json_elem) {
            packet_p->dscp = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_ipv4, KEY_STR_ECN);
        if (p_json_elem) {
            packet_p->ecn = p_json_elem->valueint;
        }

        p_json_elem = cJSON_GetObjectItem(p_ipv4, KEY_STR_L3_LENGTH);
        if (p_json_elem) {
            packet_p->l3_length = p_json_elem->valueint;
        }
    } else {
        if (p_ipv6) {
            p_json_elem = cJSON_GetObjectItem(p_ipv6, KEY_STR_DSCP);
            if (p_json_elem) {
                packet_p->dscp = p_json_elem->valueint;
            }

            p_json_elem = cJSON_GetObjectItem(p_ipv6, KEY_STR_ECN);
            if (p_json_elem) {
                packet_p->ecn = p_json_elem->valueint;
            }

            p_json_elem = cJSON_GetObjectItem(p_ipv6, KEY_STR_L3_LENGTH);
            if (p_json_elem) {
                packet_p->l3_length = p_json_elem->valueint;
            }
        }
    }

    json_elem_str = KEY_STR_MPLS;
    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, json_elem_str, &p_mpls);
    if (p_mpls) {
        SAFE_GET_CJSON_OBJ_ITEM(p_mpls, KEY_STR_LABEL_ID, &p_json_arr);
        if (p_json_arr) {
            if (!cJSON_IsArray(p_json_arr)) {
                SX_LOG_ERR("Fails to parse '%s': '%s' not a JSON array.\n", json_elem_str, KEY_STR_LABEL_ID);
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
            arr_size = cJSON_GetArraySize(p_json_arr);
            if (arr_size > (int)(sizeof(packet_p->mpls_labels) / sizeof(uint32_t))) {
                SX_LOG_ERR("Fails to parse '%s': '%s' array size %d is bigger than %lu.\n",
                           json_elem_str,
                           KEY_STR_LABEL_ID,
                           arr_size,
                           sizeof(packet_p->mpls_labels) / sizeof(uint32_t));
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
            for (i = 0; i < arr_size; i++) {
                p_json_elem = cJSON_GetArrayItem(p_json_arr, i);
                packet_p->mpls_labels[i] = p_json_elem->valueint;
            }
            packet_p->mpls_stack_size = arr_size;
        }
    }

    p_vxlan_nvgre = cJSON_GetObjectItem(p_parent_json_obj, KEY_STR_VXLAN_NVGRE);
    if (p_vxlan_nvgre) {
        p_json_elem = cJSON_GetObjectItem(p_vxlan_nvgre, KEY_STR_VNI);
        if (p_json_elem) {
            packet_p->vni = p_json_elem->valueint;
        }
    }

    SAFE_GET_CJSON_OBJ_ITEM(p_parent_json_obj, KEY_STR_GRE, &p_gre);
    if (p_gre) {
        p_json_elem = cJSON_GetObjectItem(p_gre, KEY_STR_PROTO);
        if (p_json_elem) {
            packet_p->gre_proto = p_json_elem->valueint;
        }
        p_json_elem = cJSON_GetObjectItem(p_gre, KEY_STR_KEY);
        if (p_json_elem) {
            if (__safe_get_cjson_u32_number_item(p_json_elem, &(packet_p->gre_key))) {
                SX_LOG_ERR("Fails to parse '%s':'%s'.\n", KEY_STR_GRE, KEY_STR_KEY);
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
        }
    }

out:
    return status;
}

static hash_calc_status_t __fetch_packet_info_from_json_obj(cJSON *p_parent_json_obj, hash_calc_packet_t *packet_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_packet_info = p_parent_json_obj;
    cJSON             *p_outer = NULL;
    cJSON             *p_inner = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_OUTER;
    SAFE_GET_CJSON_OBJ_ITEM(p_packet_info, json_elem_str, &p_outer);
    if (p_outer) {
        status = __fetch_outer_inner_common_packet_info_from_json_obj(p_outer, packet_p, 0);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
        status = __fetch_remaining_outer_packet_info_from_json_obj(p_outer, packet_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s' remaining part.\n", json_elem_str);
            goto out;
        }
    }

    json_elem_str = KEY_STR_INNER;
    SAFE_GET_CJSON_OBJ_ITEM(p_packet_info, json_elem_str, &p_inner);
    if (p_inner) {
        status = __fetch_outer_inner_common_packet_info_from_json_obj(p_inner, packet_p, 1);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fails to parse '%s'.\n", json_elem_str);
            goto out;
        }
    }

out:
    return status;
}

static int __fetch_packet_meta_from_json_obj(cJSON * p_parent_json_obj, hash_calc_packet_meta_t *packet_meta_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                err = 0, i = 0, arr_size = 0;
    long int           t = 0;
    cJSON             *p_ecmp_hash = p_parent_json_obj;
    cJSON             *p_ingress_port = NULL;
    cJSON             *p_json_elem = NULL;
    cJSON             *p_json_arr = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_INGRESS_PORT;
    SAFE_GET_CJSON_OBJ_ITEM(p_ecmp_hash, json_elem_str, &p_ingress_port);
    if (p_ingress_port) {
        err = __str_to_int(p_ingress_port->valuestring, &t, 16);
        if (err) {
            SX_LOG_ERR("Fails to parse '%s': %s \n", json_elem_str, p_ingress_port->valuestring);
            status = HASH_CALC_STATUS_PARSE_ERR;
            goto out;
        }
        packet_meta_p->local_port = SX_PORT_PHY_ID_GET(t);
    } else {
        SX_LOG_ERR("Fails to parse '%s': no such entry. \n", json_elem_str);
        status = HASH_CALC_STATUS_NOT_FOUND;
        goto out;
    }

    json_elem_str = KEY_STR_CUSTOM_BYTES;
    SAFE_GET_CJSON_OBJ_ITEM(p_ecmp_hash, json_elem_str, &p_json_arr);
    if (p_json_arr) {
        if (!cJSON_IsArray(p_json_arr)) {
            SX_LOG_ERR("Fails to parse '%s': not a JSON array.\n", json_elem_str);
            status = HASH_CALC_STATUS_PARSE_ERR;
            goto out;
        }
        arr_size = cJSON_GetArraySize(p_json_arr);
        if (arr_size > (int)sizeof(packet_meta_p->custom_bytes)) {
            SX_LOG_ERR("Fails to parse '%s': array size %u is bigger than %lu.\n", json_elem_str, arr_size,
                       sizeof(packet_meta_p->custom_bytes));
            status = HASH_CALC_STATUS_PARSE_ERR;
            goto out;
        }
        for (i = 0; i < arr_size; i++) {
            p_json_elem = cJSON_GetArrayItem(p_json_arr, i);
            t = strtol(p_json_elem->valuestring, NULL, 16);
            if (t > 0xFF) {
                SX_LOG_ERR("Fails to parse '%s': array idx %d is bigger than 'FF'.\n", json_elem_str, i);
                status = HASH_CALC_STATUS_PARSE_ERR;
                goto out;
            }
            packet_meta_p->custom_bytes[i] = t & 0xff;
        }
    }
out:
    return status;
}

static hash_calc_status_t __fetch_asic_from_json_obj(cJSON * p_parent_json_obj, hash_calc_asic_type_e *asic)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_asic_type = NULL;

    p_asic_type = cJSON_GetObjectItem(p_parent_json_obj, KEY_STR_ASIC_TYPE);
    if (p_asic_type) {
        if (!strcmp(p_asic_type->valuestring, STR_ASIC_TYPE_SPC2)) {
            *asic = HASH_CALC_ASIC_TYPE_SPC_2_E;
        } else if (!strcmp(p_asic_type->valuestring, STR_ASIC_TYPE_SPC3)) {
            *asic = HASH_CALC_ASIC_TYPE_SPC_3_E;
        } else if (!strcmp(p_asic_type->valuestring, STR_ASIC_TYPE_SPC4)) {
            *asic = HASH_CALC_ASIC_TYPE_SPC_4_E;
        } else if ((!strcmp(p_asic_type->valuestring, STR_ASIC_TYPE_SPC1)) ||
                   (!strcmp(p_asic_type->valuestring, STR_ASIC_TYPE_SPC1_ALIAS))) {
            *asic = HASH_CALC_ASIC_TYPE_SPC_1_E;
        } else {
            SX_LOG_ERR("Fails to parse '%s': unknown %s \n", KEY_STR_ASIC_TYPE, p_asic_type->valuestring);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

out:
    return status;
}

static hash_calc_status_t __fetch_extra_info_from_json_obj(cJSON                 * p_parent_json_obj,
                                                           boolean_t               is_offline,
                                                           boolean_t               is_ecmp,
                                                           hash_calc_extra_info_t *extra_info_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_ecmp_hash = p_parent_json_obj;
    cJSON             *p_size = NULL;
    cJSON             *p_nve_udp_dport = NULL;
    cJSON             *p_pvid = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_ECMP_SIZE;
    if (!is_ecmp) {
        json_elem_str = KEY_STR_LAG_SIZE;
    }
    p_size = cJSON_GetObjectItem(p_ecmp_hash, json_elem_str);
    if (p_size) {
        extra_info_p->size = p_size->valueint;
    }

    if (is_offline) {
        status = __fetch_asic_from_json_obj(p_ecmp_hash, &(extra_info_p->asic));
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fail to parse '%s'.\n", p_ecmp_hash->string);
            goto out;
        }

        p_nve_udp_dport = cJSON_GetObjectItem(p_ecmp_hash, KEY_STR_NVE_UDP_DPORT);
        if (p_nve_udp_dport) {
            extra_info_p->nve_udp_dport = p_nve_udp_dport->valueint;
        }

        p_pvid = cJSON_GetObjectItem(p_ecmp_hash, KEY_STR_PVID);
        if (p_pvid) {
            extra_info_p->pvid = p_pvid->valueint;
        }
    }

out:
    return status;
}

hash_calc_status_t parse_ecmp_lag_input_json(cJSON                  * p_parent_json_obj,
                                             boolean_t                is_ecmp,
                                             hash_calc_hash_config_t *hash_config_p,
                                             boolean_t               *is_offline,
                                             hash_calc_packet_t      *packet_p,
                                             hash_calc_packet_meta_t *packet_meta_p,
                                             hash_calc_extra_info_t  *extra_info_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                offline = 0;
    cJSON             *p_hash = p_parent_json_obj;
    cJSON             *p_hash_config = NULL;
    cJSON             *p_packet_info = NULL;
    cJSON             *p_offline = NULL;
    char              *json_elem_str = NULL;

    p_offline = cJSON_GetObjectItem(p_hash, KEY_STR_OFFLINE);
    if (p_offline) {
        offline = p_offline->valueint;
    }
    *is_offline = TRUE;
    if (!offline) {
        *is_offline = FALSE;
    }

    if (*is_offline) {
        json_elem_str = KEY_STR_ECMP_HASH_CONFIG;
        if (!is_ecmp) {
            json_elem_str = KEY_STR_LAG_HASH_CONFIG;
        }

        SAFE_GET_CJSON_OBJ_ITEM(p_hash, json_elem_str, &p_hash_config);
        if (!p_hash_config) {
            /* fetch hash config */
            status = HASH_CALC_STATUS_PARSE_ERR;
            SX_LOG_ERR("Fail to parse: no '%s' is found in offline mode.\n", json_elem_str);
            goto out;
        } else {
            status = __fetch_hash_config_from_json_obj(p_hash_config, is_ecmp, hash_config_p);
            if (HASH_CALC_CHECK_FAIL(status)) {
                status = HASH_CALC_STATUS_PARSE_ERR;
                SX_LOG_ERR("Fail to parse '%s'.\n", json_elem_str);
                goto out;
            }
        }
    }

    /* fetch packet info */
    json_elem_str = KEY_STR_PACKET_INFO;
    SAFE_GET_CJSON_OBJ_ITEM(p_hash, json_elem_str, &p_packet_info);
    if (NULL == p_packet_info) {
        status = HASH_CALC_STATUS_PARSE_ERR;
        SX_LOG_ERR("Fail to parse: no '%s' is found.\n", json_elem_str);
        goto out;
    }
    status = __fetch_packet_info_from_json_obj(p_packet_info, packet_p);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fail to parse '%s'.\n", json_elem_str);
        goto out;
    }

    /* fetch packet meta info */
    status = __fetch_packet_meta_from_json_obj(p_hash, packet_meta_p);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fail to parse packet meta info.\n");
        goto out;
    }

    /* fetch extra-info */
    status = __fetch_extra_info_from_json_obj(p_hash, *is_offline, is_ecmp, extra_info_p);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fail to parse packet meta info.\n");
        goto out;
    }

out:
    return status;
}

hash_calc_status_t parse_ecmp_rehash_input_json(cJSON                    *p_parent_json_obj,
                                                hash_calc_rehash_param_t *rehash_param_p,
                                                hash_calc_extra_info_t   *extra_info_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_hash_param = p_parent_json_obj;
    cJSON             *p_hash_value = NULL;
    cJSON             *p_size = NULL;
    char              *json_elem_str = NULL;

    json_elem_str = KEY_STR_ECMP_REHASH;
    status = __fetch_hash_type_seed_from_json_obj(p_hash_param, &(rehash_param_p->type), &(rehash_param_p->seed));
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fail to parse '%s': fail to fetch hash type and seed.\n", json_elem_str);
        goto out;
    }

    p_hash_value = cJSON_GetObjectItem(p_hash_param, KEY_STR_HASH_VALUE);
    if (!p_hash_value) {
        status = HASH_CALC_STATUS_NOT_FOUND;
        SX_LOG_ERR("Fail to parse '%s': no '%s' is found.\n", json_elem_str, KEY_STR_HASH_VALUE);
        goto out;
    }

    if (__safe_get_cjson_u32_number_item(p_hash_value, &(rehash_param_p->old_hash_value))) {
        status = HASH_CALC_STATUS_PARSE_ERR;
        SX_LOG_ERR("Fails to parse '%s':'%s'.\n", json_elem_str, KEY_STR_HASH_VALUE);
        goto out;
    }

    status = __fetch_asic_from_json_obj(p_hash_param, &(extra_info_p->asic));
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("Fail to parse '%s'.\n", json_elem_str);
        goto out;
    }

    p_size = cJSON_GetObjectItem(p_hash_param, KEY_STR_ECMP_SIZE);
    if (p_size) {
        extra_info_p->size = (uint32_t)p_size->valueint;
    }

out:
    return status;
}

static hash_calc_status_t __get_ecmp_hash_config_online(uint16_t local_port, hash_calc_hash_config_t *hash_config_p)
{
    sxd_reg_meta_t        recr_v2_reg_meta;
    struct ku_recr_v2_reg recr_v2_reg_data;
    sxd_status_t          sxd_status = SXD_STATUS_SUCCESS;
    hash_calc_status_t    status = HASH_CALC_STATUS_SUCCESS;
    int                   i = 0;

    memset(&recr_v2_reg_meta, 0, sizeof(sxd_reg_meta_t));
    memset(&recr_v2_reg_data, 0, sizeof(struct ku_recr_v2_reg));

    recr_v2_reg_meta.dev_id = 1;
    recr_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;


    recr_v2_reg_data.per_port_configuration = 1;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(recr_v2_reg_data.local_port, recr_v2_reg_data.lp_msb, local_port);

    sxd_status = sxd_access_reg_recr_v2(&recr_v2_reg_data, &recr_v2_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_DBG("No per port ecmp hash configuration for port %d, status = %d\n", local_port, sxd_status);
        recr_v2_reg_data.per_port_configuration = 0;
        recr_v2_reg_data.local_port = 0;
        recr_v2_reg_data.lp_msb = 0;

        SX_LOG_DBG("Take global ecmp hash configuration\n");
        sxd_status = sxd_access_reg_recr_v2(&recr_v2_reg_data, &recr_v2_reg_meta, 1, NULL, NULL);

        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to read global recr_v2, status = %d\n", sxd_status);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

    memset(hash_config_p, 0, sizeof(hash_calc_hash_config_t));

    hash_config_p->general_fields = recr_v2_reg_data.general_fields;
    hash_config_p->type = (hash_calc_hash_type_t)recr_v2_reg_data.hash_type;
    hash_config_p->sh = recr_v2_reg_data.symmetric_hash;
    hash_config_p->seed = recr_v2_reg_data.seed;
    hash_config_p->outer_header_enables = recr_v2_reg_data.outer_header_enables;
    hash_config_p->inner_header_enables = recr_v2_reg_data.inner_header_enables;
    hash_config_p->inner_header_fields_enable = recr_v2_reg_data.inner_header_field_enables;
    memcpy(hash_config_p->outer_header_fields_enable, recr_v2_reg_data.outer_header_field_enables,
           sizeof(hash_config_p->outer_header_fields_enable));

    SX_LOG_DBG("sx_hash_calc: type = %d, sh = %d, seed = %d, outer_header_enables = 0x%x\n",
               hash_config_p->type, hash_config_p->sh, hash_config_p->seed, hash_config_p->outer_header_enables);
    for (i = 0; i < 5; i++) {
        SX_LOG_DBG("outer_header_field_enables[%d] = 0x%x\n", i, recr_v2_reg_data.outer_header_field_enables[i]);
    }
    SX_LOG_DBG("inner_header_enables = 0x%x, inner_header_fields_enable = 0x%lx\n",
               recr_v2_reg_data.inner_header_enables, recr_v2_reg_data.inner_header_field_enables);

out:
    return status;
}

static hash_calc_status_t __get_lag_hash_config_online(uint16_t local_port, hash_calc_hash_config_t *hash_config_p)
{
    sxd_reg_meta_t        slcr_v2_reg_meta;
    struct ku_slcr_v2_reg slcr_v2_reg_data;
    sxd_status_t          sxd_status = SXD_STATUS_SUCCESS;
    hash_calc_status_t    status = HASH_CALC_STATUS_SUCCESS;
    int                   i = 0;

    memset(&slcr_v2_reg_meta, 0, sizeof(sxd_reg_meta_t));
    memset(&slcr_v2_reg_data, 0, sizeof(struct ku_slcr_v2_reg));

    slcr_v2_reg_meta.dev_id = 1;
    slcr_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;


    slcr_v2_reg_data.pp = 1;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(slcr_v2_reg_data.local_port, slcr_v2_reg_data.lp_msb, local_port);

    sxd_status = sxd_access_reg_slcr_v2(&slcr_v2_reg_data, &slcr_v2_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_DBG("No per port lag hash configuration for port %d, status = %d\n", local_port, sxd_status);
        slcr_v2_reg_data.pp = 0;
        slcr_v2_reg_data.local_port = 0;
        slcr_v2_reg_data.lp_msb = 0;

        SX_LOG_DBG("Take global lag hash configuration\n");
        sxd_status = sxd_access_reg_slcr_v2(&slcr_v2_reg_data, &slcr_v2_reg_meta, 1, NULL, NULL);

        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to read global slcr_v2, status = %d\n", sxd_status);
            status = HASH_CALC_STATUS_ERROR;
            goto out;
        }
    }

    memset(hash_config_p, 0, sizeof(hash_calc_hash_config_t));

    hash_config_p->general_fields = slcr_v2_reg_data.general_fields;
    hash_config_p->type = (hash_calc_hash_type_t)slcr_v2_reg_data.type;
    hash_config_p->sh = slcr_v2_reg_data.sh;
    hash_config_p->seed = slcr_v2_reg_data.seed;
    hash_config_p->outer_header_enables = slcr_v2_reg_data.outer_header_enables;
    hash_config_p->inner_header_enables = slcr_v2_reg_data.inner_header_enables;
    hash_config_p->inner_header_fields_enable = slcr_v2_reg_data.inner_header_fields_enable;
    memcpy(hash_config_p->outer_header_fields_enable, slcr_v2_reg_data.outer_header_fields_enable,
           sizeof(hash_config_p->outer_header_fields_enable));

    SX_LOG_DBG("sx_hash_calc: type = %d, sh = %d, seed = %d, outer_header_enables = 0x%x\n",
               hash_config_p->type, hash_config_p->sh, hash_config_p->seed, hash_config_p->outer_header_enables);
    for (i = 0; i < 5; i++) {
        SX_LOG_DBG("outer_header_field_enables[%d] = 0x%x.\n", i, slcr_v2_reg_data.outer_header_fields_enable[i]);
    }
    SX_LOG_DBG("inner_header_enables = 0x%x, inner_header_fields_enable = 0x%lx\n",
               slcr_v2_reg_data.inner_header_enables, slcr_v2_reg_data.inner_header_fields_enable);

out:
    return status;
}

static hash_calc_status_t __get_asic_type(hash_calc_asic_type_e *asic_type_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_mgir_reg mgir_reg_data;
    sxd_reg_meta_t     mgir_reg_meta;

    SX_MEM_CLR(mgir_reg_data);
    SX_MEM_CLR(mgir_reg_meta);

    mgir_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    mgir_reg_meta.dev_id = 1;

    sxd_status = sxd_access_reg_mgir(&mgir_reg_data, &mgir_reg_meta, 1, NULL, NULL);

    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("mgir register access fail: status = %d\n", sxd_status);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    switch (mgir_reg_data.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        *asic_type_p = HASH_CALC_ASIC_TYPE_SPC_1_E;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *asic_type_p = HASH_CALC_ASIC_TYPE_SPC_2_E;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *asic_type_p = HASH_CALC_ASIC_TYPE_SPC_3_E;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *asic_type_p = HASH_CALC_ASIC_TYPE_SPC_4_E;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *asic_type_p = HASH_CALC_ASIC_TYPE_SPC_5_E;
        break;

    default:
        status = HASH_CALC_STATUS_ERROR;
        SX_LOG_ERR("Chip 0x%x is not supported.\n", mgir_reg_data.hw_info.device_id);
        break;
    }

out:
    return status;
}

static hash_calc_status_t __get_pvid(uint16_t local_port, sx_vid_t *pvid_p)
{
    hash_calc_status_t  status = HASH_CALC_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_spvid_reg spvid_reg_data;
    sxd_reg_meta_t      spvid_reg_meta;

    SX_MEM_CLR(spvid_reg_data);
    SX_MEM_CLR(spvid_reg_meta);

    spvid_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    spvid_reg_meta.dev_id = 1;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(spvid_reg_data.local_port, spvid_reg_data.lp_msb, local_port);

    sxd_status = sxd_access_reg_spvid(&spvid_reg_data, &spvid_reg_meta, 1, NULL, NULL);

    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("spvid register access fail: status = %d\n", sxd_status);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    if (NULL != pvid_p) {
        *pvid_p = spvid_reg_data.port_default_vid;
    }

out:
    return status;
}

hash_calc_status_t parse_input_json(char                    * pMsg,
                                    hash_calc_hash_config_t  *hash_config_p,
                                    input_json_file_type_e   *input_type_p,
                                    hash_calc_packet_t       *packet_p,
                                    hash_calc_packet_meta_t  *packet_meta_p,
                                    hash_calc_extra_info_t   *extra_info_p,
                                    hash_calc_rehash_param_t *rehash_param_p)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *p_ecmp_hash = NULL;
    cJSON             *p_ecmp_rehash = NULL;
    cJSON             *p_lag_hash = NULL;
    cJSON             *p_hash = NULL;
    cJSON             *p_json_root = NULL;
    int                hash_config_cnt = 0;
    boolean_t          is_offline = FALSE;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    boolean_t          sxd_reg_inited = FALSE;
    boolean_t          is_ecmp = FALSE;

    if (!pMsg || !hash_config_p || !packet_p || !packet_meta_p || !extra_info_p) {
        status = HASH_CALC_STATUS_PARAM_ERR;
        SX_LOG_ERR("Some input params are NULL.\n");
        goto out;
    }

    p_json_root = cJSON_Parse(pMsg);
    if (NULL == p_json_root) {
        status = HASH_CALC_STATUS_PARSE_ERR;
        SX_LOG_ERR("Fail to parse string as a JSON root.\n");
        goto out;
    }

    if (!is_valid_json_obj(p_json_root)) {
        status = HASH_CALC_STATUS_PARAM_ERR;
        SX_LOG_ERR("Fail due to invalid json content.\n");
        goto out;
    }

    SAFE_GET_CJSON_OBJ_ITEM(p_json_root, KEY_STR_ECMP_HASH, &p_ecmp_hash);
    SAFE_GET_CJSON_OBJ_ITEM(p_json_root, KEY_STR_LAG_HASH, &p_lag_hash);
    SAFE_GET_CJSON_OBJ_ITEM(p_json_root, KEY_STR_ECMP_REHASH, &p_ecmp_rehash);

    if (p_ecmp_hash) {
        *input_type_p = CONFIG_ECMP_HASH_E;
        p_hash = p_ecmp_hash;
        hash_config_cnt++;
    }
    if (p_lag_hash) {
        *input_type_p = CONFIG_LAG_HASH_E;
        p_hash = p_lag_hash;
        hash_config_cnt++;
    }
    if (p_ecmp_rehash) {
        *input_type_p = CONFIG_ECMP_REHASH_E;
        p_hash = p_ecmp_rehash;
        hash_config_cnt++;
    }
    if (hash_config_cnt == 0) {
        SX_LOG_ERR("No config in json.\n");
        status = HASH_CALC_STATUS_NOT_FOUND;
        goto out;
    }
    if (hash_config_cnt > 1) {
        SX_LOG_ERR("Can only have one config.\n");
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }
    if (p_ecmp_hash || p_lag_hash) {
        is_ecmp = (p_ecmp_hash != NULL) ? TRUE : FALSE;
        status = parse_ecmp_lag_input_json(p_hash,
                                           is_ecmp,
                                           hash_config_p,
                                           &is_offline,
                                           packet_p,
                                           packet_meta_p,
                                           extra_info_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fail to parse hash config, is_ecmp = %d.\n", is_ecmp);
            goto out;
        }
        if (!is_offline) {
            sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_ERROR);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed init reg access, status = %d\n", sxd_status);
                status = HASH_CALC_STATUS_ERROR;
                goto out;
            }
            sxd_reg_inited = TRUE;

            status = __get_asic_type(&extra_info_p->asic);
            if (HASH_CALC_CHECK_FAIL(status)) {
                SX_LOG_ERR("Fail to get asic type.\n");
                goto out;
            }

            extra_info_p->nve_udp_dport = NVE_UDP_DPORT_DEFAULT;    /* Not configurable by SDK, can get from MPRS in the future */

            status = __get_pvid(packet_meta_p->local_port, &extra_info_p->pvid);
            if (HASH_CALC_CHECK_FAIL(status)) {
                SX_LOG_ERR("Fail to get port pvid.\n");
                goto out;
            }

            if (is_ecmp) {
                status = __get_ecmp_hash_config_online(packet_meta_p->local_port, hash_config_p);
                if (HASH_CALC_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Fail to get ecmp hash config online.\n");
                    goto out;
                }
            } else {
                status = __get_lag_hash_config_online(packet_meta_p->local_port, hash_config_p);
                if (HASH_CALC_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Fail to get lag hash config online.\n");
                    goto out;
                }
            }
        }
        goto out;
    }

    if (p_ecmp_rehash) {
        status = parse_ecmp_rehash_input_json(p_ecmp_rehash, rehash_param_p, extra_info_p);
        if (HASH_CALC_CHECK_FAIL(status)) {
            SX_LOG_ERR("Fail to parse '%s'.\n", KEY_STR_ECMP_REHASH);
            goto out;
        }
        goto out;
    }
out:
    if (sxd_reg_inited) {
        sxd_access_reg_deinit();
    }

    if (p_json_root) {
        cJSON_Delete(p_json_root);
    }

    return status;
}

hash_calc_status_t readJson(char *file_name, char **ret)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    int                file_size = 0;
    int                fd = 0;
    int                len = 0;

    *ret = NULL;
    fd = open(file_name, O_RDONLY);
    if (fd < 0) {
        SX_LOG_ERR("Open %s error, errno=%d (%s).\n", file_name, errno, strerror(errno));
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    if ((file_size = lseek(fd, (size_t)0, SEEK_END)) < 0) {
        SX_LOG_ERR("Fail to seek to file end, errno=%d (%s)\n", errno, strerror(errno));
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    if (file_size > MAX_INPUT_JSON_FILE_LEN) {
        SX_LOG_ERR(
            "Input file (%s) size (%d) is bigger than %d, and rejected. Please double check content is valid for hash calculate.\n",
            file_name,
            file_size,
            MAX_INPUT_JSON_FILE_LEN);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }
    if (lseek(fd, (size_t)0, SEEK_SET) < 0) {
        SX_LOG_ERR("Fail to seek to beginning, errno=%d (%s)\n", errno, strerror(errno));
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    *ret = (char *)calloc(file_size + 1, 1);
    len = read(fd, *ret, file_size);
    if (len < file_size) {
        SX_LOG_ERR("Fail to read file_name (%s), file_size:%d, read:%d\n", file_name, file_size, len);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

out:
    if (fd >= 0) {
        close(fd);
    }
    if ((HASH_CALC_CHECK_FAIL(status)) && *ret) {
        free(*ret);
        *ret = NULL;
    }

    return status;
}

hash_calc_status_t generate_output_json(boolean_t is_ecmp,
                                        uint32_t  hash_val,
                                        int       hash_idx,
                                        int       lag_mc_idx,
                                        boolean_t ignore_hash_idx,
                                        char     *file_name)
{
    hash_calc_status_t status = HASH_CALC_STATUS_SUCCESS;
    cJSON             *hash_out = NULL;
    cJSON             *hash_root = NULL;
    cJSON             *hash_value = NULL;
    cJSON             *hash_index = NULL;
    cJSON             *lag_mc_index = NULL;
    int                fd = 0;
    int                len = 0;
    int                wr_len = 0;
    char              *hash_name = KEY_STR_RET_ECMP_HASH;
    char              *hash_idx_name = KEY_STR_RET_ECMP_INDEX;
    char              *out_str = NULL;

    if (!is_ecmp) {
        hash_name = KEY_STR_RET_LAG_HASH;
        hash_idx_name = KEY_STR_RET_LAG_INDEX;
    }

    hash_root = cJSON_CreateObject();
    if (!hash_root) {
        status = HASH_CALC_STATUS_ERROR;
        SX_LOG_ERR("Fails to create returned json object.\n");
        goto out;
    }

    hash_out = cJSON_CreateObject();
    if (!hash_out) {
        status = HASH_CALC_STATUS_ERROR;
        SX_LOG_ERR("Fails to create returned json object element.\n");
        goto out;
    }

    hash_value = cJSON_CreateNumber(hash_val);
    cJSON_AddItemToObject(hash_out, KEY_STR_RET_HASH_VALUE, hash_value);

    if (!ignore_hash_idx) {
        hash_index = cJSON_CreateNumber(hash_idx);
        cJSON_AddItemToObject(hash_out, hash_idx_name, hash_index);
        if (!is_ecmp) {
            lag_mc_index = cJSON_CreateNumber(lag_mc_idx);
            cJSON_AddItemToObject(hash_out, KEY_STR_RET_LAG_MC_INDEX, lag_mc_index);
        }
    }

    cJSON_AddItemToObject(hash_root, hash_name, hash_out);

    out_str = cJSON_Print(hash_root);
    if (!out_str) {
        status = HASH_CALC_STATUS_ERROR;
        SX_LOG_ERR("Fails to generate returned json content.\n");
        goto out;
    }

    fd = open(file_name, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (fd < 0) {
        SX_LOG_ERR("Open %s error, errno=%d (%s).\n", file_name, errno, strerror(errno));
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    len = strlen(out_str);
    wr_len = write(fd, out_str, len);
    if (wr_len != len) {
        status = HASH_CALC_STATUS_ERROR;
        SX_LOG_ERR("Fails to write json content (%d) to disk (written :%d).\n", len, wr_len);
        goto out;
    }

out:
    if (fd >= 0) {
        if (0 != fsync(fd)) {
            SX_LOG_ERR("Fails to fsync json content to disk, errno:%d.\n", errno);
        }
        close(fd);
    }
    if (hash_root) {
        cJSON_Delete(hash_root);
    }
    if (out_str) {
        cJSON_free(out_str);
    }
    return status;
}

static void __display_usage(FILE *stream, char *cmd)
{
    fprintf(stream, "Usage:\n\t %s -c <input_config_json_name> [ -o <output_result_json_name> ] [ -d ]\n", cmd);
}

int main(int argc, char **argv)
{
    hash_calc_status_t       status = HASH_CALC_STATUS_SUCCESS;
    int                      err = 0;
    int                      opt = 0;
    char                    *input_json_str = NULL;
    char                    *config_json_file_name = NULL;
    char                    *output_json_file_name = NULL;
    char                    *default_output_json_file_name = NULL;
    boolean_t                is_ecmp = FALSE;
    boolean_t                ignore_hash_idx = FALSE;
    uint32_t                 hash_size = 0;
    hash_calc_hash_config_t  hash_config;
    hash_calc_packet_t       packet;
    hash_calc_packet_meta_t  packet_meta;
    hash_calc_extra_info_t   extra_info;
    hash_calc_rehash_param_t rehash_param;
    hash_calc_hash_result_t  hash_result;
    const char* const        short_options = "c:o:dh";
    input_json_file_type_e   config_type = CONFIG_ECMP_HASH_E;
    boolean_t                sx_log_inited = FALSE;
    boolean_t                enable_debug = FALSE;

    SX_MEM_CLR(hash_config);
    SX_MEM_CLR(packet);
    SX_MEM_CLR(packet_meta);
    SX_MEM_CLR(extra_info);
    SX_MEM_CLR(rehash_param);
    SX_MEM_CLR(hash_result);

    do {
        opt = getopt(argc, argv, short_options);
        switch (opt) {
        case 'c':
            config_json_file_name = optarg;
            break;

        case 'o':
            output_json_file_name = optarg;
            break;

        case 'd':
            enable_debug = TRUE;
            break;

        case -1:
            break;

        case 'h':
        case '?':
        default:
            __display_usage(stdout, argv[0]);
            goto out;
        }
    } while (opt != -1);

    /* start log */
    sx_log_init(TRUE, NULL, NULL);
    sx_log_inited = TRUE;

    if (enable_debug == TRUE) {
        hash_calc_set_log_level(HASH_CALC_LOG_LEVEL_DEBUG);
        LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_DEBUG;
    }

    if (!config_json_file_name) {
        SX_LOG_ERR("ERROR: No input json file (%s).\n", argv[1]);
        __display_usage(stderr, argv[0]);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    status = readJson(config_json_file_name, &input_json_str);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("ERROR: Fail to read json file (%s), status:%d\n", config_json_file_name, status);
        goto out;
    }

    status = parse_input_json(input_json_str,
                              &hash_config,
                              &config_type,
                              &packet,
                              &packet_meta,
                              &extra_info,
                              &rehash_param);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("ERROR: Fails to parse json file (%s), result: %d\n", config_json_file_name, status);
        goto out;
    }

    switch (config_type) {
    case CONFIG_ECMP_HASH_E:
        err = hash_calc_ecmp_hash(&hash_config, &packet, &packet_meta, &extra_info, &hash_result);
        default_output_json_file_name = DEFAULT_ECMP_HASH_RESULT_FILE;
        hash_size = extra_info.size;
        break;

    case CONFIG_LAG_HASH_E:
        err = hash_calc_lag_hash(&hash_config, &packet, &packet_meta, &extra_info, &hash_result);
        default_output_json_file_name = DEFAULT_LAG_HASH_RESULT_FILE;
        hash_size = extra_info.size;
        break;

    case CONFIG_ECMP_REHASH_E:
        err = hash_calc_rehash(&rehash_param, &extra_info, &hash_result);
        default_output_json_file_name = DEFAULT_ECMP_REHASH_RESULT_FILE;
        hash_size = extra_info.size;
        break;

    default:
        status = HASH_CALC_STATUS_ERROR;
        goto out;
        break;
    }

    if (err) {
        SX_LOG_ERR("Fails to calculate hash value, status:%d\n", err);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    if (!output_json_file_name) {
        output_json_file_name = default_output_json_file_name;
        SX_LOG_NTC("No output file name is specified, default file name %s would be used.\n",
                   output_json_file_name);
    }

    if (!strcmp(output_json_file_name, config_json_file_name)) {
        SX_LOG_ERR(
            "Cannot have input json file (%s) the same as output json file (%s)\n",
            output_json_file_name,
            config_json_file_name);
        status = HASH_CALC_STATUS_ERROR;
        goto out;
    }

    if (config_type != CONFIG_LAG_HASH_E) {
        is_ecmp = TRUE;
    }

    if (hash_size == 0) {
        ignore_hash_idx = TRUE;
        SX_LOG_NTC("Input hash size is missing or zero, hash index will not be calculated.\n");
    }
    status =
        generate_output_json(is_ecmp,
                             hash_result.value,
                             hash_result.index,
                             hash_result.lag_mc_index,
                             ignore_hash_idx,
                             output_json_file_name);
    if (HASH_CALC_CHECK_FAIL(status)) {
        SX_LOG_ERR("ERROR: Fails to generate json file (%s), status:%d\n", output_json_file_name, status);
        goto out;
    }

out:
    if (input_json_str) {
        free(input_json_str);
    }

    if (sx_log_inited) {
        sx_log_close();
    }
    return status;
}
