#!/usr/bin/env python

import sys
import site


for lib_path in site.getsitepackages()[::-1]:
    if lib_path in sys.path:            # Means python interpreter will be able to import it
        break
else:
    raise AssertionError("Failed to find python site packages directory that also available in sys.path")

if len(sys.argv) > 1 and sys.argv[1] == "no_usr":           # TODO: AutoMake Deprecation - Remove this block and usage
    lib_path = lib_path.replace("/usr/", "/")

sys.stdout.write(lib_path)
