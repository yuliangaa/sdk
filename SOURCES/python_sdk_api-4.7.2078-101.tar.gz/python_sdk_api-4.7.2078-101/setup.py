"""
Script for compiling and installing python_sdk_api package
on a custom python interpreter.

# TODO: Align example scripts to python3 and add them to the setup script

Usage:
$ python setup.py config
$ python setup.py build
$ python setup.py install
"""
import sys
import os
import tempfile
from distutils import file_util, dir_util
from distutils.core import setup, Extension
from distutils.command.build_ext import build_ext
from distutils.command.build import build
from distutils.command.config import config
from distutils.command.install import install
from distutils.dep_util import newer_group
from distutils.sysconfig import get_config_vars
import gen_sdk_types_i
import logging
import time
import re

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('[%(asctime)s,%(msecs)03d][%(levelname)s][%(filename)s:%(lineno)03d] %(message)s', '%m-%d %H:%M:%S')
sh = logging.StreamHandler(sys.stdout)
sh.setFormatter(formatter)
logger.addHandler(sh)
[hdlr.setLevel(logging.INFO) for hdlr in logger.handlers]

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_APP_LIB_PATH = '/usr'
PACKAGE_NAME = 'python_sdk_api'
SX_API_SRC = os.path.join(SRC_DIR, 'py_sx_api')
SXD_API_SRC = os.path.join(SRC_DIR, 'py_sxd_api')
DEFAULT_VERSION = '3.0.0000'  # Same as the SDK private version
EXTRA_OPT_FLAGS = ["-O0"]


class python_sdk_api_config(config, object):
    """
    This class overrides the 'config' command of setup.py
    Usage: "python setup.py config"
    By default this command is empty.
    In this package we need the config command to auto-generate
    SWIG '.i' files for sdk/sxd types using gen_sdk_types_i.py script.

    The by-product of this command does not depended on the python interpreter.
    So it's enough to execute this command once,
    and then it's possible to build the package on different python versions.
    """

    # This option is mainly for using inside the Makefile.
    # When building the package as part of SDK compilation
    # we want to use libraries and headers from the build directory
    # instead of the ones that installed on the machine
    user_options = config.user_options + \
        [
            ('app-lib-path=',   # Name
             None,              # Shortcut
             'path to user directory (default %s)' % DEFAULT_APP_LIB_PATH)  # Help
        ]

    def run(self):
        """Run the 'config' command"""
        super(python_sdk_api_config, self).run()
        gen_sdk_types_i.main(
            self.app_lib_path,
            os.path.join(self.app_lib_path, 'include/sx/sdk/'),
            os.path.join(SX_API_SRC, 'sx_api_types.i'),
            'sx_api')

    def initialize_options(self):
        super(python_sdk_api_config, self).initialize_options()
        self.app_lib_path = DEFAULT_APP_LIB_PATH


class python_sdk_api_build_ext(build_ext, object):
    """
    This class overrides the 'build_ext' command of setup.py
    This is a sub-command of the "build" command.
    For most use-cases it's better to use: "python setup.py build"
    If for some reason you want to execute specifically this command alone
    you may run: "python setup.py build_ext"
    """

    # This option is mainly for using inside the Makefile.
    # When building the package as part of SDK compilation
    # we want to use libraries and headers from the build directory
    # instead of the ones that installed on the machine
    user_options = build_ext.user_options + \
        [
            ('app-lib-path=',   # Name
             None,              # Shortcut
             'path to user directory (default %s)' % DEFAULT_APP_LIB_PATH)  # Help
        ]

    @staticmethod
    def adjust_cflags():
        """ Adjust CFLAGS and CONFIGURE_CFLAGS:
        1. WA For incompatibility of old gcc (< 8.1) and Python3:
            When compiling for Python3 under SDK's Makefile,
            distutils uses -ffile-prefix-map flag which is unrecognized by gcc.
            This flag is not interesting to begin with - Remove it
        2. CFLAGS Are also depedent on how the python interpreter was compiled.
            We would like to use O0 CPU Optimization level, even if Python itself was compiled with
            CPU Optimizations. It has major impact on compilation time, and isoteric effect on tests performance.
        """

        config_vars = get_config_vars()
        for key, val in config_vars.items():
            if key != "OPT" and "CFLAGS" not in key:
                continue

            if not (val and isinstance(val, str)):
                continue

            opt_flags = re.findall(r"-O[1-9]", val)
            if "-ffile-prefix-map" not in val and not opt_flags:
                continue

            new_val = " ".join([s for s in val.split(" ") if not s.startswith('-ffile-prefix-map')]).strip()
            new_opt = "-O1" if "FORTIFY_SOURCE" in val else "-O0"
            for opt in opt_flags:
                new_val = new_val.replace(opt, new_opt).strip()

            config_vars[key] = new_val.replace(", ", "")

    def run(self):
        """Run the 'build_ext' command"""

        self.pre_build_extensions()
        tmp_path = tempfile.mkdtemp()
        try:
            # In order to prevent parallel builds potential issues,
            # we move the sources to a temporary location and compile from there.
            for ext in self.extensions:
                old_source_dir_path, old_source_name = \
                    os.path.split(ext.sources[0])

                new_source_dir_path = os.path.join(
                    tmp_path, os.path.basename(old_source_dir_path))

                dir_util.copy_tree(old_source_dir_path, new_source_dir_path)
                ext.sources = [os.path.join(new_source_dir_path,
                                            old_source_name)]
                ext.swig_opts.append('-I' + new_source_dir_path)

            super(python_sdk_api_build_ext, self).run()
            self.post_build_extensions()
        finally:
            dir_util.remove_tree(tmp_path)

    def pre_build_extensions(self):
        """
        Operations to perform before the actual build_ext command.

        For each extension in the package:
            Mark if it's going to be skipped (because it's up to date) or not.
        This info is used by the post_build_extension method.
        """

        self.adjust_cflags()

        for ext in self.extensions:
            depends = sorted(ext.sources) + ext.depends
            ext_path = self.get_ext_fullpath(ext.name)
            ext.skip = not (self.force
                            or newer_group(depends, ext_path, 'newer'))

    def copy_api_file_by_string(self, string_to_search):
        """
        This function will copy sx_api.py or sxd_api.py to destination
        :param string: "sx_api" / "sxd_api"
        :return: nothing
        """
        sx_api_ext_found = False
        for ext in self.extensions:
            if string_to_search in ext.sources[0]:
                sx_api_ext_found = True
                break

        if sx_api_ext_found:
            script_name = os.path.dirname(ext.sources[0]) + '/' + string_to_search + '.py'
            file_util.copy_file(script_name,
                                os.path.join(self.build_lib, PACKAGE_NAME))

    def post_build_extensions(self):
        """
        Operations to perform after the actual build_ext command.

        1. Create __init__.py file if not exists in the built package.
        2. For each extension in the package that wasn't skipped:
            Copy the SWIG python-wrapper to the built package.
            (sx_api.py / sxd_api.py)
        """
        init_file_path = \
            os.path.join(self.build_lib, PACKAGE_NAME, '__init__.py')
        if not os.path.exists(init_file_path):
            file_util.write_file(init_file_path, [])
        for ext in self.extensions:
            if not ext.skip:
                script_name = os.path.splitext(ext.sources[0])[0] + '.py'
                file_util.copy_file(script_name,
                                    os.path.join(self.build_lib, PACKAGE_NAME))

        # after swig separation , swig generates sx_api_[module name].py python modules
        # to be backward compatible we will build sx_api.py module to include all new python modules
        # now we need to copy sx_api.py to destination
        # to do that we need to find the temporary folder name : os.path.dirname(ext.sources[0])
        # and then we can build the current path of sx_api.py
        self.copy_api_file_by_string("sx_api")

        # after swig separation , swig generates new sxd_api python modules
        # to be backward compatible we will build sxd_api.py module to include all new sxd python modules
        # now we need to copy sxd_api.py to destination
        # to do that we need to find the temporary folder name : os.path.dirname(ext.sources[0]) (sxd interface files placed at thew end)
        # and then we can build the current path of sxd_api.py
        self.copy_api_file_by_string("sxd_api")

    def finalize_options(self):
        super(python_sdk_api_build_ext, self).finalize_options()

        # Get the app_lib_path value from the 'build' command if not given
        self.set_undefined_options('build', ('app_lib_path', 'app_lib_path'))

        for ext in self.extensions:
            # Include self.app_lib_path in both swig and gcc commands.
            ext.swig_opts.append('-I' + self.app_lib_path)
            ext.include_dirs.append(self.app_lib_path)
            ext.include_dirs.append(os.path.join(self.app_lib_path, 'include'))

            # Use the shared-object libraries from self.app_lib_path/lib(64)/
            for i, obj in enumerate(ext.extra_objects):
                for lib in ['lib', 'lib64']:
                    path = os.path.join(self.app_lib_path, lib, obj)
                    if os.path.exists(path):
                        ext.extra_objects[i] = path
                        break
                else:
                    raise Exception("Can't find {}, please verify applib-path is set correctly".format(obj))

    def initialize_options(self):
        super(python_sdk_api_build_ext, self).initialize_options()
        self.app_lib_path = None


class python_sdk_api_build(build, object):
    """
    This class overrides the 'build' command of setup.py
    Usage: "python setup.py build"

    We override the default 'build' command
    only to expose the 'app-lib-path' option
    """

    # This option is mainly for using inside the Makefile.
    # When building the package as part of SDK compilation
    # we want to use libraries and headers from the build directory
    # instead of the ones that installed on the machine
    user_options = build.user_options + \
        [
            ('app-lib-path=',   # Name
             None,              # Shortcut
             'path to user directory (default %s)' % DEFAULT_APP_LIB_PATH)  # Help
        ]

    def initialize_options(self):
        super(python_sdk_api_build, self).initialize_options()
        self.app_lib_path = DEFAULT_APP_LIB_PATH


class python_sdk_api_install(install, object):
    """
    This class overrides the 'install' command of setup.py
    Usage: "python setup.py install"

    We override the default 'install' command
    to support 'app-lib-path' option
    """
    user_options = install.user_options + \
        [
            ('version=',   # Name
             None,              # Shortcut
             'The version of the installed package. Default: {}'.format(DEFAULT_VERSION))  # Help
        ]

    def initialize_options(self):
        super(python_sdk_api_install, self).initialize_options()
        self.version = DEFAULT_VERSION

    def finalize_options(self):
        super(python_sdk_api_install, self).finalize_options()
        sdk_formal_pattern = re.compile(r"^\d\.\d\.\d{4}$")  # e.g. 4.6.4900
        sdk_release_pattern = re.compile(r"^\d\.\d\.\d{4}-\d{3}$")  # e.g. 4.6.4900-001
        if self.version and not (sdk_formal_pattern.match(self.version) or sdk_release_pattern.match(self.version)):
            print("-W- Version '{}' might be invalid for some newer dpkg versions | Reset to default '{}'".format(
                self.version, DEFAULT_VERSION)
            )
            self.version = DEFAULT_VERSION
        self.distribution.metadata.version = self.version


def generate_ext_modules_list():
    """
    This function will do the following :
    1. prepare extensions for all SDK sx_api and sxd_api modules
    2. put all extensions to ext_modules_list
    3. build sx_api.py python module so it will include all new python modules per SDK api module
    4. build sxd_api.py python module to include all new sxd_api python modules
    """

    # build ext modules list for all sx_api_... modules
    files = os.listdir(SX_API_SRC)
    prefix_to_rem = "sx_api_"
    lib_prefix_to_rem = "sx_lib_"
    ext_modules_list = []
    sx_api_file_context = []
    filtered_files = [f for f in files if f.startswith('sx_') and f.endswith('.i')]
    # filtered_files = []
    for item in filtered_files:
        # skip non relevant files
        if ".py" in item or "swig_" in item or "sx_api_types" in item:
            continue

        # build extension for sx_api
        if "sx_api_includes" in item:
            module_name = (os.path.splitext(item)[0])[len(prefix_to_rem):]
            module_ext = Extension('_sx_api_' + module_name,
                                   sources=[os.path.join(SX_API_SRC, 'sx_api_' + module_name + '.i')],
                                   swig_opts=['-threads'],
                                   extra_objects=['libsxapi.so', 'libsw_rm.so'],
                                   extra_compile_args=EXTRA_OPT_FLAGS)
            ext_modules_list.append(module_ext)
            sx_api_import_str = "from python_sdk_api.sx_api_" + module_name + " import *"
            sx_api_file_context.insert(0, sx_api_import_str)
            continue

        # build extension for sx_api
        if "sx_api_" in item:
            module_name = (os.path.splitext(item)[0])[len(prefix_to_rem):]
            module_ext = Extension('_sx_api_' + module_name,
                                   sources=[os.path.join(SX_API_SRC, 'sx_api_' + module_name + '.i')],
                                   swig_opts=['-threads'],
                                   extra_objects=['libsxapi.so', 'libsw_rm.so'],
                                   extra_compile_args=EXTRA_OPT_FLAGS)
            ext_modules_list.append(module_ext)
            sx_api_import_str = "from python_sdk_api.sx_api_" + module_name + " import *"
            sx_api_file_context.extend([sx_api_import_str])
            continue

        # build extension for sx_lib
        if "sx_lib_" in item:
            module_name = (os.path.splitext(item)[0])[len(lib_prefix_to_rem):]
            module_ext = Extension('_sx_lib_' + module_name,
                                   sources=[os.path.join(SX_API_SRC, 'sx_lib_' + module_name + '.i')],
                                   swig_opts=['-threads'],
                                   extra_objects=['libsxapi.so', 'libsw_rm.so'],
                                   extra_compile_args=EXTRA_OPT_FLAGS)
            ext_modules_list.append(module_ext)
            sx_api_import_str = "from python_sdk_api.sx_lib_" + module_name + " import *"
            sx_api_file_context.extend([sx_api_import_str])
            continue

        # build extension for sx_api ... special_types.i
        if "sx_" in item:
            module_name = os.path.splitext(item)[0]
            module_ext = Extension('_' + module_name,
                                   sources=[os.path.join(SX_API_SRC, item)],
                                   swig_opts=['-threads'],
                                   extra_objects=['libsxapi.so', 'libsw_rm.so'],
                                   extra_compile_args=EXTRA_OPT_FLAGS)
            ext_modules_list.append(module_ext)
            sx_api_import_str = "from python_sdk_api." + module_name + " import *"
            sx_api_file_context.extend([sx_api_import_str])
            continue

    # build sx_api.py content
    sx_api_file = SX_API_SRC + "/sx_api.py"
    with open(sx_api_file, "w") as f:
        f.write("\n".join(sx_api_file_context))

    # build sxd api extensions
    sxd_ext_modules_list = [
        "sxd_api_include",
        "sxd_access_register",
        "kernel_user",
        "kernel_user_auto",
    ]

    for sxd_module in sxd_ext_modules_list:
        sxd_module_ext = Extension('_' + sxd_module,
                                   sources=[os.path.join(SXD_API_SRC, sxd_module + '.i')],
                                   extra_objects=['libsxdreg_access.so',
                                                  'libcraccess.so', 'libsxcom.so'],
                                   extra_compile_args=EXTRA_OPT_FLAGS)
        ext_modules_list.append(sxd_module_ext)

    return ext_modules_list


start_time = time.time()
logger.info("Python{} SDK API Build Started | Args: '{}'".format(sys.version_info.major, " ".join(sys.argv[:])))

setup(name=PACKAGE_NAME,
      cmdclass={'build': python_sdk_api_build,
                'build_ext': python_sdk_api_build_ext,
                'config': python_sdk_api_config,
                'install': python_sdk_api_install},
      ext_package=PACKAGE_NAME,
      ext_modules=generate_ext_modules_list()  # ext_modules_list
      # ext_modules=ext_modules_list
      )

logger.info("Python{} SDK API Build Finished | Runtime: {}s".format(sys.version_info.major, time.time() - start_time))
