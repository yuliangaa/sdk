#
# Copyright © 2015-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of Nvidia Corporation and its affiliates
# (the "Company") and all right, title, and interest in and to the software
# product, including all associated intellectual property rights, are and
# shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

rm -rf aclocal.m4 autom4te.cache stamp-h1 libtool configure config.h.in Makefile.in Makefile
rm -rf config

for a in sx_api sxd_api; do
	rm -rf py_${a}/${a}_wrap.c
	rm -rf py_${a}/Makefile 2>&1
	rm -rf py_${a}/Makefile.in 2>&1
	rm -rf py_${a}/.deps 2>&1
	rm -rf py_${a}/${a}_types.i 2>&1
done
