#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the slot information.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *


def generate_slot_info_dump(handle):
    slot_count = get_slot_count(handle)
    if slot_count == 0:
        print("Slot information dump is applicable only for modular systems.")
        return

    slot_info_list = get_slot_info(handle)
    print("========================================================================================================================================")
    header = ["Slot", "Card Type", "Card Name", "Hw version", "Minor version", "Provisioned", "Valid", "Ready", "Active", "Device count"]
    print("|%4s|%36s|%20s|%10s|%13s|%11s|%6s|%6s|%7s|%12s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6],
                                                               header[7], header[8], header[9]))
    print("========================================================================================================================================")

    card_type_enum_dict = get_enum_string_dict('SX_MGMT_SLOT_CARD_TYPE_MSN')

    for idx in range(len(slot_info_list)):
        slot_info = slot_info_list[idx]
        if slot_info.slot_description.slot_state_info.is_slot_card_provisioned:
            card_type = card_type_enum_dict[slot_info.slot_description.slot_card_type]
            card_name = slot_info.slot_description.slot_card_name
        else:
            card_type = "None"
            card_name = "None"
        print("|%4s|%36s|%20s|%10s|%13s|%11s|%6s|%6s|%7s|%12s|" % (slot_info.slot_id,
                                                                   card_type,
                                                                   card_name,
                                                                   slot_info.slot_description.slot_card_ini_info.slot_card_hw_revision,
                                                                   slot_info.slot_description.slot_card_ini_info.slot_card_minor_ini_version,
                                                                   get_boolean_string(slot_info.slot_description.slot_state_info.is_slot_card_provisioned),
                                                                   get_boolean_string(slot_info.slot_description.slot_state_info.is_slot_card_valid),
                                                                   get_boolean_string(slot_info.slot_description.slot_state_info.is_slot_card_ready),
                                                                   get_boolean_string(slot_info.slot_description.slot_state_info.is_slot_card_active),
                                                                   slot_info.dev_description.slot_device_count))
    print("========================================================================================================================================")


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    # Run the example.
    generate_slot_info_dump(handle)

    sx_api_close(handle)
