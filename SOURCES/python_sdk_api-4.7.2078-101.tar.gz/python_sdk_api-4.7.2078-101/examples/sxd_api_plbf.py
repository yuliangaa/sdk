#!/usr/bin/env python

lbf_mode_dict = {0: 'NO_CHANGE', 1: 'DISABLED', 2: 'ENABLED'}


import sys
import time
import os
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='sxd_api_plbf example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] PLBF (Port Looback Filter Register) register access test start")
print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

original_plbf = ku_plbf_reg()
original_plbf.port, original_plbf.lp_msb = common_lib.get_lsb_msb_of_local_port(1)

rc = sxd_access_reg_plbf(original_plbf, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PLBF register, rc: %d" % (rc)

plbf = ku_plbf_reg()
plbf.lbf_mode = 0
"""
Set the locat port here. Please make sure this is not the panel port.
In order to get the right mapping please use the sx_api_ports_dump utility.
"""
plbf.port, plbf.lp_msb = common_lib.get_lsb_msb_of_local_port(1)


print()
print("[+] Get PLBF")
rc = sxd_access_reg_plbf(plbf, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PLBF register, rc: %d" % (rc)

print("[+] Get PLBF content")
print("====================")
print("[+] local port: ", plbf.port)
print("[+] lp_msb: ", plbf.lp_msb)
print("[+] Loopback filter state: ", lbf_mode_dict[plbf.lbf_mode])

meta.access_cmd = SXD_ACCESS_CMD_SET

"""
See the lbf_mode_dict dictionary above for all the available options
"""

plbf.lbf_mode = plbf.lbf_mode % 2 + 1

print()
print("[+] Set PLBF content")
print("====================")
print("[+] local port: ", plbf.port)
print("[+] lp_msb: ", plbf.lp_msb)
print("[+] Loopback filter state: ", lbf_mode_dict[plbf.lbf_mode])

print("[+] Set PLBF")
rc = sxd_access_reg_plbf(plbf, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set PLBF register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
plbf.lbf_mode = 0

print()
print("[+] Get PLBF after the set operation was done")
rc = sxd_access_reg_plbf(plbf, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PLBF register, rc: %d" % (rc)

print("[+] Get PLBF content")
print("====================")
print("[+] local port: ", plbf.port)
print("[+] lp_msb: ", plbf.lp_msb)
print("[+] Loopback filter state: ", lbf_mode_dict[plbf.lbf_mode])

if args.deinit:
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_plbf(original_plbf, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PLBF register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] PLBF register access test end")
