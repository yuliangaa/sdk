#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL NVE Bind.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

"""

import sys
import socket
import struct
import errno
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_nve_bind example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

# string constants
TUNN_ID = "TUNN"
DST_IP_STR = "IP"
WEIGHT_STR = "weight"
######################################################
#    functions
######################################################


def get_chip_type():
    """
    :return: SX_CHIP_TYPE_SPECTRUM \ SX_CHIP_TYPE_SPECTRUM2 \ SX_CHIP_TYPE_SPECTRUM3
    """
    print("Retrieving Chip Type from SDK")
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 1)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)

    device_info = sx_device_info_t_arr_getitem(device_info_list_p, 0)
    chip_type = device_info.dev_type
    if chip_type == SX_CHIP_TYPE_SPECTRUM_A1:
        chip_type = SX_CHIP_TYPE_SPECTRUM

    print(chip_type)
    return chip_type


""" ############################################################################################ """


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


""" ############################################################################################ """


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


""" ############################################################################################ """


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


""" ############################################################################################ """


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


""" ############################################################################################ """


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


""" ############################################################################################ """


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return tunnel_id


""" ############################################################################################ """


def mc_container_create(container_attributes_p, tunnel_id):
    count = 1

    next_hop_list = new_sx_mc_next_hop_t_arr(count)
    next_hop = sx_mc_next_hop_t()
    next_hop.type = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4("15.15.15.15")
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 0, next_hop)

    mc_container_id_p = new_sx_mc_container_id_t_p()
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, mc_container_id_p, next_hop_list, count, container_attributes_p)
    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create mc_container, rc: %d" % (rc)

    mc_container_id = sx_mc_container_id_t_p_value(mc_container_id_p)
    return mc_container_id


""" ############################################################################################ """


def mc_container_destroy(mc_container_id):

    mc_container_id_p = new_sx_mc_container_id_t_p()
    sx_mc_container_id_t_p_assign(mc_container_id_p, mc_container_id)
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, mc_container_id_p, None, 0, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mc_container, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_destroy(tunnel_id_p):
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_create(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_destroy(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel decap rule, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_edit(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_EDIT, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to edit tunnel decap rule, rc: %d" % (rc)


""" ############################################################################################ """


def create_loopback_rif(vrid, vlan, mtu=1500):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif


######################################################
#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


""" ############################################################################################ """


def make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, underlay_rif=0, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p.underlay_rif = underlay_rif  # =underlay_rif -- not supported

    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_mode = 0
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_key = 0

    tunnel_attribute.attributes.ipinip_p2p.decap.gre_check_key = 0
    tunnel_attribute.attributes.ipinip_p2p.decap.gre_expected_key = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.nve_log_port = NVE_PORT

    return tunnel_attribute


""" ############################################################################################ """


def make_mc_container_attributes():

    mc_container_attribute = sx_mc_container_attributes_t()

    mc_container_attribute.min_mtu = 128

    return mc_container_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan_gre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN_GPE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_geneve(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_GENEVE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.vxlan_gre.encap.underlay_vrid = vrid
    tunnel_attribute.vxlan_gre.encap.underlay_ttl = 255
    tunnel_attribute.vxlan_gre.encap.underlay_sip = underlay_sip
    tunnel_attribute.vxlan_gre.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_nvgre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_NVGRE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.vxlan_gre.encap.underlay_vrid = vrid
    tunnel_attribute.vxlan_gre.encap.underlay_ttl = 255
    tunnel_attribute.vxlan_gre.encap.underlay_sip = underlay_sip
    tunnel_attribute.vxlan_gre.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_decap_key(key_type, vrid, tunnel_type=0):  # SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip
    decap_key.underlay_sip = make_sx_ip_addr_v4("192.168.1.3")  # need to change to valid ip

    return decap_key


""" ############################################################################################ """


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    tunnel_init(general_param_p)


""" ############################################################################################ """


def example_vxlan_tunnel_create_flow(vrid):

    underlay_sip = make_sx_ip_addr_v4("1.1.1.1")  # need to change to valid ip and to correctly add to the struct

    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, SX_TUNNEL_DIRECTION_SYMMETRIC)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(tunnel_attribute_p)

    return tunnel_id


""" ############################################################################################ """


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    tunnel_destroy(tunnel_id_p)


""" ############################################################################################ """


def example_ipinip_tunnel_create_flow(vrid, overlay_rif, direction=SX_TUNNEL_DIRECTION_DECAP):

    underlay_sip = make_sx_ip_addr_v4("1.1.1.20")  # need to change to valid ip and to correctly add to the struct

    tunnel_attribute = make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, 0, direction)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(tunnel_attribute_p)

    return tunnel_id


""" ############################################################################################ """


def example_decap_rules_flow(vrid, tunnel_id, counter_id, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, tunnel_type)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, counter_id)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    tunnel_decap_rule_create(decap_key_p, decap_data_p)
    #tunnel_decap_rule_destroy(decap_key_p, decap_data_p)


""" ############################################################################################ """


def example_decap_rules_destroy_flow(vrid, tunnel_id, counter_id, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, tunnel_type)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, counter_id)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    tunnel_decap_rule_destroy(decap_key_p, decap_data_p)


""" ############################################################################################ """


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        next_hop = make_ecmp_next_hop(nh[TUNN_ID], nh[DST_IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


""" ############################################################################################ """


def make_ecmp_next_hop(tunn_id, dst_ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
    This function creates ecmp_next_hop struct with given parametrs.
        action, counter_id and trap priority are optional.
    """

    address = make_sx_ip_addr_v4(dst_ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    nh_key.next_hop_key_entry.ip_tunnel.underlay_dip = address
    nh_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunn_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


""" ############################################################################################ """


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


""" ############################################################################################ """


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


""" ############################################################################################ """


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates ecmp uc_route_data struct with given parametrs.
        action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = 0
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


""" ############################################################################################ """


def delete_next_hops_uc_route(vrid, addr, mask, ipv):
    " This function deletes all next hops from given vrid. "

    if ipv == 4:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted IPv" + str(ipv) + " uc next hops of VRID %d, rc: %d" % (vrid, rc))


""" ############################################################################################ """


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


""" ############################################################################################ """


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "

    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)

    if isinstance(mask, str):
        mask = _ipv6_str_to_bytes(mask)

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    prefix = sx_ip_v6_prefix_t()
    ip_prefix.prefix = prefix
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


""" ############################################################################################ """


def _ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))
    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]
    # Finally, convert back to bytes
    out = struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])
    return [ord(i) for i in out]


""" ############################################################################################ """


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


""" ############################################################################################ """


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create():
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(3)
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_INNER_IP_PROTO)
    sx_acl_key_t_arr_setitem(key_arr, 1, FLEX_ACL_KEY_L4_SOURCE_PORT)
    sx_acl_key_t_arr_setitem(key_arr, 2, FLEX_ACL_KEY_INNER_SMAC)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 3,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def group_create(acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

    group_id = sx_acl_id_t_p_value(group_id_p)
    print("Created group %d, rc: %d" % (group_id, rc))
    for i in range(0, acls_num):
        print("acl id = %d " % sx_acl_id_t_arr_getitem(acl_id_arr, i))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def group_destroy(group_id):
    " This function destroy  flex acl key "
    group_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(group_id_p, group_id)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, group_id)

    direction = 0
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy group"

    print("Destroyed group %d, rc: %d" % (group_id, rc))
    delete_sx_acl_id_t_p(group_id_p)


def set_rules(region_id, counter_id):
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(25)

    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 10, rule)

    key_desc1 = sx_flex_acl_key_desc_t()
    key_desc1.key_id = FLEX_ACL_KEY_INNER_IP_PROTO
    key_desc1.key.inner_ip_proto = 1  # ICMP
    key_desc1.mask.inner_ip_proto = 1
    #key_desc2 = sx_flex_acl_key_desc_t()
    #key_desc2.key_id = FLEX_ACL_KEY_L4_SOURCE_PORT
    #key_desc2.key.l4_source_port = 0;
    #key_desc2.mask.l4_source_port = 0;

    #rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc1)
    #sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc2)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_COUNTER
    action1.fields.action_counter.counter_id = counter_id
    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
    action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
    action2.fields.action_set_vlan.vlan_id = 6
    action3 = sx_flex_acl_flex_action_t()
    action3.type = SX_FLEX_ACL_ACTION_FORWARD
    action3.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

    #rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
    rule.action_count = 3

    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"


def group_bind_get(group_id_prev):
    "the exapmple gets the group bind in context prev->next and return next group id"
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_bind_get(handle,
                                   group_id_prev,
                                   group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind between groups"

    group_id_next = sx_acl_id_t_p_value(group_id_p)
    print("group %d bound to group %d  rc: %d" % (group_id_prev, group_id_next, rc))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id_next


def add_pvid_to_port(vlan_id, port):
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, port, vlan_id)
    print(("Set pvid %d for port 0x%x rc %d " % (vlan_id, port, rc)))


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def destroy_flow_counter(counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function destroys a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed flow counter %d, rc: %d" % (counter_id, rc))


def example_nve_decap_rules_flow(vrid, tunnel_id, dip, sip):

    c = create_flow_counter()
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, c)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, dip, sip, SX_TUNNEL_TYPE_NVE_VXLAN)
    #decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, dip, sip, SX_TUNNEL_TYPE_NVE_VXLAN)
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    print("create VXLAN decap rule, ul vrid: %d, flow counter: %d" % (vrid, c))
    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vxlan decap rule , rc: %d" % (rc)


def example_fdb_uc_set(bridge_id, log_port, mac, cmd):
    # add static fdb
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
#    mac_addr = ether_addr(mac)

    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac

    mac_entry.fid_vid = bridge_id
    mac_entry.log_port = log_port
    mac_entry.entry_type = SX_FDB_UC_STATIC
    mac_entry.action = SX_FDB_ACTION_FORWARD
    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT

    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry)

    rc = sx_api_fdb_uc_mac_addr_set(handle, cmd, 0, mac_list_p, data_cnt_p)

    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(ports_dict.keys()), vlan_id)
    print(("Added %s port to vlan %d, rc: %d" % (str(ports_dict.keys()), vlan_id, rc)))


def bridge_vport_add(bridge_id, vlan, port, log_vport):
    # add log_vport to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    print(("virtual port 0x%x added to bridge %d " % (log_vport, bridge_id)))

    # set port state to UP
    port_state_set(log_vport, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan, {port: SX_UNTAGGED_MEMBER})

# tunnel map


def tunnel_map_entry_add(tunnel_id, vni, bridge_id):
    map_entry = make_tunnel_map_entry_params(vni, bridge_id)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)


def tunnel_map_entry_delete(tunnel_id, vni, bridge_id):
    map_entry = make_tunnel_map_entry_params(vni, bridge_id)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE, tunnel_id, map_entry_p, 1)


def make_tunnel_map_entry_params(vni, bridge_id):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = SX_TUNNEL_TYPE_NVE_VXLAN
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni

    return map_entry


def create_vport_rif(vrid, log_vport, mac_addr, mtu=1500):
    " This function creates vport rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VPORT
    ifc_param.ifc.vport.vport = log_vport

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print(("Created vport RIF: %d, rc: %d " % (rif, rc)))
    return rif


def set_rif_state_ipv4(rif,
                       ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                       ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print(("Set rif %d state, rc: %d " % (rif, rc)))


def main():

    router_init()

    # init tunnel
    example_tunnel_init_flow()

    vrid = create_vrid()
    ol_vrid = create_vrid()

    # Set for decap traffic
    # Create port rif on ingress port
    log_vport_p = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT1, 1, log_vport_p)
    log_vport1 = sx_port_log_id_t_p_value(log_vport_p)
    port_state_set(log_vport1, SX_PORT_ADMIN_STATUS_UP)
    port_rif = create_vport_rif(vrid, log_vport1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x06))
    set_rif_state_ipv4(port_rif)
    # Create bridge for egress port
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT2, 1, log_vport_p)
    log_vport2 = sx_port_log_id_t_p_value(log_vport_p)
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge_id %d created" % (bridge_id)))
    bridge_vport_add(bridge_id, 1, PORT2, log_vport2)

    example_fdb_uc_set(bridge_id, log_vport2, ether_addr(0x24, 0x8A, 0x07, 0x55, 0x11, 0x1D), SX_ACCESS_CMD_ADD)
    # v xlan tunnel create example
    vxlan_tunnel_id = example_vxlan_tunnel_create_flow(vrid)
    # Add tunnel map of bridge and vxlan tunnel
    tunnel_map_entry_add(vxlan_tunnel_id, 5, bridge_id)

    # ipinip tunnel create example
    loopback_rif = create_loopback_rif(ol_vrid, 1)
    tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif, SX_TUNNEL_DIRECTION_SYMMETRIC)

    # Add decap rules
    counter_id_1 = create_flow_counter()
    example_decap_rules_flow(vrid, vxlan_tunnel_id, counter_id_1, SX_TUNNEL_TYPE_NVE_VXLAN)
    example_decap_rules_flow(vrid, tunnel_id, 0)

    # acl module

    # Only Spectrum2 and above supports explicit tunnel port binding
    if get_chip_type() == SX_CHIP_TYPE_SPECTRUM:
        direction = SX_ACL_DIRECTION_INGRESS
    else:
        direction = SX_ACL_DIRECTION_TPORT_INGRESS

    key_handle = key_create()

    region_id = region_create(key_handle, 60)
    acl_id = acl_create(region_id, direction)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)

    counter_id_2 = create_flow_counter()
    set_rules(region_id, counter_id_2)
    sx_api_dbg_generate_dump(handle, "/tmp/flex_acl_dump_log")

    region_id_2 = region_create(key_handle, 60)
    acl_id_2 = acl_create(region_id_2, direction)
    sx_acl_id_t_arr_setitem(acl_id_arr, 1, acl_id_2)
    group_id_p = new_sx_acl_id_t_p()

    group_id = group_create(acl_id_arr, 2, direction)

    sx_acl_id_t_p_assign(group_id_p, group_id)

    # bind port to existing group
    port = NVE_PORT
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  port,
                                  group_id)
    print("port %d bound to group %d  rc: %d" % (port, group_id, rc))

    group_id_get_p = new_sx_acl_id_t_p()
    rc = sx_api_acl_port_bind_get(handle, port, direction, group_id_get_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get bound group"
    group_id_get = sx_acl_id_t_p_value(group_id_get_p)
    assert group_id_get == group_id, "Got wrong bound group id"

    # Can aslo add decap rules after nve binding
    #example_decap_rules_flow(vrid, vxlan_tunnel_id, counter_id_1, SX_TUNNEL_TYPE_NVE_VXLAN)
    #example_decap_rules_flow(vrid, tunnel_id, 0)
    # Now we can send the traffic with overlay is ICMP and check the counter
    counter_set_1_p = new_sx_flow_counter_set_t_p()
    counter_set_2_p = new_sx_flow_counter_set_t_p()

    sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id_1, counter_set_1_p)
    sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id_2, counter_set_2_p)

    if args.deinit:
        # Unbind
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      port,
                                      group_id)
        print("port %d unbound from group %d  rc: %d" % (port, group_id, rc))

        group_destroy(group_id)
        acl_destroy(acl_id, region_id)
        acl_destroy(acl_id_2, region_id_2)
        region_destroy(region_id)
        region_destroy(region_id_2)
        key_destroy(key_handle)

        # tunnel destroy
        example_decap_rules_destroy_flow(vrid, tunnel_id, 0)
        example_decap_rules_destroy_flow(vrid, vxlan_tunnel_id, counter_id_1, SX_TUNNEL_TYPE_NVE_VXLAN)
        tunnel_map_entry_delete(vxlan_tunnel_id, 5, bridge_id)
        example_tunnel_destroy_flow(tunnel_id)
        example_tunnel_destroy_flow(vxlan_tunnel_id)

        # deinit tunnel
        tunnel_deinit()

        delete_rif(ol_vrid, loopback_rif)
        delete_rif(vrid, port_rif)

        delete_vrid(vrid)
        delete_vrid(ol_vrid)

        # Delete vports and bridge
        port_state_set(log_vport1, SX_PORT_ADMIN_STATUS_DOWN)
        log_vport_p = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p, log_vport1)
        vport_add_delete(SX_ACCESS_CMD_DELETE, PORT1, 1, log_vport_p)
        sx_port_log_id_t_p_assign(log_vport_p, log_vport2)
        port_state_set(log_vport2, SX_PORT_ADMIN_STATUS_DOWN)
        example_fdb_uc_set(bridge_id, log_vport2, ether_addr(0x24, 0x8A, 0x07, 0x55, 0x11, 0x1D), SX_ACCESS_CMD_DELETE)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, log_vport2)
        vport_add_delete(SX_ACCESS_CMD_DELETE, PORT2, 1, log_vport_p)
        bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)

        destroy_flow_counter(counter_id_1)
        destroy_flow_counter(counter_id_2)

        router_deinit()

    sx_api_close(handle)

    print("finished")


if __name__ == "__main__":
    main()
