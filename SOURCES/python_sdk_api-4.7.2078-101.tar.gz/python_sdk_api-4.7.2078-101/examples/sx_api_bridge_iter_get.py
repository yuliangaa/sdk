#!/usr/bin/env python
'''
This file contains Python command example for the bridge iterator get function.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import time
import traceback
from python_sdk_api.sx_api import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_bridge_iter_get example')
    parser.add_argument('--bridge_count', type=int, default=3, help='Amount of bridges to create')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def main():
    args = parse_args()
    MAX_BRIDGE_COUNT = 256
    if not args.bridge_count or args.bridge_count > MAX_BRIDGE_COUNT:
        print("bridge_count should be an integer in range [1, %d]" % MAX_BRIDGE_COUNT)
        sys.exit(1)

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    MAX_KEY_NUM = args.bridge_count
    ret_code = 1
    try:
        key_list = []

        bridge_id_p = new_sx_bridge_id_t_p()
        # Create some bridge IDs
        for i in range(1, MAX_KEY_NUM + 1):

            rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_bridge_set failed, rc=%d" % rc)
            bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
            key_list.append(bridge_id)

        key_list.sort()
        num_keys = len(key_list)
        print("Created bridge ID list: (%d keys)" % num_keys)
        for x in key_list:
            print("bridge ID: %d" % x)

        print("--------------------------------GET---------------------------------------------------------------------------")

        key_cnt_p = new_uint32_t_p()
        key_list_p = new_sx_bridge_id_t_arr(MAX_KEY_NUM)
        # Use GET to get all elements in the list
        key_get_list = []
        for key in key_list:
            uint32_t_p_assign(key_cnt_p, 1)
            print("GET    bridge_id: %d, key_cnt: %d" % (key, 1))
            rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET, key, None, key_list_p, key_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_bridge_iter_get failed, rc=%d" % rc)

            key_cnt = uint32_t_p_value(key_cnt_p)
            assert key_cnt == 1, "Returned key count is not 1"

            key_get = sx_bridge_id_t_arr_getitem(key_list_p, 0)
            print("Return bridge_id: %d, key_cnt: %d" % (key_get, key_cnt))

        print("--------------------------------COUNT---------------------------------------------------------------------------")

        # Get Count
        uint32_t_p_assign(key_cnt_p, 0)

        rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        assert key_cnt == num_keys, "Count failed, expected %d, got %d" % (num_keys, key_cnt)
        print("Count successful, expected %d, got %d" % (num_keys, key_cnt))

        print("--------------------------------GET_FIRST---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        print("GET FIRST, requested count = %d, total count = %d" % (num_get, num_keys))
        rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("GET FIRST, returned count = %d" % key_cnt)
        for i in range(0, key_cnt):
            key_get = sx_bridge_id_t_arr_getitem(key_list_p, i)
            key = key_list[i]
            assert key == key_get, "The content returned by GET FIRST is incorrect"
            print("bridge_id: %d" % (key_get))

        print("--------------------------------GET_NEXT---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        key = key_list[index]
        print("GET NEXT %d keys after %dth key (bridge_id: %d), total count = %d" % (num_get, index + 1, key, num_keys))
        rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GETNEXT, key, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after %dth key (bridge_id: %d), returned %d keys" % (num_get, index + 1, key, key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_bridge_id_t_arr_getitem(key_list_p, i)
            key = key_list[index + i + 1]
            assert key_get == key, "The content returned by GET NEXT is incorrect"
            print("bridge_id: %d" % (key_get))

        print("--------------------------------GET_NEXT with a non-existent key------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        key = key_list[index]
        sx_bridge_id_t_p_assign(bridge_id_p, key)
        rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_set failed, rc=%d" % rc)
        print("GET NEXT %d keys after key (bridge_id: %d), total count = %d" % (num_get, key, num_keys))

        rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GETNEXT, key, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after key (bridge_id: %d), returned %d keys" % (num_get, key, key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_bridge_id_t_arr_getitem(key_list_p, i)
            key = key_list[index + i + 1]
            assert key_get == key, "The content returned by GET NEXT is incorrect"
            print("bridge_id: %d" % (key_get))

        key_list.remove(key_list[index])

        # Corner cases

        # Call GET with count > 1
        case = "Test case: Call GET with count > 1"
        print(case)
        key_cnt = MAX_KEY_NUM // 2
        if key_cnt < 2:
            key_cnt = 2
        uint32_t_p_assign(key_cnt_p, key_cnt)
        index = 0
        key = key_list[index]
        rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET, key, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_bridge_iter_get failed, rc=%d in case %s" % (rc, case))
        key_cnt = uint32_t_p_value(key_cnt_p)
        assert key_cnt <= 1, "Data count not 0 or 1 as expected  in case %s" % (case)
        print(case + " passed\n")

        if args.deinit:
            print("Cleaning up bridge IDs....\n")
            for key in key_list:
                sx_bridge_id_t_p_assign(bridge_id_p, key)
                rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
                if rc != SX_STATUS_SUCCESS:
                    raise Exception("sx_api_bridge_set failed, rc=%d" % rc)
        sx_api_close(handle)
        ret_code = 0

    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        traceback.print_exc()

    finally:
        if ret_code:
            print("Test failed: Return code = %d" % ret_code)
        else:
            print("All tests passed")
        sys.exit(ret_code)


if __name__ == "__main__":
    main()
