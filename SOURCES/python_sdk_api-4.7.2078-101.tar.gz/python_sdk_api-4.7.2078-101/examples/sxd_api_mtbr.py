#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *

print("[+] MTBR register access Example Test start")
print("[+] initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

mtbr = ku_mtbr_reg_ext()
mtbr.base_sensor_index = 0
mtbr.num_rec = 1

print("[+] Get MTBR")
rc = sxd_access_reg_mtbr(mtbr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MTBR register, rc: %d" % (rc)

print("[+] MTBR content")
print("====================")
print("[+] mtbr.base_sensor_index: ", mtbr.base_sensor_index)
print("[+] mtbr.num_rec: ", mtbr.num_rec)
print("[+] mtbr.temperature_record.max_temperature.integer_part: ", mtbr.temperature_record.max_temperature.integer_part)
print("[+] mtbr.temperature_record.max_temperature.fractional_part: ", mtbr.temperature_record.max_temperature.fractional_part)
print("[+] mtbr.temperature_record.temperature.integer_part: ", mtbr.temperature_record.temperature.integer_part)
print("[+] mtbr.temperature_record.temperature.fractional_part: ", mtbr.temperature_record.temperature.fractional_part)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] MTBR register access example test end")
