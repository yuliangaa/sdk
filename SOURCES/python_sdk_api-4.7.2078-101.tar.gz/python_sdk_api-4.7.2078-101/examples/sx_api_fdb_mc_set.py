#!/usr/bin/env python

import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_fdb_mc_set')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

rc, handle = sx_api_open(None)
print(("handle: 0x%x , rc: %d " % (handle, rc)))

port_p = new_uint32_t_p()
uint32_t_p_assign(port_p, 0x10011)

mac_entry1 = sx_fdb_uc_mac_addr_params_t()
macs = []
MAC_COUNT = 2
for i in range(MAC_COUNT):
    mac_addr = ether_addr(1, 0, 0x5e, 1, i // 256, i % 256)
    macs.append(mac_addr)
    mac_entry1.mac_addr = macs[-1]

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, 1, mac_entry1.mac_addr, port_p, 1)
    port = uint32_t_p_value(port_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fdb_mc_mac_addr_set added MAC 0x%x, MAC=01:00:5E:01:%x:%x , rc: %d " % (port, i // 256, i % 256, rc)))
        sys.exit(rc)

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD_PORTS, 0, 1, mac_entry1.mac_addr, port_p, 1)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fdb_mc_mac_addr_set added PORT 0x%x, MAC=01:00:5E:01:%x:%x , rc: %d " % (port, i // 256, i % 256, rc)))
        sys.exit(rc)

if args.deinit:
    for mac_addr in macs:
        mac_entry1.mac_addr = mac_addr

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE_PORTS, 0, 1, mac_entry1.mac_addr, port_p, 1)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_fdb_mc_mac_addr_set deleted PORT 0x%x, MAC=01:00:5E:01:%x:%x , rc: %d " % (port, i // 256, i % 256, rc)))
            sys.exit(rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, 1, mac_entry1.mac_addr, port_p, 1)
        port = uint32_t_p_value(port_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_fdb_mc_mac_addr_set deleted MAC 0x%x, MAC=01:00:5E:01:%x:%x , rc: %d " % (port, i // 256, i % 256, rc)))
            sys.exit(rc)

sx_api_close(handle)
