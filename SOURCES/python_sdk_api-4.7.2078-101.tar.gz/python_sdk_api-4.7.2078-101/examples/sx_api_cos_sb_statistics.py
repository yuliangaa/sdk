#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_sb_statistics')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
args = parser.parse_args()
print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

""" BUFF TYPE STATISTICS GET """
print("---------------  BUFF TYPE STATISTICS GET ------------------------------")
cmd = SX_ACCESS_CMD_READ
statistics_cnt = 1
statistic_param_list_p = new_sx_port_statistic_usage_params_t_arr(statistics_cnt)
attr_item = new_sx_port_statistic_usage_params_t_arr(1)

for i in range(0, statistics_cnt):
    attr_item = sx_port_statistic_usage_params_t_arr_getitem(statistic_param_list_p, i)
    """ Set relevant parameters """
    attr_item.port_cnt = 1
    attr_item.log_port_list_p = new_sx_port_log_id_t_arr(attr_item.port_cnt)
    """ Set a value at index 0 """
    sx_port_log_id_t_arr_setitem(attr_item.log_port_list_p, 0, PORT1)
    """ Set a value at index 1 """
    sx_port_log_id_t_arr_setitem(attr_item.log_port_list_p, 1, PORT2)

    attr_item.sx_port_params.port_params_cnt = 9
    attr_item.sx_port_params.port_params_type = SX_COS_PORT_BUFF_ATTR_RESERVED3_E

    print("Statistics required params")
    print("--------------------------")
    print(("[%d] port_cnt = %d" % (i, attr_item.port_cnt)))
    print(("[%d] log_port_0 = %d" % (i, sx_port_log_id_t_arr_getitem(attr_item.log_port_list_p, 0))))
    print(("[%d] log_port_1 = %d" % (i, sx_port_log_id_t_arr_getitem(attr_item.log_port_list_p, 1))))
    print(("[%d] union num entries = %d" % (i, attr_item.sx_port_params.port_params_cnt)))
    print(("[%d] union type = %d" % (i, attr_item.sx_port_params.port_params_type)))

    if attr_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_ATTR_E:
        attr_item.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (pool#0)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0, 0)
        """ Set a value at index 0 (pool#1)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1, 1)
        print(("[%d] port.pool 0 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0))))
        print(("[%d] port.pool 1 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E or attr_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E:
        attr_item.sx_port_params.port_param.port_pg_list_p = new_sx_cos_priority_group_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.port_pg_list_p = new_sx_cos_priority_group_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (PG#0)"""
        sx_cos_priority_group_t_arr_setitem(attr_item.sx_port_params.port_param.port_pg_list_p, 0, 0)
        """ Set a value at index 0 (PG#4)"""
        sx_cos_priority_group_t_arr_setitem(attr_item.sx_port_params.port_param.port_pg_list_p, 1, 4)
        print(("[%d] PG 0 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.port_pg_list_p, 0))))
        print(("[%d] PG 1 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.port_pg_list_p, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_EGRESS_PORT_ATTR_E:
        attr_item.sx_port_params.port_param.egress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.egress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (pool#4)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.egress_port_pool_list_p, 0, 4)
        """ Set a value at index 0 (pool#5)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.egress_port_pool_list_p, 1, 5)
        print(("[%d] port.pool 0 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.egress_port_pool_list_p, 0))))
        print(("[%d] port.pool 1 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.egress_port_pool_list_p, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        attr_item.sx_port_params.port_param.port_tc_list_p = new_sx_cos_traffic_class_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.port_tc_list_p = new_sx_cos_traffic_class_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (TC#0)"""
        sx_cos_traffic_class_t_arr_setitem(attr_item.sx_port_params.port_param.port_tc_list_p, 0, 0)
        """ Set a value at index 0 (TC#4)"""
        sx_cos_traffic_class_t_arr_setitem(attr_item.sx_port_params.port_param.port_tc_list_p, 1, 4)
        print(("[%d] TC 0 = %d" % (i, sx_cos_traffic_class_t_arr_getitem(attr_item.sx_port_params.port_param.port_tc_list_p, 0))))
        print(("[%d] TC 1 = %d" % (i, sx_cos_traffic_class_t_arr_getitem(attr_item.sx_port_params.port_param.port_tc_list_p, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_MULTICAST_ATTR_E:
        attr_item.port_cnt = 1
        attr_item.sx_port_params.port_param.mc_switch_prio = new_sx_cos_priority_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.mc_switch_prio = new_sx_cos_priority_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (MC#0)"""
        sx_cos_priority_t_arr_setitem(attr_item.sx_port_params.port_param.mc_switch_prio, 0, 0)
        """ Set a value at index 0 (MC#5)"""
        sx_cos_priority_t_arr_setitem(attr_item.sx_port_params.port_param.mc_switch_prio, 1, 5)
        print(("[%d] MC 0 = %d" % (i, sx_cos_priority_t_arr_getitem(attr_item.sx_port_params.port_param.mc_switch_prio, 0))))
        print(("[%d] MC 1 = %d" % (i, sx_cos_priority_t_arr_getitem(attr_item.sx_port_params.port_param.mc_switch_prio, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_MULTICAST_PORT_ATTR_E:
        attr_item.sx_port_params.port_params_cnt = 1
        attr_item.sx_port_params.port_param.egress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.egress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        print(("[%d] MC Port " % (i)))

    if attr_item.sx_port_params.port_params_type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or attr_item.sx_port_params.port_params_type < SX_COS_INGRESS_PORT_ATTR_E:
        print(("[%d] Unsupported union type = %d" % (i, attr_item.sx_port_params.port_params_type)))
        sys.exit(rc)

    if attr_item.sx_port_params.port_params_type == SX_COS_PORT_BUFF_ATTR_RESERVED1_E:
        attr_item.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (pool#0)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0, 21)
        """ Set a value at index 0 (pool#1)"""
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1, 22)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 2, 23)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 3, 24)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 4, 25)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 5, 26)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 6, 27)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 7, 28)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 8, 29)
        print(("[%d] port.pool 0 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0))))
        print(("[%d] port.pool 1 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1))))

    if attr_item.sx_port_params.port_params_type == SX_COS_PORT_BUFF_ATTR_RESERVED3_E:
        attr_item.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.ingress_port_pool_list_p = new_sx_cos_pool_id_t_arr(attr_item.sx_port_params.port_params_cnt)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0, 30)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1, 31)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 2, 32)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 3, 33)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 4, 34)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 5, 35)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 6, 36)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 7, 37)
        sx_cos_pool_id_t_arr_setitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 8, 38)
        print(("[%d] port.pool 0 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 0))))
        print(("[%d] port.pool 1 = %d" % (i, sx_cos_pool_id_t_arr_getitem(attr_item.sx_port_params.port_param.ingress_port_pool_list_p, 1))))

""" Call API with cnt=0 to retrieve number of expected retrieved entries """
usage_cnt_p = new_uint32_t_p()
""" Set cnt = 0 """
uint32_t_p_assign(usage_cnt_p, 0)

""" Set updated parameters to the object """
sx_port_statistic_usage_params_t_arr_setitem(statistic_param_list_p, 0, attr_item)

print("Call Get statistic API with cnt = 0 ")
rc = sx_api_cos_port_buff_type_statistic_get(handle, cmd, statistic_param_list_p, statistics_cnt, None, usage_cnt_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

""" Get value from PTR """
usage_cnt = uint32_t_p_value(usage_cnt_p)
print(("usage_cnt (returned from API = %d)" % (usage_cnt)))

""" Alloc mem for usage retrieved parametes """
usage_list_p = new_sx_port_occupancy_statistics_t_arr(usage_cnt)

""" Call API with cnt=0 to retrieve number of expected retrieved entries """
print(("Call Get statistic API with cnt = %d " % (usage_cnt)))
rc = sx_api_cos_port_buff_type_statistic_get(handle, cmd, statistic_param_list_p, statistics_cnt, usage_list_p, usage_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_cos_port_buff_type_statistic_get FAILED %d" % (rc)))
    sys.exit(rc)

print("---------------------")
print("Retrieved statistics:")
print("---------------------")
for i in range(0, usage_cnt):
    ret_item = sx_port_occupancy_statistics_t_arr_getitem(usage_list_p, i)
    print(("[%d] log_port = 0x%x" % (i, ret_item.log_port)))
    print(("[%d] port_params_type = %d" % (i, ret_item.sx_port_params.port_params_type)))

    if ret_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_ATTR_E:
        print(("[%d] ingress_port_pool = %d" % (i, ret_item.sx_port_params.port_param.ingress_port_pool)))

    if ret_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E or ret_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E:
        print(("[%d] port_pg = %d" % (i, ret_item.sx_port_params.port_param.port_pg)))

    if ret_item.sx_port_params.port_params_type == SX_COS_EGRESS_PORT_ATTR_E:
        print(("[%d] egress_port_pool = %d" % (i, ret_item.sx_port_params.port_param.egress_port_pool)))

    if ret_item.sx_port_params.port_params_type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        print(("[%d] port_tc = %d" % (i, ret_item.sx_port_params.port_param.port_tc)))

    if ret_item.sx_port_params.port_params_type == SX_COS_MULTICAST_ATTR_E:
        print(("[%d] mc_switch_prio = %d" % (i, ret_item.sx_port_params.port_param.mc_switch_prio)))

    if ret_item.sx_port_params.port_params_type == SX_COS_MULTICAST_PORT_ATTR_E:
        print(("[%d] MC Port Pool " % (i)))

    if ret_item.sx_port_params.port_params_type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or attr_item.sx_port_params.port_params_type < SX_COS_INGRESS_PORT_ATTR_E:
        print(("[%d] Unsupported union type = %d" % (i, ret_item.sx_port_params.port_params_type)))
        sys.exit(rc)

    if ret_item.sx_port_params.port_params_type == SX_COS_PORT_BUFF_ATTR_RESERVED1_E:
        print(("[%d] ingress_port_pool = %d" % (i, ret_item.sx_port_params.port_param.ingress_port_pool)))

    print(("[%d] Curr occupancy = %d" % (i, ret_item.statistics.curr_occupancy)))
    print(("[%d] Max occupancy = %d" % (i, ret_item.statistics.watermark)))
    print("---------------")

""" ############################################################################################ """
""" ############################################################################################ """

""" POOL STATISTICS GET """
print("---------------  POOL STATISTICS GET ------------------------------")
cmd = SX_ACCESS_CMD_READ
pool_id_cnt = 8
pool_id_list_p = new_sx_cos_pool_id_t_arr(pool_id_cnt)
usage_list_p = new_sx_cos_pool_occupancy_statistics_t_arr(pool_id_cnt)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 0, 0)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 1, 1)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 2, 2)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 3, 3)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 4, 4)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 5, 5)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 6, 6)
attr_item = sx_cos_pool_id_t_arr_setitem(pool_id_list_p, 7, 7)

rc = sx_api_cos_pool_statistic_get(handle, cmd, pool_id_list_p, pool_id_cnt, usage_list_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

print(("sx_api_cos_pool_statistic_get [cmd=0x%x , pool_id_cnt=%d, rc=%d] " % (cmd, pool_id_cnt, rc)))
print("--------------------------------------------------------------------")
for i in range(0, pool_id_cnt):
    attr_item = sx_cos_pool_occupancy_statistics_t_arr_getitem(usage_list_p, i)
    print(("[%d] pool_id = %d" % (i, attr_item.pool_id)))
    print(("[%d] Curr occupancy = %d" % (i, attr_item.statistics.curr_occupancy)))
    print(("[%d] Max occupancy = %d" % (i, attr_item.statistics.watermark)))
    print("---------------")

""" ############################################################################################ """
