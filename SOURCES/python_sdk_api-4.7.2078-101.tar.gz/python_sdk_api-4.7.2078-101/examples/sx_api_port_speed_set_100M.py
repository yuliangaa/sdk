#!/usr/bin/env python
'''
Sets all port speed to 100M
'''
import sys
import errno
import sys
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_speed_set_100M')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_attributes_list = new_sx_port_attributes_t_arr(64)
port_cnt_p = new_uint32_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
uint32_t_p_assign(port_cnt_p, 64)
admin_speed_p = new_sx_port_speed_capability_t_p()
#oper_state_p = new_sx_port_oper_state_t_p()
#admin_state_p = new_sx_port_admin_state_t_p()
#module_state_p = new_sx_port_module_state_t_p()


def get_port_admin_speed(port):
    admin_speed_p = new_sx_port_speed_capability_t_p()
    oper_speed_p = new_sx_port_oper_speed_t_p()
    rc = sx_api_port_speed_get(handle, port, admin_speed_p, oper_speed_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_speed_get failed for port[%d], rc=%d] " % (port, rc)))
        sys.exit(rc)
    return admin_speed_p


rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_device_get failed, rc=%d] " % (rc)))
    sys.exit(rc)
port_cnt = uint32_t_p_value(port_cnt_p)

for i in range(0, port_cnt):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_vport or is_cpu:
        continue

    original_port_admin_speed_p = get_port_admin_speed(int(port_attributes.log_port))

    rc = sx_api_port_state_set(handle, int(port_attributes.log_port), SX_PORT_ADMIN_STATUS_DOWN)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
        sys.exit(rc)

    print(("[+] Setting log_port:0x%x admin state to DOWN." % (port_attributes.log_port)))
    admin_speed = sx_port_speed_capability_t()
    admin_speed.mode_100MB_TX = 1
    admin_speed.mode_auto = 0
    admin_speed.force = 0
    sx_port_speed_capability_t_p_assign(admin_speed_p, admin_speed)
    rc = sx_api_port_speed_admin_set(handle, int(port_attributes.log_port), admin_speed_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_speed_admin_set failed, rc=%d] " % (rc)))
        sys.exit(rc)
    print(("[+] Setting log_port:0x%x speed to 100M." % (port_attributes.log_port)))

    rc = sx_api_port_state_set(handle, int(port_attributes.log_port), SX_PORT_ADMIN_STATUS_UP)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
        sys.exit(rc)

    if args.deinit:
        rc = sx_api_port_state_set(handle, int(port_attributes.log_port), SX_PORT_ADMIN_STATUS_DOWN)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
            sys.exit(rc)

        rc = sx_api_port_speed_admin_set(handle, int(port_attributes.log_port), original_port_admin_speed_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_speed_admin_set failed, rc=%d] " % (rc)))
            sys.exit(rc)

        rc = sx_api_port_state_set(handle, int(port_attributes.log_port), SX_PORT_ADMIN_STATUS_UP)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
            sys.exit(rc)


""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
