#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
For Spectrum2 and above:
 * PORT_USER_MEM ACL Range creation
 * PRBS ACL Range creation
For Spectrum4 and above:
 * EXACT match ACL Range creation
"""
import sys
import socket
import struct
import errno
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_acl_range_set/get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

######################################################
#    defines
######################################################
range_type_to_str = {
    SX_ACL_RANGE_TYPE_L4_PORT_E: "L4_PORT",
    SX_ACL_RANGE_TYPE_IP_LENGTH_E: "IP_LENGTH",
    SX_ACL_RANGE_TYPE_TTL_E: "TTL",
    SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E: "CUSTOM_BYTE",
    SX_ACL_RANGE_TYPE_UTC_29_14_E: "UTC_29_14",
    SX_ACL_RANGE_TYPE_REGISTER_E: "GP REGISTER",
    SX_ACL_RANGE_TYPE_PORT_USER_MEM_E: "PORT_USER_MEM",
    SX_ACL_RANGE_TYPE_PRBS_E: "PRBS",
}

match_type_to_str = {
    SX_ACL_RANGE_MATCH_TYPE_RANGE_E: "RANGE",
    SX_ACL_RANGE_MATCH_TYPE_EXACT_E: "EXACT MATCH",
}

outer_inner_to_str = {
    SX_ACL_PORT_RANGE_IP_HEADER_OUTER: "OUTER",
    SX_ACL_PORT_RANGE_IP_HEADER_INNER: "INNER",
    SX_ACL_PORT_RANGE_IP_HEADER_BOTH: "BOTH",
}

ip_version_to_str = {
    SX_IP_VERSION_NONE: "IGNORE L3",
    SX_IP_VERSION_IPV4: "IPV4",
    SX_IP_VERSION_IPV6: "IPV6",
    SX_IP_VERSION_IPV4_IPV6: "IPV4_IPV6",
}

l4_protocol_to_str = {
    SX_ACL_L4_TYPE_INVALID: "IGNORE L4",
    SX_ACL_L4_TYPE_TCP: "TCP",
    SX_ACL_L4_TYPE_UDP: "UDP",
    SX_ACL_L4_TYPE_TCP_UDP: "TCP_UDP",
}

direction_to_str = {
    SX_ACL_PORT_DIRECTION_SOURCE: "SOURCE",
    SX_ACL_PORT_DIRECTION_DESTINATION: "DESTINATION",
    SX_ACL_PORT_DIRECTION_BOTH: "BOTH",
}

######################################################
#    functions
######################################################


def acl_range_entry_dump(range_entry_p):
    print("-" * 30)
    print("range type: %s" % (range_type_to_str[range_entry_p.range_type] if range_entry_p.range_type in range_type_to_str else "N/A"))
    print("range limits: [%d-%d]" % (range_entry_p.range_limits.min, range_entry_p.range_limits.max))
    print("match type: %s" % (match_type_to_str[range_entry_p.match_type] if range_entry_p.match_type in match_type_to_str else "N/A"))
    print("outer_inner %s" % (outer_inner_to_str[range_entry_p.outer_inner] if range_entry_p.outer_inner in outer_inner_to_str else "N/A"))
    print("ip_version:  %s" % (ip_version_to_str[range_entry_p.ip_version] if range_entry_p.ip_version in ip_version_to_str else "N/A"))
    print("l4_protocol: %s" % (l4_protocol_to_str[range_entry_p.l4_protocol] if range_entry_p.l4_protocol in l4_protocol_to_str else "N/A"))
    if range_entry_p.range_type == SX_ACL_RANGE_TYPE_L4_PORT_E:
        print("direction: %s" % (direction_to_str[range_entry_p.direction] if range_entry_p.direction in direction_to_str else "N/A"))
    if range_entry_p.range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E:
        print("cb_key: %d" % (range_entry_p.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id))
    if range_entry_p.range_type == SX_ACL_RANGE_TYPE_REGISTER_E:
        print("reg_key: %d" % (range_entry_p.range_attr.register_range_attr.reg_key.key.gp_reg.reg_id))
    print("-" * 30)


def acl_range_add(handle, range_type, range_min, range_max,
                  match_type=SX_ACL_RANGE_MATCH_TYPE_RANGE_E, outer_inner=SX_ACL_PORT_RANGE_IP_HEADER_OUTER,
                  ip_version=SX_IP_VERSION_IPV4_IPV6, l4_protocol=SX_ACL_L4_TYPE_TCP_UDP, direction=SX_ACL_PORT_DIRECTION_BOTH,
                  cb_key=None, reg_key=None):
    print("")

    range_id_p = new_sx_acl_port_range_id_t_p()

    range_entry_p = new_sx_acl_range_entry_t_p()
    range_entry_p.range_type = range_type
    range_entry_p.match_type = match_type
    range_entry_p.outer_inner = outer_inner
    range_entry_p.ip_version = ip_version
    range_entry_p.l4_protocol = l4_protocol if range_type != SX_ACL_RANGE_TYPE_IP_LENGTH_E else 0
    range_entry_p.direction = direction if range_type == SX_ACL_RANGE_TYPE_L4_PORT_E else 0
    if range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E:
        range_entry_p.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id = cb_key
    if range_type == SX_ACL_RANGE_TYPE_REGISTER_E:
        range_entry_p.range_attr.register_range_attr.reg_key.key.gp_reg.reg_id = reg_key
    range_entry_p.range_limits.min = range_min
    range_entry_p.range_limits.max = range_max

    try:
        print("acl_range_add: Adding new range ID with the following params:")
        acl_range_entry_dump(range_entry_p)

        rc = sx_api_acl_range_set(handle, SX_ACCESS_CMD_ADD, range_entry_p, range_id_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to add ACL range entry"

        range_id = sx_acl_port_range_id_t_p_value(range_id_p)
        print("acl_range_add: ACL range #%d added." % (range_id))

        return range_id
    finally:
        delete_sx_acl_range_entry_t_p(range_entry_p)
        delete_sx_acl_port_range_id_t_p(range_id_p)


def acl_range_del(handle, range_id):
    print("")

    range_id_p = new_sx_acl_port_range_id_t_p()

    try:
        print("acl_range_del: Deleting ACL range #%d: " % (range_id))
        sx_acl_port_range_id_t_p_assign(range_id_p, range_id)

        rc = sx_api_acl_range_set(handle, SX_ACCESS_CMD_DELETE, None, range_id_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to add ACL range entry"

        print("acl_range_del: ACL range #%d deleted." % (range_id))
    finally:
        delete_sx_acl_port_range_id_t_p(range_id_p)


def port_user_memory_set(handle, log_ports_cnt, clr=False):
    print("")

    log_ports = []
    log_ports = get_ports(handle, log_ports_cnt)

    port_user_memory_arr = new_sx_port_user_memory_params_t_arr(log_ports_cnt)

    try:
        print("port_user_memory_set: setting port user memory: ")
        for index, log_port in enumerate(log_ports):
            port_params = sx_port_user_memory_params_t()
            port_params.log_port = log_port
            port_params.port_user_memory_value = 0 if clr else log_port & 0xff
            port_params.port_user_memory_mask = 0xff
            sx_port_user_memory_params_t_arr_setitem(port_user_memory_arr, index, port_params)

            print("port_user_memory_set: log port = %s - %d: " % (hex(log_port), port_params.port_user_memory_value))

        rc = sx_api_port_user_memory_set(handle, SX_ACCESS_CMD_SET, port_user_memory_arr, log_ports_cnt)
        assert SX_STATUS_SUCCESS == rc, "Failed to set port user memory"

        print("port_user_memory_set: done.")
    finally:
        delete_sx_port_user_memory_params_t_p(port_user_memory_arr)


"""

The example below performs shows how to create PORT_USER_MEM ACL Range.
PORT_USER_MEM Range is comparing values stored in log port memory (8-bit memory per port, see sx_api_port_user_memory_set)
In the end Flex ACL Key will be created. This key can be used for further ACL rule configuration (not a part of this example)

"""


def acl_range_port_user_mem_example(handle):
    print("#" * 80)
    print("acl_range_port_user_mem_example: START")

    # Configure port user memory for 4 logical ports:
    # for each log port memory we will write local port (0x10001 - 1, and etc.)
    print("acl_range_port_user_mem_example: store local port number into port user memory")
    log_ports_cnt = 4
    port_user_memory_set(handle, log_ports_cnt)

    ranges = []

    print("acl_range_port_user_mem_example: Add PORT_USER_MEM ACL Range #1 - covers all ports")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PORT_USER_MEM_E, range_min=0, range_max=0xff)
    ranges.append(range_id)

    print("acl_range_port_user_mem_example: Add PORT_USER_MEM ACL Range #2 - covers only local ports 1-13")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PORT_USER_MEM_E, range_min=1, range_max=13)
    ranges.append(range_id)

    print("acl_range_port_user_mem_example: Add PORT_USER_MEM ACL Range #3 - covers only local ports 5-9")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PORT_USER_MEM_E, range_min=5, range_max=9)
    ranges.append(range_id)

    # Example of Flex ACL Key for Range #1
    port_ranges_list = new_sx_acl_port_range_id_t_arr(1)
    sx_acl_port_range_id_t_arr_setitem(port_ranges_list, 0, ranges[0])

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_PORT_RANGE
    key_desc.key.l4_port_range.port_range_cnt = 1
    key_desc.key.l4_port_range.port_range_list = port_ranges_list
    key_desc.mask.l4_port_range = True

    if args.deinit:
        print("acl_range_port_user_mem_example: Clear all configuration done by the example")
        for range_id in ranges:
            acl_range_del(handle, range_id)
        port_user_memory_set(handle, log_ports_cnt, True)

    print("")
    print("acl_range_port_user_mem_example: END")
    print("#" * 80)


"""

The example below performs shows how to create PRBS ACL Range.
PRBS Range compares the value with 16-bit PRBS value, which is calculated in HW.
Whole range represent 100% probability, half of the range - 50% and etc.
Ranges which cover the part of the range, but start from different points, will give the same probability.
In the end Flex ACL Key will be created. This key can be used for further ACL rule configuration (not a part of this example)

"""


def acl_range_prbs_example(handle):
    print("#" * 80)
    print("acl_range_prbs_example: START")

    ranges = []

    print("acl_range_prbs_example: Add PRBS ACL Range #1 - 100% of probability - whole range is covered")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PRBS_E, range_min=0, range_max=0xffff)
    ranges.append(range_id)

    print("acl_range_prbs_example: Add PRBS ACL Range #2 - 50% of probability - half of the range is covered")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PRBS_E, range_min=0, range_max=0xffff // 2)
    ranges.append(range_id)

    print("acl_range_prbs_example: Add PRBS ACL Range #3 - 50% of probability - half of the range is covered")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PRBS_E, range_min=0xffff // 2, range_max=0xffff)
    ranges.append(range_id)

    print("acl_range_prbs_example: Add PRBS ACL Range #4 - 25% of probability")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PRBS_E, range_min=0xffff // 4, range_max=0xffff // 2)
    ranges.append(range_id)

    print("acl_range_prbs_example: Add PRBS ACL Range #5 - 1% of probability")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_PRBS_E, range_min=0, range_max=0xffff // 100)
    ranges.append(range_id)

    # Example of Flex ACL Key for Range #1
    port_ranges_list = new_sx_acl_port_range_id_t_arr(1)
    sx_acl_port_range_id_t_arr_setitem(port_ranges_list, 0, ranges[0])

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_PORT_RANGE
    key_desc.key.l4_port_range.port_range_cnt = 1
    key_desc.key.l4_port_range.port_range_list = port_ranges_list
    key_desc.mask.l4_port_range = True

    # Clear all configuration done by the example
    if args.deinit:
        for range_id in ranges:
            acl_range_del(handle, range_id)

    print("")
    print("acl_range_prbs_example: END")
    print("#" * 80)


"""

The example below performs shows how to create PRBS ACL Range with EXACT match type.
This match type is support starting from Spectrum4.
In the example L4 PORT range type is used, but EXACT match types works with any ACL ranges.
In the end Flex ACL Key will be created. This key can be used for further ACL rule configuration (not a part of this example)

"""


def acl_range_exact_match_example(handle):
    print("#" * 80)
    print("acl_range_exact_match_example: START")

    ranges = []

    print("acl_range_prbs_example: Add PRBS ACL Range #1 - range matches all packets with L4 ports from 80 to 8080")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_L4_PORT_E, range_min=80, range_max=8080,
                             match_type=SX_ACL_RANGE_MATCH_TYPE_RANGE_E)
    ranges.append(range_id)

    print("acl_range_prbs_example: Add PRBS ACL Range #2 - range matches only packets with L4 ports 80 or 8080")
    range_id = acl_range_add(handle, range_type=SX_ACL_RANGE_TYPE_L4_PORT_E, range_min=80, range_max=8080,
                             match_type=SX_ACL_RANGE_MATCH_TYPE_EXACT_E)
    ranges.append(range_id)

    # Example of Flex ACL Key for Range #1
    port_ranges_list = new_sx_acl_port_range_id_t_arr(1)
    sx_acl_port_range_id_t_arr_setitem(port_ranges_list, 0, ranges[0])

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_PORT_RANGE
    key_desc.key.l4_port_range.port_range_cnt = 1
    key_desc.key.l4_port_range.port_range_list = port_ranges_list
    key_desc.mask.l4_port_range = True

    # Clear all configuration done by the example
    if args.deinit:
        for range_id in ranges:
            acl_range_del(handle, range_id)

    print("")
    print("acl_range_exact_match_example: END")
    print("#" * 80)


######################################################
#    main
######################################################
def main():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5]:
        print("sx_api_acl_range_set/get is not supported on this chip type.")
        sx_api_close(handle)
        sys.exit(0)

    # Example for PORT_USER_MEM ACL Range
    acl_range_port_user_mem_example(handle)

    # Example for PRBS ACL Range
    acl_range_prbs_example(handle)

    if chip_type in [SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5]:
        acl_range_exact_match_example(handle)

    sx_api_close(handle)

    print("")
    print("finished")


if __name__ == "__main__":
    main()
