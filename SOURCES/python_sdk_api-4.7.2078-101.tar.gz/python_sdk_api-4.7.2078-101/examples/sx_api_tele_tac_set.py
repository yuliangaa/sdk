#!/usr/bin/env python
"""
This file contains Python command example for TAC configuration of the Telemetry module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


######################################################
#    functions
######################################################
def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def span_init(handle):
    """SPAN INIT"""
    print("--------------- SPAN INIT------------------------------")

    init_params_p = new_sx_span_init_params_t_p()
    init_params = sx_span_init_params_t()
    init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    print(("sx_api_span_init_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("version = %d " % (init_params.version)))
    delete_sx_span_init_params_t_p(init_params_p)


""" ############################################################################################ """


def span_session_create(handle, span_session_param_p):
    """SPAN SESSION CREATE"""
    print("--------------- SPAN SESSION CREATE------------------------------")

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


""" ############################################################################################ """


def span_session_create_remote(handle):
    # create a span session
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    span_session_param.span_type = SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1
    span_session_param.span_type_format.remote_eth_l3_type1.qos_mode = SX_SPAN_QOS_CONFIGURED
    span_session_param.span_type_format.remote_eth_l3_type1.switch_prio = TAC_TC  # switch prio mapped to TC in span configurastion
    span_session_param.span_type_format.remote_eth_l3_type1.vid = VID
    span_session_param.span_type_format.remote_eth_l3_type1.vlan_ethertype_id = 0
    span_session_param.span_type_format.remote_eth_l3_type1.dei = DEI
    span_session_param.span_type_format.remote_eth_l3_type1.pcp = PCP
    span_session_param.span_type_format.remote_eth_l3_type1.tp = TP
    span_session_param.span_type_format.remote_eth_l3_type1.mac = ether_addr(REMOTE_DMAC)
    span_session_param.span_type_format.remote_eth_l3_type1.smac = ether_addr(REMOTE_L3_SMAC)
    span_session_param.span_type_format.remote_eth_l3_type1.ttl = REMOTE_L3_TTL
    span_session_param.span_type_format.remote_eth_l3_type1.src_ip = make_sx_ip_addr_v4(REMOTE_L3_SIP)
    span_session_param.span_type_format.remote_eth_l3_type1.dest_ip = make_sx_ip_addr_v4(REMOTE_L3_DIP)
    span_session_param.truncate = True
    span_session_param.truncate_size = 1000
    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
    span_session_id_p = span_session_create(handle, span_session_param_p)
    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] created" % (span_session_id)))
    return span_session_id


""" ############################################################################################ """


def span_session_destroy(handle, span_session_id):
    """SPAN SESSION DESTROY"""
    print("--------------- SPAN SESSION DESTROY------------------------------")
    span_session_id_p = new_sx_span_session_id_t_p()
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)

    sx_span_session_id_t_p_assign(span_session_id_p, span_session_id)
    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    print(("Span session id [%d] destroyed" % (span_session_id)))


""" ############################################################################################ """


def span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- SPAN ANALYZER ADD ------------------------------")
    else:
        print("--------------- SPAN ANALYZER DELETE ------------------------------")
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    print(("sx_api_span_analyzer_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id):
    """ADD/DELETE SPAN MIRROR PORT """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD SPAN MIRROR PORT ------------------------------")
    else:
        print("--------------- DELETE SPAN MIRROR PORT  ------------------------------")
    rc = sx_api_span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id)
    print(("sx_api_span_mirror_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_session_state_set(handle, session_id, admin_state):
    """SPAN SESSION STATE SET """
    print("--------------- SPAN SESSION STATE SET  ------------------------------")
    print(("Span session id =%d, admin state =%d" % (session_id, admin_state)))
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    print(("sx_api_span_session_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_deinit(handle):
    """SPAN DEINIT"""
    print("--------------- SPAN DEINIT------------------------------")

    rc = sx_api_span_deinit_set(handle)
    print(("sx_api_span_deinit_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def tele_init(handle):
    " This function init tele. "

    tele_param_p = new_sx_tele_init_params_t_p()

    rc = sx_api_tele_init_set(handle, tele_param_p)
    assert (SX_STATUS_SUCCESS == rc), "tele init failed rc: %d" % (rc)
    print("sx_api_tele_init_set rc: %d " % (rc))


""" ############################################################################################ """


def tele_deinit(handle):
    " This function deinit tele. "

    rc = sx_api_tele_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "tele deinit failed rc %d" % (rc)
    print("sx_api_tele_deinit_set rc: %d " % (rc))


""" ############################################################################################ """


def tele_attributes_set(handle, internal_ts_enable=SX_TS_OVER_CRC_INGRESS_MODE_DISABLE_E, tac_enable=False):
    " This function set telemetry attributes. "

    tele_attr = sx_tele_attrib_t()
    tele_attr.internal_ts_enable = internal_ts_enable
    tac_attr = sx_tele_tac_attr_t()
    tac_attr.tac_mode = SX_TELE_TAC_MODE_TO_NETWORK_E
    tac_attr.tac_periodic_action_enabled = True
    tac_attr.tac_periodic_action = SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E
    tac_attr.tac_periodic_action_interval = 10
    tac_attr.tac_truncation_size = 0
    tele_attr.tac_attr_valid = tac_enable
    tele_attr.tac_attr = tac_attr
    rc = sx_api_tele_attributes_set(handle, tele_attr)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_attributes_set rc %d" % (rc)
    print("sx_api_tele_attributes_set rc: %d " % (rc))


""" ############################################################################################ """


def print_separator():
    print("----------------------------------------------------------")


def tele_attributes_get(handle):
    " This function set telemetry attributes. "

    tele_attr_p = new_sx_tele_attrib_t_p()
    rc = sx_api_tele_attributes_get(handle, tele_attr_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_attributes_get rc %d" % (rc)
    print("sx_api_tele_attributes_get rc: %d " % (rc))

    data = sx_tele_attrib_t_p_value(tele_attr_p)

    print_separator()
    print("Tele module attributes")
    print("TAC mode                           : %s " % (tele_tac_mode_dict[data.tac_attr.tac_mode]))
    print("TAC periodic action enabled        : %s " % (get_boolean_string(data.tac_attr.tac_periodic_action_enabled)))
    print("TAC periodic action                : %s " % (tele_tac_action_dict[data.tac_attr.tac_periodic_action]))
    print("TAC periodic action interval (msec): %d " % (data.tac_attr.tac_periodic_action_interval))
    print_separator()

    return data


""" ############################################################################################ """


def tele_tac_set(handle, trap_group, cmd, span_session_id, fail_on_err=1):
    " This function set trap group to use TAC. "

    tac_cfg_p = new_sx_tele_tac_cfg_t_p()
    span_id = span_session_id
    tac_cfg_p.tac_to_net_span_id = span_id
    rc = sx_api_tele_tac_set(handle, cmd, trap_group, tac_cfg_p)
    if rc != SX_STATUS_SUCCESS and fail_on_err == 1:
        assert SX_STATUS_SUCCESS == rc, "sx_api_tele_tac_set rc %d" % (rc)
    print("sx_api_tele_tac_set rc: %d " % (rc))

    return rc


""" ############################################################################################ """


def tele_tac_get(handle, trap_group):
    " This function set trap group to use TAC. "

    cmd = SX_ACCESS_CMD_GET
    tac_cfg_p = new_sx_tele_tac_cfg_t_p()
    rc = sx_api_tele_tac_get(handle, cmd, trap_group, tac_cfg_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_tac_get rc %d" % (rc)
    print("sx_api_tele_tac_get rc: %d " % (rc))

    tac_cfg = sx_tele_tac_cfg_t_p_value(tac_cfg_p)

    return tac_cfg


""" ############################################################################################ """


def tele_tac_action_set(handle, trap_group):
    " This function set trap group TAC action. "

    cmd = SX_ACCESS_CMD_SET

    tac_filter_p = new_sx_tele_tac_action_filter_t_p()
    tac_filter_p.filter_by_trap_group = True
    tac_filter_p.trap_group = trap_group

    tac_action_p = new_sx_tele_tac_action_info_t_p()
    tac_action_p.tac_action = SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E

    rc = sx_api_tele_tac_action_set(handle, cmd, tac_filter_p, tac_action_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_tac_action_set rc %d" % (rc)
    print("sx_api_tele_tac_action_set rc: %d " % (rc))

    return rc


""" ############################################################################################ """


def tele_tac_action_get(handle):
    " This function get trap group TAC action status. "

    cmd = SX_ACCESS_CMD_GET

    tac_action_status_p = new_sx_tele_tac_action_status_t_p()

    rc = sx_api_tele_tac_action_status_get(handle, cmd, tac_action_status_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_tac_action_get rc %d" % (rc)
    print("sx_api_tele_tac_action_get rc: %d " % (rc))

    return tac_action_status_p.tac_action_status


""" ############################################################################################ """


def tele_tac_stat_get(handle):
    " This function get trap group TAC action status. "

    cmd = SX_ACCESS_CMD_READ

    tac_stat_p = new_sx_tele_tac_statistics_t_arr(1)

    rc = sx_api_tele_tac_statistics_get(handle, cmd, tac_stat_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_tac_stat_get rc %d" % (rc)
    print("sx_api_tele_tac_action_get rc: %d " % (rc))

    return rc


""" ############################################################################################ """


def trap_ext_set(handle, cmd, trap_id, trap_group, trap_action, fail_on_err=1):

    sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
    sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
    sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
    sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

    sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
    sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

    # cmd = SX_ACCESS_CMD_SET
    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    print(("sx_api_host_ifc_trap_id_ext_set [rc=%d]" % (rc)))

    if rc != SX_STATUS_SUCCESS and fail_on_err == 1:
        sys.exit(errno.EACCES)
    print(("trap_id =%d, trap_group=%d, trap_action =%d, rc=%d" % (trap_id, trap_group, trap_action, rc)))


""" ############################################################################################ """


def host_ifc_trap_group_handle(handle, cmd, trap_group, prio, is_monitor, is_tac_capable, fd, trunc_profile_id=0):
    ''' CREATE/SET / EDIT / DESTROY/UNSET trap group '''
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = prio
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    if is_tac_capable:
        trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_PROFILE_ENABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.trunc_profile_id = trunc_profile_id
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = is_monitor
    if fd != 0:
        trap_group_attr.monitor_fd = fd
    trap_group_attr.is_tac_capable = is_tac_capable
    trap_group_attr.trap_group = trap_group
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(errno.EACCES)

    return sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group


""" ############################################################################################ """


def trap_group_set_unset(handle, cmd, trap_group, is_tac_capable=True, is_monitor=False, fd=0, trunc_profile_id=0):
    prio = 1
    return host_ifc_trap_group_handle(handle, cmd, trap_group, prio, is_monitor, is_tac_capable, fd, trunc_profile_id)


""" ############################################################################################ """


def host_ifc_fd_open(handle):
    fd_p = new_sx_fd_t_p()

    rc = sx_api_host_ifc_open(handle, fd_p)
    print(("sx_api_host_ifc_open, rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    fd = sx_fd_t_p_value(fd_p)
    print(("fd = %d" % (fd.fd)))
    return fd


""" ############################################################################################ """


def host_ifc_fd_close(handle, fd):
    fd_p = new_sx_fd_t_p()
    sx_fd_t_p_assign(fd_p, fd)
    rc = sx_api_host_ifc_close(handle, fd_p)
    print(("sx_api_host_ifc_close, rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    fd = sx_fd_t_p_value(fd_p)
    print(("fd = %d" % (fd.fd)))


""" ############################################################################################ """


def port_vlan_set(handle, cmd, log_port, vlan):
    # supported SX_ACCESS_CMD_ADD / SX_ACCESS_CMD_DELETE
    vlan_arr_one = new_sx_vlan_ports_t_arr(1)
    vlan_port = sx_vlan_ports_t()
    vlan_port.log_port = log_port
    vlan_port.is_untagged = 0
    sx_vlan_ports_t_arr_setitem(vlan_arr_one, 0, vlan_port)
    sx_api_vlan_ports_set(handle, cmd, 0, vlan, vlan_arr_one, 1)


""" ############################################################################################ """


def create_data_pool(handle, size, mode, direction):
    global pool_attr
    global pool_attr_p
    pool_attr.pool_dir = direction
    pool_attr.pool_size = size
    pool_attr.mode = mode
    pool_attr.buffer_type = SX_COS_DATA_BUFFER_E
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_CREATE, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)

    shared_headroom_pool_id = uint32_t_p_value(pool_id_p)
    return shared_headroom_pool_id


""" ############################################################################################ """


def destroy_data_pool(handle, pool_id):
    pool_attr = sx_cos_pool_attr_t()
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    pool_id_p = new_uint32_t_p()

    pool_attr.pool_dir = 0
    pool_attr.pool_size = 0
    pool_attr.mode = 0
    pool_attr.buffer_type = 0
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    uint32_t_p_assign(pool_id_p, pool_id)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_DESTROY, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)


""" ############################################################################################ """


def cos_port_shared_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_get failed, rc = %d\n" % (rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_get failed, rc = %d\n" % (rc)

    return port_sb_attr_list, port_sb_attr_cnt


""" ############################################################################################ """


def set_port_tc_shared_size(handle, port, tc, pool, size, max_mode):
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(handle, port)

    shared_buffer_attr.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.tc = tc
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Ingress Port = 0x%x, TC = %d, pool = %d, size = %d" % (port, shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.tc,
                                                                       shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.pool_id,
                                                                       shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.max.size)))

    return original_port_sb_attr_list, original_port_sb_attr_cnt


def set_port_tc_shared_default_cfg(handle, log_port, original_port_sb_attr_list, original_port_sb_attr_cnt):
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list,
                                              original_port_sb_attr_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)


""" ############################################################################################ """


def tac_tc_buff_cfg_set(handle, log_port, tac_tc):
    # Create static (Percentage) pools
    egress_static_percentage_pool_id = create_data_pool(handle, 60000, SX_COS_BUFFER_MAX_MODE_STATIC_E, SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E)
    print(("Egress static (percentage) Pool ID = %d" % (egress_static_percentage_pool_id)))

    # Set TAC TC  size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (percentage) ingress pool
    original_port_sb_attr_list, original_port_sb_attr_cnt = set_port_tc_shared_size(handle, log_port, tac_tc, egress_static_percentage_pool_id, 0xFFFFFFFE, SX_COS_BUFFER_MAX_MODE_STATIC_E)

    return egress_static_percentage_pool_id, original_port_sb_attr_list, original_port_sb_attr_cnt


""" ############################################################################################ """


def tac_tc_buff_cfg_default_set(handle, log_port, pool_id, original_port_sb_attr_list, original_port_sb_attr_cnt):
    set_port_tc_shared_default_cfg(handle, log_port, original_port_sb_attr_list, original_port_sb_attr_cnt)
    destroy_data_pool(handle, pool_id)


""" ############################################################################################ """


def trunc_profile_set(handle, cmd, profile_id, size):
    trunc_profile_cfg = sx_trap_truncate_profile_cfg_t()
    trunc_profile_cfg.truncate_size = size
    trunc_profile_cfg_p = new_sx_trap_truncate_profile_cfg_t_p()
    sx_trap_truncate_profile_cfg_t_p_assign(trunc_profile_cfg_p, trunc_profile_cfg)

    rc = sx_api_host_ifc_trap_truncate_profile_set(handle, cmd, 0, profile_id, trunc_profile_cfg_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_truncate_profile_set failed, rc = %d\n" % (rc)


def setup_all_trap_groups(handle, trap_group_set_cmd, trunc_profile_id):

    # For dynamic Trap Group allocation (Trap Group value allocated dynamically) used commands Create / Destroy
    # For static Trap Group allocation (Trap GRoup value provided by user) used Set / Unset
    cmd = trap_group_set_cmd

    trap_group = 10
    regular_trap_group = 20
    monitor_trap_group = 30
    tac_action_trap_group = 40

    trap_group = trap_group_set_unset(handle, cmd, trap_group, trunc_profile_id=trunc_profile_id)

    regular_trap_group = trap_group_set_unset(handle, cmd, regular_trap_group, is_tac_capable=False, trunc_profile_id=trunc_profile_id)

    monitor_fd = host_ifc_fd_open(handle)
    monitor_trap_group = 30
    monitor_trap_group = trap_group_set_unset(handle, cmd, monitor_trap_group, is_tac_capable=False, is_monitor=True, fd=monitor_fd, trunc_profile_id=trunc_profile_id)

    tac_action_trap_group = trap_group_set_unset(handle, cmd, tac_action_trap_group, is_tac_capable=False, trunc_profile_id=trunc_profile_id)

    return trap_group, regular_trap_group, monitor_fd, monitor_trap_group, tac_action_trap_group


def deinit_all_trap_groups(handle, trap_group, regular_trap_group, monitor_fd, monitor_trap_group, tac_action_trap_group, trap_group_unset_cmd):
    cmd = trap_group_unset_cmd

    trap_group_set_unset(handle, cmd, trap_group)
    trap_group_set_unset(handle, cmd, regular_trap_group)
    trap_group_set_unset(handle, cmd, monitor_trap_group)
    trap_group_set_unset(handle, cmd, tac_action_trap_group)
    host_ifc_fd_close(handle, monitor_fd)


def parse_arguments():
    parser = argparse.ArgumentParser(description='sx_api_tele_tac_set')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    parser.add_argument('--s', action='store_true', help='Use static allocation for Trap Group')

    return parser.parse_args()


def tac_oob_send_remote_command(handle, span_session_id):
    cmd = SX_ACCESS_CMD_SET

    tac_oob_msg_list = new_sx_tele_tac_oob_msg_t_arr(5)

    oob_msg = sx_tele_tac_oob_msg_t()
    oob_msg.oob_msg_type = SX_TELE_TAC_OOB_MSG_TYPE_CMD_E

    oob_cmd_msg = sx_tele_tac_oob_cmd_msg_t()
    oob_cmd_msg.remote_cmd = SX_TELE_TAC_OOB_CMD_FLUSH_ALL_E

    oob_msg_data = sx_tele_tac_oob_msg_data_t()
    oob_msg_data.oob_cmd_msg = oob_cmd_msg

    oob_msg.oob_msg_data = oob_msg_data
    sx_tele_tac_oob_msg_t_arr_setitem(tac_oob_msg_list, 0, oob_msg)

    oob_cfg_p = new_sx_tele_tac_oob_send_cfg_t_p()
    oob_cfg_p.tac_to_net_span_id = span_session_id
    oob_cfg_p.tac_oob_msg_list_cnt = 1
    oob_cfg_p.tac_oob_msg_list = tac_oob_msg_list
    rc = sx_api_tele_tac_oob_msg_send(handle, cmd, oob_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to send TAC OOB command message to span session %d, err = %d" % (span_session_id, rc))
        return 1


def tac_oob_send_port_label_mapping(handle, span_session_id):
    cmd = SX_ACCESS_CMD_SET

    tac_oob_msg_list = new_sx_tele_tac_oob_msg_t_arr(5)

    oob_msg = sx_tele_tac_oob_msg_t()
    oob_msg.oob_msg_type = SX_TELE_TAC_OOB_MSG_TYPE_PORT_LABEL_MAPPING_E

    sx_tele_tac_oob_msg_t_arr_setitem(tac_oob_msg_list, 0, oob_msg)

    oob_cfg_p = new_sx_tele_tac_oob_send_cfg_t_p()
    oob_cfg_p.tac_to_net_span_id = span_session_id
    oob_cfg_p.tac_oob_msg_list_cnt = 1
    oob_cfg_p.tac_oob_msg_list = tac_oob_msg_list
    rc = sx_api_tele_tac_oob_msg_send(handle, cmd, oob_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to send TAC OOB port label mapping message to span session %d, err = %d" % (span_session_id, rc))
        return 1


def tac_oob_send_user_defined(handle, span_session_id):
    cmd = SX_ACCESS_CMD_SET

    tac_oob_msg_list = new_sx_tele_tac_oob_msg_t_arr(5)

    oob_msg = sx_tele_tac_oob_msg_t()
    oob_msg.oob_msg_type = SX_TELE_TAC_OOB_MSG_TYPE_USER_DEF_E

    oob_user_def_msg = sx_tele_tac_oob_user_def_msg_t()
    oob_user_def_msg.user_tlv_type = 0xbb
    oob_user_def_msg.user_tlv_len = 128

    oob_msg_data = sx_tele_tac_oob_msg_data_t()
    oob_msg_data.oob_user_def_msg = oob_user_def_msg

    oob_msg.oob_msg_data = oob_msg_data
    sx_tele_tac_oob_msg_t_arr_setitem(tac_oob_msg_list, 0, oob_msg)

    oob_cfg_p = new_sx_tele_tac_oob_send_cfg_t_p()
    oob_cfg_p.tac_to_net_span_id = span_session_id
    oob_cfg_p.tac_oob_msg_list_cnt = 1
    oob_cfg_p.tac_oob_msg_list = tac_oob_msg_list
    rc = sx_api_tele_tac_oob_msg_send(handle, cmd, oob_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to send TAC OOB user defined message to span session %d, err = %d" % (span_session_id, rc))
        return 1


######################################################
#    main
######################################################


def main():
    args = parse_arguments()

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()
    trunc_profile_id = 1
    trunc_size = 100
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return 1

    port_list = mapPortAndInterfaces(handle)
    PORT_1 = port_list[0]
    PORT_2 = port_list[1]
    PORT_3 = port_list[2]

    analyzer_port = PORT_3
    ingress_port = PORT_1
    egress_port = PORT_2

    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
        print("TAC configuration is not supported on this chip type.")
        sx_api_close(handle)
        return 0

    trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)

    pool_id, original_port_sb_attr_list, original_port_sb_attr_cnt = tac_tc_buff_cfg_set(handle, analyzer_port, TAC_TC)

    port_vlan_set(handle, SX_ACCESS_CMD_ADD, analyzer_port, VID)

    # init telemetry
    tele_init(handle)

    # Tele attributes set should succeed when called on any platform with TAC disabled
    tele_attributes_set(handle)

    # Tele attributes get should succeed when called on any platform with any TAC configuration
    tele_attrib = tele_attributes_get(handle)

    # Tele attributes set should succeed pn SPC4+ when called with TAC enabled
    tele_attributes_set(handle, tac_enable=True)

    # Tele attributes get should succeed when called on any platform with any TAC configuration
    tele_attrib = tele_attributes_get(handle)

    trunc_profile_set(handle, SX_ACCESS_CMD_CREATE, trunc_profile_id, trunc_size)
    trap_group, regular_trap_group, monitor_fd, monitor_trap_group, tac_action_trap_group = setup_all_trap_groups(handle, trap_group_set_cmd, trunc_profile_id)

    # add SX_TRAP_ID_TAC_ACTION_DONE Trap ID to Trap Group
    tac_action_trap_id = SX_TRAP_ID_TAC_ACTION_DONE
    tac_action_done_ev_action = SX_TRAP_ACTION_TRAP_2_CPU
    trap_ext_set(handle, SX_ACCESS_CMD_SET, tac_action_trap_id, tac_action_trap_group, tac_action_done_ev_action)

    # init span
    span_init(handle)

    # create remote span session id
    remote_span_session_id = span_session_create_remote(handle)

    # add analyzer port to span session created above
    port_params_p = new_sx_span_analyzer_port_params_t_p()
    port_params = sx_span_analyzer_port_params_t()
    port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
    sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
    span_analyzer_set(handle, SX_ACCESS_CMD_ADD, analyzer_port, port_params_p, remote_span_session_id)

    # enable SPAN session admin state
    span_session_state_set(handle, remote_span_session_id, True)

    # set SPAN session id for TAC capable trap group
    tele_tac_set(handle, trap_group, SX_ACCESS_CMD_SET, remote_span_session_id)

    # add Trap ID to TAC connected Trap Group
    trap_id = SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC
    trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP
    trap_ext_set(handle, SX_ACCESS_CMD_SET, trap_id, trap_group, trap_action)

    # get Trap Group TAC configuration
    tele_tac_get(handle, trap_group)

    # set TAC Action for specific Trap Group
    tele_tac_action_set(handle, trap_group)

    # check TAC action status
    tele_tac_action_get(handle)

    # get TAC stastics
    tele_tac_stat_get(handle)

    # Send TAC OOB command message with remote command
    tac_oob_send_remote_command(handle, remote_span_session_id)

    # Send TAC OOB command message with port lable mapping
    tac_oob_send_port_label_mapping(handle, remote_span_session_id)

    # Send TAC OOB command message with user defined tlv
    tac_oob_send_user_defined(handle, remote_span_session_id)

    if args.deinit:
        # remove the Trap ID from TAC connected Trap Group
        trap_ext_set(handle, SX_ACCESS_CMD_UNSET, trap_id, trap_group, trap_action)

        # remove tac_action_trap_id from trap group
        trap_ext_set(handle, SX_ACCESS_CMD_UNSET, tac_action_trap_id, tac_action_trap_group, tac_action_done_ev_action)

        # try to disconnect Trap Group from TAC when NO Trap ID is connected , should SUCCESS
        tele_tac_set(handle, trap_group, SX_ACCESS_CMD_UNSET, 0)

        # disable SPAN session admin state
        span_session_state_set(handle, remote_span_session_id, False)

        # remove analyzer port
        span_analyzer_set(handle, SX_ACCESS_CMD_DELETE, analyzer_port, port_params_p, remote_span_session_id)

        span_session_destroy(handle, remote_span_session_id)

        span_deinit(handle)

        deinit_all_trap_groups(handle, trap_group, regular_trap_group, monitor_fd, monitor_trap_group, tac_action_trap_group, trap_group_unset_cmd)

        # deinit telemetry
        tele_deinit(handle)
        trunc_profile_set(handle, SX_ACCESS_CMD_DESTROY, trunc_profile_id, trunc_size)

        port_vlan_set(handle, SX_ACCESS_CMD_DELETE, analyzer_port, VID)

        tac_tc_buff_cfg_default_set(handle, analyzer_port, pool_id, original_port_sb_attr_list, original_port_sb_attr_cnt)

        sx_api_close(handle)


if __name__ == "__main__":
    SPECTRUM_SWID = 0
    VID = 10
    SWITCH_PRIO = 2
    DEI = 1
    PCP = 3
    TP = 1
    REMOTE_DMAC = "00:04:05:06:07:0F"
    REMOTE_L3_SMAC = "00:04:05:06:07:0A"
    REMOTE_L3_SIP = "2.2.2.2"
    REMOTE_L3_DIP = "2.2.2.3"
    REMOTE_L3_TTL = 64
    REMOTE_L3_ENCAP_LEN = 42
    TAC_TC = 5

    shared_buffer_attr = sx_cos_port_shared_buffer_attr_t()
    shared_buffer_attr_p = new_sx_cos_port_shared_buffer_attr_t_p()

    pool_attr = sx_cos_pool_attr_t()
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    pool_id_p = new_uint32_t_p()

    sys.exit(main())
