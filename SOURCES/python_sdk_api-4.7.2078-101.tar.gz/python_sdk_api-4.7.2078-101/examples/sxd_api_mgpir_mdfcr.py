#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *


def device_name_from_type(device_type):
    device_name = {0: "NONE",
                   1: "GEARBOX",
                   2: "TILE"}
    return device_name[device_type]


if __name__ == "__main__":
    print("[+] MPGPIR/MDFCR register access test start")

    print("[+] Initializing register access...")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        print("[+] Preparing meta...")
        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0
        meta.access_cmd = SXD_ACCESS_CMD_GET
        print("========================================")

        print("[+] Preparing MGPIR data...")
        mgpir = ku_mgpir_reg()

        print("[+] Querying MGPIR...")
        rc = sxd_access_reg_mgpir(mgpir, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "MGPIR request failed, rc: %d" % (rc)

        print("========================================")
        print("[+] MGPIR content:")
        print("[RO] mgpir.hw_info.device_type: ", device_name_from_type(mgpir.hw_info.device_type))
        print("[RO] mgpir.hw_info.devices_per_flash: ", mgpir.hw_info.devices_per_flash)
        print("[RO] mgpir.hw_info.num_of_devices: ", mgpir.hw_info.num_of_devices)
        print("[RO] mgpir.hw_info.num_of_modules: ", mgpir.hw_info.num_of_modules)
        print("========================================")

        if mgpir.hw_info.device_type != 1:
            # no gearboxes present on the system
            sys.exit(0)

        print("[+] Preparing mdfcr data...")
        mdfcr = ku_mdfcr_reg()
        mdfcr.device_type = mgpir.hw_info.device_type
        mdfcr.all = 0

        for grb_idx in range(0, mgpir.hw_info.num_of_devices):
            mdfcr.device_index = grb_idx

            print("[+] Querying MDFCR for Gearbox ID: ", mdfcr.device_index)
            rc = sxd_access_reg_mdfcr(mdfcr, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "MDFCR request failed, rc: %d" % (rc)

            print("========================================")
            print("[+] MDFCR content:")
            print("[index] mdfcr.device_type: ", mdfcr.device_type)
            print("[index] mdfcr.all:", mdfcr.all)
            print("[index] mdfcr.device_index:", mdfcr.device_index)
            print("[RO] mdfcr.fw_status:", mdfcr.fw_status)
            print("[RO] mdfcr.first_fw_status_device:", mdfcr.first_fw_status_device)
            print("[RO] mdfcr.expected_fw_version:", hex(mdfcr.expected_fw_version))
            print("[RO] mdfcr.fw_version:", hex(mdfcr.fw_version))
            print("[RO] mdfcr.build_id:", mdfcr.build_id)
            print("[RO] mdfcr.major:", mdfcr.major)
            print("[RO] mdfcr.minor:", mdfcr.minor)
            print("[RO] mdfcr.error_id:", mdfcr.error_id)
            print("========================================")
    finally:
        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)

        print("[+] MPGPIR/MDFCR register access test end")
