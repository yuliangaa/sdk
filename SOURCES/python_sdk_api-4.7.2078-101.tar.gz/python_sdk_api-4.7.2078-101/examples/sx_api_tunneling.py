#!/usr/bin/env python
'''
This file contains Python command example for the Tunneling module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import sys
import struct
import socket
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
from optparse import OptionParser, Option


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

# string constants
TUNN_ID = "TUNN"
DST_IP_STR = "IP"
WEIGHT_STR = "weight"

######################################################
#    Functions API
######################################################
'''
This part contains all the calls to that sdk API functions
'''
""" ############################################################################################ """


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


""" ############################################################################################ """


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


""" ############################################################################################ """


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


""" ############################################################################################ """


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


""" ############################################################################################ """


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


""" ############################################################################################ """


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return tunnel_id


""" ############################################################################################ """


def mc_container_create(container_attributes_p, tunnel_id):
    count = 1

    next_hop_list = new_sx_mc_next_hop_t_arr(count)
    next_hop = sx_mc_next_hop_t()
    next_hop.type = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4("15.15.15.15")
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 0, next_hop)

    mc_container_id_p = new_sx_mc_container_id_t_p()
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, mc_container_id_p, next_hop_list, count, container_attributes_p)
    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create mc_container, rc: %d" % (rc)

    mc_container_id = sx_mc_container_id_t_p_value(mc_container_id_p)
    return mc_container_id


""" ############################################################################################ """


def mc_container_destroy(mc_container_id):

    mc_container_id_p = new_sx_mc_container_id_t_p()
    sx_mc_container_id_t_p_assign(mc_container_id_p, mc_container_id)
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, mc_container_id_p, None, 0, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mc_container, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_destroy(tunnel_id_p):
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_create(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_destroy(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel decap rule, rc: %d" % (rc)


""" ############################################################################################ """


def tunnel_decap_rule_edit(decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_EDIT, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to edit tunnel decap rule, rc: %d" % (rc)


""" ############################################################################################ """


def create_loopback_rif(vrid, vlan, mtu=1500):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif


######################################################
#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.mc_ecmp_enabled = False
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


""" ############################################################################################ """


def make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, underlay_rif=0, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p.underlay_rif = underlay_rif  # =underlay_rif -- not supported

    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_mode = 0
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_key = 0

    tunnel_attribute.attributes.ipinip_p2p.decap.gre_check_key = 0
    tunnel_attribute.attributes.ipinip_p2p.decap.gre_expected_key = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.nve_log_port = NVE_PORT

    return tunnel_attribute


""" ############################################################################################ """


def make_mc_container_attributes():

    mc_container_attribute = sx_mc_container_attributes_t()

    mc_container_attribute.min_mtu = 128

    return mc_container_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan_gre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN_GPE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_geneve(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_GENEVE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.vxlan_gre.encap.underlay_vrid = vrid
    tunnel_attribute.vxlan_gre.encap.underlay_ttl = 255
    tunnel_attribute.vxlan_gre.encap.underlay_sip = underlay_sip
    tunnel_attribute.vxlan_gre.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_nvgre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP, log_port=NVE_PORT,
                                 underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0,
                                 decap_underlay_rif=0, tun_type=SX_TUNNEL_TYPE_NVE_NVGRE,
                                 tag_mode=SX_VLAN_TAG_MODE_802_1Q_E):
    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = tun_type
    tunnel_attribute.direction = direction

    # NVE - nvgre attributes
    tunnel_attribute.attributes.nvgre.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.nvgre.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.nvgre.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.nvgre.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.nvgre.decap.tag_mode = tag_mode
    tunnel_attribute.attributes.nvgre.nve_log_port = log_port
    tunnel_attribute.attributes.nvgre.underlay_domain_type = underlay_domain_type

    return tunnel_attribute


""" ############################################################################################ """


def make_decap_key(key_type, vrid, tunnel_type=0):  # SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip
    decap_key.underlay_sip = make_sx_ip_addr_v4("192.168.1.3")  # need to change to valid ip

    return decap_key


""" ############################################################################################ """


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    tunnel_init(general_param_p)


""" ############################################################################################ """


def example_vxlan_tunnel_create_flow(vrid):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip and to correctly add to the struct

    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, SX_TUNNEL_DIRECTION_SYMMETRIC)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(tunnel_attribute_p)

    return tunnel_id


""" ############################################################################################ """


def example_mc_container_flow(tunnel_id):

    mc_container_attribute = make_mc_container_attributes()
    mc_container_attribute.type = SX_MC_CONTAINER_TYPE_NVE_FLOOD
    mc_container_attribute.fid = 1
    mc_container_attribute_p = new_sx_mc_container_attributes_t_p()
    sx_mc_container_attributes_t_p_assign(mc_container_attribute_p, mc_container_attribute)
    mc_container_id = mc_container_create(mc_container_attribute_p, tunnel_id)

    return mc_container_id


""" ############################################################################################ """


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    tunnel_destroy(tunnel_id_p)


""" ############################################################################################ """


def example_ipinip_tunnel_create_flow(vrid, overlay_rif, direction=SX_TUNNEL_DIRECTION_DECAP):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("1.1.1.20")  # need to change to valid ip and to correctly add to the struct

    tunnel_attribute = make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, 0, direction)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(tunnel_attribute_p)

    return tunnel_id


""" ############################################################################################ """


def example_decap_rules_flow(vrid, tunnel_id, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, tunnel_type)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    tunnel_decap_rule_create(decap_key_p, decap_data_p)

    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_DROP, 0)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)
    tunnel_decap_rule_edit(decap_key_p, decap_data_p)

    tunnel_decap_rule_destroy(decap_key_p, decap_data_p)


""" ############################################################################################ """


def example_decap_rules_complex_flow(tunnel_id):
    low_prio_decap_key_p_list = []
    high_prio_decap_key_p_list = []

    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    for vrid in range(0, 16):
        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        low_prio_decap_key_p_list.append(decap_key_p)
        print("create low rule, vrid: %d" % (vrid))
        tunnel_decap_rule_create(decap_key_p, decap_data_p)

        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid + 16, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        high_prio_decap_key_p_list.append(decap_key_p)
        print("create high rule, vrid: %d" % (vrid + 16))
        tunnel_decap_rule_create(decap_key_p, decap_data_p)

    for vrid in range(0, 16):
        print("destroy low rule, vrid: %d" % (vrid))
        tunnel_decap_rule_destroy(low_prio_decap_key_p_list[vrid], decap_data_p)
        print("destroy high rule, vrid: %d" % (vrid + 16))
        tunnel_decap_rule_destroy(high_prio_decap_key_p_list[vrid], decap_data_p)


""" ############################################################################################ """


def example_tunnel_ttl_set(tunnel_id, direction, ttl_cmd, ttl_value):
    ttl_data_p = new_sx_tunnel_ttl_data_t_p()
    ttl_data = sx_tunnel_ttl_data_t()
    ttl_data.direction = direction
    ttl_data.ttl_cmd = ttl_cmd
    ttl_data.ttl_value = ttl_value
    sx_tunnel_ttl_data_t_p_assign(ttl_data_p, ttl_data)
    rc = sx_api_tunnel_ttl_set(handle, tunnel_id, ttl_data_p)
    print("Set ttl[%d:%d] for tunnel [0x%x] direction[%d] , rc = %d" % (ttl_cmd, ttl_value, tunnel_id, direction, rc))
    return rc


""" ############################################################################################ """


def example_tunnel_ttl_get(tunnel_id, direction):
    ttl_data_p = new_sx_tunnel_ttl_data_t_p()
    ttl_data = sx_tunnel_ttl_data_t()
    ttl_data.direction = direction
    sx_tunnel_ttl_data_t_p_assign(ttl_data_p, ttl_data)
    rc = sx_api_tunnel_ttl_get(handle, tunnel_id, ttl_data_p)
    ttl_data = sx_tunnel_ttl_data_t_p_value(ttl_data_p)
    if rc == SX_STATUS_SUCCESS:
        if ttl_data.ttl_cmd == SX_TUNNEL_TTL_CMD_SET_E:
            print("Get ttl[set : %d] for tunnel [0x%x] direction [%d]" % (ttl_data.ttl_value, tunnel_id, direction))
        else:
            print("Get ttl[copy from packet] for tunnel [0x%x] direction [%d], rc = %d" % (tunnel_id, direction))
    else:
        print(" Failed to get ttl for tunnel [0x%x] direction [%d], rc = %d" % (tunnel_id, direction, rc))
    return rc, ttl_data.ttl_cmd, ttl_data.ttl_value


""" ############################################################################################ """


def example_tunnel_hash_set(tunnel_id, hash_field, hash_cmd, nve_data):
    hash_data_p = new_sx_tunnel_hash_data_t_p()
    hash_data = sx_tunnel_hash_data_t()
    hash_data.hash_field_type = hash_field
    hash_data.hash_cmd = hash_cmd
    hash_data.nve_data = nve_data
    sx_tunnel_hash_data_t_p_assign(hash_data_p, hash_data)
    rc = sx_api_tunnel_hash_set(handle, tunnel_id, hash_data_p)
    print("Set hash data[%d:%d:%d:%d:%d] for tunnel 0x%x, rc = %d" % (hash_field, hash_cmd, nve_data.nve_udp_value_lsb, nve_data.nve_udp_value_msb, nve_data.nve_udp_value_msb_valid, tunnel_id, rc))
    return rc


""" ############################################################################################ """


def example_tunnel_hash_get(tunnel_id, hash_field):
    hash_data_p = new_sx_tunnel_hash_data_t_p()
    hash_data = sx_tunnel_hash_data_t()
    hash_data.hash_field_type = hash_field
    sx_tunnel_hash_data_t_p_assign(hash_data_p, hash_data)
    rc = sx_api_tunnel_hash_get(handle, tunnel_id, hash_data_p)
    hash_data = sx_tunnel_hash_data_t_p_value(hash_data_p)
    if rc == SX_STATUS_SUCCESS:
        print("Get hash field [%d] hash cmd [%d] for tunnel [0x%x]" % (hash_data.hash_field_type, hash_data.hash_cmd, tunnel_id))
    else:
        print("Failed to get hash filed [%d] for tunnel [0x%x], rc = %d" % (hash_field, tunnel_id, rc))
    return rc, hash_data.hash_cmd


""" ############################################################################################ """


def init_parser():
    '''
    @summary: init parser
    '''
    usage = "usage: %prog [options] arg, script will run python test with traffic.\n"
    usage += "example: %prog --host_ip=10.212.152.5 --switch_ip=10.7.144.245"

    parser = OptionParser(usage=usage)

    parser.add_option('--tunnel', dest='tunnel_type', default="vxlan",
                      help="Insert the tunnel type. example --tunnel= vxlan  ------ default = vxlan")

    parser.add_option('--traffic', dest='traffic',
                      action="store_true", default=False, help="if the test run with traffic add this flag")
    parser.add_option('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    # use logger see examlpe in

    (options, args) = parser.parse_args()

    # if not options.tunnel_type:
    #   parser.error('tunnel_type not given, for more info run script with --help')
    #    sys.exit(1)

    return options


""" ############################################################################################ """


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


""" ############################################################################################ """


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        next_hop = make_ecmp_next_hop(nh[TUNN_ID], nh[DST_IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


""" ############################################################################################ """


def make_ecmp_next_hop(tunn_id, dst_ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
    This function creates ecmp_next_hop struct with given parametrs.
        action, counter_id and trap priority are optional.
    """

    address = make_sx_ip_addr_v4(dst_ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    nh_key.next_hop_key_entry.ip_tunnel.underlay_dip = address
    nh_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunn_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


""" ############################################################################################ """


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


""" ############################################################################################ """


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


""" ############################################################################################ """


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates ecmp uc_route_data struct with given parametrs.
        action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


""" ############################################################################################ """


def delete_next_hops_uc_route(vrid, addr, mask, ipv):
    " This function deletes all next hops from given vrid. "

    if ipv == 4:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted IPv" + str(ipv) + " uc next hops of VRID %d, rc: %d" % (vrid, rc))


""" ############################################################################################ """


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


""" ############################################################################################ """


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "

    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)

    if isinstance(mask, str):
        mask = _ipv6_str_to_bytes(mask)

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    prefix = sx_ip_v6_prefix_t()
    ip_prefix.prefix = prefix
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


""" ############################################################################################ """


def _ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))
    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]
    # Finally, convert back to bytes
    out = struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])
    return [ord(i) for i in out]


""" ############################################################################################ """


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


""" ############################################################################################ """

######################################################
#    main
######################################################


def main():
    router_init()

    # init tunnel
    example_tunnel_init_flow()

    vrid = create_vrid()
    ol_vrid = create_vrid()

    # workstation init
    options = init_parser()
    if options.traffic:
        add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})  # only for traffic
        port_rif = create_router_port_rif(vrid, PORT2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))  # only for traffic

    if options.tunnel_type == "vxlan":
        # vxlan tunnel create example
        tunnel_id = example_vxlan_tunnel_create_flow(vrid)
        mc_container_id = example_mc_container_flow(tunnel_id)
        tun_type = SX_TUNNEL_TYPE_NVE_VXLAN
    else:
        # ipinip tunnel create example
        tun_type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4
        loopback_rif = create_loopback_rif(ol_vrid, 1)  # only for traffic
        tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif, SX_TUNNEL_DIRECTION_SYMMETRIC)

        # create next hop list with tunnel
        next_hops_params_list = []
        next_hops_params_list.append({TUNN_ID: tunnel_id,
                                      DST_IP_STR: "1.1.1.10",
                                      WEIGHT_STR: 1})
        # create ecmp container
        ecmp_id = create_external_ecmp_container(next_hops_params_list)

        # create uc route
        create_ecmp_uc_route(ol_vrid, "10.10.0.0", "255.255.0.0", ecmp_id)

    # decap rules
    example_decap_rules_flow(vrid, tunnel_id, tun_type)
    # example_decap_rules_complex_flow(tunnel_id)

    if options.deinit:
        print("Clean")
        # destroy mc_conatiner for vxlan and
        # uc route and ecmp container for ipinip
        if options.tunnel_type == "vxlan":
            mc_container_destroy(mc_container_id)
        else:
            delete_next_hops_uc_route(ol_vrid, "10.10.0.0", "255.255.0.0", 4)
            destroy_ecmp_container(ecmp_id)

        # tunnel destroy
        example_tunnel_destroy_flow(tunnel_id)

        # deinit tunnel
        tunnel_deinit()

        if options.tunnel_type != "vxlan":
            delete_rif(ol_vrid, loopback_rif)

        delete_vrid(vrid)
        delete_vrid(ol_vrid)
        router_deinit()

    sx_api_close(handle)


if __name__ == "__main__":
    main()
