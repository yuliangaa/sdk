#!/usr/bin/env python

import os
import sys
import random
import errno
import sys
import struct
import socket
import colorsys
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_tunneling_ipinip_6in6 example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
parser.add_argument('--subnet', action='store_true', help='Use decap key type DIP_SIP_SUBNET instead of DIP_SIP')
args = parser.parse_args()

SPECTRUM_SWID = 0

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

###################################################################


def set_parsing_depth(depth=128):
    rc = sx_api_port_parsing_depth_set(handle, depth)
    return rc


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid

###################################################################


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))

###################################################################


def router_init(max_ipinip_ipv6_loopback_rifs=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0
    router_resource.max_ipinip_ipv6_loopback_rifs = max_ipinip_ipv6_loopback_rifs

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))

###################################################################


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

###################################################################


def make_tunnel_general_params(sport=0, nve_encap_flowlabel=0, flood_ecmp_enabled=False,
                               ipinip_encap_flowlabel=0, encap_gre_hash=0,
                               fdb_resolution_valid=False, fdb_resolution_action=SX_ROUTER_ACTION_FORWARD,
                               mc_ecmp_enabled=False):
    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = sport
    general_params.nve.encap_flowlabel = nve_encap_flowlabel
    general_params.nve.flood_ecmp_enabled = flood_ecmp_enabled
    general_params.nve.mc_ecmp_enabled = mc_ecmp_enabled
    general_params.nve.fdb_resolution_valid = fdb_resolution_valid
    if fdb_resolution_valid:
        general_params.nve.fdb_resolution_action = fdb_resolution_action

    general_params.ipinip.encap_flowlabel = ipinip_encap_flowlabel
    general_params.ipinip.encap_gre_hash = encap_gre_hash

    return general_params

###################################################################


def tunnel_init_flow():
    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    return tunnel_init(general_param_p)


###################################################################
def _ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))

    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]

    # Finally, convert back to bytes
    out = struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])
    return [i for i in out]

###################################################################


def make_sx_ip_addr_v6(addr):
    " This function creates ipv6 sx_ip_addr struct with given ip address. "
    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr

###################################################################


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    return rc

###################################################################


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

###################################################################


def tunnel_create(tunnel_attribute):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return rc, tunnel_id

###################################################################


def tunnel_destroy(tunnel_id_p):

    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    return rc

###################################################################


def set_rif_state_ipv6(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = False
    rif_state.ipv6_enable = enable
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))

###################################################################


def add_neigh_ipv6(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    return rc

###################################################################


def delete_neigh_ipv6(rif, addr, mac_addr):
    " This function deletes neighbor from rif with given address. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    return rc

###################################################################


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif

###################################################################


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "

    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)

    if isinstance(mask, str):
        mask = _ipv6_str_to_bytes(mask)

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    prefix = sx_ip_v6_prefix_t()
    ip_prefix.prefix.ipv6 = prefix
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix

###################################################################


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parameters.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data

###################################################################


def create_local_route_ipv6(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    return rc

###################################################################


def delete_local_route_ipv6(vrid, rif, addr, mask):
    " This function deletes local route. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, uc_route_data_p)
    return rc
###################################################################


def make_decap_key_ipv6(key_type, vrid, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6,
                        underlay_dip='2001::0370:7334', underlay_sip="9988::0370:4337"):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid

    decap_key.underlay_dip = make_sx_ip_addr_v6(underlay_dip)
    decap_key.underlay_sip = make_sx_ip_addr_v6(underlay_sip)

    return decap_key


def make_decap_key_ipv6_subnet(key_type, vrid, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6,
                               underlay_dip='2001:2001::', underlay_sip="9988:0370:4337::",
                               underlay_dip_mask="ffff:ffff::", underlay_sip_mask="ffff:ffff:ffff::", priority=2):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid

    decap_key.underlay_dip = make_sx_ip_addr_v6(underlay_dip)
    decap_key.underlay_sip = make_sx_ip_addr_v6(underlay_sip)
    decap_key.underlay_dip_mask = make_sx_ip_addr_v6(underlay_dip_mask)
    decap_key.underlay_sip_mask = make_sx_ip_addr_v6(underlay_sip_mask)
    decap_key.priority = priority

    return decap_key


""" ############################################################################################ """


def make_decap_data(tunnel_id, action, counter_id, span_session_id=0, trap_attr_prio=2):
    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = trap_attr_prio
    decap_data.span_session_id = span_session_id
    decap_data.tunnel_id = tunnel_id

    return decap_data


def tunnel_decap_rule_process(decap_key_p, decap_data_p, delete=0):

    if delete == 0:
        rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
        print(("sx_api_tunnel_decap_rules_set (create)  [rc = %d] " % (rc)))
    else:
        rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY, decap_key_p, decap_data_p)
        print(("sx_api_tunnel_decap_rules_set (destroy)  [rc = %d] " % (rc)))
    return rc

##################################################################


def decap_rules_flow(vrid, tunnel_id, delete=0):
    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    if args.subnet:
        decap_key = make_decap_key_ipv6_subnet(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET, vrid, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6)
    else:
        decap_key = make_decap_key_ipv6(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, tunnel_type=SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    rc = tunnel_decap_rule_process(decap_key_p, decap_data_p, delete)
    return rc


""" ############################################################################################ """


def ipinip_tunnel_create_flow(tunel_type, direction, overlay_rif):
    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = tunel_type
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p.underlay_rif = 0  # Supported devices: Spectrum2
    tunnel_attribute.attributes.ipinip_p2p.underlay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID

    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)


""" ############################################################################################ """


def create_loopback_rif(vrid, vlan, mtu=1500):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif


""" ############################################################################################ """


def delete_rif(rif, vrid):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    print("Deleted RIF: %d, rc: %d " % (rif, rc))
    return rc


""" ############################################################################################ """


def ipinip_tunnel_destroy_flow(tunnel_id):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute_p, tunnel_id_p)
    return rc


###################################################################
    main
###################################################################


def main():

    rc = set_parsing_depth(128)
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to set parsing depth, rc: %d" % rc

    router_init(max_ipinip_ipv6_loopback_rifs=5)
    print("Init tunnel")
    rc = tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to init tunnel, rc: %d" % rc

    print("Create overlay and underly vrid")
    ol_vrid = create_vrid()
    ul_vrid = create_vrid()

    print("Create IPv6 tunnel")
    tun_type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6
    loopback_rif = create_loopback_rif(ol_vrid, 1)
    rc, tunnel_id = ipinip_tunnel_create_flow(tun_type, SX_TUNNEL_DIRECTION_DECAP, loopback_rif)
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to create tunnel, rc: %d" % rc

    print("Create decap rule")
    rc = decap_rules_flow(ul_vrid, tunnel_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule, rc: %d" % (rc)

    print("Set loopback RIF state to IPv6")
    rc = set_rif_state_ipv6(loopback_rif)

    # ----------- add local route and neigh for IP_A --------------#
    print("Create Underlay RIF")
    vlan = 4
    port_rif_u = create_vlan_rif(ul_vrid, vlan, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    set_rif_state_ipv6(port_rif_u)

    print("Create Overlay RIF")
    vlan = 5
    port_rif_o = create_vlan_rif(ol_vrid, vlan, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))
    set_rif_state_ipv6(port_rif_o)

    print("Create route for decapsulated packet on RIF = %d" % port_rif_o)
    onet_ip = "fc00:0:fc00:0:0:0:0:0"
    onet_mask = "ffff:ffff:ffff:0:0:0:0:0"
    rc = create_local_route_ipv6(ol_vrid, port_rif_o, onet_ip, onet_mask)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route, rc: %d" % rc

    print("Add IPv6 neighbour to RIF %d" % port_rif_o)
    mac_addr = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6D, 0xA2)
    rc = add_neigh_ipv6(port_rif_o, onet_ip, mac_addr)
    assert SX_STATUS_SUCCESS == rc, \
        "Failed to add neigh to rif %d, rc = %d" % (rif, rc)

    print("Completed configuring 6in6 tunnel: tunnel_id %d" % tunnel_id)

    if args.deinit:
        # -------------------------- clean up --------------------------#
        print("Delete decap rule")
        delete = 1
        rc = decap_rules_flow(ul_vrid, tunnel_id, delete)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule, rc: %d" % (rc)

        print("Disable loopback RIF before deleting tunnel")
        set_rif_state_ipv6(loopback_rif, False)

        print("Delete tunnel")
        rc = ipinip_tunnel_destroy_flow(tunnel_id)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete tunnel, rc: %d" % rc

        print("Delete local route")
        rc = delete_local_route_ipv6(ol_vrid, port_rif_o, onet_ip, onet_mask)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete local route, rc: %d" % rc

        print("Delete IPv6 neighbour")
        rc = delete_neigh_ipv6(port_rif_o, onet_ip, mac_addr)
        assert SX_STATUS_SUCCESS == rc, \
            "Failed to delete neigh from rif %d, rc = %d" % (port_rif_o, rc)

        print("Delete Overlay VLAN RIF")
        rc = delete_rif(port_rif_o, ol_vrid)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete VLAN RIF %d, rc: %d" % (port_rif_o, rc)

        print("Delete Underlay VLAN RIF")
        rc = delete_rif(port_rif_u, ul_vrid)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete VLAN RIF %d, rc: %d" % (port_rif_u, rc)

        print("Delete Loopback VLAN RIF")
        rc = delete_rif(loopback_rif, ol_vrid)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete VLAN RIF %d, rc: %d" % (port_rif_u, rc)

        print("Delete Underlay VRID")
        delete_vrid(ul_vrid)

        print("Delete Overlay VRID")
        delete_vrid(ol_vrid)

        print("Deinit tunnel")
        tunnel_deinit()

        print("Deinit router")
        router_deinit()

    sx_api_close(handle)


if __name__ == "__main__":
    main()
