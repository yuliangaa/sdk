#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_id_channel_filter example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
channel_filter_dict_list = [
    {
        "filter_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 100,
                    "prio": 1
                }
            }
        }
    },

    {
        "filter_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_PORT,
            "key_value": {
                "port_id": 0x10001
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 100,
                    "prio": 1
                }
            }
        }
    },

    {
        "filter_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
            "key_value": {
                "vlan_id": 100
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 100,
                    "prio": 1
                }
            }
        }
    },

    {
        "filter_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
            "key_value": {
                "vlan_id": 100
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 99,
                    "prio": 1
                }
            }
        }
    }
]


def make_channel_filter_list(channel_filter_dict_list):
    return_list = []

    for entry in channel_filter_dict_list:
        channel_filter = sx_host_ifc_channel_filter_get_entry_t()
        for key in entry:
            if key == "filter_key":
                filter_key = entry[key]
                for sub_key in filter_key:
                    if sub_key == "key_type":
                        channel_filter.filter_key.key_type = filter_key[sub_key]
                    elif sub_key == "key_value":
                        key_value = filter_key[sub_key]
                        for sub_key2 in key_value:
                            if sub_key2 == "vlan_id":
                                channel_filter.filter_key.key_value.vlan_id = key_value[sub_key2]
                            elif sub_key2 == "port_id":
                                channel_filter.filter_key.key_value.port_id = key_value[sub_key2]

            elif key == "user_channel":
                user_channel = entry[key]
                for sub_key in user_channel:
                    if sub_key == "type":
                        channel_filter.user_channel.type = user_channel[sub_key]
                    elif sub_key == "channel":
                        channel = user_channel[sub_key]
                        for sub_key2 in channel:
                            if sub_key2 == "fd":
                                fd = channel[sub_key2]
                                fd_obj = sx_fd_t()
                                for sub_key3 in fd:
                                    if sub_key3 == "fd":
                                        fd_obj.fd = fd[sub_key3]
                                    elif sub_key3 == "driver_handle":
                                        fd_obj.driver_handle = fd[sub_key3]
                                    elif sub_key3 == "valid":
                                        fd_obj.valid = fd[sub_key3]

                                channel_filter.user_channel.channel.fd = fd_obj

                            elif sub_key2 == "l2_tunnel_params":
                                l2_tunnel_params = channel[sub_key2]
                                l2_tunnel_params_obj = ku_l2_tunnel_params()
                                for sub_key3 in l2_tunnel_params:
                                    if sub_key3 == "dmac":
                                        l2_tunnel_params_obj.dmac = l2_tunnel_params[sub_key3]
                                    elif sub_key3 == "vid":
                                        l2_tunnel_params_obj.vid = l2_tunnel_params[sub_key3]
                                    elif sub_key3 == "prio":
                                        l2_tunnel_params_obj.prio = l2_tunnel_params[sub_key3]

                                channel_filter.user_channel.channel.l2_tunnel_params = l2_tunnel_params_obj

        return_list.append(channel_filter)

    return return_list


def are_two_channel_filter_entries_equal(channel_filter1, channel_filter2):
    if channel_filter1.filter_key.key_type != channel_filter2.filter_key.key_type:
        return False

    if channel_filter1.filter_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT:
        if channel_filter1.filter_key.key_value.port_id != channel_filter2.filter_key.key_value.port_id:
            return False

    if channel_filter1.filter_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN:
        if channel_filter1.filter_key.key_value.vlan_id != channel_filter2.filter_key.key_value.vlan_id:
            return False

    if channel_filter1.user_channel.type != channel_filter2.user_channel.type:
        return False

    if channel_filter1.user_channel.type == SX_USER_CHANNEL_TYPE_FD:
        if channel_filter1.user_channel.channel.fd.fd != channel_filter2.user_channel.channel.fd.fd:
            return False

        if channel_filter1.user_channel.channel.fd.driver_handle != channel_filter2.user_channel.channel.fd.driver_handle:
            return False

        if channel_filter1.user_channel.channel.fd.valid and (not channel_filter2.user_channel.channel.fd.valid):
            return False

        if (not channel_filter1.user_channel.channel.fd.valid) and channel_filter2.user_channel.channel.fd.valid:
            return False

    if channel_filter1.user_channel.type == SX_USER_CHANNEL_TYPE_L2_TUNNEL:
        if channel_filter1.user_channel.channel.l2_tunnel_params.dmac != channel_filter2.user_channel.channel.l2_tunnel_params.dmac:
            return False

        if channel_filter1.user_channel.channel.l2_tunnel_params.vid != channel_filter2.user_channel.channel.l2_tunnel_params.vid:
            return False

        if channel_filter1.user_channel.channel.l2_tunnel_params.prio != channel_filter2.user_channel.channel.l2_tunnel_params.prio:
            return False

    return True


channel_filter_entries = make_channel_filter_list(channel_filter_dict_list)

for i in range(0, 4):

    rc = sx_api_host_ifc_trap_id_channel_filter_set(handle,
                                                    SX_ACCESS_CMD_ADD,
                                                    SX_SWID_ID_MIN,
                                                    SX_TRAP_ID_MIN,
                                                    channel_filter_entries[i].user_channel,
                                                    channel_filter_entries[i].filter_key)

    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_set failed [i=%d, rc = %d]" % (i, rc)


# get the total count
channel_filter_cnt_p = new_uint32_t_p()
channel_filter_list_p = new_sx_host_ifc_channel_filter_get_entry_t_arr(4)
uint32_t_p_assign(channel_filter_cnt_p, 0)
rc = sx_api_host_ifc_trap_id_channel_filter_get(handle,
                                                SX_ACCESS_CMD_GET,
                                                SX_SWID_ID_MIN,
                                                SX_TRAP_ID_MIN,
                                                None,
                                                None,
                                                channel_filter_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_get failed [rc = %d]" % (rc)
channel_filter_cnt = uint32_t_p_value(channel_filter_cnt_p)
assert channel_filter_cnt == 4, "the returned count is not correct"

# get the first two entries
uint32_t_p_assign(channel_filter_cnt_p, 2)
rc = sx_api_host_ifc_trap_id_channel_filter_get(handle,
                                                SX_ACCESS_CMD_GET_FIRST,
                                                SX_SWID_ID_MIN,
                                                SX_TRAP_ID_MIN,
                                                None,
                                                channel_filter_list_p,
                                                channel_filter_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_get failed [rc = %d]" % (rc)
channel_filter_cnt = uint32_t_p_value(channel_filter_cnt_p)
assert channel_filter_cnt == 2, "the returned count is not correct"

assert are_two_channel_filter_entries_equal(sx_host_ifc_channel_filter_get_entry_t_arr_getitem(channel_filter_list_p, 0), channel_filter_entries[0]), "the returned channel filter entries are incorrect"
assert are_two_channel_filter_entries_equal(sx_host_ifc_channel_filter_get_entry_t_arr_getitem(channel_filter_list_p, 1), channel_filter_entries[1]), "the returned channel filter entries are incorrect"

# get the next two entries after an entry
uint32_t_p_assign(channel_filter_cnt_p, 2)
rc = sx_api_host_ifc_trap_id_channel_filter_get(handle,
                                                SX_ACCESS_CMD_GETNEXT,
                                                SX_SWID_ID_MIN,
                                                SX_TRAP_ID_MIN,
                                                channel_filter_entries[1],
                                                channel_filter_list_p,
                                                channel_filter_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_get failed [rc = %d]" % (rc)
channel_filter_cnt = uint32_t_p_value(channel_filter_cnt_p)
assert channel_filter_cnt == 2, "the returned count is not correct"
# import pdb
# pdb.set_trace()
assert are_two_channel_filter_entries_equal(sx_host_ifc_channel_filter_get_entry_t_arr_getitem(channel_filter_list_p, 0), channel_filter_entries[3]), "the returned channel filter entries are incorrect"
assert are_two_channel_filter_entries_equal(sx_host_ifc_channel_filter_get_entry_t_arr_getitem(channel_filter_list_p, 1), channel_filter_entries[2]), "the returned channel filter entries are incorrect"

if args.deinit:
    # delete the entries
    for i in range(0, 4):
        rc = sx_api_host_ifc_trap_id_channel_filter_set(handle,
                                                        SX_ACCESS_CMD_DELETE,
                                                        SX_SWID_ID_MIN,
                                                        SX_TRAP_ID_MIN,
                                                        channel_filter_entries[i].user_channel,
                                                        channel_filter_entries[i].filter_key)
        assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_get failed [i=%d, rc = %d]" % (i, rc)

    uint32_t_p_assign(channel_filter_cnt_p, 0)
    rc = sx_api_host_ifc_trap_id_channel_filter_get(handle,
                                                    SX_ACCESS_CMD_GET,
                                                    SX_SWID_ID_MIN,
                                                    SX_TRAP_ID_MIN,
                                                    None,
                                                    None,
                                                    channel_filter_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_channel_filter_get failed [rc = %d]" % (rc)
    channel_filter_cnt = uint32_t_p_value(channel_filter_cnt_p)
    assert channel_filter_cnt == 0, "the returned count is not correct"

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
