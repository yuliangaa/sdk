#!/usr/bin/env python
'''
This file contains Python command example for the RM module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import errno
import sys
import struct
import socket
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

from optparse import OptionParser, Option
print_api_example_disclaimer()

rc, handle = sx_api_open(None)

######################################################
#    defines
######################################################
hw_resources_out = ["TCAM ", "Linear",
                    "KVD Hash", "KVD Linear",
                    "Router Adjacency", "Replication Matrix",
                    "ACL Group Table", "PGT", "Flow Counter", "ACL Regions",
                    "ACLs in Groups", "Generic", "Flex Parser Transition",
                    "Flex Parser Program", "Flex Modifier EMT", "SPAN Sessions", "GP Register"]

logical_resources_out = [
    "UC MAC Table ",
    "MC MAC Table ",
    "FIB IPV4 UC Table ",
    "FIB IPV6 UC Table ",
    "FIB IPV6 SHORT UC Table ",
    "FIB IPV6 LONG UC Table ",
    "FIB IPV4 MC Table ",
    "FIB IPV6 MC Table ",
    "ARP IPV4 Table ",
    "ARP IPV6 Table ",
    "L3 MC REPLICATIONS Table ",
    "Unicast Adjacency Table ",
    "L2 MC VECTORS Table ",
    "LAG VECTORS Table ",
    "FlOOD VECTORS Table ",
    "ACL Extended Actions Table ",
    "ACL PBS Table ",
    "eRIF List ",
    "Tunnel RTDP ",
    "ILM Table ",
    "RPF Group Table ",
    "VLAN Table ",
    "VPorts Table ",
    "FID Table ",
    "VNI Table ",
    "Tunnel IPv6 FDB Table ",
    "MPLS NHLFE Table ",
    "Policy Based MPLS ILM Table ",
    "NVE IPv6 List Table ",
    "ACL Regions ",
    "RIPS IPv6 register ",
    "IGMPv3 IPv4 Table ",
    "IGMPv3 IPv6 Table ",
    "Tunnel Decap IPv4 Table ",
    "Tunnel Decap IPv6 Table ",
    "ACL Rules 18B Key ",
    "ACL Rules 36B Key ",
    "ACL Rules 54B Key ",
    "RIF Counter Basic ",
    "RIF Counter Mixed ",
    "RIF Counter Enhanced ",
    "Flow Counter ",
    "ACL GROUPS Table ",
    "Flex Parser Transition ",
    "Flex Parser Program ",
    "Flex Modifier EMT ",
    "SPAN Session Table",
    "GP Register Table",
    "Internal Type ",
    "ACL RULES Table ",
    "Decap rules ",
    "IGMPv3 table ",
    "A TCAM One-key Block Table ",
    "A TCAM Two-keys Block Table ",
    "A TCAM Four-keys Block Table ",
    "A TCAM Six-keys Block Table ",
    "FCF FORWORDING Table ",
    "RMID Manager Table ",
    "NVE MC List ",
    "SMID Manager ",
    "FIB IPV4 MC System Table ",
    "FIB IPV6 MC System Table ",
    "RIF Counter ",
    "IGMPv3 Prune ",
    "ACLs in Groups ",
    "C TCAM Two-keys Block Table ",
    "C TCAM Four-keys Block Table ",
    "C TCAM Six-keys Block Table ",
]

EXAMPLE_RESOURCES = [RM_SDK_TABLE_TYPE_UC_MAC_E, RM_SDK_TABLE_TYPE_MC_MAC_E, RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E,
                     RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_SHORT_UC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_LONG_UC_E,
                     RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E,
                     RM_SDK_TABLE_TYPE_ARP_IPV4_E, RM_SDK_TABLE_TYPE_ARP_IPV6_E, RM_SDK_TABLE_TYPE_ADJACENCY_E,
                     RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E, RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E, RM_SDK_TABLE_TYPE_ACL_PBS_E,
                     RM_SDK_TABLE_TYPE_ERIF_LIST_E, RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, RM_SDK_TABLE_TYPE_VLAN_E,
                     RM_SDK_TABLE_TYPE_VPORTS_E, RM_SDK_TABLE_TYPE_FID_E, RM_SDK_TABLE_TYPE_VNI_E, RM_SDK_TABLE_TYPE_ACL_E,
                     RM_SDK_TABLE_TYPE_RIPS_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV4_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV6_E,
                     RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E, RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E, RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E,
                     RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E,
                     RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E, RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, RM_SDK_TABLE_TYPE_ACL_GROUPS_E,
                     RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E, RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E, RM_SDK_TABLE_TYPE_SPAN_E, RM_SDK_TABLE_TYPE_GP_REGISTER_E]

######################################################
#    Functions API
######################################################


parser = argparse.ArgumentParser(description='sx_api_resource_manager_api_example')
parser.add_argument('--force', default=False, action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def print_sdk_utilization(list_element, print_header=False, print_footer=False):
    if print_footer:
        print("====================================================================================================")
        return

    if print_header:
        print("====================================================================================================")
        header = ["Resource", "HW Table", "Logical Entries ", "HW Entries", "HW Utilization(%)"]
        print("|%28s|%17s|%16s|%15s|%18s|" % (header[0], header[1], header[2], header[3], header[4]))
        print("====================================================================================================")

    if list_element.hw_table_type > RM_HW_TABLE_TYPE_MAX_E:
        return
    if list_element.resource < len(logical_resources_out) and list_element.hw_table_type < len(hw_resources_out):
        print("|%28s|%17s|%16d|%15d|%18.1f|" % (logical_resources_out[list_element.resource], hw_resources_out[list_element.hw_table_type], list_element.sdk_table_entries_used,
                                                list_element.sdk_table_entries_allocated, list_element.hw_table_utilization_per_resource / 10.0))


def print_sdk_free_entries_count(resource, free_count, print_header=False, print_footer=False):
    if print_footer:
        print("==========================================================")
        return
    if print_header:
        print("==========================================================")
        header = ["Resource", "Free Entries"]
        print("|%40s|%15s|" % (header[0], header[1]))
        print("==========================================================")
    if resource < len(logical_resources_out):
        print("|%40s|%15s|" % (logical_resources_out[resource], free_count))


def get_hw_utilization(handle, resource=None):
    if resource is None:
        for resource in range(RM_HW_TABLE_TYPE_MIN_E, RM_HW_TABLE_TYPE_MAX_E + 1):
            utilization_p = new_uint32_t_p()
            rc = sx_api_rm_hw_utilization_get(handle,
                                              resource,
                                              utilization_p)
            if rc != SX_STATUS_SUCCESS:
                continue

            utilization = uint32_t_p_value(utilization_p)
            print("Total Utilization for HW resource %s is %.1f" % (hw_resources_out[resource], utilization / 10.0))
    else:
        utilization_p = new_uint32_t_p()
        rc = sx_api_rm_hw_utilization_get(handle,
                                          resource,
                                          utilization_p)
        if rc != SX_STATUS_SUCCESS:
            print("HW Utilization failed with rc = [%d]" % (rc))

        utilization = uint32_t_p_value(utilization_p)
        print("Total Utilization for HW resource %s is %.1f" % (hw_resources_out[resource], utilization / 10.0))


def get_logical_utilization(handle, resource_list_in=[]):
    resource_list = new_sx_api_table_type_t_arr(RM_SDK_TABLE_TYPE_MAX_E)
    utilization_list = new_sx_api_rm_table_utilization_t_arr(RM_SDK_TABLE_TYPE_MAX_E)
    list_count_p = new_uint32_t_p()

    chip_type = get_chip_type()

    if resource_list_in == []:
        for resource in range(RM_SDK_TABLE_TYPE_MIN_E, RM_SDK_TABLE_TYPE_INTERNAL_E):

            if chip_type == SX_CHIP_TYPE_SPECTRUM:
                if resource == RM_SDK_TABLE_TYPE_GP_REGISTER_E:
                    continue

            uint32_t_p_assign(list_count_p, 1)
            sx_api_table_type_t_arr_setitem(resource_list, 0, resource)

            rc = sx_api_rm_sdk_table_utilization_get(handle, resource_list, list_count_p, utilization_list)
            if rc != SX_STATUS_SUCCESS:
                continue
            data_cnt = uint32_t_p_value(list_count_p)
            ut = sx_api_rm_table_utilization_t_arr_getitem(utilization_list, 0)
            print_sdk_utilization(ut, resource == RM_SDK_TABLE_TYPE_MIN_E)
        print_sdk_utilization(None, False, True)
    else:
        uint32_t_p_assign(list_count_p, len(resource_list_in))
        for i, resource in enumerate(resource_list_in):
            sx_api_table_type_t_arr_setitem(resource_list, i, resource)

        rc = sx_api_rm_sdk_table_utilization_get(handle, resource_list, list_count_p, utilization_list)
        if rc != SX_STATUS_SUCCESS:
            print("Utilization get failed: [rc=%d]" % (rc))
            return
        data_cnt = uint32_t_p_value(list_count_p)
        for i in range(data_cnt):
            ut = sx_api_rm_table_utilization_t_arr_getitem(utilization_list, i)
            print_sdk_utilization(ut, i == 0)
        print_sdk_utilization(None, False, True)


def validate_resource_is_valid(resource):

    # This is a utility function to find out if a resource is valid. We get the resource utilization
    # and check if the hw resource is valid or not.
    resource_list = new_sx_api_table_type_t_arr(RM_SDK_TABLE_TYPE_MAX_E)
    utilization_list = new_sx_api_rm_table_utilization_t_arr(RM_SDK_TABLE_TYPE_MAX_E)
    list_count_p = new_uint32_t_p()

    uint32_t_p_assign(list_count_p, 1)
    sx_api_table_type_t_arr_setitem(resource_list, 0, resource)

    rc = sx_api_rm_sdk_table_utilization_get(handle, resource_list, list_count_p, utilization_list)
    if rc != SX_STATUS_SUCCESS:
        return False
    list_element = sx_api_rm_table_utilization_t_arr_getitem(utilization_list, 0)
    # It is assumed here that this is an invalid hw type
    if list_element.hw_table_type > RM_HW_TABLE_TYPE_MAX_E:
        return False
    return True


def get_logical_free_entries_count(handle, resource_list_in=[]):
    free_count_p = new_uint32_t_p()
    print_footer = False
    if resource_list_in == []:
        for resource in range(RM_SDK_TABLE_TYPE_MIN_E, RM_SDK_TABLE_TYPE_INTERNAL_E):
            if not validate_resource_is_valid(resource):
                continue
            rc = sx_api_rm_free_entries_by_type_get(handle, resource, free_count_p)
            if rc == SX_STATUS_SUCCESS:
                free_count = uint32_t_p_value(free_count_p)
                print_sdk_free_entries_count(resource, free_count, resource == RM_SDK_TABLE_TYPE_MIN_E)
                print_footer = True
        if print_footer:
            print_sdk_free_entries_count(None, False, 0, True)
    else:
        print_header = True
        for i, resource in enumerate(resource_list_in):
            if not validate_resource_is_valid(resource):
                continue
            rc = sx_api_rm_free_entries_by_type_get(handle, resource, free_count_p)
            if rc == SX_STATUS_SUCCESS:
                free_count = uint32_t_p_value(free_count_p)
                print_sdk_free_entries_count(resource, free_count, print_header)
                if print_header:
                    print_header = False
                    print_footer = True
        if print_footer:
            print_sdk_free_entries_count(None, False, 0, True)
    delete_uint32_t_p(free_count_p)


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"


def router_deinit():
    " This function deinit the router. "
    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"


def tunnel_init():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_params)
    rc = sx_api_tunnel_init_set(handle, general_param_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)


def get_chip_type():
    """
    :return: SX_CHIP_TYPE_SPECTRUM \ SX_CHIP_TYPE_SPECTRUM2 \ SX_CHIP_TYPE_SPECTRUM3
    """
    print("Retrieving Chip Type from SDK")
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 1)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)

    device_info = sx_device_info_t_arr_getitem(device_info_list_p, 0)
    chip_type = device_info.dev_type
    if chip_type == SX_CHIP_TYPE_SPECTRUM_A1:
        chip_type = SX_CHIP_TYPE_SPECTRUM

    return chip_type

######################################################
#    main
######################################################


def main():
    if not args.force:
        print_modification_warning()

    # init router
    router_init()

    # init tunnel
    tunnel_init()

    vlan_1 = 3000

    # save original igmpv3 state for later de-configuration
    igmpv3_state_p = new_sx_fdb_igmpv3_state_t_p()
    rc = sx_api_fdb_igmpv3_state_get(handle, SX_ACCESS_CMD_GET, vlan_1, igmpv3_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_get enable; rc=%d" % rc
    igmpv3_state = sx_fdb_igmpv3_state_t_p_value(igmpv3_state_p)

    # init igmpv3
    rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
    assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"

    # certain resources cannot be initialized because they are legacy resources that do not exist in SPC
    # so when trying to get free entry count of those resources error are generated therefore we query only for resources that exist in SPC
    get_logical_free_entries_count(handle, EXAMPLE_RESOURCES)

    if args.deinit:
        rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, igmpv3_state)
        assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable; rc=%d" % rc

        # deinit tunnel
        tunnel_deinit()

        # deinit router
        router_deinit()

    sx_api_close(handle)


if __name__ == "__main__":
    main()
