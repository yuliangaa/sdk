#!/usr/bin/env python
'''
This file contains Python command example to set port rate (speed) value using sx_api_port_rate_set API.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
Note that this example is supported only if switch was run using the same API and not sx_api_port_speed_admin_set.
'''
import sys
import errno
import sys
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

valid_rates = ["100M", "1G", "10G", "25G", "40G", "50G", "50Gx1", "50Gx2",
               "100G", "100Gx1", "100Gx2", "100Gx4", "200G", "200Gx2", "200Gx4",
               "400G", "400Gx4", "400Gx8", "800G", "800Gx8", "auto"]


def parse_example_attributes():
    help_str = """
    Port rate set example. Please use the following format to run_example:
    sx_api_port_rate_set.py --log_port=<PORTs> --rate=<RATE1,RATE2,...> [--force_rate] [--force]
    --log_port can be single port (e.g. 0x10001) or multiple ports separated by a comma (0x10001,0x10005)
    --rate can be single rate, or multiple rates to enable separated by a comma
    Valid speed values are:
    {}
    Note that some of the speeds may not be supported by switch. Please check port rate capabilities
    """.format(valid_rates)

    parser = argparse.ArgumentParser(description=help_str)

    def validate_rate_args(rates_str):
        rates_list = rates_str.split(",")
        [parser.error("Specified %s rate value is not valid, valid rates are:\n%r" % (rate, valid_rates)) for rate in rates_list if rate not in valid_rates]
        return rates_list

    parser.add_argument('--log_port', type=lambda s: s.split(","), help='logical port to change rate', default=['0x10001'])
    parser.add_argument('--rate', help='List of port rates to enable, separated by a comma', default=['10G'], type=validate_rate_args)
    parser.add_argument('--force_rate', action="store_true", help='Disable Auto-negotiation on phy. Only a single rate is allowed for this option')
    parser.add_argument('--force', action="store_true", help='Disable API Disclaimer and force running the example script')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    return args.log_port, args.rate, args.force_rate, args.force, args.deinit


def change_port_state(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    if rc != SX_STATUS_SUCCESS:
        print(("Error: failed to change port state, rc=%d." % (rc)))
        sys.exit(rc)


def enable_rate(rate, admin_rate):
    return (True if (rate in admin_rate) else False)


def run_example(handle, log_port, admin_rate, force, deinit):
    rate_bitmask_p = new_sx_port_rate_bitmask_t_p()

    # went throug the admin_rate list and enable appropriate values
    rate_bitmask_p.rate_100M = enable_rate("100M", admin_rate)
    rate_bitmask_p.rate_1G = enable_rate("1G", admin_rate)
    rate_bitmask_p.rate_10G = enable_rate("10G", admin_rate)
    rate_bitmask_p.rate_25G = enable_rate("25G", admin_rate)
    rate_bitmask_p.rate_40G = enable_rate("40G", admin_rate)
    rate_bitmask_p.rate_50G = enable_rate("50G", admin_rate)
    rate_bitmask_p.rate_50Gx1 = enable_rate("50Gx1", admin_rate)
    rate_bitmask_p.rate_50Gx2 = enable_rate("50Gx2", admin_rate)
    rate_bitmask_p.rate_100G = enable_rate("100G", admin_rate)
    rate_bitmask_p.rate_100Gx1 = enable_rate("100Gx1", admin_rate)
    rate_bitmask_p.rate_100Gx2 = enable_rate("100Gx2", admin_rate)
    rate_bitmask_p.rate_100Gx4 = enable_rate("100Gx4", admin_rate)
    rate_bitmask_p.rate_200G = enable_rate("200G", admin_rate)
    rate_bitmask_p.rate_200Gx2 = enable_rate("200Gx2", admin_rate)
    rate_bitmask_p.rate_200Gx4 = enable_rate("200Gx4", admin_rate)
    rate_bitmask_p.rate_400G = enable_rate("400G", admin_rate)
    rate_bitmask_p.rate_400Gx4 = enable_rate("400Gx4", admin_rate)
    rate_bitmask_p.rate_400Gx8 = enable_rate("400Gx8", admin_rate)
    rate_bitmask_p.rate_800G = enable_rate("800G", admin_rate)
    rate_bitmask_p.rate_800Gx8 = enable_rate("800Gx8", admin_rate)
    rate_bitmask_p.rate_auto = enable_rate("auto", admin_rate)
    rate_bitmask_p.force = force

    for port in log_port:
        # convert string of log_port to appropriate integer value
        log_port = int(port, 0)

        change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)

        # save original admin_rate for later de-configuration
        original_port_admin_rate_p = new_sx_port_rate_bitmask_t_p()
        original_port_capab_rate_p = new_sx_port_rate_bitmask_t_p()
        original_port_capab_type_p = new_sx_port_phy_module_type_bitmask_t_p()
        rc = sx_api_port_rate_capability_get(handle, log_port,
                                             original_port_admin_rate_p,
                                             original_port_capab_rate_p,
                                             original_port_capab_type_p)
        if rc != SX_STATUS_SUCCESS:
            if rc == SX_STATUS_CMD_UNSUPPORTED:
                print(("This API is not supported on this device (rc=%d)" % rc))
                change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
                sys.exit(0)
            print(("Error: failed to get %s port rate, rc=%d." % (port, rc)))
            sys.exit(rc)

        rc = sx_api_port_rate_set(handle, log_port, rate_bitmask_p)
        if rc != SX_STATUS_SUCCESS:
            if rc == SX_STATUS_CMD_UNSUPPORTED:
                print(("This API is not supported on this device (rc=%d)" % rc))
                change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
                sys.exit(0)
            print(("Error: failed to change %s port rate, rc=%d." % (port, rc)))
            if rc == SX_STATUS_CMD_UNPERMITTED:
                print("Looks like switch was configured with sx_api_port_speed_admin_set API, so using sx_api_port_rate_set is not allowed !\n")
            sys.exit(rc)

        change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)

        print(("Admin rate value for %s log_port was changed to %s" % (port, admin_rate)))

        if deinit:
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)
            rc = sx_api_port_rate_set(handle, log_port, original_port_admin_rate_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_rate_set failed, rc =%d" % rc))
                sys.exit(1)
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)

        delete_sx_port_rate_bitmask_t_p(original_port_admin_rate_p)
        delete_sx_port_rate_bitmask_t_p(original_port_capab_rate_p)
        delete_sx_port_phy_module_type_bitmask_t_p(original_port_capab_type_p)


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":
    log_port, admin_rate, force_rate, force, deinit = parse_example_attributes()
    print_api_example_disclaimer()
    if not force:
        print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Run the main sx_api_port_rate_set API example with retrieved above parameters
    run_example(handle, log_port, admin_rate, force_rate, deinit)

    sx_api_close(handle)

    print("Example execution is finished successfully.")
