#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_args():
    parser = argparse.ArgumentParser(description='MDIF CRC Error Enable/Disable example')
    parser.add_argument('--cmd', default=0, type=int, help="disable(0), enable(1).")
    parser.add_argument('--local_port', default=1, type=int, help="Local Port.")
    parser.add_argument('--first_lane_only', default=0, type=int, help="configure CRC error on first lane only")

    args = parser.parse_args()
    return args.cmd, args.local_port, args.first_lane_only


def help_cmd():
    print("")
    print("The following example allows to execute Enable/Disable request for the MMDIF EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--local_port <port>] ")
    print("")
    print("cmd: 0 - Disable operation, 1 - Enable operation. 0 by default.")
    print("local_port: local port to use. 1 by default.")
    print("")


def validate_input_parameters(cmd, local_port):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def set_mdif_reg(cmd, local_port, first_lane_only):

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_SET

    mdif = ku_mdif_reg()
    mdif.local_port, mdif.lp_msb = get_lsb_msb_of_local_port(local_port)
    mdif.crc_err_mode = cmd

    if first_lane_only == 1:
        mdif.crc_lanes_mode = 0   # configure first lane only
    else:
        mdif.crc_lanes_mode = 1  # configure all port lanes

    print("====================")
    print("[+] Set MDIF")
    print("[+] local port: ", mdif.local_port)
    print("[+] lp_msb: ", mdif.lp_msb)
    print("[+] crc_err_mode: ", mdif.crc_err_mode)
    print("[+] crc_lanes_mode: ", mdif.crc_lanes_mode)

    rc = sxd_access_reg_mdif(mdif, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MDIF register, rc: %d" % (rc)

    print("[+] rc: ", rc)


def validate_chip_support():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d \n" % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Check chip type
    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("MDIF EMAD is not supported for SPC-1")
        sx_api_close(handle)
        sys.exit(0)

    sx_api_close(handle)


def main():
    cmd, local_port, first_lane_only = parse_args()

    validate_chip_support()

    validate_input_parameters(cmd, local_port)

    sxd_init()

    set_mdif_reg(cmd, local_port, first_lane_only)
    print("[+] MDIF register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] MDIF register access example")
    main()
