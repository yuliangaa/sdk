#!/usr/bin/env python
from python_sdk_api.sx_api import *
import sys
import argparse
from python_sdk_api.sxd_api import *

"""
This example demonstrates get port->port isolation by sending PIFR EMAD.
EMAD's fields values are received as args or used default values.
"""

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] Reading PIFR register:")
parser = argparse.ArgumentParser(description='PIFR read utility')
parser.add_argument("--port", default=1, type=int, help="local egress port number")
parser.add_argument("--table", default=0, type=int, help="Isolation table id. 0-GLOBAL, 1-BRIDGE_ONLY")
args = parser.parse_args()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.access_cmd = SXD_ACCESS_CMD_GET

pifr = ku_pifr_reg()
pifr.local_port = args.port
pifr.table_id = args.table

rc = sxd_access_reg_pifr(pifr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read PIFR register, rc: %d" % (rc)

print("[+] Success read PIFR register: egress port #{}, {} isolation table".format(pifr.local_port, 'BRIDGE_ONLY' if pifr.table_id else 'GLOBAL'))
port_flag = 0
for index in range(0, PIFR_MAX_PORTS):
    port = uint8_t_arr_getitem(pifr.ports_bitmap, index)
    if port == 1:
        port_flag = 1
        print("[+] [" + str(index) + "]")

if port_flag == 0:
    print("[+] Port list is empty")

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
