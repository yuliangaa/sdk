#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='sxd_api_pmcr example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

admin_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 3: 'UP_ONCE'}
oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}


print("[+] PMCR register access test start")
print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init faled, rc: %d" % (rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

original_pmcr = ku_pmcr_reg()
original_pmcr.local_port, original_pmcr.lp_msb = common_lib.get_lsb_msb_of_local_port(1)

rc = sxd_access_reg_pmcr(original_pmcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PMCR register, rc: %d" % (rc)

pmcr = ku_pmcr_reg()

pmcr.local_port, pmcr.lp_msb = common_lib.get_lsb_msb_of_local_port(1)


print("[+] Get PMCR")
rc = sxd_access_reg_pmcr(pmcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PMCR register, rc: %d" % (rc)

print("[+] local port: ", pmcr.local_port)
print("[+] lp_msb: ", pmcr.lp_msb)

print("[+] Get PMCR content")
print("====================")
print("[+] Tx disable override control: ", pmcr.tx_disable_override_cntl)
print("[+] Tx disable override value: ", pmcr.tx_disable_override_value)
print("[+] CDR override control: ", pmcr.cdr_override_cntl)
print("[+] CDR override value: ", pmcr.cdr_override_value)
print("[+] Rx AMP control: ", pmcr.rx_amp_override_cntl)
print("[+] Rx AMP override value: ", pmcr.rx_amp_override_value)
print("[+] Rx EMP control: ", pmcr.rx_emp_override_cntl)
print("[+] Rx EMP override value: ", pmcr.rx_emp_override_value)
print("[+] Tx EQU control: ", pmcr.tx_equ_override_cntl)
print("[+] Tx EQU override value: ", pmcr.tx_equ_override_value)


paos = ku_paos_reg()
meta.access_cmd = SXD_ACCESS_CMD_GET

paos.local_port, paos.lp_msb = pmcr.local_port, pmcr.lp_msb

paos.admin_status = 0
paos.ase = 0
paos.e = 0
paos.ee = 0
paos.oper_status = 0
paos.swid = 0

print("[+] Get paos")
print("====================")
rc = sxd_access_reg_paos(paos, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to GET PAOS register, rc: %d" % (rc)

print(("[+] Port admin_status is %s" % admin_dict[paos.admin_status]))
print(("[+] Port oper_status is %s" % oper_dict[paos.oper_status]))

print("[+] Note that the PMCR register can be set only when the port is down by PAOS admin status.\n")

# Make sure that used port in DOWN state
print("[+] Set paos")
print("====================")
paos.ase = 1
save_admin_status = paos.admin_status
meta.access_cmd = SXD_ACCESS_CMD_SET
if paos.admin_status == 1 or paos.admin_status == 3:
    paos.admin_status = 2

rc = sxd_access_reg_paos(paos, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to SET PAOS register, rc: %d" % (rc)

print(("[+] Port admin_status is %s" % admin_dict[paos.admin_status]))
print(("[+] Port oper_status is %s\n" % oper_dict[paos.oper_status]))

meta.access_cmd = SXD_ACCESS_CMD_SET

pmcr.tx_disable_override_cntl = 0
pmcr.tx_disable_override_value = 0
pmcr.cdr_override_cntl = 2
pmcr.cdr_override_value = 3
pmcr.rx_amp_override_cntl = 0
pmcr.rx_amp_override_value = 0
pmcr.rx_emp_override_cntl = 1
pmcr.rx_emp_override_value = 0
pmcr.tx_equ_override_cntl = 2
pmcr.tx_equ_override_value = 0

print("[+] Set PMCR content")
print("====================")
print("[+] Tx disable override control: ", pmcr.tx_disable_override_cntl)
print("[+] Tx disable override value: ", pmcr.tx_disable_override_value)
print("[+] CDR override control: ", pmcr.cdr_override_cntl)
print("[+] CDR override value: ", pmcr.cdr_override_value)
print("[+] Rx AMP control: ", pmcr.rx_amp_override_cntl)
print("[+] Rx AMP override value: ", pmcr.rx_amp_override_value)
print("[+] Rx EMP control: ", pmcr.rx_emp_override_cntl)
print("[+] Rx EMP override value: ", pmcr.rx_emp_override_value)
print("[+] Tx EQU control: ", pmcr.tx_equ_override_cntl)
print("[+] Tx EQU override value: ", pmcr.tx_equ_override_value)

print("[+] Set PMCR")
rc = sxd_access_reg_pmcr(pmcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set PMCR register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET

print("[+] Get PMCR")
rc = sxd_access_reg_pmcr(pmcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to GET PMCR register, rc: %d" % (rc)

print("[+] Get after Set PMCR content")
print("==============================")
print("[+] Tx disable override control: ", pmcr.tx_disable_override_cntl)
print("[+] Tx disable override value: ", pmcr.tx_disable_override_value)
print("[+] CDR override control: ", pmcr.cdr_override_cntl)
print("[+] CDR override value: ", pmcr.cdr_override_value)
print("[+] Rx AMP control: ", pmcr.rx_amp_override_cntl)
print("[+] Rx AMP override value: ", pmcr.rx_amp_override_value)
print("[+] Rx EMP control: ", pmcr.rx_emp_override_cntl)
print("[+] Rx EMP override value: ", pmcr.rx_emp_override_value)
print("[+] Tx EQU control: ", pmcr.tx_equ_override_cntl)
print("[+] Tx EQU override value: ", pmcr.tx_equ_override_value)

if args.deinit:
    print("Deinit")
    meta.access_cmd = SXD_ACCESS_CMD_SET

    print("[+] Restore PMCR")
    rc = sxd_access_reg_pmcr(original_pmcr, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PMCR register, rc: %d" % (rc)

    print("[+] Restore paos")
    paos.admin_status = save_admin_status
    rc = sxd_access_reg_paos(paos, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)


rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] PMCR register access test end")
