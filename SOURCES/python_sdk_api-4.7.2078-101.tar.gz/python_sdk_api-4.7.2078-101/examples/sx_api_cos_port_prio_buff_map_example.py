#!/usr/bin/env python
'''
This file contains Python command example for sx_api_cos_port_prio_buff_map_set at the CoS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different CoS attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


parser = argparse.ArgumentParser(description='sx_api_cos_port_prio_buff_map_example')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Log port')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()
log_port = args.log_port

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


""" SAVE CURRENT PRIO-TO-BUFF MAP"""
print("--------------- COS PORT PRIO TO BUFF MAG GET ------------------------------")

original_prio_to_buff_get_p = new_sx_cos_port_prio_buff_t_p()

rc = sx_api_cos_port_prio_buff_map_get(handle, log_port, original_prio_to_buff_get_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_prio_buff_map_get [log_port=0x%x ] " % (log_port)))

""" ############################################################################################ """

""" COS PORT DEFAULT PRIO SET """
print("--------------- COS PORT PRIO TO BUFF MAP SET ------------------------------")

priority = 5

# PG 0-15
# Prio 0-14

prio_to_buff_p = new_sx_cos_port_prio_buff_t_p()
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 0, 0)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 1, 1)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 2, 2)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 3, 3)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 4, 4)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 5, 5)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 6, 6)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 7, 7)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 8, 0)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 9, 1)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 10, 2)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 11, 3)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 12, 4)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 13, 5)
sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, 14, 6)

rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, log_port, prio_to_buff_p)
if rc != SX_STATUS_SUCCESS:
    print(("ERROR at sx_api_cos_port_prio_buff_map_set [log_port=0x%x ] " % (log_port)))
    sys.exit(rc)
print(("sx_api_cos_port_prio_buff_map_set [log_port=0x%x ] " % (log_port)))


print("--------------- COS PORT PRIO TO BUFF MAG GET ------------------------------")

prio_to_buff_get_p = new_sx_cos_port_prio_buff_t_p()

""" COS PORT DEFAULT PRIO GET """

rc = sx_api_cos_port_prio_buff_map_get(handle, log_port, prio_to_buff_get_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_prio_buff_map_get [log_port=0x%x ] " % (log_port)))


element_count = 15
print(("element_count %d" % (element_count)))

for i in range(0, element_count):
    buff = sx_cos_port_buff_t_arr_getitem(prio_to_buff_get_p.prio_to_buff, i)
    print(("i=%d buff=%d " % (i, buff)))

""" ############################################################################################ """

if args.deinit:
    """ RETURN BACK TO OLD PRIO-TO-BUFF MAP"""

    rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, log_port, original_prio_to_buff_get_p)
    if rc != SX_STATUS_SUCCESS:
        print(("ERROR at sx_api_cos_port_prio_buff_map_set [log_port=0x%x ] " % (log_port)))
        sys.exit(rc)
    print(("sx_api_cos_port_prio_buff_map_set [log_port=0x%x ] " % (log_port)))

sx_api_close(handle)
