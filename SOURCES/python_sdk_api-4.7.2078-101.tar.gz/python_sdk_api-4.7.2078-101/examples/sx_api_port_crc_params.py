#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of port CRC attributes.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_crc_params')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

SPECTRUM_SWID = 0
PORT1 = 0x10001
PORT2 = 0x10003
PRIO = 6

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x, rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

log_port = PORT1
original_crc_params_p = new_sx_port_crc_params_t_p()
rc = sx_api_port_crc_params_get(handle, log_port, original_crc_params_p)
original_crc_params = sx_port_crc_params_t_p_value(original_crc_params_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_port_crc_params_get [log_port=0x%x, ingress=%d, egress=%d, rc=%d]" %
       (log_port, original_crc_params.bad_crc_ingress_mode, original_crc_params.crc_egress_recalc_mode, rc)))

print("Set CRC Params to allow bad CRCs and prevent CRC recalculation")
crc_params_p = new_sx_port_crc_params_t_p()
crc_params = sx_port_crc_params_t()
crc_params.bad_crc_ingress_mode = SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
crc_params.crc_egress_recalc_mode = SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT
sx_port_crc_params_t_p_assign(crc_params_p, crc_params)
rc = sx_api_port_crc_params_set(handle, log_port, crc_params_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_port_crc_params_set return %d" % (rc)))

print("Set CRC Params to Default with sx_api_port_crc_params_set")
crc_params = sx_port_crc_params_t()
crc_params.bad_crc_ingress_mode = SX_PORT_BAD_CRC_INGRESS_MODE_DROP
crc_params.crc_egress_recalc_mode = SX_PORT_CRC_EGRESS_RECALC_MODE_ALLOW
sx_port_crc_params_t_p_assign(crc_params_p, crc_params)
rc = sx_api_port_crc_params_set(handle, log_port, crc_params_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_port_crc_params_set return %d" % (rc)))

if args.deinit:
    print("Set CRC Params to original value")
    sx_port_crc_params_t_p_assign(crc_params_p, crc_params)
    rc = sx_api_port_crc_params_set(handle, log_port, original_crc_params_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_port_crc_params_set return %d" % (rc)))

sx_api_close(handle)
