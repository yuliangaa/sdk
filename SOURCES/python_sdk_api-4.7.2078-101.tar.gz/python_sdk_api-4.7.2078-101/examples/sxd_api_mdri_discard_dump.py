#!/usr/bin/env python
# -*- python -*-
'''
Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.

This software product is a proprietary product of Mellanox Technologies, Ltd.
(the "Company") and all right, title, and interest in and to the software product,
including all associated intellectual property rights, are and shall
remain exclusively with the Company.

This software product is governed by the End User License Agreement
provided with the software product.

This file contains Python command example to dump MDRI register that contains discard reasons.
'''


import sys
import errno
import os
import logging
import argparse
import python_sdk_api.sxd_api as sxd_api
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *


def print_reasons_array(arr_name, reason_arr, arr_size):
    for i in range(arr_size):
        val = uint32_t_arr_getitem(reason_arr, i)
        print("{:<20}[{}] = 0x{:08x}".format(arr_name, i, val))


def read_mdri_reasons():
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET
    mdri_reg = ku_mdri_reg()
    mdri_reg.read = 255

    rc = sxd_access_reg_mdri(mdri_reg, meta, 1, None, None)
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to read mdri register")
        sys.exit(errno.EACCES)

    global_reasons = new_uint32_t_arr(8)
    port_reasons = new_uint32_t_arr(8)
    buffer_reasons = new_uint32_t_arr(8)
    ethernet_reasons = new_uint32_t_arr(8)
    ip_reasons = new_uint32_t_arr(8)
    mpls_reasons = new_uint32_t_arr(8)
    tunnel_reasons = new_uint32_t_arr(8)
    host_reasons = new_uint32_t_arr(8)

    global_reasons = mdri_reg.global_reasons
    port_reasons = mdri_reg.port_reasons
    buffer_reasons = mdri_reg.buffer_reasons
    ethernet_reasons = mdri_reg.ethernet_reasons
    ip_reasons = mdri_reg.ip_reasons
    mpls_reasons = mdri_reg.mpls_reasons
    tunnel_reasons = mdri_reg.tunnel_reasons
    host_reasons = mdri_reg.host_reasons

    print_reasons_array("global_reasons", global_reasons, 8)
    print_reasons_array("port_reasons", port_reasons, 8)
    print_reasons_array("buffer_reasons", buffer_reasons, 8)
    print_reasons_array("ethernet_reasons", ethernet_reasons, 8)
    print_reasons_array("ip_reasons", ip_reasons, 8)
    print_reasons_array("mpls_reasons", mpls_reasons, 8)
    print_reasons_array("tunnel_reasons", tunnel_reasons, 8)
    print_reasons_array("host_reasons", host_reasons, 8)


def clear_mdri_reasons():
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET
    mdri_reg = ku_mdri_reg()
    mdri_reg.clear = 255

    rc = sxd_access_reg_mdri(mdri_reg, meta, 1, None, None)
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to read mdri register")
        sys.exit(errno.EACCES)

    print("MDRI discard bits cleared")


def parse_args():
    parser = argparse.ArgumentParser(description='Retrive discard reasons')
    parser.add_argument('--op', choices=['read', 'clear'], default='read', help='MDRI operation')
    args = parser.parse_args()
    return args


def main():
    rc = sxd_api.sxd_access_reg_init(0, None, 1)
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    args = parse_args()

    if args.op == 'read':
        read_mdri_reasons()
    else:
        clear_mdri_reasons()

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    main()
