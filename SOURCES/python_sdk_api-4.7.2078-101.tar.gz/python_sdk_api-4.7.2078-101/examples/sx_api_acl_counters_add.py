#!/usr/bin/env python
'''
This file contains Python command example for adding flow counters to each rule within a given list of ACL regions
It saves the added counters data into a file (can be skipped if a null path is set) so it would be able to remove the counters when requested.
'''
import os
import argparse
import pickle
from python_sdk_api.sx_api import *
from test_infra_common import *

######################################################
#    defines
######################################################


#######################################################################
# function definitions
#######################################################################

def get_region_key_type(handle, region_id):
    """
    @return Region key type
    """
    acl_key_type_p = new_sx_acl_key_type_t_p()
    acl_action_type_p = new_sx_acl_action_type_t_p()
    acl_size_p = new_sx_acl_size_t_p()
    try:
        rc = sx_api_acl_region_get(handle, region_id, acl_key_type_p, acl_action_type_p, acl_size_p)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("'Failed to get ACL region", region_id, rc)
        return sx_acl_key_type_t_p_value(acl_key_type_p)

    finally:
        delete_sx_acl_size_t_p(acl_size_p)
        delete_sx_acl_action_type_t_p(acl_action_type_p)
        delete_sx_acl_key_type_t_p(acl_key_type_p)


def get_region_rules_count(handle, region_id):
    """
    @return the number of rules within a region
    """
    rules_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt_p, 0)

    try:
        rc = sx_api_acl_flex_rules_get(handle, region_id, None, None, rules_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("Failed getting rules count using sx_api_acl_flex_rules_get", region_id, rc)
        rules_cnt = uint32_t_p_value(rules_cnt_p)
        return rules_cnt
    finally:
        delete_uint32_t_p(rules_cnt_p)


def rule_contains_counter_action(rule):
    """
    @return True if the given rule has a counter action
    """
    action_cnt = rule.action_count

    for j in range(action_cnt):
        action = sx_flex_acl_flex_action_t_arr_getitem(rule.action_list_p, j)
        if action.type == SX_FLEX_ACL_ACTION_COUNTER:
            return True

    return False


def create_counter(handle, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    """
    Create a flow counter
    @return counter ID
    """
    counter_p = new_sx_flow_counter_id_t_p()
    try:
        rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("Failed to create ACL flow counter", rc)

        counter_id = sx_flow_counter_id_t_p_value(counter_p)
        return counter_id
    finally:
        delete_sx_flow_counter_id_t_p(counter_p)


def destroy_counter(handle, counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy counter %d, rc = %d" % (counter_id, rc)


def set_rule_in_sdk(handle, region_id, offset, rule):
    """
    Call SDK API to set rule
    @raise an Exception for failure
    """

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(1)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)

    try:
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rule_arr,
                                       1)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("Failed to update rule", offset, region_id, rc)
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)
        delete_sx_flex_acl_flex_rule_t_arr(rule_arr)


def set_rule_counter_action(handle, region_id, offset, rule):
    """
    Given a specific rule, edit its action in order to add a count action
    @return the new counter ID allocated and attached to the rule
    @raise RuntimeError if setting of rule in SDK fails
    """
    updated_rule = sx_flex_acl_flex_rule_t()
    updated_rule.valid = 1
    sx_lib_flex_acl_rule_init(get_region_key_type(handle, region_id), rule.action_count + 1, updated_rule)

    # Copy key fields
    for j in range(rule.key_desc_count):
        sx_flex_acl_key_desc_t_arr_setitem(updated_rule.key_desc_list_p, j, sx_flex_acl_key_desc_t_arr_getitem(rule.key_desc_list_p, j))
    updated_rule.key_desc_count = rule.key_desc_count

    # Copy actions
    for j in range(rule.action_count):
        sx_flex_acl_flex_action_t_arr_setitem(updated_rule.action_list_p, j, sx_flex_acl_flex_action_t_arr_getitem(rule.action_list_p, j))
    updated_rule.action_count = rule.action_count

    # Add count action
    counter_id = create_counter(handle)
    cnt_action = sx_flex_acl_flex_action_t()
    cnt_action.type = SX_FLEX_ACL_ACTION_COUNTER
    cnt_action.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(updated_rule.action_list_p, rule.action_count, cnt_action)
    updated_rule.action_count = rule.action_count + 1

    set_rule_in_sdk(handle, region_id, offset, updated_rule)

    return counter_id


def remove_rule_counter_action(handle, region_id, offset, rule, counter_id):
    """
    Try to remove a counter action with specific counter ID
    @return True if counter ID found and removed
    @return False if counter ID not present in this rule
    @raise RuntimeError if setting of rule in SDK fails
    """
    updated_rule = sx_flex_acl_flex_rule_t()
    updated_rule.valid = 1
    sx_lib_flex_acl_rule_init(get_region_key_type(handle, region_id), rule.action_count, updated_rule)
    action_found = False
    action_idx = 0

    # Copy actions - Use it to look up for the counter ID that marks the action to remove
    for j in range(rule.action_count):
        action = sx_flex_acl_flex_action_t_arr_getitem(rule.action_list_p, j)
        if action.type == SX_FLEX_ACL_ACTION_COUNTER and action.fields.action_counter.counter_id == counter_id:
            # Found action to delete, skip it for the rule update
            action_found = True
            continue

        sx_flex_acl_flex_action_t_arr_setitem(updated_rule.action_list_p, action_idx, action)
        action_idx += 1

    if not action_found:
        return False

    updated_rule.action_count = rule.action_count - 1

    # Copy key fields
    for j in range(rule.key_desc_count):
        sx_flex_acl_key_desc_t_arr_setitem(updated_rule.key_desc_list_p, j, sx_flex_acl_key_desc_t_arr_getitem(rule.key_desc_list_p, j))
    updated_rule.key_desc_count = rule.key_desc_count

    set_rule_in_sdk(handle, region_id, offset, updated_rule)

    destroy_counter(handle, counter_id)

    return True


def get_rules_per_offsets(handle, region_id, offsets_list_p, rules_list_p, rules_cnt):
    """
    Work on offsets list and rules list so they would contain the rules in details
    With information of actions and keys
    Note that rules_list_p is changed

    @return actual rules count
    """
    rules_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt_p, rules_cnt)

    # Get Region rules with their details
    for j in range(rules_cnt):
        rule = sx_flex_acl_flex_rule_t()
        rule.key_desc_list_p = None
        rule.action_list_p = None
        sx_flex_acl_flex_rule_t_arr_setitem(rules_list_p, j, rule)

    try:
        # First, get number of actions and key decriptor per rules
        rc = sx_api_acl_flex_rules_get(handle, region_id, offsets_list_p, rules_list_p, rules_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("Failed getting rules using sx_api_acl_flex_rules_get", region_id, rc)

        for j in range(rules_cnt):
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, j)
            rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(rule.key_desc_count)
            rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(rule.action_count)
            sx_flex_acl_flex_rule_t_arr_setitem(rules_list_p, j, rule)

        # Now get action and key descriptor details
        rc = sx_api_acl_flex_rules_get(handle, region_id, offsets_list_p, rules_list_p, rules_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise RuntimeError("Failed getting rules details using sx_api_acl_flex_rules_get", region_id, rc)

        rules_cnt = uint32_t_p_value(rules_cnt_p)
        return rules_cnt

    finally:
        delete_uint32_t_p(rules_cnt_p)


def region_counters_detach(handle, region_id, counters_dict):
    """
    Input : dictionary of type (region_id, offset) -> counter ID
    Remove the action with the counter ID from the rule

    @return a count of rules detached, a list of offsets that did not detach
    """
    skipped_detach_list = []
    rules_detached = 0
    rules_cnt = len(counters_dict.keys())
    offsets_list_p = new_sx_acl_rule_offset_t_arr(rules_cnt)
    rules_list_p = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)

    # Prepare a list of offsets to get their rules
    for j, tup in enumerate(counters_dict.keys()):
        sx_acl_rule_offset_t_arr_setitem(offsets_list_p, j, tup[1])

    # Get current rules
    try:
        rules_cnt = get_rules_per_offsets(handle, region_id, offsets_list_p, rules_list_p, rules_cnt)

        for j in range(rules_cnt):
            offset = sx_acl_rule_offset_t_arr_getitem(offsets_list_p, j)
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, j)

            # Get Counter ID to remove
            try:
                counter_id = counters_dict[(region_id, offset)]
            except KeyError:
                skipped_detach_list.append(offset)
                continue

            # Add count action if force is set or if there is no counter action for the rule
            if remove_rule_counter_action(handle, region_id, offset, rule, counter_id):
                rules_detached += 1
            else:
                skipped_detach_list.append(offset)
    finally:
        # Cleanup
        for i in range(rules_cnt):
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, i)
            delete_sx_flex_acl_flex_action_t_arr(rule.action_list_p)
            delete_sx_flex_acl_key_desc_t_arr(rule.key_desc_list_p)
        delete_sx_flex_acl_flex_rule_t_arr(rules_list_p)
        delete_sx_acl_rule_offset_t_arr(offsets_list_p)

    return rules_detached, skipped_detach_list


def region_counters_attach(handle, region_id, force=False, offsets_list=[]):
    """
    Add counter action to each rule in the region
    If force is set to True then add a counter action even if there is already a counter
    If offsets_list is given then update only the offsets in the list

    @return a dictionary {(region_id, offset) : counter ID}
    """
    rules_dict = {}

    if offsets_list:
        # Working on a list of specific offsets
        rules_cnt = len(offsets_list)
        offsets_list_p = new_sx_acl_rule_offset_t_arr(rules_cnt)
        for j in range(rules_cnt):
            sx_acl_rule_offset_t_arr_setitem(offsets_list_p, j, offsets_list[j])
    else:
        # Work it out for all the region
        rules_cnt = get_region_rules_count(handle, region_id)
        offsets_list_p = new_sx_acl_rule_offset_t_arr(rules_cnt)

    rules_list_p = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)

    # Get All rules in details
    try:

        rules_cnt = get_rules_per_offsets(handle, region_id, offsets_list_p, rules_list_p, rules_cnt)

        # Go over all rules and add a count action if needed
        for j in range(rules_cnt):
            offset = sx_acl_rule_offset_t_arr_getitem(offsets_list_p, j)
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, j)

            # Add count action if force is set or if there is no counter action for the rule
            if force or not rule_contains_counter_action(rule):
                try:
                    counter_id = set_rule_counter_action(handle, region_id, offset, rule)
                    rules_dict[(region_id, offset)] = counter_id
                except BaseException:
                    region_counters_detach(handle, region_id, rules_dict)
                    raise
    finally:
        # Cleanup
        for i in range(rules_cnt):
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, i)
            delete_sx_flex_acl_flex_action_t_arr(rule.action_list_p)
            delete_sx_flex_acl_key_desc_t_arr(rule.key_desc_list_p)
        delete_sx_flex_acl_flex_rule_t_arr(rules_list_p)
        delete_sx_acl_rule_offset_t_arr(offsets_list_p)

    return rules_dict


def save_dictionary_to_file(d, fpath):
    with open(fpath, 'w') as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)


def load_dictionary_from_file(fpath):
    """
    @return dictionary from file
    """
    with open(fpath, 'rb') as f:
        return pickle.load(f)

######################################################
#    main
######################################################


def main():

    parser = argparse.ArgumentParser(description='Add/Remove Flow counters to a given ACL region')
    parser.add_argument('--force', action='store_true', help='Add counters to all records, regardless if a counter is already present. Also override prompt for SDK configuration change.')
    parser.add_argument('--detach', action='store_true', help='Remove counters applied by this script')
    parser.add_argument("--region", default=None, type=auto_int, help="Region ID")
    parser.add_argument("--offsets", default=[], type=auto_int, nargs='+', help="Limit to specific offsets within the region")
    parser.add_argument("--path", default="/tmp/dbg_counters.bin", type=str, help="Filename to be used to store counters list for detach action")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()

    if not args.detach and not args.region:
        print("Error: region ID must be specified when attaching counters.\nExiting")
        sys.exit(0)

    print_api_example_disclaimer()

    if not args.force:
        print_modification_warning()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        raise RuntimeError("Failed to open API handle.\nPlease check that SDK is running.")

    try:
        if not args.detach:
            d = region_counters_attach(handle, args.region, args.force, args.offsets)
            print(str(len(d)) + " counters attached.")
            if len(args.path) > 0:
                save_dictionary_to_file(d, args.path)

            if not args.deinit:
                return

        d = load_dictionary_from_file(args.path)
        cntrs, skipped = region_counters_detach(handle, d.keys()[0][0], d)
        print(str(cntrs) + " counters detached.")
        if len(skipped):
            print("The following offsets were not detached from counters:")
            skipped.sort()
            for j in skipped:
                print(j)
        os.remove(args.path)

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    main()
