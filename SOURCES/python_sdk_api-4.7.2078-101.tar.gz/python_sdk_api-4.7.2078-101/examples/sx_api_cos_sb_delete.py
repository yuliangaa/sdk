#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


parser = argparse.ArgumentParser(description='sx_api_cos_sb_delete')
parser.add_argument('--log_port', type=auto_int, help='Specify log port, else considered as ALL PORTS')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

port_buffer_type_dict = {0: "INGRESS_PORT",
                         1: "INGRESS_PORT_PRIORITY_GROUP",
                         2: "EGRESS_PORT",
                         3: "EGRESS_PORT_TRAFFIC_CLASS",
                         4: "MULTICAST"}

shared_pool_direction_dict = {0: "INGRESS",
                              1: "EGRESS"}

shared_pool_mode_dict = {0: "STATIC",
                         1: "DYNAMIC"}

port_shared_buffer_alpha_dict = {0: "SX_COS_PORT_BUFF_ALPHA_0",
                                 1: "SX_COS_PORT_BUFF_ALPHA_1_128",
                                 2: "SX_COS_PORT_BUFF_ALPHA_1_64",
                                 3: "SX_COS_PORT_BUFF_ALPHA_1_32",
                                 4: "SX_COS_PORT_BUFF_ALPHA_1_16",
                                 5: "SX_COS_PORT_BUFF_ALPHA_1_8",
                                 6: "SX_COS_PORT_BUFF_ALPHA_1_4",
                                 7: "SX_COS_PORT_BUFF_ALPHA_1_2",
                                 8: "SX_COS_PORT_BUFF_ALPHA_1",
                                 9: "SX_COS_PORT_BUFF_ALPHA_2",
                                 10: "SX_COS_PORT_BUFF_ALPHA_4",
                                 11: "SX_COS_PORT_BUFF_ALPHA_8",
                                 12: "SX_COS_PORT_BUFF_ALPHA_16",
                                 13: "SX_COS_PORT_BUFF_ALPHA_32",
                                 14: "SX_COS_PORT_BUFF_ALPHA_64",
                                 255: "SX_COS_PORT_BUFF_ALPHA_INFINITY"}


def cos_port_buff_get_all(log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)
    assert(port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_shared_buff_get_all(log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt


def delete_all_mc_sb():
    print("--  Delete all MC --")
    count = 1
    log_port = SX_MC_PORT_LOG_ID
    cmd = SX_ACCESS_CMD_DELETE_ALL
    port_buffer_attr_cnt = count
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)

    for i in range(0, port_buffer_attr_cnt):
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
        """ Set type and relevant parameters """
        attr_item_min.type = SX_COS_MULTICAST_ATTR_E
        if attr_item_min.type > SX_COS_MULTICAST_ATTR_E or attr_item_min.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item_min.type)))

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, attr_item_min, port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_shared_buffer_attr_cnt = count
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)

    for i in range(0, port_shared_buffer_attr_cnt):
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
        """ Set type and relevant parameters """
        attr_item.type = SX_COS_MULTICAST_ATTR_E
        if attr_item.type > SX_COS_MULTICAST_ATTR_E or attr_item.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item.type)))

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, attr_item, port_shared_buffer_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_shared_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    print("--  Delete all MC - DONE --")


def delete_all_port_buff_sb(log_port):
    print(("--  Delete all Port buff SB for log_port=0x%x--" % log_port))
    count = 1
    cmd = SX_ACCESS_CMD_DELETE_ALL
    port_buffer_attr_cnt = count
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)

    for i in range(0, port_buffer_attr_cnt):
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, None, port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_shared_buffer_attr_cnt = count
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)

    for i in range(0, port_shared_buffer_attr_cnt):
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, attr_item, port_shared_buffer_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_shared_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    print(("--  Delete all Port buff SB for log_port=0x%x - DONE--\n" % log_port))


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

# save for later de-configuration
original_mc_port_buff_attr_list, original_mc_port_buff_attr_cnt = cos_port_buff_get_all(SX_MC_PORT_LOG_ID)
original_mc_port_sb_attr_list, original_mc_port_sb_attr_cnt = cos_port_shared_buff_get_all(SX_MC_PORT_LOG_ID)

if args.log_port:
    log_port = args.log_port
    # Save for later de-configuration
    original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all(log_port)
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(log_port)
    print(("-- Deleting port buff SB for log_port=0x%x --\n" % log_port))
    delete_all_port_buff_sb(log_port)
else:
    print("-- Deleting port buff SB for all ports --\n")
    port_cnt_p = new_uint32_t_p()
    port_attributes_list = new_sx_port_attributes_t_arr(64)
    port_attributes = sx_port_attributes_t()
    uint32_t_p_assign(port_cnt_p, 64)
    rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
    port_cnt = uint32_t_p_value(port_cnt_p)
    # save current attributes for later de-configuration
    buff_saved_attr = []
    shared_buff_saved_attr = []
    print(("sx_api_port_device_get port_cnt:%d , rc %d, port_list : " % (port_cnt, rc)))
    print("====================================================================================================")
    for i in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if is_nve or is_cpu:
            continue
        log_port = port_attributes.log_port

        original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all(log_port)
        original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(log_port)

        buff_saved_attr.append((original_port_buff_attr_list, original_port_buff_attr_cnt))
        shared_buff_saved_attr.append((original_port_sb_attr_list, original_port_sb_attr_cnt))

        delete_all_port_buff_sb(log_port)

delete_all_mc_sb()

if args.deinit:
    print("Deinit")

    if args.log_port:
        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list, original_port_buff_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_buff_type_set failed rc = %d " % (rc))
            sys.exit(rc)

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list, original_port_sb_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_shared_buff_type_set failed rc = %d " % (rc))
            sys.exit(rc)
    else:
        for i in range(0, port_cnt):
            port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
            is_nve = check_nve(int(port_attributes.log_port))
            is_cpu = check_cpu(int(port_attributes.log_port))
            if is_nve or is_cpu:
                continue
            log_port = port_attributes.log_port

            original_port_buff_attr_list, original_port_buff_attr_cnt = buff_saved_attr[i][0], \
                buff_saved_attr[i][1]

            rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list,
                                               original_port_buff_attr_cnt)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_cos_port_buff_type_set failed rc = %d " % (rc))
                sys.exit(rc)

            original_port_sb_attr_list, original_port_sb_attr_cnt = shared_buff_saved_attr[i][0], \
                shared_buff_saved_attr[i][1]

            rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list,
                                                      original_port_sb_attr_cnt)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_cos_port_shared_buff_type_set failed rc = %d " % (rc))
                sys.exit(rc)

    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, SX_MC_PORT_LOG_ID, original_mc_port_buff_attr_list,
                                       original_mc_port_buff_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, SX_MC_PORT_LOG_ID, original_mc_port_sb_attr_list,
                                              original_mc_port_sb_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_set failed rc = %d " % (rc))
        sys.exit(rc)
