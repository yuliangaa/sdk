#!/usr/bin/env python
"""
This file contains Python example to insert timestamp in the packet.
1. use flex modifier to overwrite SMAC with timestamp
2. use sx_api_tele_attributes_set to write timestamp instead of FCS at the end of the packet
test packet: Ether(dst='00:02:03:04:05:01') / Dot1Q(vlan=5) / IP() / UDP(dport=3234) / Raw(load="abcef")

"""
import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse
import struct
import logging
import inspect
from logging import DEBUG, WARNING, INFO, ERROR
import common_infra_acl


######################################################
#    Defines
######################################################
TEST_SUCCESS = 1
TEST_FAILED = 0
DEF_LOG_LEVEL = INFO


def parse_args():
    parser = argparse.ArgumentParser(description='timestamp insert example')
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument('--ingress_port', default=0x10001, type=auto_int, help='Logical port ID for ingress')
    parser.add_argument('--egress_port', default=0x10005, type=auto_int, help='Logical port ID for egress')
    parser.add_argument('--packet_dmac', default="11:11:11:11:11:11", help='Destination MAC of the probe packet')
    parser.add_argument('--vlan', default=5, type=int, help='VLAN of the probe packet')
    parser.add_argument('--loglevel', '-l', choices=['error', 'warning', 'info', 'debug'], help="Log Level to run script at: Default {info}")

    return parser.parse_args()


def set_log_level(loglevel):
    if loglevel is None:
        loglevel = DEF_LOG_LEVEL
    else:
        loglevel = loglevel.upper()

    logging.basicConfig(level=loglevel, format='%(asctime)s - %(levelname)s - %(message)s')


def check_rc(rc, error_info):
    if rc != SX_STATUS_SUCCESS:
        logging.error(error_info)
        sys.exit(rc)


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    try:
        rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, 0, vlan_id, port_list, len(ports_dict))
        check_rc(rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id))
    finally:
        delete_sx_vlan_ports_t_arr(port_list)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, vlan_id, port_list, len(ports_dict))
    check_rc(rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id))


def flex_parser_reg_ext_point_set(handle, cmd, reg_id, ext_point_type_list, ext_point_offset_list, fexp_id=None):
    """
        Sets / Un-sets list of an extraction points for a given register key.
        Note that this API together with sx_api_register_set are mutually exclusive with
        sx_api_acl_custom_bytes_set, so per single SDK life cycle only one of them can be used.

        Args:
            handle (int):                                                           SDK handle
            cmd (enum sx_access_cmd_t):                                             SET / UNSET
            reg_id (sx_gp_register_e):                                              Register id
            ext_point_type_list (sx_extraction_point_type_e  list):                 Extraction point type list
            ext_point_offset_list (int list):                                       Extraction point offset list
            fexp_id (int):                                                          Flex parser extraction point id

        Raises:
            SdkException: In case of SDK error
        """
    ext_point_arr = new_sx_extraction_point_t_arr(len(ext_point_type_list))
    ext_point_cnt_p = copy_uint32_t_p(len(ext_point_type_list))
    try:
        gp_reg = sx_gp_register_key_t()
        gp_reg.reg_id = reg_id
        reg_key_attr = sx_register_key_attr_t()
        reg_key_attr.gp_reg = gp_reg
        reg_key = sx_register_key_t()
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
        reg_key.key = reg_key_attr

        for i, (ext_type, ext_offset) in enumerate(zip(ext_point_type_list, ext_point_offset_list)):
            ext_point = sx_extraction_point_t()
            ext_point.type = ext_type
            ext_point.offset = ext_offset
            if fexp_id:
                ext_point.attr.fexp_attr.fexp_id.fexp_id = fexp_id
            sx_extraction_point_t_arr_setitem(ext_point_arr, i, ext_point)

        logging.debug("Setting extraction points for register {}".format(reg_id))
        rc = sx_api_flex_parser_reg_ext_point_set(handle, cmd, reg_key, ext_point_arr, ext_point_cnt_p)
        check_rc(rc, 'Failed to set extraction points for register %d , rc:%d' % (reg_id, rc))

    finally:
        delete_sx_extraction_point_t_arr(ext_point_arr)
        delete_uint32_t_p(ext_point_cnt_p)


def _register_set(handle, cmd, reg_id_list):
    """
    Set registers. User can set an extraction point on the allocated register and use it as ACL key.

    Args:
        handle (int):                                   SDK handle
        cmd (enum sx_access_cmd_t):                     CREATE / DESTROY
        reg_key_list (sx_gp_register_e list):           List of registers

    Raises:
        Exception: In case of SDK error
    """

    reg_key_arr = new_sx_register_key_t_arr(len(reg_id_list))
    reg_key_cnt_p = copy_uint32_t_p(len(reg_id_list))
    try:
        for i, reg_id in enumerate(reg_id_list):
            gp_reg = sx_gp_register_key_t()
            gp_reg.reg_id = reg_id

            reg_key_attr = sx_register_key_attr_t()
            reg_key_attr.gp_reg = gp_reg

            reg_key = sx_register_key_t()
            reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
            reg_key.key = reg_key_attr

            sx_register_key_t_arr_setitem(reg_key_arr, i, reg_key)

        logging.debug("Setting registers {}".format(reg_id_list))

        rc = sx_api_register_set(handle, cmd, reg_key_arr, reg_key_cnt_p)
        check_rc(rc, 'Failed to set registers {}'.format(reg_id_list))
    finally:
        delete_sx_register_key_t_arr(reg_key_arr)
        delete_uint32_t_p(reg_key_cnt_p)


def flex_parser_init(handle):
    """
        Flex parse initialization

        Args:
           handle: SDK handle.

        Raises:
            SdkException: In case of SDK error
    """
    logging.debug('Flex parser init')
    fpp_param_t_p = new_sx_flex_parser_param_t_p()
    try:
        rc = sx_api_flex_parser_init_set(handle, fpp_param_t_p)
        check_rc(rc, 'sx_api_flex_parser_init_set failed')
    finally:
        delete_sx_flex_parser_param_t_p(fpp_param_t_p)


def flex_parser_deinit(handle):
    """
        Flex parse de-initialization

        Args:
           handle: SDK handle.

        Raises:
            SdkException: In case of SDK error
    """
    logging.debug('flex parser deinit')
    rc = sx_api_flex_parser_deinit_set(handle)
    check_rc(rc, 'sx_api_flex_parser_deinit_set failed')


def register_create(handle, reg_id_list):
    _register_set(handle, SX_ACCESS_CMD_CREATE, reg_id_list)


def register_destroy(handle, reg_id_list):
    _register_set(handle, SX_ACCESS_CMD_DESTROY, reg_id_list)


def __flex_modifier_emt(handle, cmd, emt_id_t, emt_cfg_t=None):
    """
        Set, create, destroy a EMT (Egress Modifier Template).

        Args:
           handle:                                          SDK handle.
           cmd:                                             SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_SET, SX_ACCESS_CMD_DESTROY
           emt_id_t (sx_flex_modifier_emt_key_t):           EMT id struct.
                contains:
                - EMT_id:                                   SX_FLEX_MODIFIER_EMT0_E - SX_FLEX_MODIFIER_EMT7_E
           emt_cfg_t (sx_flex_modifier_emt_cfg_t):          EMT config struct.
                contains:
                - emt_data_list[FLEX_MODIFIER_MAX_EMT_CFG] (sx_flex_modifier_emt_data_t)
                - emt_data_cnt (uint32_t)
                - emt_update_commands[SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E] (sx_flex_modifier_emt_update_field_e)
                - emt_update_cnt (uint32_t)

        Raises:
            Exception: In case of SDK error
    """
    emt_cfg_t_p = new_sx_flex_modifier_emt_cfg_t_p()

    try:
        if emt_cfg_t:
            sx_flex_modifier_emt_cfg_t_p_assign(emt_cfg_t_p, emt_cfg_t)
        rc = sx_api_flex_modifier_set(handle, cmd, emt_id_t, emt_cfg_t_p)
        check_rc(rc, 'sx_api_flex_modifier_set failed')
    finally:
        delete_sx_flex_modifier_emt_cfg_t_p(emt_cfg_t_p)


def flex_modifier_emt_create(handle, emt_id):
    """
        Create a regular Flex Modifier EMT (Egress Modifier Template).

        Args:
            handle:                     SDK handle.
            emt_id (int):               EMT id (SX_FLEX_MODIFIER_EMT0_E - SX_FLEX_MODIFIER_EMT7_E)
    """
    emt_id_t = sx_flex_modifier_emt_key_t()
    emt_id_t.emt_id = emt_id
    __flex_modifier_emt(handle, SX_ACCESS_CMD_CREATE, emt_id_t)


def flex_modifier_emt_destroy(handle, emt_id):
    """
        Destroy a regular Flex Modifier EMT (Egress Modifier Template).

        Args:
            handle:                     SDK handle.
            emt_id (int):               EMT id (SX_FLEX_MODIFIER_EMT0_E - SX_FLEX_MODIFIER_EMT7_E)
    """
    emt_id_t = sx_flex_modifier_emt_key_t()
    emt_id_t.emt_id = emt_id
    __flex_modifier_emt(handle, SX_ACCESS_CMD_DESTROY, emt_id_t)


def flex_modifier_emt_set(handle, emt_id, emt_data_commands, emt_update_commands):
    """
        Set a regular Flex Modifier EMT (Egress Modifier Template) for PUSH or EDIT options.

        Args:
            handle:                                 SDK handle.
            emt_id (int):                           EMT id (SX_FLEX_MODIFIER_EMT0_E - SX_FLEX_MODIFIER_EMT7_E).
            emt_data_commands (list of dicts):      List of dicts [{"cmd_id":val, "immediate_value":val, "skip":val}]
            emt_update_commands (list of enums):    List of EMT update actions.
    """
    try:
        emt_id_t = sx_flex_modifier_emt_key_t()
        emt_cfg_t = sx_flex_modifier_emt_cfg_t()
        emt_update_field_e_arr = new_sx_flex_modifier_emt_update_field_e_arr(len(emt_update_commands))
        emt_id_t.emt_id = emt_id

        for index, emt_data_command_dict in enumerate(emt_data_commands):
            data_struct_i = sx_flex_modifier_emt_data_t()
            for key in emt_data_command_dict:
                setattr(data_struct_i, key, emt_data_command_dict[key])
            sx_flex_modifier_emt_data_t_arr_setitem(emt_cfg_t.emt_data_list, index, data_struct_i)
        emt_cfg_t.emt_data_cnt = len(emt_data_commands)

        for index, emt_update_action in enumerate(emt_update_commands):
            sx_flex_modifier_emt_update_field_e_arr_setitem(emt_update_field_e_arr, index, emt_update_action)
        emt_cfg_t.emt_update_list = emt_update_field_e_arr
        emt_cfg_t.emt_update_cnt = len(emt_update_commands)

        __flex_modifier_emt(handle, SX_ACCESS_CMD_SET, emt_id_t, emt_cfg_t)
    finally:
        delete_sx_flex_modifier_emt_update_field_e_arr(emt_update_field_e_arr)


def add_delete_fdb_uc_mac_addr_list(handle, cmd, mac_list):
    mac_count = len(mac_list)
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(mac_count)
    data_cnt_p = copy_uint32_t_p(mac_count)

    try:
        for i, mac_entry in enumerate(mac_list):
            mac_entry_1 = sx_fdb_uc_mac_addr_params_t()
            mac_entry_1.mac_addr = mac_entry["mac_addr"] if not isinstance(mac_entry['mac_addr'], str) else ether_addr(
                mac_entry['mac_addr'])
            mac_entry_1.fid_vid = mac_entry["fid_vid"]
            mac_entry_1.log_port = mac_entry["port"]
            mac_entry_1.entry_type = mac_entry["entry_type"]
            mac_entry_1.action = mac_entry["action"]
            if "ecmp" in mac_entry:
                mac_entry_1.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_ECMP_NEXT_HOP_CONTAINER
                mac_entry_1.dest.ecmp = mac_entry["ecmp"]
            else:
                if "tunnel_id" in mac_entry:
                    mac_entry_1.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP
                    mac_entry_1.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
                    mac_entry_1.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = mac_entry[
                        "tunnel_id"]
                    mac_entry_1.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_utils.make_sx_ip_addr(
                        mac_entry["ip_addr"])
                    mac_entry_1.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD

            sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, i, mac_entry_1)

        rc = sx_api_fdb_uc_mac_addr_set(handle, cmd, 0, mac_list_p, data_cnt_p)
        check_rc(rc, "sx_api_fdb_uc_mac_addr_set failed")
    finally:
        delete_uint32_t_p(data_cnt_p)
        delete_sx_fdb_uc_mac_addr_params_t_arr(mac_list_p)


def create_delete_emt_rule(handle, args):
    # Create key handle
    acl_key_ids_arr = [FLEX_ACL_KEY_DMAC]
    key_handle_p = new_sx_acl_key_type_t_p()
    common_infra_acl.acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, acl_key_ids_arr)
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)

    # Create region
    region_id_p = new_sx_acl_region_id_t_p()
    common_infra_acl.acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 32, region_id_p)
    region_id = sx_acl_region_id_t_p_value(region_id_p)
    logging.debug(("Created ACL region with region_id %d" % region_id))

    # Create ACL
    direction = SX_ACL_DIRECTION_EGRESS
    acl_id_p = new_sx_acl_id_t_p()
    common_infra_acl.acl_handle(handle, SX_ACCESS_CMD_CREATE, direction, acl_id_p, region_id)
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    logging.debug(("Created ACL with ACL ID %d" % acl_id))

    # Create ACL group
    group_id_p = new_sx_acl_id_t_p()
    common_infra_acl.acl_group_handle(handle, SX_ACCESS_CMD_CREATE, direction, group_id_p, [acl_id])
    group_id = sx_acl_id_t_p_value(group_id_p)
    logging.debug(("Created ACL Group with ID %d" % group_id))

    # Bind group to egress port
    common_infra_acl.port_bind(handle, SX_ACCESS_CMD_BIND, args.egress_port, group_id)

    # Init rules array
    rules_list = new_sx_flex_acl_flex_rule_t_arr(1)
    rules = []
    common_infra_acl.acl_rules_init(rules, rules_list, 1, key_handle, 20)

    # Now create rule for EMT edit
    key_desc_list = []
    common_infra_acl.add_dmac_key(key_desc_list, args.packet_dmac, '00:00:00:00:00:00')

    action_list = []
    counter_list = []
    counter_id = common_infra_acl.create_counter(handle)
    counter_list.append(counter_id)
    common_infra_acl.add_counter_action(action_list, counter_id)

    common_infra_acl.add_set_emt_action(action_list, SX_FLEX_MODIFIER_EMT_BIND_INDEX_0_E, SX_FLEX_MODIFIER_BIND_TYPE_EDIT_E,
                                        args.edit_emt, SX_FLEX_MODIFIER_GP_REGISTER_0_OFFSET_E)

    common_infra_acl.acl_rule_set(handle, region_id, rules[0], 0, key_desc_list, action_list)

    # Deinit rules array
    common_infra_acl.acl_rules_deinit(rules)

    if args.deinit:
        common_infra_acl.acl_rule_delete(handle, region_id, 0)
        # Unbind port from group
        common_infra_acl.port_bind(handle, SX_ACCESS_CMD_UNBIND, args.egress_port, group_id)
        # Destory ACL group
        common_infra_acl.acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, direction, group_id_p, [acl_id])
        # Destroy ACL
        common_infra_acl.acl_handle(handle, SX_ACCESS_CMD_DESTROY, direction, acl_id_p, region_id)
        # Destroy region
        common_infra_acl.acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 32, region_id_p)
        # Destory key handle
        common_infra_acl.acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p, acl_key_ids_arr)
        for counter in counter_list:
            common_infra_acl.destroy_counter(handle, counter)


def flex_modifier_set(handle, args, deinit=False):
    edit_emt = args.edit_emt

    if deinit:
        flex_modifier_emt_destroy(handle, edit_emt)
        return

    flex_modifier_emt_create(handle, edit_emt)

    # each TIMESTAMP is 2 bytes, total 6 bytes is written at SMAC
    emt_data_commands = [
        {"cmd_id": SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_SEC_LSB_E, "immediate_value": 0, "skip": False},
        {"cmd_id": SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_MSB_E, "immediate_value": 0, "skip": False},
        {"cmd_id": SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_LSB_E, "immediate_value": 0, "skip": False}
    ]
    emt_update_commands = []
    flex_modifier_emt_set(handle, edit_emt, emt_data_commands, emt_update_commands)


def set_flex_extraction_points(handle, args, deinit=False):
    # Mark point for edit GP register 0 , overwrite smac with timestamp
    ext_point_type_list = [SX_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER_E]
    ext_point_offset_list = [6]
    if deinit:
        flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_UNSET, args.reg_key_list[0], ext_point_type_list, ext_point_offset_list)
        register_destroy(handle, args.reg_key_list)
        flex_parser_deinit(handle)
        return
    flex_parser_init(handle)

    register_create(handle, args.reg_key_list)

    flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_SET, args.reg_key_list[0], ext_point_type_list, ext_point_offset_list)


def tele_init(handle):
    tele_param_p = new_sx_tele_init_params_t_p()
    try:
        rc = sx_api_tele_init_set(handle, tele_param_p)
        check_rc(rc, "sx_api_tele_init_set failed")
    finally:
        delete_sx_tele_init_params_t_p(tele_param_p)


def tele_deinit(handle):
    rc = sx_api_tele_deinit_set(handle)
    check_rc(rc, "sx_api_tele_deinit_set failed")


def main():
    args = parse_args()
    set_log_level(args.loglevel)
    args.edit_emt = SX_FLEX_MODIFIER_EMT0_E
    args.reg_key_list = [SX_GP_REGISTER_0_E]

    logging.info("[+] opening sdk")
    rc, handle = sx_api_open(None)
    check_rc(rc, 'sx_api_open failed')

    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("This example doesn't support SPC1 Example - Exiting gracefully")
        rc = sx_api_close(handle)
        check_rc(rc, 'sx_api_close failed')
        sys.exit(0)

    add_ports_to_vlan(handle, args.vlan, {args.ingress_port: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, args.vlan, {args.egress_port: SX_TAGGED_MEMBER})

    mac_list = []
    fdb_dict = {"mac_addr": "00:02:03:04:05:01", "fid_vid": args.vlan,
                "port": args.egress_port, "action": SX_FDB_ACTION_FORWARD,
                "entry_type": SX_FDB_UC_STATIC}
    mac_list.append(fdb_dict)
    add_delete_fdb_uc_mac_addr_list(handle, SX_ACCESS_CMD_ADD, mac_list)

    set_flex_extraction_points(handle, args)
    flex_modifier_set(handle, args)

    # use EMT to modify SMAC as timestamp
    create_delete_emt_rule(handle, args)

    # use sx_api_tele_attributes_set to write timestamp instead of FCS at the end of the packet
    tele_init(handle)
    original_crc_params_p = new_sx_port_crc_params_t_p()
    rc = sx_api_port_crc_params_get(handle, args.egress_port, original_crc_params_p)
    check_rc(rc, 'sx_api_port_crc_params_get failed')

    original_attr_p = new_sx_tele_attrib_t_p()
    rc = sx_api_tele_attributes_get(handle, original_attr_p)
    check_rc(rc, 'sx_api_tele_attributes_get failed')

    print("Set CRC Params to allow bad CRCs and prevent CRC recalculation")
    crc_params_p = new_sx_port_crc_params_t_p()
    crc_params = sx_port_crc_params_t()
    crc_params.bad_crc_ingress_mode = SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
    crc_params.crc_egress_recalc_mode = SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT
    sx_port_crc_params_t_p_assign(crc_params_p, crc_params)
    rc = sx_api_port_crc_params_set(handle, args.egress_port, crc_params_p)
    check_rc(rc, 'sx_api_port_crc_params_set failed')

    print("Set Timestamp at FCS")
    attr = sx_tele_attrib_t()
    attr.internal_ts_enable = 1
    rc = sx_api_tele_attributes_set(handle, attr)
    check_rc(rc, 'sx_api_tele_attributes_set failed')

    if args.deinit:
        flex_modifier_set(handle, args, deinit=True)
        add_delete_fdb_uc_mac_addr_list(handle, SX_ACCESS_CMD_DELETE, mac_list)
        remove_ports_from_vlan(handle, args.vlan, {args.ingress_port: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(handle, args.vlan, {args.egress_port: SX_TAGGED_MEMBER})
        set_flex_extraction_points(handle, args, deinit=True)
        rc = sx_api_port_crc_params_set(handle, args.egress_port, original_crc_params_p)
        check_rc(rc, 'sx_api_port_crc_params_set failed')
        attr = sx_tele_attrib_t_p_value(original_attr_p)
        rc = sx_api_tele_attributes_set(handle, attr)
        check_rc(rc, 'sx_api_tele_attributes_set failed')
        tele_deinit(handle)

    rc = sx_api_close(handle)
    check_rc(rc, 'sx_api_close failed')


if __name__ == "__main__":
    sys.exit(main())
