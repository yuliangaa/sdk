#!/usr/bin/env python
'''
This example demonstrates forwarding of Link layer protocols
'''

import sys
import os
import time
from test_infra_common import *
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_trap_link_level_protocols_fwd example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

SWID = 0

rc, handle = sx_api_open(None)
assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc: %d" % (rc)

# Create trap group
TRAP_GROUP = 1
trap_grp_attr = sx_trap_group_attributes_t()
trap_grp_attr.control_type = SX_CONTROL_TYPE_DEFAULT
trap_grp_attr.prio = 1
trap_grp_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_grp_attr.truncate_size = 0
trap_grp_attr.trap_group = TRAP_GROUP
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SWID, TRAP_GROUP, trap_grp_attr)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_group_ext_set failed, rc: %d" % (rc)
TRAP_GROUP = sx_trap_group_attributes_t_p_value(trap_grp_attr).trap_group

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = TRAP_GROUP
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_IGNORE
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_DISCARD_ING_PACKET
sx_host_ifc_trap_key_1_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_1_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_1_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_LACP
sx_host_ifc_trap_key_2_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_2_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_2_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set LACP failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_STP
sx_host_ifc_trap_key_3_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_3_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_3_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set STP failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_EAPOL
sx_host_ifc_trap_key_4_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_4_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_4_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set EAPOL failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_LLDP
sx_host_ifc_trap_key_5_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_5_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_5_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set LLDP failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_MMRP
sx_host_ifc_trap_key_6_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_6_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_6_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set MMRP failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_MVRP
sx_host_ifc_trap_key_7_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_7_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_7_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set MVRP failed, rc: %d" % (rc)

sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_RPVST
sx_host_ifc_trap_key_8_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_8_p, sx_host_ifc_trap_key)
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_8_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

if args.deinit:
    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_8_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_7_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_6_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_5_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_4_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_3_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_2_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_1_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set RPVST failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SWID, TRAP_GROUP, trap_grp_attr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_group_ext_set failed, rc: %d" % (rc)

print("Success")

sx_api_close(handle)
