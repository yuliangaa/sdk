#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev

# list of the bits from 'outer_header_enables' bitmask
LAYER2_FIELDS_BIT = 1
IPV4_FIELDS_BIT = 4
TCP_UDP_FIELDS_BIT = 7

# list of the bits from 'outer_header_fields_enable' bitmask
SRC_MAC_BIT = 0
DST_MAC_BIT = 1
SRC_IP_BIT = 9
DST_IP_BIT = 13
PROTOCOL_BIT = 17
SRC_PORT_BIT = 74
DST_PORT_BIT = 75


def parse_args():
    parser = argparse.ArgumentParser(description='IHSR Set/Get example.')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--sh', default=0, type=int, help="Symmetric hash.")
    parser.add_argument('--type', default=0, type=int, help="Hash type: 0-CRC, 1-XOR.")

    # outer header field enables
    parser.add_argument('--src_mac', default=0, type=int, help="Include Source MAC address to the hash caclulation.")
    parser.add_argument('--dst_mac', default=0, type=int, help="Include Destination MAC address to the hash caclulation.")
    parser.add_argument('--src_ip', default=0, type=int, help="Include Source IP address to the hash caclulation.")
    parser.add_argument('--dst_ip', default=0, type=int, help="Include Destination IP address to the hash caclulation.")
    parser.add_argument('--protocol', default=0, type=int, help="Include protocol type to the hash caclulation.")
    parser.add_argument('--src_port', default=0, type=int, help="Include Source Port to the hash caclulation.")
    parser.add_argument('--dst_port', default=0, type=int, help="Include Destination Port to the hash caclulation.")
    parser.add_argument('--deinit', default=False, action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    outer_header_enables = 0
    outer_header_fields_enable = 0
    if args.src_mac or args.dst_mac:
        if args.src_mac:
            outer_header_fields_enable += (1 << SRC_MAC_BIT)
        if args.dst_mac:
            outer_header_fields_enable += (1 << DST_MAC_BIT)

        outer_header_enables += (1 << LAYER2_FIELDS_BIT)

    if args.src_ip or args.dst_ip or args.protocol:
        if args.src_ip:
            outer_header_fields_enable += (0xF << SRC_IP_BIT)
        if args.dst_ip:
            outer_header_fields_enable += (0xF << DST_IP_BIT)
        if args.protocol:
            outer_header_fields_enable += (1 << PROTOCOL_BIT)

        outer_header_enables += (1 << IPV4_FIELDS_BIT)

    if args.src_port or args.dst_port:
        if args.src_port:
            outer_header_fields_enable += (1 << SRC_PORT_BIT)
        if args.dst_port:
            outer_header_fields_enable += (1 << DST_PORT_BIT)

        outer_header_enables += (1 << TCP_UDP_FIELDS_BIT)

    return args.cmd, args.sh, args.type, outer_header_enables, outer_header_fields_enable, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute example of Set/Get request for the IHSR EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--sh <sh>] [--type <type>] [--src_mac <src_mac>] [--dst_mac <dst_mac>] [--src_ip <src_ip>] [--dst_ip <dst_ip>] [--protocol <protocol>] [--src_port <src_port>] [--dst_port <dst_port>] [--deinit]")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. Get by default.")
    print("sh: Symmetric hash. 0 by default.")
    print("type: Hash type: 0-CRC, 1-XOR. 0 by default.")
    print("src_mac: Include Source MAC address to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("dst_mac: Include Destination MAC address to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("src_ip: Include Source IP address to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("dst_ip: Include Destination IP address to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("protocol: Include protocol type to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("src_port: Include Source Port to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("dst_port: Include Destination Port to the hash caclulation. 0 - exclude, 1 - include. 0 by default.")
    print("deinit: Cleanup all configuration done by the example. False by default.")
    print("")


def example_help_output():
    if [cmd for cmd in ["-h", "--help"] if cmd in sys.argv]:
        help_cmd()
        sys.exit(0)


def validate_input_parameters(cmd, sh, hash_type, oheader_enables, oheader_field_enables):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)

    if hash_type > 1:
        print("Invalid input parameter: hash_type.")
        help_cmd()
        sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, sh, hash_type, oheader_enables, oheader_field_enables, general_fields=0, iheader_enables=0, iheader_field_enables=0, deinit=True):
    reg_data = ku_ihsr_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    reg_data.sh = sh
    reg_data.type = hash_type

    reg_data.outer_header_enables = oheader_enables
    for i in range(SXD_IHSR_OUTER_HEADER_FIELDS_ENABLE_NUM):
        enables_bitmap = ((oheader_field_enables >> (32 * i))) & 0xFF
        uint32_t_arr_setitem(reg_data.outer_header_fields_enable, i, enables_bitmap)

    reg_data.general_fields = general_fields
    reg_data.inner_header_enables = iheader_enables
    reg_data.inner_header_fields_enable = iheader_field_enables

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get IHSR")
    else:
        print("[+] Set IHSR")
        print("[+] sh: ", reg_data.sh)
        print("[+] type: ", reg_data.type)
        print("[+] outer_header_enables: ", oheader_enables)
        print("[+] outer_header_fields_enable: ", oheader_field_enables)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        # Save data for later de-configuration
        original_reg_data = ku_ihsr_reg()
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_ihsr(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_ihsr failed")
            sys.exit(rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_ihsr(reg_data, meta, 1, None, None)
    print("[+] rc: ", rc)
    print("====================")
    if rc == SXD_STATUS_SUCCESS and meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] sh: ", reg_data.sh)
        print("[+] type: ", reg_data.type)
        print("[+] general_fields: ", reg_data.general_fields)
        print("[+] outer_header_enables: ", reg_data.outer_header_enables)

        oheader_field_enables = 0
        for i in range(SXD_IHSR_OUTER_HEADER_FIELDS_ENABLE_NUM):
            enables_bitmap = uint32_t_arr_getitem(reg_data.outer_header_fields_enable, i)
            oheader_field_enables += (enables_bitmap << (32 * i))
        print("[+] outer_header_fields_enable: ", oheader_field_enables)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        rc = sxd_access_reg_ihsr(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_ihsr failed")
            sys.exit(rc)


def main():
    example_help_output()

    cmd, sh, hash_type, oheader_enables, oheader_field_enables, deinit = parse_args()

    validate_input_parameters(cmd, sh, hash_type, oheader_enables, oheader_field_enables)

    sxd_init()

    chip_type, _ = get_chip_type_and_rev()
    if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM4 or chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        run_example(cmd, sh, hash_type, oheader_enables, oheader_field_enables, deinit=deinit)
    else:
        print("[+] IHSR is not supported! No need to run this example.")

    print("[+] IHSR register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] IHSR register access example")
    main()
