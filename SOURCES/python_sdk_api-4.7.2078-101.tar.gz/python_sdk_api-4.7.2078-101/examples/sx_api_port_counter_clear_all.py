#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_counter_clear_all')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

log_port = 0x1001f

rc = sx_api_port_counter_clear_set(handle, log_port, True, SX_PORT_CNTR_GRP_ALL)
if (rc != SX_STATUS_SUCCESS):
    print("sx_api_port_counter_clear_set failed")
    sys.exit(rc)
print(("sx_api_port_counter_clear_set rc %d " % (rc)))

sx_api_close(handle)
