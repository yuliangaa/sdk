#!/usr/bin/env python
# -*- python -*-

#######################################################################
# global params
#######################################################################
PORT_TYPE_NVE = 8
PORT_TYPE_CPU = 4
PORT_TYPE_VPORT = 2
PORT_TYPE_OFFSET = 28
PORT_TYPE_MASK = 0xF0000000
PORT_OPER_STATUS = 0
PORT_ADMIN_STATUS = 1
MAX_COUNT_SLEEPS = 100
SPECTRUM_SWID = 0
INVALID_SLOT_ID = 99
NVE_PORT = 0x80010000
#######################################################################
# functions
#######################################################################

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import python_sdk_api.sx_api as sx_api
import python_sdk_api.sxd_api as sxd_api
import sys
import os
import socket
import struct
import time
import subprocess
import ctypes

sx_status_dict = {
    SX_STATUS_SUCCESS: "Success",
    SX_STATUS_ERROR: "Internal Error",
    SX_STATUS_SDK_NOT_INITIALIZED: "SwitchX SDK wasn't Initialized",
    SX_STATUS_INVALID_HANDLE: "Invalid Handle",
    SX_STATUS_COMM_ERROR: "Communication Error",
    SX_STATUS_NO_RESOURCES: "No More Resources",
    SX_STATUS_NO_MEMORY: "No More Memory",
    SX_STATUS_MEMORY_ERROR: "Memory Error",
    SX_STATUS_CMD_ERROR: "Command Error",
    SX_STATUS_CMD_INCOMPLETE: "Command Not Completed",
    SX_STATUS_CMD_UNSUPPORTED: "Command Unsupported",
    SX_STATUS_CMD_UNPERMITTED: "Command Unpermitted",
    SX_STATUS_PARAM_NULL: "Parameter NULL",
    SX_STATUS_PARAM_ERROR: "Parameter Error",
    SX_STATUS_PARAM_EXCEEDS_RANGE: "Parameter Exceeds Range",
    SX_STATUS_MESSAGE_SIZE_ZERO: "Message Size Exceeds Limit",
    SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT: "Message Size Exceeds Limit",
    SX_STATUS_DB_ALREADY_INITIALIZED: "Database Already Initialized",
    SX_STATUS_DB_NOT_INITIALIZED: "Database Wasn't Initialized",
    SX_STATUS_DB_NOT_EMPTY: "Database Not Empty",
    SX_STATUS_END_OF_DB: "End of Database",
    SX_STATUS_ENTRY_NOT_FOUND: "Entry Not Found",
    SX_STATUS_ENTRY_ALREADY_EXISTS: "Entry Already Exists",
    SX_STATUS_ENTRY_NOT_BOUND: "Entry Not Bound",
    SX_STATUS_ENTRY_ALREADY_BOUND: "Entry Already bound",
    SX_STATUS_WRONG_POLICER_TYPE: "Wrong Policer Type",
    SX_STATUS_UNEXPECTED_EVENT_TYPE: "Unexpected event type",
    SX_STATUS_TRAP_ID_NOT_CONFIGURED: "Trap ID not configured",
    SX_STATUS_INT_COMM_CLOSE: "Internal Communication close",
    SX_STATUS_RESOURCE_IN_USE: "Resource is in use",
    SX_STATUS_EVENT_TRAP_ALREADY_ASSOCIATED: "Trap ID is already associated to another trap priority",
    SX_STATUS_ALREADY_INITIALIZED: "Already initialized",
    SX_STATUS_TIMEOUT: "TIMEOUT",
    SX_STATUS_MODULE_UNINITIALIZED: "Module is uninitialized",
    SX_STATUS_UNSUPPORTED: "Operation Unsupported",
    SX_STATUS_SX_UTILS_RETURNED_NON_ZERO: "Utils return status is Non-Zero",
    SX_STATUS_PARTIALLY_COMPLETE: "Partially complete",
    SX_STATUS_ACCEPTED: "Accepted",
    SX_STATUS_ISSU_IN_PROGRESS: "ISSU in progress",
    SX_STATUS_FW_INIT_FAILURE: "Secure FW boot failure, recovery action required",
    SX_STATUS_DEVICE_UNRECOVERABLE: "Kindly contact Nvidia support to discuss further options",
    SX_STATUS_SXD_RETURNED_NON_ZERO: "Driver's Return Status is Non-Zero"
}

vxlan_type_dict = {
    8: 'NVE VXLAN',
    12: 'NVE VXLAN IPv6'}


map_dir_dict = {0: 'BIDIR',
                1: 'DECAP'}


direction_dict = {0: 'NONE',
                  1: 'ENCAP',
                  2: 'DECAP',
                  3: 'SYMMETRIC'
                  }

underlay_domain_type_dict = {0: 'VRID',
                             1: 'RIF'}

tag_mode_dict = {
    0: '802_1Q',
    1: 'QINQ',
    2: '802_1AD'
}

ttl_cmd_dict = {1: 'SET',
                2: 'COPY',
                3: 'PRESERVE',
                4: 'MINIMUM'}

hash_cmd_dict = {1: 'ZERO',
                 2: 'CALCULATE'}

dscp_rewrite_action_dict = {0: 'PRESERVE',
                            2: 'DISABLE',
                            3: 'ENABLE'}

tunnel_cost_dscp_action_dict = {0: 'PRESERVE',
                                1: 'COPY',
                                2: 'SET'}

dscp_action_dict = {0: 'PRESERVE',
                    1: 'COPY',
                    2: 'SET'}

ecn_map_dict = {0: 'Non ECT(00)',
                1: 'ECT1(01)',
                2: 'ECT0(10)',
                3: 'CE(11)'}
tunnel_type_str_dict = \
    {
        SX_TUNNEL_TYPE_NVE_VXLAN: "NVE_VXLAN",
        SX_TUNNEL_TYPE_NVE_VXLAN_GPE: "NVE_VXLAN_GPE",
        SX_TUNNEL_TYPE_NVE_GENEVE: "NVE_GENEVE",
        SX_TUNNEL_TYPE_NVE_NVGRE: "NVE_NVGRE",
        SX_TUNNEL_TYPE_NVE_VXLAN_IPV6: "NVE_VXLAN_IPV6",
        SX_TUNNEL_TYPE_NVE_NVGRE_IPV6: "NVE_NVGRE_IPV6",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4: "IPV4_IN_IPV4",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE: "IPV4_IN_GRE",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4: "IPV6_IN_IPV4",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE: "IPV6_IN_IPV4_GRE",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6: "IPV4_IN_IPV6",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE: "IPV4_IN_IPV6_GRE",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6: "IPV6_IN_IPV6",
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE: "IPV6_IN_GRE",
    }

trap_attr_prio_str_dict = \
    {
        SX_TRAP_PRIORITY_BEST_EFFORT: "Best Effort",
        SX_TRAP_PRIORITY_LOW: "Low",
        SX_TRAP_PRIORITY_MED: "Med",
        SX_TRAP_PRIORITY_HIGH: "High",
        SX_TRAP_PRIORITY_CRITICAL: "Critical"
    }

router_action_str_dict =\
    {
        SX_ROUTER_ACTION_DROP: "Drop",
        SX_ROUTER_ACTION_TRAP: "Trap",
        SX_ROUTER_ACTION_FORWARD: "Forward",
        SX_ROUTER_ACTION_MIRROR: "Mirror (deprecated)",
        SX_ROUTER_ACTION_TRAP_FORWARD: "Trap and Forward",
        SX_ROUTER_ACTION_SPAN: "Span",
    }

tnl_decap_rule_key_type_str_dict =\
    {
        SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP: "DIP",
        SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP: "DIP_SIP",
        SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET: "DIP_SIP_SUBNET"
    }


log_verbosity_level = {
    'none': SX_VERBOSITY_LEVEL_NONE,
    'error': SX_VERBOSITY_LEVEL_ERROR,
    'warn': SX_VERBOSITY_LEVEL_WARNING,
    'notice': SX_VERBOSITY_LEVEL_NOTICE,
    'info': SX_VERBOSITY_LEVEL_INFO,
    'debug': SX_VERBOSITY_LEVEL_DEBUG,
    'functions': SX_VERBOSITY_LEVEL_FUNCS,
    'frames': SX_VERBOSITY_LEVEL_FRAMES,
}

bulk_cntr_done_status_str_dict = {
    SX_BULK_CNTR_DONE_STATUS_CANCELED: 'Canceled',
    SX_BULK_CNTR_DONE_STATUS_OK: 'OK',
    SX_BULK_CNTR_DONE_STATUS_ERROR: 'Error',
    SX_BULK_CNTR_DONE_STATUS_PARTIALLY_COMPLETE: 'Partially-complete',
}

tele_tac_mode_dict = {
    SX_TELE_TAC_MODE_DISABLE_E: "Disabled",
    SX_TELE_TAC_MODE_TO_NETWORK_E: "TAC to Network",
}

tele_tac_action_dict = {
    SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E: "FLUSH_AND_REPORT",
    SX_TELE_TAC_ACTION_REPORT_E: "REPORT",
    SX_TELE_TAC_ACTION_FLUSH_E: "FLUSH",
}

tele_tac_action_status_dict = {
    SX_TELE_TAC_ACTION_STATUS_FREE_E: "FREE",
    SX_TELE_TAC_ACTION_STATUS_BUSY_E: "BUSY",
}


def check_vport(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_VPORT


def check_nve(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_NVE


def check_cpu(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_CPU


def get_ports(handle, ports_num):
    port_cnt_p = new_uint32_t_p()
    port_list = []
    log_port_list_p = new_sx_port_log_id_t_arr(ports_num)
    uint32_t_p_assign(port_cnt_p, ports_num)
    rc = sx_api_port_swid_port_list_get(handle, 0, log_port_list_p, port_cnt_p)
    if rc != 0:
        raise Exception('Failed to get {} ports.'
                        'sx_api_port_swid_port_list_get returned rc: {}'.format(ports_num, rc))

    for i in range(ports_num):
        port_list.append(sx_port_log_id_t_arr_getitem(log_port_list_p, i))
    return port_list


def mapPortAndInterfaces(handle, num_ports=4, print_ports=True):

    count_sleeps = 0

    port_with_admin_up_list = getAllPortWithLinkUp(handle, PORT_ADMIN_STATUS)

    if num_ports > len(port_with_admin_up_list):
        raise Exception("Not enough ports in state up")

    if print_ports:
        print('[{}]'.format(', '.join(hex(x) for x in port_with_admin_up_list)))

    return port_with_admin_up_list


def wait_till_port_list_up(handle, interface_list, timeout=50):
    for index in range(4):
        wait_till_port_up(handle, interface_list[index].get_log_port(), timeout)
    return True


def getPortDown(handle, port_list):
    for port in port_list:
        if checkPortDown(handle, port):
            return port
    raise Exception("no port in state down")


def wait_till_port_up(handle, port, timeout=50):
    start = time.time()
    end = time.time()

    while not checkPortUp(handle, port):
        end = time.time()
        if timeout < end - start:
            print((" \n", end - start))
            sys.exit(1)

    print((" \n", end - start))

    return True


def checkPortUp(handle, port):

    oper_state_t_p = new_sx_port_oper_state_t_p()
    admin_state_t_p = new_sx_port_admin_state_t_p()
    module_state_t_p = new_sx_port_module_state_t_p()

    rc = sx_api_port_state_get(handle, port, oper_state_t_p, admin_state_t_p, module_state_t_p)
    if rc != 0:
        sys.exit(1)

    oper_state = sx_port_oper_state_t_p_value(oper_state_t_p)
    return (oper_state == SX_PORT_OPER_STATUS_UP)


def checkPortDown(handle, port):

    oper_state_t_p = new_sx_port_oper_state_t_p()
    admin_state_t_p = new_sx_port_admin_state_t_p()
    module_state_t_p = new_sx_port_module_state_t_p()

    rc = sx_api_port_state_get(handle, port, oper_state_t_p, admin_state_t_p, module_state_t_p)
    if rc != 0:
        sys.exit(1)

    oper_state = sx_port_oper_state_t_p_value(oper_state_t_p)
    return (oper_state == SX_PORT_OPER_STATUS_DOWN)


def getAllPortWithLinkUp(handle, port_mode=PORT_OPER_STATUS):

    port_with_link_up_list = []

    # Get the active SWID list

    swid_list_p = new_sx_swid_t_arr(16)

    swid_cnt_p = new_uint32_t_p()

    uint32_t_p_assign(swid_cnt_p, 16)

    rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
    if rc != 0:
        print("Failed to get SWID List, rc = %d", rc)
        sys.exit(1)

    swid_cnt = uint32_t_p_value(swid_cnt_p)

    # print ("sx_api_port_swid_list_get swid_cnt:%d , rc %d, swid table: " % ( swid_cnt, rc) )

    for i in range(0, swid_cnt):
        swid = sx_swid_t_arr_getitem(swid_list_p, i)

        # Get actual port count
        port_cnt_p = copy_uint32_t_p(0)
        rc = sx_api_port_swid_port_list_get(handle, swid, None, port_cnt_p)
        if rc != 0:
            print("Failed to get SWID Port count, rc = %d", rc)
            sys.exit(1)

        port_cnt = uint32_t_p_value(port_cnt_p)
        log_port_list_p = new_sx_port_log_id_t_arr(port_cnt)

        rc = sx_api_port_swid_port_list_get(handle, swid, log_port_list_p, port_cnt_p)
        if rc != 0:
            print("Failed to get SWID Port list, rc = %d", rc)
            sys.exit(1)

        for i in range(0, port_cnt):
            port = sx_port_log_id_t_arr_getitem(log_port_list_p, i)
            oper_state_t_p = new_sx_port_oper_state_t_p()
            admin_state_t_p = new_sx_port_admin_state_t_p()
            module_state_t_p = new_sx_port_module_state_t_p()

            rc = sx_api_port_state_get(handle, port, oper_state_t_p, admin_state_t_p, module_state_t_p)
            if rc != 0:
                print("Failed to get port 0x%x state, rc = %d", port, rc)
                sys.exit(1)

            oper_state = sx_port_oper_state_t_p_value(oper_state_t_p)
            admin_state = sx_port_admin_state_t_p_value(admin_state_t_p)
            module_state = sx_port_module_state_t_p_value(module_state_t_p)

            if port_mode == PORT_OPER_STATUS:
                if oper_state == SX_PORT_OPER_STATUS_UP:
                    # print "port state is up"
                    port_with_link_up_list.append(port)
            elif port_mode == PORT_ADMIN_STATUS:
                if admin_state == SX_PORT_ADMIN_STATUS_UP:
                    port_with_link_up_list.append(port)

    return port_with_link_up_list


def port_state_set(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    assert SX_STATUS_SUCCESS == rc, "sx_api_port_state_set failed"


def get_port_module_mapping(port_attributes_list, port_cnt):
    port_module = {}
    module_port = dict()
    for i in range(port_cnt):
        port = port_attributes_list[i]
        # consider all external/network ports
        if port.port_mode == SX_PORT_MODE_EXTERNAL and port.port_mapping.mapping_mode == SX_PORT_MAPPING_MODE_ENABLE:
            # populate {log_port: (slot_id, module_id)} mapping
            port_module[hex(port.log_port)] = (port.port_mapping.slot, port.port_mapping.module_port)
            # populate {(slot_id, module_id): log_port_list} mapping
            if (port.port_mapping.slot, port.port_mapping.module_port) not in module_port.keys():
                module_port[(port.port_mapping.slot, port.port_mapping.module_port)] = [port.log_port]
            else:
                module_port[(port.port_mapping.slot, port.port_mapping.module_port)].append(port.log_port)
    # return the dictionary
    return port_module, module_port


def get_slot_port_mapping(port_attributes_list, port_cnt):
    slot_port = dict()
    for i in range(port_cnt):
        port = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        slot_port.setdefault(port.port_mapping.slot, []).append(port)
    # return the dictionary
    return slot_port


def ports_attributes_get(handle):
    port_attributes_list = None
    port_cnt_p = new_uint32_t_p()
    try:
        rc = sx_api_port_device_get(handle, 1, SPECTRUM_SWID, None, port_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_port_device_get failed to get ports count"
        num_ports = uint32_t_p_value(port_cnt_p)

        port_attributes_list = new_sx_port_attributes_t_arr(num_ports)
        rc = sx_api_port_device_get(handle, 1, SPECTRUM_SWID, port_attributes_list, port_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_port_device_get failed to get ports count"

        return [sx_port_attributes_t_arr_getitem(port_attributes_list, i) for i in range(num_ports)]
    finally:
        delete_uint32_t_p(port_cnt_p)
        if port_attributes_list is not None:
            delete_sx_port_attributes_t_arr(port_attributes_list)


def ip_addr_to_str(ip_addr):
    if ip_addr.version == SX_IP_VERSION_IPV4:
        return socket.inet_ntop(socket.AF_INET, struct.pack('!I', ip_addr.addr.ipv4.s_addr))
    else:
        bytes = ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8
        byte_arr = []
        for i in range(0, 16):
            byte_arr.append(uint8_t_arr_getitem(bytes, i))
        if sys.byteorder == "little":
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[3], byte_arr[2], byte_arr[1], byte_arr[0], byte_arr[7], byte_arr[6], byte_arr[5], byte_arr[4], byte_arr[11], byte_arr[10], byte_arr[9], byte_arr[8], byte_arr[15], byte_arr[14], byte_arr[13], byte_arr[12])
        else:
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[0], byte_arr[1], byte_arr[2], byte_arr[3], byte_arr[4], byte_arr[5], byte_arr[6], byte_arr[7], byte_arr[8], byte_arr[9], byte_arr[10], byte_arr[11], byte_arr[12], byte_arr[13], byte_arr[14], byte_arr[15])
        return socket.inet_ntop(socket.AF_INET6, dwords)


def redirect_stdout():
    sys.stdout.flush()
    stdout_bak = os.dup(1)
    devnull = os.open('/dev/null', os.O_WRONLY)
    os.dup2(devnull, 1)
    os.close(devnull)
    return stdout_bak


def print_all_attr_from_a_struct(struct):
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            print("%s = %s" % (attr, getattr(struct, attr)))


def ip_prefix_to_str(ip_prefix):
    if ip_prefix.version == SX_IP_VERSION_IPV4:
        return socket.inet_ntop(socket.AF_INET, struct.pack('!I', ip_prefix.prefix.ipv4.addr.s_addr))
    else:
        bytes = ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8
        byte_arr = []
        for i in range(0, 16):
            byte_arr.append(uint8_t_arr_getitem(bytes, i))
        if sys.byteorder == "little":
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[3], byte_arr[2], byte_arr[1], byte_arr[0], byte_arr[7], byte_arr[6], byte_arr[5], byte_arr[4], byte_arr[11], byte_arr[10], byte_arr[9], byte_arr[8], byte_arr[15], byte_arr[14], byte_arr[13], byte_arr[12])
        else:
            dwords = struct.pack("!BBBBBBBBBBBBBBBB", byte_arr[0], byte_arr[1], byte_arr[2], byte_arr[3], byte_arr[4], byte_arr[5], byte_arr[6], byte_arr[7], byte_arr[8], byte_arr[9], byte_arr[10], byte_arr[11], byte_arr[12], byte_arr[13], byte_arr[14], byte_arr[15])
        return socket.inet_ntop(socket.AF_INET6, dwords)


def mask_len(ip_prefix):
    if ip_prefix.version == SX_IP_VERSION_IPV4:
        count = 0
        mask = ip_prefix.prefix.ipv4.mask.s_addr
        while mask != 0:
            if ((mask & 0x1) == 1):
                count = count + 1
            mask = mask >> 1
        return count
    else:
        bytes = ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8
        count = 0
        for i in range(0, 16):
            byte = uint8_t_arr_getitem(bytes, i)
            while byte != 0:
                if ((byte & 0x1) == 1):
                    count = count + 1
                byte = byte >> 1
        return count


def print_api_example_disclaimer():
    print("DISCLAIMER")
    print("==========")
    print("The following code is an EXAMPLE whose sole purpose is to demonstrate various capabilities of the SDK.")
    print("This example represents a common configuration scenario and is in no way a complete guide to the demonstrated feature.")
    print("For complete documentation please refer to the SDK API Guide.")
    print("There is no guarantee that this example will run successfully on all hardware and software configurations.")
    print("")


def print_modification_warning():
    valid = {"yes": True, "y": True, "ye": True}
    print("NOTE: Running this example MAY MODIFY current configuration of the SDK!")
    print("Do you wish to continue? (y/N)")
    choice = input().lower()
    if choice not in valid:
        sys.exit(0)


def _ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))
    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]
    # Finally, convert back to bytes
    return struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])


def check_ipv6_type(addr):
    if ':' in addr:  # IPV6 version
        return True
    else:
        return False


def check_ipv4_type(addr):
    if '.' in addr:  # IPV4 version
        return True
    else:
        return False


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def make_sx_ip_addr_v6(addr):
    " This function creates ipv6 sx_ip_addr struct with given ip address. "
    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr


def make_sx_ip_addr(addr):
    if check_ipv4_type(addr):
        return make_sx_ip_addr_v4(addr)
    elif check_ipv6_type(addr):
        return make_sx_ip_addr_v6(addr)


def make_fixed_parse_header_src_node(parser_hdr_fixed):
    from_ph = sx_flex_parser_header_t()
    from_ph.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    from_ph.hdr_data.parser_hdr_fixed = parser_hdr_fixed
    return from_ph


def make_fixed_transition_dest_node(parser_hdr_fixed, encap_level, val):
    to_ph = sx_flex_parser_transition_t()
    to_ph.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    to_ph.next_parser_hdr.hdr_data.parser_hdr_fixed = parser_hdr_fixed
    to_ph.encap_level = encap_level
    to_ph.transition_value = val
    return to_ph


def vxlan_get_udp_dport(handle, default_udp_port=4789):
    next_trans_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_trans_cnt_p, 0)
    from_ph = make_fixed_parse_header_src_node(SX_FLEX_PARSER_HEADER_UDP_E)
    rc = sx_api_flex_parser_transition_get(handle, from_ph, None, next_trans_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        return default_udp_port

    next_trans_cnt = uint32_t_p_value(next_trans_cnt_p)
    next_trans_p = new_sx_flex_parser_transition_t_arr(next_trans_cnt)
    rc = sx_api_flex_parser_transition_get(handle, from_ph, next_trans_p, next_trans_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        raise Exception("sx_api_flex_parser_transition_get failed %s" % (rc))
    to_trans = sx_flex_parser_transition_t()
    to_trans = sx_flex_parser_transition_t_arr_getitem(next_trans_p, 0)
    return to_trans.transition_value


def get_chip_type(handle, replace_spc1_a1_with_spc1=True):
    """
    :return: SX_CHIP_TYPE_SPECTRUM / SX_CHIP_TYPE_SPECTRUM2\3, Based on device id retrieved from SXD
    """

    print("Retrieving Chip Type from SDK")
    device_info_cnt = 1
    device_info_cnt_p = copy_uint32_t_p(device_info_cnt)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    try:
        rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_device_list_get failed, rc = %d" % rc))
            sys.exit(rc)
        device_info = sx_device_info_t_arr_getitem(device_info_list_p, 0)
    finally:
        delete_uint32_t_p(device_info_cnt_p)
        delete_sx_device_info_t_arr(device_info_list_p)

    if replace_spc1_a1_with_spc1 and device_info.dev_type == SX_CHIP_TYPE_SPECTRUM_A1:
        return SX_CHIP_TYPE_SPECTRUM

    return device_info.dev_type


def cmd_output_get(cmd):
    """ Run command in privileged shell, return its output as a list of strings """
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True, universal_newlines=True).strip()
    except subprocess.CalledProcessError as e:
        print("CMD '{}' Failed: {}. Command output:\n{}".format(cmd, str(e), e.output))
        raise e


def get_product_name():
    """ Get switch system product name from SMBIOS (e.g. MSN3700)
    If command fails - Will return empty string """

    try:
        return cmd_output_get("dmidecode -s system-product-name")
    except subprocess.CalledProcessError as e:
        print("-W- Failed to get product name from SMBIOS".format(str(e), e.output))
        return ""


def get_chip_id():
    """
    Return underlying chip ID, using lspci, and not through MGIR / SDK API.
    Useful for examples that needs the chip type, but not through MGIR - since FW might be stuck
    Example: sx_api_dbg_generate_dump_ext.py
    """

    nvidia_vid_str = "15b3"
    try:
        lspci_out = cmd_output_get("lspci -n")
    except subprocess.CalledProcessError as e:
        print("Failed to get 'lspci' output")
        raise e

    for line in lspci_out.split("\n"):
        if nvidia_vid_str in line:
            return int(line.split(":")[-1].split(" ")[0].strip(), base=16)

    raise Exception("Nvidia Vendor ID ({}) not found in lspci output - Check PCI Devices on the switch".format(nvidia_vid_str))


def trap_group_set_unset_cmd_get(handle):
    trap_group_set_cmd = SX_ACCESS_CMD_CREATE
    trap_group_unset_cmd = SX_ACCESS_CMD_DESTROY

    if get_chip_type(handle) in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("Using trap group legacy mode (SET/UNSET) Over SPC1. This is NOT SPC1 Limitation\n"
              "SDK Recommends To ALWAYS Use new mode - CREATE/DESTROY Instead\n"
              "Legacy mode will be deprecated entirely in the future.")
        trap_group_set_cmd = SX_ACCESS_CMD_SET
        trap_group_unset_cmd = SX_ACCESS_CMD_UNSET

    return trap_group_set_cmd, trap_group_unset_cmd


def auto_int(x):
    return None if x is None else int(x, 0)


def system_slot_count_get(handle):
    system_info_p = new_sx_mgmt_slot_system_info_t_p()
    try:
        rc = sx_mgmt_system_info_get(handle, system_info_p)
        if (rc != SX_STATUS_SUCCESS):
            print("sx_mgmt_system_info_get failed, rc = %d" % rc)
            sys.exit(rc)
        system_info = sx_mgmt_slot_system_info_t_p_value(system_info_p)
        return system_info.slot_count

    finally:
        delete_sx_mgmt_slot_system_info_t_p(system_info_p)


def phy_module_state_get(handle, slot_id, module_id):
    try:
        module_id_info_list_arr = new_sx_mgmt_module_id_info_t_arr(1)
        module_id_info = sx_mgmt_module_id_info_t()
        module_id_info.slot_id = slot_id
        module_id_info.module_id = module_id
        sx_mgmt_module_id_info_t_arr_setitem(module_id_info_list_arr, 0, module_id_info)
        module_info_list_arr = new_sx_mgmt_phy_module_info_t_arr(1)
        list_size = 1
        rc = sx_mgmt_phy_module_info_get(handle, module_id_info_list_arr, list_size, module_info_list_arr)
        if (rc != SX_STATUS_SUCCESS):
            print("phy_module_state_get failed, rc = %d" % rc)
            sys.exit(rc)

        module_info = sx_mgmt_phy_module_info_t_arr_getitem(module_info_list_arr, 0)
        return module_info.module_state.oper_state
    finally:
        delete_sx_mgmt_module_id_info_t_arr(module_id_info_list_arr)
        delete_sx_mgmt_phy_module_info_t_arr(module_info_list_arr)


def get_slot_count(handle):
    try:
        system_info_p = new_sx_mgmt_slot_system_info_t_p()
        rc = sx_mgmt_system_info_get(handle, system_info_p)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_system_info_get failed"
        system_info = sx_mgmt_slot_system_info_t_p_value(system_info_p)
        slot_count = system_info.slot_count
        return slot_count
    finally:
        delete_sx_mgmt_slot_system_info_t_p(system_info_p)


def get_slot_info(handle):
    slot_count = get_slot_count(handle)
    assert slot_count != 0, "get_slot_info failed"
    try:
        slot_id_list_p = new_sx_slot_id_t_arr(slot_count)
        slot_info_list_p = new_sx_mgmt_slot_info_t_arr(slot_count)
        slot_info_cnt_p = copy_uint32_t_p(slot_count)

        for slot_id in range(1, slot_count + 1):
            sx_slot_id_t_arr_setitem(slot_id_list_p, (slot_id - 1), slot_id)

        rc = sx_mgmt_slot_info_get(handle, slot_id_list_p, slot_info_list_p, slot_info_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_slot_info_get failed"

        return [sx_mgmt_slot_info_t_arr_getitem(slot_info_list_p, i) for i in range(slot_count)]

    finally:
        delete_sx_slot_id_t_arr(slot_id_list_p)
        delete_sx_mgmt_slot_info_t_arr(slot_info_list_p)
        delete_uint32_t_p(slot_info_cnt_p)


def del_dict_duplicate_values(dict):
    for key in list(dict.keys()):
        if key.endswith("_MIN_E") or key.endswith("_MIN"):
            del dict[key]
        if key.endswith("_MAX_E") or key.endswith("_MAX"):
            del dict[key]
    return dict


def sx_api_get_enums_from_prefix(prefix):
    sx_api_str_enum_dict = {}
    for item in dir(sx_api):
        if item.startswith(prefix):
            sx_api_str_enum_dict[item] = getattr(sx_api, item)
    return sx_api_str_enum_dict


def get_enum_string_dict(enum_prefix):
    # dict with {string: enum_value}
    string_enum = sx_api_get_enums_from_prefix(enum_prefix)
    # dict with {enum_value: string}
    string_enum = del_dict_duplicate_values(string_enum)
    enum_string = dict((v, k) for k, v in string_enum.items())
    return enum_string


def get_boolean_string(val):
    if val == 0:
        return "FALSE"
    else:
        return "TRUE"


def get_local_port(log_port):
    return (log_port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS


# Gets a local port and returns the least significant 8 bits and the most significant 2 bits of it.
# Example: for local port 258 (0100000010) - returns 00000010, 01 (in this order).
def get_lsb_msb_of_local_port(local_port):
    return (local_port & 0x0FF), ((local_port >> 8) & 0x003)


def is_swig_internal_attribute(attr):
    """
    Check whether a given attribute is swig internal attribute, such as "__<something>",
    Or "this" / "thisown"

    Returns:
        True if attribute is swig internal attribute, False otherwise
    """

    return attr.startswith("__") or attr in ["this", "thisown"]


class SXD_Interface:
    '''
    Interface for registers sending using SXD APIs
    '''

    @staticmethod
    def convert_buffer_big_little_endian(buff, size):
        num_dwords = size // 4 + (size % 4 > 0)
        for i in range(0, num_dwords):
            byte0 = uint8_t_arr_getitem(buff, i * 4)
            byte1 = uint8_t_arr_getitem(buff, i * 4 + 1)
            byte2 = uint8_t_arr_getitem(buff, i * 4 + 2)
            byte3 = uint8_t_arr_getitem(buff, i * 4 + 3)
            uint8_t_arr_setitem(buff, i * 4, byte3)
            uint8_t_arr_setitem(buff, i * 4 + 1, byte2)
            uint8_t_arr_setitem(buff, i * 4 + 2, byte1)
            uint8_t_arr_setitem(buff, i * 4 + 3, byte0)
        return buff

    @staticmethod
    def get_meta():
        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0
        return meta

    def access_reg_raw(self, command, reg_raw, register_id):
        reg_meta = self.get_meta()
        reg_meta.access_cmd = command
        reg_raw.buff = self.convert_buffer_big_little_endian(reg_raw.buff, reg_raw.size)
        rc = sxd_access_reg_raw(reg_raw, reg_meta, 1, register_id, None, None)
        if rc != SXD_STATUS_SUCCESS:
            raise Exception("sxd_access_reg_raw failed", rc)
        reg_raw.buff = self.convert_buffer_big_little_endian(reg_raw.buff, reg_raw.size)
        data = uint8_t_arr_getitem(reg_raw.buff, 0)
        return data

    def modify(self, ctype_reg, reg_id, command, **kwargs):
        '''
        Get/SET swig type raw reg register using SXD API.
        :param ctype_reg: Ctypes register
        :param reg_id: ID
        :param command: SXD_ACCESS_CMD_GET, SXD_ACCESS_CMD_SET
            Optional keyword argument parameters:
            expected_rc: Compare received return code to expected_rc, default is SXD_STATUS_SUCCESS
        :return: Ctypes register
        '''
        raw_reg = self._get_raw_from_ctype_reg(ctype_reg)
        expected_rc = kwargs.get('expected_rc', SXD_STATUS_SUCCESS)
        self.access_reg_raw(command, raw_reg, reg_id)
        reg = self._convert_raw_to_ctype_reg(ctype_reg, raw_reg)
        return reg

    @staticmethod
    def _get_raw_from_ctype_reg(ctype_reg):
        '''
        Convert ctypes register to swig raw register
        :param reg: Ctypes register
        :return: Swig raw structure
        '''
        raw_reg = ku_raw_reg()  # Get swig raw structure
        size = ctypes.sizeof(ctype_reg)
        raw_reg.size = size
        raw_reg.buff = new_uint8_t_arr(size)
        # Create ctypes buffer, same size as reg, and fill it
        buf = (ctypes.c_ubyte * size)()
        ctypes.memmove(ctypes.byref(buf), ctypes.byref(ctype_reg), size)
        for i in range(size):
            uint8_t_arr_setitem(raw_reg.buff, i, buf[i])
        return raw_reg

    @staticmethod
    def _convert_raw_to_ctype_reg(ctype_reg, raw_reg):
        '''
        Convert swig raw register to ctypes register
        :param raw_reg: Swig raw structure
        :return:
        '''
        size = ctypes.sizeof(ctype_reg)
        buf = (ctypes.c_ubyte * size)()
        for i in range(size):
            buf[i] = uint8_t_arr_getitem(raw_reg.buff, i)
        ctypes.memmove(ctypes.byref(ctype_reg), ctypes.byref(buf), size)
        return ctype_reg


class RegInterface(ctypes.Structure):
    '''
    Used for adding more abilities to an EMAD register (ctypes) as get and set
    Uses as parent class for PRM headers - NOT FOR DIRECT USAGE OF CLASS INSTANCES
    '''
    _if = SXD_Interface()

    def get(self, **kwargs):
        '''
        Get EMAD register
            Optional keyword argument parameters:
            expected_rc: Compare received return code to expected_rc, default is SXD_STATUS_SUCCESS
        :return: EMAD register
        '''
        reg = self._if.modify(self, self.tlv_id, command=SXD_ACCESS_CMD_GET, **kwargs)
        return reg

    def set(self, **kwargs):
        '''
        Set EMAD register

            Optional keyword argument parameters:
            expected_rc: Compare received return code to expected_rc, default is SXD_STATUS_SUCCESS
        :return:
        '''
        reg = self._if.modify(self, self.tlv_id, command=SXD_ACCESS_CMD_SET, **kwargs)
        return reg

    @property
    def local_port(self):
        """
            local_port get function for the property.
            This function is private in order not to confuse the user.
        """
        rd = self.lp_lsb
        if hasattr(self, 'lp_msb'):
            rd = self.lp_lsb | (self.lp_msb << 8)
        return rd

    @local_port.setter
    def local_port(self, value):
        """
            local_port get function for the property.
            This function is private in order not to confuse the user.
        """
        self.lp_lsb = (value & 0xFF)
        if hasattr(self, 'lp_msb'):
            # Check if lp_msb field exists
            self.lp_msb = (value >> 8) & 0x3
        else:
            assert value < 0xFF, "Assigning value greater than 255 to local port in struct that not support lp_msb"


def tunnel_module_verbosity_level_get(handle):
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_tunnel_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p,
                                               api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed in sx_api_tunnel_log_verbosity_level_get API rc=%d" % rc)
        sys.exit(rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    return module_verbosity_level, api_verbosity_level


def tunnel_module_verbosity_level_set(handle, module_verbosity, api_verbosity):
    rc = sx_api_tunnel_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set tunnel API verbosity level")
        sys.exit(rc)
