#!/usr/bin/env python
'''
This file contains Python command example for the Host Ifc DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''

truncate_mode_dict = {0: 'DISABLE', 1: 'ENABLE'}
control_type_dict = {0: 'DEFAULT', 1: 'ENABLE', 2: 'DISABLE'}

import sys
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_dump example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0x777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

swid = 0
trap_group_attr_p = new_sx_trap_group_attributes_t_p()
policer_id_p = new_sx_policer_id_t_p()


# save current module_verbosity_level and api_verbosity_level for later de-configuration
original_module_verbosity_level_p = new_sx_verbosity_level_t_p()
original_api_verbosity_level_p = new_sx_verbosity_level_t_p()
rc = sx_api_host_ifc_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, original_module_verbosity_level_p, original_api_verbosity_level_p)
if (rc != SX_STATUS_SUCCESS):
    print("fail to get host ifc API log verbosity level")
    sys.exit(rc)
original_module_verbosity_level = sx_verbosity_level_t_p_value(original_module_verbosity_level_p)
original_api_verbosity_level = sx_verbosity_level_t_p_value(original_api_verbosity_level_p)

# set verbosity_level
rc = sx_api_host_ifc_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
if (rc != SX_STATUS_SUCCESS):
    print("fail to set host ifc API log verbosity level")
    sys.exit(rc)

print("==================================================================================================")
header = ["trap_group", "trap_priority", "truncate_mode", "truncate_size", "control_type", "policer_id", "is_mon", "is_tac"]
print("|%11s|%14s|%14s|%14s|%13s|%11s|%6s|%6s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7]))
print("==================================================================================================")

for trap_i in range(0, 63):
    rc = sx_api_host_ifc_trap_group_get(handle, swid, trap_i, trap_group_attr_p)
    if (rc != SX_STATUS_SUCCESS):
        continue
    policer_str = "No policer"
    rc = sx_api_host_ifc_policer_bind_get(handle, swid, trap_i, policer_id_p)
    if rc == SX_STATUS_SUCCESS:
        policer_str = str(sx_policer_id_t_p_value(policer_id_p))
    print(("|%11s|%14s|%14s|%14s|%13s|%11s|%6s|%6s|" %
          (trap_i, trap_group_attr_p.prio, truncate_mode_dict[trap_group_attr_p.truncate_mode], trap_group_attr_p.truncate_size,
           control_type_dict[trap_group_attr_p.control_type], policer_str, get_boolean_string(trap_group_attr_p.is_monitor), get_boolean_string(trap_group_attr_p.is_tac_capable))))

if args.deinit:
    rc = sx_api_host_ifc_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, original_module_verbosity_level,
                                                 original_api_verbosity_level)
    if (rc != SX_STATUS_SUCCESS):
        print("fail to set host ifc API log verbosity level")
        sys.exit(rc)

print("==================================================================================================")
