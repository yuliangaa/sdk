#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='sxd_api_moni example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] MONI register access Example Test start")
print("[+] initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

meta.access_cmd = SXD_ACCESS_CMD_GET

# find valid local port for the current device
pspa = ku_pspa_reg()
for local_port in range(1, 64):
    meta.swid = 0
    pspa.swid = 0

    pspa.local_port, pspa.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    sxd_access_reg_pspa(pspa, meta, 1, None, None)

    if pspa.swid != 0xFF:
        break

print("====================")
print(("[+] For the example we will use local port %d" % (local_port)))
print("====================")

# save original_data for later de-configuration
original_data = ku_moni_reg()
original_data.local_port, original_data.lp_msb = pspa.local_port, pspa.lp_msb

rc = sxd_access_reg_moni(original_data, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MONI register, rc: %d" % (rc)
print("[+] Get original MONI content")
print("[+] local port: ", original_data.local_port)
print("[+] lp_msb: ", original_data.lp_msb)
print("[+] en:", original_data.en)
print("====================")

moni = ku_moni_reg()
moni.local_port, moni.lp_msb = pspa.local_port, pspa.lp_msb


meta.access_cmd = SXD_ACCESS_CMD_SET

moni.en = 1

print("[+] Set MONI content")
print("[+] en:", moni.en)
print("====================")

rc = sxd_access_reg_moni(moni, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MONI register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET

print("[+] Get after Set MONI content")
rc = sxd_access_reg_moni(moni, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MONI register, rc: %d" % (rc)

print("[+] local port: ", moni.local_port)
print("[+] lp_msb: ", moni.lp_msb)
print("[+] en:", moni.en)
print("====================")

if args.deinit:
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_moni(original_data, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MONI register, rc: %d" % (rc)

    meta.access_cmd = SXD_ACCESS_CMD_GET
    print("[+] Get Moni after deinit")
    rc = sxd_access_reg_moni(moni, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read MONI register, rc: %d" % (rc)

    print("[+] local port: ", moni.local_port)
    print("[+] lp_msb: ", moni.lp_msb)
    print("[+] en:", moni.en)
    print("====================")

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] MONI register access example test end")
