#!/usr/bin/env python
'''
This file contains Python command example to get vort speed.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
.
This example is supported on Spectrum devices
'''
import sys
import errno
import sys
import colorsys

from python_sdk_api.sx_api import *
from test_infra_common import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if rc != SX_STATUS_SUCCESS:
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

####################################################################################
print("------- PORT SPEED GET ------------")
####################################################################################
port_attributes_list = new_sx_port_attributes_t_arr(64)
port_cnt_p = new_uint32_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
uint32_t_p_assign(port_cnt_p, 64)
admin_speed_p = new_sx_port_speed_capability_t_p()
oper_speed_p = new_sx_port_oper_speed_t_p()

rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
port_cnt = uint32_t_p_value(port_cnt_p)
tables = []
log_port = []
for i in range(0, port_cnt):

    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_vport or is_cpu:
        continue
    rc = sx_api_port_speed_get(handle, int(port_attributes.log_port), admin_speed_p, oper_speed_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_speed_get failed for iteration[%d], rc=%d] " % (i, rc)))
        sys.exit(rc)

    admin_speed = sx_port_speed_capability_t_p_value(admin_speed_p)
    oper_speed = sx_port_oper_speed_t_p_value(oper_speed_p)
    table = [port_attributes.log_port, admin_speed.mode_1GB_CX_SGMII, admin_speed.mode_1GB_KX, admin_speed.mode_10GB_CX4_XAUI, admin_speed.mode_10GB_KX4, admin_speed.mode_10GB_KR, admin_speed.mode_20GB_KR2, admin_speed.mode_40GB_CR4, admin_speed.mode_40GB_KR4, admin_speed.mode_56GB_KR4, admin_speed.mode_56GB_KX4, admin_speed.mode_10GB_CR, admin_speed.mode_10GB_SR, admin_speed.mode_10GB_ER_LR, admin_speed.mode_40GB_SR4, admin_speed.mode_40GB_LR4_ER4, admin_speed.mode_100GB_CR4, admin_speed.mode_100GB_SR4, admin_speed.mode_100GB_KR4, admin_speed.mode_100GB_LR4_ER4, admin_speed.mode_25GB_CR, admin_speed.mode_25GB_KR, admin_speed.mode_25GB_SR, admin_speed.mode_50GB_CR2, admin_speed.mode_50GB_KR2, admin_speed.mode_50GB_SR2, admin_speed.mode_auto, oper_speed]

    tables.append(table)
header = ["LOG_PORT", "1GB_CX_SGMII", "1GB_KX", "10GB_CX4_XAUI", "mode_10GB_KX4", "mode_10GB_KR", "mode_20GB_KR2", "mode_40GB_CR4", "mode_40GB_KR4", "mode_56GB_KR4", "mode_56GB_KX4", "mode_10GB_CR", "mode_10GB_SR", "mode_10GB_ER_LR", "mode_40GB_SR4", "mode_40GB_LR4_ER4", "mode_100GB_CR4", "mode_100GB_SR4", "mode_100GB_KR4", "mode_100GB_LR4_ER4", "mode_25GB_CR", "mode_25GB_KR", "mode_25GB_SR", "mode_50GB_CR2", "mode_50GB_KR2", "mode_50GB_SR2", "mode_auto", "oper_speed"]

print("|%7s|%6s|%6s|%10s|%10s|%10s|%7s|%7s|%7s|%7s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9]))
for table in tables:
    print("|%8x|%12d|%6d|%13d|%13d|%12d|%13d|%13d|%13d|%13d|" % (table[0], table[1], table[2], table[3], table[4], table[5], table[6], table[7], table[8], table[9]))
print("---------------------------------------------------------------------------------------------------------------------------------")

print("|%7s|%6s|%10s|%10s|%10s|%10s|%7s|%7s|%7s|" % (header[0], header[10], header[11], header[12], header[13], header[14], header[15], header[16], header[17]))
for table in tables:
    print("|%8x|%13d|%12d|%12d|%15d|%13d|%17d|%14d|%14d|" % (table[0], table[10], table[11], table[12], table[13], table[14], table[15], table[16], table[17]))
print("---------------------------------------------------------------------------------------------------------------------------------------")

print("|%7s|%7s|%7s|%7s|%6s|%10s|%10s|%10s|%10s|%9s|" % (header[0], header[18], header[19], header[20], header[21], header[22], header[23], header[24], header[25], header[26]))
for table in tables:
    print("|%8x|%14d|%17d|%13d|%12d|%12d|%13d|%13d|%13d|%9d|" % (table[0], table[18], table[19], table[20], table[21], table[22], table[23], table[24], table[25], table[26]))
print("---------------------------------------------------------------------------------------------------------------------------------------")
####################################################################################
sx_api_close(handle)
####################################################################################
