#!/usr/bin/env python
# -*- python -*-
'''
Copyright (C) Mellanox Technologies, Ltd. 2020.  ALL RIGHTS RESERVED.

This software product is a proprietary product of Mellanox Technologies, Ltd.
(the "Company") and all right, title, and interest in and to the software product,
including all associated intellectual property rights, are and shall
remain exclusively with the Company.

This software product is governed by the End User License Agreement
provided with the software product.

'''

import sys
import subprocess
import errno
import time
import inspect
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import functools
import struct
import logging
import tarfile
from logging import DEBUG, WARNING, INFO, ERROR
MACSEC_DEFAULT_VERBOSITY = 'error'


def macsec_verbosity_set(handle, log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_macsec_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, log_level, log_level)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New MACSec Log verbosity level = %d" % log_level))


def macsec_init_set(handle):
    try:
        sx_macsec_init_params_p = new_sx_macsec_init_params_t_p()
        rc = sx_api_macsec_init(handle, sx_macsec_init_params_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_init failed. [%s(%d)]" % (sx_status_dict[rc], rc)
        print(("Global MACSec init executed."))
    finally:
        delete_sx_macsec_init_params_t_p(sx_macsec_init_params_p)


def macsec_deinit_set(handle):
    rc = sx_api_macsec_deinit(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_deinit failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("Global MACSec deinit executed."))


def macsec_port_init_set(handle, port):
    init_attr = sx_macsec_port_init_attribute_t()
    init_attr.enable_fixed_latency = False
    init_attr_p = new_sx_macsec_port_init_attribute_t_p()
    sx_macsec_port_init_attribute_t_p_assign(init_attr_p, init_attr)
    rc = sx_api_macsec_port_init(handle, port, SX_ACCESS_CMD_SET, init_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_port_init failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("MACSec port init executed."))


def macsec_port_deinit_set(handle, port):
    rc = sx_api_macsec_port_deinit(handle, port)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_port_deinit failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("MACSec port deinit executed."))


def macsec_port_capability_get(handle, port):
    capab = sx_macsec_port_capability_t()
    capab_p = new_sx_macsec_port_capability_t_p()
    rc = sx_api_macsec_port_capability_get(handle, port, capab_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_port_capability_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    capab = sx_macsec_port_capability_t_p_value(capab_p)
    print(("MacSecSupported [%d]" % (capab.macsec_supported)))
    print(("MacSecEnabled [%d]" % (capab.macsec_enabled)))
    print(("Cryptotestfailed [%d]" % (capab.crypto_self_test_failed)))


def macsec_flow_obj_create(handle, port, direction):
    flow_attr = sx_macsec_flow_attribute_t()
    flow_attr.log_port = port
    if direction == 'ingress':
        flow_attr.direction = SX_MACSEC_DIR_INGRESS_E
    elif direction == 'egress':
        flow_attr.direction = SX_MACSEC_DIR_EGRESS_E
    macsec_flow_attr_p = new_sx_macsec_flow_attribute_t_p()
    sx_macsec_flow_attribute_t_p_assign(macsec_flow_attr_p, flow_attr)
    macsec_flow_obj_id_p = new_sx_macsec_flow_obj_id_t_p()
    rc = sx_api_macsec_flow_obj_set(handle, SX_ACCESS_CMD_CREATE, macsec_flow_attr_p, macsec_flow_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    flow_obj_id = sx_macsec_flow_obj_id_t_p_value(macsec_flow_obj_id_p)
    print("Created flow object with ID [0x%x]" % (flow_obj_id))


def macsec_flow_obj_get(handle, flow_id):
    macsec_flow_obj_id = flow_id
    macsec_flow_attr_p = new_sx_macsec_flow_attribute_t_p()
    rc = sx_api_macsec_flow_obj_get(handle, SX_ACCESS_CMD_GET, macsec_flow_obj_id, macsec_flow_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    macsec_flow_attr = sx_macsec_flow_attribute_t_p_value(macsec_flow_attr_p)
    print("Flow obj direction[%d]" % (macsec_flow_attr.direction))
    print("Flow obj port[0x%x]" % (macsec_flow_attr.log_port))
    return macsec_flow_attr


def macsec_flow_obj_remove(handle, flow_id):
    macsec_flow_obj_id_p = new_sx_macsec_flow_obj_id_t_p()
    sx_macsec_flow_obj_id_t_p_assign(macsec_flow_obj_id_p, flow_id)
    rc = sx_api_macsec_flow_obj_set(handle, SX_ACCESS_CMD_DELETE, None, macsec_flow_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print("Deleted flow object with ID [0x%x]" % (flow_id))


def macsec_sc_obj_create(handle, flow_id, sc_id, cipher_suite, explicit_sci, confid_offset, enable_replay_protection, replay_win_size, disable_encryption):
    sc_attr = sx_macsec_sc_attribute_t()
    sc_attr.flow_obj_id = flow_id
    sc_attr.sc_profile.sc_id = sc_id
    sc_attr.sc_profile.disable_encryption = disable_encryption
    if cipher_suite == 'SX_MACSEC_CIPHER_TYPE_GCM_AES_128':
        sc_attr.sc_profile.sc_cipher_suite = SX_MACSEC_CIPHER_TYPE_GCM_AES_128
        sc_attr.sc_profile.confid_offset = confid_offset
    elif cipher_suite == 'SX_MACSEC_CIPHER_TYPE_GCM_AES_256':
        sc_attr.sc_profile.sc_cipher_suite = SX_MACSEC_CIPHER_TYPE_GCM_AES_256
        sc_attr.sc_profile.confid_offset = confid_offset
    elif cipher_suite == 'SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_128':
        sc_attr.sc_profile.sc_cipher_suite = SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_128
    elif cipher_suite == 'SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_256':
        sc_attr.sc_profile.sc_cipher_suite = SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_256

    flow_attr = macsec_flow_obj_get(handle, flow_id)
    if flow_attr.direction == SX_MACSEC_DIR_INGRESS_E:
        sc_attr.sc_profile.sc_dir_attr.sc_rx_attr.replay_protection_enable = enable_replay_protection
        sc_attr.sc_profile.sc_dir_attr.sc_rx_attr.replay_protection_window_sz = replay_win_size
    elif flow_attr.direction == SX_MACSEC_DIR_EGRESS_E:
        sc_attr.sc_profile.sc_dir_attr.sc_tx_attr.explicit_sci_enable = explicit_sci

    macsec_sc_attr_p = new_sx_macsec_sc_attribute_t_p()
    sx_macsec_sc_attribute_t_p_assign(macsec_sc_attr_p, sc_attr)
    macsec_sc_obj_id_p = new_sx_macsec_sc_obj_id_t_p()
    rc = sx_api_macsec_sc_obj_set(handle, SX_ACCESS_CMD_CREATE, macsec_sc_attr_p, macsec_sc_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sc_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    sc_obj_id = sx_macsec_sc_obj_id_t_p_value(macsec_sc_obj_id_p)
    print("Created Secure channel object with ID [0x%x]" % (sc_obj_id))


def macsec_sc_obj_get(handle, sc_id):
    macsec_sc_obj_id = sc_id
    macsec_sc_attr_p = new_sx_macsec_sc_attribute_t_p()
    rc = sx_api_macsec_sc_obj_get(handle, SX_ACCESS_CMD_GET, macsec_sc_obj_id, macsec_sc_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sc_obj_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    macsec_sc_attr = sx_macsec_sc_attribute_t_p_value(macsec_sc_attr_p)
    print("SC obj ID[0x%x]" % (macsec_sc_attr.sc_obj_id))
    print("Associated Flow obj ID[0x%x]" % (macsec_sc_attr.flow_obj_id))
    print("Protocol assigned SC ID[0x%x]" % (macsec_sc_attr.sc_profile.sc_id))
    print("SC Cipher suite [0x%x]" % (macsec_sc_attr.sc_profile.sc_cipher_suite))


def macsec_sc_obj_remove(handle, sc_id):
    macsec_sc_obj_id_p = new_sx_macsec_sc_obj_id_t_p()
    sx_macsec_sc_obj_id_t_p_assign(macsec_sc_obj_id_p, sc_id)
    rc = sx_api_macsec_sc_obj_set(handle, SX_ACCESS_CMD_DELETE, None, macsec_sc_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sc_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print("Deleted SC object with ID [0x%x]" % (sc_id))


def macsec_sa_obj_create(handle, sc_id, sa_id, sak, packet_num, ssci, salt, counter_id):
    sa_attr = sx_macsec_sa_attribute_t()
    sa_attr.sc_obj_id = sc_id
    sa_attr.sa_id = sa_id
    sa_attr.ssci = ssci
    sa_attr.sa_macsec_flow_counter_id = counter_id

    sak = bytes(sak, 'ascii')
    salt = bytes(salt, 'ascii')
    for i, byte in enumerate(sak):
        uint8_t_arr_setitem(sa_attr.sak, i, byte)
    for i, byte in enumerate(salt):
        uint8_t_arr_setitem(sa_attr.salt, i, byte)

    sa_attr.packet_num = packet_num
    macsec_sa_attr_p = new_sx_macsec_sa_attribute_t_p()
    sx_macsec_sa_attribute_t_p_assign(macsec_sa_attr_p, sa_attr)
    macsec_sa_obj_id_p = new_sx_macsec_sa_obj_id_t_p()
    rc = sx_api_macsec_sa_obj_set(handle, SX_ACCESS_CMD_CREATE, macsec_sa_attr_p, macsec_sa_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sa_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    sa_obj_id = sx_macsec_sa_obj_id_t_p_value(macsec_sa_obj_id_p)
    print("Created Secure Association object with ID [0x%x]" % (sa_obj_id))


def _acl_key_create_delete(handle, cmd, key_handle_p, keys_list):
    keys = new_sx_acl_key_t_arr(len(keys_list))
    try:
        for i, key in enumerate(keys_list):
            if key == "FLEX_ACL_KEY_MACSEC_ETHERTYPE":
                acl_key = FLEX_ACL_KEY_MACSEC_ETHERTYPE
            sx_acl_key_t_arr_setitem(keys, i, acl_key)
        rc = sx_api_acl_flex_key_set(handle,
                                     cmd,
                                     keys,
                                     len(keys_list),
                                     key_handle_p)
        # check_rc(rc, SdkException('Failed to set ACL key handle', rc))
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_flex_key_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    finally:
        delete_sx_acl_key_t_arr(keys)


def macsec_acl_key_handle_create(handle, key_type_list):
    key_handle_p = new_sx_acl_key_type_t_p()
    try:
        cmd = SX_ACCESS_CMD_CREATE
        _acl_key_create_delete(handle, cmd, key_handle_p, key_type_list)
        key_handle = sx_acl_key_type_t_p_value(key_handle_p)
        print("Created MACSEC ACL key [ 0x%x ] with key list:" % (key_handle))
        print(' '.join(key_type_list))
        return key_handle
    finally:
        delete_sx_acl_key_type_t_p(key_handle_p)


def macsec_acl_key_handle_remove(handle, key_handle):
    key_handle_p = new_sx_acl_key_type_t_p()
    try:
        cmd = SX_ACCESS_CMD_DELETE
        sx_acl_key_type_t_p_assign(key_handle_p, key_handle)
        keys_list = []
        _acl_key_create_delete(handle, cmd, key_handle_p, keys_list)
        print("Removed MACSEC ACL key [ 0x%x ]" % (key_handle))
    finally:
        delete_sx_acl_key_type_t_p(key_handle_p)


def _acl_region_set(handle, cmd, key_handle, action_type, region_size, region_id_p):
    rc = sx_api_acl_region_set(handle, cmd, key_handle, action_type, region_size, region_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_region_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)


def _acl_region_get(handle, region_id, acl_key_type_p, acl_action_type_p, acl_size_p):
    rc = sx_api_acl_region_get(handle, region_id, acl_key_type_p, acl_action_type_p, acl_size_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_region_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    acl_key = sx_acl_key_type_t_p_value(acl_key_type_p)
    acl_action = sx_acl_action_type_t_p_value(acl_action_type_p)
    acl_size = sx_acl_size_t_p_value(acl_size_p)
    print(" Acl Key [%d] " % (acl_key))
    print(" Acl Action [%d] " % (acl_action))
    print(" Acl Size [%d] " % (acl_size))

    return acl_key, acl_action, acl_size


def macsec_acl_region_create(handle, key_handle, region_size):
    '''
    Create MACSEC ACL region

    Parameters
    ----------
    @handle - SDK handle.

    @key_handle - ID of an existing MACSEC ACl key handle

    @size - Number of rules to be created in the region

    Changes made:
    - Improved names
    - Returns RC
    '''
    region_id_p = new_sx_acl_region_id_t_p()
    try:
        # print("For ACL with key ID of {}, Creating new ACL region of size {} with action type {}".
        #             format(key_handle, region_size, action_type))

        cmd = SX_ACCESS_CMD_CREATE
        action_type = 0
        _acl_region_set(handle, cmd, key_handle, action_type, region_size, region_id_p)
        region_id = sx_acl_region_id_t_p_value(region_id_p)
        print("Created MACSEC acl region with ID [0x%x] (key_handle:0x%x , region_size:%d)" % (region_id, key_handle, region_size))
        return region_id
    finally:
        delete_sx_acl_region_id_t_p(region_id_p)


def macsec_acl_region_remove(handle, region_id):
    '''
    Destroys ACL region

    Parameters
    ----------
    @handle - SDK handle.

    @region_id - ID of an existing ACL region

    Changes made:
    - Improved names
    '''
    region_id_p = new_sx_acl_region_id_t_p()
    try:
        print("Destroying ACL Region {}".format(region_id))

        cmd = SX_ACCESS_CMD_DESTROY
        action_type = 0
        key_handle_id = 0
        size = 0
        sx_acl_region_id_t_p_assign(region_id_p, region_id)
        _acl_region_set(handle, cmd, key_handle_id, action_type, size, region_id_p)
        print("Destroy MACSEC acl region with ID [0x%x] " % (region_id))
    finally:
        delete_sx_acl_region_id_t_p(region_id_p)

# ACL


def _acl_set(handle, cmd, acl_type, direction, acl_region_group_p, acl_id_p):
    rc = sx_api_acl_set(handle, cmd, acl_type, direction, acl_region_group_p, acl_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print(" Acl Id [%d] " % (acl_id))


def _acl_get(handle, acl_id, acl_type_p, acl_direction_p, acl_region_group_p):
    rc = sx_api_acl_get(handle, acl_id, acl_type_p, acl_direction_p, acl_region_group_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    acl_type = sx_acl_type_t_p_value(acl_type_p)
    acl_dir = sx_acl_direction_t_p_value(acl_direction_p)
    acl_region_grp = sx_acl_region_group_t_p_value(acl_region_group_p)

    print(" Acl type [%d] " % (acl_type))
    print(" Acl Direction [%d] " % (acl_dir))
    print("Acl Region [%d] " % (acl_region_grp.regions.acl_packet_agnostic.region))


def macsec_acl_create(handle, region_id, direction):
    '''
    Creates ACL

    Parameters
    ----------
    @handle - SDK handle.

    @direction - SDK Enum

    @region_id - ID of an existing ACL region

    Changes made:
    - Improved names
    - return RC
    '''
    acl_id_p = new_sx_acl_id_t_p()
    acl_region_group_p = new_sx_acl_region_group_t_p()
    try:
        print("Creating new ACL with direction %s, and region_id 0x%x" % (direction, region_id))

        if direction == 'ingress':
            acl_direction = SX_ACL_DIRECTION_INGRESS
        else:
            acl_direction = SX_ACL_DIRECTION_EGRESS

        cmd = SX_ACCESS_CMD_CREATE
        acl_region_group = sx_acl_region_group_t()
        acl_region_group.regions.acl_packet_agnostic.region = region_id
        sx_acl_region_group_t_p_assign(acl_region_group_p, acl_region_group)
        _acl_set(handle, cmd, SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC, acl_direction, acl_region_group_p, acl_id_p)
        acl_id = sx_acl_id_t_p_value(acl_id_p)
        print("Created MACSEC acl with ID [0x%x] (region_id:0x%x , dir:%s)" % (acl_id, region_id, direction))

        return acl_id
    finally:
        delete_sx_acl_id_t_p(acl_id_p)
        delete_sx_acl_region_group_t_p(acl_region_group_p)


def macsec_acl_destroy(handle, acl_id):
    '''
    Destroys ACL

    Parameters
    ----------
    @handle - SDK handle.

    @acl_id - ID of an existing ACL

    Changes made:
    - Improved names
    '''
    acl_id_p = new_sx_acl_id_t_p()
    try:
        print("Destroying ACL {}".format(acl_id))

        cmd = SX_ACCESS_CMD_DESTROY
        direction = 0
        sx_acl_id_t_p_assign(acl_id_p, acl_id)
        acl_region_group_p = None
        _acl_set(handle, cmd, SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC, direction, acl_region_group_p, acl_id_p)
    finally:
        delete_sx_acl_id_t_p(acl_id_p)


def macsec_acl_attr_set(handle, acl_id, log_port):
    '''
    SET  ACL Attributes

    Parameters
    ----------
    @handle - SDK handle.
    @param acl_id: The ACL id whose attributes to set/modify
    @param acl_drop_trap_en: Enable/Disable Trapping packets dropped by ACL
    @param acl_name: String Name Description of ACL
    '''
    acl_attr = sx_acl_attributes_t()

    acl_attr.macsec_attr.log_port_valid = True
    acl_attr.macsec_attr.log_port = log_port
    cmd = SX_ACCESS_CMD_SET
    rc = sx_api_acl_attributes_set(handle, cmd, acl_id, acl_attr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_attributes_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print("Added macsec_attr log_port %d to MACSEC acl with ID [0x%x]" % (log_port, acl_id))


def macsec_acl_attr_get(handle, acl_id):
    '''
    GET  ACL Attributes

    Parameters
    ----------
    @handle - SDK handle.
    @param acl_id: The ACL id whose attributes to get
    @return acl_drop_trap_en: Enable/Disable Trapping packets dropped by ACL
    @return acl_name: String Name Description of ACL
    '''
    acl_name = ""
    acl_drop_trap_en = False

    acl_attr_p = new_sx_acl_attributes_t_p()
    try:
        rc = sx_api_acl_attributes_get(handle, acl_id, acl_attr_p)
        if rc != expected_rc:
            assert rc == SX_STATUS_SUCCESS, "sx_api_acl_attributes_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

        acl_attr = sx_acl_attributes_t_p_value(acl_attr_p)

        if acl_attr.macsec_attr.log_port_valid:
            print("ACL id %d attr log_port [ 0x%x ]" % (acl_id, acl_attr.macsec_attr.log_port))
        else:
            print("ACL id %d doesn't have macsec attr" % (acl_id))

        return acl_attr.macsec_attr.log_port
    finally:
        delete_sx_acl_attributes_t_p(acl_attr_p)

# ACL port bind


def _acl_port_bind_set(handle, cmd, port, group_id):
    rc = sx_api_acl_port_bind_set(handle,
                                  cmd,
                                  port,
                                  group_id)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind/unbind ACL i0x%x to/from port 0x%x. [%s(%d)]" % (group_id, port, sx_status_dict[rc], rc)


def _acl_port_bind_get(handle, port, dir, acl_id_p):
    rc = sx_api_acl_port_bind_get(handle, port, dir, acl_id_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to get bind/unbind ACL to port [%s(%d)]" % (sx_status_dict[rc], rc)
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Port {} is bound to ACL 0x{:x}".format(port, acl_id))


def macsec_acl_port_bind(handle, port, acl_id):
    '''
    Bind existing ACL group to port

    *New method
    '''
    cmd = SX_ACCESS_CMD_BIND
    _acl_port_bind_set(handle, cmd, port, acl_id)
    print("ACL id 0x%x was bounded to port 0x%x" % (acl_id, port))


def macsec_acl_port_unbind(handle, port, acl_id):
    '''
    Unbind an existing ACL group from port
    This method will remove ALL user bindings of
    the given group direction

    *New method
    '''
    cmd = SX_ACCESS_CMD_UNBIND
    _acl_port_bind_set(handle, cmd, port, acl_id)
    print("ACL id 0x%x was unbounded from port 0x%x" % (acl_id, port))

#############################################################################################################
#          ACL Rules
#############################################################################################################


def acl_rules_init(key_handle_id, rules_count, actions_count):
    '''
    Initialize ACL rules, before setting rules in SDK

    Parameters
    ----------
    @key_handle_id - ID of key handle

    @rules_count - Number of rules to initialize.

    @actions_count - Number of maximum actions per rule

    Changes made:
    - Improved names
    - Signature changed, not getting rules and rules_list
    - removed call for check_sdk_rc
    '''
    initialize_rules = []
    rule_p = new_sx_flex_acl_flex_rule_t_p()
    try:
        for i in range(rules_count):
            rule = sx_flex_acl_flex_rule_t()
            sx_flex_acl_flex_rule_t_p_assign(rule_p, rule)
            rc = sx_lib_flex_acl_rule_init(key_handle_id, actions_count, rule_p)
            assert rc == SX_STATUS_SUCCESS, "Failed to sx_lib_flex_acl_rule_init [%s(%d)]" % (sx_status_dict[rc], rc)
            initialize_rules.append(sx_flex_acl_flex_rule_t_p_value(rule_p))
        return initialize_rules
    finally:
        delete_sx_flex_acl_flex_rule_t_p(rule_p)

# rules deinit


def acl_rules_deinit(rule_list):
    '''
    Deinitialize ACL rules

    Parameters
    ----------
    @rule_list - SDK ACL rules
    '''
    for rule in rule_list:
        rc = sx_lib_flex_acl_rule_deinit(rule)
        assert rc == SX_STATUS_SUCCESS, "Failed to sx_lib_flex_acl_rule_deinit [%s(%d)]" % (sx_status_dict[rc], rc)
        # check_rc(rc, SdkException('Failed to deinitialize ACL rule', rc))


def acl_rules_delete(handle, region_id, rules_data, start_offset=None):
    """Delete several ACL rules. See acl_rules_set
    Args:
        handle (int): SDK handle
        region_id (): ACL region id
        rules_data (list): list of dictionaries
        start_offset (int): if provided will be incremented for each rule. If
          it is None then each rule should have it's own offset key

    Raises: SdkException

    """

    offsets_list = new_sx_acl_rule_offset_t_arr(len(rules_data))
    try:
        rule_arr_index = 0
        common_offset = start_offset if start_offset else 0

        if start_offset and any(["offset" in r for r in rules_data]):
            raise SdkException("Start offset is provided for list of rules, but "
                               "some of rule objects have their own offset key")

        for rule_arr_index, rule_data in enumerate(rules_data):
            rule_offset = rule_data["offset"] if "offset" in rule_data \
                else common_offset

            sx_acl_rule_offset_t_arr_setitem(offsets_list,
                                             rule_arr_index,
                                             rule_offset + rule_arr_index)

        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_DELETE,
                                       region_id,
                                       offsets_list,
                                       None,
                                       len(rules_data))

        # assert rc == SX_STATUS_SUCCESS, "Failed to sx_lib_flex_acl_rule_deinit [%s(%d)]" % (sx_status_dict[rc], rc)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete ACL rule from region 0x%x, offset %d. rc = %d" % (region_id, offsets_list, rc)
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)


def acl_rule_set(handle, region_id, rule, offset, key_list, action_list, rule_valid=True):
    " this function sets rule in acl region"
    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    rules_list = new_sx_flex_acl_flex_rule_t_arr(1)
    try:
        rule.valid = rule_valid
        for i, action in enumerate(action_list):
            sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, i, action)
        rule.action_count = len(action_list)
        print("region id[0x%x],offset:[%d] actions len[%d] key len[%d]" % (
            region_id, offset, len(action_list), len(key_list)))

        for i, key_desc in enumerate(key_list):
            sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, i, key_desc)
        rule.key_desc_count = len(key_list)

        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)

        sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rule)

        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rules_list,
                                       1)

        assert rc == SX_STATUS_SUCCESS, 'Failed to set ACL rule in region 0x%x at offset %d. rc = %d' % (region_id, offsets_list, rc)
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)
        delete_sx_flex_acl_flex_rule_t_arr(rules_list)


def macsec_acl_rule_set(handle, key_handle, region_id, offset, key, key_val, action_type, action_data):
    rules = acl_rules_init(key_handle, 100, 20)

    key_desc = sx_flex_acl_key_desc_t()
    if key == "FLEX_ACL_KEY_MACSEC_ETHERTYPE":
        key_desc.key_id = FLEX_ACL_KEY_MACSEC_ETHERTYPE
        key_desc.key.macsec_ethertype = key_val
        key_desc.mask.macsec_ethertype = 0xFFFF

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_MACSEC_ACTION_FORWARD
    if action_type == "FORWARD":
        action1.fields.macsec_action_forward.action = SX_MACSEC_ACL_FORWARD_ACTION_TYPE_FORWARD
    if action_type == "DISCARD":
        action1.fields.macsec_action_forward.action = SX_MACSEC_ACL_FORWARD_ACTION_TYPE_DISCARD
    if action_type == "BYPASS":
        action1.fields.macsec_action_forward.action = SX_MACSEC_ACL_FORWARD_ACTION_TYPE_BYPASS

    action1.fields.macsec_action_forward.flow_obj_id = action_data

    acl_rule_set(handle, region_id, rules[0], offset, [key_desc], [action1])

    acl_rules_deinit(rules)


def macsec_acl_rule_delete(handle, region_id, offset):
    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    try:
        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_DELETE,
                                       region_id,
                                       offsets_list,
                                       None,
                                       1)

        assert rc == SX_STATUS_SUCCESS, 'Failed to delete ACL rule region 0x%x offset %d' % (rc)
        # assert rc == SX_STATUS_SUCCESS,'Failed to set ACL rule', rc), [expected_rc])
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)


#############################################################################################################
#          SA
#############################################################################################################
def macsec_sa_obj_get(handle, sa_id):
    macsec_sa_obj_id = sa_id
    macsec_sa_attr_p = new_sx_macsec_sa_attribute_t_p()
    rc = sx_api_macsec_sa_obj_get(handle, SX_ACCESS_CMD_GET, macsec_sa_obj_id, macsec_sa_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sa_obj_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    macsec_sa_attr = sx_macsec_sa_attribute_t_p_value(macsec_sa_attr_p)
    print("SA obj ID[0x%x]" % (macsec_sa_attr.sa_obj_id))
    print("Associated SC obj ID[0x%x]" % (macsec_sa_attr.sc_obj_id))
    print("Protocol assigned SA ID[0x%x]" % (macsec_sa_attr.sa_id))
    print("Packet num [0x%x]" % (macsec_sa_attr.packet_num))
    print("SSCI  [0x%x]" % (macsec_sa_attr.ssci))


def macsec_sa_obj_remove(handle, sa_id):
    macsec_sa_obj_id_p = new_sx_macsec_sa_obj_id_t_p()
    sx_macsec_sa_obj_id_t_p_assign(macsec_sa_obj_id_p, sa_id)
    rc = sx_api_macsec_sa_obj_set(handle, SX_ACCESS_CMD_DELETE, None, macsec_sa_obj_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sa_obj_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print("Deleted SA object with ID [0x%x]" % (sa_id))


def get_iterator_access_cmd(cmd):
    if cmd == "get":
        access_cmd = SX_ACCESS_CMD_GET
    elif cmd == "first":
        access_cmd = SX_ACCESS_CMD_GET_FIRST
    elif cmd == "getnext":
        access_cmd = SX_ACCESS_CMD_GETNEXT
    else:
        raise Exception("Iterator command is not valid")
    return access_cmd


def macsec_flow_obj_iter(handle, cmd, flow_id, direction, port, count):
    access_cmd = get_iterator_access_cmd(cmd)
    if access_cmd == SX_ACCESS_CMD_GET or access_cmd == SX_ACCESS_CMD_GETNEXT:
        if flow_id is None:
            raise Exception("Valid flow object ID is needed")
    flow_filter = sx_macsec_flow_filter_t()
    if direction is not None:
        if direction == 'ingress':
            flow_filter.direction = SX_MACSEC_DIR_INGRESS_E
        elif direction == 'egress':
            flow_filter.direction = SX_MACSEC_DIR_EGRESS_E
        flow_filter.filter_by_dir = SX_KEY_FILTER_FIELD_VALID
    else:
        flow_filter.filter_by_dir = SX_KEY_FILTER_FIELD_NOT_VALID

    if port is not None:
        flow_filter.log_port = port
        flow_filter.filter_by_port = SX_KEY_FILTER_FIELD_VALID

    macsec_flow_attr_list_p = new_sx_macsec_flow_attribute_t_arr(count)
    macsec_flow_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(macsec_flow_cnt_p, count)
    flow_filter_p = new_sx_macsec_flow_filter_t_p()
    sx_macsec_flow_filter_t_p_assign(flow_filter_p, flow_filter)

    rc = sx_api_macsec_flow_obj_iter_get(handle, access_cmd, flow_id, flow_filter_p, macsec_flow_attr_list_p, macsec_flow_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_iter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    count = uint32_t_p_value(macsec_flow_cnt_p)
    for i in range(count):
        macsec_flow_attr = sx_macsec_flow_attribute_t_arr_getitem(macsec_flow_attr_list_p, i)
        print("Idx [%d] Flow obj ID[0x%x]" % (i, macsec_flow_attr.flow_obj_id))
        print("Idx [%d] Flow obj direction[%d]" % (i, macsec_flow_attr.direction))
        print("Idx [%d] Flow obj port[0x%x]" % (i, macsec_flow_attr.log_port))


def macsec_sc_obj_iter(handle, cmd, sc_id, direction, flow_obj, count):
    access_cmd = get_iterator_access_cmd(cmd)
    if access_cmd == SX_ACCESS_CMD_GET or access_cmd == SX_ACCESS_CMD_GETNEXT:
        if sc_id is None:
            raise Exception("Valid SC object ID is needed")
    sc_filter = sx_macsec_sc_filter_t()
    if direction is not None:
        if direction == 'ingress':
            sc_filter.direction = SX_MACSEC_DIR_INGRESS_E
        elif direction == 'egress':
            sc_filter.direction = SX_MACSEC_DIR_EGRESS_E
        sc_filter.filter_by_dir = SX_KEY_FILTER_FIELD_VALID
    else:
        sc_filter.filter_by_dir = SX_KEY_FILTER_FIELD_NOT_VALID

    if flow_obj != SX_MACSEC_FLOW_OBJ_ID_INVALID:
        sc_filter.flow_obj_id = flow_obj
        sc_filter.filter_by_flow = SX_KEY_FILTER_FIELD_VALID

    macsec_sc_attr_list_p = new_sx_macsec_sc_attribute_t_arr(count)
    macsec_sc_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(macsec_sc_cnt_p, count)
    sc_filter_p = new_sx_macsec_sc_filter_t_p()
    sx_macsec_sc_filter_t_p_assign(sc_filter_p, sc_filter)

    rc = sx_api_macsec_sc_obj_iter_get(handle, access_cmd, sc_id, sc_filter_p, macsec_sc_attr_list_p, macsec_sc_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sc_obj_iter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    count = uint32_t_p_value(macsec_sc_cnt_p)
    for i in range(count):
        macsec_sc_attr = sx_macsec_sc_attribute_t_arr_getitem(macsec_sc_attr_list_p, i)
        print("Idx [%d] SC obj ID[0x%x]" % (i, macsec_sc_attr.sc_obj_id))
        print("Idx [%d] Associated Flow obj ID[0x%x]" % (i, macsec_sc_attr.flow_obj_id))
        print("Idx [%d] Protocol assigned SC ID[0x%x]" % (i, macsec_sc_attr.sc_profile.sc_id))
        print("Idx [%d] SC Cipher suite [0x%x]" % (i, macsec_sc_attr.sc_profile.sc_cipher_suite))


def macsec_sa_obj_iter(handle, cmd, sa_id, direction, sc_obj, count):
    access_cmd = get_iterator_access_cmd(cmd)
    if access_cmd == SX_ACCESS_CMD_GET or access_cmd == SX_ACCESS_CMD_GETNEXT:
        if sa_id is None:
            raise Exception("Valid SA object ID is needed")
    sa_filter = sx_macsec_sa_filter_t()
    if direction is not None:
        if direction == 'ingress':
            sa_filter.direction = SX_MACSEC_DIR_INGRESS_E
        elif direction == 'egress':
            sa_filter.direction = SX_MACSEC_DIR_EGRESS_E
        sa_filter.filter_by_dir = SX_KEY_FILTER_FIELD_VALID
    else:
        sa_filter.filter_by_dir = SX_KEY_FILTER_FIELD_NOT_VALID

    if sc_obj != SX_MACSEC_SC_OBJ_ID_INVALID:
        sa_filter.sc_obj_id = sc_obj
        sa_filter.filter_by_sc = SX_KEY_FILTER_FIELD_VALID

    macsec_sa_attr_list_p = new_sx_macsec_sa_attribute_t_arr(count)
    macsec_sa_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(macsec_sa_cnt_p, count)
    sa_filter_p = new_sx_macsec_sa_filter_t_p()
    sx_macsec_sa_filter_t_p_assign(sa_filter_p, sa_filter)

    rc = sx_api_macsec_sa_obj_iter_get(handle, access_cmd, sa_id, sa_filter_p, macsec_sa_attr_list_p, macsec_sa_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sa_obj_iter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    count = uint32_t_p_value(macsec_sa_cnt_p)
    for i in range(count):
        macsec_sa_attr = sx_macsec_sa_attribute_t_arr_getitem(macsec_sa_attr_list_p, i)
        print("Idx [%d] SA obj ID[0x%x]" % (i, macsec_sa_attr.sa_obj_id))
        print("Idx [%d] Associated SC obj ID[0x%x]" % (i, macsec_sa_attr.sc_obj_id))
        print("Idx [%d] Protocol assigned SA ID[0x%x]" % (i, macsec_sa_attr.sa_id))
        print("Idx [%d] Packet num [0x%x]" % (i, macsec_sa_attr.packet_num))
        print("Idx [%d] SSCI  [0x%x]" % (i, macsec_sa_attr.ssci))


__event_str_to_event = {
    'acl_id_0': SX_MACSEC_EVENT_ACL_ID_0_E,
    'acl_id_1': SX_MACSEC_EVENT_ACL_ID_1_E,
    'acl_id_2': SX_MACSEC_EVENT_ACL_ID_2_E,
    'acl_id_3': SX_MACSEC_EVENT_ACL_ID_3_E,
    'acl_id_4': SX_MACSEC_EVENT_ACL_ID_4_E,
    'acl_id_5': SX_MACSEC_EVENT_ACL_ID_5_E,
    'acl_id_6': SX_MACSEC_EVENT_ACL_ID_6_E,
    'acl_id_7': SX_MACSEC_EVENT_ACL_ID_7_E,
    'acl_id_8': SX_MACSEC_EVENT_ACL_ID_8_E,
    'acl_id_9': SX_MACSEC_EVENT_ACL_ID_9_E,
    'acl_id_10': SX_MACSEC_EVENT_ACL_ID_10_E,
    'acl_id_11': SX_MACSEC_EVENT_ACL_ID_11_E,
    'acl_id_12': SX_MACSEC_EVENT_ACL_ID_12_E,
    'acl_id_13': SX_MACSEC_EVENT_ACL_ID_13_E,
    'acl_id_14': SX_MACSEC_EVENT_ACL_ID_14_E,
    'acl_id_15': SX_MACSEC_EVENT_ACL_ID_15_E,
    'ingress_mtu': SX_MACSEC_EVENT_INGRESS_MTU_E,
    'tag_allow': SX_MACSEC_EVENT_TAG_ALLOW_E,
    'no_sectag': SX_MACSEC_EVENT_NO_SECTAG_E,
    'sectag_error': SX_MACSEC_EVENT_SECTAG_ERROR_E,
    'encrypt_error': SX_MACSEC_EVENT_ENCRYPT_ERROR_E
}


def get_event_str_to_event(event_str):
    return __event_str_to_event[event_str]


__action_str_to_action = {
    'forward': SX_MACSEC_EVENT_ACTION_FORWARD,
    'bypass': SX_MACSEC_EVENT_ACTION_BYPASS,
    'discard': SX_MACSEC_EVENT_ACTION_DISCARD,
    'trap_discard': SX_MACSEC_EVENT_ACTION_TRAP_DISCARD,
    'trap_bypass': SX_MACSEC_EVENT_ACTION_TRAP_BYPASS
}


def get_action_str_to_action(action_str):
    return __action_str_to_action[action_str]


def macsec_events_get(handle, events_info_list):
    events_str = get_enum_string_dict('SX_MACSEC_EVENT_')
    actions_str = get_enum_string_dict('SX_MACSEC_EVENT_ACTION_')
    dir_str = get_enum_string_dict('SX_MACSEC_DIR_')

    macsec_event_list_len = len(events_info_list)
    macsec_event_key_arr = new_sx_macsec_event_key_t_arr(macsec_event_list_len)
    macsec_event_attr_arr = new_sx_macsec_event_attr_t_arr(macsec_event_list_len)
    for idx, (event, direction) in enumerate(events_info_list):
        macsec_events_key_item = sx_macsec_event_key_t()
        macsec_events_key_item.event_id = get_event_str_to_event(event)
        macsec_events_key_item.direction = direction
        sx_macsec_event_key_t_arr_setitem(macsec_event_key_arr, idx, macsec_events_key_item)

    rc = sx_api_macsec_events_get(handle, macsec_event_list_len, macsec_event_key_arr, macsec_event_attr_arr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_events_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    for i in range(macsec_event_list_len):
        macsec_event_attr = sx_macsec_event_attr_t_arr_getitem(macsec_event_attr_arr, i)
        macsec_event_key = sx_macsec_event_key_t_arr_getitem(macsec_event_key_arr, i)
        print("Event [%s], Direction [%s], Action [%s]" % (events_str[macsec_event_key.event_id], dir_str[macsec_event_key.direction], actions_str[macsec_event_attr.action]))


def macsec_events_set(handle, events_info_list):
    macsec_event_list_len = len(events_info_list)
    macsec_event_key_arr = new_sx_macsec_event_key_t_arr(macsec_event_list_len)
    macsec_event_attr_arr = new_sx_macsec_event_attr_t_arr(macsec_event_list_len)
    for idx, (event, direction, action) in enumerate(events_info_list):
        macsec_events_key_item = sx_macsec_event_key_t()
        macsec_events_key_item.event_id = get_event_str_to_event(event)
        macsec_events_key_item.direction = direction
        sx_macsec_event_key_t_arr_setitem(macsec_event_key_arr, idx, macsec_events_key_item)
        macsec_events_attr_item = sx_macsec_event_attr_t()
        macsec_events_attr_item.action = get_action_str_to_action(action)
        sx_macsec_event_attr_t_arr_setitem(macsec_event_attr_arr, idx, macsec_events_attr_item)

    rc = sx_api_macsec_events_set(handle, macsec_event_list_len, macsec_event_key_arr, macsec_event_attr_arr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_events_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)


def read_macsec_sa_counter(handle, cmd, sa_list):
    list_size = len(sa_list)
    list_size_p = new_uint32_t_p()
    uint32_t_p_assign(list_size_p, list_size)
    macsec_cntr_key_list_arr = new_sx_macsec_counter_key_t_arr(list_size)
    macsec_cntr_val_list_arr = new_sx_macsec_counter_t_arr(list_size)
    for idx, sa in enumerate(sa_list):
        macsec_cntr_key_item = sx_macsec_counter_key_t()
        macsec_cntr_key_item.type = SX_MACSEC_CNTR_SA_GROUP_E
        macsec_cntr_key_item.key.sa_grp.sa_obj_id = sa

        sx_macsec_counter_key_t_arr_setitem(macsec_cntr_key_list_arr, idx, macsec_cntr_key_item)

        macsec_cntr_val_list = sx_macsec_counter_t()
        macsec_cntr_val_list.type = SX_MACSEC_CNTR_SA_GROUP_E
        sx_macsec_counter_t_arr_setitem(macsec_cntr_val_list_arr, idx, macsec_cntr_val_list)

    rc = sx_api_macsec_counters_get(handle, cmd, macsec_cntr_key_list_arr, list_size, macsec_cntr_val_list_arr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_counters_get failed for SA Counter Group. [%s(%d)]" % (sx_status_dict[rc], rc)

    for i in range(list_size):
        macsec_cntr_val_list = sx_macsec_counter_t_arr_getitem(macsec_cntr_val_list_arr, i)

        print("====================================================================================")
        print("SA Obj Id : {}".format(hex(macsec_cntr_val_list.data.sa_grp.key.sa_obj_id)))
        print("in_pkts_unchecked: {}".format(macsec_cntr_val_list.data.sa_grp.stats.in_pkts_unchecked))
        print("in_pkts_late: {}".format(macsec_cntr_val_list.data.sa_grp.stats.in_pkts_late))
        print("in_pkts_ok: {}".format(macsec_cntr_val_list.data.sa_grp.stats.in_pkts_ok))
        print("in_pkts_not_valid: {}".format(macsec_cntr_val_list.data.sa_grp.stats.in_pkts_not_valid))
        print("====================================================================================")


def read_macsec_port_counter(handle, cmd, port, port_group):

    macsec_cntr_key_item = sx_macsec_counter_key_t()
    macsec_cntr_val_list = sx_macsec_counter_t()
    if port_group == 0:
        macsec_cntr_key_item.type = SX_MACSEC_CNTR_PORT_GROUP0_E
        macsec_cntr_key_item.key.port_grp0.log_port = port
        macsec_cntr_val_list.type = SX_MACSEC_CNTR_PORT_GROUP0_E
    else:
        macsec_cntr_key_item.type = SX_MACSEC_CNTR_PORT_GROUP1_E
        macsec_cntr_key_item.key.port_grp1.log_port = port
        macsec_cntr_val_list.type = SX_MACSEC_CNTR_PORT_GROUP1_E

    macsec_cntr_key_list_arr = new_sx_macsec_counter_key_t_arr(1)
    sx_macsec_counter_key_t_arr_setitem(macsec_cntr_key_list_arr, 0, macsec_cntr_key_item)

    macsec_cntr_val_list_arr = new_sx_macsec_counter_t_arr(1)
    sx_macsec_counter_t_arr_setitem(macsec_cntr_val_list_arr, 0, macsec_cntr_val_list)

    rc = sx_api_macsec_counters_get(handle, cmd, macsec_cntr_key_list_arr, 1, macsec_cntr_val_list_arr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_counters_get failed for Port-Group%d Counter Group. [%s(%d)]" % (port_group, sx_status_dict[rc], rc)
    macsec_cntr_val_list = sx_macsec_counter_t_arr_getitem(macsec_cntr_val_list_arr, 0)

    print("====================================================================================")
    print("Log Port: 0x{} - Group: {}".format(hex(port), port_group))
    if port_group == 0:
        print("in_pkts_mtu: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_pkts_mtu))
        print("in_pkts_general: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_pkts_general))
        print("in_pn_overflow: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_pn_overflow))
        print("in_pause_pfc: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_pause_pfc))
        print("in_eapol: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_eapol))
        print("in_buffer_overflow: {}".format(macsec_cntr_val_list.data.port_grp0.stats.in_buffer_overflow))
        print("out_pkts_general: {}".format(macsec_cntr_val_list.data.port_grp0.stats.out_pkts_general))
        print("out_pn_overflow: {}".format(macsec_cntr_val_list.data.port_grp0.stats.out_pn_overflow))
        print("out_pause_pfc: {}".format(macsec_cntr_val_list.data.port_grp0.stats.out_pause_pfc))
        print("out_eapol: {}".format(macsec_cntr_val_list.data.port_grp0.stats.out_eapol))
    else:
        print("in_pkts_untagged: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_untagged))
        print("in_pkts_notag: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_notag))
        print("in_pkts_bad_tag: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_bad_tag))
        print("in_pkts_no_sa_rcv: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_no_sa_rcv))
        print("in_pkts_no_sa_discard: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_no_sa_discard))
        print("in_octets_validated: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_octets_validated))
        print("in_octets_decrypted: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_octets_decrypted))
        print("in_pkts_too_long: {}".format(macsec_cntr_val_list.data.port_grp1.stats.in_pkts_too_long))
        print("out_pkts_untagged: {}".format(macsec_cntr_val_list.data.port_grp1.stats.out_pkts_untagged))
        print("out_pkts_too_long: {}".format(macsec_cntr_val_list.data.port_grp1.stats.out_pkts_too_long))
        print("out_octets_protected: {}".format(macsec_cntr_val_list.data.port_grp1.stats.out_octets_protected))
        print("out_octets_encrypted: {}".format(macsec_cntr_val_list.data.port_grp1.stats.out_octets_encrypted))
    print("====================================================================================")


def read_macsec_utrap_counter(handle, cmd, port, direction):

    macsec_cntr_key_item = sx_macsec_counter_key_t()
    macsec_cntr_val_list = sx_macsec_counter_t()

    macsec_cntr_key_item.type = SX_MACSEC_CNTR_UTRAP_GROUP_E
    macsec_cntr_key_item.key.utrap_grp.log_port = port
    macsec_cntr_key_item.key.utrap_grp.dir = direction
    macsec_cntr_val_list.type = SX_MACSEC_CNTR_UTRAP_GROUP_E

    macsec_cntr_key_list_arr = new_sx_macsec_counter_key_t_arr(1)
    sx_macsec_counter_key_t_arr_setitem(macsec_cntr_key_list_arr, 0, macsec_cntr_key_item)

    macsec_cntr_val_list_arr = new_sx_macsec_counter_t_arr(1)
    sx_macsec_counter_t_arr_setitem(macsec_cntr_val_list_arr, 0, macsec_cntr_val_list)

    rc = sx_api_macsec_counters_get(handle, cmd, macsec_cntr_key_list_arr, 1, macsec_cntr_val_list_arr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_counters_get failed for UTrap Counter Group. [%s(%d)]" % (sx_status_dict[rc], rc)
    macsec_cntr_val_list = sx_macsec_counter_t_arr_getitem(macsec_cntr_val_list_arr, 0)
    dir_dict = get_enum_string_dict('SX_MACSEC_DIR_')
    print("====================================================================================")
    print("Log Port: {} - Direction: {}".format(hex(port), dir_dict[direction]))
    print("utrap_fifo_dropped: {}".format(macsec_cntr_val_list.data.utrap_grp.stats.utrap_fifo_dropped))
    print("====================================================================================")


def macsec_acl_cntr_get(handle, cmd, cntr_obj_list):
    macsec_cntr_list_len = len(cntr_obj_list)
    macsec_cntr_obj_list_arr = new_sx_macsec_acl_counter_id_t_arr(macsec_cntr_list_len)
    macsec_cntr_set_list_arr = new_sx_macsec_acl_counter_set_t_arr(macsec_cntr_list_len)

    for idx, counter_obj in enumerate(cntr_obj_list):
        sx_macsec_acl_counter_id_t_arr_setitem(macsec_cntr_obj_list_arr, idx, counter_obj)

    rc = sx_api_macsec_acl_counter_get(handle, cmd, macsec_cntr_obj_list_arr, macsec_cntr_set_list_arr, macsec_cntr_list_len)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_acl_counter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    for idx, counter_obj in enumerate(cntr_obj_list):
        counter_obj = sx_macsec_acl_counter_id_t_arr_getitem(macsec_cntr_obj_list_arr, idx)
        counter_val = sx_macsec_acl_counter_set_t_arr_getitem(macsec_cntr_set_list_arr, idx)
        print("counter obj:0x%x , counter_value:0x%x" % (counter_obj, counter_val.packets_counter))


def macsec_acl_cntr_set(handle, cmd, log_port, direction, cntr_obj_id):
    counter_obj_p = new_sx_macsec_acl_counter_id_t_p()
    if cmd == SX_ACCESS_CMD_DESTROY:
        sx_macsec_acl_counter_id_t_p_assign(counter_obj_p, cntr_obj_id)

    rc = sx_api_macsec_acl_counter_set(handle, cmd, log_port, direction, counter_obj_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_acl_counter_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    if cmd == SX_ACCESS_CMD_CREATE:
        cntr_obj_id = sx_macsec_acl_counter_id_t_p_value(counter_obj_p)
        print("Created counter object 0x%x" % (cntr_obj_id))


def print_help():
    print("""Example :\n
            sx_macsec_mgr.py --operation logging --verbosity error
            sx_macsec_mgr.py --operation init --scope global
            sx_macsec_mgr.py --operation init --scope port --log_port 0x1000d
            sx_macsec_mgr.py --operation deinit --scope port --log_port 0x1000d
            sx_macsec_mgr.py --operation deinit --scope global
            sx_macsec_mgr.py --create flow --log_port 0x1000d --dir ingress
            sx_macsec_mgr.py --create sc --flow_obj 0x22000d0001 --sc_id 1 --cipher SX_MACSEC_CIPHER_TYPE_GCM_AES_128  --sci_enable 1 --replay_protect 1 --protect_win_sz 100 --confid_offset 30 --disable_encryption 0
            sx_macsec_mgr.py --create sa --sc_obj 0x12000d0001 --sa_id 1 --sak "@#$%" --packet_num 2000 --ssci 1 --counter_id 0x0
            sx_macsec_mgr.py --remove flow --flow_obj_id <flow-obj-id>
            sx_macsec_mgr.py --remove sc --sc_obj_id <sc-obj-id>
            sx_macsec_mgr.py --remove sa --sa_obj_id <sa-obj-id>
            sx_macsec_mgr.py --query flow --flow_obj_id <flow_obj_id>
            sx_macsec_mgr.py --query sc --sc_obj_id <sc-obj-id>
            sx_macsec_mgr.py --query sa --sa_obj_id <sa-obj-id>
            sx_macsec_mgr.py --query capab --log_port 0x1000d
            sx_macsec_mgr.py --iter_get flow --iter_cmd get --flow_obj_id 0x22000d0001
            sx_macsec_mgr.py --iter_get flow --iter_cmd first --count 5
            sx_macsec_mgr.py --iter_get flow --iter_cmd getnext --flow_obj_id 0x22000d0001 --count 5
            sx_macsec_mgr.py --iter_get sc --iter_cmd get --sc_obj_id 0x12000d0001
            sx_macsec_mgr.py --iter_get sc --iter_cmd first --count 5
            sx_macsec_mgr.py --iter_get sc --iter_cmd getnext --sc_obj_id 0x12000d0001 --count 5
            sx_macsec_mgr.py --iter_get sa --iter_cmd get --sa_obj_id 0xa000d0001
            sx_macsec_mgr.py --iter_get sa --iter_cmd first --count 5
            sx_macsec_mgr.py --iter_get sa --iter_cmd getnext --sa_obj_id 0xa000d0001 --count 5
            sx_macsec_mgr.py --cntr_grp sa --cntr_cmd <'read', read_clear'> --sa_obj_id <sa-obj-id>
            sx_macsec_mgr.py --cntr_grp port --cntr_cmd <'read', read_clear'> --log_port 0x1000d --port_grp <0,1>
            sx_macsec_mgr.py --cntr_grp utrap --cntr_cmd <'read', read_clear'> --log_port 0x1000d --dir <'ingress','egress'>
            sx_macsec_mgr.py --events set --event <'ingress_mtu', 'tag_allow', 'no_sectag', 'sectag_error', 'encrypt_error', 'acl_id_0'> --dir ingress --action <'forward','bypass','discard','trap_discard', 'trap_bypass'>
            sx_macsec_mgr.py --events get --event <'ingress_mtu', 'tag_allow', 'no_sectag', 'sectag_error', 'encrypt_error', 'acl_id_0'> --dir ingress
            sx_macsec_mgr.py --acl_cntr get --cntr_cmd read --counter_id 0x6000d0001
            sx_macsec_mgr.py --acl_cntr get --cntr_cmd read_clear --counter_id 0x6000d0001
            sx_macsec_mgr.py --acl_cntr set --cntr_cmd create --log_port 0x1000d --direction ingress
            sx_macsec_mgr.py --acl_cntr set --cntr_cmd destroy --counter_id 0x6000d0001

            ACL flow example:
	    sx_macsec_mgr.py --operation init --scope global
            sx_macsec_mgr.py --operation init --scope port --log_port 0x1000d
            sx_macsec_mgr.py --create acl_key --key_list "FLEX_ACL_KEY_MACSEC_ETHERTYPE"
            sx_macsec_mgr.py --create acl_region --key_handle 0x40010002 --size 16
            sx_macsec_mgr.py --create acl_table --region_id 0x40002 --direction ingress
            sx_macsec_mgr.py --add acl_attr --acl_id 0x4000002 --log_port 0x1000d
            sx_macsec_mgr.py --add acl_bind --acl_id 0x4000002 --log_port 0x1000d
            sx_macsec_mgr.py --add acl_rule --key_handle 0x40010002 --region_id 0x40002 --offset 0 --key_list FLEX_ACL_KEY_MACSEC_ETHERTYPE --key_val 0x800 --action_type DISCARD  --action_data 0
            sx_macsec_mgr.py --delete acl_rule --region_id 0x40002 --offset 0
            sx_macsec_mgr.py --delete acl_bind --acl_id 0x4000002 --log_port 0x1000d
            sx_macsec_mgr.py --remove acl_table --acl_id 0x4000002
            sx_macsec_mgr.py --remove acl_region --region_id 0x40002
            sx_macsec_mgr.py --remove acl_key --key_handle 0x40010002

            """)


def parse_args():
    parser = argparse.ArgumentParser(description='MAC Security Manager')
    parser.add_argument('--operation', '-o', choices=['logging', 'init', 'deinit'], help="MACSec operations")
    parser.add_argument('--verbosity', '-v', dest='verbosity', choices=list(log_verbosity_level.keys()), default=MACSEC_DEFAULT_VERBOSITY, help='Log Verbosity Level')
    parser.add_argument('--scope', '-s', dest='scope', choices=['global', 'port'], default='global', help='MACSec Init scope')
    parser.add_argument('--log_port', '-p', dest='port', default="", help='Logical port for MACSec operation')
    parser.add_argument('--query', '-q', choices=['capab', 'flow', 'sc', 'sa'], help='Query MACSec entity')
    parser.add_argument('--iter_get', '-iter', choices=['flow', 'sc', 'sa'], help='Iterator get MACSec entity')
    parser.add_argument('--create', '-c', choices=['flow', 'sc', 'sa', 'acl_key', 'acl_region', 'acl_table'], help='Create MACSec entity')
    parser.add_argument('--remove', '-r', choices=['flow', 'sc', 'sa', 'acl_key', 'acl_region', 'acl_table'], help='Destroy MACSec entity')
    parser.add_argument('--add', '-add', choices=['acl_attr', 'acl_rule', 'acl_bind'], help='Add MACSec entity')
    parser.add_argument('--delete', '-del', choices=['acl_rule', 'acl_bind'], help='Delete MACSec entity')
    parser.add_argument('--direction', '-d', choices=['ingress', 'egress'], default="", help='Traffic direction')
    parser.add_argument('--key_list', '-kl', choices=['FLEX_ACL_KEY_MACSEC_DMAC', 'FLEX_ACL_KEY_MACSEC_ETHERTYPE', 'FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID', 'FLEX_ACL_KEY_MACSEC_SCI', 'FLEX_ACL_KEY_MACSEC_AN'], default="", help='MACSEC ACL key list')
    parser.add_argument('--sc_id', '-sc', dest='sc_id', default="", help='Protocol assigned SC ID')
    parser.add_argument('--cipher', '-cph', dest='cipher', choices=['SX_MACSEC_CIPHER_TYPE_GCM_AES_128', 'SX_MACSEC_CIPHER_TYPE_GCM_AES_256', 'SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_128', 'SX_MACSEC_CIPHER_TYPE_GCM_AES_XPN_256'], help='Cipher Suite')
    parser.add_argument('--sci_enable', '-e', dest='sci_enable', default="", help='SCI enable')
    parser.add_argument('--disable_encryption', '-dis_e', dest='disable_encryption', default="0", help='disable Encryption')
    parser.add_argument('--confid_offset', '-co', dest='confid_offset', default="0", help='Confidentiality offset')
    parser.add_argument('--replay_protect', '-rp', dest='replay_protect', default="0", help='Enable replay protection')
    parser.add_argument('--protect_win_sz', '-w', dest='win_size', default="0", help='Protection window size')
    parser.add_argument('--sa_id', '-sa', dest='sa_id', default="", help='Protocol assigned SA ID')
    parser.add_argument('--sak', '-key', dest='sak', default="", help='SA key')
    parser.add_argument('--ssci', '-ssc', dest='ssci', default="", help='Short secure channel Identifier')
    parser.add_argument('--salt', '-salt', dest='salt', default="", help='Salt')
    parser.add_argument('--counter_id', '-cntr', dest='counter_id', default="", help='Counter Id')
    parser.add_argument('--packet_num', '-pnum', dest='packet_num', default="", help='Packet number')
    parser.add_argument('--iter_cmd', '-iter_cmd', choices=['get', 'first', 'getnext'], help='Query MACSec entity iterator commands')
    parser.add_argument('--flow_obj_id', '-f', dest='flow_obj_id', default="", help='Flow obj for SC iterator filter')
    parser.add_argument('--sc_obj_id', '-sco', dest='sc_obj_id', default="", help='SC object id')
    parser.add_argument('--sa_obj_id', '-sao', dest='sa_obj_id', default="", help='SA object id')
    parser.add_argument('--count', '-cnt', dest='count', default="1", help='count of objects to fetch')
    parser.add_argument('--cntr_grp', '-cgrp', choices=['sa', 'port', 'utrap'], help='Specify MACSec counter group to read')
    parser.add_argument('--cntr_cmd', '-ccmd', choices=['read', 'read_clear', 'create', 'destroy'], default='read', help='Counter cmd')
    parser.add_argument('--port_grp', '-pgrp', dest='port_grp', choices=['0', '1'], default='0', help='Port Counter Sub Group to read')
    parser.add_argument('--events_op', '-evop', choices=['get', 'set'], help='Query/Set MACSec events action')
    parser.add_argument('--event', '-ev', choices=['ingress_mtu', 'tag_allow', 'no_sectag', 'sectag_error', 'encrypt_error', 'acl_id_0'], help='Event Id')
    parser.add_argument('--action', '-ev_action', choices=['forward', 'bypass', 'discard', 'trap_discard', 'trap_bypass'], default="", help='Event Action')
    parser.add_argument('--acl_cntr', '-cntr_op', choices=['get', 'set'], help='Query/Set MACSec ACL counter')
    parser.add_argument('--key_handle', '-kh', dest='key_handle', default="1", help='MACSEC ACL key handle')
    parser.add_argument('--size', '-sz', dest='size', default="1", help='MACSEC ACL region size')
    parser.add_argument('--region_id', '-reg_id', dest='region_id', default="1", help='MACSEC ACL region id')
    parser.add_argument('--acl_id', '-acl_id', dest='acl_id', default="1", help='MACSEC ACL id')

    parser.add_argument('--offset', '-off', dest='offset', default="0", help='MACSEC ACL rule offset')
    parser.add_argument('--key_val', '-kv', dest='key_val', default="0", help='MACSEC ACL rule key value')
    parser.add_argument('--action_type', '-at', dest='action_type', default="0", help='MACSEC ACL rule action type')
    parser.add_argument('--action_data', '-ad', dest='action_data', default="0", help='MACSEC ACL rule action data')

    try:
        args = parser.parse_args()
    except SystemExit:
        print("\n\n")
        print_help()
        exit()

    return args


def handle_macsec_operation(handle, args):
    op = args.operation
    try:
        if op == 'logging':
            log_level = args.verbosity
            macsec_verbosity_set(handle, log_verbosity_level[log_level])
            return 0

        elif op == 'init':
            scope = args.scope
            if scope == 'global':
                macsec_init_set(handle)
            else:
                port = int(args.port, 16)
                macsec_port_init_set(handle, port)
            return 0

        elif op == 'deinit':
            scope = args.scope
            if scope == 'global':
                macsec_deinit_set(handle)
            else:
                port = int(args.port, 16)
                macsec_port_deinit_set(handle, port)
            return 0

    except Exception as e:
        logging.error("MACSec operation %s failed with exception %s" % (op, str(e)))
        return 1


def handle_macsec_events_operation(handle, args):
    events_op = args.events_op
    direction_args = args.direction

    if direction_args == 'ingress':
        direction = SX_MACSEC_DIR_INGRESS_E
    elif direction_args == 'egress':
        direction = SX_MACSEC_DIR_EGRESS_E
    else:
        raise Exception("MACSec direction attribute is not correct")

    if args.event == "":
        raise Exception("MACSec event attribute is not correct")
    try:
        if events_op == 'get':
            macsec_events_get(handle, [(args.event, direction)])
            return 0

        elif events_op == 'set':
            if args.action == '':
                raise Exception("MACSec event action attribute is not correct")
            macsec_events_set(handle, [(args.event, direction, args.action)])
            return 0

    except Exception as e:
        logging.error("MACSec operation %s failed with exception %s" % (events_op, str(e)))
        return 1


def handle_macsec_query(handle, args):
    entity = args.query
    try:
        if entity == 'capab':
            port = int(args.port, 16)
            macsec_port_capability_get(handle, port)
        if entity == 'flow':
            flow_id = int(args.flow_obj_id, 16)
            macsec_flow_obj_get(handle, flow_id)
        if entity == 'sc':
            sc_id = int(args.sc_obj_id, 16)
            macsec_sc_obj_get(handle, sc_id)
        if entity == 'sa':
            sa_id = int(args.sa_obj_id, 16)
            macsec_sa_obj_get(handle, sa_id)
    except Exception as e:
        logging.error("MACSec operation query failed with exception %s" % (str(e)))
        return 1


def handle_macsec_create(handle, args):
    entity = args.create
    try:
        if entity == 'flow':
            port = int(args.port, 16)
            direction = args.direction
            macsec_flow_obj_create(handle, port, direction)
        if entity == 'sc':
            flow_id = int(args.flow_obj_id, 16)
            sc_id = int(args.sc_id, 10)
            cipher = (args.cipher)
            sci_enable = int(args.sci_enable, 10)
            confid_offset = int(args.confid_offset, 10)
            replay_protect = int(args.replay_protect, 10)
            win_sz = int(args.win_size, 10)
            disable_encryption = int(args.disable_encryption, 10)
            macsec_sc_obj_create(handle, flow_id, sc_id, cipher, sci_enable, confid_offset, replay_protect, win_sz, disable_encryption)
        if entity == 'sa':
            sc_id = int(args.sc_obj_id, 16)
            sa_id = int(args.sa_id, 10)
            sak = args.sak
            packet_num = int(args.packet_num, 10)
            ssci = int(args.ssci, 10)
            salt = args.salt
            if args.counter_id is not None:
                counter_id = int(args.counter_id, 16)
            else:
                counter_id = 0
            macsec_sa_obj_create(handle, sc_id, sa_id, sak, packet_num, ssci, salt, counter_id)
        if entity == 'acl_key':
            key_list = [args.key_list]
            macsec_acl_key_handle_create(handle, key_list)
        if entity == 'acl_region':
            key_handle = int(args.key_handle, 16)
            size = int(args.size, 10)
            macsec_acl_region_create(handle, key_handle, size)
        if entity == 'acl_table':
            region_id = int(args.region_id, 16)
            direction = args.direction
            macsec_acl_create(handle, region_id, direction)

    except Exception as e:
        logging.error("MACSec operation create failed with exception %s" % (str(e)))
        return 1

    return 0


def handle_macsec_remove(handle, args):
    entity = args.remove
    try:
        if entity == 'flow':
            flow_id = int(args.flow_obj_id, 16)
            macsec_flow_obj_remove(handle, flow_id)
        if entity == 'sc':
            sc_id = int(args.sc_obj_id, 16)
            macsec_sc_obj_remove(handle, sc_id)
        if entity == 'sa':
            sa_id = int(args.sa_obj_id, 16)
            macsec_sa_obj_remove(handle, sa_id)
        if entity == 'acl_key':
            key_handle = int(args.key_handle, 16)
            macsec_acl_key_handle_remove(handle, key_handle)
        if entity == 'acl_region':
            region_id = int(args.region_id, 16)
            macsec_acl_region_remove(handle, region_id)
        if entity == 'acl_table':
            acl_id = int(args.acl_id, 16)
            macsec_acl_destroy(handle, acl_id)
    except Exception as e:
        logging.error("MACSec operation remove failed with exception %s" % (str(e)))
        return 1


def handle_macsec_add(handle, args):
    entity = args.add
    try:
        if entity == 'acl_rule':
            key_handle = int(args.key_handle, 16)
            region_id = int(args.region_id, 16)
            offset = int(args.offset, 10)
            key = args.key_list
            key_val = eval(args.key_val)  # can read hex and decimal
            action_type = args.action_type
            action_data = eval(args.action_data)
            macsec_acl_rule_set(handle, key_handle, region_id, offset, key, key_val, action_type, action_data)
        if entity == 'acl_attr':
            acl_id = int(args.acl_id, 16)
            log_port = int(args.port, 16)
            macsec_acl_attr_set(handle, acl_id, log_port)
        if entity == 'acl_bind':
            acl_id = int(args.acl_id, 16)
            log_port = int(args.port, 16)
            macsec_acl_port_bind(handle, log_port, acl_id)

    except Exception as e:
        logging.error("MACSec operation ADD failed with exception %s" % (str(e)))
        return 1

    return 0


def handle_macsec_delete(handle, args):
    entity = args.delete
    try:
        if entity == 'acl_rule':
            region_id = int(args.region_id, 16)
            offset = int(args.offset, 10)
            macsec_acl_rule_delete(handle, region_id, offset)
        if entity == 'acl_bind':
            acl_id = int(args.acl_id, 16)
            log_port = int(args.port, 16)
            macsec_acl_port_unbind(handle, log_port, acl_id)
    except Exception as e:
        logging.error("MACSec operation DELETE failed with exception %s" % (str(e)))
        return 1

    return 0


def handle_macsec_iter(handle, args):
    entity = args.iter_get
    cmd = args.iter_cmd
    if args.count is None:
        count = 1
    else:
        count = int(args.count, 10)

    try:
        if entity == 'flow':
            dir = None
            port = None
            if args.flow_obj_id != '':
                flow_id = int(args.flow_obj_id, 16)
            else:
                flow_id = SX_MACSEC_FLOW_OBJ_ID_INVALID
            if args.direction != '':
                dir = args.direction
            if args.port != '':
                port = int(args.port, 16)
            macsec_flow_obj_iter(handle, cmd, flow_id, dir, port, count)

        if entity == 'sc':
            dir = None
            if args.sc_obj_id != '':
                sc_id = int(args.sc_obj_id, 16)
            else:
                sc_id = SX_MACSEC_SC_OBJ_ID_INVALID
            if args.direction != '':
                dir = args.direction
            if args.flow_obj_id != '':
                flow_obj_id = int(args.flow_obj_id, 16)
            else:
                flow_obj_id = SX_MACSEC_FLOW_OBJ_ID_INVALID
            macsec_sc_obj_iter(handle, cmd, sc_id, dir, flow_obj_id, count)

        if entity == 'sa':
            sa_id = None
            sc_obj = None
            dir = None
            if args.sa_obj_id != '':
                sa_id = int(args.sa_obj_id, 16)
            else:
                sa_id = SX_MACSEC_SA_OBJ_ID_INVALID
            if args.direction != '':
                dir = args.direction
            if args.sc_obj_id != '':
                sc_obj_id = int(args.sc_obj_id, 16)
            else:
                sc_obj_id = SX_MACSEC_SC_OBJ_ID_INVALID
            macsec_sa_obj_iter(handle, cmd, sa_id, dir, sc_obj_id, count)

    except Exception as e:
        logging.error("MACSec iterator failed with exception %s" % (str(e)))
        return 1


def handle_macsec_cntr_read(handle, args):
    cntr_group = args.cntr_grp
    cmd = args.cntr_cmd
    if cmd == "read":
        access_cmd = SX_ACCESS_CMD_READ
    else:
        access_cmd = SX_ACCESS_CMD_READ_CLEAR

    try:
        if cntr_group == 'sa':
            if args.sa_obj_id is None:
                raise Exception("SA obj Id not given for SA Counter Group ")
            else:
                sa_id = int(args.sa_obj_id, 16)
                sa_id_list = [sa_id]
            read_macsec_sa_counter(handle, access_cmd, sa_id_list)
        elif cntr_group == 'port':
            if args.port is None:
                raise Exception("Log_port not given for Port Counter Group ")
            else:
                port = int(args.port, 16)

            port_group = int(args.port_grp)
            read_macsec_port_counter(handle, access_cmd, port, port_group)

        elif cntr_group == 'utrap':
            if args.port is None:
                raise Exception("Log_port not given for UTrap Counter Group ")
            else:
                port = int(args.port, 16)
            if args.direction is None:
                raise Exception("Direction not given for UTrap Counter Group ")
            else:
                if args.direction == 'ingress':
                    dir = SX_MACSEC_DIR_INGRESS_E
                else:
                    dir = SX_MACSEC_DIR_EGRESS_E
            read_macsec_utrap_counter(handle, access_cmd, port, dir)
        else:
            raise Exception("Counter command is not valid")

    except Exception as e:
        logging.error("MACSec Counter Read failed with exception %s" % (str(e)))
        return 1


def handle_macsec_acl_cntr_operation(handle, args):
    cntr_op = args.acl_cntr
    try:
        if cntr_op == "get":
            cmd = args.cntr_cmd
            if cmd == "read":
                access_cmd = SX_ACCESS_CMD_READ
            else:
                access_cmd = SX_ACCESS_CMD_READ_CLEAR
            if args.counter_id is None:
                raise Exception("Counter object  not given for Counter read")
            else:
                counter_id = int(args.counter_id, 16)
            macsec_acl_cntr_get(handle, access_cmd, [counter_id])
        else:
            if cntr_op == "set":
                cmd = args.cntr_cmd
                if cmd == "create":
                    access_cmd = SX_ACCESS_CMD_CREATE
                else:
                    access_cmd = SX_ACCESS_CMD_DESTROY

                if access_cmd == SX_ACCESS_CMD_CREATE:
                    if args.port is None:
                        raise Exception("Log_port not given for Counter Create")
                    else:
                        port = int(args.port, 16)
                    if args.direction is None:
                        raise Exception("Direction not given for UTrap Counter Create")
                    else:
                        if args.direction == 'ingress':
                            dir = SX_MACSEC_DIR_INGRESS_E
                        else:
                            dir = SX_MACSEC_DIR_EGRESS_E
                    counter_id = None
                else:
                    port = 0
                    dir = SX_MACSEC_DIR_INGRESS_E
                    if args.counter_id is None:
                        raise Exception("Counter object  not given for Counter destroy")
                    else:
                        counter_id = int(args.counter_id, 16)

            macsec_acl_cntr_set(handle, access_cmd, port, dir, counter_id)
    except Exception as e:
        logging.error("MACSec Counter operation failed with exception %s" % (str(e)))


def macsec_ops(handle, args):
    if args.operation:
        return handle_macsec_operation(handle, args)
    elif args.query:
        return handle_macsec_query(handle, args)
    elif args.create:
        return handle_macsec_create(handle, args)
    elif args.remove:
        return handle_macsec_remove(handle, args)
    elif args.iter_get:
        return handle_macsec_iter(handle, args)
    elif args.cntr_grp:
        return handle_macsec_cntr_read(handle, args)
    elif args.events_op:
        return handle_macsec_events_operation(handle, args)
    elif args.acl_cntr:
        return handle_macsec_acl_cntr_operation(handle, args)
    elif args.add:
        return handle_macsec_add(handle, args)
    elif args.delete:
        return handle_macsec_delete(handle, args)
    else:
        print("\n\n")
        print_help()
        exit()


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    logging.info("[+] opening sdk")
    rc, handle = sx_api_open(None)
    logging.debug("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print("MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

    args = parse_args()

    rc = macsec_ops(handle, args)

    sx_api_close(handle)

    if rc:
        sys.exit(1)
    else:
        logging.info("%s operation completed successfully \n", args.operation)
