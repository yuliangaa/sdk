#!/usr/bin/env python

import sys
import time
import os
import argparse
from test_infra_common import auto_int
from python_sdk_api.sxd_api import *


print("[+] SBHPC register access Example Test start")


parser = argparse.ArgumentParser(description='SBHPC example')
parser.add_argument('--size', default=0, type=auto_int, help="Buffer size, if given a write will be performed")
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init failed, rc: %d" % (rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

sbhpc = ku_sbhpc_reg()

if args.size:
    if args.deinit:
        original_sbhpc = ku_sbhpc_reg()
        rc = sxd_access_reg_sbhpc(original_sbhpc, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to read SBHPC register, rc: %d" % (rc)

    print("[+] Set SBHPC size %d" % (args.size))
    sbhpc.max_buff = args.size
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_sbhpc(sbhpc, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set SBHPC register, rc: %d" % (rc)
    print("[+] Set SBHPC Done")

    if args.deinit:
        print("Deinit")
        meta.access_cmd = SXD_ACCESS_CMD_SET
        rc = sxd_access_reg_sbhpc(original_sbhpc, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set SBHPC register, rc: %d" % (rc)

print("[+] Get SBHPC")
rc = sxd_access_reg_sbhpc(sbhpc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read SBHPC register, rc: %d" % (rc)

print("[+] SBHPC content")
print("====================")
print("[+] sbhpc.max_buff: ", sbhpc.max_buff)
print("[+] sbhpc.buff_occupancy: ", sbhpc.buff_occupancy)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] SBHPC register access example test end")
