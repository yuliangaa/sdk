#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
from flex_acl_common import *


def dump_all(handle):
    acl_list = acl_get_all(handle, is_macsec=True)

    region_set = print_macsec_acls(handle, acl_id_cnt, acl_id_list)

    region_list = sorted(region_set)
    acl_rule_header_printed = False
    for i in range(0, len(region_list)):
        if not acl_rule_header_printed:
            print_region_rules_header()
            acl_rule_header_printed = True

        region_id = region_list[i]
        print_region_rules(handle, region_id)

    binding_map = {}
    get_all_macsec_port_bindings(handle, binding_map)

    print_macsec_acl_bindings_header()
    for key in list(binding_map.keys()):
        print_macsec_acl_binding(key, binding_map)


def check_macsec_init_status(handle):
    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print(" MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("MACSec module is not initialized")
            sys.exit()
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


parser = argparse.ArgumentParser(description='MACSEC ACL dump utility.')
parser.add_argument('--log_port', default=0, type=auto_int, help='Optional Logical port ID, when provided only bindings to this port will be dumped')
args = parser.parse_args()

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
check_macsec_init_status(handle)

acl_id_cnt, acl_id_list = acl_get_all(handle, is_macsec=True)
if len(sys.argv) == 1:
    dump_all(handle)
    exit(0)
else:
    if args.log_port != 0:
        binding_map = {}
        get_port_lag_bindings(handle, args.log_port, binding_map)
        '''
        for acl_id in binding_map:
            if acl_id in acl_id_list:
                region_set = print_acl_groups(handle, 1, [acl_id], prev_group_dict, next_group_dict)
                region_list = sorted(region_set)
                print_region_rules_header()
                for i in range(0, len(region_list)):
                    region_id = region_list[i]
                    print_region_rules(handle, region_id)
        '''
        if len(binding_map):
            print_acl_bindings_header()
        for acl_id in binding_map:
            print_acl_binding(acl_id, binding_map)
