#!/usr/bin/env python
'''
This file contains python based "What just happened" monitor agent for processing commands send by the WJH tool client.
The agent is started by executing the wjh_dump.py --enable/--enablex commands. The WJH agent processes the following commands from client
1. 'e' : Agent initializes the WJH trap group(63) and registers normal trap ids upon receiving 'e' over socket.
2. 'x' : Agent initializes the WJH trap group(63) and registers extended trapids upon receiving 'x' over socket.
3. 'c' : Agent  counts the number of packet in WJH queue and sends the reply over socket to client upon receiving 'c' from client.
4. 's' : Agent saves the WJH trapped packets in /tmp/wjh_<%Y%m%d-%H%M%S> and sends the file name to client in reply.
5. 'f' : Agent flushes the WJH queue and sends the confirmation over socket to client upon receiving 'f' over socket.
6. 'd' : Agent closes the WJH host interface(fd), changes action to DISCARD upon receving 'd' over socket.
This is supported on Spectrum devices.
'''
import time
import socket
import signal
from python_sdk_api.sx_api import *
import python_sdk_api.sx_api as sx_api
from test_infra_common import *
######################################################
#    defines
######################################################
# Using the upper end of trap group ID.
WJH_TRAP_GRP = 63
# Priority for WJH TRAP GROUP - Low
WJH_TRAP_PRIORITY = 0
WJH_SOCKET_BUFFER_SIZE = 1024
WJH_MONITOR_SERVER_PORT = 10000
WJH_MAX_PKT_SIZE = 10000
WJH_FILE_NAME = "/tmp/wjh_dump_"
WJH_SERVER_LISTEN_QUEUE_SIZE = 1
WJH_CMD_MONITOR_ENABLE = 'e'
WJH_CMD_MONITOR_ENABLEX = 'x'
WJH_CMD_MONITOR_DISABLE = 'd'
WJH_CMD_COUNT_PACKETS = 'c'
WJH_CMD_SAVE_PACKETS = 's'
WJH_CMD_FLUSH_PACKETS = 'f'
WJH_CMD_QUERY_STATUS = 'q'

WJH_CMD_TRAP_GROUP_MODE_AUTO = 'a'
WJH_CMD_TRAP_GROUP_MODE_STATIC = 's'
WJH_CMD_TRAP_GROUP_MODE_DYNAMIC = 'd'


SPECTRUM_SWID = 0
dest_port_type_dict = {0: 'INVALID', 1: 'MULTI_PORT', 2: 'NETWORK_PORT', 4: 'LAG_PORT'}

# Registered trap ID mode - Normal or Extended
mode = "Normal"
# ignore trapid list
per_chip_ignore_trap_id_dict = {
    SX_CHIP_TYPE_SPECTRUM: [SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0, SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0],
    SX_CHIP_TYPE_SPECTRUM2: [SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0, SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0],
    SX_CHIP_TYPE_SPECTRUM3: [SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0, SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0],
    SX_CHIP_TYPE_SPECTRUM4: [],
    SX_CHIP_TYPE_SPECTRUM5: []
}
# Trap Id dictionary <trapid, TrapId string>
trap_id_dict = {}
# Treap ID analyze dictionary < trapid , analyze_trapid>
discard_trap_id_handler_dict = {}
# Registed trap id list
reg_trap_id_list = []
# sdk handle
handle = None
# host ifc handle
fd_p = None

trap_group_set_cmd, trap_group_unset_cmd = None, None


def del_dict_duplicate_values(dict):
    for key in list(dict.keys()):
        if key.endswith("_MIN"):
            del dict[key]
        if key.endswith("_MAX"):
            del dict[key]
        if key.endswith("_FIRST"):
            del dict[key]
        if key.endswith("_LAST"):
            del dict[key]
    return dict


def sx_api_get_enums_from_prefix(prefix):
    sx_api_str_enum_dict = {}
    for item in dir(sx_api):
        if item.startswith(prefix):
            sx_api_str_enum_dict[item] = getattr(sx_api, item)
    return sx_api_str_enum_dict


def analyze_DISCARD_ING_PACKET_SMAC_MC(fd, recv_info_p, pkt_size_p, pkt):
    iii = 6
    fd.write("Discard reason: SMAC is MC %02x:%02x:%02x:%02x:%02x:%02x" %
             (uint8_t_arr_getitem(pkt, iii),
              uint8_t_arr_getitem(pkt, iii + 1),
              uint8_t_arr_getitem(pkt, iii + 2),
              uint8_t_arr_getitem(pkt, iii + 3),
              uint8_t_arr_getitem(pkt, iii + 4),
              uint8_t_arr_getitem(pkt, iii + 5)))


def analyze_DISCARD_ING_PACKET_SMAC_DMAC(fd, recv_info_p, pkt_size_p, pkt):
    iii = 0
    fd.write("Discard reason: SMAC = DMAC = %02x:%02x:%02x:%02x:%02x:%02x" %
             (uint8_t_arr_getitem(pkt, iii),
              uint8_t_arr_getitem(pkt, iii + 1),
              uint8_t_arr_getitem(pkt, iii + 2),
              uint8_t_arr_getitem(pkt, iii + 3),
              uint8_t_arr_getitem(pkt, iii + 4),
              uint8_t_arr_getitem(pkt, iii + 5)))


def analyze_DISCARD_ING_PACKET_SMAC0(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason: SMAC is Zero (00:00:00:00:00:00)")


def analyze_DISCARD_ING_PACKET_RSV_MAC(fd, recv_info_p, pkt_size_p, pkt):
    iii = 0
    fd.write("Discard reason: Reserved DMAC (01:80:c2:00:00:0x): %02x:%02x:%02x:%02x:%02x:%02x" %
             (uint8_t_arr_getitem(pkt, iii),
              uint8_t_arr_getitem(pkt, iii + 1),
              uint8_t_arr_getitem(pkt, iii + 2),
              uint8_t_arr_getitem(pkt, iii + 3),
              uint8_t_arr_getitem(pkt, iii + 4),
              uint8_t_arr_getitem(pkt, iii + 5)))


def analyze_DISCARD_ING_SWITCH_VTAG_ALLOW(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason vlan tag allow")


def analyze_DISCARD_ING_SWITCH_VLAN(fd, recv_info_p, pkt_size_p, pkt):
    iii = 14
    vlan_id = ((uint8_t_arr_getitem(pkt, iii) << 8) + (uint8_t_arr_getitem(pkt, iii + 1))) & 0xFFF
    # sx_api_vlan_ports_get
    fd.write("Discard reason: ingress vlan filter, pkt vlan: %d" %
             (vlan_id))


mstp_state_dict = {
    SX_MSTP_INST_PORT_STATE_DISCARDING: "DISCARDING",
    SX_MSTP_INST_PORT_STATE_LEARNING: "LEARNING",
    SX_MSTP_INST_PORT_STATE_FORWARDING: "FORWARDING"
}

mstp_mode_dict = {
    SX_MSTP_MODE_MSTP: "MSTP",
    SX_MSTP_MODE_RSTP: "RSTP"
}


def analyze_DISCARD_ING_SWITCH_STP(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason: ingress STP filter")

    mstp_mode_p = new_sx_mstp_mode_t_p()
    sx_api_mstp_mode_get(handle, 0, mstp_mode_p)
    mstp_mode = sx_mstp_mode_t_p_value(mstp_mode_p)
    fd.write("MSTP mode: %s" % mstp_mode_dict[mstp_mode])
    if mstp_mode == SX_MSTP_MODE_RSTP:
        rstp_port_state_p = new_sx_mstp_inst_port_state_t_p()
        log_port = recv_info_p.source_log_port
        sx_api_rstp_port_state_get(handle, log_port, rstp_port_state_p)
        rstp_port_state = sx_mstp_inst_port_state_t_p_value(rstp_port_state_p)
        fd.write("Logport 0x%x RSTP state: %s" % (log_port, mstp_state_dict[rstp_port_state]))


def analyze_DISCARD_LOOKUP_SWITCH_UC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  eth uc fdb filter (fdb discard)")


def analyze_DISCARD_LOOKUP_SWITCH_MC_NULL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  eth mc fdb filter (tx list is empty)")


def analyze_DISCARD_LOOKUP_SWITCH_LB(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  eth loopback filter")


def analyze_DISCARD_LOOKUP_SWITCH_NO_PORTS(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  eth not allowed port (tx list becomes empty)")


def analyze_DISCARD_ING_ROUTER_NO_HDR(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  packet to router is not ip/mpls/arp (no ip header)")


def analyze_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  uc dip over mc or bc dmac")


def analyze_DISCARD_ING_ROUTER_DIP_LB(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  dip is loopback address, ipv4 127.0.0.0 , ipv6 ::1/128 or 0:0:0:0:0:ffff:7f00:0/104")


def analyze_DISCARD_ING_ROUTER_SIP_MC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  sip is mc")


def analyze_DISCARD_ING_ROUTER_SIP_CLASS_E(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  sip is in class e")


def analyze_DISCARD_ING_ROUTER_SIP_LB(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  sip is loopback, ipv4 127.0.0.0 , ipv6 ::1/128")


def analyze_DISCARD_ING_ROUTER_SIP_UNSP(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  sip is unspecified, ipv4 sip == 0.0.0.0/32")


def analyze_DISCARD_ING_ROUTER_IP_HDR(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ip header not okay, due to header checksum or IPver or IPv4 IHL too short")


def analyze_DISCARD_ING_ROUTER_MC_DMAC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mc mac mismatch, DMAC isn't according MC DIP ")


def analyze_DISCARD_ING_ROUTER_SIP_DIP(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  sip equal dip")


def analyze_DISCARD_ING_ROUTER_SIP_BC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ipv4 sip is limited broadcast, sip == 255.255.255.255")


def analyze_DISCARD_ING_ROUTER_DIP_LOCAL_NET(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ipv4 dip is local network, dip = 0.0.0.0/8")


def analyze_DISCARD_ING_ROUTER_DIP_LINK_LOCAL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ipv4 uc dip is link local, dip=169.254.0.0/16")


def analyze_DISCARD_ING_LSR_NO_LABEL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  outer label is not valid")


def analyze_DISCARD_ING_LSR_UC_ET(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mpls uc Ethertype (0x8847) over mc or bc mac")


def analyze_DISCARD_ING_LSR_MC_DMAC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mpls mc Ethertype (0x8848) over not allowed, dmac != 01-00-5e-8x-xx-xx")


def analyze_DISCARD_ROUTER_IRIF_EN(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  disabled irif")


def analyze_DISCARD_ROUTER_ERIF_EN(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  disabled_erif")


def analyze_DISCARD_ROUTER_ERIF_FWD(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  disable erif forwarding")


def analyze_DISCARD_ROUTER_LPM4(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  lpm no route uc ipv4")


def analyze_DISCARD_ROUTER_LPM6(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  lpm no route uc ipv6")


def analyze_DISCARD_LSR_MIN_LABEL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mpls min ingress label allowed (label too low)")


def analyze_DISCARD_LSR_MAX_LABEL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mpls max ingress label allowed (label too high)")


def analyze_DISCARD_LSR_LB(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  mpls loopback filter")


def analyze_DISCARD_DEC_PKT(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  decap failed due to packet (pkt after decap is too short)")


def analyze_DISCARD_DEC_NVE_OPTIONS(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  decap failed due to packet (pkt after decap has non-zero reserved bits)")


def analyze_DISCARD_DEC_DIS(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  nve decap disable (due to TNGCR.type)")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC_MC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  overlay switch : smac is multicast")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC_DMAC(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  overlay switch : smac eqauls dmac")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC0(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  overlay switch : smac is zero")


def analyze_DISCARD_EGR_LSR_NO_LABEL(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  MPLS prevent sending MPLS packet with no labels available")


def analyze_DISCARD_EGR_LSR_NO_IP(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  Expected IP version after mpls decap")


def analyze_DISCARD_EGR_LSR_PHP_NO_IP(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  php decap and no ip header")


def analyze_DISCARD_MC_SCOPE_IPV6_0(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ipv6_mc_scope_0, dip = FFx0:/16")


def analyze_DISCARD_MC_SCOPE_IPV6_1(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  ipv6_mc_scope_1, dip = FFx1:/16")


def file_write_pkt_info(fd, recv_info_p, pkt_size_p, pkt, idx):
    pkt_size = pkt_size_p

    fd.write("=" * 50)
    fd.write("\nRead packet from index %d\n" % (idx))

    trap_name = "Unknown"
    if recv_info_p.trap_id in discard_trap_id_handler_dict:
        trap_name = trap_id_dict[recv_info_p.trap_id]

    fd.write("TRAP_ID:%s(%d,0x%x), PKT_SZ:%d, S_IS_LAG:%d, S_LOGPORT:0x%x, D_PORT_TYPE:%s, D_LOGPORT:0x%x\n" %
             (trap_name, recv_info_p.trap_id, recv_info_p.trap_id, pkt_size, recv_info_p.is_lag, recv_info_p.source_log_port,
              dest_port_type_dict[recv_info_p.dest_port_type], recv_info_p.dest_lag_port))
    fd.write("Packet TimeStamp: %s + %u nsecs\n" % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(recv_info_p.timestamp.tv_sec)),
                                                    recv_info_p.timestamp.tv_nsec))

    fd.write("Packet content:\n")
    if (pkt_size > 0):
        for iii in range(0, pkt_size):
            if (0 == iii % 8):
                fd.write("%02x %02x %02x %02x %02x %02x %02x %02x \n" %
                         (uint8_t_arr_getitem(pkt, iii),
                          uint8_t_arr_getitem(pkt, iii + 1),
                          uint8_t_arr_getitem(pkt, iii + 2),
                          uint8_t_arr_getitem(pkt, iii + 3),
                          uint8_t_arr_getitem(pkt, iii + 4),
                          uint8_t_arr_getitem(pkt, iii + 5),
                          uint8_t_arr_getitem(pkt, iii + 6),
                          uint8_t_arr_getitem(pkt, iii + 7)))
    if recv_info_p.trap_id in discard_trap_id_handler_dict:
        try:
            discard_trap_handler = discard_trap_id_handler_dict[recv_info_p.trap_id]
            # invoke the analyzer with parameters
            eval(discard_trap_handler + '(fd, recv_info_p, pkt_size_p, pkt)')
            fd.write("\n")
        except (NameError, KeyError) as error:
            pass
        except Exception:
            print('Analysis failure')


def sx_recv_multi_count(fd_p):
    pkt_info_arr_len_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_info_arr_len_p, 0)

    rc = sx_lib_host_ifc_recv_list(fd_p, None, pkt_info_arr_len_p)
    if rc != 0:
        delete_uint32_t_p(pkt_info_arr_len_p)
        return (rc, "WJH packet dump utility - Failed to count the discarded packets")
    else:
        pkt_info_arr_len = uint32_t_p_value(pkt_info_arr_len_p)
        delete_uint32_t_p(pkt_info_arr_len_p)
        return (rc, "WJH packet dump utility - %d packets in queue" % (pkt_info_arr_len))


def sx_recv_multi_flush(fd_p):
    # Flush the WJH Queue
    rc = sx_lib_host_ifc_recv_list(fd_p, None, None)
    if rc != 0:
        return (rc, "WJH packet dump utility - Flush failed")
    else:
        return (rc, "WJH packet dump utility - Flush succeeded")


def clr_wjh_pkt_buffer(pkt_info_arr, pkt_arr, wjh_rcv_list_size):
    for i in range(wjh_rcv_list_size):
        delete_uint8_t_arr(pkt_arr[i])
    delete_sx_packet_info_t_arr(pkt_info_arr)


def sx_recv_multi(fd_p):
    global mode
    global trap_id_dict
    global reg_trap_id_list

    # get packet count
    pkt_info_arr_len_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_info_arr_len_p, 0)
    rc = sx_lib_host_ifc_recv_list(fd_p, None, pkt_info_arr_len_p)
    if rc != 0:
        delete_uint32_t_p(pkt_info_arr_len_p)
        return (rc, "WJH packet dump utility - Dump failed")

    # prepare the array to receive packet
    pkt_info_arr_len = uint32_t_p_value(pkt_info_arr_len_p)
    wjh_rcv_list_size = pkt_info_arr_len
    pkt_info_arr = new_sx_packet_info_t_arr(pkt_info_arr_len)
    pkt_arr = []

    for i in range(0, pkt_info_arr_len):
        pkt = new_uint8_t_arr(WJH_MAX_PKT_SIZE)
        pkt_info = sx_packet_info_t()
        pkt_info.packet_p = pkt
        pkt_info.packet_size = WJH_MAX_PKT_SIZE
        pkt_arr.append(pkt)
        sx_packet_info_t_arr_setitem(pkt_info_arr, i, pkt_info)

    rc = sx_lib_host_ifc_recv_list(fd_p, pkt_info_arr, pkt_info_arr_len_p)
    if rc != 0:
        # free memory for pkt and receive info array
        clr_wjh_pkt_buffer(pkt_info_arr, pkt_arr, wjh_rcv_list_size)
        return (rc, "WJH packet dump utility - Dump failed")

    pkt_info_arr_len = uint32_t_p_value(pkt_info_arr_len_p)

    pkt_info = sx_packet_info_t()
    recv_info_p = sx_receive_info_t()

    # open the file and write the content
    file_name = WJH_FILE_NAME + time.strftime("%Y%m%d-%H%M%S")
    with open(file_name, "w+")as fd:

        fd.write("Registered Trap ID's - Mode %s\n" % (mode))
        fd.write("=" * 50)
        fd.write("\n")

        sorted_trap_id_list = sorted(reg_trap_id_list)
        for i in range(len(sorted_trap_id_list)):
            fd.write("%s\n" % (trap_id_dict[sorted_trap_id_list[i]]))

        if pkt_info_arr_len == 0:
            # free memory for pkt and receive info array
            clr_wjh_pkt_buffer(pkt_info_arr, pkt_arr, wjh_rcv_list_size)
            fd.write("=" * 50)
            fd.close()
            return (rc, "WJH packet dump utility - No Discarded packets seen, Registered traps saved in %s" % file_name)

        for i in range(pkt_info_arr_len):
            pkt_info = sx_packet_info_t_arr_getitem(pkt_info_arr, i)
            recv_info_p = pkt_info.receive_info
            file_write_pkt_info(fd, recv_info_p, pkt_info.packet_size, pkt_arr[i], i)

        # free memory for pkt and receive info array
        clr_wjh_pkt_buffer(pkt_info_arr, pkt_arr, wjh_rcv_list_size)

        fd.write("=" * 50)
        fd.close()
    return (rc, "WJH packet dump utility - Saved %d packets to file %s" % (pkt_info_arr_len, file_name))


def wjh_is_trap_id_registered(handle, trap_id):
    user_channel_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(user_channel_cnt_p, 0)
    rc = sx_api_host_ifc_trap_id_register_get(handle, SX_ACCESS_CMD_GET, SPECTRUM_SWID, trap_id, None, None, user_channel_cnt_p)
    if rc == SX_STATUS_SUCCESS:
        user_channel_cnt = uint32_t_p_value(user_channel_cnt_p)
        delete_uint32_t_p(user_channel_cnt_p)
        if user_channel_cnt:
            return True
        else:
            return False
    else:
        return False


def wjh_get_trap_id_fds(handle, trap_id):
    user_channel_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(user_channel_cnt_p, 0)
    rc = sx_api_host_ifc_trap_id_register_get(handle, SX_ACCESS_CMD_GET, SPECTRUM_SWID, trap_id, None, None, user_channel_cnt_p)
    if rc == SX_STATUS_SUCCESS:
        user_channel_cnt = uint32_t_p_value(user_channel_cnt_p)
        if user_channel_cnt:
            user_channel_list_p = new_sx_user_channel_t_arr(user_channel_cnt)
            rc = sx_api_host_ifc_trap_id_register_get(handle, SX_ACCESS_CMD_GET, SPECTRUM_SWID, trap_id, None, user_channel_list_p, user_channel_cnt_p)
            delete_uint32_t_p(user_channel_cnt_p)
            if rc == SX_STATUS_SUCCESS:
                return user_channel_list_p, user_channel_cnt
            else:
                delete_sx_user_channel_t_arr(user_channel_list_p)
                return None, 0
        else:
            return None, 0
    else:
        return None, 0


def sdk_api_open():
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        return (rc, handle, "Please check if SDK is running and tool is started with root privilege..")
    else:
        return (rc, handle, "SUCCESS")


def wjh_action_enable(cmd):

    global reg_trap_id_list
    global discard_trap_id_handler_dict
    global per_chip_ignore_trap_id_dict
    global trap_id_dict
    global mode
    global trap_group_set_cmd
    global trap_group_unset_cmd

    rc, handle, msg = sdk_api_open()
    if rc != SX_STATUS_SUCCESS:
        return (rc, handle, None, msg)

    chip_type = get_chip_type(handle, replace_spc1_a1_with_spc1=True)
    if chip_type not in per_chip_ignore_trap_id_dict:
        return (SX_STATUS_ERROR, handle, None, "Unknown chip type %d" % chip_type)

    # cmd would be like 'ea', first character is 'e' or 'x' to indicate enable, second one is 'a', 's', or 'd' to indicate trap group mode.
    # please check wjh_dump.py for the implementation.
    if cmd[1] == WJH_CMD_TRAP_GROUP_MODE_AUTO:
        trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    if cmd[1] == WJH_CMD_TRAP_GROUP_MODE_STATIC:
        trap_group_set_cmd = SX_ACCESS_CMD_SET
        trap_group_unset_cmd = SX_ACCESS_CMD_UNSET
    if cmd[1] == WJH_CMD_TRAP_GROUP_MODE_DYNAMIC:
        trap_group_set_cmd = SX_ACCESS_CMD_CREATE
        trap_group_unset_cmd = SX_ACCESS_CMD_DESTROY

    # open the host ifc
    fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        return (rc, handle, None, "Failed Opening host ifc, check SX return code")

    fd = sx_fd_t_p_value(fd_p)

    # set the trap group
    global WJH_TRAP_GRP
    trap_group = WJH_TRAP_GRP
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = WJH_TRAP_PRIORITY
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = 1
    trap_group_attr.monitor_fd = fd
    trap_group_attr.add_timestamp = 1
    trap_group_attr.trap_group = trap_group

    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        return (rc, handle, fd_p, "Failed setting trap group, check SX return code")

    if cmd[0] == WJH_CMD_MONITOR_ENABLE:
        trap_id_min = SX_TRAP_ID_DISCARD_BASE
        trap_id_max = SX_TRAP_ID_DISCARD_MAX
        mode = "Normal"
    else:
        trap_id_min = SX_TRAP_ID_EXTENDED_DISCARD_BASE
        trap_id_max = SX_TRAP_ID_EXTENDED_DISCARD_MAX
        mode = "Extended"

    trap_group_attr = sx_trap_group_attributes_t_p_value(trap_group_attr_p)
    trap_group = WJH_TRAP_GRP = trap_group_attr.trap_group
    # generate the trap_id dictionary for extended traps - <Trap ID string - Trap ID value>
    trap_id_dict = sx_api_get_enums_from_prefix('SX_TRAP_ID_DISCARD_')
    trap_id_dict = del_dict_duplicate_values(trap_id_dict)
    trap_id_dict = dict((v, k) for k, v in trap_id_dict.items())

    # Include additional drop reasons listed in the following list
    # Please pay attention that these TRAP IDs may be consumed by NOS
    non_discard_traps_list = [SX_TRAP_ID_ARP_REQUEST, SX_TRAP_ID_ETH_L3_MTUERROR, SX_TRAP_ID_ETH_L3_TTLERROR, SX_TRAP_ID_ETH_L3_LBERROR, SX_TRAP_ID_L3_UC_IP_BASE]

    for trap_name, trap_enum_value in globals().items():
        if trap_name.startswith("SX_TRAP_ID_") and trap_enum_value in non_discard_traps_list:
            trap_id_dict[trap_enum_value] = trap_name

    # associate trap id and action with the trap group
    trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP

    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()

    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = trap_action

    for trap_id in trap_id_dict:
        if trap_id >= trap_id_min and trap_id <= trap_id_max or trap_id in non_discard_traps_list:
            # ignore trap-id's belonging to ignore list
            if trap_id not in per_chip_ignore_trap_id_dict[chip_type]:
                trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
                trap_key_p.trap_key_attr.trap_id = trap_id

                rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, trap_key_p, trap_attr_p)
                if rc != SX_STATUS_SUCCESS:
                    return (rc, handle, fd_p, ("Failed to set trap id %s (%d)" % (trap_id_dict[trap_id], trap_id)))

                # generate the trap ID and analyzer callback dictionary
                reg_trap_id_list.append(trap_id)
                discard_trap_id_handler_dict[trap_id] = 'analyze_' + trap_id_dict[trap_id][len('SX_TRAP_ID_'):]

    delete_sx_host_ifc_trap_key_t_p(trap_key_p)
    delete_sx_host_ifc_trap_attr_t_p(trap_attr_p)

    return (rc, handle, fd_p, "WJH packet dump utility - Monitoring started")


def wjh_action_count():
    global fd_p
    if fd_p is None:
        return 0, "WJH packet dump utility - Failed (Disable and Enable) again"
    rc, mesg = sx_recv_multi_count(fd_p)
    return rc, mesg


def wjh_action_flush():
    global fd_p
    if fd_p is None:
        return 0, "WJH packet dump utility - Failed (Disable and Enable) again"
    rc, mesg = sx_recv_multi_flush(fd_p)
    return rc, mesg


def wjh_action_save():
    global fd_p
    if fd_p is None:
        return 0, "WJH packet dump utility - Failed (Disable and Enable) again"
    rc, mesg = sx_recv_multi(fd_p)
    return rc, mesg


def wjh_action_disable():
    global handle
    global fd_p
    global reg_trap_id_list

    if fd_p is None or handle is None:
        return 0, "WJH packet dump utility - Failed (Disable and Enable) again"

    trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()

    trap_group = WJH_TRAP_GRP
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = trap_action

    monitor_fd = sx_fd_t_p_value(fd_p)
    for trap_id in reg_trap_id_list:
        trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
        trap_key_p.trap_key_attr.trap_id = trap_id

        rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, trap_key_p, trap_attr_p)
        if rc != SX_STATUS_SUCCESS:
            return (rc, handle, fd_p, ("Failed to set trap id %s (%d)" % (trap_id_dict[trap_id], trap_id)))

    delete_sx_host_ifc_trap_key_t_p(trap_key_p)
    delete_sx_host_ifc_trap_attr_t_p(trap_attr_p)

    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = WJH_TRAP_PRIORITY
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = 1
    trap_group_attr.monitor_fd = monitor_fd
    trap_group_attr.add_timestamp = 1

    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        return (rc, handle, fd_p, "Failed setting trap group, check SX return code")

    delete_sx_trap_group_attributes_t_p(trap_group_attr_p)

    # close the host ifc
    rc = sx_api_host_ifc_close(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        return (rc, "Failed closing host ifc, check SX return code")
    fd_p = None
    # close the SDK handle
    rc = sx_api_close(handle)
    if rc != SX_STATUS_SUCCESS:
        return (rc, "Failed to close the SDK handle, check SX return code")
    handle = None
    return (rc, "WJH packet dump utility - Monitoring stopped")


def wjh_receive_signal(signum, frame):
    global handle
    global fd_p
    if handle is not None and fd_p is not None:
        wjh_action_disable()

# API to send message to wjh tool client


def wjh_send_client_msg(conn, msg, rc):
    if rc != 0:
        msg = msg + " rc:" + str(rc)

    msg = msg.encode()

    try:
        conn.sendall(msg)
        rval = True
    except Exception:
        print("Stopping WJH monitor exit: Unable to send message")
        rval = False
    return rval


# API to wait for incoming connection and messages from tool front end
def wjh_wait_incoming_connection():
    global handle
    global fd_p
    global trap_group_set_cmd
    global trap_group_unset_cmd
    is_monitoring = False
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server_address = ('localhost', WJH_MONITOR_SERVER_PORT)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(server_address)
        sock.listen(WJH_SERVER_LISTEN_QUEUE_SIZE)
    except socket.error:
        print("WJH packet dump utility already running.")
        enabled = False
    except Exception:
        print("WJH packet dump utility - Failed.")
        enabled = False
    else:
        enabled = True

        while enabled:
            try:
                connection, client_address = sock.accept()
                cmd = connection.recv(WJH_SOCKET_BUFFER_SIZE)
                if type(cmd) is bytes:
                    cmd = str(cmd.decode())
                # handle --disable
                if cmd == WJH_CMD_MONITOR_DISABLE:
                    enabled = False
                    rc, msg = wjh_action_disable()
                    rval = wjh_send_client_msg(connection, msg, rc)
                    # avoid stop again in finally
                    handle = None
                    fd_p = None
                # handle --flush
                elif cmd == WJH_CMD_FLUSH_PACKETS:
                    if is_monitoring:
                        rc, msg = wjh_action_flush()
                        rval = wjh_send_client_msg(connection, msg, rc)
                    else:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is OFF", 0)
                    enabled = rval
                # handle --count
                elif cmd == WJH_CMD_COUNT_PACKETS:
                    if is_monitoring:
                        rc, msg = wjh_action_count()
                        rval = wjh_send_client_msg(connection, msg, rc)
                    else:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is OFF", 0)
                    enabled = rval
                # handle --save
                elif cmd == WJH_CMD_SAVE_PACKETS:
                    if is_monitoring:
                        rc, msg = wjh_action_save()
                        rval = wjh_send_client_msg(connection, msg, rc)
                    else:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is OFF", 0)
                    enabled = rval
                # handle --status
                elif cmd == WJH_CMD_QUERY_STATUS:
                    if is_monitoring:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is ON", 0)
                    else:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is OFF", 0)
                    enabled = rval
                # handle --enable-discard(ex)
                elif cmd[0] == WJH_CMD_MONITOR_ENABLE or cmd[0] == WJH_CMD_MONITOR_ENABLEX:
                    if is_monitoring:
                        rval = wjh_send_client_msg(connection, "WJH packet dump utility - Monitoring is already ON", 0)
                        enabled = rval
                    else:
                        rc, handle, fd_p, msg = wjh_action_enable(cmd)
                        rval = wjh_send_client_msg(connection, msg, rc)
                        # start failure would result in agent termination
                        if rc == 0:
                            enabled = rval
                            is_monitoring = True
                        else:
                            enabled = False
                            is_monitoring = False
                else:
                    rval = wjh_send_client_msg(connection, "WJH packet dump utility - Invalid command", 0)
                    enabled = rval

                connection.close()
            except socket.error:
                print("WJH packet dump utility - Unable to accept or recv data from new connection start again")
                enabled = False
                is_monitoring = False
            except Exception:
                print("WJH packet dump utility - Failure occured , exiting..")
                enabled = False
                is_monitoring = False
    finally:
        sock.close()
        if handle is not None and fd_p is not None:
            wjh_action_disable()


def main():
    wjh_wait_incoming_connection()


signal.signal(signal.SIGTERM, wjh_receive_signal)

if __name__ == "__main__":
    main()
