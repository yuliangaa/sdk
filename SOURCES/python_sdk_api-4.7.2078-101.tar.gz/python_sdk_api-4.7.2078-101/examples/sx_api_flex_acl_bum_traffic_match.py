#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates a region with size 10
    2. Creates a ACL with keys used for BUM traffic matching at egress side
    3. Create 10 ACL rules in the region
       key: FLEX_ACL_KEY_IS_BUM, FLEX_ACL_KEY_BUM_BRIDGE_ID
       actions: 1) Attach counter that gets incremented when ACL match happens.
    4. Bind the ACL to the egress port
"""
import sys
import socket
import struct
import errno
import random
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_bum_traffic_match example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = get_ports(handle, 2)
INGRESS_PORT = port_list[0]
EGRESS_PORT = port_list[1]

#######################################################################
# CONSTANTS
#######################################################################
VLAN_10 = 10
SPECTRUM_SWID = 0


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print(("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)))


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds specified ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to failed ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print(("Added %s port to  vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)))


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(keys_list):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(len(keys_list))
    for i, key in enumerate(keys_list):
        sx_acl_key_t_arr_setitem(key_arr, i, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 2,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def create_counter(handle, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create counter , rc = %d" % (rc)

    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    return counter_id


def destroy_counter(handle, counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy counter %d, rc = %d" % (counter_id, rc)


def read_clear_flow_counter(handle, counter_id):
    " This function reads and clears a flow counter. "
    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read counter %d, rc = %d" % (counter_id, rc)
    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)

    rc = sx_api_flow_counter_clear_set(handle, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to clear counter %d, rc = %d" % (counter_id, rc)

    return counter_set.flow_counter_packets


def rule_set(region_id, key_handle, bridge_id, counter_id, cmd):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_cnt = (1)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    offsets_list = new_sx_acl_rule_offset_t_arr(rules_cnt)

    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(key_handle, 1, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_IS_BUM
    key_desc.key.is_bum_valid = True
    key_desc.mask.is_bum_valid = True
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    key_desc.key_id = FLEX_ACL_KEY_BUM_BRIDGE_ID
    key_desc.key.bum_bridge_id = bridge_id
    key_desc.mask.bum_bridge_id = True
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 1, key_desc)

    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_COUNTER
    action.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action)

    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)
    sx_lib_flex_acl_rule_deinit(rule)


def main():

    add_ports_to_vlan(handle, VLAN_10, {INGRESS_PORT: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, VLAN_10, {EGRESS_PORT: SX_TAGGED_MEMBER})

    key_handle = key_create([FLEX_ACL_KEY_IS_BUM, FLEX_ACL_KEY_BUM_BRIDGE_ID])
    region_id = region_create(key_handle, 1)
    acl_id = acl_create(region_id, SX_ACL_DIRECTION_EGRESS)
    acl_counter_id = create_counter(handle)
    rule_set(region_id, key_handle, VLAN_10, acl_counter_id, SX_ACCESS_CMD_SET)

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  EGRESS_PORT,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    print(("Inject packet to Ingress port ===>Ether(dst='00:00:01:01:01:01', src='00:00:02:02:02:01') / Dot1Q(vlan=10) /\n"
           + "\t\tIP(dst='20.20.20.20', src='20.20.20.10') /\n"
           + "\t\tRaw(load='ABCDEFGHIJKLMNOPQRSTUVWXYZ'"))

    # You can read the ACL counter after packet is injected

    count = read_clear_flow_counter(handle, acl_counter_id)
    # In working scenario, ACL hit counter should be non zero

    if args.deinit:
        # unbind acl from egress port.
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      EGRESS_PORT,
                                      acl_id)
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

        # delete the rule and clean up the acl, group
        rule_set(region_id, key_handle, VLAN_10, acl_counter_id, SX_ACCESS_CMD_DELETE)
        destroy_counter(handle, acl_counter_id)
        acl_destroy(acl_id, region_id)
        region_destroy(region_id)
        key_destroy(key_handle)

        remove_ports_from_vlan(handle, VLAN_10, {INGRESS_PORT: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(handle, VLAN_10, {EGRESS_PORT: SX_TAGGED_MEMBER})

    sx_api_close(handle)


if __name__ == "__main__":
    main()
