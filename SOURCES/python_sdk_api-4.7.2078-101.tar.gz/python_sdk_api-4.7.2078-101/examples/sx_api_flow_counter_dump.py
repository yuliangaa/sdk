#!/usr/bin/env python
'''
This file contains Python command example that reads all the Flow counters in the system
and displays their value.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
This example is supported on Spectrum and later devices
'''
import sys
import errno
import colorsys

from python_sdk_api.sx_api import *
from test_infra_common import *
######################################################
#    defines
######################################################

######################################################
#    Variables
######################################################

######################################################
#    Local Functions
######################################################


def read_flow_counter(handle, counter_id):
    " This function reads a flow counter. "
    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_flow_counter_get API failed to get counter value, rc=%d] " % (rc)))
        sys.exit(rc)

    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    return counter_set.flow_counter_packets
######################################################


######################################################
#    Main Function
######################################################
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if rc != SX_STATUS_SUCCESS:
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

num_counters_p = new_uint32_t_p()
num_counters_read = 0
uint32_t_p_assign(num_counters_p, 0)

rc = sx_api_flow_counter_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None,
                                  num_counters_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_flow_counter_iter_get API failed to get num counters, rc=%d] " % (rc)))
    sys.exit(rc)

num_counters_total = uint32_t_p_value(num_counters_p)
print("\n==================================")
print("Total Flow counters configured : %d" % (num_counters_total))

if num_counters_total > 0:
    flow_counter_get_list = []
    flow_counter_val_list = []
    ctr_array = new_sx_flow_counter_id_t_arr(num_counters_total)

    # the system has a lot of counters. To be safe, lets split into multiple read commands
    if num_counters_total < 2500:
        uint32_t_p_assign(num_counters_p, num_counters_total)

        rc = sx_api_flow_counter_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, ctr_array,
                                          num_counters_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_flow_counter_iter_get API failed to get counter values, rc=%d] " % (rc)))
            sys.exit(rc)

        num_counters_read = uint32_t_p_value(num_counters_p)
        for i in range(0, num_counters_read):
            id_get = sx_flow_counter_id_t_arr_getitem(ctr_array, i)
            flow_counter_get_list.append(id_get)
    else:
        num_iterations = 0
        while num_counters_total - num_counters_read > 0:
            num_iterations += 1
            if num_counters_read == 0:
                cmd = SX_ACCESS_CMD_GET_FIRST
                key = 0
            else:
                cmd = SX_ACCESS_CMD_GETNEXT
                key = flow_counter_get_list[-1]

            uint32_t_p_assign(num_counters_p, 2500)
            rc = sx_api_flow_counter_iter_get(handle, cmd, key, None, ctr_array,
                                              num_counters_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_flow_counter_iter_get API failed to get counter values, rc=%d] " % (rc)))
                sys.exit(rc)

            data_cnt = uint32_t_p_value(num_counters_p)
            for i in range(0, data_cnt):
                id_get = sx_flow_counter_id_t_arr_getitem(ctr_array, i)
                flow_counter_get_list.append(id_get)

            num_counters_read += data_cnt
            if num_iterations > 12:
                # to prevent an infinite loop where the total has changed since we read
                # it earlier, lets get total count again
                uint32_t_p_assign(num_counters_p, 0)

                rc = sx_api_flow_counter_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None,
                                                  num_counters_p)
                if rc != SX_STATUS_SUCCESS:
                    print(("sx_api_flow_counter_iter_get API failed to get num counters, rc=%d] " % (rc)))
                    sys.exit(rc)

                num_counters_total = uint32_t_p_value(num_counters_p)

    for counter in flow_counter_get_list:
        ctr_value = read_flow_counter(handle, counter)
        flow_counter_val_list.append(ctr_value)

    print("==================================")
    print("| %7s | %20s |" % ("Cntr Id", "  Value"))
    print("==================================")
    for i in range(0, len(flow_counter_get_list)):
        print("| %7d | %20d |" % (flow_counter_get_list[i],
                                  flow_counter_val_list[i]))
        print("----------------------------------")

print("\n=================================================================")
####################################################################################
sx_api_close(handle)
####################################################################################
