#!/usr/bin/env python
'''
This file contains Python command example for the ALL PORT COUNTER READ module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import os.path
import time
from python_sdk_api.sx_api import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

if len(sys.argv) >= 2:
    dump_file_path = str(sys.argv[1])
else:
    sx_api_sx_sdk_init_p = new_sx_api_sx_sdk_init_t_p()
    rc = sx_api_sdk_init_params_get(handle, sx_api_sx_sdk_init_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to get sdk init params.\n")
        sx_api_close(handle)
        sys.exit(rc)
    sdk_init_attr = sx_api_sx_sdk_init_t_p_value(sx_api_sx_sdk_init_p)
    dump_file_path = getattr(sdk_init_attr, "sdk_sys_info_params").sdk_sys_info_path + "/sdkdump"
    print(("No dump file path was entered as a parameter.\nWill use the default: %s path." % dump_file_path))

start_time = time.time()
rc = sx_api_dbg_generate_dump(handle, dump_file_path)
time_to_generate_dump = time.time() - start_time
print("sx_api_dbg_dump took {:.2f} seconds".format(time_to_generate_dump))

print(("sx_api_dbg_generate_dump, rc %d" % rc))

sx_api_close(handle)
