#!/usr/bin/env python
'''
This file contains SDK configuration for mstp and lag
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_lag_mstp example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

orig_port_list = mapPortAndInterfaces(handle)
PORT_1 = orig_port_list[0]
PORT_2 = orig_port_list[1]
PORT_3 = orig_port_list[2]

VLAN_1 = 5
VLAN_2 = 6

""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    elif cmd == SX_ACCESS_CMD_DESTROY:
        print("--------------- BRIDGE DELETE ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_vport_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def lag_create_delete(cmd, swid, lag_id_p, port_list, port_cnt):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- LAG CREATE ------------------------------")
    elif cmd == SX_ACCESS_CMD_DESTROY:
        print("--------------- LAG DELETE ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_id_p, port_list, port_cnt)
    print(("sx_api_lag_port_group_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def add_delete_lag_ports(cmd, swid, lag_id_p, port_list, port_cnt):
    """ ############################################################################################ """
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD PORTS TO LAG ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE PORTS FROM LAG ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_id_p, port_list, port_cnt)
    print(("sx_api_lag_port_group_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def create_delete_mstp_instance(cmd, swid, inst_id):
    """ ############################################################################################ """
    """ CREATE/DELETE MSTP INSTANCE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- CREATE MSTP INSTANCE ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE MSTP INSTANCE ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_mstp_inst_set(handle, cmd, SPECTRUM_SWID, inst_id)
    print(("sx_api_mstp_inst_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


""" ############################################################################################ """
ports_ingr_filter_mode = {}

# MSTP Mode change & LAG Usage will effect all ports RSTP State
original_rstp_modes = {}
stp_state_p = new_sx_mstp_inst_port_state_t_p()
for port in orig_port_list:
    rc = sx_api_rstp_port_state_get(handle, port, stp_state_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_get failed, rc: %d" % (rc)
    original_rstp_modes[port] = sx_mstp_inst_port_state_t_p_value(stp_state_p)
delete_sx_mstp_inst_port_state_t_p(stp_state_p)

# Create a LAG.
lag_id_p = new_sx_port_log_id_t_p()
print("Create lag")
lag_create_delete(SX_ACCESS_CMD_CREATE, SPECTRUM_SWID, lag_id_p, None, 0)
lag_id = sx_port_log_id_t_p_value(lag_id_p)
print(("lag 0x%x created" % (lag_id)))
rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
print(("sx_api_vlan_port_ingr_filter_set  [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

# Adds 2 ports to the above LAG.
ports_ingr_filter_mode[PORT_1] = ingr_filter_get(PORT_1)
ports_ingr_filter_mode[PORT_2] = ingr_filter_get(PORT_2)

print(("Add port 0x%x and 0x%x to lag 0x%x" % (PORT_1, PORT_2, lag_id)))
port_list = new_sx_port_log_id_t_arr(2)
sx_port_log_id_t_arr_setitem(port_list, 0, PORT_1)
sx_port_log_id_t_arr_setitem(port_list, 1, PORT_2)
add_delete_lag_ports(SX_ACCESS_CMD_ADD, SPECTRUM_SWID, lag_id_p, port_list, 2)

# create vlag with vlan 2 and lag created above
print(("Create vlag with lag 0x%x and vlan %d" % (lag_id, VLAN_2)))
vlag_p = new_sx_port_log_id_t_p()
vport_add_delete(SX_ACCESS_CMD_ADD, lag_id, VLAN_2, vlag_p)
vlag = sx_port_log_id_t_p_value(vlag_p)
print(("virtual lag 0x%x created" % (vlag)))

# Create vport with vlan 1 and port PORT_3
print(("Create vport with port 0x%x and vlan %d" % (PORT_3, VLAN_1)))
log_port = PORT_3
log_vport_p = new_sx_port_log_id_t_p()
vport_add_delete(SX_ACCESS_CMD_ADD, log_port, VLAN_1, log_vport_p)
log_vport = sx_port_log_id_t_p_value(log_vport_p)
print(("virtual port 0x%x created" % (log_vport)))

# Create bridge
print("bridge create")
bridge_id_p = new_sx_bridge_id_t_p()
bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
print(("bridge %d created" % (bridge_id)))

# add vlag to bridge
print(("Add vlag 0x%x to bridge %d" % (vlag, bridge_id)))
bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, vlag)
print(("vlag  0x%x added to bridge %d" % (vlag, bridge_id)))


# add vport to bridge
print(("Add vport 0x%x to bridge %d" % (log_vport, bridge_id)))
bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport)
print(("vport 0x%x added to bridge %d" % (log_vport, bridge_id)))

# Change STP mode to MSTP
# first, save the current MSTP mode for later de-configration
stp_mode_p = new_sx_mstp_mode_t_p()
rc = sx_api_mstp_mode_get(handle, SPECTRUM_SWID, stp_mode_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_get failed, rc: %d" % (rc)
original_stp_mode = sx_mstp_mode_t_p_value(stp_mode_p)

print("--------------- CHANGE STP MODE TO MSTP ------------------------------")
stp_mode = SX_MSTP_MODE_MSTP
rc = sx_api_mstp_mode_set(handle, SPECTRUM_SWID, stp_mode)
print(("sx_api_mstp_mode_set [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print("mstp mode set to SX_MSTP_MODE_MSTP")

# create mstp instance
inst_id = 2
create_delete_mstp_instance(SX_ACCESS_CMD_ADD, SPECTRUM_SWID, inst_id)
print(("mstp instance created with instance id %d" % (inst_id)))


# add bridge to mstp instance
print("--------------- ADD BRIDGE TO MSTP INSTANCE ------------------------------")
vlan_p = new_sx_vlan_id_t_p()
sx_vlan_id_t_p_assign(vlan_p, bridge_id)
cmd = SX_ACCESS_CMD_ADD
rc = sx_api_mstp_inst_vlan_list_set(handle, cmd, SPECTRUM_SWID, inst_id, vlan_p, 1)
print(("sx_api_mstp_inst_vlan_list_set [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("Added bridge %d to mstp instance created above" % (bridge_id)))


# bind mstp instance to LAG
print(("Bind mstp %d to lag 0x%x" % (inst_id, lag_id)))
print("--------------- BIND MSTP TO LAG ------------------------------")
port_state = SX_MSTP_INST_PORT_STATE_FORWARDING
rc = sx_api_mstp_inst_port_state_set(handle, SPECTRUM_SWID, inst_id, lag_id, port_state)
print(("sx_api_mstp_inst_port_state_set [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("bounded mstp instance %d to lag 0x%x" % (inst_id, lag_id)))


""" ############################################################################################ """

if args.deinit:
    print("--------------- Deinit ----------------")

    # unbind mstp instance from LAG
    port_state = SX_MSTP_INST_PORT_STATE_DISCARDING
    rc = sx_api_mstp_inst_port_state_set(handle, SPECTRUM_SWID, inst_id, lag_id, port_state)
    print(("sx_api_mstp_inst_port_state_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("unbounded mstp instance %d to lag 0x%x" % (inst_id, lag_id)))

    # delete mstp instance
    create_delete_mstp_instance(SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, inst_id)
    print(("mstp instance deleted with instance id %d" % (inst_id)))

    # set back to the original stp mode
    rc = sx_api_mstp_mode_set(handle, SPECTRUM_SWID, original_stp_mode)
    print(("sx_api_mstp_mode_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    # delete vlag from bridge
    print(("Delete vlag 0x%x from bridge %d" % (vlag, bridge_id)))
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, vlag)
    print(("vlag 0x%x deleted from bridge %d" % (vlag, bridge_id)))

    # delete vport from bridge
    print(("Delete vport 0x%x from bridge %d" % (log_vport, bridge_id)))
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    print(("vport 0x%x deleted from bridge %d" % (log_vport, bridge_id)))

    # delete bridge
    print(("delete bridge %d" % (bridge_id)))
    bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)
    print(("bridge %d deleted" % (bridge_id)))

    # delete vlag created with vlan 2 and lag created above
    print(("Delete vlag 0x%x " % (vlag)))
    vport_add_delete(SX_ACCESS_CMD_DELETE, lag_id, VLAN_2, vlag_p)
    print(("virtual lag 0x%x deleted" % (vlag)))

    # delete vport created with vlan 1 and port created above
    print(("Delete vport 0x%x " % (log_vport)))
    vport_add_delete(SX_ACCESS_CMD_DELETE, log_port, VLAN_1, log_vport_p)
    print(("virtual port 0x%x deleted" % (log_vport)))

    # Delete ports from above LAG.
    print(("Delete port 0x%x and 0x%x from lag 0x%x" % (PORT_1, PORT_2, lag_id)))
    add_delete_lag_ports(SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, lag_id_p, port_list, 2)

    print(("Delete lag 0x%x" % (lag_id)))
    lag_create_delete(SX_ACCESS_CMD_DESTROY, SPECTRUM_SWID, lag_id_p, None, 0)
    print(("lag 0x%x deleted" % (lag_id)))

    print("Add LAG Members back to default vlan and restore filter mode")
    for port, ingr_filter in list(ports_ingr_filter_mode.items()):
        add_ports_to_vlan(1, {port: SX_UNTAGGED_MEMBER})
        ingr_filter_set(port, ingr_filter)

    print("Restore all ports RSTP States")
    for port, rstp_state in original_rstp_modes.items():
        rc = sx_api_rstp_port_state_set(handle, port, rstp_state)
        assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, port 0x%x, rc: %d" % (port, rc)

""" ############################################################################################ """

sx_api_close(handle)
