#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the port PHY counters get flow.
'''
import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import auto_int
import argparse


cmds = {0: SX_ACCESS_CMD_READ, 1: SX_ACCESS_CMD_READ_CLEAR}
cntr_grps = {0: SX_PORT_CNTR_GRP_PHY_LAYER_STATISTICS, 1: SX_PORT_CNTR_GRP_PHY_LAYER_INTERNAL_LINK}


def parse_args():
    parser = argparse.ArgumentParser(description='Port PHY Counters get example.')
    parser.add_argument('--cmd', default=0, type=int, help="get(0), get_and_clear(1)")
    parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Logical port ID')
    parser.add_argument('--link_side', default=0, type=int, help='external(0), internal_near(1), internal_far(2)')
    parser.add_argument('--cntr_grp', default=0, type=int, help='PHY counters group - PHY Statistics(0), PHY Internal Link (1)')
    args = parser.parse_args()
    return cmds[args.cmd], args.log_port, args.link_side, cntr_grps[args.cntr_grp]


def init():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)
    return handle


def deinit(handle):
    sx_api_close(handle)


def run_example(handle, cmd, log_port, link_side, cntr_grp):
    print("=======================================")
    print("[+] cmd port: ", cmd)
    print("[+] log_port: ", hex(log_port))
    print("[+] link_side: ", link_side)
    print("[+] cntr_grp: ", hex(cntr_grp))
    print("=======================================")
    if cntr_grp == SX_PORT_CNTR_GRP_PHY_LAYER_INTERNAL_LINK:
        print("[+] Get PHY Internal Link counters")
        cntr_p = new_sx_port_cntr_phy_layer_internal_link_t_p()
        rc = sx_api_port_counter_phy_layer_internal_link_get(handle, cmd, log_port, link_side, cntr_p)
        print("[+] Get PHY Internal Link counters, rc: ", rc)
        if rc == SX_STATUS_SUCCESS:
            print("=======================================")
            print("[+] %-34s: %s" % ("time_since_last_clear", cntr_p.time_since_last_clear))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane0", cntr_p.fc_fec_corrected_blocks_lane0))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane1", cntr_p.fc_fec_corrected_blocks_lane1))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane2", cntr_p.fc_fec_corrected_blocks_lane2))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane3", cntr_p.fc_fec_corrected_blocks_lane3))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane4", cntr_p.fc_fec_corrected_blocks_lane4))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane5", cntr_p.fc_fec_corrected_blocks_lane5))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane6", cntr_p.fc_fec_corrected_blocks_lane6))
            print("[+] %-34s: %s" % ("fc_fec_corrected_blocks_lane7", cntr_p.fc_fec_corrected_blocks_lane7))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane0", cntr_p.fc_fec_uncorrectable_blocks_lane0))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane1", cntr_p.fc_fec_uncorrectable_blocks_lane1))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane2", cntr_p.fc_fec_uncorrectable_blocks_lane2))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane3", cntr_p.fc_fec_uncorrectable_blocks_lane3))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane4", cntr_p.fc_fec_uncorrectable_blocks_lane4))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane5", cntr_p.fc_fec_uncorrectable_blocks_lane5))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane6", cntr_p.fc_fec_uncorrectable_blocks_lane6))
            print("[+] %-34s: %s" % ("fc_fec_uncorrectable_blocks_lane7", cntr_p.fc_fec_uncorrectable_blocks_lane7))
            print("[+] %-34s: %s" % ("link_down_event_cnt", cntr_p.link_down_event_cnt))

    else:
        print("[+] Get PHY Statistics counters")
        cntr_p = new_sx_port_cntr_phy_layer_statistics_t_p()
        rc = sx_api_port_counter_phy_layer_statistics_get(handle, cmd, log_port, link_side, cntr_p)
        print("[+] Get PHY Statistics counters, rc: ", rc)
        if rc == SX_STATUS_SUCCESS:
            print("=======================================")
            print("[+] %-27s: %s" % ("time_since_last_clear", cntr_p.time_since_last_clear))
            print("[+] %-27s: %s" % ("phy_received_bits", cntr_p.phy_received_bits))
            print("[+] %-27s: %s" % ("phy_symbol_errors", cntr_p.phy_symbol_errors))
            print("[+] %-27s: %s" % ("phy_corrected_bits", cntr_p.phy_corrected_bits))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane0", cntr_p.phy_raw_errors_lane0))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane1", cntr_p.phy_raw_errors_lane1))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane2", cntr_p.phy_raw_errors_lane2))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane3", cntr_p.phy_raw_errors_lane3))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane4", cntr_p.phy_raw_errors_lane4))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane5", cntr_p.phy_raw_errors_lane5))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane6", cntr_p.phy_raw_errors_lane6))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane7", cntr_p.phy_raw_errors_lane7))
            print("[+] %-27s: %s" % ("raw_ber_magnitude", cntr_p.raw_ber_magnitude))
            print("[+] %-27s: %s" % ("raw_ber_coef", cntr_p.raw_ber_coef))
            print("[+] %-27s: %s" % ("effective_ber_magnitude", cntr_p.effective_ber_magnitude))
            print("[+] %-27s: %s" % ("effective_ber_coef", cntr_p.effective_ber_coef))
    print("=======================================")


def main():
    cmd, log_port, link_side, cntr_grp = parse_args()
    handle = init()
    run_example(handle, cmd, log_port, link_side, cntr_grp)
    deinit(handle)
    print("[+] Done")


if __name__ == "__main__":
    main()
