#!/usr/bin/env python
'''
This file contains Python command example for Bridge and Vport module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different Bridge and Vport attributes.
This example is supported on Spectrum devices.
'''

import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_bridge_vport example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def vport_add_delete(handle, cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN -----------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN -----------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def bridge_create_delete(handle, cmd, bridge_id_p):
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE -----------------------------------------------------")
    else:
        print("--------------- BRIDGE DELETE -----------------------------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def bridge_vport_add_delete(handle, cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ----------------------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  -----------------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def port_state_set(handle, log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ---------------------------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


def vlan_ports_add_delete(handle, cmd, vid, vlan_port_list_p, port_cnt):
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VLAN MEMBER PORTS  --------------------------------------------")
    else:
        print("--------------- DELETE VLAN MEMBER PORTS  -----------------------------------------")

    rc = sx_api_vlan_ports_set(handle, cmd, 0, vid, vlan_port_list_p, port_cnt)
    print(("sx_api_vlan_ports_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  -----------------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  --------------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, 0, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


def main():
    args = parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return rc

    try:
        port_list = mapPortAndInterfaces(handle)
        PORT1 = port_list[0]
        PORT2 = port_list[1]

        # create a vport for port 0x10001 and vlan 20
        log_vport_p_1 = new_sx_port_log_id_t_p()
        vport_add_delete(handle, SX_ACCESS_CMD_ADD, PORT1, 20, log_vport_p_1)
        log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
        print(("virtual port 0x%x created" % (log_vport_1)))

        # create a vport for port 0x10003 and vlan 30
        log_vport_p_2 = new_sx_port_log_id_t_p()
        vport_add_delete(handle, SX_ACCESS_CMD_ADD, PORT2, 30, log_vport_p_2)
        log_vport_2 = sx_port_log_id_t_p_value(log_vport_p_2)
        print(("virtual port 0x%x created" % (log_vport_2)))

        # create bridge
        bridge_id_p = new_sx_bridge_id_t_p()
        bridge_create_delete(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
        bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
        print(("bridge %d created" % (bridge_id)))

        # add log_vport_1 to bridge
        bridge_vport_add_delete(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
        print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))

        # add log_vport_2 to bridge
        bridge_vport_add_delete(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport_2)
        print(("virtual port 0x%x added to bridge %d " % (log_vport_2, bridge_id)))

        # create a static fdb entry
        mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
        data_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(data_cnt_p, 2)
        mac_addr = ether_addr("00:02:c9:11:ad:ca")

        mac_entry1 = sx_fdb_uc_mac_addr_params_t()
        mac_entry1.mac_addr = mac_addr
        mac_entry1.fid_vid = bridge_id          # Filtering Identifier, VID for static MAC
        mac_entry1.log_port = log_vport_1
        mac_entry1.entry_type = SX_FDB_UC_STATIC
        mac_entry1.action = SX_FDB_ACTION_MIRROR_TO_CPU
        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

        mac_entry2 = sx_fdb_uc_mac_addr_params_t()
        mac_entry2.mac_addr = mac_addr
        mac_entry2.fid_vid = bridge_id          # Filtering Identifier, VID for static MAC
        mac_entry2.log_port = log_vport_2
        mac_entry2.entry_type = SX_FDB_UC_STATIC
        mac_entry2.action = SX_FDB_ACTION_MIRROR_TO_CPU
        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

        # EK Add UC Mac address to the log port
        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to add UC Static entry"
        data_cnt = uint32_t_p_value(data_cnt_p)
        print(("sx_api_fdb_uc_mac_addr_set added %d entities, rc: %d " % (data_cnt, rc)))

        # set port state to UP
        port_state_set(handle, log_vport_1, SX_PORT_ADMIN_STATUS_UP)

        # set port state to UP
        port_state_set(handle, log_vport_2, SX_PORT_ADMIN_STATUS_UP)

        # add vlan port membership
        add_ports_to_vlan(handle, 20, {PORT1: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, 30, {PORT2: SX_TAGGED_MEMBER})

        # Send Traffic from 2 vports
        print("****** Now user can send traffic from two vports ******")

        if not args.deinit:
            return 0

        # set port state to DOWN
        port_state_set(handle, log_vport_1, SX_PORT_ADMIN_STATUS_DOWN)

        # DELETE fdb entry before destroying the bridge
        print("--------------- DELETE FDB ENTRY --------------------------------------------------")
        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_fdb_uc_mac_addr_set  [rc=%d] " % (rc)))

        # delete log_vport_1 to bridge
        bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport_1)
        print(("virtual port 0x%x deleted from bridge %d " % (log_vport_1, bridge_id)))
        # set port state to UP
        port_state_set(handle, log_vport_1, SX_PORT_ADMIN_STATUS_UP)

        # set port state to DOWN
        port_state_set(handle, log_vport_2, SX_PORT_ADMIN_STATUS_DOWN)

        # delete log_vport_2 to bridge
        bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport_2)
        print(("virtual port 0x%x deleted from bridge %d " % (log_vport_2, bridge_id)))

        # set port state to UP
        port_state_set(handle, log_vport_2, SX_PORT_ADMIN_STATUS_UP)

        # delete bridge
        bridge_create_delete(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
        #bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
        print(("bridge %d deleted" % (bridge_id)))

        # delete vport for port 0x10001 and vlan 20
        vport_add_delete(handle, SX_ACCESS_CMD_DELETE, PORT1, 20, log_vport_p_1)
        #log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
        print(("virtual port 0x%x deleted" % (log_vport_1)))

        # delete vport for port 0x10003 and vlan 30
        vport_add_delete(handle, SX_ACCESS_CMD_DELETE, PORT2, 30, log_vport_p_2)
        #log_vport_2 = sx_port_log_id_t_p_value(log_vport_p_2)
        print(("virtual port 0x%x deleted" % (log_vport_2)))

        # remove vlan port membership
        remove_ports_from_vlan(handle, 20, {PORT1: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(handle, 30, {PORT2: SX_TAGGED_MEMBER})
    finally:
        rc = sx_api_close(handle)
        assert rc == SX_STATUS_SUCCESS, "Failed to close SDK Handle"


if __name__ == "__main__":
    sys.exit(main())
