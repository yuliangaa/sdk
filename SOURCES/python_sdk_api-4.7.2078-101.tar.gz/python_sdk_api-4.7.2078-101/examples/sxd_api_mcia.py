#!/usr/bin/env python

import sys
import errno
import sys
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sxd_api_mcia example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
args = parser.parse_args()

print("[+] MCIA register access test start")
print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to initialize register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

slot_count = system_slot_count_get(handle)
sx_api_close(handle)

if args.slot_id == INVALID_SLOT_ID:
    if slot_count > 0:
        slot_index = 1
    else:
        slot_index = 0
else:
    if args.slot_id > slot_count:
        print("Slot id is not valid.")
        exit(0)
    elif args.slot_id == 0 and slot_count > 0:
        print("Slot id is not valid.")
        exit(0)
    else:
        slot_index = args.slot_id


def reg_read(module, i2c_device_address, page_number, device_address, size):
    data = ku_mcia_reg()

    data.module = module
    data.slot_index = slot_index
    data.i2c_device_address = i2c_device_address
    data.page_number = page_number
    data.device_address = device_address
    data.size = size

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mcia(data, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

    return data

###############################################################


# save current data for later de-configuration
original_data_1 = reg_read(8, 0x56, 0, 0x17, 2)
original_data_2 = reg_read(8, 0x56, 0, 0x15, 2)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_SET

print("[+] Set MCIA content, set Normal operation")
mcia = ku_mcia_reg()
mcia.module = 8
mcia.slot_index = slot_index
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2

mcia.dword_0 = 0x0F9A0000
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))
mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
mcia.dword_0 = 0xC0000000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)
print(("[+] addr 0x15 dword0 : 0x%08x" % mcia.dword_0))

print("[+] Get MCIA")
meta.access_cmd = SXD_ACCESS_CMD_GET
mcia.device_address = 0
mcia.size = 28
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print("[+] Get MCIA content, set BroadR-Reach LRE Registers")
print("[+] Slot: ", mcia.slot_index)
print("[+] Module: ", mcia.module)

print("[+] Get MCIA content")
print("====================")
print(("[+] dword0 : 0x%08x" % mcia.dword_0))
print(("[+] dword1 : 0x%08x" % mcia.dword_1))
print(("[+] dword2 : 0x%08x" % mcia.dword_2))
print(("[+] dword3 : 0x%08x" % mcia.dword_3))
print(("[+] dword4 : 0x%08x" % mcia.dword_4))
print(("[+] dword5 : 0x%08x" % mcia.dword_5))
print(("[+] dword6 : 0x%08x" % mcia.dword_6))
print(("[+] dword7 : 0x%08x" % mcia.dword_7))
print(("[+] dword8 : 0x%08x" % mcia.dword_8))
print(("[+] dword9 : 0x%08x" % mcia.dword_9))
print(("[+] dword10: 0x%08x" % mcia.dword_10))
print(("[+] dword11: 0x%08x" % mcia.dword_11))

print("[+] Get MCIA content, set BroadR-Reach LRE Registers")
mcia.module = 8
mcia.slot_index = slot_index
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = 0x0F9A0000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
mcia.dword_0 = 0x80000000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read set register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print(("[+] addr 0x15 dword0 : 0x%08x" % mcia.dword_0))

print("[+] Get MCIA")
mcia.device_address = 0
mcia.size = 10
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print("[+] Get MCIA content")
print("====================")
print(("[+] dword0 : 0x%08x" % mcia.dword_0))
print(("[+] dword1 : 0x%08x" % mcia.dword_1))
print(("[+] dword2 : 0x%08x" % mcia.dword_2))


######################################################
print("[+] Get MCIA content, read VLAN Tag1 reg ")
mcia.module = 8
mcia.slot_index = slot_index
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = 0x0D150000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

mcia.dword_0 = 0
mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)

print(("[+] addr 0x15 dword0 : 0x%08x" % mcia.dword_0))

print("[+] Get MCIA content, read VLAN Tag2 reg ")
mcia.module = 8
mcia.slot_index = slot_index
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = 0x0D160000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)
print(("[+] addr 0x15 dword0 : 0x%08x" % mcia.dword_0))

if args.deinit:
    print("Deinit")
    meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_mcia(original_data_1, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

    rc = sxd_access_reg_mcia(original_data_2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)
