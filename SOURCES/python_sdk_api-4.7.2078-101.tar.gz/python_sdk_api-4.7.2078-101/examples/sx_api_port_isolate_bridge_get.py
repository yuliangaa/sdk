#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import pdb

######################################################
#    defines
######################################################


######################################################
#    functions
######################################################

def proceed_args():
    parser = argparse.ArgumentParser(description='sx_api_port_isolation_bridge_get API')
    parser.add_argument('--egress_port', default=0x10001, type=auto_int, help='Egress port')
    args = parser.parse_args()

    return args.egress_port


def main():
    port_isolation_cfg_p = new_sx_port_isolation_cfg_t_p()
    egress_port = proceed_args()

    try:

        print("[+] opening sdk")
        rc, handle = sx_api_open(None)
        print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to open api handle.\nPlease check that SDK is running.")
            sys.exit(rc)

        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM2]:
            print("Warning: The current example is supported only by Spectrum3 and above!")
            sys.exit(rc)

        print("---------------- Parameters --------------------")
        print("Egress port: 0x%x" % egress_port)
        print("------------------------------------------------")

        # Get the number of isolated ingress ports if there are any ... (log_port_cnt must be equals to 0 !)
        port_isolation_cfg_p.log_port_cnt = 0

        rc = sx_api_port_isolate_bridge_get(handle, egress_port, port_isolation_cfg_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_bridge_get failed. [%d]" % rc

        ingress_isolated_port_cnt = port_isolation_cfg_p.log_port_cnt

        print("GET ")
        print("    Egress port: 0x%x " % (egress_port))
        print("    Ingress port counter: %d " % (ingress_isolated_port_cnt))

        if (ingress_isolated_port_cnt):
            # Get the lsit of isolated igress ports (based on the received number of ports)
            port_isolation_cfg_p.log_port_cnt = ingress_isolated_port_cnt

            rc = sx_api_port_isolate_bridge_get(handle, egress_port, port_isolation_cfg_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_bridge_get failed. [%d]" % rc

            for i in xrange(0, port_isolation_cfg_p.log_port_cnt):
                isolated_log_port = sx_port_log_id_t_arr_getitem(port_isolation_cfg_p.log_port_list, i)
                print("      ingress port[%d]: 0x%x" % (i, isolated_log_port))

        print("Done, rc = %d." % (rc))

    finally:
        delete_sx_port_isolation_cfg_t_p(port_isolation_cfg_p)
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
