#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

""" ############################################################################################ """


def host_ifc_trap_id_register(cmd, trap_id, user_channel_p):
    """ HOST IFC TRAP ID REGISTER/UNREGISTER """
    if cmd == SX_ACCESS_CMD_REGISTER:
        print("--------------- HOST IFC TRAP ID REGISTER------------------------------")
    else:
        print("--------------- HOST IFC TRAP ID DEREGISTER------------------------------")

    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, SPECTRUM_SWID, trap_id, user_channel_p)
    print(("sx_api_host_ifc_trap_id_register_set [rc = %d]" % (rc)))

    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """
""" HOST IFC OPEN """
print("--------------- HOST IFC OPEN------------------------------")

fd_p = new_sx_fd_t_p()

rc = sx_api_host_ifc_open(handle, fd_p)
print(("sx_api_host_ifc_open, rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(errno.EACCES)
fd = sx_fd_t_p_value(fd_p)
print(("fd = %d" % (fd.fd)))


""" ############################################################################################ """
""" HOST IFC TRAP GROUP SET """
print("--------------- HOST IFC TRAP GROUP EXT SET ------------------------------")

trap_group = 1
trap_group_attr_p = new_sx_trap_group_attributes_t_p()
trap_group_attr = sx_trap_group_attributes_t()
trap_group_attr.prio = 1
trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_group_attr.truncate_size = 0
trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
trap_group_attr.is_monitor = False
trap_group_attr.trap_group = trap_group
sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
print(("sx_api_host_ifc_trap_group_ext_set [rc = %d]" % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(errno.EACCES)

trap_group_attr = sx_trap_group_attributes_t_p_value(trap_group_attr_p)
trap_group = trap_group_attr.trap_group
print(("trap_group =%d " % (trap_group)))
print("--- trap_group attributes ---")
print(("prio  =%d " % (trap_group_attr.prio)))
print(("truncate mode  =%d " % (trap_group_attr.truncate_mode)))
print(("truncate size  =%d " % (trap_group_attr.truncate_size)))
print(("control type  =%d " % (trap_group_attr.control_type)))

""" ############################################################################################ """

# sx_api_host_ifc_trap_id_ext_set 0 SX_TRAP_ID_ETH_L2_STP 1 SX_TRAP_ACTION_TRAP_2_CPU
""" HOST IFC TRAP ID SET """
print("--------------- HOST IFC TRAP ID EXT SET------------------------------")

trap_id = SX_TRAP_ID_ETH_L2_STP
trap_action = SX_TRAP_ACTION_TRAP_2_CPU

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
print(("sx_api_host_ifc_trap_id_ext_set [rc=%d]" % (rc)))

if rc != SX_STATUS_SUCCESS:
    sys.exit(errno.EACCES)
print(("trap_id =%d, trap_group=%d, trap_action =%d, rc=%d" % (trap_id, trap_group, trap_action, rc)))

""" ############################################################################################ """
# trap id register
user_channel_p = new_sx_user_channel_t_p()
user_channel = sx_user_channel_t()
user_channel.type = SX_USER_CHANNEL_TYPE_FD
# FD is same returned from host_ifc_open API
user_channel.channel.fd = copy_sx_fd_t_p(fd)

sx_user_channel_t_p_assign(user_channel_p, user_channel)
host_ifc_trap_id_register(SX_ACCESS_CMD_REGISTER, trap_id, user_channel_p)
user_channel = sx_user_channel_t_p_value(user_channel_p)
print(("trap_id =%d, channel type=%d, channel fd =%d, rc=%d" % (trap_id, user_channel.type, user_channel.channel.fd.fd, rc)))

if args.deinit:
    print("--------------- TRAP ID DEREGISTER -----------------------------")
    host_ifc_trap_id_register(SX_ACCESS_CMD_DEREGISTER, trap_id, user_channel_p)

    print("--------------- TRAP ID UNSET -----------------------------")
    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)

    print("--------------- TRAP GROUP UNSET  -----------------------------")
    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)

    print("--------------- HOST IFC CLOSE------------------------------")
    rc = sx_api_host_ifc_close(handle, fd_p)
    print(("sx_api_host_ifc_close, rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)
    fd = sx_fd_t_p_value(fd_p)
    print(("fd = %d" % (fd.fd)))

sx_api_close(handle)
