#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration using following APIs:
- sx_api_host_ifc_trap_group_ext_set

Example below covers the following flow:
  1. Create trap group
  2. Edit trap group
  3. Destroy trap group
'''
import sys
import errno
import argparse
from test_infra_common import *
from python_sdk_api.sx_api import *

SPECTRUM_SWID = 0


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_group_ext_set example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def host_ifc_trap_group_handle(handle, cmd, trap_group, prio):
    ''' CREATE/SET / EDIT / DESTROY/UNSET trap group '''
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = prio
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = False
    trap_group_attr.trap_group = trap_group
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(errno.EACCES)

    return sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group


""" ############################################################################################ """
if __name__ == "__main__":
    args = parse_args()

    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)

    print("--- HOST IFC TRAP GROUP CREATE  ---------------------------")
    trap_group = host_ifc_trap_group_handle(handle, trap_group_set_cmd, 0, 0)

    if trap_group_set_cmd == SX_ACCESS_CMD_CREATE:      # Only in trap group dynamic mode EDIT Is allowed
        edit_cmd = SX_ACCESS_CMD_EDIT
    else:
        edit_cmd = trap_group_set_cmd                   # Set-over-set

    print("--- HOST IFC TRAP GROUP EDIT  -------------------------")
    host_ifc_trap_group_handle(handle, edit_cmd, trap_group, 1)

    if args.deinit:
        print("--- HOST IFC TRAP GROUP DESTROY  -------------------------")
        host_ifc_trap_group_handle(handle, trap_group_unset_cmd, trap_group, 1)

    print("--- DONE -----------------------------------------------")

    sx_api_close(handle)
