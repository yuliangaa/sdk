#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

# string constants
TYPE = "TYPE"
MAX_SIZE = "MAX_SIZE"
MAX_ALPHA = "MAX_ALPHA"
MAX_MODE = "MAX_MODE"
PG = "PG"
TC = "TC"
SP = "SP"
POOL_ID = "POOL_ID"

parser = argparse.ArgumentParser(description='sx_api_cos_port_sb_type_example')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

log_port = 0x10001


def cos_port_sb_buff_set(cmd, attr_params_list):
    port_sb_attr_cnt = len(attr_params_list)
    port_sb_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    i = 0
    for attr in attr_params_list:
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_sb_attr_list_p, i)
        if attr[TYPE] == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
            attr_item.attr.ingress_port_pg_shared_buff_attr.pg = attr[PG]
            attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode = attr[MAX_MODE]
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size = attr[MAX_SIZE]
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha = attr[MAX_ALPHA]

            print(("[%d] type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E" % (i)))
            print(("[%d] pg = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg)))
            print(("[%d] pool id = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id)))

            if cmd == SX_ACCESS_CMD_SET:
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size)))
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha)))

        elif attr[TYPE] == SX_COS_INGRESS_PORT_ATTR_E:
            attr_item.type = SX_COS_INGRESS_PORT_ATTR_E
            attr_item.attr.ingress_port_shared_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item.attr.ingress_port_shared_buff_attr.max.mode = attr[MAX_MODE]
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    attr_item.attr.ingress_port_shared_buff_attr.max.max.size = attr[MAX_SIZE]
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha = attr[MAX_ALPHA]

            print(("[%d] type = SX_COS_INGRESS_PORT_ATTR_E" % (i)))
            print(("[%d] pool id = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.pool_id)))

            if cmd == SX_ACCESS_CMD_SET:
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size)))
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha)))

        elif attr[TYPE] == SX_COS_EGRESS_PORT_ATTR_E:
            attr_item.type = SX_COS_EGRESS_PORT_ATTR_E
            attr_item.attr.egress_port_shared_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item.attr.egress_port_shared_buff_attr.max.mode = attr[MAX_MODE]
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    attr_item.attr.egress_port_shared_buff_attr.max.max.size = attr[MAX_SIZE]
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    attr_item.attr.egress_port_shared_buff_attr.max.max.alpha = attr[MAX_ALPHA]

            print(("[%d] type = SX_COS_EGRESS_PORT_ATTR_E" % (i)))
            print(("[%d] pool id = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.pool_id)))

            if cmd == SX_ACCESS_CMD_SET:
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size)))
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.alpha)))

        elif attr[TYPE] == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            attr_item.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
            attr_item.attr.egress_port_tc_shared_buff_attr.tc = attr[TC]
            attr_item.attr.egress_port_tc_shared_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item.attr.egress_port_tc_shared_buff_attr.max.mode = attr[MAX_MODE]
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size = attr[MAX_SIZE]
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha = attr[MAX_ALPHA]

            print(("[%d] type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E" % (i)))
            print(("[%d] tc = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc)))
            print(("[%d] pool id = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.pool_id)))

            if cmd == SX_ACCESS_CMD_SET:
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size)))
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha)))

        elif attr[TYPE] == SX_COS_MULTICAST_ATTR_E:
            attr_item.type = SX_COS_MULTICAST_ATTR_E
            attr_item.attr.multicast_shared_buff_attr.sp = attr[SP]
            attr_item.attr.multicast_shared_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item.attr.multicast_shared_buff_attr.max.mode = attr[MAX_MODE]
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    attr_item.attr.multicast_shared_buff_attr.max.max.size = attr[MAX_SIZE]
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    attr_item.attr.multicast_shared_buff_attr.max.max.alpha = attr[MAX_ALPHA]

            print(("[%d] type = SX_COS_MULTICAST_ATTR_E" % (i)))
            print(("[%d] sp = %d" % (i, attr_item.attr.multicast_shared_buff_attr.sp)))
            print(("[%d] pool id = %d" % (i, attr_item.attr.multicast_shared_buff_attr.pool_id)))

            if cmd == SX_ACCESS_CMD_SET:
                if attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size)))
                elif attr[MAX_MODE] == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.alpha)))

        print("\n")

        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_sb_attr_list_p, i, attr_item)

        i = i + 1

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, port_sb_attr_list_p, port_sb_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_sb_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def cos_port_shared_buff_get_all():
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_shared_buff_get(attr_params_list):
    port_sb_attr_cnt_p = new_uint32_t_p()
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(len(attr_params_list))
    uint32_t_p_assign(port_sb_attr_cnt_p, len(attr_params_list))

    i = 0
    """ Set type and relevant parameters """
    for attr in attr_params_list:
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_sb_attr_list, i)
        if attr[TYPE] == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
            attr_item.attr.ingress_port_pg_shared_buff_attr.pg = attr[PG]
            attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_INGRESS_PORT_ATTR_E:
            attr_item.type = SX_COS_INGRESS_PORT_ATTR_E
            attr_item.attr.ingress_port_shared_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_EGRESS_PORT_ATTR_E:
            attr_item.type = SX_COS_EGRESS_PORT_ATTR_E
            attr_item.attr.egress_port_shared_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            attr_item.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
            attr_item.attr.egress_port_tc_shared_buff_attr.pool_id = attr[POOL_ID]
            attr_item.attr.egress_port_tc_shared_buff_attr.tc = attr[TC]

        elif attr[TYPE] == SX_COS_MULTICAST_ATTR_E:
            attr_item.type = SX_COS_MULTICAST_ATTR_E
            attr_item.attr.multicast_shared_buff_attr.pool_id = attr[POOL_ID]
            attr_item.attr.multicast_shared_buff_attr.sp = attr[SP]

        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_sb_attr_list, i, attr_item)

        i = i + 1

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    """ Print list """
    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    print(("sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, port_sb_attr_cnt, rc)))
    print("--------------------------------------------------------------------")
    print(("Respond count:  %d" % (port_sb_attr_cnt)))
    if len(attr_params_list) > 0:
        for i in range(0, port_sb_attr_cnt):
            port_buffer_attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_sb_attr_list, i)

            if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
                print(("[%d] type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E" % (i)))
                print(("[%d] pg = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg)))
                if port_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size)))
                elif port_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha)))
            elif port_buffer_attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
                print(("[%d] type = SX_COS_INGRESS_PORT_ATTR_E" % (i)))
                print(("[%d] pool id = %d" % (i, port_buffer_attr_item.attr.ingress_port_shared_buff_attr.pool_id)))
                if port_buffer_attr_item.attr.ingress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, port_buffer_attr_item.attr.ingress_port_shared_buff_attr.max.max.size)))
                elif port_buffer_attr_item.attr.ingress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, port_buffer_attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha)))
            elif port_buffer_attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
                print(("[%d] type = SX_COS_EGRESS_PORT_ATTR_E" % (i)))
                print(("[%d] pool id = %d" % (i, port_buffer_attr_item.attr.egress_port_shared_buff_attr.pool_id)))
                if port_buffer_attr_item.attr.egress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, port_buffer_attr_item.attr.egress_port_shared_buff_attr.max.max.size)))
                elif port_buffer_attr_item.attr.egress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, port_buffer_attr_item.attr.egress_port_shared_buff_attr.max.max.alpha)))
            elif port_buffer_attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
                print(("[%d] type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E" % (i)))
                print(("[%d] tc = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.tc)))
                print(("[%d] pool id = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.pool_id)))
                if port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size)))
                elif port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha)))
            elif port_buffer_attr_item.type == SX_COS_MULTICAST_ATTR_E:
                print(("[%d] type = SX_COS_MULTICAST_ATTR_E" % (i)))
                print(("[%d] sp = %d" % (i, port_buffer_attr_item.attr.multicast_shared_buff_attr.sp)))
                print(("[%d] pool id = %d" % (i, port_buffer_attr_item.attr.multicast_shared_buff_attr.pool_id)))
                if port_buffer_attr_item.attr.multicast_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_STATIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_STATIC_E" % (i)))
                    print(("[%d] size = %d" % (i, port_buffer_attr_item.attr.multicast_shared_buff_attr.max.max.size)))
                elif port_buffer_attr_item.attr.multicast_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                    print(("[%d] max mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E" % (i)))
                    print(("[%d] alpha = %d" % (i, port_buffer_attr_item.attr.multicast_shared_buff_attr.max.max.alpha)))
            print("\n")

    return port_sb_attr_list, port_sb_attr_cnt

######################################################
#    main
######################################################


def main():
    # Save for later de-configuration
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all()

    # default ingress/egress pools
    ing_pool_id = -1
    egr_pool_id = -1

    for i in range(original_port_sb_attr_cnt):
        attr = sx_cos_port_shared_buffer_attr_t_arr_getitem(original_port_sb_attr_list, i)
        if attr.type == SX_COS_INGRESS_PORT_ATTR_E and ing_pool_id == -1:
            ing_pool_id = attr.attr.ingress_port_shared_buff_attr.pool_id
        if attr.type == SX_COS_EGRESS_PORT_ATTR_E and egr_pool_id == -1:
            egr_pool_id = attr.attr.egress_port_shared_buff_attr.pool_id
        if ing_pool_id != -1 and egr_pool_id != -1:
            break

    """ PORT SHARED BUFF TYPE CMD: SET """
    print("\n\n---------------  PORT SHARED BUFF TYPE SET - CMD: SET -------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        PG: 4,
                        POOL_ID: ing_pool_id,
                        MAX_MODE: SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                        MAX_ALPHA: 5})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        PG: 2,
                        POOL_ID: ing_pool_id,
                        MAX_MODE: SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                        MAX_ALPHA: 5})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        PG: 3,
                        POOL_ID: ing_pool_id,
                        MAX_MODE: SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                        MAX_ALPHA: 5})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: ing_pool_id,
                        MAX_MODE: SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                        MAX_ALPHA: 5})
    cos_port_sb_buff_set(SX_ACCESS_CMD_SET, params_list)

    """ PORT SHARED BUFF TYPE GET """
    print("\n\n---------------  PORT SHARED BUFF TYPE GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 4})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 3})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: 1})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_ATTR_E,
                        POOL_ID: egr_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                        TC: 5,
                        POOL_ID: egr_pool_id})
    cos_port_shared_buff_get(params_list)

    """ PORT SHARED BUFF TYPE CMD: DELETE """
    print("\n\n---------------  PORT SHARED BUFF TYPE SET - CMD: DELETE ----------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    cos_port_sb_buff_set(SX_ACCESS_CMD_DELETE, params_list)

    """ PORT SHARED BUFF TYPE GET """
    print("\n\n---------------  PORT SHARED BUFF TYPE GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    cos_port_shared_buff_get(params_list)

    """ PORT SHARED BUFF TYPE CMD: DELETE_ALL """
    print("\n\n---------------  PORT SHARED BUFF TYPE SET - CMD: DELETE_ALL ------------")
    params_list = []
    cos_port_sb_buff_set(SX_ACCESS_CMD_DELETE_ALL, params_list)

    """ PORT SHARED BUFF TYPE GET """
    print("\n\n---------------  PORT SHARED BUFF TYPE GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 4})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 3})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: ing_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_ATTR_E,
                        POOL_ID: egr_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                        TC: 5,
                        POOL_ID: egr_pool_id})
    cos_port_shared_buff_get(params_list)

    if args.deinit:
        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list, original_port_sb_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)


if __name__ == "__main__":
    main()
