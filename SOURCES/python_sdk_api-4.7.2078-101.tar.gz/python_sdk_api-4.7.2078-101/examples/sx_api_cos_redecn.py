#!/usr/bin/env python
"""
This file contains Python command example for the RED/ECN module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. Set/Get general RED/ECN parameters
    2. Create Absolute RED/ECN profile
    3. Enable all traffic classes for RED and ECN on a specific egress port
    4. Disable above configuration
    5. Read counters
"""
#import pydevd
# pydevd.settrace("10.224.13.101")
import errno
import sys
from python_sdk_api.sx_api import *
import sys
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_redecn')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

args = parser.parse_args()
print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

# get the current global configuration (and save it) for later de-configuration
original_redecn_globals_p = new_sx_cos_redecn_global_t_p()
rc = sx_api_cos_redecn_general_param_get(handle, original_redecn_globals_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_general_param_get failed rc = %d" % (rc))
    sys.exit(rc)
original_redecn_globals = sx_cos_redecn_global_t_p_value(original_redecn_globals_p)

# set redecn global configuration
redecn_globals = sx_cos_redecn_global_t()
redecn_globals.source_congestion_detection_only = True
redecn_globals.weight = 1000
rc = sx_api_cos_redecn_general_param_set(handle, redecn_globals)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_general_param_set failed rc = %d" % (rc))
    sys.exit(rc)

# get the global configuration
redecn_globals_p = new_sx_cos_redecn_global_t_p()
rc = sx_api_cos_redecn_general_param_get(handle, redecn_globals_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_general_param_get failed rc = %d" % (rc))
    sys.exit(rc)

redecn_globals_out = sx_cos_redecn_global_t_p_value(redecn_globals_p)
print(("weight = %d, source congestion only = %r" % (redecn_globals_out.weight,
                                                     redecn_globals_out.source_congestion_detection_only)))

# get a single port to "play" with
port_attributes_list = new_sx_port_attributes_t_arr(64)
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 64)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
port_cnt = uint32_t_p_value(port_cnt_p)

if rc != SX_STATUS_SUCCESS or port_cnt == 0:
    print("sx_api_port_device_get failed rc = %d port_cnt = %d" % (rc, port_cnt))
    sys.exit(rc)

port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, 0)
port = port_attributes.log_port
print("using port 0x%X" % port)

# create redecn profile (absolute, 64 min, 64 max, hdp = 100%)
profile_atts = sx_cos_redecn_profile_attributes_t()
profile_atts.mode = SX_COS_REDECN_MODE_ABSOLUTE
profile_atts.high_drop_percent = 100
profile_atts.values.absolute_mode.min = 64
profile_atts.values.absolute_mode.max = 64

redecn_profile_p = new_sx_cos_redecn_profile_t_p()
rc = sx_api_cos_redecn_profile_set(handle, SX_ACCESS_CMD_ADD, profile_atts, redecn_profile_p)

if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_profile_set failed rc = %d " % (rc))
    sys.exit(rc)

redecn_profile = sx_cos_redecn_profile_t_p_value(redecn_profile_p)

print("created redecn profile %d" % (redecn_profile))

enable_params = sx_cos_redecn_enable_params_t()
enable_params.ecn_enabled = True
enable_params.red_enabled = True
enable_params.mode = SX_COS_REDECN_MODE_ABSOLUTE
traffic_classes = new_sx_cos_traffic_class_t_arr(8)
for i in range(0, 8):
    sx_cos_traffic_class_t_arr_setitem(traffic_classes, i, i)

# save enable params for later de-configuration
original_enable_params = []
for i in range(0, 8):
    traffic_class = sx_cos_traffic_class_t_arr_getitem(traffic_classes, i)
    enable_params_p = new_sx_cos_redecn_enable_params_t_p()
    rc = sx_api_cos_redecn_tc_enable_get(handle, port, traffic_class, enable_params_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_redecn_tc_enable_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_enable_params.append(enable_params_p)

rc = sx_api_cos_redecn_tc_enable_set(handle, port, traffic_classes, 8, enable_params)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_tc_enable_set failed rc = %d " % (rc))
    sys.exit(rc)

print('enabled port successfuly')

bind_params = sx_cos_redecn_bind_params_t()
bind_params.tc_profile = redecn_profile
for i in range(0, int(SX_COS_REDECN_FLOW_TYPE_MAX) + 1):
    rc = sx_api_cos_redecn_profile_tc_bind_set(handle, port, SX_ACCESS_CMD_BIND, traffic_classes, 8, i, bind_params)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_redecn_tc_enable_set failed rc = %d " % (rc))
        sys.exit(rc)

print('bound all flows to profile')

for i in range(0, int(SX_COS_REDECN_FLOW_TYPE_MAX) + 1):
    rc = sx_api_cos_redecn_profile_tc_bind_set(handle, port, SX_ACCESS_CMD_UNBIND, traffic_classes, 8, i, bind_params)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_redecn_tc_enable_set failed rc = %d " % (rc))
        sys.exit(rc)

print('unbound all flows to profile')

counters = new_sx_cos_redecn_port_counters_t_p()
rc = sx_api_cos_redecn_counters_get(handle, SX_ACCESS_CMD_READ, port, counters)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_cos_redecn_counters_get failed rc = %d " % (rc))
    sys.exit(rc)

print('complete reading counters')

counters_str = ''
for i in range(0, 8):
    counters_str += ("| tc %d dropped %d " % (i, uint64_t_arr_getitem(counters.tc_red_dropped_packets, i)))
for i in range(0, 8):
    counters_str += ("| tc %d ECN marked %d " % (i, uint64_t_arr_getitem(counters.tc_ecn_marked_packets, i)))

counters_str += ("| ECN marked %d |" % counters.ecn_marked_packets)
print(counters_str)

if args.deinit:
    for i, original_enable_param in enumerate(original_enable_params):
        traffic_class = sx_cos_traffic_class_t_arr_getitem(traffic_classes, i)
        traffic_class_p = new_sx_cos_traffic_class_t_p()
        sx_cos_traffic_class_t_p_assign(traffic_class_p, traffic_class)
        rc = sx_api_cos_redecn_tc_enable_set(handle, port, traffic_class_p, 1, original_enable_param)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_redecn_tc_enable_set failed rc = %d " % (rc))
            sys.exit(rc)

    rc = sx_api_cos_redecn_profile_set(handle, SX_ACCESS_CMD_DELETE, profile_atts, redecn_profile_p)
    if rc != SX_STATUS_SUCCESS:
        print('delete profile failed, rc=%d', rc)
        sys.exit(rc)
    print('deleted profile')

    rc = sx_api_cos_redecn_general_param_set(handle, original_redecn_globals)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_redecn_general_param_set failed rc = %d" % (rc))
        sys.exit(rc)


sx_api_close(handle)
