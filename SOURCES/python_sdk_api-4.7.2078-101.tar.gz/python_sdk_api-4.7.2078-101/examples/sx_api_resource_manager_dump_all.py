#!/usr/bin/env python
'''
This file contains Python command example for the RM module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This is a utility script that allows the user to dump the current resource utilization
in the SDK from both a Hardare and Logical resource perspective.
'''
import os
import sys

from python_sdk_api.sx_api import *
from python_sdk_api import sxd_api

from test_infra_common import *
from sx_api_resource_manager_apis import get_logical_utilization, get_logical_free_entries_count, get_hw_utilization

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
EXAMPLE_RESOURCES = [RM_SDK_TABLE_TYPE_UC_MAC_E, RM_SDK_TABLE_TYPE_MC_MAC_E, RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E,
                     RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_SHORT_UC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_LONG_UC_E,
                     RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E,
                     RM_SDK_TABLE_TYPE_ARP_IPV4_E, RM_SDK_TABLE_TYPE_ARP_IPV6_E, RM_SDK_TABLE_TYPE_ADJACENCY_E,
                     RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E, RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E, RM_SDK_TABLE_TYPE_ACL_PBS_E,
                     RM_SDK_TABLE_TYPE_ERIF_LIST_E, RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, RM_SDK_TABLE_TYPE_VLAN_E,
                     RM_SDK_TABLE_TYPE_VPORTS_E, RM_SDK_TABLE_TYPE_FID_E, RM_SDK_TABLE_TYPE_VNI_E, RM_SDK_TABLE_TYPE_ACL_E,
                     RM_SDK_TABLE_TYPE_RIPS_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV4_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV6_E,
                     RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E, RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E, RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E,
                     RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E,
                     RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E, RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, RM_SDK_TABLE_TYPE_ACL_GROUPS_E, RM_SDK_TABLE_TYPE_SPAN_E]
#######################################################################
# function definitions
#######################################################################


def get_chip_type():
    """
    :return: SX_CHIP_TYPE_SPECTRUM \ SX_CHIP_TYPE_SPECTRUM2 \ SX_CHIP_TYPE_SPECTRUM3
    """
    print("Retrieving Chip Type from SDK")
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 1)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)

    device_info = sx_device_info_t_arr_getitem(device_info_list_p, 0)
    chip_type = device_info.dev_type
    if chip_type == SX_CHIP_TYPE_SPECTRUM_A1:
        chip_type = SX_CHIP_TYPE_SPECTRUM

    return chip_type


def get_chip_dev_id_and_rev():
    mgir = sxd_api.ku_mgir_reg()
    meta = sxd_api.sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = sxd_api.SXD_ACCESS_CMD_GET

    rc = sxd_api.sxd_access_reg_init(0, None, 2)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_mgir(mgir, meta, 1, None, None)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_deinit()
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"


def router_deinit():
    " This function de-initializes the router. "
    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"


def tunnel_init():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_params)
    rc = sx_api_tunnel_init_set(handle, general_param_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)


######################################################
#    main
######################################################
def main():

    chip_type = get_chip_type()

    print("\nHW Table Utilization\n")
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_TCAM_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_KVD_HASH_E)
    if chip_type == SX_CHIP_TYPE_SPECTRUM:
        get_hw_utilization(handle, RM_HW_TABLE_TYPE_KVD_LINEAR_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_PGT_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_FLOW_COUNTER_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_ACL_REGIONS_TABLE_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_SPAN_E)
    if chip_type != SX_CHIP_TYPE_SPECTRUM:  # supported in SPC2+
        get_hw_utilization(handle, RM_HW_TABLE_TYPE_GP_REGISTER_E)
        EXAMPLE_RESOURCES.append(RM_SDK_TABLE_TYPE_GP_REGISTER_E)

    # get logical free entries
    print("\nLogical Free Entries Count\n")
    get_logical_free_entries_count(handle, EXAMPLE_RESOURCES)

    print("\nLogical Table Utilization\n")
    get_logical_utilization(handle, [])

    sx_api_close(handle)


if __name__ == "__main__":
    main()
