#!/usr/bin/env python

import sys
import argparse
import test_infra_common as common_lib
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *


def parse_args():
    parser = argparse.ArgumentParser(description='PMAOS Register GET debug script')
    parser.add_argument('--log_port', default=0x10001, type=common_lib.auto_int, help='Logical port ID')
    return parser.parse_args()


def main():
    admin_st_dict = {1: 'ENABLED', 2: 'CONFIG_DISABLED', 3: 'ENABLED_ONCE', }
    oper_st_dict = {0: 'INIT', 1: 'PLUGGED_EN', 2: 'UNPLUGGED', 3: 'PLUGGED_ERROR', 4: 'PLUGGED_DISABLE'}
    err_typ_dict = {0: 'PWR_BUDGET_EXCEEDED',
                    1: 'LONG_RNG_4_NON_MLX_MOD',
                    2: 'BUS_STUCK(I2C/CLOCK)',
                    3: 'BAD_OR_UNSUP_EEPROM',
                    4: 'ENF_PART_NUM_LIST',
                    5: 'UNSUP_CABLE',
                    6: 'HIGH_TEMP',
                    7: 'BAD_CABLE(SHORTED)',
                    8: 'PMD_TYPE_NOT_ENABLED',
                    9: 'LASER_TEC_FLR',
                    10: 'HIGH_CURRENT',
                    11: 'HIGH_VOLTAGE',
                    12: 'PCIE_SYS_PWR_SLOT_EXCEEDED',
                    13: 'HIGH_POWER',
                    14: 'MOD_FSM_FAULT'
                    }

    rc, handle = sx_api_open(None)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to open SDK Handle, RC = %d, Please make sure SDK Running" % rc)
        sys.exit(rc)

    print("[+] PMAOS register access start")

    args = parse_args()
    input_log_port = args.log_port

    ports_attributes_list = common_lib.ports_attributes_get(handle)
    port_cnt = len(ports_attributes_list)
    port_module_map, module_port_map = common_lib.get_port_module_mapping(ports_attributes_list, port_cnt)

    if str(hex(input_log_port)) not in port_module_map.keys():
        print("Invalid Log Port {}".format(hex(input_log_port)))
        sx_api_close(handle)
        sys.exit(1)

    module_slot_id = port_module_map[str(hex(input_log_port))]
    slot_id = module_slot_id[0]
    module_id = module_slot_id[1]
    local_port = common_lib.get_local_port(input_log_port)
    print("input logical port = 0x%x" % input_log_port)
    print("Corresponding Local port = %d" % local_port)
    print("Corresponding Slot = %d" % slot_id)
    print("Corresponding Module Id = %d" % module_id)

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if rc != SXD_STATUS_SUCCESS:
        print("Failed to init SXD Access, RC = %d" % rc)
        sx_api_close(handle)
        sys.exit(rc)

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET
    pmaos = ku_pmaos_reg()
    pmaos.slot_index = slot_id
    pmaos.module = module_id
    pmaos.oper_status = 0
    pmaos.admin_status = 0
    pmaos.ase = 0
    pmaos.ee = 0
    pmaos.e = 0
    pmaos.rst = 0
    pmaos.slot_index = 0

    print("[+] Get pmaos\n")
    rc = sxd_access_reg_pmaos(pmaos, meta, 1, None, None)
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_pmaos failed, RC = %d" % rc)
        sxd_access_reg_deinit()
        sx_api_close(handle)
        sys.exit(rc)

    print("[+] PMAOS rst= {}".format(pmaos.rst))
    print("[+] PMAOS slot= {}".format(pmaos.slot_index))
    print("[+] PMAOS module= {}".format(pmaos.module))
    print("[+] PMAOS ase = {}".format(pmaos.ase))
    print("[+] PMAOS ee = {}".format(pmaos.ee))
    print("[+] PMAOS e = {}".format(pmaos.e))

    print("[+] PMAOS admin_status is {}:{}".format(pmaos.admin_status, admin_st_dict[pmaos.admin_status]))
    print("[+] Port oper_status is {}:{}\n".format(pmaos.oper_status, oper_st_dict[pmaos.oper_status]))
    print("[+] PMAOS oper notif = {}".format(pmaos.operational_notification))
    print("[+] PMAOS error_type is {}:{}".format(pmaos.error_type, err_typ_dict[pmaos.error_type]))

    sxd_access_reg_deinit()
    sx_api_close(handle)


if __name__ == "__main__":
    main()
