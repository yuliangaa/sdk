#!/usr/bin/env python

import sys
import errno
import time
import os
import argparse

from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

print("[+] Read/write QPCR register")

parser = argparse.ArgumentParser(description='QPCR read/write utility')
parser.add_argument('--cmd', default=0, type=int, help="READ(0), WRITE(1)")
parser.add_argument('--local_port', default=0, type=int, help="Local Port (1)")
parser.add_argument('--global_policer', default=2, type=int, help="Global(2), Storm control(3)")
parser.add_argument('--pid', default=0, type=int, help="Policer id (0)")
parser.add_argument('--bytes', default=0, type=int, help="Bytes(1)/Packets(0) ")
parser.add_argument('--ir_units', default=0, type=int, help="Units 10^6bps(0)/units 10^3 bps(1)")
parser.add_argument('--cbs_ebs', default=4, type=int, help="CBS and EBS(0)")
parser.add_argument('--cir_eir', default=0, type=int, help="CIR and EIR(0)")
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

qpcr = ku_qpcr_reg()

qpcr.use_bytes = args.bytes
qpcr.ir_units = args.ir_units
qpcr.committed_burst_size = args.cbs_ebs
qpcr.committed_information_rate = args.cir_eir

qpcr.color_aware = 0
qpcr.type = 0
qpcr.mode = 0
qpcr.extended_burst_size = args.cbs_ebs
qpcr.exceed_action = 0
qpcr.violate_action = 0
qpcr.excess_information_rate = args.cir_eir

""" Get QPCR """
meta.access_cmd = SXD_ACCESS_CMD_GET
qpcr.port, qpcr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

qpcr.global_policer = args.global_policer
qpcr.pid = args.pid
print(("QPCR GET: Local port: %d, Global:%d Pid:%d" % (qpcr.port, qpcr.global_policer, qpcr.pid)))

rc = sxd_access_reg_qpcr(qpcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get QPCR register, rc: %d" % (rc)

print("QPCR GET RESULT:")
print(("local port: %d" % qpcr.port))
print(("lp_msb: %d" % qpcr.lp_msb))
print(("Global: %d" % qpcr.global_policer))
print(("Pid: %d" % qpcr.pid))
print(("Bytes: %d" % qpcr.use_bytes))
print(("ir_units: %d" % qpcr.ir_units))
print(("CBS: %d" % qpcr.committed_burst_size))
print(("CIR: %d" % qpcr.committed_information_rate))

if args.cmd != 1:
    sys.exit(0)

if args.deinit:
    original_qpcr = ku_qpcr_reg()

    original_qpcr.port, original_qpcr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

    original_qpcr.global_policer = args.global_policer
    original_qpcr.pid = args.pid

    meta.access_cmd = SXD_ACCESS_CMD_GET
    rc = sxd_access_reg_qpcr(original_qpcr, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get QPCR register, rc: %d" % (rc)

""" Set QPCR """
meta.access_cmd = SXD_ACCESS_CMD_SET
qpcr.port, qpcr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

qpcr.global_policer = args.global_policer
qpcr.pid = args.pid

qpcr.use_bytes = args.bytes
qpcr.ir_units = args.ir_units
qpcr.committed_burst_size = args.cbs_ebs
qpcr.committed_information_rate = args.cir_eir

qpcr.color_aware = 0
qpcr.type = 1
qpcr.mode = 0
qpcr.extended_burst_size = args.cbs_ebs
qpcr.exceed_action = 2
qpcr.violate_action = 1
qpcr.excess_information_rate = args.cir_eir

print(("QPCR SET: Local port: %d, Global:%d Pid:%d" % (qpcr.port, qpcr.global_policer, qpcr.pid)))
print(("local port: %d" % qpcr.port))
print(("lp_msb: %d" % qpcr.lp_msb))
print(("Global: %d" % qpcr.global_policer))
print(("Pid: %d" % qpcr.pid))
print(("Bytes: %d" % qpcr.use_bytes))
print(("ir_units: %d" % qpcr.ir_units))
print(("CBS: %d" % qpcr.committed_burst_size))
print(("CIR: %d" % qpcr.committed_information_rate))

rc = sxd_access_reg_qpcr(qpcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set QPCR register, rc: %d" % (rc)

""" Get QPCR """
meta.access_cmd = SXD_ACCESS_CMD_GET
qpcr.port, qpcr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

qpcr.global_policer = args.global_policer
qpcr.pid = args.pid
qpcr.type = 0  # Should be reserved for read
qpcr.exceed_action = 0  # Should be reserved for read
qpcr.violate_action = 0  # Should be reserved for read
print(("QPCR GET: Local port: %d, Global:%d Pid:%d" % (qpcr.port, qpcr.global_policer, qpcr.pid)))

rc = sxd_access_reg_qpcr(qpcr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get QPCR register, rc: %d" % (rc)

print("QPCR GET RESULT:")
print(("local port: %d" % qpcr.port))
print(("lp_msb: %d" % qpcr.lp_msb))
print(("Global: %d" % qpcr.global_policer))
print(("Pid: %d" % qpcr.pid))
print(("Bytes: %d" % qpcr.use_bytes))
print(("ir_units: %d" % qpcr.ir_units))
print(("CBS: %d" % qpcr.committed_burst_size))
print(("CIR: %d" % qpcr.committed_information_rate))

if args.deinit:
    print("Deinit")
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_qpcr(original_qpcr, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set QPCR register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

sys.exit(0)
