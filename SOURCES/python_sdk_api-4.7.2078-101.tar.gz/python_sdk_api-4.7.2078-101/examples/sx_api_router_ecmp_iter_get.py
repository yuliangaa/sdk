#!/usr/bin/env python
'''
This file contains Python command example for the router ECMP container iterator get function.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

'''
import sys
import errno
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_router_ecmp_iter_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def print_id_array(arr, count):
    id_list = []
    for i in range(0, count):
        id_list.append(sx_ecmp_id_t_arr_getitem(arr, i))
    print("%r\n" % id_list)


# init to the params
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if rc != SX_STATUS_SUCCESS:
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

router_init(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE)

# Create a few ECMP containers
ecmp_id_p = new_sx_ecmp_id_t_p()
ecmp_id_cnt = 64
ecmp_id_arr_created = new_sx_ecmp_id_t_arr(ecmp_id_cnt)
ecmp_id_arr_get = new_sx_ecmp_id_t_arr(ecmp_id_cnt)
ecmp_id_arr_cnt_p = new_uint32_t_p()
next_hop_cnt_p = new_sx_ecmp_id_t_p()
uint32_t_p_assign(next_hop_cnt_p, 0)

for i in range(0, ecmp_id_cnt):
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_set failed, rc=%d" % (rc)
    sx_ecmp_id_t_arr_setitem(ecmp_id_arr_created, i, sx_ecmp_id_t_p_value(ecmp_id_p))
print(("Successfully created %d ECMP containers. The created ECMP container IDs are:" % (ecmp_id_cnt)))
print_id_array(ecmp_id_arr_created, ecmp_id_cnt)

# Get the total number of ECMP containers
uint32_t_p_assign(ecmp_id_arr_cnt_p, 0)
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The total number of ECMP containers is %d\n" % (uint32_t_p_value(ecmp_id_arr_cnt_p))))

# Get an ECMP Container ID
uint32_t_p_assign(ecmp_id_arr_cnt_p, 1)
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET, sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 5), None, ecmp_id_arr_get, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The input ECMP container ID is %d, the returned number of ECMP container IDs is %d, the returned ECMP container IDs are:" % (sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 5), uint32_t_p_value(ecmp_id_arr_cnt_p))))
print_id_array(ecmp_id_arr_get, uint32_t_p_value(ecmp_id_arr_cnt_p))

# Get the first few ECMP container IDs
uint32_t_p_assign(ecmp_id_arr_cnt_p, 5)
print(("Try to get the first %d ECMP container IDs" % (uint32_t_p_value(ecmp_id_arr_cnt_p))))
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, ecmp_id_arr_get, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The returned number of ECMP container IDs is %d, the returned ECMP container IDs are:" % (uint32_t_p_value(ecmp_id_arr_cnt_p))))
print_id_array(ecmp_id_arr_get, uint32_t_p_value(ecmp_id_arr_cnt_p))

# Get the first count ECMP container IDs where count is more than the total number of ECMP containers in the internal DB
uint32_t_p_assign(ecmp_id_arr_cnt_p, ecmp_id_cnt + 1)
print(("Try to get the first %d ECMP container IDs" % (uint32_t_p_value(ecmp_id_arr_cnt_p))))
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, ecmp_id_arr_get, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The returned number of ECMP container IDs is %d, the returned ECMP container IDs are:" % (uint32_t_p_value(ecmp_id_arr_cnt_p))))
print_id_array(ecmp_id_arr_get, uint32_t_p_value(ecmp_id_arr_cnt_p))

# Get the next few ECMP container IDs after a specific ECMP container ID
uint32_t_p_assign(ecmp_id_arr_cnt_p, 5)
print(("Try to get the next %d ECMP container IDs after ECMP container ID %d" % (uint32_t_p_value(ecmp_id_arr_cnt_p), sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6))))
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GETNEXT, sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6), None, ecmp_id_arr_get, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The input ECMP container ID is %d, the returned number of ECMP container IDs is %d, the returned ECMP container IDs are:" % (sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6), uint32_t_p_value(ecmp_id_arr_cnt_p))))
print_id_array(ecmp_id_arr_get, uint32_t_p_value(ecmp_id_arr_cnt_p))

# Get the next count ECMP container IDs after a specific ECMP container ID where count is more than the total number of ECMP containers in the internal DB
uint32_t_p_assign(ecmp_id_arr_cnt_p, ecmp_id_cnt + 1)
print(("Try to get the next %d ECMP container IDs after ECMP container ID %d" % (uint32_t_p_value(ecmp_id_arr_cnt_p), sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6))))
rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GETNEXT, sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6), None, ecmp_id_arr_get, ecmp_id_arr_cnt_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_iter_get failed, rc=%d" % (rc)
print(("The input ECMP container ID is %d, the returned number of ECMP container IDs is %d, the returned ECMP container IDs are:" % (sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, 6), uint32_t_p_value(ecmp_id_arr_cnt_p))))
print_id_array(ecmp_id_arr_get, uint32_t_p_value(ecmp_id_arr_cnt_p))

if args.deinit:
    # Delete the ECMP containers
    for i in range(0, ecmp_id_cnt):
        sx_ecmp_id_t_p_assign(ecmp_id_p, sx_ecmp_id_t_arr_getitem(ecmp_id_arr_created, i))
        rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_router_ecmp_set failed, rc=%d" % (rc)

    router_deinit()

sx_api_close(handle)
