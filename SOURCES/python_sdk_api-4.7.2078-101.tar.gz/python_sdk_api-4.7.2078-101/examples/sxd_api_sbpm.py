#!/usr/bin/env python

import sys
import errno
import argparse

from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

print("[+] Read SBPM register")

parser = argparse.ArgumentParser(description='SBPM read utility')
parser.add_argument('--local_port', default=1, type=int, help="Local Port")
parser.add_argument('--dir', default=1, type=int, help="Ingress(0), Egress(1)")
parser.add_argument('--pool', default=0, type=int, help="Pool ID")
parser.add_argument('--descriptors', default=0, type=int, help="Descriptors or data pool")
args = parser.parse_args()

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initialize register access.\nPlease check that SDK is running.")
    sys.exit(rc)

sbpm = ku_sbpm_reg()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

""" Get SBPM """
meta.access_cmd = SXD_ACCESS_CMD_GET
sbpm.local_port, sbpm.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

sbpm.pool = args.pool
sbpm.dir = args.dir
sbpm.desc = args.descriptors
print(("SBPM GET: Local port: %d, Dir:%d pool:%d" % (sbpm.local_port, sbpm.dir, sbpm.pool)))

rc = sxd_access_reg_sbpm(sbpm, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get SBPM register, rc: %d" % (rc)

print(("SBPM GET RC=%d RESULT:" % rc))
print(("local_port: %d" % sbpm.local_port))
print(("lp_msb: %d" % sbpm.lp_msb))
print(("dir: %d" % sbpm.dir))
print(("pool: %d" % sbpm.pool))
print(("min_buff: %d" % sbpm.min_buff))
print(("max_buff: %d" % sbpm.max_buff))
print(("infinite_size: %d" % sbpm.infinite_size))

print(("buff_occupancy: %d" % sbpm.buff_occupancy))
print(("max_buff_occupancy: %d" % sbpm.max_buff_occupancy))

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("SBPM GET is Done")

sys.exit(0)
