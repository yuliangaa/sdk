#!/usr/bin/env python

import sys
import errno
import time
import os
from python_sdk_api.sxd_api import *
import argparse


print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if rc != SXD_STATUS_SUCCESS:
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] reading mcia")
mcia = ku_mcia_reg()

parser = argparse.ArgumentParser(description='MCIA reading utility')
parser.add_argument('--slot', default=0, type=int, help=" value is 0 for 1U system and (1..8) for modular system")
parser.add_argument('--start_module', default=0, type=int, help="start from module number (label_port - 1)")
parser.add_argument('--end_module', default=999, type=int, help="optional: end with module number (label_port - 1)")
args = parser.parse_args()

slot = args.slot
start_module = args.start_module
end_module = args.end_module

if start_module > 199 or start_module < 0:
    start_module = 199

if end_module == 999:
    end_module = start_module

if end_module > 199 or end_module < 0:
    end_module = 199

if start_module > end_module:
    print("Error: start_module > end_module")
    sys.exit(1)


for mcia.module in range(start_module, end_module + 1):
    mcia.slot_index = slot
    print("")
    print("")
    print("[++++++++++++++++++++++++++++++++++++++++++++++++] mcia.module = " + str(mcia.module))
    print("")

    for iter in range(12):

        sub_iter = iter
        mcia.i2c_device_address = 80
        if iter > 5:
            mcia.i2c_device_address = 81
            sub_iter = iter - 6

        mcia.page_number = 0

        mcia.device_address = sub_iter * 48

        mcia.size = 48
        if sub_iter == 5:
            mcia.size = 16

        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0
        meta.access_cmd = SXD_ACCESS_CMD_GET

        print("")
        if (mcia.i2c_device_address == 80):
            print("[+++++++++++] reading " + "mcia.slot = " + str(mcia.slot_index) + "  mcia module " + str(mcia.module) + ", block A0, bytes " + str(mcia.device_address) + " .. " + str(mcia.device_address + mcia.size - 1))
        else:
            print("[+++++++++++] reading " + "mcia.slot = " + str(mcia.slot_index) + "  mcia module " + str(mcia.module) + ", block A2, bytes " + str(mcia.device_address) + " .. " + str(mcia.device_address + mcia.size - 1))

        rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)

        if (rc != SXD_STATUS_SUCCESS):
            if (mcia.i2c_device_address == 80):
                print("Can't retrieve data from " + "mcia.slot = " + str(mcia.slot_index) + "  module " + str(mcia.module) + ", BLOCK A0, aborting ")
            else:
                print("Can't retrieve data from " + "mcia.slot = " + str(mcia.slot_index) + "  module " + str(mcia.module) + ", BLOCK A2, aborting... ")
            break

        else:
            print("mcia.slot = " + str(mcia.slot_index))
            print("mcia.module = " + str(mcia.module))
            print("mcia.l = " + str(mcia.l))
            print("mcia.status = " + str(mcia.status))
            print("mcia.i2c_device_address = " + str(mcia.i2c_device_address))
            print("mcia.page_number = " + str(mcia.page_number))
            print("mcia.device_address = " + str(mcia.device_address))
            print("mcia.size = " + str(mcia.size))

            print("mcia.dword_0  = 0x%08X" % (mcia.dword_0))
            print("mcia.dword_1  = 0x%08X" % (mcia.dword_1))
            print("mcia.dword_2  = 0x%08X" % (mcia.dword_2))
            print("mcia.dword_3  = 0x%08X" % (mcia.dword_3))
            if (mcia.size == 48):
                print("mcia.dword_4  = 0x%08X" % (mcia.dword_4))
                print("mcia.dword_5  = 0x%08X" % (mcia.dword_5))
                print("mcia.dword_6  = 0x%08X" % (mcia.dword_6))
                print("mcia.dword_7  = 0x%08X" % (mcia.dword_7))
                print("mcia.dword_8  = 0x%08X" % (mcia.dword_8))
                print("mcia.dword_9  = 0x%08X" % (mcia.dword_9))
                print("mcia.dword_10 = 0x%08X" % (mcia.dword_10))
                print("mcia.dword_11 = 0x%08X" % (mcia.dword_11))

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
