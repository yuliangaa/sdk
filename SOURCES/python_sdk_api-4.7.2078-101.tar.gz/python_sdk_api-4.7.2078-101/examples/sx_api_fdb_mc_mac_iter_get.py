#!/usr/bin/env python
'''
This file contains Python command example for the fdb_mc_mac iterator get function.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import time
import traceback
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_fdb_mc_mac_iter_get example')
    parser.add_argument('--mac_count', type=int, default=3, help='Amount of MAC Entries to create')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def cmp(a, b):
    return (a > b) - (a < b)


def main():
    args = parse_args()
    MAX_MAC_COUNT = 256
    if not args.mac_count or args.mac_count > MAX_MAC_COUNT:
        print("ERROR: MAC count should be positive integer, up to maximum %d" % MAX_MAC_COUNT)
        sys.exit(1)

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    MAX_KEY_NUM = args.mac_count
    ret_code = 1
    try:
        key_list = []

        # Create some MC MAC keys
        index1 = 0
        index2 = 0
        index = 0
        for i in range(1, MAX_KEY_NUM + 1):
            mac_addr = ether_addr(0x01, 0x11, 0x22, 0x33, 0x44, (i - 1) % 64)
            vid = ((i - 1) // 64 + 1)

            # Do not create key {vid == 1, mac == {0x01,0x11,0x22,0x33,0x44, 0x01}}
            # And record the index right after this key
            if vid == 1 and ((i - 1) % 64 == 1):
                index1 = index
                continue

            # Do not create keys with vid == 2
            if vid == 2:
                continue

            # Record the first key with vid == 3
            if vid == 3 and index2 == 0:
                index2 = index

            key = sx_fdb_mc_mac_key_t()
            key.vid = vid
            key.mc_mac_addr = mac_addr

            rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, vid, mac_addr, None, 0)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_fdb_mc_mac_addr_set failed, rc=%d" % rc)
            key_list.append(key)
            index = index + 1

        num_keys = len(key_list)
        print("Created MC MAC key list: (%d keys)" % num_keys)
        for x in key_list:
            print("vid: %d mac: %s" % (x.vid, x.mc_mac_addr.to_str()))

        print("--------------------------------GET---------------------------------------------------------------------------")

        key_cnt_p = new_uint32_t_p()
        key_list_p = new_sx_fdb_mc_mac_key_t_arr(MAX_KEY_NUM)
        key_p = new_sx_fdb_mc_mac_key_t_p()
        # Use GET to get all elements in the list
        key_get_list = []
        for key in key_list:
            uint32_t_p_assign(key_cnt_p, 1)
            sx_fdb_mc_mac_key_t_p_assign(key_p, key)
            print("GET    vid: %d, mac: %s, key_cnt: %d" % (key.vid, key.mc_mac_addr.to_str(), 1))
            rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, key_p, None, key_list_p, key_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)

            key_cnt = uint32_t_p_value(key_cnt_p)
            assert key_cnt == 1, "Returned key count is not 1"

            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, 0)
            print("Return vid: %d, mac: %s, key_cnt: %d" % (key_get.vid, key_get.mc_mac_addr.to_str(), key_cnt))

        print("--------------------------------COUNT---------------------------------------------------------------------------")

        # Get Count
        uint32_t_p_assign(key_cnt_p, 0)

        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        assert key_cnt == num_keys, "Count failed, expected %d, got %d" % (num_keys, key_cnt)
        print("Count successful, expected %d, got %d" % (num_keys, key_cnt))

        print("--------------------------------COUNT with a filter-------------------------------------------------------------")

        # Get Count with a vid filter
        uint32_t_p_assign(key_cnt_p, 0)

        filter = sx_fdb_mc_mac_filter_t()
        filter.filter_by_vid = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.vid = 1
        filter.filter_by_mac_addr = SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E
        filter_p = new_sx_fdb_mc_mac_filter_t_p()
        sx_fdb_mc_mac_filter_t_p_assign(filter_p, filter)

        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, filter_p, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("The total count of keys with vid == 1 is %d" % (key_cnt))

        # Get Count with a mac filter
        uint32_t_p_assign(key_cnt_p, 0)

        filter.filter_by_vid = SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E
        filter.filter_by_mac_addr = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.mac_addr = ether_addr(0x01, 0x11, 0x22, 0x33, 0x44, 0x03)
        sx_fdb_mc_mac_filter_t_p_assign(filter_p, filter)

        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, filter_p, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("The total count of keys with mac == ether_addr(0x01,0x11,0x22,0x33,0x44, 0x03) is %d" % (key_cnt))

        # Get Count with a vid and mac filter
        uint32_t_p_assign(key_cnt_p, 0)

        filter.filter_by_vid = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.vid = 1
        filter.filter_by_mac_addr = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.mac_addr = ether_addr(0x01, 0x11, 0x22, 0x33, 0x44, 0x03)
        sx_fdb_mc_mac_filter_t_p_assign(filter_p, filter)

        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, filter_p, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("The total count of keys with vid == 1 and mac == ether_addr(0x01,0x11,0x22,0x33,0x44, 0x03) is %d" % (key_cnt))

        print("--------------------------------GET_FIRST---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        print("GET FIRST, requested count = %d, total count = %d" % (num_get, num_keys))
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("GET FIRST, returned count = %d" % key_cnt)
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            key = key_list[i]
            assert key_get.vid == key.vid and cmp(key_get.mc_mac_addr.to_str(), key.mc_mac_addr.to_str()) == 0,\
                "The content returned by GET FIRST is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------GET_FIRST with a filter--------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        filter.filter_by_vid = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.vid = 1
        filter.filter_by_mac_addr = SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E
        sx_fdb_mc_mac_filter_t_p_assign(filter_p, filter)
        print("GET FIRST, filter (vid == 1), requested count = %d, total count = %d" % (num_get, num_keys))
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, filter_p, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("GET FIRST, filter (vid == 1), returned count = %d" % key_cnt)
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            assert key_get.vid == filter.vid, "The content returned by GET FIRST is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------GET_NEXT---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        key = key_list[index]
        print("GET NEXT %d keys after %dth key (vid: %d mac: %s), total count = %d" % (num_get, index + 1, key.vid, key.mc_mac_addr.to_str(), num_keys))
        sx_fdb_mc_mac_key_t_p_assign(key_p, key)
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, key_p, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after %dth key (vid: %d mac: %s), returned %d keys" % (num_get, index + 1, key.vid, key.mc_mac_addr.to_str(), key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            key = key_list[index + i + 1]
            assert key_get.vid == key.vid and cmp(key_get.mc_mac_addr.to_str(), key.mc_mac_addr.to_str()) == 0,\
                "The content returned by GET NEXT is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------GET_NEXT with a filter----------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        key = key_list[index]
        filter.filter_by_vid = SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E
        filter.filter_by_mac_addr = SXD_FDB_KEY_FILTER_FIELD_VALID_E
        filter.mac_addr = ether_addr(0x01, 0x11, 0x22, 0x33, 0x44, 0x03)
        sx_fdb_mc_mac_filter_t_p_assign(filter_p, filter)
        print("GET NEXT %d keys after %dth key (vid: %d mac: %s), filter (mac == ether_addr(0x01,0x11,0x22,0x33,0x44, 0x03)), total count = %d" % (num_get, index + 1, key.vid, key.mc_mac_addr.to_str(), num_keys))
        sx_fdb_mc_mac_key_t_p_assign(key_p, key)
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, key_p, filter_p, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after %dth key (vid: %d mac: %s), filter (mac == ether_addr(0x01,0x11,0x22,0x33,0x44, 0x03)), returned %d keys" % (num_get, index + 1, key.vid, key.mc_mac_addr.to_str(), key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            #assert cmp(key_get.mc_mac_addr.to_str(), filter.mac_addr.to_str()) == 0, "The content returned by GET NEXT is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------GET_NEXT with a non-existent vid------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        key = sx_fdb_mc_mac_key_t()
        key.vid = 2
        key.mc_mac_addr = key_list[0].mc_mac_addr
        print("GET NEXT %d keys after key (vid: %d mac: %s), total count = %d" % (num_get, key.vid, key.mc_mac_addr.to_str(), num_keys))
        sx_fdb_mc_mac_key_t_p_assign(key_p, key)
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, key_p, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after key (vid: %d mac: %s), returned %d keys" % (num_get, key.vid, key.mc_mac_addr.to_str(), key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            key = key_list[index2 + i]
            assert key_get.vid == key.vid and cmp(key_get.mc_mac_addr.to_str(), key.mc_mac_addr.to_str()) == 0,\
                "The content returned by GET NEXT is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------GET_NEXT with an existent vid but non-existent MAC-------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        key = sx_fdb_mc_mac_key_t()
        key.vid = 1
        key.mc_mac_addr = ether_addr(0x01, 0x11, 0x22, 0x33, 0x44, 0x01)
        print("GET NEXT %d keys after key (vid: %d mac: %s), total count = %d" % (num_get, key.vid, key.mc_mac_addr.to_str(), num_keys))
        sx_fdb_mc_mac_key_t_p_assign(key_p, key)
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, key_p, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after key (vid: %d mac: %s), returned %d keys" % (num_get, key.vid, key.mc_mac_addr.to_str(), key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_fdb_mc_mac_key_t_arr_getitem(key_list_p, i)
            key = key_list[index1 + i]
            assert key_get.vid == key.vid and cmp(key_get.mc_mac_addr.to_str(), key.mc_mac_addr.to_str()) == 0,\
                "The content returned by GET NEXT is incorrect"
            print("vid: %d mac: %s" % (key_get.vid, key_get.mc_mac_addr.to_str()))

        print("--------------------------------Corner cases--------------------------------------------------------------------------")

        # Corner cases

        # Call GET with count > 1
        case = "Test case: Call GET with count > 1"
        print(case)
        key_cnt = MAX_KEY_NUM // 2
        if key_cnt < 2:
            key_cnt = 2
        uint32_t_p_assign(key_cnt_p, key_cnt)
        index = 0
        key = key_list[index]
        sx_fdb_mc_mac_key_t_p_assign(key_p, key)
        rc = sx_api_fdb_mc_mac_addr_iter_get(handle, SX_ACCESS_CMD_GET, 0, key_p, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_fdb_mc_mac_addr_iter_get failed, rc=%d in case %s" % (rc, case))
        key_cnt = uint32_t_p_value(key_cnt_p)
        assert key_cnt <= 1, "Data count not 0 or 1 as expected  in case %s" % (case)
        print(case + " passed\n")

        ############################################################################################

        if args.deinit:
            print("Cleaning up MC MAC keys....\n")
            for key in key_list:
                rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, key.vid, key.mc_mac_addr, None, 0)
                if rc != SX_STATUS_SUCCESS:
                    raise Exception("sx_api_fdb_mc_mac_addr_set failed. [key=%d, rc=%d]" % (key, rc))

        sx_api_close(handle)
        ret_code = 0
    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        traceback.print_exc()
    finally:
        if ret_code:
            print("Test failed: Return code = %d" % ret_code)
        else:
            print("All tests passed")
        sys.exit(ret_code)


if __name__ == "__main__":
    main()
