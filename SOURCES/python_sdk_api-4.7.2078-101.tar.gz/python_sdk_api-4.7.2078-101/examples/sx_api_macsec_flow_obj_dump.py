#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the MACSec flow objects.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
from python_sdk_api.sxd_api import *


def macsec_flow_obj_iter(handle, access_cmd, flow_id, port, direction, count):
    if access_cmd == SX_ACCESS_CMD_GET:
        if flow_id is None:
            raise Exception("Valid flow object ID is needed")

    flow_filter = sx_macsec_flow_filter_t()
    if direction is not None:
        if direction == 'ingress':
            flow_filter.direction = SX_MACSEC_DIR_INGRESS_E
        elif direction == 'egress':
            flow_filter.direction = SX_MACSEC_DIR_EGRESS_E
        flow_filter.filter_by_dir = SX_KEY_FILTER_FIELD_VALID
    else:
        flow_filter.filter_by_dir = SX_KEY_FILTER_FIELD_NOT_VALID

    if port is not None:
        flow_filter.log_port = int(port, 16)
        flow_filter.filter_by_port = SX_KEY_FILTER_FIELD_VALID

    macsec_flow_attr_list_p = new_sx_macsec_flow_attribute_t_arr(count)
    macsec_flow_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(macsec_flow_cnt_p, count)
    flow_filter_p = new_sx_macsec_flow_filter_t_p()
    sx_macsec_flow_filter_t_p_assign(flow_filter_p, flow_filter)

    try:
        rc = sx_api_macsec_flow_obj_iter_get(handle, access_cmd, flow_id, flow_filter_p, macsec_flow_attr_list_p, macsec_flow_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_iter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
        if count == 0:
            # count retrieval
            return uint32_t_p_value(macsec_flow_cnt_p)
        else:
            # object retrieval
            count = uint32_t_p_value(macsec_flow_cnt_p)
            return [sx_macsec_flow_attribute_t_arr_getitem(macsec_flow_attr_list_p, i) for i in range(count)]
    finally:
        delete_sx_macsec_flow_filter_t_p(flow_filter_p)
        delete_uint32_t_p(macsec_flow_cnt_p)
        delete_sx_macsec_flow_attribute_t_arr(macsec_flow_attr_list_p)


def generate_flow_dump(handle, args):
    macsec_dir_type_enum_dict = get_enum_string_dict('SX_MACSEC_DIR_')
    if args.flow_obj_id is not None:
        flow_id = int(args.flow_obj_id, 16)
        macsec_flow_attr = macsec_flow_obj_iter(handle, SX_ACCESS_CMD_GET, flow_id, None, None, 1)
        print("Flow obj ID[0x%8x]" % (macsec_flow_attr.flow_obj_id))
        print("Flow obj port[0x%8x]" % (macsec_flow_attr.log_port))
        print("Flow obj direction[%s]" % (macsec_dir_type_enum_dict[macsec_flow_attr.direction]))
        return

    iter_fetch_count = 50
    flow_obj_attr_list = macsec_flow_obj_iter(handle, SX_ACCESS_CMD_GET_FIRST, 0, args.log_port, args.direction, 1)
    iter_get_list_len = len(flow_obj_attr_list)
    print("========================================================================")
    header = ["Flow Obj", "Port", "Direction"]
    print("|%20s|%20s|%28s|" % (header[0], header[1], header[2]))
    print("========================================================================")
    while (iter_get_list_len > 0):
        for macsec_flow_attr in flow_obj_attr_list:
            logport = "0x%x" % macsec_flow_attr.log_port
            flow_obj = "0x%x" % macsec_flow_attr.flow_obj_id
            print("|%20s|%20s|%28s|" % (flow_obj, logport, macsec_dir_type_enum_dict[macsec_flow_attr.direction]))
        # get next set of flow objects.
        flow_obj_attr_list = macsec_flow_obj_iter(handle, SX_ACCESS_CMD_GETNEXT, macsec_flow_attr.flow_obj_id, args.log_port, args.direction, iter_fetch_count)
        iter_get_list_len = len(flow_obj_attr_list)
    print("========================================================================")


def check_macsec_init_status(handle):
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("MACSec module is not initialized")
            sys.exit()
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='MACSec Flow  dump utility')
    parser.add_argument('--log_port', '-p', help="Flow object filter port")
    parser.add_argument('--direction', '-d', choices=['ingress', 'egress'], help="Flow object filter direction")
    parser.add_argument('--flow_obj_id', '-f', help='Flow obj for flow iterator get')
    args = parser.parse_args()
    return args


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print("MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

    check_macsec_init_status(handle)

    args = parse_example_attributes()
    generate_flow_dump(handle, args)

    sx_api_close(handle)
