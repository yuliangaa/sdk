#!/usr/bin/env python
'''
This file contains Python command example for the Span module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different Span attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_span_egress_mirror example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

""" ############################################################################################ """
port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

""" ############################################################################################ """


def span_init():
    """SPAN INIT"""
    print("--------------- SPAN INIT------------------------------")
    span_session_id = 0
    init_params_p = new_sx_span_init_params_t_p()
    # init_params_p->version = SX_SPAN_MIRROR_HEADER_VERSION_0
    init_params = sx_span_init_params_t()
    #init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    init_params.version = SX_SPAN_MIRROR_HEADER_VERSION_0
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    print(("sx_api_span_init_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("version = %d " % (init_params.version)))
    delete_sx_span_init_params_t_p(init_params_p)


""" ############################################################################################ """


def span_session_create(span_session_param_p):
    """SPAN SESSION CREATE"""
    print("--------------- SPAN SESSION CREATE------------------------------")

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


""" ############################################################################################ """


def span_session_edit(span_type, span_session_id_p):
    """SPAN SESSION EDIT"""
    print("--------------- SPAN SESSION EDIT------------------------------")
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    if span_type == SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        span_session_param.span_type = span_type
        span_session_param.span_type_format.remote_eth_vlan_type1.qos_mode = SX_SPAN_QOS_MAINTAIN
        span_session_param.span_type_format.remote_eth_vlan_type1.switch_prio = 5
        span_session_param.span_type_format.remote_eth_vlan_type1.vid = 3876
        span_session_param.span_type_format.remote_eth_vlan_type1.vlan_ethertype_id = 0
        span_session_param.span_type_format.remote_eth_vlan_type1.pcp = 4
        span_session_param.span_type_format.remote_eth_vlan_type1.dei = 1
        span_session_param.truncate = True
        span_session_param.truncate_size = 100
    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_EDIT, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] Edited" % (span_session_id)))
    delete_sx_span_session_params_t_p(span_session_param_p)


""" ############################################################################################ """


def span_session_destroy(span_session_id_p, span_session_param_p):
    """SPAN SESSION DESTROY"""
    print("--------------- SPAN SESSION DESTROY------------------------------")

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] destroyed" % (span_session_id)))


""" ############################################################################################ """


def span_analyzer_set(cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- SPAN ANALYZER ADD ------------------------------")
    else:
        print("--------------- SPAN ANALYZER DELETE ------------------------------")
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    print(("sx_api_span_analyzer_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_analyzer_get(log_port):
    """SPAN ANALYZER GET"""
    print("--------------- SPAN ANALYZER GET ------------------------------")
    span_sessions_cnt_p = new_uint32_t_p()
    """ Set cnt = 1 """
    uint32_t_p_assign(span_sessions_cnt_p, 1)
    """ Get value from PTR """
    session_count = uint32_t_p_value(span_sessions_cnt_p)

    port_params_p = new_sx_span_analyzer_port_params_t_arr(session_count)
    session_id_list_p = new_sx_span_session_id_t_arr(session_count)

    rc = sx_api_span_analyzer_get(handle, log_port, port_params_p, session_id_list_p, span_sessions_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_span_analyzer_get [rc=%d]" % (rc)))
    #port_params = sx_span_analyzer_port_params_t()

    for i in range(0, session_count):
        session_id = sx_span_session_id_t_arr_getitem(session_id_list_p, i)
        port_params = sx_span_analyzer_port_params_t_arr_getitem(port_params_p, i)
        print(("cng mng =  %d" % (port_params.cng_mng)))

    delete_uint32_t_p(span_sessions_cnt_p)
    delete_sx_span_analyzer_port_params_t_arr(port_params_p)
    delete_sx_span_session_id_t_arr(session_id_list_p)


""" ############################################################################################ """


def span_mirror_set(cmd, mirror_port, mirror_direction, session_id):
    """ADD/DELETE SPAN MIRROR PORT """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD SPAN MIRROR PORT ------------------------------")
    else:
        print("--------------- DELETE SPAN MIRROR PORT  ------------------------------")
    rc = sx_api_span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id)
    print(("sx_api_span_mirror_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_get(mirror_port, mirror_direction):
    """SPAN MIRROR PORT GET """
    print("--------------- SPAN MIRROR PORT GET ------------------------------")

    session_id_p = new_sx_span_session_id_t_p()
    rc = sx_api_span_mirror_get(handle, mirror_port, mirror_direction, session_id_p)

    session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("sx_api_span_mirror_get [rc=%d], span session id = %d" % (rc, session_id)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    delete_sx_span_session_id_t_p(session_id_p)


""" ############################################################################################ """


def span_session_state_set(session_id, admin_state):
    """SPAN SESSION STATE SET """
    print("--------------- SPAN SESSION STATE SET  ------------------------------")
    print(("Span session id =%d, admin state =%d" % (session_id, admin_state)))
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    print(("sx_api_span_session_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_state_set(mirror_port, mirror_direction, admin_state):
    """SPAN MIRROR STATE SET """
    print("--------------- SPAN MIRROR STATE SET  ------------------------------")
    print(("Mirror port = 0x%x " % (mirror_port)))
    print(("Mirror direction =%d, admin state =%d" % (mirror_direction, admin_state)))
    rc = sx_api_span_mirror_state_set(handle, mirror_port, mirror_direction, admin_state)
    print(("sx_api_span_mirror_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_state_get(mirror_port, mirror_direction):
    """SPAN MIRROR STATE GET """
    print("--------------- SPAN MIRROR STATE GET  ------------------------------")

    admin_state_p = new_boolean_t_p()
    rc = sx_api_span_mirror_state_get(handle, mirror_port, mirror_direction, admin_state_p)
    print(("sx_api_span_mirror_state_get [rc=%d]" % (rc)))

    admin_state = boolean_t_p_value(admin_state_p)
    print(("Mirror port = 0x%x " % (mirror_port)))
    print(("Mirror direction =%d, admin state =%d" % (mirror_direction, admin_state)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    delete_boolean_t_p(admin_state_p)


""" ############################################################################################ """


def span_mirror_tables_set(cmd, session_id):
    """ SPAN MIRROR TABLE ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("------------ SPAN MIRROR TABLE ADD -----------------")
    else:
        print("------------ SPAN MIRROR TABLE DELETE -----------------")

    rc = sx_api_span_mirror_tables_set(handle, cmd, session_id)
    print(("sx_api_span_mirror_tables_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_tables_get():
    """ SPAN MIRROR TABLE GET"""
    print("------------ SPAN MIRROR TABLE GET -----------------")

    session_id_p = new_sx_span_session_id_t_p()
    rc = sx_api_span_mirror_tables_get(handle, session_id_p)
    session_id = sx_span_session_id_t_p_value(session_id_p)
    print(("sx_api_span_mirror_tables_get [rc=%d], span session_id = %d" % (rc, session_id)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    delete_sx_span_session_id_t_p(session_id_p)


""" ############################################################################################ """


def span_drop_mirror_set(cmd, session_id, drop_reason_list=[], drop_mirroring_attr_p=None):
    """ SPAN DROP MIRROR SET/ADD/DELETE/DELETE-ALL"""
    cmd_str = {SX_ACCESS_CMD_SET: "SET",
               SX_ACCESS_CMD_ADD: "ADD",
               SX_ACCESS_CMD_DELETE: "DELETE",
               SX_ACCESS_CMD_DELETE_ALL: "DELETE-ALL"}
    if cmd in cmd_str:
        print(("------------ SPAN DROP MIRROR %s -----------------" % (cmd_str[cmd])))
    else:
        print(("------------ SPAN DROP MIRROR cmd %u unsupported -----------------" % (cmd)))

    drop_reason_count = len(drop_reason_list)
    drop_reason_list_arr = new_sx_span_drop_reason_t_arr(drop_reason_count)
    for idx in range(drop_reason_count):
        sx_span_drop_reason_t_arr_setitem(drop_reason_list_arr, idx, drop_reason_list[idx])

    rc = sx_api_span_drop_mirror_set(handle, cmd, session_id, drop_mirroring_attr_p,
                                     drop_reason_list_arr, drop_reason_count)
    print(("sx_api_span_drop_mirror_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    delete_sx_span_drop_reason_t_arr(drop_reason_list_arr)


""" ############################################################################################ """


def span_deinit():
    """SPAN DEINIT"""
    print("--------------- SPAN DEINIT------------------------------")

    rc = sx_api_span_deinit_set(handle)
    print(("sx_api_span_deinit_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_session_mirror_port_get(session_id, mirror_ports_list_p, mirror_ports_cnt):
    """SPAN SESSION MIRROR GET"""
    print("--------------- SPAN SESSION MIRROR GET ------------------------------")

    mirror_ports_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(mirror_ports_cnt_p, mirror_ports_cnt)

    rc = sx_api_span_session_mirror_get(handle, session_id, mirror_ports_list_p, mirror_ports_cnt_p)
    mirror_ports_cnt = uint32_t_p_value(mirror_ports_cnt_p)

    print(("Num of mirrored port in session[%d] [mirrored cnt=%d]" % (session_id, mirror_ports_cnt)))


""" ############################################################################################ """

# FDB configuration
mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 2)
mac_addr1 = ether_addr("00:00:00:00:00:01")
mac_addr2 = ether_addr("00:00:00:00:00:02")

mac_entry1 = sx_fdb_uc_mac_addr_params_t()
mac_entry1.mac_addr = mac_addr1
mac_entry1.fid_vid = 1          # Filtering Identifier, VID for static MAC
mac_entry1.log_port = PORT3
mac_entry1.entry_type = SX_FDB_UC_STATIC
mac_entry1.action = SX_FDB_ACTION_FORWARD
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

mac_entry2 = sx_fdb_uc_mac_addr_params_t()
mac_entry2.mac_addr = mac_addr2
mac_entry2.fid_vid = 1          # Filtering Identifier, VID for static MAC
mac_entry2.log_port = PORT1
mac_entry2.entry_type = SX_FDB_UC_STATIC
mac_entry2.action = SX_FDB_ACTION_FORWARD
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)

# init span
span_init()
# create a span session
span_session_param_p = new_sx_span_session_params_t_p()
span_session_param = sx_span_session_params_t()
span_session_param.span_type = SX_SPAN_TYPE_LOCAL_ETH_TYPE1
span_session_param.span_type_format.local_eth_type1.qos_mode = SX_SPAN_QOS_MAINTAIN
span_session_param.span_type_format.local_eth_type1.switch_prio = 2
span_session_param.truncate = False
span_session_param.truncate_size = 32
sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
span_session_id_p = span_session_create(span_session_param_p)
span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
print(("Span session id [%d] created" % (span_session_id)))

# add analyzer port to span session created above
port_params_p = new_sx_span_analyzer_port_params_t_p()
port_params = sx_span_analyzer_port_params_t()
port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
span_analyzer_set(SX_ACCESS_CMD_ADD, PORT2, port_params_p, span_session_id)
span_analyzer_get(PORT2)

# add span mirror port
span_mirror_set(SX_ACCESS_CMD_ADD, PORT3, SX_SPAN_MIRROR_EGRESS, span_session_id)

# add span mirror port
span_mirror_set(SX_ACCESS_CMD_ADD, PORT4, SX_SPAN_MIRROR_EGRESS, span_session_id)

# span mirror get
span_mirror_get(PORT3, SX_SPAN_MIRROR_EGRESS)

# enable SPAN session admin state
span_session_state_set(span_session_id, True)

# enable SPAN mirror state
span_mirror_state_set(PORT3, SX_SPAN_MIRROR_EGRESS, True)

# get SPAN mirror state
span_mirror_state_get(PORT3, SX_SPAN_MIRROR_EGRESS)

# Get SPAN session port CNT
span_session_mirror_port_get(span_session_id, None, 0)

if args.deinit:
    print("-------------------- Cleanup ------------------------------")
    # delete all drop mirroring drop reasons
    span_drop_mirror_set(SX_ACCESS_CMD_DELETE_ALL, span_session_id)

    # disable SPAN mirror state
    span_mirror_state_set(PORT3, SX_SPAN_MIRROR_EGRESS, False)

    # delete span mirror port
    span_mirror_set(SX_ACCESS_CMD_DELETE, PORT4, SX_SPAN_MIRROR_EGRESS, span_session_id)
    span_mirror_set(SX_ACCESS_CMD_DELETE, PORT3, SX_SPAN_MIRROR_EGRESS, span_session_id)

    # disable SPAN session admin state
    span_session_state_set(span_session_id, False)

    # delete analyzer port to span session created above
    span_analyzer_set(SX_ACCESS_CMD_DELETE, PORT2, port_params_p, span_session_id)

    # destroy span session
    span_session_destroy(span_session_id_p, span_session_param_p)
    delete_sx_span_session_params_t_p(span_session_param_p)
    delete_sx_span_session_id_t_p(span_session_id_p)
    delete_sx_span_analyzer_port_params_t_p(port_params_p)

    # deinit span
    span_deinit()

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fdb_uc_mac_addr_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

sx_api_close(handle)

""" To enable SPAN with LAG mirrored port, open the following remarks """
"""------------------------------------------- """
"""--------------- LAG SUPPORT --------------- """
"""------------------------------------------- """
"""
#init span
span_init()
#create a span session
span_session_param_p = new_sx_span_session_params_t_p()
span_session_param = sx_span_session_params_t()
span_session_param.span_type = SX_SPAN_TYPE_LOCAL_ETH_TYPE1
span_session_param.span_type_format.local_eth_type1.qos_mode = SX_SPAN_QOS_MAINTAIN
span_session_param.span_type_format.local_eth_type1.switch_prio = 2
span_session_param.truncate = False
span_session_param.truncate_size =  32
sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
span_session_id_p = span_session_create(span_session_param_p)
span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
print("Span session id [%d] created" %(span_session_id))

#add analyzer port to span session created above
port_params_p = new_sx_span_analyzer_port_params_t_p()
port_params = sx_span_analyzer_port_params_t()
port_params.cng_mng  = SX_SPAN_CNG_MNG_DISCARD
sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
span_analyzer_set(SX_ACCESS_CMD_ADD, 0x10014,port_params_p, span_session_id)
span_analyzer_get(0x10014)

# LAG handling - START
# 1. Configures the fields which impact the LAG hash distribution function.
lag_hash_param = sx_lag_hash_param_t()
lag_hash_param.lag_hash_type = SX_LAG_HASH_TYPE_XOR
lag_hash_param.lag_hash = 0xA
lag_hash_param.lag_seed = 0
rc = sx_api_lag_hash_flow_params_set(handle, lag_hash_param)
print ("sx_api_lag_hash_flow_params_set , type %d , rc %d " % (lag_hash_param.lag_hash_type, rc) )

# 2. Creates a new LAG.
swid = 0
lag_id_p = new_sx_port_log_id_t_p()
rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
lag_id = sx_port_log_id_t_p_value(lag_id_p)
print ("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc) )

rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
print ("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc) )

# 3. Adds 2 ports to the above LAG.
swid = 0
port_list = new_sx_port_log_id_t_arr(2)
sx_port_log_id_t_arr_setitem(port_list, 0, 0x10012)
sx_port_log_id_t_arr_setitem(port_list, 1, 0x10013)
rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_id_p, port_list, 2)
print ("sx_api_lag_port_group_set ADD ports 0x%x, 0x%x to lag_id 0x%x , rc %d " % (0x10012, 0x10013, lag_id, rc) )

# 4. Enables collection on a specific port in a LAG port.
log_port = 0x10012
col_state = COLLECTOR_ENABLE
rc = sx_api_lag_port_collector_set(handle, lag_id, log_port, col_state)
print ("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, col_state, rc) )

log_port = 0x10013
col_state = COLLECTOR_ENABLE
rc = sx_api_lag_port_collector_set(handle, lag_id, log_port, col_state)
print ("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, col_state, rc) )

# 5. Retrieves the collection mode of a specific port in a LAG port.
log_port = 0x10012
col_state_p = new_sx_collector_mode_t_p()
rc = sx_api_lag_port_collector_get(handle, lag_id, log_port, col_state_p)
col_state = sx_collector_mode_t_p_value(col_state_p)
print ("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, col_state, rc) )

log_port = 0x10013
col_state_p = new_sx_collector_mode_t_p()
rc = sx_api_lag_port_collector_get(handle, lag_id, log_port, col_state_p)
col_state = sx_collector_mode_t_p_value(col_state_p)
print ("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, col_state, rc) )

# 6. Enables and disables distribution on a specific port in a LAG port.
log_port = 0x10012
distr_state = DISTRIBUTOR_ENABLE
rc = sx_api_lag_port_distributor_set(handle, lag_id, log_port, distr_state)
print ("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, distr_state, rc) )

log_port = 0x10013
distr_state = DISTRIBUTOR_ENABLE
rc = sx_api_lag_port_distributor_set(handle, lag_id, log_port, distr_state)
print ("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id,log_port, distr_state, rc) )

# 8. Retrieves the above mentioned LAG information.
swid = 0
#port_list = new_sx_port_log_id_t_arr(2)
sx_port_log_id_t_arr_setitem(port_list, 0, 0)
sx_port_log_id_t_arr_setitem(port_list, 1, 0)
port_list_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_list_cnt_p, 2)
rc = sx_api_lag_port_group_get(handle, swid, lag_id, port_list, port_list_cnt_p)
port_list_cnt = uint32_t_p_value(port_list_cnt_p)
log_port0 = sx_port_log_id_t_arr_getitem(port_list, 0)
log_port1 = sx_port_log_id_t_arr_getitem(port_list, 1)
print ("sx_api_lag_port_group_get %d ports 0x%x, 0x%x belong to lag_id 0x%x , rc %d " % (port_list_cnt,log_port0 ,log_port1, lag_id, rc) )

#9. Set LAG admin stat UP
sx_api_port_state_set(handle, lag_id, SX_PORT_ADMIN_STATUS_UP)
if rc != SX_STATUS_SUCCESS:
    print ("sx_api_port_state_set failed, rc=%d] " % ( rc) )
    sys.exit(rc)
print ("[+] Setting log_port:0x%x admin state to UP." % (lag_id))

# LAG handling - END

# Add VLAN# 1 to LAG
vlan_arr = new_sx_vlan_ports_t_arr(1)
vlan_port0 = sx_vlan_ports_t()
vlan_port0.log_port = lag_id
vlan_port0.is_untagged = 1
sx_vlan_ports_t_arr_setitem(vlan_arr, 0, vlan_port0)
swid = 0
vid = 1
rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, swid, vid, vlan_arr, 1)
print("Add %d ports to vlan %d , rc: %d " %(1, vid, rc))

# Update port's default VLAN.
pvid = 1
rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, lag_id, pvid);
print ("Set pvid %d for port %d, rc %d " % (pvid, lag_id, rc) )

# Sets in RSTP port state forwarding
stp_state = SX_MSTP_INST_PORT_STATE_FORWARDING
rc = sx_api_rstp_port_state_set(handle, lag_id, stp_state)
print ("sx_api_rstp_port_state_set log_port 0x%x stp_state %d , rc %d " % (lag_id, stp_state, rc) )

# FDB configuration
mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 2)
mac_addr1 = ether_addr("00:00:00:00:00:01")
mac_addr2 = ether_addr("00:00:00:00:00:11")

mac_entry1 = sx_fdb_uc_mac_addr_params_t()
mac_entry1.mac_addr = mac_addr1;
mac_entry1.fid_vid = 1;          # Filtering Identifier, VID for static MAC
mac_entry1.log_port = lag_id;
mac_entry1.entry_type = SX_FDB_UC_STATIC;
mac_entry1.action = SX_FDB_ACTION_FORWARD;
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

mac_entry2 = sx_fdb_uc_mac_addr_params_t()
mac_entry2.mac_addr = mac_addr2;
mac_entry2.fid_vid = 1;          # Filtering Identifier, VID for static MAC
mac_entry2.log_port = lag_id;
mac_entry2.entry_type = SX_FDB_UC_STATIC;
mac_entry2.action = SX_FDB_ACTION_FORWARD;
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)

#add span mirror port
span_mirror_set(SX_ACCESS_CMD_ADD, lag_id, SX_SPAN_MIRROR_EGRESS, span_session_id)

#span mirror get
span_mirror_get(lag_id, SX_SPAN_MIRROR_EGRESS)

#enable SPAN session admin state
span_session_state_set(span_session_id, True)

#enable SPAN mirror state
span_mirror_state_set(lag_id, SX_SPAN_MIRROR_EGRESS, True)

#get SPAN mirror state
span_mirror_state_get(lag_id, SX_SPAN_MIRROR_EGRESS)
"""

""" DELETE ALL """

"""
#disable SPAN mirror state
span_mirror_state_set(0x10021, SX_SPAN_MIRROR_EGRESS, False)

#delete span mirror port
span_mirror_set(SX_ACCESS_CMD_DELETE, 0x10021, SX_SPAN_MIRROR_EGRESS, span_session_id)

#disable SPAN session admin state
span_session_state_set(span_session_id, False)

#delete analyzer port to span session created above
span_analyzer_set(SX_ACCESS_CMD_DELETE, 0x10003, port_params_p, span_session_id)

#####################################################################################

#edit span session created above
span_type = SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1
span_session_edit(span_type, span_session_id_p)

#add analyzer port to span session created above
span_analyzer_set(SX_ACCESS_CMD_ADD, 0x10003,port_params_p, span_session_id)

#add span mirror port
span_mirror_set(SX_ACCESS_CMD_ADD, 0x10023, SX_SPAN_MIRROR_EGRESS, span_session_id)
span_mirror_set(SX_ACCESS_CMD_ADD, 0x1003D, SX_SPAN_MIRROR_EGRESS, span_session_id)

#span mirror get
span_mirror_get(0x10023, SX_SPAN_MIRROR_EGRESS)

#enable SPAN session admin state
span_session_state_set(span_session_id, True)

#enable SPAN mirror state
span_mirror_state_set(0x10023, SX_SPAN_MIRROR_EGRESS, True)
span_mirror_state_set(0x1003D, SX_SPAN_MIRROR_EGRESS, True)

#get SPAN mirror state
span_mirror_state_get(0x10023, SX_SPAN_MIRROR_EGRESS)

#enable table mirroring - for registers without explicit session
span_mirror_tables_set(SX_ACCESS_CMD_ADD, span_session_id)

#mirror table get
span_mirror_tables_get()

#disable table mirroring
span_mirror_tables_set(SX_ACCESS_CMD_DELETE, span_session_id)

#disable SPAN mirror state
span_mirror_state_set(0x10023, SX_SPAN_MIRROR_EGRESS, False)
span_mirror_state_set(0x1003D, SX_SPAN_MIRROR_EGRESS, False)

#delete span mirror port
span_mirror_set(SX_ACCESS_CMD_DELETE, 0x10023, SX_SPAN_MIRROR_EGRESS, span_session_id)
span_mirror_set(SX_ACCESS_CMD_DELETE, 0x1003D, SX_SPAN_MIRROR_EGRESS, span_session_id)

#disable SPAN session admin state
span_session_state_set(span_session_id, False)

#delete analyzer port to span session created above
span_analyzer_set(SX_ACCESS_CMD_DELETE, 0x10003,port_params_p, span_session_id)

#destroy span session
span_session_destroy(span_session_id_p, span_session_param_p)
delete_sx_span_session_params_t_p(span_session_param_p)
delete_sx_span_session_id_t_p(span_session_id_p)
delete_sx_span_analyzer_port_params_t_p(port_params_p)

#deinit span
span_deinit()
"""
""" ############################################################################################ """
"""sx_api_close(handle)"""
""" ############################################################################################ """
