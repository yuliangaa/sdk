#!/usr/bin/env python
'''
This tool is used to generate port xml required for SDK initialization when self init is not desired.
This utility relies on SX management API and should be executed only after SDK bare initialization is done.
This tool also needs to be executed on the same system whose xml file needs to be generated. This tool has
additional capacity to generate port information about the bonus port if any on SPC-4 based systems, when the port,
lane and module mapping are given by the user through command params.
'''

import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api
import xml.etree.ElementTree as ET
import xml.dom.minidom as MD


NUM_TUNNELS = 3
MAX_LANES = 8
LOCAL_PORT_LIST = []
DEFAULT_MAPPING_MODE = 1
DEFAULT_PORT_MODE = 0
DEFAULT_RSTP_PORT_STATE = 3
DEFAULT_PORT_SPEED = 2147483650
DEFAULT_PORT_STATE = 1
DEFAULT_PORT_SWID = 0
DEFAULT_LOOPBACK_STATE = 0
DEFAULT_BASE_MAC = '00:02:03:04:05:80'
DEFAULT_VID = 1
DEFAULT_DEVICE_STATE = 1
DEFAULT_I2C_DEV_ID = 1
DEFAULT_DEVICE_NUMBER = 1
DEFAULT_NODE_TYPE = 1


def mgmt_phy_mod_split_info_query(handle, slot_id, module_id, split_num, port_width):
    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = slot_id
    module_info.module_id = module_id

    split_params = sx_mgmt_phy_module_split_params_t()
    split_params.split_num = split_num
    split_params.port_width = port_width

    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
    module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
    split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)

    rc = sx_mgmt_phy_module_split_get(handle, module_info_p, split_params_p, split_info_p)
    assert SX_STATUS_SUCCESS == rc, "mgmt_phy_mod_split_info_query failed."
    split_info = sx_mgmt_phy_module_split_info_t_p_value(split_info_p)
    if split_info.list_len > 0:
        return split_info.list_len, split_info_p.port_attribs_list
    else:
        print("Split/unsplit is not possible, number of ports exceed the module width or ports combination is not allowed")


def get_lane_module_mapping_text(port_attr):
    lane_text = ''
    module_text = ''
    first = True
    for i in range(0, MAX_LANES):
        if port_attr.port_mapping.lane_bmap & (1 << i):
            if not first:
                lane_text = lane_text + ','
                module_text = module_text + ','
            lane_text = lane_text + str(i)
            module_text = module_text + str(port_attr.port_mapping.module_port)
            first = False

    return lane_text, module_text


def get_bonus_port_lane_module_mapping(lane_text, module_text):
    first = True
    lane_info = lane_text.split("-")
    module_info = module_text
    lane_text = ''
    module_text = ''
    for i in range(int(lane_info[0]), int(lane_info[1]) + 1):
        if not first:
            lane_text = lane_text + ','
            module_text = module_text + ','
        lane_text = lane_text + str(i)
        module_text = module_text + module_info
        first = False
    return lane_text, module_text


def generate_port_info_node(parent_node, port_attr, port_speed_bmap, default_vid):
    port_info = ET.SubElement(parent_node, 'port-info')
    port_info.append(ET.Comment("Local Port Information"))
    local_port = ET.SubElement(port_info, 'local-port')
    local_port.text = str(port_attr.port_mapping.local_port)
    mapping_mode = ET.SubElement(port_info, 'mapping-mode')
    mapping_mode.text = str(DEFAULT_MAPPING_MODE)
    port_label = ET.SubElement(port_info, 'port-label')
    port_label.text = str(port_attr.port_mapping.module_port + 1)
    width = ET.SubElement(port_info, 'width')
    width.text = str(port_attr.port_mapping.width)
    lane_text, module_text = get_lane_module_mapping_text(port_attr)
    lanes = ET.SubElement(port_info, 'lanes')
    lanes.text = lane_text
    lane_to_module = ET.SubElement(port_info, 'lane-to-module')
    lane_to_module.text = module_text
    port_mode = ET.SubElement(port_info, 'port-mode')
    port_mode.text = str(DEFAULT_PORT_MODE)
    rstp_port_state = ET.SubElement(port_info, 'rstp-port-state')
    rstp_port_state.text = str(DEFAULT_RSTP_PORT_STATE)
    port_speed = ET.SubElement(port_info, 'port-speed')
    port_speed.text = str(port_speed_bmap)
    port_state = ET.SubElement(port_info, 'port-state')
    port_state.text = str(DEFAULT_PORT_STATE)
    swid = ET.SubElement(port_info, 'swid')
    swid.text = str(DEFAULT_PORT_SWID)
    vid = ET.SubElement(port_info, 'vid')
    vid.text = str(default_vid)
    phys_loopback = ET.SubElement(port_info, 'phys-loopback')
    phys_loopback.text = str(DEFAULT_LOOPBACK_STATE)


def generate_bonus_ports(parent_node, bonus_port_list, default_vid):
    for port in bonus_port_list:
        label_port, lcl_port, port_width, lane_text, module_text, port_speed_bmap = port
        port_info = ET.SubElement(parent_node, 'port-info')
        port_info.append(ET.Comment("Bonus Port Information"))
        local_port = ET.SubElement(port_info, 'local-port')
        local_port.text = lcl_port
        mapping_mode = ET.SubElement(port_info, 'mapping-mode')
        mapping_mode.text = str(DEFAULT_MAPPING_MODE)
        port_label = ET.SubElement(port_info, 'port-label')
        port_label.text = label_port
        width = ET.SubElement(port_info, 'width')
        width.text = port_width
        lanes = ET.SubElement(port_info, 'lanes')
        lane_to_module = ET.SubElement(port_info, 'lane-to-module')
        if port_width == '1':
            lanes.text = lane_text
            lane_to_module.text = module_text
        else:
            lanes.text, lane_to_module.text = get_bonus_port_lane_module_mapping(lane_text, module_text)
        port_mode = ET.SubElement(port_info, 'port-mode')
        port_mode.text = str(DEFAULT_PORT_MODE)
        rstp_port_state = ET.SubElement(port_info, 'rstp-port-state')
        rstp_port_state.text = str(DEFAULT_RSTP_PORT_STATE)
        port_speed = ET.SubElement(port_info, 'port-speed')
        speed_val = int(port_speed_bmap, 16)
        port_speed.text = port_speed_bmap
        port_state = ET.SubElement(port_info, 'port-state')
        port_state.text = str(DEFAULT_PORT_STATE)
        swid = ET.SubElement(port_info, 'swid')
        swid.text = str(DEFAULT_PORT_SWID)
        vid = ET.SubElement(port_info, 'vid')
        vid.text = str(default_vid)
        phys_loopback = ET.SubElement(port_info, 'phys-loopback')
        phys_loopback.text = str(DEFAULT_LOOPBACK_STATE)


def generate_tunnel_ports(parent_node, num_tunnel_ports, default_vid):
    lcl_port = 0
    for i in range(num_tunnel_ports):
        port_info = ET.SubElement(parent_node, 'port-info')
        port_info.append(ET.Comment("Tunnel Port Information"))
        local_port = ET.SubElement(port_info, 'local-port')
        local_port.text = str(lcl_port)
        mapping_mode = ET.SubElement(port_info, 'mapping-mode')
        mapping_mode.text = '0'
        port_label = ET.SubElement(port_info, 'port-label')
        port_label.text = '0'
        width = ET.SubElement(port_info, 'width')
        width.text = '1'
        lanes = ET.SubElement(port_info, 'lanes')
        lanes.text = '0'
        lane_to_module = ET.SubElement(port_info, 'lane-to-module')
        lane_to_module.text = '0'
        port_mode = ET.SubElement(port_info, 'port-mode')
        port_mode.text = '4'
        rstp_port_state = ET.SubElement(port_info, 'rstp-port-state')
        rstp_port_state.text = '0'
        port_speed = ET.SubElement(port_info, 'port-speed')
        port_speed.text = '0'
        port_state = ET.SubElement(port_info, 'port-state')
        port_state.text = '0'
        swid = ET.SubElement(port_info, 'swid')
        swid.text = str(DEFAULT_PORT_SWID)
        vid = ET.SubElement(port_info, 'vid')
        vid.text = str(default_vid)
        phys_loopback = ET.SubElement(port_info, 'phys-loopback')
        phys_loopback.text = str(DEFAULT_LOOPBACK_STATE)
        lcl_port = lcl_port + 1


def generate_xml(handle, slot_id, min_module, max_module, split_num, split_width, file_path, base_mac, default_vid, port_speed, bonus_port_list):
    # Create the root element
    root = ET.Element('evb_doc')
    # Create a new element
    number_of_trees = ET.SubElement(root, 'number-of-trees')
    number_of_trees.text = '0'
    number_of_devices = ET.SubElement(root, 'number-of-devices')
    number_of_devices.text = '1'
    swids = ET.SubElement(root, 'swids')
    swids.text = '0'
    sgmii_smac = ET.SubElement(root, 'sgmii-smac')
    sgmii_smac.text = '0'
    device = ET.SubElement(root, 'device')
    device_state = ET.SubElement(device, 'device-state')
    device_state.text = str(DEFAULT_DEVICE_STATE)
    i2c_dev_id = ET.SubElement(device, 'i2c-dev-id')
    i2c_dev_id.text = str(DEFAULT_I2C_DEV_ID)
    device_number = ET.SubElement(device, 'device-number')
    device_number.text = str(DEFAULT_DEVICE_NUMBER)
    node_type = ET.SubElement(device, 'node-type')
    node_type.text = str(DEFAULT_NODE_TYPE)
    tree_handle_num = ET.SubElement(device, 'tree-handle-num')
    tree_handle_num.text = '0'
    device_mac_address = ET.SubElement(device, 'device-mac-address')
    device_mac_address.text = base_mac
    number_of_static_entries = ET.SubElement(device, 'number-of-static-entries')
    number_of_static_entries.text = '0'
    number_of_physical_ports = ET.SubElement(device, 'number-of-physical-ports')
    ports_list = ET.SubElement(device, 'ports-list')

    port_count = 0
    for module_id in range(min_module, max_module + 1):
        # Query API and get information.
        list_len, port_attr_list = mgmt_phy_mod_split_info_query(handle, slot_id, module_id, split_num, port_width)
        for i in range(list_len):
            port_attr = sx_port_attributes_t_arr_getitem(port_attr_list, i)
            if port_attr.port_mapping.local_port not in LOCAL_PORT_LIST:
                port_count = port_count + 1
                LOCAL_PORT_LIST.append(port_attr.port_mapping.local_port)
                generate_port_info_node(ports_list, port_attr, port_speed, default_vid)

    generate_tunnel_ports(ports_list, NUM_TUNNELS, default_vid)
    generate_bonus_ports(ports_list, bonus_port_list, default_vid)
    number_of_physical_ports.text = str(port_count + NUM_TUNNELS)

    # Create the XML tree
    tree = ET.ElementTree(root)

    # Print the XML
    xml_buf = ET.tostring(root)
    xml = MD.parseString(xml_buf)

    with open(file_path, "w") as f:
        f.write(xml.toprettyxml())

    print("Generated xml is %s" % (file_path))


def print_usage():
    print("Usage: port_list_xml_composer_eth.py --slot_id 0 --max_label_port 64 --num_splits 1 --port_width 8 --file_path '/tmp/port_mapping.xml' --vid 1 --base_mac '00:02:03:04:05:80'")
    print("Usage: port_list_xml_composer_eth.py --slot_id 0 --min_label_port 2 --max_label_port 3 --num_splits 2 --port_width 4 --file_path '/tmp/port_mapping.xml' --port_speed=0x80000001")
    print("Usage: port_list_xml_composer_eth.py --slot_id 0 --max_label_port 64 --num_splits 1 --port_width 8 --bonus_port '65,257,1,0,64,0x80000010' '66,258,3,0-3,65,0x80000010'")
    print("\n")
    sys.exit(0)


def parse_example_attributes(chip_type):
    parser = argparse.ArgumentParser(description='Port XML Generator Utility')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    parser.add_argument('--max_label_port', default=32, type=int, help="Panel port maximum number.")
    parser.add_argument('--min_label_port', default=1, type=int, help="Panel port minimum number.")
    parser.add_argument('--file_path', default='/tmp/port_mapping.xml', type=str, help="XML output file.")
    parser.add_argument('--vid', default=DEFAULT_VID, type=int, help="Default VID.")
    parser.add_argument('--base_mac', default=DEFAULT_BASE_MAC, type=str, help="Default base MAC.")
    parser.add_argument('--port_speed', default="0x80000000", type=str, help='bitmap of speeds supported, bit(31) means to use port rate API')
    parser.add_argument('--bonus_port', nargs='+', type=str, help='list of bonus port configuration label, local, width, laneX/laneX-laneY, module, speed')
    # SPC2 asic supports 8 lanes but the current systems do not.
    if chip_type == SX_CHIP_TYPE_SPECTRUM2 or chip_type == SX_CHIP_TYPE_SPECTRUM:
        parser.add_argument('--num_splits', type=int, choices=[1, 2, 4], help="Number of split")
        parser.add_argument('--port_width', type=int, choices=[1, 2, 4], help="Width of each port")
        max_lanes = 4
    else:
        parser.add_argument('--num_splits', type=int, choices=[1, 2, 4, 8], help="Number of split")
        parser.add_argument('--port_width', type=int, choices=[1, 2, 4, 8], help="Width of each port")
        max_lanes = 8

    args = parser.parse_args()

    if args.num_splits is None or args.port_width is None:
        print_usage()

    bonus_port_list = []
    if args.bonus_port is not None:
        for port_conf in args.bonus_port:
            tup = port_conf.split(',')
            bonus_port_list.append(tuple(tup))
    max_label_port = args.max_label_port
    min_label_port = args.min_label_port
    slot_id = args.slot_id
    num_splits = int(args.num_splits)
    port_width = int(args.port_width)
    file_path = args.file_path
    base_mac = args.base_mac
    vid = args.vid
    port_speed = int(args.port_speed, 16)

    if (num_splits * port_width) > max_lanes:
        print("Number of splits and width of each port cannot take more than %d lanes" % (max_lanes))
        print_usage()

    return slot_id, max_label_port, min_label_port, num_splits, port_width, file_path, base_mac, vid, port_speed, bonus_port_list


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = get_chip_type(handle, True)

    slot_id, max_label_port, min_label_port, num_splits, port_width, file_path, base_mac, vid, port_speed, bonus_port_list = parse_example_attributes(chip_type)

    if slot_id == INVALID_SLOT_ID:
        slot_count = system_slot_count_get(handle)
        if slot_count > 0:
            slot_id = 1
        else:
            slot_id = 0

    min_module = min_label_port - 1
    max_module = max_label_port - 1

    generate_xml(handle, slot_id, min_module, max_module, num_splits, port_width, file_path, base_mac, vid, port_speed, bonus_port_list)

    sx_api_close(handle)
