#!/usr/bin/env python
'''
This file contains Python command example for stateful DB entry set and entry meta get
using 4-tuple stateful DB key (Source IP, Destination IP, Source L4 port, Destination L4 port).
This example is supported on Spectrum4 and later devices.
'''

import errno
import sys
import argparse
import test_infra_common

from python_sdk_api.sx_api import *

stateful_db_op_dict = {
    'nop': SX_STATEFUL_DB_OP_NOP_E,
    'read': SX_STATEFUL_DB_OP_READ_E,
    'write': SX_STATEFUL_DB_OP_WRITE_E,
    'remove_with_indication': SX_STATEFUL_DB_OP_REMOVE_INDICATION_E,
    'remove_without_indication': SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E,
}

stateful_db_sem_op_dict = {
    'nop': SX_STATEFUL_DB_SEM_NOP_E,
    'lock': SX_STATEFUL_DB_SEM_LOCK_E,
    'unlock': SX_STATEFUL_DB_SEM_UNLOCK_E,
}


def parse_args():
    description_str = """
    This file contains Python command example for stateful DB entry set and entry meta get
    using 4-tuple stateful DB key (Source IP, Destination IP, Source L4 port, Destination L4 port).
    This example is supported on Spectrum4 and later devices.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--partition_id", type=int, default=1, help="Partition ID to use, range is [0-7]. Default is [%(default)d]")
    parser.add_argument("--key_id", type=int, default=1, help="Stateful key ID to use. Default is [%(default)d]")
    parser.add_argument("--entry_api", choices=['set', 'get'], default='get', help="API to preform: entry_set or entry_meta_get. Default is [%(default)s]")
    parser.add_argument("--db_op", choices=['nop', 'read', 'write', 'remove_with_indication', 'remove_without_indication'], default='nop', help="Stateful DB operation. Default is [%(default)s]")
    parser.add_argument("--sem_op", choices=['nop', 'lock', 'unlock'], default='nop', help="Stateful DB semaphore operation. Default is [%(default)s]")
    parser.add_argument("--entry_value", type=test_infra_common.auto_int, default=0, help="Entry value to set for 'write' DB operation. Default is [%(default)d]")
    parser.add_argument("--sip", type=str, default="1.1.1.1", help="Source IP for 4-tuple stateful DB key. Default is [%(default)s]")
    parser.add_argument("--dip", type=str, default="2.2.2.2", help="Destination IP for 4-tuple stateful DB key. Default is [%(default)s]")
    parser.add_argument("--sport", type=test_infra_common.auto_int, default=1001, help="Source L4 port for 4-tuple stateful DB key. Default is [%(default)d]")
    parser.add_argument("--dport", type=test_infra_common.auto_int, default=1002, help="Destination L4 port for 4-tuple stateful DB key. Default is [%(default)d]")
    return parser.parse_args()


def stateful_db_set_verbosity(handle, module, api):
    rc = sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module, api)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set stateful DB API log verbosity level")
        sys.exit(rc)


def validate_partition(handle, partition_id, orig_module_level, orig_api_level):
    partition_p = new_sx_stateful_db_partition_id_e_p()
    cnt_p = new_uint32_t_p()
    uint32_t_p_assign(cnt_p, 1)
    exit_example = False

    rc = sx_api_stateful_db_partition_iter_get(handle, SX_ACCESS_CMD_GET, partition_id, None, partition_p, cnt_p)
    if rc == SX_STATUS_SUCCESS:
        cnt = uint32_t_p_value(cnt_p)
        if cnt == 0:
            print("Partition ID {} was not allocated".format(partition_id))
            exit_example = True
    elif rc == SX_STATUS_MODULE_UNINITIALIZED:
        print("Stateful DB module is not initialized")
        rc = SX_STATUS_SUCCESS
        exit_example = True
    else:
        print("Failed in stateful DB partition iter get")
        exit_example = True

    delete_sx_stateful_db_partition_id_e_p(partition_p)
    delete_uint32_t_p(cnt_p)

    if exit_example:
        stateful_db_set_verbosity(handle, orig_module_level, orig_api_level)
        sys.exit(rc)


def validate_key_id(handle, key_id, orig_module_level, orig_api_level):
    key_id_p = new_sx_stateful_db_key_id_t_p()
    cnt_p = new_uint32_t_p()
    uint32_t_p_assign(cnt_p, 1)
    exit_example = False

    rc = sx_api_stateful_db_key_iter_get(handle, SX_ACCESS_CMD_GET, key_id, None, key_id_p, cnt_p)
    if rc == SX_STATUS_SUCCESS:
        cnt = uint32_t_p_value(cnt_p)
        if cnt == 0:
            print("Key ID {} was not allocated".format(key_id))
            exit_example = True
    elif rc == SX_STATUS_MODULE_UNINITIALIZED:
        print("Stateful DB module is not initialized")
        rc = SX_STATUS_SUCCESS
        exit_example = True
    else:
        print("Failed in stateful DB partition iter get")
        exit_example = True

    delete_sx_stateful_db_key_id_t_p(key_id_p)
    delete_uint32_t_p(cnt_p)

    if exit_example:
        stateful_db_set_verbosity(handle, orig_module_level, orig_api_level)
        sys.exit(rc)


def validate_args(handle, args):
    # Get original verbosity
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    rc = sx_api_stateful_db_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to retrieve stateful DB module verbosity")
        sys.exit(rc)

    orig_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    orig_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)
    delete_sx_verbosity_level_t_p(module_verbosity_level_p)
    delete_sx_verbosity_level_t_p(api_verbosity_level_p)

    # Set None verbosity
    stateful_db_set_verbosity(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

    # Check if partition was allocated - exit example otherwise
    validate_partition(handle, args.partition_id, orig_module_level, orig_api_level)

    # Check if key was allocated - exit example otherwise
    validate_key_id(handle, args.key_id, orig_module_level, orig_api_level)

    # Restore original verbosity
    stateful_db_set_verbosity(handle, orig_module_level, orig_api_level)


def create_sw_access_key(args):
    print("\nStateful DB SW access key:")
    print("--------------------------")
    print("Partition ID:        {}".format(args.partition_id))
    print("Stateful key ID:     {}".format(args.key_id))
    print("Source IP:           {}".format(args.sip))
    print("Destination IP:      {}".format(args.dip))
    print("Source L4 port:      {}".format(args.sport))
    print("Destination L4 port: {}".format(args.dport))
    key = sx_stateful_db_sw_access_key_t()
    key.key_id = args.key_id
    key.partition_id = args.partition_id
    key.key_data.acl_data.key_data_list_cnt = 4
    acl_key_data = sx_stateful_db_acl_key_data_t()
    acl_key_data.key_id = FLEX_ACL_KEY_SIP
    acl_key_data.key_value.sip = test_infra_common.make_sx_ip_addr(args.sip)
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 0, acl_key_data)
    acl_key_data.key_id = FLEX_ACL_KEY_DIP
    acl_key_data.key_value.dip = test_infra_common.make_sx_ip_addr(args.dip)
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 1, acl_key_data)
    acl_key_data.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    acl_key_data.key_value.l4_destination_port = args.dport
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 2, acl_key_data)
    acl_key_data.key_id = FLEX_ACL_KEY_L4_SOURCE_PORT
    acl_key_data.key_value.l4_source_port = args.sport
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 3, acl_key_data)
    if args.entry_api == 'set':
        print("DB operation:        {}".format(args.db_op))
        print("Semaphore operation: {}".format(args.sem_op))
        key.sem_op = stateful_db_sem_op_dict[args.sem_op]
        key.db_op = stateful_db_op_dict[args.db_op]
    return key


def main():
    args = parse_args()     # Parse given arguments
    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    print("[+] Open SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)
    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if (chip_type < SX_CHIP_TYPE_SPECTRUM4):
            print("This example is supported only from Spectrum4 - Exiting gracefully")
            sys.exit(0)

        # Validate key and partition exist
        validate_args(handle, args)

        key_p = new_sx_stateful_db_sw_access_key_t_p()
        data_p = new_sx_stateful_db_sw_access_data_t_p()
        meta_p = new_sx_stateful_db_entry_meta_t_p()

        sx_stateful_db_sw_access_key_t_p_assign(key_p, create_sw_access_key(args))

        if args.entry_api == 'set':
            if args.db_op == 'write':
                print("\nStateful DB SW access data:")
                print("---------------------------")
                print("DB entry value:      {}".format(args.entry_value))
                data_p.entry_data.db_entry_value = args.entry_value
            rc = sx_api_stateful_db_entry_set(handle, SX_ACCESS_CMD_SET, key_p, data_p)
        else:
            rc = sx_api_stateful_db_entry_meta_get(handle, SX_ACCESS_CMD_GET, key_p, data_p, meta_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed preform {} SW access".format(args.entry_api))
            sys.exit(rc)

        print("\nStateful DB SW access {} API:".format(args.entry_api))

        data = sx_stateful_db_sw_access_data_t_p_value(data_p)
        meta = sx_stateful_db_entry_meta_t_p_value(meta_p)
        print("----------")
        print("Entry data")
        print("----------")
        print("DB-OP RC:    {}".format(data.db_op_status))
        print("Entry found? {}".format(data.entry_found))
        print("Data value:  {}".format(data.entry_data.db_entry_value))
        if args.entry_api == 'get':
            print("----------")
            print("Entry meta")
            print("----------")
            print("Activity:    {}".format(meta.entry_activity))
            print("Sem state:   {}".format(meta.entry_sem_status))
            print("Sem cnt:     {}".format(meta.entry_sem_cnt))
        print("-----------------------")

        delete_sx_stateful_db_sw_access_key_t_p(key_p)
        delete_sx_stateful_db_sw_access_data_t_p(data_p)
        delete_sx_stateful_db_entry_meta_t_p(meta_p)

    finally:
        print("[+] Close SDK")
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
