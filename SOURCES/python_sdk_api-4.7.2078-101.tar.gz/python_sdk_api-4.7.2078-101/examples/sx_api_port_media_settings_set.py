#!/usr/bin/env python
"""
This example sets the port media settings using sx_api_port_media_settings_set API.
If lane list is empty - example will set media settings on all port available lanes.
If no ports will be provided - example will use default port 0x10001.
If no media settings will be given - example will use per define media settings according to chip type.
"""

import os
import sys
from python_sdk_api.sx_api import *
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    description_str = """
    This example sets the port media settings using sx_api_port_media_settings_set API.
    If lane list is empty - example will set media settings on all port available lanes.
    If no ports will be provided - example will use default port 0x10001.
    If no media settings will be given - example will use per define media settings according to chip type.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--log_port", type=test_infra_common.auto_int, default="0x10001",
                        help="Log port to use, either in hex format - 0x10001, or Int format - 65537")
    parser.add_argument('--lanes', type=int, default=None, nargs='+',
                        help='List of lanes ID to set. When none given, default is all port lanes')
    parser.add_argument("--idriver", type=int, default=0, help="High speed output driver amplitude, default is 0.")
    parser.add_argument("--tx_fir_pre1", type=int, default=0, help="Value for TX Finite Impulse Response (FIR) taps (pre1), default is 0.")
    parser.add_argument("--tx_fir_pre2", type=int, default=0, help="Value for TX Finite Impulse Response (FIR) taps (pre2), default is 0.")
    parser.add_argument("--tx_fir_pre3", type=int, default=0, help="Value for TX Finite Impulse Response (FIR) taps (pre3), default is 0.")
    parser.add_argument("--tx_fir_main", type=int, default=0, help="Value for TX Finite Impulse Response (FIR) taps (main), default is 0.")
    parser.add_argument("--tx_fir_post1", type=int, default=0, help="Value for TX Finite Impulse Response (FIR) taps (post1), default is 0.")
    parser.add_argument("--tx_pam4_ratio", type=int, default=0, help="MSB to LSB proportion, default is 0.")
    parser.add_argument("--tx_out_cmmn_mod", type=int, default=0, help="Output common mode, default is 0.")
    parser.add_argument("--tx_pmos_cmmn_mod", type=int, default=0, help="Output buffers input to Common mode P-channel Metal Oxide Semiconductor (PMOS) side, default is 0.")
    parser.add_argument("--tx_nmos_cmmn_mod", type=int, default=0, help="Output buffers input to Common mode N-channel Metal Oxide Semiconductor (NMOS) side, default is 0.")
    parser.add_argument("--tx_pmos_vltg_reg", type=int, default=0, help="Regulator voltage to pre output buffer PMOS side, default is 0.")
    parser.add_argument("--tx_nmos_vltg_reg", type=int, default=0, help="Regulator voltage to pre output buffer NMOS side, default is 0.")
    return parser.parse_args()


def is_zero_media_settings(media_settings):
    return (media_settings.idriver == 0 and
            media_settings.tx_fir_pre1 == 0
            and media_settings.tx_fir_pre2 == 0
            and media_settings.tx_fir_pre3 == 0
            and media_settings.tx_fir_main == 0
            and media_settings.tx_fir_post1 == 0
            and media_settings.tx_pam4_ratio == 0
            and media_settings.tx_out_cmmn_mod == 0
            and media_settings.tx_pmos_cmmn_mod == 0
            and media_settings.tx_nmos_cmmn_mod == 0
            and media_settings.tx_pmos_vltg_reg == 0
            and media_settings.tx_nmos_vltg_reg == 0)


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    # Spectrum3 example media settings
    media_settings_spectrum3 = sx_port_lane_media_settings_t()
    media_settings_spectrum3.idriver = 60
    media_settings_spectrum3.tx_fir_pre1 = 2
    media_settings_spectrum3.tx_fir_pre2 = 0
    media_settings_spectrum3.tx_fir_pre3 = 0
    media_settings_spectrum3.tx_fir_main = 32
    media_settings_spectrum3.tx_fir_post1 = 6
    media_settings_spectrum3.tx_pam4_ratio = 14
    media_settings_spectrum3.tx_out_cmmn_mod = 15
    media_settings_spectrum3.tx_pmos_cmmn_mod = 105
    media_settings_spectrum3.tx_nmos_cmmn_mod = 95
    media_settings_spectrum3.tx_pmos_vltg_reg = 30
    media_settings_spectrum3.tx_nmos_vltg_reg = 170

    # Spectrum4 example media settings
    media_settings_spectrum4 = sx_port_lane_media_settings_t()
    media_settings_spectrum4.idriver = 50
    media_settings_spectrum4.tx_fir_pre1 = -15
    media_settings_spectrum4.tx_fir_pre2 = 5
    media_settings_spectrum4.tx_fir_pre3 = 0
    media_settings_spectrum4.tx_fir_main = 43
    media_settings_spectrum4.tx_fir_post1 = 0
    media_settings_spectrum4.tx_pam4_ratio = 0
    media_settings_spectrum4.tx_out_cmmn_mod = 0
    media_settings_spectrum4.tx_pmos_cmmn_mod = 0
    media_settings_spectrum4.tx_nmos_cmmn_mod = 0
    media_settings_spectrum4.tx_pmos_vltg_reg = 0
    media_settings_spectrum4.tx_nmos_vltg_reg = 0

   # Spectrum5 example media settings
    media_settings_spectrum5 = sx_port_lane_media_settings_t()
    media_settings_spectrum5.idriver = 50
    media_settings_spectrum5.tx_fir_pre1 = -15
    media_settings_spectrum5.tx_fir_pre2 = 5
    media_settings_spectrum5.tx_fir_pre3 = 0
    media_settings_spectrum5.tx_fir_main = 43
    media_settings_spectrum5.tx_fir_post1 = 0
    media_settings_spectrum5.tx_pam4_ratio = 0
    media_settings_spectrum5.tx_out_cmmn_mod = 0
    media_settings_spectrum5.tx_pmos_cmmn_mod = 0
    media_settings_spectrum5.tx_nmos_cmmn_mod = 0
    media_settings_spectrum5.tx_pmos_vltg_reg = 0
    media_settings_spectrum5.tx_nmos_vltg_reg = 0

    media_settings_default_dict = {
        SX_CHIP_TYPE_SPECTRUM3: media_settings_spectrum3,
        SX_CHIP_TYPE_SPECTRUM4: media_settings_spectrum4,
        SX_CHIP_TYPE_SPECTRUM5: media_settings_spectrum5,
    }

    # Open Handle
    print("[+] Opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate module managment init parameter for examples - not supported when not independent module / standalone
        sx_api_sx_sdk_init_p = new_sx_api_sx_sdk_init_t_p()
        rc = sx_api_sdk_init_params_get(handle, sx_api_sx_sdk_init_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to get sdk init params.\n")
            sys.exit(rc)
        sdk_init_attr = sx_api_sx_sdk_init_t_p_value(sx_api_sx_sdk_init_p)
        if (sdk_init_attr.mgmt_params.support_type != SX_MGMT_MODULE_SUPPORT_INDEPENDENT_E and sdk_init_attr.mgmt_params.support_type != SX_MGMT_MODULE_SUPPORT_STANDALONE_E):
            print("This example is supported only when SDK init with independent module / standalone support - Exiting gracefully")
            sys.exit(0)

        log_port = args.log_port
        print("Media setting example for port 0x{:x}".format(log_port))

        # Store old media setting
        get_media_settings = sx_port_media_settings_t()
        get_media_settings.lane_cnt = 0
        orig_media_settings_p = copy_sx_port_media_settings_t_p(get_media_settings)
        rc = sx_api_port_media_settings_get(handle, SX_ACCESS_CMD_GET, log_port, orig_media_settings_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get port 0x{:x} media settings, rc = {}".format(log_port, test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        orig_media_settings = sx_port_media_settings_t_p_value(orig_media_settings_p)

        if is_zero_media_settings(args):
            print("No media settings given, example will use default values.")
            chip_type = test_infra_common.get_chip_type(handle)
            if chip_type not in media_settings_default_dict:
                print("This example doesn't hold default values for this chip type - Exiting gracefully")
                sys.exit(0)
            port_lane_media_settings = media_settings_default_dict[chip_type]
        else:
            port_lane_media_settings = sx_port_lane_media_settings_t()
            port_lane_media_settings.idriver = args.idriver
            port_lane_media_settings.tx_fir_pre1 = args.tx_fir_pre1
            port_lane_media_settings.tx_fir_pre2 = args.tx_fir_pre2
            port_lane_media_settings.tx_fir_pre3 = args.tx_fir_pre3
            port_lane_media_settings.tx_fir_main = args.tx_fir_main
            port_lane_media_settings.tx_fir_post1 = args.tx_fir_post1
            port_lane_media_settings.tx_pam4_ratio = args.tx_pam4_ratio
            port_lane_media_settings.tx_out_cmmn_mod = args.tx_out_cmmn_mod
            port_lane_media_settings.tx_pmos_cmmn_mod = args.tx_pmos_cmmn_mod
            port_lane_media_settings.tx_nmos_cmmn_mod = args.tx_nmos_cmmn_mod
            port_lane_media_settings.tx_pmos_vltg_reg = args.tx_pmos_vltg_reg
            port_lane_media_settings.tx_nmos_vltg_reg = args.tx_nmos_vltg_reg

        media_settings = sx_port_media_settings_t()
        if args.lanes is None:
            print("No lane given, will apply on all port lanes.")
            media_settings.lane_cnt = 0
            sx_port_lane_media_settings_t_arr_setitem(media_settings.media_settings, 0, port_lane_media_settings)
        else:
            media_settings.lane_cnt = len(args.lanes)
            for i, lane in enumerate(args.lanes):
                uint8_t_arr_setitem(media_settings.lane_id, i, lane)
                sx_port_lane_media_settings_t_arr_setitem(media_settings.media_settings, i, port_lane_media_settings)

        media_settings_p = copy_sx_port_media_settings_t_p(media_settings)
        rc = sx_api_port_media_settings_set(handle, SX_ACCESS_CMD_SET, log_port, media_settings_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to set port 0x{:x} media settings, rc = {}".format(log_port, test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        # Deinit configuration if user provided flag
        if args.deinit:
            restore_media_settings = sx_port_media_settings_t()
            restore_media_settings.lane_cnt = 0
            for i in range(orig_media_settings.lane_cnt):
                lane_id = uint8_t_arr_getitem(orig_media_settings.lane_id, i)
                settings = sx_port_lane_media_settings_t_arr_getitem(orig_media_settings.media_settings, i)
                if settings.idriver == 0:
                    print("Example WILL NOT restore media settings for port 0x{:x} lane ID {} since its has no configured settings (Original idriver value is 0)".format(log_port, lane_id))
                else:
                    uint8_t_arr_setitem(restore_media_settings.lane_id, restore_media_settings.lane_cnt, lane_id)
                    sx_port_lane_media_settings_t_arr_setitem(restore_media_settings.media_settings, restore_media_settings.lane_cnt, settings)
                    restore_media_settings.lane_cnt += 1
            if restore_media_settings.lane_cnt > 0:
                restore_media_settings_p = copy_sx_port_media_settings_t_p(restore_media_settings)
                rc = sx_api_port_media_settings_set(handle, SX_ACCESS_CMD_SET, log_port, restore_media_settings_p)
                if rc != SX_STATUS_SUCCESS:
                    print("Failed to restore port 0x{:x} media settings, rc = {}".format(log_port, test_infra_common.sx_status_dict[rc]))
                    sys.exit(rc)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
