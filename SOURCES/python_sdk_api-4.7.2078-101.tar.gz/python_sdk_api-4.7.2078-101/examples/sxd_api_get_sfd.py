#!/usr/bin/env python
import ctypes
import sys
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *

sfd_type_dict = {
    0: 'UNICAST',
    1: 'UNICAST_LAG',
    2: 'MULTICAST',
    12: 'UNICAST_TUNNEL',
    15: 'MULTICAST_TUNNEL'
}

sfd_action_dict = {
    0: "SFD_ACTION_FORWARD_ONLY",
    1: "SFD_ACTION_FORWARD_AND_TRAP",
    2: "SFD_ACTION_TRAP_ONLY",
    3: "SFD_ACTION_FORWARD_TO_IP_ROUTER",
    15: "SFD_ACTION_DISCARD"
}


def swig_to_byte(b):
    ty = ctypes.c_ubyte * 1
    v = ty.from_address(int(b))
    return v[0]


def print_sfd_action(sfd_action, spaces=6):
    action_str = sfd_action_dict.get(sfd_action, None)
    if action_str:
        print("[+] action%s: %s " % (" " * spaces, action_str))
    else:
        print("[+] action%s: %d " % (" " * spaces, sfd_action))


def show_sfd_uc(sfd):
    print("[+] type        : %s" % (sfd_type_dict[int(swig_to_byte(sfd.sfd_type))]))
    print("[+] policy      : %d " % (sfd.sfd_data_type.uc.policy))
    print("[+] system_port : %d " % (sfd.sfd_data_type.uc.system_port))
    print_sfd_action(sfd.sfd_data_type.uc.action)
    print("[+] activity    : %d " % (sfd.sfd_data_type.uc.activity))
    print("[+] set_vid     : %d " % (sfd.sfd_data_type.uc.set_vid))
    print("[+] vid         : %d " % (sfd.sfd_data_type.uc.vid))


def show_sfd_mc(sfd):
    print("[+] type        : %s" % (sfd_type_dict[int(swig_to_byte(sfd.sfd_type))]))
    print("[+] policy      : %d " % (sfd.sfd_data_type.mc.policy))
    print("[+] pgi         : %d " % (sfd.sfd_data_type.mc.pgi))
    print("[+] mid         : %d " % (sfd.sfd_data_type.mc.mid))
    print_sfd_action(sfd.sfd_data_type.mc.action)
    print("[+] activity    : %d " % (sfd.sfd_data_type.mc.activity))
    print("[+] vid         : %d " % (sfd.sfd_data_type.mc.vid))


def show_sfd_uc_lag(sfd):
    print("[+] type        : %s" % (sfd_type_dict[int(swig_to_byte(sfd.sfd_type))]))
    print("[+] policy      : %d " % (sfd.sfd_data_type.uc_lag.policy))
    print("[+] lag_id      : %d " % (sfd.sfd_data_type.uc_lag.lag_id))
    print_sfd_action(sfd.sfd_data_type.uc_lag.action)
    print("[+] activity    : %d " % (sfd.sfd_data_type.uc_lag.activity))
    print("[+] set_vid     : %d " % (sfd.sfd_data_type.uc_lag.set_vid))
    print("[+] vid         : %d " % (sfd.sfd_data_type.uc_lag.lag_vid))


def show_sfd_uc_tnl(sfd):
    print("[+] type                     : %s" % (sfd_type_dict[int(swig_to_byte(sfd.sfd_type))]))
    print("[+] policy                   : %d " % (sfd.sfd_data_type.uc_tunnel.policy))
    print("[+] activity                 : %d " % (sfd.sfd_data_type.uc_tunnel.activity))
    print_sfd_action(sfd.sfd_data_type.uc_tunnel.action, spaces=19)

    print("[+] gen_enc                  : %d " % (sfd.sfd_data_type.uc_tunnel.gen_enc))
    if sfd.sfd_data_type.uc_tunnel.gen_enc == 1:
        print("[+] udip_lsb                 : %d " % (sfd.sfd_data_type.uc_tunnel.udip_lsb))
        print("[+] ecmp_size                : %d " % (sfd.sfd_data_type.uc_tunnel.ecmp_size))
        print("[+] tunnel_port_lbf_bitmap   : %d " % (sfd.sfd_data_type.uc_tunnel.tunnel_port_lbf_bitmap))
    else:
        print("[+] protocol                 : %d " % (sfd.sfd_data_type.uc_tunnel.protocol))
        if sfd.sfd_data_type.uc_tunnel.protocol == 0:
            pass
            print("[+] ip                       : 0x%02x%06x" % (sfd.sfd_data_type.uc_tunnel.udip_msb, sfd.sfd_data_type.uc_tunnel.udip_lsb))
        else:
            print("[+] udip_lsb                 : %d " % (sfd.sfd_data_type.uc_tunnel.udip_lsb))

    print("[+] counter_set.type         : %d " % (sfd.sfd_data_type.uc_tunnel.counter_set.type))
    print("[+] counter_set.index        : %d " % (sfd.sfd_data_type.uc_tunnel.counter_set.index))


def show_sfd_mc_tnl(sfd):
    print("[+] type                     : %s" % (sfd_type_dict[int(swig_to_byte(sfd.sfd_type))]))
    print("[+] policy                   : %d " % (sfd.sfd_data_type.mc_tunnel.policy))
    print("[+] activity                 : %d " % (sfd.sfd_data_type.mc_tunnel.activity))
    print("[+] mid                      : %d " % (sfd.sfd_data_type.mc_tunnel.mid))
    print("[+] fid                      : %d " % (sfd.sfd_data_type.mc_tunnel.fid))
    print_sfd_action(sfd.sfd_data_type.mc_tunnel.action, spaces=19)
    print("[+] ul_mc_ptr                : %d " % (sfd.sfd_data_type.mc_tunnel.underlay_mc_ptr))
    print("[+] ecmp_size                : %d " % (sfd.sfd_data_type.mc_tunnel.ecmp_size))
    print("[+] tunnel_port_lbf_bitmap   : %d " % (sfd.sfd_data_type.mc_tunnel.tunnel_port_lbf_bitmap))
    print("[+] counter_set.type         : %d " % (sfd.sfd_data_type.mc_tunnel.counter_set.type))
    print("[+] counter_set.index        : %d " % (sfd.sfd_data_type.mc_tunnel.counter_set.index))


def show_sfd(sfd):
    if sfd.num_records == 0:
        print("Entry is not found")
        sys.exit(1)

    sfd_type = int(swig_to_byte(sfd.sfd_type))
    if sfd_type == 0:
        show_sfd_uc(sfd)
    elif sfd_type == 1:
        show_sfd_uc_lag(sfd)
    elif sfd_type == 2:
        show_sfd_mc(sfd)
    elif sfd_type == 12:
        show_sfd_uc_tnl(sfd)
    elif sfd_type == 15:
        show_sfd_mc_tnl(sfd)
    else:
        # If an exact match is not confirmed, this last case will be used if provided
        print("Unsupported sdf type %d" % (sfd_type))
        sys.exit(1)


def get_sfd(sfd_type, sfd_mac, sfd_fid, sfd_rec_type):
    sfd = ku_sfd_reg()
    sfd.swid = 0
    sfd.rec_type = sfd_rec_type
    sfd.operation = 1
    sfd.record_locator = 0
    sfd.num_records = 1
    ctypes.memset(int(sfd.sfd_type), sfd_type, 1)

    if sfd_type == 0:  # UC
        uc_data = sfd_unicast_data()
        uc_data.fid_vid_type.fid = sfd_fid
        mac_arr = [int(_, 16) for _ in sfd_mac.split(':')]
        for i in range(0, 6):
            uint8_t_arr_setitem(uc_data.mac.ether_addr_octet, i, mac_arr[i])
        sfd.sfd_data_type.uc = uc_data
    elif sfd_type == 1:  # UC LAG
        uc_lag_data = sfd_unicast_lag_data()
        uc_lag_data.fid_vid_type.fid = sfd_fid
        mac_arr = [int(_, 16) for _ in sfd_mac.split(':')]
        for i in range(0, 6):
            uint8_t_arr_setitem(uc_lag_data.mac.ether_addr_octet, i, mac_arr[i])
        sfd.sfd_data_type.uc_lag = uc_lag_data
    elif sfd_type == 2:  # MC
        mc_data = sfd_multicast_data()
        mc_data.vid = sfd_fid
        mac_arr = [int(_, 16) for _ in sfd_mac.split(':')]
        for i in range(0, 6):
            uint8_t_arr_setitem(mc_data.mac.ether_addr_octet, i, mac_arr[i])
        sfd.sfd_data_type.mc = mc_data
    elif sfd_type == 12:  # UC TUNNEL
        uc_tnl_data = sfd_uc_tunnel_data()
        uc_tnl_data.fid = sfd_fid
        mac_arr = [int(_, 16) for _ in sfd_mac.split(':')]
        for i in range(0, 6):
            uint8_t_arr_setitem(uc_tnl_data.mac.ether_addr_octet, i, mac_arr[i])
        sfd.sfd_data_type.uc_tunnel = uc_tnl_data
    elif sfd_type == 15:  # MC TUNNEL
        mc_tnl_data = sfd_mc_tunnel_data()
        mc_tnl_data.fid = sfd_fid
        mac_arr = [int(_, 16) for _ in sfd_mac.split(':')]
        for i in range(0, 6):
            uint8_t_arr_setitem(mc_tnl_data.mac.ether_addr_octet, i, mac_arr[i])
        sfd.sfd_data_type.mc_tunnel = mc_tnl_data
    else:
        print("wrong sfd type %d. exit" % (sfd_type))
        sys.exit(1)

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    print("[+] GET SFD entry fid: %d (0x%x), mac: %s, MAC type: %d, rec type: %d" % (sfd_fid, sfd_fid, sfd_mac, sfd_type, sfd_rec_type))

    rc = sxd_access_reg_sfd(sfd, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read SFD register, rc: %d" % (rc)

    return sfd


def parse_sfd_args():
    DEFAULT_REC_TYPE = 15

    parser = argparse.ArgumentParser(description='SFD read utility')
    parser.add_argument('--type', default=0, type=int, help="sfd type: uc:0, uc_lag:1, uc_tnl:12, mc:2, mc_tnl:15")
    parser.add_argument('--fid', default=0, type=int, help="fid of FDB entry")
    parser.add_argument('--mac', default="0:0:0:0:0:0", type=str, help="MAC address of FDB Entry, for example 00:11:22:33:44:55")
    parser.add_argument('--rec_type', default=DEFAULT_REC_TYPE, type=int, help="record type of FDB entry: 16B:0, 32B:1.\n If not given, the script will choose itself.")
    args = parser.parse_args()

    # show usage if no command line param was provided by user
    if len(sys.argv) == 1:
        print("some parameter is missing.")
        parser.print_usage()
        sys.exit(0)

    sfd_type_str = sfd_type_dict.get(args.type, None)
    if not sfd_type_str:
        print("Invalid sfd type: {}".format(args.type))
        parser.print_usage()
        sys.exit(1)

    sfd_type = args.type
    sfd_mac = args.mac
    sfd_fid = args.fid

    if args.rec_type == DEFAULT_REC_TYPE:
        # tunnel records are bigger than others
        if args.type == 12 or args.type == 15:
            sfd_rec_type = 1
        else:
            sfd_rec_type = 0
    else:
        sfd_rec_type = args.rec_type

    return sfd_type, sfd_mac, sfd_fid, sfd_rec_type


def main():
    sfd_type, sfd_mac, sfd_fid, sfd_rec_type = parse_sfd_args()

    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        sfd = get_sfd(sfd_type, sfd_mac, sfd_fid, sfd_rec_type)
        show_sfd(sfd)
    finally:
        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)


if __name__ == "__main__":
    main()
