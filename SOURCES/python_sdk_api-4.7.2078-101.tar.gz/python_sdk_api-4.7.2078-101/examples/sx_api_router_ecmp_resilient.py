#!/usr/bin/env python
"""

This file contains Python command example for resilient ECMP container which contains ip and ipinip next hops.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

"""
import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import time
import argparse

parser = argparse.ArgumentParser(description='sx_api_router_ecmp_resilient example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

# string constants
TUNN_ID = "TUNN"
IP_STR = "IP"
WEIGHT_STR = "weight"
RIF_STR = "RIF"

######################################################
#    functions
######################################################


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def create_loopback_rif(vrid, vlan, mtu=1500):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    tunnel_init(general_param_p)


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.mc_ecmp_enabled = False
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def example_ipinip_tunnel_create_flow(vrid, overlay_rif, usip):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4(usip)

    tunnel_attribute = make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(tunnel_attribute_p)

    return tunnel_id


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, underlay_rif=0, direction=SX_TUNNEL_DIRECTION_SYMMETRIC):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p.underlay_rif = underlay_rif  # =underlay_rif -- not supported

    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_mode = 0
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_key = 0

    tunnel_attribute.attributes.ipinip_p2p.decap.gre_check = 0
    tunnel_attribute.attributes.ipinip_p2p.decap.gre_check_key = 0
    tunnel_attribute.attributes.ipinip_p2p.decap.gre_expected_key = 0

    return tunnel_attribute


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return tunnel_id


def tunnel_destroy(tunnel_id):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    print(("Delete RIF: %d, rc: %d " % (rif, rc)))
    return rc


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        for key in nh:
            if key == TUNN_ID:
                next_hop = make_ecmp_next_hop_tunnel(nh[TUNN_ID], nh[IP_STR], nh[WEIGHT_STR])
            elif key == RIF_STR:
                next_hop = make_ecmp_next_hop_ip(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def make_ecmp_next_hop_tunnel(tunn_id, dst_ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
            This function creates ecmp_next_hop struct with given parametrs.
            action, counter_id and trap priority are optional.
    """
    address = make_sx_ip_addr_v4(dst_ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    nh_key.next_hop_key_entry.ip_tunnel.underlay_dip = address
    nh_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunn_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def make_ecmp_next_hop_ip(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates ecmp_next_hop struct with given parameters.
        action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


""" ############################################################################################ """


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates ecmp uc_route_data struct with given parametrs.
            action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    # set rif2 state to ipv4 enable
    rif_state_2 = sx_router_interface_state_t()
    rif_state_2.ipv4_enable = enable
    rif_state_2.ipv6_enable = False
    rif_state_2.ipv4_mc_enable = False
    rif_state_2.ipv6_mc_enable = False
    rif_state_p_2 = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p_2, rif_state_2)
    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p_2)
    print("Set rif %d state, rc: %d " % (rif, rc))


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def delete_next_hops_uc_route(vrid, addr, mask, ipv):
    " This function deletes all next hops from given vrid. "

    if ipv == 4:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted IPv" + str(ipv) + " uc next hops of VRID %d, rc: %d" % (vrid, rc))


def create_ip2me_route(vrid, rif, addr, mask="255.255.255.255"):
    " This function creates ip2me route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to created ip2me route for rif %d, rc: %d " % (rif, rc)

    print("Created ip2me route for rif %d, rc: %d " % (rif, rc))


def set_ecmp_attributes(handle, ecmp_id):
    "This function sets ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = SX_ECMP_TYPE_RESILIENT_E
    ecmp_attributes.active_flow_timer = 100
    ecmp_attributes.group_size = 4096
    ecmp_attributes.max_unbalanced_time = 200000000
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)


def read_ecmp_attributes(handle, ecmp_id):
    "This function reads ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_get(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read ECMP %d attributes, rc: %d" % (ecmp_id, rc)
    ecmp_attributes = sx_ecmp_attributes_t_p_value(ecmp_attributes_p)
    print_ecmp_attributes(ecmp_id, ecmp_attributes)


def print_ecmp_attributes(ecmp_id, ecmp_attributes):
    print("####################################################################")
    print("Router ECMP ID  %d:\n" % (ecmp_id))

    print("ECMP type:                {:>10}".format(ecmp_attributes.ecmp_type))
    print("ECMP active_flow_timer:   {:>10}".format(ecmp_attributes.active_flow_timer))
    print("ECMP group_size:          {:>10}".format(ecmp_attributes.group_size))
    print("ECMP max_unbalanced_time: {:>10}".format(ecmp_attributes.max_unbalanced_time))
    print("####################################################################\n")


def modify_external_ecmp_container(handle, ecmp_id, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param ecmp__id: ECMP container ID.
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify external ECMP container, rc %d" % (rc)

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Modified ECMP container ID %d " % (ecmp_id))


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted  neighbor from rif %d, rc: %d" % (rif, rc))


def delete_all_local_routes(handle, vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_ip2me_routes(handle, vrid):
    " This function deletes all ip2me routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    print(("Deleted all IP2ME UC routes, rc: %d " % (rc)))


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))

######################################################
#    main
######################################################


def main():

    # Configure vlan interfaces
    underlay_index = 1
    overlay_index = 0
    ul_vlan = 4
    ul_vlan_2 = 6
    ol_vlan = 5
    ol_vlan_2 = 7
    URIF_1_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07)
    URIF_2_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x04)
    ORIF_2_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08)
    ORIF_1_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x01)
    O_NEIGH_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6D, 0xA2)
    U_NEIGH_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x71)
    U_NEIGH_2_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x81)
    NEIGH_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x72)

    u_port_ip = "1.1.1.10"
    u_neigh_ip = "1.1.1.20"
    unet_ip = "1.1.0.0"
    unet_mask = "255.255.0.0"

    u_port_2_ip = "3.3.3.10"
    u_neigh_2_ip = "3.3.3.20"
    unet_2_ip = "3.3.0.0"

    o_neigh_ip = "10.10.10.20"
    o_port_ip = "10.10.10.10"
    onet_ip = "10.10.0.0"
    onet_mask = "255.255.0.0"
    inner_sip = "10.10.10.5"

    port_neigh_ip = "2.2.2.2"

    # init router
    router_init()

    # create overlay and underlay vrids
    ul_vrid = create_vrid()
    ol_vrid = create_vrid()

    # add port to vlan and create rif
    remove_ports_from_vlan(1, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ul_vlan, {PORT2: SX_TAGGED_MEMBER})
    port_rif_u = create_vlan_rif(ul_vrid, ul_vlan, URIF_1_MAC)

    remove_ports_from_vlan(1, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ol_vlan, {PORT1: SX_TAGGED_MEMBER})
    port_rif_o = create_vlan_rif(ol_vrid, ol_vlan, ORIF_2_MAC)

    remove_ports_from_vlan(1, {PORT3: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ol_vlan_2, {PORT3: SX_TAGGED_MEMBER})
    port_rif = create_vlan_rif(ol_vrid, ol_vlan_2, ORIF_1_MAC)

    remove_ports_from_vlan(1, {PORT4: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ul_vlan_2, {PORT4: SX_TAGGED_MEMBER})
    port_rif_u_2 = create_vlan_rif(ul_vrid, ul_vlan_2, URIF_2_MAC)

    # create loopback rif
    loopback_rif = create_loopback_rif(ol_vrid, 1)
    loopback_rif_2 = create_loopback_rif(ol_vrid, 1)

    # set IP on rif, add local route and neighbor
    create_ip2me_route(ol_vrid, port_rif_o, o_port_ip)
    add_neigh(port_rif_o, o_neigh_ip, O_NEIGH_MAC)

    create_ip2me_route(ul_vrid, port_rif_u, u_port_ip)
    create_local_route(ul_vrid, port_rif_u, unet_ip, unet_mask)
    add_neigh(port_rif_u, u_neigh_ip, U_NEIGH_MAC)

    create_ip2me_route(ul_vrid, port_rif_u_2, u_port_2_ip)
    create_local_route(ul_vrid, port_rif_u_2, unet_2_ip, unet_mask)
    add_neigh(port_rif_u_2, u_neigh_2_ip, U_NEIGH_2_MAC)

    add_neigh(port_rif, port_neigh_ip, NEIGH_MAC)

    # init tunnel
    example_tunnel_init_flow()

    # create ipinip tunnel
    tunnel_id = example_ipinip_tunnel_create_flow(ul_vrid, loopback_rif, u_port_ip)
    print(("tunnel id = 0x%x" % (tunnel_id)))
    tunnel_2_id = example_ipinip_tunnel_create_flow(ul_vrid, loopback_rif_2, u_port_2_ip)
    print(("tunnel 2 id = 0x%x" % (tunnel_2_id)))

    # set rifs to UP state
    set_rif_state_ipv4(loopback_rif)
    set_rif_state_ipv4(loopback_rif_2)
    set_rif_state_ipv4(port_rif_o)
    set_rif_state_ipv4(port_rif_u)
    set_rif_state_ipv4(port_rif_u_2)
    set_rif_state_ipv4(port_rif)

    # create empty next hops list and empty ECMP container
    next_hops_params_list = []
    ecmp_id = create_external_ecmp_container(next_hops_params_list)

    # set contaiter type to resilient
    set_ecmp_attributes(handle, ecmp_id)
    read_ecmp_attributes(handle, ecmp_id)

    # add IP next hop to container, create UC route
    next_hops_params_list.append({RIF_STR: port_rif,
                                  IP_STR: port_neigh_ip,
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    create_ecmp_uc_route(ol_vrid, onet_ip, onet_mask, ecmp_id)

    # another side start sending traffic (traffic is not terminated until running script)
    # packet for send - pip = Ether(dst="00:02:03:04:05:08", src="E4:1D:2D:1E:6D:A2")/Dot1Q(vlan=5)/IP(src="10.10.10.5",dst="10.10.10.20")
    # send packet to PORT1 (port_rif_o) - sendp(pip, iface='eth5',loop=1)
    print("####################################################################")
    print("Another side send traffic")
    print("Expect: traffic goes through rif %d (port 0x%x)" % (port_rif, PORT3))
    print("####################################################################\n")
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    # add tunnel to ECMP container
    next_hops_params_list.append({TUNN_ID: tunnel_id,
                                  IP_STR: u_neigh_ip,
                                  WEIGHT_STR: 100})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    print("Tunnel: 0x%x to container %d added" % (tunnel_id, ecmp_id))

    print("####################################################################")
    print("Another side continue send traffic")
    print("Expect: Taffic still goes through rif %d (port 0x%x)" % (port_rif, PORT3))
    print("####################################################################\n")
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    # delete port_rif neighbor
    delete_neigh(handle, port_rif, port_neigh_ip)
    print("Unresolve rif  %d " % (port_rif))

    print("####################################################################")
    print("Another side continue send traffic")
    print("Expect: Taffic start going through tunnel 0x%x (received packet udip - 1.1.1.20, port - 0x%x)" % (tunnel_id, PORT2))
    print("####################################################################\n")
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    # add another tunnel to ECMP container
    next_hops_params_list.append({TUNN_ID: tunnel_id,
                                  IP_STR: u_neigh_2_ip,
                                  WEIGHT_STR: 1000})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    print("Tunnel: 0x%x to container %d added" % (tunnel_2_id, ecmp_id))

    print("####################################################################")
    print("Another side continue send traffic")
    print("Expect: Taffic still going through tunnel 0x%x (received packet udip - 1.1.1.20, port - 0x%x)" % (tunnel_id, PORT2))
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    # delete tunnel_id from ECMP container
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: port_rif,
                                  IP_STR: "2.2.2.2",
                                  WEIGHT_STR: 1})
    next_hops_params_list.append({TUNN_ID: tunnel_2_id,
                                  IP_STR: u_neigh_2_ip,
                                  WEIGHT_STR: 1000})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    print("Tunnel: 0x%x from ecmp container %d removed" % (tunnel_2_id, ecmp_id))

    print("####################################################################")
    print("Another side continue send traffic")
    print("Expect: Taffic start going through tunnel 0x%x (received packet udip - 3.3.3.20, port - 0x%x)" % (tunnel_2_id, PORT3))
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    if args.deinit:
        # free resources
        delete_next_hops_uc_route(ol_vrid, onet_ip, onet_mask, ipv=4)

        # destroy external ECMP container
        destroy_ecmp_container(ecmp_id)

        set_rif_state_ipv4(loopback_rif, False)
        set_rif_state_ipv4(loopback_rif_2, False)
        set_rif_state_ipv4(port_rif_o, False)
        set_rif_state_ipv4(port_rif_u, False)
        set_rif_state_ipv4(port_rif, False)
        set_rif_state_ipv4(port_rif_u_2, False)

        # tunnel destroy
        tunnel_destroy(tunnel_id)
        tunnel_destroy(tunnel_2_id)

        # destroy loopbach rif
        delete_rif(ol_vrid, loopback_rif)
        delete_rif(ol_vrid, loopback_rif_2)

        delete_neigh(handle, port_rif_o, o_neigh_ip)
        delete_neigh(handle, port_rif_u, u_neigh_ip)
        delete_neigh(handle, port_rif_u_2, u_neigh_2_ip)
        delete_all_local_routes(handle, ol_vrid)
        delete_all_local_routes(handle, ul_vrid)
        delete_all_ip2me_routes(handle, ol_vrid)
        delete_all_ip2me_routes(handle, ul_vrid)

        # destroy rif
        delete_rif(ul_vrid, port_rif_u)
        delete_rif(ol_vrid, port_rif_o)
        delete_rif(ol_vrid, port_rif)
        delete_rif(ul_vrid, port_rif_u_2)

        delete_vrid(ol_vrid)
        delete_vrid(ul_vrid)

        # deinit tunnel
        tunnel_deinit()

        # deinit router
        router_deinit()

        remove_ports_from_vlan(ul_vlan, {PORT2: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(ol_vlan, {PORT1: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(ol_vlan_2, {PORT3: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(ul_vlan_2, {PORT4: SX_TAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT1: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT2: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT3: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT4: SX_UNTAGGED_MEMBER})

    sx_api_close(handle)


if __name__ == "__main__":
    main()
