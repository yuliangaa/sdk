#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
from python_sdk_api.sx_api import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


""" POOL LIST GET """
print("---------------  POOL LIST GET -----------------")
cnt = 8
pool_cnt_p = new_uint32_t_p()
""" Set cnt = 8 """
uint32_t_p_assign(pool_cnt_p, 0)

rc = sx_api_cos_pools_list_get(handle, pool_cnt_p, None)
print("CALL to: sx_api_cos_pool_list_get [cnt = 0] ")
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

uint32_t_p_assign(pool_cnt_p, cnt)
pool_list_p = new_sx_cos_pool_id_t_arr(cnt)
rc = sx_api_cos_pools_list_get(handle, pool_cnt_p, pool_list_p)
print(("CALL to: sx_api_cos_pool_list_get [cnt = %d] " % (cnt)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


for i in range(0, cnt):
    attr_item = sx_cos_pool_id_t_arr_getitem(pool_list_p, i)
    print(("[%d] pool ID = %d" % (i, attr_item)))

print("--------------------------------------------------------------------")
