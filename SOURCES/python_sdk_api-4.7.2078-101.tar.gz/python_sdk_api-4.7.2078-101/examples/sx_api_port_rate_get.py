#!/usr/bin/env python
'''
This file contains Python command example to set port rate (speed) value using sx_api_port_rate_get API.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
Note that this example is supported only if switch was run using the same API and not sx_api_port_speed_admin_set.
'''

import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='Port rate get example')
    parser.add_argument('--log_port', type=lambda s: s.split(","), help='Logical ports list to get rate for', default=['0x10001'])
    args = parser.parse_args()
    return args.log_port


def oper_rate_str_get(oper_rate):
    rate_str = {SX_PORT_RATE_NA_E: "N/A",
                SX_PORT_RATE_100M_E: "100M",
                SX_PORT_RATE_1G_E: "1G",
                SX_PORT_RATE_10G_E: "10G",
                SX_PORT_RATE_25G_E: "25G",
                SX_PORT_RATE_40G_E: "40G",
                SX_PORT_RATE_50Gx1_E: "50Gx1",
                SX_PORT_RATE_50Gx2_E: "50Gx2",
                SX_PORT_RATE_100Gx1_E: "100Gx1",
                SX_PORT_RATE_100Gx2_E: "100Gx2",
                SX_PORT_RATE_100Gx4_E: "100Gx4",
                SX_PORT_RATE_200Gx2_E: "200Gx2",
                SX_PORT_RATE_200Gx4_E: "200Gx4",
                SX_PORT_RATE_400Gx4_E: "400Gx4",
                SX_PORT_RATE_400Gx8_E: "400Gx8",
                SX_PORT_RATE_800Gx8_E: "800Gx8"}
    return rate_str[oper_rate]


def rate_list_get(rate_struct):
    rate_list = []
    if rate_struct.rate_100M:
        rate_list.append("100M")
    if rate_struct.rate_1G:
        rate_list.append("1G")
    if rate_struct.rate_10G:
        rate_list.append("10G")
    if rate_struct.rate_25G:
        rate_list.append("25G")
    if rate_struct.rate_40G:
        rate_list.append("40G")
    if rate_struct.rate_50G:
        rate_list.append("50G")
    if rate_struct.rate_50Gx1:
        rate_list.append("50Gx1")
    if rate_struct.rate_50Gx2:
        rate_list.append("50Gx2")
    if rate_struct.rate_100G:
        rate_list.append("100G")
    if rate_struct.rate_100Gx1:
        rate_list.append("100Gx1")
    if rate_struct.rate_100Gx2:
        rate_list.append("100Gx2")
    if rate_struct.rate_100Gx4:
        rate_list.append("100Gx4")
    if rate_struct.rate_200G:
        rate_list.append("200G")
    if rate_struct.rate_200Gx2:
        rate_list.append("200Gx2")
    if rate_struct.rate_200Gx4:
        rate_list.append("200Gx4")
    if rate_struct.rate_400G:
        rate_list.append("400G")
    if rate_struct.rate_400Gx4:
        rate_list.append("400Gx4")
    if rate_struct.rate_400Gx8:
        rate_list.append("400Gx8")
    if rate_struct.rate_800G:
        rate_list.append("800G")
    if rate_struct.rate_800Gx8:
        rate_list.append("800Gx8")
    if rate_struct.rate_auto:
        rate_list.append("auto")

    return rate_list


def display_port_rates(port, admin_rate_list, capab_rate_list, oper_rate):
    print(("  Log port: %s" % (port)))
    print(("    Port admin rate : %s" % (admin_rate_list)))
    print(("    Port rate capabilities: %s" % (capab_rate_list)))
    print(("    Port operational rate: %s\n" % (oper_rate)))


def run_example(handle, log_ports):

    oper_rate_p = new_sx_port_rate_e_p()
    admin_rate_p = new_sx_port_rate_bitmask_t_p()
    capab_rate_p = new_sx_port_rate_bitmask_t_p()
    capab_type_p = new_sx_port_phy_module_type_bitmask_t_p()

    for port in log_ports:
        log_port = int(port, 0)

        rc = sx_api_port_rate_get(handle, log_port, oper_rate_p)
        if rc != SX_STATUS_SUCCESS:
            if rc == SX_STATUS_CMD_UNSUPPORTED:
                print(("This API is not supported on this device (rc=%d)" % rc))
                sys.exit(0)
            print(("Error: failed to get port operational rate value, rc=%d." % (rc)))
            if rc == SX_STATUS_CMD_UNPERMITTED:
                print("  Looks like switch was configured with sx_api_port_speed_admin_set API, so using sx_api_port_rate_set is not allowed !\n")
            sys.exit(rc)

        rc = sx_api_port_rate_capability_get(handle, log_port, admin_rate_p, capab_rate_p, capab_type_p)
        if rc != SX_STATUS_SUCCESS:
            print(("Error: failed to get port admin and capability rate values, rc=%d." % (rc)))
            if rc == SX_STATUS_CMD_UNPERMITTED:
                print("  Looks like switch was configured with sx_api_port_speed_admin_set API,")
                print("  so using sx_api_port_rate_set is not allowed.")
            sys.exit(rc)

        # Display retrieved port rate information
        display_port_rates(port, rate_list_get(admin_rate_p), rate_list_get(capab_rate_p), oper_rate_str_get(sx_port_rate_e_p_value(oper_rate_p)))


################################################
# Run the MAIN function
################################################

if __name__ == "__main__":
    log_ports = parse_example_attributes()
    print("Given log ports: %s" % ",".join(log_ports))

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Run the main sx_api_port_rate_set API example with retrieved above parameters
    run_example(handle, log_ports)

    sx_api_close(handle)

    print("Example execution is finished successfully.")
