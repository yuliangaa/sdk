#!/usr/bin/env python

import sys
import errno
import argparse

from python_sdk_api.sxd_api import *

print("[+] Read SBPR register")

parser = argparse.ArgumentParser(description='SBPR read utility')
parser.add_argument('--dir', default=1, type=int, help="Ingress(0), Egress(1)")
parser.add_argument('--pool', default=0, type=int, help="Pool ID")
parser.add_argument('--descriptors', default=0, type=int, help="Descriptors or data pool")
args = parser.parse_args()

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initialize register access.\nPlease check that SDK is running.")
    sys.exit(rc)

sbpr = ku_sbpr_reg()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

""" Get SBPR """
meta.access_cmd = SXD_ACCESS_CMD_GET
sbpr.pool = args.pool
sbpr.dir = args.dir
sbpr.desc = args.descriptors
print(("SBPR GET: Dir:%d pool:%d desc:%d" % (sbpr.dir, sbpr.pool, sbpr.desc)))

rc = sxd_access_reg_sbpr(sbpr, meta, 1, None, None)
print(("SBPR GET RC=%d RESULT:" % rc))
if (rc != SXD_STATUS_SUCCESS):
    sys.exit(rc)

print(("dir: %d" % sbpr.dir))
print(("pool: %d" % sbpr.pool))
print(("size: %d" % sbpr.size))
print(("infinite_size: %d" % sbpr.infinite_size))
print(("Mode: %d" % sbpr.mode))
print(("buff_occupancy: %d" % sbpr.current_occupancy))
print(("max_buff_occupancy: %d" % sbpr.max_occupancy))
print(("ext_buff_occupancy: %d" % sbpr.current_ext_occupancy))

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("SBPR GET is Done")

sys.exit(0)
