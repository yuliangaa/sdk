#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''

import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


parser = argparse.ArgumentParser("Port PFC WD example")
parser.add_argument("-n", "--no_timeout",
                    dest="no_timeout",
                    action="store_true",
                    help="Run example until force stop (ctrl+c) or until traffic received")
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def main():

    try:

        SPECTRUM_SWID = 0
        PRIO = 6
        port_list = mapPortAndInterfaces(handle)
        PORT1 = port_list[0]
        PORT2 = port_list[1]

        """ Detect PAUSE """
        poll_interval = 0.1
        cmd = SX_ACCESS_CMD_READ
        statistics_cnt = 1
        statistic_param_list_p = new_sx_port_statistic_usage_params_t_arr(statistics_cnt)

        attr_item = sx_port_statistic_usage_params_t_arr_getitem(statistic_param_list_p, 0)
        """ Set relevant parameters """
        attr_item.port_cnt = 1
        attr_item.log_port_list_p = new_sx_port_log_id_t_arr(attr_item.port_cnt)
        """ Set a value at index 0 """
        sx_port_log_id_t_arr_setitem(attr_item.log_port_list_p, 0, PORT2)

        attr_item.sx_port_params.port_params_cnt = 1
        attr_item.sx_port_params.port_params_type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E

        attr_item.sx_port_params.port_param.port_tc_list_p = new_sx_cos_traffic_class_t_arr(attr_item.sx_port_params.port_params_cnt)
        statistic_param_list_p.sx_port_params.port_param.port_tc_list_p = new_sx_cos_traffic_class_t_arr(attr_item.sx_port_params.port_params_cnt)
        """ Set a value at index 0 (TC#0)"""
        sx_cos_traffic_class_t_arr_setitem(attr_item.sx_port_params.port_param.port_tc_list_p, 0, PRIO)

        print(("TC = %d" % (sx_cos_traffic_class_t_arr_getitem(attr_item.sx_port_params.port_param.port_tc_list_p, 0))))

        usage_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(usage_cnt_p, 0)
        sx_port_statistic_usage_params_t_arr_setitem(statistic_param_list_p, 0, attr_item)

        rc = sx_api_cos_port_buff_type_statistic_get(handle, cmd, statistic_param_list_p, statistics_cnt, None, usage_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        usage_cnt = uint32_t_p_value(usage_cnt_p)
        print(("usage_cnt (returned from API = %d)" % (usage_cnt)))

        """ Alloc mem for usage retrieved parametes """
        usage_list_p = new_sx_port_occupancy_statistics_t_arr(usage_cnt)

        cntr_tc_p = new_sx_port_traffic_cntr_t_p()
        cntr_prio_p = new_sx_port_cntr_prio_t_p()
        tx_queue = 0
        tx_frame = 0
        rx_pause = 0
        rx_pause_duration = 0
        rx_pause_duration_diff = 0
        first_detect = True
        attr_p = None
        shared_attr_p = None

        while True:
            rc = sx_api_cos_port_buff_type_statistic_get(handle, cmd, statistic_param_list_p, statistics_cnt, usage_list_p, usage_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            ret_item = sx_port_occupancy_statistics_t_arr_getitem(usage_list_p, 0)
            if ret_item.sx_port_params.port_params_type != SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
                continue

            print(("port_tc = %d" % (ret_item.sx_port_params.port_param.port_tc)))
            print(("Curr occupancy = %d" % (ret_item.statistics.curr_occupancy)))
            print(("Max occupancy = %d" % (ret_item.statistics.watermark)))

            sx_api_port_counter_prio_get(handle, SX_ACCESS_CMD_READ, PORT2, PRIO, cntr_prio_p)
            sx_api_port_counter_tc_get(handle, SX_ACCESS_CMD_READ, PORT2, PRIO, cntr_tc_p)

            print(("rx pause = %u" % (cntr_prio_p.rx_pause)))
            print(("rx pause duration= %u" % (cntr_prio_p.rx_pause_duration)))
            print(("tx queue = %u" % (cntr_tc_p.tx_queue)))
            print(("tx frame = %u" % (cntr_tc_p.tx_frames)))

            if first_detect:
                first_detect = False
                tx_frame = cntr_tc_p.tx_frames
                tx_queue = cntr_tc_p.tx_queue
                rx_pause = cntr_prio_p.rx_pause
                rx_pause_duration = cntr_prio_p.rx_pause_duration
                continue

            rx_pause_duration_diff = cntr_prio_p.rx_pause_duration - rx_pause_duration
            print(("rx pause duration diff = %u" % (rx_pause_duration_diff)))

            if not args.no_timeout:
                break

            if ret_item.statistics.curr_occupancy > 0:
                if (tx_frame == cntr_tc_p.tx_frames) and (rx_pause < cntr_prio_p.rx_pause):
                    print("Get mad pause")
                    break
            else:
                if (rx_pause_duration_diff >= 1000000 * poll_interval) and (rx_pause_duration_diff > 0):
                    print("Get mad pause")
                    break

            tx_frame = cntr_tc_p.tx_frames
            tx_queue = cntr_tc_p.tx_queue
            rx_pause = cntr_prio_p.rx_pause
            rx_pause_duration = cntr_prio_p.rx_pause_duration
            time.sleep(poll_interval)

        """ Disable TQ.TC """
        attr_p = new_sx_cos_port_buffer_attr_t_p()
        attr_deinit_p = new_sx_cos_port_buffer_attr_t_p()
        attr_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(attr_deinit_cnt_p, 1)

        attr_p.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        attr_p.attr.egress_port_tc_buff_attr.size = 0
        attr_p.attr.egress_port_tc_buff_attr.tc = PRIO
        attr_p.attr.egress_port_tc_buff_attr.pool_id = 4
        sx_cos_port_buffer_attr_t_p_assign(attr_deinit_p, attr_p)

        """ Get Current for deinit TQ.TC """
        rc = sx_api_cos_port_buff_type_get(handle, PORT2, attr_deinit_p, attr_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, attr_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        shared_attr_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr_deinit_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(shared_attr_deinit_cnt_p, 1)

        shared_attr_p.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        shared_attr_p.attr.egress_port_tc_shared_buff_attr.tc = PRIO
        shared_attr_p.attr.egress_port_tc_shared_buff_attr.max.mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E
        shared_attr_p.attr.egress_port_tc_shared_buff_attr.max.max.alpha = SX_COS_PORT_BUFF_ALPHA_0_E
        shared_attr_p.attr.egress_port_tc_shared_buff_attr.pool_id = 4
        sx_cos_port_shared_buffer_attr_t_p_assign(shared_attr_deinit_p, shared_attr_p)

        """ Get Current shared buffer attributes for deinit """
        rc = sx_api_cos_port_shared_buff_type_get(handle, PORT2, shared_attr_deinit_p, shared_attr_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [ log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, shared_attr_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        if args.deinit:
            if shared_attr_deinit_p is not None:
                rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, shared_attr_deinit_p, 1)
                print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc)))
                if rc != SX_STATUS_SUCCESS:
                    sys.exit(rc)

            if attr_deinit_p is not None:
                rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, attr_deinit_p, 1)
                print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc))
                if rc != SX_STATUS_SUCCESS:
                    sys.exit(rc)
    finally:

        delete_sx_port_log_id_t_arr(attr_item.log_port_list_p)
        delete_sx_cos_traffic_class_t_arr(statistic_param_list_p.sx_port_params.port_param.port_tc_list_p)
        delete_sx_port_statistic_usage_params_t_arr(statistic_param_list_p)
        delete_uint32_t_p(usage_cnt_p)
        delete_sx_port_occupancy_statistics_t_arr(usage_list_p)
        delete_sx_port_traffic_cntr_t_p(cntr_tc_p)
        delete_sx_port_cntr_prio_t_p(cntr_prio_p)
        delete_sx_cos_port_buffer_attr_t_p(attr_p)
        delete_sx_cos_port_buffer_attr_t_p(attr_deinit_p)
        delete_uint32_t_p(attr_deinit_cnt_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr_deinit_p)
        delete_uint32_t_p(shared_attr_deinit_cnt_p)
        sx_api_close(handle)


if __name__ == "__main__":
    main()
