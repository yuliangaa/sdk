#!/usr/bin/env python
"""
This file contains Python command example for the ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below configures the maximum possible number of UC routes with
resolved neighbors on VLAN RIFs.
Altogether the example configures:
    1. 1 Virtual router
    2. 2 router interfaces
    3. 2 local routes (1 per router interface)
    4. 8K neighbors (1 on the first RIF, and all the rest on the second)
    5. 90109 UC routes

"""
import sys
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_router_sw_neigh example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

rc, handle = sx_api_open(None)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

iRIF_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x06)
eRIF_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08)
NEIGH_MAC_1 = ether_addr(0x24, 0x8A, 0x07, 0x55, 0x11, 0x1C)
NEIGH_MAC_2 = ether_addr(0x24, 0x8A, 0x07, 0x55, 0x11, 0x1D)
NUM_NEIGHS = 8192
NUM_UC_ROUTES = 125000
MAX_UC_ROUTES = 125100  # 88K

# string constants
TUNN_ID = "TUNN"
IP_STR = "IP"
WEIGHT_STR = "weight"
RIF_STR = "RIF"

######################################################
#    functions
######################################################
# layer 2


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def set_port_state(log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))

    # router


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = addr
    ip_prefix.prefix.ipv4.mask.s_addr = mask
    return ip_prefix


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = addr
    return ip_addr


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


def make_sx_ip_addr_v6(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 0
    router_resource.min_ipv6_neighbor_entries = 0
    router_resource.min_ipv4_uc_route_entries = 0
    router_resource.min_ipv6_uc_route_entries = 0
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = NUM_NEIGHS
    router_resource.max_ipv6_neighbor_entries = NUM_NEIGHS
    router_resource.max_ipv4_uc_route_entries = MAX_UC_ROUTES
    router_resource.max_ipv6_uc_route_entries = MAX_UC_ROUTES
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parametrs.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def create_local_route_ipv6(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def set_rif_state_ipv6(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = False
    rif_state.ipv6_enable = True
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh_ipv4(rif, addr, mac_addr, iter=0):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add neigh to rif %d, rc = %d" % (iter, rif, rc)

    print("Iteration %d: Added neighbor to rif %d" % (iter, rif))


def add_neigh_ipv6(rif, addr, mac_addr, is_sw_only=False, iter=0):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif
    neigh_data.is_software_only = is_sw_only

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add neigh to rif %d, rc = %d" % (iter, rif, rc)

    print("Iteration %d: Added neighbor to rif %d" % (iter, rif))


def make_ecmp_next_hop(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates ecmp_next_hop struct with given parametrs.
        action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v6(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates ecmp uc_route_data struct with given parametrs.
        action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def delete_next_hops_uc_route(vrid, addr, mask, ipv):
    " This function deletes all next hops from given vrid. "

    if ipv == 4:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted IPv" + str(ipv) + " uc next hops of VRID %d, rc: %d" % (vrid, rc))


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, active_cnt %d, rc: %d " % (ecmp_id, active_cnt, rc))

    return ecmp_id


def create_ecmp_container(next_hop_arr=[], next_hop_cnt=0):
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, next_hop_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, active_cnt %d, rc: %d " % (ecmp_id, active_cnt, rc))

    return ecmp_id


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        for key in nh:
            if key == TUNN_ID:
                next_hop = make_ecmp_next_hop_tunnel(nh[TUNN_ID], nh[IP_STR], nh[WEIGHT_STR])
            elif key == RIF_STR:
                next_hop = make_ecmp_next_hop_ip(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def make_ecmp_next_hop_tunnel(tunn_id, dst_ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
                This function creates ecmp_next_hop struct with given parametrs.
                action, counter_id and trap priority are optional.
    """
    address = make_sx_ip_addr_v4(dst_ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    nh_key.next_hop_key_entry.ip_tunnel.underlay_dip = address
    nh_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunn_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def make_ecmp_next_hop_ip(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates ecmp_next_hop struct with given parameters.
        action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def destroy_router_counter(counter_id):
    " This function destroys router counter. "

    counter_p = new_sx_router_counter_id_t_p()
    sx_router_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed router counter %d, rc: %d" % (counter_id, rc))


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def unbind_router_counter(counter_id, rif):
    " This function unbinds router counter from rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to unbind router counter"
    print("Unbinded router counter %d from RIF %d, rc: %d" % (counter_id, rif, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def delete_neigh(rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_all_next_hops_per_vrid(vrid):
    " This function deletes all next hops from given vrid. "

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_next_hops_per_vrid_ipv6(vrid):
    " This function deletes all next hops from given vrid. "
    prefix = sx_ip_prefix_t()
    prefix.version = SX_IP_VERSION_IPV6
    prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(prefix_p, prefix)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_neigh_per_rif(rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_neigh_per_rif_ipv6(rif):
    " This function deletes all neighbors from given rif. "
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    ip_addr_p = new_sx_ip_addr_t_p()
    sx_ip_addr_t_p_assign(ip_addr_p, ip_addr)

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, ip_addr_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_local_routes(vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_local_routes_ipv6(vrid):
    " This function deletes all local uc routes from given vrid. "
    prefix = sx_ip_prefix_t()
    prefix.version = SX_IP_VERSION_IPV6
    prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(prefix_p, prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def add_pvid_to_port(vlan_id, port):
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, port, vlan_id)
    print(("Set pvid %d for port 0x%x rc %d " % (vlan_id, port, rc)))


def example_vlan_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_UNTAGGED_MEMBER})  # SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT2: SX_UNTAGGED_MEMBER})  # SX_TAGGED_MEMBER})

    add_pvid_to_port(4, PORT1)
    add_pvid_to_port(5, PORT2)

    # create vlan rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x06))
    rif_arr[1] = create_vlan_rif(vrid, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr


def example_vlan_rif_deinit(vrid, rif_arr):
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})

    delete_rif(vrid, rif_arr[1])
    delete_rif(vrid, rif_arr[0])


def router_configure(vrid, rif_arr):
    # add remote route
    prefix_addr = [0] * 16
    prefix_mask = [0] * 16
    for i in range(0, 8):
        prefix_mask[i] = 0xff

    prefix_addr[3] = 0x20
    prefix_addr[2] = 0x01

    # rif state ipv4
    set_rif_state_ipv6(rif_arr[0], True)
    set_rif_state_ipv6(rif_arr[1], True)

    # resolve neighbors, link local = fe80::268a:7ff:fe55:111d
    addr = [0] * 16
    addr[3] = 0xfe
    addr[2] = 0x80
    addr[11] = 0x26
    addr[10] = 0x8a
    addr[9] = 0x07
    addr[8] = 0xff
    addr[15] = 0xfe
    addr[14] = 0x55
    addr[13] = 0x11
    addr[12] = 0x1d

    # create ecmp
    weight = 1
    next_hop = make_ecmp_next_hop(rif_arr[1], addr, weight)
    next_hop_arr = new_sx_next_hop_t_arr(1)
    sx_next_hop_t_arr_setitem(next_hop_arr, 0, next_hop)
    ecmp_id = create_ecmp_container(next_hop_arr, 1)
    # create uc route
    create_ecmp_uc_route(vrid, prefix_addr, prefix_mask, ecmp_id)

    add_neigh_ipv6(rif_arr[1], addr, NEIGH_MAC_2, True)

    delete_next_hops_uc_route(vrid, prefix_addr, prefix_mask, 6)

    delete_all_next_hops_per_vrid(vrid)

    delete_all_next_hops_per_vrid_ipv6(vrid)

    destroy_ecmp_container(ecmp_id)

    delete_all_neigh_per_rif_ipv6(rif_arr[1])


def router_flow(vrid, rif_arr):
    # add remote route
    prefix_addr = [0] * 16
    prefix_mask = [0] * 16
    for i in range(0, 8):
        prefix_mask[i] = 0xff

    prefix_addr[3] = 0x20
    prefix_addr[2] = 0x01

    # rif state ipv4
    set_rif_state_ipv6(rif_arr[0], True)
    set_rif_state_ipv6(rif_arr[1], True)

    # resolve neighbors, link local = fe80::268a:7ff:fe55:111d
    addr = [0] * 16
    addr[3] = 0xfe
    addr[2] = 0x80
    addr[11] = 0x26
    addr[10] = 0x8a
    addr[9] = 0x07
    addr[8] = 0xff
    addr[15] = 0xfe
    addr[14] = 0x55
    addr[13] = 0x11
    addr[12] = 0x1d

    if args.deinit:
        add_neigh_ipv6(rif_arr[1], addr, NEIGH_MAC_2, True)

    # create ecmp
    weight = 1
    next_hop = make_ecmp_next_hop(rif_arr[1], addr, weight)
    next_hop_arr = new_sx_next_hop_t_arr(1)
    sx_next_hop_t_arr_setitem(next_hop_arr, 0, next_hop)
    ecmp_id = create_ecmp_container(next_hop_arr, 1)
    # create uc route
    create_ecmp_uc_route(vrid, prefix_addr, prefix_mask, ecmp_id)

    if args.deinit:
        delete_next_hops_uc_route(vrid, prefix_addr, prefix_mask, 6)

        delete_all_next_hops_per_vrid(vrid)

        delete_all_next_hops_per_vrid_ipv6(vrid)

        destroy_ecmp_container(ecmp_id)

        delete_all_neigh_per_rif_ipv6(rif_arr[1])


def main():

    # init router
    router_init()
    vrid = create_vrid()

    # router scale with vlan rif example
    rif_arr = example_vlan_rif_init(vrid)
    counter1 = create_router_counter()
    counter2 = create_router_counter()
    print("counter1 = %d" % counter1)
    print("counter2 = %d" % counter2)
    bind_router_counter(counter1, rif_arr[0])
    bind_router_counter(counter2, rif_arr[1])
    router_configure(vrid, rif_arr)
    router_flow(vrid, rif_arr)

    if args.deinit:
        unbind_router_counter(counter2, rif_arr[1])
        unbind_router_counter(counter1, rif_arr[0])
        destroy_router_counter(counter2)
        destroy_router_counter(counter1)
        example_vlan_rif_deinit(vrid, rif_arr)
        delete_vrid(vrid)
        router_deinit()
        add_pvid_to_port(1, PORT1)
        add_pvid_to_port(1, PORT2)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
