#!/usr/bin/env python
'''
This file contains Python command example for the Port module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import sys
import struct
import socket
import colorsys
import traceback
import os
import inspect
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse


def get_device_id_and_rev():
    sxd_access_reg_init(0, None, SX_VERBOSITY_LEVEL_INFO)
    mgir = ku_mgir_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert 0 == rc

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def get_chip_type():
    print("Retrieving Chip Type from SDK")
    device_id, _ = get_device_id_and_rev()

    if device_id == 0xCB84:
        print("Running over SPECTRUM chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM
    elif device_id == 0xCF6C:
        print("Running over SPECTRUM2 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM2
    elif device_id == 0xCF70:
        print("Running over SPECTRUM3 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM3
    else:
        print("chip type is not supported! exiting")
        sys.exit(0)

    return _chip_type


def main():
    parser = argparse.ArgumentParser(description='sx_api_cos_port_ptp_params_example')
    parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    chip_type = get_chip_type()
    if chip_type != SX_CHIP_TYPE_SPECTRUM:
        print("--WARNING-- chip type is not supported!")
        sys.exit(0)

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    ptp_shaper_params = sx_cos_ets_ptp_shaper_params_t()
    ptp_shaper_params.time_exp = 4
    ptp_shaper_params.time_mantissa = 7
    ptp_shaper_params.shaper_inc = 6
    ptp_shaper_params.shaper_bs = 6
    ptp_shaper_params.port_to_shaper_credits = 1

    ptp_shaper_params_p = new_sx_cos_ets_ptp_shaper_params_t_p()

    original_ptp_shaper_params_p = new_sx_cos_ets_ptp_shaper_params_t_p()
    print("get current ptp shaper params")
    rc = sx_api_cos_ets_ptp_shaper_param_get(handle, SX_ACCESS_CMD_GET, SX_COS_ETS_PTP_PORT_SPEED_100G, original_ptp_shaper_params_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get ptp shaper params for speed %d" % SX_COS_ETS_PTP_PORT_SPEED_100G
    original_ptp_shaper_params = sx_cos_ets_ptp_shaper_params_t_p_value(original_ptp_shaper_params_p)

    print("setting ptp shaper params")
    rc = sx_api_cos_ets_ptp_shaper_param_set(handle, SX_ACCESS_CMD_SET, SX_COS_ETS_PTP_PORT_SPEED_100G, ptp_shaper_params)
    assert rc == SX_STATUS_SUCCESS, "failed to set ptp shaper params, rc = %d" % rc

    print("validating ptp shaper params")
    rc = sx_api_cos_ets_ptp_shaper_param_get(handle, SX_ACCESS_CMD_GET, SX_COS_ETS_PTP_PORT_SPEED_100G, ptp_shaper_params_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get ptp shaper params for speed %d" % SX_COS_ETS_PTP_PORT_SPEED_100G

    ptp_shaper_params_get_val = sx_cos_ets_ptp_shaper_params_t_p_value(ptp_shaper_params_p)

    assert ptp_shaper_params_get_val.time_exp == ptp_shaper_params.time_exp, "time_exp got: %d, set: %d" % (ptp_shaper_params_get_val.time_exp, ptp_shaper_params.time_exp)
    assert ptp_shaper_params_get_val.time_mantissa == ptp_shaper_params.time_mantissa, "time_mantissa got: %d, set: %d" % (ptp_shaper_params_get_val.time_mantissa, ptp_shaper_params.time_mantissa)
    assert ptp_shaper_params_get_val.shaper_inc == ptp_shaper_params.shaper_inc, "shaper_inc got: %d, set: %d" % (ptp_shaper_params_get_val.shaper_inc, ptp_shaper_params.shaper_inc)
    assert ptp_shaper_params_get_val.shaper_bs == ptp_shaper_params.shaper_bs, "shaper_bs got: %d, set: %d" % (ptp_shaper_params_get_val.shaper_bs, ptp_shaper_params.shaper_bs)
    assert ptp_shaper_params_get_val.port_to_shaper_credits == ptp_shaper_params.port_to_shaper_credits, "port_to_shaper_credits got: %d, set: %d" % (ptp_shaper_params_get_val.port_to_shaper_credits, ptp_shaper_params.port_to_shaper_credits)

    print("deleting ptp shaper params")
    rc = sx_api_cos_ets_ptp_shaper_param_set(handle, SX_ACCESS_CMD_DELETE, SX_COS_ETS_PTP_PORT_SPEED_100G, ptp_shaper_params)
    assert rc == SX_STATUS_SUCCESS, "failed to set ptp shaper params, rc = %d" % rc

    port_ptp_params_p = new_sx_port_ptp_params_t_p()
    port_list = mapPortAndInterfaces(handle)
    PORT1 = port_list[0]

    port_ptp_params = sx_port_ptp_params_t()
    port_ptp_params.low_speed_role = SX_PORT_PTP_LOW_SPEED_RX_ROLE_PRIMARY
    port_ptp_params.cmd = SX_PORT_PTP_ROLE_CMD_ENABLE

    print("setting ptp port params")
    rc = sx_api_port_ptp_params_set(handle, SX_ACCESS_CMD_EDIT, PORT1, port_ptp_params)
    assert rc == SX_STATUS_SUCCESS, "failed to set ptp port params for port %d and role %d" % (PORT1, port_ptp_params.low_speed_role)

    print("getting ptp port params")
    rc = sx_api_port_ptp_params_get(handle, SX_ACCESS_CMD_GET, PORT1, port_ptp_params_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get ptp port params for port %d" % PORT1

    if args.deinit:
        port_ptp_params.cmd = SX_PORT_PTP_ROLE_CMD_DISABLE
        rc = sx_api_port_ptp_params_set(handle, SX_ACCESS_CMD_EDIT, PORT1, port_ptp_params)
        assert rc == SX_STATUS_SUCCESS, "failed to set ptp port params for port %d" % (PORT1)

        rc = sx_api_cos_ets_ptp_shaper_param_set(handle, SX_ACCESS_CMD_SET, SX_COS_ETS_PTP_PORT_SPEED_100G,
                                                 original_ptp_shaper_params)
        assert rc == SX_STATUS_SUCCESS, "failed to set ptp shaper params, rc = %d" % rc


if __name__ == "__main__":
    main()
