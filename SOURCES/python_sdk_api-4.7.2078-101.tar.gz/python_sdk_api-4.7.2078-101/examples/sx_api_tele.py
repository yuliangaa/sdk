#!/usr/bin/env python
"""
This file contains Python command example for the Telemetry module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
import sx_api_router as sx_api_router
import argparse
import test_infra_common

parser = argparse.ArgumentParser(description='sx_api_tele example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


######################################################
#    functions
######################################################


def tele_init():
    " This function init tele. "

    tele_param_p = new_sx_tele_init_params_t_p()

    rc = sx_api_tele_init_set(sx_api_router.handle, tele_param_p)
    assert SX_STATUS_SUCCESS == rc, "tele init failed rc: %d" % (rc)
    print("sx_api_tele_init_set rc: %d " % (rc))


def tele_deinit():
    " This function deinit tele. "

    rc = sx_api_tele_deinit_set(sx_api_router.handle)
    assert SX_STATUS_SUCCESS == rc, "tele deinit failed rc %d" % (rc)
    print("sx_api_tele_deinit_set rc: %d " % (rc))


def tele_attributes_set(internal_ts_enable):
    " This function set telemetry attributes. "

    tele_attr = sx_tele_attrib_t()
    tele_attr.internal_ts_enable = internal_ts_enable
    rc = sx_api_tele_attributes_set(sx_api_router.handle, tele_attr)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_attributes_set rc %d" % (rc)
    print("sx_api_tele_attributes_set rc: %d " % (rc))


def tele_attributes_get():
    " This function set telemetry attributes. "

    tele_attr_p = new_sx_tele_attrib_t_p()
    rc = sx_api_tele_attributes_get(sx_api_router.handle, tele_attr_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_attributes_get rc %d" % (rc)
    print("sx_api_tele_attributes_get rc: %d " % (rc))

    data = sx_tele_attrib_t_p_value(tele_attr_p)

    return data


def tele_histogram_set(cmd, port, type, tc=None, hist_id=None, sample_time=0, min_boundary=0, resolution=0,
                       mode=SX_TELE_HISTOGRAM_MODE_LINEAR_E, counter_type=None, ctl=None, repeatation=None):
    " This function set histogram entry. "

    key = sx_tele_histogram_key_t()
    key.type = type
    attr = sx_tele_histogram_attributes_data_t()
    attr.type = type

    if type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        port_counter = sx_tele_histogram_port_counter_key_t()
        port_counter.log_port = port
        port_counter.histogram_id = hist_id
        key.key.port_counter = port_counter

        counter_data = sx_tele_histogram_port_counter_attributes_data_t()
        counter_data.sample_time_resolution = sample_time
        counter_data.min_boundary = min_boundary
        counter_data.bin_size_resolution = resolution
        counter_data.mode = mode
        counter_data.control = ctl
        counter_data.port_counter_type = counter_type
        counter_data.repetition.number_of_repetitions = repeatation
        attr.data.port_counter = counter_data

    else:
        que_key = sx_tele_histogram_port_tc_key_t()
        que_key.log_port = port
        que_key.tc = tc
        key.key.port_tc = que_key

        que_data = sx_tele_histogram_queue_depth_attributes_data_t()
        que_data.sample_time_resolution = sample_time
        que_data.min_boundary = min_boundary
        que_data.bin_size_resolution = resolution
        que_data.mode = mode

        attr.data.queue_depth = que_data

    rc = sx_api_tele_histogram_set(sx_api_router.handle, cmd, key, attr)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_histogram_set rc %d" % (rc)
    print("sx_api_tele_histogram_set rc: %d " % (rc))


def tele_threshold_set(cmd, port, tc, threshold):
    " This function sets a threshold on the port and enables/disables the TC. "

    key = sx_tele_threshold_key_t()
    key.key_type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E

    key_attr = sx_tele_threshold_port_tc_key_t()
    key_attr.log_port = port
    key_attr.tc = tc
    key.key.port_tc = key_attr

    data = sx_tele_threshold_data_t()
    data.data_type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E
    data.data.threshold = threshold

    rc = sx_api_tele_threshold_set(sx_api_router.handle, cmd, key, data)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_threshold_set rc %d" % (rc)
    print("sx_api_tele_threshold_set rc: %d " % (rc))


def tele_threshold_get(cmd, port, tc):
    " This function gets the threshold of the port. "

    key = sx_tele_threshold_key_t()
    key.key_type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E
    key.key.port_tc.log_port = port
    key.key.port_tc.tc = tc

    data_p = new_sx_tele_threshold_data_t_p()

    rc = sx_api_tele_threshold_get(sx_api_router.handle, SX_ACCESS_CMD_GET, key, data_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_threshold_get rc %d" % (rc)
    print("sx_api_tele_threshold_get rc: %d " % (rc))

    data = sx_tele_threshold_data_t_p_value(data_p)

    return data


def tele_threshold_crossed_data_get(cmd, port, tc):
    " This function gets the threshold crossing status of select keys. (above/below) - disabled TCs will always return \"below\" "

    crossed_data_p = new_sx_tele_threshold_crossed_data_t_p()
    key = sx_tele_threshold_key_t()
    key.key_type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E

    key_attr = sx_tele_threshold_port_tc_key_t()
    key_attr.log_port = port
    key_attr.tc = tc
    key.key.port_tc = key_attr

    key_p = new_sx_tele_threshold_key_t_p()
    sx_tele_threshold_key_t_p_assign(key_p, key)

    rc = sx_api_tele_threshold_crossed_data_get(sx_api_router.handle, cmd, key, crossed_data_p, 1)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_threshold_crossed_data_get rc %d" % (rc)
    print("sx_api_tele_threshold_crossed_data_get rc: %d " % (rc))

    return sx_tele_threshold_crossed_data_t_p_value(crossed_data_p).data.port_tc


def tele_histogram_get(port, type, tc=None, hist_id=None):
    " This function get histogram entry. "

    key = sx_tele_histogram_key_t()
    key.type = type

    if type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        port_counter = sx_tele_histogram_port_counter_key_t()
        port_counter.log_port = port
        port_counter.histogram_id = hist_id
        key.key.port_counter = port_counter
    else:
        que_key = sx_tele_histogram_port_tc_key_t()
        que_key.log_port = port
        que_key.tc = tc
        key.key.port_tc = que_key

    attr_p = new_sx_tele_histogram_attributes_data_t_p()

    rc = sx_api_tele_histogram_get(sx_api_router.handle, SX_ACCESS_CMD_GET, key, attr_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_histogram_get rc %d" % (rc)
    print("sx_api_tele_histogram_get rc: %d " % (rc))

    attr = sx_tele_histogram_attributes_data_t_p_value(attr_p)

    return attr


def tele_histogram_iter_get(cmd, hist_count, port=0, tc=0, type=0, filter_port_valid=False, filter_port=0,
                            filter_tc_valid=False, filter_tc=0):
    " This function iter get histogram entry. "

    hist_list = new_sx_tele_histogram_key_t_arr(hist_count)

    hist_count_p = new_uint32_t_p()
    uint32_t_p_assign(hist_count_p, hist_count)

    filter = sx_tele_histogram_filter_t()
    if filter_port_valid:
        filter.filter_port_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E
        filter.port_filter = filter_port
    else:
        filter.filter_port_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E

    if filter_tc_valid:
        filter.filter_tc_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E
        filter.tc_filter = filter_tc
    else:
        filter.filter_tc_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E

    if port == 0:
        key_p = None
    else:
        key = sx_tele_histogram_key_t()
        key.type = type

        if type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
            port_counter = sx_tele_histogram_port_counter_key_t()
            port_counter.log_port = port
            port_counter.histogram_id = hist_id
            key.key.port_counter = port_counter
        else:

            que_key = sx_tele_histogram_port_tc_key_t()
            que_key.log_port = port
            que_key.tc = tc
            key.key.port_tc = que_key

        key_p = new_sx_tele_histogram_key_t_p()
        sx_tele_histogram_key_t_p_assign(key_p, key)

    rc = sx_api_tele_histogram_iter_get(sx_api_router.handle, cmd, key_p, filter, hist_list, hist_count_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_histogram_iter_get rc %d" % (rc)
    print("sx_api_tele_histogram_iter_get rc: %d " % (rc))

    count = uint32_t_p_value(hist_count_p)

    if hist_count > 0:
        print("\n##### Histogram list #####\n")
        for index in range(count):
            key = sx_tele_histogram_key_t_arr_getitem(hist_list, index)
            if(key.type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E):
                couner_key = key.key.port_counter
                print("Key %d: Port 0x%x, histogram id %d" % (index, couner_key.log_port, couner_key.histogram_id))
            else:
                que_key = key.key.port_tc
                print("Key %d: Port 0x%x, TC %d" % (index, que_key.log_port, que_key.tc))
        print("\n")

    return count


def tele_histogram_data_get(port, type, tc=None, hist_id=None, clear=False):
    " This function get histogram entry. "

    hist_data = sx_tele_histogram_data_t()
    hist_data_p = new_sx_tele_histogram_data_t_p()

    bins = new_uint64_t_arr(SX_TELE_HIST_MAX_BINS)

    hist_data.bins = bins
    hist_data.bins_cnt = SX_TELE_HIST_MAX_BINS
    sx_tele_histogram_data_t_p_assign(hist_data_p, hist_data)

    key = sx_tele_histogram_key_t()
    key.type = type

    if type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        port_counter = sx_tele_histogram_port_counter_key_t()
        port_counter.log_port = port
        port_counter.histogram_id = hist_id
        key.key.port_counter = port_counter
    else:

        que_key = sx_tele_histogram_port_tc_key_t()
        que_key.log_port = port
        que_key.tc = tc
        key.key.port_tc = que_key

    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
    else:
        cmd = SX_ACCESS_CMD_READ

    rc = sx_api_tele_histogram_data_get(sx_api_router.handle, cmd, key, hist_data_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_histogram_data_get rc %d" % (rc)
    print("sx_api_tele_histogram_data_get rc: %d " % (rc))

    hist_data = sx_tele_histogram_data_t_p_value(hist_data_p)
    bins = hist_data.bins

    print("\n##### Histogram data #####\n")
    for index in range(SX_TELE_HIST_MAX_BINS):
        val = uint64_t_arr_getitem(bins, index)
        print(" %d: %d" % (index, val))
    print("\n")


def tele_port_bw_gauge_set(cmd, alpha_factor=0, log_time_interval=0):

    gauge_p = new_sx_tele_gauge_config_t_p()
    gauge = sx_tele_gauge_config_t()
    gauge.log_time_interval = log_time_interval
    gauge.alpha_factor = alpha_factor

    sx_tele_gauge_config_t_p_assign(gauge_p, gauge)

    rc = sx_api_tele_port_bw_gauge_set(sx_api_router.handle, cmd, gauge_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_port_bw_gauge_set rc %d" % (rc)
    print("sx_api_tele_port_bw_gauge_set rc: %d " % (rc))


def tele_port_bw_gauge_get():
    gauge_p = new_sx_tele_gauge_config_t_p()
    gauge = sx_tele_gauge_config_t()
    sx_tele_gauge_config_t_p_assign(gauge_p, gauge)

    rc = sx_api_tele_port_bw_gauge_get(sx_api_router.handle, SX_ACCESS_CMD_GET, gauge_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_port_bw_gauge_get rc %d" % (rc)
    print("sx_api_tele_port_bw_gauge_get rc: %d " % (rc))

    gauge = sx_tele_gauge_config_t_p_value(gauge_p)
    print("alpha_factor: %d  log_time_interval: %d" % (gauge.alpha_factor, gauge.log_time_interval))
    return gauge.log_time_interval, gauge.alpha_factor


def tele_port_bw_gauge_data_get(port_list):

    gauge_key_p = new_sx_tele_gauge_key_t_p()
    gauge_key = sx_tele_gauge_key_t()
    gauge_key.port_cnt = len(port_list)

    for i, port in enumerate(port_list):
        sx_port_log_id_t_arr_setitem(gauge_key.port_list, i, port_list[i])
    sx_tele_gauge_key_t_p_assign(gauge_key_p, gauge_key)

    gauage_data_p = new_sx_tele_gauge_data_t_p()
    gauage_data = sx_tele_gauge_data_t()
    sx_tele_gauge_data_t_p_assign(gauage_data_p, gauage_data)

    rc = sx_api_tele_port_bw_gauge_data_get(sx_api_router.handle, SX_ACCESS_CMD_GET, gauge_key_p, gauage_data_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_port_bw_gauge_data_get rc %d" % (rc)
    print("sx_api_tele_port_bw_gauge_data_get rc: %d " % (rc))

    gauage_data = sx_tele_gauge_data_t_p_value(gauage_data_p)

    print("\n##### gauge data #####\n")
    for i in range(len(port_list)):
        port_gauge_data = sx_tele_gauge_port_data_t_arr_getitem(gauage_data.port_data_list, i)
        print("port: {} tx_bw: {}, rx_bw: {}".format(hex(port_gauge_data.port_id), port_gauge_data.tx_bw, port_gauge_data.rx_bw))


def tele_flow(vrid, rif_arr):

    # add local and ip2me routes
    sx_api_router.create_local_route(vrid, rif_arr[0], "192.168.1.0", "255.255.255.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[0], "192.168.1.1")
    sx_api_router.create_local_route(vrid, rif_arr[1], "22.33.0.0", "255.255.0.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[1], "22.33.44.55")

    # rif state ipv4
    sx_api_router.set_rif_state_ipv4(rif_arr[0])
    sx_api_router.set_rif_state_ipv4(rif_arr[1])

    # add neighbors
    sx_api_router.add_neigh(rif_arr[1], "22.33.0.2", sx_api_router.NEIGH_MAC_2)

    # create external ECMP container
    next_hops_params_list = []
    next_hops_params_list.append({sx_api_router.RIF_STR: rif_arr[1],
                                  sx_api_router.IP_STR: "22.33.0.2",
                                  sx_api_router.WEIGHT_STR: 1})
    ecmp_id = sx_api_router.create_external_ecmp_container(next_hops_params_list)
    sx_api_router.create_ecmp_uc_route(vrid, "100.100.128.0", "255.255.255.0", ecmp_id)

    ####################
    ## Histogram flow ##
    ####################

    # init telemetry
    tele_init()

    tele_attrib = tele_attributes_get()
    print("internal_ts_enable: %d " % (tele_attrib.internal_ts_enable))
    tele_attributes_set(SX_TS_OVER_CRC_INGRESS_MODE_DISABLE_E)
    tele_attrib = tele_attributes_get()
    print("internal_ts_enable: %d " % (tele_attrib.internal_ts_enable))
    tele_attributes_set(SX_TS_OVER_CRC_INGRESS_MODE_ENABLE_E)
    tele_attrib = tele_attributes_get()
    print("internal_ts_enable: %d " % (tele_attrib.internal_ts_enable))

    # add histogram entry
    tele_histogram_set(cmd=SX_ACCESS_CMD_SET,
                       port=sx_api_router.PORT1,
                       type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E,
                       tc=1,
                       hist_id=None,
                       sample_time=3,
                       min_boundary=3,
                       resolution=3,
                       mode=SX_TELE_HISTOGRAM_MODE_LINEAR_E)

    # edit histogram entry
    tele_histogram_set(cmd=SX_ACCESS_CMD_EDIT,
                       port=sx_api_router.PORT1,
                       type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E,
                       tc=1,
                       hist_id=None,
                       sample_time=4,
                       min_boundary=4,
                       resolution=4,
                       mode=SX_TELE_HISTOGRAM_MODE_LINEAR_E)

    # add histogram entry
    tele_histogram_set(cmd=SX_ACCESS_CMD_SET,
                       port=sx_api_router.PORT2,
                       type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E,
                       tc=4,
                       hist_id=None,
                       sample_time=3,
                       min_boundary=3,
                       resolution=3,
                       mode=SX_TELE_HISTOGRAM_MODE_LINEAR_E)

    chip_type = test_infra_common.get_chip_type(sx_api_router.handle)
    if (chip_type >= SX_CHIP_TYPE_SPECTRUM2):
        # add histogram entry
        tele_histogram_set(cmd=SX_ACCESS_CMD_SET,
                           port=sx_api_router.PORT2,
                           type=SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E,
                           tc=None,
                           hist_id=SX_TELE_HISTOGRAM_PORT_COUNTER_ID_0_E,
                           sample_time=3,
                           min_boundary=5,
                           resolution=4,
                           mode=SX_TELE_HISTOGRAM_MODE_EXPONENT_E,
                           counter_type=SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_2047BYTE_PACKETS_RECEIVED_E,
                           ctl=SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_START_REP_E,
                           repeatation=1000)

    # get histogram attributes
    tele_attr_1 = tele_histogram_get(port=sx_api_router.PORT1,
                                     type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E,
                                     tc=1,
                                     hist_id=None)

    if (chip_type >= SX_CHIP_TYPE_SPECTRUM2):
        tele_attr_2 = tele_histogram_get(port=sx_api_router.PORT2,
                                         type=SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E,
                                         tc=None,
                                         hist_id=SX_TELE_HISTOGRAM_PORT_COUNTER_ID_0_E)

    # get histograms total size
    count = tele_histogram_iter_get(cmd=SX_ACCESS_CMD_GET, hist_count=0)

    # get histogram key list
    count = tele_histogram_iter_get(cmd=SX_ACCESS_CMD_GET_FIRST, hist_count=3)

    ##########################################################
    # Traffic 192.168.1.2 --> 100.100.128.X(via 22.33.0.2)
    ##########################################################

    # read histogram data
    tele_histogram_data_get(port=sx_api_router.PORT1,
                            type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E,
                            tc=1,
                            hist_id=None,
                            clear=False)

    if (chip_type >= SX_CHIP_TYPE_SPECTRUM2):
        tele_histogram_data_get(port=sx_api_router.PORT2,
                                type=SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E,
                                tc=None,
                                hist_id=SX_TELE_HISTOGRAM_PORT_COUNTER_ID_0_E,
                                clear=True)

    # delete histogram entry
    tele_histogram_set(cmd=SX_ACCESS_CMD_DESTROY,
                       port=sx_api_router.PORT1,
                       tc=1,
                       type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E)

    tele_histogram_set(cmd=SX_ACCESS_CMD_DESTROY,
                       port=sx_api_router.PORT2,
                       tc=4,
                       type=SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E)

    if (chip_type >= SX_CHIP_TYPE_SPECTRUM2):
        tele_histogram_set(cmd=SX_ACCESS_CMD_DESTROY,
                           port=sx_api_router.PORT2,
                           type=SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E,
                           tc=None,
                           hist_id=SX_TELE_HISTOGRAM_PORT_COUNTER_ID_0_E,
                           sample_time=3,
                           min_boundary=5,
                           resolution=4,
                           mode=SX_TELE_HISTOGRAM_MODE_LINEAR_E,
                           counter_type=SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_2047BYTE_PACKETS_RECEIVED_E,
                           ctl=SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_STOP_E,
                           repeatation=1000)

    ####################
    ## Threshold flow ##
    ####################

    # add threshold entry
    tele_threshold_set(cmd=SX_ACCESS_CMD_SET,
                       port=sx_api_router.PORT1,
                       tc=1,
                       threshold=100)

    # edit threshold entry
    tele_threshold_set(cmd=SX_ACCESS_CMD_EDIT,
                       port=sx_api_router.PORT1,
                       tc=1,
                       threshold=1)

    # add threshold entry
    tele_threshold_set(cmd=SX_ACCESS_CMD_SET,
                       port=sx_api_router.PORT2,
                       tc=4,
                       threshold=200)

    # get threshold data
    tele_attr = tele_threshold_get(cmd=SX_ACCESS_CMD_GET,
                                   port=sx_api_router.PORT1,
                                   tc=1)

    crossed_data = tele_threshold_crossed_data_get(cmd=SX_ACCESS_CMD_GET,
                                                   port=sx_api_router.PORT1,
                                                   tc=1)

    ##########################################################
    # Traffic 192.168.1.2 --> 100.100.128.X(via 22.33.0.2)
    ##########################################################

    crossed_data = tele_threshold_crossed_data_get(cmd=SX_ACCESS_CMD_GET,
                                                   port=sx_api_router.PORT1,
                                                   tc=1)

    # read threshold data
    tele_threshold_get(cmd=SX_ACCESS_CMD_GET,
                       port=sx_api_router.PORT1,
                       tc=1)

    ####################
    ## gauge bw flow ##
    ####################

    if (chip_type >= SX_CHIP_TYPE_SPECTRUM4):
        # set bw gauge params
        tele_port_bw_gauge_set(cmd=SX_ACCESS_CMD_SET, alpha_factor=1, log_time_interval=6)

        # get bw gauge params
        tele_port_bw_gauge_get()

        # get bw gauge data
        tele_port_bw_gauge_data_get([sx_api_router.PORT1, sx_api_router.PORT2])

        # retrun bw gauge params to defaulte
        tele_port_bw_gauge_set(cmd=SX_ACCESS_CMD_DESTROY)

    return vrid, rif_arr, ecmp_id


def tele_flow_deinit(vrid, rif_arr, ecmp_id):
    # delete threshold entry
    tele_threshold_set(cmd=SX_ACCESS_CMD_DESTROY,
                       port=sx_api_router.PORT1,
                       tc=1,
                       threshold=100)

    tele_threshold_set(cmd=SX_ACCESS_CMD_DESTROY,
                       port=sx_api_router.PORT2,
                       tc=4,
                       threshold=150)

    # deinit telemetry
    tele_deinit()

    # delete all next hop uc routes
    sx_api_router.delete_all_next_hops_uc_routes_per_vrid(vrid)
    # destroy external ECMP container
    sx_api_router.destroy_ecmp_container(ecmp_id)

    # delete all neighbors per rif
    sx_api_router.delete_all_neigh_per_rif(rif_arr[0])
    sx_api_router.delete_all_neigh_per_rif(rif_arr[1])

    # delete all local and ip2me routes
    sx_api_router.delete_all_local_routes(vrid)
    sx_api_router.delete_all_ip2me_routes(vrid)

    # delete rif
    sx_api_router.delete_rif(vrid, rif_arr[0])
    sx_api_router.delete_rif(vrid, rif_arr[1])


######################################################
#    main
######################################################


def main():

    # init router
    sx_api_router.router_init()

    vrid = sx_api_router.create_vrid()

    # vlan rif example
    rif_arr = sx_api_router.example_vlan_rif_init(vrid)

    vrid, rif_arr, ecmp_id = tele_flow(vrid, rif_arr)

    if args.deinit:
        tele_flow_deinit(vrid, rif_arr, ecmp_id)

        sx_api_router.example_vlan_rif_deinit(vrid, rif_arr)

        # delete vrid
        sx_api_router.delete_vrid(vrid)

        # deinit router
        sx_api_router.router_deinit()


if __name__ == "__main__":
    main()
