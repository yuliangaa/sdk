#!/usr/bin/env python
'''
This file contains Python command example that reads all the extraction point in the system
and displays their value.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
This example is supported on Spectrum2 and later devices
'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_parser_ext_point_dump example')
parser.add_argument('--reg', dest='reg_id', default=None, type=int, help='Optional Register ID')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

reg_type_dict = {
    SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E: 'GP register'
}

ext_point_dict = {
    SX_EXTRACTION_POINT_TYPE_NONE_E: "None",
    SX_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER_E: "L2 start of header",
    SX_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE_E: "L2 ether type",
    SX_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER_E: "IPV4 start of header",
    SX_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD_E: "IPV4 start of payload",
    SX_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER_E: "ARP start of header",
    SX_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER_E: "IPV6 start of header",
    SX_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD_E: "IPV6 start of payload",
    SX_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER_E: "MPLS start of header",
    SX_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD_E: "payload",
    SX_EXTRACTION_POINT_TYPE_GRE_PAYLOAD_E: "GRE payload",
    SX_EXTRACTION_POINT_TYPE_UDP_PAYLOAD_E: "UDP payload",
    SX_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER_E: "Inner L2 start of header",
    SX_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE_E: "Inner L2 ether type",
    SX_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER_E: "Inner IPV4 start of header",
    SX_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD_E: "Inner IPV4 start of payload",
    SX_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER_E: "Inner IPV6 start of header",
    SX_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD_E: "Inner IPV6 start of payload",
    SX_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD_E: "Inner UDP payload",
    SX_EXTRACTION_POINT_TYPE_LAST_E: "Last",
}


def reg_id_reg(reg_key):
    if reg_key.type == SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        return reg_key.key.gp_reg.reg_id
    return -1


def example_exit(rc):
    sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_flex_module_level, orig_flex_api_level)
    sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_reg_module_level, orig_reg_api_level)
    sx_api_close(handle)
    sys.exit(rc)


def print_reg_ext_point_list(reg_key):
    ext_point_cnt_p = new_uint32_t_p()

    rc = sx_api_flex_parser_reg_ext_point_get(handle, reg_key, None, ext_point_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("Flex parser module is not initialized")
        else:
            print("Failed in extraction point get: rc = " + str(rc))
        example_exit(rc)
    ext_point_cnt = uint32_t_p_value(ext_point_cnt_p)

    if ext_point_cnt == 0:
        print('=' * 45)
        print("No extraction points for %s ID %d" % (reg_type_dict[reg_key.type], reg_id_reg(reg_key)))
        print('=' * 45)
    else:
        ext_point_list_p = new_sx_extraction_point_t_arr(ext_point_cnt)
        rc = sx_api_flex_parser_reg_ext_point_get(handle, reg_key, ext_point_list_p, ext_point_cnt_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed in extraction point get: rc = " + str(rc))
            example_exit(rc)
        ext_point_cnt = uint32_t_p_value(ext_point_cnt_p)
        print('=' * 45)
        print("Extraction point list for %s ID %d:" % (reg_type_dict[reg_key.type], reg_id_reg(reg_key)))
        print('-' * 45)
        print("| %30s | %8s |" % ("Extraction Point Type", "Offset"))
        print('-' * 45)

        for i in range(ext_point_cnt):
            ext_point_entry = sx_extraction_point_t_arr_getitem(ext_point_list_p, i)
            print("| %30s | %8d |" % (ext_point_dict[ext_point_entry.type], ext_point_entry.offset))
        print('=' * 45)


mgir = ku_mgir_reg()
meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.access_cmd = SXD_ACCESS_CMD_GET

rc = sxd_access_reg_init(0, None, 2)
if rc:
    print("Failed to init SXD Access")
    sys.exit(rc)

rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
if rc:
    print("Failed to access MGIR Register")
    sys.exit(rc)

rc = sxd_access_reg_deinit()
if rc:
    print("Failed to deinit SXD Access")
    sys.exit(rc)

if mgir.hw_info.device_id == 0xCB84:    # SPC1 ID
    print("WARNING: Flex parser ext point dump not supported on SPC1")
    sys.exit(0)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

module_verbosity_level_p = new_sx_verbosity_level_t_p()
api_verbosity_level_p = new_sx_verbosity_level_t_p()
rc = sx_api_flex_parser_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
if rc != SX_STATUS_SUCCESS:
    print("Failed to retrieve the FLEX PARSER current verbosity setting!")
    sys.exit(rc)

orig_flex_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
orig_flex_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

rc = sx_api_register_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
if rc != SX_STATUS_SUCCESS:
    print("Failed to retrieve the REGISTER Module current verbosity setting!")
    sys.exit(rc)

orig_reg_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
orig_reg_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

rc = sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
if rc != SX_STATUS_SUCCESS:
    print("fail to set FLEX PARSER API log verbosity level")
    example_exit(rc)

rc = sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
if rc != SX_STATUS_SUCCESS:
    print("fail to set Regsiter API log verbosity level")
    example_exit(rc)

reg_cnt_p = new_uint32_t_p()
key = sx_register_key_t()

if args.reg_id is None:
    uint32_t_p_assign(reg_cnt_p, 0)
    rc = sx_api_register_iter_get(handle, SX_ACCESS_CMD_GET, key, None, None, reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        if rc == SX_STATUS_UNSUPPORTED:
            print("Register module is not supported on this chip type")
        else:
            print("Failed in register iter get: rc = " + str(rc))
        example_exit(rc)

    reg_cnt = uint32_t_p_value(reg_cnt_p)
    if reg_cnt == 0:
        print("No allocated registers")
        example_exit(rc)

    reg_list_p = new_sx_register_key_t_arr(reg_cnt)

    rc = sx_api_register_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, key, None, reg_list_p, reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed in register get: rc = " + str(rc))
        example_exit(rc)

    for i in range(reg_cnt):
        reg_key = sx_register_key_t_arr_getitem(reg_list_p, i)
        print_reg_ext_point_list(reg_key)
else:
    key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    key.key.gp_reg.reg_id = args.reg_id
    uint32_t_p_assign(reg_cnt_p, 1)
    reg_list_p = new_sx_register_key_t_arr(1)

    rc = sx_api_register_iter_get(handle, SX_ACCESS_CMD_GET, key, None, reg_list_p, reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        if rc == SX_STATUS_UNSUPPORTED:
            print("Register module is not supported on this chip type")
        else:
            print("Failed in register iter get: rc = " + str(rc))
        example_exit(rc)

    reg_cnt = uint32_t_p_value(reg_cnt_p)
    if reg_cnt == 0:
        print("%s ID %d is not allocated" % (reg_type_dict[key.type], reg_id_reg(key)))
    else:
        print_reg_ext_point_list(key)

if args.deinit:
    rc = sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_flex_module_level,
                                                    orig_flex_api_level)
    if rc != SX_STATUS_SUCCESS:
        print("fail to set FLEX PARSER API log verbosity level. rc=%d", rc)
        example_exit(rc)

    rc = sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_reg_module_level,
                                                 orig_reg_api_level)
    if rc != SX_STATUS_SUCCESS:
        print("fail to set Regsiter API log verbosity level. rc=%d", rc)
        example_exit(rc)

sx_api_close(handle)

example_exit(rc)
