#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''

import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################

cmd_dict = {
    "ADD": SX_ACCESS_CMD_ADD,
    "SET": SX_ACCESS_CMD_SET,
    "DELETE": SX_ACCESS_CMD_DELETE,
    "DELETE_ALL": SX_ACCESS_CMD_DELETE_ALL,
    "add": SX_ACCESS_CMD_ADD,
    "set": SX_ACCESS_CMD_SET,
    "delete": SX_ACCESS_CMD_DELETE,
    "delete_all": SX_ACCESS_CMD_DELETE_ALL,
    "1": SX_ACCESS_CMD_ADD,
    "15": SX_ACCESS_CMD_SET,
    "3": SX_ACCESS_CMD_DELETE,
    "4": SX_ACCESS_CMD_DELETE_ALL,
}


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_isolation_bridge_set API\n-----------------------------------------')
    parser.add_argument('--cmd', type=str, choices=list(cmd_dict.keys()), default="SET",
                        help='Command: ADD|SET|DELETE|DELETE_ALL. if not inserted, script will use SET command')
    parser.add_argument('--egress_port', type=auto_int, default=0x10001, help='Insert egress port. if not inserted, script will use a default choice')
    parser.add_argument('--ingress_ports', type=auto_int, nargs='+', default=None, help='Insert ingress ports. if not inserted, script will use a default choice')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    if not args.force:
        print_modification_warning()

    return args.cmd, args.egress_port, args.ingress_ports, args.deinit


def main():
    cmd, egress_port, ingress_ports, deinit = parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM2]:
            print("Warning: The current example is supported only by Spectrum3 and above!")
            sys.exit(0)

        print_api_example_disclaimer()

        if not ingress_ports:
            ingress_ports = get_ports(handle, 3)
            if egress_port in ingress_ports:
                ingress_ports.remove(egress_port)

        print("---------------- Parameters --------------------")
        print("Cmd: %s (%d)" % (cmd, cmd_dict[cmd]))
        print("Egress port: 0x%x" % egress_port)
        if cmd_dict[cmd] != SX_ACCESS_CMD_DELETE_ALL:
            print("Ingress ports: %s" % [hex(port) for port in ingress_ports])
        print("------------------------------------------------")

        port_isolation_cfg_p = new_sx_port_isolation_cfg_t_p()
        if cmd_dict[cmd] != SX_ACCESS_CMD_DELETE_ALL:
            for i, port in enumerate(ingress_ports):
                sx_port_log_id_t_arr_setitem(port_isolation_cfg_p.log_port_list, i, port)
            port_isolation_cfg_p.log_port_cnt = len(ingress_ports)

        print("-----------------  Calling 'port_isolate_bridge_set' with the inserted parameters -----------------")
        rc = sx_api_port_isolate_bridge_set(handle, cmd_dict[cmd], egress_port, port_isolation_cfg_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_bridge_set failed. [%d]" % rc
        print("----------------------------------  port_isolate_bridge_set done  ----------------------------------")

        if deinit:
            rc = sx_api_port_isolate_bridge_set(handle, SX_ACCESS_CMD_DELETE_ALL, egress_port, port_isolation_cfg_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_bridge_set failed. [%d]" % rc

        print("Done, rc = %d." % (rc))

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
