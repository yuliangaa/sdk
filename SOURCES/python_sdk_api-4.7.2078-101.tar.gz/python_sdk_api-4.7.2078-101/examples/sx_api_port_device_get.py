#!/usr/bin/env python
'''
This file contains Python command example for the FDB module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of rate for 8x lanes port.
logic of the example is the following:
- Reset port API type usage
- Get the current port mapping configurations
- Reset port API type usage
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import sxd_api_chip_type_rev_get as sxd_api_chip_type

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

######################################################
parser = argparse.ArgumentParser(description='Call to sx_api_port_device_get',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--swid', default=0, type=int, help='SWID')
args = parser.parse_args()
print(("sx_api_port_device_get. Swid: %d " % (args.swid)))


######################################################
def main():

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Get ports count
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    port_attributes_list_p = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_get(handle, DEVICE_ID, args.swid, port_attributes_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)
    print(("Swid: %d Port count:%d" % (args.swid, port_cnt)))

    # Get ports
    port_attributes_list_p = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, DEVICE_ID, args.swid, port_attributes_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)

    for i in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list_p, i)
        print(("[%d] 0x%X Mode:%d Local:%d " %
               (i, port_attributes.log_port, port_attributes.port_mode, port_attributes.port_mapping.local_port)))

    print("Success.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
