#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility retrieves the split information of a given label port.
'''
import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api

INVALID_SLOT_ID = 99


def mgmt_phy_mod_split_info_query(handle, slot_id, module_id, split_num, port_width):
    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = slot_id
    module_info.module_id = module_id
    continue_check_splits = True
    original_split_num = split_num

    split_params = sx_mgmt_phy_module_split_params_t()
    split_params.split_num = split_num
    split_params.port_width = port_width

    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
    module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
    split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)

    try:
        while continue_check_splits:
            rc = sx_mgmt_phy_module_split_get(handle, module_info_p, split_params_p, split_info_p)
            assert SX_STATUS_SUCCESS == rc, "mgmt_phy_mod_split_info_query failed."
            split_info = sx_mgmt_phy_module_split_info_t_p_value(split_info_p)
            if split_info.list_len > 0:
                continue_check_splits = False
                if original_split_num != split_num:
                    print("Split/unsplit to [%u] is not possible max allowed is [%u]\n" % (original_split_num, split_num))
                for i in range(split_info.list_len):
                    attr = sx_port_attributes_t_arr_getitem(split_info_p.port_attribs_list, i)
                    print("log_port:%s | local_port:%d | slot:%d | module:%d | lane:%4s | width:%d" % (hex(attr.log_port),
                                                                                                       attr.port_mapping.local_port, attr.port_mapping.slot, attr.port_mapping.module_port,
                                                                                                       hex(attr.port_mapping.lane_bmap), attr.port_mapping.width))
            else:
                if split_num > 1:
                    split_num = int(split_num / 2)
                    if split_num == 1:
                        continue_check_splits = False
                        print("Split/unsplit is not possible, number of ports exceed the module width or ports combination is not allowed")
                        print("\n")
                    else:
                        delete_sx_mgmt_module_id_info_t_p(module_info_p)
                        delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
                        delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)
                        split_params.split_num = split_num
                        split_params.port_width = port_width
                        module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
                        split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
                        split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)
                else:
                    print("Split/unsplit is not possible, number of ports exceed the module width or ports combination is not allowed")
                    print("\n")

    finally:
        delete_sx_mgmt_module_id_info_t_p(module_info_p)
        delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
        delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)


def print_usage():
    print("Usage: sx_api_port_split_info_query.py --slot_id 0 --label_port 1 --num_splits 8 --port_width 1")
    print("Usage: sx_api_port_split_info_query.py --slot_id 0 --label_port 1 --num_splits 4 --port_width 2")
    print("\n")
    sys.exit(0)


def parse_example_attributes(chip_type):
    parser = argparse.ArgumentParser(description='Port Split Query Utility')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    parser.add_argument('--label_port', default=1, type=int, help="Label port")
    if chip_type == SX_CHIP_TYPE_SPECTRUM2 or chip_type == SX_CHIP_TYPE_SPECTRUM:
        parser.add_argument('--num_splits', type=int, choices=[1, 2, 4], help="Number of split")
        parser.add_argument('--port_width', type=int, choices=[1, 2, 4], help="width of each port")
        max_lanes = 4
    else:
        parser.add_argument('--num_splits', type=int, choices=[1, 2, 4, 8], help="Number of split")
        parser.add_argument('--port_width', type=int, choices=[1, 2, 4, 8], help="width of each port")
        max_lanes = 8

    args = parser.parse_args()

    print_api_example_disclaimer()

    if args.num_splits is None or args.port_width is None:
        print_usage()

    label_port_id = args.label_port
    slot_id = args.slot_id
    num_splits = int(args.num_splits)
    port_width = int(args.port_width)

    if (num_splits * port_width) > max_lanes:
        print("Number of splits and width of each port cannot take more than %d lanes" % (max_lanes))
        print_usage()

    return slot_id, label_port_id, num_splits, port_width


################################################
# Run the MAIN function
################################################
def main():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    chip_type = get_chip_type(handle, True)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    slot_id, label_port_id, num_splits, port_width = parse_example_attributes(chip_type)

    if slot_id == INVALID_SLOT_ID:
        slot_count = system_slot_count_get(handle)
        if slot_count > 0:
            slot_id = 1
        else:
            slot_id = 0

     # construct the port module map.
    ports_attributes_list = ports_attributes_get(handle)
    port_module_map, module_port_map = get_port_module_mapping(ports_attributes_list, len(ports_attributes_list))

    module_id = label_port_id - 1

    if (slot_id, module_id) not in module_port_map.keys():
        print("Error: Invalid port label")
        sx_api_close(handle)
        sys.exit(1)

    mgmt_phy_mod_split_info_query(handle, slot_id, module_id, num_splits, port_width)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
