#!/usr/bin/env python
"""
This file contains Python command example for the ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below configures the maximum possible number of UC routes with
resolved neighbors on VLAN RIFs.
Altogether the example configures:
    1. 1 Virtual router
    2. 2 router interfaces
    3. 2 local routes (1 per router interface)
    4. 8K neighbors (1 on the first RIF, and all the rest on the second)
    5. 90109 UC routes

"""
import sys
import socket
import struct
import time
from python_sdk_api.sx_api import *

rc, handle = sx_api_open(None)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

PORT1 = 0x1003D
PORT2 = 0x1001F
NEIGH_MAC_1 = ether_addr(0x7C, 0xFE, 0x90, 0x5D, 0x7B, 0x72)
NEIGH_MAC_2 = ether_addr(0x7C, 0xFE, 0x90, 0x80, 0xAA, 0xA0)
NUM_NEIGHS = 8192
NUM_UC_ROUTES = 125000
MAX_UC_ROUTES = 125100  # 88K

######################################################
#    functions
######################################################
# layer 2


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def set_port_state(log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))

    # router


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = addr
    ip_prefix.prefix.ipv4.mask.s_addr = mask
    return ip_prefix


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = addr
    return ip_addr


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    prefix = sx_ip_v6_prefix_t()
    ip_prefix.prefix = prefix
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


def make_sx_ip_addr_v6(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_vlan_router_interfaces = 16
    router_resource.max_port_router_interfaces = 16
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 0
    router_resource.min_ipv6_neighbor_entries = 0
    router_resource.min_ipv4_uc_route_entries = 0
    router_resource.min_ipv6_uc_route_entries = 0
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = NUM_NEIGHS
    router_resource.max_ipv6_neighbor_entries = NUM_NEIGHS
    router_resource.max_ipv4_uc_route_entries = MAX_UC_ROUTES
    router_resource.max_ipv6_uc_route_entries = MAX_UC_ROUTES
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parametrs.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def create_local_route_ipv6(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def set_rif_state_ipv6(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = False
    rif_state.ipv6_enable = True
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh_ipv4(rif, addr, mac_addr, iter=0):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add neigh to rif %d, rc = %d" % (iter, rif, rc)

    print("Iteration %d: Added neighbor to rif %d" % (iter, rif))


def add_neigh_ipv6(rif, addr, mac_addr, iter=0):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add neigh to rif %d, rc = %d" % (iter, rif, rc)

    print("Iteration %d: Added neighbor to rif %d" % (iter, rif))


def make_uc_route_data(next_hop_list, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for uc route with given parametrs.
        Action is optional, default action is forward.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = len(next_hop_list)
    for i, ipaddr in enumerate(next_hop_list):
        ip_addr = make_sx_ip_addr_v4(ipaddr)
        sx_ip_addr_t_arr_setitem(uc_route_data.next_hop_list_p, i, ip_addr)
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    return uc_route_data


def make_uc_route_data_ipv6(next_hop_list, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for uc route with given parametrs.
        Action is optional, default action is forward.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = len(next_hop_list)
    for i, ipaddr in enumerate(next_hop_list):
        ip_addr = make_sx_ip_addr_v6(ipaddr)
        sx_ip_addr_t_arr_setitem(uc_route_data.next_hop_list_p, i, ip_addr)
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    return uc_route_data


def add_uc_route_next_hop(vrid, addr, mask, next_hop_list, iter=0):
    " This function adds uc route with given parameters. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_uc_route_data(next_hop_list)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add uc route, rc: %d" % (iter, rc)

    print("Iteration %d: Added uc route" % (iter))


def add_uc_route_next_hop_ipv6(vrid, addr, mask, next_hop_list, iter=0):
    " This function adds uc route with given parameters. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_uc_route_data_ipv6(next_hop_list)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    retries = 0
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    while ((rc == 5) and (retries < 200)):
        print("Iteration %d: Received rc %d, retries = %d, sleeping and retrying..." % (iter, rc, retries))
        time.sleep(0.1)
        rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
        retries += 1

    assert SX_STATUS_SUCCESS == rc, "Iteration %d: Failed to add uc route, rc: %d" % (iter, rc)

    print("Iteration %d: Added uc route" % (iter))


def make_ecmp_next_hop(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates ecmp_next_hop struct with given parametrs.
        action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates ecmp uc_route_data struct with given parametrs.
        action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = 0
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def delete_neigh(rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_all_next_hops_per_vrid(vrid):
    " This function deletes all next hops from given vrid. "

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_next_hops_per_vrid_ipv6(vrid):
    " This function deletes all next hops from given vrid. "
    prefix = sx_ip_prefix_t()
    prefix.version = SX_IP_VERSION_IPV6
    prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(prefix_p, prefix)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_neigh_per_rif(rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_neigh_per_rif_ipv6(rif):
    " This function deletes all neighbors from given rif. "
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    ip_addr_p = new_sx_ip_addr_t_p()
    sx_ip_addr_t_p_assign(ip_addr_p, ip_addr)

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, ip_addr_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_local_routes(vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_local_routes_ipv6(vrid):
    " This function deletes all local uc routes from given vrid. "
    prefix = sx_ip_prefix_t()
    prefix.version = SX_IP_VERSION_IPV6
    prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(prefix_p, prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def add_pvid_to_port(vlan_id, port):
    pvid = vlan_id
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, port, vlan_id)
    print(("Set pvid %d for port 0x%x rc %d " % (vlan_id, port, rc)))


def example_vlan_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_UNTAGGED_MEMBER})  # SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT2: SX_UNTAGGED_MEMBER})  # SX_TAGGED_MEMBER})

    add_pvid_to_port(4, PORT1)
    add_pvid_to_port(5, PORT2)

    # create vlan rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_vlan_rif(vrid, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr


def example_vlan_rif_deinit(vrid, rif_arr):
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})


def router_scale_flow(vrid, rif_arr):
    # add local routes
    prefix_addr = [0] * 16
    prefix_mask = [0] * 16
    prefix_addr[3] = 0x20

    for i in range(0, 8):
        prefix_mask[i] = 0xff

    prefix_addr[4] = 0x11
    create_local_route_ipv6(vrid, rif_arr[0], prefix_addr, prefix_mask)

    prefix_addr[4] = 0x22
    create_local_route_ipv6(vrid, rif_arr[1], prefix_addr, prefix_mask)

    # rif state ipv4
    set_rif_state_ipv6(rif_arr[0], True)
    set_rif_state_ipv6(rif_arr[1], True)

    # resolve neighbors
    addr = [0] * 16
    addr[3] = 0x20
    addr[4] = 0x11
    addr[12] = 0x11
    add_neigh_ipv6(rif_arr[0], addr, NEIGH_MAC_1)

    addr[4] = 0x22
    addr[12] = 0x22
    add_neigh_ipv6(rif_arr[1], addr, NEIGH_MAC_2)
    # for i in xrange(0, 32):
    #    for j in xrange(0, 256):
    #        if (((256 * i) + j) == NUM_NEIGHS - 1):
    #            break
    #        add_neigh_ipv6(rif_arr[1], addr, NEIGH_MAC_2, (256 * i) + j);
    #        if (j == 255):
    #            addr[12] = 0x0
    #        else:
    #            addr[12] += 1
    #    addr[8] += 1

    #print("Added %d neighs in total" % (NUM_NEIGHS))

    # add uc route next_hop
    prefix_addr[0] = 0xAA
    prefix_addr[4] = 0x0
    for i in range(0, NUM_UC_ROUTES):
        add_uc_route_next_hop_ipv6(vrid, prefix_addr, prefix_mask, [addr], i)
        # if ((i % (NUM_NEIGHS - 1)) == 0):
        #    addr = 0x16200002 #22.32.0.2
        # else:
        #    addr += 1
        if ((i % 65536) == 0):
            prefix_addr[6] += 1
            prefix_addr[5] = 0x0
            prefix_addr[4] = 0x0
        elif ((i % 256) == 0):
            prefix_addr[5] += 1
            prefix_addr[4] = 0x0
        else:
            prefix_addr[4] += 1
    print(("Added %d next-hop routes in total" % (NUM_UC_ROUTES)))

    ##################################################################
    # Traffic 192.166.1.2 <--> <Remote destination IP> (via next hop)
    ##################################################################

#   #delete all next hop uc routes
#   delete_all_next_hops_per_vrid_ipv6(vrid)
#
#   #delete all neighbors per rif
#   delete_all_neigh_per_rif_ipv6(rif_arr[0])
#   delete_all_neigh_per_rif_ipv6(rif_arr[1])
#
#   #delete all local routes
#   delete_all_local_routes_ipv6(vrid)
#
#   #delete rif
#   delete_rif(vrid, rif_arr[0])
#   delete_rif(vrid, rif_arr[1])


def main():

    # init router
    router_init()
    vrid = create_vrid()

    # router scale with vlan rif example
    rif_arr = example_vlan_rif_init(vrid)
    counter1 = create_router_counter()
    counter2 = create_router_counter()
    print("counter1 = %d" % counter1)
    print("counter2 = %d" % counter2)
    bind_router_counter(counter1, rif_arr[0])
    bind_router_counter(counter2, rif_arr[1])
    router_scale_flow(vrid, rif_arr)
#   example_vlan_rif_deinit(vrid, rif_arr)
#
#   #delete vrid
#   delete_vrid(vrid)
#
#   #deinit router
#   router_deinit()


if __name__ == "__main__":
    main()
