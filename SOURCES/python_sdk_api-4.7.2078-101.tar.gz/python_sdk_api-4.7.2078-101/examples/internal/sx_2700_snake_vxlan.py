#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-

import os
import sys
import random
import errno
import sys
import struct
import socket
import colorsys
from python_sdk_api.sx_api import *
#from sx_tunnel_error_flows import *
from optparse import OptionParser, Option

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0
# VPORT
PORT17 = 0x10001
# PORT OF VLAN RIF
PORT18 = 0x10003
PORT15 = 0x10021
PORT16 = 0x10023

PORT19 = 0x10005
PORT20 = 0x10007

PORT1 = 0x1003d


PORT = [0, 0x1003d, 0x1003f, 0x10039, 0x1003b, 0x10035, 0x10037, 0x10031, 0x10033, 0x1002d, 0x1002f, 0x10029, 0x1002b,
        0x10025, 0x10027, 0x10021, 0x10023, 0x10001, 0x10003, 0x10005, 0x10007, 0x10009, 0x1000b, 0x1000d, 0x1000f,
        0x10011, 0x10013, 0x10015, 0x10017, 0x10019, 0x1001b, 0x1001d, 0x1001f]


MAX_RIF_NUM = 400

# dest mac of packet sent from port 1
mac_a = ether_addr("7C:FE:90:80:AA:A0")

# dest mac of packet sent from port 32
mac_b = ether_addr("7C:FE:90:5D:7B:72")

# mac of port_rifs1[2]
mac_c = ether_addr("7c:fe:90:04:05:06")
# mac of port_rifs1[3]
mac_d = ether_addr("7c:fe:90:04:05:07")

""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


""" ############################################################################################ """


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 123
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.mc_ecmp_enabled = False
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


""" ############################################################################################ """


def make_tunnel_attributes_vxlan(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_ttl = 255
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.encap.underlay_dport = 0
    tunnel_attribute.attributes.vxlan.nve_log_port = 0x0080010000

    return tunnel_attribute


""" ############################################################################################ """


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return rc, tunnel_id


""" ############################################################################################ """


def tunnel_destroy(tunnel_id_p):
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    return rc

###################################################################
# Router related functions
###################################################################


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_vlan_router_interfaces = 16
    router_resource.max_port_router_interfaces = 16
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vport_rif(vrid, log_vport, mac_addr, mtu=9300):
    " This function creates vport rif with given parametrs. "
    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VPORT
    ifc_param.ifc.vport.vport = log_vport

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vport rif: %d, rc: %d " % (rif, rc))

    return rif


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


""" ############################################################################################ """


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def create_ip_route(vrid, addr, mask, next_hop):
    " This function creates next hop with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD
    uc_route_data.next_hop_cnt = 1
    ip_addr = make_sx_ip_addr_v4(next_hop)
    sx_ip_addr_t_arr_setitem(uc_route_data.next_hop_list_p, 0, ip_addr)

    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ip route"

    print("Created ip route for vrid %d, rc: %d " % (vrid, rc))


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "
    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


# Flex ACL
def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def key_create():
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_DMAC)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def group_create(acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

    group_id = sx_acl_id_t_p_value(group_id_p)
    print("Created group %d, rc: %d" % (group_id, rc))
    for i in range(0, acls_num):
        print("acl id = %d " % sx_acl_id_t_arr_getitem(acl_id_arr, i))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def rule_set(region_id, offset, access, old_mac, new_mac):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 10, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_DMAC
    key_desc.key.dmac = old_mac
    key_desc.mask.dmac = ether_addr(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)

    #rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_SET_DST_MAC
    action.fields.action_set_dst_mac.mac = new_mac

    #rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action)
    rule.action_count = 1

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(1)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    if access == SX_ACCESS_CMD_SET:
        print("Added rule offset  %d, to region %d,  rc: %d" % (offset, region_id, rc))
    else:
        print("Deleted rule offset  %d, region %d,  rc: %d" % (offset, region_id, rc))

    # delete_sx_flex_acl_key_desc_t_arr(rule.key_desc_list_p)
    # delete_sx_flex_acl_flex_action_t_arr(rule.action_list_p)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)

# tunnel map


def tunnel_map_entry_add(tunnel_id, vni, bridge_id):
    map_entry = make_tunnel_map_entry_params(vni, bridge_id)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)


def make_tunnel_map_entry_params(vni, bridge_id):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = SX_TUNNEL_TYPE_NVE_VXLAN
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni

    return map_entry


######################################################
#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parametrs.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def create_ip2me_route(vrid, rif, addr, mask="255.255.255.255"):
    " This function creates ip2me route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    check_sdk_rc(rc)

    print("Created ip2me route for rif %d, rc: %d " % (rif, rc))


""" ############################################################################################ """


def make_decap_key(key_type, vrid, dip, sip, tunnel_type):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4(dip)
    decap_key.underlay_sip = make_sx_ip_addr_v4(sip)

    return decap_key


""" ############################################################################################ """


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data


""" ############################################################################################ """


def tunnel_decap_rule_create(decap_key_p, decap_data_p):
    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set(create)  [rc = %d] " % (rc)))
    #assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)
    return rc


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    return tunnel_init(general_param_p)


""" ############################################################################################ """


def example_vxlan_tunnel_create_flow(vrid, ip):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4(ip)  # need to change to valid ip and to correctly add to the struct
    #tunnel_attribute = make_tunnel_attributes_vxlan(vrid ,underlay_sip)
    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, SX_TUNNEL_DIRECTION_SYMMETRIC)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)


""" ############################################################################################ """


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    return tunnel_destroy(tunnel_id_p)


def bridge_vport_create_example(vlan, port1):
    # create a vport for port 0x10001 and vlan 20
    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, port1, vlan, log_vport_p_1)
    log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtula port 0x%x created" % (log_vport_1)))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge %d created" % (bridge_id)))

    # add log_vport_1 to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
    print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))

    # set port state to UP
    port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan, {PORT1: SX_UNTAGGED_MEMBER})

    return bridge_id


def bridge_vport_add(bridge_id, vlan, port, log_vport):
    # add log_vport to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    print(("virtual port 0x%x added to bridge %d " % (log_vport, bridge_id)))

    # set port state to UP
    port_state_set(log_vport, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan, {port: SX_UNTAGGED_MEMBER})
    #add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})


def example_nve_decap_rules_flow(vrid, tunnel_id, dip, sip):

    c = create_flow_counter()
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, c)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, dip, sip, SX_TUNNEL_TYPE_NVE_VXLAN)
    #decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, dip, sip, SX_TUNNEL_TYPE_NVE_VXLAN)
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    print("create VXLAN decap rule, ul vrid: %d, flow counter: %d" % (vrid, c))
    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vxlan decap rule , rc: %d" % (rc)


def example_fdb_uc_set(bridge_id, log_port, mac):
    # add static fdb
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
#    mac_addr = ether_addr(mac)

    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac

    mac_entry.fid_vid = bridge_id
    mac_entry.log_port = log_port
    mac_entry.entry_type = SX_FDB_UC_STATIC
    mac_entry.action = SX_FDB_ACTION_FORWARD
    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT

    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)

    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))


def example_fdb_uc_tunnel_set(bridge_id, tunnel_id, dip, mac):
    # add static fdb
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    #mac_addr = ether_addr(mac)

    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac

    mac_entry.fid_vid = bridge_id
    #mac_entry.log_port = log_vport
    mac_entry.entry_type = SX_FDB_UC_STATIC
    mac_entry.action = SX_FDB_ACTION_FORWARD
    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP

    mac_entry.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4(dip)
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_addr
    mac_entry.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD

    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)

    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # enable router interface and create route for encapsulated packet
    #create_local_route(vrid, port_rif,addr,"255.255.255.0")
    #add_neigh(port_rif, dip, ether_addr(mac))


def example_mc_container_create():
    # add mc container for flood
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    mcc_attr = sx_mc_container_attributes_t()
    mcc_attr.type = SX_MC_CONTAINER_TYPE_NVE_FLOOD
    mcc_attr.min_mtu = 100
    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mcc_attr)

    container_id_p = new_sx_mc_container_id_t_p()
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, container_id_p, None, 0, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(container_id_p)
    print(("sx_api_mc_container_set id %x created, rc: %d " % (mc_container_id, rc)))

    return mc_container_id


def example_mc_container_add(mc_container_id, tunnel_id, dip):
    # add mc container for flood
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    mcc_attr = sx_mc_container_attributes_t()
    mcc_attr.type = SX_MC_CONTAINER_TYPE_NVE_FLOOD
    mcc_attr.min_mtu = 100
    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mcc_attr)

    next_hop_list = new_sx_mc_next_hop_t_arr(2)
    next_hop = sx_mc_next_hop_t()
    next_hop.type = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4(dip)
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 0, next_hop)

    count = 1
    container_id_p = new_sx_mc_container_id_t_p()
    sx_mc_container_id_t_p_assign(container_id_p, mc_container_id)
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_ADD, container_id_p, next_hop_list, count, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(container_id_p)
    print(("sx_api_mc_container_set id %x created with %d entries, rc: %d " % (mc_container_id, count, rc)))

    return mc_container_id


def example_acl_add():
    direction = 0

    key_handle = key_create()

    region_id = region_create(key_handle, 60)

    acl_id = acl_create(region_id, direction)

    #acl_id_arr = new_sx_acl_id_t_arr(5)
    #sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)

    #group_id = group_create(acl_id_arr, 1, 0)

    # the rule hard coded now with action discard

    rule_set(region_id, 0, SX_ACCESS_CMD_SET, mac_b, mac_d)
    rule_set(region_id, 1, SX_ACCESS_CMD_SET, mac_a, mac_c)

    #rc = sx_api_acl_group_bind_set(handle,SX_ACCESS_CMD_BIND, group_list[0], group_list[1]);
    #assert SX_STATUS_SUCCESS == rc, "Failed to bind between groups"
    # print "group %d bound to group %d  rc: %d" %(group_list[0], group_list[1],  rc)
    # bind port to existing group
    for i in range(1, 33):
        rc = sx_api_acl_port_bind_set(handle, SX_ACCESS_CMD_BIND, PORT[i], acl_id)
        print("port 0x%x bound to acl_id %d  rc: %d" % (PORT[i], acl_id, rc))

#####################################################
#    main
######################################################


def main():
    router_init()
    print("init")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    port_arr = [None] * 32
    port_arr[0] = 0x1003D
    port_arr[1] = 0x1003F
    port_arr[2] = 0x10039
    port_arr[3] = 0x1003B
    port_arr[4] = 0x10035
    port_arr[5] = 0x10037
    port_arr[6] = 0x10031
    port_arr[7] = 0x10033
    port_arr[8] = 0x1002d
    port_arr[9] = 0x1002f
    port_arr[10] = 0x10029
    port_arr[11] = 0x1002b
    port_arr[12] = 0x10025
    port_arr[13] = 0x10027
    port_arr[14] = 0x10021
    port_arr[15] = 0x10023
    port_arr[16] = 0x10001
    port_arr[17] = 0x10003
    port_arr[18] = 0x10005
    port_arr[19] = 0x10007
    port_arr[20] = 0x10009
    port_arr[21] = 0x1000b
    port_arr[22] = 0x1000d
    port_arr[23] = 0x1000f
    port_arr[24] = 0x10011
    port_arr[25] = 0x10013
    port_arr[26] = 0x10015
    port_arr[27] = 0x10017
    port_arr[28] = 0x10019
    port_arr[29] = 0x1001b
    port_arr[30] = 0x1001d
    port_arr[31] = 0x1001f

    # set mtu
    for i in range(0, 32):
        rc = sx_api_port_mtu_set(handle, port_arr[i], 9300)
        print("MTU set for port %d, rc: %d" % (port_arr[i], rc))

    bridge_ids = []
    # rif on vport of vlan 1
    port_rifs1 = []
    # rif on vport of vlan 2
    port_rifs2 = []
    # vport of vlan 1
    log_vports1 = []
    # vport of vlan 2
    log_vports2 = []
    for i in range(33):
        bridge_ids.append(0)
        port_rifs1.append(0)
        port_rifs2.append(0)
        log_vports1.append(0)
        log_vports2.append(0)

    # create underlay vrid
    vrid1 = create_vrid()
    vrid2 = create_vrid()

    # create tunnel
    rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid1, "1.1.1.1")
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    for i in range(1, 33):
        # create pvid
        rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, PORT[i], 1)
        # create vport on vlan 1 for each port
        log_vport_p = new_sx_port_log_id_t_p()
        vport_add_delete(SX_ACCESS_CMD_ADD, PORT[i], 1, log_vport_p)
        log_vports1[i] = sx_port_log_id_t_p_value(log_vport_p)
        print(("virtula port 0x%x created" % (log_vports1[i])))

        vport_add_delete(SX_ACCESS_CMD_ADD, PORT[i], 2, log_vport_p)
        log_vports2[i] = sx_port_log_id_t_p_value(log_vport_p)
        print(("virtula port 0x%x created" % (log_vports2[i])))

        sx_api_port_phys_loopback_set(handle, PORT[i], 0)

    for i in range(1, 33):
        #remove_ports_from_vlan(1, {PORT[i]: SX_TAGGED_MEMBER})
        #remove_ports_from_vlan(1, {PORT[i]: SX_UNTAGGED_MEMBER})
        log_vport_p = new_sx_port_log_id_t_p()
        # for non-tunnel port
        if (i % 4 == 1):
            # create bridge
            bridge_id_p = new_sx_bridge_id_t_p()
            bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
            bridge_ids[i] = sx_bridge_id_t_p_value(bridge_id_p)
            print(("bridge_ids[%d] %d created" % (i, bridge_ids[i])))
            # add vport to bridge
            bridge_vport_add(bridge_ids[i], 1, PORT[i], log_vports1[i])
            bridge_vport_add(bridge_ids[i], 1, PORT[i + 3], log_vports1[i + 3])

            tunnel_map_entry_add(tunnel_id, i, bridge_ids[i])

        # for tunnel port
        if (i % 4 == 2) or (i % 4 == 3):
            #remove_ports_from_vlan(1, {PORT[i]: SX_TAGGED_MEMBER})
            #remove_ports_from_vlan(2, {PORT[i]: SX_TAGGED_MEMBER})
            add_ports_to_vlan(1, {PORT[i]: SX_TAGGED_MEMBER})
            add_ports_to_vlan(2, {PORT[i]: SX_TAGGED_MEMBER})

            # create vport pn vlan 2 for tunnel port
            #vport_add_delete(SX_ACCESS_CMD_ADD, PORT[i], 2, log_vport_p)
            #log_vports2[i] = sx_port_log_id_t_p_value(log_vport_p)
            #print("virtula port 0x%x created" %(log_vports2[i]))

            if (i % 4 == 2):
                port_rifs1[i] = create_vport_rif(vrid1, log_vports1[i], mac_d)
                port_rifs2[i] = create_vport_rif(vrid2, log_vports2[i], mac_d)

                subnet = str(i) + '.' + str(i) + '.' + str(i) + '.0'
                create_local_route(vrid1, port_rifs1[i], subnet, "255.255.255.0")
                subnet = str(i) + '.' + str(i) + '.' + str(i + 1) + '.0'
                create_local_route(vrid2, port_rifs2[i], subnet, "255.255.255.0")
            if (i % 4 == 3):
                port_rifs1[i] = create_vport_rif(vrid2, log_vports1[i], mac_c)
                port_rifs2[i] = create_vport_rif(vrid1, log_vports2[i], mac_c)

                subnet = str(i) + '.' + str(i) + '.' + str(i) + '.0'
                create_local_route(vrid2, port_rifs1[i], subnet, "255.255.255.0")
                subnet = str(i) + '.' + str(i) + '.' + str(i + 1) + '.0'
                create_local_route(vrid1, port_rifs2[i], subnet, "255.255.255.0")

            port_state_set(log_vports1[i], SX_PORT_ADMIN_STATUS_UP)
            port_state_set(log_vports2[i], SX_PORT_ADMIN_STATUS_UP)
            set_rif_state_ipv4(port_rifs1[i])
            set_rif_state_ipv4(port_rifs2[i])
            c1 = create_router_counter()
            bind_router_counter(c1, port_rifs1[i])
            c2 = create_router_counter()
            bind_router_counter(c2, port_rifs2[i])

            if (i % 4 == 2):
                dip = str(i) + '.' + str(i) + '.' + str(i) + '.' + str(i)
                next_hop = str(i) + '.' + str(i) + '.' + str(i) + '.1'
                create_ip_route(vrid1, dip, "255.255.255.255", next_hop)
                add_neigh(port_rifs1[i], next_hop, mac_c)
            if (i % 4 == 3):
                dip = str(i) + '.' + str(i) + '.' + str(i + 1) + '.' + str(i)
                next_hop = str(i) + '.' + str(i) + '.' + str(i + 1) + '.1'
                create_ip_route(vrid1, dip, "255.255.255.255", next_hop)
                add_neigh(port_rifs2[i], next_hop, mac_d)

    # add acl
    example_acl_add()

    # fdb forward
    for i in range(1, 33):
        if (i % 4 == 1):
            example_fdb_uc_set(bridge_ids[i], PORT[i + 3], mac_a)
            example_fdb_uc_set(bridge_ids[i], PORT[i], mac_b)

            j = i + 1
            dip = str(j) + '.' + str(j) + '.' + str(j) + '.' + str(j)
            #mac = "00:01:03:04:05:" + str(j)
            mac = mac_c
            example_fdb_uc_tunnel_set(bridge_ids[i], tunnel_id, dip, mac_c)

            j = i + 2
            dip = str(j) + '.' + str(j) + '.' + str(j + 1) + '.' + str(j)
            #mac = "00:01:03:04:05:" + str(j)
            mac = mac_d
            example_fdb_uc_tunnel_set(bridge_ids[i], tunnel_id, dip, mac_d)

    # decap rules
    for i in range(1, 33):
        if (i % 4 == 2):
            dip = str(i) + '.' + str(i) + '.' + str(i) + '.' + str(i)
            example_nve_decap_rules_flow(vrid2, tunnel_id, dip, "1.1.1.1")
        if (i % 4 == 3):
            dip = str(i) + '.' + str(i) + '.' + str(i + 1) + '.' + str(i)
            example_nve_decap_rules_flow(vrid2, tunnel_id, dip, "1.1.1.1")

    exit(1)


if __name__ == "__main__":
    main()


""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
