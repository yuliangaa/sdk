#!/usr/bin/env python

import sys
import os
import time
import argparse
from test_infra_common import auto_int, SPECTRUM_SWID
from python_sdk_api.sxd_api import *
import sxd_api_chip_type_rev_get as sxd_api_chip_type

######################################################
#    Defines
######################################################
SWID = SPECTRUM_SWID
DEVICE_ID = 1

OP_GET = 0
OP_SET = 1

TYPE_GLOBAL_CONFIGURATION = 0
TYPE_PER_SECTION_CONFIGURATION = 1
TYPE_PER_REGISTER_CONFIGURATION = 2

FEATURE_DISABLE = 0
FEATURE_ENABLE = 1

ACTION_ENABLE_STUB = 0
ACTION_DISABLE_STUB = 1

######################################################
#    Handle input paramters
######################################################

parser = argparse.ArgumentParser(description='SXD-API MOFS example')
parser.add_argument('--op', default=OP_GET, type=int, help='Operation: 0 - GET operation, 1 - SET operation')
parser.add_argument('--type', default=TYPE_GLOBAL_CONFIGURATION, type=int, help='Configuration type: 0 - global, 1 - per section, 2 - per register')
parser.add_argument('--section_id', type=auto_int, help='Register Section ID: 8-bit MSB of the register ID. Relevant only if type==1 (per section configuration)')
parser.add_argument('--register_id', type=auto_int, help='Register ID. Relevant only if type==2 (per register configuration)')
parser.add_argument('--en', type=int, default=0, help='0 - disallow stubs, 1 - allow stubs. Relevant only if type==0 (global configuration). Default is set to 0.')
parser.add_argument('--action', type=int, help='0 - enable stub(s), 1 - disable stub(s). Relevant only if type==1 or type==2 (per section and per register configuration).')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

######################################################
#    Global variables
######################################################

meta = sxd_reg_meta_t()
meta.swid = SWID
meta.dev_id = DEVICE_ID

mofs = ku_mofs_reg()

op_to_sxd_access_cmd = {
    OP_GET: SXD_ACCESS_CMD_GET,
    OP_SET: SXD_ACCESS_CMD_SET
}
cmd_to_str = {
    SXD_ACCESS_CMD_GET: "GET",
    SXD_ACCESS_CMD_SET: "SET"
}
feature_to_str = {
    FEATURE_DISABLE: "Stub support is disabled",
    FEATURE_ENABLE: "Stub support is enabled"
}
reg_status_to_str = {
    ACTION_ENABLE_STUB: "Stub enabled",
    ACTION_DISABLE_STUB: "Stub disabled"
}

######################################################
#    Local functions
######################################################


def help_cmd():
    print("")
    print("The following example allow to modify default register stubs configuration in FW:")
    print("  sxd_api_mofs.py --op <op> --type <type> [--section_id <section_id>] [--register_id <register_id>] [--en <en>] [--action_action]")
    print("")
    print("op: 0 - GET operation, 1 - SET operation")
    print("type: 0 - global configuration, 1 - section configuration, 2 - register configuration")
    print("section_id: 8-bit MSB of the register ID, supported only if type==1")
    print("register_id: register ID, supported only if type==2")
    print("en: 0 - disallow stubs, 1 - allow stubs, supported only if type==2")
    print("action: 0 - enable stub(s), 1 - disable stub(s), supported only if type==1 or type==2")
    print("")
    print("Global configuration - disable/enable the feature:")
    print("to allow stub configuration:    sxd_api_mofs.py --op 1 --type 0 --en 1")
    print("to disallow stub configuration: sxd_api_mofs.py --op 1 --type 0 --en 0")
    print("to read global configuration:   sxd_api_mofs.py --op 0 --type 0")
    print("")
    print("Section configuration - enable/disable stubs for the given register section ID:")
    print("to enable stubs for the section:  sxd_api_mofs.py --op 1 --type 1 --section_id <section_id> --action 0")
    print("to disable stubs for the section: sxd_api_mofs.py --op 1 --type 1 --section_id <section_id> --action 1")
    print("NOTE: GET operation is not support for this type.")
    print("")
    print("Register configuration - enable/disable stub for the given register ID:")
    print("to enable stub for the register:     sxd_api_mofs.py --op 1 --type 2 --register_id <register_id> --action 0")
    print("to disable stub for the register:    sxd_api_mofs.py --op 1 --type 2 --register_id <register_id> --action 1")
    print("to read register stub configuration: sxd_api_mofs.py --op 0 --type 2 --register_id <register_id>")
    print("")
    sys.exit(0)


def validate_input_parameters(op, type, section_id, register_id, en, action):
    if op not in [OP_GET, OP_SET]:
        print("Invalid input parameter: op.")
        help_cmd()
        sys.exit(0)

    if type not in [TYPE_GLOBAL_CONFIGURATION, TYPE_PER_SECTION_CONFIGURATION, TYPE_PER_REGISTER_CONFIGURATION]:
        print("Invalid input parameter: type.")
        help_cmd()
        sys.exit(0)

    if op == OP_GET and type == TYPE_PER_SECTION_CONFIGURATION:
        print("Per section configuration doesn't support GET command.")
        help_cmd()
        sys.exit(0)

    if en is not None and type != TYPE_GLOBAL_CONFIGURATION:
        print("Provided type doesn't support --en option.")
        help_cmd()
        sys.exit(0)

    if section_id is not None and type != TYPE_PER_SECTION_CONFIGURATION:
        print("Provided type doesn't support --section_id option.")
        help_cmd()
        sys.exit(0)

    if register_id is not None and type != TYPE_PER_REGISTER_CONFIGURATION:
        print("Provided type doesn't support --register_id option.")
        help_cmd()
        sys.exit(0)

    if action is not None and type == TYPE_GLOBAL_CONFIGURATION:
        print("Provided type doesn't support --action option.")
        help_cmd()
        sys.exit(0)

    if type == TYPE_GLOBAL_CONFIGURATION and op == OP_SET:
        if en not in [FEATURE_DISABLE, FEATURE_ENABLE]:
            print("Invalid input parameter: en.")
            help_cmd()
            sys.exit(0)

    if type == TYPE_PER_SECTION_CONFIGURATION:
        if section_id < 0 or section_id > 0xFF:
            print("Invalid input parameter: section_id.")
            help_cmd()
            sys.exit(0)

        if op == OP_SET:
            if action not in [ACTION_ENABLE_STUB, ACTION_DISABLE_STUB]:
                print("Invalid input parameter: action.")
                help_cmd()
                sys.exit(0)

    if type == TYPE_PER_REGISTER_CONFIGURATION:
        if register_id < 0x2000 or register_id > 0xFFFF:
            print("Invalid input parameter: register_id.")
            help_cmd()
            sys.exit(0)

        if op == OP_SET:
            if register_id in [0x9020, 0x90f8]:
                print("Stub configuration for MGIR (0x9020) and for MOFS (0x90f8) can't be changed.")
                help_cmd()
                sys.exit(0)

            if action not in [ACTION_ENABLE_STUB, ACTION_DISABLE_STUB]:
                print("Invalid input parameter: action.")
                help_cmd()
                sys.exit(0)


def handle_mofs(cmd, type=TYPE_GLOBAL_CONFIGURATION, section_id=0, register_id=0, en=FEATURE_DISABLE, action=ACTION_ENABLE_STUB):
    meta.access_cmd = cmd

    mofs.type = type
    mofs.section_id = section_id
    mofs.register_id = register_id
    mofs.en = en
    mofs.action = action

    print("[+] Sending MOFS...")
    print("[+] handle_mofs(): cmd=%s, type=%d, section_id=%s, register_id=%s, en=%d, action=%d" %
          (cmd_to_str[cmd], type, hex(section_id), hex(register_id), en, action))
    rc = sxd_access_reg_mofs(mofs, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "MOFS request failed, rc: %d" % (rc)
    print("[+] MOFS request was handled successfully.")

    return mofs


def set_get_global_configuration(cmd, en_dis=FEATURE_DISABLE):
    if cmd == SXD_ACCESS_CMD_SET:
        mofs = handle_mofs(cmd, type=TYPE_GLOBAL_CONFIGURATION, en=en_dis)
    elif cmd == SXD_ACCESS_CMD_GET:
        mofs = handle_mofs(cmd, type=TYPE_GLOBAL_CONFIGURATION)

        print("====================================")
        print("= MOFS: Global configuration dump: =")
        print("====================================")
        print("[+] Global status: %d, %s" % (mofs.en, feature_to_str[mofs.en]))

    return mofs


def set_get_per_register_configuration(cmd, register_id, action):
    if cmd == SXD_ACCESS_CMD_SET:
        mofs = handle_mofs(cmd, type=TYPE_PER_REGISTER_CONFIGURATION, register_id=register_id, action=action)
    elif cmd == SXD_ACCESS_CMD_GET:
        mofs = handle_mofs(cmd, type=TYPE_PER_REGISTER_CONFIGURATION, register_id=register_id)

        print("======================================")
        print("= MOFS: Register configuration dump: =")
        print("======================================")
        print("[+] register_id:", hex(mofs.register_id))
        print("[+] reg_status: %d, %s" % (mofs.reg_status, reg_status_to_str[mofs.reg_status]))

    return mofs

######################################################
#    MOFS example
######################################################


def mofs_example():
    # check whether device type is supported by the test
    device_id, _ = sxd_api_chip_type.get_chip_type_and_rev()
    if device_id not in [SXD_MGIR_HW_DEV_ID_SPECTRUM4, SXD_MGIR_HW_DEV_ID_SPECTRUM5]:
        print("The following example is not supported by the device.")
        sys.exit(0)

    print("[+] SXD-API MOFS example start")

    print("[+] Initializing register access")
    sxd_access_reg_init(0, None, 4)

    args = parser.parse_args()

    op = args.op
    type = args.type
    section_id = args.section_id
    register_id = args.register_id
    en = args.en
    action = args.action

    validate_input_parameters(op, type, section_id, register_id, en, action)

    cmd = op_to_sxd_access_cmd[op]

    if type == TYPE_GLOBAL_CONFIGURATION:
        # save current data for later de-configuration
        original_data = set_get_global_configuration(SXD_ACCESS_CMD_GET, en)

        set_get_global_configuration(cmd, en)

    elif type == TYPE_PER_SECTION_CONFIGURATION:
        # save current data for later de-configuration
        original_data = handle_mofs(cmd=SXD_ACCESS_CMD_GET, type=TYPE_PER_SECTION_CONFIGURATION, section_id=section_id)

        handle_mofs(cmd=SXD_ACCESS_CMD_SET, type=TYPE_PER_SECTION_CONFIGURATION, section_id=section_id, action=action)

    elif type == TYPE_PER_REGISTER_CONFIGURATION:
        # save current data for later de-configuration
        original_data = set_get_per_register_configuration(SXD_ACCESS_CMD_GET, register_id, action)

        set_get_per_register_configuration(cmd, register_id, action)

    if args.deinit:
        meta.access_cmd = SXD_ACCESS_CMD_SET
        rc = sxd_access_reg_mofs(original_data, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "MOFS request failed, rc: %d" % (rc)

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)

    print("[+] SXD-API MOFS example end")


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    mofs_example()
