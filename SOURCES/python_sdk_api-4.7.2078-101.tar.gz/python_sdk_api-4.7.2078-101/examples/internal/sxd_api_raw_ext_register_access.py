#!/usr/bin/env python

import sys
import errno
import time
import os
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *


SXD_MAX_REGISTERS = 0x10000
SXD_REG_TLV_MAX_SIZE = 128

def parse_args():

    description_str = """ This is an example of sxd_access_reg_raw_ext() \n 
                          the example will verify api functionality by comparing the returned values from a GET/SET cmd """
    parser = argparse.ArgumentParser(description = description_str)
    parser.add_argument("--reg_id", default = "0x90F0", help = "register id to query raw data [Hexadecimal][0 : SXD_MAX_REGISTERS]")
    parser.add_argument("--size", default = 8, type = int, help = "number of register bytes to verify")
    return parser.parse_args()

def main():
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != 0):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)
    
    args = parse_args()   
    reg_id = int(args.reg_id, base=16)
    size = args.size
    if (reg_id >= SXD_MAX_REGISTERS):
        print(" Invalid reg_id ")
        sys.exit(errno.EACCES)
    if (size > SXD_REG_TLV_MAX_SIZE):
        size = SXD_REG_TLV_MAX_SIZE  
        
    raw_reg_ext_cmp1 = ku_raw_reg_ext()
    raw_reg_ext_cmp2 = ku_raw_reg_ext()
    reg_meta = sxd_reg_meta_t()
    
    reg_meta.dev_id = 1
    reg_meta.swid = 0
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET
    
    raw_reg_ext_cmp1.raw_reg.size = size
    raw_reg_ext_cmp1.raw_reg.buff = new_uint8_t_arr(raw_reg_ext_cmp1.raw_reg.size)
    
    print("calling sxd_access_reg_raw_ext() to query reg_id = 0x%x [raw_reg_ext_cmp1]" %(reg_id))
    rc = sxd_access_reg_raw_ext(raw_reg_ext_cmp1, reg_meta, 1, reg_id, None, None)
    
    print("raw_reg_ext_cmp1 GET Output parameter: ")
    print("raw_reg_ext_cmp1: rc = %d" % (rc))
    print("raw_reg_ext_cmp1: fw_cache_read_time %d" % (raw_reg_ext_cmp1.fw_cache_read_time))
    print("raw_reg_ext_cmp1: fw_emad_latency %d" % (raw_reg_ext_cmp1.fw_emad_latency))
    
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET
    
    print("calling sxd_access_reg_raw_ext() to set reg_id = 0x%x [raw_reg_ext_cmp1]" %(reg_id)) 
    rc = sxd_access_reg_raw_ext(raw_reg_ext_cmp1, reg_meta, 1, reg_id, None, None)
    
    raw_reg_ext_cmp2.raw_reg.size = size
    raw_reg_ext_cmp2.raw_reg.buff = new_uint8_t_arr(raw_reg_ext_cmp2.raw_reg.size)
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET
    
    print("calling sxd_access_reg_raw_ext() to query reg_id = 0x%x [raw_reg_ext_cmp2]" %(reg_id))
    rc = sxd_access_reg_raw_ext(raw_reg_ext_cmp2, reg_meta, 1, reg_id, None, None)
    
    print("raw_reg_ext_cmp2 GET Output parameter: ")
    print("raw_reg_ext_cmp2: rc = %d" % (rc))
    print("raw_reg_ext_cmp2: size %d" % (raw_reg_ext_cmp1.raw_reg.size))
    print("raw_reg_ext_cmp2: fw_cache_read_time %d" % (raw_reg_ext_cmp2.fw_cache_read_time))
    print("raw_reg_ext_cmp2: fw_emad_latency %d" % (raw_reg_ext_cmp2.fw_emad_latency))
    
    print("compare raw_reg_ext_cmp1, raw_reg_ext_cmp2 raw data output")
    for i in range(0, raw_reg_ext_cmp2.raw_reg.size):
        cmp_1 = uint8_t_arr_getitem(raw_reg_ext_cmp1.raw_reg.buff, i)
        cmp_2 = uint8_t_arr_getitem(raw_reg_ext_cmp2.raw_reg.buff, i)
        if (cmp_1 != cmp_2):
            print("****************************************************")
            print("Failed on %d byte Get/Set operation comparison" % (i))
            print("****************************************************")
            sys.exit(errno.EACCES)   
    
if __name__ == "__main__":
    main()
    
