#!/usr/bin/env python
'''
This file contains a Python commands example for the FDB module.

Python commands syntax is very similar to the Switch SDK APIs.

You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

\section cases Example Flow

The example below performs the following configuration operations:

1. boot in ISSU_FAST/ISSU_NORMAL mode.

2. Sets FDB port uc dynamic ageable records according to "number_of_fdb_uc_entries".

3. Get all dynamic ageable entries pre ISSU

4. initiate sw update process.

5. Gets all recovered dynamic entries and compare to the configured pre-ISSU.
'''

import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from collections import namedtuple
import os
import argparse
import subprocess
import re
LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)
from test_infra_common import *    

MAX_FDB_API_ENTRIES = 12 * 1024
FdbEntry = namedtuple('FdbEntry', 'mac fid log_port')


def parse_args():
    parser = argparse.ArgumentParser(description='ISSU example')
    parser.add_argument('--num_records', default=MAX_FDB_API_ENTRIES, type=int, help='number of dynamic ageable fdb to configure')
    args = parser.parse_args()
    return args


def execute_command(cmd):
    rc = os.system(cmd)
    assert rc == SX_STATUS_SUCCESS, '%s failed, rc = %d' % (cmd, rc)


def get_and_check_all_uc_ageable_fdb_entries(handle, expected_entries):

    fdb_entries = []
    mac_entry_arr = new_sx_fdb_uc_mac_addr_params_t_arr(SX_FDB_MAX_GET_ENTRIES)
    key_filter = sx_fdb_uc_key_filter_t()
    key_filter_p = copy_sx_fdb_uc_key_filter_t_p(key_filter)
    key = sx_fdb_uc_mac_addr_params_t()
    key_p = copy_sx_fdb_uc_mac_addr_params_t_p(key)
    data_cnt_p = copy_uint32_t_p(0)
    data_cnt = SX_FDB_MAX_GET_ENTRIES
    uint32_t_p_assign(data_cnt_p, data_cnt)
    total_cnt = 0

    try:
        # Get first entries
        rc = sx_api_fdb_uc_mac_addr_get(handle, 0, SX_ACCESS_CMD_GET_FIRST,
                                        SX_FDB_UC_AGEABLE, key_p, key_filter_p, mac_entry_arr, data_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_get failed with rc=%d" % rc
        data_cnt = uint32_t_p_value(data_cnt_p)
        total_cnt += data_cnt
        for i in range(data_cnt):
            mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, i)
            fdb_entries.append(
                FdbEntry(mac=mac_entry.mac_addr.to_str(), fid=mac_entry.fid_vid, log_port=mac_entry.log_port))

        # Get next entries
        while data_cnt == SX_FDB_MAX_GET_ENTRIES:
            last_mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, data_cnt - 1)
            key_p.fid_vid = last_mac_entry.fid_vid
            key_p.mac_addr = last_mac_entry.mac_addr
            rc = sx_api_fdb_uc_mac_addr_get(handle, 0, SX_ACCESS_CMD_GETNEXT,
                                            SX_FDB_UC_AGEABLE, key_p, key_filter_p, mac_entry_arr, data_cnt_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_get failed with rc=%d" % rc
            data_cnt = uint32_t_p_value(data_cnt_p)
            total_cnt += data_cnt
            for i in range(data_cnt):
                mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, i)
                fdb_entries.append(
                    FdbEntry(mac=mac_entry.mac_addr.to_str(), fid=mac_entry.fid_vid, log_port=mac_entry.log_port))

        # Compare with expected
        print(("sx_api_fdb_uc_mac_addr_get: %d enties, rc: %d " % (total_cnt, rc)))
        if not (set(expected_entries) == set(fdb_entries)):
            print('expected_entries = %s' % expected_entries)
            print('fdb_entries = %s' % fdb_entries)
            assert 0
    finally:
        delete_uint32_t_p(data_cnt_p)
        delete_sx_fdb_uc_key_filter_t_p(key_filter_p)
        delete_sx_fdb_uc_mac_addr_params_t_p(key_p)
        delete_sx_fdb_uc_mac_addr_params_t_arr(mac_entry_arr)


def prepare_type_port_uc_fdb_records(number_of_fdb_uc_entries, mac_list, fid_list, ports_list):

    # prepare dynamic agable records
    array = new_sx_fdb_uc_mac_addr_params_t_arr(number_of_fdb_uc_entries)
    for index in range(number_of_fdb_uc_entries):
        mac_entry_1 = sx_fdb_uc_mac_addr_params_t()
        mac_entry_1.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT
        mac_entry_1.mac_addr = ether_addr(mac_list[index])
        mac_entry_1.fid_vid = fid_list[index]
        mac_entry_1.log_port = ports_list[index]
        mac_entry_1.entry_type = SX_FDB_UC_AGEABLE
        mac_entry_1.action = SX_FDB_ACTION_FORWARD
        sx_fdb_uc_mac_addr_params_t_arr_setitem(array, index, mac_entry_1)

    return array


def dec_to_mac(dec):
    mac_str = format(dec, 'x')
    num_add_zero = 12 - len(mac_str)
    for _ in range(num_add_zero):
        mac_str = '0' + mac_str
    blocks = [mac_str[x:x + 2] for x in range(0, len(mac_str), 2)]
    mac_formatted = ':'.join(blocks)
    return mac_formatted


def create_mac_address_list(init_mac_add, number_of_addresses):
    mac_addr_list = []
    for i in range(number_of_addresses):
        mac_addr = dec_to_mac(int(init_mac_add.replace(':', ''), 16) + i)
        mac_addr_list.append(mac_addr)

    return mac_addr_list


def create_fdb(handle, number_of_entries):

    try:
        print(("Setting aging timer to max : %d sec" % (SX_FDB_AGE_TIME_MAX)))

        rc = sx_api_fdb_age_time_set(handle, 0, SXD_FDB_AGE_TIME_MAX)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_age_time_set failed, rc = %d" % rc
        expected_fdb_entries = []
        current_fdb_list = []
        print(("Adding %d UC FDB entries of type dynamic agable" % (number_of_entries)))
        ports_list = mapPortAndInterfaces(handle)
        mac_addr_list = create_mac_address_list("00:00:00:00:00:01", number_of_entries)
        vlans_list = [50] * number_of_entries

        ports_list = [ports_list[i % 4] for i in range(number_of_entries)]

        mac_records_p = prepare_type_port_uc_fdb_records(number_of_entries, mac_addr_list, vlans_list, ports_list)
        data_cnt_p = new_uint32_t_p()

        tmp_number_of_entries = number_of_entries

        # configure FDB's in MAX_FDB_API_ENTRIES bulk due to sdk's RPC CMD_BODY limitation
        mac_records_idx = 0
        while tmp_number_of_entries != 0:
            if (tmp_number_of_entries > MAX_FDB_API_ENTRIES):
                uint32_t_p_assign(data_cnt_p, MAX_FDB_API_ENTRIES)
            else:
                uint32_t_p_assign(data_cnt_p, tmp_number_of_entries)
            data_cnt = uint32_t_p_value(data_cnt_p)
            current_fdb_list = new_sx_fdb_uc_mac_addr_params_t_arr(data_cnt)
            for j in range(data_cnt):
                sx_fdb_uc_mac_addr_params_t_arr_setitem(current_fdb_list, j, sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_records_p, mac_records_idx))
                mac_records_idx += 1
            rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, current_fdb_list, data_cnt_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_set failed, rc = %d" % rc
            data_cnt = uint32_t_p_value(data_cnt_p)
            tmp_number_of_entries = tmp_number_of_entries - data_cnt
            delete_sx_fdb_uc_mac_addr_params_t_arr(current_fdb_list)
            print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

        # store list of dynamic agable mac records for validation post ISSU.
        for i in range(number_of_entries):
            mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_records_p, i)
            expected_fdb_entries.append(FdbEntry(mac=mac_entry.mac_addr.to_str(), fid=mac_entry.fid_vid, log_port=mac_entry.log_port))

        return expected_fdb_entries

    finally:
        delete_uint32_t_p(data_cnt_p)
        delete_sx_fdb_uc_mac_addr_params_t_arr(mac_records_p)


def issu_start_flow(handle):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc != SX_STATUS_SUCCESS:
        print("SDK is not running.\n")
        sys.exit(-1)

    rc = sx_api_issu_start_set(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_iss_start_set failed, rc = %d" % rc

    rc = sx_api_close(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc = %d" % rc

    print("\nISSU start flow has been succesfully executed.\n")
    print("\nWe are going to stop SDK now.\n")

    execute_command('dvs_stop.sh')


def issu_end_flow(handle):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc != SX_STATUS_SUCCESS:
        print("SDK is not running.\n")
        sys.exit(-1)

    rc = sx_api_issu_end_set(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_issu_end_set failed, rc = %d" % rc

    print("\nISSU end flow has been succesfully executed.\n")


def issu_dvs_start_flow(args):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc == SX_STATUS_SUCCESS:
        print("SDK is already running.\n")
        sys.exit(-1)

    execute_command('dvs_start.sh --sdk_bridge_mode=HYBRID --boot_mode=%s' % args.boot_mode)

    rc, handle = sx_api_open(None)
    assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc = %d" % rc

    return handle


def main():

    args = parse_args()
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc == SX_STATUS_SUCCESS:
        execute_command('dvs_stop.sh')

    args.boot_mode = 'ISSU_FAST'
    handle = issu_dvs_start_flow(args)
    # configure dynamic agable fdb records.
    mac_records_dict = create_fdb(handle, args.num_records)
    issu_start_flow(handle)
    args.boot_mode = 'ISSU_STARTED'
    handle = issu_dvs_start_flow(args)
    issu_end_flow(handle)
    # validate fdb mac records are recovered after ISSU.
    get_and_check_all_uc_ageable_fdb_entries(handle, mac_records_dict)

    rc = sx_api_close(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc = %d" % rc


if __name__ == "__main__":
    main()
