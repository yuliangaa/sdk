#!/usr/bin/env python
from python_sdk_api.sx_api import *
from python_sdk_api import sxd_api

######################################################
#    defines
######################################################

# --- JSON dict keys ---
PLATFORM = "Platform"
ASIC_CONF = "ASIC configuration"
PORTS = "Ports"
DATA = "Data"
ASIC_CONF = "ASIC configuration"
RUN_CONFG = "Run configuration"
RUN = 'Run'
# ------

TEXT = 'text'
JSON = 'json'
MAX_SAMPLES_TEXT = 10
MAX_SAMPLES_JSON = 100
MAX_DELAY = 300  # sec

INSTANCE = "instance"
HW_UNIT_SUB_INSTANCE = "sub_instance"
HW_UNIT_NAME = "hw_unit_name"
UNIT_ID = "unit_id"
UNIT_NAME = "unit_name"
COUNTER_NAME = "counter_name"
COUNTER_ID = "counter_id"
COUNTER_VALUE = "counter_value"
PORT = "port"

CHIP = 'ASIC'
SYSTEM = 'System'
FW_VER = 'FW'
SDK_VER = 'SDK'
OS = 'OS'
TIME = 'Time'

PORTS_NUM = "Ports num"
SYSTEM_PORT = "System port"
LOG_PORT = "Log_port"
LOCAL = "Local"
DCM = "DCM"
DCP = "DCP"
LLU = "LLU"
KVC = "KVC"
PLU = "PLU"
PTB = "PTB"
TILE = "TILE"
TILE_PLT = "TILE_PLT"
DCP_SUB_INDEX = "DCP_SUB_INDEX"
DCM_SUB_INDEX = "DCM_SUB_INDEX"
PTB_SUB_INDEX = "PTB_SUB_INDEX"
LLU_SUB_INDEX = "LLU_SUB_INDEX"
LANES = "Lanes"
SPEED = "Speed"
ADMIN_STATE = "Admin state"
OPER_STATE = "Oper state"
TYPE = "Type"
LAG = "LAG"
AR = "AR enabled"

SPC1_HW_UNITS_NAMES_LIST = ["DQS", "DQL", "DQC", "DQC", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA",
                            "SMA", "SMA", "SMA", "SMA", "SMA", "PXDP", "PXT", "DCP", "DCP", "DCP",
                            "DCP", "KVH", "KVC", "KVC", "KVC", "KVI", "KVI", "TUL", "GLC", "GLC",
                            "GLC", "PHYSICAL", "DCM", "PTB"]

SPC2_HW_UNITS_NAMES_LIST = ["SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA",
                            "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "IR", "PXDP", "PXDP",
                            "PXT", "GLC", "GLC", "GLC", "GLC", "KVC", "KVM", "KVA", "KVI", "KVI",
                            "KVI", "KVI", "KVX", "KVX", "KVX", "TUL", "TUB", "DCP", "DCP", "DCP",
                            "DCP", "DCO", "DUP", "DCL", "DCE", "DQS", "DQL", "DQA", "RIB", "DQC",
                            "LLU", "LLU", "PLU", "DCM", "PTB", "PLU", "PLU"]

SPC3_HW_UNITS_NAMES_LIST = ["SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA",
                            "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "SMA", "IR", "PXDP", "PXDP",
                            "PXT", "GLC", "GLC", "GLC", "GLC", "KVC", "KVM", "KVA", "KVI", "KVI",
                            "KVI", "KVI", "KVX", "KVX", "KVX", "TUL", "TUB", "DCP", "DCP", "DCP",
                            "DCP", "DCO", "DUP", "DCL", "DCE", "DQS", "DQL", "DQA", "RIB", "DQC",
                            "LLU", "LLU", "TILE", "DCM", "PTB", "PLU", "PLU", "TILE", "MGM", "DQCF",
                            "TILE", "TILE"]

SPC4_HW_UNITS_NAMES_LIST = ["SMA", "SMA", "RESERVED", "IR", "DMA", "YU", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
                            "MGM", "PXTL", "PXTL", "PXTL", "PXTL", "PXDP", "PXDP", "PXDP", "PXDP", "PXTH",
                            "KVC", "KVC", "KVM", "KVA", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "KVIT", "KVIB",
                            "TUL", "TUB", "DUP", "DUP", "DCO", "DCL", "DCE", "MNG", "MNG", "MNG", "MNG",
                            "MNG", "DQS", "DQLZ", "DQLE", "DQAI", "DQAW", "DQCA", "DQCF", "RESERVED", "RESERVED",
                            "RESERVED", "LLU", "PLU", "PLU", "PLU", "PLU", "PLU", "DCM", "PTB", "MNG",
                            "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "RIB", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "RESERVED", "GLC", "GLC", "RESERVED",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "LLU", "LLU", "LLU",
                            "LLU", "LLU", "LLU", "MGM", "MGM"]

SPC5_HW_UNITS_NAMES_LIST = ["SMA", "SMA", "RESERVED", "IR", "DMA", "YU", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
                            "MGM", "PXTL", "PXTL", "PXTL", "PXTL", "PXDP", "PXDP", "PXDP", "PXDP", "PXTH",
                            "KVC", "KVC", "KVM", "KVA", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "KVIT", "KVIB",
                            "TUL", "TUB", "DUP", "DUP", "DCO", "DCL", "DCE", "MNG", "MNG", "MNG", "MNG",
                            "MNG", "DQS", "DQLZ", "DQLE", "DQAI", "DQAW", "DQCA", "DQCF", "RESERVED", "RESERVED",
                            "RESERVED", "LLU", "PLU", "PLU", "PLU", "PLU", "PLU", "DCM", "PTB", "MNG",
                            "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "MNG", "RIB", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "RESERVED", "GLC", "GLC", "RESERVED",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC",
                            "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "GLC", "LLU", "LLU", "LLU",
                            "LLU", "LLU", "LLU", "MGM", "MGM"]

oper_rate_dict = {0: "N/A",  # Not connected
                    1: "100M",
                    2: "1G",
                    3: "10G",
                    4: "25G",
                    5: "40G",
                    6: "50Gx1",
                    7: "50Gx2",
                    8: "100Gx1",
                    9: "100Gx2",
                    10: "100Gx4",
                    11: "200Gx2",
                    12: "200Gx4",
                    13: "400Gx4",
                    14: "400Gx8",
                    15: "800Gx8"}

oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}
admin_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 3: 'UP_ONCE'}
oper_speed_dict = {0: 'N/A', 1: '1GB_CX_SGMII', 2: '1GB_KX', 3: '10GB_CX4_XAUI', 4: '10GB_KX4', 5: '10GB_KR', 6: '20GB_KR2', 7: '40GB_CR4',
                    8: '40GB_KR4', 9: '56GB_KR4', 10: '56GB_KX4', 11: '10GB_CR', 12: '10GB_SR', 13: '10GB_ER_LR', 14: '40GB_SR4', 15: '40GB_LR4_ER4',
                    16: '100GB_CR4', 17: '100GB_SR4', 18: '100GB_KR4', 19: '100GB_LR4_ER4', 20: '25GB_CR', 21: '25GB_KR', 22: '25GB_SR', 23: '50GB_CR2',
                    24: '50GB_KR2', 25: '50GB_SR2', 26: '10MB-T', 27: '100MB-TX', 28: '1000MB-T', 29: 'Not supported'}

LOGICAL_RESOURCE_LIST = [RM_SDK_TABLE_TYPE_UC_MAC_E, RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E,
                            RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E, RM_SDK_TABLE_TYPE_ARP_IPV4_E,
                            RM_SDK_TABLE_TYPE_ARP_IPV6_E, RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E,
                            RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E]

RESOURCE_LIST_NAME = ["FDB", "LPMv4", "LPMv6", "ARPv4", "ARPv6", "ACL18B", "ACL36B", "ACL54B"]

type_dict = {0: 'VLAN', 1: 'PORT_VLAN', 2: 'VPORT', 3: 'PKEY', 4: 'BRIDGE_PORT', 5: 'BRIDGE', 6: 'LOOPBACK', 7: 'ADAPTIVE'}

PERF_CNTR_TABLE_LINE_FMT = "\n| {:<10s} | {:<12s} | {:<10s} | {:<10s} | {:<73s} | {:<60s} |  {:<12s} |"
