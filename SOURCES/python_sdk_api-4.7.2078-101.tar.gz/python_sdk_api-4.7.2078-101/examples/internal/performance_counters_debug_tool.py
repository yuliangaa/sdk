#!/usr/bin/env python
# coding: utf-8
'''
This file is a python debug tool for internal use.
It shows the values of a set of performance counters set by the user when running the script.
It was built based on sx_api_performance_counters.py script, and it allows the user to see
the counters values change live in advanced mode (--advanced)
'''
import os
import argparse
import time
import sys
import subprocess
import tkinter as tk
from tkinter import ttk
import math
from argparse import Namespace


LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from python_sdk_api import sxd_api
from test_infra_common import get_chip_type
# import sx_api_performance_counters as pc
import sx_api_performance_counters as pc
from sx_api_performance_counters import PerformanceCountersTool
from performance_counters_global_vars import *

#######################################################################
#       GUI tool
#######################################################################
class AdvancedTool:
    """
    A GUI based class for the tool's advanced mode
    """

    def __init__(self, platform_info, ports_info, asic_config, delay):
        
        self.platform_info, self.ports_info, self.asic_config = platform_info, ports_info, asic_config

        # Delay between re-reading debugFs file in ms
        self.delay = max(delay, 2000)

        self.counter_attributes = COUNTER_ATTRIBUTES + [COUNTER_VALUE]

        # Function for reading counters values from debugFs
        self.read_counters_values = PerformanceCountersTool.create_new_sample


    def run(self):
        # Read initial counters values from the file
        self.counters_values = self.read_counters_values(CHIP_TYPE)

        # Create the main application window
        self.root = tk.Tk()
        self.root.title("Counters Viewer")

        # Create a Notebook (tabs container)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True)

        # Create the main tab that holds the counters table
        self.pc_tab_frame = tk.Frame(self.notebook)
        self.create_pc_table_tab(self.pc_tab_frame)
        self.notebook.add(self.pc_tab_frame, text="pc table")

        # Create tab that contains system information
        self.sys_info_tab = tk.Frame(self.notebook)
        self.create_info_tab(self.sys_info_tab, self.platform_info)
        self.notebook.add(self.sys_info_tab, text="sys info")

        # Create tab that contains asic configurations
        self.asic_config_tab = tk.Frame(self.notebook)
        self.create_info_tab(self.asic_config_tab, self.asic_config)
        self.notebook.add(self.asic_config_tab, text="asic configurations")

        # Create tab that contains ports information
        self.ports_tab = tk.Frame(self.notebook)
        self.create_ports_tab(self.ports_tab)
        self.notebook.add(self.ports_tab, text="ports info")
        
        # Start the periodic update of the GUI
        self.root.after(self.delay, self.update_gui)

        # Start the main event loop
        self.root.mainloop()


    def create_info_tab(self, frame, text):
        """
        adding text label to the given frame
        """
        displayed_text = ""
        for key, value in text.items():
            displayed_text += str(key)+ ' : ' + str(value) + '\n'
        info = tk.Label(frame, text=displayed_text)
        info.pack()

    def create_ports_tab(self, frame):

        # Displays the available ports the user can search for
        available_ports = ''
        for port in self.ports_info:
            available_ports += str(port) + ' '
        entry_label = ttk.Label(frame, text= "available ports: " + available_ports)
        entry_label.pack(side='top')

        # Add an entry for user input
        self.port_entry = ttk.Entry(frame, width=20)
        self.port_entry.pack(side='left', padx=(5, 10))

        # Create a label to display the search result
        self.port_info_label = ttk.Label(frame, text="", padding="10")
        self.port_info_label.pack(padx=10, pady=10, fill='x')

        # Create a button to trigger the search
        search_button = ttk.Button(frame, text="Search port", command=self.display_port_info)
        search_button.pack(side='left')

    def display_port_info(self):

        # Empty label's text from last search
        self.port_info_label.config(text='')

        local_port = int(self.port_entry.get())

        # Adding searched port info to the label
        port_info = ""
        for attr in self.ports_info[local_port]:
            port_info += str(attr) + " : " +  str(self.ports_info[local_port][attr]) + "\n"
        self.port_info_label.config(text=port_info)

    def create_pc_table_tab(self, tab):

        # Creating frame for the performance counters table
        self.table_frame = tk.Frame(tab)
        self.table_frame.pack(fill='both', expand='true')

        # Adding a frame for filter options
        self.create_filter_frame(tab)

        # Initializing the performance counters table
        self.init_gui(self.table_frame)

        # Adding option for changing settings
        self.add_settings_options()

    def add_settings_options(self):

        # Create a dropdown box for changing the set of counters to one of the predefined sets
        self.change_counters_dropdown = ttk.Combobox(self.table_frame, values=PRE_DEFINED_FLOWS)
        self.change_counters_dropdown.set("change counters set")
        self.change_counters_dropdown.pack(side='top', pady=10)
        self.change_counters_dropdown.bind("<<ComboboxSelected>>", self.change_counters)

        # Create an entry for user input to change the interval time of each sample
        self.change_interval_entry = ttk.Entry(self.table_frame)
        self.change_interval_entry.pack(side='left', padx=(5, 10))

        # Create a button to trigger the change
        search_button = ttk.Button(self.table_frame, text="change interval", command=self.change_interval)
        search_button.pack(side='left')

    def create_filter_frame(self, tab):

        # Create a frame for filter options
        self.filter_frame = tk.Frame(tab, width=200, height=100)
        self.filter_frame.pack(side='bottom')

        tk.Label(self.filter_frame, text="Filter by: ", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=5, pady=5, sticky="w")

        # Adding user input entries for each of the filter options
        self.filter_texts = {}
        for attr in self.counter_attributes+[PORT]:
            self.filter_texts[attr] = tk.StringVar()

        # Defining a triggered function for each of the filter entries
        for att in self.filter_texts:
            if att != PORT:
                self.filter_texts[att].trace("w", self.apply_filter)
            else:
                self.filter_texts[att].trace("w", self.apply_port_filter) 

        # Place labels and entry widgets in a grid for alignment
        for idx, att in enumerate(self.filter_texts):
            tk.Label(self.filter_frame, text=att, anchor="w").grid(row=0, column=idx+1, padx=5, pady=5, sticky="w")
            tk.Entry(self.filter_frame, textvariable=self.filter_texts[att], width=12).grid(row=1, column=idx+1, padx=5, pady=5, sticky="w")


    def change_interval(self):
        set_interval(self.change_interval_entry.get())

    def change_counters(self, _):
        """
        the function restarts the script in advanced mode with the given flow configuration
        """
        selected_flow = self.change_counters_dropdown.get()
        self.root.destroy()
        subprocess.call([sys.executable] + ['./performance_counters_debug_tool.py', '--flow', selected_flow, '--advanced'])
        sys.exit()

    def update_gui(self):
        """
        A functions that is being called every self.delay time to update the counters values. 
        """
        # Extracting from debugFs new values of the counters
        new_counters_values = self.read_counters_values(CHIP_TYPE)

        for key in new_counters_values:
            if int(new_counters_values[key][COUNTER_VALUE]) != 0: # new values of the counter detected

                # Adding the new value to the old one
                self.counters_values[key][COUNTER_VALUE] = str(int(self.counters_values[key][COUNTER_VALUE]) + int(new_counters_values[key][COUNTER_VALUE]))

                # Searching for right row in table
                for child in self.tree.get_children():
                    child_values = self.tree.item(child, "values")
                    changed_counter = new_counters_values[key]
                    if (child_values[1], child_values[6], child_values[3], child_values[4]) == (changed_counter[UNIT_ID],changed_counter[COUNTER_ID], changed_counter[INSTANCE], changed_counter[HW_UNIT_SUB_INSTANCE]):

                        # Updating the changed counters row in the table
                        self.tree.set(child, column=COUNTER_VALUE, value=self.counters_values[key][COUNTER_VALUE])

                        # Tagging row as 'changed' to trigger color change
                        self.tree.item(child, tags=('changed',))

                        # Time a function call to reset row's color
                        self.root.after(math.floor(self.delay/2), self.reset_color, child)   
        self.root.after(self.delay, self.update_gui)

    def reset_color(self, item):
        # the function resets the row's color
        if self.tree.exists(item):
            self.tree.item(item, tags=())

    def init_gui(self, frame):

        style = ttk.Style()
        style.configure("Treeview.Heading", font=(style.lookup('Treeview.Heading', 'font'), 9, "bold"))  # Header font size
        style.configure("Treeview", font=(style.lookup('Treeview', 'font'), 9))  # Row font size

        self.tree = ttk.Treeview(frame, columns=self.counter_attributes, show="headings", style="Treeview")

        # Defining width to each column of the performance counters table
        widths = [20,20,150,20,50,150,20,150]
        for col, width in zip(self.counter_attributes, widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=width, anchor='w')

        # Filling the performance counters table
        for _, attrs in self.counters_values.items():
            if all(self.filter_texts[att].get().lower() in attrs[att].lower() for att in self.counter_attributes):
                self.tree.insert("", "end", values=[attrs[att] for att in self.counter_attributes])

        # Defining a tag for changed row to change its text color
        self.tree.tag_configure('changed', foreground='orange')
        self.tree.pack(fill="both", expand=True)

    def apply_filter(self, *args):

        # Delete all rows from table
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Filling table with filtered rows
        for _, attrs in self.counters_values.items():
            if all(self.filter_texts[att].get().lower() in attrs[att].lower() for att in self.counter_attributes):
                self.tree.insert("", "end", values=[attrs[att] for att in self.counter_attributes])

    def apply_port_filter(self, *args):
        """
        filtering counters by instance and sub-instance that match the given port
        """

        # Delete all rows from table
        for item in self.tree.get_children():
            self.tree.delete(item)

        # HW units that can be filtered by port
        relevant_hw_units = {DCP:DCP_SUB_INDEX, KVC:None, PLU:None, DCM:DCM_SUB_INDEX, PTB:PTB_SUB_INDEX, LLU:LLU_SUB_INDEX}

        wanted_port = self.filter_texts[PORT].get().lower()

        if self.filter_texts[PORT].get().lower() != '' and int(wanted_port) in self.ports_info:
            for _, attrs in self.counters_values.items():
                if attrs[HW_UNIT_NAME] in relevant_hw_units:
                    counter_unit_name = attrs[HW_UNIT_NAME]

                    # The given ports instance that matches the counters HW unit
                    relevant_instance = str(hex(self.ports_info[int(wanted_port)][counter_unit_name]))

                    if relevant_hw_units[counter_unit_name]:
                        # The given ports sub instance that matches the counters HW unit
                        relevant_sub_instance = str(hex(self.ports_info[int(wanted_port)][relevant_hw_units[counter_unit_name]]))
                    else:
                        relevant_sub_instance = '0x0'
                    if attrs[INSTANCE] == relevant_instance and attrs[HW_UNIT_SUB_INSTANCE] == relevant_sub_instance:
                        # Counters instance and sub instance are matching to the port, adding it to the table 
                        self.tree.insert("", "end", values=[attrs[att] for att in self.counter_attributes])
        elif self.filter_texts[PORT].get().lower() == '':
            # No port was given, filling the table with all counters info
            for _, attrs in self.counters_values.items():
                if all(self.filter_texts[att].get().lower() in attrs[att].lower() for att in self.counter_attributes):
                    self.tree.insert("", "end", values=[attrs[att] for att in self.counter_attributes])


##################### Light mode #############################

class PerfCounter():
    """
    helper class to encapsulate a counter from resource_db
    """
    def __init__(self, id, name):
        self.name = name
        self.id = id
        self.selections = []

    def p(self):
        print("name: {}".format(self.name))
        print("id: {}".format(self.id))
        print("selections: {}".format(self.selections))

def read_resource_db_file(light_mode):
    if not os.path.exists(RESOURCE_DB_FILE_PATH):
        print("Error: Performance counters resource_db file is missing in %s\n" % RESOURCE_DB_FILE_PATH)
        return
    
    resource_db_file = open(RESOURCE_DB_FILE_PATH, "r")
    resource_db_lines = resource_db_file.readlines()
    resource_db_file.close()

    if light_mode:
        current_counter = None
        splitted_line = resource_db_lines[0].split(":")
        counter_id = int(splitted_line[0], 16)
        counter_name = splitted_line[1]
        current_counter = PerfCounter(counter_id, counter_name)

    for line in resource_db_lines[:-1]:

        unit_id, blank_flag, counter_id, counter_name = line.strip().split(":")

        if blank_flag != "":
            # starting new unit
            HW_UNIT_ID_TO_NAME[unit_id] = blank_flag
            FIND_BY_ID[unit_id] = {}
        else:
            FIND_BY_ID[unit_id][counter_id] = counter_name
            if counter_name in FIND_BY_NAME:
                FIND_BY_NAME[counter_name].append((unit_id, counter_id))
            else:    
                FIND_BY_NAME[counter_name] = [(unit_id, counter_id)]

        if light_mode and line != resource_db_lines[0]:   
            splitted_line = line.split(":")
            counter_id = int(splitted_line[0], 16)
            if current_counter.id != counter_id:
                counter_name = splitted_line[1]
                counters_db.append(current_counter)
                current_counter = PerfCounter(counter_id, counter_name)
            else:
                current_counter.selections.append(splitted_line[-1].replace("\n", ""))

class WatchItem():
    """
    light_mode helper class
    """
    def get_table_row(self):
        # UNIT, COUNTER, INSTANCE, SUB-INSTANCE, VALUE
        row = [0] * 5
        row[0] = self.unit
        row[1] = str(self.instance)
        row[2] = str(self.sub_instance)
        row[3] = self.counter_selection_name
        row[4] = self.value

        return row

    def __init__(self, line):
        self.line = line
        splitted_line = line.split(":")
        splitted_line[-1].replace("\n", ":")

        # UNIT, COUNTER, INSTANCE, SUB-INSTANCE, VALUE
        perf_counter = counters_db[int(splitted_line[1], 16)]
        self.selection = int(splitted_line[3], 16)
        self.unit_id = perf_counter.id
        self.unit = perf_counter.name
        self.instance = int(splitted_line[0], 16)
        self.sub_instance = int(splitted_line[2], 16)
        self.counter_selection_name = perf_counter.selections[self.selection]
        self.value = splitted_line[4]

def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  # If Machine is running on Windows, use cls
        command = 'cls'
    os.system(command)

def print_table(table_data, prev_table_data):
    # ANSI escape sequences for bold red text
    BOLD_RED_START = '\033[1;31m'
    BOLD_RED_END = '\033[0m'

    # Determine the width of each column
    columns = list(zip(*table_data))
    column_widths = [max(len(str(item)) for item in column) for column in columns]

    # Create a format string for the table
    format_string = ' | '.join(f'{{:<{width}}}' for width in column_widths)
    separator = '-+-'.join('-' * width for width in column_widths)

    # Print the table
    for i, row in enumerate(table_data):
        formatted_row = []
        for j, cell in enumerate(row):
            cell_str = str(cell)
            if i < len(prev_table_data) and j < len(prev_table_data[i]) and cell != prev_table_data[i][j]:
                cell_str = f'{BOLD_RED_START}{cell_str}{BOLD_RED_END}'
            formatted_row.append(cell_str)
        print(format_string.format(*formatted_row))
        if row == table_data[0]:  # Print the separator after the header row
            print(separator)        

def print_auto_watch():
    col_attributes = ["UNIT", "INSTANCE", "SUB-INSTANCE", "COUNTER", "VALUE"]
    prev_table_data = None
    filter = configurations_dict["filter"]
    filters = instances_filter[filter]
    while(True):
        table_data = [col_attributes]
        counters_val_res_file = open(DEBUG_FS_FILE_PATH, "r")
        counters_val = counters_val_res_file.readlines()
        counters_val_res_file.close()

        for line in counters_val:
            watch_item = WatchItem(line)
            current_row = watch_item.get_table_row()
            if filters:
                if [watch_item.instance, watch_item.sub_instance] not in filters:
                    continue
            table_data.append(current_row)

        clearConsole()
        if prev_table_data == None:
            prev_table_data = table_data
        else:
            #accumulate counters values
            for row in range(1, len(table_data)):
                table_data[row][-1] = hex(int(table_data[row][-1], 16) + int(prev_table_data[row][-1], 16)) + "\n"
        print_table(table_data, prev_table_data)
        prev_table_data = table_data                


############################ General ####################################

def set_interval(new_interval):

    interval_sysfs_path = "/sys/module/sx_core/asic0/performance/interval"
    interval_sysfs_file_exist = os.path.exists(interval_sysfs_path)
    if not interval_sysfs_file_exist:
        parser.error(
            "Error: Performance interval SysFS file does not exist. SPICE might be down. Use '/sbin/modprobe sx_spice_dump' to enable SPICE\n")
        
    if new_interval is None:
        # interval argument was not configured, checking default value in interval file 
        interval_sysfs = open(interval_sysfs_path, 'r')
        lines = interval_sysfs.readlines()
        tokens = lines[0].split()
        interval = tokens[0]
        if interval == "0":
            interval = "1000"  # Default
    else:
        # writing configured interval to interval file
        interval = new_interval
        with open(interval_sysfs_path, 'w') as interval_file:
            interval_file.write(new_interval+'\n')
    return interval


############################ Input arguments ###################################
def parse_args():
    parser = argparse.ArgumentParser(description=arg_help['general'],
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--samples', default=1, help=arg_help["--samples"], type=int)
    parser.add_argument('--delay', default=0, help=arg_help["--delay"], type=int)
    parser.add_argument('--flow', default=None, help=arg_help["--flow"])
    parser.add_argument('--counters', default=None, help=arg_help["--counters"])
    parser.add_argument('--by_name', action="store_true", help=arg_help["--by_name"])
    parser.add_argument('--advanced', action="store_true", help=arg_help["--advanced"])
    parser.add_argument('--interval', default="1000", help=arg_help["--interval"])
    parser.add_argument('--light_mode', action="store_true", help=arg_help["--light_mode"])
    parser.add_argument('--out_format', default=TEXT, help=arg_help["--out_format"], choices=[TEXT, JSON])

    args = parser.parse_args()

    if args.delay > MAX_DELAY:
        parser.error("Error: max delay allowed is %d seconds\n" % MAX_DELAY)

    if (not args.flow and not args.counters) or (args.flow and args.counters):
        parser.error("Error: must specify exactly one of the following: flow, counters")

    if args.flow is not None and args.flow not in PRE_DEFINED_FLOWS:
        parser.error(f"Error: flow is %s, valid options are {PRE_DEFINED_FLOWS}\n" % args.flow)

    if int(args.interval) < 1:
        parser.error("Error: interval needs to be larger than 0\n")

    if args.by_name and args.counters is None:
        parser.error("by_name must be specified with counters flag.\n")

    if args.light_mode and (args.counters is None or args.by_name):
        parser.error("light mode must be specified only with counters flag.\nThe counters file must be formatted the following way: <hw_unit_id:counter_id>.\n")

    if not os.path.exists(COUNTERS_SYSFS_PATH):
        parser.error("Error: Performance counters SysFS file does not exist. SPICE might be down."
                     " Use '/sbin/modprobe sx_spice_dump' to enable SPICE\n")
        
    custome_args = {k:v for k,v in vars(args).items() if k not in ["flow", "advanced", "interval", "by_name", "light_mode"]}   
    PerformanceCountersTool.validating_args(Namespace(**custome_args))

    return args, custome_args


def help_only():
    """
    print a certain argument help option, and exit script
    """
    if len(sys.argv) == 3 and sys.argv[1] in arg_help and sys.argv[2] == "-h":
        print(sys.argv[1] + "\t\t" + arg_help[sys.argv[1]].replace('\n', '\n\t\t\t'))
        sys.exit(0)


############################ script flow ####################################


def pre_defined_file_to_formatted_file(orig_file_path):
    temp_file_name = "/tmp/running_file"
    with open(temp_file_name, 'w') as new_file:
        with open(orig_file_path, 'r') as orig_file:
            for line in orig_file:
                hw_unit_id, counters_id, counters_name = line.replace('\n', '').split(":")
                new_file.write(str(hw_unit_id) + ":" + str(counters_id)+ "\n")
    return temp_file_name


def write_to_sysfs(file):
    with open(file, 'r') as inputfile, open(COUNTERS_SYSFS_PATH, 'w') as sysfsfile:
        for line in inputfile.readlines():
            if len(line) != 0:
                sysfsfile.write(line)


def make_formatted_file(counters_file):
    """
    Make user counters file in the right format to write to sysFs file
    """
    temp_file_name = "/tmp/running_file"
    with open(counters_file, 'r') as inputfile, open(temp_file_name, 'w') as temp_file:
        for line in inputfile:
            hw_unit_id, counters_id = FIND_BY_NAME[line.replace('\n', '')][0]
            temp_file.write(str(hw_unit_id) + ":" + str(counters_id) + "\n")
    return temp_file_name


def names_file_to_formatted_file(counters):
    counters_input_file_exist = os.path.exists(counters)
    if not counters_input_file_exist:
        parser.error("Error: Performance counters input file does not exist '%s'\n" % counters)

    formatted_file = make_formatted_file(counters)
    # Check 4k size
    validate_file_size(formatted_file)
    return formatted_file

def validate_file_size(file):
    input_file_size = os.path.getsize(file)
    if input_file_size > (4 * 1024):
        parser.error(
            "Error: counters input file is %d, maximum file size supported fby sysFS is 4KB" % input_file_size)

def remove_file(file):
    os.remove(file)

def user_counters(counters, by_name):
    if by_name:
        temp_file = names_file_to_formatted_file(counters)
    else:
        temp_file = counters
    # Write to sysFs file
    write_to_sysfs(temp_file)

    return temp_file


def flow_counters(flow, sysfs=False):
    if (flow == AR_FLOW) and (CHIP_TYPE == SX_CHIP_TYPE_SPECTRUM):
        parser.error("Error: there is no AR in spectrum 1\n")

    # Define file path by the given flow
    if flow in PRE_DEFINED_FLOWS:
        file_path = counters_default_file.get(flow).get(CHIP_TYPE)

    file_path = pre_defined_file_to_formatted_file(file_path)

    # check 4k size
    validate_file_size(file_path)
    
    # Write to sysfs file the wanted counters
    if sysfs:
        write_to_sysfs(file_path)

    return file_path


def init_counters(flow, counters, by_name):
    if flow is not None:
        file = flow_counters(flow, True)
    elif counters is not None:
        file = user_counters(counters, by_name)
    if counters is not None and by_name:
        remove_file(file)

######################################################
#    main
######################################################


def main():
    global CHIP_TYPE, pc_tool

    help_only()
    args, custome_args = parse_args()

    pc_tool = pc.PerformanceCountersTool()
    
    rc, handle = sx_api_open(None)
    print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        print("Error: Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_init(0, None, 2)
    if rc != SX_STATUS_SUCCESS:
        print("Error: sxd_access_reg_init failed, rc = %d" % rc)
        sys.exit(rc)

    CHIP_TYPE = get_chip_type(handle)

    if args.by_name or args.light_mode:
        read_resource_db_file(args.light_mode)

    if args.light_mode:
        if args.interval:
            set_interval(args.interval)
        write_to_sysfs(args.counters)
        print_auto_watch()


    if args.advanced:

        # for not printing
        args.out_format = None

        init_counters(args.flow, args.counters, args.by_name)

        start_time = time.time()

        pc_tool.print_platform_info(handle, args.out_format, CHIP_TYPE)
        platform = pc_tool.json_dict[PLATFORM]
        
        ports = pc_tool.print_ports_info(handle, args.out_format)

        asic_conf = pc_tool.print_asic_configuration(handle, args.out_format)

        rc = sxd_api.sxd_access_reg_deinit()
        if rc != SX_STATUS_SUCCESS:
            print("Error: sxd_access_reg_deinit failed, rc = %d" % rc)
            sys.exit(rc)

        AdvancedTool(platform, ports, asic_conf, args.delay).run()

        exec_time = (time.time() - start_time)
        print('\n Run ' + str(exec_time))

    else:
        temp_file = None
        if args.counters is not None and args.by_name:
            temp_file = custome_args["counters"] = names_file_to_formatted_file(args.counters)

        if args.flow:
            temp_file = custome_args["counters"] = flow_counters(args.flow)

        pc_tool.main(Namespace(**custome_args))

        if(temp_file):
            remove_file(temp_file)

    sx_api_close(handle)


if __name__ == "__main__":
    AR_FLOW = "AR"
    PRE_DEFINED_FILES_RELATIVE_PATH = "debug_flows/"
    PRE_DEFINED_FLOWS = []

    for dir in os.listdir(PRE_DEFINED_FILES_RELATIVE_PATH):
        PRE_DEFINED_FLOWS.append(dir)

    counters_default_file = {}
    NUM_TO_SPC = {1: SX_CHIP_TYPE_SPECTRUM, 2: SX_CHIP_TYPE_SPECTRUM2, 3: SX_CHIP_TYPE_SPECTRUM3, 4: SX_CHIP_TYPE_SPECTRUM4, 5:SX_CHIP_TYPE_SPECTRUM5}
    for flow in PRE_DEFINED_FLOWS:
        counters_default_file[flow] = {}
        for i in range(1,5):
            if os.path.isfile(PRE_DEFINED_FILES_RELATIVE_PATH+flow+"/spc"+str(i)+".txt"):
                counters_default_file[flow][NUM_TO_SPC[i]] = PRE_DEFINED_FILES_RELATIVE_PATH+flow+"/spc"+str(i)+".txt"
            else:
                counters_default_file[flow][NUM_TO_SPC[i]] = None


    arg_help = {
        'general': 'performance counters debug tool.\nneed to install sdk with spice flag for the tool to work\nto use advanced mode:\nssh root@machine -X\napt update\napt install xauth\nexport DISPLAY=<your_vdi>.wap.labs.mlnx:1',
        '--samples': """Default is 1.\nNumber of samples to run the performance counters reading""",
        '--delay': 'Default is 0. \nDelay between samples',
        '--flow': f"""using flow option will disable counters option. \navailable options are: {PRE_DEFINED_FLOWS}. \nthe default counters files are under python_sdk_api/examples/internal/debug_flows""",
        '--counters': """using counters option will disable flow option. \npath to a file that contains a list of counters to debug. \nthe file should be formatted as a list of names of counters""",
        '--advanced': 'GUI based.\ndisplays counters accumulated values in auto watch mode',
        '--interval': """must be applied with advanced / light_mode  flag.\nDefault is 1000.\nTime of each sample""",
        '--out_format': '\'text\' or \'json\'',
        '--by_name' : "must be specifies with counters flag.\nuse flag when counters file is formatted by names of counters.",
        '--light_mode' : "must be specified with counters flag.\n does not support by_name flag.\n live accumulated values in terminal."
    }

    RESOURCE_DB_FILE_PATH ="/usr/share/performance_counters/resource_db.txt"
    COUNTERS_SYSFS_PATH = "/sys/module/sx_core/asic0/performance/counters"
    DEBUG_FS_FILE_PATH = "/sys/kernel/debug/nvswitch/asic_counters/ASIC.1/Performance_counters"
    CHIP_TYPE = ""
    FIND_BY_ID = {}
    HW_UNIT_ID_TO_NAME = {}
    FIND_BY_NAME = {}
    COUNTER_ATTRIBUTES = [HW_UNIT_NAME, UNIT_ID, UNIT_NAME, INSTANCE, HW_UNIT_SUB_INSTANCE, COUNTER_NAME, COUNTER_ID]
    counters_db = []
    instances_filter = {"example" : None, "f1" : [[1, 1], [1, 0], [2, 1]]}
    configurations_dict = {
    "preset": "example", # counters preset selection.
    "filter": "example" # filter selection.
    }
    instances_filter = {
    "example" : None,
    "f1" : [[1, 1], [1, 0], [2, 1]]
    }
    sys.exit(main())

