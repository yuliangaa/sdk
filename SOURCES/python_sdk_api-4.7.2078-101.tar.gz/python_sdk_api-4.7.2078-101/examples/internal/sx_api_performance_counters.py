#!/usr/bin/env python

'''
This file contains Python command example for the Performance counters modulr in sysfs/debugfs.
Python commands syntax is very similar to the commads requires for retriving the performance counters and chip performance status info.

This is a application example script that allows the user to get a full view of the current performance status
in the SDK from Hardare, ports and Logical resource perspective.
'''
import os
import argparse
import datetime
import time
import json
import sys

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
   sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from python_sdk_api import sxd_api
from test_infra_common import get_chip_type
from performance_counters_global_vars import *

class PerformanceCountersTool:

    def __init__(self):
        
        self.port_type_l3_list = []
        self.port_ar_enable_list = []
        self.per_port_lag_membership_dict = {}
        self.json_dict = {}
        self.dev_id = 1

    #######################################################################
    #       function definitions
    #######################################################################

    ########################## Port info ##################################

    @staticmethod
    def router_module_verbosity_level_get(handle):
        module_verbosity_level_p = new_sx_verbosity_level_t_p()
        api_verbosity_level_p = new_sx_verbosity_level_t_p()
        rc = sx_api_router_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p,
                                                api_verbosity_level_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed in sx_api_router_log_verbosity_level_get API rc=%d" % rc)
            sys.exit(rc)
        module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
        api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

        return module_verbosity_level, api_verbosity_level

    @staticmethod
    def router_module_verbosity_level_set(handle, module_verbosity, api_verbosity):
        rc = sx_api_router_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity, api_verbosity)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to set router API verbosity level")
            sys.exit(rc)

    @staticmethod
    def port_type_id_get(port_id):
        port_type = (port_id & SX_PORT_TYPE_ID_MASK) >> SX_PORT_TYPE_ID_OFFS
        return port_type

    @staticmethod
    def phy_port_id_get(port_id):
            phy_port_id = (port_id & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS
            return phy_port_id

    @staticmethod
    def port_speed_param_get(handle, log_port):
        try:
            admin_speed_p = new_sx_port_speed_capability_t_p()
            oper_speed_p = new_sx_port_oper_speed_t_p()
            oper_rate_p = new_sx_port_rate_e_p()
            module_verbosity_level_p = new_sx_verbosity_level_t_p()
            api_verbosity_level_p = new_sx_verbosity_level_t_p()

            # retrieve the current verbosity level settings
            rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
            if rc != SX_STATUS_SUCCESS:
                print("Error: failed to retrieve the current verbosity setting!\n")
                sys.exit(rc)
            module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
            api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

            ''' Modify the port module verbosity level to hide additional log messages
                in case if different API type were used for port speed set and get.
            '''
            rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_port_log_verbosity_level_set failed\n")
                sys.exit(rc)

            # get the current port speed value
            rc = sx_api_port_speed_get(handle, int(log_port), admin_speed_p, oper_speed_p)
            if rc == SX_STATUS_SUCCESS:
                port_speed = oper_speed_dict[sx_port_oper_speed_t_p_value(oper_speed_p)]

            elif rc == SX_STATUS_CMD_UNPERMITTED:
                # looks like port was configured with the 'RATE'-type of API
                rc = sx_api_port_rate_get(handle, int(log_port), oper_rate_p)
                if rc == SX_STATUS_SUCCESS:
                    port_speed = oper_rate_dict[sx_port_rate_e_p_value(oper_rate_p)]

            if rc != SX_STATUS_SUCCESS:
                port_speed = "N/A"
                print("Error: something went wrong - can not retrieve the current port 0x%x speed value, rc = %u.\n" % (int(log_port), rc))
                sys.exit(rc)

            # restore original verbosity setting
            rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_port_log_verbosity_level_set failed\n")
                sys.exit(rc)

        finally:
            delete_sx_port_speed_capability_t_p(admin_speed_p)
            delete_sx_port_oper_speed_t_p(oper_speed_p)
            delete_sx_port_rate_e_p(oper_rate_p)
            delete_sx_verbosity_level_t_p(module_verbosity_level_p)
            delete_sx_verbosity_level_t_p(api_verbosity_level_p)

        return port_speed

    @staticmethod
    def port_info_as_text(port):

        PORT_LINE_STR_FMT = "     {:<14s}         {:<10s}\n"
        PORT_LINE_INT_FMT = "     {:<14s}         {:<10d}\n"

        print("     port    %d\n" % port[LOCAL])
        print(PORT_LINE_STR_FMT
                    .format(LOG_PORT, port[LOG_PORT]))
        print(PORT_LINE_INT_FMT
                    .format(SYSTEM_PORT, port[SYSTEM_PORT]))
        print(PORT_LINE_INT_FMT
                    .format(LOCAL, port[LOCAL]))
        print(PORT_LINE_INT_FMT
                    .format(DCP, port[DCP]))
        print(PORT_LINE_INT_FMT
                    .format(KVC, port[KVC]))
        print(PORT_LINE_INT_FMT
                    .format(PLU, port[PLU]))
        print(PORT_LINE_INT_FMT
                    .format(DCM, port[DCM]))
        print(PORT_LINE_INT_FMT
                    .format(PTB, port[PTB]))
        print(PORT_LINE_INT_FMT
                    .format(LLU, port[LLU]))
        print(PORT_LINE_INT_FMT
                    .format (TILE, port[TILE]))
        print(PORT_LINE_INT_FMT
                    .format(TILE_PLT, port[TILE_PLT]))
        print(PORT_LINE_INT_FMT
                    .format(DCP_SUB_INDEX, port[DCP_SUB_INDEX]))
        print(PORT_LINE_INT_FMT
                    .format (DCM_SUB_INDEX, port[DCM_SUB_INDEX]))
        print(PORT_LINE_INT_FMT
                    .format(PTB_SUB_INDEX, port[PTB_SUB_INDEX]))
        print(PORT_LINE_INT_FMT
                    .format(LLU_SUB_INDEX, port[LLU_SUB_INDEX]))
        print(PORT_LINE_INT_FMT
                    .format(LANES, port[LANES]))
        print(PORT_LINE_STR_FMT
                    .format(SPEED, port[SPEED]))
        print(PORT_LINE_STR_FMT
                    .format(ADMIN_STATE, port[ADMIN_STATE]))
        print(PORT_LINE_STR_FMT
                    .format(OPER_STATE, port[OPER_STATE]))
        print(PORT_LINE_STR_FMT
                    .format(TYPE, port[TYPE]))
        print(PORT_LINE_INT_FMT
                    .format(LAG, port[LAG]))
        print(PORT_LINE_INT_FMT
                    .format(AR, port[AR]))
        print("\n")

    
    def build_per_port_table_for_port_type_and_ar_enable(self, handle):

        vrid_p = new_sx_router_id_t_p()
        sx_router_id_t_p_assign(vrid_p, 0)
        rif_cnt_p = new_uint32_t_p()
        ifc_param_p = sx_router_interface_param_t()
        ifc_attr_p = sx_interface_attributes_t()

        # The following is used to prevent error messages if the router is not initialized
        module_verbosity, api_verbosity = PerformanceCountersTool.router_module_verbosity_level_get(handle)
        PerformanceCountersTool.router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
        uint32_t_p_assign(rif_cnt_p, 0)
        rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, rif_cnt_p)
        PerformanceCountersTool.router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Continue the script, all ports type will be "L2" and all "AR" will be 0
            return
        if rc != SX_STATUS_SUCCESS:
            print("Error: sx_api_router_interface_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)

        rif_cnt = uint32_t_p_value(rif_cnt_p)
        rif_list_p = new_sx_router_interface_t_arr(rif_cnt)
        rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, None, None, rif_list_p, rif_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("Error: sx_api_router_interface_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)
        rif_cnt = uint32_t_p_value(rif_cnt_p)

        for i in range(0, rif_cnt):
            rif = sx_router_interface_t_arr_getitem(rif_list_p, i)
            rc = sx_api_router_interface_get(handle, rif, vrid_p, ifc_param_p, ifc_attr_p)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_router_interface_get for Router %d failed, rc = %d" % (rif, rc))
                sys.exit(1)
            ifc_param = sx_router_interface_param_t_p_value(ifc_param_p)
            if (rc == 0):
                rif_type = type_dict[ifc_param.type]
                port = 0
                if (rif_type == "PORT_VLAN"):
                    port = ifc_param.ifc.port_vlan.port
                elif (rif_type == "VPORT"):
                    vport = ifc_param.ifc.vport.vport
                    port = PerformanceCountersTool.phy_port_id_get(vport)
                elif (rif_type == "ADAPTIVE"):
                    vport = ifc_param.ifc.adaptive_routing.vport
                    port = PerformanceCountersTool.phy_port_id_get(vport)
                    self.port_ar_enable_list.append(port)

                if port != 0:
                    self.port_type_l3_list.append(port)


    def build_lag_port_membership(self, handle, port_cnt):

        lag_id_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(lag_id_cnt_p, 0)
        lag_id = 0

        rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET, 0, lag_id, None, None, lag_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)
        lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)
        lag_id_list_p = new_sx_port_log_id_t_arr(lag_id_cnt)
        rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, lag_id, None, lag_id_list_p,
                                            lag_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)
        lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)

        for j in range(0, lag_id_cnt):
            lag_id = sx_port_log_id_t_arr_getitem(lag_id_list_p, j)
            log_port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(log_port_cnt_p, port_cnt)
            log_port_list_p = new_sx_port_log_id_t_arr(port_cnt)
            rc = sx_api_lag_port_group_get(handle, 0, lag_id, log_port_list_p, log_port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_lag_port_group_get, lag_id 0x%x,  failed, rc = %d" % (lag_id, rc))
                sys.exit(rc)
            log_port_cnt = uint32_t_p_value(log_port_cnt_p)
            for k in range(0, log_port_cnt):
                log_port_id = sx_port_log_id_t_arr_getitem(log_port_list_p, k)
                self.per_port_lag_membership_dict[log_port_id] = lag_id


    def print_ports_info(self, handle, out_format):
        try:
            self.json_dict[PORTS] = []

            port_cnt_p = new_uint32_t_p()
            oper_state_p = new_sx_port_oper_state_t_p()
            admin_state_p = new_sx_port_admin_state_t_p()
            oper_mode_p = new_sx_port_phy_mode_t_p()
            module_state_p = new_sx_port_module_state_t_p()
            admin_mode_p = new_sx_port_phy_mode_t_p()

            uint32_t_p_assign(port_cnt_p, 0)
            port_attributes_list = new_sx_port_attributes_t_arr(0)
            rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_port_device_get failed, rc = %d" % (rc))
                sys.exit(rc)
            port_cnt = uint32_t_p_value(port_cnt_p)

            if out_format == TEXT:
                print(" Ports\n")

            # Get ports
            port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
            rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
            if (rc != SX_STATUS_SUCCESS):
                print("Error: sx_api_port_device_get failed, rc = %d")
                sys.exit(rc)

            # Build L3 and AR ports lists
            self.build_per_port_table_for_port_type_and_ar_enable(handle)

            # Build lag port members table
            self.build_lag_port_membership(handle, port_cnt)

            # Run over the ports and print the information per port
            ports = {}
            for k in range(0, port_cnt):
                port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, k)
                log_port = port_attributes.log_port
                phy_port = PerformanceCountersTool.phy_port_id_get(log_port)
                port_id_type = PerformanceCountersTool.port_type_id_get(log_port)
                if port_id_type != SX_PORT_TYPE_NETWORK:
                    continue

                oper_speed = PerformanceCountersTool.port_speed_param_get(handle, int(log_port))
                lanes = port_attributes.port_mapping.width
                sx_api_port_state_get(handle, int(log_port), oper_state_p, admin_state_p, module_state_p)
                if phy_port in self.port_ar_enable_list:
                    AR_enabled = 1
                else:
                    AR_enabled = 0
                if phy_port in self.port_type_l3_list:
                    port_type = "L3"
                else:
                    port_type = "L2"

                port_lag = 0
                if log_port in self.per_port_lag_membership_dict:
                    port_lag = "0x%x" % self.per_port_lag_membership_dict[log_port]

                mopcs = sxd_api.ku_mopcs_reg()
                meta = sxd_api.sxd_reg_meta_t()
                meta.dev_id = self.dev_id
                meta.swid = 0
                meta.access_cmd = sxd_api.SXD_ACCESS_CMD_GET
                mopcs.local_port = (port_attributes.port_mapping.local_port & 0xFF)
                mopcs.lp_msb = (port_attributes.port_mapping.local_port >> 8) & 0x3

                rc = sxd_api.sxd_access_reg_mopcs(mopcs, meta, 1, None, None)
                if rc != SX_STATUS_SUCCESS:
                    print("Error: sxd_access_reg_mopcs failed, rc = %d" % rc)
                    sys.exit(rc)

                port = {}
                port[LOG_PORT] = "0x%x" % log_port
                port[SYSTEM_PORT] = port_attributes.port_mapping.local_port
                port[LOCAL] = port_attributes.port_mapping.local_port
                port[DCP] = mopcs.dcp_index
                port[KVC] = mopcs.kvc_index
                port[PLU] = mopcs.plu_index
                port[DCM] = mopcs.dcm_index
                port[PTB] = mopcs.ptb_index
                port[LLU] = mopcs.llu_index
                port[TILE] = mopcs.tile_index
                port[TILE_PLT] = mopcs.tile_plt_index
                port[DCP_SUB_INDEX] = mopcs.dcp_sub_index
                port[DCM_SUB_INDEX] = mopcs.dcm_sub_index
                port[PTB_SUB_INDEX] = mopcs.ptb_sub_index
                port[LLU_SUB_INDEX] = mopcs.llu_sub_index
                port[LANES] = lanes
                port[SPEED] = str(oper_speed)
                port[ADMIN_STATE] = admin_dict[sx_port_admin_state_t_p_value(admin_state_p)]
                port[OPER_STATE] = oper_dict[sx_port_oper_state_t_p_value(oper_state_p)]
                port[TYPE] = port_type
                port[LAG] = port_lag
                port[AR] = AR_enabled
                ports[port[SYSTEM_PORT]] = port

                if out_format == TEXT:
                    PerformanceCountersTool.port_info_as_text(port)

                else:
                    self.json_dict[PORTS].append(port)

        finally:
            delete_uint32_t_p(port_cnt_p)
            delete_sx_port_oper_state_t_p(oper_state_p)
            delete_sx_port_admin_state_t_p(admin_state_p)
            delete_sx_port_phy_mode_t_p(oper_mode_p)
            delete_sx_port_module_state_t_p(module_state_p)
            delete_sx_port_phy_mode_t_p(admin_mode_p)
            delete_sx_port_attributes_t_arr(port_attributes_list)
        
        return ports

    ##################### Performance counters table #############################
    @staticmethod
    def __get_hw_unit_name(hw_unit_id, chip_type):

        hw_unit_id_int = int(hw_unit_id, 16)

        if chip_type == SX_CHIP_TYPE_SPECTRUM:
            return SPC1_HW_UNITS_NAMES_LIST[hw_unit_id_int]
        elif chip_type == SX_CHIP_TYPE_SPECTRUM2:
            return SPC2_HW_UNITS_NAMES_LIST[hw_unit_id_int]
        elif chip_type == SX_CHIP_TYPE_SPECTRUM3:
            return SPC3_HW_UNITS_NAMES_LIST[hw_unit_id_int]
        elif chip_type == SX_CHIP_TYPE_SPECTRUM4:
            return SPC4_HW_UNITS_NAMES_LIST[hw_unit_id_int]
        elif chip_type == SX_CHIP_TYPE_SPECTRUM5:
            return SPC5_HW_UNITS_NAMES_LIST[hw_unit_id_int]

    @staticmethod
    def __get_unit_name_and_counter_name_from_resource_db_file(unit_id, counter_id):

        resource_db_path = "/usr/share/performance_counters/resource_db.txt"
        resource_db_exist = os.path.exists(resource_db_path)
        if not resource_db_exist:
            print("Error: Performance counters resource_db file is missing in %s\n" % resource_db_path)
            return
        unit_name = "N/A"
        resource_db_file = open(resource_db_path, 'r')
        lines = resource_db_file.readlines()
        line_idx = 0
        for line in lines:
            if line.startswith(unit_id):
                tokens = line.split(':')
                unit_name = tokens[1]
                break
            else:
                line_idx += 1

        line_idx += 1
        for line in lines[line_idx:-1]:
            if counter_id in line:
                tokens = line.split(':')
                counter_name = tokens[3].replace('\n', '')
                break

        return unit_name, counter_name

    @staticmethod
    def print_separate_line(num_samples):

        sys.stdout.write("\n===================================================================================================================================================================================================================")
        for i in range(num_samples):
            sys.stdout.write("============")

    @staticmethod
    def print_performance_counters_table_header(num_samples):

        sys.stdout.write(PERF_CNTR_TABLE_LINE_FMT
                        .format("Instance","Sub Instance", "HW Unit","Unit ID","Unit Name","Counter Name","Counter ID"))
        for i in range(num_samples):
            sys.stdout.write(" %-10d|" % i)

    @staticmethod
    def print_performance_counters_table_info(samples_dict):
        # go over the first sample lines and print the whole line till the counter value
        first_sample_key = "sample_0"
        first_sample_dict = samples_dict[first_sample_key]
        for line_key in first_sample_dict:
            line_cntr_dict = first_sample_dict[line_key]
            sys.stdout.write(PERF_CNTR_TABLE_LINE_FMT
                            .format(line_cntr_dict[INSTANCE],
                                    line_cntr_dict[HW_UNIT_SUB_INSTANCE],
                                    line_cntr_dict[HW_UNIT_NAME],
                                    line_cntr_dict[UNIT_ID],
                                    line_cntr_dict[UNIT_NAME],
                                    line_cntr_dict[COUNTER_NAME],
                                    line_cntr_dict[COUNTER_ID]))

        # go over all samples and print the counter values
            for sample_iter in samples_dict:
                counter_value = samples_dict[sample_iter][line_key][COUNTER_VALUE]
                sys.stdout.write(" %-10s|" % counter_value)

    def print_performance_counter_table_as_json(self, samples_dict):
        # go over the first sample lines and print the whole line till the counter value
        self.json_dict[DATA] = []
        first_sample_key = "sample_0"
        first_sample_dict = samples_dict[first_sample_key]
        for line_key in first_sample_dict:
            line_dict = first_sample_dict[line_key]
            index = 0
            for sample_iter in samples_dict:
                sample_key = "%s" % index
                line_dict[sample_key] = samples_dict[sample_iter][line_key][COUNTER_VALUE]
                index += 1
            self.json_dict[DATA].append(line_dict)

    @staticmethod
    def create_new_sample(chip_type):

        debug_fs_path = "/sys/kernel/debug/nvswitch/asic_counters/ASIC.1/Performance_counters"
        debugfs_file_exist = os.path.exists(debug_fs_path)
        if not debugfs_file_exist:
            print("Error: Performance counters output file does not exist. SPICE might be down. Use '/sbin/modprobe sx_spice_dump' to enable SPICE\n")
            return

        samples_dict = {}

        perf_cnt_file = open(debug_fs_path, 'r')
        lines = perf_cnt_file.readlines()
        line_index = 0
        for line in lines:
            line_dict = {}
            line_key = "%d" % line_index
            curr_line = line.split(':')
            instance = curr_line[0].replace("'", "")
            unit_id = curr_line[1].replace("'", "")
            hw_unit_name = PerformanceCountersTool.__get_hw_unit_name(unit_id, chip_type)
            counter_id = curr_line[3].replace("'", "")
            counter_value = curr_line[4].replace("'", "")
            counter_value = curr_line[4].replace("\n", "")
            hw_unit_sub_instance = curr_line[2].replace("'", "")
            unit_name, counter_name = PerformanceCountersTool.__get_unit_name_and_counter_name_from_resource_db_file(unit_id, counter_id)

            line_dict[INSTANCE] = instance
            line_dict[HW_UNIT_SUB_INSTANCE] = hw_unit_sub_instance
            line_dict[HW_UNIT_NAME] = hw_unit_name
            line_dict[UNIT_ID] = unit_id
            line_dict[UNIT_NAME] = unit_name
            line_dict[COUNTER_NAME] = counter_name
            line_dict[COUNTER_ID] = counter_id
            line_dict[COUNTER_VALUE] = str(int(counter_value, 16))
            samples_dict[line_key] = line_dict
            line_index += 1

        return samples_dict

    def print_performance_counters_table(self, args, chip_type):
        # Open the performance counter file output in debugFS to retrive the performance counter sample.
        # Store the samples and wait delay time untill retriveing the next sample.
        samples_values_dict = {}
        delay = int(args.delay)

        for sample_iter in range(int(args.samples)):
            new_sample_dict = PerformanceCountersTool.create_new_sample(chip_type)
            # if the samples are empty, return
            if not bool(new_sample_dict):
                return

            sample_key = "sample_%d" % sample_iter
            samples_values_dict[sample_key] = new_sample_dict
            time.sleep(delay)

        # After gathering all the samples, print the performance counter table
        if args.out_format == TEXT:
            PerformanceCountersTool.print_separate_line(int(args.samples))
            PerformanceCountersTool.print_performance_counters_table_header(int(args.samples))
            PerformanceCountersTool.print_separate_line(int(args.samples))
            PerformanceCountersTool.print_performance_counters_table_info(samples_values_dict)
            PerformanceCountersTool.print_separate_line(int(args.samples))
        else:
            self.print_performance_counter_table_as_json(samples_values_dict)


    ############################ General ####################################
    def print_platform_info(self, handle, out_format, chip_type):
        try:
            platform = {}

            if chip_type == SX_CHIP_TYPE_SPECTRUM:
                chip_type_s = "Spectrum"
            elif chip_type == SX_CHIP_TYPE_SPECTRUM2:
                chip_type_s = "Spectrum_2"
            elif chip_type == SX_CHIP_TYPE_SPECTRUM3:
                chip_type_s = "Spectrum_3"
            elif chip_type == SX_CHIP_TYPE_SPECTRUM4:
                chip_type_s = "Spectrum_4"
            elif chip_type == SX_CHIP_TYPE_SPECTRUM5:
                chip_type_s = "Spectrum_5"

            mgir = sxd_api.ku_mgir_reg()
            meta = sxd_api.sxd_reg_meta_t()
            meta.dev_id = 1
            meta.swid = 0
            meta.access_cmd = sxd_api.SXD_ACCESS_CMD_GET

            os.system("mlxfwmanager >/tmp/mlxfwmanager")

            mlxfw_file = open('/tmp/mlxfwmanager')
            lines = mlxfw_file.readlines()
            tokens = lines[8].split(':')
            psid = tokens[1]
            system = psid.strip('\n').strip(' ')

            rc = sxd_api.sxd_access_reg_mgir(mgir, meta, 1, None, None)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sxd_api.sxd_access_reg_mgir failed, rc = %d" % rc)
                sys.exit(rc)
            dev_id = mgir.hw_info.device_id

            fw_ver = "%d_%d_%d" % (mgir.fw_info.extended_major, mgir.fw_info.extended_minor, mgir.fw_info.extended_sub_minor)

            versions_p = new_sx_api_sx_sdk_versions_t_p()
            rc = sx_api_sx_sdk_version_get(handle, versions_p)
            if rc != SX_STATUS_SUCCESS:
                print("Error: sx_api_sx_sdk_version_get failed, rc = %d" % rc)
                sys.exit(rc)
            versions = sx_api_sx_sdk_versions_t_p_value(versions_p)
            sdk_version = versions.sx_sdk.strip()

            with open("/etc/os-release") as f:
                lines = f.readlines()
                for line in lines:
                    if 'PRETTY_NAME' in line:
                        tokens = line.split('=')
                        break

            _os = tokens[1].replace('"', ' ')

            now_time = "%s" % datetime.datetime.now()

            platform[CHIP] = chip_type_s
            platform[SYSTEM] = system
            platform[FW_VER] = fw_ver
            platform[SDK_VER] = sdk_version
            platform[OS] = _os
            platform[TIME] = now_time

            if out_format == TEXT:
                PerformanceCountersTool.platform_info_as_text(platform)
            else:
                self.json_dict[PLATFORM] = platform
        finally:
            delete_sx_api_sx_sdk_versions_t_p(versions_p)
    
    @staticmethod
    def platform_info_as_text(platform_dict):

        print("\n\nGeneral\n")

        print(" %s\n" % PLATFORM)
        print("    ASIC    %s\n" % platform_dict[CHIP])
        print("    System  %s\n" % platform_dict[SYSTEM])
        print("    FW      %s\n" % platform_dict[FW_VER])
        print("    SDK     %s\n" % platform_dict[SDK_VER])
        print("    OS      %s" % platform_dict[OS])
        print("    Time    %s\n" % platform_dict[TIME])

    def print_run_configuration(self, args):

        if args.counters is None:
            counters_input_file = 'N/A'
        else:
            counters_input_file = args.counters
        
        interval_sysfs_path = "/sys/module/sx_core/asic0/performance/interval"
        interval_sysfs_file_exist = os.path.exists(interval_sysfs_path)
        if not interval_sysfs_file_exist:
            parser.error("Error: Performance interval SysFS file does not exist. SPICE might be down. Use '/sbin/modprobe sx_spice_dump' to enable SPICE\n")
            sys.exit(1)

        interval_sysfs = open(interval_sysfs_path, 'r')
        lines = interval_sysfs.readlines()
        tokens = lines[0].split()
        interval = tokens[0]
        if interval == "0":
            interval = "1000"  # Default
        
        if args.out_format == TEXT:
            print("\n Run configuration\n")
            print("    Samples               %s\n" % args.samples)
            print("    Delay                 %s\n" % args.delay)
            print("    Counters_list         %s\n" % counters_input_file)
            print("    Reading interval time %s [100us] \n" % interval)
            print("\n")
        else:
            args_dict = {}
            args_dict['Samples'] = args.samples
            args_dict['Delay'] = args.delay
            args_dict['Counters_list'] = counters_input_file
            args_dict['Reading interval time [100us]'] = interval
            self.json_dict[RUN_CONFG] = args_dict


    ######################## Asic Configuration ##############################
    def print_asic_configuration(self, handle, out_format):
        try:
            asic_conf = {}

            resource_list = new_sx_api_table_type_t_arr(len(LOGICAL_RESOURCE_LIST))
            utilization_list = new_sx_api_rm_table_utilization_t_arr(len(LOGICAL_RESOURCE_LIST))
            list_count_p = new_uint32_t_p()

            uint32_t_p_assign(list_count_p, len(LOGICAL_RESOURCE_LIST))
            for i, resource in enumerate(LOGICAL_RESOURCE_LIST):
                sx_api_table_type_t_arr_setitem(resource_list, i, resource)

            rc = sx_api_rm_sdk_table_utilization_get(handle, resource_list, list_count_p, utilization_list)
            if rc != SX_STATUS_SUCCESS:
                print("Error: Utilization get failed: [rc=%d]" % (rc))
                sys.exit(rc)

            if out_format == TEXT:
                print("\n    %s [units in entries]\n" % ASIC_CONF)

            data_cnt = uint32_t_p_value(list_count_p)
            for i in range(data_cnt):
                ut = sx_api_rm_table_utilization_t_arr_getitem(utilization_list, i)
            
                if out_format == TEXT:
                    print("    %-12s  %-10d\n" % (RESOURCE_LIST_NAME[i], ut.sdk_table_entries_used))
                else:
                    asic_conf[RESOURCE_LIST_NAME[i]] = ut.sdk_table_entries_used
            asic_ut_key = "%s [units in entries]" % ASIC_CONF
            if out_format == JSON:
                self.json_dict[asic_ut_key] = asic_conf
        finally:
            delete_sx_api_table_type_t_arr(resource_list)
            delete_sx_api_rm_table_utilization_t_arr(utilization_list)
            delete_uint32_t_p(list_count_p)
        return asic_conf


    ############################ Input arguments ###################################
    @staticmethod
    def parse_args():
        parser = argparse.ArgumentParser(description='Generate performance application example dump')
        parser.add_argument('--samples', default=1, help='Number of performance counters samples to read, default: one sample')
        parser.add_argument('--delay', default=0, help='Delay between samples in seconds, default: no delay (0)')
        parser.add_argument('--counters', default=None, help='Counters list file path. The example will read the counters in the file.\n Open \'/usr/share/performance_counters/\' to see the avilable counters per chip.')
        parser.add_argument('--out_format', default=TEXT, help='Dump output format { \'text\', \'json\'}, default: text ')

        args = parser.parse_args()
        PerformanceCountersTool.validating_args(args)
        return args


    @staticmethod
    def validating_args(args):
        if (int(args.samples) < 1) or (int(args.delay) < 0):
            sys.exit("Error: samples\delay are invalid\n")

        if (int(args.samples) > MAX_SAMPLES_TEXT) and args.out_format == TEXT:
            sys.exit("Error: max samples allowed for text format is %d\n" % MAX_SAMPLES_TEXT)

        if (int(args.samples) > MAX_SAMPLES_JSON) and args.out_format == JSON:
            sys.exit("Error: max samples allowed for json format is %d\n" % MAX_SAMPLES_JSON)

        if int(args.delay) > MAX_DELAY:
            sys.exit("Error: max delay allowed is %d seconds\n" % MAX_DELAY)

        if (args.out_format != TEXT) and (args.out_format != JSON):
            sys.exit("Error: out_format is %s, valid options are [%s, %s]\n" % (args.out_format, TEXT, JSON))

        counters_sysfs_path = "/sys/module/sx_core/asic0/performance/counters"
        counters_sysfs_file_exist = os.path.exists(counters_sysfs_path)
        if not counters_sysfs_file_exist:
            sys.exit("Error: Performance counters SysFS file does not exist. SPICE might be down. Use '/sbin/modprobe sx_spice_dump' to enable SPICE\n")

        if args.counters is None:
            print("\nCounters list file path is empty, reading the default performance counters list")
            counters_input_file = 'N/A'
        else:
            counters_input_file_exist = os.path.exists(args.counters)
            if not counters_input_file_exist:
                sys.exit("Error: Performance counters input file does not exist '%s'\n" % args.counters)

            # check 4k size
            input_file_size = os.path.getsize(args.counters)
            if input_file_size > (4 * 1024):
                sys.exit("Error: counters input file is %d, maximum file size supported fby sysFS is 4KB" % input_file_size)

            PerformanceCountersTool.write_to_sysfs(args, counters_sysfs_path)

        return args
    
    @staticmethod
    def write_to_sysfs(args, counters_sysfs_path):
        counters_input_file = args.counters
        with open(args.counters, 'r') as inputfile, open(counters_sysfs_path, 'w') as sysfsfile:
            for line in inputfile:
                sysfsfile.write(line)

    ######################################################
    #    main
    ######################################################


    def main(self, args=None):
        start_time = time.time()
        if args is None:
            args = PerformanceCountersTool.parse_args()
        else:
            PerformanceCountersTool.write_to_sysfs(args, "/sys/module/sx_core/asic0/performance/counters")

        print("[+] opening sdk")
        rc, handle = sx_api_open(None)
        print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
        if (rc != SX_STATUS_SUCCESS):
            print("Error: Failed to open api handle.\nPlease check that SDK is running.")
            sys.exit(rc)

        rc = sxd_api.sxd_access_reg_init(0, None, 2)
        if rc != SX_STATUS_SUCCESS:
            print("Error: sxd_access_reg_init failed, rc = %d" % rc)
            sys.exit(rc)

        chip_type = get_chip_type(handle)
        self.print_platform_info(handle, args.out_format, chip_type)

        self.print_run_configuration(args)

        self.print_ports_info(handle, args.out_format)

        self.print_asic_configuration(handle, args)

        rc = sxd_api.sxd_access_reg_deinit()
        if rc != SX_STATUS_SUCCESS:
            print("Error: sxd_access_reg_deinit failed, rc = %d" % rc)
            sys.exit(rc)

        self.print_performance_counters_table(args, chip_type)

        sx_api_close(handle)
        exec_time = (time.time() - start_time)

        if args.out_format == TEXT:
            print('\n Run ' + str(exec_time))
        else:
            run_time = "%s" % exec_time
            self.json_dict[RUN] = run_time
            out_file_path = '/tmp/asic_performance_counters.json'
            with open(out_file_path, 'w') as outfile:
                json.dump(self.json_dict, outfile)

            print("\nJSON Output file: %s \n" % out_file_path)


if __name__ == "__main__":
    sys.exit(PerformanceCountersTool().main())
