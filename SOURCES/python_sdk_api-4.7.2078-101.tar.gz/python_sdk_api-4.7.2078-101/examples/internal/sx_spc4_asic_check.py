#!/usr/bin/env python

import sys
import re
import os
import subprocess
import time
from optparse import OptionParser
from textwrap import dedent
from subprocess import Popen, PIPE

TILE_R1CNT_MAX_VALUE_BASE = 0xc0022ac
TILE_JUMP = 0x800000
NUM_OF_TILES = 8


def printRed(str):
    print("\033[1;31m%s\033[1;m" % str)
    return 0


def printGreen(str):
    print("\033[1;32m%s\033[1;m" % str)
    return 0


def printBlue(str):
    print("\033[1;34m%s\033[1;m" % str)
    return 0


def printYellow(str):
    print("\033[1;33m%s\033[1;m" % str)
    return 0


def cmdline(command):
    process = Popen(
        args=command,
        stdout=PIPE,
        shell=True
    )
    return process.communicate()[0]


def mcra_write(device, adress, value):
    cmdline("mcra " + str(device) + " " + str(adress) + " " + str(value))


def mcra_read(device, addr_str):
    str_value = cmdline("mcra " + device + " " + addr_str)
    return int(str_value, 16)  # convert hex string to int (decimal)


def get_mst_device():
    line = os.popen("mst status | grep mt53120_pciconf0").read()
    match = re.search("\S+", line)
    if match:
        mst = match.group()
    else:
        print("no mst PCICONF device. exit...")
        exit(1)
    return mst


def main():
    mst = get_mst_device()

    mcra_write(mst, 0x3ffffffc, 0x80000000)
    print("\n")
    security_monitor_en = mcra_read(mst, "0xa3f58.23:1")
    if security_monitor_en == 1:
        printGreen("Security Monitor is Enabled")
    else:
        printRed("Security Monitor is Disabled")
    for tile_idx in range(NUM_OF_TILES):
        r1cnt_max_value = mcra_read(mst, str(TILE_R1CNT_MAX_VALUE_BASE + TILE_JUMP * tile_idx) + ".0:5")
        if r1cnt_max_value == 15:
            printGreen("Tile " + str(tile_idx) + " to MAIN sync iterations LOG value is " + str(r1cnt_max_value))
        else:
            printBlue("Tile " + str(tile_idx) + " to MAIN sync iterations LOG value is " + str(r1cnt_max_value))
    icpe_version = mcra_read(mst, "0xf17ec.0")
    if icpe_version < 4:
        printRed("ICPE version is smaller than 2, exiting...")
        print("\n")
        sys.exit(1)
    fuse_state = mcra_read(mst, "0xf17c4.22:2")
    if fuse_state == 0:
        printGreen("ASIC is in LOW Risk")
    elif fuse_state == 1:
        printRed("ASIC is in HIGH Risk")
    else:
        printRed("invalid fuse state for ASIC Risk = " + str(fuse_state))
    mcra_write(mst, 0x3ffffffc, 0x90000000)
    print("\n")


if __name__ == '__main__':
    main()
