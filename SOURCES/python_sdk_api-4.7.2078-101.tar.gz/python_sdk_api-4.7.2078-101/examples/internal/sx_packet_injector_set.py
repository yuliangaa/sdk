#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
import os
import argparse

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from test_infra_common import auto_int


def config_port_netdev_and_loopback(log_port, enable):

    if enable:
        phys_loopback = SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL
        netlink_cmd = "add"
    else:
        phys_loopback = SX_PORT_PHYS_LOOPBACK_DISABLE
        netlink_cmd = "delete"

    admin_state = SX_PORT_ADMIN_STATUS_DOWN
    rc = sx_api_port_state_set(handle, log_port, admin_state)

    rc = sx_api_port_phys_loopback_set(handle, log_port, phys_loopback)

    admin_state = SX_PORT_ADMIN_STATUS_UP
    rc = sx_api_port_state_set(handle, log_port, admin_state)

    cmd = "ip link %s p%x type sx_netdev port 0x%x" % (netlink_cmd, log_port, log_port)
    os.system(cmd)
    if enable:
        cmd = "ifconfig p%x up" % (log_port)
        os.system(cmd)

    print("----------------------------------------------------------")

    if enable:
        print("Created interface: ")
        cmd = "ifconfig p%x" % (log_port)
        os.system(cmd)
    else:
        print(("Interface p%x was deleted" % (log_port)))

    print("----------------------------------------------------------")


def show_port_netdev():
    print("----------------------------------------------------------")
    print("Created port interfaces list: ")
    cmd = "ifconfig | grep p10"
    os.system(cmd)
    print("----------------------------------------------------------")


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

parser = argparse.ArgumentParser(description='Packet injector setup utility')
parser.add_argument("--add", help='Create Port netdev of the provided port and enable port loopback mode', action="store_true")
parser.add_argument("--delete", help='Delete Port netdev of the provided port and disable port loopback mode', action="store_true")
parser.add_argument("--show", help='Show all active port netdevices', action="store_true")
parser.add_argument('--log_port', default=0, type=auto_int, help='Logical port ID')
args = parser.parse_args()
if args.add:
    enable = 1
if args.delete:
    enable = 0
if args.log_port == 0 and args.show == 0:
    print("Please provide --log_port parameter.")
    sys.exit(0)
else:
    log_port = args.log_port

if (args.show == 0):
    config_port_netdev_and_loopback(log_port, enable)
else:
    show_port_netdev()


""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
