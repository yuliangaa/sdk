#!/usr/bin/env python
"""
This file contains Python command example for the MC ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""
import sys
import socket
import struct
from argparse import Action
from python_sdk_api.sx_api import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

PORT0 = 0x1003D
PORT1 = 0x1003F
PORT2 = 0x10039
PORT3 = 0x1003B
PORT4 = 0x10035
PORT5 = 0x10037
PORT6 = 0x10031
PORT7 = 0x10033
PORT8 = 0x1002d
PORT9 = 0x1002f
PORT10 = 0x10029
PORT11 = 0x1002b
PORT12 = 0x10025
PORT13 = 0x10027
PORT14 = 0x10021
PORT15 = 0x10023
PORT16 = 0x10001
PORT17 = 0x10003
PORT18 = 0x10005
PORT19 = 0x10007
PORT20 = 0x10009
PORT21 = 0x1000b
PORT22 = 0x1000d
PORT23 = 0x1000f
PORT24 = 0x10011
PORT25 = 0x10013
PORT26 = 0x10015
PORT27 = 0x10017
PORT28 = 0x10019
PORT29 = 0x1001b
PORT30 = 0x1001d
PORT31 = 0x1001f
DONT_CARE_RIF = 401


def add_pvid_to_port(vlan_id, port):
    pvid = vlan_id
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, port, vlan_id)
    print(("Set pvid %d for port 0x%x rc %d " % (vlan_id, port, rc)))


def prepare_vlan_rif(vrid, port, vlan, mac, mtu=1500):
    sx_api_router.add_ports_to_vlan(vlan, {port: SX_UNTAGGED_MEMBER})

    add_pvid_to_port(vlan, port)

    rif = sx_api_router.create_vlan_rif(vrid, vlan, mac, mtu)
    return rif


def destroy_vlan_rif(vrid, port, vlan, rif):
    sx_api_router.delete_rif(vrid, rif)
    sx_api_router.remove_ports_from_vlan(vlan, {port: SX_TAGGED_MEMBER})


def prepare_bridge_rif(vrid, port_vlan_list, mac, mtu=1500):
    bridge_id = sx_api_router.create_bridge()

    vport_arr = [None] * len(port_vlan_list)
    for i, port_vlan in enumerate(port_vlan_list):
        sx_api_router.add_ports_to_vlan(port_vlan[1], {port_vlan[0]: SX_TAGGED_MEMBER})
        vport_arr[i] = sx_api_router.create_vport(port_vlan[0], port_vlan[1], SX_TAGGED_MEMBER)
        sx_api_router.add_vport_to_bridge(bridge_id, vport_arr[i])
        sx_api_router.set_port_state(vport_arr[i], SX_PORT_ADMIN_STATUS_UP)

    rif = sx_api_router.create_bridge_rif(vrid, bridge_id, mac, mtu)
    return vport_arr, bridge_id, rif


def destroy_bridge_rif(vrid, vport_list, bridge_id, rif, port_vlan_list):
    sx_api_router.delete_rif(vrid, rif)
    for i, vport in enumerate(vport_list):
        sx_api_router.delete_vport_from_bridge(bridge_id, vport)
        sx_api_router.delete_vport(port_vlan_list[i][0], vport, port_vlan_list[i][1], SX_TAGGED_MEMBER)

    sx_api_router.destroy_bridge(bridge_id)


def prepare_router_port_rif(vrid, port, mac, mtu=1500):
    rif = sx_api_router.create_router_port_rif(vrid, port, mac, mtu)
    return rif


def destroy_router_port_rif(vrid, rif):
    sx_api_router.delete_rif(vrid, rif)


def prepare_vport_rif(vrid, port, vlan, mac, mtu=1500):
    sx_api_router.add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})
    vport = sx_api_router.create_vport(port, vlan, SX_TAGGED_MEMBER)
    rif = sx_api_router.create_vport_rif(vrid, vport, mac, mtu)
    return vport, rif


def destroy_vport_rif(vrid, port, vlan, vport, rif):
    sx_api_router.delete_rif(vrid, rif)
    sx_api_router.delete_vport(port, vport, vlan, SX_TAGGED_MEMBER)
    sx_api_router.remove_ports_from_vlan(vlan, {port: SX_TAGGED_MEMBER})


def make_ipv4_mc_route_key(ingress_rif, s_addr, s_mask, g_addr, g_mask):
    mc_route_key = sx_mc_route_key_t()
    mc_route_key.source_addr = sx_api_router.make_sx_ip_prefix_v4(s_addr, s_mask)
    mc_route_key.mc_group_addr = sx_api_router.make_sx_ip_prefix_v4(g_addr, g_mask)
    mc_route_key.ingress_rif = ingress_rif
    return mc_route_key


def make_mc_route_attributes(rpf_action=SX_ROUTER_RPF_ACTION_DISABLED,
                             ttl_cmd=SX_ROUTE_TTL_CMD_DEC,
                             ttl_val=0,
                             prio_type=SX_PRIO_TYPE_MANUAL,
                             manual_prio=1,
                             rpf_group_id=0):
    mc_attr = sx_mc_route_attributes_t()
    mc_attr.rpf_action = rpf_action
    mc_attr.ttl_cmd = ttl_cmd
    mc_attr.ttl_val = ttl_val
    mc_attr.prio.type = prio_type
    mc_attr.prio.manual_prio = manual_prio
    mc_attr.rpf_group_id = rpf_group_id
    return mc_attr


def make_egress_rif_list(erif_list):
    erif_cnt = len(erif_list)
    erif_arr = new_sx_router_interface_t_arr(erif_cnt)
    for i, erif in enumerate(erif_list):
        sx_router_interface_t_arr_setitem(erif_arr, i, erif)
    return erif_arr


def make_mc_route_data(erif_list,
                       action=SX_ROUTER_ACTION_FORWARD,
                       trap_prio=0):
    mc_route_data = sx_mc_route_data_t()
    mc_route_data.action = action
    mc_route_data.trap_attr.prio = trap_prio
    mc_route_data.egress_rif_cnt = len(erif_list)
    for i, erif in enumerate(erif_list):
        sx_router_interface_t_arr_setitem(mc_route_data.egress_rif_list_p, i, erif)
    return mc_route_data


def add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_ADD,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add MC route to VRID %d, rc: %d" % (vrid, rc)
    print("Added MC route to VRID %d" % (vrid))


def modify_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_EDIT,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify MC route to VRID %d, rc: %d" % (vrid, rc)
    print("Modified MC route in VRID %d" % (vrid))


def delete_mc_route(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_DELETE,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete MC route from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted MC route from VRID %d" % (vrid))


def delete_all_mc_routes(vrid, protocol=SX_IP_VERSION_NONE):
    if (protocol == SX_IP_VERSION_IPV4):
        mc_route_key = make_ipv4_mc_route_key(0, '0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')
        mc_route_key_p = new_sx_mc_route_key_t_p()
        sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)
    else:
        mc_route_key_p = None

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_DELETE_ALL,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all MC routes from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted all MC routes from VRID %d" % (vrid))


def get_mc_route_activity(vrid, mc_route_key, clear=False):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    activity_p = new_boolean_t_p()

    cmd = SX_ACCESS_CMD_READ_CLEAR if clear else SX_ACCESS_CMD_READ

    rc = sx_api_router_mc_route_activity_get(sx_api_router.handle,
                                             cmd,
                                             vrid,
                                             mc_route_key_p,
                                             activity_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get activity of MC route on VRID %d, rc: %d" % (vrid, rc)

    activity = boolean_t_p_value(activity_p)
    print("Activity of MC route is %s" % ("True" if (activity != 0) else "False"))


def add_egress_rifs(vrid, mc_route_key, new_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    new_erifs_arr = make_egress_rif_list(new_erifs)

    rc = sx_api_router_mc_egress_rif_set(sx_api_router.handle,
                                         SX_ACCESS_CMD_ADD,
                                         vrid,
                                         mc_route_key_p,
                                         new_erifs_arr,
                                         len(new_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to add %d egress RIFs to MC route on VRID %d, rc: %d" % (len(new_erifs), vrid, rc)
    print("Added %d egress RIFs to MC route on VRID %d" % (len(new_erifs), vrid))


def set_egress_rifs(vrid, mc_route_key, new_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    new_erifs_arr = make_egress_rif_list(new_erifs)

    rc = sx_api_router_mc_egress_rif_set(sx_api_router.handle,
                                         SX_ACCESS_CMD_SET,
                                         vrid,
                                         mc_route_key_p,
                                         new_erifs_arr,
                                         len(new_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to set %d egress RIFs to MC route on VRID %d, rc: %d" % (len(new_erifs), vrid, rc)
    print("Set %d egress RIFs to MC route on VRID %d" % (len(new_erifs), vrid))


def delete_egress_rifs(vrid, mc_route_key, deleted_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    deleted_erifs_arr = make_egress_rif_list(deleted_erifs)

    rc = sx_api_router_mc_egress_rif_set(sx_api_router.handle,
                                         SX_ACCESS_CMD_DELETE,
                                         vrid,
                                         mc_route_key_p,
                                         deleted_erifs_arr,
                                         len(deleted_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to delete %d egress RIFs from MC route on VRID %d, rc: %d" % (len(deleted_erifs), vrid, rc)
    print("Deleted %d egress RIFs from MC route on VRID %d" % (len(deleted_erifs), vrid))


def delete_all_egress_rifs(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_egress_rif_set(sx_api_router.handle,
                                         SX_ACCESS_CMD_DELETE_ALL,
                                         vrid,
                                         mc_route_key_p,
                                         None,
                                         0)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all egress RIFs from MC route on VRID %d, rc: %d" % (vrid, rc)
    print("Deleted all egress RIFs from MC route on VRID %d" % (vrid))


def main():
    # Initialize router
    sx_api_router.router_init(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    # Create VRID that supports IPv4, both UC and MC
    vrid = sx_api_router.create_vrid(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

#    port_vlan_list = [(PORT2, 3)]

    rif_arr = [None] * 32

    # Create 4 RIFs, one of each type that supports MC routing
    rif_arr[0] = prepare_router_port_rif(vrid, PORT0, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = prepare_router_port_rif(vrid, PORT1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))
    rif_arr[2] = prepare_router_port_rif(vrid, PORT2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x09))
    rif_arr[3] = prepare_router_port_rif(vrid, PORT3, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0A))
    rif_arr[4] = prepare_router_port_rif(vrid, PORT4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0B))
    rif_arr[5] = prepare_router_port_rif(vrid, PORT5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0C))
    rif_arr[6] = prepare_router_port_rif(vrid, PORT6, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0D))
    rif_arr[7] = prepare_router_port_rif(vrid, PORT7, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0E))
    rif_arr[8] = prepare_router_port_rif(vrid, PORT8, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0F))
    rif_arr[9] = prepare_router_port_rif(vrid, PORT9, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x10))
    rif_arr[10] = prepare_router_port_rif(vrid, PORT10, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x11))
    rif_arr[11] = prepare_router_port_rif(vrid, PORT11, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x12))
    rif_arr[12] = prepare_router_port_rif(vrid, PORT12, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x13))
    rif_arr[13] = prepare_router_port_rif(vrid, PORT13, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x14))
    rif_arr[14] = prepare_router_port_rif(vrid, PORT14, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x15))
    rif_arr[15] = prepare_router_port_rif(vrid, PORT15, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x16))
    rif_arr[16] = prepare_router_port_rif(vrid, PORT16, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x17))
    rif_arr[17] = prepare_router_port_rif(vrid, PORT17, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x18))
    rif_arr[18] = prepare_router_port_rif(vrid, PORT18, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x19))
    rif_arr[19] = prepare_router_port_rif(vrid, PORT19, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1A))
    rif_arr[20] = prepare_router_port_rif(vrid, PORT20, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1B))
    rif_arr[21] = prepare_router_port_rif(vrid, PORT21, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1C))
    rif_arr[22] = prepare_router_port_rif(vrid, PORT22, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1D))
    rif_arr[23] = prepare_router_port_rif(vrid, PORT23, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1E))
    rif_arr[24] = prepare_router_port_rif(vrid, PORT24, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x1F))
    rif_arr[25] = prepare_router_port_rif(vrid, PORT25, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x20))
    rif_arr[26] = prepare_router_port_rif(vrid, PORT26, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x21))
    rif_arr[27] = prepare_router_port_rif(vrid, PORT27, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x22))
    rif_arr[28] = prepare_router_port_rif(vrid, PORT28, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x23))
    rif_arr[29] = prepare_router_port_rif(vrid, PORT29, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x24))
    rif_arr[30] = prepare_router_port_rif(vrid, PORT30, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x25))
    rif_arr[31] = prepare_router_port_rif(vrid, PORT31, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x26))

    # Enable IPv4 UC and MC on each RIF
    for i in range(32):
        sx_api_router.set_rif_state_ipv4(rif_arr[i],
                                         ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    erif_list = [rif_arr[1], rif_arr[2], rif_arr[3], rif_arr[4], rif_arr[5], rif_arr[6], rif_arr[7], rif_arr[8], rif_arr[9], rif_arr[10], rif_arr[11], rif_arr[12], rif_arr[13], rif_arr[14], rif_arr[15], rif_arr[16], rif_arr[17], rif_arr[18], rif_arr[19], rif_arr[20], rif_arr[21], rif_arr[22], rif_arr[23], rif_arr[24], rif_arr[25], rif_arr[26], rif_arr[27], rif_arr[28], rif_arr[29], rif_arr[30], rif_arr[31]]

#    erif_list = [rif_arr[1], rif_arr[3], rif_arr[5], rif_arr[7], rif_arr[9], rif_arr[11], rif_arr[13], rif_arr[15], rif_arr[17], rif_arr[19], rif_arr[21], rif_arr[23], rif_arr[25], rif_arr[27], rif_arr[29], rif_arr[31]]

    # Create MC route (S = 0.0.0.0/0, G = 225.1.1.1/32) with one egress RIF - ASM
    mc_route_key = make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', '225.1.1.1', '255.255.255.255')
    mc_route_attr = make_mc_route_attributes()
    mc_route_data = make_mc_route_data(erif_list)
    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic to 224.1.1.1

    # Create MC route (S = 192.168.1.2/32, G = 224.1.1.2/32) with one egress RIF - SSM
#    mc_route_key = make_ipv4_mc_route_key(DONT_CARE_RIF, '192.168.1.2', '255.255.255.255', '224.1.1.2', '255.255.255.255')
#    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)
#
#    # Send traffic from 192.168.1.2 to 224.1.1.2
#
#    # Create directional MC route (S = 192.168.1.2/32, G = 224.1.1.3/32) with one egress RIF - SSM with RPF
#    mc_route_key = make_ipv4_mc_route_key(rif_arr[0], '192.168.1.2', '255.255.255.255', '224.1.1.3', '255.255.255.255')
#    mc_route_attr = make_mc_route_attributes(SX_ROUTER_RPF_ACTION_DIRECTIONAL)
#    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.3

    # Add two additional egress RIFs to last MC route created
#    erif_list = [rif_arr[2], rif_arr[2]]
#    add_egress_rifs(vrid, mc_route_key, erif_list)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.3

    # Create MC route with RPF action DROP (S = 192.168.1.2/32, G = 224.1.1.4/32) with one egress RIF
 #   mc_route_key = make_ipv4_mc_route_key(rif_arr[0], '192.168.1.2', '255.255.255.255', '224.1.1.4', '255.255.255.255')
 #   mc_route_attr = make_mc_route_attributes(SX_ROUTER_RPF_ACTION_DROP)
 #   add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.4

    # Get activity of last MC route configured, without clearing activity (activity should be True)
#    get_mc_route_activity(vrid, mc_route_key, False) ####################### Need this???????????????????????

    # Delete all MC routes
  #  delete_all_mc_routes(vrid)
  #
  #  # Destroy all RIFs
  #  destroy_vport_rif(vrid, PORT4, 5, vport, rif_arr[3])
  #  destroy_router_port_rif(vrid, rif_arr[2])
  #  destroy_bridge_rif(vrid, vport_arr, bridge_id, rif_arr[1], port_vlan_list)
  #  destroy_vlan_rif(vrid, PORT1, 2, rif_arr[0])
  #
  #  # Destroy VRID
  #  sx_api_router.delete_vrid(vrid)
  #
  #  # Deinitialize router
  #  sx_api_router.router_deinit()


if __name__ == "__main__":
    main()
