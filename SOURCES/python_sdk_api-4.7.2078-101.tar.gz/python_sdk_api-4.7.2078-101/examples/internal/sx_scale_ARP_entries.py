#!/usr/bin/env python
"""
This file contains Python command example for the ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
	1. vlan RIF
	2. bridge RIF
	3. vport RIF
	4. router port RIF

On each RIF configured the following:
	1. various UC routes
	2. neighbors
	3. external ecmp container
	4. router counters
"""
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

PORT1 = 0x10001
PORT2 = 0x10021
NEIGH_MAC_1 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6C, 0x81)

NEIGH_MAC_2 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x68, 0x82)


# string constants
RIF_STR = "RIF"
IP_STR = "IP"
WEIGHT_STR = "weight"

######################################################
#    functions
######################################################
# layer 2


def ecmp_hash_params_get():
    print("get global ECMP hash params")
    params_p = new_sx_router_ecmp_hash_params_t_p()
    rc = sx_api_router_ecmp_hash_params_get(handle, params_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get global ECMP hash params, rc: %d" % (rc)
    params = sx_router_ecmp_hash_params_t_p_value(params_p)
    return (params.hash_type, params.symmetric_hash, params.seed, params.hash)


def ecmp_hash_params_get_and_validate(type, symmetric, seed, hash):
    (rtype, rsymmetric, rseed, rhash) = ecmp_hash_params_get(type, symmetric, seed, hash)
    assert rtype == type, "got wrong ECMP hash params, type: received: %d, expected %d" % (rtype, type)
    assert rsymmetric == symmetric, "got wrong ECMP hash params, symmetric hash indication: received: %d, expected %d" % (rsymmetric, symmetric)
    assert rhash == hash, "got wrong ECMP hash params, hash value: received: %d, expected %d" % (rhash, hash)
    assert rseed == seed, "got wrong ECMP hash params, seed: received: %d, expected %d" % (rseed, seed)


def ecmp_hash_params_set(type, symmetric, seed, hash):
    print("set global ECMP hash params")
    params = sx_router_ecmp_hash_params_t()
    params.ecmp_hash_type = type
    params.symmetric_hash = symmetric
    params.seed = seed
    params.hash = hash
    rc = sx_api_router_ecmp_hash_params_set(handle, params)
    assert SX_STATUS_SUCCESS == rc, "Failed to set global ECMP hash params, rc: %d" % (rc)


def ecmp_port_hash_params_get(port, enables_cnt, fields_cnt):
    print("set ECMP hash params on port %s" % (str(hex(port))))
    params_p = new_sx_router_ecmp_port_hash_params_t_p()
    fields_arr = new_sx_router_ecmp_hash_field_t_arr(fields_cnt)
    enables_arr = new_sx_router_ecmp_hash_field_enable_t_arr(enables_cnt)
    enables_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(enables_cnt_p, enables_cnt)
    fields_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(fields_cnt_p, fields_cnt)
    rc = sx_api_router_ecmp_port_hash_params_get(handle, port, params_p, enables_arr, enables_cnt_p, fields_arr, fields_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get port %s ECMP hash params, rc: %d" % (str(hex(port)), rc)

    params = sx_router_ecmp_port_hash_params_t_p_value(params_p)
    enables = [sx_router_ecmp_hash_field_enable_t_arr_getitem(enables_arr, i) for i in range(enables_cnt)]
    fields = [sx_router_ecmp_hash_field_t_arr_getitem(fields_arr, i) for i in range(fields_cnt)]
    enables_cnt = uint32_t_p_value(enables_cnt_p)
    fields_cnt = uint32_t_p_value(fields_cnt_p)

    return (params.ecmp_hash_type, params.symmetric_hash, params.seed, enables, enables_cnt, fields, fields_cnt)


def ecmp_port_hash_params_get_and_validate(port, type, symmetric, seed, enables, fields):
    (rtype, rsymmetric, rseed, renables, renable_cnt, rfields, rfields_cnt) = ecmp_port_hash_params_get(port, len(enables), len(fields))
    assert rtype == type, "got wrong ECMP hash params on port %s, type: received: %d, expected %d" % (str(hex(port)), rtype, type)
    assert rsymmetric == symmetric, "got wrong ECMP hash params on port %s, seed: received: %d, expected %d" % (str(hex(port)), rsymmetric, symmetric)
    assert rseed == seed, "got wrong ECMP hash params on port %s, seed: received: %d, expected %d" % (str(hex(port)), params_val.seed, seed)
    assert rfields_cnt == len(fields), "got wrong ECMP hash params on port %s, fields cnt: received: %d, expected %d" % (str(hex(port)), rfields_cnt, len(fields))
    assert renable_cnt == len(enables), "got wrong ECMP hash params on port %s, enables cnt: received: %d, expected %d" % (str(hex(port)), renable_cnt, len(enables))
    assert set(rfields) == set(fields), "got wrong ECMP hash params on port %s, fields arr" % (str(hex(port)))
    assert set(renables) == set(enables), "got wrong ECMP hash params on port %s, fields arr" % (str(hex(port)))


def ecmp_port_hash_params_set_api_call(cmd, port, type, symmetric, seed, enables, fields):
    print("set ECMP hash params on port %s" % (str(hex(port))))
    params = sx_router_ecmp_port_hash_params_t()
    params.ecmp_hash_type = type
    params.symmetric_hash = symmetric
    params.seed = seed
    enables_arr = new_sx_router_ecmp_hash_field_enable_t_arr(len(enables))
    for i, enable in enumerate(enables):
        sx_router_ecmp_hash_field_enable_t_arr_setitem(enables_arr, i, enable)
    fields_arr = new_sx_router_ecmp_hash_field_t_arr(len(fields))
    for i, field in enumerate(fields):
        sx_router_ecmp_hash_field_t_arr_setitem(fields_arr, i, field)
    rc = sx_api_router_ecmp_port_hash_params_set(handle, cmd, port, params, enables_arr, len(enables), fields_arr, len(fields))
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP hash params on port %s, rc: %d" % (str(hex(port)), rc)


def ecmp_port_hash_params_add(port, enables, fields):
    ecmp_port_hash_params_set_api_call(SX_ACCESS_CMD_ADD, port, 0, 0, 0, enables, fields)


def ecmp_port_hash_params_delete(port, enables, fields):
    ecmp_port_hash_params_set_api_call(SX_ACCESS_CMD_DELETE, port, 0, 0, 0, enables, fields)


def ecmp_port_hash_params_set(port, type, symmetric, seed, enables, fields):
    ecmp_port_hash_params_set_api_call(SX_ACCESS_CMD_SET, port, type, symmetric, seed, enables, fields)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def set_port_state(log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))


def create_bridge():
    " This function creates bridge. "

    bridge_id_p = new_sx_bridge_id_t_p()

    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create bridge"

    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print("Created bridge %d, rc: %d" % (bridge_id, rc))
    return bridge_id


def add_vport_to_bridge(bridge_id, log_vport):
    " This function adds vport to bridge with given parametrs. "

    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    assert SX_STATUS_SUCCESS == rc, "Failed to add vport %d to bridge %d" % (log_vport, bridge_id)
    print("Added vport %d to bridge %d , rc: %d" % (log_vport, bridge_id, rc))


def delete_vport_from_bridge(bridge_id, log_vport):
    " This function removes vport from bridge with given parametrs. "

    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    assert SX_STATUS_SUCCESS == rc, "Failed to remove vport %d from bridge %d" % (log_vport, bridge_id)
    print(("Removed vport %d from bridge %d, rc: %d " % (log_vport, bridge_id, rc)))


def destroy_bridge(bridge_id):
    " This function destroys bridge. "

    bridge_id_p = new_sx_bridge_id_t_p()
    sx_bridge_id_t_p_assign(bridge_id_p, bridge_id)

    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy bridge %d" % (bridge_id)
    print(("Destroyed bridge %d, rc: %d " % (bridge_id, rc)))


def disable_auto_learn_port(log_port):
    " This function disables autolearn for given port. "

    rc = sx_api_fdb_port_learn_mode_set(handle, log_port, 0)
    assert SX_STATUS_SUCCESS == rc, "Failed to disable autolearn of port %d" % (log_port)
    print("Disabled autolearn for port %d, rc: %d " % (log_port, rc))


def create_vport(log_port, vlan_id, egress_mode):
    " This function creates vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport for port %d and vlan %d" % (log_port, vlan_id)

    log_vport = sx_port_log_id_t_p_value(log_vport_p)
    print("Create vport %d for port %d and vlan %d, rc: %d" % (log_vport, log_port, vlan_id, rc))
    return log_vport


def delete_vport(log_port, log_vport, vlan_id, egress_mode):
    " This function deletes vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_DELETE, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete vport %d" % (log_vport)
    print("Deleted vport %d from port %d and vlan %d, rc: %d " % (log_vport, log_port, vlan_id, rc))

# router


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_vlan_router_interfaces = 16
    router_resource.max_port_router_interfaces = 16
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    #router_resource.max_ipv4_neighbor_entries   = 1000
    router_resource.max_ipv4_neighbor_entries = 70000
    router_resource.max_ipv6_neighbor_entries = 1000
    #router_resource.max_ipv4_uc_route_entries   = 1000
    router_resource.max_ipv4_uc_route_entries = 70000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                uc_default_action=SX_ROUTER_ACTION_DROP,
                mc_default_action=SX_ROUTER_ACTION_DROP):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = ipv4_enable
    router_attr.ipv6_enable = ipv6_enable
    router_attr.ipv4_mc_enable = ipv4_mc_enable
    router_attr.ipv6_mc_enable = ipv6_mc_enable
    router_attr.uc_default_rule_action = uc_default_action
    router_attr.mc_default_rule_action = mc_default_action

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def create_ip2me_route(vrid, rif, addr, mask="255.255.255.255"):
    " This function creates ip2me route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ip2me route"

    print("Created ip2me route for rif %d, rc: %d " % (rif, rc))


def set_rif_state_ipv4(rif,
                       ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                       ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def read_clear_ecmp_counters(ecmp_counter_arr):
    " This function reads and clears router counters. "

    for i, counter_id in enumerate(ecmp_counter_arr):
        counter_set = sx_flow_counter_set_t()
        counter_set_p = new_sx_flow_counter_set_t_p()

        rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d, rc: %d" % (counter_id, rc)
        print("Read router counter %d" % (counter_id))
        counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
        print_flow_counter(counter_id, counter_set)

        rc = sx_api_flow_counter_clear_set(handle, counter_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to clear flow counter %d, rc: %d" % (counter_id, rc)
        print("Cleared router counter %d" % (counter_id))


def print_flow_counter(counter_id, counter_set):
    print("####################################################################")
    print("Router counter ID %d:\n" % (counter_id))

    print("Flow counter packets:             {:>10}".format(counter_set.flow_counter_packets))
    print("Flow counter bytes:               {:>10}".format(counter_set.flow_counter_bytes))
    print("####################################################################\n")


def read_clear_router_counters(counter_id_arr):
    " This function reads and clears router counters. "

    for i, counter_id in enumerate(counter_id_arr):
        counter_set = sx_router_counter_set_t()
        counter_set_p = new_sx_router_counter_set_t_p()
        sx_router_counter_set_t_p_assign(counter_set_p, counter_set)

        rc = sx_api_router_counter_get(handle, SX_ACCESS_CMD_READ_CLEAR, counter_id, counter_set_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to read and clear router counter %d" % (counter_id)
        print("Read and cleared router counter %d, rc: %d" % (counter_id, rc))
        print_router_counter(counter_id, counter_set)


def print_router_counter(counter_id, counter_set):
    print("####################################################################")
    print("Router counter ID %d:\n" % (counter_id))

    print("Router ingress good unicast packets:             {:>10}".format(counter_set.router_ingress_good_unicast_packets))
    print("Router ingress good multicast packets:           {:>10}".format(counter_set.router_ingress_good_multicast_packets))
    print("Router ingress good unicast bytes:               {:>10}".format(counter_set.router_ingress_good_unicast_bytes))
    print("Router ingress good multicast bytes:             {:>10}".format(counter_set.router_ingress_good_multicast_bytes))
    print("Router ingress bad unicast packets:              {:>10}".format(counter_set.router_ingress_bad_unicast_packets))
    print("Router ingress bad multicast packets:            {:>10}".format(counter_set.router_ingress_bad_multicast_packets))
    print("Router ingress bad unicast bytes:                {:>10}".format(counter_set.router_ingress_bad_unicast_bytes))
    print("Router ingress bad multicast bytes:              {:>10}".format(counter_set.router_ingress_bad_multicast_bytes))
    print("Router egress good unicast packets:              {:>10}".format(counter_set.router_egress_good_unicast_packets))
    print("Router egress good multicast packets:            {:>10}".format(counter_set.router_egress_good_multicast_packets))
    print("Router egress good unicast bytes:                {:>10}".format(counter_set.router_egress_good_unicast_bytes))
    print("Router egress good multicast bytes:              {:>10}".format(counter_set.router_egress_good_multicast_bytes))
    print("Router egress bad unicast packets:               {:>10}".format(counter_set.router_egress_bad_unicast_packets))
    print("Router egress bad multicast packets:             {:>10}".format(counter_set.router_egress_bad_multicast_packets))
    print("Router egress bad unicast bytes:                 {:>10}".format(counter_set.router_egress_bad_unicast_bytes))
    print("Router egress bad multicast bytes:               {:>10}".format(counter_set.router_egress_bad_multicast_bytes))
    print("Router ingress good broadcast packets:           {:>10}".format(counter_set.router_ingress_good_broadcast_packets))
    print("Router ingress error packets:                    {:>10}".format(counter_set.router_ingress_error_packets))
    print("Router ingress discard packets:                  {:>10}".format(counter_set.router_ingress_discard_packets))
    print("Router ingress good broadcast bytes:             {:>10}".format(counter_set.router_ingress_good_broadcast_bytes))
    print("Router ingress error bytes:                      {:>10}".format(counter_set.router_ingress_error_bytes))
    print("Router ingress discard bytes:                    {:>10}".format(counter_set.router_ingress_discard_bytes))
    print("Router egress good broadcast packets:            {:>10}".format(counter_set.router_egress_good_broadcast_packets))
    print("Router egress error packets:                     {:>10}".format(counter_set.router_egress_error_packets))
    print("Router egress discard packets:                   {:>10}".format(counter_set.router_egress_discard_packets))
    print("Router egress good broadcast bytes:              {:>10}".format(counter_set.router_egress_good_broadcast_bytes))
    print("Router egress error bytes:                       {:>10}".format(counter_set.router_egress_error_bytes))
    print("Router egress discard bytes:                     {:>10}".format(counter_set.router_egress_discard_bytes))
    print("####################################################################\n")


def make_uc_route_data(next_hop_list, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for uc route with given parametrs.
            Action is optional, default action is forward.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = len(next_hop_list)
    for i, ipaddr in enumerate(next_hop_list):
        ip_addr = make_sx_ip_addr_v4(ipaddr)
        sx_ip_addr_t_arr_setitem(uc_route_data.next_hop_list_p, i, ip_addr)
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    return uc_route_data


def add_uc_route_next_hop(vrid, addr, mask, next_hop_list):
    " This function adds uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_uc_route_data(next_hop_list)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add uc route"

    print("Added uc route, rc: %d " % (rc))


def make_ecmp_next_hop(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
            This function creates ecmp_next_hop struct with given parametrs.
            action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        next_hop = make_ecmp_next_hop(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates ecmp uc_route_data struct with given parametrs.
            action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.next_hop_cnt = 0
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def create_bridge_rif(vrid, bridge_id, mac_addr, mtu=1500):
    " This function creates bridge rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_BRIDGE
    ifc_param.ifc.bridge.swid = SPECTRUM_SWID
    ifc_param.ifc.bridge.bridge = bridge_id

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed create bridge RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created bridge RIF: %d, rc: %d " % (rif, rc))
    return rif


def create_vport_rif(vrid, log_vport, mac_addr, mtu=1500):
    " This function creates vport rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VPORT
    ifc_param.ifc.vport.vport = log_vport

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vport RIF: %d, rc: %d " % (rif, rc))
    return rif


def create_router_port_rif(vrid, log_port, mac_addr, mtu=1500):
    " This function creates router port rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_PORT_VLAN
    ifc_param.ifc.port_vlan.port = log_port
    ifc_param.ifc.port_vlan.vlan = 0

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router port for port %d" % (log_port)
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created router port RIF: %d for port %d, rc: %d" % (rif, log_port, rc))
    return rif


def delete_neigh(rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def unbind_router_counter(counter_id, rif):
    " This function unbinds router counter from rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to unbind router counter"
    print("Unbinded router counter %d from RIF %d, rc: %d" % (counter_id, rif, rc))


def destroy_router_counter(counter_id):
    " This function destroys router counter. "

    counter_p = new_sx_router_counter_id_t_p()
    sx_router_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed router counter %d, rc: %d" % (counter_id, rc))


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_all_next_hops_uc_routes_per_vrid(vrid):
    " This function deletes all next hops from given vrid. "

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_neigh_per_rif(rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_local_routes(vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_ip2me_routes(vrid):
    " This function deletes all ip2me routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all IP2ME UC routes"
    print(("Deleted all IP2ME UC routes, rc: %d " % (rc)))


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

# router examples


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def create_ecmp_container_counter():
    " This function creates ecmp flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP counter, rc: %d" % (rc)

    counter_id = sx_router_counter_id_t_p_value(counter_p)

    print("Created ECMP counter %d" % (counter_id))
    return counter_id


def unbind_entire_ecmp_container(ecmp_id):
    counters_id_arr = new_sx_flow_counter_id_t_arr(1)
    counters_offset_arr = new_uint32_t_arr(1)

    # 0             = SX_FLOW_COUNTER_ID_INVALID
    # 0xFFFFFFFF = INVALID_NEXT_HOP_OFFSET
    sx_flow_counter_id_t_arr_setitem(counters_id_arr, 0, 0)
    uint32_t_arr_setitem(counters_offset_arr, 0, 0xFFFFFFFF)

    rc = sx_api_router_ecmp_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, ecmp_id, counters_id_arr, counters_offset_arr, 1)
    assert SX_STATUS_SUCCESS == rc, "Failed unbind counters from entire external ecmp container, rc: %d" % (rc)

    print("Unbound ECMP container ID %d counters" % (ecmp_id))


def unbind_entire_ecmp_container_fine_grain(ecmp_id):
    offset_arr = new_uint32_t_arr(1)
    uint32_t_arr_setitem(offset_arr, 0, 0)

    rc = sx_api_router_ecmp_fine_grain_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, ecmp_id, 0xFFFFFFFF, offset_arr, 1)
    assert SX_STATUS_SUCCESS == rc, "Failed to unbind resilient counters to entire resilient ECMP container, rc: %d" % (rc)

    print("Unbounded entire resilient ECMP container ID %d" % (ecmp_id))


def destroy_ecmp_container_counter(ecmp_counter_id):
    " This function destroys router counter. "

    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS
    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, ecmp_counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy ecmp counter, rc: %d" % (rc)

    print("Destroyed router counter %d" % (ecmp_counter_id))


def operational_ecmp_print(ecmp_id, block_size):
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, block_size)
    next_hop_arr = new_sx_next_hop_t_arr(block_size)
    sx_api_router_operational_ecmp_get(handle, ecmp_id, next_hop_arr, next_hop_cnt_p)
    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("operational_ecmp_print next_hop_cnt: %d " % (next_hop_cnt))


def set_ecmp_container_counter(ecmp_id, counter_ids_list):
    """ This func binds counters to next hops on ecmp container, given counters list
            the function binds each counter to its relative offset by the index """
    counters_count = len(counter_ids_list)
    counters_id_arr = new_sx_flow_counter_id_t_arr(counters_count)
    counters_offset_arr = new_uint32_t_arr(counters_count)

    for offset, counter_id in enumerate(counter_ids_list):
        sx_flow_counter_id_t_arr_setitem(counters_id_arr, offset, counter_id)
        uint32_t_arr_setitem(counters_offset_arr, offset, offset)

    rc = sx_api_router_ecmp_counter_bind_set(handle, SX_ACCESS_CMD_BIND, ecmp_id, counters_id_arr, counters_offset_arr, counters_count)
    assert SX_STATUS_SUCCESS == rc, "Failed bind counter to external ecmp next hop, rc: %d" % (rc)

    print("Bound ECMP container ID %d nexthops to counters" % (ecmp_id))


def set_ecmp_container_fine_grain_counter(ecmp_id, counter_id, offsets_list):
    """
    This func binds counters to next hops on ecmp container, given counters list
    the function binds each counter to its relative offset by the index
    @param param ecmp_id: ECMP container ID
    @param counter_id: Counter ID
    @param offsets_list: List of offsets in container active set(actual HW entries)
    """
    offsets_count = len(offsets_list)
    offset_arr = new_uint32_t_arr(offsets_count)

    for i, offset in enumerate(offsets_list):
        uint32_t_arr_setitem(offset_arr, i, offset)

    rc = sx_api_router_ecmp_fine_grain_counter_bind_set(handle, SX_ACCESS_CMD_BIND, ecmp_id, counter_id, offset_arr, offsets_count)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind resilient counters to resilient ECMP container, rc: %d" % (rc)

    print("Bound resilient ECMP container ID %d to counter %d" % (ecmp_id, counter_id))


def read_ecmp_attributes(ecmp_id):
    "This function reads ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_get(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read ECMP %d attributes, rc: %d" % (ecmp_id, rc)
    ecmp_attributes = sx_ecmp_attributes_t_p_value(ecmp_attributes_p)
    print_ecmp_attributes(ecmp_id, ecmp_attributes)


def set_ecmp_attributes(ecmp_id, ecmp_type, active_flow_timer=100, group_size=4096, max_unbalanced_time=200):
    """"
    This function sets ECMP external container attributes
    @param emcp_id: ECMP container ID
    @param type: External ECMP container type, e.g. SX_ECMP_TYPE_RESILIENT_E
    @param active_flow_timer: ECMP active flow timer
    @param groups_size:	ECMP container group size
    @param max_unbalanced_time: ECMP max unbalanced time
    """
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = ecmp_type
    ecmp_attributes.active_flow_timer = active_flow_timer
    ecmp_attributes.group_size = group_size
    ecmp_attributes.max_unbalanced_time = max_unbalanced_time
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)


def print_ecmp_attributes(ecmp_id, ecmp_attributes):
    print("####################################################################")
    print("Router ECMP ID  %d:\n" % (ecmp_id))

    print("ECMP type:                {:>10}".format(ecmp_attributes.ecmp_type))
    print("ECMP active_flow_timer:   {:>10}".format(ecmp_attributes.active_flow_timer))
    print("ECMP group_size:          {:>10}".format(ecmp_attributes.group_size))
    print("ECMP max_unbalanced_time: {:>10}".format(ecmp_attributes.max_unbalanced_time))
    print("####################################################################\n")


def modify_external_ecmp_container(ecmp_id, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param ecmp__id: ECMP container ID.
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify external ECMP container, rc %d" % (rc)

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Modified ECMP container ID %d " % (ecmp_id))


def example_vlan_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT2: SX_TAGGED_MEMBER})

    # create vlan rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_vlan_rif(vrid, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr


def example_vlan_rif_deinit(vrid, rif_arr):
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})


def example_bridge_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})

    # vport init
    log_vport = create_vport(PORT2, 5, SX_TAGGED_MEMBER)

    # create bridge
    bridge_id = create_bridge()

    # add vport to bridge
    add_vport_to_bridge(bridge_id, log_vport)

    # set port state to up
    set_port_state(log_vport, SX_PORT_ADMIN_STATUS_UP)

    # create vlan rif and bridge rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_bridge_rif(vrid, bridge_id, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr, log_vport, bridge_id


def example_bridge_rif_deinit(bridge_id, log_vport):
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})

    # remove vport form bridge
    delete_vport_from_bridge(bridge_id, log_vport)

    # destroy bridge
    destroy_bridge(bridge_id)

    # vport deinit
    delete_vport(PORT2, log_vport, 5, SX_TAGGED_MEMBER)


def example_vport_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})

    # disable autolearn
    disable_auto_learn_port(PORT2)

    # vport init
    log_vport = create_vport(PORT2, 5, SX_TAGGED_MEMBER)

    # set port state to up
    set_port_state(log_vport, SX_PORT_ADMIN_STATUS_UP)

    # create vlan rif and vport rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_vport_rif(vrid, log_vport, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr, log_vport


def example_vport_rif_deinit(log_vport):
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})

    # vport deinit
    delete_vport(PORT2, log_vport, 5, SX_TAGGED_MEMBER)


def example_router_port_rif_init(vrid):
    # vlan init
    add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})

    # disable autolearn
    disable_auto_learn_port(PORT2)

    # vport init
    remove_ports_from_vlan(1, {PORT2: SX_TAGGED_MEMBER})

    # create vlan rif and router port rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_router_port_rif(vrid, PORT2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif_arr


def example_router_port_rif_deinit():
    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})


def example_ecmp_hash():
    # Set global ECMP hash params
    type = SX_ROUTER_ECMP_HASH_TYPE_XOR
    symmetric = True
    seed = 14142
    # Since symmetric hash is True, enabling in hash bitmask should be in couples, source and destination.
    # Here both SX_ROUTER_ECMP_HASH_SRC_IP, SX_ROUTER_ECMP_HASH_DST_IP are enabled.
    hash = 3
    ecmp_hash_params_set(type, symmetric, seed, hash)
    # Set ECMP hash params on PORT1
    type = SX_ROUTER_ECMP_HASH_TYPE_CRC
    symmetric = False
    seed = 31415

    # Set ECMP hash params of PORT1
    # SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4 - Enable L2 fields for IPv4 and IPV6 packets.
    # SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP - Enable IPv4 fields for TCP/UDP packets.
    enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4,
               SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP]
    fields = [SX_ROUTER_ECMP_HASH_OUTER_SMAC,
              SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_0,
              SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_0]
    ecmp_port_hash_params_set(PORT1, type, symmetric, seed, enables, fields)
    ecmp_port_hash_params_get_and_validate(PORT1, type, symmetric, seed, enables, fields)

    # After calling sx_api_router_ecmp_port_hash_params_set, legacy API sx_api_router_ecmp_hash_params_set is disabled

    # Add enables and fields to ECMP hash params of PORT1
    add_enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV6,
                   SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP]
    add_fields = [SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7]
    enables += add_enables
    fields += add_fields
    ecmp_port_hash_params_add(PORT1, add_enables, add_fields)
    ecmp_port_hash_params_get_and_validate(PORT1, type, symmetric, seed, enables, fields)

    # Delete enables and fields from ECMP hash params on PORT1
    delete_enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4]
    delete_fields = [SX_ROUTER_ECMP_HASH_OUTER_SMAC]
    enables = [enable for enable in enables if enable not in delete_enables]
    fields = [field for field in fields if field not in delete_fields]
    ecmp_port_hash_params_delete(PORT1, delete_enables, delete_fields)
    ecmp_port_hash_params_get_and_validate(PORT1, type, symmetric, seed, enables, fields)

# router flow


def router_flow(vrid, rif_arr):

    # add local and ip2me routes
    create_local_route(vrid, rif_arr[0], "192.168.1.0", "255.255.255.0")
    create_ip2me_route(vrid, rif_arr[0], "192.168.1.1")
    create_local_route(vrid, rif_arr[1], "22.33.0.0", "255.255.0.0")
    create_ip2me_route(vrid, rif_arr[1], "22.33.44.55")

    # rif state ipv4
    set_rif_state_ipv4(rif_arr[0], ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE)
    set_rif_state_ipv4(rif_arr[1], ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE)

    # add neighbors
    add_neigh(rif_arr[0], "192.168.1.2", NEIGH_MAC_1)
    add_neigh(rif_arr[1], "22.33.0.2", NEIGH_MAC_2)

    # router counters - create and bind
    router_counter_arr = [None] * 2
    router_counter_arr[0] = create_router_counter()
    router_counter_arr[1] = create_router_counter()
    bind_router_counter(router_counter_arr[0], rif_arr[0])
    bind_router_counter(router_counter_arr[1], rif_arr[1])

    # flow counters - create
    ecmp_counter_arr = [None] * 2
    ecmp_counter_arr[0] = create_ecmp_container_counter()
    ecmp_counter_arr[1] = create_ecmp_container_counter()
    ##########################################################
    # Traffic 192.168.1.2 <--> 22.33.0.2
    ##########################################################

    # read and clear router counters
    read_clear_router_counters(router_counter_arr)

    # add uc route next_hop
    add_uc_route_next_hop(vrid, "100.100.128.0", "255.255.255.0", {"22.33.0.2"})

    ##########################################################
    # Traffic 192.168.1.2 <--> 100.100.128.X(via 22.33.0.2)
    ##########################################################

    # read and clear router counters
    read_clear_router_counters(router_counter_arr)

    # add uc route next hop
    #add_uc_route_next_hop(vrid, "100.100.128.0", "255.255.255.0", {"22.33.0.3", "22.33.0.4", "22.33.0.5", "22.33.0.6", "22.33.0.7", "22.33.0.8", "22.33.0.9", "22.33.0.10"})

    for i in range(1, 254):
        for j in range(1, 254):
            for k in range(3, 254):
                NEIGH_MAC_3 = ether_addr(0xE4, 0x1D, 0x2D, i, j, k)
                ip = "22.%d.%d.%d" % (i, j, k)
            add_neigh(rif_arr[1], ip, NEIGH_MAC_3)

    ##########################################################
    # Traffic 192.168.1.2 <--> {22.33.0.2, 22.33.0.3, 22.33.0.4, 22.33.0.5, 22.33.0.6}
    ##########################################################

    # read and clear router counters
    read_clear_router_counters(router_counter_arr)
    # exit added by annatoly
    exit(1)

    # unresolve neighbors
    delete_neigh(rif_arr[1], "22.33.0.2")
    delete_neigh(rif_arr[1], "22.33.0.3")
    delete_neigh(rif_arr[1], "22.33.0.4")
    delete_neigh(rif_arr[1], "22.33.0.5")
    delete_neigh(rif_arr[1], "22.33.0.6")

    # create external ECMP container with {22.33.0.7} next hops

    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.7",
                                  WEIGHT_STR: 2})

    ecmp_id = create_external_ecmp_container(next_hops_params_list)
    create_ecmp_uc_route(vrid, "100.100.129.0", "255.255.255.0", ecmp_id)

    # unbind counters from entire ECMP container, create counter and bind it
    # to first next hop on ecmp container
    unbind_entire_ecmp_container(ecmp_id)
    set_ecmp_container_counter(ecmp_id, [ecmp_counter_arr[0]])
    # resolve neighbor
    add_neigh(rif_arr[1], "22.33.0.7", NEIGH_MAC_2)
    ##########################################################
    # Traffic 192.168.1.2 <--> 22.33.0.7
    ##########################################################

    # read and clear router counters
    read_clear_router_counters(router_counter_arr)

    # read and clear ecmp counters
    read_clear_ecmp_counters(ecmp_counter_arr)

    # unbind all related counters
    unbind_entire_ecmp_container(ecmp_id)

    # modify external ECMP container with {22.33.0.7, 22.33.0.8} next hops
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.8",
                                  WEIGHT_STR: 7})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # unbind counters from entire ECMP container, create counter and bind it
    # to first next hop on ecmp container
    set_ecmp_container_counter(ecmp_id, [ecmp_counter_arr[0], ecmp_counter_arr[1]])

    # resolve neighbor
    add_neigh(rif_arr[1], "22.33.0.8", NEIGH_MAC_2)

    ##########################################################
    # Traffic 192.168.1.2 <--> {22.33.0.7, 22.33.0.8}
    ##########################################################
    # read and clear router counters
    read_clear_router_counters(router_counter_arr)

    # read and clear ecmp counters
    read_clear_ecmp_counters(ecmp_counter_arr)

    # unbind all related counters
    unbind_entire_ecmp_container(ecmp_id)

    delete_neigh(rif_arr[1], "22.33.0.7")
    delete_neigh(rif_arr[1], "22.33.0.8")
    # unbind router counters
    unbind_router_counter(router_counter_arr[0], rif_arr[0])
    unbind_router_counter(router_counter_arr[1], rif_arr[1])

    # delete all next hop uc routes
    delete_all_next_hops_uc_routes_per_vrid(vrid)

    # clear container(unbound from routes), and change to resilient container
    modify_external_ecmp_container(ecmp_id, [])
    container_group_size = 4096
    set_ecmp_attributes(ecmp_id, SX_ECMP_TYPE_RESILIENT_E, group_size=container_group_size)
    next_hops_params_list = []
    # set resilient ECMP container with {22.33.0.7} next hop
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.7",
                                  WEIGHT_STR: 2})

    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # resolve next hops
    add_neigh(rif_arr[1], "22.33.0.7", NEIGH_MAC_2)
    add_neigh(rif_arr[1], "22.33.0.8", NEIGH_MAC_2)

    operational_ecmp_print(ecmp_id, container_group_size)

    # create uc route
    create_ecmp_uc_route(vrid, "100.100.129.0", "255.255.255.0", ecmp_id)

    ##########################################################
    # Traffic 192.168.1.2 <--> {22.33.0.7}
    ##########################################################
    # set resilient ECMP container with {22.33.0.7, 22.33.0.8} next hops
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.8",
                                  WEIGHT_STR: 7})

    modify_external_ecmp_container(ecmp_id, next_hops_params_list)
    ##########################################################
    # Traffic 192.168.1.2 <--> {22.33.0.7, 22.33.0.8}
    ##########################################################
    # delete all next hop uc routes
    delete_all_next_hops_uc_routes_per_vrid(vrid)

    # clear container(unbounded from routes), and change to consistent container
    modify_external_ecmp_container(ecmp_id, [])
    set_ecmp_attributes(ecmp_id, SX_ECMP_TYPE_CONSISTENT_E)
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)
    # set fine grain counters
    unbind_entire_ecmp_container(ecmp_id)

    offsets_list = [0]
    set_ecmp_container_fine_grain_counter(ecmp_id, ecmp_counter_arr[0], offsets_list)

    # create uc route
    create_ecmp_uc_route(vrid, "100.100.129.0", "255.255.255.0", ecmp_id)
    ##########################################################
    # Traffic 192.168.1.2 <--> {22.33.0.7, 22.33.0.8}
    ##########################################################

    # read and clear ecmp counters
    read_clear_ecmp_counters(ecmp_counter_arr)
    # unbind and destroy ecmp counters
    unbind_entire_ecmp_container_fine_grain(ecmp_id)

    for ecmp_counter_id in ecmp_counter_arr:
        destroy_ecmp_container_counter(ecmp_counter_id)

    # destroy router counters
    destroy_router_counter(router_counter_arr[0])
    destroy_router_counter(router_counter_arr[1])

    # delete all next hop uc routes
    delete_all_next_hops_uc_routes_per_vrid(vrid)

    # destroy external ECMP container
    destroy_ecmp_container(ecmp_id)

    # delete all neighbors per rif
    delete_all_neigh_per_rif(rif_arr[0])
    delete_all_neigh_per_rif(rif_arr[1])

    # delete all local and ip2me routes
    delete_all_local_routes(vrid)
    delete_all_ip2me_routes(vrid)

    # delete rif
    delete_rif(vrid, rif_arr[0])
    delete_rif(vrid, rif_arr[1])

######################################################
#    main
######################################################


def main():

    # init router
    router_init(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE)

    example_ecmp_hash()

    vrid = create_vrid()

    # vlan rif example
    rif_arr = example_vlan_rif_init(vrid)
    router_flow(vrid, rif_arr)
    #example_vlan_rif_deinit(vrid, rif_arr)
    # exit added by annatoly
    exit(1)

    # bridge rif example
    rif_arr, log_vport, bridge_id = example_bridge_rif_init(vrid)
    router_flow(vrid, rif_arr)
    #example_bridge_rif_deinit(bridge_id, log_vport)

    # vport rif example
    rif_arr, log_vport = example_vport_rif_init(vrid)
    router_flow(vrid, rif_arr)
    # example_vport_rif_deinit(log_vport)

    # router port rif example
    rif_arr = example_router_port_rif_init(vrid)
    router_flow(vrid, rif_arr)
    # example_router_port_rif_deinit()

    # delete vrid
    # delete_vrid(vrid)

    # deinit router
    # router_deinit()


if __name__ == "__main__":
    main()
