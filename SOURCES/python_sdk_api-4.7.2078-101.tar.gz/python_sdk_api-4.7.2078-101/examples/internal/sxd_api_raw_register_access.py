#!/usr/bin/env python

import sys
import errno

import time
import os
import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != 0):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

print("[+] Initializing variables")
raw_reg = ku_raw_reg()
raw_reg.size = 8
raw_reg.buff = new_uint8_t_arr(8)
uint8_t_arr_setitem(raw_reg.buff, 0, 0x0)
uint8_t_arr_setitem(raw_reg.buff, 1, 0x0)
uint8_t_arr_setitem(raw_reg.buff, 2, 0x0)
uint8_t_arr_setitem(raw_reg.buff, 3, 0x5)
uint8_t_arr_setitem(raw_reg.buff, 7, 0x1)


meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_SET


print("[+] Input parameter: ")
print("raw_reg: rc = %d" % (rc))
print("raw_reg: size %d" % (raw_reg.size))
print("raw_reg: buff 0x%x" % (uint8_t_arr_getitem(raw_reg.buff, 0)))
print("raw_reg: buff 0x%x" % (raw_reg.buff))

print("[+] calling sxd_access_reg_raw()")
rc = sxd_access_reg_raw(raw_reg, meta, 1, 0x90F0, None, None)

print("[+] Output parameter: ")
print("raw_reg: rc = %d" % (rc))
print("raw_reg: size %d" % (raw_reg.size))
print("raw_reg: buff 0x%x" % (uint8_t_arr_getitem(raw_reg.buff, 0)))
