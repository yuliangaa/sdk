#!/usr/bin/env python

import sys
import time
import os

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

# Due to an issue with SWIG we can't read arrays of structs
# Instead, use raw register access to get PBMC buffer statistics


def print_pbmc_buffers(port):
    pbmc_raw = ku_raw_reg()
    pbmc_raw.size = 0x70
    pbmc_raw.buff = new_uint8_t_arr(pbmc_raw.size)

    for i in range(0, pbmc_raw.size):
        uint8_t_arr_setitem(pbmc_raw.buff, i, 0x0)

    uint8_t_arr_setitem(pbmc_raw.buff, 1, port)

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_raw(pbmc_raw, meta, 1, 0x500C, None, None)
    assert rc == 0, "Failed to query PBMC register, rc: %d" % (rc)

    pg_offset = 0x0c
    show_psb = False

    for pg in range(10):
        byte_offset = pg * 8 + pg_offset
        lossy = ((uint8_t_arr_getitem(pbmc_raw.buff, byte_offset) & 0x2) >> 1)
        epsb = uint8_t_arr_getitem(pbmc_raw.buff, byte_offset) & 0x1
        size = (uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 2) << 8) | uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 3)
        print("[+] PG : ", pg)
        print("\t[+] size: ", size)
        print("\t[+] Lossy: ", lossy)
        if lossy == 0:
            print("\t[+] epsb: ", epsb)
            if epsb == 1:
                show_psb = True
            xoff_thr = (uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 4) << 8) | uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 5)
            xon_thr = (uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 6) << 8) | uint8_t_arr_getitem(pbmc_raw.buff, byte_offset + 7)
            print("\t[+] Xon: ", xon_thr)
            print("\t[+] Xoff: ", xoff_thr)

    return show_psb


parser = argparse.ArgumentParser(description='SXD-API PBMC example')
parser.add_argument('--local_port', default=1, type=int, help='Local port')
args = parser.parse_args()

local_port = args.local_port

print("[+] PBMC example start")
print("[+] Initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

pbmc = ku_pbmc_reg()
pbmc.local_port, pbmc.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

pbmc.pnat = 0

print("[+] Querying PBMC")
rc = sxd_access_reg_pbmc(pbmc, meta, 1, None, None)
assert rc == 0, "Failed to query PBMC register, rc: %d" % (rc)

print("====================")
print("[+] local port: ", pbmc.local_port)
print("[+] lp_msb: ", pbmc.lp_msb)
print("[+] Xoff timer value: ", pbmc.xof_timer_value)
print("[+] Xoff refresh: ", pbmc.xof_refresh)
print("[+] max headroom size: ", pbmc.port_buffer_size)

psb_valid = print_pbmc_buffers(pbmc.local_port)

# if psb_valid:
print("[+] port shared buffer size: ", pbmc.port_shared_buffer.size)
print("[+] port shared buffer Xon: ", pbmc.port_shared_buffer.xon_threshold)
print("[+] port shared buffer Xoff: ", pbmc.port_shared_buffer.xof_threshold)
print("[+] port shared buffer Max loan: ", pbmc.shared_headroom_pool.size)

print("[+] PBMC example end")
