#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
import os
import argparse

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib


def set_moni_reg(log_port, enable):

    sxd_access_reg_init(0, None, 4)

    moni = ku_moni_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_SET

    local_port = common_lib.get_local_port(log_port)
    moni.local_port, moni.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    moni.en = enable

    sxd_access_reg_moni(moni, meta, 1, None, None)


def unset_trap_to_netdev(trap_group):
    # Unset trap ID
    user_channel_p = new_sx_user_channel_t_p()
    user_channel = sx_user_channel_t()
    user_channel.type = SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, 0, SX_TRAP_ID_PACKET_RECEIVED, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed, [cmd = SX_ACCESS_CMD_DEREGISTER, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)

    # Set trap ID back to discard
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = SX_TRAP_ID_PACKET_RECEIVED

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_DISCARD

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_ext_set failed, [cmd = %d, rc = %d]" % (SX_ACCESS_CMD_UNSET, rc))
        sys.exit(errno.EACCES)

    # Remove trap group
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, 0, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (trap_group_unset_cmd, rc))
        sys.exit(errno.EACCES)


def set_trap_to_netdev(trap_group):
    # Trap group handling
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = 1
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = False
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, 0, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (trap_group_set_cmd, rc))
        sys.exit(errno.EACCES)
    trap_group = sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group
    print("NOTE: Created trap group ID Is %d" % trap_group)
    # SET/UNSET trap id association to the relevant trap group
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = SX_TRAP_ID_PACKET_RECEIVED

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_ext_set failed, [cmd = SX_ACCESS_CMD_SET, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)

    # Set Trap to go out on netdev
    user_channel_p = new_sx_user_channel_t_p()
    user_channel = sx_user_channel_t()
    user_channel.type = SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, 0, SX_TRAP_ID_PACKET_RECEIVED, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed, [cmd = SX_ACCESS_CMD_REGISTER, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)
    return trap_group


def set_receiver_trap_and_group(log_port, enable, trap_group):

    # Set MONI register on rx port
    set_moni_reg(log_port, enable)

    # Create Trap group, set trap ID
    if enable:
        set_trap_to_netdev(trap_group)
    else:
        unset_trap_to_netdev(trap_group)


def config_port_netdev_and_loopback(log_port, enable):

    if enable:
        phys_loopback = SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL
        netlink_cmd = "add"
    else:
        phys_loopback = SX_PORT_PHYS_LOOPBACK_DISABLE
        netlink_cmd = "delete"

    admin_state = SX_PORT_ADMIN_STATUS_DOWN
    rc = sx_api_port_state_set(handle, log_port, admin_state)

    rc = sx_api_port_phys_loopback_set(handle, log_port, phys_loopback)

    admin_state = SX_PORT_ADMIN_STATUS_UP
    rc = sx_api_port_state_set(handle, log_port, admin_state)

    cmd = "ip link %s p%x type sx_netdev port 0x%x" % (netlink_cmd, log_port, log_port)
    os.system(cmd)
    if enable:
        cmd = "ifconfig p%x up" % (log_port)
        os.system(cmd)

    print("----------------------------------------------------------")

    if enable:
        print("Created interface: ")
        cmd = "ifconfig p%x" % (log_port)
        os.system(cmd)
    else:
        print(("Interface p%x was deleted" % (log_port)))

    print("----------------------------------------------------------")


def show_port_netdev():
    print("----------------------------------------------------------")
    print("Created port interfaces list: ")
    cmd = "ifconfig | grep p10"
    os.system(cmd)
    print("----------------------------------------------------------")


parser = argparse.ArgumentParser(description='Packet receiver setup utility')
parser.add_argument("--add", help='Create Port netdev of the provided port and enable packet rx over it', action="store_true")
parser.add_argument("--delete", help='Delete Port netdev of the provided port and disable packet rx', action="store_true")
parser.add_argument("--show", help='Show all active port netdevices', action="store_true")
parser.add_argument('--log_port', default=0, type=common_lib.auto_int, help='Logical port ID')
parser.add_argument('--trap_group', default=17, type=common_lib.auto_int, help='Trap group ID. Note that for new allocation mode you must provide explicit ID On delete')
args = parser.parse_args()
if args.add:
    enable = 1
if args.delete:
    enable = 0
if args.log_port == 0 and args.show == 0:
    print("Please provide --log_port parameter.")
    sys.exit(0)
else:
    log_port = args.log_port

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

trap_group_set_cmd, trap_group_unset_cmd = common_lib.trap_group_set_unset_cmd_get(handle)
if (args.show == 0):
    config_port_netdev_and_loopback(log_port, enable)
    set_receiver_trap_and_group(log_port, enable, args.trap_group)
else:
    show_port_netdev()


""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
