#!/usr/bin/env python

import sys
import errno
import time
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse

STATUS_UNKNOWN = "unknown"
NOT_APPLICABLE = "N/A"
RESERVED = "Reserved"
adm_st_dict = {1: "enabled",
               2: "disabled by configuration",
               3: "enabled_once"}
oper_st_dict = {0: "initializing",
                1: "plugged enabled",
                2: "unplugged",
                3: "plugged with error",
                4: "plugged disabled"
                }
oper_notif_dict = {0: "no notifications",
                   1: "speed degradation"
                   }
error_type_dict = {0: "power budged exceeded",
                   1: "long range for non MLX cable or module",
                   2: "bus stuck",
                   3: "bad or unsupported EEPROM",
                   4: "enforce part num list",
                   5: "unsupported cable",
                   6: "high temp",
                   7: "bad cable - module/cable is shorted",
                   8: "PMD type is not enabled(chk PMTPS reg)",
                   9: "Laser TEC Failure",
                   10: "high current",
                   11: "high voltage",
                   12: "PCIE system power slot exceeded",
                   13: "high power",
                   14: "module state machine fault",
                   }


def validate_module(module):
    if module > 255:
        print("====================")
        print("Invalid Module Id: ", module)
        print("Module Id must be less than 255")
        print("====================")
        sys.exit(errno.EACCES)
    else:
        return module


def validate_slot(slot):
    if slot > 8:
        print("====================")
        print("Invalid Slot Id: ", slot)
        print("Slot Id must be in the range 1-8")
        print("====================")
        sys.exit(errno.EACCES)

    else:
        # as of today, we do not support modular system. So slot must be 0
        return 0


def convert_operation_to_pmaos_operation(oper):
    if oper == 'insert':
        admin_st = 0x1  # no macros in SDK available
    else:
        admin_st = 0xE  # no macros in SDK available

    return admin_st


def print_pmaos_reg(pmaos_reg):

    print("=====PMAOS REGISTER============")
    print("[+] Module       :", pmaos_reg.module)
    print("[+] Slot Index   :", pmaos_reg.slot_index)
    if pmaos_reg.admin_status in list(adm_st_dict.keys()):
        print("[+] Admin Status :", adm_st_dict[pmaos_reg.admin_status])
    else:
        print("[+] Admin Status :", STATUS_UNKNOWN)
    if pmaos_reg.admin_status == 1:
        if pmaos_reg.oper_status in list(oper_st_dict.keys()):
            print("[+] Oper Status  :", oper_st_dict[pmaos_reg.oper_status])
        else:
            print("[+] Oper Status  :", STATUS_UNKNOWN)
    else:
        print("[+] Oper Status  :", RESERVED)
    if pmaos_reg.oper_status == 1:
        if pmaos_reg.operational_notification in list(oper_notif_dict.keys()):
            print("[+] Oper Notif   :", oper_notif_dict[pmaos_reg.operational_notification])
        else:
            print("[+] Oper Notif   :", STATUS_UNKNOWN)
    else:
        print("[+] Oper Notif   :", RESERVED)
    if pmaos_reg.oper_status == 3:
        if pmaos_reg.error_type in list(error_type_dict.keys()):
            print("[+] Error Type   :", error_type_dict[pmaos_reg.error_type])
        else:
            print("[+] Error Type   :", STATUS_UNKNOWN)
    else:
        print("[+] Error Type   :", RESERVED)
    print("[+] e            :", pmaos_reg.e)
    print("=============END===============")


parser = argparse.ArgumentParser(description='SXD-API PMAOS debug script to simulate port insertion/removal')
parser.add_argument('--module', default=1, type=int, help='Module id')
parser.add_argument('--slot', default=0, type=int, help='Slot Index')
parser.add_argument('--operation', choices=['insert', 'remove'], required=True, help='Operation to simulate')
args = parser.parse_args()


module = validate_module(args.module)
slot = validate_slot(args.slot)
admin_status = convert_operation_to_pmaos_operation(args.operation)

print("[+] PMOAS debug utility start")
print("[+] Initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_SET

pmaos = ku_pmaos_reg()
pmaos.module = module
pmaos.slot_index = slot
pmaos.admin_status = admin_status
pmaos.ase = SXD_PMAOS_ADMIN_STATE_ENABLE
pmaos.e = SXD_PORT_EVENT_GENERATE_MODE_GENERATE_SINGLE  # 2 = generate single event
pmaos.ee = SXD_PMAOS_EVENT_ENABLE  # 1 = Event update Enable

print("*** Setting PMAOS Register ***")
print_pmaos_reg(pmaos)
rc = sxd_access_reg_pmaos(pmaos, meta, 1, None, None)
assert rc == 0, "Failed to set pmaos register, rc: %d" % (rc)

print("*** Reading PMAOS Register ***")
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_pmaos(pmaos, meta, 1, None, None)
assert rc == 0, "Failed to set pmaos register, rc: %d" % (rc)
print_pmaos_reg(pmaos)
