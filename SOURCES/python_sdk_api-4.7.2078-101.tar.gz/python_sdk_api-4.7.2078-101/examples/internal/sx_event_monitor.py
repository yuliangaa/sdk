#!/usr/bin/env python
'''
This file contains Python command example for event monitor in debugfs.

This is a application example script that allows the user to recived event on the fly
'''

import sys
import errno
import os
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse


# Event array
__event_array = [
    # HW/FW EVENTS
    SXD_TRAP_ID_FSHE, SXD_TRAP_ID_MFDE, SXD_TRAP_ID_MOCS_DONE,
    SXD_TRAP_ID_PPCNT, SXD_TRAP_ID_MGPCB, SXD_TRAP_ID_PBSR, SXD_TRAP_ID_SBSRD,
    SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED, SXD_TRAP_ID_MAFBI, SXD_TRAP_ID_ACCU_FLOW_INC,
    SX_TRAP_ID_PTP_CLOCK_PPS_EVENT, SX_TRAP_ID_PUDE, SX_TRAP_ID_SDK_HEALTH_EVENT,
    SX_TRAP_ID_PMPE, SXD_TRAP_ID_IPAC_DONE, SXD_TRAP_ID_FSED, SXD_TRAP_ID_MOFRB,

    # SDK EVENTS
    SX_TRAP_ID_SIGNAL, SX_TRAP_ID_NEW_DEVICE_ADD, SX_TRAP_ID_NEED_TO_RESOLVE_ARP,
    SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP, SX_TRAP_ID_FDB_EVENT, SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT,
    SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT, SX_TRAP_ID_FDB_SRC_MISS, SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY,
    SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT, SX_TRAP_ID_ROUTER_MC_ACTIVITY, SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY,
    SX_TRAP_ID_TRANSACTION_ERROR, SX_TRAP_ID_BFD_TIMEOUT_EVENT, SX_TRAP_ID_BFD_PACKET_EVENT,
    SX_TRAP_ID_OBJECT_DELETED_EVENT, SX_TRAP_ID_PORT_PROFILE_APPLY_DONE, SX_TRAP_ID_API_LOGGER_EVENT,
    SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, SX_TRAP_ID_PORT_ADDED, SX_TRAP_ID_PORT_DELETED,
    SX_TRAP_ID_PORT_ADDED_TO_LAG, SX_TRAP_ID_PORT_REMOVED_FROM_LAG, SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT,
    SX_TRAP_ID_ACL_ACTIVITY
]

def main():
    # Initialize variables
    handle = None
    rc = None
    sx_fd = None
    event_monitor_file_p = None
    event_id = 0

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.sys.exit(rc)

    print("[+] opening host ifc recv fd")
    rx_fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, rx_fd_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_open failed, rc %d" % rc)
        sys.exit(rc)

    uc_p = new_sx_user_channel_t_p()
    uc_p.type = SX_USER_CHANNEL_TYPE_FD
    uc_p.channel.fd = rx_fd_p

    cmd = SX_ACCESS_CMD_REGISTER

    print("[+] register all events to recv_fd")
    for event_id in range(len(__event_array)):
        rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, 0, __event_array[event_id], uc_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_host_ifc_trap_id_register_set failed, rc %d" % rc)
            sys.exit(rc)

    # Open event monitor file
    print("[+] open event monitor file")
    with open("/var/log/sdk_dbg/event_monitor.txt", "a+") as event_monitor_file_p:
        if event_monitor_file_p is None:
            print("ERROR: File /var/log/sdk_dbg/event_monitor.txt with a+ failed to open")
            sys.exit(1)

        event_monitor_file_p.write("=" * 50)
        event_monitor_file_p.write("\n")

        event_id = 0
        pkt_size = (12 * 1024)  # Max size 12K
        pkt_size_p = new_uint32_t_p()
        pkt = new_uint8_t_arr(pkt_size)
        recv_info_p = new_sx_receive_info_t_p()

        while True:
            uint32_t_p_assign(pkt_size_p, pkt_size)

            print("[recv] recv on fd")
            rc = sx_lib_host_ifc_recv(rx_fd_p, pkt, pkt_size_p, recv_info_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_lib_host_ifc_recv failed, rc %d" % rc)
                sys.exit(rc)

            event_monitor_file_p.write(f"================== Event num {event_id + 1} ================ :\n")
            event_id += 1
            event_monitor_file_p.write("Source log port [0x%x] \n" % recv_info_p.source_log_port)
            event_monitor_file_p.write("Trap id: [%d]\n" % recv_info_p.trap_id)
            recv_pkt_size = uint32_t_p_value(pkt_size_p)

            if (pkt_size > 0):
                for iii in range(0, recv_pkt_size):
                    if (iii and (0 == iii % 4)):
                       event_monitor_file_p.write("\n")
                    if (iii and (0 == iii % 16)):
                        print("")
                    event_monitor_file_p.write("%02x " % uint8_t_arr_getitem(pkt, iii))
                event_monitor_file_p.write("")
            event_monitor_file_p.write("\n")
            event_monitor_file_p.write("=" * 50)
            event_monitor_file_p.write("\n")

            print("[recv] recv done")

    print("[+] End of Main closing all")
    for event_id in range(len(__event_array)):
        print("[+] de-register on event_id  %d" % __event_array[event_id])
        rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, swid, __event_array[event_id], uc_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_host_ifc_trap_id_register_set failed, rc %d" % rc)
            sys.exit(rc)

    sx_api_host_ifc_close(sx_handle, sx_fd)

    sx_api_close(sx_handle)
    delete_sx_fd_t_p(sx_fd)
    if event_monitor_file_p is not None:
        event_monitor_file_p.flush()
        event_monitor_file_p.close()

if __name__ == "__main__":
    sys.exit(main())

