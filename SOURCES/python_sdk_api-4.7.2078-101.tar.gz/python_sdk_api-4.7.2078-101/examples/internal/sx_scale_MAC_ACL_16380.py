#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates N regions
    2. Creates N acls
    3. Add each acl to group
    4. adds rule to regions
    5. Bind between groups
    6. Bind head group to port
    7. Print dump
    8. Unbind head group from port
    9. Unbind between groups
    10 . Destroy groups
    11. Delete rules
    12. Destroy created acls and regions

"""
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
PORT0 = 0x1003D
PORT1 = 0x1003F
PORT2 = 0x10039
PORT3 = 0x1003B
PORT4 = 0x10035
PORT5 = 0x10037
PORT6 = 0x10031
PORT7 = 0x10033
PORT8 = 0x1002d
PORT9 = 0x1002f
PORT10 = 0x10029
PORT11 = 0x1002b
PORT12 = 0x10025
PORT13 = 0x10027
PORT14 = 0x10021
PORT15 = 0x10023
PORT16 = 0x10001
PORT17 = 0x10003
PORT18 = 0x10005
PORT19 = 0x10007
PORT20 = 0x10009
PORT21 = 0x1000b
PORT22 = 0x1000d
PORT23 = 0x1000f
PORT24 = 0x10011
PORT25 = 0x10013
PORT26 = 0x10015
PORT27 = 0x10017
PORT28 = 0x10019
PORT29 = 0x1001b
PORT30 = 0x1001d
PORT31 = 0x1001f

mac_2byte = 0

######################################################
#    functions
######################################################
# layer 2


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               SX_ACL_ACTION_TYPE_BASIC,  # SX_ACL_ACTION_TYPE_BASIC = 0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create():
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_DMAC)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def group_create(acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

    group_id = sx_acl_id_t_p_value(group_id_p)
    print("Created group %d, rc: %d" % (group_id, rc))
    for i in range(0, acls_num):
        print("acl id = %d " % sx_acl_id_t_arr_getitem(acl_id_arr, i))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def group_destroy(group_id):
    " This function destroy  flex acl key "
    group_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(group_id_p, group_id)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, group_id)

    direction = 0
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy group"

    print("Destroyed group %d, rc: %d" % (group_id, rc))
    delete_sx_acl_id_t_p(group_id_p)


def rule_set(region_id, offset, access):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 10, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_DMAC
    key_desc.key.l4_destination_port = 7
    key_desc.mask.l4_destination_port = 11

    #rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_FORWARD
    action1.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD
    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
    action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
    action2.fields.action_set_vlan.vlan_id = 6
    action3 = sx_flex_acl_flex_action_t()
    action3.type = SX_FLEX_ACL_ACTION_FORWARD
    action3.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

    #rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
    rule.action_count = 3

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    if access == SX_ACCESS_CMD_SET:
        print("Added rule offset  %d, to region %d,  rc: %d" % (offset, region_id, rc))
    else:
        print("Deleted rule offset  %d, region %d,  rc: %d" % (offset, region_id, rc))

    # delete_sx_flex_acl_key_desc_t_arr(rule.key_desc_list_p)
    # delete_sx_flex_acl_flex_action_t_arr(rule.action_list_p)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def set_50_rules(region_id):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_list = []
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(16383)

    mac_2byte = 0  # 0xfe91 0xaa,0xa0
#    print "!!!!rules cnt %x"%((mac_2byte >> 8) & 0x00ff)
#    print "!!!!!!!!!!rules cnt %x"%(mac_2byte & 0x00ff)
    for yy in range(0, 819):  # 775):
        #        print "!!!!msb %x"%((mac_2byte >> 8) & 0x00ff)
        #        print "!!!!lsb %x"%(mac_2byte & 0x00ff)
        for x in range(0, 20):
            rule = sx_flex_acl_flex_rule_t()
            rule.valid = 1
            sx_lib_flex_acl_rule_init(0, 10, rule)
            rules_list.append(rule)

            key_desc = sx_flex_acl_key_desc_t()
            key_desc.key_id = FLEX_ACL_KEY_DMAC
            local_dmac = ether_addr(0x7D, 0xfe, 0x91, 0x80, (mac_2byte >> 8) & 0xff, mac_2byte & 0xff)
            key_desc.key.dmac = local_dmac
            local_dmac_mask = ether_addr(0xff, 0xff, 0xff, 0xff, 0xff, 0xff)
            key_desc.mask.dmac = local_dmac_mask
            mac_2byte += 1

            sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
            rule.key_desc_count = 1

            action1 = sx_flex_acl_flex_action_t()
            action1.type = SX_FLEX_ACL_ACTION_FORWARD
            action1.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD

            sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
            rule.action_count = 1  # 2 + x%2;

            sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x + (yy * 20)])
        offsets_list = new_sx_acl_rule_offset_t_arr(25)

        for x in range(0, 20):
            sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x + (yy * 20))  # +(yy*20)

        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rule_arr,  # rules_list[0], #[idx],
                                       20)
        assert SX_STATUS_SUCCESS == rc, "Failed to add rule"
#        delete_sx_acl_rule_offset_t_arr(offsets_list)
#        print "!!!!delete rule_arr"
#        delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
#    for x in xrange(0, 16):
#        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x+16)
#
#    rc = sx_api_acl_flex_rules_set(handle,
#                               SX_ACCESS_CMD_SET,
#                               region_id,
#                               offsets_list,
#                               rule_arr,
#                               16)
#    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"
#
#    for x in xrange(0, 16):
#        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x+32)
#
#    rc = sx_api_acl_flex_rules_set(handle,
#                               SX_ACCESS_CMD_SET,
#                               region_id,
#                               offsets_list,
#                               rule_arr,
#                               16)
#    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"


def get_50_rules(region_id):

    offsets_list = new_sx_acl_rule_offset_t_arr(50)
    print("defore first rules get")
    #sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 10)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(50)
    rules_list = []
    check_rules_list = []

    for x in range(0, 48):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 10, rule)
        rules_list.append(rule)
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x])

    print("before first rules get")
    rules_cnt = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt, 0)
    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   None,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule"
    cnt = uint32_t_p_value(rules_cnt)
    print("the rule get is cnt = %d,  rc: %d" % (cnt, rc))
    assert cnt == 48, "the count wrong"

    print("get the counters of each rule")

    rule_arr_2 = new_sx_flex_acl_flex_rule_t_arr(50)
    rule = sx_flex_acl_flex_rule_t()
    rule.key_desc_list_p = None
    rule.action_list_p = None
    rule.valid = 1
    for x in range(0, 48):
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr_2, x, rule)

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr_2,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("rules cnt %d" % (cnt))
    for x in range(0, 48):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr_2, x)
        print("aaction count %d, key count %d, rule idx %d" % (rule_get.action_count, rule_get.key_desc_count, x))
        assert rule_get.action_count == (2 + x % 2)
        assert rule_get.key_desc_count == 1

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("rules cnt %d" % (cnt))
    rule_get = sx_flex_acl_flex_rule_t()
    for x in range(0, 48):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr, x)
        key_desc = sx_flex_acl_key_desc_t_arr_getitem(rule_get.key_desc_list_p, 0)
        print("x are %d" % (x))
        print(" key_desc.key.l4_destination_port = %d" % (key_desc.key.l4_destination_port))
        assert key_desc.key.l4_destination_port == (7 + x % 16)
        assert key_desc.mask.l4_destination_port == (11 + x % 16)

        action1 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 0)
        action2 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 1)
        assert action1.type == SX_FLEX_ACL_ACTION_FORWARD
        assert action2.type == SX_FLEX_ACL_ACTION_SET_VLAN
        if (x % 2):
            action3 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 2)
            assert action3.type == SX_FLEX_ACL_ACTION_FORWARD
            assert action3.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

        assert action1.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD
        assert action2.fields.action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH

        offset = sx_acl_rule_offset_t_arr_getitem(offsets_list, x)
        assert offset == x


def group_bind_get(group_id_prev):
    "the exapmple gets the group bind in context prev->next and return next group id"
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_bind_get(handle,
                                   group_id_prev,
                                   group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind between groups"

    group_id_next = sx_acl_id_t_p_value(group_id_p)
    print("group %d bound to group %d  rc: %d" % (group_id_prev, group_id_next, rc))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id_next


def main():
    "the exapmple uses predefined function to bind group to region "
    direction = 0
    group_list = []
    acl_list = []
    region_list = []

    key_handle = key_create()

    for i in range(0, 1):
        region_id = region_create(key_handle, 16383)
        region_list.append(region_id)

        acl_id = acl_create(region_id, direction)
        acl_list.append(acl_id)

        acl_id_arr = new_sx_acl_id_t_arr(5)
        sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)

        group_id = group_create(acl_id_arr, 1, 0)
        group_list.append(group_id)

        # the rule hard coded now with action discard
#        rule_set(region_id, 0, SX_ACCESS_CMD_SET)

#    rc = sx_api_acl_group_bind_set(handle,
#                                    SX_ACCESS_CMD_BIND,
#                                    group_list[0],
#                                    group_list[1]);
#    assert SX_STATUS_SUCCESS == rc, "Failed to bind between groups"
#    print "group %d bound to group %d  rc: %d" %(group_list[0], group_list[1],  rc)
    # bind port to existing group
    port = PORT1
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  port,
                                  group_list[0])
    print("port %d bound to group %d  rc: %d" % (port, group_id, rc))

    set_50_rules(region_list[0])
#    sx_api_dbg_generate_dump(handle, "/rdmzsysgwork/maxims/python_sdk_api/examples/dump_log")
#    get_50_rules(region_list[0])
#
#    rc = sx_api_acl_port_bind_set(handle,
#                                                    SX_ACCESS_CMD_UNBIND,
#                                                    port,
#                                                    group_list[0]);
#    print "port %d unbound frop  group %d  rc: %d" %(port, group_id,  rc)
#    group_bind_get(group_list[0])
#
#    rc = sx_api_acl_group_bind_set(handle,
#                                                        SX_ACCESS_CMD_UNBIND,
#                                                        group_list[0],
#                                                        group_list[1]);
#    print "group %d unbound from group %d  rc: %d" %(group_list[0], group_list[1],  rc)
#
#
#    for i in xrange(0,2):
#        group_destroy(group_list[i])
#        rule_set(region_list[i], 0, SX_ACCESS_CMD_DELETE)
#        acl_destroy(acl_list[i], region_list[i])
#        region_destroy(region_list[i])
#
#    key_destroy(key_handle)

    print("finished")


if __name__ == "__main__":
    main()
