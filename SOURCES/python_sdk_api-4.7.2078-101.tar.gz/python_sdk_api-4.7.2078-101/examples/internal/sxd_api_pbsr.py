#!/usr/bin/env python

import sys
import time
import os

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

# Due to an issue with SWIG we can't read arrays of structs
# Instead, use raw register access to get PBSR buffer statistics


def print_pbsr_buffers(port, buffer_type, clear_wm):
    pbsr_raw = ku_raw_reg()
    pbsr_raw.size = 0x64
    pbsr_raw.buff = new_uint8_t_arr(pbsr_raw.size)

    for i in range(0, pbsr_raw.size):
        uint8_t_arr_setitem(pbsr_raw.buff, i, 0x0)

    uint8_t_arr_setitem(pbsr_raw.buff, 1, port)
    uint8_t_arr_setitem(pbsr_raw.buff, 3, buffer_type)
    if clear_wm:
        uint8_t_arr_setitem(pbsr_raw.buff, 4, 0x80)

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_raw(pbsr_raw, meta, 1, 0x5038, None, None)
    assert rc == 0, "Failed to query PBSR register, rc: %d" % (rc)

    pg_offset = 0x0c

    for pg in range(10):
        print("[+] PG : ", pg)
        watermark = (uint8_t_arr_getitem(pbsr_raw.buff, pg * 8 + pg_offset + 2) << 8) | uint8_t_arr_getitem(pbsr_raw.buff, pg * 8 + pg_offset + 3)
        print("[+] watermark: ", watermark)
        used = (uint8_t_arr_getitem(pbsr_raw.buff, pg * 8 + pg_offset + 6) << 8) | uint8_t_arr_getitem(pbsr_raw.buff, pg * 8 + pg_offset + 7)
        print("[+] used_buffer: ", used)


parser = argparse.ArgumentParser(description='SXD-API PBSR example')
parser.add_argument('--local_port', default=1, type=int, help='Local port')
parser.add_argument('--buffer_type', default=0, type=int, help='buffer type')
parser.add_argument('--clear_wm', default=0, type=int, help='Clear Watermarks')
args = parser.parse_args()

local_port = args.local_port


print("[+] PBSR example start")
print("[+] Initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

pbsr = ku_pbsr_reg()
pbsr.local_port, pbsr.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

pbsr.buffer_type = args.buffer_type
pbsr.clear_wm = 0

print("[+] Querying PBSR")
rc = sxd_access_reg_pbsr(pbsr, meta, 1, None, None)
assert rc == 0, "Failed to query PBSR register, rc: %d" % (rc)

print("====================")
print("[+] local port: ", pbsr.local_port)
print("[+] lp_msb: ", pbsr.lp_msb)
print("[+] Used shared headroom buffer: ", pbsr.used_shared_headroom_buffer)

print_pbsr_buffers(local_port, args.buffer_type, args.clear_wm)

print("[+] port shared headroom pool: ")
print("[+] watermark: ", pbsr.stat_shared_headroom_pool.watermark)
print("[+] used_buffer: ", pbsr.stat_shared_headroom_pool.used_buffer)

print("[+] PBSR example end")
