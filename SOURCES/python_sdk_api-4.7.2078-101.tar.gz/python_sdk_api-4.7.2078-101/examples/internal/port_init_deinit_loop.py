#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration port split / uspilt flow.
'''

import argparse
import sys
import errno
import time
import os

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *

LIB_ROOT = os.path.join(os.path.abspath(__file__)[:os.path.abspath(__file__).find('internal')])
if LIB_ROOT not in sys.path:
    sys.path.append(LIB_ROOT)
from test_infra_common import *
######################################################
#    Defines
######################################################
SWID = 0
DEVICE_ID = 1

######################################################
#    Handle input params
######################################################
def parse_args():

    description_str = """ This is an example of port init/deinit \n
                          the example will invoke init deinit api sequence in a loop to the port list input (--ports)
                          according to the number of iterations (--iter) """

    parser = argparse.ArgumentParser(description = description_str)
    parser.add_argument('--ports',default = "0x10001", type=auto_int, nargs='+', help='logical ports - to unmap')
    parser.add_argument('--iter',default = 1, type=auto_int, help='number of iterations to init/deinit the port list')
    return parser.parse_args()

def get_device_id_and_rev():
    mgir = ku_mgir_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = SWID
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert 0 == rc

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision

def get_chip_type():
    print("Retrieving Chip Type from SDK")
    device_id, _ = get_device_id_and_rev()

    if device_id == 0xCB84:
        print("[+] Running over SPECTRUM chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM
    elif device_id == 0xCF6C:
        print("[+] Running over SPECTRUM2 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM2
    elif device_id == 0xCF70:
        print("[+] Running over SPECTRUM3 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM3
    elif device_id == 0xCF80:
        print("[+] Running over SPECTRUM4 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM4
    elif device_id == 0xCF82:
        print("[+] Running over SPECTRUM5 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM5
    else:
        print("--ERROR-- chip type is not supported!")
        sys.exit(errno.EACCES)

    return _chip_type

def port_admin_speed_10G_set(handle, port):
    print(("Setting port rate for port 0x%x\n" % (port)))
    admin_speed_p = new_sx_port_speed_capability_t_p()
    admin_speed_p.mode_10GB_CR = 1
    admin_speed_p.mode_10GB_CX = 1
    admin_speed_p.mode_10GB_SR = 1
    admin_speed_p.mode_10GB_KR = 1
    admin_speed_p.mode_10GB_ER_LR = 1
    admin_speed_p.mode_auto = 0
    admin_speed_p.force = 0

    rc = sx_api_port_speed_admin_set(handle, port, admin_speed_p)
    assert SX_STATUS_SUCCESS == rc
    print(("[+] 10G speed is configured for log_port: 0x%x." % (port)))

def port_rate_configuration(handle, port):
    # Went through the admin_rate list and enable appropriate values
    rate_bitmask_p = new_sx_port_rate_bitmask_t_p()
    rate_bitmask_p.rate_100M = True
    rate_bitmask_p.rate_1G = True
    rate_bitmask_p.rate_10G = True
    rate_bitmask_p.rate_25G = True
    rate_bitmask_p.rate_40G = True
    rate_bitmask_p.rate_50G = True
    rate_bitmask_p.rate_100G = True
    rate_bitmask_p.rate_200G = True
    rate_bitmask_p.rate_400G = False
    rate_bitmask_p.rate_800G = False
    rate_bitmask_p.rate_auto = False
    rate_bitmask_p.force = False  # Note that this option may be enabled only for single rate value

    rc = sx_api_port_rate_set(handle, port, rate_bitmask_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to set port admin rate."

    print(("[+] Rate and PMD type is configured for log_port: 0x%x." % (port)))

def add_ports_to_vlan(handle, vlan_id, ports_dict):
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SWID, vlan_id, port_list, len(ports_dict))
    assert rc == SX_STATUS_SUCCESS, "Failed to add port into the VLAN."

def ports_mapping_attr_get(handle, port):
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    port_mapping_list_arr = new_sx_port_mapping_t_arr(1)
    port_cnt = 1

    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)
    rc = sx_api_port_mapping_get(handle, log_port_list_arr, port_mapping_list_arr, port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to get port mapping attributes."

    port_mapping_att = sx_port_mapping_t_arr_getitem(port_mapping_list_arr, 0)
    return port_mapping_att.module_port, port_mapping_att.width, port_mapping_att.lane_bmap

def rstp_port_state_set(handle, log_port, mstp_state):
    rc = sx_api_rstp_port_state_set(handle, log_port, mstp_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure RSTP port state."

def ports_mapping_info(handle, port):

    module_port, width, lane_bmap = ports_mapping_attr_get(handle, port)
    print(("[+] log_port:0x%x width: %d lane_bmap: 0x%x module_port: %d" % (port, width, lane_bmap, module_port)))

def port_swid_bind_set(handle, port, swid):
    rc = sx_api_port_swid_bind_set(handle, port, swid)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."

def port_swid_bind_get(handle, port):
    sx_swid_p = new_sx_swid_t_p()
    rc = sx_api_port_swid_bind_get(handle, port, sx_swid_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."
    swid = sx_swid_t_p_value(sx_swid_p)
    return swid

def port_state_set(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to change port state."

def port_init_handle(handle, port, is_init=True):
    if is_init:
        rc = sx_api_port_init_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to init port"
    else:
        rc = sx_api_port_deinit_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to de-init port"

def port_unmapping_set(handle, port, log_port_cnt=1):
    log_port_list_arr = new_sx_port_log_id_t_arr(log_port_cnt)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(log_port_cnt)
    mapping_item = new_sx_port_mapping_t_arr(1)
    module_id, _, _ = ports_mapping_attr_get(handle, port)

    for i in range(0, log_port_cnt):
        mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, i)
        mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
        mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE
        mapping_item.module_port = module_id
        mapping_item.slot = 0
        mapping_item.width = 0
        mapping_item.lane_bmap = 0

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, log_port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable mapping."

def port_mapping_attr_set(handle, port, module, lane_bmap, width):
    print(("[+] port_mapping_attr_set: port:0x%x module:%d lane_bmap:0x%x" % (port, module, lane_bmap)))
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(1)
    mapping_item = new_sx_port_mapping_t_arr(1)

    mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, 0)
    mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
    mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE
    mapping_item.width = width
    mapping_item.module_port = module
    mapping_item.slot = 0
    mapping_item.lane_bmap = lane_bmap

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, 1)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure port mapping."

def port_map_init(handle, port, module_port, width, lane_bmap):

    bind_swid = SWID
    vlan = 1

    # port remapp and up
    port_mapping_attr_set(handle, port, module_port, lane_bmap, width)

    port_swid_bind_set(handle, port, bind_swid)

    port_init_handle(handle, port, is_init=True)

    chip_type = get_chip_type()

    if chip_type == SX_CHIP_TYPE_SPECTRUM:
        # set port speed - use legacy APIs, 10G
        port_admin_speed_10G_set(handle, port)
    else:
        port_rate_configuration(handle, port)

    rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)

    # add configured ports into the specified below VLAN

    add_ports_to_vlan(handle, vlan, {port: SX_UNTAGGED_MEMBER})

    port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)

    print(("[+] port_map_init: port:0x%x initiated successfully" % (port)))
    # Print new port mapping attributes
    ports_mapping_info(handle, port)

def port_unmap_deinit(handle, port):

    # port down and unmap
    # ports must be in DOWN state
    un_bind_swid = 255
    port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    # de-init ports
    port_init_handle(handle, port, is_init=False)
    # un-bind ports
    port_swid_bind_set(handle, port, un_bind_swid)
    # disable mapping
    port_unmapping_set(handle, port)

    print(("[+] port_unmap_deinit: port:0x%x deinit successfully" % (port)))
    # Print new port mapping attributes
    ports_mapping_info(handle, port)

def ports_init_deinit_set_example(handle):

    args = parse_args()
    ports_list = args.ports

    for i, port in enumerate(ports_list):
        print(("ports[%d]: 0x%x" % (i, port)))

    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    for port in ports_list:

        swid = port_swid_bind_get(handle, port)
        print(("[+] port:0x%x swid:%d" % (port, swid)))
        if swid != SWID:
            print(("[+] Skipping port:0x%x as its unbounded to swid:%d" % (port, SWID)))
            continue

        module_port, width, lane_bmap = ports_mapping_attr_get(handle, port)

        port_unmap_deinit(handle, port)

        port_map_init(handle, port, module_port, width, lane_bmap)



################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":

    args = parse_args()
    iter = args.iter

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("[+] sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    for j in range(iter):
        ports_init_deinit_set_example(handle)
