#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_sb_example')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)
#######################################################
######################################################
#    defines
######################################################
shared_buffer_attr = sx_cos_port_shared_buffer_attr_t()
shared_buffer_attr_p = new_sx_cos_port_shared_buffer_attr_t_p()

pool_attr = sx_cos_pool_attr_t()
pool_attr_p = new_sx_cos_pool_attr_t_p()
pool_id_p = new_uint32_t_p()

port_list = mapPortAndInterfaces(handle)

######################################################
#    Functions
######################################################


def create_data_pool(size, mode, dir):
    global pool_attr
    global pool_attr_p
    pool_attr.pool_dir = dir
    pool_attr.pool_size = size
    pool_attr.mode = mode
    pool_attr.buffer_type = SX_COS_DATA_BUFFER_E
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_CREATE, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)

    shared_headroom_pool_id = uint32_t_p_value(pool_id_p)
    return shared_headroom_pool_id


def create_shared_headroom_pool(size):
    global pool_attr
    global pool_attr_p
    pool_attr.pool_dir = SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E
    pool_attr.pool_size = size
    pool_attr.mode = SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E
    pool_attr.buffer_type = SX_COS_SHARED_HEADROOM_BUFFER_E
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_CREATE, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)

    shared_headroom_pool_id = uint32_t_p_value(pool_id_p)
    return shared_headroom_pool_id


def destroy_shared_headroom_pool(handle, pool_id):
    pool_attr = sx_cos_pool_attr_t()
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    pool_id_p = new_uint32_t_p()

    pool_attr.pool_dir = 0
    pool_attr.pool_size = 0
    pool_attr.mode = 0
    pool_attr.buffer_type = 0
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    uint32_t_p_assign(pool_id_p, pool_id)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_DESTROY, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)


def set_port_pg_shared_size(port, pg, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.pg = pg
    shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Ingress Port = 0x%x, PG = %d, pool = %d, size = %d" % (port, shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.pg,
                                                                       shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.pool_id,
                                                                       shared_buffer_attr.attr.ingress_port_pg_shared_buff_attr.max.max.size)))


def set_port_tc_shared_size(port, tc, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.tc = tc
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Ingress Port = 0x%x, TC = %d, pool = %d, size = %d" % (port, shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.tc,
                                                                       shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.pool_id,
                                                                       shared_buffer_attr.attr.egress_port_tc_shared_buff_attr.max.max.size)))


def set_ingress_port_pool_shared_size(port, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_INGRESS_PORT_ATTR_E
    shared_buffer_attr.attr.ingress_port_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.ingress_port_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.ingress_port_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Ingress Port.pool- Port = 0x%x, pool = %d, size = %d" % (port, shared_buffer_attr.attr.ingress_port_shared_buff_attr.pool_id,
                                                                         shared_buffer_attr.attr.ingress_port_shared_buff_attr.max.max.size)))


def set_egress_port_pool_shared_size(port, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_EGRESS_PORT_ATTR_E
    shared_buffer_attr.attr.egress_port_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.egress_port_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.egress_port_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Egress Port.pool- Port = 0x%x, pool = %d, size = %d" % (port, shared_buffer_attr.attr.egress_port_shared_buff_attr.pool_id,
                                                                        shared_buffer_attr.attr.egress_port_shared_buff_attr.max.max.size)))


def set_egress_port_pool_mc_shared_size(port, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_MULTICAST_PORT_ATTR_E
    shared_buffer_attr.attr.multicast_port_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.multicast_port_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.multicast_port_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, port, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Egress Port.pool(MC)- Port = 0x%x, pool = %d, size = %d" % (port, shared_buffer_attr.attr.multicast_port_shared_buff_attr.pool_id,
                                                                            shared_buffer_attr.attr.multicast_port_shared_buff_attr.max.max.size)))


def set_egress_mc_sp_shared_size(sp, pool, size, max_mode):
    global shared_buffer_attr
    global shared_buffer_attr_p
    shared_buffer_attr.type = SX_COS_MULTICAST_ATTR_E
    shared_buffer_attr.attr.multicast_shared_buff_attr.sp = sp
    shared_buffer_attr.attr.multicast_shared_buff_attr.pool_id = pool
    shared_buffer_attr.attr.multicast_shared_buff_attr.max.mode = max_mode
    shared_buffer_attr.attr.multicast_shared_buff_attr.max.max.size = size
    sx_cos_port_shared_buffer_attr_t_p_assign(shared_buffer_attr_p, shared_buffer_attr)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, SX_MC_PORT_LOG_ID, shared_buffer_attr_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_port_shared_buff_type_set failed, rc = %d\n" % (rc)
    print(("SET Egress (MC.SP)- SP = %d, pool = %d, size = %d" % (shared_buffer_attr.attr.multicast_shared_buff_attr.sp,
                                                                  shared_buffer_attr.attr.multicast_shared_buff_attr.pool_id,
                                                                  shared_buffer_attr.attr.multicast_shared_buff_attr.max.max.size)))


def cos_port_shared_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)
    assert(port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt

##############################################################################################################


# save created pools in a list for a later de-configuration
pools_list = []

# INGRESS POOLS
# Create Shared headroom pool
shared_headroom_pool_id = create_shared_headroom_pool(1000)
print(("Shared headroom Pool ID = %d" % (shared_headroom_pool_id)))
pools_list.append(shared_headroom_pool_id)

# Create static (buffer units) pools
ingress_static_buffer_unit_pool_id = create_data_pool(50000, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E, SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E)
print(("Ingress static (buffer unit) Pool ID = %d" % (ingress_static_buffer_unit_pool_id)))
pools_list.append(ingress_static_buffer_unit_pool_id)

# Create static (Percentage) pools
ingress_static_percentage_pool_id = create_data_pool(50000, SX_COS_BUFFER_MAX_MODE_STATIC_E, SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E)
print(("Ingress static (percentage) Pool ID = %d" % (ingress_static_percentage_pool_id)))
pools_list.append(ingress_static_percentage_pool_id)

# Create Dynamic pools
ingress_dynamic_pool_id = create_data_pool(50000, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E, SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E)
print(("Ingress dynamic Pool ID = %d" % (ingress_dynamic_pool_id)))
pools_list.append(ingress_dynamic_pool_id)

# EGRESS POOLS
# Create static (buffer units) pools
egress_static_buffer_unit_pool_id = create_data_pool(60000, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E, SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E)
print(("Egress static (buffer unit) Pool ID = %d" % (egress_static_buffer_unit_pool_id)))
pools_list.append(egress_static_buffer_unit_pool_id)

# Create static (Percentage) pools
egress_static_percentage_pool_id = create_data_pool(60000, SX_COS_BUFFER_MAX_MODE_STATIC_E, SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E)
print(("Egress static (percentage) Pool ID = %d" % (egress_static_percentage_pool_id)))
pools_list.append(egress_static_percentage_pool_id)

# Create Dynamic pools
egress_dynamic_pool_id = create_data_pool(60000, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E, SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E)
print(("Egress dynamic Pool ID = %d" % (egress_dynamic_pool_id)))
pools_list.append(egress_dynamic_pool_id)

##############################################################################################################

PORT1 = port_list[0]

# Save these for a later de-configuration
original_port1_buff_attr_list, original_port1_buff_attr_cnt = cos_port_buff_get_all(handle, PORT1)
original_port1_sb_attr_list, original_port1_sb_attr_cnt = cos_port_shared_buff_get_all(handle, PORT1)

# iPort.pool configuration
# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) ingress pool
set_ingress_port_pool_shared_size(PORT1, ingress_static_buffer_unit_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)

# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (percentage) ingress pool
set_ingress_port_pool_shared_size(PORT1, ingress_static_percentage_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_STATIC_E)

# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new dynamic ingress pool
set_ingress_port_pool_shared_size(PORT1, ingress_dynamic_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E)

# ePort.pool configuration
# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) ingress pool
set_egress_port_pool_shared_size(PORT1, egress_static_buffer_unit_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)

# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (percentage) ingress pool
set_egress_port_pool_shared_size(PORT1, egress_static_percentage_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_STATIC_E)

# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new dynamic ingress pool
set_egress_port_pool_shared_size(PORT1, egress_dynamic_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E)

# ePort.pool[15]MC configuration
# Set size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) ingress pool
mc_pool = 10
set_egress_port_pool_mc_shared_size(PORT1, mc_pool, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)

# MC.SP configuration
# Set sp = 1 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) Egress pool

# Save these for a later de-configuration
original_mc_port_sb_attr_list, original_mc_port_sb_attr_cnt = cos_port_shared_buff_get_all(handle, SX_MC_PORT_LOG_ID)
sp = 1
set_egress_mc_sp_shared_size(sp, egress_static_buffer_unit_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)


# PG configuration
# Set PG = 0 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) ingress pool
pg = 0
set_port_pg_shared_size(PORT1, pg, ingress_static_buffer_unit_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)

# Set PG = 1 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (percentage) ingress pool
pg = 1
set_port_pg_shared_size(PORT1, pg, ingress_static_percentage_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_STATIC_E)

# Set PG = 2 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new dynamic ingress pool
pg = 2
set_port_pg_shared_size(PORT1, pg, ingress_dynamic_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E)


# TC configuration
# Set TC = 0 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (buffer units) ingress pool
tc = 0
set_port_tc_shared_size(PORT1, tc, egress_static_buffer_unit_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E)

# Set TC = 1 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new static (percentage) ingress pool
tc = 1
set_port_tc_shared_size(PORT1, tc, egress_static_percentage_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_STATIC_E)

# Set TC = 2 size=SX_COS_SB_STATIC_BUFF_INFINIT_VAL bound to pool=new dynamic ingress pool
tc = 2
set_port_tc_shared_size(PORT1, tc, egress_dynamic_pool_id, 0xFFFFFFFF, SX_COS_BUFFER_MAX_MODE_DYNAMIC_E)


##############################################################################################################

PORT2 = port_list[1]

# Save these for a later de-configuration
original_port2_buff_attr_list, original_port2_buff_attr_cnt = cos_port_buff_get_all(handle, PORT2)
original_port2_sb_attr_list, original_port2_sb_attr_cnt = cos_port_shared_buff_get_all(handle, PORT2)


""" PORT TYPE BUFF SET """
print("---------------  PORT TYPE BUFF SET (MIN) ------------------------------")
count = 1
""" CMD_SET = 15 """
cmd = 15
""" CMD_DELETE = 3 """
""" cmd = 3 """
port_buffer_attr_cnt = count
port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)

for i in range(0, port_buffer_attr_cnt):
    attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
    """ Set type and relevant parameters """
    attr_item_min.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E

    print("[%d] type = %d" % (i, attr_item_min.type))
    if attr_item_min.type == SX_COS_INGRESS_PORT_ATTR_E:
        attr_item_min.attr.ingress_port_buff_attr.size = 15
        attr_item_min.attr.ingress_port_buff_attr.pool_id = 0
        print("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.size))
        print("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.pool_id))

    if attr_item_min.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
        attr_item_min.attr.ingress_port_pg_buff_attr.size = 20
        attr_item_min.attr.ingress_port_pg_buff_attr.pg = 1
        """ is_lossy: 0=Lossless, 1=Lossy """
        attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy = 1
        attr_item_min.attr.ingress_port_pg_buff_attr.xon = 0
        attr_item_min.attr.ingress_port_pg_buff_attr.xoff = 0
        attr_item_min.attr.ingress_port_pg_buff_attr.pool_id = 0
        attr_item_min.attr.ingress_port_pg_buff_attr.pipeline_latency.override_default = False
        print("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.size))
        print("[%d] PG    = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pg))
        print("[%d] is_lossy (0=Lossless)  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy))
        print("[%d] Xon  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xon))
        print("[%d] Xoff  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xoff))
        print("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pool_id))

    if attr_item_min.type == SX_COS_EGRESS_PORT_ATTR_E:
        attr_item_min.attr.egress_port_buff_attr.size = 15
        attr_item_min.attr.egress_port_buff_attr.pool_id = 4
        print("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.size))
        print("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.pool_id))

    if attr_item_min.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        attr_item_min.attr.egress_port_tc_buff_attr.size = 15
        attr_item_min.attr.egress_port_tc_buff_attr.tc = 0
        attr_item_min.attr.egress_port_tc_buff_attr.pool_id = 4
        print("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.size))
        print("[%d] TC  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.tc))
        print("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.pool_id))

    if attr_item_min.type == SX_COS_MULTICAST_ATTR_E:
        attr_item_min.attr.multicast_buff_attr.size = 15
        attr_item_min.attr.multicast_buff_attr.sp = 5
        attr_item_min.attr.multicast_buff_attr.pool_id = 4
        print("[%d] Size  = %d" % (i, attr_item_min.attr.multicast_buff_attr.size))
        print("[%d] SP  = %d" % (i, attr_item_min.attr.multicast_buff_attr.sp))
        print("[%d] pool_id  = %d" % (i, attr_item_min.attr.multicast_buff_attr.pool_id))

    if attr_item_min.type > SX_COS_MULTICAST_ATTR_E or attr_item_min.type < SX_COS_INGRESS_PORT_ATTR_E:
        print("[%d] Unsupported union type = %d" % (i, attr_item_min.type))

rc = sx_api_cos_port_buff_type_set(handle, cmd, PORT2, attr_item_min, port_buffer_attr_cnt)
print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, PORT2, port_buffer_attr_cnt, rc))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

print("--------------------------------------------------------------------")


""" PORT TYPE BUFF GET (MIN) """
print("---------------  PORT TYPE BUFF GET (MIN) ------------------------------")
count = 2
port_buffer_attr_cnt = new_uint32_t_p()
port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)
port_buffer_attr_item = new_sx_cos_port_buffer_attr_t_arr(1)
uint32_t_p_assign(port_buffer_attr_cnt, count)

""" Set type and relevant parameters """
port_buffer_attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E

""" # ITEM #0 """
if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
    port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg = 4
    print("#### [%d] PG    = %d" % (0, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg))

sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, port_buffer_attr_item)

""" Set ITEM#1 """
if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
    port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg = 1
    print("#### [%d] PG    = %d" % (1, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg))

sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 1, port_buffer_attr_item)

rc = sx_api_cos_port_buff_type_get(handle, PORT2, port_buffer_attr_list_p, port_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
print("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, attr_cnt, rc))
print("--------------------------------------------------------------------")
for i in range(0, attr_cnt):
    port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
    print("[%d] type = %d" % (i, port_buffer_attr_item.type))

    if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
        print("[%d] Size  = %d" % (i, port_buffer_attr_item.attr.ingress_port_buff_attr.size))
        print("[%d] pool_id  = %d" % (i, port_buffer_attr_item.attr.ingress_port_buff_attr.pool_id))

    if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
        print("[%d] Size  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.size))
        print("[%d] PG    = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg))
        print("[%d] is_lossy (0=Lossless)  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.is_lossy))
        print("[%d] Xon  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xon))
        print("[%d] Xoff  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xoff))
        print("[%d] pool_id  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pool_id))

    if port_buffer_attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
        print("[%d] Size  = %d" % (i, port_buffer_attr_item.attr.egress_port_buff_attr.size))
        print("[%d] pool_id  = %d" % (i, port_buffer_attr_item.attr.egress_port_buff_attr.pool_id))

    if port_buffer_attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        print("[%d] Size  = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.size))
        print("[%d] TC  = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.tc))
        print("[%d] pool_id  = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.pool_id))

    if port_buffer_attr_item.type == SX_COS_MULTICAST_ATTR_E:
        port_buffer_attr_item.attr.multicast_buff_attr.size = 15
        port_buffer_attr_item.attr.multicast_buff_attr.sp = 5
        port_buffer_attr_item.attr.multicast_buff_attr.pool_id = 4

    if port_buffer_attr_item.type > SX_COS_MULTICAST_ATTR_E or attr_item_min.type < SX_COS_INGRESS_PORT_ATTR_E:
        print(("[%d] Unsupported union type = %d" % (i, port_buffer_attr_item.type)))


""" ############################################################################################ """
""" PORT SHARED BUFF SET """
print("---------------  PORT SHARED BUFF SET ------------------------------")
count = 1
""" CMD_SET = 15 """
cmd = 15
""" CMD_DELETE = 3 """
""" cmd = 3 """
port_shared_buffer_attr_cnt = count
port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)

for i in range(0, port_shared_buffer_attr_cnt):
    attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
    """ Set type and relevant parameters """
    attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E

    print("[%d] type = %d" % (i, attr_item.type))
    if attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
        attr_item.attr.ingress_port_shared_buff_attr.max.mode = 1
        print("[%d] pool_mode  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.mode))
        if attr_item.attr.ingress_port_shared_buff_attr.max.mode == 0:
            """ Static """
            attr_item.attr.ingress_port_shared_buff_attr.max.max.size = 15
            print("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size))
        else:
            """ Dynamic """
            attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha = 2
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha))
        attr_item.attr.ingress_port_shared_buff_attr.pool_id = 0
        print("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
        attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode = 1
        print("[%d] pool_mode  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode))
        if attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode == 0:
            """ Static """
            attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size = 20
            print("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size))
        else:
            """ Dynamic """
            attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha = 3
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha))
        attr_item.attr.ingress_port_pg_shared_buff_attr.pg = 4
        print("[%d] PG  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg))
        attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id = 0
        print("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
        attr_item.attr.egress_port_shared_buff_attr.max.mode = 1
        print("[%d] pool_mode  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.mode))
        if attr_item.attr.egress_port_shared_buff_attr.max.mode == 0:
            """ Static """
            attr_item.attr.egress_port_shared_buff_attr.max.max.size = 20
            print("[%d] Max  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size))
        else:
            """ Dynamic """
            attr_item.attr.egress_port_shared_buff_attr.max.max.alpha = 4
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.alpha))

        attr_item.attr.egress_port_shared_buff_attr.pool_id = 4
        print("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        attr_item.attr.egress_port_tc_shared_buff_attr.max.mode = 1
        print("[%d] pool_mode  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.mode))
        if attr_item.attr.egress_port_tc_shared_buff_attr.max.mode == 0:
            """ Static """
            attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size = 30
            print("[%d] Max  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size))
        else:
            """ Dynamic """
            attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha = 5
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha))

        attr_item.attr.egress_port_tc_shared_buff_attr.tc = 0
        print("[%d] TC  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc))
        attr_item.attr.egress_port_tc_shared_buff_attr.pool_id = 4
        print("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_MULTICAST_ATTR_E:
        attr_item.attr.multicast_shared_buff_attr.max.mode = 1
        print("[%d] pool_mode  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.mode))
        if attr_item.attr.multicast_shared_buff_attr.max.mode == 0:
            """ Static """
            attr_item.attr.multicast_shared_buff_attr.max.max.size = 50
            print("[%d] Max  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size))
        else:
            """ Dynamic """
            attr_item.attr.multicast_shared_buff_attr.max.max.alpha = 6
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.alpha))

        attr_item.attr.multicast_shared_buff_attr.sp = 0
        print("[%d] SP  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.sp))
        attr_item.attr.multicast_shared_buff_attr.pool_id = 4
        print("[%d] pool_id  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.pool_id))

    if attr_item.type > SX_COS_MULTICAST_ATTR_E or attr_item.type < SX_COS_INGRESS_PORT_ATTR_E:
        print("[%d] Unsupported union type = %d" % (i, attr_item.type))

rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, PORT2, attr_item, port_shared_buffer_attr_cnt)
print("sx_api_cos_port_shared_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, PORT2, port_shared_buffer_attr_cnt, rc))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

print("--------------------------------------------------------------------")


""" PORT SHARED BUFF GET """
print("---------------  PORT SHARED BUFF GET ------------------------------")
count = 2

port_shared_buffer_attr_cnt = new_uint32_t_p()
port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)
port_shared_buffer_attr_item = new_sx_cos_port_shared_buffer_attr_t_arr(1)
uint32_t_p_assign(port_shared_buffer_attr_cnt, count)

""" Set type and relevant parameters """
port_shared_buffer_attr_item.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E

""" # ITEM #0 """
if port_shared_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg = 4
    print("#### [%d] PG    = %d" % (0, port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg))

if port_shared_buffer_attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
    port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.tc = 0
    print("#### [%d] TC    = %d" % (0, port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.tc))

sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, port_shared_buffer_attr_item)

""" Set ITEM#1 """
if port_shared_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg = 0
    print("#### [%d] PG    = %d" % (1, port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg))

if port_shared_buffer_attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
    port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.tc = 7
    print("#### [%d] TC    = %d" % (0, port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.tc))

sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 1, port_shared_buffer_attr_item)

rc = sx_api_cos_port_shared_buff_type_get(handle, PORT2, port_shared_buffer_attr_list_p, port_shared_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)
print("sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, attr_cnt, rc))
print("--------------------------------------------------------------------")
for i in range(0, attr_cnt):
    attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
    print("[%d] type = %d" % (i, attr_item.type))
    if attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
        if attr_item.attr.ingress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
            """ Dynamic """
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha))
        else:
            """ Static """
            print("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size))

        print("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
        if attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
            """ Dynamic """
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha))
        else:
            """ Static """
            print("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size))

        print("[%d] PG  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg))
        print("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id))

    if attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
        if attr_item.attr.egress_port_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
            """ Dynamic """
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.alpha))
        else:
            """ Static """
            print("[%d] Max  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size))

        print("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.pool_id))
    if attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
        if attr_item.attr.egress_port_tc_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
            """ Dynamic """
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha))
        else:
            """ Static """
            print("[%d] Max  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size))

        print("[%d] TC  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc))
        print("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.pool_id))
    if attr_item.type == SX_COS_MULTICAST_ATTR_E:
        if attr_item.attr.multicast_shared_buff_attr.max.mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
            """ Dynamic """
            print("[%d] Max (Alpha) = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.alpha))
        else:
            """ Static """
            print("[%d] Max  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size))

        print("[%d] SP  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.sp))
        print("[%d] pool_id  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.pool_id))
    if attr_item.type > SX_COS_MULTICAST_ATTR_E or attr_item.type < SX_COS_INGRESS_PORT_ATTR_E:
        print("[%d] Unsupported union type = %d" % (i, attr_item.type))

if args.deinit:
    print("Deinit")
    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, original_port2_buff_attr_list,
                                       original_port2_buff_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_set failed rc = %d" % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, original_port2_sb_attr_list,
                                              original_port2_sb_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_set failed rc = %d" % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, original_port1_buff_attr_list,
                                       original_port1_buff_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_set failed rc = %d" % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, original_port1_sb_attr_list,
                                              original_port1_sb_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_set failed rc = %d" % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, SX_MC_PORT_LOG_ID, original_mc_port_sb_attr_list,
                                              original_mc_port_sb_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_set failed for MC PORT rc = %d" % (rc))
        sys.exit(rc)

    for pool in pools_list:
        destroy_shared_headroom_pool(handle, pool)
