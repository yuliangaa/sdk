#!/usr/bin/env python
'''
This file contains Python command example for the ALL PORT COUNTER READ module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import os.path
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_transaction_mode_set example')
parser.add_argument('--cmd', default='enable', choices=['enable', 'disable'], help='Choose transaction mode to set. Default is "enable".')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example. Note: Transacation mode default is assumed to be disable, Yet if user provide explicit cmd = disable + deinit flag, the cleanup part will set it to enable.')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def transaction_mode_set(cmd):
    rc = sx_api_transaction_mode_set(handle, cmd)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_transaction_mode_set failed")
        sys.exit(rc)
    print(("sx_api_transaction_mode_set, rc %d" % rc))

###########################################################################################


# set the new transaction mode
cmd = SX_ACCESS_CMD_ENABLE if args.cmd == "enable" else SX_ACCESS_CMD_DISABLE
transaction_mode_set(cmd)

if args.deinit:
    print("Deinit")

    cmd = SX_ACCESS_CMD_DISABLE if args.cmd == "enable" else SX_ACCESS_CMD_ENABLE
    transaction_mode_set(cmd)

sx_api_close(handle)
