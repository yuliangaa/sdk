#!/usr/bin/env python
'''
This file contains Python command example for router counter related operations.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the create, destroy, bind, unbind, clear and dump RIF counters.
This example is supported on Spectrum+ devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

INPUT_ERR_REPLY_PFX = "\n\t"
TEST_CMD_NONE = (SX_ACCESS_CMD_MAX + 1)

CREATE_CMD = 'create'
DETROY_CMD = 'destroy'
BIND_CMD = 'bind'
UNBIND_CMD = 'unbind'
DUMP_CMD = 'dump'
CLEAR_CMD = 'clear'

BASIC_CNTR = 'basic'
ENHANCED_CNTR = 'enhanced'


def validate_rif(handle, rif):
    """ Check that the RIF exists in the SDK"""

    vrid_p = new_sx_router_id_t_p()
    ifc_p = new_sx_router_interface_param_t_p()
    ifc_attr_p = new_sx_interface_attributes_t_p()
    try:
        rc = sx_api_router_interface_get(handle, rif, vrid_p, ifc_p, ifc_attr_p)
        if rc != SX_STATUS_SUCCESS:
            if rc == SX_STATUS_ENTRY_NOT_FOUND:
                print("Router Interface - RIF %u doesnt exist." % (rif))
            else:
                print("Unexpected error %s while fetching rif interface %u. Try again" % (sx_status_dict[rc], rif))
        return rc
    finally:
        delete_sx_router_id_t_p(vrid_p)
        delete_sx_router_interface_param_t_p(ifc_p)
        delete_sx_interface_attributes_t_p(ifc_attr_p)


def is_router_counter_valid(handle, counter_id):
    """ Check the router counter and counter type """
    cntr_attr_p = new_sx_router_counter_attributes_t_p()
    cntr_attr = None

    try:
        rc = sx_api_router_counter_attr_get(handle, counter_id, cntr_attr_p)
        if rc == SX_STATUS_SUCCESS:
            cntr_attr = sx_router_counter_attributes_t_p_value(cntr_attr_p)
            return True, cntr_attr.type
        print("Router Counter %u doesnt exist." % (counter_id))
        return False, None
    finally:
        delete_sx_router_counter_attributes_t_p(cntr_attr_p)


def print_router_common_counter_data(counter_set):
    print("Router ingress good unicast packets:             {:>10}".format(counter_set.router_ingress_good_unicast_packets))
    print("Router ingress good unicast bytes:               {:>10}".format(counter_set.router_ingress_good_unicast_bytes))
    print("Router ingress good multicast packets:           {:>10}".format(counter_set.router_ingress_good_multicast_packets))
    print("Router ingress good multicast bytes:             {:>10}".format(counter_set.router_ingress_good_multicast_bytes))
    print("Router ingress good broadcast packets:           {:>10}".format(counter_set.router_ingress_good_broadcast_packets))
    print("Router ingress good broadcast bytes:             {:>10}".format(counter_set.router_ingress_good_broadcast_bytes))
    print("Router ingress discard packets:                  {:>10}".format(counter_set.router_ingress_discard_packets))
    print("Router ingress discard bytes:                    {:>10}".format(counter_set.router_ingress_discard_bytes))
    print("Router ingress error packets:                    {:>10}".format(counter_set.router_ingress_error_packets))
    print("Router ingress error bytes:                      {:>10}".format(counter_set.router_ingress_error_bytes))
    print("Router egress good unicast packets:              {:>10}".format(counter_set.router_egress_good_unicast_packets))
    print("Router egress good unicast bytes:                {:>10}".format(counter_set.router_egress_good_unicast_bytes))
    print("Router egress good multicast packets:            {:>10}".format(counter_set.router_egress_good_multicast_packets))
    print("Router egress good multicast bytes:              {:>10}".format(counter_set.router_egress_good_multicast_bytes))
    print("Router egress good broadcast packets:            {:>10}".format(counter_set.router_egress_good_broadcast_packets))
    print("Router egress good broadcast bytes:              {:>10}".format(counter_set.router_egress_good_broadcast_bytes))
    print("Router egress discard packets:                   {:>10}".format(counter_set.router_egress_discard_packets))
    print("Router egress discard bytes:                     {:>10}".format(counter_set.router_egress_discard_bytes))
    print("Router egress error packets:                     {:>10}".format(counter_set.router_egress_error_packets))
    print("Router egress error bytes:                       {:>10}".format(counter_set.router_egress_error_bytes))


def print_router_extended_counter(counter_id, counter_set):
    print("###########################################################")
    print("Router counter ID: %d" % (counter_id))
    print("Counter type: Enhanced")
    print("###########################################################")
    print("Router interface IPv4 counters.")
    print_router_common_counter_data(counter_set.ipv4_counters)
    print("###########################################################")
    print("Router interface IPv6 counters.")
    print_router_common_counter_data(counter_set.ipv6_counters)
    print("###########################################################")
    print("Router interface MPLS counters.")
    print_router_common_counter_data(counter_set.mpls_counters)
    print("###########################################################")


def print_router_basic_counter(counter_id, counter_set):
    print("###########################################################")
    print("Router counter ID: %d" % (counter_id))
    print("Counter type: Basic")
    print("###########################################################")
    print_router_common_counter_data(counter_set)
    print("###########################################################")


def read_router_counter(handle, counter_id):
    " Read/dump router counter values. "
    counter_is_valid, counter_type = is_router_counter_valid(handle, counter_id)
    if not counter_is_valid:
        print("Invalid router counter id {}".format(counter_id))
        rc = SX_STATUS_PARAM_ERROR
        return rc

    counter_set_extended = sx_router_counter_set_extended_t()
    counter_set_extended.type = counter_type

    if counter_type == SX_ROUTER_COUNTER_TYPE_BASIC:
        counter_data = sx_router_counter_set_t()
        counter_set_extended.data.rif_basic = counter_data
    else:
        counter_data = sx_router_counter_enhanced_t()
        counter_set_extended.data.rif_enhanced = counter_data

    counter_set_extended_p = new_sx_router_counter_set_extended_t_p()
    sx_router_counter_set_extended_t_p_assign(counter_set_extended_p, counter_set_extended)

    try:
        rc = sx_api_router_counter_extended_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_extended_p)
        if rc != SX_STATUS_PARAM_ERROR and rc != SX_STATUS_SUCCESS:
            print("Unexpected error while fetching counters for rif interface")
            return rc
        counter_set_extended = sx_router_counter_set_extended_t_p_value(counter_set_extended_p)

        if counter_type == SX_ROUTER_COUNTER_TYPE_BASIC:
            print_router_basic_counter(counter_id, counter_set_extended.data.rif_basic)
        else:
            print_router_extended_counter(counter_id, counter_set_extended.data.rif_enhanced)

        return rc

    finally:
        delete_sx_router_counter_set_extended_t_p(counter_set_extended_p)


def clear_router_counter(handle, counter_id):
    " Clear router counter. "

    rc = sx_api_router_counter_clear_set(handle, counter_id, False)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to read and clear router counter {}, ret:{}.".format(counter_id, rc))
    return rc


def create_router_counter(handle, counter_type=SX_ROUTER_COUNTER_TYPE_BASIC):
    " Create a router counter. "
    try:
        counter_p = new_sx_router_counter_id_t_p()
        counter_att = sx_router_counter_attributes_t()
        counter_att.type = counter_type

        rc = sx_api_router_counter_extended_set(handle, SX_ACCESS_CMD_CREATE, counter_att, counter_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to create router counter, ret:{}".format(rc))
            return rc, None

        counter_id = sx_router_counter_id_t_p_value(counter_p)
        print("Create router counter {}".format(counter_id))

        return rc, counter_id
    finally:
        delete_sx_router_counter_id_t_p(counter_p)


def destroy_router_counter(handle, counter_id, counter_type=SX_ROUTER_COUNTER_TYPE_BASIC):
    " Destroy the router counter. "
    try:
        counter_p = new_sx_router_counter_id_t_p()
        sx_router_counter_id_t_p_assign(counter_p, counter_id)
        counter_att = sx_router_counter_attributes_t()
        counter_att.type = counter_type

        rc = sx_api_router_counter_extended_set(handle, SX_ACCESS_CMD_DESTROY, counter_att, counter_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to destroy router counter {}, ret:{}".format(counter_id, rc))
            delete_sx_router_counter_id_t_p(counter_p)
            return rc

        print("Destroyed router counter %d, rc: %d" % (counter_id, rc))
        return rc
    finally:
        delete_sx_router_counter_id_t_p(counter_p)


def bind_unbind_router_counter(handle, cmd, counter_id, rif):
    " Binds/unbind a router counter to/from a rif. "

    cmd_str = "BIND"
    if cmd == SX_ACCESS_CMD_UNBIND:
        cmd_str = "UNBIND"

    rc = sx_api_router_interface_counter_bind_set(handle, cmd, counter_id, rif)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to {} router counter {} to rif {}, err:{}".format(cmd_str, counter_id, rif, rc))
        return rc

    print("{} router counter {} of rif {}".format(cmd_str, counter_id, rif))
    return rc


def get_args():
    parser = argparse.ArgumentParser(description='sx_api_router_rif_counter.py example. If no explicit action is given, the default will do nothing. In case of "--cmd create", user should take care of the counter id, and destoy it later.')

    parser.add_argument('--cmd', choices=[CREATE_CMD, DETROY_CMD, BIND_CMD, UNBIND_CMD, DUMP_CMD, CLEAR_CMD],
                        help='Select one operation: "create", "destroy", "bind", "unbind", "dump", "clear"')

    parser.add_argument('--rif', default="", help='Select an existing rif id (decimal format) for the counter operation.')
    parser.add_argument('--counter_id', default="", help='Select existing counter id (decimal format) to operate.')
    parser.add_argument('--counter_type', default=BASIC_CNTR, choices=[BASIC_CNTR, ENHANCED_CNTR], help='Select rif counter type.')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Unset configurations done by the example')
    args = parser.parse_args()
    return args


def main():
    args = get_args()
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        if not args.cmd:
            # default operations
            cmd = TEST_CMD_NONE
        elif args.cmd == CREATE_CMD:
            cmd = SX_ACCESS_CMD_CREATE
        elif args.cmd == DETROY_CMD:
            cmd = SX_ACCESS_CMD_DESTROY
        elif args.cmd == BIND_CMD:
            cmd = SX_ACCESS_CMD_BIND
        elif args.cmd == UNBIND_CMD:
            cmd = SX_ACCESS_CMD_UNBIND
        elif args.cmd == DUMP_CMD:
            cmd = SX_ACCESS_CMD_READ
        elif args.cmd == CLEAR_CMD:
            cmd = SX_ACCESS_CMD_CLEAR
        else:
            print(INPUT_ERR_REPLY_PFX + '"--cmd" should specify one operation: "create", "destroy", "bind", "unbind", "dump", "clear"')
            rc = SX_STATUS_PARAM_ERROR
            return rc

        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_QUANTUM, SX_CHIP_TYPE_QUANTUM2]:
            print(INPUT_ERR_REPLY_PFX + "port extended params GET/SET is supported on spectrum and above.")
            return rc

        if cmd != TEST_CMD_NONE:
            print_api_example_disclaimer()

        if args.rif:
            rif = int(args.rif, 10)  # decimal value
            rc = validate_rif(handle, rif)
            if rc != SX_STATUS_SUCCESS:
                return rc
        else:
            if cmd == SX_ACCESS_CMD_BIND or cmd == SX_ACCESS_CMD_UNBIND:
                print(INPUT_ERR_REPLY_PFX + "'--rif' should be set with an existing RIF id for this cmd '{}' .".format(args.cmd))
                rc = SX_STATUS_PARAM_ERROR
                return rc

        if args.counter_id:
            counter_id = int(args.counter_id, 10)  # decimal value
        else:
            if cmd != SX_ACCESS_CMD_CREATE and cmd != TEST_CMD_NONE:
                print(INPUT_ERR_REPLY_PFX + "'--counter_id' should be set with an created counter id for this cmd '{}' .".format(args.cmd))
                rc = SX_STATUS_PARAM_ERROR
                return rc

        if cmd != SX_ACCESS_CMD_READ and cmd != TEST_CMD_NONE:
            if not args.force:
                print_modification_warning()

        if cmd == SX_ACCESS_CMD_READ:
            rc = read_router_counter(handle, counter_id)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to dump rif counter id {}, rc:{}.".format(counter_id, rc))
                return rc

        elif cmd == SX_ACCESS_CMD_CLEAR:
            rc = clear_router_counter(handle, counter_id)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to clear rif counter id {}, rc:{}.".format(counter_id, rc))
                return rc

        elif cmd == SX_ACCESS_CMD_CREATE:
            cntr_type = SX_ROUTER_COUNTER_TYPE_BASIC
            if args.counter_type == ENHANCED_CNTR:
                cntr_type = SX_ROUTER_COUNTER_TYPE_ENHANCED

            rc, counter_id = create_router_counter(handle, cntr_type)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to create rif counter, rc:{}.".format(rc))
                return rc

        elif cmd == SX_ACCESS_CMD_DESTROY:
            rc = destroy_router_counter(handle, counter_id)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to destroy rif counter id {}, rc:{}.".format(counter_id, rc))
                return rc

        elif cmd == SX_ACCESS_CMD_BIND or cmd == SX_ACCESS_CMD_UNBIND:
            rc = bind_unbind_router_counter(handle, cmd, counter_id, rif)
            if (rc != SX_STATUS_SUCCESS):
                return rc

        rollback_cap = False
        # handle deinit only in case of  "create", "bind", "unbind"
        if cmd == SX_ACCESS_CMD_CREATE or cmd == SX_ACCESS_CMD_BIND or cmd == SX_ACCESS_CMD_UNBIND:
            rollback_cap = True

        if args.deinit and rollback_cap:
            if cmd == SX_ACCESS_CMD_CREATE:
                rc = destroy_router_counter(handle, counter_id)
                if (rc != SX_STATUS_SUCCESS):
                    print("Failed to destroy rif counter id {}, rc:{}.".format(counter_id, rc))
                    return rc

            if cmd == SX_ACCESS_CMD_BIND:
                rc = bind_unbind_router_counter(handle, SX_ACCESS_CMD_UNBIND, counter_id, rif)
                if (rc != SX_STATUS_SUCCESS):
                    print("Failed to rollback counter id {} rif {} binding, rc:{}.".format(counter_id, rif, rc))
                    return rc

            if cmd == SX_ACCESS_CMD_UNBIND:
                rc = bind_unbind_router_counter(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
                if (rc != SX_STATUS_SUCCESS):
                    print("Failed to rollback counter id {} rif {} binding, rc:{}.".format(counter_id, rif, rc))
                    return rc

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
