#!/usr/bin/env python
'''
Sets all port speed to 10G
'''
import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

precoding_enum_to_str = {
    SX_PORT_EXT_PORT_LANE_PRECODING_ON_E: "enable",
    SX_PORT_EXT_PORT_LANE_PRECODING_OFF_E: "disable",
    SX_PORT_EXT_PORT_LANE_PRECODING_INVALID_E: "invalid"
}

parser = argparse.ArgumentParser(description='sx_api_port_state_set')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--log_port', default="", help='List of log port to set state for separated by ",". i.e. 0x10001,0x10005')
parser.add_argument('--state', default="down", choices=["up", "down"], help='Port state - "down" or "up"')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

state = args.state
if args.log_port:
    log_port_list = [int(log_port, 16) for log_port in args.log_port.split(",")]
else:
    print("No port given - Fetching port from SDK and setting its state to %s" % state)
    print("Usage: %s <log_port> <up|down> " % sys.argv[0])
    log_port_list_p = new_sx_port_log_id_t_arr(1)
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 1)
    rc = sx_api_port_swid_port_list_get(handle, 0, log_port_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to get port_list, rc %d" % rc)
        sys.exit(rc)

    log_port = sx_port_log_id_t_arr_getitem(log_port_list_p, 0)
    log_port_list = [log_port]

# Before set
oper_state_p = new_sx_port_oper_state_t_p()
admin_state_p = new_sx_port_admin_state_t_p()
module_state_p = new_sx_port_module_state_t_p()
ext_state_p = new_sx_port_ext_port_state_t_p()
for port in log_port_list:
    rc = sx_api_port_state_get(handle, port, oper_state_p, admin_state_p, module_state_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Error: sx_api_port_state_get returns rc:%d" % (rc)))
        sys.exit(rc)

    oper_state = sx_port_oper_state_t_p_value(oper_state_p)
    admin_state = sx_port_admin_state_t_p_value(admin_state_p)
    module_state = sx_port_module_state_t_p_value(module_state_p)
    print(("Before set: log_port:0x%x oper_state:%d admin state:%d module_state:%d." % (port, oper_state, admin_state, module_state)))

    state_up_down = ""
    if state == "up":
        state_up_down = SX_PORT_ADMIN_STATUS_UP
    elif state == "down":
        state_up_down = SX_PORT_ADMIN_STATUS_DOWN
    else:
        print("Failed : the state should be up or down.")
        sys.exit(rc)

    print("Setting port 0x%x to state %s(%d)" % (port, state, state_up_down))
    rc = sx_api_port_state_set(handle, port, state_up_down)
    if rc != SX_STATUS_SUCCESS:
        print(("Error: sx_api_port_state_set returns rc:%d" % (rc)))
        sys.exit(rc)

    print(("rc %d , Setting log_port:0x%x admin state to %s." % (rc, port, state)))

    rc = sx_api_port_state_ext_get(handle, port, ext_state_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Error: sx_api_port_state_ext_get returns rc:%d" % (rc)))
        sys.exit(rc)

    ext_state = sx_port_ext_port_state_t_p_value(ext_state_p)
    print(("After set: log_port:0x%x oper_state:%d admin state:%d module_state:%d an_speed:%d tx_ready:%d." % (port, ext_state.oper_state, ext_state.admin_state, ext_state.module_state, ext_state.an_speed_state, ext_state.tx_ready_state)))
    lane_cnt = ext_state.port_precoding.lane_cnt
    table_prefix = 4 * " "
    if lane_cnt > 0:
        print((table_prefix + "precoding status: lane_cnt=%d" % (lane_cnt)))
        table_hdr_str = "| Lane ID | Tx Precoding | Rx Precoding |"
        table_line_len = len(table_hdr_str)
        print(table_prefix + table_line_len * "=")
        print(table_prefix + table_hdr_str)
        for j in range(0, lane_cnt):
            print(table_prefix + table_line_len * "-")
            lid = uint8_t_arr_getitem(ext_state.port_precoding.lane_id, j)
            setting = sx_port_ext_lane_precoding_t_arr_getitem(ext_state.port_precoding.precoding_settings, j)
            print(table_prefix + "| {:>7d} | {:>12s} | {:>12s} |"
                  .format(lid, precoding_enum_to_str[setting.tx_precoding], precoding_enum_to_str[setting.tx_precoding]))
        print(table_prefix + table_line_len * "=")

    if args.deinit:
        if state_up_down == SX_PORT_ADMIN_STATUS_DOWN:
            print("Setting port 0x%x UP" % (port))
            rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_state_set returns rc:%d" % (rc)))
                sys.exit(rc)

sx_api_close(handle)

sys.exit(rc)
