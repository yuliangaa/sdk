#!/usr/bin/env python
"""
This example disables the TX of a given Logical port if supported by the module.
Please refer your modules EEPROM Spec to ensure that the module supports this feature
The EEPROM values in this example are taken from
CMIS spec https://www.oiforum.com/wp-content/uploads/OIF-CMIS-05.2.pdf
and the SFF spec https://members.snia.org/document/dl/26423
"""

import os
import sys
from python_sdk_api.sx_api import *
import argparse
import subprocess
import time
from enum import Enum


DISABLE = 1
ENABLE = 0


class ModuleIdentifier(Enum):
    SFP = 0x03
    QSFP = 0x0C
    QSFP_PLUS = 0x0D
    QSFP28 = 0x11
    QSFP_DD = 0x18
    OSFP = 0x19
    SFP_DD = 0x1A
    DSFP = 0x1B
    QSFP_PLUS_CMIS = 0x1E


def auto_int(x):
    return None if x is None else int(x, 0)


def print_api_example_disclaimer():
    print("DISCLAIMER")
    print("==========")
    print("The following code is an EXAMPLE whose sole purpose is to demonstrate various capabilities of the SDK.")
    print("This example represents a common configuration scenario and is in no way a complete guide to the demonstrated feature.")
    print("For complete documentation please refer to the SDK API Guide.")
    print("There is no guarantee that this example will run successfully on all hardware and software configurations.")
    print("")


def print_modification_warning():
    valid = {"yes": True, "y": True, "ye": True}
    print("NOTE: Running this example MAY MODIFY current configuration of the SDK!")
    print("Do you wish to continue? (y/N)")
    choice = input().lower()
    if choice not in valid:
        sys.exit(0)


def parse_args():

    description_str = """
    Utility to disable TX Lasers of a module if supported.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--log_port", dest='port', type=auto_int, default="0x10001",
                        help="Logical port to use, either in hex format - 0x10001, or Int format - 65537")
    return parser.parse_args()


def run_and_test_raising(cmd, should_fail=False):
    rc = run_and_test(cmd, should_fail)
    if rc != 0:
        raise Exception('run_and_test failed of cmd = ' + cmd + ' with rc = ' + str(rc))
    return 0


def run_and_test(cmd, should_fail=False):
    print("Running command : " + cmd)
    ret = subprocess.call(cmd, shell=True)
    failed = (ret != 0)
    # ret = ret / 256
    if should_fail:
        if failed:
            return 0

    if not should_fail:
        if not failed:
            return 0

    print("Command " + cmd + " mismatched Failure = " + str(should_fail))
    print("return value:")
    print(ret)
    return ret


def read_present(port_dev):
    """
    returns: 1 in case port module is plugged in, 0 if port module is plugged off.
    """
    with open("/sys/module/sx_netdev/{}/module/present".format(port_dev)) as f:
        return int(f.readline().strip())


def read_tx_disable(port_dev):
    """
    returns: 1 if tx disabled else 0 (default).
    """
    with open("/sys/module/sx_netdev/{}/module/tx_disable".format(port_dev)) as f:
        return int(f.readline().strip())


def set_tx_disable_enable(port_dev, value):
    assert value in [0, 1], "value can be only 0 for Default and 1 for Disable"
    filename = "/sys/module/sx_netdev/{}/module/tx_disable".format(port_dev)
    with open(filename, "w") as f:
        f.write(str(value))
    time.sleep(1)


def is_tx_disable_implemented(port_dev):
    """
    If CMIS
    Paged: Page1, Byte 155, Bit 1 OutputDisableTxSupported
    Not paged: Page 0 , Byte 195, Bit 4
    If SFF:
     Page 0, Byte 195, Bit 4


    """
    is_cmis = is_CMIS_module(port_dev)
    if is_cmis:
        is_paged = is_paged_memory(port_dev)
        if not is_paged:
            tx_disable = read_eeprom_page(port_dev, 0, 195, 1)
            if tx_disable:
                return (int(tx_disable[0], 16) & 0x10)
            else:
                return 0
        else:
            tx_disable = read_eeprom_page(port_dev, 1, 155, 1)
            if tx_disable:
                return (int(tx_disable[0], 16) & 0x2)
            else:
                return 0
    else:
        tx_disable = read_eeprom_page(port_dev, 0, 195, 1)
        if tx_disable:
            return (int(tx_disable[0], 16) & 0x10)
        else:
            return 0


def is_SFF_module(module_id):
    module_identifier = read_eeprom_page(module_id, 0, 0, 1)
    return int(module_identifier[0], 16) in [ModuleIdentifier.QSFP.value, ModuleIdentifier.QSFP_PLUS.value,
                                             ModuleIdentifier.QSFP28.value, ModuleIdentifier.SFP.value]


def is_CMIS_module(module_id):
    module_identifier = read_eeprom_page(module_id, 0, 0, 1)
    return int(module_identifier[0], 16) in [ModuleIdentifier.QSFP_DD.value, ModuleIdentifier.OSFP.value,
                                             ModuleIdentifier.SFP_DD.value, ModuleIdentifier.DSFP.value,
                                             ModuleIdentifier.QSFP_PLUS_CMIS.value]


def is_paged_memory(module_id):
    """
    gets the memory model of the module
    page 0, byte 2, bit 7 in CMIS
    0 in bit 7 - paged memory - active
    1 -in bit 7 - flat memory - passive
    page 0, byte 2, bit 2 in SFF8636
    0 in bit 2 - paged memory - active
    1 -in bit 2 - flat memory - passive

    return true for optics (for paged memory)
    """
    page_0_byte_2 = read_eeprom_page(module_id, 0, 2, 1)

    if is_SFF_module(module_id):
        return int(page_0_byte_2[0], 16) & 0x04 == 0
    if is_CMIS_module(module_id):
        return int(page_0_byte_2[0], 16) & 0x80 == 0

    return False


def read_eeprom_page(port_dev, page, pos=0, size=-1):
    """
    param page: page to read from
    param pos: position in page to read from - default 0
    param size: size to read - default -1 to read all page

    returns: The specified EEPROM page content
    """
    page_location = "{}/{}data".format(page, 'i2c-0x50/' if page == 0 else '')
    netdev_file_location = "/sys/module/sx_netdev/{}/module/eeprom/pages/".format(port_dev) + page_location

    try:
        with open(netdev_file_location, "rb", buffering=0) as f:
            f.seek(pos)
            read_res = f.read(size)
            return [hex(byte) for byte in read_res]
    except OSError as e:
        raise Exception("Issue while accessing EEPROM for module {}: {}".format(port_dev, str(e)))


def main():
    args = parse_args()     # Parse given arguments

    print_api_example_disclaimer()

    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    port_dev = None

    try:

        # Set Port to Admin Down
        admin_state = SX_PORT_ADMIN_STATUS_DOWN
        rc = sx_api_port_state_set(handle, args.port, admin_state)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to Set Port 0x{} to admin Down.".format(args.port))
            sys.exit(rc)

        # Create Net dev
        cmd = "ip link add p%x type sx_netdev port 0x%x" % (args.port, args.port)
        run_and_test_raising(cmd)
        print("Created interface: ")
        cmd = "ip link show p%x" % (args.port)
        run_and_test_raising(cmd)

        port_dev = "p%x" % (args.port)

        # See if Module is present
        if not read_present(port_dev):
            print("Module not present, exiting")
            sys.exit(0)

        # See if Tx disable is supported
        supported = is_tx_disable_implemented(port_dev)
        if not supported:
            print("TX disable is not supported for module, exiting")
            sys.exit(0)

        # Read Current TX staus
        ret = read_tx_disable(port_dev)
        if ret == DISABLE:
            print("Module is already in TX Disabled state, exiting")
            sys.exit(0)

        # Actually disable TX
        set_tx_disable_enable(port_dev, DISABLE)

        # Verify
        ret = read_tx_disable(port_dev)
        if ret == ENABLE:
            print("Could not set module TX to disable, exiting")
            sys.exit(0)
        else:
            print("Module TX set to disable")

        # Bring Port back up
        admin_state = SX_PORT_ADMIN_STATUS_UP
        rc = sx_api_port_state_set(handle, args.port, admin_state)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to Set Port 0x{} to admin UP.".format(args.port))
            sys.exit(rc)

        # Deinit configuration if user provided flag
        if args.deinit:
            # Enable TX
            set_tx_disable_enable(port_dev, ENABLE)
            if port_dev:
                # Delete Net Dev
                cmd = "ip link delete p%x type sx_netdev port 0x%x" % (args.port, args.port)
                run_and_test_raising(cmd)

        print("SUCCESS")
    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        if port_dev:
            # Delete Net Dev
            cmd = "ip link delete p%x type sx_netdev port 0x%x" % (args.port, args.port)
            run_and_test_raising(cmd)
        # Bring Port back up
        admin_state = SX_PORT_ADMIN_STATUS_UP
        sx_api_port_state_set(handle, args.port, admin_state)
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
