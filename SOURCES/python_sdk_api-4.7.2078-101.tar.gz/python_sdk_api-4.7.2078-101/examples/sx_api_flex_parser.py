#!/usr/bin/env python
"""
This file contains the flex_parser API usage.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This example shows the following
1. verbosity setting for flex parser module
2. flex parser module init
3. flex parser transition set
4. flex parser transition count get
5. flex parser transition get
6. flex parser module deinit
"""
import sys
import os
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_parser example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

from python_sdk_api.sx_api import *

print("[+] Redirecting stderr to: %s" % ERR_FILE_LOCATION)
file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
TEST_SUCCESS = 0
TEST_FAILED = 1


######################################################
#    functions
#####################################################
def lineno():
    """Returns the current line number in our program."""
    return inspect.currentframe().f_back.f_lineno


def make_fixed_parse_header_src_node(parser_hdr_fixed):
    from_ph = sx_flex_parser_header_t()
    from_ph.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    from_ph.hdr_data.parser_hdr_fixed = parser_hdr_fixed
    return from_ph


def make_fixed_transition_dest_node(parser_hdr_fixed, encap_level, val):
    to_ph = sx_flex_parser_transition_t()
    to_ph.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    to_ph.next_parser_hdr.hdr_data.parser_hdr_fixed = parser_hdr_fixed
    to_ph.encap_level = encap_level
    to_ph.transition_value = val
    return to_ph


def print_transition_node(node):
    print("********* Transition Node ************")
    if node.next_parser_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E:
        print("parser_hdr_type          : FIXED")
    else:
        print("parser_hdr_type          : UNKNOWN")
    if node.next_parser_hdr.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_UDP_E:
        print("parser_hdr_node          : UDP")
    elif node.next_parser_hdr.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_VXLAN_E:
        print("parser_hdr_node          : VxLAN")
    else:
        print("parser_hdr_node          : UNKNOWN")
    if node.encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E:
        print("encap level              : OUTER")
    else:
        print("encap level              : UNKNOWN")
    print("transition value         : %d" % (node.transition_value))


def print_from_node(node):
    print("********* From Node ***************")
    if node.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E:
        print("parser_hdr_type          : FIXED")
    else:
        print("parser_hdr_type          : UNKNOWN")
    if node.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_UDP_E:
        print("parser_hdr_node          : UDP")
    elif node.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_VXLAN_E:
        print("parser_hdr_node          : VxLAN")
    else:
        print("parser_hdr_node          : UNKNOWN")


def main():
    try:
        ret_code = TEST_SUCCESS

        # set verbosity level
        rc = sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_ERROR, SX_VERBOSITY_LEVEL_ERROR)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_log_verbosity_level_set failed %s" % (rc)

        # initialize the flex parser module
        rc = sx_api_flex_parser_init_set(handle, None)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_init_set failed %s" % (rc)

        # set the flex parser transition
        udp_dport = 17654
        from_ph = make_fixed_parse_header_src_node(SX_FLEX_PARSER_HEADER_UDP_E)
        to_ph = make_fixed_transition_dest_node(SX_FLEX_PARSER_HEADER_VXLAN_E, SX_FLEX_PARSER_ENCAP_OUTER_E, udp_dport)

        rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, from_ph, to_ph)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        # retrieve the number of transitions from a given from header
        next_trans_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(next_trans_cnt_p, 0)

        rc = sx_api_flex_parser_transition_get(handle, from_ph, None, next_trans_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_get failed %s" % (rc)
        next_trans_cnt = uint32_t_p_value(next_trans_cnt_p)
        print("Number of transition from the given node:  %d" % (next_trans_cnt))

        next_trans_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(next_trans_cnt_p, 1)

        # retrieve the transition from a given from header
        next_trans_p = new_sx_flex_parser_transition_t_arr(next_trans_cnt)
        rc = sx_api_flex_parser_transition_get(handle, from_ph, next_trans_p, next_trans_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_get failed %s" % (rc)

        next_trans_cnt = uint32_t_p_value(next_trans_cnt_p)
        to_trans = sx_flex_parser_transition_t()

        print_from_node(from_ph)
        # print the trnasition
        for i in range(0, next_trans_cnt):
            to_trans = sx_flex_parser_transition_t_arr_getitem(next_trans_p, i)
            print_transition_node(to_trans)

        if args.deinit:
            print("Clean up")
            rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, from_ph, to_ph)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

            rc = sx_api_flex_parser_deinit_set(handle)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_deinit_set failed %s" % (rc)

    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        ret_code = TEST_FAILED

    finally:
        sx_api_close(handle)

        sys.exit(ret_code)


if __name__ == "__main__":
    main()
