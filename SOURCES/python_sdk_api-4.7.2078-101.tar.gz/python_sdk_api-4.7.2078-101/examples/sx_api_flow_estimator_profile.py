#!/usr/bin/env python
'''
This file contains Python command example for flow estimator profiles.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of flow estimator profiles.
This example is supported on Spectrum2+ devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


PROFILE0 = "0"
PROFILE1 = "1"
PROFILE2 = "2"
PROFILE3 = "3"
ALL_S = "all"
MIN_PROFILE_IDX = int(PROFILE0)
MAX_PROFILE_IDX = int(PROFILE3)
INPUT_ERR_REPLY_PFX = "\n\t"
DEFAULT_BIN_GROUP_SIZE = 64


def check_sdk_rc(rc, errmsg):
    if rc != SX_STATUS_SUCCESS:
        print("Fail: %s, rc=%d" % (errmsg, rc))
        return rc


def flow_estimator_profile_set(handle, cmd=SX_ACCESS_CMD_CREATE, profile_id=0, bin_group_size=DEFAULT_BIN_GROUP_SIZE):
    """ CREATE/SET/DESTROY FLOW ESTIMATOR PROFILE """
    if cmd != SX_ACCESS_CMD_DESTROY and bin_group_size == 0:
        rc = SXD_STATUS_PARAM_ERROR
        print("Invalid param of bin group size {}.".format(bin_group_size))

    profile_key = sx_flow_estimator_profile_key_t()
    profile_key.profile_id = profile_id

    profile_cfg_p = new_sx_flow_estimator_profile_cfg_t_p()
    profile_cfg = sx_flow_estimator_profile_cfg_t()
    profile_cfg.bin_group_size = bin_group_size
    profile_cfg.hash_params_p = None
    sx_flow_estimator_profile_cfg_t_p_assign(profile_cfg_p, profile_cfg)

    # set with bin_group_size and default hash params
    rc = sx_api_flow_estimator_profile_set(handle,
                                           cmd,
                                           profile_key,
                                           profile_cfg_p)
    check_sdk_rc(rc, "sx_api_flow_estimator_profile_set failed for profile id : {}".format(profile_id))
    return rc


def flow_estimator_profile_get(handle, profile_id=0):
    """ GET PROFILE ATTRIBUTES """
    print("profile {}:\n".format(profile_id) + 20 * '-')
    try:
        profile_key = sx_flow_estimator_profile_key_t()
        profile_key.profile_id = profile_id
        profile_attr_p = new_sx_flow_estimator_profile_attr_t_p()
        profile_attr = sx_flow_estimator_profile_attr_t()
        hash_params = sx_flow_estimator_profile_hash_t()
        hash_params.fields_enable_list_cnt = 0
        hash_params.fields_list_cnt = 0
        profile_attr.config.hash_params_p = new_sx_flow_estimator_profile_hash_t_p()
        sx_flow_estimator_profile_hash_t_p_assign(profile_attr.config.hash_params_p, hash_params)
        sx_flow_estimator_profile_attr_t_p_assign(profile_attr_p, profile_attr)

        # get attributes count
        rc = sx_api_flow_estimator_profile_get(handle,
                                               profile_key,
                                               profile_attr_p)
        if rc == SX_STATUS_ENTRY_NOT_FOUND:
            print("\tProfile {} is not created yet.".format(profile_id))
            return SX_STATUS_SUCCESS
        check_sdk_rc(rc, "sx_api_flow_estimator_profile_get failed for profile id : {}".format(profile_id))

        print("Profile {} attr:\n\tin_use:{}\n\tsize:{}\n\tseed_en_by_sw:{}\n\tseed_by_sw:{}\n\tenable_cnt:{}\n\tfields_cnt:{}"
              .format(profile_id,
                      profile_attr_p.in_use,
                      profile_attr_p.config.bin_group_size,
                      profile_attr_p.config.hash_params_p.seed_en_by_sw,
                      profile_attr_p.config.hash_params_p.seed_by_sw,
                      profile_attr_p.config.hash_params_p.fields_enable_list_cnt,
                      profile_attr_p.config.hash_params_p.fields_list_cnt))
        if (profile_attr_p.config.hash_params_p.fields_enable_list_cnt == 0
                and profile_attr_p.config.hash_params_p.fields_list_cnt == 0):
            return rc

        # get attributes
        hash_params.fields_enable_list_cnt = profile_attr.config.hash_params_p.fields_enable_list_cnt
        hash_params.fields_enable_list_p = new_sx_flow_estimator_profile_hash_field_enable_t_arr(hash_params.fields_enable_list_cnt)
        hash_params.fields_list_cnt = profile_attr.config.hash_params_p.fields_list_cnt
        hash_params.fields_list_p = new_sx_flow_estimator_profile_hash_field_t_arr(hash_params.fields_list_cnt)
        sx_flow_estimator_profile_hash_t_p_assign(profile_attr.config.hash_params_p, hash_params)
        sx_flow_estimator_profile_attr_t_p_assign(profile_attr_p, profile_attr)
        rc = sx_api_flow_estimator_profile_get(handle,
                                               profile_key,
                                               profile_attr_p)
        check_sdk_rc(rc, "sx_api_flow_estimator_profile_get failed for profile id : {}".format(profile_id))

        list_print = "\tenable_list: ["
        for i in range(profile_attr_p.config.hash_params_p.fields_enable_list_cnt):
            list_print = list_print + " {}".format(
                sx_flow_estimator_profile_hash_field_enable_t_arr_getitem(
                    profile_attr_p.config.hash_params_p.fields_enable_list_p, i))
        list_print = list_print + " ]"
        print(list_print)

        list_print = "\tfield_list: ["
        for i in range(profile_attr_p.config.hash_params_p.fields_list_cnt):
            list_print = list_print + " {}".format(
                sx_flow_estimator_profile_hash_field_t_arr_getitem(
                    profile_attr_p.config.hash_params_p.fields_list_p, i))
        list_print = list_print + " ]"
        print(list_print + '\n')
        return rc

    finally:
        delete_sx_flow_estimator_profile_hash_field_enable_t_arr(hash_params.fields_enable_list_p)
        delete_sx_flow_estimator_profile_hash_field_t_arr(hash_params.fields_list_p)


def flow_estimator_profile_get_all(handle):
    """ GET all existing PROFILEs """
    print(30 * '-' + "\nFlow Estimator Profiles:\n" + 30 * '-')
    try:
        profile_key = sx_flow_estimator_profile_key_t()
        profile_key_arr = new_sx_flow_estimator_profile_key_t_arr(MAX_PROFILE_IDX + 1)
        profile_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(profile_cnt_p, MAX_PROFILE_IDX + 1)

        rc = sx_api_flow_estimator_profile_iter_get(handle,
                                                    SX_ACCESS_CMD_GET_FIRST,
                                                    profile_key,
                                                    None,
                                                    profile_key_arr,
                                                    profile_cnt_p)
        check_sdk_rc(rc, "sx_api_flow_estimator_profile_iter_get failed")
        profile_cnt = uint32_t_p_value(profile_cnt_p)
        print("Existing number: {}\n".format(profile_cnt))

        for i in range(profile_cnt):
            prof_k = sx_flow_estimator_profile_key_t_arr_getitem(profile_key_arr, i)
            rc = flow_estimator_profile_get(handle, prof_k.profile_id)
            check_sdk_rc(rc, "flow_estimator_profile_get failed for profile id : {}".format(prof_k.profile_id))

        return rc

    finally:
        delete_sx_flow_estimator_profile_key_t_arr(profile_key_arr)


def get_args():
    parser = argparse.ArgumentParser(description='sx_api_flow_estimator_profile.py example. If no explicit action is given, the default will be to create a profile.')
    parser.add_argument('--profile', default=[PROFILE0], nargs='+',
                        choices=[ALL_S, PROFILE0, PROFILE1, PROFILE2, PROFILE3],
                        help='specify profile id or "all". "all" is used only for "--get"')

    operation = parser.add_mutually_exclusive_group()
    operation.add_argument('--create', action='store_true', help='Create the specific profile id with default hash param')
    operation.add_argument('--get', action='store_true', help='Get specific or all profile attributes')
    operation.add_argument('--delete', action='store_true', help='Delete the specific profile id')

    parser.add_argument('--bin_group_size', default="64", help='bin group size of the profile')
    parser.add_argument('--force', action='store_true', help='Directly create or delete flow estimator profile and despite prompt for SDK configuration change')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    return args


def main():
    args = get_args()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print(INPUT_ERR_REPLY_PFX + "Flow estimator profile is supported from spectrum2 and above.")
            return rc

        is_iter = False
        profile_id = 0
        if args.profile[0] == ALL_S:
            if not args.get:
                print(INPUT_ERR_REPLY_PFX + '"all" is used only for "--get"')
                return rc
            is_iter = True
        else:
            profile_id = int(args.profile[0])
            if profile_id < 0 or profile_id > 3:
                print(INPUT_ERR_REPLY_PFX + "profile id {} is out of range".format(profile_id))
                sys.exit(rc)

        bin_group_size = DEFAULT_BIN_GROUP_SIZE
        if args.bin_group_size:
            bin_group_size = int(args.bin_group_size, 10)

        rollback_cmd = SX_ACCESS_CMD_NONE
        if args.get:
            if is_iter:
                rc = flow_estimator_profile_get_all(handle)
                if (rc != SX_STATUS_SUCCESS):
                    print("Failed to get all profiles.")
                    return rc
            else:
                rc = flow_estimator_profile_get(handle, profile_id)
                if (rc != SX_STATUS_SUCCESS):
                    print("Failed to get profile {}.".format(profile_id))
                    return rc
        elif args.delete:
            if not args.force:
                print_modification_warning()
            rc = flow_estimator_profile_set(handle, SX_ACCESS_CMD_DESTROY, profile_id, bin_group_size)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to destroy profile {}.".format(profile_id))
                return rc
            rollback_cmd = SX_ACCESS_CMD_CREATE
        else:
            # default action is creating a profile
            if not args.force:
                print_modification_warning()
            rc = flow_estimator_profile_set(handle, SX_ACCESS_CMD_CREATE, profile_id, bin_group_size)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to create profile {}, bin group size {}.".format(profile_id, bin_group_size))
                return rc
            rollback_cmd = SX_ACCESS_CMD_DESTROY
            rc = flow_estimator_profile_get(handle, profile_id)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to get profile {}.".format(profile_id))
                return rc

        if args.deinit and rollback_cmd != SX_ACCESS_CMD_NONE:
            rc = flow_estimator_profile_set(handle, rollback_cmd, profile_id, bin_group_size)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to rollback ({}) profile {}.".format(rollback_cmd, profile_id))
                return rc

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
