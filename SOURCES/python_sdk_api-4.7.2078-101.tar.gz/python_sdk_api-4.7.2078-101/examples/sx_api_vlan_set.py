#!/usr/bin/env python
'''
This an example how to add/delete VLAN.
'''

import errno
import sys
import colorsys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_vlan_set')
parser.add_argument('--force', default=False, action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

swid = 0
vlan_id = 100

vlan_list_p = new_sx_vlan_id_t_p()
sx_vlan_id_t_p_assign(vlan_list_p, vlan_id)

# get number of VLANs
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 0)

rc = sx_api_vlan_get(handle, swid, None, data_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_vlan_get failed, rc=[%d] " % (rc)))
    sys.exit(rc)
vlans_num_before_delete = uint32_t_p_value(data_cnt_p)
print(("Successfully got %d VLANs" % (vlans_num_before_delete)))

# delete VLAN
uint32_t_p_assign(data_cnt_p, 1)

rc = sx_api_vlan_set(handle, SX_ACCESS_CMD_DELETE, swid, vlan_list_p, data_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_vlan_set failed, rc=[%d], cmd=[%d] " % (rc, SX_ACCESS_CMD_DELETE)))
    sys.exit(rc)

print(("VLAN %d was successfully deleted" % (vlan_id)))

# get number of VLANs
uint32_t_p_assign(data_cnt_p, 0)

rc = sx_api_vlan_get(handle, swid, None, data_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_vlan_get failed, rc=[%d] " % (rc)))
    sys.exit(rc)
vlans_num_after_delete = uint32_t_p_value(data_cnt_p)
print(("Successfully got %d VLANs" % (vlans_num_after_delete)))

if args.deinit:
    print("Deinit")
    if vlans_num_before_delete != vlans_num_after_delete:
        # add VLAN
        uint32_t_p_assign(data_cnt_p, 1)

        rc = sx_api_vlan_set(handle, SX_ACCESS_CMD_ADD, swid, vlan_list_p, data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_vlan_set failed, rc=[%d], cmd=[%d] " % (rc, SX_ACCESS_CMD_ADD)))
            sys.exit(rc)

        print(("VLAN %d was successfully added" % (vlan_id)))

        # get number of VLANs after deinit
        uint32_t_p_assign(data_cnt_p, 0)

        rc = sx_api_vlan_get(handle, swid, None, data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_vlan_get failed, rc=[%d] " % (rc)))
            sys.exit(rc)
        print(("Successfully got %d VLANs" % (uint32_t_p_value(data_cnt_p))))

sx_api_close(handle)
