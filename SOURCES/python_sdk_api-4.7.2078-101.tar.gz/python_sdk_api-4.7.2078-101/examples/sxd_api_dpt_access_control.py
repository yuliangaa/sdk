#!/usr/bin/env python

import sys
import argparse
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

device_id_min = 0x01
device_id_max = 0xFD
access_control_dict = {0: 'NO_ACCESS', 1: 'READ_ONLY', 2: 'READ_WRITE'}


def parse_args():
    parser = argparse.ArgumentParser(description='DPT Get/Set example')
    parser.add_argument('--cmd', default=0, type=int, choices=[0, 1], help="GET(0), SET(1).")
    parser.add_argument('--dev_id', default=device_id_min, type=int, choices=list(range(device_id_min, device_id_max + 1)), help="Device ID")
    parser.add_argument('--access_control', default=2, type=int, choices=[1, 2], help="for SET: READ_ONLY (1)|READ_WRITE (2)")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    return args.cmd, args.dev_id, args.access_control, args.deinit


def help_cmd():
    print("")
    print("The following example allows users to execute Set/Get request for the DPT.")
    print(sys.argv[0] + " [--cmd <cmd>] [--dev_id <dev_id>] --access_control < 0 (R/O)| 1(R/W)>")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. 0 by default.")
    print("dev_id: The device ID to be used, 1 is default, range is 1 - 253 ")
    print("access_control: The access control state, to be used with SET operation (READ_ONLY (1)|READ_WRITE (2) default is 2)")

    print("")


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, dev_id, access_control, deinit):

    rc, current_access_control = sxd_dpt_get_access_control(dev_id)
    if rc != SXD_STATUS_SUCCESS:
        raise Exception("sxd_dpt_get_access_control failed, rc=%d" % rc)
    print("====================")
    print("[+] Get current DPT Access control state :")
    print("[+] dev_id: ", dev_id)
    print("[+] Curent access_control state: ", access_control_dict[current_access_control])

    if cmd == 1:
        print("====================")
        print("[+] Set DPT Access control state :")
        print("[+] dev_id: ", dev_id)
        print("[+] access_control state: ", access_control_dict[access_control])

        rc = sxd_dpt_set_access_control(dev_id, access_control)
        if rc != SXD_STATUS_SUCCESS:
            raise Exception("sxd_dpt_set_access_control failed, rc=%d" % rc)

    if deinit and cmd == 1:
        print("Deinit")
        rc = sxd_dpt_set_access_control(dev_id, current_access_control)
        if rc != SXD_STATUS_SUCCESS:
            raise Exception("sxd_dpt_set_access_control failed, rc=%d" % rc)


def main():
    print("[+] SXD DPT access control example")
    cmd, dev_id, access_control, deinit = parse_args()

    sxd_init()
    run_example(cmd, dev_id, access_control, deinit)
    print("[+] SXD DPT access example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    sys.exit(main())
