#!/usr/bin/env python
"""
This file contains Python command example for the ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
	1. Initialize one virtual router, and two VLAN router interfaces
	2. Bind flow-counters to a Local route, an IP2ME route, and a Next-hop route
	3. Read, display and clear the flow counters
	4. Router tear-down and cleanup
"""
import sys
import socket
import struct
import errno
from test_infra_common import *
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_router_flow_counter example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0
SX_FLOW_COUNTER_ID_INVALID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

NEIGH_MAC_1 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x69, 0x12)
NEIGH_MAC_2 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x68, 0x11)

# string constants
RIF_STR = "RIF"
IP_STR = "IP"
WEIGHT_STR = "weight"

######################################################
#    functions
######################################################


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def router_init():
    " This function creates a router and some VLAN interfaces. "
    # Make some VLANs
    add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT2: SX_TAGGED_MEMBER})

    # Initialize the router module
    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))

    # Create a virtual router
    vrid = create_vrid()

    # Create two VLAN router interfaces
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    rif_arr[1] = create_vlan_rif(vrid, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    # Enable interfaces with IPv4
    set_rif_state_ipv4(rif_arr[0], True)
    set_rif_state_ipv4(rif_arr[1], True)

    return vrid, rif_arr


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


def create_ip2me_route(vrid, rif, addr, mask="255.255.255.255"):
    " This function creates ip2me route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ip2me route"

    print("Created ip2me route for rif %d, rc: %d " % (rif, rc))


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        next_hop = make_ecmp_next_hop(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def make_ecmp_next_hop(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
            This function creates ecmp_next_hop struct with given parametrs.
            action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates ecmp uc_route_data struct with given parametrs.
            action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def create_ecmp_uc_route(vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def delete_neigh(rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_all_next_hops_per_vrid(vrid):
    " This function deletes all next hops from given vrid. "

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_neigh_per_rif(rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_all_local_routes(vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_ip2me_routes(vrid):
    " This function deletes all ip2me routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all IP2ME UC routes"
    print(("Deleted all IP2ME UC routes, rc: %d " % (rc)))


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit(vrid, rif_arr, ecmp_id, ecmp_id_1):
    " This function deinit the router. "
    # delete all next hop uc routes
    delete_all_next_hops_per_vrid(vrid)

    # destroy external ECMP container
    destroy_ecmp_container(ecmp_id_1)
    destroy_ecmp_container(ecmp_id)

    # delete all neighbors per rif
    delete_all_neigh_per_rif(rif_arr[0])
    delete_all_neigh_per_rif(rif_arr[1])

    # delete all local and ip2me routes
    delete_all_local_routes(vrid)
    delete_all_ip2me_routes(vrid)

    # delete rif
    delete_rif(vrid, rif_arr[0])
    delete_rif(vrid, rif_arr[1])

    # delete vrid
    delete_vrid(vrid)

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

    # vlan deinit
    remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})

# router examples


def example_create_external_ecmp_container(next_hop_rif):

    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)

    # next hop number 1
    next_hop = make_ecmp_next_hop(next_hop_rif, "22.33.0.7", 2)
    next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, next_hop_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def read_flow_counter(counter_id):
    " This function reads a flow counter. "

    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d; rc=%d" % (counter_id, rc)
    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    print(("Read flow counter %d, rc: %d; Packets: %u " % (counter_id, rc, counter_set.flow_counter_packets)))


def clear_flow_counter(counter_id):
    " This function clears a flow counter. "
    rc = sx_api_flow_counter_clear_set(handle, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to clear flow counter %d; rc=%d" % (counter_id, rc)
    print(("Counter clear rc: %d" % (rc)))


def destroy_flow_counter(counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function destroys a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed flow counter %d, rc: %d" % (counter_id, rc))


def bind_uc_route_counter(vrid, addr, mask, counter_id):
    " This function binds a flow-counter to a unicast route. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    rc = sx_api_router_uc_route_counter_bind_set(handle, SX_ACCESS_CMD_BIND, vrid, ip_prefix_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind flow counter %d to route" % (counter_id)

    print("Bound flow counter %d to route, rc: %d" % (counter_id, rc))


def unbind_uc_route_counter(vrid, addr, mask):
    " This function unbinds a flow-counter from a unicast route. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    rc = sx_api_router_uc_route_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, vrid, ip_prefix_p, SX_FLOW_COUNTER_ID_INVALID)
    assert SX_STATUS_SUCCESS == rc, "Failed to unbind flow counter from route"

    print("Unbound flow counter from route, rc: %d" % (rc))

# router flow


def router_with_flow_counters(vrid, rif_arr):
    local_counter = create_flow_counter()
    ip2me_counter = create_flow_counter()
    nexthop_counter = create_flow_counter()

    # This local route will be counted by local_counter
    create_local_route(vrid, rif_arr[0], "192.168.1.0", "255.255.255.0")
    bind_uc_route_counter(vrid, "192.168.1.0", "255.255.255.0", local_counter)

    create_local_route(vrid, rif_arr[1], "22.33.0.0", "255.255.0.0")

    create_ip2me_route(vrid, rif_arr[0], "192.168.1.1")

    # This IP2ME route will be counted by ip2me_counter
    create_ip2me_route(vrid, rif_arr[1], "22.33.44.55")
    bind_uc_route_counter(vrid, "22.33.44.55", "255.255.255.255", ip2me_counter)

    # create external ECMP container with {22.33.0.2} next hops

    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.2",
                                  WEIGHT_STR: 1})
    ecmp_id_1 = create_external_ecmp_container(next_hops_params_list)
    create_ecmp_uc_route(vrid, "100.100.128.0", "255.255.255.0", ecmp_id_1)
    bind_uc_route_counter(vrid, "100.100.128.0", "255.255.255.0", nexthop_counter)

    # Create external ECMP container with {22.33.0.7} next hops
    ecmp_id = example_create_external_ecmp_container(rif_arr[1])
    create_ecmp_uc_route(vrid, "100.100.129.0", "255.255.255.0", ecmp_id)

    # ARP-resolve the neighbors
    add_neigh(rif_arr[0], "192.168.1.2", NEIGH_MAC_1)
    add_neigh(rif_arr[1], "22.33.0.2", NEIGH_MAC_2)
    add_neigh(rif_arr[1], "22.33.0.7", NEIGH_MAC_2)

    ##########################################################
    # Traffic between neighbors 192.168.1.2 <--> 22.33.0.2
    # Traffic between neighbors 192.168.1.2 <--> 22.33.0.7
    # Traffic to remote network 192.168.1.2 --> 100.100.128.X (via 22.33.0.2)
    # Traffic to remote network 192.168.1.2 --> 100.100.129.X (via 22.33.0.7)
    # Traffic to me         --> 192.168.1.1
    # Traffic to me         --> 22.33.44.55
    ##########################################################

    # Display counted traffic
    read_flow_counter(local_counter)
    read_flow_counter(ip2me_counter)
    read_flow_counter(nexthop_counter)

    if args.deinit:
        # Unbind the counters. Traffic will not be counted anymore
        unbind_uc_route_counter(vrid, "192.168.1.0", "255.255.255.0")
        unbind_uc_route_counter(vrid, "22.33.44.55", "255.255.255.255")
        unbind_uc_route_counter(vrid, "100.100.128.0", "255.255.255.0")

        destroy_flow_counter(local_counter)
        destroy_flow_counter(ip2me_counter)
        destroy_flow_counter(nexthop_counter)

    return ecmp_id, ecmp_id_1

######################################################
#    main
######################################################


def main():
    # Init router and rifs
    vrid, rif_arr = router_init()

    # Configure neighbors and routes with flow counters
    ecmp_id, ecmp_id_1 = router_with_flow_counters(vrid, rif_arr)

    if args.deinit:
        # Deinit router
        router_deinit(vrid, rif_arr, ecmp_id, ecmp_id_1)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
