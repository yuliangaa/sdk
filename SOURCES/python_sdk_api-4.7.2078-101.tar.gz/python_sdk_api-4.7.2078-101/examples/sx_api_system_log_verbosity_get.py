#!/usr/bin/env python
'''
This file contains Python command example for controlling log verbosity
level of different SDK modules.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1


######################################################
#    Local Functions
######################################################

def system_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    rc = sx_api_system_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_system_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent System Wide Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def acl_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_acl_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent ACL Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def bfd_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_bfd_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_bfd_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent BFD Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def bridge_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_bridge_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_bridge_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Bridge Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def cos_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_cos_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent COS Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def cos_redecn_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_cos_redecn_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_redecn_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent COS Redecn Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def fdb_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_fdb_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent FDB Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def flex_parser_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_flex_parser_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_flex_parser_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Flex Parser Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def flow_cntr_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_flow_counter_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_flow_counter_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Flow Counter Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def host_ifc_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_host_ifc_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Host Ifc Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def issu_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_issu_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_issu_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Issu Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def lag_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_lag_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Lag Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def mc_cont_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_mc_container_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mc_container_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent MC Container Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def mpls_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_mpls_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mpls_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Mpls Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def mstp_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_mstp_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mstp_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Mstp Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def policer_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_policer_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_policer_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Policer Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def port_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_port_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Port Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def ptp_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_ptp_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_ptp_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Ptp Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def router_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_router_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_router_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Router Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def span_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_span_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_span_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Span Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def telemetry_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_tele_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Tele Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def topology_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_topo_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_topo_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Topo Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def tunnel_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_tunnel_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Tunnel Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def vlan_verbosity_get():
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_vlan_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    print("\nCurrent Vlan Log verbosity level are as follows:")
    print(("\tAPI verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(api_verbosity_level)]))
    print(("\tModule verbosity =" + list(log_verbosity_level.keys())[list(log_verbosity_level.values()).index(module_verbosity_level)]))


def getCmdLineOptions(args):

    parser = argparse.ArgumentParser(description="Get Current Log Verbosity levels for SDK Modules.")
    parser.add_argument('-m', dest='module', choices=list(sdk_module_dict.keys()), default='all', help='specify module to read Log Level of')
    options = parser.parse_args()
    return options


def usage():
    print("usage: sx_api_sdk_module_log_verbosity_get.py \n-[h ]print this help")
    print(("-l [ " + '{}'.format(', '.join(x for x in list(log_verbosity_level.keys()))) + ' ]'))


######################################################
#    Local Data Structures
######################################################
sdk_module_dict = {
    'all': system_verbosity_get,
    'acl': acl_verbosity_get,
    'bfd': bfd_verbosity_get,
    'bridge': bridge_verbosity_get,
    'cos': cos_verbosity_get,
    'redecn': cos_redecn_verbosity_get,
    'fdb': fdb_verbosity_get,
    'flex_parser': flex_parser_verbosity_get,
    'flow_counter': flow_cntr_verbosity_get,
    'host_ifc': host_ifc_verbosity_get,
    # 'issu' : issu_verbosity_get , #TODO : Uncomment. once GET API is avail
    'lag': lag_verbosity_get,
    'mc_cont': mc_cont_verbosity_get,
    'mpls': mpls_verbosity_get,
    'mstp': mstp_verbosity_get,
    'policer': policer_verbosity_get,
    'port': port_verbosity_get,
    'ptp': ptp_verbosity_get,
    'router': router_verbosity_get,
    'span': span_verbosity_get,
    'tele': telemetry_verbosity_get,
    'topo': topology_verbosity_get,
    'tunnel': tunnel_verbosity_get,
    'vlan': vlan_verbosity_get,
}

# *********************************************
#            main                            *
# *********************************************
print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

options = getCmdLineOptions(sys.argv)
module = options.module

if (options is None):
    print("insufficient parameters.")
    print(usage())
else:
    sdk_module_dict[module]()

sx_api_close(handle)
