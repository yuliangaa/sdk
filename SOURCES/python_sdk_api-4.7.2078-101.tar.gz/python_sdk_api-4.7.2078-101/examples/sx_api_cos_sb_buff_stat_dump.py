#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_sb_buff_stat_dump')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
args = parser.parse_args()
print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


""" ############################################################################################ """

""" BUU STATUS GET """
print("--------------- BUFF STATUS GET ------------------------------")

buffer_status_p = new_sx_buffer_status_t_p()
buffer_status = sx_buffer_status_t()

rc = sx_api_cos_buff_status_get(handle, buffer_status_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

print("sx_api_cos_pool_statistic_get [buffer_status]")
print("--------------------------------------------------------------------")
buffer_status = sx_buffer_status_t_p_value(buffer_status_p)
print(("buff_status.free_size_Ingress = %d" % (buffer_status.free_size_ingress)))
print(("buff_status.free_size_Egress = %d" % (buffer_status.free_size_egress)))

""" ############################################################################################ """
