#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the port split configuration for 8x lanes port.
logic of the example is the following:
- Get the current chip type
- Check whether the current chip is suitable for test, since not every chip supports 8x lanes
- Get the current port mapping configurations
- Un-configure used port
- Configure required port width [1x, 2x, 4x, and 8x]
- Configure required port rate(speed) according to port width [1x -> 50Gb, 2x -> 100Gb, 4x -> 200Gb, 8x -> 400Gb]
'''
import sys
import errno
import pdb
import time
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *


def help_cmd():
    print("Current example dimonstrates the basic logic for 8x-lanes port split/un-split flow. ")
    print("In example used local ports which belong to the same module #17.")
    print("Example scenario:")
    print(" - remove existing split configuration for 8x lanes port 0x10001.")
    print(" - configure 8 1x-lane ports with the lane_mask from the [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80] list.")
    print("   Note that in this case neighbot module configuration must be removed.")
    print(" - removed split configuration for every 1x-lane port and restore configuration for neighbor module.")
    print(" - configure 4 2x-lanes ports with lane_mask from the [0x03, 0x0C, 0x30, 0xC0] list.")
    print(" - remove split configuration for every 2x-lanes port.")
    print(" - configure 2 4x-lanes ports with lane_mask from the [0x0F, 0xF0] list.")
    print(" - remove split configuration for every 4x-lanes port.")
    print(" - restore original port split configuration.")
    print("\nIMPORTANT: Note that example is legal for Spectrum3 device.")


help_cmd()
parser = argparse.ArgumentParser(description='sx_api_port_mapping_8x_lanes')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

######################################################
#    defines
######################################################
SWID = 0
UNBIND_SWID = 255
######################################################
#    functions
######################################################


def info(msg):
    print(("-I- " + msg))


def WarningAndQuit(msg):
    sys.stdout.write("-W- " + msg + "\n")
    sys.exit(0)


def ErrorAndQuit(msg, rc):
    sys.stderr.write("-E- " + msg + "\n")
    sys.exit(rc)


def get_chip_type_and_rev():
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        ErrorAndQuit("Failed to initializing register access.\nPlease check that SDK is running.", rc)

    mgir = ku_mgir_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = SWID
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert SX_STATUS_SUCCESS == rc, "sxd_access_reg_mgir failed"

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def port_state_set(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to change port state."


def port_init_handle(handle, port, is_init=True):
    if is_init:
        rc = sx_api_port_init_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to init port"

    else:
        rc = sx_api_port_deinit_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to de-init port"


def port_swid_bind_set(handle, port, swid):
    rc = sx_api_port_swid_bind_set(handle, port, swid)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."


def port_unmapping_set(handle, port, port_attr, log_port_cnt=1):

    log_port_list_p = new_sx_port_log_id_t_arr(log_port_cnt)
    sx_port_log_id_t_arr_setitem(log_port_list_p, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(log_port_cnt)
    mapping_item = new_sx_port_mapping_t_arr(1)

    for i in range(0, log_port_cnt):
        mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, i)
        mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
        mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE
        mapping_item.module_port = port_attr['module']
        mapping_item.slot = port_attr['slot']
        mapping_item.width = 0
        mapping_item.lane_bmap = 0

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_p, port_mapping_list_p, log_port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable mapping."


def rstp_port_state_set(handle, log_port, mstp_state):
    rc = sx_api_rstp_port_state_set(handle, log_port, mstp_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure RSTP port state."


def add_ports_to_vlan(handle, vlan_id, ports_dict):

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SWID, vlan_id, port_list, len(ports_dict))
    assert rc == SX_STATUS_SUCCESS, "Failed to add port into the VLAN."


def ports_mapping_attr_get(handle, ports_list):
    log_port_list_p = new_sx_port_log_id_t_arr(4)
    port_mapping_list_p = new_sx_port_mapping_t_arr(4)
    port_cnt = 1
    port_attr = {}

    for port in ports_list:
        port_dict = {}
        sx_port_log_id_t_arr_setitem(log_port_list_p, 0, port)
        rc = sx_api_port_mapping_get(handle, log_port_list_p, port_mapping_list_p, port_cnt)
        assert rc == SX_STATUS_SUCCESS, "Failed to get port mapping attributes."

        port_mapping_att = sx_port_mapping_t_arr_getitem(port_mapping_list_p, 0)
        width = port_mapping_att.width
        lane_bmap = port_mapping_att.lane_bmap
        module = port_mapping_att.module_port
        slot = port_mapping_att.slot

        port_dict['width'] = width
        port_dict['lmap'] = lane_bmap
        port_dict['module'] = module
        port_dict['slot'] = slot
        port_attr[port] = port_dict
    return port_attr


def port_orig_rate_get(handle, port):
    # Following logic is added to handle case which may happen in case of someone will use 'SPEED' or 'RATE' port speed configuration API type
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    # retrieve the current verbosity level settings
    rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        assert rc == SX_STATUS_SUCCESS, "Error: failed to retrieve the current verbosity setting!\n"

    ''' Modify the port module verbosity level to hide additional log messages
        in case if different API type were used for port speed set and get.
    '''
    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        assert rc == SX_STATUS_SUCCESS, "Error: failed to disable printing all log messages!\n"

    admin_rate_p = new_sx_port_rate_bitmask_t_p()
    capab_rate_p = new_sx_port_rate_bitmask_t_p()
    capab_type_p = new_sx_port_phy_module_type_bitmask_t_p()

    admin_speed_p = new_sx_port_speed_capability_t_p()
    oper_speed_p = new_sx_port_oper_speed_t_p()

    try:
        rc = sx_api_port_rate_capability_get(handle, port, admin_rate_p, capab_rate_p, capab_type_p)
        assert rc in [SX_STATUS_SUCCESS, SX_STATUS_CMD_UNPERMITTED], "sx_api_port_rate_capability_get for port 0x{:x} failed with rc {}".format(port, rc)
        if rc == SX_STATUS_SUCCESS:
            return sx_port_rate_bitmask_t_p_value(admin_rate_p)

        # Unpermitted, looks like port was configured with the 'SPEED'-type of API
        if rc == SX_STATUS_CMD_UNPERMITTED:
            rc = sx_api_port_speed_get(handle, port, admin_speed_p, oper_speed_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_speed_get for port 0x{:x} failed with rc {}".format(port, rc)
            return sx_port_speed_capability_t_p_value(admin_speed_p),
    finally:
        delete_sx_port_phy_module_type_bitmask_t_p(capab_type_p)
        delete_sx_port_rate_bitmask_t_p(capab_rate_p)
        delete_sx_port_rate_bitmask_t_p(admin_rate_p)
        delete_sx_port_oper_speed_t_p(oper_speed_p)
        delete_sx_port_speed_capability_t_p(admin_speed_p)

    # restore original verbosity setting
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_log_verbosity_level_set failed!\n")
        sys.exit(rc)


def port_rate_configuration(handle, port, module_id, slot_id, rate):
    rate_bitmask_p = admin_speed_p = None
    if type(rate) is sx_port_rate_bitmask_t:
        rate_bitmask_p = copy_sx_port_rate_bitmask_t_p(rate)
    elif type(rate) is sx_port_speed_capability_t:
        admin_speed_p = copy_sx_port_speed_capability_t_p(rate)
    else:
        rate_bitmask_p = new_sx_port_rate_bitmask_t_p()
        # In DVS - All rates besides 100M Are enabled by default on SPC3 leopard. if "all" given (after unsplit) -> Re-Enable them
        rate_bitmask_p.rate_100M = rate in ["100M"]
        rate_bitmask_p.rate_1G = rate in ["1G", "all"]
        rate_bitmask_p.rate_10G = rate in ["10G", "all"]
        rate_bitmask_p.rate_25G = rate in ["25G", "all"]
        rate_bitmask_p.rate_40G = rate in ["40G", "all"]
        rate_bitmask_p.rate_50G = rate in ["50G", "all"]
        rate_bitmask_p.rate_100G = rate in ["100G", "all"]
        rate_bitmask_p.rate_200G = rate in ["200G", "all"]
        rate_bitmask_p.rate_400G = rate in ["400G", "all"]

    # enable all modules by default - no need to limit this configuration for now
    phy_type_p = new_sx_port_phy_module_type_bitmask_t_p()
    phy_type_p.module_smf_up_500m = True
    phy_type_p.module_smf_up_2km = True
    phy_type_p.module_smf_above_2km = True
    phy_type_p.module_mmf_up_100m = True
    phy_type_p.module_mmf_above_100m = True
    phy_type_p.module_aoc_acc_up_30m = True
    phy_type_p.module_aoc_acc_above_30m = True
    phy_type_p.module_base_cr = True
    phy_type_p.module_base_tp = True

    # Following logic is added to handle case which may happen in case of someone will use 'SPEED' or 'RATE' port speed configuration API type
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    # retrieve the current verbosity level settings
    rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        assert rc == SX_STATUS_SUCCESS, "Error: failed to retrieve the current verbosity setting!\n"

    ''' Modify the port module verbosity level to hide additional log messages
        in case if different API type were used for port speed set and get.
    '''
    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        assert rc == SX_STATUS_SUCCESS, "Error: failed to disable printing all log messages!\n"

    rc = sx_api_port_rate_set(handle, port, rate_bitmask_p)
    if rc == SX_STATUS_CMD_UNPERMITTED:
        # looks like port was configured with the 'SPEED'-type of API
        if admin_speed_p is None:
            admin_speed_p = new_sx_port_speed_capability_t_p()
            admin_speed_p.mode_auto = True
        rc = sx_api_port_speed_admin_set(handle, port, admin_speed_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to set port admin speed."

    else:
        assert rc == SX_STATUS_SUCCESS, "Failed to set port admin rate."

        module_id_info = sx_mgmt_module_id_info_t()
        module_id_info.slot_id = slot_id
        module_id_info.module_id = module_id
        module_id_info_p = new_sx_mgmt_module_id_info_t_p()
        sx_mgmt_module_id_info_t_p_assign(module_id_info_p, module_id_info)
        rc = sx_mgmt_phy_module_admin_type_set(handle, module_id_info_p, phy_type_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to set port phy type."

    # restore original verbosity setting
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_log_verbosity_level_set failed!\n")
        sys.exit(rc)


def port_unmap_set(handle, port_attrs):
    for port in port_attrs:
        if port_attrs[port]['width'] != 0:
            # un-configure port
            port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
            port_init_handle(handle, port, is_init=False)

            port_swid_bind_set(handle, port, UNBIND_SWID)
            port_unmapping_set(handle, port, port_attrs[port])


def port_mapping_set(handle, port, width, lane_mask, module_id, slot_id):
    log_port_cnt = 1

    log_port_list_p = new_sx_port_log_id_t_arr(log_port_cnt)
    sx_port_log_id_t_arr_setitem(log_port_list_p, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(log_port_cnt)
    mapping_item = new_sx_port_mapping_t_arr(log_port_cnt)

    mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, 0)
    mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
    mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE
    mapping_item.width = width
    mapping_item.module_port = module_id
    mapping_item.slot = slot_id
    mapping_item.lane_bmap = lane_mask

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_p, port_mapping_list_p, log_port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure port mapping."


def port_1x_map_set(handle, ports_list, module_id, slot_id):
    for port in ports_list:

        if ports_list.index(port) == 0:
            lanes_mask = 0x01
        elif ports_list.index(port) == 1:
            lanes_mask = 0x02
        elif ports_list.index(port) == 2:
            lanes_mask = 0x04
        elif ports_list.index(port) == 3:
            lanes_mask = 0x08
        elif ports_list.index(port) == 4:
            lanes_mask = 0x10
        elif ports_list.index(port) == 5:
            lanes_mask = 0x20
        elif ports_list.index(port) == 6:
            lanes_mask = 0x40
        elif ports_list.index(port) == 7:
            lanes_mask = 0x80

        port_mapping_set(handle, port, SX_COS_PORT_1X_LANES_WIDTH_E, lanes_mask, module_id, slot_id)
        port_swid_bind_set(handle, port, SWID)
        port_init_handle(handle, port, is_init=True)
        rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)
        add_ports_to_vlan(handle, 1, {port: SX_UNTAGGED_MEMBER})
        port_rate_configuration(handle, port, module_id, slot_id, "50G")
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def port_2x_map_set(handle, ports_list, module_id, slot_id):
    for port in ports_list:
        if ports_list.index(port) == 0:
            lanes_mask = 0x03
        elif ports_list.index(port) == 1:
            lanes_mask = 0x0C
        elif ports_list.index(port) == 2:
            lanes_mask = 0x30
        elif ports_list.index(port) == 3:
            lanes_mask = 0xC0

        port_mapping_set(handle, port, SX_COS_PORT_2X_LANES_WIDTH_E, lanes_mask, module_id, slot_id)
        port_swid_bind_set(handle, port, SWID)
        port_init_handle(handle, port, is_init=True)
        rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)
        add_ports_to_vlan(handle, 1, {port: SX_UNTAGGED_MEMBER})
        port_rate_configuration(handle, port, module_id, slot_id, "100G")
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def port_4x_map_set(handle, ports_list, module_id, slot_id):

    for port in ports_list:
        lanes_mask = 0x0F if ports_list.index(port) == 0 else 0xF0

        port_mapping_set(handle, port, SX_COS_PORT_4X_LANES_WIDTH_E, lanes_mask, module_id, slot_id)
        port_swid_bind_set(handle, port, SWID)
        port_init_handle(handle, port, is_init=True)
        rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)
        add_ports_to_vlan(handle, 1, {port: SX_UNTAGGED_MEMBER})
        port_rate_configuration(handle, port, module_id, slot_id, "200G")
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def port_8x_map_set(handle, port, module_id, slot_id, rate="400G"):

    lanes_mask = 0xFF
    port_mapping_set(handle, port, SX_COS_PORT_8X_LANES_WIDTH_E, lanes_mask, module_id, slot_id)
    port_swid_bind_set(handle, port, SWID)
    port_init_handle(handle, port, is_init=True)
    rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)
    add_ports_to_vlan(handle, 1, {port: SX_UNTAGGED_MEMBER})
    port_rate_configuration(handle, port, module_id, slot_id, rate)
    port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


################################################################################
def main():

    used_ports = [0x10001, 0x10002, 0x10003, 0x10004]  # take all ports from single module #17
    neigh_ports = [0x10005, 0x10006, 0x10007, 0x10008]  # local ports which belong to neighbor module #16

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        ErrorAndQuit("Failed to open api handle.\nPlease check that SDK is running.", rc)

    # Check the current chip type
    device_id, device_hw_revision = get_chip_type_and_rev()
    if device_id != SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        WarningAndQuit("The following example is suitable only for Spectrum3 chip.")

    info("Start.")

    # Get the current port speeds on bound ports
    orig_speeds_list = [port_orig_rate_get(handle, used_ports[0]), port_orig_rate_get(handle, neigh_ports[0])]

    # Get the current port mapping attributes since first of all we need to remove current configuration
    port_attrs = ports_mapping_attr_get(handle, used_ports)
    port_unmap_set(handle, port_attrs)

    info("Configure 8 1x-lanes ports and rate to 50Gb (or auto).")
    # Note that physically single module can have only 4 active ports, so in order to have 8 1x-lane ports
    # we need to use resources of the neighbor module.
    # Before applying config for 8 1x-lane ports we need to remove configuration from the neighbor module
    neigh_port_attrs = ports_mapping_attr_get(handle, neigh_ports)
    port_unmap_set(handle, neigh_port_attrs)

    # apply 1x-lane configuration to all ports
    port_1x_map_set(handle, used_ports + neigh_ports, port_attrs[used_ports[0]]['module'], port_attrs[used_ports[0]]['slot'])
    info("Now we have four 1x lane ports.\n")

    # remove current port split configuration
    port_attrs = ports_mapping_attr_get(handle, used_ports + neigh_ports)
    port_unmap_set(handle, port_attrs)

    # restore neighbor module configuration - we won't need it any more
    port_8x_map_set(handle, neigh_ports[0], neigh_port_attrs[neigh_ports[0]]['module'], port_attrs[used_ports[0]]['slot'])

    info("Configure 4 2x-lanes ports and rate to 100Gb (or auto).")
    port_2x_map_set(handle, used_ports, port_attrs[used_ports[0]]['module'], port_attrs[used_ports[0]]['slot'])
    info("Now we have four 2x lanes ports.\n")

    # remove current port split configuration
    port_attrs = ports_mapping_attr_get(handle, used_ports)
    port_unmap_set(handle, port_attrs)

    info("Configure 2 4x-lanes ports and rate to 200Gb (or auto).")
    port_4x_map_set(handle, used_ports[0::2], port_attrs[used_ports[0]]['module'], port_attrs[used_ports[0]]['slot'])
    info("Now we have two 4x lanes ports.\n")

    # remove current port split configuration
    port_attrs = ports_mapping_attr_get(handle, used_ports)
    port_unmap_set(handle, port_attrs)
    neigh_port_attrs = ports_mapping_attr_get(handle, [neigh_ports[0]])

    info("Configure 1 8x-lanes ports and set Rate back to all bits .")
    port_8x_map_set(handle, used_ports[0], port_attrs[used_ports[0]]['module'], port_attrs[used_ports[0]]['slot'], rate=orig_speeds_list[0])
    port_rate_configuration(handle, neigh_ports[0], neigh_port_attrs[neigh_ports[0]]['module'], neigh_port_attrs[neigh_ports[0]]['slot'], rate=orig_speeds_list[1])
    info("Now we have single 8x lanes port.\n")

    info("Done.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
