#!/usr/bin/env python
'''
This file contains Python command example for the FDB DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import os
import binascii
import socket
import struct
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *

print_api_example_disclaimer()

entry_dict = {0: 'STATIC', 1: 'REMOTE', 2: 'NONAGEABLE', 3: 'AGEABLE', 4: 'ALL',
              5: 'AGED', 6: 'NONAGED', 7: 'POLICY_INVALID'}
action_dict = {0: 'FORWARD', 1: 'MIRROR_TO_CPU', 2: 'TRAP', 3: 'FORWARD_TO_ROUTER',
               4: 'INVALID', 5: 'INVALID', 6: 'INVALID', 7: 'INVALID', 8: 'INVALID', 9: 'INVALID', 10: 'INVALID', 11: 'INVALID',
               12: 'INVALID', 13: 'INVALID', 14: 'INVALID', 15: 'DISCARD'}
dest_type_dict = {0: 'Logical Port', 1: 'Next Hop', 2: 'ECMP'}
ERR_FILE_LOCATION = '/tmp/python_err_log.txt'


def addr_str_get(addr, version):
    if version == SX_IP_VERSION_IPV4:
        addr_str = int_to_ip(addr.ipv4.s_addr)
    else:
        addr_int = ip_to_int(__list_to_ipv6_str([uint8_t_arr_getitem(addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i) for i in range(16)]), True)
        addr_str = int_to_ip(addr_int, True)

    return addr_str


def ip_to_int(ipstr, is_ipv6=False):
    if is_ipv6:
        return ipv6_to_int(ipstr)
    else:
        return ipv4_to_int(ipstr)


def ipv4_to_int(ipstr):
    return struct.unpack('!I', socket.inet_aton(ipstr))[0]


def ipv6_to_int(ipv6_addr):
    return int(binascii.hexlify(socket.inet_pton(socket.AF_INET6, ipv6_addr)), 16)


def int_to_ip(n, is_ipv6=False):
    if is_ipv6:
        return int_to_ipv6(n)
    else:
        return int_to_ipv4(n)


def int_to_ipv4(n):
    return socket.inet_ntoa(struct.pack('!I', n))


def int_to_ipv6(ipv6_addr):
    a = ipv6_addr >> 64
    b = ipv6_addr & ((1 << 64) - 1)
    return socket.inet_ntop(socket.AF_INET6, struct.pack('!2Q', a, b))


def __list_to_ipv6_str(addr):
    ipv6_str = ""
    for i in range(0, len(addr), 4):
        for j in range(0, 4, 2):
            byte_1 = str(hex(addr[i + 3 - j]))
            b_1 = byte_1.replace("0x", "") if len(byte_1) == 4 else byte_1.replace("0x", "0")
            byte_2 = str(hex(addr[i + 3 - (j + 1)]))
            b_2 = byte_2.replace("0x", "") if len(byte_2) == 4 else byte_2.replace("0x", "0")
            ipv6_str += b_1 + b_2 + ":"
    return ipv6_str[0:-1]


file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

swid_cnt_p = new_uint32_t_p()
uint32_t_p_assign(swid_cnt_p, 0)
rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)

swid_cnt = uint32_t_p_value(swid_cnt_p)
swid_list_p = new_sx_swid_t_arr(swid_cnt)
rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)

mac_entry_arr = new_sx_fdb_uc_mac_addr_params_t_arr(64)
key_p = new_sx_fdb_uc_mac_addr_params_t_p()
key_filter_p = new_sx_fdb_uc_key_filter_t_p()
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 64)
header_printed = False

if swid_cnt == 0:
    print("No SWID entries found!")


for i in range(0, swid_cnt):
    swid = sx_swid_t_arr_getitem(swid_list_p, i)

    rc = sx_api_fdb_uc_mac_addr_get(handle, swid, SX_ACCESS_CMD_GET_FIRST, SX_FDB_UC_ALL, key_p, key_filter_p, mac_entry_arr, data_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_fdb_uc_mac_addr_get failed, rc = %d" % (rc))
        sys.exit(rc)
    data_cnt = uint32_t_p_value(data_cnt_p)

    if data_cnt == 0:
        print("No FDB entries found!")

    read_number = 0
    while (data_cnt == 64):
        for i in range(0, data_cnt):
            if not header_printed:
                print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
                print("|%5s|%10s|%10s|%20s|%62s|%20s|%10s|%20s|" % ("SWID", "Entry", "VID", "MAC", "Destination", "Action", "Entry Type", "Destination Type"))
                print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
                header_printed = True

            mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, i)
            if mac_entry.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT:
                destination = "0x%x" % mac_entry.log_port
            elif mac_entry.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP:
                tunnel_id_str = "TUN_ID_%u" % mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id
                ip_version = mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.version
                ip_addr = mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.addr
                ip_addr_str = "_IP_" + addr_str_get(ip_addr, ip_version)
                destination = tunnel_id_str + ip_addr_str
            else:  # ECMP
                destination = "%u" % mac_entry.dest.ecmp
            print("|%5d|%10d|%10d|%20s|%62s|%20s|%10s|%20s|" % (swid, read_number * 64 + i, mac_entry.fid_vid, mac_entry.mac_addr.to_str(),
                                                                destination, action_dict[mac_entry.action], entry_dict[mac_entry.entry_type], dest_type_dict[mac_entry.dest_type]))
            print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")

        key_p.fid_vid = mac_entry.fid_vid
        key_p.mac_addr = mac_entry.mac_addr
        rc = sx_api_fdb_uc_mac_addr_get(handle, swid, SX_ACCESS_CMD_GETNEXT, SX_FDB_UC_ALL, key_p, key_filter_p, mac_entry_arr, data_cnt_p)
        if (rc != SX_STATUS_SUCCESS):
            print("sx_api_fdb_uc_mac_addr_get failed, rc = %d" % (rc))
            sys.exit(rc)

        data_cnt = uint32_t_p_value(data_cnt_p)
        read_number = read_number + 1

    for i in range(0, data_cnt):
        if not header_printed:
            print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
            print("|%5s|%10s|%10s|%20s|%62s|%20s|%10s|%20s|" % ("SWID", "Entry", "VID", "MAC", "Destination", "Action", "Entry Type", "Destination Type"))
            print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
            header_printed = True

        mac_entry = sx_fdb_uc_mac_addr_params_t_arr_getitem(mac_entry_arr, i)
        if mac_entry.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT:
            destination = "0x%x" % mac_entry.log_port
        elif mac_entry.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP:
            tunnel_id_str = "TUN_ID_%u" % mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id
            ip_version = mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.version
            ip_addr = mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.addr
            ip_addr_str = "_IP_" + addr_str_get(ip_addr, ip_version)
            destination = tunnel_id_str + ip_addr_str
        else:  # ECMP
            destination = "%u" % mac_entry.dest.ecmp
        print("|%5d|%10d|%10d|%20s|%62s|%20s|%10s|%20s|" % (swid, read_number * 64 + i, mac_entry.fid_vid, mac_entry.mac_addr.to_str(),
                                                            destination, action_dict[mac_entry.action], entry_dict[mac_entry.entry_type], dest_type_dict[mac_entry.dest_type]))
        print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
