#!/usr/bin/env python
"""
Example detailed description
"""

import os
import sys
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *        # Needed only when using SXD_APIs in the examples
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    # Description str can be same as header in lines 2-4: It will be printed to user when doing <py_example>.py --help
    description_str = """
    This is an example of the description string, which describes the python example content / details, i.e.:
    Python SDK API Example template, to help SDK Developers build custom examples for their features.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--var1", default="1", help="Custom STR Argument, with default value of '1'")
    parser.add_argument("--var2", type=int, default=10, help="Custom Int Argument, with default value of 10")
    parser.add_argument("--port", type=test_infra_common.auto_int, default="10",
                        help="Log port to use, either in hex format - 0x10001, or Int format - 65537")
    return parser.parse_args()


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    # Constant Defines if needed
    TRAP_GROUP = 30

    # For SWID = 0, One can use SPECTRUM_SWID Defined in test_infra_common directly, or by assigning it to local const
    SWID = test_infra_common.SPECTRUM_SWID

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("This example doesn't support SPC1 Example - Exiting gracefully")
            sys.exit(0)

        # Examples using sx_api_host_ifc_trap_group_ext_set, should use trap group allocation mode based on chip:
        # SPC1: Use legacy mode - User is providing the trap group
        # Non-SPC1: Dynamic mode - SDK Will allocate trap group

        TRAP_GROUP = 30
        trap_group_set_cmd, trap_group_unset_cmd = test_infra_common.trap_group_set_unset_cmd_get(handle)

        trap_group_attr = sx_trap_group_attributes_t()
        trap_group_attr.prio = 4
        trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
        trap_group_attr.truncate_size = 0
        trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
        trap_group_attr.is_monitor = False

        # MUST Set to trap group we want, for SPC1 compatibility (SDK Doesn't update out param over SPC1)
        trap_group_attr.trap_group = TRAP_GROUP
        trap_group_attr_p = copy_sx_trap_group_attributes_t_p(trap_group_attr)
        rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SWID, TRAP_GROUP, trap_group_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
            sys.exit(rc)
        TRAP_GROUP = sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group

        print("Created Trap Group = %d", TRAP_GROUP)

        # Do other configuration flows #

        # Deinit configuration if user provided flag
        if args.deinit:
            rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SWID, TRAP_GROUP, trap_group_attr_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
                sys.exit(rc)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
