#!/usr/bin/env python
'''
This example is supported on Spectrum2+ devices.
'''

import sys
import argparse

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import get_chip_type


def main():

    print("[+] Read MAFCR register")

    parser = argparse.ArgumentParser(description='MAFCR read utility')
    parser.add_argument('--clear', action='store_true', help="Clear counter_accu_overflow counter")
    args = parser.parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return rc

    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4]:
        print("MAFCR is supported on chips : spectrum2 / spectrum3 / spectrum4")
        sx_api_close(handle)
        return rc

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if rc != SXD_STATUS_SUCCESS:
        print("Failed to initialize register access.\nPlease check that SDK is running.\n")
        sx_api_close(handle)
        return rc

    try:
        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0
        meta.access_cmd = SXD_ACCESS_CMD_GET

        mafcr = ku_mafcr_reg()
        mafcr.clear = 0
        mafcr.counter_accu_fifo_overflow = 0

        rc = sxd_access_reg_mafcr(mafcr, meta, 1, None, None)
        if rc != SXD_STATUS_SUCCESS:
            raise RuntimeError("Failed to get MAFCR register, rc: %d" % (rc))

        print(("GET: counter_accu_fifo_overflow: %d" % mafcr.counter_accu_fifo_overflow))
        print(("GET: packets_inc_units: %d" % mafcr.packets_inc_units))
        print(("GET: bytes_inc_units: %d" % mafcr.bytes_inc_units))

        if args.clear:
            meta.access_cmd = SXD_ACCESS_CMD_SET

            mafcr.clear = 1

            rc = sxd_access_reg_mafcr(mafcr, meta, 1, None, None)
            if rc != SXD_STATUS_SUCCESS:
                print("Failed to get MAFCR register, rc: %d" % (rc))
                raise RuntimeError("Failed to get MAFCR register, rc: %d" % (rc))

            print(("SET: clear: %d" % mafcr.clear))
            print(("SET: counter_accu_fifo_overflow: %d" % mafcr.counter_accu_fifo_overflow))

    finally:
        sx_api_close(handle)
        sxd_access_reg_deinit()

    print("[+] Done")
    return 0


if __name__ == '__main__':
    sys.exit(main())
