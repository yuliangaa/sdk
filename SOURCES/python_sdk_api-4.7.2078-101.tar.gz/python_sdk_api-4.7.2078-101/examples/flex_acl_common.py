#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""


import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

########################################################################
# ARGUMENTS PARSING
########################################################################


INVALID_GROUP_ID = 0xFFFFFFFF
dir_dict = {
    SX_ACL_DIRECTION_INGRESS: 'INGRESS',
    SX_ACL_DIRECTION_EGRESS: 'EGRESS',
    SX_ACL_DIRECTION_RIF_INGRESS: 'RIF_INGRESS',
    SX_ACL_DIRECTION_RIF_EGRESS: 'RIF_EGRESS',
    SX_ACL_DIRECTION_TPORT_INGRESS: 'TPORT_INGRESS',
    SX_ACL_DIRECTION_TPORT_EGRESS: 'TPORT_EGRESS',
    SX_ACL_DIRECTION_CPU_INGRESS: 'CPU_INGRESS',
    SX_ACL_DIRECTION_CPU_EGRESS: 'CPU_EGRESS',
    SX_ACL_DIRECTION_MULTI_POINTS_E: 'MULTI_POINTS'
}

key_type_dict = {
    FLEX_ACL_KEY_INVALID: 'INVALID',
    FLEX_ACL_KEY_DMAC: 'DMAC',
    FLEX_ACL_KEY_SMAC: 'SMAC',
    FLEX_ACL_KEY_ETHERTYPE: 'ETHERTYPE',
    FLEX_ACL_KEY_DEI: 'DEI',
    FLEX_ACL_KEY_PCP: 'PCP',
    FLEX_ACL_KEY_VLAN_ID: 'VLAN_ID',
    FLEX_ACL_KEY_INNER_DMAC: 'INNER_DMAC',
    FLEX_ACL_KEY_INNER_SMAC: 'INNER_SMAC',
    FLEX_ACL_KEY_INNER_DEI: 'INNER_DEI',
    FLEX_ACL_KEY_INNER_PCP: 'INNER_PCP',
    FLEX_ACL_KEY_INNER_ETHERTYPE: 'INNER_ETHERTYPE',
    FLEX_ACL_KEY_IS_BUM: 'IS_BUM',
    FLEX_ACL_KEY_BUM_BRIDGE_ID: 'BUM_BRIDGE_ID',
    FLEX_ACL_KEY_FID: 'FID',
    FLEX_ACL_KEY_INNER_VLAN_ID: 'INNER_VLAN_ID',
    FLEX_ACL_KEY_DIP: 'DIP',
    FLEX_ACL_KEY_SIP: 'SIP',
    FLEX_ACL_KEY_DSCP: 'DSCP',
    FLEX_ACL_KEY_ECN: 'ECN',
    FLEX_ACL_KEY_IP_PACKET_LENGTH: 'IP_PACKET_LENGTH',
    FLEX_ACL_KEY_IP_PROTO: 'IP_PROTO',
    FLEX_ACL_KEY_TTL: 'TTL',
    FLEX_ACL_KEY_DIPV6: 'DIPV6',
    FLEX_ACL_KEY_SIPV6: 'SIPV6',
    FLEX_ACL_KEY_INNER_SIP: 'INNER_SIP',
    FLEX_ACL_KEY_INNER_DIP: 'INNER_DIP',
    FLEX_ACL_KEY_INNER_DSCP: 'INNER_DSCP',
    FLEX_ACL_KEY_INNER_ECN: 'INNER_ECN',
    FLEX_ACL_KEY_INNER_IP_PROTO: 'INNER_IP_PROTO',
    FLEX_ACL_KEY_INNER_SIPV6: 'INNER_SIPV6',
    FLEX_ACL_KEY_INNER_DIPV6: 'INNER_DIPV6',
    FLEX_ACL_KEY_L4_DESTINATION_PORT: 'L4_DESTINATION_PORT',
    FLEX_ACL_KEY_L4_SOURCE_PORT: 'L4_SOURCE_PORT',
    FLEX_ACL_KEY_TCP_CONTROL: 'TCP_CONTROL',
    FLEX_ACL_KEY_TCP_ECN: 'TCP_ECN',
    FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT: 'INNER_L4_DESTINATION_PORT',
    FLEX_ACL_KEY_INNER_L4_SOURCE_PORT: 'INNER_L4_SOURCE_PORT',
    FLEX_ACL_KEY_ROCE_DEST_QP: "ROCE_DEST_QP",
    FLEX_ACL_KEY_ROCE_PKEY: "ROCE_PKEY",
    FLEX_ACL_KEY_ROCE_BTH_OPCODE: "ROCE_BTH_OPCODE",
    FLEX_ACL_KEY_GRE_KEY: 'GRE_KEY',
    FLEX_ACL_KEY_VNI_KEY: 'VNI_KEY',
    FLEX_ACL_KEY_GRE_PROTOCOL: 'GRE_PROTOCOL',
    FLEX_ACL_KEY_MPLS_LABEL_ID_1: 'MPLS_LABEL_ID_1',
    FLEX_ACL_KEY_MPLS_LABEL_ID_2: 'MPLS_LABEL_ID_2',
    FLEX_ACL_KEY_MPLS_LABEL_ID_3: 'MPLS_LABEL_ID_3',
    FLEX_ACL_KEY_MPLS_LABEL_ID_4: 'MPLS_LABEL_ID_4',
    FLEX_ACL_KEY_MPLS_LABEL_ID_5: 'MPLS_LABEL_ID_5',
    FLEX_ACL_KEY_MPLS_LABEL_ID_6: 'MPLS_LABEL_ID_6',
    FLEX_ACL_KEY_EXP: 'EXP',
    FLEX_ACL_KEY_BOS: 'BOS',
    FLEX_ACL_KEY_MPLS_TTL: 'MPLS_TTL',
    FLEX_ACL_KEY_RW_PCP: 'RW_PCP',
    FLEX_ACL_KEY_L2_DMAC_TYPE: 'L2_DMAC_TYPE',
    FLEX_ACL_KEY_DMAC_IS_UC: 'DMAC_IS_UC',
    FLEX_ACL_KEY_VLAN_TAGGED: 'VLAN_TAGGED',
    FLEX_ACL_KEY_VLAN_VALID: 'VLAN_VALID',
    FLEX_ACL_KEY_DST_PORT: 'DST_PORT',
    FLEX_ACL_KEY_SRC_PORT: 'SRC_PORT',
    FLEX_ACL_KEY_RW_DSCP: 'RW_DSCP',
    FLEX_ACL_KEY_IP_FRAGMENTED: 'IP_FRAGMENTED',
    FLEX_ACL_KEY_IP_DONT_FRAGMENT: 'IP_DONT_FRAGMENT',
    FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST: 'IP_FRAGMENT_NOT_FIRST',
    FLEX_ACL_KEY_IP_OK: 'IP_OK',
    FLEX_ACL_KEY_IS_ARP: 'IS_ARP',
    FLEX_ACL_KEY_URPF_FAIL: 'URPF_FAIL',
    FLEX_ACL_KEY_IP_OPT: 'IP_OPT',
    FLEX_ACL_KEY_IS_IP_V4: 'IS_IP_V4',
    FLEX_ACL_KEY_L3_TYPE: 'L3_TYPE',
    FLEX_ACL_KEY_TTL_OK: 'TTL_OK',
    FLEX_ACL_KEY_L4_OK: 'L4_OK',
    FLEX_ACL_KEY_L4_TYPE: 'L4_TYPE',
    FLEX_ACL_KEY_SWITCH_PRIO: 'SWITCH_PRIO',
    FLEX_ACL_KEY_COLOR: 'COLOR',
    FLEX_ACL_KEY_BUFF: 'BUFF',
    FLEX_ACL_KEY_L4_PORT_RANGE: 'L4_PORT_RANGE',
    FLEX_ACL_KEY_DISCARD_STATE: 'DISCARD_STATE',
    FLEX_ACL_KEY_IS_TRAPPED: 'IS_TRAPPED',
    FLEX_ACL_KEY_RX_LIST: 'RX_LIST',
    FLEX_ACL_KEY_IRIF: 'IRIF',
    FLEX_ACL_KEY_ERIF: 'ERIF',
    FLEX_ACL_KEY_VIRTUAL_ROUTER: 'VIRTUAL_ROUTER',
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS: 'IPV6_EXTENSION_HEADERS',
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS: 'IPV6_EXTENSION_HEADER_EXISTS',
    FLEX_ACL_KEY_USER_TOKEN: 'USER_TOKEN',
    FLEX_ACL_KEY_INNER_VLAN_VALID: 'INNER_VLAN_VALID',
    FLEX_ACL_KEY_INNER_IP_OK: 'INNER_IP_OK',
    FLEX_ACL_KEY_INNER_L3_TYPE: 'INNER_L3_TYPE',
    FLEX_ACL_KEY_INNER_L4_OK: 'INNER_L4_OK',
    FLEX_ACL_KEY_INNER_TTL_OK: 'INNER_TTL_OK',
    FLEX_ACL_KEY_TUNNEL_TYPE: 'TUNNEL_TYPE',
    FLEX_ACL_KEY_GRE_KEY_EXISTS: 'GRE_KEY_EXISTS',
    FLEX_ACL_KEY_TUNNEL_NVE_TYPE: 'TUNNEL_NVE_TYPE',
    FLEX_ACL_KEY_L4_TYPE_EXTENDED: 'L4_TYPE_EXTENDED',
    FLEX_ACL_KEY_IS_MPLS: 'IS_MPLS',
    FLEX_ACL_KEY_MPLS_LABELS_VALID: 'MPLS_LABELS_VALID',
    FLEX_ACL_KEY_RW_EXP: 'RW_EXP',
    FLEX_ACL_KEY_RX_PORT_LIST: 'RX_PORT_LIST',
    FLEX_ACL_KEY_TX_PORT_LIST: 'TX_PORT_LIST',
    FLEX_ACL_KEY_IS_ROUTED: 'IS_ROUTED',
    FLEX_ACL_KEY_CUSTOM_BYTE_0: 'CUSTOM_BYTE_0',
    FLEX_ACL_KEY_CUSTOM_BYTE_1: 'CUSTOM_BYTE_1',
    FLEX_ACL_KEY_CUSTOM_BYTE_2: 'CUSTOM_BYTE_2',
    FLEX_ACL_KEY_CUSTOM_BYTE_3: 'CUSTOM_BYTE_3',
    FLEX_ACL_KEY_CUSTOM_BYTE_4: 'CUSTOM_BYTE_4',
    FLEX_ACL_KEY_CUSTOM_BYTE_5: 'CUSTOM_BYTE_5',
    FLEX_ACL_KEY_CUSTOM_BYTE_6: 'CUSTOM_BYTE_6',
    FLEX_ACL_KEY_CUSTOM_BYTE_7: 'CUSTOM_BYTE_7',
    FLEX_ACL_KEY_CUSTOM_BYTE_8: 'CUSTOM_BYTE_8',
    FLEX_ACL_KEY_CUSTOM_BYTE_9: 'CUSTOM_BYTE_9',
    FLEX_ACL_KEY_CUSTOM_BYTE_10: 'CUSTOM_BYTE_10',
    FLEX_ACL_KEY_CUSTOM_BYTE_11: 'CUSTOM_BYTE_11',
    FLEX_ACL_KEY_CUSTOM_BYTE_12: 'CUSTOM_BYTE_12',
    FLEX_ACL_KEY_CUSTOM_BYTE_13: 'CUSTOM_BYTE_13',
    FLEX_ACL_KEY_CUSTOM_BYTE_14: 'CUSTOM_BYTE_14',
    FLEX_ACL_KEY_CUSTOM_BYTE_15: 'CUSTOM_BYTE_15',
    FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID: 'MPLS_CONTROL_WORD_VALID',
    FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS: 'INNER_IPV6_EXTENSION_HEADERS',
    FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS: 'INNER_IPV6_EXTENSION_HEADERS_EXISTS',
    FLEX_ACL_KEY_MC_TYPE: 'MC_TYPE',
    FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB: 'FREE_RUNNING_CLOCK_MSB',
    FLEX_ACL_KEY_TRAP_ID: 'TRAP_ID',
    FLEX_ACL_KEY_INNER_IS_MPLS: 'INNER_IS_MPLS',
    FLEX_ACL_KEY_INNER_IS_IP_V4: 'INNER_IS_IP_V4',
    FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID: 'INNER_MPLS_CONTROL_WORD_VALID',
    FLEX_ACL_KEY_INNER_IP_OPT: 'INNER_IP_OPT',
    FLEX_ACL_KEY_IP_MORE_FRAGMENTS: 'IP_MORE_FRAGMENTS',
    FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT: 'INNER_IP_DONT_FRAGMENT',
    FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS: 'INNER_IP_MORE_FRAGMENTS',
    FLEX_ACL_KEY_INNER_IP_FRAGMENTED: 'INNER_IP_FRAGMENTED',
    FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST: 'INNER_IP_FRAGMENT_NOT_FIRST',
    FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID: 'ND_SLL_OR_TLL_VALID',
    FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED: 'INNER_L4_TYPE_EXTENDED',
    FLEX_ACL_KEY_INNER_IS_TCP_OPTION: 'INNER_IS_TCP_OPTION',
    FLEX_ACL_KEY_IS_TCP_OPTION: 'IS_TCP_OPTION',
    FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID: 'INNER_MPLS_LABELS_VALID',
    FLEX_ACL_KEY_L2_VALID: 'L2_VALID',
    FLEX_ACL_KEY_FDB_MISS: 'FDB_MISS',
    FLEX_ACL_KEY_LLC_VALID: 'LLC_VALID',
    FLEX_ACL_KEY_INNER_DMAC_VALID: 'INNER_DMAC_VALID',
    FLEX_ACL_KEY_VLAN_TAG_VALID: 'VLAN_TAG_VALID',
    FLEX_ACL_KEY_INNER_VLAN_TAG_VALID: 'INNER_VLAN_TAG_VALID',
    FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID: 'TUNNEL_VLAN_TAG_VALID',
    FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID: 'TUNNEL_INNER_VLAN_TAG_VALID',
    FLEX_ACL_KEY_LAG_HASH: 'LAG_HASH',
    FLEX_ACL_KEY_ECMP_HASH: 'ECMP_HASH',
    FLEX_ACL_KEY_ALU_CARRY_FLAG: 'ALU_CARRY_FLAG',
    FLEX_ACL_KEY_PORT_USER_MEMORY: 'PORT_USER_MEMORY',
    FLEX_ACL_KEY_PACKET_IS_ELEPHANT: 'PACKET_IS_ELEPHANT',
    FLEX_ACL_KEY_RX_TUNNEL_LIST: 'RX_TUNNEL_LIST',
    FLEX_ACL_KEY_MAC_COMPARE: 'MAC_COMPARE',
    FLEX_ACL_KEY_IP_COMPARE: 'IP_COMPARE',
    FLEX_ACL_KEY_L4_PORT_COMPARE: 'L4_PORT_COMPARE',
    FLEX_ACL_KEY_DEFAULT_ROUTE_HIT: "DEFAULT_ROUTE_HIT",
    FLEX_ACL_KEY_AR_PACKET_CLASS: "AR_PACKET_CLASS",
    FLEX_ACL_KEY_SRC_PHY_PORT: "SRC_PHY_PORT",
    FLEX_ACL_KEY_GP_REGISTER_0: 'GP_REGISTER_0',
    FLEX_ACL_KEY_GP_REGISTER_1: 'GP_REGISTER_1',
    FLEX_ACL_KEY_GP_REGISTER_2: 'GP_REGISTER_2',
    FLEX_ACL_KEY_GP_REGISTER_3: 'GP_REGISTER_3',
    FLEX_ACL_KEY_GP_REGISTER_4: 'GP_REGISTER_4',
    FLEX_ACL_KEY_GP_REGISTER_5: 'GP_REGISTER_5',
    FLEX_ACL_KEY_GP_REGISTER_6: 'GP_REGISTER_6',
    FLEX_ACL_KEY_GP_REGISTER_7: 'GP_REGISTER_7',
    FLEX_ACL_KEY_GP_REGISTER_8: 'GP_REGISTER_8',
    FLEX_ACL_KEY_GP_REGISTER_9: 'GP_REGISTER_9',
    FLEX_ACL_KEY_GP_REGISTER_0_VALID: 'GP_REGISTER_0_VALID',
    FLEX_ACL_KEY_GP_REGISTER_1_VALID: 'GP_REGISTER_1_VALID',
    FLEX_ACL_KEY_GP_REGISTER_2_VALID: 'GP_REGISTER_2_VALID',
    FLEX_ACL_KEY_GP_REGISTER_3_VALID: 'GP_REGISTER_3_VALID',
    FLEX_ACL_KEY_GP_REGISTER_4_VALID: 'GP_REGISTER_4_VALID',
    FLEX_ACL_KEY_GP_REGISTER_5_VALID: 'GP_REGISTER_5_VALID',
    FLEX_ACL_KEY_GP_REGISTER_6_VALID: 'GP_REGISTER_6_VALID',
    FLEX_ACL_KEY_GP_REGISTER_7_VALID: 'GP_REGISTER_7_VALID',
    FLEX_ACL_KEY_GP_REGISTER_8_VALID: 'GP_REGISTER_8_VALID',
    FLEX_ACL_KEY_GP_REGISTER_9_VALID: 'GP_REGISTER_9_VALID',
    FLEX_ACL_KEY_FPP_0_TOUCHED: "FPP_0_TOUCHED",
    FLEX_ACL_KEY_FPP_1_TOUCHED: "FPP_1_TOUCHED",
    FLEX_ACL_KEY_FPP_2_TOUCHED: "FPP_2_TOUCHED",
    FLEX_ACL_KEY_FPP_3_TOUCHED: "FPP_3_TOUCHED",
    FLEX_ACL_KEY_FPP_4_TOUCHED: "FPP_4_TOUCHED",
    FLEX_ACL_KEY_FPP_5_TOUCHED: "FPP_5_TOUCHED",
    FLEX_ACL_KEY_FPP_6_TOUCHED: "FPP_6_TOUCHED",
    FLEX_ACL_KEY_FPP_7_TOUCHED: "FPP_7_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_0_TOUCHED: "INNER_FPP_0_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_1_TOUCHED: "INNER_FPP_1_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_2_TOUCHED: "INNER_FPP_2_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_3_TOUCHED: "INNER_FPP_3_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_4_TOUCHED: "INNER_FPP_4_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_5_TOUCHED: "INNER_FPP_5_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_6_TOUCHED: "INNER_FPP_6_TOUCHED",
    FLEX_ACL_KEY_INNER_FPP_7_TOUCHED: "INNER_FPP_7_TOUCHED",
    FLEX_ACL_KEY_GP_REGISTER_0_OFFSET: "GP_REGISTER_0_OFFSET",
    FLEX_ACL_KEY_GP_REGISTER_1_OFFSET: "GP_REGISTER_1_OFFSET",
    FLEX_ACL_KEY_RX_PORT_LIST_1_128: 'RX_PORT_LIST_1_128',
    FLEX_ACL_KEY_RX_PORT_LIST_129_258: 'RX_PORT_LIST_129_258',
    FLEX_ACL_KEY_RX_PORT_LIST_0: 'RX_PORT_LIST_0',
    FLEX_ACL_KEY_RX_PORT_LIST_1: 'RX_PORT_LIST_1',
    FLEX_ACL_KEY_RX_PORT_LIST_2: 'RX_PORT_LIST_2',
    FLEX_ACL_KEY_RX_PORT_LIST_3: 'RX_PORT_LIST_3',
    FLEX_ACL_KEY_TX_PORT_LIST_1_128: 'TX_PORT_LIST_1_128',
    FLEX_ACL_KEY_TX_PORT_LIST_129_258: 'TX_PORT_LIST_129_258',
    FLEX_ACL_KEY_TX_PORT_LIST_0: 'TX_PORT_LIST_0',
    FLEX_ACL_KEY_TX_PORT_LIST_1: 'TX_PORT_LIST_1',
    FLEX_ACL_KEY_TX_PORT_LIST_2: 'TX_PORT_LIST_2',
    FLEX_ACL_KEY_TX_PORT_LIST_3: 'TX_PORT_LIST_3',
    FLEX_ACL_KEY_IPSEC_SPI: "IPSEC_SPI",
    FLEX_ACL_KEY_INNER_IPSEC_SPI: "INNER_IPSEC_SPI",
    FLEX_ACL_KEY_TUNNEL_DEI: "TUNNEL_DEI",
    FLEX_ACL_KEY_TUNNEL_PCP: "TUNNEL_PCP",
    FLEX_ACL_KEY_TUNNEL_INNER_DEI: "TUNNEL_INNER_DEI",
    FLEX_ACL_KEY_TUNNEL_INNER_PCP: "TUNNEL_INNER_PCP",
    FLEX_ACL_KEY_MACSEC_DMAC: "MACSEC_DMAC",
    FLEX_ACL_KEY_MACSEC_ETHERTYPE: "MACSEC_ETHERTYPE",
    FLEX_ACL_KEY_MACSEC_VLAN_ID: "MACSEC_VLAN_ID",
    FLEX_ACL_KEY_MACSEC_VNI_ID: "MACSEC_VNI_ID",
    FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID_VALID: "MACSEC_FLOW_SECY_ID_VALID",
    FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID: "MACSEC_FLOW_SECY_ID",
    FLEX_ACL_KEY_MACSEC_SCI_VALID: "MACSEC_SCI_VALID",
    FLEX_ACL_KEY_MACSEC_SCI: "MACSEC_SCI",
    FLEX_ACL_KEY_MACSEC_AN: "MACSEC_AN",
}

action_type_dict = {
    SX_FLEX_ACL_ACTION_FORWARD: 'FORWARD',
    SX_FLEX_ACL_ACTION_TRAP: 'TRAP',
    SX_FLEX_ACL_ACTION_COUNTER: 'COUNTER',
    SX_FLEX_ACL_ACTION_COUNTER_BY_REF: 'COUNTER_BY_REF',
    SX_FLEX_ACL_ACTION_MIRROR: 'MIRROR',
    SX_FLEX_ACL_ACTION_POLICER: 'POLICER',
    SX_FLEX_ACL_ACTION_SET_PRIO: 'SET_PRIO',
    SX_FLEX_ACL_ACTION_SET_VLAN: 'SET_VLAN',
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI: 'SET_INNER_VLAN_PRI',
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI: 'SET_OUTER_VLAN_PRI',
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID: 'SET_INNER_VLAN_ID',
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID: 'SET_OUTER_VLAN_ID',
    SX_FLEX_ACL_ACTION_SET_SRC_MAC: 'SET_SRC_MAC',
    SX_FLEX_ACL_ACTION_SET_DST_MAC: 'SET_DST_MAC',
    SX_FLEX_ACL_ACTION_SET_DSCP: 'SET_DSCP',
    SX_FLEX_ACL_ACTION_SET_BRIDGE: 'SET_BRIDGE',
    SX_FLEX_ACL_ACTION_PBS: 'PBS',
    SX_FLEX_ACL_ACTION_SET_TC: 'SET_TC',
    SX_FLEX_ACL_ACTION_SET_TTL: 'SET_TTL',
    SX_FLEX_ACL_ACTION_DEC_TTL: 'DEC_TTL',
    SX_FLEX_ACL_ACTION_SET_COLOR: 'SET_COLOR',
    SX_FLEX_ACL_ACTION_SET_ECN: 'SET_ECN',
    SX_FLEX_ACL_ACTION_SET_USER_TOKEN: 'SET_USER_TOKEN',
    SX_FLEX_ACL_ACTION_DONT_LEARN: 'DONT_LEARN',
    SX_FLEX_ACL_ACTION_RPF: 'RPF',
    SX_FLEX_ACL_ACTION_MC_ROUTE: 'MC_ROUTE',
    SX_FLEX_ACL_ACTION_TUNNEL_DECAP: 'TUNNEL_DECAP',
    SX_FLEX_ACL_ACTION_GOTO: 'GOTO',
    SX_FLEX_ACL_ACTION_SET_ROUTER: 'SET_ROUTER',
    SX_FLEX_ACL_ACTION_MC: 'MC',
    SX_FLEX_ACL_ACTION_UC_ROUTE: 'UC_ROUTE',
    SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE: 'SET_DSCP_REWRITE',
    SX_FLEX_ACL_ACTION_SET_PCP_REWRITE: 'SET_PCP_REWRITE',
    SX_FLEX_ACL_ACTION_EGRESS_MIRROR: 'EGRESS_MIRROR',
    SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER: 'IGNORE_EGRESS_VLAN_FILTER',
    SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER: 'IGNORE_EGRESS_STP_FILTER',
    SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING: 'DISABLE_OVERLAY_LEARNING',
    SX_FLEX_ACL_ACTION_PORT_FILTER: 'PORT_FILTER',
    SX_FLEX_ACL_ACTION_SET_MPLS_TTL: 'SET_MPLS_TTL',
    SX_FLEX_ACL_ACTION_DEC_MPLS_TTL: 'DEC_MPLS_TTL',
    SX_FLEX_ACL_ACTION_SET_EXP: 'SET_EXP',
    SX_FLEX_ACL_ACTION_SET_EXP_REWRITE: 'SET_EXP_REWRITE',
    SX_FLEX_ACL_ACTION_PBILM: 'PBILM',
    SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP: 'NVE_TUNNEL_ENCAP',
    SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP: 'NVE_MC_TUNNEL_ENCAP',
    SX_FLEX_ACL_ACTION_TRAP_W_USER_ID: 'TRAP_W_USER_ID',
    SX_FLEX_ACL_ACTION_HASH: 'HASH',
    SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN: 'SWAP_INNER_OUTER_VLAN',
    SX_FLEX_ACL_ACTION_SET_VNI: 'SET_VNI',
    SX_FLEX_ACL_ACTION_SET_SIP_ADDR: 'SET_SIP',
    SX_FLEX_ACL_ACTION_SET_DIP_ADDR: 'SET_DIP',
    SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR: 'SET_SIPV6',
    SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR: 'SET_DIPV6',
    SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT: 'SET_L4_SRC_PORT',
    SX_FLEX_ACL_ACTION_SET_L4_DST_PORT: 'SET_L4_DST_PORT',
    SX_FLEX_ACL_ACTION_ALU_IMM: 'ALU_IMMEDIATE',
    SX_FLEX_ACL_ACTION_ALU_REG: 'ALU_REGISTER',
    SX_FLEX_ACL_ACTION_ALU_FIELD: 'ALU_FIELD',
    SX_FLEX_ACL_ACTION_REGISTER_ACCESS: 'REGISTER_ACCESS',
    SX_FLEX_ACL_ACTION_ELEPHANT_SET: 'ELEPHANT_SET',
    SX_FLEX_ACL_ACTION_MIRROR_SAMPLER: 'MIRROR_SAMPLER',
    SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW: 'MIRROR_TRIGGER_DISALLOW',
    SX_FLEX_ACL_ACTION_NAT: 'SET_NAT',
    SX_FLEX_ACL_MACSEC_ACTION_FORWARD: "MACSEC_ACTION_FORWARD",
    SX_FLEX_ACL_MACSEC_ACTION_TRAP: "MACSEC_ACTION_TRAP",
    SX_FLEX_ACL_MACSEC_ACTION_COUNTER: "MACSEC_ACTION_COUNTER",
    SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE: 'SET_VLAN_ETHERTYPE',
    SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR: 'ESTIMATOR',
    SX_FLEX_ACL_ACTION_SET_EMT: 'SET_EMT',
    SX_FLEX_ACL_ACTION_AR_UC_ROUTE: 'AR_UC_ROUTE',
    SX_FLEX_ACL_ACTION_DISABLE_FDB_SECURITY: 'DISABLE_FDB_SECURITY',
    SX_FLEX_ACL_ACTION_FIELD_COPY: 'FIELD_COPY',
    SX_FLEX_ACL_ACTION_FIELD_IMM: 'FIELD_IMM',
    SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE: 'SET_AR_PACKET_PROFILE',
    SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP: 'SET_BUFFER_SNAP',
    SX_FLEX_ACL_ACTION_TRUNCATION: 'TRUNCATION',
}

l2_dmac_type_dict = {
    SX_ACL_L2_DMAC_TYPE_MULTICAST: 'MULTICAST',
    SX_ACL_L2_DMAC_TYPE_BROADCAST: 'BROADCAST',
    SX_ACL_L2_DMAC_TYPE_UNICAST: 'UNICAST'
}

l3_type_dict = {
    SX_ACL_L3_TYPE_IPV4: 'IPV4',
    SX_ACL_L3_TYPE_IPV6: 'IPV6',
    SX_ACL_L3_TYPE_ARP: 'ARP',
    SX_ACL_L3_TYPE_OTHER: 'OTHER'
}

l4_type_dict = {
    SX_ACL_L4_TYPE_INVALID: 'INVALID',
    SX_ACL_L4_TYPE_TCP: 'TCP',
    SX_ACL_L4_TYPE_UDP: 'UDP',
    SX_ACL_L4_TYPE_OTHER: 'OTHER'
}

forward_action_dict = {
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD: 'FORWARD',
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD: 'DISCARD',
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD: 'SOFT_DISCARD',
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT: 'PERMIT',
}

action_macsec_forward_dict = {
    SX_MACSEC_ACL_FORWARD_ACTION_TYPE_FORWARD: 'FORWARD',
    SX_MACSEC_ACL_FORWARD_ACTION_TYPE_DISCARD: 'DISCARD',
    SX_MACSEC_ACL_FORWARD_ACTION_TYPE_BYPASS: 'BYPASS',
}

trap_action_dict = {
    SX_ACL_TRAP_ACTION_TYPE_TRAP: 'TRAP',
    SX_ACL_TRAP_ACTION_TYPE_DISCARD: 'DISCARD',
    SX_ACL_TRAP_ACTION_TYPE_SOFT_DISCARD: 'SOFT_DISCARD',
}

tunnel_type_dict = {
    SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4: 'IPINIP_P2P_IPV4_IN_IPV4',
    SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE: 'IPINIP_P2P_IPV4_IN_GRE',

    SX_TUNNEL_TYPE_NVE_VXLAN: 'NVE_VXLAN',
    SX_TUNNEL_TYPE_NVE_VXLAN_GPE: 'NVE_VXLAN_GPE',
    SX_TUNNEL_TYPE_NVE_GENEVE: 'NVE_GENEVE',
    SX_TUNNEL_TYPE_NVE_NVGRE: 'NVE_NVGRE',
    SX_TUNNEL_TYPE_NVE_VXLAN_IPV6: 'NVE_VXLAN_IPV6',
    SX_TUNNEL_TYPE_NVE_NVGRE_IPV6: 'NVE_NVGRE_IPV6',
}

# action_nve_tunnel_encap_type_dict = {
#    SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP: 'NEXT_HOP',
#    SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP: "ECMP",
# }

l4_type_extended_dict = {
    SX_ACL_L4_TYPE_EXTENDED_TCP: 'TCP',
    SX_ACL_L4_TYPE_EXTENDED_UDP: 'UDP',
    SX_ACL_L4_TYPE_EXTENDED_BTH: 'BTH',
    SX_ACL_L4_TYPE_EXTENDED_BTHOUDP: 'BTHOUDP',
    SX_ACL_L4_TYPE_EXTENDED_ICMP: 'ICMP',
    SX_ACL_L4_TYPE_EXTENDED_IGMP: 'IGMP',
    SX_ACL_L4_TYPE_EXTENDED_AH: 'AH',
    SX_ACL_L4_TYPE_EXTENDED_ESP: 'ESP',
    SX_ACL_L4_TYPE_EXTENDED_RAW: 'RAW',
    SX_ACL_L4_TYPE_EXTENDED_OTHERS: 'OTHERS'
}

port_list_match_dict = {
    SX_ACL_PORT_LIST_MATCH_NEGATIVE: 'NEGATIVE',
    SX_ACL_PORT_LIST_MATCH_POSITIVE: 'POSITIVE'
}

action_set_vlan_type_dict = {
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH: 'PUSH',
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_POP: 'POP'
}

action_set_vlan_ethertype_type_dict = {
    SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_OUTER_E: 'SET OUTER',
    SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_INNER_E: 'SET INNER',
    SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_OUTER_E: 'COPY OUTER',
    SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_INNER_E: 'COPY INNER',
    SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SWAP_INNER_OUTER_E: 'SWAP INNER OUTER'
}

qinq_tunnel_qos_dict = {
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_UNIFORM: 'UNIFORM',
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_PIPE: 'PIPE'
}

action_color_type_dict = {
    SX_ACL_FLEX_COLOR_GREEN: 'GREEN',
    SX_ACL_FLEX_COLOR_YELLOW: 'YELLOW',
    SX_ACL_FLEX_COLOR_RED: 'RED'
}

rpf_action_dict = {
    SX_ACL_RPF_ACTION_TYPE_DISABLED: 'DISABLED',
    SX_ACL_RPF_ACTION_TYPE_DROP: 'DROP',
    SX_ACL_RPF_ACTION_TYPE_TRAP: 'TRAP'
}

action_goto_cmd_dict = {
    SX_ACL_ACTION_GOTO_JUMP: 'JUMP',
    SX_ACL_ACTION_GOTO_CALL: 'CALL',
    SX_ACL_ACTION_GOTO_BREAK: 'BREAK',
    SX_ACL_ACTION_GOTO_TERMINATE: 'TERMINATE'
}

action_rewrite_cmd_dict = {
    SX_ACL_ACTION_REWRITE_ENABLE: 'ENABLE',
    SX_ACL_ACTION_REWRITE_DISABLE: 'DISABLE'
}

action_hash_command_dict = {
    SX_ACL_ACTION_HASH_COMMAND_NONE: 'NONE',
    SX_ACL_ACTION_HASH_COMMAND_SET: 'SET',
    SX_ACL_ACTION_HASH_COMMAND_XOR: 'XOR',
    SX_ACL_ACTION_HASH_COMMAND_RANDOM: 'RANDOM',
    SX_ACL_ACTION_HASH_COMMAND_COPY: 'COPY',
    SX_ACL_ACTION_HASH_COMMAND_SWAP: 'SWAP'
}

action_hash_type_dict = {
    SX_ACL_ACTION_HASH_TYPE_LAG: 'LAG',
    SX_ACL_ACTION_HASH_TYPE_ECMP: 'ECMP'
}

action_elephant_flow_dict = {
    SX_ACL_ACTION_SET_ELEPHANT_FLOW_E: 'ELEPHANT',
    SX_ACL_ACTION_SET_NON_ELEPHANT_FLOW_E: 'NON_ELEPHANT'
}

action_register_field_dict = {
    SX_FLEX_ACL_FIELD_SELECT_ECMP_HASH: 'ECMP_HASH',
    SX_FLEX_ACL_FIELD_SELECT_LAG_HASH: 'LAG_HASH',
    SX_FLEX_ACL_FIELD_SELECT_RANDOM: 'RANDOM',
    SX_FLEX_ACL_FIELD_SELECT_IP_LENGTH: 'IP_LENGTH',
    SX_FLEX_ACL_FIELD_SELECT_VID: 'VID',
    SX_FLEX_ACL_FIELD_SELECT_USER_TOKEN: 'USER_TOKEN',
    SX_FLEX_ACL_FIELD_SELECT_TTL: 'TTL',
    SX_FLEX_ACL_FIELD_SELECT_DMAC: 'DMAC',
    SX_FLEX_ACL_FIELD_SELECT_SMAC: 'SMAC',
    SX_FLEX_ACL_FIELD_SELECT_DIP: 'DIP',
    SX_FLEX_ACL_FIELD_SELECT_SIP: 'SIP',
    SX_FLEX_ACL_FIELD_SELECT_DIPV6: 'DIPV6',
    SX_FLEX_ACL_FIELD_SELECT_SIPV6: 'SIPV6',
    SX_FLEX_ACL_FIELD_SELECT_L4_SOURCE_PORT: 'L4_SOURCE_PORT',
    SX_FLEX_ACL_FIELD_SELECT_L4_DESTINATION_PORT: 'L4_DESTINATION_PORT',
    SX_FLEX_ACL_FIELD_SELECT_VNI: 'VNI',
    SX_FLEX_ACL_FIELD_SELECT_FID: 'FID',
    SX_FLEX_ACL_FIELD_SELECT_VRID: 'VRID',
    SX_FLEX_ACL_FIELD_SELECT_PORT_USER_MEMORY: 'PORT_USER_MEMORY'
}

action_alu_imm_cmd_dict = {
    SX_ACL_ACTION_ALU_IMM_COMMAND_SET: 'SET',
    SX_ACL_ACTION_ALU_IMM_COMMAND_ADD: 'ADD',
    SX_ACL_ACTION_ALU_IMM_COMMAND_AND: 'AND',
    SX_ACL_ACTION_ALU_IMM_COMMAND_OR: 'OR'
}

action_alu_reg_cmd_dict = {
    SX_ACL_ACTION_ALU_REG_COMMAND_SET: 'SET',
    SX_ACL_ACTION_ALU_REG_COMMAND_ADD: 'ADD',
    SX_ACL_ACTION_ALU_REG_COMMAND_AND: 'AND',
    SX_ACL_ACTION_ALU_REG_COMMAND_OR: 'OR',
    SX_ACL_ACTION_ALU_REG_COMMAND_SUB: 'SUB',
    SX_ACL_ACTION_ALU_REG_COMMAND_XOR: 'XOR',
    SX_ACL_ACTION_ALU_REG_COMMAND_ADDC: 'ADDC',
    SX_ACL_ACTION_ALU_REG_COMMAND_SUBC: 'SUBC'
}

action_alu_field_cmd_dict = {
    SX_ACL_ACTION_ALU_FIELD_COMMAND_SET: 'SET',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_ADD: 'ADD',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_AND: 'AND',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_OR: 'OR',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_SUB: 'SUB',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_XOR: 'XOR',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_ADDC: 'ADDC',
    SX_ACL_ACTION_ALU_FIELD_COMMAND_SUBC: 'SUBC'
}

action_register_access_cmd_dict = {
    SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_COPY: 'COPY',
    SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LOAD: 'LOAD',
    SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE: 'STORE'
}

ar_classifier_dict = {
    SX_AR_CLASSIFIER_ACTION_STATIC_E: 'STATIC',
    SX_AR_CLASSIFIER_ACTION_PROFILE0_E: 'PROFILE0',
    SX_AR_CLASSIFIER_ACTION_PROFILE1_E: 'PROFILE1'
}

stateful_db_op_dict = {
    SX_STATEFUL_DB_OP_NOP_E: 'nop',
    SX_STATEFUL_DB_OP_READ_E: 'read',
    SX_STATEFUL_DB_OP_WRITE_E: 'write',
    SX_STATEFUL_DB_OP_REMOVE_INDICATION_E: 'remove with failure',
    SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E: 'remove without failure',
}

stateful_db_gp_reg_set_dict = {
    SX_STATEFUL_DB_GP_REGISTER_SET_NOP_E: 'nop',
    SX_STATEFUL_DB_GP_REGISTER_SET_0_E: 'set_0',
    SX_STATEFUL_DB_GP_REGISTER_SET_1_E: 'set_1',
    SX_STATEFUL_DB_GP_REGISTER_SET_2_E: 'set_2',
}

buffer_snap_dict = {
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E: 'sw_command',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_WRED_E: 'ing_wred',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_SHARED_BUFFER_DROP_E: 'ing_shared',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_PG_THRESHOLD_E: 'ing_pg_latency',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_TC_THRESHOLD_E: 'ing_tc_latency',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_EGR_TC_LATENCY_E: 'egr_tc_latency',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_0_E: 'acl_0',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_1_E: 'acl_1',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_2_E: 'acl_2',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_3_E: 'acl_3',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_4_E: 'acl_4',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_5_E: 'acl_5',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_6_E: 'acl_6',
    SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_7_E: 'acl_7',
}

truncation_profile_dict = {
    SX_TRUNCATION_PROFILE_TYPE_MIRROR_E: 'mirror',
    SX_TRUNCATION_PROFILE_TYPE_ACL_E: 'acl',
}


def get_key_val_mask_str(key_desc):
    key_value = ""
    key_mask = ""

    if key_desc.key_id == FLEX_ACL_KEY_INVALID:
        key_value = "INVALID"
        key_mask = "INVALID"

    elif key_desc.key_id == FLEX_ACL_KEY_DMAC:
        key_value = key_desc.key.dmac.to_str()
        key_mask = key_desc.mask.dmac.to_str()

    elif key_desc.key_id == FLEX_ACL_KEY_SMAC:
        key_value = key_desc.key.smac.to_str()
        key_mask = key_desc.mask.smac.to_str()

    elif key_desc.key_id == FLEX_ACL_KEY_ETHERTYPE:
        key_value = "0x%x" % key_desc.key.ethertype
        key_mask = "0x%x" % key_desc.mask.ethertype

    elif key_desc.key_id == FLEX_ACL_KEY_DEI:
        key_value = "0x%x" % key_desc.key.dei
        key_mask = "0x%x" % key_desc.mask.dei

    elif key_desc.key_id == FLEX_ACL_KEY_PCP:
        key_value = "0x%x" % key_desc.key.pcp
        key_mask = "0x%x" % key_desc.mask.pcp

    elif key_desc.key_id == FLEX_ACL_KEY_VLAN_ID:
        key_value = "0x%x" % key_desc.key.vlan_id
        key_mask = "0x%x" % key_desc.mask.vlan_id

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DMAC:
        key_value = key_desc.key.inner_dmac.to_str()
        key_mask = key_desc.mask.inner_dmac.to_str()

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_SMAC:
        key_value = key_desc.key.inner_smac.to_str()
        key_mask = key_desc.mask.inner_smac.to_str()

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DEI:
        key_value = "0x%x" % key_desc.key.inner_dei
        key_mask = "0x%x" % key_desc.mask.inner_dei

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_PCP:
        key_value = "0x%x" % key_desc.key.inner_pcp
        key_mask = "0x%x" % key_desc.mask.inner_pcp

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_DEI:
        key_value = "0x%x" % key_desc.key.tunnel_dei
        key_mask = "0x%x" % key_desc.mask.tunnel_dei

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_PCP:
        key_value = "0x%x" % key_desc.key.tunnel_pcp
        key_mask = "0x%x" % key_desc.mask.tunnel_pcp

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_INNER_DEI:
        key_value = "0x%x" % key_desc.key.tunnel_inner_dei
        key_mask = "0x%x" % key_desc.mask.tunnel_inner_dei

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_INNER_PCP:
        key_value = "0x%x" % key_desc.key.tunnel_inner_pcp
        key_mask = "0x%x" % key_desc.mask.tunnel_inner_pcp

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_ETHERTYPE:
        key_value = "0x%x" % key_desc.key.inner_ethertype
        key_mask = "0x%x" % key_desc.mask.inner_ethertype

    elif key_desc.key_id == FLEX_ACL_KEY_FID:
        key_value = "0x%x" % key_desc.key.fid
        key_mask = "0x%x" % key_desc.mask.fid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_VLAN_ID:
        key_value = "0x%x" % key_desc.key.inner_vlan_id
        key_mask = "0x%x" % key_desc.mask.inner_vlan_id

    elif key_desc.key_id == FLEX_ACL_KEY_DIP:
        key_value = ip_addr_to_str(key_desc.key.dip)
        key_mask = ip_addr_to_str(key_desc.mask.dip)

    elif key_desc.key_id == FLEX_ACL_KEY_SIP:
        key_value = ip_addr_to_str(key_desc.key.sip)
        key_mask = ip_addr_to_str(key_desc.mask.sip)

    elif key_desc.key_id == FLEX_ACL_KEY_DSCP:
        key_value = "0x%x" % key_desc.key.dscp
        key_mask = "0x%x" % key_desc.mask.dscp

    elif key_desc.key_id == FLEX_ACL_KEY_ECN:
        key_value = "0x%x" % key_desc.key.ecn
        key_mask = "0x%x" % key_desc.mask.ecn

    elif key_desc.key_id == FLEX_ACL_KEY_ROCE_DEST_QP:
        key_value = "0x%x" % key_desc.key.dest_qp
        key_mask = "0x%x" % key_desc.mask.dest_qp

    elif key_desc.key_id == FLEX_ACL_KEY_ROCE_PKEY:
        key_value = "0x%x" % key_desc.key.pkey
        key_mask = "0x%x" % key_desc.mask.pkey

    elif key_desc.key_id == FLEX_ACL_KEY_ROCE_BTH_OPCODE:
        key_value = "0x%x" % key_desc.key.bth_opcode
        key_mask = "0x%x" % key_desc.mask.bth_opcode

    elif key_desc.key_id == FLEX_ACL_KEY_IP_PACKET_LENGTH:
        key_value = "0x%x" % key_desc.key.ip_packet_length
        key_mask = "0x%x" % key_desc.mask.ip_packet_length

    elif key_desc.key_id == FLEX_ACL_KEY_IP_PROTO:
        key_value = "0x%x" % key_desc.key.ip_proto
        key_mask = "0x%x" % key_desc.mask.ip_proto

    elif key_desc.key_id == FLEX_ACL_KEY_TTL:
        key_value = "0x%x" % key_desc.key.ttl
        key_mask = "0x%x" % key_desc.mask.ttl

    elif key_desc.key_id == FLEX_ACL_KEY_DIPV6:
        key_value = ip_addr_to_str(key_desc.key.dipv6)
        key_mask = ip_addr_to_str(key_desc.mask.dipv6)

    elif key_desc.key_id == FLEX_ACL_KEY_SIPV6:
        key_value = ip_addr_to_str(key_desc.key.sipv6)
        key_mask = ip_addr_to_str(key_desc.mask.sipv6)

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_SIP:
        key_value = ip_addr_to_str(key_desc.key.inner_sip)
        key_mask = ip_addr_to_str(key_desc.mask.inner_sip)

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DIP:
        key_value = ip_addr_to_str(key_desc.key.inner_dip)
        key_mask = ip_addr_to_str(key_desc.mask.inner_dip)

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DSCP:
        key_value = "0x%x" % key_desc.key.inner_dscp
        key_mask = "0x%x" % key_desc.mask.inner_dscp

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_ECN:
        key_value = "0x%x" % key_desc.key.inner_ecn
        key_mask = "0x%x" % key_desc.mask.inner_ecn

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_PROTO:
        key_value = "0x%x" % key_desc.key.inner_ip_proto
        key_mask = "0x%x" % key_desc.mask.inner_ip_proto

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_SIPV6:
        key_value = ip_addr_to_str(key_desc.key.inner_sipv6)
        key_mask = ip_addr_to_str(key_desc.mask.inner_sipv6)

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DIPV6:
        key_value = ip_addr_to_str(key_desc.key.inner_dipv6)
        key_mask = ip_addr_to_str(key_desc.mask.inner_dipv6)

    elif key_desc.key_id == FLEX_ACL_KEY_L4_DESTINATION_PORT:
        key_value = "0x%x" % key_desc.key.l4_destination_port
        key_mask = "0x%x" % key_desc.mask.l4_destination_port

    elif key_desc.key_id == FLEX_ACL_KEY_L4_SOURCE_PORT:
        key_value = "0x%x" % key_desc.key.l4_source_port
        key_mask = "0x%x" % key_desc.mask.l4_source_port

    elif key_desc.key_id == FLEX_ACL_KEY_TCP_CONTROL:
        key_value = "0x%x" % key_desc.key.tcp_control
        key_mask = "0x%x" % key_desc.mask.tcp_control

    elif key_desc.key_id == FLEX_ACL_KEY_TCP_ECN:
        key_value = "0x%x" % key_desc.key.tcp_ecn
        key_mask = "0x%x" % key_desc.mask.tcp_ecn

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT:
        key_value = "0x%x" % key_desc.key.inner_l4_destination_port
        key_mask = "0x%x" % key_desc.mask.inner_l4_destination_port

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_L4_SOURCE_PORT:
        key_value = "0x%x" % key_desc.key.inner_l4_source_port
        key_mask = "0x%x" % key_desc.mask.inner_l4_source_port

    elif key_desc.key_id == FLEX_ACL_KEY_GRE_KEY:
        key_value = "0x%x" % key_desc.key.gre_key
        key_mask = "0x%x" % key_desc.mask.gre_key

    elif key_desc.key_id == FLEX_ACL_KEY_VNI_KEY:
        key_value = "0x%x" % key_desc.key.vni_key
        key_mask = "0x%x" % key_desc.mask.vni_key

    elif key_desc.key_id == FLEX_ACL_KEY_GRE_PROTOCOL:
        key_value = "0x%x" % key_desc.key.gre_protocol
        key_mask = "0x%x" % key_desc.mask.gre_protocol

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_1:
        key_value = "0x%x" % key_desc.key.mpls_label_id_1
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_1

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_2:
        key_value = "0x%x" % key_desc.key.mpls_label_id_2
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_2

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_3:
        key_value = "0x%x" % key_desc.key.mpls_label_id_3
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_3

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_4:
        key_value = "0x%x" % key_desc.key.mpls_label_id_4
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_4

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_5:
        key_value = "0x%x" % key_desc.key.mpls_label_id_5
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_5

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABEL_ID_6:
        key_value = "0x%x" % key_desc.key.mpls_label_id_6
        key_mask = "0x%x" % key_desc.mask.mpls_label_id_6

    elif key_desc.key_id == FLEX_ACL_KEY_EXP:
        key_value = "0x%x" % key_desc.key.exp
        key_mask = "0x%x" % key_desc.mask.exp

    elif key_desc.key_id == FLEX_ACL_KEY_BOS:
        key_value = "0x%x" % key_desc.key.bos
        key_mask = "0x%x" % key_desc.mask.bos

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_TTL:
        key_value = "0x%x" % key_desc.key.mpls_ttl
        key_mask = "0x%x" % key_desc.mask.mpls_ttl

    elif key_desc.key_id == FLEX_ACL_KEY_RW_PCP:
        key_value = "0x%x" % key_desc.key.rw_pcp
        key_mask = "0x%x" % key_desc.mask.rw_pcp

    elif key_desc.key_id == FLEX_ACL_KEY_L2_DMAC_TYPE:
        if key_desc.key.l2_dmac_type in l2_dmac_type_dict:
            key_value = l2_dmac_type_dict[key_desc.key.l2_dmac_type]
            key_mask = "0x%x" % key_desc.mask.l2_dmac_type

    elif key_desc.key_id == FLEX_ACL_KEY_DMAC_IS_UC:
        key_value = "0x%x" % key_desc.key.dmac_is_uc
        key_mask = "0x%x" % key_desc.mask.dmac_is_uc

    elif key_desc.key_id == FLEX_ACL_KEY_VLAN_TAGGED:
        key_value = "0x%x" % key_desc.key.vlan_tagged
        key_mask = "0x%x" % key_desc.mask.vlan_tagged

    elif key_desc.key_id == FLEX_ACL_KEY_VLAN_VALID:
        key_value = "0x%x" % key_desc.key.vlan_valid
        key_mask = "0x%x" % key_desc.mask.vlan_valid

    elif key_desc.key_id == FLEX_ACL_KEY_DST_PORT:
        key_value = "0x%x" % key_desc.key.dst_port
        key_mask = "0x%x" % key_desc.mask.dst_port

    elif key_desc.key_id == FLEX_ACL_KEY_SRC_PORT:
        key_value = "0x%x" % key_desc.key.src_port
        key_mask = "0x%x" % key_desc.mask.src_port

    elif key_desc.key_id == FLEX_ACL_KEY_RW_DSCP:
        key_value = "0x%x" % key_desc.key.rw_dscp
        key_mask = "0x%x" % key_desc.mask.rw_dscp

    elif key_desc.key_id == FLEX_ACL_KEY_IP_FRAGMENTED:
        key_value = "0x%x" % key_desc.key.ip_fragmented
        key_mask = "0x%x" % key_desc.mask.ip_fragmented

    elif key_desc.key_id == FLEX_ACL_KEY_IP_DONT_FRAGMENT:
        key_value = "0x%x" % key_desc.key.ip_dont_fragment
        key_mask = "0x%x" % key_desc.mask.ip_dont_fragment

    elif key_desc.key_id == FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST:
        key_value = "0x%x" % key_desc.key.ip_fragment_not_first
        key_mask = "0x%x" % key_desc.mask.ip_fragment_not_first

    elif key_desc.key_id == FLEX_ACL_KEY_IP_OK:
        key_value = "0x%x" % key_desc.key.ip_ok
        key_mask = "0x%x" % key_desc.mask.ip_ok

    elif key_desc.key_id == FLEX_ACL_KEY_IS_ARP:
        key_value = "0x%x" % key_desc.key.is_arp
        key_mask = "0x%x" % key_desc.mask.is_arp

    elif key_desc.key_id == FLEX_ACL_KEY_URPF_FAIL:
        key_value = "0x%x" % key_desc.key.urpf_fail
        key_mask = "0x%x" % key_desc.mask.urpf_fail

    elif key_desc.key_id == FLEX_ACL_KEY_IP_OPT:
        key_value = "0x%x" % key_desc.key.ip_opt
        key_mask = "0x%x" % key_desc.mask.ip_opt

    elif key_desc.key_id == FLEX_ACL_KEY_IS_IP_V4:
        key_value = "0x%x" % key_desc.key.is_ip_v4
        key_mask = "0x%x" % key_desc.mask.is_ip_v4

    elif key_desc.key_id == FLEX_ACL_KEY_L3_TYPE:
        if key_desc.key.l3_type in l3_type_dict:
            key_value = l3_type_dict[key_desc.key.l3_type]
            key_mask = "0x%x" % (key_desc.mask.l3_type)

    elif key_desc.key_id == FLEX_ACL_KEY_TTL_OK:
        key_value = "0x%x" % key_desc.key.ttl_ok
        key_mask = "0x%x" % key_desc.mask.ttl_ok

    elif key_desc.key_id == FLEX_ACL_KEY_L4_OK:
        key_value = "0x%x" % key_desc.key.l4_ok
        key_mask = "0x%x" % key_desc.mask.l4_ok

    elif key_desc.key_id == FLEX_ACL_KEY_L4_TYPE:
        if key_desc.key.l4_type in l4_type_dict:
            key_value = l4_type_dict[key_desc.key.l4_type]
            key_mask = "0x%x" % (key_desc.mask.l4_type)

    elif key_desc.key_id == FLEX_ACL_KEY_SWITCH_PRIO:
        key_value = "0x%x" % key_desc.key.switch_prio
        key_mask = "0x%x" % key_desc.mask.switch_prio

    elif key_desc.key_id == FLEX_ACL_KEY_COLOR:
        key_value = "0x%x" % key_desc.key.color
        key_mask = "0x%x" % key_desc.mask.color

    elif key_desc.key_id == FLEX_ACL_KEY_BUFF:
        key_value = "0x%x" % key_desc.key.buff
        key_mask = "0x%x" % key_desc.mask.buff

    elif key_desc.key_id == FLEX_ACL_KEY_L4_PORT_RANGE:
        key_value += "0x"
        for i in range(0, RM_API_ACL_PORT_RANGES_MAX):
            key_value += "%x" % sx_acl_port_range_id_t_arr_getitem(key_desc.key.l4_port_range.port_range_list, i)
        key_mask = "0x%x" % key_desc.mask.l4_port_range

    elif key_desc.key_id == FLEX_ACL_KEY_DISCARD_STATE:
        if key_desc.key.discard_state in forward_action_dict:
            key_value = forward_action_dict[key_desc.key.discard_state]
            key_mask = "0x%x" % key_desc.mask.discard_state

    elif key_desc.key_id == FLEX_ACL_KEY_IS_TRAPPED:
        key_value = "0x%x" % key_desc.key.is_trapped
        key_mask = "0x%x" % key_desc.mask.is_trapped

    elif key_desc.key_id == FLEX_ACL_KEY_RX_LIST:
        key_value = "0x%x" % key_desc.key.rx_list
        key_mask = "0x%x" % key_desc.mask.rx_list

    elif key_desc.key_id == FLEX_ACL_KEY_IRIF:
        key_value = "0x%x" % key_desc.key.irif
        key_mask = "0x%x" % key_desc.mask.irif

    elif key_desc.key_id == FLEX_ACL_KEY_ERIF:
        key_value = "0x%x" % key_desc.key.erif
        key_mask = "0x%x" % key_desc.mask.erif

    elif key_desc.key_id == FLEX_ACL_KEY_VIRTUAL_ROUTER:
        key_value = "0x%x" % key_desc.key.virtual_router
        key_mask = "0x%x" % key_desc.mask.virtual_router

    elif key_desc.key_id == FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS:
        key_value = "0x"
        for i in range(0, SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST):
            key_value += "%x" % sx_flex_acl_ipv6_extension_header_t_arr_getitem(key_desc.key.ipv6_extension_headers.extension_headers_list, i)
        key_mask = "0x%x" % key_desc.mask.ipv6_extension_headers

    elif key_desc.key_id == FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS:
        key_value = "0x%x" % key_desc.key.ipv6_extension_header_exists
        key_mask = "0x%x" % key_desc.mask.ipv6_extension_header_exists

    elif key_desc.key_id == FLEX_ACL_KEY_USER_TOKEN:
        key_value = "0x%x" % key_desc.key.user_token
        key_mask = "0x%x" % key_desc.mask.user_token

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_VLAN_VALID:
        key_value = "0x%x" % key_desc.key.inner_vlan_valid
        key_mask = "0x%x" % key_desc.mask.inner_vlan_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_OK:
        key_value = "0x%x" % key_desc.key.inner_ip_ok
        key_mask = "0x%x" % key_desc.mask.inner_ip_ok

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_L3_TYPE:
        if key_desc.key.inner_l3_type in l3_type_dict:
            key_value = l3_type_dict[key_desc.key.inner_l3_type]
            key_mask = "0x%x" % (key_desc.mask.inner_l3_type)

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_L4_OK:
        key_value = "0x%x" % key_desc.key.inner_l4_ok
        key_mask = "0x%x" % key_desc.mask.inner_l4_ok

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_TTL_OK:
        key_value = "0x%x" % key_desc.key.inner_ttl_ok
        key_mask = "0x%x" % key_desc.mask.inner_ttl_ok

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_TYPE:
        if key_desc.key.tunnel_type in tunnel_type_dict:
            key_value = tunnel_type_dict[key_desc.key.tunnel_type]
            key_mask = "0x%x" % key_desc.mask.tunnel_type

    elif key_desc.key_id == FLEX_ACL_KEY_GRE_KEY_EXISTS:
        key_value = "0x%x" % key_desc.key.gre_key_exists
        key_mask = "0x%x" % key_desc.mask.gre_key_exists

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_NVE_TYPE:
        if key_desc.key.tunnel_nve_type in tunnel_type_dict:
            key_value = tunnel_type_dict[key_desc.key.tunnel_nve_type]
            key_mask = "0x%x" % key_desc.mask.tunnel_nve_type

    elif key_desc.key_id == FLEX_ACL_KEY_L4_TYPE_EXTENDED:
        if key_desc.key.l4_type_extended in l4_type_extended_dict:
            key_value = l4_type_extended_dict[key_desc.key.l4_type_extended]
            key_mask = "0x%x" % (key_desc.mask.l4_type_extended)

    elif key_desc.key_id == FLEX_ACL_KEY_IS_MPLS:
        key_value = "0x%x" % key_desc.key.is_mpls
        key_mask = "0x%x" % key_desc.mask.is_mpls

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_LABELS_VALID:
        key_value = "0x%x" % key_desc.key.mpls_labels_valid
        key_mask = "0x%x" % key_desc.mask.mpls_labels_valid

    elif key_desc.key_id == FLEX_ACL_KEY_RW_EXP:
        key_value = "0x%x" % key_desc.key.rw_exp
        key_mask = "0x%x" % key_desc.mask.rw_exp

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST:
        if key_desc.key.rx_port_list.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list.match_type], key_desc.key.rx_port_list.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_1_128:
        if key_desc.key.rx_port_list_1_128.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_1_128.match_type], key_desc.key.rx_port_list_1_128.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_1_128

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_129_258:
        if key_desc.key.rx_port_list_129_258.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_129_258.match_type], key_desc.key.rx_port_list_129_258.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_129_258

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_0:
        if key_desc.key.rx_port_list_0.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_0.match_type], key_desc.key.rx_port_list_0.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_0

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_1:
        if key_desc.key.rx_port_list_1.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_1.match_type], key_desc.key.rx_port_list_1.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_1

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_2:
        if key_desc.key.rx_port_list_2.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_2.match_type], key_desc.key.rx_port_list_2.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_2

    elif key_desc.key_id == FLEX_ACL_KEY_RX_PORT_LIST_3:
        if key_desc.key.rx_port_list_3.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.rx_port_list_3.match_type], key_desc.key.rx_port_list_3.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.rx_port_list_3

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST:
        if key_desc.key.tx_port_list.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list.match_type], key_desc.key.tx_port_list.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_1_128:
        if key_desc.key.tx_port_list_1_128.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_1_128.match_type], key_desc.key.tx_port_list_1_128.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_1_128

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_129_258:
        if key_desc.key.tx_port_list_129_258.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_129_258.match_type], key_desc.key.tx_port_list_129_258.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_129_258

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_0:
        if key_desc.key.tx_port_list_0.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_0.match_type], key_desc.key.tx_port_list_0.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_0

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_1:
        if key_desc.key.tx_port_list_1.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_1.match_type], key_desc.key.tx_port_list_1.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_1

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_2:
        if key_desc.key.tx_port_list_2.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_2.match_type], key_desc.key.tx_port_list_2.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_2

    elif key_desc.key_id == FLEX_ACL_KEY_TX_PORT_LIST_3:
        if key_desc.key.tx_port_list_3.match_type in port_list_match_dict:
            key_value = "Match Type: %s, MC Container ID: 0x%x" % (port_list_match_dict[key_desc.key.tx_port_list_3.match_type], key_desc.key.tx_port_list_3.mc_container_id)
            key_mask = "0x%x" % key_desc.mask.tx_port_list_3

    elif key_desc.key_id == FLEX_ACL_KEY_IS_ROUTED:
        key_value = "0x%x" % key_desc.key.is_routed
        key_mask = "0x%x" % key_desc.mask.is_routed

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_0:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_1:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_2:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_3:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_4:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_5:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_6:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_7:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_8:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_9:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_10:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_11:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_12:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_13:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_14:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_CUSTOM_BYTE_15:
        key_value = "0x%x" % key_desc.key.custom_byte
        key_mask = "0x%x" % key_desc.mask.custom_byte

    elif key_desc.key_id == FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID:
        key_value = "0x%x" % key_desc.key.mpls_control_word_valid
        key_mask = "0x%x" % key_desc.mask.mpls_control_word_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS:
        key_value = "0x%x" % key_desc.key.inner_ipv6_extension_headers
        key_mask = "0x%x" % key_desc.mask.inner_ipv6_extension_headers

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS:
        key_value = "0x%x" % key_desc.key.inner_ipv6_extension_headers_exists
        key_mask = "0x%x" % key_desc.mask.inner_ipv6_extension_headers_exists

    elif key_desc.key_id == FLEX_ACL_KEY_MC_TYPE:
        key_value = "0x%x" % key_desc.key.mc_type_vector
        key_mask = "0x%x" % key_desc.mask.mc_type_vector

    elif key_desc.key_id == FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB:
        key_value = "0x%x" % key_desc.key.free_running_clock_msb
        key_mask = "0x%x" % key_desc.mask.free_running_clock_msb

    elif key_desc.key_id == FLEX_ACL_KEY_TRAP_ID:
        key_value = "0x%x" % key_desc.key.trap_id
        key_mask = "0x%x" % key_desc.mask.trap_id

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IS_MPLS:
        key_value = "0x%x" % key_desc.key.inner_is_mpls
        key_mask = "0x%x" % key_desc.mask.inner_is_mpls

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IS_IP_V4:
        key_value = "0x%x" % key_desc.key.is_ip_v4
        key_mask = "0x%x" % key_desc.mask.is_ip_v4

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID:
        key_value = "0x%x" % key_desc.key.inner_mpls_control_word_valid
        key_mask = "0x%x" % key_desc.mask.inner_mpls_control_word_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_OPT:
        key_value = "0x%x" % key_desc.key.inner_ip_opt
        key_mask = "0x%x" % key_desc.mask.inner_ip_opt

    elif key_desc.key_id == FLEX_ACL_KEY_IP_MORE_FRAGMENTS:
        key_value = "0x%x" % key_desc.key.ip_more_fragments
        key_mask = "0x%x" % key_desc.mask.ip_more_fragments

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT:
        key_value = "0x%x" % key_desc.key.inner_ip_dont_fragment
        key_mask = "0x%x" % key_desc.mask.inner_ip_dont_fragment

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS:
        key_value = "0x%x" % key_desc.key.inner_ip_more_fragments
        key_mask = "0x%x" % key_desc.mask.inner_ip_more_fragments

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_FRAGMENTED:
        key_value = "0x%x" % key_desc.key.inner_ip_fragmented
        key_mask = "0x%x" % key_desc.mask.inner_ip_fragmented

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST:
        key_value = "0x%x" % key_desc.key.inner_ip_fragment_not_first
        key_mask = "0x%x" % key_desc.mask.inner_ip_fragment_not_first

    elif key_desc.key_id == FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID:
        key_value = "0x%x" % key_desc.key.nd_sll_or_tll_valid
        key_mask = "0x%x" % key_desc.mask.nd_sll_or_tll_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED:
        key_value = "0x%x" % key_desc.key.inner_l4_type_extended
        key_mask = "0x%x" % key_desc.mask.inner_l4_type_extended

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IS_TCP_OPTION:
        key_value = "0x%x" % key_desc.key.inner_is_tcp_option
        key_mask = "0x%x" % key_desc.mask.inner_is_tcp_option

    elif key_desc.key_id == FLEX_ACL_KEY_IS_TCP_OPTION:
        key_value = "0x%x" % key_desc.key.is_tcp_option
        key_mask = "0x%x" % key_desc.mask.is_tcp_option

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID:
        key_value = "0x%x" % key_desc.key.inner_mpls_labels_valid
        key_mask = "0x%x" % key_desc.mask.inner_mpls_labels_valid

    elif key_desc.key_id == FLEX_ACL_KEY_L2_VALID:
        key_value = "0x%x" % key_desc.key.l2_valid
        key_mask = "0x%x" % key_desc.mask.l2_valid

    elif key_desc.key_id == FLEX_ACL_KEY_FDB_MISS:
        key_value = "0x%x" % key_desc.key.fdb_miss
        key_mask = "0x%x" % key_desc.mask.fdb_miss

    elif key_desc.key_id == FLEX_ACL_KEY_LLC_VALID:
        key_value = "0x%x" % key_desc.key.llc_valid
        key_mask = "0x%x" % key_desc.mask.llc_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_DMAC_VALID:
        key_value = "0x%x" % key_desc.key.inner_dmac_valid
        key_mask = "0x%x" % key_desc.mask.inner_dmac_valid

    elif key_desc.key_id == FLEX_ACL_KEY_VLAN_TAG_VALID:
        key_value = "0x%x" % key_desc.key.vlan_tag_valid
        key_mask = "0x%x" % key_desc.mask.vlan_tag_valid

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_VLAN_TAG_VALID:
        key_value = "0x%x" % key_desc.key.inner_vlan_tag_valid
        key_mask = "0x%x" % key_desc.mask.inner_vlan_tag_valid

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID:
        key_value = "0x%x" % key_desc.key.tunnel_vlan_tag_valid
        key_mask = "0x%x" % key_desc.mask.tunnel_vlan_tag_valid

    elif key_desc.key_id == FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID:
        key_value = "0x%x" % key_desc.key.tunnel_inner_vlan_tag_valid
        key_mask = "0x%x" % key_desc.mask.tunnel_inner_vlan_tag_valid

    elif key_desc.key_id == FLEX_ACL_KEY_LAG_HASH:
        key_value = "0x%x" % key_desc.key.lag_hash
        key_mask = "0x%x" % key_desc.mask.lag_hash

    elif key_desc.key_id == FLEX_ACL_KEY_ECMP_HASH:
        key_value = "0x%x" % key_desc.key.ecmp_hash
        key_mask = "0x%x" % key_desc.mask.ecmp_hash

    elif key_desc.key_id == FLEX_ACL_KEY_ALU_CARRY_FLAG:
        key_value = "0x%x" % key_desc.key.alu_carry_flag
        key_mask = "0x%x" % key_desc.mask.alu_carry_flag

    elif key_desc.key_id == FLEX_ACL_KEY_PORT_USER_MEMORY:
        key_value = "0x%x" % key_desc.key.port_user_memory
        key_mask = "0x%x" % key_desc.mask.port_user_memory

    elif key_desc.key_id == FLEX_ACL_KEY_PACKET_IS_ELEPHANT:
        key_value = "0x%x" % key_desc.key.packet_is_elephant
        key_mask = "0x%x" % key_desc.mask.packet_is_elephant

    elif key_desc.key_id == FLEX_ACL_KEY_RX_TUNNEL_LIST:
        key_value = "0x%x" % key_desc.key.rx_tunnel_list
        key_mask = "0x%x" % key_desc.mask.rx_tunnel_list

    elif key_desc.key_id == FLEX_ACL_KEY_MAC_COMPARE:
        key_value = "0x%x" % key_desc.key.mac_compare
        key_mask = "0x%x" % key_desc.mask.mac_compare

    elif key_desc.key_id == FLEX_ACL_KEY_IP_COMPARE:
        key_value = "0x%x" % key_desc.key.ip_compare
        key_mask = "0x%x" % key_desc.mask.ip_compare

    elif key_desc.key_id == FLEX_ACL_KEY_L4_PORT_COMPARE:
        key_value = "0x%x" % key_desc.key.l4_port_compare
        key_mask = "0x%x" % key_desc.mask.l4_port_compare

    elif key_desc.key_id == FLEX_ACL_KEY_AR_PACKET_CLASS:
        key_value = "0x%x" % key_desc.key.ar_packet_class
        key_mask = "0x%x" % key_desc.mask.ar_packet_class

    elif key_desc.key_id == FLEX_ACL_KEY_SRC_PHY_PORT:
        key_value = "0x%x" % key_desc.key.src_phy_port
        key_mask = "0x%x" % key_desc.mask.src_phy_port

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_0:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_1:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_2:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_3:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_4:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_5:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_6:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_7:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_8:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_9:
        key_value = "0x%x" % key_desc.key.gp_register
        key_mask = "0x%x" % key_desc.mask.gp_register

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_0_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_1_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_2_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_3_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_4_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_5_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_6_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_7_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_8_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_9_VALID:
        key_value = "0x%x" % key_desc.key.gp_register_extraction_valid
        key_mask = "0x%x" % key_desc.mask.gp_register_extraction_valid

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_0_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_1_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_2_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_3_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_4_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_5_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_6_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_FPP_7_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_0_OFFSET:
        key_value = "0x%x" % key_desc.key.gp_register_offset
        key_mask = "0x%x" % key_desc.mask.gp_register_offset

    elif key_desc.key_id == FLEX_ACL_KEY_GP_REGISTER_1_OFFSET:
        key_value = "0x%x" % key_desc.key.gp_register_offset
        key_mask = "0x%x" % key_desc.mask.gp_register_offset

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_0_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_1_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_2_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_3_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_4_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_5_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_6_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_FPP_7_TOUCHED:
        key_value = "0x%x" % key_desc.key.fpp_touched
        key_mask = "0x%x" % key_desc.mask.fpp_touched

    elif key_desc.key_id == FLEX_ACL_KEY_DEFAULT_ROUTE_HIT:
        key_value = "0x%x" % key_desc.key.default_route_hit
        key_mask = "0x%x" % key_desc.mask.default_route_hit

    elif key_desc.key_id == FLEX_ACL_KEY_IPSEC_SPI:
        key_value = "0x%x" % key_desc.key.ipsec_spi
        key_mask = "0x%x" % key_desc.mask.ipsec_spi

    elif key_desc.key_id == FLEX_ACL_KEY_INNER_IPSEC_SPI:
        key_value = "0x%x" % key_desc.key.inner_ipsec_spi
        key_mask = "0x%x" % key_desc.mask.inner_ipsec_spi

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_DMAC:
        key_value = key_desc.key.macsec_dmac.to_str()
        key_mask = key_desc.mask.macsec_dmac.to_str()

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_ETHERTYPE:
        key_value = "0x%x" % key_desc.key.macsec_ethertype
        key_mask = "0x%x" % key_desc.mask.macsec_ethertype

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_VLAN_ID:
        key_value = "0x%x" % key_desc.key.macsec_vlan_id
        key_mask = "0x%x" % key_desc.mask.macsec_vlan_id

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_VNI_ID:
        key_value = "0x%x" % key_desc.key.macsec_vni_key
        key_mask = "0x%x" % key_desc.mask.macsec_vni_key

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID_VALID:
        key_value = "0x%x" % key_desc.key.macsec_flow_secy_id_valid
        key_mask = "0x%x" % key_desc.mask.macsec_flow_secy_id_valid

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID:
        key_value = "0x%x" % key_desc.key.macsec_flow_secy_id
        key_mask = "0x%x" % key_desc.mask.macsec_flow_secy_id

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_SCI_VALID:
        key_value = "0x%x" % key_desc.key.macsec_sci_valid
        key_mask = "0x%x" % key_desc.mask.macsec_sci_valid

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_SCI:
        key_value = "0x%x" % key_desc.key.macsec_sci
        key_mask = "0x%x" % key_desc.mask.macsec_sci

    elif key_desc.key_id == FLEX_ACL_KEY_MACSEC_AN:
        key_value = "0x%x" % key_desc.key.macsec_an
        key_mask = "0x%x" % key_desc.mask.macsec_an

    return (key_value, key_mask)


def read_flow_counter(handle, counter_id):
    " This function reads a flow counter. "
    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to read flow counter[0x%x]; rc=%d" % (counter_id, rc))
        return 0

    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    return counter_set.flow_counter_packets


def read_flow_estimator_counter(handle, counter_id):
    " This function reads a flow counter. "
    counter_set_p = sx_flow_estimator_counter_set_t()
    rc = sx_api_flow_counter_estimator_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to read flow estimator counter[0x%x]; rc=%d" % (counter_id, rc))
        return 0

    counter_set = sx_flow_estimator_counter_set_t_p_value(counter_set_p)
    return counter_set.flow_estimator_bins


def get_action_fields_str(handle, action):
    action_fields = ""

    if action.type == SX_FLEX_ACL_ACTION_FORWARD:
        if action.fields.action_forward.action in forward_action_dict:
            action_fields = "Action: %s" % forward_action_dict[action.fields.action_forward.action]

    elif action.type == SX_FLEX_ACL_ACTION_TRAP:
        if action.fields.action_trap.action in trap_action_dict:
            action_fields = "Action: %s, Trap ID: 0x%x" % (trap_action_dict[action.fields.action_trap.action], action.fields.action_trap.trap_id)

    elif action.type == SX_FLEX_ACL_ACTION_COUNTER:
        val = read_flow_counter(handle, action.fields.action_counter.counter_id)
        action_fields = "ID:0x%x (Val:%d)" % (action.fields.action_counter.counter_id, val)

    elif action.type == SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR:
        # val = read_flow_estimator_counter(handle, action.fields.action_counter.counter_id)
        val = 0
        action_fields = "Cntr ID:0x%x, Profile ID:%d" % (action.fields.action_flow_estimator.counter.base_counter_id, action.fields.action_flow_estimator.profile_key.profile_id)

    elif action.type == SX_FLEX_ACL_ACTION_SET_EMT:
        action_fields = ""
        for i in range(SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E):
            e = sx_flex_modifier_emt_bind_t_arr_getitem(action.fields.action_set_emt.emt_bind_action, i)
            a = e.emt_bind_type_attr
            if i > 0:
                action_fields += ", "
            action_fields += "{Index:%d type:%d {id:%d type:%d offset:%d,{header:%d offset:%d}}" % (e.emt_bind_index, e.emt_bind_type, a.emt_id.emt_id, a.emt_offset_type, a.emt_offset, a.emt_encap_header_offset.encap_header, a.emt_encap_header_offset.offset)

    elif action.type == SX_FLEX_ACL_ACTION_MIRROR:
        action_fields = "Session ID: 0x%x" % action.fields.action_mirror.session_id

    elif action.type == SX_FLEX_ACL_ACTION_POLICER:
        action_fields = "Policer ID: 0x%x" % action.fields.action_policer.policer_id

    elif action.type == SX_FLEX_ACL_ACTION_SET_PRIO:
        action_fields = "Prio: 0x%x" % action.fields.action_set_prio.prio_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_VLAN:
        if action.fields.action_set_vlan.cmd in action_set_vlan_type_dict and action.fields.action_set_vlan.qinq_tunnel_qos in qinq_tunnel_qos_dict:
            action_fields = "CMD: %s, VLAN: 0x%x, QOS: %s, PCP: 0x%x, DEI: 0x%x" % (action_set_vlan_type_dict[action.fields.action_set_vlan.cmd],
                                                                                    action.fields.action_set_vlan.vlan_id,
                                                                                    qinq_tunnel_qos_dict[action.fields.action_set_vlan.qinq_tunnel_qos],
                                                                                    action.fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.pcp,
                                                                                    action.fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.dei)

    elif action.type == SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI:
        action_fields = "PCP: 0x%x, DEI: 0x%x" % (action.fields.action_set_inner_vlan_prio.pcp, action.fields.action_set_inner_vlan_prio.dei)

    elif action.type == SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI:
        action_fields = "PCP: 0x%x, DEI: 0x%x" % (action.fields.action_set_outer_vlan_prio.pcp, action.fields.action_set_outer_vlan_prio.dei)

    elif action.type == SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID:
        action_fields = "VLAN: 0x%x" % action.fields.action_set_inner_vlan_id.vlan_id

    elif action.type == SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID:
        action_fields = "VLAN: 0x%x" % action.fields.action_set_outer_vlan_id.vlan_id

    elif action.type == SX_FLEX_ACL_ACTION_SET_SRC_MAC:
        action_fields = "SMAC: %s" % action.fields.action_set_src_mac.mac.to_str()

    elif action.type == SX_FLEX_ACL_ACTION_SET_DST_MAC:
        action_fields = "SMAC: %s" % action.fields.action_set_dst_mac.mac.to_str()

    elif action.type == SX_FLEX_ACL_ACTION_SET_DSCP:
        action_fields = "DSCP: 0x%x" % action.fields.action_set_dscp.dscp_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_BRIDGE:
        action_fields = "Bridge ID: 0x%x" % action.fields.action_set_bridge.bridge_id

    elif action.type == SX_FLEX_ACL_ACTION_PBS:
        action_fields = "PBS ID: 0x%x" % action.fields.action_pbs.pbs_id

    elif action.type == SX_FLEX_ACL_ACTION_SET_TC:
        action_fields = "TC: 0x%x" % action.fields.action_set_tc.tc_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_TTL:
        action_fields = "TTL: 0x%x" % action.fields.action_set_ttl.ttl_val

    elif action.type == SX_FLEX_ACL_ACTION_DEC_TTL:
        action_fields = "TTL: 0x%x" % action.fields.action_dec_ttl.ttl_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_COLOR:
        if action.fields.action_set_color.color_val in action_color_type_dict:
            action_fields = action_color_type_dict[action.fields.action_set_color.color_val]

    elif action.type == SX_FLEX_ACL_ACTION_SET_ECN:
        action_fields = "ECN: 0x%x" % action.fields.action_set_ecn.ecn_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_USER_TOKEN:
        action_fields = "User Token: 0x%x, Mask: 0x%x" % (action.fields.action_set_user_token.user_token, action.fields.action_set_user_token.mask)

    elif action.type == SX_FLEX_ACL_ACTION_DONT_LEARN:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_RPF:
        if action.fields.action_rpf.rpf_action in rpf_action_dict:
            if action.fields.action_rpf.rpf_param.rpf_param_type == SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF:
                action_fields = "RPF Action: %s, RPF RIF: 0x%x" % (rpf_action_dict[action.fields.action_rpf.rpf_action], action.fields.action_rpf.rpf_param.rpf_param_value.rpf_rif)
            else:
                action_fields = "RPF Action: %s, RPF RIF: 0x%x" % (rpf_action_dict[action.fields.action_rpf.rpf_action], action.fields.action_rpf.rpf_param.rpf_param_value.rpf_group)

    elif action.type == SX_FLEX_ACL_ACTION_MC_ROUTE:
        action_fields = "Egress MC Container ID: 0x%x" % action.fields.action_mc_route.egress_mc_container

    elif action.type == SX_FLEX_ACL_ACTION_TUNNEL_DECAP:
        action_fields = "Tunnel ID: 0x%x" % action.fields.action_tunnel_decap.tunnel_id

    elif action.type == SX_FLEX_ACL_ACTION_GOTO:
        if action.fields.action_goto.goto_action_cmd in action_goto_cmd_dict:
            action_fields = "CMD: %s, ACL Group ID: 0x%x" % (action_goto_cmd_dict[action.fields.action_goto.goto_action_cmd], action.fields.action_goto.acl_group_id)

    elif action.type == SX_FLEX_ACL_ACTION_SET_ROUTER:
        action_fields = "VRID: 0x%x" % action.fields.action_set_router.vrid

    elif action.type == SX_FLEX_ACL_ACTION_MC:
        action_fields = "MC Container ID: 0x%x" % action.fields.action_mc.mc_container_id

    elif action.type == SX_FLEX_ACL_ACTION_UC_ROUTE:
        if action.fields.action_uc_route.uc_route_type == SX_UC_ROUTE_TYPE_NEXT_HOP:
            action_fields = "UC Route Type: NEXT_HOP, ECMP ID: 0x%x" % action.fields.action_uc_route.uc_route_param.ecmp_id
        elif action.fields.action_uc_route.uc_route_type == SX_UC_ROUTE_TYPE_LOCAL:
            action_fields = "UC Route Type: LOCAL, Local Egress RIF: 0x%x" % action.fields.action_uc_route.uc_route_param.local_egress_rif
        elif action.fields.action_uc_route.uc_route_type == SX_UC_ROUTE_TYPE_IP2ME:
            action_fields = "UC Route Type: IP2ME"

    elif action.type == SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE:
        if action.fields.action_set_dscp_rewrite.set_rewrite_cmd in action_rewrite_cmd_dict:
            action_fields = "Rewrite CMD: %s" % action_rewrite_cmd_dict[action.fields.action_set_dscp_rewrite.set_rewrite_cmd]

    elif action.type == SX_FLEX_ACL_ACTION_SET_PCP_REWRITE:
        if action.fields.action_set_pcp_rewrite.set_rewrite_cmd in action_rewrite_cmd_dict:
            action_fields = "Rewrite CMD: %s" % action_rewrite_cmd_dict[action.fields.action_set_pcp_rewrite.set_rewrite_cmd]

    elif action.type == SX_FLEX_ACL_ACTION_EGRESS_MIRROR:
        action_fields = "Session ID: 0x%x" % action.fields.action_egress_mirror.session_id

    elif action.type == SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_PORT_FILTER:
        action_fields = "MC Container ID: 0x%x" % action.fields.action_port_filter.mc_container_id

    elif action.type == SX_FLEX_ACL_ACTION_SET_MPLS_TTL:
        action_fields = "TTL: 0x%x" % action.fields.action_set_mpls_ttl.ttl_val

    elif action.type == SX_FLEX_ACL_ACTION_DEC_MPLS_TTL:
        action_fields = "TTL: 0x%x" % action.fields.action_dec_mpls_ttl.ttl_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_EXP:
        action_fields = "EXP: 0x%x" % action.fields.action_set_exp.exp_val

    elif action.type == SX_FLEX_ACL_ACTION_SET_EXP_REWRITE:
        if action.fields.action_set_exp_rewrite.set_rewrite_cmd in action_rewrite_cmd_dict:
            action_fields = "Rewrite CMD: %s" % action_rewrite_cmd_dict[action.fields.action_set_exp_rewrite.set_rewrite_cmd]

    elif action.type == SX_FLEX_ACL_ACTION_PBILM:
        action_fields = "PBILM ID: 0x%x" % action.fields.action_pbilm.pbilm_id

    elif action.type == SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
        if action.fields.action_nve_tunnel_encap.encap_type == SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP:
            action_fields = "Underlay DIP: %s, Tunnel ID: %d" % (ip_addr_to_str(action.fields.action_nve_tunnel_encap.underlay_dip), action.fields.action_nve_tunnel_encap.tunnel_id)
        else:
            action_fields = "ECMP ID: %u" % action.fields.action_nve_tunnel_encap.ecmp_id

    elif action.type == SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
        action_fields = "MC Container ID: %d" % (action.fields.action_nve_mc_tunnel_encap.mc_container_id)

    elif action.type == SX_FLEX_ACL_ACTION_TRAP_W_USER_ID:
        if action.fields.action_trap_w_user_id.action in trap_action_dict:
            action_fields = "Action: %s, Trap ID: %d, User ID: %d" % (trap_action_dict[action.fields.action_trap_w_user_id.action], action.fields.action_trap_w_user_id.trap_id, action.fields.action_trap_w_user_id.user_id)

    elif action.type == SX_FLEX_ACL_ACTION_HASH:
        hash_command = "Unknown"
        hash_type = "Unknown"
        if action.fields.action_hash.command in action_hash_command_dict:
            hash_command = action_hash_command_dict[action.fields.action_hash.command]
        if action.fields.action_hash.type in action_hash_type_dict:
            hash_type = action_hash_type_dict[action.fields.action_hash.type]

        action_fields = "Type: %s, Hash Command: %s, Hash Value: %d" % (hash_type, hash_command, action.fields.action_hash.hash_value)
    elif action.type == SX_FLEX_ACL_ACTION_SET_VNI:
        action_fields = "VNI: 0x%x" % action.fields.action_vni.vni_value

    elif action.type == SX_FLEX_ACL_ACTION_SET_SIP_ADDR:
        action_fields = "SIP: %s" % ip_addr_to_str(action.fields.action_set_sip.ip_addr)

    elif action.type == SX_FLEX_ACL_ACTION_SET_DIP_ADDR:
        action_fields = "DIP: %s" % ip_addr_to_str(action.fields.action_set_dip.ip_addr)

    elif action.type == SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR:
        action_fields = "SIPV6: %s" % ip_addr_to_str(action.fields.action_set_sipv6.ip_addr)

    elif action.type == SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR:
        action_fields = "DIPV6: %s" % ip_addr_to_str(action.fields.action_set_dipv6.ip_addr)

    elif action.type == SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT:
        action_fields = "L4 src port: 0x%x" % action.fields.action_set_l4_src_port.l4_port

    elif action.type == SX_FLEX_ACL_ACTION_SET_L4_DST_PORT:
        action_fields = "L4 destination port: 0x%x" % action.fields.action_set_l4_dst_port.l4_port

    elif action.type == SX_FLEX_ACL_ACTION_ALU_IMM:
        if action.fields.action_alu_imm.command in action_alu_imm_cmd_dict:
            if action.fields.action_alu_imm.imm_data_type == SX_ACL_ACTION_ALU_IMM_TYPE_UINT16_E:
                action_fields = "CMD: %s, GP register: 0x%x, Value: 0x%x, Offset: 0x%x, Size: %d" % (action_alu_imm_cmd_dict[action.fields.action_alu_imm.command], action.fields.action_alu_imm.dst_register, action.fields.action_alu_imm.imm_data, action.fields.action_alu_imm.dst_offset, action.fields.action_alu_imm.size)
            if action.fields.action_alu_imm.imm_data_type == SX_ACL_ACTION_ALU_IMM_TYPE_OBJECT_E:
                if action.fields.action_alu_imm.imm_obj.obj_type == SX_ACL_ACTION_ALU_IMM_OBJ_FLOW_COUNTER_TYPE_E:
                    action_fields = "CMD: %s, base_counter_id: 0x%x" % (action_alu_imm_cmd_dict[action.fields.action_alu_imm.command], action.fields.action_alu_imm.imm_obj.obj_data.base_counter_id)
    elif action.type == SX_FLEX_ACL_ACTION_COUNTER_BY_REF:
        action_fields = "GP register: 0x%x" % (action.fields.action_counter_by_ref.gp_reg_lsb)

    elif action.type == SX_FLEX_ACL_ACTION_ALU_REG:
        if action.fields.action_alu_reg.command in action_alu_reg_cmd_dict:
            action_fields = "CMD: %s, SRC GP register: 0x%x, DST GP register: 0x%x, SRC offset: %d, DST offset: %d, Size: %d" % (action_alu_reg_cmd_dict[action.fields.action_alu_reg.command], action.fields.action_alu_reg.src_register, action.fields.action_alu_reg.dst_register, action.fields.action_alu_reg.src_offset, action.fields.action_alu_reg.dst_offset, action.fields.action_alu_reg.size)

    elif action.type == SX_FLEX_ACL_ACTION_ALU_FIELD:
        if action.fields.action_alu_field.src_field in action_register_field_dict and action.fields.action_alu_field.command in action_alu_field_cmd_dict:
            action_fields = "CMD: %s, DST GP register: 0x%x, SRC field: %s" % (action_alu_field_cmd_dict[action.fields.action_alu_field.command], action.fields.action_alu_field.dst_register, action_register_field_dict[action.fields.action_alu_field.src_field])

    elif action.type == SX_FLEX_ACL_ACTION_REGISTER_ACCESS:
        if action.fields.action_register_access.command in action_register_access_cmd_dict:
            action_fields = "CMD: %s" % action_register_access_cmd_dict[action.fields.action_register_access.command]

    elif action.type == SX_FLEX_ACL_ACTION_ELEPHANT_SET:
        if action.fields.action_set_elephant_flow_type.action in action_elephant_flow_dict:
            action_fields = "Elephant set: %s" % action_elephant_flow_dict[action.fields.action_set_elephant_flow_type.action]

    elif action.type == SX_FLEX_ACL_ACTION_MIRROR_SAMPLER:
        action_fields = "Session ID: 0x%x, PRobability rate: %d" % (action.fields.action_mirror_sampler.session_id, action.fields.action_mirror_sampler.mirror_probability_rate)

    elif action.type == SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW:
        disallow_list_p = action.fields.action_mirror_disallow.cfg_list.mirror_trigger_disallow
        disallow_cnt = action.fields.action_mirror_disallow.cfg_list.mirror_trigger_disallow_cnt
        disallow_show_list = []
        type_val_map = {}
        for i in range(disallow_cnt):
            item_t = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(disallow_list_p, i)
            type_val_map[item_t.type] = item_t.mirror_trigger_disallow
        type_list = sorted(type_val_map, key=lambda k: type_val_map[k])
        if disallow_cnt > 0:
            type_val_arr_str = "<type:enable>:["
            for i in type_list:
                type_val_arr_str = "{} <{}:{}>".format(type_val_arr_str, i, type_val_map[i])
            type_val_arr_str = type_val_arr_str + " ]"
            action_fields = "Mirror disallow count: %d, %s" % (disallow_cnt, type_val_arr_str)
        else:
            action_fields = "Mirror disallow count: %d" % (disallow_cnt)

    elif action.type == SX_FLEX_ACL_ACTION_NAT:
        action_fields = "NAT ID: %d, SIP: %s, DIP: %s" % (action.fields.action_nat.nat_id, ip_addr_to_str(action.fields.action_nat.sip), ip_addr_to_str(action.fields.action_nat.dip))
    elif action.type == SX_FLEX_ACL_MACSEC_ACTION_FORWARD:
        if action.fields.macsec_action_forward.action in action_macsec_forward_dict:
            action_fields = "%s, Flow ID: 0x%x " % (action_macsec_forward_dict[action.fields.macsec_action_forward.action], action.fields.macsec_action_forward.data.secy_flow_obj_id)

    elif action.type == SX_FLEX_ACL_MACSEC_ACTION_TRAP:
        action_fields = "UCHECK_ID: 0x%x (%d) " % (action.fields.macsec_action_trap.ucheck_id, action.fields.macsec_action_trap.ucheck_id)

    elif action.type == SX_FLEX_ACL_MACSEC_ACTION_COUNTER:
        action_fields = "Counter ID: 0x%x " % (action.fields.macsec_action_counter.counter_id)

    elif action.type == SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE:
        if action.fields.action_set_vlan_ethertype.ethertype_cmd in action_set_vlan_ethertype_type_dict:
            action_fields = "CMD: %s, Tag mode: 0x%x Set egress ET: %d" % (action_set_vlan_ethertype_type_dict[action.fields.action_set_vlan_ethertype.ethertype_cmd],
                                                                           action.fields.action_set_vlan_ethertype.tag_mode, action.fields.action_set_vlan_ethertype.egress_et_set)

    elif action.type == SX_FLEX_ACL_ACTION_AR_UC_ROUTE:
        if action.fields.action_ar_uc_route.profile_id in ar_classifier_dict:
            action_fields = "AR UC Route : Profile %s, ECMP ID: 0x%x" % (ar_classifier_dict[action.fields.action_ar_uc_route.profile_id],
                                                                         action.fields.action_ar_uc_route.ecmp_id)

    elif action.type == SX_FLEX_ACL_ACTION_DISABLE_FDB_SECURITY:
        action_fields = ""

    elif action.type == SX_FLEX_ACL_ACTION_FIELD_COPY:
        if action.fields.action_field_copy.dst_field in action_register_field_dict and action.fields.action_field_copy.src_field in action_register_field_dict:
            action_fields = "Field copy: DST %s offset: %d, SRC %s offset: %d" % (action_register_field_dict[action.fields.action_field_copy.dst_field],
                                                                                  action.fields.action_field_copy.dst_field_offset,
                                                                                  action_register_field_dict[action.fields.action_field_copy.src_field],
                                                                                  action.fields.action_field_copy.src_field_offset)

    elif action.type == SX_FLEX_ACL_ACTION_FIELD_IMM:
        if action.fields.action_field_imm.dst_field in action_register_field_dict:
            action_fields = "Field imm: %s offset: %d" % (action_register_field_dict[action.fields.action_field_imm.dst_field], action.fields.action_field_imm.field_offset)

    elif action.type == SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE:
        if action.fields.action_ar_packet_profile.ar_packet_profile_type in ar_classifier_dict:
            action_fields = "AR set profile %s" % (ar_classifier_dict[action.fields.action_ar_packet_profile.ar_packet_profile_type])

    elif action.type == SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP:
        if action.fields.action_set_buffer_snap.sb_snap_id in buffer_snap_dict:
            action_fields = "Buffer snap %s" % (buffer_snap_dict[action.fields.action_set_buffer_snap.sb_snap_id])

    elif action.type == SX_FLEX_ACL_ACTION_STATEFUL_DB:
        if action.fields.action_stateful_db.db_op in stateful_db_op_dict and action.fields.action_stateful_db.gp_reg_set in stateful_db_gp_reg_set_dict:
            action_fields = "Stateful DB: partition %d, key_id %d, DB op %s, gp reg %s" % (action.fields.action_stateful_db.partition_id,
                                                                                           action.fields.action_stateful_db.stateful_key_id,
                                                                                           stateful_db_op_dict[action.fields.action_stateful_db.db_op],
                                                                                           stateful_db_gp_reg_set_dict[action.fields.action_stateful_db.gp_reg_set])

    elif action.type == SX_FLEX_ACL_ACTION_TRUNCATION:
        if action.fields.action_truncation.trunc_profile_id.trunc_profile_type in truncation_profile_dict:
            if action.fields.action_truncation.trunc_profile_id.trunc_profile_type == SX_TRUNCATION_PROFILE_TYPE_ACL_E:
                action_fields = "Truncation profile type %s id %d" % (truncation_profile_dict[action.fields.action_truncation.trunc_profile_id.trunc_profile_type],
                                                                      action.fields.action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id)
            if action.fields.action_truncation.trunc_profile_id.trunc_profile_type == SX_TRUNCATION_PROFILE_TYPE_MIRROR_E:
                action_fields = "Truncation profile type %s id %d" % (truncation_profile_dict[action.fields.action_truncation.trunc_profile_id.trunc_profile_type],
                                                                      action.fields.action_truncation.trunc_profile_id.trunc_profile_id.span_session_id)

    return action_fields


def acl_module_verbosity_level_get(handle):

    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_acl_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed in sx_api_acl_log_verbosity_level_get API rc=%d" % rc)
        sys.exit(rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    return module_verbosity_level, api_verbosity_level


def acl_module_verbosity_level_set(handle, module_verbosity, api_verbosity):
    rc = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set ACL log verbosity level")
        sys.exit(rc)


def router_module_verbosity_level_get(handle):
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_router_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p,
                                               api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed in sx_api_router_log_verbosity_level_get API rc=%d" % rc)
        sys.exit(rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    return module_verbosity_level, api_verbosity_level


def router_module_verbosity_level_set(handle, module_verbosity, api_verbosity):
    rc = sx_api_router_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set router API verbosity level")
        sys.exit(rc)


def get_port_lag_bindings(handle, log_port, binding_map):

    group_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(group_cnt_p, 16)
    groups_list_p = new_sx_acl_id_t_arr(16)

    for direction in [SX_ACL_DIRECTION_INGRESS, SX_ACL_DIRECTION_EGRESS]:
        uint32_t_p_assign(group_cnt_p, 16)
        rc = sx_api_acl_port_bindings_get(handle, log_port, direction, groups_list_p, group_cnt_p)
        if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
            print("sx_api_acl_port_bindings_get failed, rc = %d" % (rc))
            sys.exit(rc)

        if rc == SX_STATUS_SUCCESS:
            group_cnt = uint32_t_p_value(group_cnt_p)
            for i in range(0, group_cnt):
                acl_id = sx_acl_id_t_arr_getitem(groups_list_p, i)
                if acl_id not in binding_map:
                    binding_map[acl_id] = []
                binding_map[acl_id].append({'direction': direction, 'log_port': log_port})


def get_all_port_lag_bindings(handle, binding_map):
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 0)
    rc = sx_api_port_device_list_get(handle, None, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)

    swid_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(swid_cnt_p, 0)
    rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    swid_cnt = uint32_t_p_value(swid_cnt_p)
    swid_list_p = new_sx_swid_t_arr(swid_cnt)
    rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    swid_cnt = uint32_t_p_value(swid_cnt_p)

    port_id_list = []
    lag_id_list = []
    lag_member_port_list = []

    for i in range(0, device_info_cnt):
        device_info = sx_device_info_t_arr_getitem(device_info_list_p, i)
        device_id = device_info.dev_id
        for j in range(0, swid_cnt):
            swid = sx_swid_t_arr_getitem(swid_list_p, j)
            port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(port_cnt_p, 0)
            rc = sx_api_port_device_get(handle, device_id, swid, None, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_device_get failed, rc = %d" % (rc))
                sys.exit(rc)
            port_cnt = uint32_t_p_value(port_cnt_p)
            port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
            rc = sx_api_port_device_get(handle, device_id, swid, port_attributes_list, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_device_get failed, rc = %d" % (rc))
                sys.exit(rc)
            port_cnt = uint32_t_p_value(port_cnt_p)
            for k in range(0, port_cnt):
                port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, k)
                log_port = port_attributes.log_port
                port_id_list.append(log_port)

            lag_id_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(lag_id_cnt_p, 0)
            rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET, swid, 0, None, None, lag_id_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
                sys.exit(rc)
            lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)
            lag_id_list_p = new_sx_port_log_id_t_arr(lag_id_cnt)
            rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, swid, 0, None, lag_id_list_p, lag_id_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
                sys.exit(rc)
            lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)
            for k in range(0, lag_id_cnt):
                lag_id = sx_port_log_id_t_arr_getitem(lag_id_list_p, k)
                lag_id_list.append(lag_id)
                log_port_cnt_p = new_uint32_t_p()
                uint32_t_p_assign(log_port_cnt_p, 0)
                rc = sx_api_lag_port_group_get(handle, swid, lag_id, None, log_port_cnt_p)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_lag_port_group_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                log_port_cnt = uint32_t_p_value(log_port_cnt_p)
                if log_port_cnt == 0:
                    continue
                log_port_list_p = new_sx_port_log_id_t_arr(log_port_cnt)
                rc = sx_api_lag_port_group_get(handle, swid, lag_id, log_port_list_p, log_port_cnt_p)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_lag_port_group_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                log_port_cnt = uint32_t_p_value(log_port_cnt_p)
                for n in range(0, log_port_cnt):
                    log_port = sx_port_log_id_t_arr_getitem(log_port_list_p, n)
                    lag_member_port_list.append(log_port)

    for member_port in lag_member_port_list:
        if member_port in port_id_list:
            port_id_list.remove(member_port)

    for port_id in port_id_list:
        is_cpu = check_cpu(int(port_id))
        is_vport = check_vport(int(port_id))
        # check_vport checks for vport and vlags
        if is_vport or is_cpu:
            continue
        get_port_lag_bindings(handle, port_id, binding_map)

    for lag_id in lag_id_list:
        get_port_lag_bindings(handle, lag_id, binding_map)


def check_macsec_init_status(handle):
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("MACSec module is not initialized")
            sys.exit()
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


def is_macsec_enabled_on_port(handle, port):
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
    if rc == SX_STATUS_MODULE_UNINITIALIZED:
        return False

    capab = sx_macsec_port_capability_t()
    capab_p = new_sx_macsec_port_capability_t_p()
    rc = sx_api_macsec_port_capability_get(handle, port, capab_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_port_capability_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    capab = sx_macsec_port_capability_t_p_value(capab_p)
    if capab.macsec_enabled:
        return True
    else:
        return False


def get_all_macsec_port_bindings(handle, binding_map):
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 0)
    rc = sx_api_port_device_list_get(handle, None, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)

    swid_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(swid_cnt_p, 0)
    rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    swid_cnt = uint32_t_p_value(swid_cnt_p)
    swid_list_p = new_sx_swid_t_arr(swid_cnt)
    rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    swid_cnt = uint32_t_p_value(swid_cnt_p)

    port_id_list = []
    lag_id_list = []
    lag_member_port_list = []

    for i in range(0, device_info_cnt):
        device_info = sx_device_info_t_arr_getitem(device_info_list_p, i)
        device_id = device_info.dev_id
        for j in range(0, swid_cnt):
            swid = sx_swid_t_arr_getitem(swid_list_p, j)
            port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(port_cnt_p, 0)
            rc = sx_api_port_device_get(handle, device_id, swid, None, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_device_get failed, rc = %d" % (rc))
                sys.exit(rc)
            port_cnt = uint32_t_p_value(port_cnt_p)
            port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
            rc = sx_api_port_device_get(handle, device_id, swid, port_attributes_list, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_device_get failed, rc = %d" % (rc))
                sys.exit(rc)
            port_cnt = uint32_t_p_value(port_cnt_p)
            for k in range(0, port_cnt):
                port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, k)
                log_port = port_attributes.log_port
                if is_macsec_enabled_on_port(handle, log_port) == 0:
                    continue
                port_id_list.append(log_port)

    for port_id in port_id_list:
        is_cpu = check_cpu(int(port_id))
        is_vport = check_vport(int(port_id))
        # check_vport checks for vport and vlags
        if is_vport or is_cpu:
            continue
        get_port_lag_bindings(handle, port_id, binding_map)


def get_all_rif_bindings(handle, binding_map, rif_id=0):
    module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
    router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rif_id == 0:
        rif_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(rif_cnt_p, 0)
        rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, rif_cnt_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
            return
        elif rc != SX_STATUS_SUCCESS:
            router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
            print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)
        rif_cnt = uint32_t_p_value(rif_cnt_p)
        rif_list_p = new_sx_router_interface_t_arr(rif_cnt)
        rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, None, None, rif_list_p, rif_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
            print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)
        rif_cnt = uint32_t_p_value(rif_cnt_p)
    else:
        rif_cnt = 1
        rif_list_p = new_sx_router_interface_t_arr(rif_cnt)
        sx_router_interface_t_arr_setitem(rif_list_p, 0, rif_id)

    group_cnt_p = new_uint32_t_p()
    groups_list_p = new_sx_acl_id_t_arr(16)
    for i in range(0, rif_cnt):
        rif = sx_router_interface_t_arr_getitem(rif_list_p, i)

        for direction in [SX_ACL_DIRECTION_RIF_INGRESS, SX_ACL_DIRECTION_RIF_EGRESS]:

            uint32_t_p_assign(group_cnt_p, 16)
            rc = sx_api_acl_rif_bindings_get(handle, rif, direction, groups_list_p, group_cnt_p)
            if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
                print("sx_api_acl_rif_bindings_get failed, rc = %d" % (rc))
                router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
                sys.exit(rc)

            if rc == SX_STATUS_SUCCESS:
                group_cnt = uint32_t_p_value(group_cnt_p)
                for i in range(0, group_cnt):
                    acl_id = sx_acl_id_t_arr_getitem(groups_list_p, i)
                    if acl_id not in binding_map:
                        binding_map[acl_id] = []
                    binding_map[acl_id].append({'direction': direction, 'rif': rif})

    router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)


def get_vlan_group_bindings(handle, vlan_group, binding_map):

    group_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(group_cnt_p, 16)
    groups_list_p = new_sx_acl_id_t_arr(16)

    rc = sx_api_acl_vlan_group_bindings_get(handle, vlan_group, SX_ACL_DIRECTION_INGRESS, groups_list_p, group_cnt_p)
    if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
        print("sx_api_acl_vlan_group_bindings_get failed, rc = %d" % (rc))
        return -1

    if rc == SX_STATUS_SUCCESS:
        group_cnt = uint32_t_p_value(group_cnt_p)
        for i in range(0, group_cnt):
            bound_acl = sx_acl_id_t_arr_getitem(groups_list_p, i)
            if bound_acl not in binding_map:
                binding_map[bound_acl] = []
            binding_map[bound_acl].append({'direction': SX_ACL_DIRECTION_INGRESS, 'vlan_group': vlan_group})

    # No support for Egress direction in VLAN group bindings

    return 0


def get_all_vlan_group_bindings(handle, binding_map):
    module_level, api_level = acl_module_verbosity_level_get(handle)
    acl_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    VLAN_GROUP_MAX = 255
    for vlan_group in range(0, VLAN_GROUP_MAX):
        rc = get_vlan_group_bindings(handle, vlan_group, binding_map)
        if rc != 0:
            break
    acl_module_verbosity_level_set(handle, module_level, api_level)
    if rc != 0:
        sys.exit(rc)


def print_region_rules(handle, region_id):
    rules_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt_p, 0)
    rc = sx_api_acl_flex_rules_get(handle, region_id, None, None, rules_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_flex_rules_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rules_cnt = uint32_t_p_value(rules_cnt_p)

    offsets_list_p = new_sx_acl_rule_offset_t_arr(rules_cnt)
    for j in range(0, rules_cnt):
        sx_acl_rule_offset_t_arr_setitem(offsets_list_p, j, 0)

    rules_list_p = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    for j in range(0, rules_cnt):
        rule = sx_flex_acl_flex_rule_t()
        rule.key_desc_list_p = None
        rule.action_list_p = None
        sx_flex_acl_flex_rule_t_arr_setitem(rules_list_p, j, rule)

    rc = sx_api_acl_flex_rules_get(handle, region_id, offsets_list_p, rules_list_p, rules_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_flex_rules_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rules_cnt = uint32_t_p_value(rules_cnt_p)

    # Get region's default actions
    default_rule_action_p = new_sx_acl_default_action_cfg_t_p()
    action_list = []
    rc = sx_api_acl_flex_default_action_get(handle, SX_ACCESS_CMD_GET, region_id, default_rule_action_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_flex_default_action_get failed, rc = %d" % (rc))
        sys.exit(rc)
    for j in range(default_rule_action_p.action_count):
        action_list.append(sx_flex_acl_flex_action_t_arr_getitem(default_rule_action_p.action_list, j))

    for j in range(0, rules_cnt):
        rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, j)
        rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(rule.key_desc_count)
        rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(rule.action_count)
        sx_flex_acl_flex_rule_t_arr_setitem(rules_list_p, j, rule)

    rc = sx_api_acl_flex_rules_get(handle, region_id, offsets_list_p, rules_list_p, rules_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_flex_rules_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rules_cnt = uint32_t_p_value(rules_cnt_p)

    print("|%10s|" % ("0x%x" % region_id), end="")

    rules_list = []
    for j in range(0, rules_cnt + 1):
        if (j == rules_cnt):
            offset = "default"
            rule = sx_flex_acl_flex_rule_t()
            rule.key_desc_list_p = None
            key_cnt = rule.key_desc_count = 0
            action_cnt = rule.action_count = default_rule_action_p.action_count
            rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(rule.action_count)
            rule.action_list_p = default_rule_action_p.action_list
            priority = rule.priority = 0
        else:
            offset = sx_acl_rule_offset_t_arr_getitem(offsets_list_p, j)
            rule = sx_flex_acl_flex_rule_t_arr_getitem(rules_list_p, j)
            key_cnt = rule.key_desc_count
            action_cnt = rule.action_count
            priority = rule.priority
        max_cnt = max(key_cnt, action_cnt)
        if max_cnt == 0:
            rules_list.append(("%d" % offset, priority, "", "", "", "", ""))
        else:
            for k in range(0, max_cnt):
                key_type = ""
                key_value = ""
                key_mask = ""
                action_type = ""
                action_fields = ""
                if k < key_cnt and k >= action_cnt:
                    key_desc = sx_flex_acl_key_desc_t_arr_getitem(rule.key_desc_list_p, k)
                    if key_desc.key_id in key_type_dict:
                        key_type = key_type_dict[key_desc.key_id]
                    else:
                        key_type = "Unknown"

                    key_value, key_mask = get_key_val_mask_str(key_desc)
                elif k >= key_cnt and k < action_cnt:
                    action = sx_flex_acl_flex_action_t_arr_getitem(rule.action_list_p, k)
                    if action.type in action_type_dict:
                        action_type = action_type_dict[action.type]
                    else:
                        action_type = "Unknown"

                    action_fields = get_action_fields_str(handle, action)
                else:
                    key_desc = sx_flex_acl_key_desc_t_arr_getitem(rule.key_desc_list_p, k)
                    if key_desc.key_id in key_type_dict:
                        key_type = key_type_dict[key_desc.key_id]
                    else:
                        key_type = "Unknown"
                    action = sx_flex_acl_flex_action_t_arr_getitem(rule.action_list_p, k)
                    if action.type in action_type_dict:
                        action_type = action_type_dict[action.type]
                    else:
                        action_type = "Unknown"

                    key_value, key_mask = get_key_val_mask_str(key_desc)
                    action_fields = get_action_fields_str(handle, action)

                rules_list.append(
                    (offset, priority, key_type, key_value, key_mask, action_type, action_fields))

    rules_list_len = len(rules_list)
    for j in range(0, rules_list_len):
        if j == 0:
            print("%8s|%8s|%30s|%20s|%40s|%26s|%31s|" % rules_list[j])
        else:
            print("|%10s|%8s|%8s|%30s|%20s|%40s|%26s|%31s|" % (
                "", rules_list[j][0], rules_list[j][1], rules_list[j][2], rules_list[j][3], rules_list[j][4],
                rules_list[j][5], rules_list[j][6]))

        if j == (rules_list_len - 1):
            print(
                "======================================================================================================================================================================================")
        else:
            if rules_list[j][0] != rules_list[j + 1][0]:
                print(
                    "======================================================================================================================================================================================")
            else:
                print(
                    "|%10s|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------" % (
                        ""))


def get_acl_groups(handle):
    """
    Gets all ACL groups.

    @:return
    acl_group_id_cnt, acl_ids_list, prev_group_dict, next_group_dict
    """

    acl_id_list = []
    acl_group_id_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(acl_group_id_cnt_p, 0)
    rc = sx_api_acl_group_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None, acl_group_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_group_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    acl_group_id_cnt = uint32_t_p_value(acl_group_id_cnt_p)
    acl_group_id_list_p = new_sx_acl_id_t_arr(acl_group_id_cnt)
    rc = sx_api_acl_group_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, acl_group_id_list_p, acl_group_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_group_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    acl_group_id_cnt = uint32_t_p_value(acl_group_id_cnt_p)

    prev_group_dict = {}
    next_group_dict = {}

    next_group_id_p = new_uint32_t_p()
    for i in range(0, acl_group_id_cnt):
        acl_group_id = sx_acl_id_t_arr_getitem(acl_group_id_list_p, i)
        acl_id_list.append(acl_group_id)
        if acl_group_id not in prev_group_dict:
            prev_group_dict[acl_group_id] = INVALID_GROUP_ID
        if acl_group_id not in next_group_dict:
            next_group_dict[acl_group_id] = INVALID_GROUP_ID
        rc = sx_api_acl_group_bind_get(handle, acl_group_id, next_group_id_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_group_bind_get failed, rc = %d" % (rc))
            sys.exit(rc)
        next_group_id = uint32_t_p_value(next_group_id_p)
        next_group_dict[acl_group_id] = next_group_id
        prev_group_dict[next_group_id] = acl_group_id

    return acl_group_id_cnt, acl_id_list, prev_group_dict, next_group_dict


def is_macsec_acl_id(acl_id):
    macsec_acl_id_mask = 0x4000000
    if (acl_id & macsec_acl_id_mask) == macsec_acl_id_mask:
        return True
    else:
        return False


def acl_get_all(handle, is_macsec=False):
    '''
    Get all ACL

    Parameters
    ----------
    @handle - SDK handle.

    @is_macsec - get list of all MACSEC acls.

    @return - acl list from the SDK
    '''
    max_acl_list_len = 1024
    acl_filter_p = new_sx_acl_filter_t_p()
    acl_id_list_p = new_sx_acl_id_t_arr(max_acl_list_len)
    acl_id_cnt_p = new_uint32_t_p()
    acl_id = 0

    try:
        cmd = SX_ACCESS_CMD_GET_FIRST
        uint32_t_p_assign(acl_id_cnt_p, max_acl_list_len)  # Max possible num for api

        rc = sx_api_acl_iter_get(handle, cmd, acl_id, acl_filter_p, acl_id_list_p, acl_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_iter_get failed, rc = %d" % (rc))
            sys.exit(rc)

        acl_cnt = uint32_t_p_value(acl_id_cnt_p)
        acl_id_list = []
        for i in range(0, acl_cnt):
            curr_acl_id = sx_acl_id_t_arr_getitem(acl_id_list_p, i)

            if is_macsec and is_macsec_acl_id(curr_acl_id) == False:
                continue

            acl_id_list.append(sx_acl_id_t_arr_getitem(acl_id_list_p, i))

        return acl_cnt, acl_id_list
    finally:
        delete_sx_acl_filter_t_p(acl_filter_p)
        delete_sx_acl_id_t_arr(acl_id_list_p)
        delete_uint32_t_p(acl_id_cnt_p)


def get_acl_regions(handle, acl_id):
    """
    Get All regions related to an ACL ID
    Whether it is packet type agnostic or not

    :param acl_id: ID of the ACL
    :return: list of regions in the ACL
    """
    regions_list = []
    acl_type_p = new_sx_acl_type_t_p()
    acl_direction_p = new_sx_acl_direction_t_p()
    acl_region_group_p = new_sx_acl_region_group_t_p()
    rc = sx_api_acl_get(handle, acl_id, acl_type_p, acl_direction_p, acl_region_group_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_get failed, rc = %d" % (rc))
        sys.exit(rc)
    acl_region_group = sx_acl_region_group_t_p_value(acl_region_group_p)
    if acl_region_group.acl_type == SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC:
        regions_list.append(acl_region_group.regions.acl_packet_agnostic.region)
    else:
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.non_ip_region)
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.ipv4_region)
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.ipv6_region)

    return regions_list


def get_macsec_acl_regions(handle, acl_id):
    """
    Get MACSEC regions related to an ACL ID

    :param acl_id: ID of the ACL
    :return: list of regions in the ACL and direction
    """
    regions_list = []
    acl_type_p = new_sx_acl_type_t_p()
    acl_direction_p = new_sx_acl_direction_t_p()
    acl_region_group_p = new_sx_acl_region_group_t_p()
    rc = sx_api_acl_get(handle, acl_id, acl_type_p, acl_direction_p, acl_region_group_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_get failed, rc = %d" % (rc))
        sys.exit(rc)
    acl_direction = sx_acl_direction_t_p_value(acl_direction_p)
    acl_region_group = sx_acl_region_group_t_p_value(acl_region_group_p)
    if acl_region_group.acl_type == SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC:
        regions_list.append(acl_region_group.regions.acl_packet_agnostic.region)
    else:
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.non_ip_region)
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.ipv4_region)
        regions_list.append(acl_region_group.regions.acl_packet_sensitive.ipv6_region)

    return regions_list, acl_direction


def print_macsec_acls(handle, acl_id_cnt, acl_id_list):
    """

    :param acl_group_id_cnt:
    :param acl_id_list:
    :return: region_set - All regions in the range
    """
    acl_header_printed = False
    acl_direction_p = new_sx_acl_direction_t_p()
    region_set = set()

    print("----------------------------")
    print("MACSEC ACLs")
    print("----------------------------\n")

    print("=======================================")
    print("|%11s|%12s|%12s|" % ("ACL ID", "Region ID", "Direction"))
    print("=======================================")
    acl_header_printed = True

    if acl_id_cnt == 0:
        print("%11s|%12s|" % ("", ""))
        print("=======================================")
    else:
        acl_region_pair_list = []

        for j in range(0, acl_id_cnt):
            # acl_id = sx_acl_id_t_arr_getitem(acl_id_list_p, j)
            acl_id = acl_id_list[j]
            regions, direction = get_macsec_acl_regions(handle, acl_id)
            for r in regions:
                acl_region_pair_list.append((acl_id, r, direction))
                region_set.add(r)

        for k in range(0, len(acl_region_pair_list)):
            # if k == 0:
            print("|%11s|%12s|%12s|" % ("0x%x" % acl_region_pair_list[k][0], "0x%x" % acl_region_pair_list[k][1],
                  dir_dict[acl_region_pair_list[k][2]]))

            if k == (len(acl_region_pair_list) - 1):
                print("=======================================")
            else:
                print("|--------------------------------------")
    return region_set


def print_acl_groups(handle, acl_group_id_cnt, acl_id_list, prev_group_dict, next_group_dict):
    """

    :param acl_group_id_cnt:
    :param acl_id_list:
    :param prev_group_dict:
    :param next_group_dict:
    :return: region_set - All regions in the range
    """
    acl_group_header_printed = False
    acl_direction_p = new_sx_acl_direction_t_p()
    region_set = set()

    for i in range(0, acl_group_id_cnt):
        if not acl_group_header_printed:
            print("----------------------------")
            print("ACL Groups")
            print("----------------------------\n")

            print("===================================================================================")
            print("|%10s|%12s|%10s|%11s|%11s|%11s|%10s|" % ("Group ID", "Direction", "Priority", "Prev Group", "Next Group", "ACL ID", "Region ID"))
            print("===================================================================================")
            acl_group_header_printed = True

        acl_group_id = acl_id_list[i]
        acl_id_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(acl_id_cnt_p, 0)
        rc = sx_api_acl_group_get(handle, acl_group_id, acl_direction_p, None, acl_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_group_get failed, rc = %d" % (rc))
            sys.exit(rc)
        acl_id_cnt = uint32_t_p_value(acl_id_cnt_p)

        # Get the name and priority of the group
        attribs_p = new_sx_acl_group_attributes_t_p()
        rc = sx_api_acl_group_attributes_get(handle, acl_group_id, attribs_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_group_attributes_get failed, rc = %d" % (rc))
            sys.exit(rc)
        priority_str = "%d" % attribs_p.priority

        acl_id_list_p = new_sx_acl_id_t_arr(acl_id_cnt)
        rc = sx_api_acl_group_get(handle, acl_group_id, acl_direction_p, acl_id_list_p, acl_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_group_get failed, rc = %d" % (rc))
            sys.exit(rc)
        acl_id_cnt = uint32_t_p_value(acl_id_cnt_p)

        print("|%10s %12s %10s %11s %11s|" % ("0x%x" % acl_group_id,
                                              dir_dict[sx_acl_direction_t_p_value(acl_direction_p)],
                                              priority_str,
                                              "0x%x" % prev_group_dict[acl_group_id],
                                              "0x%x" % next_group_dict[acl_group_id]), end="")

        if acl_id_cnt == 0:
            print("%11s|%10s|" % ("", ""))
            print("===================================================================================")
        else:
            acl_region_pair_list = []

            for j in range(0, acl_id_cnt):
                acl_id = sx_acl_id_t_arr_getitem(acl_id_list_p, j)
                regions = get_acl_regions(handle, acl_id)
                for r in regions:
                    acl_region_pair_list.append((acl_id, r))
                    region_set.add(r)

            for k in range(0, len(acl_region_pair_list)):
                if k == 0:
                    print("%11s|%10s|" % ("0x%x" % acl_region_pair_list[k][0], "0x%x" % acl_region_pair_list[k][1]))
                else:
                    print("|%58s|%11s|%10s|" % ("", "0x%x" % acl_region_pair_list[k][0], "0x%x" % acl_region_pair_list[k][1]))

                if k == (len(acl_region_pair_list) - 1):
                    print("===================================================================================")
                else:
                    print("|%58s|-----------------------" % (""))
    return region_set


def print_region_rules_header(is_macsec=False):
    print("\n----------------------------")
    if not is_macsec:
        print("ACL Rules")
    else:
        print("MACSEC ACL Rules")
    print("----------------------------\n")

    print(
        "======================================================================================================================================================================================")
    print("|%10s|%8s|%8s|%30s|%20s|%40s|%26s|%31s|" % ("Region ID", "Offset", "Priority", "Key Type", "Key Value", "Key Mask", "Action Type", "Action Fields"))
    print("======================================================================================================================================================================================")


def print_acl_bindings_header():
    print("\n----------------------------")
    print("ACL Bindings")
    print("----------------------------\n")

    print("==========================================================")
    print("|%11s|%12s|%13s|%11s|%5s|" % ("ACL ID", "Direction", "Logical Port", "VLAN Group", "RIF"))
    print("==========================================================")


def print_macsec_acl_bindings_header():
    print("\n----------------------------")
    print("MACSEC ACL Bindings")
    print("----------------------------\n")

    print("========================================")
    print("|%11s|%12s|%13s|" % ("ACL ID", "Direction", "Logical Port"))
    print("========================================")


def print_acl_binding(acl_id, binding_map):
    acl_id_str = "0x%x" % (acl_id)
    print("|%11s|" % (acl_id_str), end="")
    for j in range(0, len(binding_map[acl_id])):
        entry = binding_map[acl_id][j]
        dir_str = ""
        log_port_str = ""
        vlan_group_str = ""
        rif_str = ""
        if 'direction' in entry and entry['direction'] in dir_dict:
            dir_str = dir_dict[entry['direction']]
        if 'log_port' in entry:
            log_port_str = "0x%x" % (entry['log_port'])
        if 'vlan_group' in entry:
            vlan_group_str = "%d" % (entry['vlan_group'])
        if 'rif' in entry:
            rif_str = "%d" % (entry['rif'])

        if j == 0:
            print("%12s|%13s|%11s|%5s|" % (dir_str, log_port_str, vlan_group_str, rif_str))
        else:
            print("|%11s|%12s|%13s|%11s|%5s|" % ("", dir_str, log_port_str, vlan_group_str, rif_str))

        if j == (len(binding_map[acl_id]) - 1):
            print("==========================================================")
        else:
            print("|%11s|---------------------------------------------" % (""))


def print_macsec_acl_binding(acl_id, binding_map):
    acl_id_str = "0x%x" % (acl_id)
    print("|%11s|" % (acl_id_str), end="")
    for j in range(0, len(binding_map[acl_id])):
        entry = binding_map[acl_id][j]
        dir_str = ""
        log_port_str = ""
        vlan_group_str = ""
        rif_str = ""
        if 'direction' in entry and entry['direction'] in dir_dict:
            dir_str = dir_dict[entry['direction']]
        if 'log_port' in entry:
            log_port_str = "0x%x" % (entry['log_port'])

        if j == 0:
            print("%12s|%13s|" % (dir_str, log_port_str))
        else:
            print("|%11s|%12s|%13s|" % ("", dir_str, log_port_str))

        if j == (len(binding_map[acl_id]) - 1):
            print("========================================")
        else:
            print("|%11s|---------------------------------------------" % (""))


def get_vlan_vlan_group(handle, vlan_id):
    """
    Find per VLAN what vlan_group it belongs to
    :param handle:
    :param vlan_id: VLAN ID to search for
    :return: vlan_group number or an invalid value if not found
    """
    module_level, api_level = acl_module_verbosity_level_get(handle)
    rc = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE,
                                            SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set ACL API log verbosity level")
        sys.exit(rc)
    vlan_list_p = new_sx_vlan_id_t_arr(4094)
    vlan_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(vlan_cnt_p, 4094)
    VLAN_GROUP_MAX = 255
    for vlan_group in range(0, VLAN_GROUP_MAX):
        rc = sx_api_acl_vlan_group_map_get(handle, 0, vlan_group, vlan_list_p, vlan_cnt_p)
        if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND and rc != SX_STATUS_PARAM_EXCEEDS_RANGE:
            print("sx_api_acl_vlan_group_map_get failed, rc = %d" % (rc))
            sys.exit(rc)

        if rc == SX_STATUS_PARAM_EXCEEDS_RANGE:
            break
        if rc == SX_STATUS_SUCCESS:
            vlan_count = uint32_t_p_value(vlan_cnt_p)
            for i in range(0, vlan_count):
                if vlan_id == sx_vlan_id_t_arr_getitem(vlan_list_p, i):
                    rc = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_level, api_level)
                    if rc != SX_STATUS_SUCCESS:
                        print("Failed to set ACL API log verbosity level")
                        sys.exit(rc)
                    return vlan_group

    rc = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_level, api_level)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set ACL API log verbosity level")
        sys.exit(rc)
    return -1
