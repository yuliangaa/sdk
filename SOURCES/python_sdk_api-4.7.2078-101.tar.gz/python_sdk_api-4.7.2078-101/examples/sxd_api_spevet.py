#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sxd_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev
import test_infra_common as common_lib


def parse_args():
    parser = argparse.ArgumentParser(description='SPEVET Set/Get example')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--local_port', default=1, type=int, help="Local Port.")
    parser.add_argument('--et_vlan', default=0, type=int, help="Egress ethertype index value.")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    return args.cmd, args.local_port, args.et_vlan, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute Set/Get request for the SPEVET EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--local_port <port>] [--et_vlan <et_vlan>]")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. 0 by default.")
    print("local_port: local port to use. 1 by default.")
    print("et_vlan: ethertype index to use for ingress port configuration. 0 by default.")
    print("")


def validate_input_parameters(cmd, local_port, et_vlan):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(1)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, local_port, et_vlan, deinit):

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        original_spevet = ku_spevet_reg()

        original_spevet.local_port, original_spevet.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_spevet(original_spevet, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get SPEVET register, rc: %d" % (rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    spevet = ku_spevet_reg()

    spevet.local_port, spevet.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    spevet.et_vlan = et_vlan

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get SPEVET")
        print("[+] local port: ", spevet.local_port)
        print("[+] lp_msb: ", spevet.lp_msb)
    else:
        print("[+] Set SPEVET")
        print("[+] local port: ", spevet.local_port)
        print("[+] lp_msb: ", spevet.lp_msb)
        print("[+] et_vlan: ", spevet.et_vlan)

    rc = sxd_access_reg_spevet(spevet, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to query SPEVET register, rc: %d" % (rc)

    print("[+] rc: ", rc)
    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] local port: ", spevet.local_port)
        print("[+] lp_msb: ", spevet.lp_msb)
        print("[+] et_vlan: ", spevet.et_vlan)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        print("Deinit")
        rc = sxd_access_reg_spevet(original_spevet, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set SPEVET register, rc: %d" % (rc)


def main():
    cmd, local_port, et_vlan, deinit = parse_args()

    validate_input_parameters(cmd, local_port, et_vlan)

    sxd_init()

    chip_type, _ = get_chip_type_and_rev()

    if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM:
        print("[+] SPC1 does not support SPEVET EMAD.")
    else:
        run_example(cmd, local_port, et_vlan, deinit)

    print("[+] SPEVET register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] SPEVET register access example")
    main()
