#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates N regions
    2. Creates N acls
    3. Add each acl to group
    4. adds rule to regions
    5. Bind between groups
    6. Bind head group to port
    7. Print dump
    8. Unbind head group from port
    9. Unbind between groups
    10 . Destroy groups
    11. Delete rules
    12. Destroy created acls and regions

"""
import sys
import socket
import struct
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_key_attr_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

rc, handle = sx_api_open(None)
RULES_MAX = 16000
REGIONS_MAX = 400
ACL_TABLES_MAX = 400
GROUPS_NUM_MAX = 400
GROUP_NUM_ING = 95
GROUP_NUM_EGR = 31
PORT_RANGES_MAX = 16
VLAN_GROUPS_MAX = 512


######################################################
#    defines
######################################################

######################################################
#    functions
######################################################
# helping functions:


def key_create(key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def test_key_attribs():
    key_handle = key_create(FLEX_ACL_KEY_SMAC)

    key_attr_p = new_sx_acl_flex_key_attr_t_p()

    rc = sx_api_acl_flex_key_attr_get(handle, key_handle, key_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("ERROR sx_api_acl_flex_key_attr_get failed \n")
        sys.exit(rc)

    key_attr = sx_acl_flex_key_attr_t_p_value(key_attr_p)

    print("key attrib are %u" % (key_attr.key_width))

    if args.deinit:
        key_destroy(key_handle)

    sx_api_close(handle)


def main():
    test_key_attribs()


if __name__ == "__main__":
    main()
