#!/usr/bin/env python
'''
This file contains Python command example for the CoS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different CoS attributes.
This example is supported on Spectrum devices.
'''

import sys
import errno
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_trust_port_both')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

""" ############################################################################################ """

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

traffic_class_count = 8

""" ############################################################################################ """


def cos_port_get_all():
    priority_p = new_sx_cos_priority_t_p()
    rc = sx_api_cos_port_default_prio_get(handle, PORT1, priority_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_default_prio_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_priority = sx_cos_priority_t_p_value(priority_p)

    color_p = new_sx_cos_color_t_p()

    rc = sx_api_cos_port_default_color_get(handle, PORT1, color_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_default_color_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_color = sx_cos_color_t_p_value(color_p)

    ############################################################

    trust_state_p = new_sx_cos_trust_level_t_p()

    rc = sx_api_cos_port_trust_get(handle, PORT1, trust_state_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_trust_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_trust_state = sx_cos_trust_level_t_p_value(trust_state_p)

    ############################################################

    rewrite_enable_p = new_sx_cos_rewrite_enable_t_p()

    rc = sx_api_cos_port_rewrite_enable_get(handle, PORT1, rewrite_enable_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_rewrite_enable_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_rewrite = sx_cos_rewrite_enable_t_p_value(rewrite_enable_p)

    ############################################################

    element_count_p = new_uint32_t_p()
    uint32_t_p_assign(element_count_p, 0)

    rc = sx_api_cos_port_prio_to_pcpdei_rewrite_get(handle, PORT2, None, None, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_pcpdei_rewrite_get failed rc = %d " % (rc))
        sys.exit(rc)

    original_pcp_count = uint32_t_p_value(element_count_p)
    original_pcp_switch_priority_color_p = new_sx_cos_priority_color_t_arr(original_pcp_count)
    original_pcp_p = new_sx_cos_pcp_dei_t_arr(original_pcp_count)
    rc = sx_api_cos_port_prio_to_pcpdei_rewrite_get(handle, PORT2, original_pcp_switch_priority_color_p,
                                                    original_pcp_p, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_pcpdei_rewrite_get failed rc = %d " % (rc))
        sys.exit(rc)

    ############################################################

    uint32_t_p_assign(element_count_p, 0)

    rc = sx_api_cos_port_prio_to_dscp_rewrite_get(handle, PORT2, None, None, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_dscp_rewrite_get failed rc = %d " % (rc))
        sys.exit(rc)

    original_dscp_count = uint32_t_p_value(element_count_p)
    original_dscp_switch_priority_color_p = new_sx_cos_priority_color_t_arr(original_dscp_count)
    original_dscp_p = new_sx_cos_dscp_t_arr(original_dscp_count)

    rc = sx_api_cos_port_prio_to_dscp_rewrite_get(handle, PORT2, original_dscp_switch_priority_color_p, original_dscp_p,
                                                  element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_dscp_rewrite_get failed rc = %d " % (rc))
        sys.exit(rc)

    ############################################################

    uint32_t_p_assign(element_count_p, 0)

    rc = sx_api_cos_port_pcpdei_to_prio_get(handle, PORT2, None, None, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_pcpdei_to_prio_get failed rc = %d " % (rc))
        sys.exit(rc)

    original_pcp_to_prio_count = uint32_t_p_value(element_count_p)
    original_pcp_to_prio_switch_priority_color_p = new_sx_cos_priority_color_t_arr(original_pcp_to_prio_count)
    original_pcp_to_prio_p = new_sx_cos_pcp_dei_t_arr(original_pcp_to_prio_count)

    rc = sx_api_cos_port_pcpdei_to_prio_get(handle, PORT2, original_pcp_to_prio_p, original_pcp_to_prio_switch_priority_color_p,
                                            element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_pcpdei_to_prio_get failed rc = %d " % (rc))
        sys.exit(rc)

    ############################################################

    uint32_t_p_assign(element_count_p, 0)

    rc = sx_api_cos_port_dscp_to_prio_get(handle, PORT2, None, None, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_pcpdei_to_prio_get failed rc = %d " % (rc))
        sys.exit(rc)

    original_dscp_to_prio_count = uint32_t_p_value(element_count_p)
    original_dscp_to_prio_switch_priority_color_p = new_sx_cos_priority_color_t_arr(original_dscp_to_prio_count)
    original_dscp_to_prio_p = new_sx_cos_dscp_t_arr(original_dscp_to_prio_count)

    rc = sx_api_cos_port_dscp_to_prio_get(handle, PORT2, original_dscp_to_prio_p, original_dscp_to_prio_switch_priority_color_p,
                                          element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_dscp_to_prio_get failed rc = %d " % (rc))
        sys.exit(rc)

    ############################################################

    uint32_t_p_assign(element_count_p, 0)

    rc = sx_api_cos_prio_to_ieeeprio_get(handle, None, None, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_prio_to_ieeeprio_get failed rc = %d " % (rc))
        sys.exit(rc)

    original_ieee_count = uint32_t_p_value(element_count_p)
    original_ieee_switch_prio_p = new_sx_cos_priority_t_arr(original_ieee_count)
    original_ieee_prio_p = new_sx_cos_ieee_prio_t_arr(original_ieee_count)

    rc = sx_api_cos_prio_to_ieeeprio_get(handle, original_ieee_switch_prio_p, original_ieee_prio_p, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_prio_to_ieeeprio_get failed rc = %d " % (rc))
        sys.exit(rc)

    ############################################################

    original_traffic_class_list = []
    for i in range(0, traffic_class_count):
        priority = i

        traffic_class_p = new_sx_cos_traffic_class_t_p()
        rc = sx_api_cos_port_tc_prio_map_get(handle, PORT1, priority, traffic_class_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_tc_prio_map_get failed rc = %d " % (rc))
            sys.exit(rc)
        traffic_class = sx_cos_traffic_class_t_p_value(traffic_class_p)
        original_traffic_class_list.append(traffic_class)

    ############################################################

    mc_aware_p = new_boolean_t_p()

    rc = sx_api_cos_port_tc_mcaware_get(handle, PORT1, mc_aware_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_tc_mcaware_get failed rc = %d " % (rc))
        sys.exit(rc)
    original_mc_aware = boolean_t_p_value(mc_aware_p)

    ############################################################

    return original_priority,                                                                                      \
        original_color,                                                                                         \
        original_trust_state,                                                                                   \
        original_rewrite,                                                                                       \
        original_pcp_switch_priority_color_p, original_pcp_p, original_pcp_count,                               \
        original_dscp_switch_priority_color_p, original_dscp_p, original_dscp_count,                            \
        original_pcp_to_prio_switch_priority_color_p, original_pcp_to_prio_p, original_pcp_to_prio_count,        \
        original_dscp_to_prio_switch_priority_color_p, original_dscp_to_prio_p, original_dscp_to_prio_count,     \
        original_ieee_switch_prio_p, original_ieee_prio_p, original_ieee_count,                                 \
        original_traffic_class_list,                                                                            \
        original_mc_aware                                                                                       \



""" ############################################################################################ """


# Save all values for later de-configuration
original_priority, \
    original_color, \
    original_trust_state, \
    original_rewrite, \
    original_pcp_switch_priority_color_p, original_pcp_p, original_pcp_count, \
    original_dscp_switch_priority_color_p, original_dscp_p, original_dscp_count, \
    original_pcp_to_prio_switch_priority_color_p, original_pcp_to_prio_p, original_pcp_to_prio_count, \
    original_dscp_to_prio_switch_priority_color_p, original_dscp_to_prio_p, original_dscp_to_prio_count, \
    original_ieee_switch_prio_p, original_ieee_prio_p, original_ieee_count, \
    original_traffic_class_list, \
    original_mc_aware                                                                                       \
    = cos_port_get_all()


""" ############################################################################################ """

""" COS PORT DEFAULT PRIO SET """
print("--------------- COS PORT DEFAULT PRIO SET ------------------------------")

priority = 5

rc = sx_api_cos_port_default_prio_set(handle, PORT1, priority)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_default_prio_set [log_port=0x%x , priority=%d] " % (PORT1, priority)))

""" ############################################################################################ """

""" COS PORT DEFAULT PRIO GET """
print("--------------- COS PORT DEFAULT PRIO GET ------------------------------")

priority_p = new_sx_cos_priority_t_p()

rc = sx_api_cos_port_default_prio_get(handle, PORT1, priority_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
priority = sx_cos_priority_t_p_value(priority_p)
print("--------------------------------------------------------------------")
print(("sx_api_cos_port_default_prio_get [log_port=0x%x , priority=%d] " % (PORT1, priority)))

""" ############################################################################################ """

""" COS PORT DEFAULT COLOR SET """
print("--------------- COS PORT DEFAULT COLOR SET ------------------------------")

color = 2

rc = sx_api_cos_port_default_color_set(handle, PORT1, color)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_default_color_set [log_port=0x%x , color=%d] " % (PORT1, color)))

""" ############################################################################################ """

""" COS PORT DEFAULT COLOR GET """
print("--------------- COS PORT DEFAULT COLOR GET ------------------------------")

color_p = new_sx_cos_color_t_p()

rc = sx_api_cos_port_default_color_get(handle, PORT1, color_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
color = sx_cos_color_t_p_value(color_p)
print("--------------------------------------------------------------------")
print(("sx_api_cos_port_default_color_get [log_port=0x%x ,color=%d] " % (PORT1, color)))


""" ############################################################################################ """

# sx_api_cos_port_pcpdei_to_prio_set  0x10023 [{0;0},{1;0},{2;0},{3;0},{4;0},{5;0},{6;0},{7;0}]
# [{7;0},{6;0},{5;0},{4;0},{3;0},{2;0},{1;0},{0;0}] 8
""" COS PORT PCP DEI TO PRIO SET """
print("--------------- COS PORT PCP DEI TO PRIO SET ------------------------------")

element_count = 8
pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_count)
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)

for i in range(0, element_count):
    pcp_dei = sx_cos_pcp_dei_t()
    switch_priority_color = sx_cos_priority_color_t()

    pcp_dei.pcp = i % 8
    pcp_dei.dei = i % 2
    switch_priority_color.priority = i % 15
    switch_priority_color.color = i % 3

    sx_cos_pcp_dei_t_arr_setitem(pcp_dei_p, i, pcp_dei)
    sx_cos_priority_color_t_arr_setitem(switch_priority_color_p, i, switch_priority_color)


rc = sx_api_cos_port_pcpdei_to_prio_set(handle, PORT1, pcp_dei_p, switch_priority_color_p, element_count)
print(("sx_api_cos_port_pcpdei_to_prio_set for log_port=0x%x, rc=%d " % (PORT1, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

""" ############################################################################################ """
# sx_api_cos_port_pcpdei_to_prio_get  0x10001 8
""" COS PORT PCP DEI TO PRIO GET """
print("--------------- COS PORT PCP DEI TO PRIO GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 8 """
uint32_t_p_assign(element_count_p, 8)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_count)
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)

rc = sx_api_cos_port_pcpdei_to_prio_get(handle, PORT1, pcp_dei_p, switch_priority_color_p, element_count_p)
print(("sx_api_cos_port_pcpdei_to_prio_get for log_port=0x%x, rc=%d " % (PORT1, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

for i in range(0, element_count):
    pcp_dei = sx_cos_pcp_dei_t_arr_getitem(pcp_dei_p, i)
    print(("pcp=%d, dei=%d " % (pcp_dei.pcp, pcp_dei.dei)))

    switch_priority_color = sx_cos_priority_color_t_arr_getitem(switch_priority_color_p, i)
    print(("priority=%d, color=%d " % (switch_priority_color.priority, switch_priority_color.color)))

""" ############################################################################################ """

# sx_api_cos_port_dscp_to_prio_set  0x10023 [0,1,2,3,4,5,6,7,]
# [{7;0},{6;0},{5;0},{4;0},{3;0},{2;0},{1;0},{0;0}] 8
""" COS PORT PCP DSCP TO PRIO SET """
print("--------------- COS PORT DSCP TO PRIO SET ------------------------------")

element_count = 8
dscp_p = new_sx_cos_dscp_t_arr(element_count)
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)

for i in range(0, element_count):
    switch_priority_color = sx_cos_priority_color_t()

    dscp = i % 64
    switch_priority_color.priority = i % 15
    switch_priority_color.color = i % 3

    sx_cos_dscp_t_arr_setitem(dscp_p, i, dscp)
    sx_cos_priority_color_t_arr_setitem(switch_priority_color_p, i, switch_priority_color)


rc = sx_api_cos_port_dscp_to_prio_set(handle, PORT1, dscp_p, switch_priority_color_p, element_count)
print(("sx_api_cos_port_dscp_to_prio_set for log_port=0x%x, rc=%d" % (PORT1, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


""" ############################################################################################ """

# sx_api_cos_port_dscp_to_prio_get  0x10001 8
""" COS PORT DSCP TO PRIO GET """
print("--------------- COS PORT DSCP TO PRIO GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 8 """
uint32_t_p_assign(element_count_p, 8)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

dscp_p = new_sx_cos_dscp_t_arr(element_count)
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)

rc = sx_api_cos_port_dscp_to_prio_get(handle, PORT1, dscp_p, switch_priority_color_p, element_count_p)
print(("sx_api_cos_port_dscp_to_prio_get for log_port=0x%x, rc=%d " % (PORT1, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


for i in range(0, element_count):
    dscp = sx_cos_dscp_t_arr_getitem(dscp_p, i)
    print(("dscp=%d " % (dscp)))

    switch_priority_color = sx_cos_priority_color_t_arr_getitem(switch_priority_color_p, i)
    print(("priority=%d, color=%d " % (switch_priority_color.priority, switch_priority_color.color)))

""" ############################################################################################ """

""" COS PORT TRUST SET """
print("--------------- COS PORT TRUST SET ------------------------------")

trust_state = SX_COS_TRUST_LEVEL_BOTH

rc = sx_api_cos_port_trust_set(handle, PORT1, trust_state)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_trust_set [log_port=0x%x , trust_state=%d] " % (PORT1, trust_state)))

""" ############################################################################################ """

""" COS PORT TRUST GET"""
print("--------------- COS PORT TRUST GET ------------------------------")

trust_state_p = new_sx_cos_trust_level_t_p()

rc = sx_api_cos_port_trust_get(handle, PORT1, trust_state_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
trust_state = sx_cos_trust_level_t_p_value(trust_state_p)
print("--------------------------------------------------------------------")
print(("sx_api_cos_port_trust_get [log_port=0x%x , trust_state=%d] " % (PORT1, trust_state)))

""" ############################################################################################ """

# 0xsx_api_cos_port_rewrite_enable_set 10100 {1;1;1}
""" COS PORT REWRITE ENABLE SET """
print("--------------- COS PORT REWRITE ENABLE SET ------------------------------")

rewrite = sx_cos_rewrite_enable_t()
rewrite.rewrite_pcp_dei = 1
rewrite.rewrite_dscp = 1
rewrite.rewrite_exp = 1

rc = sx_api_cos_port_rewrite_enable_set(handle, PORT1, rewrite)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_rewrite_enable_set (1,1,1) for log_port=0x%x " % (PORT1)))

""" ############################################################################################ """
# sx_api_cos_port_rewrite_enable_get 0x10001
""" COS PORT REWRITE ENABLE GET """
print("--------------- COS PORT REWRITE ENABLE GET ------------------------------")

rewrite_enable_p = new_sx_cos_rewrite_enable_t_p()

rc = sx_api_cos_port_rewrite_enable_get(handle, PORT1, rewrite_enable_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
rewrite_p = sx_cos_rewrite_enable_t_p_value(rewrite_enable_p)

print(("sx_api_cos_port_rewrite_enable_get (pcp_dei=%d, dscp=%d, exp=%d) for log_port=0x%x ] " % (rewrite_p.rewrite_pcp_dei, rewrite_p.rewrite_dscp, rewrite_p.rewrite_exp, PORT1)))

""" ############################################################################################ """

# sx_api_cos_port_prio_to_pcpdei_rewrite_set  0x10023 [{0;0},{1;1}] [{0;0},{1;1}] 2
""" COS PORT PRIO TO PCP DEI REWRITE SET """
print("--------------- COS PORT PRIO TO PCP DEI REWRITE ENABLE SET ------------------------------")

element_count = 2
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)
pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_count)


for i in range(0, element_count):
    switch_priority_color = sx_cos_priority_color_t()
    pcp_dei = sx_cos_pcp_dei_t()

    switch_priority_color.priority = i % 15
    switch_priority_color.color = i % 3
    pcp_dei.pcp = i % 8
    pcp_dei.dei = i % 2

    sx_cos_priority_color_t_arr_setitem(switch_priority_color_p, i, switch_priority_color)
    sx_cos_pcp_dei_t_arr_setitem(pcp_dei_p, i, pcp_dei)

rc = sx_api_cos_port_prio_to_pcpdei_rewrite_set(handle, PORT2, switch_priority_color_p, pcp_dei_p, element_count)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_prio_to_pcpdei_rewrite_set for log_port=0x%x " % (PORT2)))


""" ############################################################################################ """

# sx_api_cos_port_prio_to_pcpdei_rewrite_get  0x10023 2
""" COS PORT PRIO TO PCP DEI REWRITE GET """
print("--------------- COS PORT PRIO TO PCP DEI REWRITE ENABLE GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 2 """
uint32_t_p_assign(element_count_p, 2)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)
pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_count)

rc = sx_api_cos_port_prio_to_pcpdei_rewrite_get(handle, PORT2, switch_priority_color_p, pcp_dei_p, element_count_p)
print(("sx_api_cos_port_prio_to_pcpdei_rewrite_get for log_port=0x%x, rc=%d " % (PORT2, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


for i in range(0, element_count):
    switch_priority_color = sx_cos_priority_color_t_arr_getitem(switch_priority_color_p, i)
    print(("priority=%d, color=%d " % (switch_priority_color.priority, switch_priority_color.color)))

    pcp_dei = sx_cos_pcp_dei_t_arr_getitem(pcp_dei_p, i)
    print(("pcp=%d, dei=%d " % (pcp_dei.pcp, pcp_dei.dei)))


""" ############################################################################################ """
# sx_api_cos_port_prio_to_dscp_rewrite_set  0x10023 [{0;0}, {1;1}] [0,1] 2
""" COS PORT PRIO TO DSCP REWRITE SET """
print("--------------- COS PORT PRIO TO DSCP REWRITE ENABLE SET ------------------------------")

element_count = 2
switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)
dscp_p = new_sx_cos_dscp_t_arr(element_count)


for i in range(0, element_count):
    switch_priority_color = sx_cos_priority_color_t()
    pcp_dei = sx_cos_pcp_dei_t()
    switch_priority_color.priority = i % 15
    switch_priority_color.color = i % 3
    dscp = i % 64

    sx_cos_priority_color_t_arr_setitem(switch_priority_color_p, i, switch_priority_color)
    sx_cos_dscp_t_arr_setitem(dscp_p, i, dscp)

rc = sx_api_cos_port_prio_to_dscp_rewrite_set(handle, PORT2, switch_priority_color_p, dscp_p, element_count)
print(("sx_api_cos_port_prio_to_dscp_rewrite_set for log_port=0x%x, rc =%d" % (PORT2, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


""" ############################################################################################ """

# sx_api_cos_port_prio_to_dscp_rewrite_get  0x10023 2
""" COS PORT PRIO TO DSCP REWRITE GET """
print("--------------- COS PORT PRIO TO DSCP REWRITE ENABLE GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 2 """
uint32_t_p_assign(element_count_p, 2)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

switch_priority_color_p = new_sx_cos_priority_color_t_arr(element_count)
dscp_p = new_sx_cos_dscp_t_arr(element_count)

rc = sx_api_cos_port_prio_to_dscp_rewrite_get(handle, PORT2, switch_priority_color_p, dscp_p, element_count_p)
print(("sx_api_cos_port_prio_to_dscp_rewrite_get for log_port=0x%x, rc=%d " % (PORT2, rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)


for i in range(0, element_count):
    switch_priority_color = sx_cos_priority_color_t_arr_getitem(switch_priority_color_p, i)
    print(("priority=%d, color=%d " % (switch_priority_color.priority, switch_priority_color.color)))

    dscp = sx_cos_dscp_t_arr_getitem(dscp_p, i)
    print(("dscp=%d " % (dscp)))


""" ############################################################################################ """
# sx_api_cos_prio_to_ieeeprio_set [0,1,2,3,4,5,6,7,8,9] [[0,1,2,3,4,5,6,7,0,1] 10
""" COS PRIO TO IEEE PRIORITY SET """
print("--------------- COS PRIO TO IEEE PRIORITY SET ------------------------------")

element_count = 10
switch_prio_p = new_sx_cos_priority_t_arr(element_count)
ieee_prio_p = new_sx_cos_ieee_prio_t_arr(element_count)


for i in range(0, element_count):
    ieee_priority = i % 8
    priority = i

    sx_cos_priority_t_arr_setitem(switch_prio_p, i, priority)
    sx_cos_ieee_prio_t_arr_setitem(ieee_prio_p, i, ieee_priority)

    switch_prio = sx_cos_priority_t_arr_getitem(switch_prio_p, i)
    ieee_prio = sx_cos_ieee_prio_t_arr_getitem(ieee_prio_p, i)
    print(("Setter switch priority=%d, ieee priority=%d " % (switch_prio, ieee_prio)))

rc = sx_api_cos_prio_to_ieeeprio_set(handle, switch_prio_p, ieee_prio_p, element_count)
print(("sx_api_cos_prio_to_ieeeprio_set- rc=%d" % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

""" ############################################################################################ """
# sx_api_cos_prio_to_ieeeprio_get 10
""" COS PRIO TO IEEE PRIORITY GET """
print("--------------- COS PRIO TO IEEE PRIORITY GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 10 """
uint32_t_p_assign(element_count_p, 10)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

switch_prio_p = new_sx_cos_priority_t_arr(element_count)
ieee_prio_p = new_sx_cos_ieee_prio_t_arr(element_count)

rc = sx_api_cos_prio_to_ieeeprio_get(handle, switch_prio_p, ieee_prio_p, element_count_p)
print(("sx_api_cos_prio_to_ieeeprio_get, rc=%d " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

for i in range(0, element_count):
    switch_prio = sx_cos_priority_t_arr_getitem(switch_prio_p, i)
    ieee_prio = sx_cos_ieee_prio_t_arr_getitem(ieee_prio_p, i)
    print(("switch priority=%d, ieee priority=%d " % (switch_prio, ieee_prio)))

""" ############################################################################################ """


""" COS PORT TC PRIO MAP SET  AND GET """
print("--------------- COS PORT TC PRIO MAP SET AND GET ------------------------------")

element_count_p = new_uint32_t_p()
""" Set cnt = 8 """
uint32_t_p_assign(element_count_p, 8)
""" Get value from PTR """
element_count = uint32_t_p_value(element_count_p)
print(("element_count (returned from API = %d)" % (element_count)))

for i in range(0, element_count):
    priority = i
    traffic_class = i
    cmd = SX_ACCESS_CMD_ADD

    rc = sx_api_cos_port_tc_prio_map_set(handle, cmd, PORT1, priority, traffic_class)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_cos_port_tc_prio_map_set [log_port=0x%x , prio=%d, tc=%d] " % (PORT1, priority, traffic_class)))

    traffic_class_p = new_sx_cos_traffic_class_t_p()
    rc = sx_api_cos_port_tc_prio_map_get(handle, PORT1, priority, traffic_class_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    traffic_class = sx_cos_traffic_class_t_p_value(traffic_class_p)
    print(("sx_api_cos_port_tc_prio_map_get [log_port=0x%x , prio=%d, tc=%d] " % (PORT1, priority, traffic_class)))
    delete_sx_cos_traffic_class_t_p(traffic_class_p)

""" ############################################################################################ """

""" COS PORT TC MCAWARE SET """
print("--------------- COS PORT TC MCAWARE SET ------------------------------")

mc_aware = False

rc = sx_api_cos_port_tc_mcaware_set(handle, PORT1, mc_aware)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_tc_mcaware_set [log_port=0x%x , mc_aware=%d] " % (PORT1, mc_aware)))

""" ############################################################################################ """

""" COS PORT TC MCAWARE GET """
print("--------------- COS PORT TC MCAWARE GET ------------------------------")

mc_aware_p = new_boolean_t_p()

rc = sx_api_cos_port_tc_mcaware_get(handle, PORT1, mc_aware_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
mc_aware = boolean_t_p_value(mc_aware_p)
print(("sx_api_cos_port_tc_mcaware_get [log_port=0x%x , mc_aware=%d] " % (PORT1, mc_aware)))

""" ############################################################################################ """


if args.deinit:
    print("Deinit")
    rc = sx_api_cos_port_tc_mcaware_set(handle, PORT1, original_mc_aware)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_tc_mcaware_set failed rc = %d " % (rc))
        sys.exit(rc)

    for i in range(0, element_count):
        priority = i
        traffic_class = i

        rc = sx_api_cos_port_tc_prio_map_set(handle, SX_ACCESS_CMD_ADD, PORT1, priority, original_traffic_class_list[i])
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_tc_prio_map_set failed rc = %d " % (rc))
            sys.exit(rc)

    rc = sx_api_cos_prio_to_ieeeprio_set(handle, original_ieee_switch_prio_p, original_ieee_prio_p, original_ieee_count)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_prio_to_ieeeprio_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_prio_to_dscp_rewrite_set(handle, PORT2, original_dscp_switch_priority_color_p, original_dscp_p, original_dscp_count)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_dscp_rewrite_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_prio_to_pcpdei_rewrite_set(handle, PORT2, original_pcp_switch_priority_color_p, original_pcp_p, original_pcp_count)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_prio_to_pcpdei_rewrite_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_dscp_to_prio_set(handle, PORT1, original_dscp_to_prio_p, original_dscp_to_prio_switch_priority_color_p, original_dscp_to_prio_count)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_dscp_to_prio_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_pcpdei_to_prio_set(handle, PORT1, original_pcp_to_prio_p, original_pcp_to_prio_switch_priority_color_p, original_pcp_to_prio_count)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_pcpdei_to_prio_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_rewrite_enable_set(handle, PORT1, original_rewrite)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_rewrite_enable_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_trust_set(handle, PORT1, original_trust_state)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_trust_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_default_color_set(handle, PORT1, original_color)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_default_color_set failed rc = %d " % (rc))
        sys.exit(rc)

    rc = sx_api_cos_port_default_prio_set(handle, PORT1, original_priority)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_default_prio_set failed rc = %d " % (rc))
        sys.exit(rc)

sx_api_close(handle)
