#!/usr/bin/env python
'''
Stateful DB example for eviction flow
    1. Configuring partition and writing 2 entries using sw access. This step will be executed only when running with the flag: add_configuration
    2. Clear activity of all entries in the given partition
    3. Reading the entries with activity disable
    4. Removing those entries using sx_api_stateful_db_entry_set API
'''

import argparse
from test_infra_common import *


def parse_args():
    description_str = """
    Stateful DB example for eviction flow
    1. Configuring partition and writing 2 entries using sw access. This step will be executed only when running with the flag: add_configuration.
    2. Clear activity of all entries in the given partition
    3. Reading the entries with activity disable
    4. Removing those entries using sx_api_stateful_db_entry_set API
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--partition_id", type=int, default=1,
                        help="Partition ID to delete its entries, range is [0-7]. Default is [%(default)d]")
    parser.add_argument("--waiting_time", type=int, default=1,
                        help="Waiting time after clear activity and before start eviction in seconds, range is [0-1000]. Default is [%(default)d]")
    parser.add_argument('--add_configuration', action='store_true', default=True, help="Adding configuration - insert 2 rules to stateful DB via SW access")
    parser.add_argument('--no_configuration', action='store_false', dest='add_configuration', help='Set add_configuration flag to False')

    return parser.parse_args()


def stateful_db_init(handle, sem_unlock_fail=False, max_sem_retries=1, force_ordering_enable=False, ordering_register_id=0):
    print("[+] Init stateful DB")

    init_param_p = new_sx_stateful_db_init_param_t_p()
    init_param_p.stateful_db_attr.entry_not_found_sem_unlock_failure = sem_unlock_fail
    init_param_p.stateful_db_attr.max_sem_retries = max_sem_retries
    init_param_p.stateful_db_attr.force_ordering_enable = force_ordering_enable
    init_param_p.stateful_db_attr.ordering_register.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    init_param_p.stateful_db_attr.ordering_register.key.gp_reg.reg_id = ordering_register_id

    rc = sx_api_stateful_db_init_set(handle, init_param_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB init set failed")
        sys.exit(rc)


def host_ifc_set(handle):
    rx_fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, rx_fd_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open FD: rc = " + str(rc))
        sys.exit(rc)

    uc_p = new_sx_user_channel_t_p()
    uc_p.type = SX_USER_CHANNEL_TYPE_FD
    uc_p.channel.fd = rx_fd_p
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, 0, SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, uc_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to register on bulk counter DONE. rc = " + str(rc))
        sys.exit(rc)
    return rx_fd_p


def host_ifc_close(handle, rx_fd_p):
    uc_p = new_sx_user_channel_t_p()
    uc_p.type = SX_USER_CHANNEL_TYPE_FD
    uc_p.channel.fd = rx_fd_p
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, 0, SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, uc_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to de register from bulk counter DONE. rc = " + str(rc))

    rc = sx_api_host_ifc_close(handle, rx_fd_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open FD: rc = " + str(rc))


def wait_for_async_read_done(rx_fd_p):
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)
    pkt = new_uint8_t_arr(pkt_size)
    recv_info_p = new_sx_receive_info_t_p()

    rc = sx_lib_host_ifc_recv(rx_fd_p, pkt, pkt_size_p, recv_info_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to receive BULK COUNTER DONE event. rc = " + str(rc))
        sys.exit(rc)
    else:
        print("Async read completed!")


def partition_info_get(handle, partition_id):
    partition_state_p = new_sx_stateful_db_partition_status_t_p()
    rc = sx_api_stateful_db_partition_get(handle, SX_ACCESS_CMD_GET, partition_id, partition_state_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition get failed")
        sys.exit(rc)
    partition_state = sx_stateful_db_partition_status_t_p_value(partition_state_p)
    return partition_state


def dump_partition_info(partition_id, partition_state):
    print("------Partition Info----------------")
    print(" Partition %d  " % partition_id)
    print(" Partition name = %s" % (partition_state.partition_cfg.partition_name))
    print(" Partition size = %d" % (partition_state.partition_cfg.max_size))
    print(" Partition warning threshold = %d. " % (partition_state.partition_cfg.warn_size))
    print(" Partition occupancy = %d" % (partition_state.num_entries))
    print("-----------------------------------")


def partition_create(handle, partition_id, partition_size, partition_warn_threshold, name):
    partition_cfg_p = new_sx_stateful_db_partition_cfg_t_p()
    partition_cfg_p.max_size = partition_size
    partition_cfg_p.warn_size = partition_warn_threshold
    partition_cfg_p.partition_name = name
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_CREATE, partition_id, partition_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition create failed")
        sys.exit(rc)
    print(" Partition %d, size %d created" % (partition_id, partition_size))


def partition_destroy(handle, partition_id):
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_DESTROY, partition_id, None)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition destroy failed")
        sys.exit(rc)


def stateful_db_deinit(handle):
    rc = sx_api_stateful_db_deinit_set(handle)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB Deinit failed")
        sys.exit(rc)


def bulk_buffer_destroy(handle, cntr_buffer_p):
    rc = sx_api_bulk_counter_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, cntr_buffer_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to destroy bulk buffer: rc = " + str(rc))


def large_key_create(handle):

    mask = "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff"
    large_key_p = new_sx_stateful_db_key_t_p()
    large_key_id_p = new_sx_stateful_db_key_id_t_p()
    large_acl_key = sx_stateful_db_acl_key_t()

    large_key_p.key_name = "Stateful DB large key example"
    large_key_p.key_desc.acl_key_desc.acl_key_cnt = 3
    large_key_p.key_desc.acl_key_desc.is_symmetric = False
    large_acl_key.key_id = FLEX_ACL_KEY_DIPV6
    large_acl_key.mask.dipv6 = make_sx_ip_addr_v6(mask)
    sx_stateful_db_acl_key_t_arr_setitem(large_key_p.key_desc.acl_key_desc.acl_key_list_p, 0, large_acl_key)
    large_acl_key.key_id = FLEX_ACL_KEY_SIPV6
    large_acl_key.mask.sipv6 = make_sx_ip_addr_v6(mask)
    sx_stateful_db_acl_key_t_arr_setitem(large_key_p.key_desc.acl_key_desc.acl_key_list_p, 1, large_acl_key)
    large_acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    large_acl_key.mask.ethertype = 0xffff
    sx_stateful_db_acl_key_t_arr_setitem(large_key_p.key_desc.acl_key_desc.acl_key_list_p, 2, large_acl_key)

    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_CREATE, large_key_p, large_key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_set create failed.")
        sys.exit(rc)

    large_key_size = large_key_p.key_size
    large_key_id = sx_stateful_db_key_id_t_p_value(large_key_id_p)
    print("key ID is %d, key_size is %d." % (large_key_id, large_key_p.key_size))

    return large_key_size, large_key_id


def key_destroy(handle, key_id):

    key_id_p = new_sx_stateful_db_key_id_t_p()
    sx_stateful_db_key_id_t_p_assign(key_id_p, key_id)
    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_DESTROY, None, key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_set destroy failed")
        sys.exit(rc)


def key_dump(handle, key_id):
    key_p = new_sx_stateful_db_key_t_p()
    acl_key = sx_stateful_db_acl_key_t()

    rc = sx_api_stateful_db_key_get(handle, SX_ACCESS_CMD_GET, key_id, key_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_get failed")
        sys.exit(rc)

    print("--------- Key info ----------")
    print("Dump for key ID %d" % key_id)
    print("Key name: %s" % key_p.key_name)
    print("Key size: %d" % key_p.key_size)
    print("Key type: %d" % key_p.key_type)
    for i in range(key_p.key_desc.acl_key_desc.acl_key_cnt):
        acl_key = sx_stateful_db_acl_key_t_arr_getitem(key_p.key_desc.acl_key_desc.acl_key_list_p, i)
        print("[%d] ACL key ID %d" % (i, acl_key.key_id))
    print("------------------------------")


def large_entry_set(handle, key_id, partition_id, sipv6, dipv6, ethr, op_db, op_sem, val):
    key = sx_stateful_db_sw_access_key_t()
    key_p = new_sx_stateful_db_sw_access_key_t_p()
    data = sx_stateful_db_sw_access_data_t()
    data_p = new_sx_stateful_db_sw_access_data_t_p()
    stateful_db_acl_key = sx_stateful_db_acl_key_data_t()

    key.db_op = op_db
    key.sem_op = op_sem
    key.key_id = key_id
    key.partition_id = partition_id
    key.key_data.acl_data.key_data_list_cnt = 3
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_SIPV6
    stateful_db_acl_key.key_value.sipv6 = make_sx_ip_addr_v6(sipv6)

    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 0, stateful_db_acl_key)
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_DIPV6
    stateful_db_acl_key.key_value.dipv6 = make_sx_ip_addr_v6(dipv6)
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 1, stateful_db_acl_key)

    stateful_db_acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    stateful_db_acl_key.key_value.ethertype = ethr
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 2, stateful_db_acl_key)

    if (op_db == SX_STATEFUL_DB_OP_WRITE_E):
        data.entry_data.db_entry_value = val

    sx_stateful_db_sw_access_key_t_p_assign(key_p, key)
    sx_stateful_db_sw_access_data_t_p_assign(data_p, data)

    rc = sx_api_stateful_db_entry_set(handle, SX_ACCESS_CMD_SET, key_p, data_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_entry_set failed.")
        sys.exit(rc)

    print("------ Entry set info -----------")
    print("Entry data:")
    print("Access status  [%d]" % data.db_op_status)
    print("Entry found? [%d]" % data.entry_found)
    print("Data value [ 0x%x ]" % data.entry_data.db_entry_value)
    print("---------------------------------")


def large_entry_meta_get(handle, key_id, partition_id, sipv6, dipv6, ethr):

    key = sx_stateful_db_sw_access_key_t()
    key_p = new_sx_stateful_db_sw_access_key_t_p()
    data_p = new_sx_stateful_db_sw_access_data_t_p()
    meta_p = new_sx_stateful_db_entry_meta_t_p()
    stateful_db_acl_key = sx_stateful_db_acl_key_data_t()

    key.key_id = key_id
    key.partition_id = partition_id
    key.key_data.acl_data.key_data_list_cnt = 3
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_SIPV6
    stateful_db_acl_key.key_value.sipv6 = make_sx_ip_addr_v6(sipv6)
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 0, stateful_db_acl_key)
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_DIPV6
    stateful_db_acl_key.key_value.dipv6 = make_sx_ip_addr_v6(dipv6)
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 1, stateful_db_acl_key)
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    stateful_db_acl_key.key_value.ethertype = ethr
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 2, stateful_db_acl_key)
    sx_stateful_db_sw_access_key_t_p_assign(key_p, key)

    rc = sx_api_stateful_db_entry_meta_get(handle, SX_ACCESS_CMD_GET, key_p, data_p, meta_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_entry_meta_get failed.")
        sys.exit(rc)

    data = sx_stateful_db_sw_access_data_t_p_value(data_p)
    meta = sx_stateful_db_entry_meta_t_p_value(meta_p)

    print("--------- Large Entry info ---------------")
    print("Entry data:")
    print("  Access status [%d]" % data.db_op_status)
    print("  Entry found?[%d]" % data.entry_found)
    print("  Data value[ 0x%x ]" % data.entry_data.db_entry_value)
    print("Entry meta:")
    print("  Activity [%d]" % meta.entry_activity)
    print("  Semaphore state [%d]" % meta.entry_sem_status)
    print("  Semaphore count[%d]" % meta.entry_sem_cnt)
    print("------------------------------------")


def adding_rules(handle, max_entries_in_partition, entries_warning_threshold, large_key_size, large_key_id):
    print("[+] Create key,partition & write entry to partition ")
    print("  [+] Create key")
    # For validation purpose: dump created stateful key.
    key_dump(handle, large_key_id)
    print("  [+] Create partition")
    partition_id = SX_STATEFUL_DB_PARTITION_1_E
    partition_size = max_entries_in_partition * large_key_size  # key_size
    partition_warn_threshold = entries_warning_threshold * large_key_size  # key_size
    name = "Eviction example Partition"
    partition_create(handle, partition_id, partition_size, partition_warn_threshold, name)
    # For validation purpose
    partition_info = partition_info_get(handle, partition_id)
    dump_partition_info(partition_id, partition_info)

    # For validation purpose: query non exist entry.
    EXAMPLE_ETHR_TYPE = 0x88cc
    EXAMPLE_ENTRY_VAL3 = 45
    EXAMPLE_ENTRY_VAL4 = 43
    EXAMPLE_SIPV6 = "1234:4567:1020:3040:0001:0002:0003:0004"
    EXAMPLE_SIPV6_1 = "1234:4567:1020:3040:0001:0002:CAFE:CAFE"
    EXAMPLE_DIPV6 = "A234:A567:A020:A040:0005:0006:0007:0008"
    EXAMPLE_DIPV6_1 = "A234:A567:A020:A040:0005:0006:CAFE:CAFE"

    print("  [+] Write large new entry to stateful DB")
    large_entry_set(handle, large_key_id, partition_id, EXAMPLE_SIPV6, EXAMPLE_DIPV6, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_SEM_NOP_E, EXAMPLE_ENTRY_VAL3)
    print("  [+] Read new entry from stateful DB")
    large_entry_set(handle, large_key_id, partition_id, EXAMPLE_SIPV6, EXAMPLE_DIPV6, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_SEM_NOP_E, 0)
    print(" [+] For validation- data and meta data of new entry")
    large_entry_meta_get(handle, large_key_id, partition_id, EXAMPLE_SIPV6, EXAMPLE_DIPV6, EXAMPLE_ETHR_TYPE)
    print("  [+] partition occupancy should increase by 4 ")
    partition_info = partition_info_get(handle, partition_id)
    print("  [+] Write large new entry 2to stateful DB")
    large_entry_set(handle, large_key_id, partition_id, EXAMPLE_SIPV6_1, EXAMPLE_DIPV6_1, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_SEM_NOP_E, EXAMPLE_ENTRY_VAL4)
    print("  [+] Read new entry from stateful DB")
    large_entry_set(handle, large_key_id, partition_id, EXAMPLE_SIPV6_1, EXAMPLE_DIPV6_1, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_SEM_NOP_E, 0)
    print(" [+] For validation- data and meta data of new entry")
    large_entry_meta_get(handle, large_key_id, partition_id, EXAMPLE_SIPV6_1, EXAMPLE_DIPV6_1, EXAMPLE_ETHR_TYPE)
    print("  [+] partition occupancy should increase by 4 ")
    partition_info = partition_info_get(handle, partition_id)
    dump_partition_info(partition_id, partition_info)


def bulk_counter_clear_activity(handle, fd_p, max_entries_in_partition, partition_id):
    cntr_buffer_p = new_sx_bulk_cntr_buffer_t_p()
    key_p = sx_bulk_cntr_buffer_key_t()
    key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    key_p.key.stateful_db_key.key_id_filter_valid = False
    key_p.key.stateful_db_key.activity_filter_valid = False
    key_p.key.stateful_db_key.sem_lock_filter_valid = False
    key_p.key.stateful_db_key.entries_num_max = max_entries_in_partition
    key_p.key.stateful_db_key.partition_id = partition_id
    cmd = SX_ACCESS_CMD_CREATE

    print("Register on bulk counter done trap")
    rc = sx_api_bulk_counter_buffer_set(handle, cmd, key_p, cntr_buffer_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API  sx_api_bulk_counter_buffer_set failed.")
        sys.exit(rc)
    print("SDK API  sx_api_bulk_counter_buffer_set OK.")

    cmd = SX_ACCESS_CMD_CLEAR
    rc = sx_api_bulk_counter_transaction_set(handle, cmd, cntr_buffer_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API  sx_api_bulk_counter_transaction_set failed.")
        sys.exit(rc)
    print(" SDK API  sx_api_bulk_counter_transaction_set OK")
    print("Wait for partition read completion")
    wait_for_async_read_done(fd_p)

    print("Destroy bulk buffer ")
    bulk_buffer_destroy(handle, cntr_buffer_p)


def bulk_counter_buffer_set(handle, cntr_buffer_unused_entries_p, max_entries_in_partition, partition_id):
    key_p = sx_bulk_cntr_buffer_key_t()
    key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    key_p.key.stateful_db_key.key_id_filter_valid = False
    key_p.key.stateful_db_key.activity_filter_valid = True
    key_p.key.stateful_db_key.is_active = False
    key_p.key.stateful_db_key.sem_lock_filter_valid = False
    key_p.key.stateful_db_key.entries_num_max = max_entries_in_partition
    key_p.key.stateful_db_key.partition_id = partition_id
    cmd = SX_ACCESS_CMD_CREATE

    rc = sx_api_bulk_counter_buffer_set(handle, cmd,
                                        key_p,
                                        cntr_buffer_unused_entries_p)

    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API  sx_api_bulk_counter_buffer_set failed.")
        sys.exit(rc)
    print("SDK API  sx_api_bulk_counter_buffer_set OK.")


def bulk_counter_read_and_remove(handle, cntr_buffer_unused_entries_p, partition_id, fd_p):
    cmd = SX_ACCESS_CMD_READ
    rc = sx_api_bulk_counter_transaction_set(handle, cmd, cntr_buffer_unused_entries_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API  sx_api_bulk_counter_transaction_set failed.")
        sys.exit(rc)
    print(" SDK API  sx_api_bulk_counter_transaction_set OK")
    print("Wait for partition read completion")
    wait_for_async_read_done(fd_p)

    counter_data_p = bulk_counter_num_of_entries_get(handle, cntr_buffer_unused_entries_p)

    delete_rules_after_bulk_counter_get(handle, cntr_buffer_unused_entries_p, counter_data_p, partition_id)


def bulk_counter_num_of_entries_get(handle, cntr_buffer_unused_entries_p):
    read_key_p = new_sx_bulk_cntr_read_key_t_p()
    read_key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    read_key_p.key.stateful_db_key.type = SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_NUM_ENTRIES_GET_E
    counter_data_p = new_sx_bulk_cntr_data_t_p()

    rc = sx_api_bulk_counter_transaction_get(handle,
                                             read_key_p,
                                             cntr_buffer_unused_entries_p,
                                             counter_data_p)

    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_bulk_counter_transaction_get failed.")
        sys.exit(rc)

    return counter_data_p


def delete_rules_after_bulk_counter_get(handle, cntr_buffer_unused_entries_p, counter_data_p, partition_id):
    key = sx_stateful_db_sw_access_key_t()
    key_p = new_sx_stateful_db_sw_access_key_t_p()
    data = sx_stateful_db_sw_access_data_t()
    data_p = new_sx_stateful_db_sw_access_data_t_p()
    counter_data = sx_bulk_cntr_data_t_p_value(counter_data_p)
    entries_num = counter_data.data.stateful_db_entry_data.stateful_db_entries_num_p.entries_num
    key.db_op = SX_STATEFUL_DB_OP_REMOVE_INDICATION_E
    key.sem_op = SX_STATEFUL_DB_SEM_NOP_E
    key.partition_id = partition_id
    read_key_p = new_sx_bulk_cntr_read_key_t_p()
    read_key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    read_key_p.key.stateful_db_key.type = SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_ENTRY_DATA_GET_E

    for index in range(entries_num):
        read_key_p.key.stateful_db_key.read_key.entry_access.entry_index = index

        rc = sx_api_bulk_counter_transaction_get(handle,
                                                 read_key_p,
                                                 cntr_buffer_unused_entries_p,
                                                 counter_data_p)
        if (rc != SX_STATUS_SUCCESS):
            print("ERROR: SDK API sx_api_bulk_counter_transaction_get failed.")
            sys.exit(rc)

        for j in range(
                counter_data_p.data.stateful_db_entry_data.stateful_db_entry_p.key_data.acl_data.key_data_list_cnt):
            acl_key = sx_stateful_db_acl_key_data_t_arr_getitem(
                counter_data_p.data.stateful_db_entry_data.stateful_db_entry_p.key_data.acl_data.key_data_list_p, j)
            sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, j, acl_key)

        # delete rule via SW access
        key.key_data.acl_data.key_data_list_cnt = counter_data_p.data.stateful_db_entry_data.stateful_db_entry_p.key_data.acl_data.key_data_list_cnt
        key.key_id = counter_data_p.data.stateful_db_entry_data.stateful_db_entry_p.key_id
        sx_stateful_db_sw_access_key_t_p_assign(key_p, key)
        sx_stateful_db_sw_access_data_t_p_assign(data_p, data)

        rc = sx_api_stateful_db_entry_set(handle, SX_ACCESS_CMD_SET, key_p, data_p)
        if (rc != SX_STATUS_SUCCESS):
            print("ERROR: SDK API sx_api_stateful_db_entry_set failed.")
            sys.exit(rc)

    print("Destroy bulk buffer ")
    bulk_buffer_destroy(handle, cntr_buffer_unused_entries_p)


def main():
    args = parse_args()     # Parse given arguments
    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    if args.partition_id not in range(8):
        print(("partition id %d is not valid." % (args.partition_id)))
        help_cmd()
        sys.exit(1)

    print("[+] Open SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)
    try:

        # Validate chip type for examples not supported on specific chip types
        chip_type = get_chip_type(handle)
        if (chip_type < SX_CHIP_TYPE_SPECTRUM4):
            print("This example is not supported below Spectrum4 - Exiting gracefully")
            sys.exit(0)

        print("Register on bulk counter done trap")
        fd_p = host_ifc_set(handle)

        max_entries_in_partition = 1000
        if (args.add_configuration):
            print("stateful DB init and configure global attributes")
            # set global attributes
            sem_unlock_fail = False
            max_sem_retries = 2
            force_ordering_enable = False
            ordering_register_id = 0
            entries_warning_threshold = 80

            stateful_db_init(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id)
            large_key_size, large_key_id = large_key_create(handle)
            adding_rules(handle, max_entries_in_partition, entries_warning_threshold, large_key_size, large_key_id)

        bulk_counter_clear_activity(handle, fd_p, max_entries_in_partition, args.partition_id)

        # Waiting before reading the rules again in order to delete only unused entries
        print("waiting %d seconds before continue..." % args.waiting_time)
        time.sleep(args.waiting_time)

        cntr_buffer_unused_entries_p = new_sx_bulk_cntr_buffer_t_p()

        bulk_counter_buffer_set(handle, cntr_buffer_unused_entries_p, max_entries_in_partition, args.partition_id)

        bulk_counter_read_and_remove(handle, cntr_buffer_unused_entries_p, args.partition_id, fd_p)
        host_ifc_close(handle, fd_p)

        print("dump partition after deleting rules")
        partition_info = partition_info_get(handle, args.partition_id)
        dump_partition_info(args.partition_id, partition_info)

        if args.deinit:

            if args.add_configuration:

                print("Destroy stateful DB partition")
                partition_destroy(handle, args.partition_id)

                print("Destroy stateful DB Key")
                key_destroy(handle, large_key_id)

                print("Deinit stateful DB module")
                stateful_db_deinit(handle)

                print("SUCCESS")

    finally:
        print("[+] Close SDK ")
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
