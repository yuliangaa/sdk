#!/usr/bin/env python
"""
This file contains a example for the VLAN module.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configuration operations:
1. Adds multiple ports to a specific VLAN.
2. Adds a port to a list of VLANs.
3. Retrieves ports in a specific VLAN.
4. Update port's default VLAN.
5. Sets VLAN related port attributes.
6. Sets port's Q-in-Q mode.
7. Sets port's outer tag priority (relevant only when Q-in-Q is enabled).
8. Removes all the ports from the above mentioned VLANs.

"""

import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_vlan')
parser.add_argument('--force', default=False, action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]
PORT_2 = port_list[1]

swid = 0
vid = 5

# Save current ports in vlan for later de-configuration
port_cnt_p = new_uint32_t_p()
rc = sx_api_vlan_ports_get(handle, swid, vid, None, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
    sys.exit(rc)
original_port_cnt = uint32_t_p_value(port_cnt_p)
original_vlan_port_list_p = new_sx_vlan_ports_t_arr(original_port_cnt)

rc = sx_api_vlan_ports_get(handle, swid, vid, original_vlan_port_list_p, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
    sys.exit(rc)

# Adds multiple ports to a the vlan
vlan_arr = new_sx_vlan_ports_t_arr(2)
vlan_port0 = sx_vlan_ports_t()
vlan_port0.log_port = PORT_1
vlan_port0.is_untagged = 1
vlan_port1 = sx_vlan_ports_t()
vlan_port1.log_port = PORT_2
vlan_port1.is_untagged = 1
sx_vlan_ports_t_arr_setitem(vlan_arr, 0, vlan_port0)
sx_vlan_ports_t_arr_setitem(vlan_arr, 1, vlan_port1)

rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, swid, vid, vlan_arr, 2)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ports_get failed; rc=%d" % (rc)
print(("Add %d ports to vlan %d , rc: %d " % (2, vid, rc)))

log_port = PORT_1

# Save current pvid for later de-configuration
original_pvid_p = new_sx_vid_t_p()
rc = sx_api_vlan_port_pvid_get(handle, log_port, original_pvid_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_vlan_port_pvid_get failed, rc = %d" % (rc))
    sys.exit(rc)
origianl_pvid = sx_vid_t_p_value(original_pvid_p)

# Update port's default VLAN.
pvid = 4
rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, log_port, pvid)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_pvid_set failed; rc=%d" % (rc)
print(("Set pvid %d for port %d, rc %d " % (pvid, log_port, rc)))

# Save current prio tagged state for later de-configuration
original_prio_tag_state_p = new_sx_untagged_prio_state_t_p()
rc = sx_api_vlan_port_prio_tagged_get(handle, log_port, original_prio_tag_state_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_prio_tagged_get failed; rc=%d" % (rc)
original_prio_tag_state = sx_untagged_prio_state_t_p_value(original_prio_tag_state_p)

# sx_api_vlan_port_prio_tagged_set 0x10001 SX_PRIO_TAGGED_STATE
prio_tag_state = SX_PRIO_TAGGED_STATE
rc = sx_api_vlan_port_prio_tagged_set(handle, log_port, prio_tag_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_prio_tagged_set failed; rc=%d" % (rc)
print(("Set SX_PRIO_TAGGED_STATE prio_tag_state %d for port %d, rc %d " % (prio_tag_state, log_port, rc)))

# sx_api_vlan_port_prio_tagged_set 0x10001 SX_UNTAGGED_STATE
prio_tag_state = SX_UNTAGGED_STATE
rc = sx_api_vlan_port_prio_tagged_set(handle, log_port, prio_tag_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_prio_tagged_set failed; rc=%d" % (rc)
print(("Set prio_tag_state %d for port %d, rc %d " % (prio_tag_state, log_port, rc)))

# Save current ingress_filter_mode for later de-configuration
original_ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
rc = sx_api_vlan_port_ingr_filter_get(handle, log_port, original_ingress_filter_mode_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_get failed; rc=%d" % (rc)
original_ingr_filter_mode = sx_ingr_filter_mode_t_p_value(original_ingress_filter_mode_p)

# sx_api_vlan_port_ingr_filter_set 0x10001 SX_INGR_FILTER_DISABLE
ingr_fltr_state = SX_INGR_FILTER_DISABLE
rc = sx_api_vlan_port_ingr_filter_set(handle, log_port, ingr_fltr_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed; rc=%d" % (rc)
print(("Set ingr_fltr_state %d for port %d, rc %d " % (ingr_fltr_state, log_port, rc)))

# sx_api_vlan_port_ingr_filter_set 0x10001 SX_INGR_FILTER_ENABLE
ingr_fltr_state = SX_INGR_FILTER_ENABLE
rc = sx_api_vlan_port_ingr_filter_set(handle, log_port, ingr_fltr_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed; rc=%d" % (rc)
print(("Set ingr_fltr_state %d for port %d, rc %d " % (ingr_fltr_state, log_port, rc)))

# Save current accptd_frame_type for later de-configuration
original_accptd_frame_type_p = new_sx_vlan_frame_types_t_p()
rc = sx_api_vlan_port_accptd_frm_types_get(handle, log_port, original_accptd_frame_type_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_accptd_frm_types_get failed; rc=%d" % (rc)
print(("Set sx_api_vlan_port_accptd_frm_types_get; rc=%d" % (rc)))

# sx_api_vlan_port_accptd_frm_types_set PORT_1 {1;0;0}
accptd_frame_type = sx_vlan_frame_types_t()
accptd_frame_type.allow_untagged = 1
accptd_frame_type.allow_priotagged = 0
accptd_frame_type.allow_tagged = 0
rc = sx_api_vlan_port_accptd_frm_types_set(handle, log_port, accptd_frame_type)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_accptd_frm_types_set failed; rc=%d" % (rc)
print(("Set sx_api_vlan_port_accptd_frm_types_set (1,0,0) for port %d, rc %d " % (log_port, rc)))

# sx_api_vlan_port_accptd_frm_types_set PORT_1 {0;1;0}
accptd_frame_type = sx_vlan_frame_types_t()
accptd_frame_type.allow_untagged = 0
accptd_frame_type.allow_priotagged = 1
accptd_frame_type.allow_tagged = 0
rc = sx_api_vlan_port_accptd_frm_types_set(handle, log_port, accptd_frame_type)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_accptd_frm_types_set failed; rc=%d" % (rc)
print(("Set sx_api_vlan_port_accptd_frm_types_set (0,1,0) for port %d, rc %d " % (log_port, rc)))

# sx_api_vlan_port_accptd_frm_types_set PORT_1 {0;0;1}
accptd_frame_type = sx_vlan_frame_types_t()
accptd_frame_type.allow_untagged = 0
accptd_frame_type.allow_priotagged = 0
accptd_frame_type.allow_tagged = 1
rc = sx_api_vlan_port_accptd_frm_types_set(handle, log_port, accptd_frame_type)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_accptd_frm_types_set failed; rc=%d" % (rc)
print(("sx_api_vlan_port_accptd_frm_types_set (0,0,1) for port %d, rc %d " % (log_port, rc)))

# sx_api_vlan_port_qinq_mode_set 0x10001 SX_QINQ_MODE_QINQ
qinq_mode = SX_QINQ_MODE_QINQ
# Register SPVTR Unsupported yet by FW
#rc = sx_api_vlan_port_qinq_mode_set(handle, log_port, qinq_mode);
#print ("Set sx_api_vlan_port_qinq_mode_set %d for port %d, rc %d " % (qinq_mode, log_port, rc) )

# sx_api_vlan_port_qinq_outer_prio_mode_set 0x10001 SX_QINQ_OUTER_PRIO_MODE_CVLAN
qinq_outer_prio_mode = SX_QINQ_OUTER_PRIO_MODE_CVLAN

# Register SPVTR Unsupported yet by FW
#rc = sx_api_vlan_port_qinq_outer_prio_mode_set(handle, log_port, qinq_outer_prio_mode);
#print ("sx_api_vlan_port_qinq_outer_prio_mode_set %d for port %d, rc %d " % (qinq_outer_prio_mode, log_port, rc) )

# Save current switch default vlan id for later de-configuration
original_default_vid_p = new_sx_vid_t_p()
rc = sx_api_vlan_default_vid_get(handle, swid, original_default_vid_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_default_vid_set failed; rc=%d" % (rc)
print("sx_api_vlan_default_vid_get done")
original_default_vid = sx_vid_t_p_value(original_default_vid_p)

# sx_api_vlan_default_vid_set 0 1
rc = sx_api_vlan_default_vid_set(handle, swid, 1)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_default_vid_set failed; rc=%d" % (rc)
print(("sx_api_vlan_default_vid_set %d for swid %d, rc %d " % (1, 0, rc)))

if args.deinit:
    rc = sx_api_vlan_default_vid_set(handle, swid, original_default_vid)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_default_vid_set failed; rc=%d" % (rc)
    print(("sx_api_vlan_default_vid_set %d for swid %d, rc %d " % (original_default_vid, 0, rc)))

    rc = sx_api_vlan_port_accptd_frm_types_set(handle, log_port, original_accptd_frame_type_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_accptd_frm_types_set failed; rc=%d" % (rc)
    print(("Set sx_api_vlan_port_accptd_frm_types_set for port %d, rc %d " % (log_port, rc)))

    rc = sx_api_vlan_port_ingr_filter_set(handle, log_port, original_ingr_filter_mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_get failed; rc=%d" % (rc)
    print(("Set ingr_fltr_state %d for port %d, rc %d " % (original_ingr_filter_mode, log_port, rc)))

    rc = sx_api_vlan_port_prio_tagged_set(handle, log_port, original_prio_tag_state)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_prio_tagged_set failed; rc=%d" % (rc)
    print("sx_api_vlan_port_prio_tagged_set done")

    pvid = 4
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_DELETE, log_port, pvid)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_pvid_set failed; rc=%d" % (rc)
    print(("Delete pvid %d for port %d, rc %d " % (pvid, log_port, rc)))

    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, log_port, origianl_pvid)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_pvid_set failed; rc=%d" % (rc)
    print(("Delete pvid %d for port %d, rc %d " % (origianl_pvid, log_port, rc)))

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE_ALL, swid, vid, None, 0)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ports_set failed; rc=%d" % (rc)
    print("sx_api_vlan_ports_set done")

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, swid, vid, original_vlan_port_list_p, original_port_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ports_set failed; rc=%d" % (rc)
    print("sx_api_vlan_ports_set done")
