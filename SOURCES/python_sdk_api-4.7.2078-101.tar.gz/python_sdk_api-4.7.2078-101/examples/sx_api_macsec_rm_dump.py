#!/usr/bin/env python
"""
This file contains Python command example for the RESOURCE MANAGER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
	1. Get the number of data entry duplication per table type
	2. Configuration of duplication per data entry is not allowed in run
	   time at the moment. The configuration of data entries duplication
	   should take place before SDK initialization.

"""
import sys
import socket
import struct
import errno
import colorsys
import argparse
import logging
import pdb
import decimal
from python_sdk_api.sx_api import *
import sys
from python_sdk_api.sxd_api import *
from test_infra_common import *
from optparse import OptionParser, Option


######################################################
#    defines
######################################################
macsec_logical_rsrc_choices = {
    "macsec_rules": RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULES_E,
    "macsec_cntr": RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_COUNTER_E,
    "macsec_sadb": RM_SDK_TABLE_TYPE_PORT_MACSEC_SADB_E,
}
macsec_hw_rsrc_choices = {
    "macsec_rules": RM_HW_TABLE_TYPE_MACSEC_UTCAM_E,
    "macsec_cntr": RM_HW_TABLE_TYPE_MACSEC_UTCAM_COUNTER_E,
    "macsec_sadb": RM_HW_TABLE_TYPE_MACSEC_USADB_E,
}
macsec_dir_dict = {
    "ingress": SX_MACSEC_DIR_INGRESS_E,
    "egress": SX_MACSEC_DIR_EGRESS_E,
}
acl_key_width_dict = {
    # 0: SX_ACL_FLEX_KEY_WIDTH_NONE_E,
    # 9: SX_ACL_FLEX_KEY_WIDTH_9_E,
    18: SX_ACL_FLEX_KEY_WIDTH_18_E,
    36: SX_ACL_FLEX_KEY_WIDTH_36_E,
    54: SX_ACL_FLEX_KEY_WIDTH_54_E
}
rm_operations_list = ['hw_util', 'sw_util', 'free_cnt']
macsec_logical_rsrc_choices_list = list(str(key) for key in macsec_logical_rsrc_choices.keys())
macsec_dir_dict_list = [str(key) for key in macsec_dir_dict.keys()]
macsec_dir_dict_list2 = [str(key) for key in macsec_dir_dict.keys()]

######################################################
#    functions
######################################################


def print_acl_header():
    print("===============================================================================================")
    header = ["Resource", "log_port", "direction", "key_width", "SW Used", "SW Free", "HW Used", "HW Total"]
    print("|%25s|%10s|%10s|%10s|%8s|%8s|%8s|%8s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7]))
    print("===============================================================================================")


def print_header():
    print("====================================================================================")
    header = ["Resource", "log_port", "direction", "SW Used", "SW Free", "HW Used", "HW Total"]
    print("|%25s|%10s|%10s|%8s|%8s|%8s|%8s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6]))
    print("====================================================================================")


def print_footer():
    print("====================================================================================")


def print_macsec_resource_counts(resource, port, direction, key_width, count=None, sw_util=None, hw_util=None):
    for name, enum in macsec_dir_dict.items():
        if enum == direction:
            dir_to_print = name
    macsec_rm_resource_dict = get_enum_string_dict('RM_SDK_TABLE_TYPE_PORT_MACSEC_')

    rsrc = macsec_rm_resource_dict[resource].replace('RM_SDK_TABLE_TYPE_PORT_', '')
    if count is None:
        count_to_print = "N/A"
    else:
        count_to_print = count
    if sw_util is None:
        sw_util_to_print = "N/A"
    else:
        sw_util_to_print = sw_util
    if hw_util is None:
        hw_util_to_print = "N/A"
        max = "N/A"
    else:
        if (resource == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULES_E):
            max = "4096"
        elif (resource == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_COUNTER_E):
            max = "16"
        else:
            max = "1024"
        hw_util = decimal.Decimal(hw_util) / decimal.Decimal(10)
        hw_util_to_print = str(hw_util) + "%"

    if key_width:
        width_to_print = str(key_width) + "B"
        print("|%25s|%10s|%10s|%10s|%8s|%8s|%8s|%8s|" % (rsrc, hex(port), dir_to_print,
                                                         width_to_print, sw_util_to_print, count_to_print, hw_util_to_print, max))
        print("-----------------------------------------------------------------------------------------------")
    else:
        print("|%25s|%10s|%10s|%8s|%8s|%8s|%8s|" % (rsrc, hex(port), dir_to_print,
                                                    sw_util_to_print, count_to_print, hw_util_to_print, max))
        print("------------------------------------------------------------------------------------")


def validate_args(handle, args):
    ports_attributes_list = ports_attributes_get(handle)
    port_list = []
    for i in range(len(ports_attributes_list)):
        port_list.append(ports_attributes_list[i].log_port)
    if args.log_port not in port_list:
        print("!!! log_port = {} is not a valid port on this system. ".format(hex(args.log_port)))
        return SX_STATUS_PARAM_ERROR
    if not is_port_macsec_capable(handle, args.log_port):
        print("!!! log_port = {} is not MACSec capable. Exiting".format(hex(args.log_port)))
        return SX_STATUS_PARAM_ERROR
    else:

        return SX_STATUS_SUCCESS


def handle_macsec_rm_free_cnt_get(handle, resource, log_port, direction, key_width):
    free_count = 0
    free_cnt_p = copy_uint32_t_p(free_count)

    macsec_rm_logical_table = sx_api_rm_sdk_logical_resource_t()
    macsec_rm_logical_table.rsrc_type = resource
    macsec_rm_logical_table.key_valid = True

    if macsec_rm_logical_table.rsrc_type == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULES_E:
        macsec_rm_logical_table.rsrc_key.macsec_acl_rule.port = log_port
        macsec_rm_logical_table.rsrc_key.macsec_acl_rule.dir = direction
        macsec_rm_logical_table.rsrc_key.macsec_acl_rule.key_width = key_width
    elif macsec_rm_logical_table.rsrc_type == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_COUNTER_E:
        macsec_rm_logical_table.rsrc_key.macsec_acl_cntr.port = log_port
        macsec_rm_logical_table.rsrc_key.macsec_acl_cntr.dir = direction
    else:
        # RM_SDK_TABLE_TYPE_PORT_MACSEC_SADB_E
        macsec_rm_logical_table.rsrc_key.macsec_sadb.port = log_port
        macsec_rm_logical_table.rsrc_key.macsec_sadb.dir = direction

    rc = sx_api_rm_free_entries_by_type_ext_get(handle, macsec_rm_logical_table, free_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        raise Exception("sx_api_rm_free_entries_by_type_ext_get failed. [%s(%d)]" % (sx_status_dict[rc], rc))

    free_count = uint32_t_p_value(free_cnt_p)

    return rc, free_count


def handle_macsec_rm_hw_util_get(handle, resource, log_port, direction, key_width):
    hw_util = 0
    hw_util_p = copy_uint32_t_p(hw_util)

    hw_type = sx_api_rm_hw_resource_t()

    hw_type.rsrc_type = resource
    hw_type.key_valid = True
    if hw_type.rsrc_type == RM_HW_TABLE_TYPE_MACSEC_UTCAM_E:
        hw_type.rsrc_key.macsec_utcam.port = log_port
        hw_type.rsrc_key.macsec_utcam.dir = direction
        hw_type.rsrc_key.macsec_utcam.key_width = key_width
    elif hw_type.rsrc_type == RM_HW_TABLE_TYPE_MACSEC_UTCAM_COUNTER_E:
        hw_type.rsrc_key.macsec_utcam_cntr.port = log_port
        hw_type.rsrc_key.macsec_utcam_cntr.dir = direction
    else:
        # RM_SDK_TABLE_TYPE_PORT_MACSEC_SADB_E
        hw_type.rsrc_key.macsec_sadb.port = log_port
        hw_type.rsrc_key.macsec_sadb.dir = direction

    rc = sx_api_rm_hw_utilization_ext_get(handle, hw_type, hw_util_p)
    if rc != SX_STATUS_SUCCESS:
        raise Exception("sx_api_rm_hw_utilization_ext_get failed. [%s(%d)]" % (sx_status_dict[rc], rc))

    hw_util = uint32_t_p_value(hw_util_p)

    return rc, hw_util


def handle_macsec_rm_sw_util_get(handle, resource, log_port, direction, key_width):
    sw_util = sx_api_rm_table_utilization_t()

    sw_type = sx_api_rm_sdk_logical_resource_t()
    sw_type_list = new_sx_api_rm_sdk_logical_resource_t_arr(1)
    sw_util_list_p = new_sx_api_rm_table_utilization_t_arr(1)
    list_count_p = new_uint32_t_p()
    uint32_t_p_assign(list_count_p, 1)

    sw_type.rsrc_type = resource
    sw_type.key_valid = True
    if sw_type.rsrc_type == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULES_E:
        sw_type.rsrc_key.macsec_acl_rule.port = log_port
        sw_type.rsrc_key.macsec_acl_rule.dir = direction
        sw_type.rsrc_key.macsec_acl_rule.key_width = key_width
    elif sw_type.rsrc_type == RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_COUNTER_E:
        sw_type.rsrc_key.macsec_acl_cntr.port = log_port
        sw_type.rsrc_key.macsec_acl_cntr.dir = direction
    else:
        # RM_HW_TABLE_TYPE_MACSEC_USADB_E
        sw_type.rsrc_key.macsec_sadb.port = log_port
        sw_type.rsrc_key.macsec_sadb.dir = direction

    sx_api_rm_sdk_logical_resource_t_arr_setitem(sw_type_list, 0, sw_type)

    rc = sx_api_rm_sdk_table_utilization_ext_get(handle, sw_type_list, list_count_p, sw_util_list_p)
    list_cnt = uint32_t_p_value(list_count_p)
    if rc != SX_STATUS_SUCCESS:
        raise Exception("sx_api_rm_sdk_table_utilization_ext_get failed. [%s(%d)]" % (sx_status_dict[rc], rc))
    if list_cnt != 1:
        raise Exception("sx_api_rm_sdk_table_utilization_ext_get failed. list_cnt = (%d), expected = 1 ]" % (list_cnt))

    sw_util = sx_api_rm_table_utilization_t_arr_getitem(sw_util_list_p, 0)

    return rc, sw_util.sdk_table_entries_used


def process_macsec_rm_ops(handle, args):
    rc = SX_STATUS_SUCCESS
    try:

        rc = validate_args(handle, args)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("port validation failed, rc=%d" % (rc))

        hw_util_cnt = None
        sw_util_cnt = None
        free_count = None
        log_port = args.log_port

        for rsrc in macsec_logical_rsrc_choices.keys():
            if rsrc == "macsec_rules":
                print_acl_header()
            else:
                print_header()
            for direction in macsec_dir_dict.values():
                sw_resource = macsec_logical_rsrc_choices[rsrc]
                hw_resource = macsec_hw_rsrc_choices[rsrc]
                key_width = None

                if rsrc == "macsec_rules":
                    for key_width in acl_key_width_dict.values():
                        rc, free_count = handle_macsec_rm_free_cnt_get(handle, sw_resource, log_port, direction, key_width)
                        if rc != SX_STATUS_SUCCESS:
                            raise Exception("free_cnt_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                        rc, sw_util_cnt = handle_macsec_rm_sw_util_get(handle, sw_resource, log_port, direction, key_width)
                        if rc != SX_STATUS_SUCCESS:
                            raise Exception("sw_util_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                        rc, hw_util_cnt = handle_macsec_rm_hw_util_get(handle, hw_resource, log_port, direction, key_width)
                        if rc != SX_STATUS_SUCCESS:
                            raise Exception("hw_util_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                        print_macsec_resource_counts(sw_resource, log_port, direction, key_width,
                                                     free_count, sw_util_cnt, hw_util_cnt)
                else:
                    # pdb.set_trace()
                    rc, free_count = handle_macsec_rm_free_cnt_get(handle, sw_resource, log_port, direction, key_width)
                    if rc != SX_STATUS_SUCCESS:
                        raise Exception("free_cnt_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                    rc, sw_util_cnt = handle_macsec_rm_sw_util_get(handle, sw_resource, log_port, direction, key_width)
                    if rc != SX_STATUS_SUCCESS:
                        raise Exception("sw_util_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                    rc, hw_util_cnt = handle_macsec_rm_hw_util_get(handle, hw_resource, log_port, direction, key_width)
                    if rc != SX_STATUS_SUCCESS:
                        raise Exception("hw_util_get failed for %s %s %x [%s(%d)]" % (rsrc, direction, log_port, sx_status_dict[rc], rc))
                    print_macsec_resource_counts(sw_resource, log_port, direction, key_width,
                                                 free_count, sw_util_cnt, hw_util_cnt)

        print_footer()

    except Exception as e:
        logging.error("MACSec RM Dump failed with exception %s" % (str(e)))

        return SX_STATUS_SUCCESS

    finally:
        return rc


def is_port_macsec_capable(handle, port):
    try:
        capab = sx_macsec_port_capability_t()
        capab_p = new_sx_macsec_port_capability_t_p()
        rc = sx_api_macsec_port_capability_get(handle, port, capab_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_macsec_port_capability_get failed, rc=%d" % (rc))

        capab = sx_macsec_port_capability_t_p_value(capab_p)
        # TODO Change the flag below from macsec_supported to macsec_enabled once it is added
        print("MacSec Supported = {}".format(bool(capab.macsec_supported)))
        return bool(capab.macsec_supported)

    finally:
        delete_sx_macsec_port_capability_t_p(capab_p)


def print_help():
    print("""Example :\n
            sx_api_macsec_dm_dump.py 0x10001
			""")


def parse_args():

    parser = argparse.ArgumentParser(description='SDK MACSec Resource Manager Dump ')
    parser.add_argument('log_port', default=0, type=auto_int, help="MACSec Logical Port ")

    try:
        args = parser.parse_args()
    except SystemExit:
        print("\n\n")
        print_help()
        exit()

    return args


######################################################
#    main
######################################################
def main():

    args = parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print("MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

        decimal.getcontext().prec = 3
    rc = process_macsec_rm_ops(handle, args)

    sx_api_close(handle)

    if rc:
        sys.exit(1)
    else:
        print("[+] operation completed successfully \n")


if __name__ == "__main__":
    main()
