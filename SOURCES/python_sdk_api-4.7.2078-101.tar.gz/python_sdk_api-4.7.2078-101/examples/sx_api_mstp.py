#!/usr/bin/env python
"""
This file contains a Python commands example for the MSTP module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configuration operations:
1. Sets the STP mode to RSTP.
2. Sets in RSTP port state (learning / discarding / forwarding).
3. Changes the STP mode to MSTP.
4. Gets the STP mode.
5. Sets the STP mode back to RSTP.
"""
import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_mstp example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]

# gets the current STP mode
swid = 0
stp_mode_p = new_sx_mstp_mode_t_p()
rc = sx_api_mstp_mode_get(handle, swid, stp_mode_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_get failed, rc: %d" % (rc)
original_stp_mode = sx_mstp_mode_t_p_value(stp_mode_p)
delete_sx_mstp_mode_t_p(stp_mode_p)
print(("sx_api_mstp_mode_get swid %d mode %d , rc %d " % (swid, original_stp_mode, rc)))

# Get original RSTP States of all ports - They change during MSTP Mode change
original_rstp_modes = {}
stp_state_p = new_sx_mstp_inst_port_state_t_p()
for port in port_list:
    rc = sx_api_rstp_port_state_get(handle, port, stp_state_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_get failed, port 0x%x, rc: %d" % (port, rc)
    original_rstp_modes[port] = sx_mstp_inst_port_state_t_p_value(stp_state_p)
delete_sx_mstp_inst_port_state_t_p(stp_state_p)

# 1. Sets the STP mode to RSTP.
swid = 0
stp_mode = SX_MSTP_MODE_RSTP
rc = sx_api_mstp_mode_set(handle, swid, stp_mode)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_set failed, rc: %d" % (rc)
print(("sx_api_mstp_mode_set swid %d mode %d , rc %d " % (swid, stp_mode, rc)))

# 2.1 Sets in RSTP port state learning
log_port = PORT_1
stp_state = SX_MSTP_INST_PORT_STATE_LEARNING
rc = sx_api_rstp_port_state_set(handle, log_port, stp_state)
assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, rc: %d" % (rc)
print(("sx_api_rstp_port_state_set log_port 0x%x stp_state %d , rc %d " % (log_port, stp_state, rc)))

# 2.2 Sets in RSTP port state discarding
log_port = PORT_1
stp_state = SX_MSTP_INST_PORT_STATE_DISCARDING
rc = sx_api_rstp_port_state_set(handle, log_port, stp_state)
assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, rc: %d" % (rc)
print(("sx_api_rstp_port_state_set log_port 0x%x stp_state %d , rc %d " % (log_port, stp_state, rc)))

# 2.3 Sets in RSTP port state forwarding
log_port = PORT_1
stp_state = SX_MSTP_INST_PORT_STATE_FORWARDING
rc = sx_api_rstp_port_state_set(handle, log_port, stp_state)
assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, rc: %d" % (rc)
print(("sx_api_rstp_port_state_set log_port 0x%x stp_state %d , rc %d " % (log_port, stp_state, rc)))

# 3. Changes the STP mode to MSTP.
swid = 0
stp_mode = SX_MSTP_MODE_MSTP
rc = sx_api_mstp_mode_set(handle, swid, stp_mode)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_set failed, rc: %d" % (rc)
print(("sx_api_mstp_mode_set swid %d mode %d , rc %d " % (swid, stp_mode, rc)))

# 4. Gets the STP mode.
swid = 0
stp_mode_p = new_sx_mstp_mode_t_p()
rc = sx_api_mstp_mode_get(handle, swid, stp_mode_p)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_get failed, rc: %d" % (rc)
stp_mode = sx_mstp_mode_t_p_value(stp_mode_p)
delete_sx_mstp_mode_t_p(stp_mode_p)
print(("sx_api_mstp_mode_get swid %d mode %d , rc %d " % (swid, stp_mode, rc)))

# 5. Sets the STP mode back to RSTP.
swid = 0
stp_mode = SX_MSTP_MODE_RSTP
rc = sx_api_mstp_mode_set(handle, swid, stp_mode)
assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_set failed, rc: %d" % (rc)
print(("sx_api_mstp_mode_set swid %d mode %d , rc %d " % (swid, stp_mode, rc)))

if args.deinit:
    print("Clean up")

    swid = 0
    rc = sx_api_mstp_mode_set(handle, swid, original_stp_mode)
    assert SX_STATUS_SUCCESS == rc, "sx_api_mstp_mode_set failed, rc: %d" % (rc)
    print(("sx_api_mstp_mode_set swid %d mode %d , rc %d " % (swid, original_stp_mode, rc)))

    for port, rstp_state in original_rstp_modes.items():
        rc = sx_api_rstp_port_state_set(handle, port, rstp_state)
        assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, port 0x%x, rc: %d" % (port, rc)

sx_api_close(handle)
