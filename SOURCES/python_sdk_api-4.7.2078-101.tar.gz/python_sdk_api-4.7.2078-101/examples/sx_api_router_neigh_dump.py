#!/usr/bin/env python
'''
This file contains Python command example for the ROUTER NEIGHBORS DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import os

from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
from flex_acl_common import router_module_verbosity_level_get, router_module_verbosity_level_set


def get_all_neighbors(handle, version):
    try:
        neighbors = []
        neigh_entry_arr = new_sx_neigh_get_entry_t_arr(128)
        rif = 0
        neigh_key_p = new_sx_ip_addr_t_p()
        neigh_key = sx_ip_addr_t()
        neigh_key.version = version
        neigh_key.addr.ipv4.addr = 0
        sx_ip_addr_t_p_assign(neigh_key_p, neigh_key)
        data_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(data_cnt_p, 128)

        # The following is used to prevent error messages if the router is not initialized
        module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
        router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

        rc = sx_api_router_neigh_get(handle, SX_ACCESS_CMD_GET_FIRST, rif, neigh_key_p, None, neigh_entry_arr, data_cnt_p)
        router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
        data_cnt = uint32_t_p_value(data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            # check if router module initialize
            if rc == SX_STATUS_MODULE_UNINITIALIZED:
                print("# Router is not initialized ")
                return neighbors

            print("An error was found in sx_api_router_neigh_get. rc: %d" % (rc))
            sys.exit(rc)

        read_number = 0
        while (data_cnt == 128):
            for i in range(0, data_cnt):
                neighbor = sx_neigh_get_entry_t_arr_getitem(neigh_entry_arr, i)
                neighbors.append(neighbor)

            rif = neighbor.neigh_data.rif
            sx_ip_addr_t_p_assign(neigh_key_p, neighbor.ip_addr)
            rc = sx_api_router_neigh_get(handle, SX_ACCESS_CMD_GETNEXT, rif, neigh_key_p, None, neigh_entry_arr, data_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("An error was found in sx_api_router_neigh_get. rc: %d" % (rc))
                sys.exit(rc)
            data_cnt = uint32_t_p_value(data_cnt_p)
            read_number = read_number + 1

        for i in range(0, data_cnt):
            neighbor = sx_neigh_get_entry_t_arr_getitem(neigh_entry_arr, i)
            neighbors.append(neighbor)
    finally:
        delete_uint32_t_p(data_cnt_p)
        delete_sx_ip_addr_t_p(neigh_key_p)
        delete_sx_neigh_get_entry_t_arr(neigh_entry_arr)

    return neighbors


def main():
    ip_dict = {0: 'NONE', 1: 'IPV4', 2: 'IPV6'}
    prio_dict = {0: 'BEST_EFFORT', 1: 'LOW', 2: 'MED', 3: 'HIGH', 4: 'CRITICAL'}
    action_dict = {0: 'DROP', 1: 'TRAP', 2: 'FORWARD', 3: 'TRAP_FORWARD', 4: 'SPAN'}

    print_api_example_disclaimer()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        neighbors = get_all_neighbors(handle, SX_IP_VERSION_IPV4) + get_all_neighbors(handle, SX_IP_VERSION_IPV6)
        if len(neighbors) > 0:
            print("----------------------------------------------------------------------------------------------------------")
            print("|%10s|%40s|%15s|%15s|%20s|" % ("RIF", "IP", "Action", "Trap Prio", "MAC"))
            print("----------------------------------------------------------------------------------------------------------")
            for neighbor in neighbors:
                print("|%10d|%40s|%15s|%15s|%20s|" % (neighbor.neigh_data.rif,
                                                      ip_addr_to_str(neighbor.ip_addr),
                                                      action_dict[neighbor.neigh_data.action],
                                                      prio_dict[neighbor.neigh_data.trap_attr.prio],
                                                      neighbor.neigh_data.mac_addr.to_str()))
                print("----------------------------------------------------------------------------------------------------------")

    finally:
        sx_api_close(handle)


if __name__ == '__main__':
    main()
