#!/usr/bin/env python
'''
This is an example how to use port profile for configuration.
Init flow : open sdk and host interface
Register to port profile trap
Create port profile
Set port profile attributes
get port list
Save ports old attributes
Apply port profile on port list
Wait fro port profile done trap
Get port list attributes, verify they changed
Deint flow

'''

import errno
import sys
import colorsys
import argparse
import importlib

from python_sdk_api.sx_api import *
from test_infra_common import *
from threading import Thread


def get_test_args():
    parser = argparse.ArgumentParser(description='sx_api_port_mtu_set')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    return args


def sx_recv(fd_p, handle):
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)

    pkt = sx_event_port_profile_apply_done_t()
    pkt_p = new_sx_event_port_profile_apply_done_t_p()
    sx_event_port_profile_apply_done_t_p_assign(pkt_p, pkt)

    recv_info_p = new_sx_receive_info_t_p()

    rc = sx_lib_host_ifc_recv(fd_p, pkt_p, pkt_size_p, recv_info_p)
    if rc != SX_STATUS_SUCCESS:
        print(("[recv] host_ifc_redv failed, rc %d" % rc))
        sys.exit(rc)

    # print the event parametes
    print("[recv] Receive port profile apply done on the fd")
    print(("Recv trap id: 0x%x" % recv_info_p.trap_id))
    print(("Recv port profile index %d" % recv_info_p.event_info.port_profile_apply_done_info.port_profile_index))
    print(("Recv port profile status %d" % recv_info_p.event_info.port_profile_apply_done_info.status))

    print("[recv] recv done")


def main():
    args = get_test_args()
    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    print(" ---- Init Test Flow  ---- ")
    print("[+] Open sdk")
    SWID = 0
    DEVICE_ID = 1
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)
    print("[+] Check number of port profiles initialized")
    sx_api_sx_sdk_init_p = new_sx_api_sx_sdk_init_t_p()
    rc = sx_api_sdk_init_params_get(handle, sx_api_sx_sdk_init_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to get sdk init params.\n")
        sys.exit(rc)
    sdk_init_attr = sx_api_sx_sdk_init_t_p_value(sx_api_sx_sdk_init_p)
    profile = getattr(sdk_init_attr, "profile")
    port_profiles_num = getattr(profile, "port_profile_num")
    print("port_profiles_num = %d" % (port_profiles_num))
    if port_profiles_num == 0:
        print("WARNING : No port profiles were initailized.\n"
              "To intialize port profiles please call sx_api_sdk_init_set with sdk_init_params_p-> profile.port_profile_num = <1-4> .\n"
              "Or call dvs_start.sh with flag --port_profile_num <1..4>.\n")
        sys.exit(SX_STATUS_SUCCESS)

    print("[+] Open host interface ")
    fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_open failed rc %d" % rc))
        sys.exit(rc)
    fd = sx_fd_t_p_value(fd_p)
    print(("sx_api_host_ifc_open,fd = %d rc=%d " % (fd.fd, rc)))

    print("--- Register to trap : port profile apply done ---")
    print("[+]Registering to SX_TRAP_ID_PORT_PROFILE_APPLY_DONE = 0x%x" % (SX_TRAP_ID_PORT_PROFILE_APPLY_DONE))
    sx_user_channel_p = new_sx_user_channel_t_p()
    sx_user_channel_p.type = SX_USER_CHANNEL_TYPE_FD
    sx_user_channel_p.channel.fd = fd
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, SWID,
                                              SX_TRAP_ID_PORT_PROFILE_APPLY_DONE,
                                              sx_user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed rc %d" % rc))
        sys.exit(rc)
    print(("sx_api_host_ifc_trap_id_register_set  rc %d " % (rc)))
    delete_sx_user_channel_t_p(sx_user_channel_p)

    print("[+] open rx thread to receive the trap ")
    rx = Thread(target=sx_recv, args=(fd_p, handle))
    rx.setDaemon(True)
    rx.start()

    print("[+] get log_ports")
    ports_num = 2
    log_port = []
    log_port = get_ports(handle, ports_num)
    for i in range(ports_num):
        print("log_port[ %d] = 0x%x " % (i, log_port[i]))

    print("--- create port profile ----")
    port_profile1_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port_profile1_p, 0)
    param_p = new_sx_port_profile_params_t_p()
    rc = sx_api_port_profile_set(handle, SX_ACCESS_CMD_CREATE, param_p, port_profile1_p)

    port_profile1 = sx_port_log_id_t_p_value(port_profile1_p)

    print("port profile id  =  0x%x" % (port_profile1))

    print(" --- set port profile attributes ---- ")
    print("[+] Set MTU for port profile")
    new_oper_mtu_size = 1024
    rc = sx_api_port_mtu_set(handle, port_profile1, new_oper_mtu_size)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_mtu_set failed, rc=[%d] " % (rc)))
        sys.exit(rc)
    print(("MTU set for port profile 0x%x, MTU: %d" % (port_profile1, new_oper_mtu_size)))

    max_mtu_size_p = new_sx_port_mtu_t_p()
    oper_mtu_size_p = new_sx_port_mtu_t_p()
    rc = sx_api_port_mtu_get(handle, port_profile1, max_mtu_size_p, oper_mtu_size_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
        sys.exit(rc)

    oper_mtu_size = sx_port_mtu_t_p_value(oper_mtu_size_p)
    print(("MTU get for port profile 0x%x, MTU: %d" % (port_profile1, oper_mtu_size)))

    print("[+] Set Loopback filter ")
    LOOPBACK_FILTER_DICT = {SX_LOOPBACK_FILTER_MODE_DISABLED: 'DISABLED', SX_LOOPBACK_FILTER_MODE_ENABLED: 'ENABLED'}
    mode = SX_LOOPBACK_FILTER_MODE_DISABLED
    rc = sx_api_port_loopback_filter_set(handle, port_profile1, mode)
    if (rc != SX_STATUS_SUCCESS):
        print(("sx_api_port_loopback_filter_set failed [rc=%d]" % (rc)))
        sys.exit(rc)
    print(("sx_api_port_loopback_filter_set log_port 0x%x type %s, rc %d " % (port_profile1, LOOPBACK_FILTER_DICT[mode], rc)))

    loopback_filter_type_p = new_sx_port_loopback_filter_mode_t_p()
    rc = sx_api_port_loopback_filter_get(handle, port_profile1, loopback_filter_type_p)
    if (rc != SX_STATUS_SUCCESS):
        sys.exit(rc)
        print(("sx_api_port_phys_loopback_get failed [rc=%d]" % (rc)))
    loopback_filter_type = sx_port_loopback_filter_mode_t_p_value(loopback_filter_type_p)
    print(("sx_api_port_loopback_get log_port 0x%x loopback_type:%s(%d), rc %d " %
           (port_profile1, LOOPBACK_FILTER_DICT[loopback_filter_type], loopback_filter_type, rc)))

    print("[+] Set state event delay for port profile")
    new_port_state_delay = sx_port_state_delay_t()
    new_port_state_delay.up_event_timeout = 200
    new_port_state_delay.down_event_timeout = 500
    new_port_state_delay_p = new_sx_port_state_delay_t_p()
    sx_port_state_delay_t_p_assign(new_port_state_delay_p, new_port_state_delay)
    rc = sx_api_port_state_event_delay_set(handle, SX_ACCESS_CMD_SET, port_profile1, new_port_state_delay_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state event delay_set failed, rc=[%d] " % (rc)))
        sys.exit(rc)
    print(("event state delay set for port profile 0x%x, up delay: %d, down delay: %d" %
           (port_profile1, new_port_state_delay.up_event_timeout, new_port_state_delay.down_event_timeout)))

    port_state_delay_p = new_sx_port_state_delay_t_p()
    rc = sx_api_port_state_event_delay_get(handle, port_profile1, port_state_delay_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state_event_delay_get failed, rc=[%d] " % (rc)))
        sys.exit(rc)

    print(("state delay get for port profile 0x%x, up delay: %d" % (port_profile1, port_state_delay_p.up_event_timeout)))
    print(("state delay get for port profile 0x%x, down delay: %d" % (port_profile1, port_state_delay_p.down_event_timeout)))

    print("----- Save ports old attributes ---")
    print("[+] get MTU")
    original_max_mtu_size_p = new_sx_port_mtu_t_p()
    original_oper_mtu_size_p = new_sx_port_mtu_t_p()
    orig_mtu_list = []
    for i in range(ports_num):
        rc = sx_api_port_mtu_get(handle, log_port[i], original_max_mtu_size_p, original_oper_mtu_size_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
            sys.exit(rc)
        original_oper_mtu_size = sx_port_mtu_t_p_value(original_oper_mtu_size_p)
        print(("Original MTU port  0x%x, MTU: %d" % (log_port[i], original_oper_mtu_size)))
        orig_mtu_list.append(original_oper_mtu_size)

    print("[+] Get Loopback filter ")
    # get original value
    orig_loopback_filter_list = []
    for i in range(ports_num):
        rc = sx_api_port_loopback_filter_get(handle, log_port[i], loopback_filter_type_p)
        if (rc != SX_STATUS_SUCCESS):
            sys.exit(rc)
            print(("sx_api_port_loopback_filter_get failed [rc=%d]" % (rc)))
        orig_loopback_filter_list.append(sx_port_loopback_filter_mode_t_p_value(loopback_filter_type_p))
        print(("sx_api_port_loopback_filter_get log_port 0x%x loopback_type:%s(%d), rc %d " %
               (log_port[i], LOOPBACK_FILTER_DICT[orig_loopback_filter_list[i]], orig_loopback_filter_list[i], rc)))

    print("[+] get state delay")
    orig_port_state_delay_p = new_sx_port_state_delay_t_p()
    orig_port_state_delay_list = []
    for i in range(ports_num):
        rc = sx_api_port_state_event_delay_get(handle, log_port[i], orig_port_state_delay_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_event_delay_get failed, rc=[%d] " % (rc)))
            sys.exit(rc)
        print(("Original up state delay port  0x%x, up state delay: %d" % (log_port[i],
                                                                           orig_port_state_delay_p.up_event_timeout)))
        orig_port_state_delay_list.append(orig_port_state_delay_p)
        print(("Original down state delay port  0x%x, down state delay: %d" % (
            log_port[i], orig_port_state_delay_p.down_event_timeout)))
        orig_port_state_delay_list.append(orig_port_state_delay_p)

    print("[+]Apply to log port ")
    params_p = new_sx_port_profile_apply_params_t_p()
    params_p.port_list_cnt = ports_num
    for i in range(ports_num):
        sx_port_log_id_t_arr_setitem(params_p.port_list, i, log_port[i])
    rc = sx_api_port_profile_apply_set(handle, port_profile1, params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_profile apply failed, rc=[%d] " % (rc)))
        sys.exit(rc)
    print("[+]Wait for trap to arrive ")

    # wait for the trap to arrive
    trap_rc = 0
    rx.join(timeout=20)
    if rx.is_alive():
        print("ERROR: port profile apply done trap didn't arrive!")
        trap_rc = 1
    else:
        print("Port profile apply done trap - handling completed")

    print("--- Get ports attribute and check their change --- ")
    print("[+] Validate MTU ")
    max_mtu_size_p = new_sx_port_mtu_t_p()
    oper_mtu_size_p = new_sx_port_mtu_t_p()
    for i in range(ports_num):
        rc = sx_api_port_mtu_get(handle, log_port[i], max_mtu_size_p, oper_mtu_size_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
            sys.exit(rc)
        oper_mtu_size = sx_port_mtu_t_p_value(oper_mtu_size_p)
        if oper_mtu_size != new_oper_mtu_size:
            print("MTU does not match configured value!")
        print(("MTU get for port 0x%x, MTU: %d configured MTU: %d" % (log_port[i], oper_mtu_size, new_oper_mtu_size)))

    print("[+] Validate looback filter ")
    for i in range(ports_num):
        rc = sx_api_port_loopback_filter_get(handle, log_port[i], loopback_filter_type_p)
        if (rc != SX_STATUS_SUCCESS):
            sys.exit(rc)
            print(("sx_api_port_loopback_filter_get  failed [rc=%d]" % (rc)))
        loopback_filter_type = sx_port_loopback_filter_mode_t_p_value(loopback_filter_type_p)
        if (loopback_filter_type != mode):
            print("Loopback filter type does not match configured value!")
        print(("sx_api_port_loopback_filter_get port profile 0x%x loopback_type:%s(%d) configured value:%s(%d), rc %d " %
               (log_port[i], LOOPBACK_FILTER_DICT[loopback_filter_type],
                loopback_filter_type, LOOPBACK_FILTER_DICT[mode], mode, rc)))

    print("[+] Validate delay state ")
    port_state_delay_p = new_sx_port_state_delay_t_p()
    for i in range(ports_num):
        rc = sx_api_port_state_event_delay_get(handle, log_port[i], port_state_delay_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
            sys.exit(rc)
        port_state_delay_value = sx_port_state_delay_t_p_value(port_state_delay_p)
        if port_state_delay_value.up_event_timeout != new_port_state_delay.up_event_timeout:
            print("up delay state does not match configured value!")
        print((" up delay state for port 0x%x, up delay state: %d configured up delay state: %d" %
               (log_port[i], port_state_delay_value.up_event_timeout, new_port_state_delay.up_event_timeout)))
        if port_state_delay_value.down_event_timeout != new_port_state_delay.down_event_timeout:
            print("down delay state does not match configured value!")
        print((" down delay state for port 0x%x, down delay state: %d configured down delay state: %d" %
               (log_port[i], port_state_delay_value.down_event_timeout, new_port_state_delay.down_event_timeout)))

    print("---- Deinit flow ---")
    print("[+] Destroy port profiles")
    rc = sx_api_port_profile_set(handle, SX_ACCESS_CMD_DESTROY, param_p, port_profile1_p)

    if args.deinit:
        print("[+] Set attribute to original values")
        for i in range(ports_num):
            # set back to the original mtu value
            rc = sx_api_port_mtu_set(handle, log_port[i], orig_mtu_list[i])
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_mtu_set failed, rc=[%d] " % (rc)))
                sys.exit(rc)
            print(("MTU set for port %d, MTU: %d" % (log_port[i], orig_mtu_list[i])))
            # set back to the original loop back filter
            rc = sx_api_port_loopback_filter_set(handle, log_port[i], orig_loopback_filter_list[i])
            if (rc != SX_STATUS_SUCCESS):
                print(("sx_api_port_loopback_filter_set failed [rc=%d]" % (rc)))
                sys.exit(rc)
            print(("sx_api_port_loopback_filter_set log_port 0x%x type %s, rc %d " %
                   (log_port[i], LOOPBACK_FILTER_DICT[orig_loopback_filter_list[i]], rc)))
            # set back to the original state delay value
            rc = sx_api_port_state_event_delay_set(handle, SX_ACCESS_CMD_SET, log_port[i], orig_port_state_delay_list[i])
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_state_event_delay_set failed, rc=[%d] " % (rc)))
                sys.exit(rc)
            print(("up state delay set for port 0x%x, up event: %d" %
                   (log_port[i], orig_port_state_delay_list[i].up_event_timeout)))
            print(("down state delay set for port 0x%x, up event: %d" % (
                log_port[i], orig_port_state_delay_list[i].down_event_timeout)))

    print("[+] Close SDK ")
    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
