#!/usr/bin/env python
"""
This file contains Python command example for the MC ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""
import sys
import socket
import struct
from argparse import Action

from python_sdk_api.sx_api import *
import sys
from test_infra_common import *
from python_sdk_api import sxd_api
import argparse

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

parser = argparse.ArgumentParser(description='sx_api_mc_router example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]


def get_chip_dev_id_and_rev():
    mgir = sxd_api.ku_mgir_reg()
    meta = sxd_api.sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = sxd_api.SXD_ACCESS_CMD_GET

    rc = sxd_api.sxd_access_reg_init(0, None, 2)
    if rc:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_mgir(mgir, meta, 1, None, None)
    if rc:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_deinit()
    if rc:
        sys.exit(rc)

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def get_chip_type():
    """
    :return: SX_CHIP_TYPE_SPECTRUM \ SX_CHIP_TYPE_SPECTRUM2, Based on device id retrieved from SXD
    """

    print("Retrieving Chip Type from SDK")
    device_id, _ = get_chip_dev_id_and_rev()
    return device_id


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def create_bridge():
    " This function creates bridge. "

    bridge_id_p = new_sx_bridge_id_t_p()

    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create bridge"

    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print("Created bridge %d, rc: %d" % (bridge_id, rc))
    return bridge_id


def create_vport(log_port, vlan_id, egress_mode):
    " This function creates vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport for port %d and vlan %d" % (log_port, vlan_id)

    log_vport = sx_port_log_id_t_p_value(log_vport_p)
    print("Create vport %d for port %d and vlan %d, rc: %d" % (log_vport, log_port, vlan_id, rc))
    return log_vport


def prepare_vlan_rif(vrid, port, vlan, mac, mtu=1500):
    add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})
    rif = create_vlan_rif(vrid, vlan, mac, mtu)
    return rif


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def destroy_vlan_rif(vrid, port, vlan, rif):
    delete_rif(vrid, rif)
    remove_ports_from_vlan(vlan, {port: SX_TAGGED_MEMBER})


def add_vport_to_bridge(bridge_id, log_vport):
    " This function adds vport to bridge with given parametrs. "

    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    assert SX_STATUS_SUCCESS == rc, "Failed to add vport %d to bridge %d" % (log_vport, bridge_id)
    print("Added vport %d to bridge %d , rc: %d" % (log_vport, bridge_id, rc))


def set_port_state(log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))


def create_bridge_rif(vrid, bridge_id, mac_addr, mtu=1500):
    " This function creates bridge rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_BRIDGE
    ifc_param.ifc.bridge.swid = SPECTRUM_SWID
    ifc_param.ifc.bridge.bridge = bridge_id

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed create bridge RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created bridge RIF: %d, rc: %d " % (rif, rc))
    return rif


def prepare_bridge_rif(vrid, port_vlan_list, mac, mtu=1500):
    bridge_id = create_bridge()

    vport_arr = [None] * len(port_vlan_list)
    for i, port_vlan in enumerate(port_vlan_list):
        add_ports_to_vlan(port_vlan[1], {port_vlan[0]: SX_TAGGED_MEMBER})
        vport_arr[i] = create_vport(port_vlan[0], port_vlan[1], SX_TAGGED_MEMBER)
        add_vport_to_bridge(bridge_id, vport_arr[i])
        set_port_state(vport_arr[i], SX_PORT_ADMIN_STATUS_UP)

    rif = create_bridge_rif(vrid, bridge_id, mac, mtu)
    return vport_arr, bridge_id, rif


def create_router_port_rif(vrid, log_port, mac_addr, mtu=1500):
    " This function creates router port rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_PORT_VLAN
    ifc_param.ifc.port_vlan.port = log_port
    ifc_param.ifc.port_vlan.vlan = 0

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router port for port %d" % (log_port)
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created router port RIF: %d for port %d, rc: %d" % (rif, log_port, rc))
    return rif


def destroy_bridge(bridge_id):
    " This function destroys bridge. "

    bridge_id_p = new_sx_bridge_id_t_p()
    sx_bridge_id_t_p_assign(bridge_id_p, bridge_id)

    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy bridge %d" % (bridge_id)
    print(("Destroyed bridge %d, rc: %d " % (bridge_id, rc)))


def delete_vport_from_bridge(bridge_id, log_vport):
    " This function removes vport from bridge with given parametrs. "
    # set port state to up
    set_port_state(log_vport, SX_PORT_ADMIN_STATUS_DOWN)

    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    assert SX_STATUS_SUCCESS == rc, "Failed to remove vport %d from bridge %d" % (log_vport, bridge_id)
    print(("Removed vport %d from bridge %d, rc: %d " % (log_vport, bridge_id, rc)))

    # set port state to up
    set_port_state(log_vport, SX_PORT_ADMIN_STATUS_UP)


def delete_vport(log_port, log_vport, vlan_id, egress_mode):
    " This function deletes vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_DELETE, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete vport %d" % (log_vport)
    print("Deleted vport %d from port %d and vlan %d, rc: %d " % (log_vport, log_port, vlan_id, rc))


def destroy_bridge_rif(vrid, vport_list, bridge_id, rif, port_vlan_list):
    delete_rif(vrid, rif)
    for i, vport in enumerate(vport_list):
        set_port_state(vport, SX_PORT_ADMIN_STATUS_DOWN)
        delete_vport_from_bridge(bridge_id, vport)
        delete_vport(port_vlan_list[i][0], vport, port_vlan_list[i][1], SX_TAGGED_MEMBER)

    for i, port_vlan in enumerate(port_vlan_list):
        remove_ports_from_vlan(port_vlan[1], {port_vlan[0]: SX_TAGGED_MEMBER})

    destroy_bridge(bridge_id)


def prepare_router_port_rif(vrid, port, mac, mtu=1500):
    rif = create_router_port_rif(vrid, port, mac, mtu)
    return rif


def destroy_router_port_rif(vrid, rif):
    delete_rif(vrid, rif)


def create_vport_rif(vrid, log_vport, mac_addr, mtu=1500):
    " This function creates vport rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VPORT
    ifc_param.ifc.vport.vport = log_vport

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vport RIF: %d, rc: %d " % (rif, rc))
    return rif


def prepare_vport_rif(vrid, port, vlan, mac, mtu=1500):
    add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})
    vport = create_vport(port, vlan, SX_TAGGED_MEMBER)
    rif = create_vport_rif(vrid, vport, mac, mtu)
    return vport, rif


def destroy_vport_rif(vrid, port, vlan, vport, rif):
    delete_rif(vrid, rif)
    delete_vport(port, vport, vlan, SX_TAGGED_MEMBER)
    remove_ports_from_vlan(vlan, {port: SX_TAGGED_MEMBER})


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_ipv4_mc_route_key(ingress_rif, s_addr, s_mask, g_addr, g_mask):
    mc_route_key = sx_mc_route_key_t()
    mc_route_key.source_addr = make_sx_ip_prefix_v4(s_addr, s_mask)
    mc_route_key.mc_group_addr = make_sx_ip_prefix_v4(g_addr, g_mask)
    mc_route_key.ingress_rif = ingress_rif
    return mc_route_key


def make_mc_route_attributes(rpf_action=SX_ROUTER_RPF_ACTION_DISABLED,
                             ttl_cmd=SX_ROUTE_TTL_CMD_DEC,
                             ttl_val=0,
                             prio_type=SX_PRIO_TYPE_MANUAL,
                             manual_prio=1,
                             rpf_group_id=0):
    mc_attr = sx_mc_route_attributes_t()
    mc_attr.rpf_action = rpf_action
    mc_attr.ttl_cmd = ttl_cmd
    mc_attr.ttl_val = ttl_val
    mc_attr.prio.type = prio_type
    mc_attr.prio.manual_prio = manual_prio
    mc_attr.rpf_group_id = rpf_group_id
    return mc_attr


def make_egress_rif_list(erif_list):
    erif_cnt = len(erif_list)
    erif_arr = new_sx_router_interface_t_arr(erif_cnt)
    for i, erif in enumerate(erif_list):
        sx_router_interface_t_arr_setitem(erif_arr, i, erif)
    return erif_arr


def make_mc_route_data(erif_list,
                       action=SX_ROUTER_ACTION_FORWARD,
                       trap_prio=0):
    mc_route_data = sx_mc_route_data_t()
    mc_route_data.action = action
    mc_route_data.trap_attr.prio = trap_prio
    mc_route_data.egress_rif_cnt = len(erif_list)
    for i, erif in enumerate(erif_list):
        sx_router_interface_t_arr_setitem(mc_route_data.egress_rif_list_p, i, erif)
    return mc_route_data


def add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_ADD,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add MC route to VRID %d, rc: %d" % (vrid, rc)
    print("Added MC route to VRID %d" % (vrid))


def modify_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_EDIT,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify MC route to VRID %d, rc: %d" % (vrid, rc)
    print("Modified MC route in VRID %d" % (vrid))


def delete_mc_route(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_DELETE,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete MC route from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted MC route from VRID %d" % (vrid))


def delete_all_mc_routes(vrid, protocol=SX_IP_VERSION_NONE):
    if (protocol == SX_IP_VERSION_IPV4):
        mc_route_key = make_ipv4_mc_route_key(0, '0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')
        mc_route_key_p = new_sx_mc_route_key_t_p()
        sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)
    else:
        mc_route_key_p = None

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_DELETE_ALL,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all MC routes from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted all MC routes from VRID %d" % (vrid))


def get_mc_route_activity(vrid, mc_route_key, clear=False):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    activity_p = new_boolean_t_p()

    cmd = SX_ACCESS_CMD_READ_CLEAR if clear else SX_ACCESS_CMD_READ

    rc = sx_api_router_mc_route_activity_get(handle,
                                             cmd,
                                             vrid,
                                             mc_route_key_p,
                                             activity_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get activity of MC route on VRID %d, rc: %d" % (vrid, rc)

    activity = boolean_t_p_value(activity_p)
    print("Activity of MC route is %s" % ("True" if (activity != 0) else "False"))


def add_egress_rifs(vrid, mc_route_key, new_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    new_erifs_arr = make_egress_rif_list(new_erifs)

    rc = sx_api_router_mc_egress_rif_set(handle,
                                         SX_ACCESS_CMD_ADD,
                                         vrid,
                                         mc_route_key_p,
                                         new_erifs_arr,
                                         len(new_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to add %d egress RIFs to MC route on VRID %d, rc: %d" % (len(new_erifs), vrid, rc)
    print("Added %d egress RIFs to MC route on VRID %d" % (len(new_erifs), vrid))


def set_egress_rifs(vrid, mc_route_key, new_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    new_erifs_arr = make_egress_rif_list(new_erifs)

    rc = sx_api_router_mc_egress_rif_set(handle,
                                         SX_ACCESS_CMD_SET,
                                         vrid,
                                         mc_route_key_p,
                                         new_erifs_arr,
                                         len(new_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to set %d egress RIFs to MC route on VRID %d, rc: %d" % (len(new_erifs), vrid, rc)
    print("Set %d egress RIFs to MC route on VRID %d" % (len(new_erifs), vrid))


def delete_egress_rifs(vrid, mc_route_key, deleted_erifs):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    deleted_erifs_arr = make_egress_rif_list(deleted_erifs)

    rc = sx_api_router_mc_egress_rif_set(handle,
                                         SX_ACCESS_CMD_DELETE,
                                         vrid,
                                         mc_route_key_p,
                                         deleted_erifs_arr,
                                         len(deleted_erifs))
    assert SX_STATUS_SUCCESS == rc, "Failed to delete %d egress RIFs from MC route on VRID %d, rc: %d" % (len(deleted_erifs), vrid, rc)
    print("Deleted %d egress RIFs from MC route on VRID %d" % (len(deleted_erifs), vrid))


def delete_all_egress_rifs(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_egress_rif_set(handle,
                                         SX_ACCESS_CMD_DELETE_ALL,
                                         vrid,
                                         mc_route_key_p,
                                         None,
                                         0)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all egress RIFs from MC route on VRID %d, rc: %d" % (vrid, rc)
    print("Deleted all egress RIFs from MC route on VRID %d" % (vrid))


def bind_mc_route_flow_counter(vrid, mc_route_key, counter_id):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_route_counter_bind_set(handle,
                                                 SX_ACCESS_CMD_BIND,
                                                 vrid,
                                                 mc_route_key_p,
                                                 counter_id)

    assert SX_STATUS_SUCCESS == rc, "Failed to bind MC route to counter %d on VRID %d, rc: %d" % (counter_id, vrid, rc)
    print("Binding MC route to counter %d on VRID %d" % (counter_id, vrid))


def create_flow_counter():
    " This function creates ecmp flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter, rc: %d" % (rc)

    counter_id = sx_router_counter_id_t_p_value(counter_p)

    print("Created Flow counter %d" % (counter_id))
    return counter_id


def read_flow_counters(flow_counter_id):
    " This function reads flow counter. "

    counter_set = sx_flow_counter_set_t()
    counter_set_p = new_sx_flow_counter_set_t_p()

    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, flow_counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d, rc: %d" % (flow_counter_id, rc)
    print("Read flow counter %d" % (flow_counter_id))
    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    return counter_set


def unbind_mc_route_flow_counter(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_route_counter_bind_set(handle,
                                                 SX_ACCESS_CMD_UNBIND,
                                                 vrid,
                                                 mc_route_key_p,
                                                 0)

    assert SX_STATUS_SUCCESS == rc, "Failed to unbind flow counter from MC route VRID %d, rc: %d" % (vrid, rc)
    print("Unbinding flow counter from MC route on VRID %d" % (vrid))


def destroy_flow_counter(flow_counter_id):
    " This function destroys flow counter. "

    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS
    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, flow_counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flow counter, rc: %d" % (rc)

    print("Destroyed flow counter %d" % (flow_counter_id))


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = rpf_enable
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                uc_default_action=SX_ROUTER_ACTION_DROP,
                mc_default_action=SX_ROUTER_ACTION_DROP):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = ipv4_enable
    router_attr.ipv6_enable = ipv6_enable
    router_attr.ipv4_mc_enable = ipv4_mc_enable
    router_attr.ipv6_mc_enable = ipv6_mc_enable
    router_attr.uc_default_rule_action = uc_default_action
    router_attr.mc_default_rule_action = mc_default_action

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def set_rif_state_ipv4(rif,
                       ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                       ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def main():

    chip_type = get_chip_type()

    if chip_type == 0xcb84:     # SPC1
        DONT_CARE_RIF = 1001
    elif chip_type == 0xcf80:   # SPC4
        DONT_CARE_RIF = 8001
    else:                       # SPC2/3/5
        DONT_CARE_RIF = 4001

    # Initialize router
    router_init(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    # Create VRID that supports IPv4, both UC and MC
    vrid = create_vrid(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    port_vlan_list = [(PORT2, 3)]

    rif_arr = [None] * 4

    # Create 4 RIFs, one of each type that supports MC routing
    rif_arr[0] = prepare_vlan_rif(vrid, PORT1, 2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    vport_arr, bridge_id, rif_arr[1] = prepare_bridge_rif(vrid, port_vlan_list, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))
    rif_arr[2] = prepare_router_port_rif(vrid, PORT3, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x09))
    vport, rif_arr[3] = prepare_vport_rif(vrid, PORT4, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0a))

    # Create flow counter
    counter_id = create_flow_counter()

    # Enable IPv4 UC and MC on each RIF
    for i in range(4):
        set_rif_state_ipv4(rif_arr[i], ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    erif_list = [rif_arr[2]]

    # Create MC route (S = 0.0.0.0/0, G = 224.1.1.1/32) with one egress RIF
    mc_route_key = make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', '224.1.1.1', '255.255.255.255')
    mc_route_attr = make_mc_route_attributes()
    mc_route_data = make_mc_route_data(erif_list)
    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Bind flow counter to mc route
    bind_mc_route_flow_counter(vrid, mc_route_key, counter_id)

    # Send traffic to 224.1.1.1

    # Read flow counters
    counter_set = read_flow_counters(counter_id)

    # Unbind flow counter from mc route
    unbind_mc_route_flow_counter(vrid, mc_route_key)

    # Create MC route (S = 192.168.1.2/32, G = 224.1.1.2/32) with one egress RIF
    mc_route_key = make_ipv4_mc_route_key(DONT_CARE_RIF, '192.168.1.2', '255.255.255.255', '224.1.1.2', '255.255.255.255')
    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic from 192.168.1.2 to 224.1.1.2

    # Create directional MC route (S = 192.168.1.2/32, G = 224.1.1.3/32) with one egress RIF
    mc_route_key = make_ipv4_mc_route_key(rif_arr[0], '192.168.1.2', '255.255.255.255', '224.1.1.3', '255.255.255.255')
    mc_route_attr = make_mc_route_attributes(SX_ROUTER_RPF_ACTION_DIRECTIONAL)
    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.3

    # Add two additional egress RIFs to last MC route created
    erif_list = [rif_arr[1], rif_arr[3]]
    add_egress_rifs(vrid, mc_route_key, erif_list)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.3

    # Create MC route with RPF action DROP (S = 192.168.1.2/32, G = 224.1.1.4/32) with one egress RIF
    mc_route_key = make_ipv4_mc_route_key(rif_arr[0], '192.168.1.2', '255.255.255.255', '224.1.1.4', '255.255.255.255')
    mc_route_attr = make_mc_route_attributes(SX_ROUTER_RPF_ACTION_DROP)
    add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data)

    # Send traffic from first RIF, from 192.168.1.2 to 224.1.1.4

    # Get activity of last MC route configured, without clearing activity (activity should be True)
    get_mc_route_activity(vrid, mc_route_key, False)

    if args.deinit:
        # Destroy flow counter
        destroy_flow_counter(counter_id)

        # Delete all MC routes
        delete_all_mc_routes(vrid)

        # Destroy all RIFs
        destroy_vport_rif(vrid, PORT4, 5, vport, rif_arr[3])
        destroy_router_port_rif(vrid, rif_arr[2])
        destroy_bridge_rif(vrid, vport_arr, bridge_id, rif_arr[1], port_vlan_list)
        destroy_vlan_rif(vrid, PORT1, 2, rif_arr[0])

        # Destroy VRID
        delete_vrid(vrid)

        # Deinitialize router
        router_deinit()


if __name__ == "__main__":
    main()
