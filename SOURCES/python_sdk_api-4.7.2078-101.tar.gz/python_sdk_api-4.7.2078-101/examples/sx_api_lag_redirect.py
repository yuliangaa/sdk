#!/usr/bin/env python
'''
This file contains Python command example for the Tunneling module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import sys
import struct
import socket
import colorsys
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
from optparse import OptionParser, Option
import argparse

parser = argparse.ArgumentParser(description='sx_api_lag_redirect example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

ports_ingr_filter_mode = {}

######################################################
#    Functions API
######################################################

""" ############################################################################################ """


def make_lag():
    '''
    # 1. Configures the fields which impact the LAG hash distribution function.
    lag_hash_param = sx_lag_hash_param_t()
    lag_hash_param.lag_hash_type = SX_LAG_HASH_TYPE_XOR
    lag_hash_param.lag_hash = 0xA
    lag_hash_param.lag_seed = 0
    rc = sx_api_lag_hash_flow_params_set(handle, lag_hash_param)
    print ("sx_api_lag_hash_flow_params_set , type %d , rc %d " % (lag_hash_param.lag_hash_type, rc) )
    '''
    # 2. Creates a new LAG.
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

    rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
    print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    return lag_id


""" ############################################################################################ """


def destroy_lag(lag_id):
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, swid, lag_id_p, None, 0)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc))


""" ############################################################################################ """


def add_delete_lag_ports(cmd, swid, lag_id_p, port_list, port_cnt):
    """ ############################################################################################ """
    """ ADD/DELETE LAG MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD PORTS TO LAG ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE PORTS FROM LAG ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_id_p, port_list, port_cnt)
    print(("sx_api_lag_port_group_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    return rc


""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (
        str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


######################################################
#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_make_redirect_lag():
    swid = 0
    VLAN1 = 1
    VLAN2 = 2
    lag_server = make_lag()
    lag_peerlink = make_lag()

    ports_ingr_filter_mode[PORT2] = ingr_filter_get(PORT2)
    ports_ingr_filter_mode[PORT3] = ingr_filter_get(PORT3)

    lag1_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag1_p, lag_server)
    port2_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port2_p, PORT2)
    rc = add_delete_lag_ports(SX_ACCESS_CMD_ADD, swid, lag1_p, port2_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT2, lag_server, rc)))

    lag2_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag2_p, lag_peerlink)
    port3_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port3_p, PORT3)
    rc = add_delete_lag_ports(SX_ACCESS_CMD_ADD, swid, lag2_p, port3_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    port_state_set(PORT1, SX_PORT_ADMIN_STATUS_UP)

    port_state_set(lag_server, SX_PORT_ADMIN_STATUS_UP)

    rc = sx_api_lag_port_collector_set(handle, lag_server, PORT2, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT2, lag_server, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_server, PORT2, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT2, lag_server, rc)))

    port_state_set(lag_peerlink, SX_PORT_ADMIN_STATUS_UP)

    rc = sx_api_lag_port_collector_set(handle, lag_peerlink, PORT3, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_peerlink, PORT3, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    rc = sx_api_rstp_port_state_set(handle, lag_server, SX_MSTP_INST_PORT_STATE_FORWARDING)
    print(("sx_api_rstp_port_state_set set lag 0x%x FORWARDING, rc %d " % (lag_server, rc)))
    rc = sx_api_rstp_port_state_set(handle, lag_peerlink, SX_MSTP_INST_PORT_STATE_FORWARDING)
    print(("sx_api_rstp_port_state_set set lag 0x%x FORWARDING, rc %d " % (lag_peerlink, rc)))

    add_ports_to_vlan(VLAN2, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(VLAN2, {lag_server: SX_TAGGED_MEMBER})
    add_ports_to_vlan(VLAN2, {lag_peerlink: SX_TAGGED_MEMBER})

    # add fdb uc
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    mac_addr = ether_addr("E4:1D:2D:BD:07:12")

    mac_entry1 = sx_fdb_uc_mac_addr_params_t()
    mac_entry1.mac_addr = mac_addr
    mac_entry1.fid_vid = VLAN2          # Filtering Identifier, VID for static MAC
    mac_entry1.log_port = lag_server
    mac_entry1.entry_type = SX_FDB_UC_STATIC
    mac_entry1.action = SX_FDB_ACTION_FORWARD
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # add fdb mc
    group_addr = ether_addr(0x01, 0x00, 0x5E, 0x00, 0x00, 0x20)
    lag_server_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_server_p, lag_server)

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, swid, VLAN2, group_addr, None, 0)
    print(("sx_api_fdb_mc_mac_addr_set added mc group, rc: %d " % (rc)))

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD_PORTS, swid, VLAN2, group_addr, lag_server_p, 1)
    print(("sx_api_fdb_mc_mac_addr_set added 1 port, rc: %d " % (rc)))

    # set redirect
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag_server, lag_peerlink)
    print(("sx_api_lag_redirect_set, rc: %d " % (rc)))

    """ ############################################################################################ """

    if args.deinit:
        rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag_server, lag_peerlink)
        print(("sx_api_lag_redirect_set  [rc=%d] " % (rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE_PORTS, swid, VLAN2, group_addr, lag_server_p, 1)
        print(("sx_api_fdb_mc_mac_addr_set  [rc=%d] " % (rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, swid, VLAN2, group_addr, None, 0)
        print(("sx_api_fdb_mc_mac_addr_set  [rc=%d] " % (rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        print(("sx_api_fdb_uc_mac_addr_set  [rc=%d] " % (rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        remove_ports_from_vlan(VLAN2, {lag_peerlink: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(VLAN2, {lag_server: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(VLAN2, {PORT1: SX_TAGGED_MEMBER})
        add_delete_lag_ports(SX_ACCESS_CMD_DELETE, swid, lag2_p, port3_p, 1)
        add_delete_lag_ports(SX_ACCESS_CMD_DELETE, swid, lag1_p, port2_p, 1)
        destroy_lag(lag_peerlink)
        destroy_lag(lag_server)

        for port, ingr_filter in list(ports_ingr_filter_mode.items()):
            add_ports_to_vlan(1, {port: SX_UNTAGGED_MEMBER})
            ingr_filter_set(port, ingr_filter)

######################################################
#    main
######################################################


def main():
    example_make_redirect_lag()
    sx_api_close(handle)


if __name__ == "__main__":
    main()
