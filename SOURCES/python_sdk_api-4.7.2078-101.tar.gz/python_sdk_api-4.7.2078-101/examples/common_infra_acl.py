#!/usr/bin/env python
# -*- python -*-

import os
import sys
import ctypes
import struct
import socket
import logging
from python_sdk_api.sx_api import *


#######################################################################
# defines
SPECTRUM_SWID = 0
#######################################################################

#######################################################################
# function definitions
#######################################################################


def check_sdk_rc(rc):
    if rc != SX_STATUS_SUCCESS:
        print("bad sdk rc %d" % rc)
        sys.exit(1)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


""" ############################################################################################ """


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    check_sdk_rc(rc)
    # print "Added %s port to vlan %d, rc: %d" % (str(ports_dict.keys()), vlan_id, rc)


""" ############################################################################################ """


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    check_sdk_rc(rc)


def check_cmd(cmd, msg, valid_cmds):
    if cmd not in valid_cmds:
        print('--------------- Wrong cmd', msg, '------------------------------')
        sys.exit(1)
    if cmd == SX_ACCESS_CMD_CREATE:
        print('--------------- CREATE ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_ADD:
        print('--------------- ADD ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_DELETE:
        print('--------------- DELETE ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_DESTROY:
        print('--------------- DESTROY ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_ADD_PORTS:
        print('--------------- ADD PORTS ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_DELETE_PORTS:
        print('--------------- DELETE PORTS ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_BIND:
        print('--------------- BIND ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_UNBIND:
        print('--------------- UNBIND ', msg, '------------------------------')
    elif cmd == SX_ACCESS_CMD_L4_PORT_RANGE:
        print('--------------- L4_PORT_RANGE ', msg, '------------------------------')
    else:
        print('--------------- INVALID ', msg, '------------------------------')


def pbs_handle_port(handle, cmd, pbs_type, pbs_id_p, ports):
    check_cmd(cmd, 'PBS PORTS', [SX_ACCESS_CMD_DELETE_PORTS, SX_ACCESS_CMD_ADD_PORTS])
    pbs_entry = sx_acl_pbs_entry_t()
    pbs_entry.entry_type = pbs_type
    pbs_entry.port_num = len(ports)
    pbs_entry.log_ports = new_sx_port_log_id_t_arr(len(ports))
    for i, port in enumerate(ports):
        sx_port_log_id_t_arr_setitem(pbs_entry.log_ports, i, port)
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               cmd,
                                               SPECTRUM_SWID,
                                               pbs_entry,
                                               pbs_id_p)
    check_sdk_rc(rc)


def pbs_handle(handle, cmd, pbs_type, pbs_id_p, ports):
    check_cmd(cmd, 'PBS', [SX_ACCESS_CMD_ADD, SX_ACCESS_CMD_DELETE])
    pbs_entry = sx_acl_pbs_entry_t()
    pbs_entry.entry_type = pbs_type
    pbs_entry.port_num = len(ports)
    pbs_entry.log_ports = new_sx_port_log_id_t_arr(len(ports))
    for i, port in enumerate(ports):
        sx_port_log_id_t_arr_setitem(pbs_entry.log_ports, i, port)
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               cmd,
                                               SPECTRUM_SWID,
                                               pbs_entry,
                                               pbs_id_p)
    check_sdk_rc(rc)


def acl_key_create_delete(handle, cmd, key_handle_p, keys_list):
    check_cmd(cmd, 'KEY', [SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DELETE])
    keys = new_sx_acl_key_t_arr(len(keys_list))
    for i, key in enumerate(keys_list):
        sx_acl_key_t_arr_setitem(keys, i, key)
    rc = sx_api_acl_flex_key_set(handle,
                                 cmd,
                                 keys,
                                 len(keys_list),
                                 key_handle_p)
    check_sdk_rc(rc)


def acl_rules_init(rules, rules_list, rules_count, key_handle, actions_count):
    for i in range(0, rules_count):
        rule = new_sx_flex_acl_flex_rule_t_p()
        rc = sx_lib_flex_acl_rule_init(key_handle, actions_count, rule)
        check_sdk_rc(rc)
        rules.append(rule)
        sx_flex_acl_flex_rule_t_arr_setitem(rules_list, i, rule)


def acl_rules_deinit(rule_list):
    for rule in rule_list:
        rc = sx_lib_flex_acl_rule_deinit(rule)
        check_sdk_rc(rc)


def acl_region_handle(handle, cmd, key_handle, size, region_id_p):
    check_cmd(cmd, 'REGION', [SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DESTROY])
    rc = sx_api_acl_region_set(handle,
                               cmd,
                               key_handle,
                               0,
                               size,
                               region_id_p)
    check_sdk_rc(rc)


def acl_handle(handle, cmd, dir, acl_id_p, region_id):
    check_cmd(cmd, 'ACL', [SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DESTROY])
    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id
    rc = sx_api_acl_set(handle,
                        cmd,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        dir,
                        acl_region_group,
                        acl_id_p)
    check_sdk_rc(rc)


def acl_group_handle(handle, cmd, dir, group_id_p, acls):
    check_cmd(cmd, 'ACL GROUP', [SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DESTROY, SX_ACCESS_CMD_SET])
    acl_id_list = new_sx_acl_id_t_arr(len(acls))
    for i, acl_id in enumerate(acls):
        sx_acl_id_t_arr_setitem(acl_id_list, i, acl_id)
    if cmd == SX_ACCESS_CMD_DESTROY:
        rc = sx_api_acl_group_set(handle,
                                  SX_ACCESS_CMD_DESTROY,
                                  dir,
                                  acl_id_list,
                                  0,
                                  group_id_p)
        check_sdk_rc(rc)
        return

    if cmd == SX_ACCESS_CMD_CREATE:
        rc = sx_api_acl_group_set(handle,
                                  SX_ACCESS_CMD_CREATE,
                                  dir,
                                  acl_id_list,
                                  0,
                                  group_id_p)
        check_sdk_rc(rc)

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              dir,
                              acl_id_list,
                              len(acls),
                              group_id_p)
    check_sdk_rc(rc)


def port_bind(handle, cmd, port, group_id):
    check_cmd(cmd, 'ACL PORT', [SX_ACCESS_CMD_BIND, SX_ACCESS_CMD_UNBIND])
    rc = sx_api_acl_port_bind_set(handle,
                                  cmd,
                                  port,
                                  group_id)
    check_sdk_rc(rc)


class acl_port_bind():
    def __init__(self, handle, group_id, port):
        self.group_id = group_id
        self.port = port
        port_bind(handle, SX_ACCESS_CMD_BIND, port, group_id)
        self.bound = True
        self.handle = handle

    def __del__(self):
        self.unbind()

    def unbind(self):
        if self.bound:
            port_bind(self.handle, SX_ACCESS_CMD_UNBIND, self.port, self.group_id)
            self.bound = False


def rif_bind(handle, cmd, rif, group_id):
    check_cmd(cmd, 'ACL RIF', [SX_ACCESS_CMD_BIND, SX_ACCESS_CMD_UNBIND])
    rc = sx_api_acl_rif_bind_set(handle,
                                 cmd,
                                 rif,
                                 group_id)
    check_sdk_rc(rc)


def create_counter(handle, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    check_sdk_rc(rc)

    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    return counter_id


def check_count(num_of_packets, expected_value):
    if num_of_packets != expected_value:
        logging.info("FAil counter read")
        sys.exit(1)


def read_clear_flow_counter(handle, counter_id):
    " This function reads and clears a flow counter. "
    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    check_sdk_rc(rc)
    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)

    #rc = sx_api_flow_counter_clear_set(handle, counter_id)
    # check_sdk_rc(rc)

    print("counter id[%d]:packets:[%d]" % (counter_id, counter_set.flow_counter_packets))
    return counter_set.flow_counter_packets


def destroy_counter(handle, counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    check_sdk_rc(rc)

    return counter_id


def acl_rule_set(handle, region_id, rule, offset, key_list, action_list):
    " this function sets rule in acl region"
    rule.valid = 1
    for i, action in enumerate(action_list):
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, i, action)
    rule.action_count = len(action_list)
    print("region id[%d],offset:[%d] actions len[%d] key len[%d]" % (region_id, offset, len(action_list), len(key_list)))

    for i, key_desc in enumerate(key_list):
        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, i, key_desc)
    rule.key_desc_count = len(key_list)

    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)
    rules_list = new_sx_flex_acl_flex_rule_t_arr(1)
    sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rule)

    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rules_list,
                                   1)
    if rc != SX_STATUS_SUCCESS:
        logging.info("API sx_api_acl_flex_rules_set failed \n")
        sys.exit(1)


def acl_rule_delete(handle, region_id, offset):
    offsets_list = new_sx_acl_rule_offset_t_arr(1)

    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)
    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_DELETE,
                                   region_id,
                                   offsets_list,
                                   None,
                                   1)
    if rc != SX_STATUS_SUCCESS:
        logging.info("API sx_api_acl_flex_rules_set failed \n")
        sys.exit(1)


def add_goto_action(action_list, cmd, group_id):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_GOTO
    action.fields.action_goto.acl_group_id = group_id
    action.fields.action_goto.goto_action_cmd = cmd
    action_list.append(action)


def add_counter_action(action_list, counter_id):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_COUNTER
    action.fields.action_counter.counter_id = counter_id
    action_list.append(action)


def add_ttl_action(action_list, ttl_value):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_SET_TTL
    action.fields.action_set_ttl.ttl_val = ttl_value
    action_list.append(action)


def add_forward_action(action_list, fwd_cmd):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_FORWARD
    action.fields.action_forward.action = fwd_cmd
    action_list.append(action)


def add_alu_imm_action(action_list, command, imm_data, dst_register, dst_offset, size):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_ALU_IMM
    action.fields.action_alu_imm.command = command
    action.fields.action_alu_imm.imm_data = imm_data
    action.fields.action_alu_imm.dst_register = dst_register
    action.fields.action_alu_imm.dst_offset = dst_offset
    action.fields.action_alu_imm.size = size
    action_list.append(action)


def add_stateful_db_action(action_list, partition_id, stateful_key_id, order_op, sem_op, db_op, gp_reg_set, flow_dir):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_STATEFUL_DB
    action.fields.action_stateful_db.partition_id = partition_id
    action.fields.action_stateful_db.stateful_key_id = stateful_key_id
    action.fields.action_stateful_db.order_op = order_op
    action.fields.action_stateful_db.sem_op = sem_op
    action.fields.action_stateful_db.db_op = db_op
    action.fields.action_stateful_db.gp_reg_set = gp_reg_set
    action.fields.action_stateful_db.flow_dir = flow_dir
    action_list.append(action)


def add_alu_reg_action(action_list, command, dst_register, dst_offset, src_register, src_offset, size):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_ALU_REG
    action.fields.action_alu_reg.command = command
    action.fields.action_alu_reg.src_register = src_register
    action.fields.action_alu_reg.src_offset = src_offset
    action.fields.action_alu_reg.dst_register = dst_register
    action.fields.action_alu_reg.dst_offset = dst_offset
    action.fields.action_alu_reg.size = size
    action_list.append(action)


def add_set_emt_action(action_list, emt_bind_index, emt_bind_type, emt_id, emt_offset):
    action = sx_flex_acl_flex_action_t()
    action.type = SX_FLEX_ACL_ACTION_SET_EMT
    action.fields.action_set_emt.emt_bind_action.emt_bind_index = emt_bind_index
    action.fields.action_set_emt.emt_bind_action.emt_bind_type = emt_bind_type
    action.fields.action_set_emt.emt_bind_action.emt_bind_type_attr.emt_id.emt_id = emt_id
    action.fields.action_set_emt.emt_bind_action.emt_bind_type_attr.emt_offset = emt_offset
    action_list.append(action)


def add_is_ipv4_key(key_list, key, mask):
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_IS_IP_V4
    key_desc.key.is_ip_v4 = key
    key_desc.mask.is_ip_v4 = mask
    key_list.append(key_desc)


def add_ip_compare_key(key_list, key, mask):
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_IP_COMPARE
    key_desc.key.ip_compare = key
    key_desc.mask.ip_compare = mask
    key_list.append(key_desc)


def set_simple_key(key_desc_list, key_type, key, mask):
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = key_type
    if (key_type == FLEX_ACL_KEY_L4_DESTINATION_PORT):
        key_desc.key.l4_destination_port = 7777
        key_desc.mask.l4_destination_port = 0xFFFF
    elif (key_type == FLEX_ACL_KEY_L4_SOURCE_PORT):
        key_desc.key.l4_source_port = key
        key_desc.mask.l4_source_port = mask
    else:
        logging.info("RULE key desc set failed \n")
        sys.exit(1)

    key_desc_list.append(key_desc)


def add_dmac_key(key_list, key, mask):
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_DMAC
    key_desc.key.dmac = ether_addr(key)
    key_desc.mask.dmac = ether_addr(mask)
    key_list.append(key_desc)


def l4_port_range_handle(handle, cmd, port_dir, min_port, max_port, port_range_id_p):
    check_cmd(cmd, 'L4_PORT_RANGE', [SX_ACCESS_CMD_ADD, SX_ACCESS_CMD_DELETE])
    l4_port_range = sx_acl_port_range_entry_t()
    l4_port_range.port_range_min = min_port
    l4_port_range.port_range_max = max_port
    l4_port_range.port_range_direction = port_dir
    l4_port_range.port_range_ip_header = SX_ACL_PORT_RANGE_IP_HEADER_OUTER
    l4_port_range.port_range_ip_length = 0
    rc = sx_api_acl_l4_port_range_set(handle,
                                      cmd,
                                      l4_port_range,
                                      port_range_id_p)
    check_sdk_rc(rc)


def router_init(handle, ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_vlan_router_interfaces = 16
    router_resource.max_port_router_interfaces = 16
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 10000
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 11000
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))
