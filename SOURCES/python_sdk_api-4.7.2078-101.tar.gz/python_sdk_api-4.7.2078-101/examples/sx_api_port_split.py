#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration port split / uspilt flow.
'''

import sys
import errno
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    Defines
######################################################
SWID = 0
DEVICE_ID = 1

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'
file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

######################################################
#    Handle input params
######################################################


def help_cmd():
    print("\n")
    print((sys.argv))
    print("Bad parameters.")
    print("sx_api_port_split.py --old_ports <op> --new_ports <np> --new_label_ports <m> --new_lane_bmaps <bmap> --new_width <w> [--validate] [--rate <r>] [--force] [--module_support_disabled]")
    print("Supported width: 1 | 2 | 4 | 8,")
    print("Supported rate: 100M | 1G | 10G | 25G | 40G | 50G | 100G | 200G | 400G | auto")
    print("\n")
    print("Example 1 for split 2x (MSN2700-SPC1):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10002 --new_label_ports 17 17 --new_lane_bmaps 0x03 0x0C --new_width 2")
    print("Example 1 for unsplit, after split 2x (MSN2700-SPC1):" + sys.argv[0]
          + " --old_ports 0x10001 0x10002 --new_ports 0x10001 --new_label_ports 17 --new_lane_bmaps 0x0F --new_width 4")
    print("Example 2 for split 4x (MSN2700-SPC1):" + sys.argv[0]
          + " --old_ports 0x10011 --new_ports 0x10011 0x10012 0x10013 0x10014 --new_label_ports 25 25 25 25  --new_lane_bmaps 0x1 0x2 0x4 0x8 --new_width 1")
    print("Example 2 for unsplit, after split 4x (MSN2700-SPC1):" + sys.argv[0]
          + " --old_ports 0x10011 0x10012 0x10013 0x10014 --new_ports 0x10011 0x10013 --new_label_ports 25 26  --new_lane_bmaps 0xF 0xF --new_width 4")
    print("\n")
    print("Example 3 for split 2x (MSN3700-SPC2):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10003 --new_label_ports 17 17 --new_lane_bmaps 0x03 0x0C --new_width 2 --rate 50G")
    print("Example 3 for unsplit, after split 2x (MSN3700-SPC2):" + sys.argv[0]
          + " --old_ports 0x10001 0x10003 --new_ports 0x10001 --new_label_ports 17 --new_lane_bmaps 0x0F --new_width 4 -rate auto")
    print("Example 4 for split 4x (MSN3700-SPC2):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10002 0x10003 0x10004 --new_label_ports 17 17 17 17 --new_lane_bmaps 0x1 0x2 0x4 0x8 --new_width 1 --rate 25G")
    print("Example 4 for unsplit, after split 4x (MSN3700-SPC2):" + sys.argv[0]
          + " --old_ports 0x10001 0x10002 0x10003 0x10004 --new_ports 0x10001 --new_label_ports 17 --new_lane_bmaps 0x0F --new_width 4 --rate auto")
    print("\n")
    print("Example 5 for split 4x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10003 --new_label_ports 18 18 --new_lane_bmaps 0x0F 0xF0 --new_width 4 --rate 100G")
    print("Example 5 for unsplit, after split 4x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 0x10003 --new_ports 0x10001 --new_label_ports 18 --new_lane_bmaps 0xFF --new_width 8 --rate auto")

    print("Example 6 for split 2x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10002 0x10003 0x10004 --new_label_ports 18 18 18 18 --new_lane_bmaps 0x03 0x0C 0x30 0xC0 --new_width 2 --rate 50G")
    print("Example 6 for unsplit, after split 2x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 0x10002 0x10003 0x10004 --new_ports 0x10001 --new_label_ports 18 --new_lane_bmaps 0xFF --new_width 8 --rate auto")

    print("Example 7 for split 1x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 --new_ports 0x10001 0x10002 0x10003 0x10004 0x10005 0x10006 0x10007 0x10008 --new_label_ports 18 18 18 18 18 18 18 18 --new_lane_bmaps 0x01 0x02 0x04 0x08 0x10 0x20 0x40 0x80 --new_width 1 --rate 50G")
    print("Example 7 for unsplit, after split 1x (MSN4700-SPC3):" + sys.argv[0]
          + " --old_ports 0x10001 0x10002 0x10003 0x10004 0x10005 0x10006 0x10007 0x10008 --new_ports 0x10001 0x10005 --new_label_ports 18 17 --new_lane_bmaps 0xFF 0xFF --new_width 8 --rate auto")

    print("\n")
    print("IMPORTANT: the examples are for MSN2700-SPC1 / MSN3700-SPC2 / MSN4700-SPC3. For other systems and other ports please check module numbers.")
    print("IMPORTANT: Note the difference for split_2x in SPC2 - new port after the split is port+2, not port+1 as in SPC1")
    print("IMPORTANT: rate option is not supported by SPC-1 systems")
    sys.exit(0)


if len(sys.argv) < 8:
    help_cmd()


parser = argparse.ArgumentParser(description='Port Split utility')
parser.add_argument('--old_ports', type=auto_int, nargs='+', help='Old logical ports - before split/unsplit')
parser.add_argument('--new_ports', type=auto_int, nargs='+', help='New logical ports - after split/unsplit')
parser.add_argument('--new_label_ports', type=auto_int, nargs='+', help='label_ports per new port')
parser.add_argument('--new_lane_bmaps', type=auto_int, nargs='+', help='Lane bitmask per new port')
parser.add_argument('--new_width', default=1, type=int, help='Number of lanes for new ports')
parser.add_argument('--rate', default=['auto'], type=str, nargs='+', help='New port rate value')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--module_support_disabled', action='store_true', help='Module support disabled in SDK.')
parser.add_argument('--validate', '-v', action='store_true', help='Validate the the port combination and width supported')
args = parser.parse_args()

print_api_example_disclaimer()
print("This example is only applicable for non modular system.")
if not args.force:
    print_modification_warning()

valid_rates = {"100M", "1G", "10G", "25G", "40G", "50G", "100G", "200G", "400G", "auto"}
admin_rate = args.rate[0].split(",")
for rate in admin_rate:
    if rate not in valid_rates:
        print(("Specified %s rate value is not valid." % (rate)))
        help_cmd()
        sys.exit(1)

for i, port in enumerate(args.old_ports):
    print(("Old ports[%d]: 0x%x" % (i, port)))

for i, port in enumerate(args.new_ports):
    print(("New ports[%d]: 0x%x" % (i, port)))

for i, module in enumerate(args.new_label_ports):
    print(("New label_ports[%d]: %d" % (i, module)))

for i, lane_bmap in enumerate(args.new_lane_bmaps):
    print(("New lane_bmaps[%d]: 0x%x" % (i, lane_bmap)))

print("New width:" + str(args.new_width))
print("validate split:" + str(args.validate))

######################################################
#    Local functions
######################################################


def get_device_id_and_rev():
    mgir = ku_mgir_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = SWID
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert 0 == rc

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def get_chip_type():
    print("Retrieving Chip Type from SDK")
    device_id, _ = get_device_id_and_rev()

    if device_id == 0xCB84:
        print("Running over SPECTRUM chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM
    elif device_id == 0xCF6C:
        print("Running over SPECTRUM2 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM2
    elif device_id == 0xCF70:
        print("Running over SPECTRUM3 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM3
    elif device_id == 0xCF80:
        print("Running over SPECTRUM4 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM4
    elif device_id == 0xCF82:
        print("Running over SPECTRUM5 chip")
        _chip_type = SX_CHIP_TYPE_SPECTRUM5
    else:
        print("--ERROR-- chip type is not supported!")
        sys.exit(errno.EACCES)

    return _chip_type


def port_state_set(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to change port state."


def port_init_handle(handle, port, is_init=True):
    if is_init:
        rc = sx_api_port_init_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to init port"
    else:
        rc = sx_api_port_deinit_set(handle, port)
        assert rc == SX_STATUS_SUCCESS, "Failed to de-init port"


# de-init and init port to reset port speed API type flag
def reset_port_type_api_flag(handle, ports_lst):
    for port in ports_lst:
        swid = port_swid_bind_get(handle, port)
        if swid != SWID:
            continue
        port_init_handle(handle, port, is_init=False)
        port_init_handle(handle, port, is_init=True)


def port_swid_bind_set(handle, port, swid):
    rc = sx_api_port_swid_bind_set(handle, port, swid)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."


def port_swid_bind_get(handle, port):
    sx_swid_p = new_sx_swid_t_p()
    rc = sx_api_port_swid_bind_get(handle, port, sx_swid_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."
    swid = sx_swid_t_p_value(sx_swid_p)
    return swid


def port_unmapping_set(handle, port, log_port_cnt=1):
    log_port_list_arr = new_sx_port_log_id_t_arr(log_port_cnt)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(log_port_cnt)
    mapping_item = new_sx_port_mapping_t_arr(1)
    module_id, _, _ = ports_mapping_attr_get(handle, port)

    for i in range(0, log_port_cnt):
        mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, i)
        mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
        mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE
        mapping_item.module_port = module_id
        mapping_item.slot = 0
        mapping_item.width = 0
        mapping_item.lane_bmap = 0

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, log_port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable mapping."


def port_mapping_attr_set(handle, port, module, lane_bmap):
    print(("port_mapping_attr_set: port:0x%x module:%d lane_bmap:0x%x" % (port, module, lane_bmap)))
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(1)
    mapping_item = new_sx_port_mapping_t_arr(1)

    mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, 0)
    mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
    mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE
    mapping_item.width = args.new_width
    mapping_item.module_port = module - 1
    mapping_item.slot = 0
    mapping_item.lane_bmap = lane_bmap

    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, 1)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure port mapping."


def ports_mapping_attr_get(handle, port):
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    port_mapping_list_arr = new_sx_port_mapping_t_arr(1)
    port_cnt = 1

    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)
    rc = sx_api_port_mapping_get(handle, log_port_list_arr, port_mapping_list_arr, port_cnt)
    assert rc == SX_STATUS_SUCCESS, "Failed to get port mapping attributes."

    port_mapping_att = sx_port_mapping_t_arr_getitem(port_mapping_list_arr, 0)
    return port_mapping_att.module_port, port_mapping_att.width, port_mapping_att.lane_bmap


def rstp_port_state_set(handle, log_port, mstp_state):
    rc = sx_api_rstp_port_state_set(handle, log_port, mstp_state)
    assert rc == SX_STATUS_SUCCESS, "Failed to configure RSTP port state."


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SWID, vlan_id, port_list, len(ports_dict))
    assert rc == SX_STATUS_SUCCESS, "Failed to add port into the VLAN."


def port_admin_speed_10G_set(handle, port):
    print(("Setting port rate for port 0x%x\n" % (port)))
    admin_speed_p = new_sx_port_speed_capability_t_p()
    admin_speed_p.mode_10GB_CR = 1
    admin_speed_p.mode_10GB_CX = 1
    admin_speed_p.mode_10GB_SR = 1
    admin_speed_p.mode_10GB_KR = 1
    admin_speed_p.mode_10GB_ER_LR = 1
    admin_speed_p.mode_auto = 0
    admin_speed_p.force = 0

    rc = sx_api_port_speed_admin_set(handle, port, admin_speed_p)
    assert SX_STATUS_SUCCESS == rc
    print(("[+] 10G speed is configured for log_port: 0x%x." % (port)))


def enable_rate(rate, admin_rate):
    return (True if (rate in admin_rate) else False)


def port_rate_configuration(handle, port, admin_rate):
    # Went through the admin_rate list and enable appropriate values
    rate_bitmask_p = new_sx_port_rate_bitmask_t_p()
    rate_bitmask_p.rate_100M = enable_rate("100M", admin_rate)
    rate_bitmask_p.rate_1G = enable_rate("1G", admin_rate)
    rate_bitmask_p.rate_10G = enable_rate("10G", admin_rate)
    rate_bitmask_p.rate_25G = enable_rate("25G", admin_rate)
    rate_bitmask_p.rate_40G = enable_rate("40G", admin_rate)
    rate_bitmask_p.rate_50G = enable_rate("50G", admin_rate)
    rate_bitmask_p.rate_100G = enable_rate("100G", admin_rate)
    rate_bitmask_p.rate_200G = enable_rate("200G", admin_rate)
    rate_bitmask_p.rate_400G = enable_rate("400G", admin_rate)
    rate_bitmask_p.rate_800G = enable_rate("800G", admin_rate)
    rate_bitmask_p.rate_auto = enable_rate("auto", admin_rate)
    rate_bitmask_p.force = False  # Note that this option may be enabled only for single rate value

    if not args.module_support_disabled:
        # Set all module types
        phy_type_p = new_sx_port_phy_module_type_bitmask_t_p()
        phy_type_p.module_smf_up_500m = True
        phy_type_p.module_smf_up_2km = True
        phy_type_p.module_smf_above_2km = True
        phy_type_p.module_mmf_up_100m = True
        phy_type_p.module_mmf_above_100m = True
        phy_type_p.module_aoc_acc_up_30m = True
        phy_type_p.module_aoc_acc_above_30m = True
        phy_type_p.module_base_cr = True
        phy_type_p.module_base_tp = True

        module_id, _, _ = ports_mapping_attr_get(handle, port)
        module_id_info = sx_mgmt_module_id_info_t()
        module_id_info.slot_id = 0
        module_id_info.module_id = module_id
        module_id_info_p = new_sx_mgmt_module_id_info_t_p()
        sx_mgmt_module_id_info_t_p_assign(module_id_info_p, module_id_info)
        rc = sx_mgmt_phy_module_admin_type_set(handle, module_id_info_p, phy_type_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to set port phy type."

    rc = sx_api_port_rate_set(handle, port, rate_bitmask_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to set port admin rate."

    print(("[+] Rate and PMD type is configured for log_port: 0x%x." % (port)))


def split_unsplit_validate_and_compare(handle, new_ports_list, module_id, new_lane_bmaps, chip_type):
    module_id = module_id - 1  # script get label port as input
    split_num = len(new_ports_list)
    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = 0
    module_info.module_id = module_id
    split_params = sx_mgmt_phy_module_split_params_t()
    split_params.split_num = split_num
    split_params.port_width = args.new_width

    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
    module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
    split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)
    error = 0
    attr_new_ports = set()
    user_new_ports_attr_dict = {}

    for i in range(split_num):
        user_new_ports_attr_dict[new_ports_list[i]] = [module_id, new_lane_bmaps[i], args.new_width]

    slot_id, max_lanes, port_width = get_chip_port_info(chip_type)
    if (split_num * args.new_width) > max_lanes:
        print("Validation error \nNumber of splits and width of each port cannot take more than %d lanes" % (max_lanes))
        exit(0)

    try:
        rc = sx_mgmt_phy_module_split_get(handle, module_info_p, split_params_p, split_info_p)
        assert SX_STATUS_SUCCESS == rc, "mgmt_phy_mod_split_info_query failed."
        split_info = sx_mgmt_phy_module_split_info_t_p_value(split_info_p)
        if split_info.list_len > 0:
            if split_info.list_len != split_num:
                print("Validation error \nNumber of sub ports is not equal to expected split length %d" % split_info.list_len)
                exit(0)
            for i in range(split_info.list_len):
                attr = sx_port_attributes_t_arr_getitem(split_info_p.port_attribs_list, i)
                attr_new_ports.add(attr.log_port)
            for i in range(split_num):
                if new_ports_list[i] not in attr_new_ports:
                    print("Validation error \nPort %s is not present in the expected ports for label_port %d " % (hex(new_ports_list[i]), (module_id + 1)))
                    error = 1
            if not error:
                for i in range(split_info.list_len):
                    attr = sx_port_attributes_t_arr_getitem(split_info_p.port_attribs_list, i)
                    port_input_attr_list = user_new_ports_attr_dict[attr.log_port]
                    if attr.port_mapping.module_port != port_input_attr_list[0]:
                        print("Validation error \nNew port %s should have label port %d but label port %d is provided." % (hex(new_ports_list[i]), (attr.port_mapping.module_port + 1), (port_input_attr_list[0] + 1)))
                        error = 1
                    if attr.port_mapping.lane_bmap != port_input_attr_list[1]:
                        print("Validation error \nNew port %s should have lane %4s but lane %4s is provided. " % (hex(new_ports_list[i]), hex(attr.port_mapping.lane_bmap), hex(port_input_attr_list[1])))
                        error = 1
                    if attr.port_mapping.width != port_input_attr_list[2]:
                        print("Validation error \nNew port %s should have width %d but width %d is provided. " % (hex(new_ports_list[i]), hex(attr.port_mapping.width), port_input_attr_list[2]))
                        error = 1

        if split_info.list_len == 0:
            print("Split/unsplit is not possible, number of ports exceed the module width or ports combination is not allowed.\n")
            exit(0)

        if split_info.list_len > 0 and error == 1:
            print("\nGiven label port: %d \n" % (module_id + 1))
            for i in range(split_info.list_len):
                attr = sx_port_attributes_t_arr_getitem(split_info_p.port_attribs_list, i)
                print("log_port:%s | local_port:%d | slot:%d | module:%d | lane:%4s | width:%d" % (hex(attr.log_port),
                                                                                                   attr.port_mapping.local_port, attr.port_mapping.slot, attr.port_mapping.module_port,
                                                                                                   hex(attr.port_mapping.lane_bmap), attr.port_mapping.width))
            exit(0)

    finally:
        delete_sx_mgmt_module_id_info_t_p(module_info_p)
        delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
        delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)


def get_chip_port_info(chip_type):
    port_width = 1
    slot_id = 0
    if chip_type == SX_CHIP_TYPE_SPECTRUM2 or chip_type == SX_CHIP_TYPE_SPECTRUM:
        num_splits = 4
    else:
        num_splits = 8

    return slot_id, num_splits, port_width


def get_possible_module_ports(handle, module_id, chip_type, split_len):

    slot_id, num_splits, port_width = get_chip_port_info(chip_type)
    possible_ports_for_module = set()
    continue_check_splits = True

    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = 0
    module_info.module_id = module_id

    split_params = sx_mgmt_phy_module_split_params_t()
    split_params.split_num = num_splits
    split_params.port_width = port_width

    module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
    split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)

    try:
        while continue_check_splits:
            rc = sx_mgmt_phy_module_split_get(handle, module_info_p, split_params_p, split_info_p)
            assert SX_STATUS_SUCCESS == rc, "mgmt_phy_mod_split_info_query failed."
            split_info = sx_mgmt_phy_module_split_info_t_p_value(split_info_p)
            if split_info.list_len > 0:
                continue_check_splits = False
                for i in range(split_info.list_len):
                    attr = sx_port_attributes_t_arr_getitem(split_info_p.port_attribs_list, i)
                    possible_ports_for_module.add(attr.log_port)
            else:
                num_splits = int(num_splits / 2)
                if num_splits == 1:
                    continue_check_splits = False
                else:
                    delete_sx_mgmt_module_id_info_t_p(module_info_p)
                    delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
                    delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)
                    split_params.split_num = num_splits
                    split_params.port_width = port_width
                    module_info_p = copy_sx_mgmt_module_id_info_t_p(module_info)
                    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()
                    split_params_p = copy_sx_mgmt_phy_module_split_params_t_p(split_params)

    finally:
        delete_sx_mgmt_module_id_info_t_p(module_info_p)
        delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
        delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)

    return possible_ports_for_module


def validate_split_unsplit(handle, new_ports_list, chip_type):

    # validate old ports
    user_label_ports = set()
    new_possible_ports = set()
    all_possible_ports = set()

    for module in args.new_label_ports:
        if module not in user_label_ports:
            val_module = module - 1
            user_label_ports.add(val_module)
            new_possible_ports = get_possible_module_ports(handle, val_module, chip_type, len(args.old_ports))
            all_possible_ports = all_possible_ports | new_possible_ports
    for old_port in args.old_ports:
        if old_port not in all_possible_ports:
            label_ports_str = ', '.join(list(map(str, user_label_ports)))
            all_possible_ports_list = list(all_possible_ports)
            possible_ports_str = ', '.join(list(map(hex, all_possible_ports_list)))
            print("Validation error \nPort 0x%x is not mapped to input module %s, possible ports are %s" % (old_port, label_ports_str, possible_ports_str))
            exit(0)

    # Validate the new split/unsplit ports attributes
    sub_split_index = 0
    if len(args.new_label_ports) > 1:
        for i in range(1, len(args.new_label_ports)):
            if args.new_label_ports[i] != args.new_label_ports[i - 1]:
                sub_split_index = i
    if sub_split_index > 0:
        left_module_id = args.new_label_ports[sub_split_index - 1]
        right_module_id = args.new_label_ports[sub_split_index]
        left_port_list = new_ports_list[:sub_split_index]
        right_port_list = new_ports_list[sub_split_index:]
        left_new_lane_bmaps = args.new_lane_bmaps[:sub_split_index]
        right_new_lane_bmaps = args.new_lane_bmaps[sub_split_index:]

    else:
        left_port_list = new_ports_list
        left_module_id = args.new_label_ports[0]
        left_new_lane_bmaps = args.new_lane_bmaps

    split_unsplit_validate_and_compare(handle, left_port_list, left_module_id, left_new_lane_bmaps, chip_type)
    if sub_split_index > 0:
        split_unsplit_validate_and_compare(handle, right_port_list, right_module_id, right_new_lane_bmaps, chip_type)

    print("\nAll inputs parameters are validated successfully")


def split_unsplit_ports(handle, chip_type, old_ports_list, new_ports_list):
    un_bind_swid = 255

    for port in old_ports_list:
        swid = port_swid_bind_get(handle, port)
        print(("Old port:0x%x swid:%d" % (port, swid)))
        if swid != SWID:
            continue

        # ports must be in DOWN state
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
        # de-init ports
        port_init_handle(handle, port, is_init=False)
        # un-bind ports
        port_swid_bind_set(handle, port, un_bind_swid)
        # disable mapping
        port_unmapping_set(handle, port)

    for port in new_ports_list:
        swid = port_swid_bind_get(handle, port)
        print(("New port:0x%x swid:%d" % (port, swid)))
        if swid != SWID:
            continue

        # ports must be in DOWN state
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
        # de-init ports
        port_init_handle(handle, port, is_init=False)
        # un-bind ports
        port_swid_bind_set(handle, port, un_bind_swid)
        # disable mapping
        port_unmapping_set(handle, port)

    # Change port mapping
    for i, (port, module, lane_bmap) in enumerate(zip(new_ports_list, args.new_label_ports, args.new_lane_bmaps)):
        port_mapping_attr_set(handle, port, module, lane_bmap)

    # bind ports
    for port in new_ports_list:
        swid = SWID
        port_swid_bind_set(handle, port, swid)

    # init ports
    for port in new_ports_list:
        port_init_handle(handle, port, is_init=True)

    # init ports
    if chip_type == SX_CHIP_TYPE_SPECTRUM:
        for port in new_ports_list:
            # set port speed - use legacy APIs, 10G
            port_admin_speed_10G_set(handle, port)
    else:
        for port in new_ports_list:
            # set port speed - use new APIs, default 1G
            port_rate_configuration(handle, port, admin_rate)

    # configure RSTP forwarding state
    for port in new_ports_list:
        rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)

    # add configured ports into the specified below VLAN
    for port in new_ports_list:
        vlan = 1
        add_ports_to_vlan(handle, vlan, {port: SX_UNTAGGED_MEMBER})

    # bring port into the UP state
    for port in new_ports_list:
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def ports_mapping_info(handle, ports_list):
    for port in ports_list:
        module_port, width, lane_bmap = ports_mapping_attr_get(handle, port)
        print(("log_port:0x%x width: %d lane_bmap: 0x%x module_port: %d" % (port, width, lane_bmap, module_port)))

######################################################
#    Port split example
######################################################


def port_split_example():
    new_ports = args.new_ports
    old_ports = args.old_ports

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    _chip_type = get_chip_type()

    # Reset port speed API type flag
    reset_port_type_api_flag(handle, new_ports)

    # Print current port mapping attributes
    ports_mapping_info(handle, old_ports)

    # Validate args
    if args.validate:
        validate_split_unsplit(handle, new_ports, _chip_type)
    else:
        # Split or unsplit
        split_unsplit_ports(handle, _chip_type, old_ports, new_ports)

        # Print new port mapping attributes
        ports_mapping_info(handle, new_ports)

        print("Success.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    port_split_example()
