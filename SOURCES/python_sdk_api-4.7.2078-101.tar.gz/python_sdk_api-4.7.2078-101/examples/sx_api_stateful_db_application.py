#!/usr/bin/env python
"""
This file contains Python command example for an application using stateful DB module.
The example create an ACL rule which count the number of packet on a flow connection.
This example is supported on Spectrum4 and later devices.
"""

import os
import sys
from python_sdk_api.sx_api import *
import test_infra_common
import common_infra_acl
import argparse


def parse_args():
    description_str = """
    This file contains Python command example for an application using stateful DB module.
    The example create an ACL rule which count the number of packet on a flow connection.
    This example is supported on Spectrum4 and later devices.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--max_sem_retries", type=int, default=255, help="Maximum number of semaphore retries, range is [1-255]. Default is [%(default)d]")
    parser.add_argument("--partition_id", type=int, default=1, help="Partition ID to use, range is [0-7]. Default is [%(default)d]")
    parser.add_argument("--partition_size", type=int, default=1000, help="Partition size. Default is [%(default)d]")
    parser.add_argument("--partition_warn_threshold", type=int, default=800, help="Partition warning threshold. Default is [%(default)d]")
    parser.add_argument("--log_port", type=test_infra_common.auto_int, help="Log port to use (hex/int format), if not provided example will query one port")
    return parser.parse_args()


def stateful_db_init(handle, args):
    init_param_p = new_sx_stateful_db_init_param_t_p()
    init_param_p.stateful_db_attr.entry_not_found_sem_unlock_failure = False
    init_param_p.stateful_db_attr.max_sem_retries = args.max_sem_retries
    init_param_p.stateful_db_attr.force_ordering_enable = False

    rc = sx_api_stateful_db_init_set(handle, init_param_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to init stateful DB module")
        sys.exit(rc)

    delete_sx_stateful_db_init_param_t_p(init_param_p)


def stateful_db_deinit(handle):
    rc = sx_api_stateful_db_deinit_set(handle)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to de-init stateful DB module")
        sys.exit(rc)


def partition_create(handle, args, key_size):
    partition_cfg_p = new_sx_stateful_db_partition_cfg_t_p()
    partition_cfg_p.max_size = args.partition_size * key_size
    partition_cfg_p.warn_size = args.partition_warn_threshold * key_size
    partition_cfg_p.name = "Application example partition"
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_CREATE, args.partition_id, partition_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to create partition %d" % (args.partition_id))
        sys.exit(rc)

    delete_sx_stateful_db_partition_cfg_t_p(partition_cfg_p)


def partition_destroy(handle, args):
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_DESTROY, args.partition_id, None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to destroy partition %d" % (args.partition_id))
        sys.exit(rc)


def key_create(handle):
    key_p = new_sx_stateful_db_key_t_p()

    key_p.key_name = "4 tuple symmetric key"
    key_p.key_desc.acl_key_desc.is_symmetric = True
    key_p.key_desc.acl_key_desc.acl_key_cnt = 4

    acl_key = sx_stateful_db_acl_key_t()
    acl_key.key_id = FLEX_ACL_KEY_SIP
    acl_key.mask.sip = test_infra_common.make_sx_ip_addr("255.255.255.255")
    sx_stateful_db_acl_key_t_arr_setitem(key_p.key_desc.acl_key_desc.acl_key_list_p, 0, acl_key)
    acl_key.key_id = FLEX_ACL_KEY_DIP
    acl_key.mask.dip = test_infra_common.make_sx_ip_addr("255.255.255.255")
    sx_stateful_db_acl_key_t_arr_setitem(key_p.key_desc.acl_key_desc.acl_key_list_p, 1, acl_key)
    acl_key.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    acl_key.mask.l4_destination_port = 0xffff
    sx_stateful_db_acl_key_t_arr_setitem(key_p.key_desc.acl_key_desc.acl_key_list_p, 2, acl_key)
    acl_key.key_id = FLEX_ACL_KEY_L4_SOURCE_PORT
    acl_key.mask.l4_source_port = 0xffff
    sx_stateful_db_acl_key_t_arr_setitem(key_p.key_desc.acl_key_desc.acl_key_list_p, 3, acl_key)

    key_id_p = new_sx_stateful_db_key_id_t_p()
    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_CREATE, key_p, key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_set create failed.")
        sys.exit(rc)

    key_size = key_p.key_size
    key_id = sx_stateful_db_key_id_t_p_value(key_id_p)

    delete_sx_stateful_db_key_id_t_p(key_id_p)
    delete_sx_stateful_db_key_t_p(key_p)
    return key_id, key_size


def key_destroy(handle, key_id):
    key_id_p = new_sx_stateful_db_key_id_t_p()
    sx_stateful_db_key_id_t_p_assign(key_id_p, key_id)
    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_DESTROY, None, key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to destroy key %d" % (key_id))
        sys.exit(rc)
    delete_sx_stateful_db_key_id_t_p(key_id_p)


def gp_register_set(handle, cmd):
    # Create GP register 0-4: 0-3 for GP register set, 4 for ALU add carry action.
    reg_cnt = 5
    reg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(reg_cnt_p, reg_cnt)
    key = sx_register_key_t()
    key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    reg_list_p = new_sx_register_key_t_arr(reg_cnt)
    for i in range(reg_cnt):
        key.key.gp_reg.reg_id = i
        sx_register_key_t_arr_setitem(reg_list_p, i, key)
    rc = sx_api_register_set(handle, cmd, reg_list_p, reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to set GP register list")
        sys.exit(rc)
    delete_uint32_t_p(reg_cnt_p)
    delete_sx_register_key_t_p(reg_list_p)


def acl_application_create(handle, args, stateful_key_id):
    # Create key handle
    acl_key_ids_arr = [FLEX_ACL_KEY_IS_IP_V4, FLEX_ACL_KEY_IP_COMPARE]
    acl_key_ids_cnt = len(acl_key_ids_arr)
    key_handle_p = new_sx_acl_key_type_t_p()
    common_infra_acl.acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, acl_key_ids_arr)
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)

    # Create region
    region_id_p = new_sx_acl_region_id_t_p()
    common_infra_acl.acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 32, region_id_p)
    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print(("Created ACL region with region_id %d" % region_id))

    # Create ACL
    direction = SX_ACL_DIRECTION_INGRESS
    acl_id_p = new_sx_acl_id_t_p()
    common_infra_acl.acl_handle(handle, SX_ACCESS_CMD_CREATE, direction, acl_id_p, region_id)
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print(("Created ACL with ACL ID %d" % acl_id))

    # Create ACL group
    group_id_p = new_sx_acl_id_t_p()
    common_infra_acl.acl_group_handle(handle, SX_ACCESS_CMD_CREATE, direction, group_id_p, [acl_id])
    group_id = sx_acl_id_t_p_value(group_id_p)
    print(("Created ACL Group with ID %d" % group_id))

    # Bind group to port
    common_infra_acl.port_bind(handle, SX_ACCESS_CMD_BIND, args.log_port, group_id)

    # Init rules array
    rules_list = new_sx_flex_acl_flex_rule_t_arr(1)
    rules = []
    common_infra_acl.acl_rules_init(rules, rules_list, 1, key_handle, 20)

    # Set 2 ACL rules: upstream and downstream
    # Create ACL Downstream rule
    # Set ACL key: IPv4 downstream packets
    key_desc_list = []
    common_infra_acl.add_is_ipv4_key(key_desc_list, True, True)
    common_infra_acl.add_ip_compare_key(key_desc_list, SX_ACL_IP_COMPARE_FLOW_DIR_DOWNSTREAM_E, True)

    # Set ACL action list:
    action_list = []
    # Read into GP register set 0 [GP reg 0-3] and do semaphore lock on stateful DB
    #   using input partition and the generated 4-tuple stateful key.
    # For stateful symmetric key: flow direction matches ACL key direction - both DOWNSTREAM.
    # If entry not found, read and semaphore lock operations creates new stateful DB entry with value 0.
    common_infra_acl.add_stateful_db_action(action_list, args.partition_id, stateful_key_id,
                                            SX_STATEFUL_DB_ORDER_NOP_E, SX_STATEFUL_DB_SEM_LOCK_E,
                                            SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_GP_REGISTER_SET_0_E,
                                            SX_STATEFUL_DB_FLOW_DIR_DOWNSTREAM_E)
    # In order to count number of packets in a connection: add 1 to the read value using ALU add immediate.
    common_infra_acl.add_alu_imm_action(action_list, SX_ACL_ACTION_ALU_IMM_COMMAND_ADD, 1, SX_GP_REGISTER_0_E, 0, 16)
    # Stateful DB operates on GP register SET (64 bits). But, ACL ALU operation operates on single GP register (16 bits).
    # To increase the counter by 1, add 1 to the most significant GP register (GP register 0),
    #   and add the carry bit to the next GP register using ACL ALU add carry register operation.
    # Add carry bit operation uses source GP register 4, which assumed to be 0.
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_1_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_2_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_3_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    # Write the new counter value to stateful DB and unlock the semaphore, using same partition and stateful key.
    # For stateful symmetric key: flow direction matches ACL key direction - both DOWNSTREAM.
    common_infra_acl.add_stateful_db_action(action_list, args.partition_id, stateful_key_id,
                                            SX_STATEFUL_DB_ORDER_NOP_E, SX_STATEFUL_DB_SEM_UNLOCK_E,
                                            SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_GP_REGISTER_SET_0_E,
                                            SX_STATEFUL_DB_FLOW_DIR_DOWNSTREAM_E)

    # Set ACL Downstream rule - offset 0
    common_infra_acl.acl_rule_set(handle, region_id, rules[0], 0, key_desc_list, action_list)

    # Create ACL Upstream rule
    # Set ACL key: IPv4 upstream packets
    key_desc_list = []
    common_infra_acl.add_is_ipv4_key(key_desc_list, True, True)
    common_infra_acl.add_ip_compare_key(key_desc_list, SX_ACL_IP_COMPARE_FLOW_DIR_UPSTREAM_E, True)

    # Set ACL action list:
    action_list = []
    # Read from stateful DB, use semaphore lock to create new entry with value 0 if entry not found.
    # For stateful symmetric key: flow direction matches ACL key direction - both UPSTREAM.
    common_infra_acl.add_stateful_db_action(action_list, args.partition_id, stateful_key_id,
                                            SX_STATEFUL_DB_ORDER_NOP_E, SX_STATEFUL_DB_SEM_LOCK_E,
                                            SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_GP_REGISTER_SET_0_E,
                                            SX_STATEFUL_DB_FLOW_DIR_UPSTREAM_E)
    # Add 1 to most significant GP register
    common_infra_acl.add_alu_imm_action(action_list, SX_ACL_ACTION_ALU_IMM_COMMAND_ADD, 1, SX_GP_REGISTER_0_E, 0, 16)
    # Add carry bit operation to next GP register, using source GP register 4, which assume to be 0.
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_1_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_2_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    common_infra_acl.add_alu_reg_action(action_list, SX_ACL_ACTION_ALU_REG_COMMAND_ADDC, SX_GP_REGISTER_3_E, 0, SX_GP_REGISTER_4_E, 0, 16)
    # Write the new counter value to stateful DB and unlock the semaphore.
    # For stateful symmetric key: flow direction matches ACL key direction - both UPSTREAM.
    common_infra_acl.add_stateful_db_action(action_list, args.partition_id, stateful_key_id,
                                            SX_STATEFUL_DB_ORDER_NOP_E, SX_STATEFUL_DB_SEM_UNLOCK_E,
                                            SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_GP_REGISTER_SET_0_E,
                                            SX_STATEFUL_DB_FLOW_DIR_UPSTREAM_E)

    # Set ACL Upstream rule - offset 1
    common_infra_acl.acl_rule_set(handle, region_id, rules[0], 1, key_desc_list, action_list)

    # Deinit rules array
    common_infra_acl.acl_rules_deinit(rules)

    # Deinit configuration if user provided flag
    if args.deinit:
        print("Destroy ACL application")
        # Delete rules
        common_infra_acl.acl_rule_delete(handle, region_id, 1)
        common_infra_acl.acl_rule_delete(handle, region_id, 0)
        # Unbind port from group
        common_infra_acl.port_bind(handle, SX_ACCESS_CMD_UNBIND, args.log_port, group_id)
        # Destory ACL group
        common_infra_acl.acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, direction, group_id_p, [acl_id])
        # Destroy ACL
        common_infra_acl.acl_handle(handle, SX_ACCESS_CMD_DESTROY, direction, acl_id_p, region_id)
        # Destroy region
        common_infra_acl.acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 32, region_id_p)
        # Destory key handle
        common_infra_acl.acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p, acl_key_ids_arr)


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    # Open Handle
    print("[+] opening SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("This example doesn't support below Spectrum4 - Exiting gracefully")
            sys.exit(0)

        if args.log_port is None:
            args.log_port = test_infra_common.mapPortAndInterfaces(handle, print_ports=False)[0]
            print("Log port not provided: will use 0x{:x} in this example".format(args.log_port))

        print("Init stateful DB module")
        stateful_db_init(handle, args)

        print("Create stateful DB key")
        key_id, key_size = key_create(handle)
        print("Stateful DB key created! key_id {} key_size {}".format(key_id, key_size))

        print("Create stateful DB partition")
        partition_create(handle, args, key_size)

        print("Create GP register set")
        gp_register_set(handle, SX_ACCESS_CMD_CREATE)

        print("Create ACL rule")
        acl_application_create(handle, args, key_id)

        # Deinit configuration if user provided flag
        if args.deinit:
            print("Destroy GP register set")
            gp_register_set(handle, SX_ACCESS_CMD_DESTROY)

            print("Destory stateful DB partition")
            partition_destroy(handle, args)

            print("Destory stateful DB Key")
            key_destroy(handle, key_id)

            print("Deinit stateful DB module")
            stateful_db_deinit(handle)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
