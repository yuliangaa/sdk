#!/usr/bin/env python
'''
This example demonstrates LLDP trap registration
'''

import sys
import os
import time
import socket
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import python_sdk_api.sx_api as sx_api
import python_sdk_api.sxd_api as sxd_api  # For WA
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_register_lldp example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

SWID = 0

rc, handle = sx_api_open(None)
assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc: %d" % (rc)

# Create trap group
TRAP_GROUP = 1
trap_grp_attr = sx_trap_group_attributes_t()
trap_grp_attr.control_type = SX_CONTROL_TYPE_DEFAULT
trap_grp_attr.prio = 1
trap_grp_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_grp_attr.truncate_size = 0
trap_grp_attr.trap_group = TRAP_GROUP
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SWID, TRAP_GROUP, trap_grp_attr)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_group_ext_set failed, rc: %d" % (rc)
TRAP_GROUP = sx_trap_group_attributes_t_p_value(trap_grp_attr).trap_group

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_ETH_L2_LLDP
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = TRAP_GROUP
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

# Map trap ID SX_TRAP_ID_ETH_L2_LLDP to trap group 1, set the trap action to SX_TRAP_ACTION_TRAP_2_CPU
rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set failed, rc: %d" % (rc)

# Register the trap ID SX_TRAP_ID_ETH_L2_LLDP with a user channel with type SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV
uc_p = new_sx_user_channel_t_p()
uc_p.type = SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV
rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, SWID, SX_TRAP_ID_ETH_L2_LLDP, uc_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_set failed, rc: %d" % (rc)

if args.deinit:
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, SWID, SX_TRAP_ID_ETH_L2_LLDP, uc_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_set failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_ext_set failed, rc: %d" % (rc)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SWID, TRAP_GROUP, trap_grp_attr)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_group_ext_set failed, rc: %d" % (rc)

rc = sx_api_close(handle)
assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc: %d" % (rc)
