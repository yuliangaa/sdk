#!/usr/bin/env python
'''
This is an example how to set port MTU.
'''

import errno
import sys
import pdb
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_system_log_enter_func_severity example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def wait():
    pass
    # # wait for enter from user to continue the flow
    # tmp = input()


def span_sessions_get(handle):
    span_session_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(span_session_cnt_p, 0)
    rc = sx_api_span_session_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, span_session_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_span_session_iter_get failed, rc = %d" % (rc)))
        sys.exit(rc)

    span_session_cnt = uint32_t_p_value(span_session_cnt_p)
    #print ("span_session_cnt: {}".format(span_session_cnt))


def port_mtu_get(handle, log_port=0x10001):
    max_mtu_size_p = new_sx_port_mtu_t_p()
    oper_mtu_size_p = new_sx_port_mtu_t_p()

    rc = sx_api_port_mtu_get(handle, log_port, max_mtu_size_p, oper_mtu_size_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
        sys.exit(rc)

    oper_mtu_size = sx_port_mtu_t_p_value(oper_mtu_size_p)
    return oper_mtu_size


def port_mtu_set(handle, mtu=2000, log_port=0x10001):
    rc = sx_api_port_mtu_set(handle, log_port, mtu)
    if (rc != SX_STATUS_SUCCESS):
        print(("Failed to set 0x{:x} for MTU value.\n".format(log_port)))
        sys.exit(rc)
    #print ("log_port_0x{:x}: MTU: {}".format(log_port, mtu))


def func_severity_configuration_get(handle, target):

    attr_p = new_sx_log_verbosity_target_attr_t_p()
    attr_p.verbosity_target = target

    rc = sx_api_system_log_enter_func_severity_get(handle, attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to get the current configuration for function enter/leave logs.")
        sys.exit(rc)

    print(("Target: {}: funcion_logs: {}.".format(("API" if (target == SX_LOG_VERBOSITY_TARGET_API) else "Module"), ("Enabled" if attr_p.enable else "Disabled"))))

    return attr_p


def func_severity_configuration_set(handle, target, enable):
    attr_p = new_sx_log_verbosity_target_attr_t_p()
    attr_p.verbosity_target = target
    attr_p.enable = enable

    rc = sx_api_system_log_enter_func_severity_set(handle, attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to set new configuration for function enter/leave logs.")
        sys.exit(rc)

    print(("Target: {}: function_logs: {}.\n".format(("API" if (target == SX_LOG_VERBOSITY_TARGET_API) else "Module" if (target == SX_LOG_VERBOSITY_TARGET_MODULE) else "Both"), ("Enabled" if enable else "Disabled"))))


################################################################################
#                                   Main
################################################################################
def main():
    idx = 1

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    #########################################################################################

    # save for later de-configuration
    original_api_func_severity_p = func_severity_configuration_get(handle, SX_LOG_VERBOSITY_TARGET_API)
    original_module_func_severity_p = func_severity_configuration_get(handle, SX_LOG_VERBOSITY_TARGET_MODULE)

    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    rc = sx_api_system_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p,
                                               api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_system_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    original_system_module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    original_system_api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    rc = sx_api_fdb_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p,
                                            api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    original_fdb_module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    original_fdb_api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    original_oper_mtu_size = port_mtu_get(handle)

    #########################################################################################

    print(("\n{}. Configure system verbosity level API=Debug, Module=Debug.\n".format(idx)))
    idx += 1
    wait()

    rc = sx_api_system_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_DEBUG, SX_VERBOSITY_LEVEL_DEBUG)
    if rc != SX_STATUS_SUCCESS:
        print("Error: failed to disable printing all log messages!\n")
        sys.exit(rc)

    rc = sx_api_fdb_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        print("Error: failed to disable printing all log messages!\n")
        sys.exit(rc)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    print(("\n{}. Enable function enter/exit API logs.".format(idx)))
    idx += 1
    wait()
    func_severity_configuration_set(handle, SX_LOG_VERBOSITY_TARGET_API, True)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    print(("\n{}. Disable function enter/exit API logs.".format(idx)))
    idx += 1
    wait()
    func_severity_configuration_set(handle, SX_LOG_VERBOSITY_TARGET_API, False)

    print(("\n{}. Enable function enter/exit MODULE logs.".format(idx)))
    idx += 1
    wait()
    func_severity_configuration_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, True)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    print(("\n{}. Enable function enter/exit logs for BOTH targets.".format(idx)))
    idx += 1
    wait()
    func_severity_configuration_set(handle, SX_LOG_VERBOSITY_BOTH, True)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    print(("\n{}. Call any API (e.g. sx_api_span_session_iter_get).\n".format(idx)))
    idx += 1
    wait()
    span_sessions_get(handle)

    # Restore deefault configuration
    print(("\n{}. Disable function enter/exit logs for BOTH targets.".format(idx)))
    idx += 1
    wait()
    func_severity_configuration_set(handle, SX_LOG_VERBOSITY_BOTH, False)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    print(("\n{}. Configure system verbosity level API=Notice, Module=Notice.\n".format(idx)))
    idx += 1
    wait()
    rc = sx_api_system_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NOTICE, SX_VERBOSITY_LEVEL_NOTICE)
    if rc != SX_STATUS_SUCCESS:
        print("Error: failed to disable printing all log messages!\n")
        sys.exit(rc)

    print(("\n{}. Call any API (e.g. sx_api_port_mtu_set).\n".format(idx)))
    idx += 1
    wait()
    port_mtu_set(handle)

    if args.deinit:
        port_mtu_set(handle, mtu=original_oper_mtu_size, log_port=0x10001)

        rc = sx_api_fdb_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, original_fdb_module_verbosity_level,
                                                original_fdb_api_verbosity_level)
        if rc != SX_STATUS_SUCCESS:
            print("Error: failed to disable printing all log messages!\n")

        rc = sx_api_system_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, original_system_module_verbosity_level,
                                                   original_system_api_verbosity_level)
        if rc != SX_STATUS_SUCCESS:
            print("Error: failed to disable printing all log messages!\n")
            sys.exit(rc)

        func_severity_configuration_set(handle, SX_LOG_VERBOSITY_TARGET_API, original_api_func_severity_p.enable)

        func_severity_configuration_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, original_module_func_severity_p.enable)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
