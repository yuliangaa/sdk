#!/usr/bin/env python
"""
This file contains a python commands example for the CoS elephant detection feature.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following operations:
1. Configures elephant detection with the given parameters and checks configuration, unless the user asked for
   enable_only depending on previous configuration. User must configure elephant detection at least once before enabling
   detection on ports.
2. Enables detection for the given ports and checks states.

"""

import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def main():

    # Parse arguments
    parser = argparse.ArgumentParser(description='The example below performs the following operations: \n'
                                                 '1. Configures elephant detection with the given parameters and checks'
                                                 ' configuration, unless the user asked for\n'
                                                 'enable_only depending on previous configuration. User must configure '
                                                 'elephant detection at least once before enabling \n'
                                                 'detection on ports.\n'
                                                 '2. Enables detection for the given ports and checks states.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    parser.add_argument('--enable_only', action='store_true', help='Enable elephant detection on given ports without'
                                                                   ' global elephant detection configuration.')
    parser.add_argument('--state', default='enable', choices=['enable', 'disable'],
                        help='State to set, enable (default) or disable')
    parser.add_argument('--ports', type=auto_int, default=None, nargs='+',
                        help='Logical ports to enable elephant detection for. Expected in decimal/hex format, for example:'
                             '--ports 65585 0x10001 ')
    parser.add_argument('--threshold', type=int, default=10, help='Elephant flow threshold')
    parser.add_argument('--time', type=int, default=1, help='The time after which a crawler is detected as elephant flow')
    parser.add_argument('--rate', type=int, default=5000, help='Reference rate to compare flows rate to, units are Mbps')
    parser.add_argument('--auto_clear_disable', action='store_true', help='Disable automatic clear on configuration')
    parser.add_argument('--force', default=False, action='store_true',
                        help='Override prompt for SDK configuration change.')
    args = parser.parse_args()

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    # Open SDK
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Check chip type
    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4]:
        print("Elephant detection is available on Spectrum2, Spectrum3 and Spectrum4 only.")
        sx_api_close(handle)
        sys.exit(0)

    # 1.Configure elephant detection and check configuration, unless the user asked for enable_only depending on previous
    #  configuration. User must configure elephant detection at least once before enabling detection on ports.
    state_p = new_sx_cos_elephant_detection_state_e_p()
    if not args.enable_only:
        attr_p = new_sx_cos_elephant_config_attribs_t_p()
        attr = sx_cos_elephant_config_attribs_t()
        initialized = False
        if args.deinit:
            ports_list = mapPortAndInterfaces(handle)
            for port in ports_list:
                rc = sx_api_cos_elephant_detection_port_state_get(handle, port, state_p)
                assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_get failed, rc: %d" % (rc)
                state = sx_cos_elephant_detection_state_e_p_value(state_p)
                if state == SX_COS_ELEPHANT_DETECTION_STATE_ENABLED_E:
                    initialized = True
                    break

            if initialized:
                rc = sx_api_cos_elephant_detection_config_get(handle, attr_p)
                assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_config_get failed, rc: %d" % (rc)

                attr = sx_cos_elephant_config_attribs_t_p_value(attr_p)
                initialized = True
                old_elephant_threshold = attr.elephant_flow_threshold
                old_reference_rate = attr.reference_rate
                old_floating_time = attr.max_floating_time
                old_clear = attr.elephant_flow_clear

        attr.elephant_flow_threshold = args.threshold
        attr.reference_rate = args.rate
        attr.max_floating_time = args.time
        if args.auto_clear_disable:
            attr.elephant_flow_clear = SX_COS_ELEPHANT_AUTOMATIC_CLEAR_DISABLED_E
        else:
            attr.elephant_flow_clear = SX_COS_ELEPHANT_AUTOMATIC_CLEAR_ENABLED_E

        sx_cos_elephant_config_attribs_t_p_assign(attr_p, attr)

        rc = sx_api_cos_elephant_detection_config_set(handle, attr_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_config_set failed, rc: %d" % (rc)

        attr.elephant_flow_threshold = 0
        attr.reference_rate = 0
        attr.max_floating_time = 0
        sx_cos_elephant_config_attribs_t_p_assign(attr_p, attr)
        rc = sx_api_cos_elephant_detection_config_get(handle, attr_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_config_get failed, rc: %d" % (rc)

        attr = sx_cos_elephant_config_attribs_t_p_value(attr_p)
        assert attr.max_floating_time == args.time, "max floating time doesnt match requested = %d, got %d" % (args.time) % (attr.max_floating_time)
        assert attr.reference_rate == args.rate, "reference rate doesnt match requested = %d, got %d" % (args.rate) % (attr.reference_rate)
        assert attr.elephant_flow_threshold == args.threshold, "elephant flow threshold doesnt match requested = %d, got %d" % (args.threshold) % (attr.elephant_flow_threshold)

    # 2.Enable detection for the given ports and check states.
    set_ports = []
    if args.state == "disable":
        req_state = SX_COS_ELEPHANT_DETECTION_STATE_DISABLED_E
        cmd = SX_ACCESS_CMD_UNSET
        deinit_cmd = SX_ACCESS_CMD_SET
    else:
        req_state = SX_COS_ELEPHANT_DETECTION_STATE_ENABLED_E
        cmd = SX_ACCESS_CMD_SET
        deinit_cmd = SX_ACCESS_CMD_UNSET

    if args.ports:
        state_p = new_sx_cos_elephant_detection_state_e_p()
        for port in args.ports:
            rc = sx_api_cos_elephant_detection_port_state_get(handle, port, state_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_get failed, rc: %d" % (rc)
            state = sx_cos_elephant_detection_state_e_p_value(state_p)
            if state != req_state:
                set_ports.append(port)

    if set_ports:
        ports_arr = new_sx_port_log_id_t_arr(len(set_ports))
        for i, port in enumerate(set_ports):
            sx_port_log_id_t_arr_setitem(ports_arr, i, port)

            rc = sx_api_cos_elephant_detection_port_state_set(handle, cmd, ports_arr, len(set_ports))
            assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_set failed, rc: %d" % (rc)

        for port in set_ports:
            rc = sx_api_cos_elephant_detection_port_state_get(handle, port, state_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_get failed, rc: %d" % (rc)
            state = sx_cos_elephant_detection_state_e_p_value(state_p)
            assert state == req_state

    if args.deinit:
        if set_ports:
            rc = sx_api_cos_elephant_detection_port_state_set(handle, deinit_cmd, ports_arr, len(set_ports))
            assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_set failed, rc: %d" % (rc)

        if initialized:
            attr.elephant_flow_threshold = old_elephant_threshold
            attr.reference_rate = old_reference_rate
            attr.max_floating_time = old_floating_time
            attr.elephant_flow_clear = old_clear
            sx_cos_elephant_config_attribs_t_p_assign(attr_p, attr)

            rc = sx_api_cos_elephant_detection_config_set(handle, attr_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_config_set failed, rc: %d" % (rc)

    # cleanup allocated objects
    if not args.enable_only:
        delete_sx_cos_elephant_config_attribs_t_p(attr_p)
    delete_sx_cos_elephant_detection_state_e_p(state_p)
    sx_api_close(handle)


if __name__ == "__main__":
    main()
