#!/usr/bin/env python
"""
This file contains a python commands example for the CoS elephant detection feature.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below dumps detected elephant flows on all enabled ports unless ports are provided by user specifically.

"""

import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################

l2_type_dict = {
    SX_COS_ELEPHANT_FLOW_L2_TYPE_NO_ETH_E: "L2_TYPE_NO_ETH",
    SX_COS_ELEPHANT_FLOW_L2_TYPE_ETH_E: "L2_TYPE_ETH"
}

vlan_type_dict = {
    SX_COS_ELEPHANT_FLOW_VLAN_TYPE_NO_TAG_E: "VLAN_TYPE_NO_TAG",
    SX_COS_ELEPHANT_FLOW_VLAN_TYPE_PRIO_TAG_E: "VLAN_TYPE_PRIO_TAG",
    SX_COS_ELEPHANT_FLOW_VLAN_TYPE_VLAN_TAG_E: "VLAN_TYPE_VLAN_TAG",
    SX_COS_ELEPHANT_FLOW_VLAN_TYPE_QINQ_E: "VLAN_TYPE_QINQ"
}

l3_type_dict = {
    SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV4_E: "L3_TYPE_IPV4",
    SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV6_E: "L3_TYPE_IPV6",
    SX_COS_ELEPHANT_FLOW_L3_TYPE_GRH_E: "L3_TYPE_GRH",
    SX_COS_ELEPHANT_FLOW_L3_TYPE_FIBER_CHANNEL_E: "L3_TYPE_FIBER_CHANNEL",
    SX_COS_ELEPHANT_FLOW_L3_TYPE_OTHER_E: "L3_TYPE_OTHER",
}

l4_type_dict = {
    SX_COS_ELEPHANT_FLOW_L4_TYPE_TCP_E: "L4_TYPE_TCP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_UDP_E: "L4_TYPE_UDP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_ICMP_E: "L4_TYPE_ICMP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_IGMP_E: "L4_TYPE_IGMP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_BTH_E: "L4_TYPE_BTH",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_BTH_OVER_UDP_E: "L4_TYPE_BTH_OVER_UDP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_AH_E: "L4_TYPE_AH",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_ESP_E: "L4_TYPE_ESP",
    SX_COS_ELEPHANT_FLOW_L4_TYPE_OTHER_E: "L4_TYPE_OTHER",
}

extra_data_key_dict = {
    SX_COS_ELEPHANT_EXTRA_DATA_INVALID: "EXTRA_DATA_INVALID",
    SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_VXLAN_E: "EXTRA_DATA_TUNNEL_VXLAN",
    SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_NVGRE_E: "EXTRA_DATA_TUNNEL_NVGRE",
    SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_IP_IN_IP_E: "EXTRA_DATA_TUNNEL_IP_IN_IP",
    SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_IP_IN_GRE_IN_IP_E: "EXTRA_DATA_TUNNEL_IP_IN_GRE_IN_IP",
    SX_COS_ELEPHANT_EXTRA_DATA_MPLS_E: "EXTRA_DATA_MPLS",
}

max_flow_ids_num = 128


def elephant_detection_flows_get(handle, log_port, flow_ids_cnt):
    cmd = SX_ACCESS_CMD_READ
    flow_ids_list_p = new_sx_cos_elephant_flow_id_t_arr(flow_ids_cnt)
    flow_ids_cnt_p = copy_uint32_t_p(flow_ids_cnt)
    try:
        rc = sx_api_cos_elephant_detection_port_flows_get(handle, cmd, log_port, flow_ids_list_p, flow_ids_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_flows_get failed, rc: %d" % (rc)

        flow_ids_cnt = uint32_t_p_value(flow_ids_cnt_p)

        return [sx_cos_elephant_flow_id_t_arr_getitem(flow_ids_list_p, i) for i in range(flow_ids_cnt)]

    finally:
        delete_sx_cos_elephant_flow_id_t_arr(flow_ids_list_p)
        delete_uint32_t_p(flow_ids_cnt_p)


def cos_elephant_detection_port_flows_data_get(handle, log_port, flow_ids_list, clear):
    cmd = SX_ACCESS_CMD_READ_CLEAR if clear else SX_ACCESS_CMD_READ
    list_cnt_requested = len(flow_ids_list)
    flow_ids_list_p = new_sx_cos_elephant_flow_id_t_arr(list_cnt_requested)
    list_cnt_p = copy_uint32_t_p(list_cnt_requested)
    flow_data_list_p = new_sx_cos_elephant_flow_data_t_arr(list_cnt_requested)
    try:
        for i, flow_id in enumerate(flow_ids_list):
            sx_cos_elephant_flow_id_t_arr_setitem(flow_ids_list_p, i, flow_id)

        rc = sx_api_cos_elephant_detection_port_flows_data_get(handle, cmd, log_port, flow_ids_list_p, flow_data_list_p,
                                                               list_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_flows_data_get failed, rc: %d" % (rc)

        list_cnt = uint32_t_p_value(list_cnt_p)
        assert list_cnt == list_cnt_requested, "SDK did not return all requested entries, returned %d, requested %d"\
                                               % (list_cnt) % (list_cnt_requested)

        return [sx_cos_elephant_flow_data_t_arr_getitem(flow_data_list_p, i) for i in range(list_cnt)]

    finally:
        delete_uint32_t_p(list_cnt_p)
        delete_sx_cos_elephant_flow_id_t_arr(flow_ids_list_p)
        delete_sx_cos_elephant_flow_data_t_arr(flow_data_list_p)


def print_flow_ids(flow_ids_list):
    print("Flow IDs detected:\n%s\n\n" % (" ".join(["%d" % i for i in flow_ids_list])))


def print_flow_data(flow_data_list):

    for flow_data in flow_data_list:
        print("=====================================================================")
        print(("Flow ID %d data:" % (flow_data.data_key.flow_id)))
        print("=====================================================================")
        if not flow_data.data_key.valid_elephant_flow:
            print("Flow ID is invalid\n")
            continue

        print("\nHash attributes:")
        print("---------------------")
        if not flow_data.data_value.hash.hash_valid:
            print("INVALID")
        else:
            print(("Lag hash: %d\n Router hash: %d" % (flow_data.data_value.hash.lag_hash,
                                                       flow_data.data_value.hash.router_hash)))

        print("\nL2 attributes:")
        print("---------------------")
        print(("L2 type: %s" % (l2_type_dict[flow_data.data_value.l2.l2_type])))
        if flow_data.data_value.l2.l2_type == SX_COS_ELEPHANT_FLOW_L2_TYPE_ETH_E:
            print(("Vlan type: %s\nsmac: %s\ndmac: %s" % (vlan_type_dict[flow_data.data_value.l2.vlan_type],
                                                          flow_data.data_value.l2.smac.to_str(),
                                                          flow_data.data_value.l2.dmac.to_str())))
        if flow_data.data_value.l2.vlan_type is not SX_COS_ELEPHANT_FLOW_VLAN_TYPE_PRIO_TAG_E and\
                flow_data.data_value.l2.vlan_type is not SX_COS_ELEPHANT_FLOW_VLAN_TYPE_NO_TAG_E:
            print(("VID: %d" % (flow_data.data_value.l2.vid)))
        if flow_data.data_value.l2.vlan_type != SX_COS_ELEPHANT_FLOW_VLAN_TYPE_NO_TAG_E:
            print(("PCP: %d\nDEI: %d" % (flow_data.data_value.l2.pcp_dei.pcp, flow_data.data_value.l2.pcp_dei.dei)))
        if flow_data.data_value.l2.vlan_type == SX_COS_ELEPHANT_FLOW_VLAN_TYPE_QINQ_E:
            print(("inner VID: %d\ninner PCP: %d\ninner DEI: %d" %
                   (flow_data.data_value.l2.inner_vid, flow_data.data_value.l2.inner_pcp_dei.pcp,
                    flow_data.data_value.l2.inner_pcp_dei.dei)))

        print("\nL3 attributes:")
        print("---------------------")
        print(("L3 type: %s" % (l3_type_dict[flow_data.data_value.l3.l3_type])))
        if flow_data.data_value.l3.l3_type in [SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV4_E, SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV6_E,
                                               SX_COS_ELEPHANT_FLOW_L3_TYPE_GRH_E]:
            print("dscp: %d\necn: %d\nttl: %d\n"
                  "Dont fragment: %s\ndip: %s\nsip: %s" % (flow_data.data_value.l3.dscp,
                                                           flow_data.data_value.l3.ecn,
                                                           flow_data.data_value.l3.ttl,
                                                           str(bool(flow_data.data_value.l3.dont_frag)).upper(),
                                                           ip_addr_to_str(flow_data.data_value.l3.dip),
                                                           ip_addr_to_str(flow_data.data_value.l3.sip)))

        print("\nL4 attributes:")
        print("---------------------")
        print(("L4 type: %s" % (l4_type_dict[flow_data.data_value.l4.l4_type])))
        if flow_data.data_value.l4.l4_type in [SX_COS_ELEPHANT_FLOW_L4_TYPE_TCP_E, SX_COS_ELEPHANT_FLOW_L4_TYPE_UDP_E]:
            print(("Destination port: 0x%x\nSource port: 0x%x" %
                   (flow_data.data_value.l4.l4_destination_port, flow_data.data_value.l4.l4_source_port)))

        print("\nExtra data:")
        print("---------------------")
        print("extra data key: %s" % (extra_data_key_dict[flow_data.data_value.extra_data.extra_data_key]))
        if flow_data.data_value.extra_data.extra_data_key in [SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_VXLAN_E,
                                                              SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_NVGRE_E,
                                                              SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_IP_IN_IP_E,
                                                              SX_COS_ELEPHANT_EXTRA_DATA_TUNNEL_IP_IN_GRE_IN_IP_E]:
            print("vni: %d\nsmac: %s\ndmac: %s" % (flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.vni,
                                                   flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.smac.to_str(),
                                                   flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.dmac.to_str()))
            print(("inner L3 type: %s"
                   % (l3_type_dict[flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.l3_type])))
            if flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.l3_type in\
                    [SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV4_E, SX_COS_ELEPHANT_FLOW_L3_TYPE_IPV6_E,
                     SX_COS_ELEPHANT_FLOW_L3_TYPE_GRH_E]:
                print("dscp: %d\necn: %d\nttl: %d\nDont fragment: %s\ndip: %s\nsip: %s" %
                      (flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.dscp,
                       flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.ecn,
                       flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.ttl,
                       str(bool(flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.dont_frag)).upper(),
                       ip_addr_to_str(flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.dip),
                       ip_addr_to_str(flow_data.data_value.extra_data.extra_data_value.tunnel_extra_data.inner_l3.sip)))
        elif flow_data.data_value.extra_data.extra_data_key == SX_COS_ELEPHANT_EXTRA_DATA_MPLS_E:
            print("exp: %d\nbos: %d\nmpls labels: " % (flow_data.data_value.extra_data.extra_data_value.mpls_extra_data.exp,
                                                       flow_data.data_value.extra_data.extra_data_value.mpls_extra_data.bos))
        for i in range(SX_COS_ELEPHANT_MPLS_LABELS_MAX_CNT):
            mpls_label = sx_cos_mpls_label_t_arr_getitem(flow_data.data_value.extra_data.extra_data_value.mpls_extra_data.mpls_labels, i)
            if mpls_label.label_valid:
                print("label id: %d   ttl: %d" % (mpls_label.label_id, mpls_label.ttl))

        print("\n")


def elephant_detection_flows_dump(handle, ports_list, flow_ids_only, clear):
    for port in ports_list:
        print(("\nDetected flows info on port 0x%x:" % (port)))
        print("-----------------------------------------------------------------------\n")
        flow_ids_list = elephant_detection_flows_get(handle, port, max_flow_ids_num)
        print_flow_ids(flow_ids_list)
        if not flow_ids_only:
            flow_data_list = cos_elephant_detection_port_flows_data_get(handle, port, flow_ids_list, clear)
            print_flow_data(flow_data_list)


def main():
    # Parse arguments
    parser = argparse.ArgumentParser(description='Elephant detection dump for detected flows and their data on requested'
                                                 ' enabled ports, if non given all flows on all enabled ports are dumped.')
    parser.add_argument('--ports', type=auto_int, nargs='+', default=None,
                        help='Logical ports to enable elephant detection for. Expected in decimal/hex format, for example:'
                             '--ports 65585 0x10001 ')
    parser.add_argument('--flow_ids_only', action='store_true', help='Dump flow IDs detected without flows data')
    parser.add_argument('--clear', action='store_true', help='Clears the flows after getting the flows data')
    args = parser.parse_args()

    print_api_example_disclaimer()

    # Open SDK
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d \n" % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Check chip type
    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4]:
        print("Elephant detection is available on Spectrum2, Spectrum3 and Spectrum4 only.")
        sx_api_close(handle)
        sys.exit(0)

    # Get ports
    enabled_ports_list = []
    if args.ports:
        ports_list = args.ports
    else:
        ports_list = mapPortAndInterfaces(handle)
    state_p = new_sx_cos_elephant_detection_state_e_p()
    for port in ports_list:
        rc = sx_api_cos_elephant_detection_port_state_get(handle, port, state_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_cos_elephant_detection_port_state_get failed, rc: %d" % (rc)
        state = sx_cos_elephant_detection_state_e_p_value(state_p)
        if state == SX_COS_ELEPHANT_DETECTION_STATE_ENABLED_E:
            enabled_ports_list.append(port)
        elif args.ports:
            print(("Elephant detection is disabled on port 0x%x\n" % (port)))

    # Dump flows
    elephant_detection_flows_dump(handle, enabled_ports_list, args.flow_ids_only, args.clear)

    # cleanup allocated objects
    delete_sx_cos_elephant_detection_state_e_p(state_p)
    sx_api_close(handle)


if __name__ == "__main__":
    main()
