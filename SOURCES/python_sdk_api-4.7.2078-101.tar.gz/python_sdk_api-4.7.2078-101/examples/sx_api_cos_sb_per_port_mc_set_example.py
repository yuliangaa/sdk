#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys

from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_cos_sb_per_port_mc_set_example example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_attributes_list = new_sx_port_attributes_t_arr(64)
port_cnt_p = new_uint32_t_p()
max_mtu_size_p = new_sx_port_mtu_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
uint32_t_p_assign(port_cnt_p, 64)
oper_state_p = new_sx_port_oper_state_t_p()
admin_state_p = new_sx_port_admin_state_t_p()
module_state_p = new_sx_port_module_state_t_p()
vid_p = new_sx_vid_t_p()

rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
port_cnt = uint32_t_p_value(port_cnt_p)
print(("sx_api_port_device_get port_cnt:%d , rc %d, port_list : " % (port_cnt, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("An error was found in sx_api_fdb_uc_mac_addr_get.\nThe example will exit")
    sys.exit(rc)


def cos_port_buff_get_all(log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    assert(port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_shared_buff_get_all(log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt

#####################################################################################


# save current attributes for later de-configuration
buff_saved_attr = []
shared_buff_saved_attr = []
for i in range(0, port_cnt):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_cpu or is_vport:
        continue
    log_port = port_attributes.log_port

    original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all(log_port)
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(log_port)

    buff_saved_attr.append((original_port_buff_attr_list, original_port_buff_attr_cnt))
    shared_buff_saved_attr.append((original_port_sb_attr_list, original_port_sb_attr_cnt))

#####################################################################################

for i in range(0, port_cnt):
    # for i in range(0,1):

    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_cpu or is_vport:
        continue
    log_port = port_attributes.log_port
    """ PORT TYPE BUFF SET """
    print("---------------  PORT TYPE BUFF SET (MIN) ------------------------------")
    count = 1
    """ CMD_SET = 15 """
    cmd = 15
    port_buffer_attr_cnt = count
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)

    for i in range(0, port_buffer_attr_cnt):
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
        """ Set type and relevant parameters """
        attr_item_min.type = SX_COS_MULTICAST_PORT_ATTR_E

        print(("[%d] type = %d" % (i, attr_item_min.type)))
        if attr_item_min.type == SX_COS_MULTICAST_PORT_ATTR_E:
            attr_item_min.attr.multicast_port_buff_attr.size = 96
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.multicast_port_buff_attr.size)))

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, attr_item_min, port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    print("--------------------------------------------------------------------")

    """ ############################################################################################ """
    """ PORT SHARED BUFF SET """
    print("---------------  PORT SHARED BUFF SET ------------------------------")
    count = 1
    """ CMD_SET = 15 """
    cmd = 15
    port_shared_buffer_attr_cnt = count
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)

    for i in range(0, port_shared_buffer_attr_cnt):
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
        """ Set type and relevant parameters """
        attr_item.type = SX_COS_MULTICAST_PORT_ATTR_E

        print(("[%d] type = %d" % (i, attr_item.type)))

        if attr_item.type == SX_COS_MULTICAST_PORT_ATTR_E:
            attr_item.attr.multicast_port_shared_buff_attr.max.mode = 2
            attr_item.attr.multicast_port_shared_buff_attr.pool_id = 10
            print(("[%d] pool_mode  = %d" % (i, attr_item.attr.multicast_port_shared_buff_attr.max.mode)))
            if attr_item.attr.multicast_port_shared_buff_attr.max.mode == 0:
                """ Static """
                attr_item.attr.multicast_port_shared_buff_attr.max.max.size = 58
                print(("[%d] Max  = %d" % (i, attr_item.attr.multicast_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                attr_item.attr.multicast_port_shared_buff_attr.max.max.alpha = 4
                print(("[%d] Max (Alpha) = %d" % (i, attr_item.attr.multicast_port_shared_buff_attr.max.max.alpha)))

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, attr_item, port_shared_buffer_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_shared_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

if args.deinit:
    for i in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if is_nve or is_cpu or is_vport:
            continue
        log_port = port_attributes.log_port

        original_port_buff_attr_list, original_port_buff_attr_cnt = buff_saved_attr[i][0], buff_saved_attr[i][1]

        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list,
                                           original_port_buff_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        original_port_sb_attr_list, original_port_sb_attr_cnt = shared_buff_saved_attr[i][0], shared_buff_saved_attr[i][1]

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list,
                                                  original_port_sb_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

print("--------------------------------------------------------------------")
