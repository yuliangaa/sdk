#!/usr/bin/env python
"""
This file contains a python commands example for the BRIDGE module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""


import sys
import os
from python_sdk_api.sx_api import *
from test_infra_common import *


tagged_dict = {0: 'Tagged Member', 1: 'Untagged Member'}
mirror_mode_dict = {0: 'Disabled', 1: 'Enabled'}

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')

print_api_example_disclaimer()

bridge_id_cnt_p = new_uint32_t_p()
uint32_t_p_assign(bridge_id_cnt_p, 0)
bridge_id = 0
rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET, bridge_id, None, None, bridge_id_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_bridge_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
bridge_id_cnt = uint32_t_p_value(bridge_id_cnt_p)

bridge_id_list_p = new_sx_bridge_id_t_arr(bridge_id_cnt)
rc = sx_api_bridge_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, bridge_id, None, bridge_id_list_p, bridge_id_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_bridge_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
bridge_id_cnt = uint32_t_p_value(bridge_id_cnt_p)
header_printed = False

if bridge_id_cnt == 0:
    print("No bridge found! ")

for i in range(0, bridge_id_cnt):
    if not header_printed:
        print("==================================================")
        print("|%11s|%17s|%18s|" % ("Bridge ID", "Flow Counter ID", "Member Vport ID"))
        print("==================================================")
        header_printed = True

    bridge_id = sx_bridge_id_t_arr_getitem(bridge_id_list_p, i)
    bridge_vport_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(bridge_vport_cnt_p, 0)
    rc = sx_api_bridge_vport_get(handle, bridge_id, None, bridge_vport_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_bridge_vport_get failed, rc = %d" % (rc))
        sys.exit(rc)
    bridge_vport_cnt = uint32_t_p_value(bridge_vport_cnt_p)
    bridge_vport_list_p = new_sx_port_log_id_t_arr(bridge_vport_cnt)
    rc = sx_api_bridge_vport_get(handle, bridge_id, bridge_vport_list_p, bridge_vport_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_bridge_vport_get failed, rc = %d" % (rc))
        sys.exit(rc)
    bridge_vport_cnt = uint32_t_p_value(bridge_vport_cnt_p)

    flow_counter_id_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_bridge_counter_bind_get(handle, bridge_id, flow_counter_id_p)
    if rc == SX_STATUS_ENTRY_NOT_FOUND:
        flow_counter_id = 0
    elif rc == SX_STATUS_SUCCESS:
        flow_counter_id = sx_flow_counter_id_t_p_value(flow_counter_id_p)
    else:
        print("sx_api_bridge_counter_bind_get failed, rc = %d" % (rc))
        sys.exit(rc)

    print("|%11d %17d| " % (bridge_id, flow_counter_id), end="")

    if bridge_vport_cnt == 0:
        print("%17s|" % (""))
        print("==================================================")
    else:
        for j in range(0, bridge_vport_cnt):
            vport = sx_port_log_id_t_arr_getitem(bridge_vport_list_p, j)
            vport_str = "0x%x" % vport
            if j == 0:
                print("%17s|" % (vport_str))
            else:
                print("|%29s|%18s|" % ("", vport_str))

            if j == (bridge_vport_cnt - 1):
                print("==================================================")
            else:
                print("|%29s|-------------------" % (""))
