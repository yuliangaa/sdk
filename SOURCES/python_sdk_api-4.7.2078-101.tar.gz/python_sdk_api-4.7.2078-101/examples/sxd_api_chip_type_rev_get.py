#!/usr/bin/env python


import sys
import errno
import time
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *


def get_chip_type_and_rev(deinit=False):
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    mgir = ku_mgir_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert SX_STATUS_SUCCESS == rc, "sxd_access_reg_mgir failed; rc=%d" % (rc)

    if deinit:
        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)

    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


################
# Start of run #
################

def main():
    print("\r\n")
    print("[+] initializing register access")
    print("\r\n")

    # Get chip type and rev
    chip_type, chip_rev = get_chip_type_and_rev()

    print("\r\n")
    # Iterate python variable names and values - to find and print chip type
    found = False
    for name, value in list(globals().items()):
        if name.find("SXD_MGIR_HW_DEV_ID") != -1:
            if str(value) == str(chip_type):
                print("Chip type is %s (0x%X)" % (str(name), chip_type))
                found = True

    if not found:
        print("Error: Did not find a matching string for chip type 0x%X" % (chip_type))

    # Print chip revision
    print("Chip HW revision is %x" % (chip_rev))

    print("\r\n")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    main()
