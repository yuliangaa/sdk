#!/usr/bin/env python
'''
This file contains Python command example for the Policer module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different policer attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_policer example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

""" ############################################################################################ """


def policer_create(meter_type, cbs, ebs, cir, yellow_action, red_action, eir, rate_type,
                   color_aware, is_host_ifc_policer, ir_units):
    """ ############################################################################################ """
    """ POLICER CREATE """
    print("--------------- POLICER CREATE ------------------------------")
    cmd = SX_ACCESS_CMD_CREATE

    policer_id_p = new_sx_policer_id_t_p()

    policer_attr_p = new_sx_policer_attributes_t_p()
    policer_attr = sx_policer_attributes_t()

    policer_attr.meter_type = meter_type
    policer_attr.cbs = cbs
    policer_attr.ebs = ebs
    policer_attr.cir = cir
    policer_attr.yellow_action = yellow_action
    policer_attr.red_action = red_action
    policer_attr.eir = eir
    policer_attr.rate_type = rate_type
    policer_attr.color_aware = color_aware
    policer_attr.is_host_ifc_policer = is_host_ifc_policer
    policer_attr.ir_units = ir_units

    sx_policer_attributes_t_p_assign(policer_attr_p, policer_attr)

    policer_attr = sx_policer_attributes_t_p_value(policer_attr_p)

    print(("meter type =%d " % (policer_attr.meter_type)))
    print(("cbs=%d " % (policer_attr.cbs)))
    print(("ebs=%d " % (policer_attr.ebs)))
    print(("cir=%d " % (policer_attr.cir)))
    print(("yellow action=%d " % (policer_attr.yellow_action)))
    print(("red action=%d " % (policer_attr.red_action)))
    print(("eir=%d " % (policer_attr.eir)))
    print(("rate type=%d " % (policer_attr.rate_type)))
    print(("color aware=%d " % (policer_attr.color_aware)))
    print(("host ifc policer=%d " % (policer_attr.is_host_ifc_policer)))
    print(("ir units=%d " % (policer_attr.ir_units)))

    rc = sx_api_policer_set(handle, cmd, policer_attr_p, policer_id_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_policer_set CREATE [rc=%d] " % (rc)))

    return policer_id_p, policer_attr_p


""" ############################################################################################ """


def policer_get(policer_id):
    """ POLICER  GET """
    print("--------------- POLICER GET ------------------------------")

    policer_attr_p = new_sx_policer_attributes_t_p()

    rc = sx_api_policer_get(handle, policer_id, policer_attr_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_policer_get, rc=%d " % (rc)))

    policer_attr = sx_policer_attributes_t_p_value(policer_attr_p)

    print(("policer id =%d " % (policer_id)))
    print(("meter type =%d " % (policer_attr.meter_type)))
    print(("cbs=%d " % (policer_attr.cbs)))
    print(("ebs=%d " % (policer_attr.ebs)))
    print(("cir=%d " % (policer_attr.cir)))
    print(("yellow action=%d " % (policer_attr.yellow_action)))
    print(("red action=%d " % (policer_attr.red_action)))
    print(("eir=%d " % (policer_attr.eir)))
    print(("rate type=%d " % (policer_attr.rate_type)))
    print(("color aware=%d " % (policer_attr.color_aware)))
    print(("host ifc policer=%d " % (policer_attr.is_host_ifc_policer)))
    print(("ir units=%d " % (policer_attr.ir_units)))


""" ############################################################################################ """


def host_ifc_policer_bind_unbind(cmd, policer_id):
    """ ############################################################################################ """
    """ HOST IFC POLICER BIND/UNBIND SET """
    print("--------------- HOST IFC POLICER BIND/UNBIND SET------------------------------")

    swid = 0
    if cmd == SX_ACCESS_CMD_BIND:
        print("HOST IFC POLICER BIND")
    if cmd == SX_ACCESS_CMD_UNBIND:
        print("HOST IFC POLICER UNBIND")

    rc = sx_api_host_ifc_policer_bind_set(handle, cmd, swid, trap_group, policer_id)
    print(("rc = %d" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    print(("swid =%d, trap group =%d, policer id=%d" % (swid, trap_group, policer_id)))


""" ############################################################################################ """


def get_policer_counter(policer_id):
    """ POLICER  COUNTER GET """
    print("--------------- POLICER COUNTER GET ------------------------------")

    policer_counters_p = new_sx_policer_counters_t_p()

    rc = sx_api_policer_counters_get(handle, policer_id, policer_counters_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_policer_counters_get, rc=%d " % (rc)))

    policer_counters = sx_policer_counters_t_p_value(policer_counters_p)

    print(("policer id =%d " % (policer_id)))
    print(("violation counter =%d " % (policer_counters.violation_counter)))


""" ############################################################################################ """


def clear_policer_counter(policer_id):
    """ CLEAR POLICER COUNTER SET"""
    print("--------------- CLEAR POLICER COUNTER SET ------------------------------")

    clear_counters_p = new_sx_policer_counters_clear_t_p()
    clear_counters = sx_policer_counters_clear_t()

    clear_counters.clear_violation_counter = 1
    sx_policer_counters_clear_t_p_assign(clear_counters_p, clear_counters)
    clear_counters = sx_policer_counters_clear_t_p_value(clear_counters_p)

    rc = sx_api_policer_counters_clear_set(handle, policer_id, clear_counters_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_policer_counters_clear_set, rc=%d " % (rc)))

    clear_counters = sx_policer_counters_clear_t_p_value(clear_counters_p)

    print(("policer id =%d " % (policer_id)))
    print(("clear violation counter =%d " % (clear_counters.clear_violation_counter)))


""" ############################################################################################ """
policer_id_1_p, policer_attr_1_p = policer_create(SX_POLICER_METER_PACKETS, 10, 10, 1000, SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR,
                                                  SX_POLICER_ACTION_DISCARD, 1000, SX_POLICER_RATE_TYPE_SINGLE_RATE_E, 0, 1,
                                                  SX_POLICER_IR_UNITS_10_POWER_3_E)
policer_id_1 = sx_policer_id_t_p_value(policer_id_1_p)
print(("policer id rcvd from create _policer =%d " % (policer_id_1)))
policer_get(policer_id_1)

""" ############################################################################################ """
policer_id_2_p, policer_attr_2_p = policer_create(SX_POLICER_METER_TRAFFIC, 10, 10, 1000, SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR,
                                                  SX_POLICER_ACTION_DISCARD, 1000, SX_POLICER_RATE_TYPE_SINGLE_RATE_E, 0, 1,
                                                  SX_POLICER_IR_UNITS_10_POWER_6_E)
policer_id_2 = sx_policer_id_t_p_value(policer_id_2_p)
print(("policer id rcvd from create _policer =%d " % (policer_id_2)))
policer_get(policer_id_2)

""" ############################################################################################ """

""" HOST IFC OPEN """
print("--------------- HOST IFC OPEN------------------------------")

fd_p = new_sx_fd_t_p()

rc = sx_api_host_ifc_open(handle, fd_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
fd = sx_fd_t_p_value(fd_p)

print(("sx_api_host_ifc_open,fd = %d rc=%d] " % (fd.fd, rc)))

""" ############################################################################################ """

""" HOST IFC TRAP GROUP EXT SET """
print("--------------- HOST IFC TRAP GROUP EXT SET------------------------------")

swid = 0
trap_group = 1
trap_group_attr_p = new_sx_trap_group_attributes_t_p()
trap_group_attr = sx_trap_group_attributes_t()

trap_group_attr.prio = 0
trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_group_attr.truncate_size = 0
trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
trap_group_attr.is_monitor = False
trap_group_attr.trap_group = trap_group

sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

trap_group_attr = sx_trap_group_attributes_t_p_value(trap_group_attr_p)

print(("prio =%d " % (trap_group_attr.prio)))
print(("truncate mode  =%d " % (trap_group_attr.truncate_mode)))
print(("truncate size  =%d " % (trap_group_attr.truncate_size)))
print(("control size  =%d " % (trap_group_attr.control_type)))

trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, swid, trap_group, trap_group_attr_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_host_ifc_trap_group_ext_set, rc=%d" % (rc))
    sys.exit(rc)

trap_group = sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group

""" ############################################################################################ """
""" HOST IFC TRAP ID SET """
print("--------------- HOST IFC TRAP ID EXT SET------------------------------")

swid = 0
trap_id = 16
trap_action = SX_TRAP_ACTION_TRAP_2_CPU

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
print(("prio =%d " % (trap_group_attr.prio)))
print("sx_api_host_ifc_trap_id_ext_set")
print(("swid =%d, trap_id =%d, trap_group=%d, trap_action =%d, rc=%d" % (swid, trap_id, trap_group, trap_action, rc)))
if rc != SX_STATUS_SUCCESS:
    print("sx_api_host_ifc_trap_id_ext_set failed, rc = %d" % rc)
    sys.exit(rc)

""" HOST IFC TRAP ID REGISTER SET """
print("--------------- HOST IFC TRAP ID REGISTER SET------------------------------")

swid = 0
trap_id = 16
cmd = SX_ACCESS_CMD_REGISTER
user_channel_p = new_sx_user_channel_t_p()
user_channel = sx_user_channel_t()
user_channel.type = SX_USER_CHANNEL_TYPE_FD
user_channel.channel.fd = copy_sx_fd_t_p(fd)

sx_user_channel_t_p_assign(user_channel_p, user_channel)

rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, swid, trap_id, user_channel_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

user_channel = sx_user_channel_t_p_value(user_channel_p)

print("sx_api_host_ifc_trap_id_register_set")
print(("swid =%d, trap_id =%d, channel type=%d, channel fd =%d, rc=%d" % (swid, trap_id, user_channel.type,
                                                                          user_channel.channel.fd.fd, rc)))

""" ############################################################################################ """

# bind, get policer_id_1 created above
host_ifc_policer_bind_unbind(SX_ACCESS_CMD_BIND, policer_id_1)
get_policer_counter(policer_id_1)

# clear and unbind policer_id_1
clear_policer_counter(policer_id_1)
host_ifc_policer_bind_unbind(SX_ACCESS_CMD_UNBIND, policer_id_1)

# bind, get policer_id_2 created above
host_ifc_policer_bind_unbind(SX_ACCESS_CMD_BIND, policer_id_2)
get_policer_counter(policer_id_2)

# clear and unbind policer_id_2
clear_policer_counter(policer_id_2)
host_ifc_policer_bind_unbind(SX_ACCESS_CMD_UNBIND, policer_id_2)

if args.deinit:
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, swid, trap_id, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_ext_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, swid, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_group_ext_set set failed; [rc=%d]" % (rc)))
        sys.exit(rc)

    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_DESTROY, policer_attr_1_p, policer_id_1_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed; [rc=%d]" % (rc)))
        sys.exit(rc)

    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_DESTROY, policer_attr_2_p, policer_id_2_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed; [rc=%d]" % (rc)))
        sys.exit(rc)

    rc = sx_api_host_ifc_close(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_close failed; [rc=%d]" % (rc)))
        sys.exit(rc)

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
