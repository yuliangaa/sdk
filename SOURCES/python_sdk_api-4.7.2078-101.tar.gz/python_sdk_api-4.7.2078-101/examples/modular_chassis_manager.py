#!/usr/bin/env python
# -*- python -*-
'''
Copyright (C) Mellanox Technologies, Ltd. 2020.  ALL RIGHTS RESERVED.

This software product is a proprietary product of Mellanox Technologies, Ltd.
(the "Company") and all right, title, and interest in and to the software product,
including all associated intellectual property rights, are and shall
remain exclusively with the Company.

This software product is governed by the End User License Agreement
provided with the software product.

'''

import sys
import subprocess
import errno
import time
import inspect
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import functools
import struct
import logging
import tarfile
from logging import DEBUG, WARNING, INFO, ERROR
from test_infra_common import *

######################################################
#    Defines
######################################################

NUM_SLOTS = 8
MAX_INI_DATA_SIZE = 1024
IDLE = SX_MGMT_SLOT_INI_OPER_NONE_STATUS_IDLE_E
BUSY = SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_BUSY_E
READY_NEXT = SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_READY_NEXT_XFER_E
FAILURE = SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_FAILURE_E
INI_ERROR = SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_INI_ERROR_E
MAX_DEVICE_PER_CARD = SX_MGMT_MAX_DEVICE_PER_CARD
VALID = SX_MGMT_SLOT_INI_STATUS_VALID_E
APPLY_READY = SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_LAST_XFER_READY_APPLY_E

PORT_TYPE_NVE = 8
PORT_TYPE_CPU = 4
PORT_TYPE_VPORT = 2
PORT_TYPE_OFFSET = 28
PORT_TYPE_MASK = 0xF0000000


UNBIND_SWID = 255
SWID = 0
SPECTRUM_DEVICE = 1

HW_MANAGEMENT_BASE_PATH = '/var/run/hw-management/'
LINE_CARD_PRESENT = 'system/lcX_present'
LINE_CARD_VERIFIED = 'system/lcX_verified'
LINE_CARD_POWERED = 'system/lcX_powered'
LINE_CARD_READY = 'system/lcX_ready'
LINE_CARD_SYNCED = 'system/lcX_synced'
LINE_CARD_ACTIVE = 'system/lcX_active'
LINE_CARD_POWER = 'system/lcX_pwr'
LINE_CARD_ENABLE = 'system/lcX_enable'
EEPROM_INI_PATH = "lcX/eeprom/ini"
VALID_SLOT_INDEX = list(map(str, list(range(1, (NUM_SLOTS + 1)))))

slot_count_g = 0

#########################################
# Set Default log Level [ERROR >  WARNING > INFO > DEBUG]
DEF_LOG_LEVEL = ERROR
########################################


######################################################
#   Helper Functions
######################################################
class TimeOutException(Exception):
    """Exception to be raised in case of timeout"""
    pass

###########################################
# retry_on_failure_till_timeout decorator #
###########################################


class NotifyFailure(Exception):
    """
    Exception class to be used inside a function wrapped by @retry_on_failure_till_timeout decorator.
    An instance of this class should be raised for letting the wrapper know that the function failed, and need to be retried
    """
    pass


def retry_on_failure_till_timeout(timeout, e_msg=None):
    """
    A decorator for retrying an execution of a function until it succeeds or timeout

    :param timeout: int/float
    :param e_msg: string (optional). The message to be raised in case of a timeout
    :returns: returns the result of the function if succeeded
    :raises:  TimeOutException(e_msg) in case of a timeout


    Example:
        @retry_on_failure_till_timeout(1)
        def foo(countdown):
            countdown -= 1
            if countdown > 0:
                raise NotifyFailure()


    Explanation: foo will try to countdown till 0 within 1 second.

    """

    def decorate(f):
        @functools.wraps(f)
        def new_f(*args, **kwargs):
            if e_msg is None:
                error_str = "Function %s didn't succeed after %f seconds" % (f.__name__, timeout)
            else:
                error_str = e_msg
            until = time.time() + timeout
            while time.time() < until:
                try:
                    return f(*args, **kwargs)
                except NotifyFailure:
                    pass
            raise TimeOutException(error_str)

        return new_f

    return decorate


def set_log_level(loglevel):
    if loglevel is None:
        loglevel = DEF_LOG_LEVEL
    else:
        loglevel = loglevel.upper()

    logging.basicConfig(level=loglevel, format='%(asctime)s - %(levelname)s - %(message)s')


def cmd_set(cmd):
    try:
        subprocess.call(cmd, shell=True)
    except subprocess.CalledProcessError:
        logging.error("cmd '{}' failed:\n{}".format(cmd, e.output))
        raise


def check_rc(rc, expected_results=None, **kwargs):
    if rc != SX_STATUS_SUCCESS:
        # Get the calling function name from the last frame
        cf = inspect.currentframe().f_back
        func_name = inspect.getframeinfo(cf).function

        error_info = func_name + ' Failed with rc = ' + str(rc)

        for k, v in list(kwargs.items()):
            error_info += ', %s = %s' % (k, v)

        logging.error(error_info)
        raise Exception


def port_mapping_parse(port_mapping):
    port_mapping_dict = {'local_port': port_mapping.local_port,
                         'mapping_mode': port_mapping.mapping_mode,
                         'module_port': port_mapping.module_port,
                         'width': port_mapping.width,
                         'lane_bmap': port_mapping.lane_bmap,
                         'slot_id': port_mapping.slot}

    return port_mapping_dict


def get_path(base, slot_id):
    path = HW_MANAGEMENT_BASE_PATH + base
    path = path.replace('X', str(slot_id))
    if os.path.exists(path) == False:
        logging.debug("File %s does not exist", path)
        return None

    return path


def is_line_card_present(slot_id):
    try:
        path = get_path(LINE_CARD_PRESENT, slot_id)
        if path is None:
            logging.debug("check card presence failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is present", slot_id)
            return True
        else:
            logging.debug("Line card %d is not present", slot_id)
            return False

    except BaseException:
        raise


def is_line_card_verified(slot_id):
    try:
        path = get_path(LINE_CARD_VERIFIED, slot_id)
        if path is None:
            logging.debug("check card verify failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is verified", slot_id)
            return True
        else:
            logging.debug("Line card %d is not verified", slot_id)
            return False

    except BaseException:
        raise


def is_line_card_powered(slot_id):
    try:
        path = get_path(LINE_CARD_POWERED, slot_id)
        if path is None:
            logging.debug("check card powered failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is powered", slot_id)
            return True
        else:
            logging.debug("Line card %d is not powered", slot_id)
            return False

    except BaseException:
        raise


def is_line_card_ready(slot_id):
    try:
        path = get_path(LINE_CARD_READY, slot_id)
        if path is None:
            logging.debug("check card ready failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is ready", slot_id)
            return True
        else:
            logging.debug("Line card %d is not ready", slot_id)
            return False

    except BaseException:
        raise


def is_line_card_synced(slot_id):
    try:
        path = get_path(LINE_CARD_SYNCED, slot_id)
        if path is None:
            logging.debug("check card sync failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is Synced", slot_id)
            return True
        else:
            logging.debug("Line card %d is not Synced", slot_id)
            return False
    except BaseException:
        raise


def is_line_card_active(slot_id):
    try:
        path = get_path(LINE_CARD_ACTIVE, slot_id)
        if path is None:
            logging.debug("check card active failed")
            return False
        if '1' in cmd_output_get('cat ' + path).splitlines():
            logging.debug("Line card %d is active", slot_id)
            return True
        else:
            logging.debug("Line card %d is not active", slot_id)
            return False
    except BaseException:
        raise


def line_card_power_on(slot_id):
    try:
        if is_line_card_powered(slot_id) != True:
            path = get_path(LINE_CARD_POWER, slot_id)
            logging.debug("Power on Line card %d", slot_id)
            cmd_set('echo 1 >' + path)
        else:
            logging.debug("Linecard %d is already powered on", slot_id)

    except BaseException:
        raise


def line_card_power_off(handle, slot_id):
    try:
        if is_line_card_powered(slot_id):
            path = get_path(LINE_CARD_POWER, slot_id)
            logging.debug("Power off Line card %d", slot_id)
            cmd_set('echo 0 >' + path)
        else:
            logging.debug("Linecard %d is not powered on", slot_id)

    except BaseException:
        raise


def line_card_enable(slot_id):
    try:
        path = get_path(LINE_CARD_ENABLE, slot_id)
        logging.debug("Enable Line card %d", slot_id)
        cmd_set('echo 1 >' + path)

    except BaseException:
        raise


def line_card_disable(slot_id):
    try:
        path = get_path(LINE_CARD_ENABLE, slot_id)
        logging.debug("Disable Line card %d", slot_id)
        cmd_set('echo 0 >' + path)

    except BaseException:
        raise


@retry_on_failure_till_timeout(60)
def __check_powered_up_linecard(slot_id):
    if is_line_card_powered(slot_id) != True:
        time.sleep(0.1)
        raise NotifyFailure()


def slot_control_power_on(handle, slot_id):
    line_card_power_on(slot_id)
    __check_powered_up_linecard(slot_id)


def enable_rate(rate, admin_rate):
    return (True if (rate in admin_rate) else False)


def port_swid_bind_get(handle, port):
    sx_swid_p = new_sx_swid_t_p()
    rc = sx_api_port_swid_bind_get(handle, port, sx_swid_p)
    check_rc(rc, "Failed to get port swid binding.")
    swid = sx_swid_t_p_value(sx_swid_p)
    return swid


def port_rate_configuration(handle, port, admin_rate):
    # Went through the admin_rate list and enable appropriate values
    rate_bitmask_p = new_sx_port_rate_bitmask_t_p()
    rate_bitmask_p.rate_100M = enable_rate("100M", admin_rate)
    rate_bitmask_p.rate_1G = enable_rate("1G", admin_rate)
    rate_bitmask_p.rate_10G = enable_rate("10G", admin_rate)
    rate_bitmask_p.rate_25G = enable_rate("25G", admin_rate)
    rate_bitmask_p.rate_40G = enable_rate("40G", admin_rate)
    rate_bitmask_p.rate_50G = enable_rate("50G", admin_rate)
    rate_bitmask_p.rate_100G = enable_rate("100G", admin_rate)
    rate_bitmask_p.rate_200G = enable_rate("200G", admin_rate)
    rate_bitmask_p.rate_400G = enable_rate("400G", admin_rate)
    rate_bitmask_p.rate_auto = enable_rate("auto", admin_rate)
    rate_bitmask_p.force = False  # Note that this option may be enabled only for single rate value

    # Set all module types
    phy_type_p = new_sx_port_phy_module_type_bitmask_t_p()
    phy_type_p.module_smf_up_500m = True
    phy_type_p.module_smf_up_2km = True
    phy_type_p.module_smf_above_2km = True
    phy_type_p.module_mmf_up_100m = True
    phy_type_p.module_mmf_above_100m = True
    phy_type_p.module_aoc_acc_up_30m = True
    phy_type_p.module_aoc_acc_above_30m = True
    phy_type_p.module_base_cr = True
    phy_type_p.module_base_tp = True

    module_id, _, _, slot_id = ports_mapping_attr_get(handle, port)
    # Todo replace with sx_mgmt_port_phy_module_type_oper_set with slot ID
    #rc = sx_api_port_phy_module_type_set(handle, module_id, phy_type_p)
    #check_rc(rc, "Failed to set port phy type.")

    rc = sx_api_port_rate_set(handle, port, rate_bitmask_p)
    check_rc(rc, "Failed to set port admin rate.")

    logging.debug("[+] Rate and PMD type is configured for log_port: 0x%x." % (port))


def port_states_get(handle, port, debug_print=True):
    if debug_print:
        logging.debug("Getting port 0x{:x} states".format(port))

    oper_state_p = copy_sx_port_oper_state_t_p(0)
    admin_state_p = copy_sx_port_admin_state_t_p(0)
    module_state_p = copy_sx_port_module_state_t_p(0)

    try:
        rc = sx_api_port_state_get(handle, port, oper_state_p, admin_state_p, module_state_p)
        check_rc(rc, "sx_api_port_state_get failed.")

        oper_state = sx_port_oper_state_t_p_value(oper_state_p)
        admin_state = sx_port_admin_state_t_p_value(admin_state_p)
        module_state = sx_port_module_state_t_p_value(module_state_p)

        return oper_state, admin_state, module_state
    finally:
        delete_sx_port_module_state_t_p(module_state_p)
        delete_sx_port_admin_state_t_p(admin_state_p)
        delete_sx_port_oper_state_t_p(oper_state_p)


def get_meta():
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    return meta


def clear_raw_reg(raw_reg, size):
    for i in range(0, size):
        uint8_t_arr_setitem(raw_reg.buff, i, 0x0)


def convert_buffer_big_little_endian(buff, size):
    num_dwords = size / 4 + (size % 4 > 0)
    for i in range(0, num_dwords):
        byte0 = uint8_t_arr_getitem(buff, i * 4)
        byte1 = uint8_t_arr_getitem(buff, i * 4 + 1)
        byte2 = uint8_t_arr_getitem(buff, i * 4 + 2)
        byte3 = uint8_t_arr_getitem(buff, i * 4 + 3)
        uint8_t_arr_setitem(buff, i * 4, byte3)
        uint8_t_arr_setitem(buff, i * 4 + 1, byte2)
        uint8_t_arr_setitem(buff, i * 4 + 2, byte1)
        uint8_t_arr_setitem(buff, i * 4 + 3, byte0)
    return buff


def get_access_reg_raw(reg_raw, reg_meta, register_id, reg_name):
    reg_raw.buff = convert_buffer_big_little_endian(reg_raw.buff, reg_raw.size)
    rc = sxd_access_reg_raw(reg_raw, reg_meta, 1, register_id, None, None)
    reg_raw.buff = convert_buffer_big_little_endian(reg_raw.buff, reg_raw.size)
    if rc:
        raise Exception('{} returned a bad status: {}'.format(reg_name.upper(), rc))

    data = uint8_t_arr_getitem(reg_raw.buff, 0)

    return data


def set_pplr_raw_reg_data(handle, log_port, port_type=1):
    # Used for setting Buffalo LB at the near end of AGB
    # For more information please see PPLR in PRM file
    oper_state, _, _ = port_states_get(handle, log_port)
    assert oper_state == SX_PORT_OPER_STATUS_DOWN, "Port {} oper state must be down before setting loopback".format(hex(log_port))

    logging.debug("Setting port's {} mode to AGB loopback".format(hex(log_port)))
    local_port = get_local_port(log_port)

    pplr_id = 0x5018
    port_type_offset = 0x0
    lp_msb_offset = 0x1
    local_port_offset = 0x2
    lb_en_offset = 0x4
    pplr_port_type = port_type
    lb_en = 0x2

    meta = get_meta()
    meta.access_cmd = SXD_ACCESS_CMD_SET

    pplr_raw_reg = ku_raw_reg()
    pplr_raw_reg.size = 0x100
    pplr_raw_reg.buff = new_uint8_t_arr(pplr_raw_reg.size)
    clear_raw_reg(pplr_raw_reg, pplr_raw_reg.size)

    local_port_lsb, local_port_msb = get_lsb_msb_of_local_port(local_port)

    uint8_t_arr_setitem(pplr_raw_reg.buff, local_port_offset, local_port_lsb)
    uint8_t_arr_setitem(pplr_raw_reg.buff, lp_msb_offset, ((local_port_msb & 0x3) << 4))
    uint8_t_arr_setitem(pplr_raw_reg.buff, lb_en_offset, lb_en)
    uint8_t_arr_setitem(pplr_raw_reg.buff, port_type_offset, ((pplr_port_type & 0xF) << 4))

    get_access_reg_raw(pplr_raw_reg, meta, pplr_id, 'pplr')


def set_port_loop_back_mode(handle, log_port, state):
    sxd_access_reg_init(0, None, 1)
    if state == "enable":
        set_pplr_raw_reg_data(handle, log_port)
    else:
        rc = sx_api_port_phys_loopback_set(handle, log_port, SX_PORT_PHYS_LOOPBACK_DISABLE)
    sxd_access_reg_deinit()


def rstp_port_state_set(handle, log_port, mstp_state):
    rc = sx_api_rstp_port_state_set(handle, log_port, mstp_state)
    check_rc(rc, "Failed to configure RSTP port state.")


def vlan_port_ingress_filter_set(handle, log_port, ingress_filter):
    logging.debug('Calling sx_api_vlan_port_ingr_filter_set. log_port: 0x{:x}, filter: {}'.format(
        log_port, ingress_filter))
    rc = sx_api_vlan_port_ingr_filter_set(handle, log_port, ingress_filter)
    check_rc(rc, 'sx_api_vlan_port_ingr_filter_set failed.')


def set_vlan_port_pvid(handle, log_port, vlan_id):
    logging.debug("Setting port 0x{:x} pvid to {}".format(log_port, vlan_id))
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_id)
    check_rc(rc, "sx_api_vlan_port_pvid_set failed.")


def vlan_set(handle, cmd, vlan_id):
    vlan_list_p = new_sx_vlan_id_t_arr(1)
    sx_vlan_id_t_arr_setitem(vlan_list_p, SWID, vlan_id)
    data_cnt_p = copy_uint32_t_p(1)
    try:
        rc = sx_api_vlan_set(handle, cmd, SWID, vlan_list_p, data_cnt_p)
        check_rc(rc, "sx_api_vlan_set failed.")
    finally:
        delete_sx_vlan_id_t_arr(vlan_list_p)
        delete_uint32_t_p(data_cnt_p)


def add_vlan(handle, vlan_id):
    vlan_set(handle, SX_ACCESS_CMD_ADD, vlan_id)


def del_vlan(handle, vlan_id):
    vlan_set(handle, SX_ACCESS_CMD_DELETE, vlan_id)


def add_ports_to_vlan(handle, vlan_id, swid, ports_dict):
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, swid, vlan_id, port_list, len(ports_dict))
    check_rc(rc, "Failed to add ports to Vlan.")


def remove_ports_from_vlan(handle, vlan_id, swid, ports_dict):
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, swid, vlan_id, port_list, len(ports_dict))
    check_rc(rc, "Failed to remove ports from Vlan.")


def get_vlan_count_swid(handle, swid):
    data_cnt = copy_uint32_t_p(0)
    vlan_list = None
    try:
        rc = sx_api_vlan_get(handle, swid, None, data_cnt)
        check_rc(rc, "sx_api_vlan_get failed.")
        count = uint32_t_p_value(data_cnt)
    finally:
        delete_uint32_t_p(data_cnt)


def port_delete(handle, port, vlan=1):
    swid = port_swid_bind_get(handle, port)
    if swid != SWID:
        return

    logging.debug("Deleting port:0x%x swid:%d" % (port, swid))
    # ports must be in DOWN state
    port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    # remove ports from vlan
    remove_ports_from_vlan(handle, vlan, swid, {port: SX_UNTAGGED_MEMBER})
    # de-init ports
    port_init_handle(handle, port, is_init=False)
    # un-bind ports
    port_swid_bind_set(handle, port, UNBIND_SWID)


def port_create(handle, port, port_mapping_dict, vlan=1):
    port_mapping_attr_set(handle, port, port_mapping_dict["width"], port_mapping_dict["module_port"], port_mapping_dict["lane_bmap"], port_mapping_dict["slot_id"])

    swid = port_swid_bind_get(handle, port)
    if swid != SWID:
        port_swid_bind_set(handle, port, SWID)
    port_init_handle(handle, port, is_init=True)
    port_rate_configuration(handle, port, 'auto')
    rstp_port_state_set(handle, port, SX_MSTP_INST_PORT_STATE_FORWARDING)
    set_vlan_port_pvid(handle, port, vlan)
    vlan_port_ingress_filter_set(handle, port, SX_INGR_FILTER_ENABLE)
    add_ports_to_vlan(handle, vlan, SWID, {port: SX_UNTAGGED_MEMBER})
    port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)

    logging.debug("Created port:0x%x swid:%d" % (port, SWID))


######################################################
#   SDK API Wrappers
######################################################

def mgmt_lib_verbosity_set(handle, module_verbosity_level, api_verbosity_level):
    sx_mgmt_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)


def slot_ini_oper_set(handle, slot_id, op):
    operation_result_dict = {}
    port_list_dict = {}
    operation_result_p = new_sx_mgmt_slot_ini_operation_result_t_p()
    operation_result = sx_mgmt_slot_ini_operation_result_t()
    operation_result.port_info.port_attr_list_p = new_sx_port_attributes_t_arr(MAX_PHYPORT_NUM)
    operation_result.port_info.port_attr_list_size = MAX_PHYPORT_NUM
    sx_mgmt_slot_ini_operation_result_t_p_assign(operation_result_p, operation_result)

    try:
        rc = sx_mgmt_slot_ini_operation_set(handle, slot_id, op, operation_result_p)
        check_rc(rc, "Failed sx_mgmt_slot_ini_oper_set")
        operation_result = sx_mgmt_slot_ini_operation_result_t_p_value(operation_result_p)
        operation_result_dict['ini_status'] = operation_result.ini_status
        operation_result_dict['slot_id'] = operation_result.slot_state_info.slot_id
        operation_result_dict['provisioned'] = operation_result.slot_state_info.is_slot_card_provisioned
        operation_result_dict['valid'] = operation_result.slot_state_info.is_slot_card_valid
        operation_result_dict['ready'] = operation_result.slot_state_info.is_slot_card_ready
        operation_result_dict['active'] = operation_result.slot_state_info.is_slot_card_active
        operation_result_dict['port_cnt'] = operation_result.port_info.port_count

        port_attr_list_arr = operation_result.port_info.port_attr_list_p
        port_attr_list_size = operation_result.port_info.port_attr_list_size
        for x in range(0, operation_result.port_info.port_count):
            port_attr = sx_port_attributes_t_arr_getitem(port_attr_list_arr, x)
            log_port = port_attr.log_port
            port_list_dict[log_port] = port_mapping_parse(port_attr.port_mapping)

        return operation_result_dict, port_list_dict
    finally:
        delete_sx_port_attributes_t_arr(operation_result.port_info.port_attr_list_p)
        delete_sx_mgmt_slot_ini_operation_result_t_p(operation_result_p)


def slot_ini_status_get(handle, slot_id):
    slot_ini_content = sx_mgmt_slot_ini_data_t()
    slot_ini_content.ini_data_size = 0

    slot_ini_data_p = new_sx_mgmt_slot_ini_data_t_p()
    sx_mgmt_slot_ini_data_t_p_assign(slot_ini_data_p, slot_ini_content)

    transfer_result_p = new_sx_mgmt_slot_ini_transfer_result_t_p()
    transfer_result = sx_mgmt_slot_ini_transfer_result_t()
    sx_mgmt_slot_ini_transfer_result_t_p_assign(transfer_result_p, transfer_result)

    try:
        rc = sx_mgmt_slot_ini_data_set(handle, slot_id, slot_ini_data_p, transfer_result_p)
        check_rc(rc, "Failed sx_mgmt_slot_ini_data_set")

        transfer_result = sx_mgmt_slot_ini_transfer_result_t_p_value(transfer_result_p)
        transfer_result_dict = {'ini_status': transfer_result.ini_status,
                                'ini_oper_status': transfer_result.ini_oper_status,
                                }
        return transfer_result_dict

    except BaseException:
        raise

    finally:
        delete_sx_mgmt_slot_ini_transfer_result_t_p(transfer_result_p)
        delete_sx_mgmt_slot_ini_data_t_p(slot_ini_data_p)


def slot_init_data_set_chunk(handle, slot_id, slot_ini_data_p, max_retries=10):
    transfer_result_p = new_sx_mgmt_slot_ini_transfer_result_t_p()
    transfer_result = sx_mgmt_slot_ini_transfer_result_t()
    sx_mgmt_slot_ini_transfer_result_t_p_assign(transfer_result_p, transfer_result)

    for _ in range(max_retries):
        try:
            rc = sx_mgmt_slot_ini_data_set(handle, slot_id, slot_ini_data_p, transfer_result_p)
            check_rc(rc, "Failed sx_mgmt_slot_ini_data_set")
            transfer_result = sx_mgmt_slot_ini_transfer_result_t_p_value(transfer_result_p)
            if transfer_result.ini_oper_status in [IDLE, READY_NEXT, APPLY_READY]:
                logging.debug("Transfered data chunk without error")
                return transfer_result.ini_oper_status
            if transfer_result.ini_status in [VALID]:
                return transfer_result.ini_oper_status
            if transfer_result.ini_oper_status in [FAILURE, INI_ERROR]:
                raise Exception("Transfer failed")

        except BaseException:
            raise


def slot_ini_data_xfer_file_obj_get(ops, slot_id, ini_path):
    ini_file_obj = None
    if ops == 'pre_provision' or ops == 'upgrade' or ops == 'provision':

        # Pre-provision done without ini path .
        if ini_path is None:
            print("%s attempted for slot(%d) without INI file." % (ops, slot_id))

        if ini_path is not None:
            # Pre-provision done with ini path
            if os.path.exists(ini_path) == False:
                raise Exception("Ini does not exist")

            ini_file_obj = open(ini_path, "rb")
            print("Attempting %s of slot(%d) with INI file - %s." % (ops, slot_id, ini_path))

    elif ini_path is None:
        ini_path = get_path(EEPROM_INI_PATH, slot_id)
        if os.path.exists(ini_path) == False:
            raise Exception("EEPROM Ini does not exist")

        ini_file_obj = open(ini_path, "rb")
        print("Attempting %s of slot(%d) with card EEPROM INI file - %s." % (ops, slot_id, ini_path))

    if ini_file_obj is None:
        raise Exception("INI file not found.")

    return ini_file_obj


def slot_ini_data_set(handle, slot_id, ini_obj):
    try:
        data = ini_obj.read()

        offset = 0
        data_len = len(data)
        total_offset = 0

        while total_offset < data_len:
            ini_content = sx_mgmt_slot_ini_data_t()
            ini_content.ini_data = new_uint8_t_arr(MAX_INI_DATA_SIZE)
            cur_offset = 0
            # take chunks of 1024 bytes.
            for i, byte in enumerate(data, start=total_offset):
                bin_byte = struct.unpack('B', data[i])[0]
                idx = i % MAX_INI_DATA_SIZE
                uint8_t_arr_setitem(ini_content.ini_data, idx, bin_byte)
                cur_offset = cur_offset + 1
                if (cur_offset % MAX_INI_DATA_SIZE == 0 or cur_offset + total_offset == data_len):
                    break

            ini_content.ini_data_size = cur_offset
            total_offset = total_offset + cur_offset

            if total_offset == data_len:
                ini_content.is_last_chunk = True
            else:
                ini_content.is_last_chunk = False

            ini_content_p = new_sx_mgmt_slot_ini_data_t_p()
            sx_mgmt_slot_ini_data_t_p_assign(ini_content_p, ini_content)
            slot_init_data_set_chunk(handle, slot_id, ini_content_p)
            delete_sx_mgmt_slot_ini_data_t_p(ini_content_p)

    finally:
        ini_obj.close()


def slot_state_info_get(handle, slot_id):

    slot_id_list_p = new_sx_slot_id_t_arr(1)
    slot_info_list_p = new_sx_mgmt_slot_state_info_t_arr(1)
    slot_info_cnt_p = copy_uint32_t_p(1)
    slot_state_info_list_dict = {}

    try:
        sx_slot_id_t_arr_setitem(slot_id_list_p, 0, slot_id)
        rc = sx_mgmt_slot_state_info_get(handle, slot_id_list_p, slot_info_list_p, slot_info_cnt_p)
        check_rc(rc, "Failed slot_state_get")

        slot_state_info_list_dict = {'slot_id': slot_info_list_p.slot_id,
                                     'is_provisioned': slot_info_list_p.is_slot_card_provisioned,
                                     'is_valid': slot_info_list_p.is_slot_card_valid,
                                     'is_ready': slot_info_list_p.is_slot_card_ready,
                                     'is_active': slot_info_list_p.is_slot_card_active
                                     }

        return slot_state_info_list_dict

    finally:
        delete_sx_slot_id_t_arr(slot_id_list_p)
        delete_sx_mgmt_slot_state_info_t_arr(slot_info_list_p)
        delete_uint32_t_p(slot_info_cnt_p)


def slot_info_get(handle, slot_id):
    slot_id_list_p = new_sx_slot_id_t_arr(1)
    slot_info_list_p = new_sx_mgmt_slot_info_t_arr(1)
    slot_info_cnt_p = copy_uint32_t_p(1)
    slot_info_list_dict = {}

    try:
        sx_slot_id_t_arr_setitem(slot_id_list_p, 0, slot_id)
        rc = sx_mgmt_slot_info_get(handle, slot_id_list_p, slot_info_list_p, slot_info_cnt_p)
        check_rc(rc, "Failed sx_mgmt_slot_info_get")

        slot_info_list_dict = {'slot_id': slot_info_list_p.slot_id,
                               'type': slot_info_list_p.slot_description.slot_card_type,
                               'name': slot_info_list_p.slot_description.slot_card_name,
                               'ini_version_major': slot_info_list_p.slot_description.slot_card_ini_info.slot_card_hw_revision,
                               'ini_version_minor': slot_info_list_p.slot_description.slot_card_ini_info.slot_card_minor_ini_version,
                               'device_count': slot_info_list_p.dev_description.slot_device_count,
                               }

        return slot_info_list_dict

    finally:
        delete_sx_slot_id_t_arr(slot_id_list_p)
        delete_sx_mgmt_slot_info_t_arr(slot_info_list_p)
        delete_uint32_t_p(slot_info_cnt_p)


def slot_control_set(handle, slot_id, operation):
    slot_control_info_p = new_sx_mgmt_slot_control_info_t_p()
    slot_control_info = sx_mgmt_slot_control_info_t()
    slot_control_info.operation = operation
    sx_mgmt_slot_control_info_t_p_assign(slot_control_info_p, slot_control_info)
    try:
        rc = sx_mgmt_slot_control_set(handle, slot_id, slot_control_info_p)
        check_rc(rc, "Failed sx_mgmt_control_set")

    finally:
        delete_sx_mgmt_slot_control_info_t_p(slot_control_info_p)


def slot_control_activate(handle, slot_id):
    slot_control_set(handle, slot_id, SX_MGMT_SLOT_CONTROL_OPERATION_ACTIVATE_E)


def slot_control_soft_reset(handle, slot_id):
    slot_control_set(handle, slot_id, SX_MGMT_SLOT_CONTROL_OPERATION_SOFT_RESET_E)


def sx_mgmt_phy_module_split_get(handle, slot_id, module_id, split_num):

    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = slot_id
    module_info.module_id = module_id
    module_info_p = new_sx_mgmt_module_id_info_t_p()
    sx_mgmt_module_id_info_t_p_assign(module_info_p, module_info)

    split_params = sx_mgmt_phy_module_split_params_t()
    split_params.split_num = split_num
    split_params_p = new_sx_mgmt_phy_module_split_params_t_p()
    sx_mgmt_phy_module_split_params_t_p_assign(split_params_p, split_params)

    split_info_p = new_sx_mgmt_phy_module_split_info_t_p()

    try:
        rc = sx_mgmt_phy_module_split_get(hamdle, module_info_p, split_params_p, split_info_p)
        check_rc(rc, "Failed sx_mgmt_phy_module_split_get")
        split_info = sx_mgmt_phy_module_split_info_t_p_value(split_info_p)
        port_attribs_list = []
        for i in range(split_num):
            port_attribs_list.append(sx_port_attributes_t_arr_getitem(split_info.port_attribs_list, i))

        split_info_dict = {
            'port_width': split_info.port_width,
            'port_attrib': port_attribs_list
        }

        return split_info_dict

    finally:
        delete_sx_mgmt_module_id_info_t_p(module_info_p)
        delete_sx_mgmt_phy_module_split_params_t_p(split_params_p)
        delete_sx_mgmt_phy_module_split_info_t_p(split_info_p)


def phy_module_info_get(handle, slot_id, module_id):

    module_info = sx_mgmt_module_id_info_t()
    module_info.slot_id = slot_id
    module_info.module_id = module_id
    module_info_list_p = new_sx_mgmt_module_id_info_t_arr(1)
    sx_mgmt_module_id_info_t_arr_setitem(module_info_list_p, 0, module_info)
    phy_module_info_p = new_sx_mgmt_phy_module_info_t_arr(1)

    try:
        rc = sx_mgmt_phy_module_info_get(handle, module_info_list_p, 1, phy_module_info_p)
        check_rc(rc, "Failed sx_mgmt_phy_module_info_get")

        phy_module_info_dict = {
            'module_type': phy_module_info_p.module_type,
            'module_width': phy_module_info_p.module_width,
        }

        return phy_module_info_dict

    finally:
        delete_sx_mgmt_module_id_info_t_arr(module_info_list_p)
        delete_sx_mgmt_phy_module_info_t_arr(phy_module_info_p)


def port_info_get(handle, log_port):

    port_log_id_list_p = new_sx_port_log_id_t_arr(1)
    sx_port_log_id_t_arr_setitem(port_log_id_list_p, 0, log_port)

    port_info_p = new_sx_mgmt_port_info_t_arr(1)

    try:
        rc = sx_mgmt_port_info_get(handle, port_log_id_list_p, 1, port_info_p)
        check_rc(rc, "Failed sx_mgmt_port_info_get")

        port_info_dict = {
            'slot_id': port_info_p.module_id_info.slot_id,
            'module_id': port_info_p.module_id_info.module_id,
            'label_info': port_info_p.label_info,
            'label_port': port_info_p.panel_info.label_port,
            'split_num': port_info_p.panel_info.split_num,
        }

        return port_info_dict

    finally:
        delete_sx_port_log_id_t_arr(port_log_id_list_p)
        delete_sx_mgmt_port_info_t_arr(port_info_p)


def system_info_get(handle):

    system_info_p = new_sx_mgmt_slot_system_info_t_p()

    try:
        rc = sx_mgmt_system_info_get(handle, system_info_p)
        check_rc(rc, "Failed sx_mgmt_system_info_get")
        system_info = sx_mgmt_slot_system_info_t_p_value(system_info_p)
        logging.info("System has [%d] slots:" % system_info.slot_count)

        return system_info.slot_count

    finally:
        delete_sx_mgmt_slot_system_info_t_p(system_info_p)


def port_state_set(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    check_rc(rc, "Failed to change port state.")


def port_init_handle(handle, port, is_init=True):
    if is_init:
        rc = sx_api_port_init_set(handle, port)
        check_rc(rc, "Failed to init port")
    else:
        rc = sx_api_port_deinit_set(handle, port)
        check_rc(rc, "Failed to de-init port")


def port_swid_bind_set(handle, port, swid):
    rc = sx_api_port_swid_bind_set(handle, port, swid)
    check_rc(rc, "Failed to bind port.")


def port_unmapping_set(handle, port, module, slot_id, log_port_cnt=1):

    local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)

    log_port_list_arr = new_sx_port_log_id_t_arr(log_port_cnt)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(log_port_cnt)
    mapping_item = new_sx_port_mapping_t_arr(1)
    for i in range(0, log_port_cnt):
        mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, i)
        mapping_item.local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
        mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE
        mapping_item.module_port = module
        mapping_item.width = 0
        mapping_item.lane_bmap = 0
        mapping_item.slot = slot_id
    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)
    try:
        rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, log_port_cnt)
        check_rc(rc, "Failed to disable mapping.")
        print("Removed Port:0x%x Local port:%d Slot:%d Module:%d" % (port, local_port, slot_id, module))

    finally:
        delete_sx_port_log_id_t_arr(log_port_list_arr)
        delete_sx_port_mapping_t_arr(port_mapping_list_p)


def port_mapping_attr_set(handle, port, width, module, lane_bmap, slot_id):

    local_port = ((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS)
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)

    port_mapping_list_p = new_sx_port_mapping_t_arr(1)
    mapping_item = new_sx_port_mapping_t_arr(1)

    mapping_item = sx_port_mapping_t_arr_getitem(port_mapping_list_p, 0)
    mapping_item.local_port = local_port
    mapping_item.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE
    mapping_item.width = width
    mapping_item.module_port = module
    mapping_item.lane_bmap = lane_bmap
    mapping_item.slot = slot_id
    sx_port_mapping_t_arr_setitem(port_mapping_list_p, 0, mapping_item)

    try:
        rc = sx_api_port_mapping_set(handle, log_port_list_arr, port_mapping_list_p, 1)
        check_rc(rc, "Failed to configure port mapping.")
        print("Added Port:0x%x Local port:%d Slot:%d Module:%d lane_bmap:0x%x" % (port, local_port, slot_id, module, lane_bmap))

    finally:
        delete_sx_port_log_id_t_arr(log_port_list_arr)
        delete_sx_port_mapping_t_arr(port_mapping_list_p)


def ports_mapping_attr_get(handle, port):
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    port_mapping_list_arr = new_sx_port_mapping_t_arr(1)
    port_cnt = 1
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)
    rc = sx_api_port_mapping_get(handle, log_port_list_arr, port_mapping_list_arr, port_cnt)
    check_rc(rc, "Failed to get port mapping attributes.")

    port_mapping_att = sx_port_mapping_t_arr_getitem(port_mapping_list_arr, 0)

    return port_mapping_att.module_port, port_mapping_att.width, port_mapping_att.lane_bmap, port_mapping_att.slot


def check_vport(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_VPORT


def check_nve(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_NVE


def check_cpu(port):
    port_type = (port & PORT_TYPE_MASK) >> PORT_TYPE_OFFSET
    return port_type & PORT_TYPE_CPU


def get_ports_swid(handle, swid=0):
    # Get ports count
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    port_attributes_list = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_get(handle, SPECTRUM_DEVICE, swid, port_attributes_list, port_cnt_p)
    check_rc(rc, 'Failed to get ports count.'
             'sx_api_port_device_get returned rc: {}'.format(port_cnt, rc))
    port_cnt = uint32_t_p_value(port_cnt_p)

    # Get ports
    port_cnt_p = new_uint32_t_p()
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    port_list = []
    uint32_t_p_assign(port_cnt_p, port_cnt)
    rc = sx_api_port_device_get(handle, SPECTRUM_DEVICE, swid, port_attributes_list, port_cnt_p)
    check_rc(rc, 'Failed to get {} ports.'
             'sx_api_port_device_get returned rc: {}'.format(port_cnt, rc))

    for i in range(port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if is_vport or is_cpu or is_nve:
            continue
        port_list.append(port_attributes.log_port)
    return port_list


def port_dev_mapping_get(handle, dev_id):
    port_attr_list_size_p = new_uint32_t_p()
    uint32_t_p_assign(port_attr_list_size_p, 0)
    port_attr_list_arr = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_mapping_get(handle, dev_id, port_attr_list_arr, port_attr_list_size_p)
    check_rc(rc, "Failed to retrieve the count of ports with valid mapping")
    port_attr_list_size = uint32_t_p_value(port_attr_list_size_p)

    port_list_dict = {}
    port_attr_list_arr = new_sx_port_attributes_t_arr(port_attr_list_size)
    port_attr_list_size_p = new_uint32_t_p()
    uint32_t_p_assign(port_attr_list_size_p, port_attr_list_size)
    rc = sx_api_port_device_mapping_get(handle, dev_id, port_attr_list_arr, port_attr_list_size_p)
    check_rc(rc, "Failed to retrieve port mapping information")

    port_attr_list_size = uint32_t_p_value(port_attr_list_size_p)

    for x in range(0, port_attr_list_size):
        port_attr = sx_port_attributes_t_arr_getitem(port_attr_list_arr, x)
        log_port = port_attr.log_port
        port_list_dict[log_port] = port_mapping_parse(port_attr.port_mapping)

    return port_list_dict


######################################################
#   Local functions
######################################################


def mcm_bootup(handle):
    slot_count_g = system_info_get(handle)
    try:
        for slot_id in range(1, slot_count_g + 1):
            slot_state_info = slot_state_info_get(handle, slot_id)
            if not slot_state_info['is_provisioned']:
                print("Chassis Manager - Manual provision is required for slotid(%d)." % (slot_id))
            else:
                print("Chassis Manager - Slotid(%d) is already provisioned, try bringup if present and verified." % (slot_id))
                if is_line_card_present(slot_id) and is_line_card_verified(slot_id):
                    # when line card is present, bring the card up.
                    print("Chassis Manager - Attempting to bring up slotid(%d)." % (slot_id))
                    mcm_line_card_bring_up(handle, slot_id)

        logging.info("Bootup operation completed: %d slots" % (slot_count_g))
        return 0

    except Exception as e:
        logging.error("Bootup failed with exception %s", str(e))
        return 1


def mcm_teardown(handle):
    try:
        for slot_id in range(1, slot_count_g + 1):
            if is_line_card_active(slot_id):
                line_card_power_off(slot_id)
                # Do we need to do anything else ?
                mcm_line_card_reset(handle, slot_id)
        return 0

    except Exception as e:
        logging.error("Teardown failed with exception %s", str(e))
        return 1


def mcm_line_card_ini_reset(handle, slot_id):
    port_list_dict = port_dev_mapping_get(handle, 1)
    slot_port_list_dict = {}

    # Delete any ports on this slot
    for port in list(port_list_dict.keys()):
        if port_list_dict[port]["slot_id"] == slot_id:
            slot_port_list_dict[port] = port_list_dict[port]
            port_delete(handle, port)

    '''
    # Some NOS may try to sleep and remove the mapping, before executing
    # un-provision. Either sleep or MBCT poll is needed to recognize when
    # port are oper down and removed from SWID(0) before removing the mapping.

    time.sleep(5)

    # Unmap ports
    for port in slot_port_list_dict.keys():
        port_unmapping_set(handle, port, slot_port_list_dict[port]["module_port"], slot_id)
    '''

    max_retries = 10
    for _ in range(max_retries):
        status = slot_ini_status_get(handle, slot_id)
        if (status['ini_status'] != SX_MGMT_SLOT_INI_STATUS_IN_USE_E):
            print("INI is not in use any more, proceed with erase....")
            break
        else:
            print("INI is in use, wait 0.5 secs again for erase....")
            time.sleep(0.5)

    if status['ini_status'] == SX_MGMT_SLOT_INI_STATUS_IN_USE_E:
        print("INI is still in use, operation failed.")
        return

    _, _ = slot_ini_oper_set(handle, slot_id, SX_MGMT_SLOT_INI_OPERATION_RESET_E)
    logging.debug("Performing Slot Reset Operation for slot[%d]", (slot_id))

    ''' below port unmap is not needed if sleep and unmapping is done
    before executing un-provision
    '''
    # Unmap ports
    for port in list(slot_port_list_dict.keys()):
        port_unmapping_set(handle, port, slot_port_list_dict[port]["module_port"], slot_id)


def mcm_line_card_ini_xfer(ops, slot_id, file_name):
    ini_obj = slot_ini_data_xfer_file_obj_get(ops, slot_id, file_name)
    slot_ini_data_set(handle, slot_id, ini_obj)
    logging.debug("Ini transfer completed without error for slot[%d]", (slot_id))


def mcm_line_card_ini_activate(handle, slot_id):
    _, port_list_dict = slot_ini_oper_set(handle, slot_id, SX_MGMT_SLOT_INI_OPERATION_APPLY_E)
    line_card_add_ports(slot_id)


def mcm_line_card_info(handle, slot_id):
    print("======Slot General Info======")
    print("Slot Id: %d" % (slot_id))
    print("Present[%d]" % (is_line_card_present(slot_id)))
    print("Verified[%d]" % (is_line_card_verified(slot_id)))
    print("Powered[%d]" % (is_line_card_powered(slot_id)))
    print("Ready[%d]" % (is_line_card_ready(slot_id)))
    print("Synced[%d]" % (is_line_card_synced(slot_id)))
    print("Active[%d]" % (is_line_card_active(slot_id)))
    print("======Slot Card Info======")
    slot_info = slot_info_get(handle, slot_id)
    slot_type_dict = get_enum_string_dict('SX_MGMT_SLOT_CARD_TYPE')
    print("Slot Card Type[%s]" % (slot_type_dict[slot_info['type']]))
    print("Slot Card Name[%s]" % (slot_info['name']))
    print("Slot Card Ini Major version[%d]" % (slot_info['ini_version_major']))
    print("Slot Card Ini Minor version[%d]" % (slot_info['ini_version_minor']))
    print("Slot Device count[%d]" % (slot_info['device_count']))
    print("======Slot State Info======")
    slot_state_info = slot_state_info_get(handle, slot_id)
    print("Card Provisioned[%d]" % (slot_state_info['is_provisioned']))
    print("Card Validity[%d]" % (slot_state_info['is_valid']))
    print("Card Ready[%d]" % (slot_state_info['is_ready']))
    print("Card Active[%d]" % (slot_state_info['is_active']))
    print("======Slot INI Info======")
    transfer_result = slot_ini_status_get(handle, slot_id)
    slot_ini_status_dict = get_enum_string_dict('SX_MGMT_SLOT_INI_STATUS')
    slot_ini_oper_status_dict = get_enum_string_dict('SX_MGMT_SLOT_INI_OPER_')
    print("Card INI Status[%s]" % (slot_ini_status_dict[transfer_result['ini_status']]))
    print("Card INI Oper Status[%s]" % (slot_ini_oper_status_dict[transfer_result['ini_oper_status']]))


def line_card_add_ports(slot_id):
    max_retries = 5
    for _ in range(max_retries):
        status = slot_ini_status_get(handle, slot_id)
        if (status['ini_status'] == SX_MGMT_SLOT_INI_STATUS_IN_USE_E):
            print("slot %d INI is in use now, proceed with port addition...." % (slot_id))
            break
        else:
            print("slot %d INI is not in use yet, wait 1 secs(max 5s) before activate...." % (slot_id))
            time.sleep(1)

    if status['ini_status'] != SX_MGMT_SLOT_INI_STATUS_IN_USE_E:
        raise Exception("slot %d INI is not in use after 5 secs" % (slot_id))

    port_list_dict = port_dev_mapping_get(handle, 1)
    for port in port_list_dict.keys():
        if port_list_dict[port]["slot_id"] == slot_id:
            port_create(handle, port, port_list_dict[port])


def line_card_loop_back_set(slot_id, state):
    port_list_dict = port_dev_mapping_get(handle, 1)
    for port in port_list_dict.keys():
        if port_list_dict[port]["slot_id"] == slot_id:
            print("Executing loopback %s on port 0x%x" % (state, port))
            port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
            set_port_loop_back_mode(handle, port, state)
            port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def mcm_line_card_action(handle, action, slot_id_str, file_name):
    slot_id = auto_int(slot_id_str)
    if action == 'reset_ini':
        print("Executing Slot control INI reset..")
        mcm_line_card_ini_reset(handle, slot_id)
    elif action == 'xfer_ini':
        print("Executing Slot control INI data transfer..")
        mcm_line_card_ini_xfer("pre_provision", slot_id, file_name)
    elif action == 'activate_ini':
        print("Executing Slot control INI activate..")
        mcm_line_card_ini_activate(handle, slot_id)
    elif action == 'reset_card':
        print("Executing Slot control reset card..")
        slot_control_soft_reset(handle, slot_id)
    elif action == 'activate_card':
        print("Executing Slot control activate card..")
        slot_control_activate(handle, slot_id)
    elif action == 'power_on':
        print("Executing Slot control power on..")
        slot_control_power_on(handle, slot_id)
    elif action == 'power_off':
        print("Executing Slot control power off...")
        line_card_power_off(handle, slot_id)
    elif action == 'enable':
        print("Executing Slot control enable...")
        line_card_enable(slot_id)
    elif action == 'disable':
        print("Executing Slot control disable...")
        line_card_disable(slot_id)
    elif action == 'addports':
        print("Executing addports ...")
        line_card_add_ports(slot_id)
    elif action == 'lb_enable':
        print("Executing loopback enable ...")
        line_card_loop_back_set(slot_id, "enable")
    elif action == 'lb_disable':
        print("Executing loopback disable ...")
        line_card_loop_back_set(slot_id, "disable")
    else:
        return 1


def mcm_line_card_ops(handle, operation, slot_id_str, file_name=None):

    slot_id = auto_int(slot_id_str)
    slot_count_g = system_info_get(handle)

    logging.debug("Performing %s linecard operation on Slot [%d]" % (operation, slot_id))

    try:
        if operation == 'provision':
            mcm_line_card_provision(handle, slot_id, operation, False, file_name)
        elif operation == 'unprovision':
            mcm_line_card_unprovision(handle, slot_id)
        elif operation == 'upgrade':
            mcm_line_card_upgrade(handle, slot_id, file_name)
        elif operation == 'bringup':
            mcm_line_card_bring_up(handle, slot_id)
        elif operation == 'teardown':
            mcm_teardown()
        elif operation == "pre_provision":
            mcm_line_card_pre_provision(handle, slot_id, file_name)
        elif operation == "query":
            mcm_line_card_info(handle, slot_id)
        else:
            return 1
        logging.info("Linecard operation %s succeded" % (operation))
        return 0

    except Exception as e:
        logging.error("Linecard operation %s failed with exception %s" % (operation, str(e)))
        return 1


def mcm_line_card_provision(handle, slot_id, ops, ignore_presence=False, file_name=None):
    # power off the linecard, do provision and then power on and enable
    if ops == 'provision':
        line_card_power_off(handle, slot_id)
        time.sleep(2)
    try:
        if not ignore_presence:
            if is_line_card_present(slot_id) != True:
                raise Exception("Line Card is not present")
            if is_line_card_verified(slot_id) != True:
                raise Exception("Line Card is not verified")

        slot_state_info_dict = slot_state_info_get(handle, slot_id)
        if slot_state_info_dict['is_provisioned']:
            print("INI upgrade operation will be executed as slot has INI already provisioned")

        mcm_line_card_ini_xfer(ops, slot_id, file_name)

        mcm_line_card_ini_activate(handle, slot_id)

        if ops == 'provision':
            mcm_line_card_bring_up(handle, slot_id)

    except Exception as e:
        logging.debug("Line Card Provisioning failed with exception %s", str(e))
        raise


def mcm_line_card_unprovision(handle, slot_id):
    mcm_line_card_ini_reset(handle, slot_id)


def mcm_line_card_upgrade(handle, slot_id, file_name):

    mcm_line_card_ini_xfer('upgrade', slot_id, file_name)

    _, port_list_dict = slot_ini_oper_set(handle, slot_id, SX_MGMT_SLOT_INI_OPERATION_APPLY_E)

    slot_state_info = slot_state_info_get(handle, slot_id)
    if not slot_state_info['is_provisioned']:
        raise Exception("Provisioning failed")
        return

    print("Upgrade for  slot(%d) with INI file - %s finished." % (slot_id, file_name))


def mcm_line_card_bring_up(handle, slot_id):
    try:
        if is_line_card_present(slot_id) != True:
            raise Exception("Line Card %d is not present" % (slot_id))
        if is_line_card_verified(slot_id) != True:
            raise Exception("Line Card %d is not verified" % (slot_id))

        slot_state_info_dict = slot_state_info_get(handle, slot_id)
        if not slot_state_info_dict['is_provisioned']:
            print("Line Card %d is not ready for bring up, not provisioned" % (slot_id))
            return 1

        if is_line_card_powered(slot_id) != True:
            try:
                line_card_power_on(slot_id)
                time.sleep(2)
                __check_powered_up_linecard(slot_id)
            except Exception as e:
                raise Exception("Line Card %d is not ready for bring up, power on problem" % (slot_id))

        line_card_enable(slot_id)

        slot_control_soft_reset(handle, slot_id)
        time.sleep(5)

        max_retries = 25
        for _ in range(max_retries):
            slot_state_info_dict = slot_state_info_get(handle, slot_id)
            if slot_state_info_dict['is_ready'] == 1:
                print("slot %d is ready, proceed with activate card...." % (slot_id))
                break
            else:
                print("slot %d is not ready yet, wait 1 secs again (max 25s) and check...." % (slot_id))
                time.sleep(1)

        slot_state_info_dict = slot_state_info_get(handle, slot_id)
        if slot_state_info_dict['is_ready'] == 0:
            raise Exception("Line Card %d is not ready for bring up after 25 secs" % (slot_id))
        if slot_state_info_dict['is_ready'] == 2:
            raise Exception("Line Card %d is not ready, error with gearbox bringup after 25 secs" % (slot_id))

        max_retries = 5
        for _ in range(max_retries):
            status = slot_ini_status_get(handle, slot_id)
            if (status['ini_status'] == SX_MGMT_SLOT_INI_STATUS_IN_USE_E):
                print("slot %d INI is in use now " % (slot_id))
                break
            else:
                print("slot %d INI is not in use yet, wait 1 secs(max 5s) before activate...." % (slot_id))
                time.sleep(1)

        if status['ini_status'] != SX_MGMT_SLOT_INI_STATUS_IN_USE_E:
            raise Exception("slot %d INI is not in use after 5 secs" % (slot_id))

        print("Going to execute activate for slot %d" % (slot_id))
        # Activate
        slot_control_activate(handle, slot_id)
        print("Executed activate for slot %d" % (slot_id))

        max_retries = 5
        for _ in range(max_retries):
            slot_state_info_dict = slot_state_info_get(handle, slot_id)
            if slot_state_info_dict['is_active'] == 1:
                print("slot %d is active now ...." % (slot_id))
                break
            else:
                print("slot %d is not active yet, wait 1 secs again (max 5s) and check...." % (slot_id))
                time.sleep(1)

        if slot_state_info_dict['is_active'] != 1:
            raise Exception("Line Card %d is not active after 5 secs" % (slot_id))

    except Exception as e:
        print("Line Card %d bringup failed with exception %s" % (slot_id, str(e)))
        # raise


def mcm_line_card_pre_provision(handle, slot_id, file_name):
    try:
        # preprovision is same as provision except the fact that line card presence is ignored.
        mcm_line_card_provision(handle, slot_id, "pre_provision", True, file_name)

    except Exception as e:
        logging.error("Pre-provision failed with exception %s", str(e))
        raise


def auto_int(x):
    return int(x, 0)


def print_help():
    print("""Example :\n
            modular_chassis_manager.py -m boot (brings up line card if present)
            modular_chassis_manager.py -m linecard -o pre_provision -f <INI file name> -s 1 (pre provision with given INI file)
            modular_chassis_manager.py -m linecard -o upgrade -f <INI file name> -s 1 (upgrade a given INI file)
            modular_chassis_manager.py -m linecard -o unprovision -s 1 (unprovision a line card)
            modular_chassis_manager.py -m linecard -o provision -s 1 -f <INI file name> (provision INI and bring up the line card.)
            modular_chassis_manager.py -m linecard -o query -s 1 (retrieve slot information)
            modular_chassis_manager.py -m linecard -a <action> -s 1 (slot control individual action)""")


def parse_args():
    parser = argparse.ArgumentParser(description='Modular Chassis Manager')
    parser.add_argument("--mode", '-m', dest="mode", choices=['boot', 'linecard'], help='Mode', required=True)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--operation', '-o', choices=['provision', 'unprovision', 'pre_provision', 'bringup', 'teardown', 'query', 'upgrade'], help="Line card operations, information")
    group.add_argument('--slot_action', '-a', choices=['reset_ini', 'xfer_ini', 'activate_ini', 'reset_card', 'activate_card', 'power_on', 'power_off', 'enable', 'disable', 'addports', 'lb_enable', 'lb_disable'], help='Slot individual action')
    parser.add_argument('--slot_id', '-s', choices=VALID_SLOT_INDEX, help='Slot Index for Line card operation [1-8]')
    parser.add_argument('--filename', '-f', help='INI file path for pre-provisioning')
    parser.add_argument('--loglevel', '-l', choices=['error', 'warning', 'info', 'debug'], help="Log Level to run script at: Default {info}")

    try:
        args = parser.parse_args()
    except SystemExit:
        print("\n\n")
        print_help()
        exit()

    if args.mode == 'linecard':
        if not args.slot_id:
            print_help()
            parser.error("Slot ID is required for linecard operations.")
            exit(1)
    return args


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    args = parse_args()
    set_log_level(args.loglevel)

    logging.info("[+] opening sdk")
    rc, handle = sx_api_open(None)
    logging.debug("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    vlan_count = get_vlan_count_swid(handle, SWID)
    if vlan_count == 0:
        add_vlan(handle, 1)

    if args.mode == 'boot':
        rc = mcm_bootup(handle)
    elif args.mode == 'linecard':
        if args.operation:
            rc = mcm_line_card_ops(handle, args.operation, args.slot_id, args.filename)
        elif args.slot_action:
            rc = mcm_line_card_action(handle, args.slot_action, args.slot_id, args.filename)
        else:
            print_help()
            print("Either operation or slot action is required.")

    sx_api_close(handle)

    if rc:
        sys.exit(1)
    else:
        logging.info("%s operation completed successfully \n", args.mode)
