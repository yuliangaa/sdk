#!/usr/bin/env python
'''
This file contains Python command example for registering,
recivieing and handling SDK health event by extracting debug information
'''
import sys
import errno
import os
import time

from python_sdk_api.sx_api import *
from test_infra_common import *
from threading import Thread
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'
parser = argparse.ArgumentParser(description='This example demonstrats how to register, \
                                              activate and handle SDK health events',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--device_id', default=1, type=lambda x: int(x, 0), help='The device id on which the health example will run')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def sx_recv(fd_p, handle):
    # recv parameters
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)

    pkt = sx_event_health_notification_t()
    pkt_p = new_sx_event_health_notification_t_p()
    sx_event_health_notification_t_p_assign(pkt_p, pkt)

    recv_info_p = new_sx_receive_info_t_p()

    print("[recv] recv SDK health notification on the fd")
    rc = sx_lib_host_ifc_recv(fd_p, pkt_p, pkt_size_p, recv_info_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sys.exit with error, rc %d" % rc))
        sys.exit(rc)

    # print the event parametes
    print(("Recv trap id: %d" % recv_info_p.trap_id))
    print(("Recv device id: %d" % recv_info_p.event_info.sdk_health.device_id))

    # call the API to take sx_api_dbg_generate_dump_extra
    dbg_params = sx_dbg_extra_info_t()
    dbg_params_p = new_sx_dbg_extra_info_t_p()
    dbg_params.dev_id = recv_info_p.event_info.sdk_health.device_id
    dbg_params.timeout_usec = 0  # not yet supported
    dbg_params.is_async = False  # not yet supported
    dbg_params.path = "/var/log/sdk_dbg"  # can be changed to any user path. path should exist preior to calling example
    dbg_params_p = copy_sx_dbg_extra_info_t_p(dbg_params)
    rc = sx_api_dbg_generate_dump_extra(handle, dbg_params_p)
    delete_sx_dbg_extra_info_t_p(dbg_params_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to generate extended debug dump for device:{0}".format(dbg_params_p.dev_id)

    print("[recv] recv done")

    # make sure the deature is re-armd
    # so that the functionality wont be influenced by the example


def main():

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    print("--------------- HOST IFC OPEN------------------------------")
    fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_open failed rc %d" % rc))
        sys.exit(rc)
    fd = sx_fd_t_p_value(fd_p)
    print(("sx_api_host_ifc_open,fd = %d rc=%d] " % (fd.fd, rc)))

    # register to recive the SDK health event, set a handler to be called
    print("registering to recive the SDK health event")
    # Register trap with host interface
    sx_user_channel_p = new_sx_user_channel_t_p()
    sx_user_channel_p.type = SX_USER_CHANNEL_TYPE_FD
    sx_user_channel_p.channel.fd = fd
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, SWID,
                                              SX_TRAP_ID_SDK_HEALTH_EVENT,
                                              sx_user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed rc %d" % rc))
        sys.exit(rc)
    print(("sx_api_host_ifc_trap_id_register_set  rc %d " % (rc)))
    delete_sx_user_channel_t_p(sx_user_channel_p)

    # open rx threads to recive the trap
    rx = Thread(target=sx_recv, args=(fd_p, handle))
    rx.setDaemon(True)
    rx.start()

    # get current fw fatal even mode for later de-configuration
    print("Get fw dump me parameter ")
    original_sx_dbg_control_params_p = new_sx_dbg_control_params_t_p()
    original_sx_dbg_control_params_p.dev_id = args.device_id
    rc = sx_api_fw_dbg_control_get(handle, original_sx_dbg_control_params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fw_dbg_control_get failed rc %d" % rc))
        sys.exit(rc)
    print(("GET : enable = %d" % original_sx_dbg_control_params_p.fw_fatal_event_config.fw_fatal_event_enable))
    print(("GET :  policy = %d" % original_sx_dbg_control_params_p.fw_fatal_event_config.auto_extraction_policy))

    # enable fw_fatal_event_mode
    sx_dbg_control_params_p = new_sx_dbg_control_params_t_p()
    sx_dbg_control_params_p.dev_id = args.device_id
    sx_dbg_control_params_p.fw_fatal_event_config.fw_fatal_event_enable = True
    sx_dbg_control_params_p.fw_fatal_event_config.auto_extraction_policy = SX_DBG_POLICY_NO_AUTO_DEBUG_EXTRACTION_E
    print("Sending debug control Enable+Test")
    rc = sx_api_fw_dbg_control_set(handle, SX_ACCESS_CMD_SET, sx_dbg_control_params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fw_dbg_control_set failed rc %d" % rc))
        sys.exit(rc)
    delete_sx_dbg_control_params_t_p(sx_dbg_control_params_p)

    # trigger a test event which will activate the handler
    sx_dbg_test_params_p = new_sx_dbg_test_params_t_p()
    sx_dbg_test_params_p.dev_id = args.device_id
    sx_dbg_test_params_p.test_type = SX_DBG_TEST_FW_FATAL_EVENT_E
    rc = sx_api_fw_dbg_test(handle, sx_dbg_test_params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fw_dbg_test failed rc %d" % rc))
        sys.exit(rc)
    delete_sx_dbg_test_params_t_p(sx_dbg_test_params_p)

    # wait for the trap to arrive
    trap_rc = 0
    rx.join(timeout=30)
    if rx.is_alive():
        print("ERROR: DBG TEST FW Fatal event trap didn't arrive!")
        trap_rc = 1
    else:
        print("Success.")

    if args.deinit:
        print("Deinit")
        rc = sx_api_fw_dbg_control_set(handle, SX_ACCESS_CMD_SET, original_sx_dbg_control_params_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

    print("[+] close host ifc recv fd")
    rc = sx_api_host_ifc_close(handle, fd_p)
    delete_sx_fd_t_p(fd_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sys.exit with error, rc %d" % rc))
        sys.exit(rc)

    print("[+] close sdk")
    rc = sx_api_close(handle)
    if rc != SX_STATUS_SUCCESS:
        print(("sys.exit with error, rc %d" % rc))
        sys.exit(rc)

    sys.exit(trap_rc or rc)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
