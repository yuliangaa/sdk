#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of rate for 8x lanes port.
logic of the example is the following:
- Reset port API type usage
- Get the current port mapping configurations
- Reset port API type usage
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import pdb

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1
MAX_PORTS = 64


ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

parser = argparse.ArgumentParser(description='sx_api_port_isolation_get API')
parser.add_argument('--egress_port', default=0x10001, type=auto_int, help='Egress port')
args = parser.parse_args()

print("Egress port: 0x%x" % args.egress_port)

# file_exist = os.path.isfile(ERR_FILE_LOCATION)
# sys.stderr = open(ERR_FILE_LOCATION, 'w')
# if not file_exist:
#     os.chmod(ERR_FILE_LOCATION, 0o777)

######################################################
#    functions
######################################################


def get_chip_type_and_rev():
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(rc)
    mgir = ku_mgir_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = SWID
    meta.access_cmd = SXD_ACCESS_CMD_GET
    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert SX_STATUS_SUCCESS == rc, "sxd_access_reg_mgir failed; rc=%d" % rc
    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def main():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    ingress_ports_arr = new_sx_port_log_id_t_arr(MAX_PORTS)
    for i in range(MAX_PORTS):
        sx_port_log_id_t_arr_setitem(ingress_ports_arr, i, 0)

    ingress_ports_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(ingress_ports_cnt_p, MAX_PORTS)
    for i in range(MAX_PORTS):
        sx_port_log_id_t_arr_setitem(ingress_ports_arr, i, 0)
    rc = sx_api_port_isolate_get(handle, args.egress_port, ingress_ports_arr, ingress_ports_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_get failed. [%d]" % rc

    ingress_ports_cnt = uint32_t_p_value(ingress_ports_cnt_p)
    print("GET ")
    print("    Egress port:0x%x " % (args.egress_port))
    print("    Ingress port cnt:%d " % (ingress_ports_cnt))
    for i in range(ingress_ports_cnt):
        port = sx_port_log_id_t_arr_getitem(ingress_ports_arr, i)
        print("    ingress port[%d]:0x%x " % (i, port))

    print("Success.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
