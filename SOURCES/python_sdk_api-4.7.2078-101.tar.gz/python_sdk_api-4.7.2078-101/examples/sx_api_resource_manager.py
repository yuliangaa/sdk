#!/usr/bin/env python
"""
This file contains Python command example for the RESOURCE MANAGER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
	1. Get the number of data entry duplication per table type
	2. Configuration of duplication per data entry is not allowed in run
	   time at the moment. The configuration of data entries duplication
	   should take place before SDK initialization.

"""
import sys
import socket
import struct
import errno

from python_sdk_api.sx_api import *
import sys
from python_sdk_api.sxd_api import *
from test_infra_common import *

print_api_example_disclaimer()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################


######################################################
#    functions
######################################################

def get_chip_type():
    sxd_access_reg_init(0, None, SX_VERBOSITY_LEVEL_INFO)

    mgir = ku_mgir_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert SX_STATUS_SUCCESS == rc, "sxd_access_reg_mgir failed; rc=%d" % rc

    #print ("mgir_reg.hw_info.device_id = %s" % (hex(mgir.hw_info.device_id)))
    #print ("mgir_reg.hw_info.device_hw_revision = %s" % (hex(mgir.hw_info.device_hw_revision)))
    #print ("SXD_MGIR_HW_DEV_ID_SPECTRUM2 = %s" % (hex(SXD_MGIR_HW_DEV_ID_SPECTRUM2)))

    return mgir.hw_info.device_id


def rm_single_table_duplication_parameters_get(resource, sub_type=SX_SDK_SUB_TYPE_NONE_E):
    res = {}

    param_p = new_sx_sdk_table_duplication_param_t_p()
    param_p.sub_type = sub_type
    param_p.num_of_duplication = 0

    rc = sx_api_rm_entries_duplication_get(handle, resource, param_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to get parameters for %d resource type.; rc=%d" % (resource, rc)

    res['resource'] = resource
    res['sub_type'] = param_p.sub_type
    res['num_of_duplication'] = param_p.num_of_duplication

    delete_sx_sdk_table_duplication_param_t_p(param_p)
    return res


def rm_single_table_duplication_parameters_set(resource, num_of_duplication):
    param_p = new_sx_sdk_table_duplication_param_t_p()

    param_p.num_of_duplication = num_of_duplication

    if (resource == RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E) | \
       (resource == RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E):
        param_p.sub_type = SX_SDK_SUB_TYPE_DEFAULT_E
    else:
        param_p.sub_type = SX_SDK_SUB_TYPE_NONE_E

    rc = sx_api_rm_entries_duplication_set(handle, resource, param_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_rm_entries_duplication_set failed; rc=%d" % (rc)

    delete_sx_sdk_table_duplication_param_t_p(param_p)
    return rc


######################################################
#    main
######################################################
def main():

    if get_chip_type() != 0xcf6c:  # SXD_MGIR_HW_DEV_ID_SPECTRUM2
        print("\n\tDynamic Data Duplciation is supported only on Spectrum2 chip type, hence go out from example.\n")
        sys.exit(0)
    else:
        # Get the current number of entry duplication for specified resource type
        resource = RM_SDK_TABLE_TYPE_NVE_MC_LIST_E
        original_param = rm_single_table_duplication_parameters_get(resource)
        assert bool(original_param), "Failed to get %d resource parameters." % (resource)

        print(("Original number of duplication for %u resource is %u." % (resource, original_param["num_of_duplication"])))

        # Get the current number of entry duplication for another resource type
        # Default values for RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E default routes
        resource = RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E
        sub_type = SX_SDK_SUB_TYPE_DEFAULT_E
        dup = rm_single_table_duplication_parameters_get(resource, sub_type)
        assert bool(dup), "Failed to get %d resource parameters." % (resource)

        print(("Original number of duplication for %u resource sub type %u is %u." % (resource, sub_type, dup["num_of_duplication"])))

    sx_api_close(handle)


if __name__ == "__main__":
    main()
