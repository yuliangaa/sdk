#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='SXD-API PBMC max headroom example')
parser.add_argument('--local_port', default=1, type=int, help='Local port')
args = parser.parse_args()

local_port = args.local_port

print("[+] PBMC max headroom example start")
print("[+] Initializing register access")
rc = sxd_access_reg_init(0, None, 4)
assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init failed, rc: %d" % (rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

pbmc = ku_pbmc_reg()
pbmc.local_port, pbmc.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

pbmc.pnat = 0

print("[+] Querying PBMC")
rc = sxd_access_reg_pbmc(pbmc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to query PBMC register, rc: %d" % (rc)

print("====================")
print("[+] local port: ", pbmc.local_port)
print("[+] lp_msb: ", pbmc.lp_msb)
print("[+] max headroom size:", pbmc.port_buffer_size)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] PBMC max headroom example end")
