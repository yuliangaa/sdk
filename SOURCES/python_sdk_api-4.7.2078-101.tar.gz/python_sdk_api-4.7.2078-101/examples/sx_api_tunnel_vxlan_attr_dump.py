#!/usr/bin/env python
'''
This file contains Python command example for the VxLAN Tunnel Dump module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''

import sys
import errno
import os

from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse


parser = argparse.ArgumentParser(description='Tunnel Attributes Dump utility')
parser.add_argument('-t', dest='vxlan_tunnel_id', default=None, type=auto_int, help='Optional VxLAN Tunnel ID')
args = parser.parse_args()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

tunnel_input = args.vxlan_tunnel_id
tunnel_id_list = []
is_tunnel_init = False

if tunnel_input is None:
    # VXLAN
    tunnel_id_cnt_p = new_uint32_t_p()
    tunnel_id_cnt_v6_p = new_uint32_t_p()
    filter_p = new_sx_tunnel_filter_t_p()
    filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
    filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN

    uint32_t_p_assign(tunnel_id_cnt_p, 0)
    # The following is used to prevent error messages if the router is not initialized
    module_verbosity, api_verbosity = tunnel_module_verbosity_level_get(handle)
    tunnel_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_p)
    tunnel_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if tunnel module is initialized.
            print("####################################")
            print("# Tunnel Module is not initialized ")
            print("####################################")
        else:
            print("Tunnel Iterator failed with rc (%d)" % (rc))
            sys.exit(rc)
    else:
        is_tunnel_init = True
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)
        tunnel_id_list_p = new_sx_tunnel_id_t_arr(tunnel_id_cnt)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p, tunnel_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)

        # VXLAN v6
        filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
        filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6
        uint32_t_p_assign(tunnel_id_cnt_v6_p, 0)
        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt_v6 = uint32_t_p_value(tunnel_id_cnt_v6_p)
        tunnel_id_list_p_v6 = new_sx_tunnel_id_t_arr(tunnel_id_cnt_v6)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p_v6, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)

        for i in range(tunnel_id_cnt):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p, i)
            tunnel_id_list.append(tunnel_id)

        for i in range(tunnel_id_cnt_v6):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p_v6, i)
            tunnel_id_list.append(tunnel_id)
else:
    is_tunnel_init = True
    tunnel_id_cnt = 1
    tunnel_id_list = [tunnel_input]


udp_dest_port = vxlan_get_udp_dport(handle) if is_tunnel_init else "N/A"
print('-' * 50)
print("|%25s%25s" % ("VXLAN UDP Port", "|"))
print('-' * 50)
print('|%25s%25s' % (udp_dest_port, "|"))
print('-' * 50)

tunnel_attr_p = new_sx_tunnel_attribute_t_p()
ttl_data_p = new_sx_tunnel_ttl_data_t_p()
hash_data_p = new_sx_tunnel_hash_data_t_p()
counter_data_p = new_sx_tunnel_counter_t_p()

tables = []
for tunnel_id in tunnel_id_list:
    rc1 = sx_api_tunnel_get(handle, tunnel_id, tunnel_attr_p)
    if rc1 != SX_STATUS_SUCCESS:
        print("####################################")
        print("# Failed to lookup tunnel Info rc(:%d)" % (rc))
        print("####################################")
        sys.exit(1)

    tunnel_attr = sx_tunnel_attribute_t_p_value(tunnel_attr_p)

    nve_log_port = 0
    encap_underlay_rif = "N/A"
    ethertype = "N/A"
    underlay_vrid = "N/A"
    underlay_sip = "N/A"
    decap_underlay_rif = "N/A"
    ttl_cmd = "N/A"
    ttl_value = 0
    hash_cmd = "N/A"
    hash_field_type = 'UDP Source Port'
    encapsulated_pkts = 0
    decapsulated_pkts = 0
    decapsulated_errors = 0
    decapsulated_discards = 0

    type = vxlan_type_dict.get(tunnel_attr.type)
    if type is None:
        print("Unsupported tunnel type (:%d)" % (type))
        sys.exit(1)

    direction = direction_dict[tunnel_attr.direction]
    nve_log_port = hex(tunnel_attr.attributes.vxlan.nve_log_port)
    tunnel_id_str = hex(tunnel_id)
    ul_dom_type = underlay_domain_type_dict[tunnel_attr.attributes.vxlan.underlay_domain_type]
    if tunnel_attr.direction in [SX_TUNNEL_DIRECTION_ENCAP, SX_TUNNEL_DIRECTION_SYMMETRIC]:
        underlay_vrid = str(tunnel_attr.attributes.vxlan.encap.underlay_vrid)
        encap_underlay_rif = str(tunnel_attr.attributes.vxlan.encap.underlay_rif)
        underlay_sip = ip_addr_to_str(tunnel_attr.attributes.vxlan.encap.underlay_sip)

    if tunnel_attr.direction in [SX_TUNNEL_DIRECTION_DECAP, SX_TUNNEL_DIRECTION_SYMMETRIC]:
        decap_underlay_rif = str(tunnel_attr.attributes.vxlan.decap.underlay_rif)
        tag_mode = tag_mode_dict.get(tunnel_attr.attributes.vxlan.decap.tag_mode, "Invalid")
        egress_et_set = str(tunnel_attr.attributes.vxlan.decap.egress_et_set)

    ttl_data = sx_tunnel_ttl_data_t()
    ttl_data.direction = tunnel_attr.direction
    sx_tunnel_ttl_data_t_p_assign(ttl_data_p, ttl_data)
    rc2 = sx_api_tunnel_ttl_get(handle, tunnel_id, ttl_data_p)
    if (rc2 == SX_STATUS_SUCCESS):
        ttl_data = sx_tunnel_ttl_data_t_p_value(ttl_data_p)
        ttl_cmd = ttl_cmd_dict[ttl_data.ttl_cmd]
        ttl_value = ttl_data.ttl_value

    hash_data = sx_tunnel_hash_data_t()
    hash_data.hash_field_type = SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E
    sx_tunnel_hash_data_t_p_assign(hash_data_p, hash_data)
    rc3 = sx_api_tunnel_hash_get(handle, tunnel_id, hash_data_p)
    if (rc3 == SX_STATUS_SUCCESS):
        hash_data = sx_tunnel_hash_data_t_p_value(hash_data_p)
        hash_cmd = hash_cmd_dict[hash_data.hash_cmd]

    rc4 = sx_api_tunnel_counter_get(handle, SX_ACCESS_CMD_READ, tunnel_id, counter_data_p)
    if (rc4 == SX_STATUS_SUCCESS):
        counter_data = sx_tunnel_counter_t_p_value(counter_data_p)
        encapsulated_pkts = counter_data.counter.nve.encapsulated_pkts
        decapsulated_pkts = counter_data.counter.nve.decapsulated_pkts
        decapsulated_errors = counter_data.counter.nve.decapsulated_errors
        decapsulated_discards = counter_data.counter.nve.decapsulated_discards

    table = [tunnel_id_str, type, direction, nve_log_port, ul_dom_type, encap_underlay_rif, tag_mode, egress_et_set, underlay_vrid, underlay_sip, decap_underlay_rif, ttl_cmd, ttl_value, hash_cmd, hash_field_type, encapsulated_pkts, decapsulated_pkts, decapsulated_errors, decapsulated_discards]
    tables.append(table)


header = ["Tunnel ID", "Type", "Direction", "NVE Log Port", "U/L Dom Type", "Encap U/L RIF", "Tag mode", "Egress ET", "U/L VRID", "U/L SIP", "Decap U/L RIF", "TTL CMD", "TTL", "Hash CMD", "Hash Type", "Encap pkts", "Decap pkts", "Decap Err", "Decap disc"]
print('-' * 230)
print("|%10s|%15s|%10s|%13s|%12s|%14s|%10s|%10s|%17s|%14s|%8s|%6s|%11s|%15s|%11s|%11s|%11s|%11s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10], header[11], header[12], header[13], header[14], header[15], header[16], header[17]))
print('-' * 230)

for table in tables:
    print("|%10s|%15s|%10s|%13s|%12s|%14s|%10s|%10s|%17s|%14s|%8s|%6s|%11s|%15s|%11s|%11s|%11s|%11s|" % (table[0], table[1], table[2], table[3], table[4], table[5], table[6], table[7], table[8], table[9], table[10], table[11], table[12], table[13], table[14], table[15], table[16], table[17]))
    print('-' * 230)

sx_api_close(handle)
