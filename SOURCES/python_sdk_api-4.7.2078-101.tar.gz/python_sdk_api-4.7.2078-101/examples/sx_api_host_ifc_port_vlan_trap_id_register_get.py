#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_port_vlan_trap_id_register_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
register_entry_dict_list = [
    {
        "register_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV
        }
    },

    {
        "register_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_PORT,
            "key_value": {
                "port_id": 0x10001
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L3_NETDEV
        }
    },

    {
        "register_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV
        }
    },

    {
        "register_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
            "key_value": {
                "vlan_id": 100
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 100,
                    "prio": 1
                }
            }
        }
    },

    {
        "register_key": {
            "key_type": SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN,
            "key_value": {
                "vlan_id": 100
            }
        },
        "user_channel": {
            "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
            "channel": {
                "l2_tunnel_params": {
                    "dmac": 0x12345678,
                    "vid": 99,
                    "prio": 1
                }
            }
        }
    }
]


def make_register_entry_list(register_entry_dict_list):
    return_list = []

    for entry in register_entry_dict_list:
        register_entry = sx_host_ifc_register_get_entry_t()
        for key in entry:
            if key == "register_key":
                register_key = entry[key]
                for sub_key in register_key:
                    if sub_key == "key_type":
                        register_entry.register_key.key_type = register_key[sub_key]
                    elif sub_key == "key_value":
                        key_value = register_key[sub_key]
                        for sub_key2 in key_value:
                            if sub_key2 == "vlan_id":
                                register_entry.register_key.key_value.vlan_id = key_value[sub_key2]
                            elif sub_key2 == "port_id":
                                register_entry.register_key.key_value.port_id = key_value[sub_key2]

            elif key == "user_channel":
                user_channel = entry[key]
                for sub_key in user_channel:
                    if sub_key == "type":
                        register_entry.user_channel.type = user_channel[sub_key]
                    elif sub_key == "channel":
                        channel = user_channel[sub_key]
                        for sub_key2 in channel:
                            if sub_key2 == "fd":
                                fd = channel[sub_key2]
                                fd_obj = sx_fd_t()
                                for sub_key3 in fd:
                                    if sub_key3 == "fd":
                                        fd_obj.fd = fd[sub_key3]
                                    elif sub_key3 == "driver_handle":
                                        fd_obj.driver_handle = fd[sub_key3]
                                    elif sub_key3 == "valid":
                                        fd_obj.valid = fd[sub_key3]

                                register_entry.user_channel.channel.fd = fd_obj

                            elif sub_key2 == "l2_tunnel_params":
                                l2_tunnel_params = channel[sub_key2]
                                l2_tunnel_params_obj = ku_l2_tunnel_params()
                                for sub_key3 in l2_tunnel_params:
                                    if sub_key3 == "dmac":
                                        l2_tunnel_params_obj.dmac = l2_tunnel_params[sub_key3]
                                    elif sub_key3 == "vid":
                                        l2_tunnel_params_obj.vid = l2_tunnel_params[sub_key3]
                                    elif sub_key3 == "prio":
                                        l2_tunnel_params_obj.prio = l2_tunnel_params[sub_key3]

                                register_entry.user_channel.channel.l2_tunnel_params = l2_tunnel_params_obj

        return_list.append(register_entry)

    return return_list


def are_two_register_entries_equal(register_entry1, register_entry2):
    if register_entry1.register_key.key_type != register_entry2.register_key.key_type:
        return False

    if register_entry1.register_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT:
        if register_entry1.register_key.key_value.port_id != register_entry2.register_key.key_value.port_id:
            return False

    if register_entry1.register_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN:
        if register_entry1.register_key.key_value.vlan_id != register_entry2.register_key.key_value.vlan_id:
            return False

    if register_entry1.user_channel.type != register_entry2.user_channel.type:
        return False

    if register_entry1.user_channel.type == SX_USER_CHANNEL_TYPE_FD:
        if register_entry1.user_channel.channel.fd.fd != register_entry2.user_channel.channel.fd.fd:
            return False

        if register_entry1.user_channel.channel.fd.driver_handle != register_entry2.user_channel.channel.fd.driver_handle:
            return False

        if register_entry1.user_channel.channel.fd.valid and (not register_entry2.user_channel.channel.fd.valid):
            return False

        if (not register_entry1.user_channel.channel.fd.valid) and register_entry2.user_channel.channel.fd.valid:
            return False

    if register_entry1.user_channel.type == SX_USER_CHANNEL_TYPE_L2_TUNNEL:
        if register_entry1.user_channel.channel.l2_tunnel_params.dmac != register_entry2.user_channel.channel.l2_tunnel_params.dmac:
            return False

        if register_entry1.user_channel.channel.l2_tunnel_params.vid != register_entry2.user_channel.channel.l2_tunnel_params.vid:
            return False

        if register_entry1.user_channel.channel.l2_tunnel_params.prio != register_entry2.user_channel.channel.l2_tunnel_params.prio:
            return False

    return True


register_entries = make_register_entry_list(register_entry_dict_list)

for i in range(0, 5):
    rc = sx_api_host_ifc_port_vlan_trap_id_register_set(handle,
                                                        SX_ACCESS_CMD_REGISTER,
                                                        SX_SWID_ID_MIN,
                                                        SX_TRAP_ID_MIN,
                                                        register_entries[i].register_key,
                                                        register_entries[i].user_channel)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_port_vlan_trap_id_register_set failed, rc = %d" % (rc)


# get the total count
register_entry_cnt_p = new_uint32_t_p()
register_entry_list_p = new_sx_host_ifc_register_get_entry_t_arr(5)
uint32_t_p_assign(register_entry_cnt_p, 0)
rc = sx_api_host_ifc_port_vlan_trap_id_register_get(handle,
                                                    SX_ACCESS_CMD_GET,
                                                    SX_SWID_ID_MIN,
                                                    SX_TRAP_ID_MIN,
                                                    None,
                                                    None,
                                                    register_entry_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_port_vlan_trap_id_register_get failed, rc = %d" % (rc)
register_entry_cnt = uint32_t_p_value(register_entry_cnt_p)
assert register_entry_cnt == 5, "the returned count is not correct"

# get the first two entries
uint32_t_p_assign(register_entry_cnt_p, 2)
rc = sx_api_host_ifc_port_vlan_trap_id_register_get(handle,
                                                    SX_ACCESS_CMD_GET_FIRST,
                                                    SX_SWID_ID_MIN,
                                                    SX_TRAP_ID_MIN,
                                                    None,
                                                    register_entry_list_p,
                                                    register_entry_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_port_vlan_trap_id_register_get failed, rc = %d" % (rc)
register_entry_cnt = uint32_t_p_value(register_entry_cnt_p)
assert register_entry_cnt == 2, "the returned count is not correct"
assert are_two_register_entries_equal(sx_host_ifc_register_get_entry_t_arr_getitem(register_entry_list_p, 0), register_entries[2]), "the returned register entries are incorrect"
assert are_two_register_entries_equal(sx_host_ifc_register_get_entry_t_arr_getitem(register_entry_list_p, 1), register_entries[0]), "the returned register entries are incorrect"

# get the next three entries after an entry
uint32_t_p_assign(register_entry_cnt_p, 3)
rc = sx_api_host_ifc_port_vlan_trap_id_register_get(handle,
                                                    SX_ACCESS_CMD_GETNEXT,
                                                    SX_SWID_ID_MIN,
                                                    SX_TRAP_ID_MIN,
                                                    register_entries[0],
                                                    register_entry_list_p,
                                                    register_entry_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_port_vlan_trap_id_register_get failed, rc = %d" % (rc)
register_entry_cnt = uint32_t_p_value(register_entry_cnt_p)
assert register_entry_cnt == 3, "the returned count is not correct"
assert are_two_register_entries_equal(sx_host_ifc_register_get_entry_t_arr_getitem(register_entry_list_p, 0), register_entries[1]), "the returned register entries are incorrect"
assert are_two_register_entries_equal(sx_host_ifc_register_get_entry_t_arr_getitem(register_entry_list_p, 1), register_entries[4]), "the returned register entries are incorrect"
assert are_two_register_entries_equal(sx_host_ifc_register_get_entry_t_arr_getitem(register_entry_list_p, 2), register_entries[3]), "the returned register entries are incorrect"

if args.deinit:
    # deregister the entries
    for i in range(0, 5):
        rc = sx_api_host_ifc_port_vlan_trap_id_register_set(handle,
                                                            SX_ACCESS_CMD_DEREGISTER,
                                                            SX_SWID_ID_MIN,
                                                            SX_TRAP_ID_MIN,
                                                            register_entries[i].register_key,
                                                            register_entries[i].user_channel)
        assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_port_vlan_trap_id_register_set failed, rc = %d" % (rc)

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
