#!/usr/bin/env python
'''
This file contains Python command example for the PORT COUNTER DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse

print_api_example_disclaimer()


def need_to_be_printed(cnt_value, cnt_type):
    is_cntr_zero = check_counter_are_zero(cnt_value)
    if print_active_only == False or is_cntr_zero == False:
        if type == 'all' or type == cnt_type:
            return 1
    return 0


def print_all_attr_of_struct(struct):
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            if print_active_only and int(getattr(struct, attr)) == 0:
                continue
            print("%s = %s" % (attr, getattr(struct, attr)))


def check_counter_are_zero(struct):
    total = 0
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            total += int(getattr(struct, attr))

    if total == 0:
        return True

    return False


ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

parser = argparse.ArgumentParser(description='Port Counter dump utility')
parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Logical port ID')
parser.add_argument('--clear', default='false', choices=['true', 'false'], help='Whether to clear the counters')
parser.add_argument('-a', action='store_true', help='display only active counter set (have non zero counters)')
parser.add_argument('--type', default='all', choices=['all', 'ieee802_3', 'rfc2863', 'rfc2819', 'rfc3635', 'cli', 'perf', 'discard', 'phy_layer', 'prio', 'traffic', 'buffer', 'state_event_delay'], help='display specific counter set')
args = parser.parse_args()

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

log_port_input = args.log_port
print_active_only = args.a

type = args.type


if args.clear == 'true':
    print_modification_warning()

if args.clear == 'true':
    rc = sx_api_port_counter_clear_set(handle, log_port_input, 0, SX_PORT_CNTR_GRP_ALL)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_counter_clear_set failed, rc = %d" % (rc))
        sys.exit(rc)

    cntr_state_event_delay = sx_port_state_event_delay_counters_t()
    rc = sx_api_port_state_event_delay_counter_get(handle, SX_ACCESS_CMD_READ_CLEAR, log_port_input, cntr_state_event_delay)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_state_event_delay_counter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    print("Port 0x%x counters cleared" % (log_port_input))
    sys.exit(rc)

device_info_cnt_p = new_uint32_t_p()
uint32_t_p_assign(device_info_cnt_p, 0)
rc = sx_api_port_device_list_get(handle, None, device_info_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_device_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
device_info_cnt = uint32_t_p_value(device_info_cnt_p)
device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_device_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
device_info_cnt = uint32_t_p_value(device_info_cnt_p)

swid_cnt_p = new_uint32_t_p()
uint32_t_p_assign(swid_cnt_p, 0)
rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)
swid_list_p = new_sx_swid_t_arr(swid_cnt)
rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)

cnt_802_dot_3 = sx_port_cntr_ieee_802_dot_3_t()
cntr_rfc_2863 = sx_port_cntr_rfc_2863_t()
cntr_rfc_2819 = sx_port_cntr_rfc_2819_t()
cntr_rfc_3635 = sx_port_cntr_rfc_3635_t()
cntr_cli = sx_port_cntr_cli_t()
cntr_perf = sx_port_cntr_perf_t()
cntr_discard = sx_port_cntr_discard_t()
cntr_prio = sx_port_cntr_prio_t()
cntr_tc = sx_port_traffic_cntr_t()
cntr_buff = sx_port_cntr_buff_t()
cntr_phy_layer = sx_port_cntr_phy_layer_t()
cntr_state_event_delay = sx_port_state_event_delay_counters_t()

for i in range(0, device_info_cnt):
    device_info = sx_device_info_t_arr_getitem(device_info_list_p, i)
    device_id = device_info.dev_id
    for j in range(0, swid_cnt):
        swid = sx_swid_t_arr_getitem(swid_list_p, j)
        port_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(port_cnt_p, 0)
        rc = sx_api_port_device_get(handle, device_id, swid, None, port_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_device_get failed, rc = %d" % (rc))
            sys.exit(rc)
        port_cnt = uint32_t_p_value(port_cnt_p)
        port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
        rc = sx_api_port_device_get(handle, device_id, swid, port_attributes_list, port_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_device_get failed, rc = %d" % (rc))
            sys.exit(rc)
        port_cnt = uint32_t_p_value(port_cnt_p)
        for k in range(0, port_cnt):
            port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, k)
            log_port = port_attributes.log_port
            is_nve = check_nve(int(log_port))
            is_cpu = check_cpu(int(log_port))
            is_vport = check_vport(int(log_port))
            if is_nve or is_vport or is_cpu:
                continue

            if log_port_input == log_port:

                rc = sx_api_port_counter_ieee_802_dot_3_get(handle, SX_ACCESS_CMD_READ, log_port, cnt_802_dot_3)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_ieee_802_dot_3_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cnt_802_dot_3, 'ieee802_3'):
                    print("\nPort 0x%x - IEEE 802.3 Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cnt_802_dot_3)

                rc = sx_api_port_counter_rfc_2863_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_rfc_2863)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_rfc_2863_get f/ailed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_rfc_2863, 'rfc2863'):
                    print("\nPort 0x%x - RFC 2863 Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_rfc_2863)

                rc = sx_api_port_counter_rfc_2819_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_rfc_2819)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_rfc_2819_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_rfc_2819, 'rfc2819'):
                    print("\nPort 0x%x - RFC 2819 Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_rfc_2819)

                rc = sx_api_port_counter_rfc_3635_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_rfc_3635)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_rfc_3635_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_rfc_3635, 'rfc3635'):
                    print("\nPort 0x%x - RFC 3635 Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_rfc_3635)

                rc = sx_api_port_counter_cli_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_cli)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_cli_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_cli, 'cli'):
                    print("\nPort 0x%x - CLI Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_cli)

                rc = sx_api_port_counter_perf_get(handle, SX_ACCESS_CMD_READ, log_port, SX_PORT_PRIO_ID_0, cntr_perf)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_perf_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_perf, 'perf'):
                    print("\nPort 0x%x - EXTENDED (perf) Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_perf)

                rc = sx_api_port_counter_discard_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_discard)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_discard_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_discard, 'discard'):
                    print("\nPort 0x%x - DISCARD Counters Group" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_discard)

                rc = sx_api_port_counter_phy_layer_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_phy_layer)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_counter_phy_layer_get failed, rc = %d" % (rc))
                    sys.exit(rc)

                if need_to_be_printed(cntr_phy_layer, 'symbol_errors'):
                    if type == 'all' or type == 'phy_layer':
                        print("\nPort 0x%x - PHY_LAYER Counters Group" % (log_port))
                        print("==================================================")
                        print_all_attr_of_struct(cntr_phy_layer)

                counter_caption_printed = 0
                for prio in range(SX_PORT_PRIO_ID_MIN, SX_PORT_PRIO_ID_MAX + 1):
                    rc = sx_api_port_counter_prio_get(handle, SX_ACCESS_CMD_READ, log_port, prio, cntr_prio)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_counter_prio_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    if need_to_be_printed(cntr_prio, 'prio'):
                        if counter_caption_printed == 0:
                            print("\nPort 0x%x - PER PRIO Counters Group" % (log_port))
                            print("==================================================")
                            counter_caption_printed = 1
                        print("\nPrio %d" % (prio))
                        print("----------------------")
                        print_all_attr_of_struct(cntr_prio)

                mc_aware_p = new_boolean_t_p()
                rc = sx_api_cos_port_tc_mcaware_get(handle, log_port, mc_aware_p)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_cos_port_tc_mcaware_get failed, rc = %d" % (rc))
                    sys.exit(rc)

                sx_port_max_tc_val = SX_PORT_TC_ID_MAX
                mc_aware = boolean_t_p_value(mc_aware_p)
                if mc_aware:
                    sx_port_max_tc_val = SX_PORT_TC_ID_7

                counter_caption_printed = 0
                for tc in range(SX_PORT_TC_ID_MIN, sx_port_max_tc_val + 1):
                    rc = sx_api_port_counter_tc_get(handle, SX_ACCESS_CMD_READ, log_port, tc, cntr_tc)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_counter_tc_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    if need_to_be_printed(cntr_tc, 'traffic'):
                        if counter_caption_printed == 0:
                            print("\nPort 0x%x - PER TC Counters Group" % (log_port))
                            print("==================================================")
                            counter_caption_printed = 1
                        print("\nTC %d" % (tc))
                        print("----------------------")
                        print_all_attr_of_struct(cntr_tc)

                counter_caption_printed = 0
                for buf in range(0, RM_API_COS_BUFFERS_NUM):
                    rc = sx_api_port_counter_buff_get(handle, SX_ACCESS_CMD_READ, log_port, buf, cntr_buff)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_counter_buff_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    if need_to_be_printed(cntr_buff, 'buffer'):
                        if counter_caption_printed == 0:
                            print("\nPort 0x%x - PER BUFF Counters Group" % (log_port))
                            print("==================================================")
                            counter_caption_printed = 1
                        print("\nBuff %d" % (buf))
                        print("----------------------")
                        print_all_attr_of_struct(cntr_buff)

                rc = sx_api_port_state_event_delay_counter_get(handle, SX_ACCESS_CMD_READ, log_port, cntr_state_event_delay)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_port_state_event_delay_counter_get failed, rc = %d" % (rc))
                    sys.exit(rc)
                if need_to_be_printed(cntr_state_event_delay, 'state_event_delay'):
                    print("\nPort 0x%x - State Event Delay Counters" % (log_port))
                    print("==================================================")
                    print_all_attr_of_struct(cntr_state_event_delay)

                sys.exit(rc)

print("Could not find logical port 0x%x in the device" % log_port_input)

sx_api_close(handle)
