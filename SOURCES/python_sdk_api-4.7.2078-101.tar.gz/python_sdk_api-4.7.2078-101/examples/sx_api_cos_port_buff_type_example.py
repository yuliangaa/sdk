#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

# string constants
TYPE = "TYPE"
SIZE = "SIZE"
IS_LOSSY = "LOSSY"
PG = "PG"
TC = "TC"
SP = "SP"
POOL_ID = "POOL_ID"
XON = "XON"
XOFF = "XOFF"
OVERRIDE_DEFAULT = "OVERRIDE_DEFAULT"
LATENCY = "LATENCY"
USE_SHARED_HEADROOM = "USE_SHARED_HEADROOM"
MAX_POOL_LOAN = "MAX_POOL_LOAN"


parser = argparse.ArgumentParser(description='SX-API sx_api_cos_port_buff_type GET/SET example')
parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Log port')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

log_port = args.log_port
print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def get_buff_stat():
    stat_p = new_sx_buffer_status_t_p()

    rc = sx_api_cos_buff_status_get(handle, stat_p)
    print(("sx_api_cos_buff_status_get [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    stat = sx_buffer_status_t_p_value(stat_p)

    print(("Ingress freespace [%d]" % stat.free_size_ingress))
    print(("Egress freespace [%d]" % stat.free_size_egress))


def cos_sb_buff_set(cmd, attr_params_list):
    port_buffer_attr_cnt = len(attr_params_list)
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(port_buffer_attr_cnt)

    i = 0
    for attr in attr_params_list:
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)

        if attr[TYPE] == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            attr_item_min.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
            attr_item_min.attr.ingress_port_pg_buff_attr.pg = attr[PG]
            attr_item_min.attr.ingress_port_pg_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy = attr[IS_LOSSY]
                if attr[IS_LOSSY]:
                    attr_item_min.attr.ingress_port_pg_buff_attr.xon = 0
                    attr_item_min.attr.ingress_port_pg_buff_attr.xoff = 0
                    attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom = 0

                    pipe_latency = sx_cos_buff_pipeline_latency_t()
                    if attr[OVERRIDE_DEFAULT]:
                        pipe_latency.override_default = True
                        pipe_latency.size = attr[LATENCY]
                    else:
                        pipe_latency.override_default = False
                        pipe_latency.size = 0
                    attr_item_min.attr.ingress_port_pg_buff_attr.pipeline_latency = pipe_latency
                else:
                    attr_item_min.attr.ingress_port_pg_buff_attr.xon = attr[XON]
                    attr_item_min.attr.ingress_port_pg_buff_attr.xoff = attr[XOFF]
                    attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom = attr[USE_SHARED_HEADROOM]

                attr_item_min.attr.ingress_port_pg_buff_attr.size = attr[SIZE]
            else:
                attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy = False
                attr_item_min.attr.ingress_port_pg_buff_attr.size = 0
                attr_item_min.attr.ingress_port_pg_buff_attr.xon = 0
                attr_item_min.attr.ingress_port_pg_buff_attr.xoff = 0

            print(("[%d] type  = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.size)))
            print(("[%d] PG    = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pg)))
            print(("[%d] is_lossy (0=Lossless)  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy)))
            print(("[%d] Xon  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xon)))
            print(("[%d] Xoff  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xoff)))
            print(("[%d] use_shared_headroom = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom)))
            if attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy:
                print(("[%d] override_default  = %d" % (i, pipe_latency.override_default)))
                print(("[%d] latency  = %d" % (i, pipe_latency.size)))

        elif attr[TYPE] == SX_COS_INGRESS_PORT_ATTR_E:
            attr_item_min.type = SX_COS_INGRESS_PORT_ATTR_E
            attr_item_min.attr.ingress_port_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.ingress_port_buff_attr.size = attr[SIZE]
            else:
                attr_item_min.attr.ingress_port_buff_attr.size = 0

            print(("[%d] type  = SX_COS_INGRESS_PORT_ATTR_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.size)))
            print(("[%d] Pool id    = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.pool_id)))

        elif attr[TYPE] == SX_COS_EGRESS_PORT_ATTR_E:
            attr_item_min.type = SX_COS_EGRESS_PORT_ATTR_E
            attr_item_min.attr.egress_port_buff_attr.pool_id = attr[POOL_ID]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.egress_port_buff_attr.size = attr[SIZE]
            else:
                attr_item_min.attr.egress_port_buff_attr.size = 0

            print(("[%d] type  = SX_COS_EGRESS_PORT_ATTR_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.size)))
            print(("[%d] Pool id    = %d" % (i, attr_item_min.attr.egress_port_buff_attr.pool_id)))

        elif attr[TYPE] == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            attr_item_min.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
            attr_item_min.attr.egress_port_tc_buff_attr.pool_id = attr[POOL_ID]
            attr_item_min.attr.egress_port_tc_buff_attr.tc = attr[TC]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.egress_port_tc_buff_attr.size = attr[SIZE]
            else:
                attr_item_min.attr.egress_port_tc_buff_attr.size = 0

            print(("[%d] type  = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.size)))
            print(("[%d] TC    = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.tc)))
            print(("[%d] Pool id    = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.pool_id)))

        elif attr[TYPE] == SX_COS_MULTICAST_ATTR_E:
            attr_item_min.type = SX_COS_MULTICAST_ATTR_E
            attr_item_min.attr.multicast_buff_attr.pool_id = attr[POOL_ID]
            attr_item_min.attr.multicast_buff_attr.sp = attr[SP]

            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.multicast_buff_attr.size = attr[SIZE]
            else:
                attr_item_min.attr.multicast_buff_attr.size = 0

            print(("[%d] type  = SX_COS_MULTICAST_ATTR_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.multicast_buff_attr.size)))
            print(("[%d] SP    = %d" % (i, attr_item_min.attr.multicast_buff_attr.sp)))
            print(("[%d] Pool id    = %d" % (i, attr_item_min.attr.multicast_buff_attr.pool_id)))

        elif attr[TYPE] == SX_COS_PORT_SHARED_HEADROOM_E:
            attr_item_min.type = SX_COS_PORT_SHARED_HEADROOM_E
            if cmd == SX_ACCESS_CMD_SET:
                attr_item_min.attr.port_shared_headroom_attr.max_pool_loan = attr[MAX_POOL_LOAN]
                attr_item_min.attr.port_shared_headroom_attr.shared_pool_id = attr[POOL_ID]
                attr_item_min.attr.port_shared_headroom_attr.xon = attr[XON]
                attr_item_min.attr.port_shared_headroom_attr.xoff = attr[XOFF]
                attr_item_min.attr.port_shared_headroom_attr.size = attr[SIZE]

            print(("[%d] type  = SX_COS_PORT_SHARED_HEADROOM_E" % (i)))
            print(("[%d] size  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.size)))
            print(("[%d] Xon  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.xon)))
            print(("[%d] Xoff  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.xoff)))
            print(("[%d] SHP  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.shared_pool_id)))
            print(("[%d] Max pool loan = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.max_pool_loan)))

        print("\n")

        attr_item_min = sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, i, attr_item_min)

        i = i + 1

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, port_buffer_attr_list_p, port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (cmd, log_port, port_buffer_attr_cnt, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def cos_port_buff_get_all():
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    assert(port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_buff_get(attr_params_list):
    port_buffer_attr_cnt = new_uint32_t_p()
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(len(attr_params_list))
    uint32_t_p_assign(port_buffer_attr_cnt, len(attr_params_list))

    i = 0
    """ Set type and relevant parameters """
    for attr in attr_params_list:
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
        if attr[TYPE] == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            attr_item_min.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
            attr_item_min.attr.ingress_port_pg_buff_attr.pg = attr[PG]
            attr_item_min.attr.ingress_port_pg_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_INGRESS_PORT_ATTR_E:
            attr_item_min.type = SX_COS_INGRESS_PORT_ATTR_E
            attr_item_min.attr.ingress_port_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_EGRESS_PORT_ATTR_E:
            attr_item_min.type = SX_COS_EGRESS_PORT_ATTR_E
            attr_item_min.attr.egress_port_buff_attr.pool_id = attr[POOL_ID]

        elif attr[TYPE] == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            attr_item_min.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
            attr_item_min.attr.egress_port_tc_buff_attr.pool_id = attr[POOL_ID]
            attr_item_min.attr.egress_port_tc_buff_attr.tc = attr[TC]

        elif attr[TYPE] == SX_COS_MULTICAST_ATTR_E:
            attr_item_min.type = SX_COS_MULTICAST_ATTR_E
            attr_item_min.attr.multicast_buff_attr.pool_id = attr[POOL_ID]
            attr_item_min.attr.multicast_buff_attr.sp = attr[SP]

        elif attr[TYPE] == SX_COS_PORT_BUFF_CAPABILITIES_E:
            attr_item_min.type = SX_COS_PORT_BUFF_CAPABILITIES_E

        elif attr[TYPE] == SX_COS_PORT_SHARED_HEADROOM_E:
            attr_item_min.type = SX_COS_PORT_SHARED_HEADROOM_E

        attr_item_min = sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, i, attr_item_min)

        i = i + 1

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_buffer_attr_list_p, port_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    """ Print list """
    attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
    print("--------------------------------------------------------------------")
    print(("Respond count:  %d" % (attr_cnt)))
    if len(attr_params_list) > 0:
        for i in range(0, attr_cnt):
            port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)

            if port_buffer_attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
                pipe_latency = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pipeline_latency
                print(("[%d] type  = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.size)))
                print(("[%d] PG    = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg)))
                print(("[%d] is_lossy (0=Lossless)  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.is_lossy)))
                print(("[%d] Xon  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xon)))
                print(("[%d] Xoff  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xoff)))
                print(("[%d] override_default  = %d" % (i, pipe_latency.override_default)))
                print(("[%d] latency  = %d" % (i, pipe_latency.size)))
                if port_buffer_attr_item.attr.ingress_port_pg_buff_attr.is_lossy == 0:
                    print(("[%d] use_shared_headroom  = %d" % (i, port_buffer_attr_item.attr.ingress_port_pg_buff_attr.use_shared_headroom)))

            elif port_buffer_attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
                print(("[%d] type  = SX_COS_INGRESS_PORT_ATTR_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.ingress_port_buff_attr.size)))
                print(("[%d] Pool id    = %d" % (i, port_buffer_attr_item.attr.ingress_port_buff_attr.pool_id)))
            elif port_buffer_attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
                print(("[%d] type  = SX_COS_EGRESS_PORT_ATTR_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.egress_port_buff_attr.size)))
                print(("[%d] Pool id    = %d" % (i, port_buffer_attr_item.attr.egress_port_buff_attr.pool_id)))
            elif port_buffer_attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
                print(("[%d] type  = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.size)))
                print(("[%d] TC    = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.tc)))
                print(("[%d] Pool id    = %d" % (i, port_buffer_attr_item.attr.egress_port_tc_buff_attr.pool_id)))
            elif port_buffer_attr_item.type == SX_COS_MULTICAST_ATTR_E:
                print(("[%d] type  = SX_COS_MULTICAST_ATTR_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.multicast_buff_attr.size)))
                print(("[%d] SP    = %d" % (i, port_buffer_attr_item.attr.multicast_buff_attr.sp)))
                print(("[%d] Pool id    = %d" % (i, port_buffer_attr_item.attr.multicast_buff_attr.pool_id)))
            elif port_buffer_attr_item.type == SX_COS_PORT_BUFF_CAPABILITIES_E:
                print(("[%d] type  = SX_COS_PORT_BUFF_CAPABILITIES_E" % (i)))
                print(("[%d] max supported headroom  = %d" % (i, port_buffer_attr_item.attr.port_buff_cap.ingress_port_pg_buff_cap.max_headroom_size)))
            elif port_buffer_attr_item.type == SX_COS_PORT_SHARED_HEADROOM_E:
                print(("[%d] type  = SX_COS_PORT_SHARED_HEADROOM_E" % (i)))
                print(("[%d] size  = %d" % (i, port_buffer_attr_item.attr.port_shared_headroom_attr.size)))
                print(("[%d] Xon  = %d" % (i, port_buffer_attr_item.attr.port_shared_headroom_attr.xon)))
                print(("[%d] Xoff  = %d" % (i, port_buffer_attr_item.attr.port_shared_headroom_attr.xoff)))
                print(("[%d] SHP  = %d" % (i, port_buffer_attr_item.attr.port_shared_headroom_attr.shared_pool_id)))
                print(("[%d] Max pool loan = %d" % (i, port_buffer_attr_item.attr.port_shared_headroom_attr.max_pool_loan)))
            print("\n")

######################################################
#    main
######################################################


def main():

    get_buff_stat()

    # Save for later de-configuration
    original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all()
    # get valid default ingress/egress pools id's
    ing_pool_id = -1
    egr_pool_id = -1

    for i in range(original_port_buff_attr_cnt):
        attr = sx_cos_port_buffer_attr_t_arr_getitem(original_port_buff_attr_list, i)
        if attr.type == SX_COS_INGRESS_PORT_ATTR_E and ing_pool_id == -1:
            ing_pool_id = attr.attr.ingress_port_buff_attr.pool_id
        if attr.type == SX_COS_EGRESS_PORT_ATTR_E and egr_pool_id == -1:
            egr_pool_id = attr.attr.egress_port_buff_attr.pool_id
        if ing_pool_id != -1 and egr_pool_id != -1:
            break

    """ PORT TYPE BUFF CMD: SET """
    print("\n\n---------------  PORT TYPE BUFF SET - CMD: SET -------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        IS_LOSSY: True,
                        PG: 1,
                        POOL_ID: ing_pool_id,
                        OVERRIDE_DEFAULT: 0,
                        SIZE: 20})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        IS_LOSSY: True,
                        PG: 2,
                        POOL_ID: ing_pool_id,
                        OVERRIDE_DEFAULT: 1,
                        LATENCY: 30,
                        SIZE: 20})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        IS_LOSSY: True,
                        PG: 3,
                        POOL_ID: ing_pool_id,
                        OVERRIDE_DEFAULT: 0,
                        SIZE: 20})
    # Port PG which is using the shared headroom
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        IS_LOSSY: False,
                        PG: 5,
                        XON: 100,
                        XOFF: 100,
                        SIZE: 200,
                        POOL_ID: ing_pool_id,
                        USE_SHARED_HEADROOM: 1})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                        TC: 5,
                        POOL_ID: egr_pool_id,
                        SIZE: 15})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: ing_pool_id,
                        SIZE: 15})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_ATTR_E,
                        POOL_ID: egr_pool_id,
                        SIZE: 15})

    # Port shared headroom configuration
    params_list.append({TYPE: SX_COS_PORT_SHARED_HEADROOM_E,
                        POOL_ID: 0,
                        SIZE: 123,
                        XON: 10,
                        XOFF: 20,
                        MAX_POOL_LOAN: 0})

    cos_sb_buff_set(SX_ACCESS_CMD_SET, params_list)

    get_buff_stat()

    """ PORT TYPE BUFF GET """
    print("\n\n---------------  PORT TYPE BUFF GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 3})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 5})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: ing_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_ATTR_E,
                        POOL_ID: egr_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                        TC: 0,
                        POOL_ID: egr_pool_id})

    params_list.append({TYPE: SX_COS_PORT_SHARED_HEADROOM_E})
    cos_port_buff_get(params_list)

    """ PORT TYPE BUFF CMD: DELETE """
    print("\n\n---------------  PORT TYPE BUFF SET - CMD: DELETE ----------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 5})

    params_list.append({TYPE: SX_COS_PORT_SHARED_HEADROOM_E})

    cos_sb_buff_set(SX_ACCESS_CMD_DELETE, params_list)

    get_buff_stat()

    """ PORT TYPE BUFF GET """
    print("\n\n---------------  PORT TYPE BUFF GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 5})

    params_list.append({TYPE: SX_COS_PORT_SHARED_HEADROOM_E})
    cos_port_buff_get(params_list)

    """ PORT TYPE BUFF CMD: DELETE_ALL """
    print("\n\n---------------  PORT TYPE BUFF SET - CMD: DELETE_ALL ------------")
    params_list = []
    cos_sb_buff_set(SX_ACCESS_CMD_DELETE_ALL, params_list)

    """ PORT TYPE BUFF GET """
    print("\n\n---------------  PORT TYPE BUFF GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 1})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 2})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                        POOL_ID: ing_pool_id,
                        PG: 3})
    params_list.append({TYPE: SX_COS_INGRESS_PORT_ATTR_E,
                        POOL_ID: ing_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_ATTR_E,
                        POOL_ID: egr_pool_id})
    params_list.append({TYPE: SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                        TC: 5,
                        POOL_ID: egr_pool_id})
    params_list.append({TYPE: SX_COS_PORT_SHARED_HEADROOM_E})
    cos_port_buff_get(params_list)

    """ PORT TYPE BUFF GET """
    print("\n\n---------------  PORT CAPABILITIES GET ------------------------------")
    params_list = []
    params_list.append({TYPE: SX_COS_PORT_BUFF_CAPABILITIES_E})
    cos_port_buff_get(params_list)

    if args.deinit:
        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list, original_port_buff_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)


if __name__ == "__main__":
    main()
