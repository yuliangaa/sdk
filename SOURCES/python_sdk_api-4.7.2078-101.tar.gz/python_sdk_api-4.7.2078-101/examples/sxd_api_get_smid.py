#!/usr/bin/env python
from python_sdk_api.sx_api import *
import socket
import struct


import sys
import errno
import time
import os
import argparse
from python_sdk_api.sxd_api import *

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] Reading SMID register:")
parser = argparse.ArgumentParser(description='SMID read utility')
parser.add_argument('--mid', default=1, type=int, help="MID")
args = parser.parse_args()

smid = ku_smid_reg()
smid.mid = args.mid
smid.swid = 0

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

rc = sxd_access_reg_smid(smid, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read SMID register, rc: %d" % (rc)

print("Swid: ", smid.swid)
print("mid: ", smid.mid)
print("Ports list: ")

port_flag = 0
for index in range(0, 256):
    port = uint16_t_arr_getitem(smid.ports_bitmap, index)
    if port == 1:
        port_flag = 1
        print("[" + str(index) + "]")

if port_flag == 0:
    print("* Port list is empty")

print("Opcode: ", smid.op)
print("Smpe_valid: ", smid.smpe_valid)
print("Smpe: ", smid.smpe)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
