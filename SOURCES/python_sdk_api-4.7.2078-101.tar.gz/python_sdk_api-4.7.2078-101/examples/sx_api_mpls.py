#!/usr/bin/env python
"""
This file contains Python command example for the MPLS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of mpls module.
This example is supported on Spectrum devices.
"""
import os
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import sx_api_router as sx_api_router
import argparse

parser = argparse.ArgumentParser(description='sx_api_mpls example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

# to check the current chip type we need to import required module from the 'sx_sdk_py_tests' repo
sys.path.append(os.getcwd().split("python_sdk_api")[0] + "/sx_sdk_py_tests/python_traffic_test/test_infra/")

from test_infra_common import *

import sys


######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(sx_api_router.handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

NEIGH_MAC_1 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6C, 0x81)
NEIGH_MAC_2 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x68, 0x81)
NEIGH_MAC_3 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x64, 0x81)


# string constants
RIF_STR = "RIF"
IP_STR = "IP"
LABELS_OUT_STR = "LABELS_OUT"
NEXT_HOP_TYPE_STR = "NEXT_HOP_TYPE"
WEIGHT_STR = "WEIGHT"
iRIF_STR = "iRIF"
eRIF_STR = "eRIF"
uRIF_STR = "uRIF"

trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(sx_api_router.handle)

######################################################
#    functions
######################################################


def mpls_init(tq_profile_type=0, tq_profile=2, underlay_domain=0):
    " This function init mpls. "

    general_params = sx_mpls_general_params_t()
    general_params.label_id_range_min = 100
    general_params.label_id_range_max = 888
    general_params.reserved_label_id_max = 1
    general_params.ttl_model = SX_MPLS_TTL_MODEL_TYPE_UNIFORM
    general_params.tq_profile_type = tq_profile_type
    general_params.tq_profile_data.single_profile.tq_profile = tq_profile
    general_params.underlay_domain = underlay_domain

    rc = sx_api_mpls_init_set(sx_api_router.handle, general_params)
    assert SX_STATUS_SUCCESS == rc, "Failed to init mpls"

    print("sx_api_mpls_init_set, rc: %d" % (rc))


def mpls_deinit():
    " This function deinit mpls. "

    rc = sx_api_mpls_deinit_set(sx_api_router.handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit mpls"
    print("sx_api_mpls_deinit_set, rc: %d" % (rc))


def mpls_ilm_init(vrid):
    " This function init mpls ilm. "

    cmd = SX_ACCESS_CMD_CREATE
    ilm_table = vrid

    rc = sx_api_mpls_ilm_init_set(sx_api_router.handle, cmd, ilm_table)
    assert SX_STATUS_SUCCESS == rc, "Failed to init mpls ilm"
    print("sx_api_mpls_ilm_init_set, rc: %d" % (rc))


def mpls_ilm_destroy(vrid):
    " This function destroy mpls ilm. "

    cmd = SX_ACCESS_CMD_DESTROY
    ilm_table = vrid

    rc = sx_api_mpls_ilm_init_set(sx_api_router.handle, cmd, ilm_table)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mpls ilm"
    print("sx_api_mpls_ilm_init_set, rc: %d" % (rc))


def mpls_router_interface_attributes_set(rif_arr, mpls_enabled, vrid=0):
    " This function sets the MPLS interface attributes."

    rif_mpls_attr = sx_mpls_router_interface_attr_t()
    rif_mpls_attr.mpls_enabled = mpls_enabled
    rif_mpls_attr.ilm_table_id = vrid

    for rif in rif_arr:
        rc = sx_api_mpls_router_interface_attributes_set(sx_api_router.handle, rif, rif_mpls_attr)
        assert SX_STATUS_SUCCESS == rc, "Failed to init mpls router interface attributes (%u)" % (rif)

    print("sx_api_mpls_router_interface_attributes_set, rc: %d" % (rc))


def make_mpls_ecmp_next_hop(rif, ipaddr, label_out_arr, weight, nh_type=SX_NEXT_HOP_TYPE_MPLS, eRIF=None, uRIF=None):
    " This function creates ecmp_mpls_next_hop struct with given parameters. "

    nh_key = make_sx_mpls_next_hop(rif, ipaddr, label_out_arr, nh_type, eRIF, uRIF)

    nh_data = sx_next_hop_data_t()
    nh_data.action = SX_ROUTER_ACTION_FORWARD
    nh_data.weight = weight

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = nh_data

    return next_hop


def make_sx_mpls_label_stack_entry(label_out_arr):
    " This function creates sx_mpls_label_stack_entry_t struct with given parameters. "

    mpls_label_stack_entry_arr = new_sx_mpls_label_stack_entry_t_arr(6)

    for i in range(len(label_out_arr)):
        mpls_label_entry = sx_mpls_label_stack_entry_t()
        mpls_label_entry.label = label_out_arr[i]
        sx_mpls_label_stack_entry_t_arr_setitem(mpls_label_stack_entry_arr, i, mpls_label_entry)

    return mpls_label_stack_entry_arr


def make_sx_mpls_ip_next_hop_data(rif, ipaddr):
    " This function creates sx_mpls_ip_next_hop_data_t struct with given parameters. "

    nh_sx_ip = sx_ip_next_hop_t()
    nh_sx_ip.rif = rif
    nh_sx_ip.address = sx_api_router.make_sx_ip_addr_v4(ipaddr)

    nh_mpls_ip_data = sx_mpls_ip_next_hop_data_t()
    nh_mpls_ip_data.ip_next_hop = nh_sx_ip

    return nh_mpls_ip_data


def make_sx_mpls_next_hop(rif, ipaddr, label_out_arr, nh_type=SX_NEXT_HOP_TYPE_MPLS, eRIF=None, uRIF=None):
    " This function creates sx_mpls_next_hop_t struct with given parameters. "

    nh_key = sx_next_hop_key_t()
    nh_key.type = nh_type

    if nh_type == SX_NEXT_HOP_TYPE_MPLS:
        mpls_nh = sx_mpls_next_hop_t()
        mpls_nh.type = SX_MPLS_IP_NEXT_HOP_TYPE
        mpls_nh.label_cnt = len(label_out_arr)
        mpls_nh.label_list = make_sx_mpls_label_stack_entry(label_out_arr)
        mpls_nh.mpls_next_hop_entry.ip_next_hop_data = make_sx_mpls_ip_next_hop_data(rif, ipaddr)

        nh_key.next_hop_key_entry.mpls_next_hop = mpls_nh

    return nh_key


def mpls_in_segment_create(label_in,
                           irif=0,
                           use_erif=False,
                           erif=0,
                           ecmp_container_id=0,
                           action=SX_ROUTER_ACTION_FORWARD,
                           number_of_pops=1,
                           ilm_fwd_action=SX_MPLS_ILM_GOTO_ECMP,
                           trap_id="",
                           vrid=0):
    " This function creates mpls in segment entry with given parameters. "

    cmd = SX_ACCESS_CMD_CREATE

    in_segment_key = sx_mpls_in_segment_key_t()
    in_segment_key.ilm_table = vrid
    in_segment_key.label_cnt = 1

    mpls_label_arr = new_sx_mpls_label_t_arr(2)
    sx_mpls_label_t_arr_setitem(mpls_label_arr, 0, label_in)
    in_segment_key.in_label = mpls_label_arr

    in_segment_params = sx_mpls_in_segment_params_t()
    in_segment_params.action = action
    in_segment_params.number_of_pops = number_of_pops
    in_segment_params.ilm_fwd_action = ilm_fwd_action

    if action == SX_ROUTER_ACTION_TRAP:
        trap_attributes = sx_trap_attributes_t()
        trap_attributes.prio = trap_id
        in_segment_params.trap_attr = trap_attributes

    qos_params = sx_mpls_qos_params_t()
    qos_params.remap_qos_from_inner_dscp = False
    qos_params.remap_qos_from_inner_exp = False

    if ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP:
        in_segment_params.fwd_actions_params.ecmp_id = ecmp_container_id
    elif ilm_fwd_action == SX_MPLS_ILM_GOTO_ROUTER:
        in_segment_params.fwd_actions_params.goto_router_params.irif = irif
        in_segment_params.fwd_actions_params.goto_router_paramsqos_params = qos_params

        in_segment_params.fwd_actions_params.goto_router_params.use_egress_rif = use_erif
        in_segment_params.fwd_actions_params.goto_router_params.erif = erif

    elif ilm_fwd_action == SX_MPLS_ILM_CONTINUE_LOOKUP:
        in_segment_params.fwd_actions_params.continue_lookup_params.irif = irif
        in_segment_params.fwd_actions_params.continue_lookup_params.qos_params = qos_params

        in_segment_params.fwd_actions_params.continue_lookup_params.use_egress_rif = use_erif
        in_segment_params.fwd_actions_params.continue_lookup_params.erif = erif

    else:
        raise Exception("Unsupported ilm forward action")

    rc = sx_api_mpls_in_segment_set(sx_api_router.handle, cmd, in_segment_key, in_segment_params)
    assert SX_STATUS_SUCCESS == rc, "sx_api_mpls_in_segment_set failed, rc: %d" % (rc)
    print("sx_api_mpls_in_segment_set, rc: %d" % (rc))


def mpls_in_segment_destroy(label_in, vrid=0):
    " This function destroy mpls in segment entry with given parameters. "

    cmd = SX_ACCESS_CMD_DESTROY

    in_segment_key = sx_mpls_in_segment_key_t()
    in_segment_key.ilm_table = vrid

    mpls_label_arr = new_sx_mpls_label_t_arr(2)
    sx_mpls_label_t_arr_setitem(mpls_label_arr, 0, label_in)

    in_segment_key.in_label = mpls_label_arr
    in_segment_key.label_cnt = 1

    in_segment_params = sx_mpls_in_segment_params_t()

    rc = sx_api_mpls_in_segment_set(sx_api_router.handle, cmd, in_segment_key, in_segment_params)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mpls in segment entry"
    print("sx_api_mpls_in_segment_set, rc: %d" % (rc))


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                    RIF_STR, RIF_STR, LABEL_OUT_STR.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()

    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        nh_type = SX_NEXT_HOP_TYPE_MPLS
        nh_eRIF = None
        nh_uRIF = None

        next_hop = make_mpls_ecmp_next_hop(nh[RIF_STR], nh[IP_STR],
                                           nh[LABELS_OUT_STR], nh[WEIGHT_STR],
                                           nh_type, nh_eRIF, nh_uRIF)
        next_hop_arr = sx_api_router.add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def create_empty_external_ecmp_container():
    """
    This function creates an empty external ECMP container.
    @return: ECMP container ID
    """
    uint32_ptr = new_uint32_t_p()
    uint32_t_p_assign(uint32_ptr, 0)

    nh_ptr = new_sx_next_hop_t_p()
    ecmp_id_p = new_sx_ecmp_id_t_p()

    rc = sx_api_router_ecmp_set(sx_api_router.handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_ptr, uint32_ptr)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def modify_external_ecmp_container(ecmp_id, nh_params_list=[]):
    """
    This function modify an external ECMP container with a given next hops list
    @param ecmp_id: ecmp container id.
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(sx_api_router.handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def set_ecmp_attributes(ecmp_id, ecmp_type, active_flow_timer=100, group_size=4096, max_unbalanced_time=200, container_type=SX_ECMP_CONTAINER_TYPE_IP, rif_valid=0, underlay_rif=0):
    """"
    This function sets ECMP external container attributes
    @param emcp_id: ECMP container ID
    @param type: External ECMP container type, e.g. SX_ECMP_TYPE_RESILIENT_E
    @param active_flow_timer: ECMP active flow timer
    @param groups_size:    ECMP container group size
    @param max_unbalanced_time: ECMP max unbalanced time
    @param container_type: ECMP container type, e.g. SX_ECMP_CONTAINER_TYPE_IP
    """
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = ecmp_type
    ecmp_attributes.container_type = container_type
    ecmp_attributes.active_flow_timer = active_flow_timer
    ecmp_attributes.group_size = group_size
    ecmp_attributes.max_unbalanced_time = max_unbalanced_time
    ecmp_attributes.mpls_attributes.rif_valid = rif_valid
    ecmp_attributes.mpls_attributes.underlay_rif = underlay_rif
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(sx_api_router.handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)


def read_clear_router_counters_extended(counter_id_arr):
    " This function reads and clears router counters. "

    for i, counter_id in enumerate(counter_id_arr):
        counter_set_extended = sx_router_counter_set_extended_t()
        counter_set_extended.type = SX_ROUTER_COUNTER_TYPE_ENHANCED

        counter_basic_data = sx_router_counter_set_t()

        counter_set_extended.data.rif_basic = counter_basic_data
        counter_set_extended_p = new_sx_router_counter_set_extended_t_p()
        sx_router_counter_set_extended_t_p_assign(counter_set_extended_p, counter_set_extended)

        rc = sx_api_router_counter_extended_get(sx_api_router.handle, SX_ACCESS_CMD_READ_CLEAR, counter_id, counter_set_extended_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to read and clear router counter %d" % (counter_id)

        counter_set_extended = sx_router_counter_set_extended_t_p_value(counter_set_extended_p)
        print("Read and cleared router counter %d, rc: %d" % (counter_id, rc))

        print("########################### IPv4 counters ##########################\n")
        sx_api_router.print_router_counter(counter_id, counter_set_extended.data.rif_enhanced.ipv4_counters)
        print("########################### IPv6 counters ##########################\n")
        sx_api_router.print_router_counter(counter_id, counter_set_extended.data.rif_enhanced.ipv6_counters)
        print("########################### MPLS counters ##########################\n")
        sx_api_router.print_router_counter(counter_id, counter_set_extended.data.rif_enhanced.mpls_counters)


def mpls_ilm_flow_counter_bind(counter_id, label_in, vrid=0):
    " This function creates mpls in segment entry with given parameters. "

    in_segment_key = sx_mpls_in_segment_key_t()
    in_segment_key.ilm_table = vrid
    in_segment_key.label_cnt = 1

    mpls_label_arr = new_sx_mpls_label_t_arr(2)
    sx_mpls_label_t_arr_setitem(mpls_label_arr, 0, label_in)
    in_segment_key.in_label = mpls_label_arr

    in_segment_key_p = new_sx_mpls_in_segment_key_t_p()
    sx_mpls_in_segment_key_t_p_assign(in_segment_key_p, in_segment_key)

    rc = sx_api_mpls_ilm_counter_bind_set(sx_api_router.handle, SX_ACCESS_CMD_BIND, in_segment_key_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "sx_api_mpls_ilm_counter_bind_set failed, rc: %d" % (rc)

    print("Binding flow counter to ILM entry, counter id: %d label in: %d" % (counter_id, label_in))


def destroy_flow_counter(flow_counter_id):
    " This function destroys router counter. "

    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS
    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, flow_counter_id)

    rc = sx_api_flow_counter_set(sx_api_router.handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy ecmp counter, rc: %d" % (rc)

    print("Destroyed flow counter %d" % (flow_counter_id))


def mpls_ilm_flow_counter_unbind(label_in, vrid=0):
    " This function creates mpls in segment entry with given parameters. "

    in_segment_key = sx_mpls_in_segment_key_t()
    in_segment_key.ilm_table = vrid
    in_segment_key.label_cnt = 1

    mpls_label_arr = new_sx_mpls_label_t_arr(2)
    sx_mpls_label_t_arr_setitem(mpls_label_arr, 0, label_in)
    in_segment_key.in_label = mpls_label_arr

    in_segment_key_p = new_sx_mpls_in_segment_key_t_p()
    sx_mpls_in_segment_key_t_p_assign(in_segment_key_p, in_segment_key)

    rc = sx_api_mpls_ilm_counter_bind_set(sx_api_router.handle, SX_ACCESS_CMD_UNBIND, in_segment_key_p, 0)
    assert SX_STATUS_SUCCESS == rc, "sx_api_mpls_ilm_counter_bind_set failed, rc: %d" % (rc)
    print("Unbinding flow counter from ILM entry, label in: %d" % (label_in))


def create_flow_counter():
    " This function creates ecmp flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES

    rc = sx_api_flow_counter_set(sx_api_router.handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter, rc: %d" % (rc)

    counter_id = sx_router_counter_id_t_p_value(counter_p)

    print("Created ECMP counter %d" % (counter_id))
    return counter_id


def create_loopback_rif(vrid, vlan, mtu):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(sx_api_router.handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif


def ifc_trap_group_set(trap_group, unset=False):

    trap_group_attr_p = new_sx_trap_group_attributes_t_p()

    trap_group_attr_p.prio = 1
    trap_group_attr_p.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr_p.truncate_size = 0
    trap_group_attr_p.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr_p.is_monitor = False
    cmd = trap_group_unset_cmd if unset else trap_group_set_cmd
    rc = sx_api_host_ifc_trap_group_ext_set(sx_api_router.handle, cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_host_ifc_trap_group_ext_set, rc %d" % (rc)
    trap_group = sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group
    print("Set trap group %d " % (trap_group))

    return trap_group


def ifc_trap_set(trap_group, trap_id, unset=False):
    sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
    sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
    sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
    sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

    sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT if unset else SX_TRAP_ACTION_TRAP_2_CPU
    sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

    cmd = SX_ACCESS_CMD_UNSET if unset else SX_ACCESS_CMD_SET
    rc = sx_api_host_ifc_trap_id_ext_set(sx_api_router.handle, cmd, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_host_ifc_trap_id_ext_set failed, rc %d" % (rc)

    print("Set trap id %d " % (trap_id))


def read_flow_counters(flow_counter_id):
    " This function reads and clears router counters. "

    counter_set = sx_flow_counter_set_t()
    counter_set_p = new_sx_flow_counter_set_t_p()

    rc = sx_api_flow_counter_get(sx_api_router.handle, SX_ACCESS_CMD_READ, flow_counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d, rc: %d" % (flow_counter_id, rc)
    print("Read flow counter %d" % (flow_counter_id))

    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    return counter_set

# router_init


def router_init():
    """
    This function init router and port, add neighbors, create router counters and
    flow counter
    @return: List of vrid id, rif array, ecmp counter id, list of router counters
    """

    # init router
    sx_api_router.router_init()

    sx_api_router.example_ecmp_hash()

    # create vrid
    vrid = sx_api_router.create_vrid()

    sx_api_router.add_ports_to_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    sx_api_router.add_ports_to_vlan(5, {PORT2: SX_TAGGED_MEMBER})
    sx_api_router.add_ports_to_vlan(6, {PORT3: SX_TAGGED_MEMBER})
    sx_api_router.add_ports_to_vlan(7, {PORT4: SX_TAGGED_MEMBER})

    # init router port rif
    rif_arr = [None] * 4
    rif_arr[0] = sx_api_router.create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07), 1500)
    rif_arr[1] = sx_api_router.create_vlan_rif(vrid, 5, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08), 1500)
    rif_arr[2] = sx_api_router.create_vlan_rif(vrid, 6, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x09), 1500)
    rif_arr[3] = sx_api_router.create_vlan_rif(vrid, 7, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x0A), 1500)

    # add local and ip2me routes
    sx_api_router.create_local_route(vrid, rif_arr[0], "192.168.1.0", "255.255.255.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[0], "192.168.1.1")
    sx_api_router.create_local_route(vrid, rif_arr[1], "22.33.0.0", "255.255.0.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[1], "22.33.44.55")
    sx_api_router.create_local_route(vrid, rif_arr[2], "99.88.0.0", "255.255.0.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[2], "99.88.77.66")
    sx_api_router.create_local_route(vrid, rif_arr[3], "192.168.2.0", "255.255.255.0")
    sx_api_router.create_ip2me_route(vrid, rif_arr[3], "192.168.2.1")

    # rif state ipv4
    sx_api_router.set_rif_state_ipv4(rif_arr[0])
    sx_api_router.set_rif_state_ipv4(rif_arr[1])
    sx_api_router.set_rif_state_ipv4(rif_arr[2])
    sx_api_router.set_rif_state_ipv4(rif_arr[3])

    return vrid, rif_arr


def router_deinit(vrid, rif_arr):
    """
    This function deinit router and port, remove neighbors, router counters and
    flow counters
    """

    # delete all neighbors per rif
    sx_api_router.delete_all_neigh_per_rif(rif_arr[0])
    sx_api_router.delete_all_neigh_per_rif(rif_arr[1])
    sx_api_router.delete_all_neigh_per_rif(rif_arr[2])
    sx_api_router.delete_all_neigh_per_rif(rif_arr[3])

    # delete all local and ip2me routes
    sx_api_router.delete_all_local_routes(vrid)
    sx_api_router.delete_all_ip2me_routes(vrid)

    # delete rif
    sx_api_router.delete_rif(vrid, rif_arr[0])
    sx_api_router.delete_rif(vrid, rif_arr[1])
    sx_api_router.delete_rif(vrid, rif_arr[2])
    sx_api_router.delete_rif(vrid, rif_arr[3])

    sx_api_router.remove_ports_from_vlan(4, {PORT1: SX_TAGGED_MEMBER})
    sx_api_router.remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})
    sx_api_router.remove_ports_from_vlan(6, {PORT3: SX_TAGGED_MEMBER})
    sx_api_router.remove_ports_from_vlan(7, {PORT4: SX_TAGGED_MEMBER})

    # delete vrid
    sx_api_router.delete_vrid(vrid)

    # deinit router
    sx_api_router.router_deinit()

######################################################
#    main
######################################################


def main(vrid):

    ################################################################
    # MPLS single label swap flow -
    #           Create ECMP with 2 entries
    #           Create ILM with forward action goto ECMP
    #           Create flow counter and binding it to ilm
    #           Create flow counter and binding it to ecmp container
    #           Create interfaces counters and binding them
    ################################################################

    mpls_init()
    mpls_ilm_init(vrid)
    mpls_router_interface_attributes_set(rif_arr, True, vrid)

    # router counters - create and bind
    router_counter_arr = [None] * 2
    router_counter_arr[0] = sx_api_router.create_router_counter_extended(attr=SX_ROUTER_COUNTER_TYPE_ENHANCED)
    router_counter_arr[1] = sx_api_router.create_router_counter_extended(attr=SX_ROUTER_COUNTER_TYPE_ENHANCED)
    sx_api_router.bind_router_counter(router_counter_arr[0], rif_arr[0])
    sx_api_router.bind_router_counter(router_counter_arr[1], rif_arr[1])

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[1], "22.33.0.7", NEIGH_MAC_2)
    sx_api_router.add_neigh(rif_arr[0], "192.168.1.7", NEIGH_MAC_1)

    # Create flow counter
    ilm_flow_counter = create_flow_counter()
    ecmp_flow_counter = create_flow_counter()

    # create empty external ECMP container
    ecmp_id = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)

    # modify external ECMP container with {MPLS,22.33.0.7}, {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [222, 333],
                                  WEIGHT_STR: 1})

    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.7",
                                  LABELS_OUT_STR: [111, 444],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # Bind ecmp container to flow counter
    sx_api_router.set_ecmp_container_counter(ecmp_id, [ecmp_flow_counter])

    # create ilm entry
    rc = mpls_in_segment_create(label_in=200,
                                ecmp_container_id=ecmp_id,
                                action=SX_ROUTER_ACTION_FORWARD,
                                number_of_pops=1,
                                ilm_fwd_action=SX_MPLS_ILM_GOTO_ECMP,
                                vrid=vrid)

    # bind ilm entry to flow counter
    mpls_ilm_flow_counter_bind(ilm_flow_counter, label_in=200, vrid=vrid)

    """ Send Traffic here """

    # Read flow Counters
    counter_set_ecmp = read_flow_counters(ilm_flow_counter)
    counter_set_ilm = read_flow_counters(ecmp_flow_counter)

    # unbind all related counters
    sx_api_router.unbind_entire_ecmp_container(ecmp_id)

    # unbind ilm entry to flow counter
    mpls_ilm_flow_counter_unbind(label_in=200, vrid=vrid)

    # delete ilm entry
    mpls_in_segment_destroy(label_in=200, vrid=vrid)

    # delete ecmp container
    sx_api_router.destroy_ecmp_container(ecmp_id)

    # delete flow counters
    destroy_flow_counter(ilm_flow_counter)
    destroy_flow_counter(ecmp_flow_counter)

    # delete neighbor
    sx_api_router.delete_neigh(rif_arr[1], "22.33.0.7")
    sx_api_router.delete_neigh(rif_arr[0], "192.168.1.7")

    # unbind router counters
    sx_api_router.unbind_router_counter(router_counter_arr[0], rif_arr[0])
    sx_api_router.unbind_router_counter(router_counter_arr[1], rif_arr[1])

    # destroy router counters
    sx_api_router.destroy_router_counter(router_counter_arr[0], counter_type=SX_ROUTER_COUNTER_TYPE_ENHANCED)
    sx_api_router.destroy_router_counter(router_counter_arr[1], counter_type=SX_ROUTER_COUNTER_TYPE_ENHANCED)

    ################################################################
    # MPLS to IP flow - Create ECMP with 1 entries
    #                   Create ILM with forward action GOTO ROUTER
    ################################################################

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[0], "192.168.1.7", NEIGH_MAC_1)

    # create empty external ECMP container
    ecmp_id = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)
    # modify external ECMP container with {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # create ilm entry
    mpls_in_segment_create(label_in=200,
                           ecmp_container_id=ecmp_id,
                           number_of_pops=1,
                           vrid=vrid)

    """ Send Traffic here """

    # Delete ilm entry
    mpls_in_segment_destroy(label_in=200, vrid=vrid)

    # Delete ecmp container
    sx_api_router.destroy_ecmp_container(ecmp_id)

    # Delete neighbor
    sx_api_router.delete_neigh(rif_arr[0], "192.168.1.7")

    ################################################################
    # MPLS flow with continue lookup action -
    #                 Create ECMP with 1 entry
    #                 Create ILM with forward action CONTINUE LOOKUP
    #                 Create ILM with forward action GOTO ECMP
    ################################################################

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[0], "192.168.1.7", NEIGH_MAC_1)

    # create empty external ECMP container
    ecmp_id = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)

    # modify external ECMP container with {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [300],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # create ilm entry
    mpls_in_segment_create(label_in=200,
                           number_of_pops=1,
                           irif=rif_arr[0],
                           ilm_fwd_action=SX_MPLS_ILM_CONTINUE_LOOKUP,
                           vrid=vrid)

    # create ilm entry
    mpls_in_segment_create(label_in=201,
                           ecmp_container_id=ecmp_id,
                           action=SX_ROUTER_ACTION_FORWARD,
                           number_of_pops=1,
                           ilm_fwd_action=SX_MPLS_ILM_GOTO_ECMP,
                           vrid=vrid)

    """ Send Traffic here """

    # Delete ilm entries
    mpls_in_segment_destroy(label_in=200, vrid=vrid)
    mpls_in_segment_destroy(label_in=201, vrid=vrid)

    # Delete ecmp container
    sx_api_router.destroy_ecmp_container(ecmp_id)

    # Delete neighbor
    sx_api_router.delete_neigh(rif_arr[0], "192.168.1.7")

    ################################################################
    # MPLS flow with trap action -
    #                   Create ILM with action TRAP
    ################################################################

    # create empty external ECMP container
    ecmp_id = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)

    # modify external ECMP container with {MPLS,22.33.0.7}, {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [222, 333],
                                  WEIGHT_STR: 1})

    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "22.33.0.7",
                                  LABELS_OUT_STR: [111, 444],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    # Create trap group
    trap_group = ifc_trap_group_set(trap_group=0)

    # Attach traps to trap group
    ifc_trap_set(trap_group, SX_TRAP_ID_MPLS_ILM1)
    ifc_trap_set(trap_group, SX_TRAP_ID_MPLS_ILM_MISS)

    # Create ilm entry
    mpls_in_segment_create(
        label_in=200, ecmp_container_id=ecmp_id, number_of_pops=1, action=SX_ROUTER_ACTION_TRAP,
        trap_id=SX_TRAP_PRIORITY_HIGH,
        vrid=vrid)

    """
    Send Traffic here

    For ILM miss trap send mpls packets with label differ than 200

    For ILM trap send mpls packets with label 200
    """

    # Delete ilm entry
    mpls_in_segment_destroy(label_in=200, vrid=vrid)

    # Delete ecmp container
    sx_api_router.destroy_ecmp_container(ecmp_id)

    ################################################################
    # IP to MPLS flow -
    #                   Create ECMP with 1 entry
    #                   Create ecmp uc route
    ################################################################

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[0], "192.168.1.7", NEIGH_MAC_1)

    # create empty external ECMP container
    ecmp_id = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)

    # modify external ECMP container with {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [300],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id, next_hops_params_list)

    sx_api_router.create_ecmp_uc_route(vrid, "100.100.100.0", "255.255.255.0", ecmp_id)

    """ Send Traffic here """

    if args.deinit:
        # Delete all uc nh
        sx_api_router.delete_all_next_hops_uc_routes_per_vrid(vrid)

        # Delete ecmp container
        sx_api_router.destroy_ecmp_container(ecmp_id)

        # Delete neighbor
        sx_api_router.delete_neigh(rif_arr[0], "192.168.1.7")

        ifc_trap_set(trap_group, SX_TRAP_ID_MPLS_ILM1, unset=True)
        ifc_trap_set(trap_group, SX_TRAP_ID_MPLS_ILM_MISS, unset=True)
        ifc_trap_group_set(trap_group=trap_group, unset=True)

        mpls_router_interface_attributes_set(rif_arr, False)
        mpls_ilm_destroy(vrid)
        mpls_deinit()


################################################################
# IP to MPLS flow -
#                   Create ECMP with 1 entry
#                   Create ecmp uc route
################################################################
def ip_to_mpls_router_flow(vrid):
    print("#########################################################")
    print("#                    IP to MPLS flow                    #")
    print("#########################################################")

    mpls_init(underlay_domain=1)
    mpls_ilm_init(vrid)
    mpls_router_interface_attributes_set(rif_arr, True)

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[2], "22.33.0.7", NEIGH_MAC_2)
    sx_api_router.add_neigh(rif_arr[3], "192.168.2.8", NEIGH_MAC_3)

    # create empty external ECMP container
    ecmp_id_1 = create_empty_external_ecmp_container()
    ecmp_id_2 = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id_1, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS, rif_valid=1, underlay_rif=rif_arr[3])
    set_ecmp_attributes(ecmp_id=ecmp_id_2, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS, rif_valid=1, underlay_rif=rif_arr[3])

    # modify external ECMP container with {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[0],
                                  eRIF_STR: rif_arr[2],
                                  uRIF_STR: rif_arr[3],  # underlay RIF to MPLS
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [300],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id_1, next_hops_params_list)

    sx_api_router.create_ecmp_uc_route(vrid, "100.100.100.0", "255.255.255.0", ecmp_id_1)

    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "192.168.2.8",
                                  LABELS_OUT_STR: [],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id_2, next_hops_params_list)

    # create ilm entry
    mpls_in_segment_create(label_in=200,
                           ecmp_container_id=ecmp_id_2,
                           number_of_pops=1,
                           irif=rif_arr[3],
                           use_erif=True,
                           erif=rif_arr[1],
                           vrid=vrid)

    ''' Send Traffic here '''

    if args.deinit:
        # Delete ilm entry

        mpls_in_segment_destroy(label_in=200, vrid=vrid)

        # Delete all uc nh
        sx_api_router.delete_all_next_hops_uc_routes_per_vrid(vrid)

        # Delete ecmp container
        sx_api_router.destroy_ecmp_container(ecmp_id_2)
        sx_api_router.destroy_ecmp_container(ecmp_id_1)

        # Delete neighbor
        sx_api_router.delete_neigh(rif_arr[3], "192.168.2.8")
        sx_api_router.delete_neigh(rif_arr[2], "22.33.0.7")

        mpls_router_interface_attributes_set(rif_arr, False)
        mpls_ilm_destroy(vrid)
        mpls_deinit()


################################################################
# MPLS to IP flow - Create ECMP with 1 entries
#                   Create ILM with forward action GOTO ROUTER
################################################################
def mpls_to_ip_router_flow(vrid):
    print("#########################################################")
    print("#                    MPLS to IP flow                    #")
    print("#########################################################")

    mpls_init(underlay_domain=1)
    mpls_ilm_init(vrid)
    mpls_router_interface_attributes_set(rif_arr, True)

    # resolve neighbor
    sx_api_router.add_neigh(rif_arr[1], "192.168.1.7", NEIGH_MAC_1)  # MPLS eRIF
    sx_api_router.add_neigh(rif_arr[2], "192.168.2.8", NEIGH_MAC_2)

    # create empty external ECMP container
    ecmp_id_1 = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id_1, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS, rif_valid=1, underlay_rif=rif_arr[3])

    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  IP_STR: "192.168.1.7",
                                  LABELS_OUT_STR: [],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id_1, next_hops_params_list)

    # create ilm entry
    mpls_in_segment_create(label_in=200,
                           ecmp_container_id=ecmp_id_1,
                           number_of_pops=1,
                           ilm_fwd_action=SX_MPLS_ILM_GOTO_ROUTER,
                           irif=rif_arr[2],
                           use_erif=True,
                           erif=rif_arr[3],
                           vrid=vrid)

    ecmp_id_2 = create_empty_external_ecmp_container()

    # set external ECMP container type MPLS
    set_ecmp_attributes(ecmp_id=ecmp_id_2, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS, rif_valid=1, underlay_rif=rif_arr[3])

    # modify external ECMP container with {MPLS,192.168.1.7} next hops
    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: rif_arr[1],
                                  eRIF_STR: rif_arr[2],
                                  uRIF_STR: rif_arr[0],  # underlay RIF to MPLS - in the current flow it is not needed
                                  IP_STR: "192.168.2.8",
                                  LABELS_OUT_STR: [300],
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(ecmp_id_2, next_hops_params_list)

    sx_api_router.create_ecmp_uc_route(vrid, "100.100.100.0", "255.255.255.0", ecmp_id_2)

    ''' Send Traffic here '''

    if args.deinit:
        # Delete ilm entry
        mpls_in_segment_destroy(label_in=200, vrid=vrid)

        # Delete all uc nh
        sx_api_router.delete_all_next_hops_uc_routes_per_vrid(vrid)

        # Delete ecmp container
        sx_api_router.destroy_ecmp_container(ecmp_id_2)
        sx_api_router.destroy_ecmp_container(ecmp_id_1)

        # Delete neighbor
        sx_api_router.delete_neigh(rif_arr[1], "192.168.1.7")
        sx_api_router.delete_neigh(rif_arr[2], "192.168.2.8")

        mpls_router_interface_attributes_set(rif_arr, False)
        mpls_ilm_destroy(vrid)
        mpls_deinit()


if __name__ == "__main__":
    chip_type = get_chip_type(sx_api_router.handle)

    vrid, rif_arr = router_init()

    # init mpls

    main(vrid)

    # validate chip type, since the following examples are supported only by Spectrum2 and above
    if chip_type == SX_CHIP_TYPE_SPECTRUM2 or chip_type == SX_CHIP_TYPE_SPECTRUM3 or chip_type == SX_CHIP_TYPE_SPECTRUM4 or chip_type == SX_CHIP_TYPE_SPECTRUM5:
        ip_to_mpls_router_flow(vrid)
        mpls_to_ip_router_flow(vrid)
        pass

    if args.deinit:
        router_deinit(vrid, rif_arr)

    sx_api_close(sx_api_router.handle)
