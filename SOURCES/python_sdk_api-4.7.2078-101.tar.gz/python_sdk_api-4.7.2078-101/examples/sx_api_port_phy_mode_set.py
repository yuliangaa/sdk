#!/usr/bin/env python
'''
This file contains Python command example to set port phy mode value using sx_api_port_phy_mode_set API.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import sys
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

valid_phy_speed = {
    "10Gb": SX_PORT_PHY_SPEED_10GB,
    "40Gb": SX_PORT_PHY_SPEED_40GB,
    "25Gb": SX_PORT_PHY_SPEED_25GB,
    "50Gb": SX_PORT_PHY_SPEED_50GB,
    "100Gb": SX_PORT_PHY_SPEED_100GB,
    "56Gb": SX_PORT_PHY_SPEED_56GB,
    "200Gb": SX_PORT_PHY_SPEED_200GB,
    "1Gb": SX_PORT_PHY_SPEED_1GB,
    "50Gb_1X": SX_PORT_PHY_SPEED_50GB_1X,
    "100Gb_2X": SX_PORT_PHY_SPEED_100GB_2X,
    "400Gb_8X": SX_PORT_PHY_SPEED_400GB_8X,
    "10Mb": SX_PORT_PHY_SPEED_10MB,
    "100Mb": SX_PORT_PHY_SPEED_100MB,
    "100Gb_1X": SX_PORT_PHY_SPEED_100GB_1X,
    "200Gb_2X": SX_PORT_PHY_SPEED_200GB_2X,
    "400Gb_4X": SX_PORT_PHY_SPEED_400GB_4X,
    "800Gb_8X": SX_PORT_PHY_SPEED_800GB_8X,
}

phy_speed_2_str = {
    SX_PORT_PHY_SPEED_10GB: "10Gb",
    SX_PORT_PHY_SPEED_40GB: "40Gb",
    SX_PORT_PHY_SPEED_25GB: "25Gb",
    SX_PORT_PHY_SPEED_50GB: "50Gb",
    SX_PORT_PHY_SPEED_100GB: "100Gb",
    SX_PORT_PHY_SPEED_56GB: "56Gb",
    SX_PORT_PHY_SPEED_200GB: "200Gb",
    SX_PORT_PHY_SPEED_1GB: "1Gb",
    SX_PORT_PHY_SPEED_50GB_1X: "50Gb_1X",
    SX_PORT_PHY_SPEED_100GB_2X: "100Gb_2X",
    SX_PORT_PHY_SPEED_400GB_8X: "400Gb_8X",
    SX_PORT_PHY_SPEED_10MB: "10Mb",
    SX_PORT_PHY_SPEED_100MB: "100Mb",
    SX_PORT_PHY_SPEED_100GB_1X: "100Gb_1X",
    SX_PORT_PHY_SPEED_200GB_2X: "200Gb_2X",
    SX_PORT_PHY_SPEED_400GB_4X: "400Gb_4X",
    SX_PORT_PHY_SPEED_800GB_8X: "800Gb_8X",
}

valid_phy_mode = {
    "Auto": SX_PORT_FEC_MODE_AUTO,
    "None": SX_PORT_FEC_MODE_NONE,
    "FC": SX_PORT_FEC_MODE_FC,
    "RS": SX_PORT_FEC_MODE_RS,
    "LL_RS": SX_PORT_FEC_MODE_LL_RS,
    "INT_ELL_RS": SX_PORT_FEC_MODE_INT_ELL_RS,
    "INT_RS": SX_PORT_FEC_MODE_INT_RS,
}

mode_2_str = {
    SX_PORT_FEC_MODE_AUTO: "Auto",
    SX_PORT_FEC_MODE_NONE: "None",
    SX_PORT_FEC_MODE_FC: "FC",
    SX_PORT_FEC_MODE_RS: "RS",
    SX_PORT_FEC_MODE_LL_RS: "LL_RS",
    SX_PORT_FEC_MODE_INT_ELL_RS: "INT_ELL_RS",
    SX_PORT_FEC_MODE_INT_RS: "INT_RS",
}


def parse_args():
    help_str = """
    Port physical mode set example. Please use the following format to run_example:
    sx_api_port_phy_mode_set.py --log_port=<PORTs> --phy_speed=<SPEED> --phy_mode=<MODE> [--deinit] [--force]
    --log_port can be single port (e.g. 0x10001) or multiple ports separated by a comma (0x10001,0x10005)
    Valid speed values are:
    {}
    Valid mode values are:
    {}
    Note that some of the speeds may not be supported by switch. Please check port FEC capabilities.
    """.format(valid_phy_speed.keys(), valid_phy_mode.keys())

    parser = argparse.ArgumentParser(description=help_str)

    parser.add_argument('--log_port', type=auto_int, nargs='+', help='List of logical port to change rate', default=[0x10001])
    parser.add_argument('--phy_speed', help='Phy rates to enable', default='40Gb', choices=valid_phy_speed.keys())
    parser.add_argument('--phy_mode', help='Phy mode to enable', default='Auto', choices=valid_phy_mode.keys())
    parser.add_argument('--force', action='store_true', help='Disable API Disclaimer and force running the example script')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    return args


def change_port_state(handle, log_port, admin_state):
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to change port 0x{:x} state, error: {}.".format(log_port, sx_status_dict[rc])))
        sys.exit(rc)


def fec_cap_get(handle, log_port):
    fec_cnt_p = new_uint32_t_p()
    rc = sx_api_port_fec_capability_get(handle, log_port, None, fec_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to get FEC capability for port 0x{:x}, error: {}.".format(log_port, sx_status_dict[rc])))
        sys.exit(rc)

    fec_cnt = uint32_t_p_value(fec_cnt_p)
    fec_capability_list_p = new_sx_port_fec_capability_t_arr(fec_cnt)
    rc = sx_api_port_fec_capability_get(handle, log_port, fec_capability_list_p, fec_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Error: failed to get FEC capability for port 0x{:x}, error: {}.".format(log_port, sx_status_dict[rc])))
        sys.exit(rc)

    print("[+] Port 0x{:x} FEC capabilities:".format(log_port))
    table_format = "{:<12} {:<9} {:<15} {:<9} {:<9} {:<17} {:<15}"
    print(table_format.format("Phy speed", "no_FEC", "firecode_FEC", "RS_FEC", "LL_RS_FEC", "INT_ELL_RS_FEC", "INT_RS_FEC"))
    print(table_format.format("---------", "------", "------------", "------", "---------", "--------------", "----------"))
    for i in range(fec_cnt):
        fec_cap = sx_port_fec_capability_t_arr_getitem(fec_capability_list_p, i)
        print(table_format.format(phy_speed_2_str[fec_cap.speed], get_boolean_string(fec_cap.fec_capability.no_FEC),
                                  get_boolean_string(fec_cap.fec_capability.firecode_FEC), get_boolean_string(fec_cap.fec_capability.RS_FEC),
                                  get_boolean_string(fec_cap.fec_capability.LL_RS_FEC), get_boolean_string(fec_cap.fec_capability.INT_ELL_RS_FEC),
                                  get_boolean_string(fec_cap.fec_capability.INT_RS_FEC)))
    print(table_format.format("---------", "------", "------------", "------", "---------", "--------------", "----------"))

    delete_uint32_t_p(fec_cnt_p)
    delete_sx_port_fec_capability_t_arr(fec_capability_list_p)


def run_example(handle, args):
    for log_port in args.log_port:
        # Dump port FEC capabilities
        fec_cap_get(handle, log_port)

        # Set port admin down
        change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)

        # Save original mode for later de-configuration
        original_admin_mode_p = new_sx_port_phy_mode_t_p()
        original_oper_mode_p = new_sx_port_phy_mode_t_p()

        rc = sx_api_port_phy_mode_get(handle, log_port, valid_phy_speed[args.phy_speed], original_admin_mode_p, original_oper_mode_p)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to get %s port phy mode, error: {}.".format(log_port, sx_status_dict[rc])))
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
            sys.exit(rc)

        admin_mode = sx_port_phy_mode_t_p_value(original_admin_mode_p)
        oper_mode = sx_port_phy_mode_t_p_value(original_oper_mode_p)

        new_admin_mode = sx_port_phy_mode_t()
        new_admin_mode.fec_mode = valid_phy_mode[args.phy_mode]

        print("[+] Original phy mode for port 0x{:x} | Admin: {} | Oper: {}".format(log_port, mode_2_str[admin_mode.fec_mode], mode_2_str[oper_mode.fec_mode]))

        # Set port new phy mode
        rc = sx_api_port_phy_mode_set(handle, log_port, valid_phy_speed[args.phy_speed], new_admin_mode)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to set port 0x{:x} phy mode, error: {}.".format(log_port, sx_status_dict[rc])))
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
            sys.exit(rc)

        # Change port admin back to up
        change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)

        print("[+] Admin phy mode value for port 0x{:x} was changed to: {}".format(log_port, args.phy_mode))

        if args.deinit:
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)
            print("[+] Restore admin phy mode value for port 0x{:x} to original value: {}".format(log_port, mode_2_str[admin_mode.fec_mode]))
            rc = sx_api_port_phy_mode_set(handle, log_port, valid_phy_speed[args.phy_speed], admin_mode)
            if rc != SX_STATUS_SUCCESS:
                print(("Failed to set port 0x{:x} phy mode, error: {}.".format(log_port, sx_status_dict[rc])))
                sys.exit(rc)
            change_port_state(handle, log_port, SX_PORT_ADMIN_STATUS_UP)

        delete_sx_port_phy_mode_t_p(original_admin_mode_p)
        delete_sx_port_phy_mode_t_p(original_oper_mode_p)


def main():
    args = parse_args()     # Parse given arguments

    print_api_example_disclaimer()
    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    # Open Handle
    print("[+] Opening SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        run_example(handle, args)
        print("Example execution is finished successfully.")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
