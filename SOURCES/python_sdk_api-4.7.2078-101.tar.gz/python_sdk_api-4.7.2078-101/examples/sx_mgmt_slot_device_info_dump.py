#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the slot device information.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *


def get_dev_fw_string(fw_info):
    return str(fw_info.fw_major) + "." + str(fw_info.fw_minor) + "." + str(fw_info.fw_sub_minor)


def generate_slot_device_info_dump(handle, slot_id):
    slot_count = get_slot_count(handle)
    if slot_count == 0:
        print("Slot device information dump is applicable only for modular systems.")
        return

    slot_info_list = get_slot_info(handle)
    print("=================================================================================================================================")
    header = ["Slot", "Device Idx", "Flash Used", "Flash Owner", "Flash Id", "GB Type", "Sensor Id", "Thermal Shutdown", "Firmware version"]
    print("|%4s|%10s|%10s|%11s|%8s|%35s|%9s|%16s|%16s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8]))
    print("=================================================================================================================================")

    gb_type_enum_dict = get_enum_string_dict('SX_MGMT_SLOT_LC_DEV_GB_TYPE')
    for idx in range(len(slot_info_list)):
        slot_info = slot_info_list[idx]
        if slot_id != INVALID_SLOT_ID and slot_info.slot_id != slot_id:
            continue
        dev_info_arr = slot_info.dev_description.slot_device_info
        for dev_idx in range(slot_info.dev_description.slot_device_count):
            dev_info = sx_mgmt_slot_device_info_t_arr_getitem(dev_info_arr, dev_idx)
            print("|%4s|%10s|%10s|%11s|%8s|%35s|%9s|%16s|%16s|" % (slot_info.slot_id,
                                                                   dev_info.device_index,
                                                                   get_boolean_string(dev_info.is_flash_used),
                                                                   get_boolean_string(dev_info.is_flash_owner),
                                                                   dev_info.flash_id,
                                                                   gb_type_enum_dict[dev_info.device_gb_type],
                                                                   dev_info.device_temp_info.sensor_id,
                                                                   get_boolean_string(dev_info.device_temp_info.thermal_sd),
                                                                   get_dev_fw_string(dev_info.device_fw_info)))
    print("=================================================================================================================================")


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='Slot device info dump utility')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    args = parser.parse_args()
    slot_id = args.slot_id
    return slot_id


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    slot_id = parse_example_attributes()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    # Run the example.
    generate_slot_device_info_dump(handle, slot_id)

    sx_api_close(handle)
