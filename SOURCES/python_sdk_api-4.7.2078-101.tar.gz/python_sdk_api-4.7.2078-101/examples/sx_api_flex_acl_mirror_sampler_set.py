#!/usr/bin/env python

import sys
import socket
import struct
import errno
import random
from python_sdk_api.sx_api import *
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    description_str = """
    Python SDK API Example for MIRROR_SAMPLER ACL action for Ingress and Egress ACLs.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--mp", type=test_infra_common.auto_int, default="0",
                        help="Log port to analyze traffic on it, either in hex format - 0x10001, or Int format - 65537")
    parser.add_argument("--anp", type=test_infra_common.auto_int, default="0",
                        help="SPAN Analyzer Log port to use (connected to analyzer) , either in hex format - 0x10001, or Int format - 65537")
    parser.add_argument("--wait", action="store_true", help="wait for key to deinit")
    parser.add_argument("--ingress", action="store_true", help="create ingress ACL")
    parser.add_argument("--egress", action="store_true", help="create egress ACL")
    return parser.parse_args()


def region_create(handle, key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(handle, region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(handle, key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(handle, key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(handle, region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(handle, acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def rule_set(handle, region_id, rule_offset, cmd, span_session_id):
    ''' This function sets rule, where cmd is the choice for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_cnt = 1
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    offsets_list = new_sx_acl_rule_offset_t_arr(rules_cnt)

    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 3, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    key_desc.key.l4_destination_port = 7777
    key_desc.mask.l4_destination_port = 0xFFFF

    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_MIRROR_SAMPLER
    action1.fields.action_mirror_sampler.session_id = span_session_id
    action1.fields.action_mirror_sampler.mirror_probability_rate = 10

    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    rule.action_count = 1

    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, rule_offset)

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)


def span_init(handle):
    """SPAN INIT"""
    print("--------------- SPAN INIT------------------------------")

    init_params_p = new_sx_span_init_params_t_p()
    init_params = sx_span_init_params_t()
    init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    print(("sx_api_span_init_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("version = %d " % (init_params.version)))
    delete_sx_span_init_params_t_p(init_params_p)


""" ############################################################################################ """


def span_session_create(handle, span_session_param_p):
    """SPAN SESSION CREATE"""
    print("--------------- SPAN SESSION CREATE------------------------------")

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


def span_session_destroy(handle, span_session_id_p, span_session_param_p):
    """SPAN SESSION DESTROY"""
    print("--------------- SPAN SESSION DESTROY------------------------------")

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] destroyed" % (span_session_id)))


""" ############################################################################################ """


def span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- SPAN ANALYZER ADD ------------------------------")
    else:
        print("--------------- SPAN ANALYZER DELETE ------------------------------")
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    print(("sx_api_span_analyzer_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_session_state_set(handle, session_id, admin_state):
    """SPAN SESSION STATE SET """
    print("--------------- SPAN SESSION STATE SET  ------------------------------")
    print(("Span session id =%d, admin state =%d" % (session_id, admin_state)))
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    print(("sx_api_span_session_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_deinit(handle):
    """SPAN DEINIT"""
    print("--------------- SPAN DEINIT------------------------------")

    rc = sx_api_span_deinit_set(handle)
    print(("sx_api_span_deinit_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def span_create(handle, analyzer_port):
    # init span
    span_init(handle)

    # create a span session
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    span_session_param.span_type = SX_SPAN_TYPE_LOCAL_ETH_TYPE1
    span_session_param.span_type_format.local_eth_type1.qos_mode = SX_SPAN_QOS_MAINTAIN
    span_session_param.span_type_format.local_eth_type1.switch_prio = 0
    span_session_param.truncate = False
    span_session_param.truncate_size = 0

    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
    span_session_id_p = span_session_create(handle, span_session_param_p)
    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] created" % (span_session_id)))

    # add analyzer port to span session created above
    port_params_p = new_sx_span_analyzer_port_params_t_p()
    port_params = sx_span_analyzer_port_params_t()
    port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
    sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
    span_analyzer_set(handle, SX_ACCESS_CMD_ADD, analyzer_port, port_params_p, span_session_id)

    # enable SPAN session admin state
    span_session_state_set(handle, span_session_id, True)

    delete_sx_span_session_params_t_p(span_session_param_p)
    delete_sx_span_session_id_t_p(span_session_id_p)
    delete_sx_span_analyzer_port_params_t_p(port_params_p)

    return span_session_id


def span_destroy(handle, span_session_id, analyzer_port):
    # disable SPAN session admin state
    span_session_state_set(handle, span_session_id, False)

    # delete analyzer port to span session created above
    port_params_p = new_sx_span_analyzer_port_params_t_p()
    span_analyzer_set(handle, SX_ACCESS_CMD_DELETE, analyzer_port, port_params_p, span_session_id)

    # destroy span session
    span_session_id_p = new_sx_span_session_id_t_p()
    sx_span_session_id_t_p_assign(span_session_id_p, span_session_id)
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_destroy(handle, span_session_id_p, span_session_param_p)

    # deinit span
    span_deinit(handle)

    delete_sx_span_session_id_t_p(span_session_id_p)
    delete_sx_span_analyzer_port_params_t_p(port_params_p)
    delete_sx_span_session_params_t_p(span_session_param_p)


def acl_example(handle, bind_port, analyzer_port, wait_for_key, acl_direction, deinit):
    span_session_id = span_create(handle, analyzer_port)
    key_handle = key_create(handle, FLEX_ACL_KEY_L4_DESTINATION_PORT)
    region_id = region_create(handle, key_handle, 254)
    # acl_id = acl_create(handle, region_id, SX_ACL_DIRECTION_INGRESS)
    acl_id = acl_create(handle, region_id, acl_direction)
    rule_set(handle, region_id, 0, SX_ACCESS_CMD_SET, span_session_id)

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  bind_port,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    if wait_for_key:
        input("Press the Enter key for deinit")

    if deinit:
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      bind_port,
                                      acl_id)
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
        rule_set(handle, region_id, 0, SX_ACCESS_CMD_DELETE, span_session_id)
        acl_destroy(handle, acl_id, region_id)
        region_destroy(handle, region_id)
        key_destroy(handle, key_handle)
        span_destroy(handle, span_session_id, analyzer_port)


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    ret_code = 1
    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("This example doesn't support SPC1 Example - Exiting gracefully")
            ret_code = 0
            sys.exit(0)

        if args.ingress:
            acl_example(handle, args.mp, args.anp, args.wait, SX_ACL_DIRECTION_INGRESS, args.deinit)

        if args.egress:
            acl_example(handle, args.mp, args.anp, args.wait, SX_ACL_DIRECTION_EGRESS, args.deinit)

        # print("SUCCESS")
        sx_api_close(handle)
        ret_code = 0

    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        traceback.print_exc()

    finally:
        # sx_api_close(handle)
        if ret_code:
            print("Test failed: Return code = %d" % ret_code)
        else:
            print("All tests passed")
        sys.exit(ret_code)


if __name__ == "__main__":
    sys.exit(main())
