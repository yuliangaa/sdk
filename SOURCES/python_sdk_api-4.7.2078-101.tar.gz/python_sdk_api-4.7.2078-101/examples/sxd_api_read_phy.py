#!/usr/bin/env python

import sys
import errno


import sys
import time
import os
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sxd_api_read_phy example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] MCIA register access test start")
print("[+] initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

if args.deinit:
    meta.access_cmd = SXD_ACCESS_CMD_GET

    original_mcia_1 = ku_mcia_reg()

    original_mcia_1.module = 8
    original_mcia_1.i2c_device_address = 0x56
    original_mcia_1.page_number = 0
    original_mcia_1.device_address = 0x17
    original_mcia_1.size = 2

    rc = sxd_access_reg_mcia(original_mcia_1, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)

    original_mcia_2 = ku_mcia_reg()

    original_mcia_2.module = 8
    original_mcia_2.i2c_device_address = 0x56
    original_mcia_2.page_number = 0
    original_mcia_2.device_address = 0x15
    original_mcia_2.size = 2

    meta.access_cmd = SXD_ACCESS_CMD_GET
    rc = sxd_access_reg_mcia(original_mcia_2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)

mcia = ku_mcia_reg()

######################################################
# read extention registers
print("====================")
print("[+] Extension Registers:")

EXT_REG = 0x0F900000
mcia.slot_index = 0
mcia.module = 8
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = EXT_REG
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] ext_reg:0x%x , dword0: 0x%04x" % ((EXT_REG >> 16) & 0xff, mcia.dword_0 >> 16)))


EXT_REG = 0x0F990000
mcia.slot_index = 0
mcia.module = 8
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = EXT_REG
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)

print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] ext_reg:0x%x , dword0: 0x%04x" % ((EXT_REG >> 16) & 0xff, mcia.dword_0 >> 16)))


EXT_REG = 0x0F9A0000
mcia.slot_index = 0
mcia.module = 8
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = EXT_REG
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] ext_reg:0x%x , dword0: 0x%04x" % ((EXT_REG >> 16) & 0xff, mcia.dword_0 >> 16)))

######################################################
print("====================")
print("[+] BroadR-Reach LRE Registers:")
mcia.slot_index = 0
mcia.module = 8
mcia.i2c_device_address = 0x56
mcia.page_number = 0
mcia.device_address = 0x17
mcia.size = 2
mcia.dword_0 = 0x0F9A0000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr 0x17 dword0 : 0x%08x" % mcia.dword_0))

mcia.page_number = 0
mcia.device_address = 0x15
mcia.size = 2
mcia.dword_0 = 0x80000000
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr 0x15 dword0 : 0x%08x" % mcia.dword_0))

mcia.device_address = 0
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d , dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))

mcia.device_address = 1
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d , dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))

mcia.device_address = 2
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d , dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))

mcia.device_address = 3
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d , dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))

mcia.device_address = 4
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d , dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))

mcia.device_address = 15
mcia.size = 2
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MCIA register, rc: %d" % (rc)
print(("[+] addr:%d, dword0 : 0x%04x" % (mcia.device_address, mcia.dword_0 >> 16)))
print("====================")

if args.deinit:
    meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_mcia(original_mcia_1, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

    rc = sxd_access_reg_mcia(original_mcia_2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
