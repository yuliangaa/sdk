#!/usr/bin/env python
'''
This file contains Python command example for the VxLAN Tunnel Dump module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''

import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='VXLAN Tunnel Map Dump utility')
parser.add_argument('-t', dest='vxlan_tunnel_id', default=None, type=auto_int, help='Optional VxLAN Tunnel ID')
args = parser.parse_args()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

tunnel_input = args.vxlan_tunnel_id


def tunnel_map_entry_t_make(bridge_id, tunnel_type, vni, direction=SX_TUNNEL_MAP_DIR_BIDIR):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni
    map_entry.params.nve.direction = direction

    return map_entry


tunnel_id_list = []

if tunnel_input is None:
    # VXLAN
    tunnel_id_cnt_p = new_uint32_t_p()
    tunnel_id_cnt_v6_p = new_uint32_t_p()
    filter_p = new_sx_tunnel_filter_t_p()
    filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
    filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN

    uint32_t_p_assign(tunnel_id_cnt_p, 0)
    module_verbosity, api_verbosity = tunnel_module_verbosity_level_get(handle)
    tunnel_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_p)
    tunnel_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if tunnel module is initialized.
            print("####################################")
            print("# Tunnel Module is not initialized ")
            print("####################################")
        else:
            print("Tunnel Iterator failed with rc (%d)" % (rc))
            sys.exit(rc)
    else:
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)
        tunnel_id_list_p = new_sx_tunnel_id_t_arr(tunnel_id_cnt)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p, tunnel_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)

        # VXLAN v6
        filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
        filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6
        uint32_t_p_assign(tunnel_id_cnt_v6_p, 0)
        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt_v6 = uint32_t_p_value(tunnel_id_cnt_v6_p)
        tunnel_id_list_p_v6 = new_sx_tunnel_id_t_arr(tunnel_id_cnt_v6)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p_v6, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)

        for i in range(tunnel_id_cnt):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p, i)
            tunnel_id_list.append(tunnel_id)

        for i in range(tunnel_id_cnt_v6):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p_v6, i)
            tunnel_id_list.append(tunnel_id)
else:
    tunnel_id_cnt = 1
    tunnel_id_list = [tunnel_input]

tunnel_encap_cos_data_p = new_sx_tunnel_cos_data_t_p()
tunnel_decap_cos_data_p = new_sx_tunnel_cos_data_t_p()
tunnel_attr_p = new_sx_tunnel_attribute_t_p()


for tunnel_id in tunnel_id_list:
    rc1 = sx_api_tunnel_get(handle, tunnel_id, tunnel_attr_p)
    if rc1 != SX_STATUS_SUCCESS:
        print("####################################")
        print("# Failed to lookup tunnel Info rc(:%d)" % (rc))
        print("####################################")
        sys.exit(rc1)

    if (rc1 == SX_STATUS_SUCCESS):
        tunnel_attr = sx_tunnel_attribute_t_p_value(tunnel_attr_p)
        type = vxlan_type_dict.get(tunnel_attr.type)
        if type is None:
            print("Unsupported tunnel type (:%d)" % (type))
            sys.exit(1)

        tunnel_id_str = 'Tunnel ID: ' + hex(tunnel_id)
        empty_map_entry = tunnel_map_entry_t_make(0, 0, 0, 0)

        data_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(data_cnt_p, 0)
        sx_api_tunnel_map_get(handle, SX_ACCESS_CMD_GET_FIRST, tunnel_id, empty_map_entry, None, data_cnt_p)

        data_cnt = uint32_t_p_value(data_cnt_p)
        tables = []
        map_entry_list_p = new_sx_tunnel_map_entry_t_arr(1000)
        cmd = SX_ACCESS_CMD_GET_FIRST
        map_entry = empty_map_entry
        while data_cnt > 1000:
            uint32_t_p_assign(data_cnt_p, 1000)
            sx_api_tunnel_map_get(handle, cmd, tunnel_id, map_entry, map_entry_list_p, data_cnt_p)
            for i in range(uint32_t_p_value(data_cnt_p)):
                got_map_entry = sx_tunnel_map_entry_t_arr_getitem(map_entry_list_p, i)
                table = [got_map_entry.params.nve.bridge_id, got_map_entry.params.nve.vni, map_dir_dict[got_map_entry.params.nve.direction]]
                tables.append(table)
            data_cnt = data_cnt - 1000
            cmd = SX_ACCESS_CMD_GETNEXT
            map_entry = tunnel_map_entry_t_make(got_map_entry.params.nve.bridge_id, tunnel_attr.typegot_map_entry.params.nve.vni, got_map_entry.params.nve.direction)

        if data_cnt > 0:
            uint32_t_p_assign(data_cnt_p, data_cnt)
            sx_api_tunnel_map_get(handle, SX_ACCESS_CMD_GETNEXT, tunnel_id, map_entry, map_entry_list_p, data_cnt_p)
            for i in range(uint32_t_p_value(data_cnt_p)):
                got_map_entry = sx_tunnel_map_entry_t_arr_getitem(map_entry_list_p, i)
                table = [got_map_entry.params.nve.bridge_id, got_map_entry.params.nve.vni, map_dir_dict[got_map_entry.params.nve.direction]]
                tables.append(table)

        print('-' * 64)
        print(tunnel_id_str)
        print('-' * 64)
        header = ["Bridge ID", "VNI", "Direction"]
        print("|%20s|%20s|%20s|" % (header[0], header[1], header[2]))
        print('-' * 64)
        for table in tables:
            print("|%20s|%20s|%20s|" % (table[0], table[1], table[2]))
            print('-' * 64)

sx_api_close(handle)
