#!/usr/bin/env python
'''
This file contains a Python commands example for the sflow module.

Python commands syntax is very similar to the Switch SDK APIs.

You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

\section cases Example Flow

The example below performs the following configuration operations:

1. Open host intreface.

2. Set trap group.

3. Set trap id for sflow.

4. Register trap with host interface.

5 Configure LAG hash distribution function

6 Create LAG

7 Set ingress filter

8 Add ports to LAG

9 Enable collection on a specific LAG port

10 Enable distribution on a specific LAG port

11 Create sflow on port

12 Get sflow statistics from port

13 Delete sflow from port

14 Deletes ports from LAG

15 Destroys LAG

16 Cleanup allocated objects

'''
import sys
import errno
from test_infra_common import *
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *
from pprint import pprint
import argparse

parser = argparse.ArgumentParser(description='sx_api_sflow_lag_port example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

os.system("command")

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'


def print_all_attr_from_a_struct(struct):
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            print("\t%s = %s" % (attr, getattr(struct, attr)))


print("[+] Redirecting stderr to: %s" % ERR_FILE_LOCATION)
file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)

sys_argv_len = len(sys.argv)
if args.deinit:
    sys_argv_len = sys_argv_len - 1

if sys_argv_len >= 6:
    log_port1 = int(str(sys.argv[1]), 16)
    log_port2 = int(str(sys.argv[2]), 16)
    log_port3 = int(str(sys.argv[3]), 16)
    log_port4 = int(str(sys.argv[4]), 16)
    rate = int(str(sys.argv[5]), 10)
    sleep_cntr = int(str(sys.argv[6]), 10)
elif sys_argv_len >= 6:
    log_port1 = int(str(sys.argv[1]), 16)
    log_port2 = int(str(sys.argv[2]), 16)
    log_port3 = int(str(sys.argv[3]), 16)
    log_port4 = int(str(sys.argv[4]), 16)
    rate = int(str(sys.argv[5]), 10)
elif sys_argv_len >= 5:
    log_port1 = int(str(sys.argv[1]), 16)
    log_port2 = int(str(sys.argv[2]), 16)
    log_port3 = int(str(sys.argv[3]), 16)
    log_port4 = int(str(sys.argv[4]), 16)
    rate = 1000
    sleep_cntr = 60
else:
    log_port1 = port_list[0]
    log_port2 = port_list[1]
    log_port3 = port_list[2]
    log_port4 = port_list[3]
    rate = 1000
    sleep_cntr = 60

print(("Input parameters: ports 0x%x 0x%x 0x%x 0x%x, rate %d sleep %d "
       % (log_port1, log_port2, log_port3, log_port4, rate, sleep_cntr)))

INGRESS_PORT = None
for port in port_list:
    if port not in [log_port1, log_port2, log_port3, log_port4]:
        INGRESS_PORT = port
        break


def get_port_lag_hash_param(port):
    lag_hash_params_p = new_sx_lag_port_hash_params_t_p()
    hash_field_enable_list_cnt_p = new_uint32_t_p()
    hash_field_list_cnt_p = new_uint32_t_p()

    rc = sx_api_lag_port_hash_flow_params_get(
        handle, port, lag_hash_params_p, None, hash_field_enable_list_cnt_p, None, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    field_enable_cnt = uint32_t_p_value(hash_field_enable_list_cnt_p)
    field_cnt = uint32_t_p_value(hash_field_list_cnt_p)

    # Get actual values based on count
    hash_field_list_p = new_sx_lag_hash_field_t_arr(field_cnt)
    hash_field_enable_list_p = new_sx_lag_hash_field_enable_t_arr(field_enable_cnt)

    rc = sx_api_lag_port_hash_flow_params_get(handle, port, lag_hash_params_p, hash_field_enable_list_p,
                                              hash_field_enable_list_cnt_p, hash_field_list_p,
                                              hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    return lag_hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt


def set_port_lag_hash_param(port, cmd):
    port_lag_hash_field_en_set_arr = new_sx_lag_hash_field_enable_t_arr(2)
    port_lag_hash_field_set_arr = new_sx_lag_hash_field_t_arr(4)
    port_lag_hash_type_params = sx_lag_port_hash_params_t()
    port_lag_hash_type_params_p = new_sx_lag_port_hash_params_t_p()
    num_hdr_enables_cnt = 2
    num_fields_cnt = 4

    port_lag_hash_type_params.is_lag_hash_symmetric = False
    port_lag_hash_type_params.lag_hash_type = SX_LAG_HASH_TYPE_XOR
    port_lag_hash_type_params.lag_seed = 0

    sx_lag_port_hash_params_t_p_assign(port_lag_hash_type_params_p,
                                       port_lag_hash_type_params)

    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 0,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4)
    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 1,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP)

    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 0, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_0)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 1, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_1)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 2, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_2)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 3, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_3)

    rc = sx_api_lag_port_hash_flow_params_set(handle, cmd,
                                              port, port_lag_hash_type_params_p,
                                              port_lag_hash_field_en_set_arr, num_hdr_enables_cnt,
                                              port_lag_hash_field_set_arr, num_fields_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


# Open host intreface
sx_fd_p = new_sx_fd_t_p()
rc = sx_api_host_ifc_open(handle, sx_fd_p)
sx_fd = sx_fd_t_p_value(sx_fd_p)
print(("sx_api_host_ifc_open 0x%x , rc %d " % (sx_fd.fd, rc)))

# Set trap group
swid = 0
trap_group = 1
sx_trap_group_attributes_p = new_sx_trap_group_attributes_t_p()
sx_trap_group_attributes = sx_trap_group_attributes_t()
sx_trap_group_attributes.prio = SX_TRAP_PRIORITY_BEST_EFFORT
sx_trap_group_attributes.truncate_mode = SX_TRUNCATE_MODE_DISABLE
sx_trap_group_attributes.truncate_size = 0
sx_trap_group_attributes.control_type = SX_CONTROL_TYPE_DEFAULT
sx_trap_group_attributes.is_monitor = False
sx_trap_group_attributes.trap_group = trap_group
sx_trap_group_attributes_t_p_assign(sx_trap_group_attributes_p, sx_trap_group_attributes)
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, swid, trap_group, sx_trap_group_attributes_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_group_set prio 0x%x , rc %d " % (sx_trap_group_attributes.prio, rc)))
trap_group = sx_trap_group_attributes_t_p_value(sx_trap_group_attributes_p).trap_group

# Set trap id for sflow
trap_id = SX_TRAP_ID_ETH_L2_PACKET_SAMPLING
trap_action = SX_TRAP_ACTION_TRAP_2_CPU

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_id_ext_set rc %d " % (rc)))

# Register trap with host interface
sx_user_channel_p = new_sx_user_channel_t_p()
sx_user_channel = sx_user_channel_t()
sx_user_channel.type = SX_USER_CHANNEL_TYPE_FD
sx_user_channel.channel.fd = sx_fd
sx_user_channel_t_p_assign(sx_user_channel_p, sx_user_channel)
rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, swid, trap_id, sx_user_channel_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_id_register_set  rc %d " % (rc)))

# 0. Get original RSTP States of used ports - They change during lag operations
original_rstp_modes = {}
stp_state_p = new_sx_mstp_inst_port_state_t_p()
for port in [log_port1, log_port2, log_port3, log_port4]:
    rc = sx_api_rstp_port_state_get(handle, port, stp_state_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_get failed, port 0x%x, rc: %d" % (port, rc)
    original_rstp_modes[port] = sx_mstp_inst_port_state_t_p_value(stp_state_p)
delete_sx_mstp_inst_port_state_t_p(stp_state_p)

# 1. Configures the fields which impact the LAG hash distribution function.
# lag_hash_param = sx_lag_hash_param_t()
# lag_hash_param.lag_hash_type = SX_LAG_HASH_TYPE_XOR
# lag_hash_param.lag_hash = 0xA
# lag_hash_param.lag_seed = 0
# rc = sx_api_lag_hash_flow_params_set(handle, lag_hash_param)
# assert rc == SX_STATUS_SUCCESS, "sx_api_lag_hash_flow_params_set failed, rc: %d" % (rc)
# print(("sx_api_lag_hash_flow_params_set , type %d , rc %d " % (lag_hash_param.lag_hash_type, rc)))
print("Setting lag_port_hash_flow_params per port. NOTE That instead you can use legacy global API 'sx_api_lag_hash_flow_params_set'\n"
      "(an example is commented above), which sets lag hash globally. Note also that once the new API is called\n"
      "legacy API is disabled.")
# Save port lag hash params for later de-configuration
lag_hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt = get_port_lag_hash_param(INGRESS_PORT)

# Sets new lag hash on port
set_port_lag_hash_param(INGRESS_PORT, SX_ACCESS_CMD_SET)

# Create LAG
swid = 0
lag_id_p = new_sx_port_log_id_t_p()
rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
lag_id = sx_port_log_id_t_p_value(lag_id_p)
print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

# Set ingress filter
rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))

# Add ports to LAG
swid = 0
port_list = new_sx_port_log_id_t_arr(4)
ports_ingr_filter_mode = {}
for i, port in enumerate([log_port1, log_port2, log_port3, log_port4]):
    sx_port_log_id_t_arr_setitem(port_list, i, port)
    ports_ingr_filter_mode[port] = ingr_filter_get(port)

rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_id_p, port_list, 4)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_lag_port_group_set ADD ports 0x%x, 0x%x 0x%x, 0x%x  to lag_id 0x%x , rc %d "
       % (log_port1, log_port2, log_port3, log_port4, lag_id, rc)))

# Enables collection on a specific LAG port
log_port = log_port1
col_state = COLLECTOR_ENABLE
rc = sx_api_lag_port_collector_set(handle, lag_id, log_port, col_state)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, col_state, rc)))

# Enables distribution on a specific LAG port
log_port = log_port1
distr_state = DISTRIBUTOR_ENABLE
rc = sx_api_lag_port_distributor_set(handle, lag_id, log_port, distr_state)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, distr_state, rc)))

# Create sflow on port
sx_port_sflow_params_p = new_sx_port_sflow_params_t_p()
sx_port_sflow_params = sx_port_sflow_params_t()
sx_port_sflow_params.ratio = rate
sx_port_sflow_params.deviation = 0
sx_port_sflow_params.packet_types.uc = 0
sx_port_sflow_params.packet_types.mc = 0
sx_port_sflow_params.packet_types.bc = 0
sx_port_sflow_params.packet_types.uuc = 0
sx_port_sflow_params.packet_types.umc = 0
sx_port_sflow_params_t_p_assign(sx_port_sflow_params_p, sx_port_sflow_params)
rc = sx_api_port_sflow_set(handle, SX_ACCESS_CMD_ADD, lag_id, sx_port_sflow_params_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_port_sflow_set ADD rc %d %x" % (rc, log_port)))

print("At this point, if traffic occurs, User should wait for sflow collection based on sleep counter\n"
      "Since this is only an example, will not sleep at all")

# Get sflow statistics from port
sx_port_sflow_statistics_p = new_sx_port_sflow_statistics_t_p()
sx_port_sflow_statistics = sx_port_sflow_statistics_t()
sx_port_sflow_statistics_t_p_assign(sx_port_sflow_statistics_p, sx_port_sflow_statistics)
rc = sx_api_port_sflow_statistics_get(handle, SX_ACCESS_CMD_READ, lag_id, sx_port_sflow_statistics_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_port_sflow_statistics_get READ rc %d %x" % (rc, log_port)))
print(("sx_port_sflow_statistics : %d " % (sx_port_sflow_statistics.count_sample_drop)))

if args.deinit:
    # Delete sflow from port
    sx_port_sflow_params_p = new_sx_port_sflow_params_t_p()
    sx_port_sflow_params_t_p_assign(sx_port_sflow_params_p, sx_port_sflow_params)
    rc = sx_api_port_sflow_set(handle, SX_ACCESS_CMD_DELETE, lag_id, sx_port_sflow_params_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_port_sflow_set failed; rc=%d", rc)
        sys.exit(rc)
    print(("sx_api_port_sflow_set DELETE rc %d %x" % (rc, log_port)))

    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, swid, trap_id, sx_user_channel_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_host_ifc_trap_id_register_set failed; rc=%d", rc)
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_host_ifc_trap_id_ext_set failed; rc=%d", rc)
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, swid, trap_group, sx_trap_group_attributes_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_host_ifc_trap_group_ext_set failed; rc=%d", rc)
        sys.exit(rc)

    # Delete ports from LAG
    swid = 0
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_id_p, port_list, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_lag_port_group_set failed; rc=%d", rc)
        sys.exit(rc)
    print(("sx_api_lag_port_group_set DELETE ports 0x%x, 0x%x, 0x%x 0x%x from lag_id 0x%x , rc %d "
           % (log_port1, log_port2, log_port3, log_port4, lag_id, rc)))

    # Destroy LAG
    swid = 0
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, swid, lag_id_p, None, 0)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_lag_port_group_set failed; rc=%d", rc)
        sys.exit(rc)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc)))

    # Reset origin lag hash of port
    rc = sx_api_lag_port_hash_flow_params_set(handle, SX_ACCESS_CMD_SET,
                                              INGRESS_PORT, lag_hash_params_p, hash_field_enable_list_p,
                                              field_enable_cnt, hash_field_list_p, field_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)

    # Restore vlan membership & ingr filter mode
    for port, ingr_filter in list(ports_ingr_filter_mode.items()):
        add_ports_to_vlan(1, {port: SX_UNTAGGED_MEMBER})
        ingr_filter_set(port, ingr_filter)

    for port, rstp_state in original_rstp_modes.items():
        rc = sx_api_rstp_port_state_set(handle, port, rstp_state)
        assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, port 0x%x, rc: %d" % (port, rc)

# Cleanup allocated objects
delete_sx_port_log_id_t_p(lag_id_p)
delete_sx_port_log_id_t_arr(port_list)

sx_api_close(handle)

print("[+] end test")
