#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility resets the module
'''
import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api

INVALID_SLOT_ID = 99


def mgmt_phy_mod_reset(handle, slot_id, module_id):
    module_id_info = sx_mgmt_module_id_info_t()
    module_id_info.slot_id = slot_id
    module_id_info.module_id = module_id
    rc = sx_mgmt_phy_module_reset(handle, module_id_info)
    assert SX_STATUS_SUCCESS == rc, "mgmt_phy_module_reset failed"


def print_slot_warning():
    valid = {"yes": True, "y": True, "ye": True}
    print("Slot ID is assumed 0 and is applicable only for 1U system")
    print("Do you wish to continue? (y/N)")
    choice = input().lower()
    if choice not in valid:
        sx_api_close(handle)
        sys.exit(1)


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='Module reset utility')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    parser.add_argument('--module_id', default=0, type=int, help="Module id")
    args = parser.parse_args()

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    module_id = args.module_id
    slot_id = args.slot_id
    return slot_id, module_id


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    slot_id, module_id = parse_example_attributes()
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # construct the port module map.
    ports_attributes_list = ports_attributes_get(handle)
    port_module_map, module_port_map = get_port_module_mapping(ports_attributes_list, len(ports_attributes_list))

    if slot_id == INVALID_SLOT_ID:
        slot_count = system_slot_count_get(handle)
        if slot_count > 0:
            slot_id = 1
        else:
            slot_id = 0

    if (slot_id, module_id) not in module_port_map.keys():
        print("Error: Invalid Module Id")
        sx_api_close(handle)
        sys.exit(1)

    state = phy_module_state_get(handle, slot_id, module_id)
    if state != SX_PORT_MODULE_STATUS_PLUGGED:
        print("Module state other than SX_PORT_MODULE_STATUS_PLUGGED is not compatible for reset operation")
        sx_api_close(handle)
        sys.exit(0)

    mgmt_phy_mod_reset(handle, slot_id, module_id)
    print("Reset executed for slot[%d] module [%d]" % (slot_id, module_id))

    sx_api_close(handle)
