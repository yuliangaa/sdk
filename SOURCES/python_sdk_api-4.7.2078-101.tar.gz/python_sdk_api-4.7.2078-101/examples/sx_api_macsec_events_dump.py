#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the MACSec events.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
from python_sdk_api.sxd_api import *

events_id_list = [SX_MACSEC_EVENT_ACL_ID_0_E, SX_MACSEC_EVENT_ACL_ID_1_E, SX_MACSEC_EVENT_ACL_ID_2_E, SX_MACSEC_EVENT_ACL_ID_4_E, SX_MACSEC_EVENT_ACL_ID_5_E,
                  SX_MACSEC_EVENT_ACL_ID_6_E, SX_MACSEC_EVENT_ACL_ID_7_E, SX_MACSEC_EVENT_ACL_ID_8_E, SX_MACSEC_EVENT_ACL_ID_9_E, SX_MACSEC_EVENT_ACL_ID_10_E,
                  SX_MACSEC_EVENT_ACL_ID_11_E, SX_MACSEC_EVENT_ACL_ID_12_E, SX_MACSEC_EVENT_ACL_ID_13_E, SX_MACSEC_EVENT_ACL_ID_14_E, SX_MACSEC_EVENT_ACL_ID_15_E,
                  SX_MACSEC_EVENT_INGRESS_MTU_E, SX_MACSEC_EVENT_TAG_ALLOW_E, SX_MACSEC_EVENT_NO_SECTAG_E, SX_MACSEC_EVENT_SECTAG_ERROR_E, SX_MACSEC_EVENT_ENCRYPT_ERROR_E]


def macsec_events_get(handle):
    count = len(events_id_list)
    macsec_event_key_arr = new_sx_macsec_event_key_t_arr(count * 2)
    macsec_event_attr_arr = new_sx_macsec_event_attr_t_arr(count * 2)
    for idx, event in enumerate(events_id_list):
        macsec_events_key_item = sx_macsec_event_key_t()
        macsec_events_key_item.event_id = event
        macsec_events_key_item.direction = SX_MACSEC_DIR_INGRESS_E
        sx_macsec_event_key_t_arr_setitem(macsec_event_key_arr, (idx * 2), macsec_events_key_item)
        macsec_events_key_item.direction = SX_MACSEC_DIR_EGRESS_E
        sx_macsec_event_key_t_arr_setitem(macsec_event_key_arr, (idx * 2 + 1), macsec_events_key_item)
    try:
        rc = sx_api_macsec_events_get(handle, (count * 2), macsec_event_key_arr, macsec_event_attr_arr)
        assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_events_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
        return [sx_macsec_event_key_t_arr_getitem(macsec_event_key_arr, i) for i in range(count * 2)], [sx_macsec_event_attr_t_arr_getitem(macsec_event_attr_arr, i) for i in range(count * 2)]
    finally:
        delete_sx_macsec_event_key_t_arr(macsec_event_key_arr)
        delete_sx_macsec_event_attr_t_arr(macsec_event_attr_arr)


def generate_events_dump(handle):
    macsec_dir_type_enum_dict = get_enum_string_dict('SX_MACSEC_DIR_')
    macsec_events_str = get_enum_string_dict('SX_MACSEC_EVENT_')
    macsec_actions_str = get_enum_string_dict('SX_MACSEC_EVENT_ACTION_')
    key_list, attr_list = macsec_events_get(handle)
    print("========================================================================================================================")
    header = ["Event ID", "Direction", "Action"]
    print("|%36s|%40s|%40s|" % (header[0], header[1], header[2]))
    print("========================================================================================================================")

    for i in range(len(key_list)):
        print("|%36s|%40s|%40s|" % (macsec_events_str[key_list[i].event_id], macsec_dir_type_enum_dict[key_list[i].direction], macsec_actions_str[attr_list[i].action]))
    print("========================================================================================================================")


def check_macsec_init_status(handle):
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("MACSec module is not initialized")
            sys.exit()
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print("MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

    check_macsec_init_status(handle)

    generate_events_dump(handle)

    sx_api_close(handle)
