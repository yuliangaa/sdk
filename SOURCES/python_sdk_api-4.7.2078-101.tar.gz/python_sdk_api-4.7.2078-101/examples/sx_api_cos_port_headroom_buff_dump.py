#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import os
import sys
from python_sdk_api.sx_api import *
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    # Description str can be same as header in lines 2-4: It will be printed to user when doing <py_example>.py --help
    description_str = """
    This is an example of using API sx_api_cos_port_buff_type_statistic_get in order to get and optionally clear
    headroom statistics"""
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument('--port', default=0x10001, type=test_infra_common.auto_int, help='Log port to use, either in hex format - 0x10001, or Int format - 65537')
    parser.add_argument('--pg_list', default=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], type=test_infra_common.auto_int, nargs='*')
    parser.add_argument('--clear', action='store_true', help='Clear stats on read')
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")

    return parser.parse_args()


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    PORT1 = args.port

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open API handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        """ BUFF TYPE STATISTICS GET """
        print("---------------  BUFF TYPE STATISTICS GET ------------------------------")
        cmd = SX_ACCESS_CMD_READ
        if args.clear:
            cmd = SX_ACCESS_CMD_READ_CLEAR

        statistics_cnt = 1
        statistic_param_list_p = new_sx_port_statistic_usage_params_t_arr(statistics_cnt)

        for i in range(0, statistics_cnt):
            attr_item = sx_port_statistic_usage_params_t_arr_getitem(statistic_param_list_p, i)
            """ Set relevant parameters """
            attr_item.port_cnt = 1
            attr_item.log_port_list_p = new_sx_port_log_id_t_arr(attr_item.port_cnt)
            """ Set a value at index 0 """
            sx_port_log_id_t_arr_setitem(attr_item.log_port_list_p, 0, PORT1)
            attr_item.sx_port_params.port_params_cnt = len(args.pg_list)
            attr_item.sx_port_params.port_params_type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E

            print("Statistics required params")
            print("--------------------------")
            print(("[%d] port_cnt = %d" % (i, attr_item.port_cnt)))
            print(("[%d] log_port_0 = %d" % (i, sx_port_log_id_t_arr_getitem(attr_item.log_port_list_p, 0))))
            print(("[%d] union num entries = %d" % (i, attr_item.sx_port_params.port_params_cnt)))
            print(("[%d] union type = %d" % (i, attr_item.sx_port_params.port_params_type)))

            attr_item.sx_port_params.port_param.port_pg_list_p = new_sx_cos_priority_group_t_arr(attr_item.sx_port_params.port_params_cnt)
            statistic_param_list_p.sx_port_params.port_param.port_pg_list_p = new_sx_cos_priority_group_t_arr(attr_item.sx_port_params.port_params_cnt)
            """ Set a value at index 0 (PG#0)"""
            for j in range(len(args.pg_list)):
                sx_cos_priority_group_t_arr_setitem(attr_item.sx_port_params.port_param.port_pg_list_p, j, j)

        """ Call API with cnt=0 to retrieve number of expected retrieved entries """
        usage_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(usage_cnt_p, len(args.pg_list))

        """ Set updated parameters to the object """
        sx_port_statistic_usage_params_t_arr_setitem(statistic_param_list_p, 0, attr_item)

        """ Get value from PTR """
        usage_cnt = uint32_t_p_value(usage_cnt_p)
        print(("usage_cnt (returned from API = %d)" % (usage_cnt)))

        """ Alloc mem for usage retrieved parametes """
        usage_list_p = new_sx_port_occupancy_statistics_t_arr(usage_cnt)

        for i in range(usage_cnt):
            sx_cos_priority_group_t_arr_setitem(attr_item.sx_port_params.port_param.port_pg_list_p, i, args.pg_list[i])

        """ Call API with cnt=0 to retrieve number of expected retrieved entries """
        print(("Call Get statistic API with cnt = %d " % (usage_cnt)))
        rc = sx_api_cos_port_buff_type_statistic_get(handle, cmd, statistic_param_list_p, statistics_cnt, usage_list_p, usage_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_cos_port_buff_type_statistic_get FAILED %d" % (rc)))
            sys.exit(rc)

        print("---------------------")
        print("Retrieved statistics:")
        print("---------------------")
        usage_cnt = uint32_t_p_value(usage_cnt_p)
        for i in range(0, usage_cnt):
            ret_item = sx_port_occupancy_statistics_t_arr_getitem(usage_list_p, i)
            print(("[%d] log_port = 0x%x" % (i, ret_item.log_port)))
            print(("[%d] port_params_type = %d" % (i, ret_item.sx_port_params.port_params_type)))

            if ret_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E or ret_item.sx_port_params.port_params_type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E:
                print(("[%d] port_pg = %d" % (i, ret_item.sx_port_params.port_param.port_pg)))

                print(("[%d] Curr occupancy = %d" % (i, ret_item.statistics.curr_occupancy)))
                print(("[%d] Max occupancy = %d" % (i, ret_item.statistics.watermark)))
                print("---------------")
        print("SUCCESS")

    finally:
        delete_sx_port_occupancy_statistics_t_arr(usage_list_p)
        delete_uint32_t_p(usage_cnt_p)
        for i in range(0, statistics_cnt):
            attr_item = sx_port_statistic_usage_params_t_arr_getitem(statistic_param_list_p, i)
            delete_sx_cos_priority_group_t_arr(attr_item.sx_port_params.port_param.port_pg_list_p)
            delete_sx_port_log_id_t_arr(attr_item.log_port_list_p)
        delete_sx_port_statistic_usage_params_t_arr(statistic_param_list_p)
        sx_api_close(handle)


if __name__ == "__main__":
    main()
