#!/usr/bin/env python

import sys
import time
import os
import argparse
import errno
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

print("[+] Set/Get PPLR register access example")

parser = argparse.ArgumentParser(description='PPLR get/set example')
parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1)")
parser.add_argument('--local_port', default=1, type=int, help="Local Port")
parser.add_argument('--egress_lpbk', default=0, type=int, help="Disable(0), Enable(1)")
parser.add_argument('--ingress_lpbk', default=1, type=int, help="Disable(0), Enable(1)")
parser.add_argument('--port_type', default=0, type=int, help="0-default 1-near-end; 2-internal IC LR; 3-far-end; 4-usr main; 5-usr tile")
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

if args.ingress_lpbk and args.egress_lpbk:
    print("Error: egress_lpbk and ingress_lpbk cannot be both enabled at the same time.")
    sys.exit(1)

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initialize register access.\nPlease check that SDK is running.")
    sys.exit(rc)

original_pplr = ku_pplr_reg()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

meta.access_cmd = SXD_ACCESS_CMD_GET
original_pplr.local_port, original_pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

original_pplr.port_type = args.port_type

rc = sxd_access_reg_pplr(original_pplr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PPLR register, rc: %d" % (rc)

pplr = ku_pplr_reg()

pplr.local_port, pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

pplr.port_type = args.port_type


print("====================")
print("[+] Get PPLR")
print("[+] local port : ", pplr.local_port)
print("[+] lp_msb : ", pplr.lp_msb)
print("[+] port_type : ", pplr.port_type)
rc = sxd_access_reg_pplr(pplr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PPLR register, rc: %d" % (rc)

print("[+] Get PPLR done. rc:", rc)
print("[+] local_port : ", pplr.local_port)
print("[+] lp_msb : ", pplr.lp_msb)
print("[+] port_type : ", pplr.port_type)
print("[+] lb_cap : ", pplr.lb_cap)
print("[+] lb_en : ", pplr.lb_en)

if args.cmd != 1:
    sys.exit(0)

meta.access_cmd = SXD_ACCESS_CMD_SET
pplr.local_port, pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

pplr.port_type = args.port_type
if args.ingress_lpbk:
    pplr.lb_en |= SXD_PPLR_LB_EN_EXTERNAL_LOCAL_LOOPBACK_E

if args.egress_lpbk:
    pplr.lb_en |= SXD_PPLR_LB_EN_PHY_LOCAL_LOOPBACK_E

print("====================")
print("[+] Set PPLR")
print("[+] local_port : ", pplr.local_port)
print("[+] lp_msb : ", pplr.lp_msb)
print("[+] port_type : ", pplr.port_type)
print("[+] lb_en : ", pplr.lb_en)

rc = sxd_access_reg_pplr(pplr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set PPLR register, rc: %d" % (rc)

print("[+] Set PPLR done. rc:", rc)

meta.access_cmd = SXD_ACCESS_CMD_GET
pplr.local_port, pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

pplr.port_type = args.port_type


print("====================")
print("[+] Get PPLR")
print("[+] local_port : ", pplr.local_port)
print("[+] lp_msb : ", pplr.lp_msb)
print("[+] port_type : ", pplr.port_type)
rc = sxd_access_reg_pplr(pplr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PPLR register, rc: %d" % (rc)

print("[+] Get PPLR done. rc:", rc)
print("[+] local_port : ", pplr.local_port)
print("[+] lp_msb : ", pplr.lp_msb)
print("[+] port_type : ", pplr.port_type)
print("[+] lb_cap : ", pplr.lb_cap)
print("[+] lb_en : ", pplr.lb_en)
print("[+] PPLR register example end")

if args.deinit:
    print("Deinit")
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_pplr(original_pplr, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PPLR register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
