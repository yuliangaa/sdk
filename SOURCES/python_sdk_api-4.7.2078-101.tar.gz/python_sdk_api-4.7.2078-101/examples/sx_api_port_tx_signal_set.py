#!/usr/bin/env python
'''
Sets port TX signal
'''
import sys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_tx_signal_set')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--log_port', default="", help='List of log port to set state for separated by ",". i.e. 0x10001,0x10005')
    parser.add_argument('--state', default="down", choices=["up", "down"], help='Port TX signal - "down" (not allowed) or "up" (allowed)')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def main():
    args = parse_args()     # Parse given arguments
    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    print("[+] Open SDK")
    SWID = 0
    DEVICE_ID = 1
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)
    try:
        # Validate module managment init parameter for examples - not supported when not independent module
        sx_api_sx_sdk_init_p = new_sx_api_sx_sdk_init_t_p()
        rc = sx_api_sdk_init_params_get(handle, sx_api_sx_sdk_init_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to get sdk init params.\n")
            sys.exit(rc)
        sdk_init_attr = sx_api_sx_sdk_init_t_p_value(sx_api_sx_sdk_init_p)
        if (sdk_init_attr.mgmt_params.support_type != SX_MGMT_MODULE_SUPPORT_INDEPENDENT_E):
            print("This example is supported only when SDK init with independent module support - Exiting gracefully")
            sys.exit(0)

        state = args.state
        if args.log_port:
            log_port_list = [int(log_port, 16) for log_port in args.log_port.split(",")]
        else:
            print("No port given - Fetching a port from SDK and setting its state to %s" % state)
            print("Usage: %s <log_port> <up|down> " % sys.argv[0])
            log_port_list_p = new_sx_port_log_id_t_arr(1)
            port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(port_cnt_p, 1)
            rc = sx_api_port_swid_port_list_get(handle, 0, log_port_list_p, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("Failed to get port_list, rc %d" % rc)
                sys.exit(rc)

            log_port = sx_port_log_id_t_arr_getitem(log_port_list_p, 0)
            log_port_list = [log_port]

        # Before set
        old_tx_signal_p = new_sx_port_tx_signal_t_p()
        new_tx_signal_p = new_sx_port_tx_signal_t_p()
        config_tx_signal_p = new_sx_port_tx_signal_t_p()
        oper_tx_signal_p = new_sx_port_tx_signal_oper_t_p()

        for port in log_port_list:
            rc = sx_api_port_tx_signal_attr_get(handle, SX_ACCESS_CMD_GET, port, old_tx_signal_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_tx_signal_attr_get returns rc:%d" % (rc)))
                sys.exit(rc)

            old_tx_signal = sx_port_tx_signal_t_p_value(old_tx_signal_p)
            print(("Before TX signal set: log_port:0x%x tx_signal:%d." % (port, old_tx_signal.tx_signal_state)))

            new_tx_signal = sx_port_tx_signal_t()
            if state == "up":
                new_tx_signal.tx_signal_state = SX_PORT_TX_SIGNAL_TX_ALLOWED_E
            elif state == "down":
                new_tx_signal.tx_signal_state = SX_PORT_TX_SIGNAL_TX_NOT_ALLOWED_E
            else:
                print("Failed: the TX signal should be up or down.")
                sys.exit(rc)

            print("Setting port 0x%x to state %s (%d)" % (port, state, new_tx_signal.tx_signal_state))
            sx_port_tx_signal_t_p_assign(new_tx_signal_p, new_tx_signal)
            rc = sx_api_port_tx_signal_set(handle, SX_ACCESS_CMD_SET, port, new_tx_signal_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_tx_signal_set returns rc:%d" % (rc)))
                sys.exit(rc)

            print(("rc %d , Setting log_port:0x%x TX signal to %s." % (rc, port, new_tx_signal.tx_signal_state)))

            rc = sx_api_port_tx_signal_attr_get(handle, SX_ACCESS_CMD_GET, port, config_tx_signal_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_tx_signal_attr_get returns rc:%d" % (rc)))
                sys.exit(rc)

            config_tx_signal = sx_port_tx_signal_t_p_value(config_tx_signal_p)
            rc = sx_api_port_tx_signal_oper_get(handle, SX_ACCESS_CMD_GET, port, oper_tx_signal_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_tx_signal_oper_get returns rc:%d" % (rc)))
                sys.exit(rc)

            oper_tx_signal = sx_port_tx_signal_oper_t_p_value(oper_tx_signal_p)
            print(("After TX signal set: log_port:0x%x config tx_signal:%d oper tx_signal:%d." % (port, config_tx_signal.tx_signal_state, oper_tx_signal.oper_state)))

            ext_state_p = new_sx_port_ext_port_state_t_p()
            rc = sx_api_port_state_ext_get(handle, port, ext_state_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_state_ext_get returns rc:%d" % (rc)))
                sys.exit(rc)
            ext_state = sx_port_ext_port_state_t_p_value(ext_state_p)
            print(("Port state: log_port:0x%x oper_state:%d admin state:%d module_state:%d an_speed:%d tx_ready:%d." % (port, ext_state.oper_state, ext_state.admin_state, ext_state.module_state, ext_state.an_speed_state, ext_state.tx_ready_state)))

            if args.deinit:
                if old_tx_signal.tx_signal_state != new_tx_signal.tx_signal_state:
                    print("Setting port 0x%x to old state" % (port))
                    rc = sx_api_port_tx_signal_set(handle, SX_ACCESS_CMD_SET, port, old_tx_signal_p)
                    if rc != SX_STATUS_SUCCESS:
                        print(("Error: sx_api_port_tx_signal_set returns rc:%d" % (rc)))
                        sys.exit(rc)

    finally:
        print("[+] Close SDK ")
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
