#!/usr/bin/env python
'''
This file contains Python command example for the PORT DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''

from test_infra_common import *
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import sxd_api_chip_type_rev_get as sxd_api_chip_type
import argparse

oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}
admin_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 3: 'UP_ONCE'}
module_dict = {0: 'INITIALIZING', 1: 'PLUGGED', 2: 'UNPLUGGED', 3: 'PLUGGED-ERR', 4: 'PLUGGED-DIS', 5: 'UNKNOWN', 255: 'RESERVED'}
oper_speed_dict = {0: 'N/A', 1: '1GB_CX_SGMII', 2: '1GB_KX', 3: '10GB_CX4_XAUI', 4: '10GB_KX4', 5: '10GB_KR', 6: '20GB_KR2', 7: '40GB_CR4',
                   8: '40GB_KR4', 9: '56GB_KR4', 10: '56GB_KX4', 11: '10GB_CR', 12: '10GB_SR', 13: '10GB_ER_LR', 14: '40GB_SR4', 15: '40GB_LR4_ER4',
                   16: '100GB_CR4', 17: '100GB_SR4', 18: '100GB_KR4', 19: '100GB_LR4_ER4', 20: '25GB_CR', 21: '25GB_KR', 22: '25GB_SR', 23: '50GB_CR2',
                   24: '50GB_KR2', 25: '50GB_SR2', 26: '10MB-T', 27: '100MB-TX', 28: '1000MB-T', 29: 'Not supported'}
fec_mode_dict = {0: 'Auto', 1: 'None', 2: 'FC', 4: 'RS', 8: 'LL_RS', 64: 'INT_RS', 1024: 'INT_ELL_RS'}

oper_rate_dict = {0: "N/A",  # Not connected
                  1: "100M",
                  2: "1G",
                  3: "10G",
                  4: "25G",
                  5: "40G",
                  6: "50Gx1",
                  7: "50Gx2",
                  8: "100Gx1",
                  9: "100Gx2",
                  10: "100Gx4",
                  11: "200Gx2",
                  12: "200Gx4",
                  13: "400Gx4",
                  14: "400Gx8",
                  15: "800Gx8"}

INVALID_SLOT_ID = 99


parser = argparse.ArgumentParser(description='sx_api_ports_dump example')
parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
parser.add_argument('--order_by', choices=['port_label'], help='Order output by label port')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
parser.add_argument('--no_mst', action='store_true', help='Do not run mst tools during script execution')
parser.add_argument('--is_alligator', default=False, action='store_true', help='Use argument when running alligator')
args = parser.parse_args()
slot_id = args.slot_id
order_by = args.order_by

unsupported_phy_mode_devices = [SXD_MGIR_HW_DEV_ID_SX, SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]

# For the IB devices we shouldn't display some of the fields, since they are not applicable
ib_devices_list = [SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def port_speed_param_get(handle, log_port):

    admin_speed_p = new_sx_port_speed_capability_t_p()
    oper_speed_p = new_sx_port_oper_speed_t_p()
    oper_rate_p = new_sx_port_rate_e_p()
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    # retrieve the current verbosity level settings
    rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Error: failed to retrieve the current verbosity setting!\n")
        sys.exit(rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    ''' Modify the port module verbosity level to hide additional log messages
        in case if different API type were used for port speed set and get.
    '''
    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_log_verbosity_level_set failed\n")
        sys.exit(rc)

    # get the current port speed value
    rc = sx_api_port_speed_get(handle, int(port_attributes.log_port), admin_speed_p, oper_speed_p)
    if rc == SX_STATUS_SUCCESS:
        port_speed = oper_speed_dict[sx_port_oper_speed_t_p_value(oper_speed_p)]

    elif rc == SX_STATUS_CMD_UNPERMITTED:
        # looks like port was configured with the 'RATE'-type of API
        rc = sx_api_port_rate_get(handle, int(port_attributes.log_port), oper_rate_p)
        if rc == SX_STATUS_SUCCESS:
            port_speed = oper_rate_dict[sx_port_rate_e_p_value(oper_rate_p)]

    if rc != SX_STATUS_SUCCESS:
        port_speed = "N/A"
        print(("Error: something went wrong - can not retrieve the current port speed value, rc = %u.\n" % (rc)))
        sys.exit(rc)

    if args.deinit:
        # restore original verbosity setting
        rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_log_verbosity_level_set failed\n")
            sys.exit(rc)

    return port_speed


def macsec_supported(handle):
    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        return False
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_SUCCESS:
            return True
        else:
            return False
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


def macsec_port_capab_get(handle, port):
    port_capability_p = new_sx_macsec_port_capability_t_p()
    try:
        rc = sx_api_macsec_port_capability_get(handle, port, port_capability_p)
        return bool(port_capability_p.macsec_supported), bool(port_capability_p.macsec_enabled)
    finally:
        delete_sx_macsec_port_capability_t_p(port_capability_p)


##################################################################################################################
max_mtu_size_p = new_sx_port_mtu_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
truncation_att_p = new_sx_port_truncation_t_p()
oper_state_p = new_sx_port_oper_state_t_p()
admin_state_p = new_sx_port_admin_state_t_p()
module_state_p = new_sx_port_module_state_t_p()
vid_p = new_sx_vid_t_p()
admin_mode_p = new_sx_port_phy_mode_t_p()
oper_mode_p = new_sx_port_phy_mode_t_p()

# Get ports count
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 0)
port_attributes_list = new_sx_port_attributes_t_arr(0)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_device_get failed, rc = %d" % (rc))
    sys.exit(rc)
port_cnt = uint32_t_p_value(port_cnt_p)

# Get ports
port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
if (rc != SX_STATUS_SUCCESS):
    print("sx_api_port_device_get failed, rc = %d")
    sys.exit(rc)

device_id, device_hw_revision = sxd_api_chip_type.get_chip_type_and_rev()

# Check whether we are going to dump IB ports
is_ib = True if device_id in ib_devices_list else False

if not is_ib:
    if device_id == SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        is_macsec_supported = macsec_supported(handle)
    else:
        is_macsec_supported = False
else:
    is_macsec_supported = False

print("======================================================================================================================================================")
header = ["log_port", "local_port", "slot", "label_port", "mtu", "truncation", "admin_s", "oper_s", "module_s", "pvid", "oper_speed", "fec_mode", "macsec cap", "macsec en"]
print("|%10s|%10s|%4s|%10s|%10s|%10s|%8s|%8s|%15s|%6s|%15s|%10s|%10s|%9s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10], header[11], header[12], header[13]))
print("======================================================================================================================================================")

slot_count = system_slot_count_get(handle)
slot_port = get_slot_port_mapping(port_attributes_list, port_cnt)

for slot_idx in range(0, slot_count + 1):

    # if slot filter is passed then show only relevant slots.
    if slot_id != INVALID_SLOT_ID and slot_idx != slot_id:
        continue

    if slot_idx not in slot_port.keys():
        continue

    port_attributes_list = slot_port.get(slot_idx)
    if port_attributes_list is None:
        continue

    if order_by == 'port_label':
        port_attributes_list.sort(key=lambda x: x.port_mapping.module_port)

    for port_attributes in port_attributes_list:
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if is_nve or is_cpu:
            continue
        elif is_vport:
            sx_port_mtu_t_p_assign(max_mtu_size_p, 0)
            sx_port_mtu_t_p_assign(oper_mtu_size_p, 0)
            oper_speed = 'N/A'
            pvid = 'N/A'
        elif not is_ib:
            # The following is applicable only for ETH devices
            sx_api_port_mtu_get(handle, int(port_attributes.log_port), max_mtu_size_p, oper_mtu_size_p)
            sx_api_port_ingress_truncation_get(handle, SX_ACCESS_CMD_GET, int(port_attributes.log_port), truncation_att_p)
            sx_api_vlan_port_pvid_get(handle, int(port_attributes.log_port), vid_p)
            pvid = sx_vid_t_p_value(vid_p)
            # Get the current operation speed on specified port
            oper_speed = port_speed_param_get(handle, int(port_attributes.log_port))
            if is_macsec_supported:
                macsec_capable, macsec_enabled = macsec_port_capab_get(handle, int(port_attributes.log_port))
        sx_api_port_state_get(handle, int(port_attributes.log_port), oper_state_p, admin_state_p, module_state_p)

        # The speed is ignored when getting the operational mode
        if device_id in unsupported_phy_mode_devices:
            oper_mode = sx_port_phy_mode_t()
            oper_mode.fec_mode = SX_PORT_FEC_MODE_NONE
        elif args.is_alligator:
            # sx_api_port_phy_mode_get API uses PPLM register which is not supported on Alligator platform
            oper_mode = sx_port_phy_mode_t()
            oper_mode.fec_mode = SX_PORT_FEC_MODE_NONE
        elif not is_vport:
            sx_api_port_phy_mode_get(handle, int(port_attributes.log_port), SX_PORT_PHY_SPEED_10GB, admin_mode_p, oper_mode_p)
            oper_mode = sx_port_phy_mode_t_p_value(oper_mode_p)
        log_port = "0x%x" % port_attributes.log_port

        print("|%10s|%10d|%4d|%10d|%10s|%10s|%8s|%8s|%15s|%6s|%15s|%10s|%10s|%9s|" %
              (log_port,
               port_attributes.port_mapping.local_port,
               port_attributes.port_mapping.slot,
               port_attributes.port_mapping.module_port + 1,
               (str(sx_port_mtu_t_p_value(oper_mtu_size_p) if (is_ib == False) else "N/A")),
               (str(((sx_port_truncation_t_p_value(truncation_att_p).truncation_size) if (sx_port_truncation_t_p_value(truncation_att_p).truncation_size != 0) else "Disable") if (is_ib == False) else "N/A")),
               admin_dict[sx_port_admin_state_t_p_value(admin_state_p)],
               oper_dict[sx_port_oper_state_t_p_value(oper_state_p)],
               module_dict[sx_port_module_state_t_p_value(module_state_p)],
               (str(pvid) if (is_ib == False) else "N/A"),
               (str(oper_speed) if (is_ib == False) else "N/A"),
               ((fec_mode_dict[oper_mode.fec_mode]) if (is_vport == False) else "N/A"),
               ((macsec_capable) if (is_macsec_supported) else "N/A"),
               ((macsec_enabled) if (is_macsec_supported) else "N/A")))


print("======================================================================================================================================================")
sx_api_close(handle)
