#!/usr/bin/env python
"""
This file contains a command example for the VLAN module.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configuration operations:
1. Adds multiple ports to a specific VLAN.
2. Adds a port to a list of VLANs.
3. Retrieves ports in a specific VLAN.
4. Update port's default VLAN.
5. Sets VLAN related port attributes.
6. Sets port's Q-in-Q mode.
7. Sets port's outer tag priority (relevant only when Q-in-Q is enabled).
8. Removes all the ports from the above mentioned VLANs.

"""

import sys
import errno
import errno
import sys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

MIN_VLAN = 2
MAX_VLAN = 4095


def max_vlan_check(vlan):
    vlan = int(vlan)
    assert MIN_VLAN <= vlan <= MAX_VLAN, "max_vlan should be an integer in range [%d, %d]" % (MIN_VLAN, MAX_VLAN)
    return vlan


parser = argparse.ArgumentParser(description='sx_api_vlan_multi_set')
parser.add_argument('--force', default=False, action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
parser.add_argument('--max_vlan', type=max_vlan_check, default=MIN_VLAN, help='Max Vlan number to use in multi set API')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
log_port = port_list[0]

# Adds multiple VLANs to a specific Port.
swid = 0
vlan_arr = new_sx_port_vlans_t_arr(args.max_vlan)
port_vlan = sx_port_vlans_t()

vlan_arr_one = new_sx_vlan_ports_t_arr(1)
vlan_port = sx_vlan_ports_t()
vlan_port.log_port = log_port
vlan_port.is_untagged = 1
sx_vlan_ports_t_arr_setitem(vlan_arr_one, 0, vlan_port)

#######################################################################

max_vlan_in_range = args.max_vlan + 1

# Save current ports in vlan for later de-configuration
original_vlans_ports_list_p = []
original_vlans_ports_cnt_list = []

for i in range(1, max_vlan_in_range):
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    rc = sx_api_vlan_ports_get(handle, swid, i, None, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_vlan_ports_get failed, rc = %d" % (rc))

    port_cnt = uint32_t_p_value(port_cnt_p)
    original_vlan_port_list_p = new_sx_vlan_ports_t_arr(port_cnt)

    rc = sx_api_vlan_ports_get(handle, swid, i, original_vlan_port_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
        sys.exit(rc)

    original_vlans_ports_cnt_list.append(port_cnt)
    original_vlans_ports_list_p.append(original_vlan_port_list_p)

#######################################################################

# Set ports in vlans
for i in range(2, max_vlan_in_range):
    sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, i, vlan_arr_one, 1)

# Delete added ports from vlans
for i in range(2, max_vlan_in_range):
    sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, 0, i, vlan_arr_one, 1)

print("ADD & DELETE - : END of 1 by 1 NOT MULTI FUNC ")

#######################################################################

vlan_arr_one = new_sx_vlan_ports_t_arr(1)
vlan_port = sx_vlan_ports_t()
vlan_port.log_port = log_port
vlan_port.is_untagged = 1
sx_vlan_ports_t_arr_setitem(vlan_arr_one, 0, vlan_port)

for i in range(2, max_vlan_in_range):
    port_vlan.vid = i
    port_vlan.is_untagged = 1
    sx_port_vlans_t_arr_setitem(vlan_arr, 0, port_vlan)
    rc = sx_api_vlan_port_multi_vlan_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_arr, 1)
    print(("sx_api_vlan_port_multi_vlan_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

print("ADD: END of 1 by 1 setting ")

for i in range(2, max_vlan_in_range):
    port_vlan.vid = i
    port_vlan.is_untagged = 1
    sx_port_vlans_t_arr_setitem(vlan_arr, 0, port_vlan)
    rc = sx_api_vlan_port_multi_vlan_set(handle, SX_ACCESS_CMD_DELETE, log_port, vlan_arr, 1)
    print(("sx_api_vlan_port_multi_vlan_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
print("DELETE: END of 1 by 1 setting ")

""" USE MULTI VLANS """
for i in range(2, max_vlan_in_range):
    port_vlan.vid = i
    port_vlan.is_untagged = 1
    sx_port_vlans_t_arr_setitem(vlan_arr, i - 2, port_vlan)

rc = sx_api_vlan_port_multi_vlan_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_arr, max_vlan_in_range - 2)
print(("sx_api_vlan_port_multi_vlan_set [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("Add VLANs 2-%d to port 0x%x , rc: %d " % (max_vlan_in_range - 1, log_port, rc)))

rc = sx_api_vlan_port_multi_vlan_set(handle, SX_ACCESS_CMD_DELETE, log_port, vlan_arr, max_vlan_in_range - 2)
print(("sx_api_vlan_port_multi_vlan_set [rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("Delete VLANs 2-%d to port 0x%x , rc: %d " % (max_vlan_in_range - 1, log_port, rc)))

if args.deinit:
    for i in range(2, max_vlan_in_range):
        rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE_ALL, 0, i, None, 0)
        assert SX_STATUS_SUCCESS == rc, "sx_api_vlan_ports_set failed rc: %d" % (rc)

    for i in range(2, max_vlan_in_range):
        rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, i, original_vlans_ports_list_p[i - 1], original_vlans_ports_cnt_list[i - 1])
        assert SX_STATUS_SUCCESS == rc, "sx_api_vlan_ports_set failed rc: %d" % (rc)

sx_api_close(handle)
