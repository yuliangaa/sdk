#!/usr/bin/env python
'''
This file contains a Python commands example for the sflow module.

Python commands syntax is very similar to the Switch SDK APIs.

You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

\section cases Example Flow

The example below performs the following configuration operations:

1. Open host intreface.

2. Set trap group.

3. Set trap id for sflow.

4. Register trap with host interface.

5. Create sflow on port.

6. Get sflow statistics from port.

7. Delete sflow from port.

'''
import sys
import errno
import time
import os
from test_infra_common import *
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *
from pprint import pprint
import argparse

parser = argparse.ArgumentParser(description='sx_api_sflow_port example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

os.system("command")

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'


def print_all_attr_from_a_struct(struct):
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            print("\t%s = %s" % (attr, getattr(struct, attr)))


print("[+] Redirecting stderr to: %s" % ERR_FILE_LOCATION)
file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)

sys_argv_len = len(sys.argv)
if args.deinit:
    sys_argv_len = sys_argv_len - 1

if sys_argv_len >= 4:
    log_port = int(str(sys.argv[1]), 16)
    rate = int(str(sys.argv[2]), 10)
    sleep_cntr = int(str(sys.argv[3]), 10)
elif sys_argv_len >= 3:
    log_port = int(str(sys.argv[1]), 16)
    rate = int(str(sys.argv[2]), 10)
    sleep_cntr = 60
elif sys_argv_len >= 2:
    log_port = int(str(sys.argv[1]), 16)
    rate = 1000
    sleep_cntr = 60
else:
    log_port = port_list[0]
    rate = 1000
    sleep_cntr = 60

print(("Input parameters: log_port 0x%x , rate %d, sleep %d " % (log_port, rate, sleep_cntr)))

# Open host intreface
sx_fd_p = new_sx_fd_t_p()
rc = sx_api_host_ifc_open(handle, sx_fd_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
sx_fd = sx_fd_t_p_value(sx_fd_p)
print(("sx_api_host_ifc_open 0x%x , rc %d " % (sx_fd.fd, rc)))

# Set trap group
swid = 0
trap_group = 1
sx_trap_group_attributes_p = new_sx_trap_group_attributes_t_p()
sx_trap_group_attributes = sx_trap_group_attributes_t()
sx_trap_group_attributes.prio = SX_TRAP_PRIORITY_BEST_EFFORT
sx_trap_group_attributes.truncate_mode = SX_TRUNCATE_MODE_DISABLE
sx_trap_group_attributes.truncate_size = 0
sx_trap_group_attributes.control_type = SX_CONTROL_TYPE_DEFAULT
sx_trap_group_attributes.is_monitor = False
sx_trap_group_attributes.trap_group = trap_group
sx_trap_group_attributes_t_p_assign(sx_trap_group_attributes_p, sx_trap_group_attributes)
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, swid, trap_group, sx_trap_group_attributes_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_group_set prio 0x%x , rc %d " % (sx_trap_group_attributes.prio, rc)))
trap_group = sx_trap_group_attributes_t_p_value(sx_trap_group_attributes_p).trap_group

# Set trap id for sflow
trap_id = SX_TRAP_ID_ETH_L2_PACKET_SAMPLING
trap_action = SX_TRAP_ACTION_TRAP_2_CPU

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_id_ext_set rc %d " % (rc)))

# Register trap with host interface
sx_user_channel_p = new_sx_user_channel_t_p()
sx_user_channel = sx_user_channel_t()
sx_user_channel.type = SX_USER_CHANNEL_TYPE_FD
sx_user_channel.channel.fd = sx_fd
sx_user_channel_t_p_assign(sx_user_channel_p, sx_user_channel)
rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, swid, trap_id, sx_user_channel_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_host_ifc_trap_id_register_set  rc %d " % (rc)))

# Create sflow on port
sx_port_sflow_params_p = new_sx_port_sflow_params_t_p()
sx_port_sflow_params = sx_port_sflow_params_t()
sx_port_sflow_params.ratio = rate
sx_port_sflow_params.deviation = 0
sx_port_sflow_params.packet_types.uc = 0
sx_port_sflow_params.packet_types.mc = 0
sx_port_sflow_params.packet_types.bc = 0
sx_port_sflow_params.packet_types.uuc = 0
sx_port_sflow_params.packet_types.umc = 0
sx_port_sflow_params_t_p_assign(sx_port_sflow_params_p, sx_port_sflow_params)
rc = sx_api_port_sflow_set(handle, SX_ACCESS_CMD_ADD, log_port, sx_port_sflow_params_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_port_sflow_set ADD rc %d %x" % (rc, log_port)))

print("At this point, if traffic occurs, User should wait for sflow collection based on sleep counter\n"
      "Since this is only an example, will not sleep at all")

# Get sflow statistics from port
sx_port_sflow_statistics_p = new_sx_port_sflow_statistics_t_p()
sx_port_sflow_statistics = sx_port_sflow_statistics_t()
sx_port_sflow_statistics_t_p_assign(sx_port_sflow_statistics_p, sx_port_sflow_statistics)
rc = sx_api_port_sflow_statistics_get(handle, SX_ACCESS_CMD_READ, log_port, sx_port_sflow_statistics_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
print(("sx_api_port_sflow_statistics_get READ rc %d %x" % (rc, log_port)))
print(("sx_port_sflow_statistics : %d " % (sx_port_sflow_statistics.count_sample_drop)))

if args.deinit:
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, swid, trap_id, sx_user_channel_p)
    if (rc != SX_STATUS_SUCCESS):
        print(("sx_api_host_ifc_trap_id_register_set failed; rc=%d" % (rc)))
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print(("sx_api_host_ifc_trap_id_ext_set failed; rc=%d" % (rc)))
        sys.exit(rc)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, swid, trap_group, sx_trap_group_attributes_p)
    if (rc != SX_STATUS_SUCCESS):
        print(("sx_api_host_ifc_trap_group_ext_set failed; rc=%d" % (rc)))
        sys.exit(rc)

    #  Delete sflow from port
    sx_port_sflow_params_p = new_sx_port_sflow_params_t_p()
    sx_port_sflow_params_t_p_assign(sx_port_sflow_params_p, sx_port_sflow_params)
    rc = sx_api_port_sflow_set(handle, SX_ACCESS_CMD_DELETE, log_port, sx_port_sflow_params_p)
    if (rc != SX_STATUS_SUCCESS):
        print(("sx_api_port_sflow_set failed; rc=%d" % (rc)))
        sys.exit(rc)
    print(("sx_api_port_sflow_set DELETE rc %d %x" % (rc, log_port)))

sx_api_close(handle)

print("[+] end test")
