#!/usr/bin/env python
"""
This file contains Python command example for HFT configuration and retrieval of HFT data.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
import time
import inspect
import logging
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse
import json

######################################################
#    functions
######################################################


def check_sdk_rc(rc, errmsg):
    if rc != SX_STATUS_SUCCESS:
        print("Fail: %s, rc=%d" % (errmsg, rc))
        sys.exit(rc)


def host_ifc_open(handle):
    ''' Opening fd for traps '''
    trap_fd = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, trap_fd)
    check_sdk_rc(rc, "Failed to open host_ifc trap_fd")
    return trap_fd


def host_ifc_close(handle, fd):
    ''' Closing host ifc '''
    trap_fd = new_sx_fd_t_p()
    sx_fd_t_p_assign(trap_fd, fd)
    rc = sx_api_host_ifc_close(handle, trap_fd)
    check_sdk_rc(rc, "Failed to close host_ifc trap_fd")


def host_ifc_trap_id_set(handle, cmd, trap_id, trap_group):
    ''' SET/UNSET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id
    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    if cmd == SX_ACCESS_CMD_SET:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU
    else:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT
    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    check_sdk_rc(rc, "sx_api_host_ifc_trap_id_ext_set failed, cmd = %d" % (cmd))


def host_ifc_trap_id_register_set(handle, cmd, trap_id, user_channel, fd):
    ''' REGISTER/DEREGISTER trap id association to the relevant user channel '''
    user_channel_p = new_sx_user_channel_t_p()
    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t()
        user_channel.type = SX_USER_CHANNEL_TYPE_FD
        user_channel.channel.fd = copy_sx_fd_t_p(fd)
    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, 0, trap_id, user_channel_p)
    check_sdk_rc(rc, "sx_api_host_ifc_trap_id_register_set failed")
    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t_p_value(user_channel_p)
    return user_channel


def sx_api_get_enums_from_prefix(prefix):
    sx_api_str_enum_dict = {}
    for item in dir(sx_api):
        if item.startswith(prefix):
            sx_api_str_enum_dict[item] = getattr(sx_api, item)
    return sx_api_str_enum_dict


def wait_bulk_counter_done(trap_fd, trap_id, buffer_id):
    trap_fd_p = copy_sx_fd_t_p(trap_fd)
    pkt_size_p = copy_uint32_t_p(PACKET_SIZE)
    pkt_p = new_uint8_t_arr(PACKET_SIZE)
    recv_info = sx_receive_info_t()
    recv_info_p = copy_sx_receive_info_t_p(recv_info)
    # wait for trap id
    received_packets_list = []
    for i in range(WAIT_HOSTIFC_LOOP):
        rc = sx_lib_host_ifc_recv(trap_fd_p, pkt_p, pkt_size_p, recv_info_p)
        check_sdk_rc(rc, "sx_lib_host_ifc_recv failed")
        recv_info2 = sx_receive_info_t_p_value(recv_info_p)
        recv_info = "recv_info" + str(i)
        received_packets_list.append({recv_info: {'acl_user_id': recv_info2.acl_user_id,
                                                  'dest_lag_port': recv_info2.dest_lag_port,
                                                  'dest_log_port': recv_info2.dest_log_port,
                                                  'dest_port_type': recv_info2.dest_port_type,
                                                  'event_info': recv_info2.event_info,
                                                  'buffer_id': recv_info2.event_info.bulk_cntr_done_info.buffer_id,
                                                  'bulk_cntr_done_status': recv_info2.event_info.bulk_cntr_done_info.status,
                                                  'is_lag': recv_info2.is_lag,
                                                  'original_packet_size': recv_info2.original_packet_size,
                                                  'source_lag_port': recv_info2.source_lag_port,
                                                  'source_log_port': recv_info2.source_log_port,
                                                  'trap_id': recv_info2.trap_id}})
        if recv_info2.trap_id == trap_id and recv_info2.event_info.bulk_cntr_done_info.buffer_id == buffer_id:
            break
        time.sleep(WAIT_HOSTIFC_INTV)


def bulk_cntr_hft_buffer_set(handle, cmd, args, counter_buffer_id):
    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    sample_config = None
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            sample_config = hft_config(handle, args)
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_HFT_E
            counter_buffer_key.key.hft_key.sample_count = args.sample_count
            counter_buffer_key.key.hft_key.min_sample_interval = args.sample_interval
            counter_buffer_key.key.hft_key.hft_config = sample_config
        else:
            cntr_buffer = counter_buffer_id
            counter_buffer_key = None
        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return None, None
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer, sample_config
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)


def start_collect_hft_counters(handle, counter_buffer):
    cmd = SX_ACCESS_CMD_READ
    cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed".format(cmd_str))


def read_metadata(handle, sample_idx, counter_buffer):
    cntr_read_key = sx_bulk_cntr_read_key_t()
    cntr_data_p = new_sx_bulk_cntr_data_t_p()
    cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_HFT_E
    cntr_read_key.key.hft_key.key_type = SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_METADATA_E
    cntr_read_key.key.hft_key.hft_key_data.metadata_key.sample_key.sample_iteration = sample_idx
    rc = sx_api_bulk_counter_transaction_get(handle, cntr_read_key, counter_buffer, cntr_data_p)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for metadata key")
    hftdata = sx_bulk_cntr_data_t_p_value(cntr_data_p)
    return hftdata


def read_metadata_config(sample_config):
    metadata_config = sample_config.metadata_config
    metadata_list_sz = sample_config.metadata_config.metadata_list_size
    bool_secs = False
    bool_nsecs = False
    sample_metadata_nsec_ts = []
    for i in range(metadata_list_sz):
        metadata_info = sx_bulk_cntr_hft_sample_metadata_e_arr_getitem(metadata_config.metadata_list, i)
        if metadata_info == SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E:
            bool_secs = True
        if metadata_info == SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E:
            bool_nsecs = True
    return bool_secs, bool_nsecs


def read_print_metadata(handle, args, counter_buffer, sample_config, sample_count):
    bool_secs, bool_nsecs = read_metadata_config(sample_config)
    sample_metadata_nsec_ts = []
    if bool_secs or bool_nsecs:
        print("Metadata -")
        print("==========================================================================")
        header = ["Sample index", "Seconds", "Nano seconds"]
        print("|%20s|%20s|%30s|" % (header[0], header[1], header[2]))
        print("==========================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            hftdata = read_metadata(handle, sample_idx, counter_buffer)
            if bool_secs:
                secs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_secs_p)
            if bool_nsecs:
                nsecs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_nsecs_p)
            print("|%20d|%20s|%30s|" % (sample_idx, str(secs.ts_val) if bool_secs else "N/A", str(nsecs.ts_val) if bool_nsecs else "N/A"))
            print("==========================================================================")
            # Meta data analysis below.
            sec_in_nsecs = nsecs_val = 0
            if bool_secs:
                sec_in_nsecs = secs.ts_val * 1000 * 1000 * 1000
            if bool_nsecs:
                nsecs_val = nsecs.ts_val
            sample_metadata_nsec_ts.append(nsecs_val + sec_in_nsecs)

        if sample_count > 2:
            diff = []
            for i in range(len(sample_metadata_nsec_ts)):
                if i > 1:
                    diff.append(sample_metadata_nsec_ts[i] - sample_metadata_nsec_ts[i - 1])
            return diff
        else:
            return None


def analyze_metadata(handle, args, counter_buffer, sample_config, sample_count, sample_time_diff):
    diff = []
    if sample_time_diff is None:
        sample_metadata_nsec_ts = []
        metadata_config = sample_config.metadata_config
        metadata_list_sz = sample_config.metadata_config.metadata_list_size
        bool_secs = False
        bool_nsecs = False
        for i in range(metadata_list_sz):
            metadata_info = sx_bulk_cntr_hft_sample_metadata_e_arr_getitem(metadata_config.metadata_list, i)
            if metadata_info == SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E:
                bool_secs = True
            if metadata_info == SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E:
                bool_nsecs = True

        if metadata_list_sz != 0:
            for i in range(sample_count):
                sample_idx = i + 1
                hftdata = read_metadata(handle, sample_idx, counter_buffer)
                sec_in_nsecs = nsecs_val = 0
                if bool_secs:
                    secs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_secs_p)
                    sec_in_nsecs = secs.ts_val * 1000 * 1000 * 1000
                if bool_nsecs:
                    nsecs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_nsecs_p)
                    nsecs_val = nsecs.ts_val
                sample_metadata_nsec_ts.append(nsecs_val + sec_in_nsecs)
        if sample_count > 2:
            for i in range(len(sample_metadata_nsec_ts)):
                if i > 1:
                    diff.append(sample_metadata_nsec_ts[i] - sample_metadata_nsec_ts[i - 1])
        else:
            print("Data is not enough for analysis.")
    else:
        diff = sample_time_diff

    if len(diff):
        import statistics
        print("Average sample time is %d usecs" % (statistics.mean(diff) / 1000))
        print("Standard deviation sample time is %d usecs" % (statistics.stdev(diff) / 1000))
        print("Median sample time is %d usecs" % (statistics.median(diff) / 1000))


def read_print_flow_counter_data(handle, args, counter_buffer, sample_config, sample_count):
    print("Flow Counter -")
    print("===============================================================================================")
    header = ["Sample index", "Flow counter id", "Packets", "Bytes"]
    print("|%20s|%20s|%20s|%30s|" % (header[0], header[1], header[2], header[3]))
    print("===============================================================================================")
    for i in range(sample_count):
        sample_idx = i + 1
        for j in range(sample_config.global_counter_config.flow_counter_list_size):
            flow_counter_config = sx_bulk_cntr_hft_sample_flow_counter_config_t_arr_getitem(sample_config.global_counter_config.flow_counter_list, j)
            base_id = flow_counter_config.flow_counter_base_id
            for index in range(flow_counter_config.flow_counter_count):
                flow_counter_id = base_id + index
                hftdata = read_flow_counter_data(handle, sample_idx, j, flow_counter_id, counter_buffer)
                flow_counter_value = sx_flow_counter_set_t_p_value(hftdata.data.hft_data.global_data_info.flow_cntr_p)
                print("|%20d|%20s|%20s|%30s|" % (sample_idx, str(hex(flow_counter_id)), str(flow_counter_value.flow_counter_packets), str(flow_counter_value.flow_counter_bytes)))
                print("===============================================================================================")


def read_port_data(handle, sample_idx, port, counter_buffer):
    cntr_read_key = sx_bulk_cntr_read_key_t()
    cntr_data_p = new_sx_bulk_cntr_data_t_p()
    cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_HFT_E
    cntr_read_key.key.hft_key.key_type = SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_PORT_E
    cntr_read_key.key.hft_key.hft_key_data.port_counter_key.sample_key.sample_iteration = sample_idx
    cntr_read_key.key.hft_key.hft_key_data.port_counter_key.port = port
    rc = sx_api_bulk_counter_transaction_get(handle, cntr_read_key, counter_buffer, cntr_data_p)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port counter key")
    hftdata = sx_bulk_cntr_data_t_p_value(cntr_data_p)
    return hftdata


def read_flow_counter_data(handle, sample_idx, flow_counter_type, flow_counter_id, counter_buffer):
    cntr_read_key = sx_bulk_cntr_read_key_t()
    cntr_data_p = new_sx_bulk_cntr_data_t_p()
    cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_HFT_E
    cntr_read_key.key.hft_key.key_type = SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_GLOBAL_COUNTER_E
    cntr_read_key.key.hft_key.hft_key_data.global_counter_key.sample_key.sample_iteration = sample_idx
    cntr_read_key.key.hft_key.hft_key_data.global_counter_key.global_counter_type = flow_counter_type
    cntr_read_key.key.hft_key.hft_key_data.global_counter_key.global_counter_data.flow_key.cntr_id = flow_counter_id
    rc = sx_api_bulk_counter_transaction_get(handle, cntr_read_key, counter_buffer, cntr_data_p)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port counter key")
    hftdata = sx_bulk_cntr_data_t_p_value(cntr_data_p)
    return hftdata


def read_print_port_general_data(handle, args, counter_buffer, sample_config, sample_count):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_tx_byte = bool_rx_byte = bool_tx_packet = bool_pause_rx = False
    bool_rx_packet = bool_in_discards = bool_pause_tx = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_TRANSMIT_OK_E:
            bool_tx_byte = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_RECEIVED_OK_E:
            bool_rx_byte = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_TRANSMITTED_OK_E:
            bool_tx_packet = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_RECEIVED_OK_E:
            bool_rx_packet = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_2863_GROUP_IF_IN_DISCARDS_E:
            bool_in_discards = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED_E:
            bool_pause_tx = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_RECEIVED_E:
            bool_pause_rx = True

    if bool_tx_byte or bool_rx_byte or bool_tx_packet or bool_rx_packet or bool_in_discards or bool_pause_tx or bool_pause_rx:
        if args.log == "all" or args.log == "port":
            print("Port General - ")
            print("=================================================================================================================================================")
            header = ["Sample index", "Port", "Bytes TX", "Bytes RX", "Packets TX", "Packets RX", "Discards", "Pause TX", "Pause RX"]
            print("|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8]))
            print("=================================================================================================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                hftdata = read_port_data(handle, sample_idx, port, counter_buffer)
                if bool_tx_byte:
                    tx_byte = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.if_out_octets_p)
                if bool_rx_byte:
                    rx_byte = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.if_in_octets_p)
                if bool_tx_packet:
                    tx_packet = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.a_frames_transmitted_ok_p)
                if bool_rx_packet:
                    rx_packet = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.a_frames_received_ok_p)
                if bool_in_discards:
                    in_discards = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.if_in_discards_p)
                if bool_pause_tx:
                    pause_tx = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_transmitted_p)
                if bool_pause_rx:
                    pause_rx = sx_hft_port_ctr_64_t_p_value(hftdata.data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_received_p)

                if args.log == "all" or args.log == "port":
                    print("|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (sample_idx, str(hex(port)), str(tx_byte.counter_value) if bool_tx_byte else "N/A",
                                                                              str(rx_byte.counter_value) if bool_rx_byte else "N/A", str(tx_packet.counter_value) if bool_tx_packet else "N/A",
                                                                              str(rx_packet.counter_value) if bool_rx_packet else "N/A", str(in_discards.counter_value) if bool_in_discards else "N/A",
                                                                              str(pause_tx.counter_value) if bool_pause_tx else "N/A", str(pause_rx.counter_value) if bool_pause_rx else "N/A"))
            if args.log == "all" or args.log == "port":
                print("=================================================================================================================================================")


def read_print_port_ar_data(handle, args, counter_buffer, sample_config, sample_count):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_ar_low = bool_ar_high = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_LOW_E:
            bool_ar_low = True
        elif counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_HIGH_E:
            bool_ar_high = True

    if bool_ar_low or bool_ar_high:
        if args.log == "all" or args.log == "port":
            print("Port AR - ")
            print("=================================================================")
            header = ["Sample index", "Port", "AR low", "AR high"]
            print("|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3]))
            print("=================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                hftdata = read_port_data(handle, sample_idx, port, counter_buffer)
                if bool_ar_low:
                    ar_low = sx_hft_port_ctr_32_t_p_value(hftdata.data.hft_data.port_cntr_info.ar_grades_low_p)
                if bool_ar_high:
                    ar_high = sx_hft_port_ctr_32_t_p_value(hftdata.data.hft_data.port_cntr_info.ar_grades_high_p)
                if args.log == "all" or args.log == "port":
                    print("|%15d|%15s|%15s|%15s|" % (sample_idx, str(hex(port)), str(hex(ar_low.counter_value)) if bool_ar_low else "N/A",
                                                     str(hex(ar_high.counter_value)) if bool_ar_high else "N/A"))
            if args.log == "all" or args.log == "port":
                print("=================================================================")


def read_print_port_cos_prio_data(handle, args, counter_buffer, sample_config, sample_count):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_prio_tx_pause = bool_prio_rx_pause = False
    bool_prio_rx_octets = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E:
            bool_prio_tx_pause = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E:
            bool_prio_rx_pause = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E:
            bool_prio_rx_octets = True

    if bool_prio_tx_pause or bool_prio_rx_pause or bool_prio_rx_octets:
        if args.log == "all" or args.log == "port":
            print("Port Cos Prio - ")
            print("=================================================================================================================================================================================")
            header = ["Counter type", "Sample index", "Port", "Prio 0", "Prio 1", "Prio 2", "Prio 3", "Prio 4", "Prio 5", "Prio 6", "Prio 7"]
            print("|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10]))
            print("=================================================================================================================================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                port_counter_data = read_port_data(handle, sample_idx, port, counter_buffer)
                prio_list_arr_len = uint32_t_p_value(port_counter_data.data.hft_data.port_cntr_info.prio_list_cnt_p)
                prio_tx_pause0 = prio_tx_pause1 = prio_tx_pause2 = prio_tx_pause3 = None
                prio_tx_pause4 = prio_tx_pause5 = prio_tx_pause6 = prio_tx_pause7 = None
                prio_rx_pause0 = prio_rx_pause1 = prio_rx_pause2 = prio_rx_pause3 = None
                prio_rx_pause4 = prio_rx_pause5 = prio_rx_pause6 = prio_rx_pause7 = None
                prio_rx_octets0 = prio_rx_octets1 = prio_rx_octets2 = prio_rx_octets3 = None
                prio_rx_octets4 = prio_rx_octets5 = prio_rx_octets6 = prio_rx_octets7 = None
                for l in range(prio_list_arr_len):
                    prio = sx_cos_ieee_prio_t_arr_getitem(sample_config.port_counter_config.prio_id_list, l)
                    if prio == 0:
                        if bool_prio_tx_pause:
                            prio_tx_pause0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 1:
                        if bool_prio_tx_pause:
                            prio_tx_pause1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 2:
                        if bool_prio_tx_pause:
                            prio_tx_pause2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 3:
                        if bool_prio_tx_pause:
                            prio_tx_pause3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 4:
                        if bool_prio_tx_pause:
                            prio_tx_pause4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 5:
                        if bool_prio_tx_pause:
                            prio_tx_pause5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 6:
                        if bool_prio_tx_pause:
                            prio_tx_pause6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 7:
                        if bool_prio_tx_pause:
                            prio_tx_pause7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                if args.log == "all" or args.log == "port":
                    if bool_prio_tx_pause:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("tx pause"), sample_idx, str(hex(port)),
                                                                                            str(prio_tx_pause0) if prio_tx_pause0 is not None else "N/A",
                                                                                            str(prio_tx_pause1) if prio_tx_pause1 is not None else "N/A",
                                                                                            str(prio_tx_pause2) if prio_tx_pause2 is not None else "N/A",
                                                                                            str(prio_tx_pause3) if prio_tx_pause3 is not None else "N/A",
                                                                                            str(prio_tx_pause4) if prio_tx_pause4 is not None else "N/A",
                                                                                            str(prio_tx_pause5) if prio_tx_pause5 is not None else "N/A",
                                                                                            str(prio_tx_pause6) if prio_tx_pause6 is not None else "N/A",
                                                                                            str(prio_tx_pause7) if prio_tx_pause7 is not None else "N/A"))
                    if bool_prio_rx_pause:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("rx pause"), sample_idx, str(hex(port)),
                                                                                            str(prio_rx_pause0) if prio_rx_pause0 is not None else "N/A",
                                                                                            str(prio_rx_pause1) if prio_rx_pause1 is not None else "N/A",
                                                                                            str(prio_rx_pause2) if prio_rx_pause2 is not None else "N/A",
                                                                                            str(prio_rx_pause3) if prio_rx_pause3 is not None else "N/A",
                                                                                            str(prio_rx_pause4) if prio_rx_pause4 is not None else "N/A",
                                                                                            str(prio_rx_pause5) if prio_rx_pause5 is not None else "N/A",
                                                                                            str(prio_rx_pause6) if prio_rx_pause6 is not None else "N/A",
                                                                                            str(prio_rx_pause7) if prio_rx_pause7 is not None else "N/A"))
                    if bool_prio_rx_octets:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("rx octets"), sample_idx, str(hex(port)),
                                                                                            str(prio_rx_octets0) if prio_rx_octets0 is not None else "N/A",
                                                                                            str(prio_rx_octets1) if prio_rx_octets1 is not None else "N/A",
                                                                                            str(prio_rx_octets2) if prio_rx_octets2 is not None else "N/A",
                                                                                            str(prio_rx_octets3) if prio_rx_octets3 is not None else "N/A",
                                                                                            str(prio_rx_octets4) if prio_rx_octets4 is not None else "N/A",
                                                                                            str(prio_rx_octets5) if prio_rx_octets5 is not None else "N/A",
                                                                                            str(prio_rx_octets6) if prio_rx_octets6 is not None else "N/A",
                                                                                            str(prio_rx_octets7) if prio_rx_octets7 is not None else "N/A"))
                if args.log == "all" or args.log == "port":
                    print("=================================================================================================================================================================================")


def read_print_port_cos_pg_data(handle, args, counter_buffer, sample_config, sample_count):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_pg_hr_watermark = bool_pg_hr_occupancy = False
    bool_pg_watermark = bool_pg_occupancy = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_WATERMARK_E:
            bool_pg_hr_watermark = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_CURRENT_OCCUPANCY_E:
            bool_pg_hr_occupancy = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_WATERMARK_E:
            bool_pg_watermark = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_OCCUPANCY_E:
            bool_pg_occupancy = True

    if bool_pg_hr_watermark or bool_pg_hr_occupancy or bool_pg_watermark or bool_pg_occupancy:
        if args.log == "all" or args.log == "port":
            print("Port Cos PG - ")
            print("=================================================================================================================================================================================")
            header = ["Counter type", "Sample index", "Port", "PG 0", "PG 1", "PG 2", "PG 3", "PG 4", "PG 5", "PG 6", "PG 7"]
            print("|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10]))
            print("=================================================================================================================================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                port_counter_data = read_port_data(handle, sample_idx, port, counter_buffer)
                pg_list_arr_len = uint32_t_p_value(port_counter_data.data.hft_data.port_cntr_info.pg_list_cnt_p)
                pg_hr_watermark0 = pg_hr_watermark1 = pg_hr_watermark2 = pg_hr_watermark3 = None
                pg_hr_watermark4 = pg_hr_watermark5 = pg_hr_watermark6 = pg_hr_watermark7 = None
                pg_hr_occupancy0 = pg_hr_occupancy1 = pg_hr_occupancy2 = pg_hr_occupancy3 = None
                pg_hr_occupancy4 = pg_hr_occupancy5 = pg_hr_occupancy6 = pg_hr_occupancy7 = None
                pg_watermark0 = pg_watermark1 = pg_watermark2 = pg_watermark3 = None
                pg_watermark4 = pg_watermark5 = pg_watermark6 = pg_watermark7 = None
                pg_occupancy0 = pg_occupancy1 = pg_occupancy2 = pg_occupancy3 = None
                pg_occupancy4 = pg_occupancy5 = pg_occupancy6 = pg_occupancy7 = None
                for l in range(pg_list_arr_len):
                    pg = sx_cos_priority_group_t_arr_getitem(sample_config.port_counter_config.pg_id_list, l)
                    if pg == 0:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark0 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy0 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark0 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy0 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 1:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark1 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy1 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark1 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy1 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 2:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark2 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy2 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark2 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy2 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 3:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark3 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy3 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark3 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy3 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 4:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark4 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy4 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark4 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy4 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 5:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark5 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy5 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark5 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy5 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 6:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark6 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy6 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark6 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy6 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                    if pg == 7:
                        if bool_pg_hr_watermark:
                            pg_hr_watermark7 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_watermark_list_p, l).counter_value
                        if bool_pg_hr_occupancy:
                            pg_hr_occupancy7 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p, l).counter_value
                        if bool_pg_watermark:
                            pg_watermark7 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_watermark_list_p, l).counter_value
                        if bool_pg_occupancy:
                            pg_occupancy7 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p, l).counter_value
                if args.log == "all" or args.log == "port":
                    if bool_pg_hr_watermark:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("hr watermark"), sample_idx, str(hex(port)),
                                                                                            str(pg_hr_watermark0) if pg_hr_watermark0 is not None else "N/A",
                                                                                            str(pg_hr_watermark1) if pg_hr_watermark1 is not None else "N/A",
                                                                                            str(pg_hr_watermark2) if pg_hr_watermark2 is not None else "N/A",
                                                                                            str(pg_hr_watermark3) if pg_hr_watermark3 is not None else "N/A",
                                                                                            str(pg_hr_watermark4) if pg_hr_watermark4 is not None else "N/A",
                                                                                            str(pg_hr_watermark5) if pg_hr_watermark5 is not None else "N/A",
                                                                                            str(pg_hr_watermark6) if pg_hr_watermark6 is not None else "N/A",
                                                                                            str(pg_hr_watermark7) if pg_hr_watermark7 is not None else "N/A"))
                    if bool_pg_hr_occupancy:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("hr occupancy"), sample_idx, str(hex(port)),
                                                                                            str(pg_hr_occupancy0) if pg_hr_occupancy0 is not None else "N/A",
                                                                                            str(pg_hr_occupancy1) if pg_hr_occupancy1 is not None else "N/A",
                                                                                            str(pg_hr_occupancy2) if pg_hr_occupancy2 is not None else "N/A",
                                                                                            str(pg_hr_occupancy3) if pg_hr_occupancy3 is not None else "N/A",
                                                                                            str(pg_hr_occupancy4) if pg_hr_occupancy4 is not None else "N/A",
                                                                                            str(pg_hr_occupancy5) if pg_hr_occupancy5 is not None else "N/A",
                                                                                            str(pg_hr_occupancy6) if pg_hr_occupancy6 is not None else "N/A",
                                                                                            str(pg_hr_occupancy7) if pg_hr_occupancy7 is not None else "N/A"))
                    if bool_pg_watermark:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("pg watermark"), sample_idx, str(hex(port)),
                                                                                            str(pg_watermark0) if pg_watermark0 is not None else "N/A",
                                                                                            str(pg_watermark1) if pg_watermark1 is not None else "N/A",
                                                                                            str(pg_watermark2) if pg_watermark2 is not None else "N/A",
                                                                                            str(pg_watermark3) if pg_watermark3 is not None else "N/A",
                                                                                            str(pg_watermark4) if pg_watermark4 is not None else "N/A",
                                                                                            str(pg_watermark5) if pg_watermark5 is not None else "N/A",
                                                                                            str(pg_watermark6) if pg_watermark6 is not None else "N/A",
                                                                                            str(pg_watermark7) if pg_watermark7 is not None else "N/A"))
                    if bool_pg_occupancy:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("pg occupancy"), sample_idx, str(hex(port)),
                                                                                            str(pg_occupancy0) if pg_occupancy0 is not None else "N/A",
                                                                                            str(pg_occupancy1) if pg_occupancy1 is not None else "N/A",
                                                                                            str(pg_occupancy2) if pg_occupancy2 is not None else "N/A",
                                                                                            str(pg_occupancy3) if pg_occupancy3 is not None else "N/A",
                                                                                            str(pg_occupancy4) if pg_occupancy4 is not None else "N/A",
                                                                                            str(pg_occupancy5) if pg_occupancy5 is not None else "N/A",
                                                                                            str(pg_occupancy6) if pg_occupancy6 is not None else "N/A",
                                                                                            str(pg_occupancy7) if pg_occupancy7 is not None else "N/A"))
                if args.log == "all" or args.log == "port":
                    print("=================================================================================================================================================================================")


def read_print_port_cos_tc_data(handle, args, counter_buffer, sample_config, sample_count, is_low):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_tc_ecn_marked = bool_tc_tx_bytes = False
    bool_tc_watermark = bool_tc_occupancy = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_CONG_ECN_MARKED_E:
            bool_tc_ecn_marked = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_TX_OCTETS_E:
            bool_tc_tx_bytes = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_WATERMARK_E:
            bool_tc_watermark = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_CURRENT_OCCUPANCY_E:
            bool_tc_occupancy = True
    if bool_tc_ecn_marked or bool_tc_tx_bytes or bool_tc_watermark or bool_tc_occupancy:
        if args.log == "all" or args.log == "port":
            if is_low:
                print("Port Cos TC Low - ")
            else:
                print("Port Cos TC High - ")
            print("=================================================================================================================================================================================")
            if is_low:
                header = ["Counter type", "Sample index", "Port", "TC 0", "TC 1", "TC 2", "TC 3", "TC 4", "TC 5", "TC 6", "TC 7"]
            else:
                header = ["Counter type", "Sample index", "Port", "TC 8", "TC 9", "TC 10", "TC 11", "TC 12", "TC 13", "TC 14", "TC 15"]
            print("|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10]))
            print("=================================================================================================================================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                port_counter_data = read_port_data(handle, sample_idx, port, counter_buffer)
                tc_list_arr_len = uint32_t_p_value(port_counter_data.data.hft_data.port_cntr_info.tc_list_cnt_p)
                tc_ecn_marked0 = tc_ecn_marked1 = tc_ecn_marked2 = tc_ecn_marked3 = None
                tc_ecn_marked4 = tc_ecn_marked5 = tc_ecn_marked6 = tc_ecn_marked7 = None
                tc_tx_bytes0 = tc_tx_bytes1 = tc_tx_bytes2 = tc_tx_bytes3 = None
                tc_tx_bytes4 = tc_tx_bytes5 = tc_tx_bytes6 = tc_tx_bytes7 = None
                tc_watermark0 = tc_watermark1 = tc_watermark2 = tc_watermark3 = None
                tc_watermark4 = tc_watermark5 = tc_watermark6 = tc_watermark7 = None
                tc_occupancy0 = tc_occupancy1 = tc_occupancy2 = tc_occupancy3 = None
                tc_occupancy4 = tc_occupancy5 = tc_occupancy6 = tc_occupancy7 = None
                for l in range(tc_list_arr_len):
                    tc = sx_port_tc_id_t_arr_getitem(sample_config.port_counter_config.tc_id_list, l)
                    if (tc in range(8) and is_low) or (tc in range(8, 16) and not is_low):
                        if tc == 0 or tc == 8:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark0 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy0 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 1 or tc == 9:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark1 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy1 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 2 or tc == 10:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark2 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy2 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 3 or tc == 11:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark3 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy3 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 4 or tc == 12:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark4 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy4 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 5 or tc == 13:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark5 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy5 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 6 or tc == 14:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark6 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy6 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                        if tc == 7 or tc == 15:
                            if bool_tc_ecn_marked:
                                tc_ecn_marked7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.ecn_marked_tc_list_p, l).counter_value
                            if bool_tc_tx_bytes:
                                tc_tx_bytes7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_octets_list_p, l).counter_value
                            if bool_tc_watermark:
                                tc_watermark7 = sx_hft_buffer_unit_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_watermark_list_p, l).counter_value
                            if bool_tc_occupancy:
                                tc_occupancy7 = sx_hft_buffer_unit_32_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p, l).counter_value
                if args.log == "all" or args.log == "port":
                    if bool_tc_ecn_marked:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("ecn marked"), sample_idx, str(hex(port)),
                                                                                            str(tc_ecn_marked0) if tc_ecn_marked0 is not None else "N/A",
                                                                                            str(tc_ecn_marked1) if tc_ecn_marked1 is not None else "N/A",
                                                                                            str(tc_ecn_marked2) if tc_ecn_marked2 is not None else "N/A",
                                                                                            str(tc_ecn_marked3) if tc_ecn_marked3 is not None else "N/A",
                                                                                            str(tc_ecn_marked4) if tc_ecn_marked4 is not None else "N/A",
                                                                                            str(tc_ecn_marked5) if tc_ecn_marked5 is not None else "N/A",
                                                                                            str(tc_ecn_marked6) if tc_ecn_marked6 is not None else "N/A",
                                                                                            str(tc_ecn_marked7) if tc_ecn_marked7 is not None else "N/A"))
                    if bool_tc_tx_bytes:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("tx bytes"), sample_idx, str(hex(port)),
                                                                                            str(tc_tx_bytes0) if tc_tx_bytes0 is not None else "N/A",
                                                                                            str(tc_tx_bytes1) if tc_tx_bytes1 is not None else "N/A",
                                                                                            str(tc_tx_bytes2) if tc_tx_bytes2 is not None else "N/A",
                                                                                            str(tc_tx_bytes3) if tc_tx_bytes3 is not None else "N/A",
                                                                                            str(tc_tx_bytes4) if tc_tx_bytes4 is not None else "N/A",
                                                                                            str(tc_tx_bytes5) if tc_tx_bytes5 is not None else "N/A",
                                                                                            str(tc_tx_bytes6) if tc_tx_bytes6 is not None else "N/A",
                                                                                            str(tc_tx_bytes7) if tc_tx_bytes7 is not None else "N/A"))
                    if bool_tc_watermark:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("tc watermark"), sample_idx, str(hex(port)),
                                                                                            str(tc_watermark0) if tc_watermark0 is not None else "N/A",
                                                                                            str(tc_watermark1) if tc_watermark1 is not None else "N/A",
                                                                                            str(tc_watermark2) if tc_watermark2 is not None else "N/A",
                                                                                            str(tc_watermark3) if tc_watermark3 is not None else "N/A",
                                                                                            str(tc_watermark4) if tc_watermark4 is not None else "N/A",
                                                                                            str(tc_watermark5) if tc_watermark5 is not None else "N/A",
                                                                                            str(tc_watermark6) if tc_watermark6 is not None else "N/A",
                                                                                            str(tc_watermark7) if tc_watermark7 is not None else "N/A"))
                    if bool_tc_occupancy:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("tc occupancy"), sample_idx, str(hex(port)),
                                                                                            str(tc_occupancy0) if tc_occupancy0 is not None else "N/A",
                                                                                            str(tc_occupancy1) if tc_occupancy1 is not None else "N/A",
                                                                                            str(tc_occupancy2) if tc_occupancy2 is not None else "N/A",
                                                                                            str(tc_occupancy3) if tc_occupancy3 is not None else "N/A",
                                                                                            str(tc_occupancy4) if tc_occupancy4 is not None else "N/A",
                                                                                            str(tc_occupancy5) if tc_occupancy5 is not None else "N/A",
                                                                                            str(tc_occupancy6) if tc_occupancy6 is not None else "N/A",
                                                                                            str(tc_occupancy7) if tc_occupancy7 is not None else "N/A"))
                if args.log == "all" or args.log == "port":
                    print("=================================================================================================================================================================================")


def read_print_port_cos_prio_data(handle, args, counter_buffer, sample_config, sample_count):
    port_counter_list = sample_config.port_counter_config.port_counter_list
    port_counter_list_sz = sample_config.port_counter_config.port_counter_list_size
    bool_prio_tx_pause = bool_prio_rx_pause = False
    bool_prio_rx_octets = False
    for i in range(port_counter_list_sz):
        counter_type = sx_bulk_cntr_hft_sample_port_counter_e_arr_getitem(port_counter_list, i)
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E:
            bool_prio_tx_pause = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E:
            bool_prio_rx_pause = True
        if counter_type == SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E:
            bool_prio_rx_octets = True

    if bool_prio_tx_pause or bool_prio_rx_pause or bool_prio_rx_octets:
        if args.log == "all" or args.log == "port":
            print("Port Cos Prio - ")
            print("=================================================================================================================================================================================")
            header = ["Counter type", "Sample index", "Port", "Prio 0", "Prio 1", "Prio 2", "Prio 3", "Prio 4", "Prio 5", "Prio 6", "Prio 7"]
            print("|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10]))
            print("=================================================================================================================================================================================")
        for i in range(sample_count):
            sample_idx = i + 1
            for j in range(sample_config.port_counter_config.port_list_size):
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                port_counter_data = read_port_data(handle, sample_idx, port, counter_buffer)
                prio_list_arr_len = uint32_t_p_value(port_counter_data.data.hft_data.port_cntr_info.prio_list_cnt_p)
                if bool_prio_tx_pause:
                    tx_pause_arr = port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p
                if bool_prio_rx_pause:
                    rx_pause_arr = port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p
                if bool_prio_rx_octets:
                    rx_octets_arr = port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p
                prio_tx_pause0 = prio_tx_pause1 = prio_tx_pause2 = prio_tx_pause3 = None
                prio_tx_pause4 = prio_tx_pause5 = prio_tx_pause6 = prio_tx_pause7 = None
                prio_rx_pause0 = prio_rx_pause1 = prio_rx_pause2 = prio_rx_pause3 = None
                prio_rx_pause4 = prio_rx_pause5 = prio_rx_pause6 = prio_rx_pause7 = None
                prio_rx_octets0 = prio_rx_octets1 = prio_rx_octets2 = prio_rx_octets3 = None
                prio_rx_octets4 = prio_rx_octets5 = prio_rx_octets6 = prio_rx_octets7 = None
                for l in range(prio_list_arr_len):
                    prio = sx_cos_ieee_prio_t_arr_getitem(sample_config.port_counter_config.prio_id_list, l)
                    if prio == 0:
                        if bool_prio_tx_pause:
                            prio_tx_pause0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets0 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 1:
                        if bool_prio_tx_pause:
                            prio_tx_pause1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets1 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 2:
                        if bool_prio_tx_pause:
                            prio_tx_pause2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets2 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 3:
                        if bool_prio_tx_pause:
                            prio_tx_pause3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets3 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 4:
                        if bool_prio_tx_pause:
                            prio_tx_pause4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets4 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 5:
                        if bool_prio_tx_pause:
                            prio_tx_pause5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets5 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 6:
                        if bool_prio_tx_pause:
                            prio_tx_pause6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets6 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                    if prio == 7:
                        if bool_prio_tx_pause:
                            prio_tx_pause7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_pause:
                            prio_rx_pause7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p, l).counter_value
                        if bool_prio_rx_octets:
                            prio_rx_octets7 = sx_hft_port_ctr_64_t_arr_getitem(port_counter_data.data.hft_data.port_cntr_info.rx_octets_list_p, l).counter_value
                if args.log == "all" or args.log == "port":
                    if bool_prio_tx_pause:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("tx pause"), sample_idx, str(hex(port)),
                                                                                            str(prio_tx_pause0) if prio_tx_pause0 is not None else "N/A",
                                                                                            str(prio_tx_pause1) if prio_tx_pause1 is not None else "N/A",
                                                                                            str(prio_tx_pause2) if prio_tx_pause2 is not None else "N/A",
                                                                                            str(prio_tx_pause3) if prio_tx_pause3 is not None else "N/A",
                                                                                            str(prio_tx_pause4) if prio_tx_pause4 is not None else "N/A",
                                                                                            str(prio_tx_pause5) if prio_tx_pause5 is not None else "N/A",
                                                                                            str(prio_tx_pause6) if prio_tx_pause6 is not None else "N/A",
                                                                                            str(prio_tx_pause7) if prio_tx_pause7 is not None else "N/A"))
                    if bool_prio_rx_pause:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("rx pause"), sample_idx, str(hex(port)),
                                                                                            str(prio_rx_pause0) if prio_rx_pause0 is not None else "N/A",
                                                                                            str(prio_rx_pause1) if prio_rx_pause1 is not None else "N/A",
                                                                                            str(prio_rx_pause2) if prio_rx_pause2 is not None else "N/A",
                                                                                            str(prio_rx_pause3) if prio_rx_pause3 is not None else "N/A",
                                                                                            str(prio_rx_pause4) if prio_rx_pause4 is not None else "N/A",
                                                                                            str(prio_rx_pause5) if prio_rx_pause5 is not None else "N/A",
                                                                                            str(prio_rx_pause6) if prio_rx_pause6 is not None else "N/A",
                                                                                            str(prio_rx_pause7) if prio_rx_pause7 is not None else "N/A"))
                    if bool_prio_rx_octets:
                        print("|%15s|%15d|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|%15s|" % (str("rx octets"), sample_idx, str(hex(port)),
                                                                                            str(prio_rx_octets0) if prio_rx_octets0 is not None else "N/A",
                                                                                            str(prio_rx_octets1) if prio_rx_octets1 is not None else "N/A",
                                                                                            str(prio_rx_octets2) if prio_rx_octets2 is not None else "N/A",
                                                                                            str(prio_rx_octets3) if prio_rx_octets3 is not None else "N/A",
                                                                                            str(prio_rx_octets4) if prio_rx_octets4 is not None else "N/A",
                                                                                            str(prio_rx_octets5) if prio_rx_octets5 is not None else "N/A",
                                                                                            str(prio_rx_octets6) if prio_rx_octets6 is not None else "N/A",
                                                                                            str(prio_rx_octets7) if prio_rx_octets7 is not None else "N/A"))
                if args.log == "all" or args.log == "port":
                    print("=================================================================================================================================================================================")


def read_print_portdata(handle, args, counter_buffer, sample_config, sample_count):
    read_print_port_general_data(handle, args, counter_buffer, sample_config, sample_count)
    read_print_port_cos_prio_data(handle, args, counter_buffer, sample_config, sample_count)
    read_print_port_cos_pg_data(handle, args, counter_buffer, sample_config, sample_count)
    # print tc 0 - 7
    read_print_port_cos_tc_data(handle, args, counter_buffer, sample_config, sample_count, True)
    # print tc 8 - 15
    read_print_port_cos_tc_data(handle, args, counter_buffer, sample_config, sample_count, False)
    read_print_port_ar_data(handle, args, counter_buffer, sample_config, sample_count)


def generate_json_data(handle, args, counter_buffer, sample_config, sample_count):
    bool_secs, bool_nsecs = read_metadata_config(sample_config)
    hft_samples = {}
    for i in range(sample_count):
        sample = {}
        sample_idx = i + 1
        sample['sample_index'] = sample_idx
        # metadata
        if args.json == "all" or args.json == "metadata":
            metadata = {}
            hftdata = read_metadata(handle, sample_idx, counter_buffer)
            if bool_secs:
                secs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_secs_p)
                metadata["sec"] = secs.ts_val
            if bool_nsecs:
                nsecs = sx_hft_ts_32_t_p_value(hftdata.data.hft_data.meta_data_info.start_ts_nsecs_p)
                metadata["nsec"] = nsecs.ts_val
            if bool_secs or bool_nsecs:
                sample['metadata'] = metadata
        # port data
        if args.json == "all" or args.json == "port":
            ports_data = {}
            for j in range(sample_config.port_counter_config.port_list_size):
                port_data = {}
                port = sx_port_log_id_t_arr_getitem(sample_config.port_counter_config.port_list, j)
                port_data['port'] = hex(port)
                hftdata = read_port_data(handle, sample_idx, port, counter_buffer)
                if args.json == "all" or args.json == "port":
                    for counter_type, counter_p in [
                        ('if_out_octets', hftdata.data.hft_data.port_cntr_info.if_out_octets_p),
                        ('if_in_octets', hftdata.data.hft_data.port_cntr_info.if_in_octets_p),
                        ('a_frames_transmitted_ok', hftdata.data.hft_data.port_cntr_info.a_frames_transmitted_ok_p),
                        ('a_frames_received_ok', hftdata.data.hft_data.port_cntr_info.a_frames_received_ok_p),
                        ('if_in_discards', hftdata.data.hft_data.port_cntr_info.if_in_discards_p),
                        ('a_pause_mac_ctrl_frames_transmitted', hftdata.data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_transmitted_p),
                            ('a_pause_mac_ctrl_frames_received', hftdata.data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_received_p)]:
                        if counter_p is not None:
                            counter_val = sx_hft_port_ctr_64_t_p_value(counter_p)
                            port_data[counter_type] = counter_val.counter_value
                        ports_data[j] = port_data

                    pg_list_arr_len = uint32_t_p_value(hftdata.data.hft_data.port_cntr_info.pg_list_cnt_p)
                    if pg_list_arr_len != 0:
                        pgs_data = {}
                        for index in range(sample_config.port_counter_config.pg_id_list_size):
                            pg_data = {}
                            pg = sx_cos_priority_group_t_arr_getitem(sample_config.port_counter_config.pg_id_list, index)
                            pg_data['pg'] = pg
                            for pg_counter_type, counter_list_p in [
                                ('pg_watermark', hftdata.data.hft_data.port_cntr_info.pg_watermark_list_p),
                                ('pg_curr_occupancy', hftdata.data.hft_data.port_cntr_info.pg_curr_occupancy_list_p),
                                ('pg_headroom_watermark', hftdata.data.hft_data.port_cntr_info.headroom_watermark_list_p),
                                    ('pg_headroom_curr_occupancy', hftdata.data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p)]:
                                if counter_list_p is not None:
                                    if 'pg_watermark' == pg_counter_type:
                                        counter_val = sx_hft_buffer_unit_64_t_arr_getitem(counter_list_p, index)
                                    else:
                                        counter_val = sx_hft_buffer_unit_32_t_arr_getitem(counter_list_p, index)
                                    if counter_val is not None:
                                        pg_data[pg_counter_type] = counter_val.counter_value
                            pgs_data[index] = pg_data
                        ports_data[j]['pg_data'] = pgs_data

                    tc_list_arr_len = uint32_t_p_value(hftdata.data.hft_data.port_cntr_info.tc_list_cnt_p)
                    if tc_list_arr_len != 0:
                        tcs_data = {}
                        for index in range(sample_config.port_counter_config.tc_id_list_size):
                            tc_data = {}
                            tc = sx_port_tc_id_t_arr_getitem(sample_config.port_counter_config.tc_id_list, index)
                            tc_data['tc'] = tc
                            for tc_counter_type, counter_list_p in [
                                ('tx_octets', hftdata.data.hft_data.port_cntr_info.tx_octets_list_p),
                                ('tc_watermark', hftdata.data.hft_data.port_cntr_info.tc_watermark_list_p),
                                ('tc_curr_occupancy', hftdata.data.hft_data.port_cntr_info.tc_curr_occupancy_list_p),
                                    ('tc_ecn_marked', hftdata.data.hft_data.port_cntr_info.ecn_marked_tc_list_p)]:
                                if counter_list_p is not None:
                                    if tc_counter_type == 'tx_octets' or tc_counter_type == 'tc_ecn_marked':
                                        counter_val = sx_hft_port_ctr_64_t_arr_getitem(counter_list_p, index)
                                    elif tc_counter_type == 'tc_watermark':
                                        counter_val = sx_hft_buffer_unit_64_t_arr_getitem(counter_list_p, index)
                                    else:  # tc_counter_type == 'tc_curr_occupancy'
                                        counter_val = sx_hft_buffer_unit_32_t_arr_getitem(counter_list_p, index)
                                    if counter_val is not None:
                                        tc_data[tc_counter_type] = counter_val.counter_value
                            tcs_data[index] = tc_data
                        ports_data[j]['tc_data'] = tcs_data

                    prio_list_arr_len = uint32_t_p_value(hftdata.data.hft_data.port_cntr_info.prio_list_cnt_p)
                    if prio_list_arr_len != 0:
                        prios_data = {}
                        for index in range(sample_config.port_counter_config.prio_id_list_size):
                            prio_data = {}
                            prio = sx_cos_ieee_prio_t_arr_getitem(sample_config.port_counter_config.prio_id_list, index)
                            prio_data['prio'] = prio
                            for prio_counter_type, counter_list_p in [
                                ('prio_rx_octets', hftdata.data.hft_data.port_cntr_info.rx_octets_list_p),
                                ('prio_rx_pause', hftdata.data.hft_data.port_cntr_info.rx_pause_per_prio_list_p),
                                    ('prio_tx_pause', hftdata.data.hft_data.port_cntr_info.tx_pause_per_prio_list_p)]:
                                if counter_list_p is not None:
                                    counter_val = sx_hft_port_ctr_64_t_arr_getitem(counter_list_p, index)
                                    if counter_val is not None:
                                        prio_data[prio_counter_type] = counter_val.counter_value
                            prios_data[index] = prio_data
                        ports_data[j]['prio_data'] = prios_data
                    sample['port_data'] = ports_data

        if args.json == "all" or args.json == "flow_counter":
            if sample_config.global_counter_config.flow_counter_list_size != 0:
                # flow counter information.
                flow_counter_sets = {}
                for j in range(sample_config.global_counter_config.flow_counter_list_size):
                    flow_counter_set = {}
                    flow_counter_config = sx_bulk_cntr_hft_sample_flow_counter_config_t_arr_getitem(sample_config.global_counter_config.flow_counter_list, j)
                    base_id = flow_counter_config.flow_counter_base_id
                    for index in range(flow_counter_config.flow_counter_count):
                        flow_counter = {}
                        flow_counter_id = base_id + index
                        hftdata = read_flow_counter_data(handle, sample_idx, j, flow_counter_id, counter_buffer)
                        flow_counter_value = sx_flow_counter_set_t_p_value(hftdata.data.hft_data.global_data_info.flow_cntr_p)
                        flow_counter['id'] = hex(flow_counter_id)
                        flow_counter['packets'] = flow_counter_value.flow_counter_packets
                        flow_counter['bytes'] = flow_counter_value.flow_counter_bytes
                        flow_counter_set[index] = flow_counter
                    flow_counter_sets[j] = flow_counter_set
                sample['flow_counter_set'] = flow_counter_sets
        hft_samples[i] = sample

    json_object = json.dumps(hft_samples, indent=4)
    if args.json_file is not None:
        file_path = args.json_file
    else:
        file_path = DEFAULT_JSON_DUMP_FILE
    with open(file_path, "w") as outfile:
        outfile.write(json_object)
        print("Generated json file %s\n" % (file_path))


def read_bulk_counter_values(handle, args, counter_buffer, sample_config):
    sample_metadata = None
    if args.log is not None:
        if args.log == "all" or args.log == "metadata":
            sample_metadata = read_print_metadata(handle, args, counter_buffer, sample_config, args.sample_count)
        if args.log == "all" or args.log == "port":
            read_print_portdata(handle, args, counter_buffer, sample_config, args.sample_count)
        if args.log == "all" or args.log == "flow_counter":
            read_print_flow_counter_data(handle, args, counter_buffer, sample_config, args.sample_count)
    if args.json is not None:
        generate_json_data(handle, args, counter_buffer, sample_config, args.sample_count)
    analyze_metadata(handle, args, counter_buffer, sample_config, args.sample_count, sample_metadata)


def handle_bulk_read(handle, args):
    trap_id = SX_TRAP_ID_BULK_COUNTER_DONE_EVENT
    sx_fdp = host_ifc_open(handle)
    trap_fd = sx_fd_t_p_value(sx_fdp)

    user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, trap_id, None, sx_fdp)

    # alloc bulk hft port counters.
    counter_buffer, sample_config = bulk_cntr_hft_buffer_set(handle, SX_ACCESS_CMD_CREATE, args, None)

    # collect bulk counters.
    start_collect_hft_counters(handle, counter_buffer)

    # wait for mocs done.
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    # collect bulk counters.
    read_bulk_counter_values(handle, args, counter_buffer, sample_config)

    # dealloc bulk hft port counters.
    bulk_cntr_hft_buffer_set(handle, SX_ACCESS_CMD_DESTROY, args, counter_buffer)

    user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, trap_id, user_channel, None)

    host_ifc_close(handle, trap_fd)

    return 0


def handle_bulk_buffer_limits_get(handle, args):
    bulk_cntr_attr = sx_bulk_cntr_attr_t()
    bulk_cntr_attr.buffer_type = SX_BULK_CNTR_BUFFER_TYPE_HFT
    bulk_cntr_attr_p = new_sx_bulk_cntr_attr_t_p()
    sx_bulk_cntr_attr_t_p_assign(bulk_cntr_attr_p, bulk_cntr_attr)
    try:
        rc = sx_api_bulk_counter_attr_get(handle, bulk_cntr_attr_p)
        check_sdk_rc(rc, "sx_api_bulk_counter_attr_get failed")
        bulk_cntr_attr = sx_bulk_cntr_attr_t_p_value(bulk_cntr_attr_p)
        print("Max limit: %d" % (bulk_cntr_attr.max_buffer_limit))
        print("Current utilization: %d" % (bulk_cntr_attr.current_buffer_utilization))
    finally:
        delete_sx_bulk_cntr_attr_t_p(bulk_cntr_attr_p)
    return rc


def handle_bulk_buffer_limits_set(handle, args):
    bulk_cntr_attr = sx_bulk_cntr_attr_t()
    bulk_cntr_attr.buffer_type = SX_BULK_CNTR_BUFFER_TYPE_HFT
    bulk_cntr_attr.max_buffer_limit = args.max_buffer
    bulk_cntr_attr_p = new_sx_bulk_cntr_attr_t_p()
    sx_bulk_cntr_attr_t_p_assign(bulk_cntr_attr_p, bulk_cntr_attr)
    try:
        rc = sx_api_bulk_counter_attr_set(handle, bulk_cntr_attr_p)
        check_sdk_rc(rc, "sx_api_bulk_counter_attr_set failed")
    finally:
        delete_sx_bulk_cntr_attr_t_p(bulk_cntr_attr_p)
    return rc


def get_meta_data_config(handle, args):
    metadata_info_type = args.metadata_type
    if metadata_info_type is not None:
        secs_info = []
        nsecs_info = []
        metadata_config = sx_bulk_cntr_hft_sample_metadata_config_t()
        if metadata_info_type == "secs" or metadata_info_type == "all":
            secs_info = [SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E]
        if metadata_info_type == "nsecs" or metadata_info_type == "all":
            nsecs_info = [SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E]

        metadata_info_type_list = nsecs_info + secs_info
        metadata_config.metadata_list_size = len(metadata_info_type_list)
        for idx, info_type in enumerate(metadata_info_type_list):
            sx_bulk_cntr_hft_sample_metadata_e_arr_setitem(metadata_config.metadata_list, idx, metadata_info_type_list[idx])
        return metadata_config
    else:
        return None


def get_all_ports(handle):
    # Get ports count
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    port_attributes_list = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
    check_sdk_rc(rc, "sx_api_port_device_get failed")
    port_cnt = uint32_t_p_value(port_cnt_p)

    # Get ports
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
    check_sdk_rc(rc, "sx_api_port_device_get failed")
    port_list = []
    for i in range(port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        width = port_attributes.port_mapping.width
        if is_nve or is_cpu or is_vport or width > 4:
            continue
        port_list.append(port_attributes.log_port)
    return port_list


def port_mapping_attr_width_get(handle, port):
    log_port_list_arr = new_sx_port_log_id_t_arr(1)
    port_mapping_list_arr = new_sx_port_mapping_t_arr(1)
    port_cnt = 1
    sx_port_log_id_t_arr_setitem(log_port_list_arr, 0, port)
    rc = sx_api_port_mapping_get(handle, log_port_list_arr, port_mapping_list_arr, port_cnt)
    check_sdk_rc(rc, "Failed to get port mapping attributes.")
    port_mapping_att = sx_port_mapping_t_arr_getitem(port_mapping_list_arr, 0)
    return port_mapping_att.width


def get_port_counter_config(handle, args):
    port_counter_type = args.port_counter_type
    # port counter config
    if port_counter_type is not None:
        port_counter_config = sx_bulk_cntr_hft_sample_port_counter_config_t()
        per_port_counter_type_list = []
        cos_prio_port_counter_type_list = []
        cos_pg_port_counter_type_list = []
        cos_tc_port_counter_type_list = []
        ar_port_counter_type_list = []
        if port_counter_type == "per_port" or port_counter_type == "all":
            per_port_counter_type_list = [SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_TRANSMIT_OK_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_RECEIVED_OK_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_TRANSMITTED_OK_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_RECEIVED_OK_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_2863_GROUP_IF_IN_DISCARDS_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_RECEIVED_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_LOW_E,
                                          SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_HIGH_E]

        if port_counter_type == "cos_prio" or port_counter_type == "all":
            cos_prio_port_counter_type_list = [SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E,
                                               SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E,
                                               SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E]

        if port_counter_type == "cos_pg" or port_counter_type == "all":
            cos_pg_port_counter_type_list = [SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_WATERMARK_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_CURRENT_OCCUPANCY_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_WATERMARK_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_OCCUPANCY_E]

        if port_counter_type == "cos_tc" or port_counter_type == "all":
            cos_tc_port_counter_type_list = [SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_TX_OCTETS_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_CONG_ECN_MARKED_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_WATERMARK_E,
                                             SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_CURRENT_OCCUPANCY_E]

        port_counter_type_list = per_port_counter_type_list + cos_prio_port_counter_type_list + cos_pg_port_counter_type_list + cos_tc_port_counter_type_list + ar_port_counter_type_list
        port_counter_config.port_counter_list_size = len(port_counter_type_list)
        for idx, counter_type in enumerate(port_counter_type_list):
            sx_bulk_cntr_hft_sample_port_counter_e_arr_setitem(port_counter_config.port_counter_list, idx, port_counter_type_list[idx])
        if args.tc == "all":
            for idx in range(16):
                sx_port_tc_id_t_arr_setitem(port_counter_config.tc_id_list, idx, idx)
            port_counter_config.tc_id_list_size = 16
        else:
            tc_list = [int(tc_id) for tc_id in args.tc.split(",")]
            port_counter_config.tc_id_list_size = len(tc_list)
            for idx, tc_id in enumerate(tc_list):
                sx_port_tc_id_t_arr_setitem(port_counter_config.tc_id_list, idx, tc_id)
        if args.pg == "all":
            for idx in range(8):
                sx_cos_priority_group_t_arr_setitem(port_counter_config.pg_id_list, idx, idx)
            port_counter_config.pg_id_list_size = 8
        else:
            pg_list = [int(pg_id) for pg_id in args.pg.split(",")]
            port_counter_config.pg_id_list_size = len(pg_list)
            for idx, pg_id in enumerate(pg_list):
                sx_cos_priority_group_t_arr_setitem(port_counter_config.pg_id_list, idx, pg_id)
        if args.prio == "all":
            for idx in range(8):
                sx_cos_ieee_prio_t_arr_setitem(port_counter_config.prio_id_list, idx, idx)
            port_counter_config.prio_id_list_size = 8
        else:
            prio_list = [int(prio_id) for prio_id in args.prio.split(",")]
            port_counter_config.prio_id_list_size = len(prio_list)
            for idx, prio_id in enumerate(prio_list):
                sx_cos_ieee_prio_t_arr_setitem(port_counter_config.prio_id_list, idx, prio_id)
        if args.log_port == "all":
            port_list = get_all_ports(handle)
        else:
            port_list = []
            given_port_list = [int(log_port, 16) for log_port in args.log_port.split(",")]
            for port in given_port_list:
                width = port_mapping_attr_width_get(handle, port)
                if width <= 4:
                    port_list.append(port)

        if len(port_list) == 0:
            print("Warning - High frequency telemetry is not applicable on any given ports, make sure network ports are used with width 4x or less.")

        port_counter_config.port_list_size = len(port_list)
        for idx, port in enumerate(port_list):
            sx_port_log_id_t_arr_setitem(port_counter_config.port_list, idx, port)
        if args.clear_watermark:
            port_counter_config.read_clear_buffer_watermark = True

        return port_counter_config


def get_global_counter_config(handle, args):
    global_counter_config = sx_bulk_cntr_hft_sample_global_counter_config_t()
    if args.flow_counter_base is not None and args.flow_counter_num is not None:
        flow_counter_list = [int(flow_counter, 16) for flow_counter in args.flow_counter_base.split(",")]
        flow_counter_num_list = [int(flow_counter_num, 10) for flow_counter_num in args.flow_counter_num.split(",")]
        # fill in the global counter types
        for i in range(len(flow_counter_list)):
            sx_bulk_cntr_hft_sample_global_counter_e_arr_setitem(global_counter_config.global_counter_list, i, SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_0_E + i)
            global_counter_config.global_counter_list_size = global_counter_config.global_counter_list_size + 1

        idx = 0
        # fill in the flow counter details
        for base, num in zip(flow_counter_list, flow_counter_num_list):
            flow_counter = sx_bulk_cntr_hft_sample_flow_counter_config_t()
            flow_counter.flow_counter_base_id = base
            flow_counter.flow_counter_count = num
            flow_counter.flow_counter_type = SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_0_E + idx
            sx_bulk_cntr_hft_sample_flow_counter_config_t_arr_setitem(global_counter_config.flow_counter_list, idx, flow_counter)
            idx = idx + 1
        global_counter_config.flow_counter_list_size = len(flow_counter_list)
    else:
        global_counter_config.global_counter_list_size = 0
        global_counter_config.flow_counter_list_size = 0

    return global_counter_config


def hft_config(handle, args):
    hft_sample_config = sx_bulk_cntr_hft_sample_config_t()
    # Meta data config
    hft_sample_config.metadata_config = get_meta_data_config(handle, args)
    # Port counter data config
    hft_sample_config.port_counter_config = get_port_counter_config(handle, args)
    # global data config
    hft_sample_config.global_counter_config = get_global_counter_config(handle, args)

    return hft_sample_config


""" ############################################################################################ """


def print_help():
    print("""Example :\n
        sx_api_bulk_counter_hft.py --read bulk --tc all --pg 3,4,5 --prio 1,5,6 --log_port all --port_counter_type all --metadata_type all --sample_count 1 --sample_interval 100 --clear_watermark False --log all --json all
        sx_api_bulk_counter_hft.py --buffer_limit set --max_buffer 500
        sx_api_bulk_counter_hft.py --buffer_limit get
        """
          )


def parse_arguments():
    parser = argparse.ArgumentParser(description='sx_api_bulk_cntr_hft')
    parser.add_argument("--read", choices=["bulk"], help='read hft counters.')
    parser.add_argument("--sample_count", type=int, help='number of sample to read.')
    parser.add_argument("--sample_interval", default=0, type=int, help='interval between each sample read')
    parser.add_argument('--tc', default="all", help='List of tc to be enabled in hft. values are all or 1,2,3..')
    parser.add_argument('--pg', default="all", help='List of pg to be enabled in hfti. values are all or 0,1,2...')
    parser.add_argument('--prio', default="all", help='List of ieee prio to be enabled in hft. values are all or 1,2,3..')
    parser.add_argument('--log_port', default="", help='List of log port to be enabled in hft. values are all or 0x10001, 0x10005')
    parser.add_argument('--port_counter_type', choices=["all", "per_port", "cos_prio", "cos_pg", "cos_tc"], help='List of counter type to fetch')
    parser.add_argument('--clear_watermark', type=bool, default=False, help='List of counter type to fetch')
    parser.add_argument('--metadata_type', choices=["all", "secs", "nsecs"], help='List metadata information types to be enabled in hft.')
    parser.add_argument("--buffer_limit", choices=["get", "set"], help='hft buffer limit set or get')
    parser.add_argument("--max_buffer", type=int, help='Set maximum buffer limit in MBs')
    parser.add_argument("--log", choices=["all", "metadata", "port", "flow_counter"], help='print on console metadata or port or all information')
    parser.add_argument("--json", choices=["all", "metadata", "port", "flow_counter"], help='generate json for metadata or port or all information')
    parser.add_argument("--json_file", help='json absolute file name.')
    parser.add_argument('--flow_counter_base', help='Single or two flow counter base in hex format separated by ,')
    parser.add_argument('--flow_counter_num', help='Single or two flow counter numbers to be enabled in hft.')
    try:
        args = parser.parse_args()
    except SystemExit:
        print("\n\n")
        print_help()
        sys.exit()
    return args

######################################################
#    main
######################################################


def main():
    args = parse_arguments()

    rc, handle = sx_api_open(None)
    check_sdk_rc(rc, "Failed to open api handle.\nPlease check that SDK is running.")

    chip_type = get_chip_type(handle)
    if (chip_type < SX_CHIP_TYPE_SPECTRUM4):
        print("High frequency telemetry is supported only on SPC4 and above based systems")
        sys.exit(0)
    try:
        if args.read:
            rc = handle_bulk_read(handle, args)
            check_sdk_rc(rc, "failed to handle bulk read operation.")
        elif args.buffer_limit:
            if args.buffer_limit == "get":
                rc = handle_bulk_buffer_limits_get(handle, args)
                check_sdk_rc(rc, "failed to get buffer limits")
            else:
                rc = handle_bulk_buffer_limits_set(handle, args)
                check_sdk_rc(rc, "failed to set buffer limits")
        else:
            print_help()

    finally:
        rc = sx_api_close(handle)
        check_sdk_rc(rc, "failed to close sx api")

    sys.exit(rc)


if __name__ == "__main__":
    PACKET_SIZE = 1024
    WAIT_HOSTIFC_INTV = 0.5
    # expect hft to finish before 10000 MOCS done events from bulk sessions running in parallel
    WAIT_HOSTIFC_LOOP = 10000
    DEFAULT_JSON_DUMP_FILE = "/var/log/sdk_dbg/hft.json"
    main()
