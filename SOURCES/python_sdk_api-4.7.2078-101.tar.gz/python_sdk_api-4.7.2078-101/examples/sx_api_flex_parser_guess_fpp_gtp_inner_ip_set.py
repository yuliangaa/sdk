#!/usr/bin/env python
"""
This script file should serve as an example of how to use flex parser to parse GTPv1 followed by either ipv4 or ipv6 header and match the inner sip field. We create a guessing empty FPH, then set the transition based on ip version.
add this to traffic_generator.py when sending packets
load_contrib('gtp')
the packet is:
Ether(dst='00:11:22:33:44:55')/IP(src='1.1.1.1', dst='2.2.2.2',chksum=0xff7f)/UDP(sport=5000, dport=2152)/GTPHeader(teid=0x11112222, gtp_type=0x4)/IP(src='192.168.1.44')
"""
import sys
import os
import argparse
import struct
import socket
import test_infra_common

parser = argparse.ArgumentParser(description='sx_api_flex_parser example')
parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
args = parser.parse_args()
from python_sdk_api.sx_api import *
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)
######################################################
#    defines
######################################################
TEST_SUCCESS = 1
TEST_FAILED = 0
key_handle_p = new_sx_acl_key_type_t_p()
key_arr = new_sx_acl_key_t_arr(1)
region_id_p = new_sx_acl_region_id_t_p()
acl_region_group = sx_acl_region_group_t()
acl_id_p = new_sx_acl_id_t_p()
group_id_p = new_sx_acl_id_t_p()
acl_id_arr = new_sx_acl_id_t_arr(5)
direction = SX_ACL_DIRECTION_INGRESS
rule = sx_flex_acl_flex_rule_t()
port = 0x10001
gtp_port = 2152
fpp = SX_FLEX_PARSER_HEADER_FPP1
fpp2 = SX_FLEX_PARSER_HEADER_FPP2
group_id = 0


def ip2int(addr):
    return struct.unpack("!I", socket.inet_aton(addr))[0]


def create_delete_fpp_rule(handle, fpp):
    # create key
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_FPP_1_TOUCHED)
    sx_acl_key_t_arr_setitem(key_arr, 1, FLEX_ACL_KEY_FPP_2_TOUCHED)
    sx_acl_key_t_arr_setitem(key_arr, 2, FLEX_ACL_KEY_INNER_SIP)
    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 3,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    # creates acl region
    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               16,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    region_id = sx_acl_region_id_t_p_value(region_id_p)
    # create acl
    acl_region_group.regions.acl_packet_agnostic.region = region_id
    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        SX_ACL_DIRECTION_INGRESS,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    # Create ACL group
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              SX_ACL_DIRECTION_INGRESS,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"
    # add acl to acl group
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              1,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"
    group_id = sx_acl_id_t_p_value(group_id_p)
    sx_lib_flex_acl_rule_init(0, 10, rule)
    key_desc0 = sx_flex_acl_key_desc_t()
    key_desc0.key_id = FLEX_ACL_KEY_FPP_TOUCHED_START + SX_FLEX_PARSER_HEADER_FPP1
    key_desc0.key.fpp_touched = True
    key_desc0.mask.fpp_touched = True
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc0)

    key_desc0 = sx_flex_acl_key_desc_t()
    key_desc0.key_id = FLEX_ACL_KEY_FPP_TOUCHED_START + fpp
    key_desc0.key.fpp_touched = True
    key_desc0.mask.fpp_touched = True
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 1, key_desc0)

    ip = ip2int("192.168.1.44")
    mask = ip2int("255.255.255.0")
    key_desc4 = sx_flex_acl_key_desc_t()
    key_desc4.key_id = FLEX_ACL_KEY_INNER_SIP
    key_desc4.key.sip.version = SX_IP_VERSION_IPV4
    key_desc4.key.sip.addr.ipv4.s_addr = ip
    key_desc4.mask.sip.version = SX_IP_VERSION_IPV4
    key_desc4.mask.sip.addr.ipv4.s_addr = mask
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 2, key_desc4)

    rule.key_desc_count = 3
    rule.valid = 1
    # Create Flow Counter
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, SX_FLOW_COUNTER_TYPE_PACKETS, counter_p)
    if rc != SX_STATUS_SUCCESS:
        printf("Failed to create ACL flow counter", rc)
    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_COUNTER
    action1.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    rule.action_count = 1

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)
    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"
    # bind port to existing group
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  port,
                                  group_id)
    print("Port %d is bound to group %d  rc: %d" % (port, group_id, rc))

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_UNBIND,
                                  port,
                                  group_id)
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    acl_region_group.regions.acl_packet_agnostic.region = region_id
    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id_p, rc)
    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy region"
    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, SX_FLOW_COUNTER_TYPE_PACKETS, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flow counter"


def main():
    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()
    try:
        ret_code = TEST_SUCCESS
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("This example doesn't support SPC1 Example - Exiting gracefully")
            sys.exit(0)
        # initialize the flex parser module
        rc = sx_api_flex_parser_init_set(handle, None)

        fpp_cfg = new_sx_flex_parser_fpp_t_p()
        fpp_id = new_sx_flex_parser_fpp_id_t_p()
        fpp_id.fpp_id = fpp
        fpp_cfg.type = SX_FLEX_PARSER_FPP_TYPE_FPH
        rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_CREATE, fpp_id, fpp_cfg)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)
        # Set a regular FPH
        fpp_cfg.hdr_len_field.constant = 8
        fpp_cfg.hdr_len_field.offset = 0
        fpp_cfg.hdr_len_field.size = 0
        fpp_cfg.hdr_len_field.mask = 0
        fpp_cfg.hdr_len_field.shift = 0

        fpp_cfg.protocol_field.offset = 0
        fpp_cfg.protocol_field.size = 1
        fpp_cfg.protocol_field.mask = 0x0

        sx_status = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_SET, fpp_id, fpp_cfg)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        # Set the transition from UDP to our FPH gtpv1 */
        from_ph = sx_flex_parser_header_t()
        to_ph = sx_flex_parser_transition_t()

        from_ph.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
        from_ph.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_UDP_E
        to_ph.transition_value = gtp_port
        to_ph.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
        to_ph.next_parser_hdr.hdr_data.parser_hdr_fpp = fpp
        sx_status = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, from_ph, to_ph)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        print("Guess config")
        guess_fpp_cfg = new_sx_flex_parser_fpp_t_p()
        guess_fpp_id = new_sx_flex_parser_fpp_id_t_p()

        guess_fpp_id.fpp_id = fpp2
        guess_fpp_cfg.type = SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY
        rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_CREATE, guess_fpp_id, guess_fpp_cfg)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        # Set a EMPTY FPH
        guess_fpp_cfg.hdr_len_field.constant = 0
        guess_fpp_cfg.hdr_len_field.offset = 0
        guess_fpp_cfg.hdr_len_field.size = 0
        guess_fpp_cfg.hdr_len_field.mask = 0
        guess_fpp_cfg.hdr_len_field.shift = 0

        guess_fpp_cfg.protocol_field.offset = 0
        guess_fpp_cfg.protocol_field.size = 1
        guess_fpp_cfg.protocol_field.mask = 0xF0

        fexp_id0 = new_sx_flex_parser_fexp_id_t_p()
        fexp_id0.fexp_id = SX_FLEX_PARSER_FEXP0
        sx_api_flex_parser_fexp_set(handle, SX_ACCESS_CMD_CREATE, fexp_id0)
        guess_fpp_cfg.fexp_start.enable = True
        guess_fpp_cfg.fexp_start.fexp_id = sx_flex_parser_fexp_id_t_p_value(fexp_id0)

        sx_status = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_SET, guess_fpp_id, guess_fpp_cfg)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        print("New transistion from gtp to guess")
        from_gtp = sx_flex_parser_header_t()
        to_guess = sx_flex_parser_transition_t()

        from_gtp.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
        from_gtp.hdr_data.parser_hdr_fpp = fpp
        to_guess.transition_value = 0
        to_guess.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
        to_guess.next_parser_hdr.hdr_data.parser_hdr_fpp = fpp2
        to_guess.encap_level = SX_FLEX_PARSER_ENCAP_OUTER_E
        sx_status = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, from_gtp, to_guess)
        assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

        print("New transistion from guess to ipv4 ")
        # Set the transition from UDP to our FPH gtpv1 */
        from_guess = sx_flex_parser_header_t()
        to_ipv4 = sx_flex_parser_transition_t()

        from_guess.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
        from_guess.hdr_data.parser_hdr_fpp = fpp2
        to_ipv4.transition_value = 0x40
        to_ipv4.current_encap = SX_FLEX_PARSER_ENCAP_OUTER_E
        to_ipv4.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
        to_ipv4.next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV4_E
        to_ipv4.encap_level = SX_FLEX_PARSER_ENCAP_INNER_E
        sx_status = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, from_guess, to_ipv4)

        print("New transistion from guess to ipv6 ")
        from_guess = sx_flex_parser_header_t()
        to_ipv6 = sx_flex_parser_transition_t()

        from_guess.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
        from_guess.hdr_data.parser_hdr_fpp = fpp2
        to_ipv6.transition_value = 0x60
        to_ipv6.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
        to_ipv6.next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_E
        to_ipv6.encap_level = SX_FLEX_PARSER_ENCAP_INNER_E
        sx_status = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, from_guess, to_ipv6)
        create_delete_fpp_rule(handle, fpp2)

        if args.deinit:
            print("Cleanup")
            rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, from_guess, to_ipv4)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)
            rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, from_guess, to_ipv6)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

            rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, from_gtp, to_guess)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

            rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_DESTROY, guess_fpp_id, guess_fpp_cfg)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

            rc = sx_api_flex_parser_fexp_set(handle, SX_ACCESS_CMD_DESTROY, fexp_id0)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_fexp_set failed %s" % (rc)

            rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, from_ph, to_ph)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)
            rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_DESTROY, fpp_id, fpp_cfg)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_transition_set failed %s" % (rc)

            rc = sx_api_flex_parser_deinit_set(handle)
            assert SX_STATUS_SUCCESS == rc, "sx_api_flex_parser_deinit_set failed %s" % (rc)
    except Exception as err:
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        ret_code = TEST_FAILED
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    main()
