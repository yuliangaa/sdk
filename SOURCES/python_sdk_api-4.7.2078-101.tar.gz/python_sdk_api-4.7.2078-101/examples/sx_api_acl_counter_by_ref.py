#!/usr/bin/env python
# -*- python -*-
'''
Counter by reference example for configuration flows
1. extract vlan to gp register
2. acl action to set base counter id
3. acl action to counter by reference
'''
import os
import sys
from python_sdk_api.sx_api import *
from common_infra_acl import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='counter by reference example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    args = parser.parse_args()

    return args


def gp_register_set(handle, reg_id, cmd):
    reg_cnt = 1
    reg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(reg_cnt_p, reg_cnt)
    key = sx_register_key_t()
    key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    key.key.gp_reg.reg_id = reg_id
    reg_list_p = new_sx_register_key_t_arr(reg_cnt)
    sx_register_key_t_arr_setitem(reg_list_p, 0, key)
    rc = sx_api_register_set(handle, cmd,
                             reg_list_p,
                             reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("GP register set failed ")
        sys.exit(rc)
    if (cmd == SX_ACCESS_CMD_CREATE):
        print(" GP register set to %d" % (key.key.gp_reg.reg_id))
    if (cmd == SX_ACCESS_CMD_DESTROY):
        print(" GP register %d is cleared" % (key.key.gp_reg.reg_id))


def bulk_flow_counter_set(handle, counter_cnt, cmd=SX_ACCESS_CMD_CREATE, base_counter_id=None,
                          counter_type=SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES):
    counter_id = new_sx_flow_counter_bulk_data_t_p()
    try:
        counter_attr = sx_flow_counter_bulk_attr_t()
        counter_attr.counter_type = counter_type
        counter_attr.counter_num = counter_cnt
        counter_attr.inc_by_ref_en = True

        if cmd == SX_ACCESS_CMD_DESTROY:
            counter_id.base_counter_id = base_counter_id

        rc = sx_api_flow_counter_bulk_set(handle, cmd, counter_attr, counter_id)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_flow_counter_bulk_set failed rc: %d" % (rc)

        base_counter_id = sx_flow_counter_bulk_data_t_p_value(counter_id)

        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        flow_counter_get_list = []
        for i in range(counter_cnt):
            flow_counter_get_list.append(base_counter_id.base_counter_id + i)
        return flow_counter_get_list

    finally:
        delete_sx_flow_counter_bulk_data_t_p(counter_id)


def main():
    args = parse_args()
    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    reg_id = SX_GP_REGISTER_0_E
    counter_num = 4096

    try:
        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("This example only supports SPC4 and above - Exiting gracefully")
            sys.exit(0)

        parser_params_p = new_sx_flex_parser_param_t_p()
        rc = sx_api_flex_parser_init_set(handle, parser_params_p)
        if rc:
            print("sx_api_flex_parser_init_set failed with rc %d" % (rc))
            sys.exit(1)
        delete_sx_flex_parser_param_t_p(parser_params_p)

        counter_id_list = bulk_flow_counter_set(handle, counter_num)

        gp_register_set(handle, reg_id, SX_ACCESS_CMD_CREATE)

        ext_point_arr = new_sx_extraction_point_t_arr(1)
        ext_point_cnt_p = copy_uint32_t_p(1)

        gp_reg = sx_gp_register_key_t()
        gp_reg.reg_id = reg_id

        reg_key_attr = sx_register_key_attr_t()
        reg_key_attr.gp_reg = gp_reg

        reg_key = sx_register_key_t()
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
        reg_key.key = reg_key_attr

        # extract vlan to gp reg
        ext_point = sx_extraction_point_t()
        ext_point.type = SX_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER_E
        ext_point.offset = 14
        sx_extraction_point_t_arr_setitem(ext_point_arr, 0, ext_point)

        rc = sx_api_flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_SET, reg_key, ext_point_arr, ext_point_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_flex_parser_reg_ext_point_set failed rc: %d" % (rc)

        ingress_log_port = mapPortAndInterfaces(handle, 1)[0]
        add_ports_to_vlan(handle, 1, {ingress_log_port: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, 2, {ingress_log_port: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, 3, {ingress_log_port: SX_TAGGED_MEMBER})

        key_handle_p = new_sx_acl_key_type_t_p()
        acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, [FLEX_ACL_KEY_L4_DESTINATION_PORT])
        key_handle = sx_acl_key_type_t_p_value(key_handle_p)

        rules_list = new_sx_flex_acl_flex_rule_t_arr(100)
        rules = []
        acl_rules_init(rules, rules_list, 100, key_handle, 20)

        region_id_p = new_sx_acl_region_id_t_p()
        acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 10, region_id_p)
        region_id = sx_acl_region_id_t_p_value(region_id_p)

        acl_dir = SX_ACL_DIRECTION_INGRESS
        acl_id_p = new_sx_acl_id_t_p()
        acl_handle(handle, SX_ACCESS_CMD_CREATE, acl_dir, acl_id_p, region_id)
        acl_id = sx_acl_id_t_p_value(acl_id_p)

        group_id_p = new_sx_acl_id_t_p()
        acl_group_handle(handle, SX_ACCESS_CMD_CREATE, acl_dir, group_id_p, [acl_id])
        group_id = sx_acl_id_t_p_value(group_id_p)

        port_bind(handle, SX_ACCESS_CMD_BIND, ingress_log_port, group_id)

        offsets_list = new_sx_acl_rule_offset_t_arr(100)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
        rules[0].valid = 1
        rules[0].key_desc_count = 1

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
        key_desc.key.l4_destination_port = 0x1111
        key_desc.mask.l4_destination_port = 0xffff
        sx_flex_acl_key_desc_t_arr_setitem(rules[0].key_desc_list_p, 0, key_desc)

        rules[0].action_count = 0

        action = sx_flex_acl_flex_action_t()
        action.type = SX_FLEX_ACL_ACTION_ALU_IMM
        action.fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_ADD
        action.fields.action_alu_imm.imm_data_type = SX_ACL_ACTION_ALU_IMM_TYPE_OBJECT_E
        action.fields.action_alu_imm.imm_obj.obj_type = SX_ACL_ACTION_ALU_IMM_OBJ_FLOW_COUNTER_TYPE_E
        action.fields.action_alu_imm.imm_obj.obj_data.base_counter_id = counter_id_list[0]
        action.fields.action_alu_imm.dst_register = reg_id
        action.fields.action_alu_imm.dst_offset = 0
        action.fields.action_alu_imm.size = 16
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        # This is optional. It will make sure the index is valid, but it also disable error indication in MOCBS.cnt_err
        # Note: MOCBS.cnt_err will only set when index > (2^20-1)
        action = sx_flex_acl_flex_action_t()
        action.type = SX_FLEX_ACL_ACTION_ALU_IMM
        action.fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_AND
        action.fields.action_alu_imm.imm_data_type = SX_ACL_ACTION_ALU_IMM_TYPE_UINT16_E
        action.fields.action_alu_imm.imm_data = 0xfff
        action.fields.action_alu_imm.dst_register = reg_id
        action.fields.action_alu_imm.dst_offset = 0
        action.fields.action_alu_imm.size = 16
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        action = sx_flex_acl_flex_action_t()
        action.type = SX_FLEX_ACL_ACTION_COUNTER_BY_REF
        action.fields.action_counter_by_ref.gp_reg_lsb = reg_id
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rules[0])
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rules_list,
                                       1)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

        # Now send packet Ether(dst='00:11:22:33:44:55')/Dot1Q(vlan=1)/IP(src='1.1.1.1', dst='2.2.2.2')/UDP(dport=0x1111)
        read_clear_flow_counter(handle, counter_id_list[0])
        read_clear_flow_counter(handle, counter_id_list[1])
        read_clear_flow_counter(handle, counter_id_list[2])
        if args.deinit:
            print("Clean up")
            port_bind(handle, SX_ACCESS_CMD_UNBIND, ingress_log_port, group_id)

            sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
            rc = sx_api_acl_flex_rules_set(handle,
                                           SX_ACCESS_CMD_DELETE,
                                           region_id,
                                           offsets_list,
                                           rules_list,
                                           1)
            assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

            acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, acl_dir, group_id_p, [])
            acl_handle(handle, SX_ACCESS_CMD_DESTROY, acl_dir, acl_id_p, region_id)
            acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 10, region_id_p)

            acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p, [key_handle])

            bulk_flow_counter_set(handle, counter_num, cmd=SX_ACCESS_CMD_DESTROY, base_counter_id=counter_id_list[0])

            rc = sx_api_flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_UNSET, reg_key, ext_point_arr, ext_point_cnt_p)
            assert SX_STATUS_SUCCESS == rc, "API sx_api_flex_parser_reg_ext_point_set failed rc: %d" % (rc)
            gp_register_set(handle, reg_id, SX_ACCESS_CMD_DESTROY)
            rc = sx_api_flex_parser_deinit_set(handle)
            assert SX_STATUS_SUCCESS == rc, "API sx_api_flex_parser_deinit_set failed rc: %d" % (rc)
            remove_ports_from_vlan(handle, 1, {ingress_log_port: SX_TAGGED_MEMBER})
            add_ports_to_vlan(handle, 1, {ingress_log_port: SX_UNTAGGED_MEMBER})        # By default all ports are untagged members of VLAN 1
            remove_ports_from_vlan(handle, 2, {ingress_log_port: SX_TAGGED_MEMBER})
            remove_ports_from_vlan(handle, 3, {ingress_log_port: SX_TAGGED_MEMBER})

        print("SUCCESS")
    finally:
        rc = sx_api_close(handle)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_close failed rc: %d" % (rc)


if __name__ == "__main__":
    main()
