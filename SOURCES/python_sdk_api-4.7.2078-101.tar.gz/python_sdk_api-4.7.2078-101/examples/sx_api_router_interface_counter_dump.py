#!/usr/bin/env python
# -*- python -*-
'''
Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.

This software product is a proprietary product of Mellanox Technologies, Ltd.
(the "Company") and all right, title, and interest in and to the software product,
including all associated intellectual property rights, are and shall
remain exclusively with the Company.

This software product is governed by the End User License Agreement
provided with the software product.

'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse
import logging


def read_router_counters_basic(handle, counter_id):
    " This function reads router counters of type Basic. "
    counter_set_extended = sx_router_counter_set_extended_t()
    counter_set_extended.type = SX_ROUTER_COUNTER_TYPE_BASIC

    counter_basic_data = sx_router_counter_set_t()

    counter_set_extended.data.rif_basic = counter_basic_data
    counter_set_extended_p = new_sx_router_counter_set_extended_t_p()
    sx_router_counter_set_extended_t_p_assign(counter_set_extended_p, counter_set_extended)

    rc = sx_api_router_counter_extended_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_extended_p)
    if rc != SX_STATUS_PARAM_ERROR and rc != SX_STATUS_SUCCESS:
        print("Unexpected error while fetching counters for rif interface")
        sys.exit(1)
    counter_set_extended = sx_router_counter_set_extended_t_p_value(counter_set_extended_p)

    print_router_basic_counter(counter_id, counter_set_extended.data.rif_basic)


def read_router_counters_extended(handle, counter_id):
    " This function reads router counters of type Enhanced. "
    counter_set_extended = sx_router_counter_set_extended_t()
    counter_set_extended.type = SX_ROUTER_COUNTER_TYPE_ENHANCED

    counter_enhanced_data = sx_router_counter_enhanced_t()
    counter_set_extended.data.rif_enhanced = counter_enhanced_data
    counter_set_extended_p = new_sx_router_counter_set_extended_t_p()
    sx_router_counter_set_extended_t_p_assign(counter_set_extended_p, counter_set_extended)

    rc = sx_api_router_counter_extended_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_extended_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read router counter %d, unexpected error" % (counter_id)

    counter_set_extended = sx_router_counter_set_extended_t_p_value(counter_set_extended_p)
    print_router_extended_counter(counter_id, counter_set_extended.data.rif_enhanced)


def is_router_counter_valid(handle, counter_id):
    """ check if a counter is valid """
    cntr_attr_p = new_sx_router_counter_attributes_t_p()
    cntr_attr = None

    try:
        rc = sx_api_router_counter_attr_get(handle, counter_id, cntr_attr_p)
        if rc == SX_STATUS_SUCCESS:
            cntr_attr = sx_router_counter_attributes_t_p_value(cntr_attr_p)
            return True, cntr_attr.type
        else:
            print("Router Counter %u doesnt exist." % (counter_id))
            return False, None
    finally:
        delete_sx_router_counter_attributes_t_p(cntr_attr_p)


def is_counter_bound_to_rif(handle, counter_id):
    " Get the binding point and make sure RIF is bound to the counter. "
    rif_p = new_sx_router_interface_t_p()
    try:
        rc = sx_api_router_interface_counter_bind_get(handle, counter_id, rif_p)
        if rc == SX_STATUS_SUCCESS:
            is_valid = True
            rif_id = sx_router_interface_t_p_value(rif_p)
            print("counter {:d} is bound to RIF {:d}".format(counter_id, rif_id))
        else:
            is_valid = False
            print("counter {:d} is not bound to any RIF." .format(counter_id))
    finally:
        delete_sx_router_interface_t_p(rif_p)
    return is_valid


def rif_iter_get(handle, cmd, count, rif_id=None, filter_by_vrid=None):
    """
    Get a list of one or more rif identifiers.

    Args:
        handle (int):                       SDK handle
        cmd (enum sx_access_cmd_t):         GET / GET_FIRST / GETNEXT
        count (int):                        Number of rifs to get, max 400
        rif_id (int, optional):             Rif id, default is None
        filter_by_vrid (int, optional):     Vrid to filter the results by, default is None

    Returns:
        All cases will return rif ids list (can be empty) and sdk retrieved count
        GET + Count=0 : ([], SDK Actual Count)
        GET + Count!=0 : ([rif_id], SDK Count)
        GET_FIRST/GETNEXT + Count=0 : ([], SDK Count that should be 0)
        GET_FIRST + Count!=0: ([First sdk_count rifs], SDK Count[<= count])
        GETNEXT + Count !=0: ([Next sdk_count rifs after given rif_id, SDK Count[<= count])
        GETNEXT + Invalid rif_id: ([], SDK Count that should be 0)

    Raises:
        SdkException: In case of SDK error
    """
    rif_list_p = None
    filter_p = None
    rif_key_p = None
    rif_cnt_p = copy_uint32_t_p(count)
    try:

        filter_p = None
        if filter_by_vrid is not None:  # VRID=0 is also valid ID
            logging.debug("Filtering RIFs by VRID {}".format(filter_by_vrid))
            filter = sx_rif_filter_t()
            filter.filter_by_vrid = True
            filter.vrid = filter_by_vrid
            filter_p = copy_sx_rif_filter_t_p(filter)

        rif_key_p = rif_id if rif_id is None else copy_sx_router_interface_t_p(rif_id)
        rif_list_p = None if not count else new_sx_router_interface_t_arr(count)

        rc = sx_api_router_interface_iter_get(handle, cmd, rif_key_p, filter_p, rif_list_p, rif_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("Unexpected error while fetching rif interfaces")
            sys.exit(1)

        sdk_count = uint32_t_p_value(rif_cnt_p)
        logging.debug("Retrieved RIF count = {}".format(sdk_count))
        if not count or not sdk_count:
            return [], sdk_count

        rif_ids = []
        for i in range(sdk_count):
            rif_ids.append(sx_router_interface_t_arr_getitem(rif_list_p, i))

        logging.debug("RIF IDs retrieved: '{}'".format(rif_ids))
        return rif_ids, sdk_count
    finally:
        if rif_list_p is not None:
            delete_sx_router_interface_t_arr(rif_list_p)
        if filter_p is not None:
            delete_sx_rif_filter_t_p(filter_p)
        if rif_key_p is not None:
            delete_sx_router_interface_t_p(rif_key_p)
        delete_uint32_t_p(rif_cnt_p)


def is_rif_valid(handle, rif):
    """ Check that the RIF exists in the SDK"""

    vrid_p = new_sx_router_id_t_p()
    ifc_p = new_sx_router_interface_param_t_p()
    ifc_attr_p = new_sx_interface_attributes_t_p()
    try:
        rc = sx_api_router_interface_get(handle, rif, vrid_p, ifc_p, ifc_attr_p)
        if rc == SX_STATUS_SUCCESS:
            return True
        else:
            if rc == SX_STATUS_ENTRY_NOT_FOUND:
                print("Router Interface - RIF %u doesnt exist." % (rif))
                return False
            else:
                print("Unexpected error %s while fetching rif interface %u. Try again" % (sx_status_dict[rc], rif))
                return False
    finally:
        delete_sx_router_id_t_p(vrid_p)
        delete_sx_router_interface_param_t_p(ifc_p)
        delete_sx_interface_attributes_t_p(ifc_attr_p)


def is_rif_counter_bound(handle, rif, cmd=SX_ACCESS_CMD_READ):
    "get the RIF counter from SDK"

    cntr_id_p = new_sx_router_counter_id_t_p()
    cntr_data_p = new_sx_router_counter_set_extended_t_p()
    is_bound = False
    try:
        rc = sx_api_router_interface_counter_ext_get(handle, cmd, rif, cntr_id_p, cntr_data_p)
        if rc == SX_STATUS_SUCCESS:
            cntr_id = sx_router_counter_id_t_p_value(cntr_id_p)

            # if hex(cntr_id) != hex(abs(SX_ROUTER_COUNTER_ID_INVALID ^ 0xFFFFFFFF)  -1):
            if hex(cntr_id) != hex(SX_ROUTER_COUNTER_ID_INVALID):
                is_bound = True
                # print("counter %u is bound to router interface - RIF %u." % (cntr_id, rif))
                cntr_data = sx_router_counter_set_extended_t_p_value(cntr_data_p)
            else:
                # print("No counter is bound to Router Interface - RIF %u." % (rif))
                # in this case we should return SX_ROUTER_COUNTER_ID_INVALID
                cntr_data = None
        else:

            # print("No counter is bound to router interface - RIF %u." % (rif))
            cntr_id = None
            cntr_data = None
    finally:
        delete_sx_router_counter_id_t_p(cntr_id_p)
        delete_sx_router_counter_set_extended_t_p(cntr_data_p)
    return is_bound, cntr_id, cntr_data


def print_router_common_counter_data(counter_set):
    print("Router ingress good unicast packets:             {:>10}".format(counter_set.router_ingress_good_unicast_packets))
    print("Router ingress good unicast bytes:               {:>10}".format(counter_set.router_ingress_good_unicast_bytes))
    print("Router ingress good multicast packets:           {:>10}".format(counter_set.router_ingress_good_multicast_packets))
    print("Router ingress good multicast bytes:             {:>10}".format(counter_set.router_ingress_good_multicast_bytes))
    print("Router ingress good broadcast packets:           {:>10}".format(counter_set.router_ingress_good_broadcast_packets))
    print("Router ingress good broadcast bytes:             {:>10}".format(counter_set.router_ingress_good_broadcast_bytes))
    print("Router ingress discard packets:                  {:>10}".format(counter_set.router_ingress_discard_packets))
    print("Router ingress discard bytes:                    {:>10}".format(counter_set.router_ingress_discard_bytes))
    print("Router ingress error packets:                    {:>10}".format(counter_set.router_ingress_error_packets))
    print("Router ingress error bytes:                      {:>10}".format(counter_set.router_ingress_error_bytes))
    print("Router egress good unicast packets:              {:>10}".format(counter_set.router_egress_good_unicast_packets))
    print("Router egress good unicast bytes:                {:>10}".format(counter_set.router_egress_good_unicast_bytes))
    print("Router egress good multicast packets:            {:>10}".format(counter_set.router_egress_good_multicast_packets))
    print("Router egress good multicast bytes:              {:>10}".format(counter_set.router_egress_good_multicast_bytes))
    print("Router egress good broadcast packets:            {:>10}".format(counter_set.router_egress_good_broadcast_packets))
    print("Router egress good broadcast bytes:              {:>10}".format(counter_set.router_egress_good_broadcast_bytes))
    print("Router egress discard packets:                   {:>10}".format(counter_set.router_egress_discard_packets))
    print("Router egress discard bytes:                     {:>10}".format(counter_set.router_egress_discard_bytes))
    print("Router egress error packets:                     {:>10}".format(counter_set.router_egress_error_packets))
    print("Router egress error bytes:                       {:>10}".format(counter_set.router_egress_error_bytes))


def print_router_extended_counter(counter_id, counter_set):
    print("###########################################################")
    print("Router counter ID: %d" % (counter_id))
    print("Counter type: Enhanced")
    print("###########################################################")
    print("Router interface IPv4 counters.")
    print_router_common_counter_data(counter_set.ipv4_counters)
    print("###########################################################")
    print("Router interface IPv6 counters.")
    print_router_common_counter_data(counter_set.ipv6_counters)
    print("###########################################################")
    print("Router interface MPLS counters.")
    print_router_common_counter_data(counter_set.mpls_counters)
    print("###########################################################")


def print_router_basic_counter(counter_id, counter_set):
    print("###########################################################")
    print("Router counter ID: %d" % (counter_id))
    print("Counter type: Basic")
    print("###########################################################")
    print_router_common_counter_data(counter_set)
    print("###########################################################")


def handle_all_rifs(handle):
    # we will iterate 10 RIFs at a time
    rif_iter_count = 10

    # get total count of RIFS
    _, rif_total_count = rif_iter_get(handle, SX_ACCESS_CMD_GET, 0)

    if rif_total_count < rif_iter_count:
        rif_iter_count = rif_total_count
    rif_id_list = []
    total_rif_cntr_dict = {}
    cntr_data_dict = {}
    cmd = SX_ACCESS_CMD_GET_FIRST
    last_rif = None
    while rif_total_count > 0:

        # lets get the first/next set of rif_iter_count of RIF Ids
        rif_id_list, tmp_rif_count = rif_iter_get(handle, cmd, rif_iter_count, last_rif)

        for i in range(0, tmp_rif_count):
            total_rif_cntr_dict[rif_id_list[i]] = {}
            rif_has_counter_bound, counter_id, counter_set_extended = is_rif_counter_bound(handle, rif_id_list[i])

            if rif_has_counter_bound:
                total_rif_cntr_dict[rif_id_list[i]]['bound'] = "True"
                total_rif_cntr_dict[rif_id_list[i]]['cntr_id'] = counter_id
                cntr_data_dict[counter_id] = counter_set_extended
                if counter_set_extended.type == SX_ROUTER_COUNTER_TYPE_BASIC:
                    total_rif_cntr_dict[rif_id_list[i]]['type'] = "Basic"
                else:
                    total_rif_cntr_dict[rif_id_list[i]]['type'] = "Enhanced"
            else:
                # No counter is bound to this RIF. Skip  it.
                total_rif_cntr_dict[rif_id_list[i]]['bound'] = "False"
                total_rif_cntr_dict[rif_id_list[i]]['cntr_id'] = "N/A"
                total_rif_cntr_dict[rif_id_list[i]]['type'] = "N/A"
                continue

        # save the last RIF to index the next set from
        last_rif = rif_id_list[tmp_rif_count - 1]
        # update the total count
        rif_total_count = rif_total_count - tmp_rif_count
        cmd = SX_ACCESS_CMD_GETNEXT

    # lets print a short list of RIFs and the bound counter IDs alone as a table
    print_rif_counter_ids(total_rif_cntr_dict)
    if print_allrif_warning(len(cntr_data_dict)):
        print_rif_cntr_values(cntr_data_dict)


def print_rif_cntr_values(cntr_ext_data_dict):
    for cntr in cntr_ext_data_dict.keys():
        if cntr_ext_data_dict[cntr].type == SX_ROUTER_COUNTER_TYPE_BASIC:
            print_router_basic_counter(cntr, cntr_ext_data_dict[cntr].data.rif_basic)
        else:
            print_router_extended_counter(cntr, cntr_ext_data_dict[cntr].data.rif_enhanced)


def print_rif_counter_ids(rif_cntr_dict):
    print("#####################################################")
    print("|   Rif Id   | Cntr Bound |  Cntr Id   |  Cntr Type |")

    for rif in rif_cntr_dict.keys():
        print("-----------------------------------------------------")
        print("| {:^10d} |{:^12}|{:^12}|{:^12}|".format(rif,
                                                        rif_cntr_dict[rif]['bound'],
                                                        rif_cntr_dict[rif]['cntr_id'],
                                                        rif_cntr_dict[rif]['type']))

    print("#####################################################")


def handle_counter_id(handle, counter):

    counter_is_valid, counter_type = is_router_counter_valid(handle, counter)
    if counter_is_valid:
        if is_counter_bound_to_rif(handle, counter):
            if counter_type == SX_ROUTER_COUNTER_TYPE_BASIC:
                read_router_counters_basic(handle, counter)
            else:
                read_router_counters_extended(handle, counter)
    else:
        sx_api_close(handle)
        sys.exit(0)


def handle_rif_id(handle, rif):
    if not is_rif_valid(handle, rif):
        sx_api_close(handle)
        sys.exit(0)

    rif_cntr_dict = {}
    cntr_data_dict = {}
    rif_cntr_dict[rif] = {}
    rif_has_counter_bound, counter_id, counter_set_extended = is_rif_counter_bound(handle, rif)
    if rif_has_counter_bound:
        rif_cntr_dict[rif]['bound'] = "True"
        rif_cntr_dict[rif]['cntr_id'] = counter_id
        cntr_data_dict[counter_id] = counter_set_extended
        if counter_set_extended.type == SX_ROUTER_COUNTER_TYPE_BASIC:
            rif_cntr_dict[rif]['type'] = "Basic"
        else:
            rif_cntr_dict[rif]['type'] = "Enhanced"
    else:
        # No counter is bound to this RIF.
        rif_cntr_dict[rif]['bound'] = "False"
        rif_cntr_dict[rif]['cntr_id'] = "N/A"
        rif_cntr_dict[rif]['type'] = "N/A"

    print_rif_counter_ids(rif_cntr_dict)
    if rif_has_counter_bound:
        print_rif_cntr_values(cntr_data_dict)


def parse_args():
    parser = argparse.ArgumentParser(description='Dump router interface counters. Filter by RIF or Counter Id ')
    parser.add_argument('--counter_id', '-c', default=None, help='Dump a specific Router Counter\'s values')
    parser.add_argument('--rif', '-r', default=None, help='Dump values of the Router Counter bound to a specific RIF')
    parser.add_argument('--all', '-a', action='store_true', help='Dump counters of all RIFs')
    args = parser.parse_args()
    return args


def handle_counter_ops(handle, args):
    if args.counter_id is not None:
        if args.counter_id.startswith("0x"):
            counter_id = int(args.counter_id, 16)
        else:
            counter_id = int(args.counter_id, 10)
        return handle_counter_id(handle, counter_id)
    elif args.rif is not None:
        if args.rif.startswith("0x"):
            rif_id = int(args.rif, 16)
        else:
            rif_id = int(args.rif, 10)
        return handle_rif_id(handle, rif_id)
    elif args.all:
        return handle_all_rifs(handle)
    else:
        print("No arguments specified. please provide -c or -r or -a options")
        sx_api_close(handle)
        sys.exit(0)


def print_allrif_warning(rif_cnt=0):
    valid = {"yes": True, "y": True}
    if (rif_cnt > 0):
        print("There are {} RIFs with counters bound. Script will dump counter data for all {} RIFs".format(rif_cnt, rif_cnt))
    else:
        print("No Rif or Counter is specified. Script will dump counter data for ALL Rifs")

    print("Do you wish to continue? (y/N)")
    return input().lower() in valid


def main():
    counter_is_valid = False
    rif_is_valid = False
    args = parse_args()
    logging.info("[+] opening sdk")
    rc, handle = sx_api_open(None)
    logging.debug("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        logging.error("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    handle_counter_ops(handle, args)

    sx_api_close(handle)
    sys.exit(0)


if __name__ == "__main__":
    main()
