#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev


def parse_args():
    parser = argparse.ArgumentParser(description='HTACG Set/Get example.')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--idx', default=0, type=int, help="Grepper Index: init grepper (0), SW grepper (1).")
    parser.add_argument('--tac_flush', default=0, type=int, help="TAC grepper action to perform for the entries found at hash. Possible actions: flush_and_report(0), flush_no_report(1), report_only(2).")
    parser.add_argument('--rdq', default=0, type=int, help="RDQ Index value for lookup at hash.")
    parser.add_argument('--rdq_mask', default=0, type=int, help="RDQ Index mask for lookup at hash. Max value is 0x3F. 0 by default.")
    parser.add_argument('--trap_id', default=0, type=int, help="Trap Index value for lookup at hash.")
    parser.add_argument('--trap_id_mask', default=0, type=int, help="Trap Index mask for lookup at hash. Max value is 0x3FF. 0 by default.")
    parser.add_argument('--last_ts', default=0, type=int, help="Last time stamp value for lookup at hash.")
    parser.add_argument('--last_ts_mask', default=0, type=int, help="Last time stamp mask for lookup at hash. Max value is 0xFFFFFFFF. 0 by default.")
    parser.add_argument('--pkt_count', default=0, type=int, help="Packets counter value for lookup at hash.")
    parser.add_argument('--pkt_count_mask', default=0, type=int, help="Packets counter mask for lookup at hash. Max value is 0xFFFFFFFF. 0 by default.")
    parser.add_argument('--byte_count', default=0, type=int, help="Byte counter value for lookup at hash.")
    parser.add_argument('--byte_count_mask', default=0, type=int, help="Byte counter mask for lookup at hash. Max value is 0xFFFFFFFFFF. 0 by default.")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    field = {}
    field['rdq'] = args.rdq
    field['trap_id'] = args.trap_id
    field['last_ts'] = args.last_ts
    field['pkt_count'] = args.pkt_count
    field['byte_count'] = args.byte_count

    mask = {}
    mask['rdq'] = args.rdq_mask
    mask['trap_id'] = args.trap_id_mask
    mask['last_ts'] = args.last_ts_mask
    mask['pkt_count'] = args.pkt_count_mask
    mask['byte_count'] = args.byte_count_mask

    return args.cmd, args.idx, args.tac_flush, field, mask, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute Set/Get request for the HTACG EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--idx <grepper_idx>] [--tac_flush <tac_flush>] [--rdq <rdq>] [--rdq_mask <rdq_mask>] [--trap_id <trap_id>] [--trap_id_mask <trap_id_mask>] [--last_ts <last_ts>] [--last_ts_mask <last_ts_mask>] [--pkt_count <pkt_count>] [--pkt_count_mask <pkt_count_mask>] [--byte_count <byte_count>] [--byte_count_mask <byte_count_mask>]")

    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. Get by default.")
    print("grepper_idx: grepper index value. May be Init grepper (0) or SW grepper(1).0 by default.")
    print("tac_flush: TAC grepper action to perform - flush_and_report(0), flush_no_report(1), report_only(2). 0 by default.")
    print("rdq: RDQ Index value for lookup at hash. 0 by default.")
    print("rdq_mask: RDQ Index mask for lookup at hash. Max value is 0x3F. 0 by default.")
    print("trap_id: Trap Index value for lookup at hash. 0 by default.")
    print("trap_id_mask: Trap Index mask for lookup at hash. Max value is 0x3FF. 0 by default.")
    print("last_ts: Last time stamp value for lookup at hash. 0 by default.")
    print("last_ts_mask: Last time stamp mask for lookup at hash. Max value is 0xFFFFFFFF. 0 by default.")
    print("pkt_count: Packets counter value for lookup at hash. 0 by default.")
    print("pkt_count_mask: Packets counter mask for lookup at hash. Max value is 0xFFFFFFFF. 0 by default.")
    print("byte_count: Byte counter value for lookup at hash. 0 by default.")
    print("byte_count_mask: Byte counter mask for lookup at hash. Max value is 0xFFFFFFFFFF. 0 by default.")
    print("")


def validate_input_parameters(cmd, idx, tac_flush, field, mask):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)

    if idx > 1:
        print("Invalid input parameter: idx.")
        help_cmd()
        sys.exit(0)

    if tac_flush > 2:
        print("Invalid input parameter: tac_flush.")
        help_cmd()
        sys.exit(0)

    for entry in [field, mask]:
        if entry['rdq'] > 0x3F:
            print("Invalid input parameter: rdq.")
            help_cmd()
            sys.exit(0)
        if entry['trap_id'] > 0x3FF:
            print("Invalid input parameter: trap_id.")
            help_cmd()
            sys.exit(0)
        if entry['last_ts'] > 0xFFFFFFFF:
            print("Invalid input parameter: last_ts.")
            help_cmd()
            sys.exit(0)
        if entry['pkt_count'] > 0xFFFFFFFF:
            print("Invalid input parameter: pkt_count.")
            help_cmd()
            sys.exit(0)
        if entry['byte_count'] > 0xFFFFFFFFFF:
            print("Invalid input parameter: byte_count.")
            help_cmd()
            sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, idx, tac_flush, field, mask, deinit):

    reg_data = ku_htacg_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    reg_data.grepper_index = idx
    reg_data.go = 1
    reg_data.tac_flush = tac_flush

    # fill in fields entry
    reg_data.fields.mirror_reason = 0              # mirror is not supported yet
    reg_data.fields.mirror_tclass = 0              # mirror is not supported yet
    reg_data.fields.mirror_tx_acl_system_port = 0  # mirror is not supported yet
    reg_data.fields.rdq = field['rdq']
    reg_data.fields.trap_id = field['trap_id']
    reg_data.fields.max_egress_buffer_fill_level = 0  # is not supported yet
    reg_data.fields.last_ts = field['last_ts']
    reg_data.fields.pkt_count = field['pkt_count']
    reg_data.fields.byte_count_high = ((field['byte_count'] >> 32) & 0xFF)
    reg_data.fields.byte_count_low = (field['byte_count'] & 0xFFFFFFFF)

    # fill in mask entry
    reg_data.mask.mirror_reason = 0              # mirror is not supported yet
    reg_data.mask.mirror_tclass = 0              # mirror is not supported yet
    reg_data.mask.mirror_tx_acl_system_port = 0  # mirror is not supported yet
    reg_data.mask.rdq = mask['rdq']
    reg_data.mask.trap_id = mask['trap_id']
    reg_data.mask.max_egress_buffer_fill_level = 0  # is not supported yet
    reg_data.mask.last_ts = mask['last_ts']
    reg_data.mask.pkt_count = mask['pkt_count']
    reg_data.mask.byte_count_high = ((mask['byte_count'] >> 32) & 0xFF)
    reg_data.mask.byte_count_low = (mask['byte_count'] & 0xFFFFFFFF)

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get HTACG")
        print("[+] grepper_index: ", reg_data.grepper_index)
        print("[+] tac_flush: ", reg_data.tac_flush)

    else:
        print("[+] Set HTACG")
        print("[+] grepper_index: ", reg_data.grepper_index)
        print("[+] tac_flush: ", reg_data.tac_flush)
        for k in field:
            print("[+] field %s: %s" % (k, field[k]))
        for k in mask:
            print("[+] mask %s: %s" % (k, mask[k]))

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        # Save data for later de-configuration
        original_reg_data = ku_htacg_reg()
        original_reg_data.grepper_index = idx
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_htacg(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_htacg failed")
            sys.exit(rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_htacg(reg_data, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to query HTACG register, rc: %d" % (rc)

    print("[+] rc: ", rc)
    print("====================")
    if rc == SXD_STATUS_SUCCESS and meta.access_cmd == SXD_ACCESS_CMD_GET:
        for k in field:
            print("[+] field %s: %s" % (k, field[k]))
        for k in mask:
            print("[+] mask %s: %s" % (k, mask[k]))

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        print("Deinit")
        rc = sxd_access_reg_htacg(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_htacg failed")
            sys.exit(rc)


def main():
    cmd, idx, tac_flush, field, mask, deinit = parse_args()

    validate_input_parameters(cmd, idx, tac_flush, field, mask)

    sxd_init()

    chip_type, _ = get_chip_type_and_rev()
    if chip_type != SXD_MGIR_HW_DEV_ID_SPECTRUM5 and chip_type != SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        print("[+] HTACG is not supported! No need to run this example.")
    else:
        run_example(cmd, idx, tac_flush, field, mask, deinit)
    print("[+] HTACG register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] HTACG register access example")
    main()
