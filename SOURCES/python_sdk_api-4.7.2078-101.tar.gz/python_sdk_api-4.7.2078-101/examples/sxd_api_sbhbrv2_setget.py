#!/usr/bin/env python

import sys
import errno
import time
import os
import argparse

from python_sdk_api.sxd_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev

if __name__ == "__main__":
    HIST_TYPE_QUEUE_DEPTH = 0x1000

    print("[+] Read/write SBHBRv2 register")

    parser = argparse.ArgumentParser(description='SBHBRv2 read/write utility')
    parser.add_argument('--cmd', default=0, type=int, help="READ(0), WRITE(1)")
    parser.add_argument('--local_port', default=1, type=int, help="Local Port")
    parser.add_argument('--dir', default=1, type=int, help="Ingress(0), Egress(1)")
    parser.add_argument('--pg_or_tc', default=0, type=int, help="pg/tc")
    parser.add_argument('--en', default=0, type=int, help="Disable(0)/Enable(1) ")
    parser.add_argument('--mode', default=0, type=int, help="Linear(0)/Exp(1) ")
    parser.add_argument('--min', default=0, type=int, help="Min value for histogram main range")
    parser.add_argument('--max', default=0, type=int, help="Linear: max = min + 2^n, n >= 3; Exp: max = min + 255*2^n, n >= 0")
    parser.add_argument('--sample_time', default=1, type=int, help="Sample time interval. time = 2^sample_time * 128nSec. [0..11]")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type, _ = get_chip_type_and_rev()
    if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM:
        print("SPC1 does not support sbhbrv2 EMAD.")
        sys.exit(0)

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    sbhbrv2 = ku_sbhbr_v2_reg()

    """ Get sbhbrv2 """
    meta.access_cmd = SXD_ACCESS_CMD_GET
    sbhbrv2.local_port = args.local_port
    sbhbrv2.pg_buff = args.pg_or_tc
    sbhbrv2.dir = args.dir
    sbhbrv2.hist_type = HIST_TYPE_QUEUE_DEPTH
    print(("sbhbrv2 GET args: Local port: %d, Dir:%d pg_buff:%d" % (sbhbrv2.local_port, sbhbrv2.dir, sbhbrv2.pg_buff)))

    rc = rc = sxd_access_reg_sbhbr_v2(sbhbrv2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get SBHBR_V2 register, rc: %d" % (rc)

    print(("sbhbrv2 GET RC=%d RESULT:" % rc))
    print(("Local port: %d" % sbhbrv2.local_port))
    print(("Dir: %d" % sbhbrv2.dir))
    print(("Pg_buff: %d" % sbhbrv2.pg_buff))
    print(("En: %d" % sbhbrv2.en))
    print(("Mode: %d" % sbhbrv2.mode))
    print(("Min: %d" % sbhbrv2.hist_min_value))
    print(("Max: %d" % sbhbrv2.hist_max_value))
    print(("Sample time: %d" % sbhbrv2.sample_time))
    print("sbhbrv2 GET is Done")

    if args.cmd != 1:
        sys.exit(0)

    if args.deinit:
        meta.access_cmd = SXD_ACCESS_CMD_GET

        original_sbhbrv2 = ku_sbhbr_v2_reg()

        original_sbhbrv2.local_port = args.local_port
        original_sbhbrv2.pg_buff = args.pg_or_tc
        original_sbhbrv2.dir = args.dir
        original_sbhbrv2.hist_type = HIST_TYPE_QUEUE_DEPTH

        rc = rc = sxd_access_reg_sbhbr_v2(original_sbhbrv2, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get SBHBR_V2 register, rc: %d" % (rc)

    """ Set sbhbrv2 """
    meta.access_cmd = SXD_ACCESS_CMD_SET
    sbhbrv2.local_port = args.local_port
    sbhbrv2.pg_buff = args.pg_or_tc
    sbhbrv2.dir = args.dir
    sbhbrv2.en = args.en
    sbhbrv2.mode = args.mode
    sbhbrv2.hist_type = HIST_TYPE_QUEUE_DEPTH
    sbhbrv2.hist_min_value = args.min
    sbhbrv2.hist_max_value = args.max
    sbhbrv2.sample_time = args.sample_time

    print(("sbhbrv2 SET args: Local port: %d, Dir:%d pg_buff:%d" % (sbhbrv2.local_port, sbhbrv2.dir, sbhbrv2.pg_buff)))
    print(("En: %d" % sbhbrv2.en))
    print(("Mode: %d" % sbhbrv2.mode))
    print(("Min: %d" % sbhbrv2.hist_min_value))
    print(("Max: %d" % sbhbrv2.hist_max_value))
    print(("Sample time: %d" % sbhbrv2.sample_time))

    rc = sxd_access_reg_sbhbr_v2(sbhbrv2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set SBHBR_V2 register, rc: %d" % (rc)
    print("sbhbrv2 SET is Done")
    print(("sbhbrv2 SET Result: Local port: %d, Dir:%d pg_buff:%d" % (sbhbrv2.local_port, sbhbrv2.dir, sbhbrv2.pg_buff)))
    print(("En: %d" % sbhbrv2.en))
    print(("Mode: %d" % sbhbrv2.mode))
    print(("Min: %d" % sbhbrv2.hist_min_value))
    print(("Max: %d" % sbhbrv2.hist_max_value))
    print(("Sample time: %d" % sbhbrv2.sample_time))

    """ Get sbhbrv2 """
    meta.access_cmd = SXD_ACCESS_CMD_GET
    sbhbrv2.local_port = args.local_port
    sbhbrv2.pg_buff = args.pg_or_tc
    sbhbrv2.dir = args.dir
    sbhbrv2.hist_type = HIST_TYPE_QUEUE_DEPTH
    print(("sbhbrv2 GET args: Local port: %d, Dir:%d pg_buff:%d" % (sbhbrv2.local_port, sbhbrv2.dir, sbhbrv2.pg_buff)))

    rc = sxd_access_reg_sbhbr_v2(sbhbrv2, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get SBHBR_V2 register, rc: %d" % (rc)

    print(("sbhbrv2 GET Result: Local port: %d, Dir:%d pg_buff:%d" % (sbhbrv2.local_port, sbhbrv2.dir, sbhbrv2.pg_buff)))
    print(("En: %d" % sbhbrv2.en))
    print(("Mode: %d" % sbhbrv2.mode))
    print(("Min: %d" % sbhbrv2.hist_min_value))
    print(("Max: %d" % sbhbrv2.hist_max_value))
    print(("Sample time: %d" % sbhbrv2.sample_time))
    print("sbhbrv2 GET is Done")

    if args.deinit:
        meta.access_cmd = SXD_ACCESS_CMD_SET
        rc = sxd_access_reg_sbhbr_v2(original_sbhbrv2, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set SBHBR_V2 register, rc: %d" % (rc)

    sys.exit(0)
