#!/usr/bin/env python
'''
This file contains Python command example for flow counter for Bridge and Vport module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of flow counters for Bridge and Vport attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flow_counter.py example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

""" ############################################################################################ """


def bind_unbind_vport_counter(cmd, vport, counter_id):
    """ BIND/UNBIND FLOW COUNTER TO/FROM VPORT """
    if cmd == SX_ACCESS_CMD_BIND:
        print("--------------- BIND COUNTER TO VPORT  ------------------------------")
    else:
        print("--------------- UNBIND COUNTER FROM VPORT  ------------------------------")

    rc = sx_api_port_vport_counter_bind_set(handle, cmd, vport, counter_id)
    print(("sx_api_port_vport_counter_bind_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id

####################################################################################


def read_clear_flow_counter(counter_id):
    " This function reads and clears a flow counter. "

    counter_set_p = sx_flow_counter_set_t()
    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d; rc=%d" % (counter_id, rc)
    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    print(("Read and cleared flow counter %d, rc: %d; Packets: %u " % (counter_id, rc, counter_set.flow_counter_packets)))

    rc = sx_api_flow_counter_clear_set(handle, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to clear flow counter %d; rc=%d" % (counter_id, rc)
    print(("Counter clear rc: %d" % (rc)))


def destroy_flow_counter(counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function destroys a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed flow counter %d, rc: %d" % (counter_id, rc))


####################################################################################
""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


""" ############################################################################################ """


def vlan_ports_add_delete(cmd, vid, vlan_port_list_p, port_cnt):
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VLAN MEMBER PORTS  ------------------------------")
    else:
        print("--------------- DELETE VLAN MEMBER PORTS  ------------------------------")

    rc = sx_api_vlan_ports_set(handle, cmd, SPECTRUM_SWID, vid, vlan_port_list_p, port_cnt)
    print(("sx_api_vlan_ports_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


""" ############################################################################################ """


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """

# create a vport for port 0x10001 and vlan 20
log_vport_p_1 = new_sx_port_log_id_t_p()
vport_add_delete(SX_ACCESS_CMD_ADD, PORT1, 20, log_vport_p_1)
log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
print(("virtula port 0x%x created" % (log_vport_1)))
""" ############################################################################################ """

# create a vport for port 0x10003 and vlan 30
log_vport_p_2 = new_sx_port_log_id_t_p()
vport_add_delete(SX_ACCESS_CMD_ADD, PORT2, 30, log_vport_p_2)
log_vport_2 = sx_port_log_id_t_p_value(log_vport_p_2)
print(("virtual port 0x%x created" % (log_vport_2)))
""" ############################################################################################ """

# create bridge
bridge_id_p = new_sx_bridge_id_t_p()
bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
print(("bridge %d created" % (bridge_id)))
""" ############################################################################################ """

# add log_vport_1 to bridge
bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))
""" ############################################################################################ """

# add log_vport_2 to bridge
bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_2)
print(("virtual port 0x%x added to bridge %d " % (log_vport_2, bridge_id)))
""" ############################################################################################ """

# set port state to UP
port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_UP)
""" ############################################################################################ """

# set port state to UP
port_state_set(log_vport_2, SX_PORT_ADMIN_STATUS_UP)
""" ############################################################################################ """

# add vlan port membership
add_ports_to_vlan(20, {PORT1: SX_TAGGED_MEMBER})
add_ports_to_vlan(30, {PORT2: SX_TAGGED_MEMBER})

""" ############################################################################################ """
# Send Traffic from 2 vports
print("****** Now user can send traffic from two vports ******")

flow_counter_1 = create_flow_counter()
flow_counter_2 = create_flow_counter()
bind_unbind_vport_counter(SX_ACCESS_CMD_BIND, log_vport_1, flow_counter_1)

if args.deinit:
    bind_unbind_vport_counter(SX_ACCESS_CMD_UNBIND, log_vport_1, flow_counter_1)
    """ ############################################################################################ """

    # set port state to DOWN before deleting log_vport_1
    port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_DOWN)

    # delete log_vport_1 to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, log_vport_1)
    print(("virtual port 0x%x deleted from bridge %d " % (log_vport_1, bridge_id)))
    """ ############################################################################################ """

    # set port state to DOWN before deleting log_vport_2
    port_state_set(log_vport_2, SX_PORT_ADMIN_STATUS_DOWN)

    # delete log_vport_2 to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, log_vport_2)
    print(("virtual port 0x%x deleted from bridge %d " % (log_vport_2, bridge_id)))
    """ ############################################################################################ """

    # delete bridge
    bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)
    #bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge %d deleted" % (bridge_id)))
    """ ############################################################################################ """

    # delete vport for port 0x10001 and vlan 20
    vport_add_delete(SX_ACCESS_CMD_DELETE, PORT1, 20, log_vport_p_1)
    #log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtual port 0x%x deleted" % (log_vport_1)))
    """ ############################################################################################ """

    # delete vport for port 0x10003 and vlan 30
    vport_add_delete(SX_ACCESS_CMD_DELETE, PORT2, 30, log_vport_p_2)
    #log_vport_2 = sx_port_log_id_t_p_value(log_vport_p_2)
    print(("virtual port 0x%x deleted" % (log_vport_2)))
    """ ############################################################################################ """

    destroy_flow_counter(flow_counter_1)
    destroy_flow_counter(flow_counter_2)

    # remove vlan port membership
    remove_ports_from_vlan(20, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(30, {PORT2: SX_TAGGED_MEMBER})

sx_api_close(handle)
