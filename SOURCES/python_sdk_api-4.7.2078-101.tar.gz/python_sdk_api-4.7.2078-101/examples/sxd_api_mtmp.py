#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *

print("[+] MTMP register access Example Test start")
print("[+] initializing register access")
sxd_access_reg_init(0, None, 4)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET


mtmp = ku_mtmp_reg()
mtmp.sensor_index = 0

print("[+] Get MTMP")
rc = sxd_access_reg_mtmp(mtmp, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read MTMP register, rc: %d" % (rc)

print("[+] MTMP content")
print("====================")
print("[+] mtmp.sensor_index: ", mtmp.sensor_index)
print("[+] mtmp.temperature: ", mtmp.temperature)
print("[+] mtmp.max_temperature: ", mtmp.max_temperature)
print("[+] mtmp.mte: ", mtmp.mte)
print("[+] mtmp.mtr: ", mtmp.mtr)
print("[+] mtmp.tee: ", mtmp.tee)
print("[+] mtmp.sensor_name_hi: ", mtmp.sensor_name_hi)
print("[+] mtmp.sensor_name_lo: ", mtmp.sensor_name_lo)
print("[+] mtmp.sensor_name_hi: ", mtmp.sensor_name_hi)
print("[+] mtmp.sensor_name_hi: ", mtmp.sensor_name_hi)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] MTMP register access example test end")
