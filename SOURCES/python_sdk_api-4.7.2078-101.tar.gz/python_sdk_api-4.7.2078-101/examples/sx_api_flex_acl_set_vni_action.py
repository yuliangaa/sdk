#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

Set VNI action is only applicable to tunnel encapsulated/decpasulated packets.
The example below performs the following configurations so that the set vni
action is acted upon the encapsulated packet just before the fdb lookup.
VxLAN Tunnel Setup and Bridge/VNI Mapping Configuration -
    1. Creates a VxLAN tunnel, and bridge to vni mapping for vni 55
    2. Creates another bridge to vni mapping for vni 100
VxLAN Decap Side with Ingress Port ACL -
    1. creates a region with size 254
    2. Creates a ACL
    3. Create ingress ACL rule to set vni(100).
    4. Bind the ACL to the underlay port.
Desired Behavior -
    1. When VxLAN encapped packet is received, the packet is decapsulated
    2. Just before the FDB lookup the set vni action done by ACL is considered
    3. FDB lookup is done with bridge/fid associated with vni
    4. Decapsulated packet is sent out on bridge associated with vni(100)
VxLAN Encap Side with Egress Port ACL -
    1. creates a region with size 254
    2. Creates a ACL
    3. Create ingress ACL rule to set vni(100).
    4. Bind the ACL to the underlay port.
Desired Behavior -
    1. FDB entry redirects the L2 packet to the tunnel
    2. VxLAN encapsulation is done on the packet and vni is set to 55
    3. Packet is sent to the underlay egress port.
    4. Egress ACL is hit that changes the vni to 100
"""
import sys
import socket
import struct
import errno
import random
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_set_vni_action example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

#######################################################################
# CONSTANTS
#######################################################################
SW1_OL_VLAN_4 = 4
SW1_OL_VLAN_5 = 5
SW1_UL_VLAN_6 = 6

SW1_UL_RIF_MAC = ether_addr(0x00, 0x00, 0x01, 0x01, 0x01, 0x01)
SW1_UL_RIF_MAC_STR = '00:00:01:01:01:01'
SW1_OL_RIF_MAC = ether_addr(0x00, 0x00, 0x01, 0x01, 0x01, 0x02)
SW1_OL_RIF_MAC_STR = '00:00:01:01:01:02'

SW1_OL_HOST_MAC = ether_addr(0x00, 0x00, 0x01, 0x01, 0x01, 0x10)
SW1_OL_HOST_MAC_STR = '00:00:01:01:01:10'
SW1_UL_NGBR_MAC = ether_addr(0x00, 0x00, 0x02, 0x02, 0x02, 0x01)
SW1_UL_NGBR_MAC_STR = '00:00:02:02:02:01'

SW1_HOST_1_MAC = SW1_OL_HOST_MAC
SW1_HOST_1_MAC_STR = SW1_OL_HOST_MAC_STR
SW1_HOST_2_MAC = ether_addr(0x00, 0x00, 0x01, 0x01, 0x01, 0x11)
SW1_HOST_2_MAC_STR = '00:00:01:01:01:11'

SW1_NVE_SIP = '20.20.20.1'
SW1_NVE_DIP = '20.20.20.2'

SW1_UL_NEIGH_IP = '20.20.20.10'
SW1_UL_SELF_IP = '20.20.20.20'

SW1_NET_IP = '20.20.0.0'
SW1_NET_MASK = '255.255.0.0'

SW1_HOST1_IP = '1.1.1.10'
SW1_HOST2_IP = '1.1.1.11'

VNI_55 = 55
VNI_100 = 100

SPECTRUM_SWID = 0
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def check_sdk_rc(rc):
    if rc != SX_STATUS_SUCCESS:
        print("bad sdk rc %d" % rc)
        sys.exit(rc)

# ***********************************************************************
#    ACL Functions
# ***********************************************************************


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def rule_set(region_id, start_offset, end_offset, cmd):
    ''' This function sets rule, where cmd is the choice for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_cnt = (end_offset - start_offset + 1)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    offsets_list = new_sx_acl_rule_offset_t_arr(rules_cnt)
    j = 0

    for i in range(start_offset, end_offset + 1):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 3, rule)

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_SIP
        key_desc.key.sip.version = SX_IP_VERSION_IPV4
        key_desc.key.sip.addr.ipv4.s_addr = 0x00000000 + i + 1
        key_desc.mask.sip.version = SX_IP_VERSION_IPV4
        key_desc.mask.sip.addr.ipv4.s_addr = 0x00000000

        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
        rule.key_desc_count = 1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_SET_VNI
        action1.fields.action_vni.vni_value = 100

        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
        rule.action_count = 1

        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, j, rule)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, j, i)
        j = j + 1

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)


# **************************************************************************
#    Router Functions
# ***************************************************************************
def router_init(handle, ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_vlan_router_interfaces = 16
    router_resource.max_port_router_interfaces = 16
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 6000
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 7000
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid(handle, ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                uc_default_action=SX_ROUTER_ACTION_DROP,
                mc_default_action=SX_ROUTER_ACTION_DROP):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = ipv4_enable
    router_attr.ipv6_enable = ipv6_enable
    router_attr.ipv4_mc_enable = ipv4_mc_enable
    router_attr.ipv6_mc_enable = ipv6_mc_enable
    router_attr.uc_default_rule_action = uc_default_action
    router_attr.mc_default_rule_action = mc_default_action

    vrid_p = new_sx_router_id_t_p()
    print("Vrid create")
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    check_sdk_rc(rc)

    vrid = sx_router_id_t_p_value(vrid_p)
    print(("Created VRID: %d " % (vrid)))
    return vrid


def create_vlan_rif(handle, vrid, vlan, mac_addr, mtu, ttl=0):
    " This function creates vlan rif with given parametrs. "
    ifc_param_1 = sx_router_interface_param_t()
    ifc_param_1.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param_1.ifc.vlan.swid = 0
    ifc_param_1.ifc.vlan.vlan = vlan
    ifc_attr_1 = sx_interface_attributes_t()
    ifc_attr_1.mac_addr = mac_addr
    ifc_attr_1.mtu = mtu
    ifc_attr_1.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr_1.multicast_ttl_threshold = ttl
    ifc_attr_1.loopback_enable = False
    vlan_rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param_1, ifc_attr_1, vlan_rif_p)
    check_sdk_rc(rc)
    vlan_rif = sx_router_interface_t_p_value(vlan_rif_p)
    print(("Created vlan rif: %d, rc: %d " % (vlan_rif, rc)))

    return vlan_rif


def set_rif_state_ipv4(handle, rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    # set rif2 state to ipv4 enable
    rif_state_2 = sx_router_interface_state_t()
    rif_state_2.ipv4_enable = enable
    rif_state_2.ipv6_enable = False
    rif_state_2.ipv4_mc_enable = False
    rif_state_2.ipv6_mc_enable = False
    rif_state_p_2 = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p_2, rif_state_2)
    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p_2)
    assert rc == SX_STATUS_SUCCESS, "sx_api_router_interface_state_set failed, rc = %d, rif = %d" % (rc, rif)
    print(("Set rif %d state, rc: %d " % (rif, rc)))


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parameters.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(handle, vrid, rif, addr, mask, type_ipv6=False,
                       action=SX_ROUTER_ACTION_FORWARD, need_rc_check=True):
    " This function creates local route with given parameters. "

    if(type_ipv6):
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    uc_route_data = make_local_route_data(rif, action)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    if (need_rc_check):
        check_sdk_rc(rc)
        print(("Created local route for rif %d, rc: %d " % (rif, rc)))
    elif ((need_rc_check == False) and (rc == SX_STATUS_NO_RESOURCES)):
        print(("Got no more resources error rc: %d" % (rc)))
    return rc


def add_neigh(handle, rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def delete_all_local_routes(handle, vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all local UC routes"
    print(("Deleted all local UC routes, rc: %d " % (rc)))


def delete_all_ip2me_routes(handle, vrid):
    " This function deletes all ip2me routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all IP2ME UC routes"
    print(("Deleted all IP2ME UC routes, rc: %d " % (rc)))


def delete_rif(handle, vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_vrid(handle, vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit(handle):
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

# **********************************************
#    Bridge Functions
# **********************************************


def bridge_create_delete(handle, cmd, bridge_id_p):
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    elif cmd == SX_ACCESS_CMD_DESTROY:
        print("--------------- BRIDGE DELETE ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_bridge_set failed, cmd = %d" % (cmd)


def vport_add_delete(handle, cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_vport_set failed, cmd = %d, port = 0x%x, vid = %d" % (cmd, log_port, vid)


def bridge_vport_add_delete(handle, cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    assert SX_STATUS_SUCCESS == rc, "sx_api_bridge_vport_set failed, cmd = %d, port = 0x%x, bridge = %d" % (cmd, log_port, bridge_id)


def bridge_vport_create(handle, vlan, port1, tag_mode=SX_UNTAGGED_MEMBER):
    ''' This function creates a bridge and a virtual port with vlan
    the vport is then linked to the bridge '''
    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(handle, SX_ACCESS_CMD_ADD, port1, vlan, log_vport_p_1)
    log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtual port 0x%x created" % (log_vport_1)))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge %d created, rc: %d" % (bridge_id, rc)))

    # add log_vport_1 to bridge
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
    print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))

    # set port state to UP
    port_state_set(handle, log_vport_1, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(handle, vlan, {port1: tag_mode})

    return (bridge_id, log_vport_1)


def bridge_vport_delete(handle, vlan, port1, bridge_id, log_vport):

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    bridge_id_p = new_sx_bridge_id_t_p()
    sx_bridge_id_t_p_assign(bridge_id_p, bridge_id)

    # set port state to DOWN
    port_state_set(handle, log_vport, SX_PORT_ADMIN_STATUS_DOWN)

    # delete log_vport_1 from bridge
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    print(("virtual port 0x%x remove from bridge %d " % (log_vport, bridge_id)))

    # delete bridge
    bridge_create_delete(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
    print(("bridge %d deleted" % (bridge_id)))

    vport_add_delete(handle, SX_ACCESS_CMD_DELETE, port1, vlan, log_vport_p)
    print(("virtual port 0x%x deleted" % (log_vport)))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print(("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)))


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds specified ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    check_sdk_rc(rc)
    print(("Added %s port to  vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)))


def port_state_set(handle, log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))
    rc = sx_api_port_state_set(handle, log_port, admin_state)
    assert SX_STATUS_SUCCESS == rc, "sx_api_port_state_set failed, port = 0x%x, admin_state = %d" % (log_port, admin_state)


def port_parsing_depth_get(handle):
    parsing_length_p = new_uint16_t_p()
    rc = sx_api_port_parsing_depth_get(handle, parsing_length_p)
    check_sdk_rc(rc)
    parsing_length = uint16_t_p_value(parsing_length_p)
    delete_uint16_t_p(parsing_length_p)
    return parsing_length


def port_parsing_depth_set(handle, depth):
    rc = sx_api_port_parsing_depth_set(handle, depth)
    check_sdk_rc(rc)

# **********************************************
#    Tunnel Functions
# **********************************************


def tunnel_init(handle, tunnel_general_params):
    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc = %d" % rc
    print("init tunnel")


def tunnel_deinit(handle):
    rc = sx_api_tunnel_deinit_set(handle)
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc = %d" % rc
    print("deinit tunnel")


def tunnel_create(handle, tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to create tunnel, rc = %d" % rc
    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    print(("Created tunnel id : %d" % (tunnel_id)))
    return tunnel_id


def tunnel_edit(handle, tunnel_id, tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_EDIT, tunnel_attribute, tunnel_id_p)
    check_sdk_rc(rc)
    print(("Edited tunnel id : %d" % (tunnel_id)))


def tunnel_destroy(handle, tunnel_id):

    print(("Destroy tunnel id : %d" % (tunnel_id)))
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute_p, tunnel_id_p)
    check_sdk_rc(rc)


def make_tunnel_attributes_vxlan(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_SYMMETRIC,
                                 log_port=NVE_PORT,
                                 underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID,
                                 encap_underlay_rif=0, decap_underlay_rif=0,
                                 tun_type=SX_TUNNEL_TYPE_NVE_VXLAN, tag_mode=SX_VLAN_TAG_MODE_802_1Q_E):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = tun_type
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.vxlan.nve_log_port = log_port
    tunnel_attribute.attributes.vxlan.underlay_domain_type = underlay_domain_type
    tunnel_attribute.attributes.vxlan.decap.tag_mode = tag_mode

    return tunnel_attribute


def create_vxlan_tunnel_flow(handle, vrid, log_port=NVE_PORT,
                             direction=SX_TUNNEL_DIRECTION_SYMMETRIC,
                             usip="192.168.0.1",
                             underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID,
                             encap_underlay_rif=0, decap_underlay_rif=0,
                             tun_type=SX_TUNNEL_TYPE_NVE_VXLAN):

    underlay_sip = sx_ip_addr_t()
    if(tun_type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6):
        underlay_sip = make_sx_ip_addr_v6(usip)
    else:
        underlay_sip = make_sx_ip_addr_v4(usip)
    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, direction,
                                                    log_port, underlay_domain_type,
                                                    encap_underlay_rif, decap_underlay_rif,
                                                    tun_type)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id = tunnel_create(handle, tunnel_attribute_p)
    return tunnel_id


def make_tunnel_map_entry_params(bridge_id, tunnel_type, vni,
                                 direction=SX_TUNNEL_MAP_DIR_BIDIR):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni
    map_entry.params.nve.direction = direction

    return map_entry


def tunnel_map_entry_add(handle, tunnel_id, tunnel_type, bridge_id, vni,
                         map_direction=SX_TUNNEL_MAP_DIR_BIDIR):
    map_entry = make_tunnel_map_entry_params(bridge_id, tunnel_type,
                                             vni, map_direction)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)

    rc = sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id,
                               map_entry_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_map_set failed add, rc = %d, tunnel_id = %d, tunnel_type = %d, bridge = %d, vni = %d, direction = %d" % (rc, tunnel_id, tunnel_type, bridge_id, vni, map_direction)
    return map_entry_p


def tunnel_map_entry_delete(handle, tunnel_id, tunnel_type, bridge_id,
                            vni, direction=SX_TUNNEL_MAP_DIR_BIDIR):

    map_entry = make_tunnel_map_entry_params(bridge_id, tunnel_type,
                                             vni, direction)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    print(("Delete map entry for tunnle %d bridge %d" %
           (tunnel_id, bridge_id)))
    rc = sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE,
                               tunnel_id, map_entry_p, 1)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_map_set failed delete, rc = %d, tunnel_id = %d, tunnel_type = %d, bridge = %d, vni = %d, direction = %d" % (rc, tunnel_id, tunnel_type, bridge_id, vni, map_direction)


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data


def make_decap_key(key_type, vrid, dip="1.1.1.1", sip="1.1.1.100", tunnel_type=0):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4(dip)
    decap_key.underlay_sip = make_sx_ip_addr_v4(sip)

    return decap_key


def create_decap_rule_flow(handle, vrid, key_type, dip, sip,
                           tunnel_id, tunnel_type):

    print("Create decap rule vrid : %d key_type : %d, tunnel : %d "
          "tunnel_type : %d dip : %s sip : %s" % (vrid, key_type, tunnel_id,
                                                  tunnel_type, dip, sip))
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    decap_key = make_decap_key(key_type, vrid, dip, sip, tunnel_type)
    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE,
                                       decap_key_p, decap_data_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_decap_rules_set failed create, rc = %d, vrid = %d, key_type = %d, tunnel_id = %d, tunnel_type = %d" % (rc, vrid, key_type, tunnel_id, tunnel_type)
    print(("sx_api_tunnel_decap_rules_set(create)  [rc = %d] " % (rc)))

    return (decap_key_p, decap_data_p)


def tunnel_decap_rule_destroy(handle, decap_key_p, decap_data_p):

    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY,
                                       decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel decap rule, rc: %d" % (rc)


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def make_sx_ip_addr_v6(addr):
    " This function creates ipv6 sx_ip_addr struct with given ip address. "
    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "

    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)

    if isinstance(mask, str):
        mask = _ipv6_str_to_bytes(mask)

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    prefix = sx_ip_v6_prefix_t()
    ip_prefix.prefix = prefix
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix


def vxlan_create_mac_entry(bridge_id, tunnel_id, mac_addr, u_dip, type_ipv6=False, entry_type=SX_FDB_UC_STATIC):
    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac_addr
    mac_entry.fid_vid = bridge_id
    mac_entry.entry_type = entry_type
    mac_entry.action = SX_FDB_ACTION_FORWARD
    ip_addr = sx_ip_addr_t()

    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP

    if u_dip is not None:
        if (type_ipv6):
            ip_addr = make_sx_ip_addr_v6(u_dip)
        else:
            ip_addr = make_sx_ip_addr_v4(u_dip)

    mac_entry.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_addr
    mac_entry.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD

    return mac_entry


def tunnel_uc_fdb_set_flow(handle, cmd, tunnel_id, bridge_id, mac_addr, u_dip=None, type_ipv6=False,
                           entry_type=SX_FDB_UC_STATIC):

    mac_entry = vxlan_create_mac_entry(bridge_id, tunnel_id, mac_addr, u_dip, type_ipv6, entry_type)

    data_cnt_p = copy_uint32_t_p(1)
    mac_arr = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_arr, 0, mac_entry)

    try:
        rc = sx_api_fdb_uc_mac_addr_set(handle, cmd, 0, mac_arr, data_cnt_p)
        expected_results = [SX_STATUS_SUCCESS, SX_STATUS_ACCEPTED]
        check_sdk_rc(rc)
    finally:
        delete_sx_fdb_uc_mac_addr_params_t_arr(mac_arr)
        delete_uint32_t_p(data_cnt_p)


def make_tunnel_general_params(sport=0, nve_encap_flowlabel=0, flood_ecmp_enabled=False,
                               ipinip_encap_flowlabel=0, encap_gre_hash=0,
                               fdb_resolution_valid=False,
                               fdb_resolution_action=SX_ROUTER_ACTION_FORWARD,
                               mc_ecmp_enabled=False):

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = sport
    general_params.nve.encap_flowlabel = nve_encap_flowlabel
    general_params.nve.flood_ecmp_enabled = flood_ecmp_enabled
    general_params.nve.mc_ecmp_enabled = mc_ecmp_enabled
    general_params.nve.fdb_resolution_valid = fdb_resolution_valid
    if fdb_resolution_valid:
        general_params.nve.fdb_resolution_action = fdb_resolution_action

    general_params.ipinip.encap_flowlabel = ipinip_encap_flowlabel
    general_params.ipinip.encap_gre_hash = encap_gre_hash

    return general_params


def main():

    # Configure vlans and port memberships
    overlay_index_1 = 0
    overlay_index_2 = 1
    underlay_index = 2

    # tunnel logical port
    log_port = NVE_PORT

    tun_type = SX_TUNNEL_TYPE_NVE_VXLAN

    port_list = getAllPortWithLinkUp(handle, PORT_ADMIN_STATUS)
    overlay_port_1 = port_list[overlay_index_1]
    overlay_port_2 = port_list[overlay_index_2]
    underlay_port = port_list[underlay_index]
    print(("overlay port first = 0x%x" % overlay_port_1))
    print(("overlay port second = 0x%x" % overlay_port_2))
    print(("Underlay port = 0x%x" % underlay_port))

    parse_len = port_parsing_depth_get(handle)
    new_parse_len = 128
    port_parsing_depth_set(handle, new_parse_len)

    print("Port VLAN Membersip")
    remove_ports_from_vlan(handle, 1, {underlay_port: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, SW1_UL_VLAN_6, {underlay_port: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(handle, 1, {overlay_port_1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, SW1_OL_VLAN_5, {overlay_port_1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(handle, 1, {overlay_port_2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, SW1_OL_VLAN_4, {overlay_port_2: SX_TAGGED_MEMBER})

    bridge_id_1, log_egress_vport_1 = bridge_vport_create(handle, SW1_OL_VLAN_5,
                                                          overlay_port_1, SX_TAGGED_MEMBER)
    bridge_id_2, log_egress_vport_2 = bridge_vport_create(handle, SW1_OL_VLAN_4,
                                                          overlay_port_2, SX_TAGGED_MEMBER)
    router_init(handle)
    print("Router Module initialized \n")

    # create underlay vrid & Router Interface
    ul_vrid = create_vrid(handle)
    print(("created underlay VRID %d\n" % ul_vrid))

    underlay_rif = create_vlan_rif(handle, ul_vrid, SW1_UL_VLAN_6,
                                   SW1_UL_RIF_MAC, 1500)
    set_rif_state_ipv4(handle, underlay_rif)
    print(("created underlay_rif %d\n" % underlay_rif))

    ##########################################
    ######    Tunnel Config              #####
    ##########################################
    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    tunnel_init(handle, general_param_p)

    ulay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID
    tunnel_id = create_vxlan_tunnel_flow(handle, ul_vrid, log_port,
                                         SX_TUNNEL_DIRECTION_SYMMETRIC,
                                         SW1_NVE_SIP)

    # tunnel decap rule
    key_type = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP
    tun_type = SX_TUNNEL_TYPE_NVE_VXLAN
    # create decap rule with action forward
    decap_key_p, decap_data_p = create_decap_rule_flow(handle, ul_vrid, key_type,
                                                       SW1_UL_SELF_IP, SW1_UL_NEIGH_IP,
                                                       tunnel_id, tun_type)

    print("created Tunnel decap rule with SIP-DIP as key")

    # Add tunnel map entry
    tunnel_map_entry_add(handle, tunnel_id, tun_type, bridge_id_1, VNI_55)
    tunnel_map_entry_add(handle, tunnel_id, tun_type, bridge_id_2, VNI_100)

    # create route for encapsulated packet
    create_local_route(handle, ul_vrid, underlay_rif, SW1_NET_IP, SW1_NET_MASK)
    tunnel_uc_fdb_set_flow(handle, SX_ACCESS_CMD_ADD, tunnel_id, bridge_id_1, SW1_UL_NGBR_MAC, SW1_NVE_DIP)

    add_neigh(handle, underlay_rif, SW1_NVE_DIP, SW1_UL_NGBR_MAC)
    add_neigh(handle, underlay_rif, SW1_HOST1_IP, SW1_OL_HOST_MAC)

    # create Ingress ACL region, key, acl and rul with set vni action
    key_handle = key_create(FLEX_ACL_KEY_SIP)

    region_id = region_create(key_handle, 254)
    acl_id = acl_create(region_id, SX_ACL_DIRECTION_INGRESS)
    # create set vni rule
    rule_set(region_id, 0, 1, SX_ACCESS_CMD_SET)

    # bind acl to underlay port and apply ingress acl on packets
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  underlay_port,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    print(("Inject Packet to underlay port =====>\n\t\tEther(dst='00:00:01:01:01:01', src='00:00:02:02:02:01') / Dot1Q(vlan=6) /\n"
           + "\t\tIP(dst='20.20.20.20', src='20.20.20.10') / UDP(dport=4789) /\n"
           + "\t\tVXLAN(vni=55, flags='Instance') / Ether(src='00:00:01:01:01:10', dst='00:00:01:01:01:11') /\n"
           + "\t\tIP(src='1.1.1.10', dst='1.1.1.11', ttl=64) / Raw(load='ABCDEFGHIJKLMNOPQRSTUVWXYZ')"))

    # unbind acl from underlay port.
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_UNBIND,
                                  underlay_port,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    # delete the rule and clean up the acl, group
    rule_set(region_id, 0, 1, SX_ACCESS_CMD_DELETE)
    acl_destroy(acl_id, region_id)
    region_destroy(region_id)

    region_id = region_create(key_handle, 254)
    acl_id = acl_create(region_id, SX_ACL_DIRECTION_EGRESS)
    # create set vni rule
    rule_set(region_id, 0, 1, SX_ACCESS_CMD_SET)

    # bind acl to underlay port and apply ingress acl on packets
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  underlay_port,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    print(("Inject packet to overlay port 1 =====>\n\t\tEther(dst='00:00:02:02:02:01', src='00:00:01:01:01:11') /\n"
           + "\t\tDot1Q(vlan=5) /IP(src='1.1.1.11', dst='1.1.1.10', ttl=64) /\n"
           "\t\tRaw(load='ABCDEFGHIJKLMNOPQRSTUVWXYZ')"))

    if args.deinit:
        # unbind acl from underlay port.
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      underlay_port,
                                      acl_id)
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

        # delete the rule and clean up the acl, group
        rule_set(region_id, 0, 1, SX_ACCESS_CMD_DELETE)
        acl_destroy(acl_id, region_id)
        region_destroy(region_id)

        key_destroy(key_handle)

        print("delete neighbors")
        delete_neigh(handle, underlay_rif, SW1_HOST1_IP)
        delete_neigh(handle, underlay_rif, SW1_NVE_DIP)
        print("Delete tunnel fdb entry")
        tunnel_uc_fdb_set_flow(handle, SX_ACCESS_CMD_DELETE, tunnel_id, bridge_id_1, SW1_UL_NGBR_MAC, SW1_NVE_DIP)
        print("delete all local routes")
        delete_all_local_routes(handle, ul_vrid)
        print(("Delete tunnel vni mapping %d" % VNI_55))
        tunnel_map_entry_delete(handle, tunnel_id, tun_type, bridge_id_1, VNI_55)
        print(("Delete tunnel vni mapping %d" % VNI_100))
        tunnel_map_entry_delete(handle, tunnel_id, tun_type, bridge_id_2, VNI_100)
        print("Delete decap rule")
        tunnel_decap_rule_destroy(handle, decap_key_p, decap_data_p)
        print(("Destroy tunnel ID %d" % tunnel_id))
        tunnel_destroy(handle, tunnel_id)
        print("de-init tunnel")
        tunnel_deinit(handle)
        print("delete rif")
        delete_rif(handle, ul_vrid, underlay_rif)
        print("delete vrid")
        delete_vrid(handle, ul_vrid)
        print("de-init router")
        router_deinit(handle)

        print(("Delete bridge & Vport %d" % bridge_id_1))
        bridge_vport_delete(handle, SW1_OL_VLAN_5, overlay_port_1, bridge_id_1, log_egress_vport_1)
        print(("Delete bridge & Vport %d" % bridge_id_2))
        bridge_vport_delete(handle, SW1_OL_VLAN_4, overlay_port_2, bridge_id_2, log_egress_vport_2)

        print("Revert Port VLAN Membersip")
        remove_ports_from_vlan(handle, SW1_UL_VLAN_6, {underlay_port: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(handle, SW1_OL_VLAN_5, {overlay_port_1: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(handle, SW1_OL_VLAN_4, {overlay_port_2: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, 1, {overlay_port_1: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(handle, 1, {overlay_port_2: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(handle, 1, {underlay_port: SX_UNTAGGED_MEMBER})

        print("Revert port parsing depth")
        port_parsing_depth_set(handle, parse_len)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
