#!/usr/bin/env python
"""
This file contains a python commands example for the SPAN module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""
import sys
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
from test_infra_common import get_chip_type

print_api_example_disclaimer()

admin_state_dict = {0: 'Disabled', 1: 'Enabled'}
mirror_direction_dict = {1: 'INGRESS', 2: 'EGRESS'}

span_type_dict = {
    SX_SPAN_TYPE_LOCAL_IB: 'LOCAL_IB',
    SX_SPAN_TYPE_LOCAL_ETH_TYPE1: 'LOCAL_ETH_TYPE1',
    SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1: 'REMOTE_ETH_VLAN_TYPE1',
    SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1: 'REMOTE_ETH_L2_TYPE1',
    SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1: 'REMOTE_ETH_L3_TYPE1'
}

qos_mode_dict = {
    SX_SPAN_QOS_CONFIGURED: 'CONFIGURED',
    SX_SPAN_QOS_MAINTAIN: 'MAINTAIN'
}

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')

module_verbosity_level_p = new_sx_verbosity_level_t_p()
api_verbosity_level_p = new_sx_verbosity_level_t_p()
rc = sx_api_span_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
if rc != SX_STATUS_SUCCESS:
    print(("Failed in sx_api_span_log_verbosity_level_get API rc=%d" % rc))
    sys.exit(rc)
module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

rc = sx_api_span_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
if rc != SX_STATUS_SUCCESS:
    print("Failed to set span API log verbosity level")
    sys.exit(rc)

span_session_cnt_p = new_uint32_t_p()
uint32_t_p_assign(span_session_cnt_p, 0)
rc = sx_api_span_session_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, span_session_cnt_p)
rc1 = sx_api_span_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
if rc1 != SX_STATUS_SUCCESS:
    print("Failed to set span API log verbosity level")
    sys.exit(rc)
if rc == SX_STATUS_MODULE_UNINITIALIZED:
    print("The SPAN module is not initialized. Dump is not available.")
    sys.exit(rc)

if rc != SX_STATUS_SUCCESS:
    print("sx_api_span_session_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
span_session_cnt = uint32_t_p_value(span_session_cnt_p)
span_session_list_p = new_sx_span_session_id_t_arr(span_session_cnt)
rc = sx_api_span_session_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, None, None, span_session_list_p, span_session_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_span_session_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
span_session_cnt = uint32_t_p_value(span_session_cnt_p)
header_printed = False

if span_session_cnt == 0:
    print("No span session found! ")

for i in range(0, span_session_cnt):
    if not header_printed:
        print("=================================================================================================================================================================")
        print("|%16s|%22s|%12s|%14s|%60s|%12s|%17s|" % ("SPAN Session ID", "Type", "Admin State", "Analyzer Port", "Span Session Params", "Mirror Port", "Mirror Direction"))
        print("=================================================================================================================================================================")
        header_printed = True

    span_session_id = sx_span_session_id_t_arr_getitem(span_session_list_p, i)
    span_session_id_str = "%d" % span_session_id

    span_session_params_p = new_sx_span_session_params_t_p()
    rc = sx_api_span_session_get(handle, span_session_id, span_session_params_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_span_session_get failed, rc =%d" % (rc))
        sys.exit(rc)
    span_session_params = sx_span_session_params_t_p_value(span_session_params_p)
    span_type_str = ""
    if span_session_params.span_type in span_type_dict:
        span_type_str = span_type_dict[span_session_params.span_type]

    admin_state_p = new_boolean_t_p()
    rc = sx_api_span_session_state_get(handle, span_session_id, admin_state_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_span_session_state_get failed, rc = %d" % (rc))
        sys.exit(rc)
    admin_state = boolean_t_p_value(admin_state_p)
    admin_state_str = ""
    if admin_state in admin_state_dict:
        admin_state_str = admin_state_dict[admin_state]

    analyzer_port_p = new_sx_port_log_id_t_p()
    rc = sx_api_span_session_analyzer_get(handle, span_session_id, analyzer_port_p)
    if rc != SX_STATUS_SUCCESS and rc != SX_STATUS_ENTRY_NOT_FOUND:
        print("sx_api_span_session_analyzer_get failed, rc = %d" % (rc))
        sys.exit(rc)
    if rc == SX_STATUS_SUCCESS:
        analyzer_port_str = "0x%x" % (sx_port_log_id_t_p_value(analyzer_port_p))
    else:
        analyzer_port_str = ""

    mirror_port_str_list = []
    mirror_ports_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(mirror_ports_cnt_p, 0)
    rc = sx_api_span_session_mirror_get(handle, span_session_id, None, mirror_ports_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_span_session_mirror_get failed, rc = %d" % (rc))
        sys.exit(rc)
    mirror_ports_cnt = uint32_t_p_value(mirror_ports_cnt_p)
    mirror_ports_list_p = new_sx_span_mirror_t_arr(mirror_ports_cnt)
    rc = sx_api_span_session_mirror_get(handle, span_session_id, mirror_ports_list_p, mirror_ports_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_span_session_mirror_get failed, rc = %d" % (rc))
        sys.exit(rc)
    mirror_ports_cnt = uint32_t_p_value(mirror_ports_cnt_p)
    for j in range(0, mirror_ports_cnt):
        mirror_port = sx_span_mirror_t_arr_getitem(mirror_ports_list_p, j)
        mirror_port_str = "0x%x" % mirror_port.log_port
        mirror_direction_str = ""
        if mirror_port.mirror_direction in mirror_direction_dict:
            mirror_direction_str = mirror_direction_dict[mirror_port.mirror_direction]
        mirror_port_str_list.append((mirror_port_str, mirror_direction_str))

    line_str_list = []
    mirror_port_str1 = ""
    mirror_port_str2 = ""
    mirror_port_str3 = ""
    mirror_port_str4 = ""
    mirror_port_str5 = ""
    mirror_port_str6 = ""
    mirror_port_str7 = ""
    mirror_direction_str1 = ""
    mirror_direction_str2 = ""
    mirror_direction_str3 = ""
    mirror_direction_str4 = ""
    mirror_direction_str5 = ""
    mirror_direction_str6 = ""
    mirror_direction_str7 = ""

    if mirror_ports_cnt > 0:
        mirror_port_str1 = mirror_port_str_list[0][0]
        mirror_direction_str1 = mirror_port_str_list[0][1]
    if mirror_ports_cnt > 1:
        mirror_port_str2 = mirror_port_str_list[1][0]
        mirror_direction_str2 = mirror_port_str_list[1][1]
    if mirror_ports_cnt > 2:
        mirror_port_str3 = mirror_port_str_list[2][0]
        mirror_direction_str3 = mirror_port_str_list[2][1]
    if mirror_ports_cnt > 3:
        mirror_port_str4 = mirror_port_str_list[3][0]
        mirror_direction_str4 = mirror_port_str_list[3][1]
    if mirror_ports_cnt > 4:
        mirror_port_str5 = mirror_port_str_list[4][0]
        mirror_direction_str5 = mirror_port_str_list[4][1]
    if mirror_ports_cnt > 5:
        mirror_port_str6 = mirror_port_str_list[5][0]
        mirror_direction_str6 = mirror_port_str_list[5][1]
    if mirror_ports_cnt > 6:
        mirror_port_str7 = mirror_port_str_list[6][0]
        mirror_direction_str7 = mirror_port_str_list[6][1]

    printed_line_count = 0
    if span_session_params.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        local_eth_type1 = span_session_params.span_type_format.local_eth_type1
        qos_mode_str = ""
        if local_eth_type1.qos_mode in qos_mode_dict:
            qos_mode_str = qos_mode_dict[local_eth_type1.qos_mode]
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             span_session_id_str,
                             span_type_str,
                             admin_state_str,
                             analyzer_port_str,
                             "QOS Mode: %s, Switch Priority: 0x%x" % (qos_mode_str, local_eth_type1.switch_prio),
                             mirror_port_str1,
                             mirror_direction_str1))
        printed_line_count = 1
    elif span_session_params.span_type == SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        remote_eth_vlan_type1 = span_session_params.span_type_format.remote_eth_vlan_type1
        qos_mode_str = ""
        if remote_eth_vlan_type1.qos_mode in qos_mode_dict:
            qos_mode_str = qos_mode_dict[remote_eth_vlan_type1.qos_mode]
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             span_session_id_str,
                             span_type_str,
                             admin_state_str,
                             analyzer_port_str,
                             "QOS Mode: %s, Switch Priority: 0x%x, VID: %d" % (qos_mode_str, remote_eth_vlan_type1.switch_prio, remote_eth_vlan_type1.vid),
                             mirror_port_str1,
                             mirror_direction_str1))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "VLAN Ethertype ID: 0x%x, PCP: 0x%x, DEI: 0x%x" % (remote_eth_vlan_type1.vlan_ethertype_id, remote_eth_vlan_type1.pcp, remote_eth_vlan_type1.dei),
                             mirror_port_str2,
                             mirror_direction_str2))
        printed_line_count = 2
    elif span_session_params.span_type == SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        remote_eth_l2_type1 = span_session_params.span_type_format.remote_eth_l2_type1
        qos_mode_str = ""
        if remote_eth_l2_type1.qos_mode in qos_mode_dict:
            qos_mode_str = qos_mode_dict[remote_eth_l2_type1.qos_mode]
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             span_session_id_str,
                             span_type_str,
                             admin_state_str,
                             analyzer_port_str,
                             "QOS Mode: %s, Switch Priority: 0x%x, VID: %d" % (qos_mode_str, remote_eth_l2_type1.switch_prio, remote_eth_l2_type1.vid),
                             mirror_port_str1,
                             mirror_direction_str1))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "VLAN Ethertype ID: 0x%x, PCP: 0x%x, DEI: 0x%x" % (remote_eth_l2_type1.vlan_ethertype_id, remote_eth_l2_type1.pcp, remote_eth_l2_type1.dei),
                             mirror_port_str2,
                             mirror_direction_str2))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "Tag Packet: 0x%x, DMAC: %s" % (remote_eth_l2_type1.tp, remote_eth_l2_type1.mac.to_str()),
                             mirror_port_str3,
                             mirror_direction_str3))
        printed_line_count = 3
    elif span_session_params.span_type == SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        remote_eth_l3_type1 = span_session_params.span_type_format.remote_eth_l3_type1
        qos_mode_str = ""
        if remote_eth_l3_type1.qos_mode in qos_mode_dict:
            qos_mode_str = qos_mode_dict[remote_eth_l3_type1.qos_mode]
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             span_session_id_str,
                             span_type_str,
                             admin_state_str,
                             analyzer_port_str,
                             "QOS Mode: %s, Switch Priority: 0x%x, VID: %d" % (qos_mode_str, remote_eth_l3_type1.switch_prio, remote_eth_l3_type1.vid),
                             mirror_port_str1,
                             mirror_direction_str1))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "VLAN Ethertype ID: 0x%x, PCP: 0x%x, DEI: 0x%x" % (remote_eth_l3_type1.vlan_ethertype_id, remote_eth_l3_type1.pcp, remote_eth_l3_type1.dei),
                             mirror_port_str2,
                             mirror_direction_str2))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "Tag Packet: 0x%x, DMAC: %s" % (remote_eth_l3_type1.tp, remote_eth_l3_type1.mac.to_str()),
                             mirror_port_str3,
                             mirror_direction_str3))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "SMAC: %s" % (remote_eth_l3_type1.smac.to_str()),
                             mirror_port_str4,
                             mirror_direction_str4))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "DIP: %s" % (ip_addr_to_str(remote_eth_l3_type1.dest_ip)),
                             mirror_port_str5,
                             mirror_direction_str5))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "SIP: %s" % (ip_addr_to_str(remote_eth_l3_type1.src_ip)),
                             mirror_port_str6,
                             mirror_direction_str6))
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             "",
                             "",
                             "",
                             "",
                             "DSCP: 0x%x, ECN: 0x%x, TTL: 0x%x" % (remote_eth_l3_type1.dscp, remote_eth_l3_type1.ecn, remote_eth_l3_type1.ttl),
                             mirror_port_str7,
                             mirror_direction_str7))
        printed_line_count = 7
    else:
        line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                             span_session_id_str,
                             span_type_str,
                             admin_state_str,
                             analyzer_port_str,
                             "",
                             mirror_port_str1,
                             mirror_direction_str1))
        printed_line_count = 1

    if mirror_ports_cnt > printed_line_count:
        for j in range(printed_line_count, mirror_ports_cnt):
            line_str_list.append("|%16s %22s %12s %14s %60s|%12s|%17s|" % (
                                 "",
                                 "",
                                 "",
                                 "",
                                 "",
                                 mirror_port_str_list[j][0],
                                 mirror_port_str_list[j][1]))

    line_str_list_len = len(line_str_list)
    for j in range(0, line_str_list_len):
        print(line_str_list[j])
        if j == (line_str_list_len - 1):
            print("=================================================================================================================================================================")
        else:
            print("|%128s|-------------------------------" % (""))


def span_mirror_disallow_get(port_list=None):
    """SPAN MIRROR DISALLOW GET:
    get mirror disallow configs of the port_list
    """
    if port_list:
        print('Span mirror disallow get on ports:[{}]'.format(', '.join(hex(x) for x in port_list)))
    cfg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(cfg_cnt_p, 0)
    cmd = SX_ACCESS_CMD_GET
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, None, cfg_cnt_p)
    cfg_cnt = uint32_t_p_value(cfg_cnt_p)
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    cmd = SX_ACCESS_CMD_GET_FIRST
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, cfg_item_list, cfg_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_span_mirror_enable_port_iter_get, GET_FIRST, [rc=%d]" % (rc)))
        sys.exit(rc)
    type_enum_dict = get_enum_string_dict('SX_SPAN_MIRROR_BIND')
    print_tail = False
    for i in range(cfg_cnt):
        if i == 0:
            print("============================= SPAN MIRROR DISALLOW CONFIGS ===============================")
            print("------------------------------------------------------------------------------------------")
            print(("|%-11s|%-16s|%-48s|%-10s|" % ("Port", "Flow_Type", "Mirror_Trigger_Type", "Disallow")))
            print("------------------------------------------------------------------------------------------")
            print_tail = True
        cfg_item = sx_span_mirror_enable_port_set_t_arr_getitem(cfg_item_list, i)
        # for elephant settings
        for j in range(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow_cnt):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j)
            print(("|0x%-9x|%-16s|%-48s|%-10s|" % (cfg_item.ingress_log_port, "Elephant", type_enum_dict[mirror_trigger_disallow.type], get_boolean_string(mirror_trigger_disallow.mirror_trigger_disallow))))
        # for non_elephant settings
        for j in range(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, j)
            print(("|0x%-9x|%-16s|%-48s|%-10s|" % (cfg_item.ingress_log_port, "None-elephant", type_enum_dict[mirror_trigger_disallow.type], get_boolean_string(mirror_trigger_disallow.mirror_trigger_disallow))))
    if print_tail:
        print("==========================================================================================")


chip_type = get_chip_type(handle)
if chip_type >= SX_CHIP_TYPE_SPECTRUM4:
    span_mirror_disallow_get()

sx_api_close(handle)
