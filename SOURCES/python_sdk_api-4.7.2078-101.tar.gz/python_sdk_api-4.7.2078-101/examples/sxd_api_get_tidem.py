#!/usr/bin/env python
from python_sdk_api.sx_api import *
import socket
import struct


import sys
import errno
import time
import os
import argparse
from python_sdk_api.sxd_api import *


print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] Reading TIDEM register:\n")

tidem = ku_tidem_reg()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0
meta.access_cmd = SXD_ACCESS_CMD_GET

for i in range(0, 4):
    for j in range(0, 4):
        tidem.overlay_ecn = i
        tidem.underlay_ecn = j

        rc = sxd_access_reg_tidem(tidem, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to read TIDEM register, rc: %d" % (rc)

        print("overlay_ecn: ", tidem.overlay_ecn)
        print("underlay_ecn: ", tidem.underlay_ecn)
        print("trap_en: ", tidem.trap_en)
        print("eip_ecn: ", tidem.eip_ecn)
        print("trap_id: ", tidem.trap_id)
        print("")

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
