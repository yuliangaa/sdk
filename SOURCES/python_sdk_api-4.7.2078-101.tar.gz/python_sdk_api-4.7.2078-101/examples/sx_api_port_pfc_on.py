#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


SPECTRUM_SWID = 0
DEFAULT_EGRESS_POOL = 11
DEFAULT_INGRESS_POOL = 0
EXAMPLE_PRIORITY_GROUP = 1
EXAMPLE_PRIORITY_GROUP_SIZE = 1000
EXAMPLE_PRIORITY_GROUP_ISLOSSY = 0
EXAMPLE_PRIORITY_GROUP_XON = 0
EXAMPLE_PRIORITY_GROUP_XOFF = 500
EXAMPLE_TRAFFIC_CLASS_PRIO = 6


parser = argparse.ArgumentParser(description='sx_api_port_pfc_on')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

# Open Handle
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)
port_list = get_ports(handle, 2)
PORT1 = port_list[0]
PORT2 = port_list[1]


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes speificed ports_dict into target vlan. "
    print("--------------- RMEMOVE PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to delete port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Deleted port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def main():

    try:

        add_ports_to_vlan(1, {PORT1: SX_TAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT2: SX_TAGGED_MEMBER})

        """ Set FDB UC for traffic """
        mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
        data_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(data_cnt_p, 2)
        mac_addr = ether_addr("24:8a:07:55:11:1c")

        mac_entry1 = sx_fdb_uc_mac_addr_params_t()
        mac_entry1.mac_addr = mac_addr
        mac_entry1.fid_vid = 1          # Filtering Identifier, VID for static MAC
        mac_entry1.log_port = PORT1
        mac_entry1.entry_type = SX_FDB_UC_STATIC
        mac_entry1.action = SX_FDB_ACTION_FORWARD
        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

        mac_addr = ether_addr("24:8a:07:55:11:1d")
        mac_entry2 = sx_fdb_uc_mac_addr_params_t()
        mac_entry2.mac_addr = mac_addr
        mac_entry2.fid_vid = 1          # Filtering Identifier, VID for static MAC
        mac_entry2.log_port = PORT2
        mac_entry2.entry_type = SX_FDB_UC_STATIC
        mac_entry2.action = SX_FDB_ACTION_FORWARD
        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
        data_cnt = uint32_t_p_value(data_cnt_p)
        print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        original_port1_fc_mode_p = new_sx_port_flow_ctrl_mode_t_p()
        rc = sx_api_port_pfc_enable_get(handle, PORT1, EXAMPLE_TRAFFIC_CLASS_PRIO, original_port1_fc_mode_p)
        print(("sx_api_port_pfc_enable_get: 0x%x, rc %d" % (PORT1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        original_port1_fc_mode = sx_port_flow_ctrl_mode_t_p_value(original_port1_fc_mode_p)

        original_port2_fc_mode_p = new_sx_port_flow_ctrl_mode_t_p()
        rc = sx_api_port_pfc_enable_get(handle, PORT1, EXAMPLE_TRAFFIC_CLASS_PRIO, original_port2_fc_mode_p)
        print(("sx_api_port_pfc_enable_get: 0x%x, rc %d" % (PORT2, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        original_port2_fc_mode = sx_port_flow_ctrl_mode_t_p_value(original_port2_fc_mode_p)

        """ Enable PFC """
        fc_mode = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN
        rc = sx_api_port_pfc_enable_set(handle, PORT1, EXAMPLE_TRAFFIC_CLASS_PRIO, fc_mode)
        print(("sx_api_port_pfc_enable_set: 0x%x enabled, rc %d" % (PORT1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        # fc_mode = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS
        rc = sx_api_port_pfc_enable_set(handle, PORT2, EXAMPLE_TRAFFIC_CLASS_PRIO, fc_mode)
        print(("sx_api_port_pfc_enable_set: 0x%x enabled, rc %d" % (PORT2, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        """ Enable TQ.TC """
        attr1_p = new_sx_cos_port_buffer_attr_t_p()
        attr1_deinit_p = new_sx_cos_port_buffer_attr_t_p()
        attr1_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(attr1_deinit_cnt_p, 1)

        attr1_p.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        attr1_p.attr.egress_port_tc_buff_attr.size = 0
        attr1_p.attr.egress_port_tc_buff_attr.tc = EXAMPLE_TRAFFIC_CLASS_PRIO
        attr1_p.attr.egress_port_tc_buff_attr.pool_id = DEFAULT_EGRESS_POOL
        sx_cos_port_buffer_attr_t_p_assign(attr1_deinit_p, attr1_p)

        """ Get Current for deinit TQ.TC """
        rc = sx_api_cos_port_buff_type_get(handle, PORT2, attr1_deinit_p, attr1_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, attr1_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        shared_attr1_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr1_deinit_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr1_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(shared_attr1_deinit_cnt_p, 1)
        shared_attr1_p.type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        shared_attr1_p.attr.egress_port_tc_shared_buff_attr.tc = EXAMPLE_TRAFFIC_CLASS_PRIO
        shared_attr1_p.attr.egress_port_tc_shared_buff_attr.max.mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E
        shared_attr1_p.attr.egress_port_tc_shared_buff_attr.max.max.alpha = SX_COS_PORT_BUFF_ALPHA_2_E
        shared_attr1_p.attr.egress_port_tc_shared_buff_attr.pool_id = DEFAULT_EGRESS_POOL
        sx_cos_port_shared_buffer_attr_t_p_assign(shared_attr1_deinit_p, shared_attr1_p)

        """ Get Current shared buffer attributes for deinit """
        rc = sx_api_cos_port_shared_buff_type_get(handle, PORT2, shared_attr1_deinit_p, shared_attr1_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [ log_port=0x%x , cnt=%d, rc=%d] " % (PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, shared_attr1_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT2, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        """ Set LOSSLESS """
        attr2_p = new_sx_cos_port_buffer_attr_t_p()
        attr2_deinit_p = new_sx_cos_port_buffer_attr_t_p()
        attr2_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(attr2_deinit_cnt_p, 1)

        attr2_p.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
        attr2_p.attr.ingress_port_pg_buff_attr.size = EXAMPLE_PRIORITY_GROUP_SIZE
        attr2_p.attr.ingress_port_pg_buff_attr.pg = EXAMPLE_PRIORITY_GROUP
        """ is_lossy: 0=Lossless, 1=Lossy """
        attr2_p.attr.ingress_port_pg_buff_attr.is_lossy = EXAMPLE_PRIORITY_GROUP_ISLOSSY
        attr2_p.attr.ingress_port_pg_buff_attr.xon = EXAMPLE_PRIORITY_GROUP_XON
        attr2_p.attr.ingress_port_pg_buff_attr.xoff = EXAMPLE_PRIORITY_GROUP_XOFF
        attr2_p.attr.ingress_port_pg_buff_attr.pool_id = DEFAULT_INGRESS_POOL
        sx_cos_port_buffer_attr_t_p_assign(attr2_deinit_p, attr2_p)

        """ Get Current port buffer attributes for deinit """
        rc = sx_api_cos_port_buff_type_get(handle, PORT1, attr2_deinit_p, attr2_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT1, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, attr2_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT1, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        shared_attr2_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr2_deinit_p = new_sx_cos_port_shared_buffer_attr_t_p()
        shared_attr2_deinit_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(shared_attr2_deinit_cnt_p, 1)

        shared_attr2_p.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
        shared_attr2_p.attr.ingress_port_pg_shared_buff_attr.pg = EXAMPLE_PRIORITY_GROUP
        shared_attr2_p.attr.ingress_port_pg_shared_buff_attr.max.mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E
        shared_attr2_p.attr.ingress_port_pg_shared_buff_attr.max.max.alpha = SX_COS_PORT_BUFF_ALPHA_1_128_E
        shared_attr2_p.attr.ingress_port_pg_shared_buff_attr.pool_id = DEFAULT_INGRESS_POOL
        sx_cos_port_shared_buffer_attr_t_p_assign(shared_attr2_deinit_p, shared_attr2_p)

        """ Get Current for deinit  """
        rc = sx_api_cos_port_shared_buff_type_get(handle, PORT1, shared_attr2_deinit_p, shared_attr2_deinit_cnt_p)
        print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (PORT1, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, shared_attr2_p, 1)
        print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, PORT1, 1, rc)))
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        # set Switch Priority To PG mapping so packet with correct pcp/dscp can enter the PG buffer and trigger pfc.
        prio_to_buff_get_p = new_sx_cos_port_prio_buff_t_p()
        rc = sx_api_cos_port_prio_buff_map_get(handle, PORT1, prio_to_buff_get_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        prio_to_buff_p = new_sx_cos_port_prio_buff_t_p()
        for prio in range(0, 15):
            if prio == EXAMPLE_TRAFFIC_CLASS_PRIO:
                sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, prio, EXAMPLE_PRIORITY_GROUP)
            else:
                sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, prio, 0)

        rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, PORT1, prio_to_buff_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        if args.deinit:
            rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, PORT1, prio_to_buff_get_p)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, shared_attr2_deinit_p, 1)
            print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_DELETE, PORT1, 1, rc))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT1, attr2_deinit_p, 1)
            print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_DELETE, PORT1, 1, rc))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, shared_attr1_deinit_p, 1)
            print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_DELETE, PORT2, 1, rc))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, PORT2, attr1_deinit_p, 1)
            print("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_DELETE, PORT2, 1, rc))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_port_pfc_enable_set(handle, PORT2, EXAMPLE_TRAFFIC_CLASS_PRIO, original_port2_fc_mode)
            print(("sx_api_port_pfc_enable_set: 0x%x, rc %d" % (PORT2, rc)))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_port_pfc_enable_set(handle, PORT1, EXAMPLE_TRAFFIC_CLASS_PRIO, original_port1_fc_mode)
            print(("sx_api_port_pfc_enable_set: 0x%x, rc %d" % (PORT1, rc)))
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)

            rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)

            remove_ports_from_vlan(1, {PORT1: SX_TAGGED_MEMBER})
            remove_ports_from_vlan(1, {PORT2: SX_TAGGED_MEMBER})

            add_ports_to_vlan(1, {PORT1: SX_UNTAGGED_MEMBER})
            add_ports_to_vlan(1, {PORT2: SX_UNTAGGED_MEMBER})

    finally:
        delete_sx_fdb_uc_mac_addr_params_t_arr(mac_list_p)
        delete_uint32_t_p(data_cnt_p)
        delete_sx_port_flow_ctrl_mode_t_p(original_port1_fc_mode_p)
        delete_sx_port_flow_ctrl_mode_t_p(original_port2_fc_mode_p)
        delete_sx_cos_port_buffer_attr_t_p(attr1_p)
        delete_sx_cos_port_buffer_attr_t_p(attr1_deinit_p)
        delete_uint32_t_p(attr1_deinit_cnt_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr1_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr1_deinit_p)
        delete_uint32_t_p(shared_attr1_deinit_cnt_p)
        delete_sx_cos_port_buffer_attr_t_p(attr2_p)
        delete_sx_cos_port_buffer_attr_t_p(attr2_deinit_p)
        delete_uint32_t_p(attr2_deinit_cnt_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr2_p)
        delete_sx_cos_port_shared_buffer_attr_t_p(shared_attr2_deinit_p)
        delete_uint32_t_p(shared_attr2_deinit_cnt_p)
        sx_api_close(handle)


if __name__ == "__main__":
    main()
