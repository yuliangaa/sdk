#!/usr/bin/env python
'''
This is an example how to set port MTU.
'''

import errno
import sys
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_mtu_set')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

# get a log_port
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 1)
log_port_list_p = new_sx_port_log_id_t_arr(1)
rc = sx_api_port_swid_port_list_get(handle, 0, log_port_list_p, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_swid_port_list_get failed, rc=[%d] " % (rc)))
    sys.exit(rc)
log_port = sx_port_log_id_t_arr_getitem(log_port_list_p, 0)
new_oper_mtu_size = 1522

# get the vurrent mtu value
original_max_mtu_size_p = new_sx_port_mtu_t_p()
original_oper_mtu_size_p = new_sx_port_mtu_t_p()
rc = sx_api_port_mtu_get(handle, log_port, original_max_mtu_size_p, original_oper_mtu_size_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
    sys.exit(rc)
original_oper_mtu_size = sx_port_mtu_t_p_value(original_oper_mtu_size_p)

# set new mtu value
rc = sx_api_port_mtu_set(handle, log_port, new_oper_mtu_size)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_mtu_set failed, rc=[%d] " % (rc)))
    sys.exit(rc)
print(("MTU set for port %d, MTU: %d" % (log_port, new_oper_mtu_size)))

# get the new mtu value
max_mtu_size_p = new_sx_port_mtu_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
rc = sx_api_port_mtu_get(handle, log_port, max_mtu_size_p, oper_mtu_size_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_mtu_get failed, rc=[%d] " % (rc)))
    sys.exit(rc)

oper_mtu_size = sx_port_mtu_t_p_value(oper_mtu_size_p)
print(("MTU get for port %d, MTU: %d" % (log_port, oper_mtu_size)))

if args.deinit:
    # set back to the original mtu value
    rc = sx_api_port_mtu_set(handle, log_port, original_oper_mtu_size)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_mtu_set failed, rc=[%d] " % (rc)))
        sys.exit(rc)
    print(("MTU set for port %d, MTU: %d" % (log_port, original_oper_mtu_size)))

sx_api_close(handle)
