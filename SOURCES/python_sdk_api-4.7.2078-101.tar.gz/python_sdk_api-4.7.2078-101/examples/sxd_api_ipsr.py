#!/usr/bin/env python

import sys
import os
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse


def parse_arguments():
    parser = argparse.ArgumentParser(description='sxd_api_ipsr example')
    parser.add_argument('--port_profile', default=0, type=int, help="port profiles index 0-3")
    return parser.parse_args()


def main():
    args = parse_arguments()

    rc, handle = sx_api_open(None)
    print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    assert rc == SX_STATUS_SUCCESS, "Failed to open api handle.\nPlease check that SDK is running."

    try:
        if common_lib.get_chip_type(handle) in [SX_CHIP_TYPE_QUANTUM, SX_CHIP_TYPE_QUANTUM2, SX_CHIP_TYPE_SPECTRUM]:
            print("IPSR Not supported on current ASIC - Nothing to do here.")
            return 0

        print("[+] IPSR register access ")
        print("[+] initializing register access")
        rc = sxd_access_reg_init(0, None, 4)
        assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init faled, rc: %d" % (rc)

        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0
        meta.access_cmd = SXD_ACCESS_CMD_GET

        ipsr = ku_ipsr_reg()
        ipsr.profile_index = args.port_profile

        print("[+] Get IPSR")
        rc = sxd_access_reg_ipsr(ipsr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get IPSR  register, rc: %d" % (rc)

        print("[+] port profile ", ipsr.profile_index)

        print("[+] Get IPSR content")
        print("====================")
        print("[+] Capability size (in KBs): ", ipsr.cap_size)
        print("[+] Current size (in KBs): ", ipsr.current_size)
        print("[+] Current entries: ", ipsr.current_entries)

        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)
    finally:
        assert sx_api_close(handle) == SX_STATUS_SUCCESS, "Failed to close SDK Handle"


if __name__ == "__main__":
    sys.exit(main())
