#!/usr/bin/env python
"""

This file contains Python command example for ECMP IP container which contains IP and re-lookup next hops.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

"""
import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
import test_infra_common
import time
import argparse

######################################################
#    defines
######################################################
SWID = 0

# string constants
IP_STR = "IP"
RIF_STR = "RIF"
RELOOKUP_ECMP_ID = "RELOOKUP_ECMP_ID"
RELOOKUP_VRID = "RELOOKUP_VRID"
REHASH_ENABLE = "REHASH_ENABLE"
REHASH_SEED = "REHASH_SEED"
WEIGHT_STR = "WEIGHT"
ACTION_STR = "ACTION"
COUNTER_STR = "COUNTER"


######################################################
#    functions
######################################################

def parse_args():
    description_str = """
    This is an example for ECMP IP container which contains IP and re-lookup next hops
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    return parser.parse_args()


def router_init(handle,
                ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def router_deinit(handle):
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def create_vrid(handle):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    " This function removes ports from given vlan_. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan_ %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan_ %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan_. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan_ %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan_ %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vlan_rif(handle, vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def delete_rif(handle, vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    print(("Delete RIF: %d, rc: %d " % (rif, rc)))
    return rc


def delete_vrid(handle, vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def create_external_ecmp_container(handle, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def make_ecmp_next_hop_ip(rif, ipaddr, weight=1, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED,
                          counter_id=0):
    """
        This function creates next_hop of type 'IP' struct with given parameters.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def make_ecmp_next_hop_relookup_ecmp(relookup_ecmp_id, rehash_enable=False, rehash_seed=0, weight=1,
                                     action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates next_hop of type 'ECMP_relookup' struct with given parameters.
    """

    next_hop_key = sx_next_hop_key_t()
    next_hop_key.type = SX_NEXT_HOP_TYPE_RELOOKUP
    next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_ECMP_E
    next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_data.ecmp_container = relookup_ecmp_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = next_hop_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def make_ecmp_next_hop_relookup_vrid(relookup_vrid, rehash_enable=False, rehash_seed=0, weight=1,
                                     action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates next_hop of type 'LPM_relookup with new vrid' struct with given parameters.
    """

    next_hop_key = sx_next_hop_key_t()
    next_hop_key.type = SX_NEXT_HOP_TYPE_RELOOKUP
    next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_LPM_E
    next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_data.vrid = relookup_vrid

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = next_hop_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @nh_params_list (dict list):     List of next hop parameters dictionary with fields:
                                            RIF_STR, IP_STR, RELOOKUP_ECMP_ID, RELOOKUP_VRID,
                                            WEIGHT_STR, ACTION_STR, COUNTER_STR.
                                            When relookup is given, the following fields can be added optionally:
                                            REHASH_ENABLE and REHASH_SEED.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        nh[ACTION_STR] = nh.get(ACTION_STR, SX_ROUTER_ACTION_FORWARD)
        nh[COUNTER_STR] = nh.get(COUNTER_STR, 0)
        nh[REHASH_ENABLE] = nh.get(REHASH_ENABLE, False)
        nh[REHASH_SEED] = nh.get(REHASH_SEED, 0)

        for key in nh:
            if key == RIF_STR:
                next_hop = make_ecmp_next_hop_ip(nh[RIF_STR], nh[IP_STR],
                                                 nh[WEIGHT_STR], nh[ACTION_STR], SX_TRAP_PRIORITY_MED, nh[COUNTER_STR])

            elif key == RELOOKUP_ECMP_ID or key == RELOOKUP_VRID:
                if key == RELOOKUP_ECMP_ID:
                    next_hop = make_ecmp_next_hop_relookup_ecmp(nh[RELOOKUP_ECMP_ID], nh[REHASH_ENABLE], nh[REHASH_SEED],
                                                                nh[WEIGHT_STR], nh[ACTION_STR], SX_TRAP_PRIORITY_MED, nh[COUNTER_STR])
                elif key == RELOOKUP_VRID:
                    next_hop = make_ecmp_next_hop_relookup_vrid(nh[RELOOKUP_VRID], nh[REHASH_ENABLE], nh[REHASH_SEED],
                                                                nh[WEIGHT_STR], nh[ACTION_STR], SX_TRAP_PRIORITY_MED, nh[COUNTER_STR])

        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def destroy_ecmp_container(handle, ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def create_ecmp_uc_route(handle, vrid, addr, mask, ecmp_id):
    " This function creates ecmp uc route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_ecmp_uc_route_data(ecmp_id)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ECMP uc route"

    print("Created ECMP uc route, rc: %d " % (rc))


def make_ecmp_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates ecmp uc_route_data struct with given parametrs.
            action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    return uc_route_data


def set_rif_state_ipv4(handle, rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    # set rif2 state to ipv4 enable
    rif_state_2 = sx_router_interface_state_t()
    rif_state_2.ipv4_enable = enable
    rif_state_2.ipv6_enable = False
    rif_state_2.ipv4_mc_enable = False
    rif_state_2.ipv6_mc_enable = False
    rif_state_p_2 = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p_2, rif_state_2)
    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p_2)
    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh(handle, rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def delete_next_hops_uc_route(handle, vrid, addr, mask, ipv):
    " This function deletes all next hops from given vrid. "

    if ipv == 4:
        ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    else:
        ip_prefix = make_sx_ip_prefix_v6(addr, mask)

    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted IPv" + str(ipv) + " uc next hops of VRID %d, rc: %d" % (vrid, rc))


def modify_external_ecmp_container(handle, ecmp_id, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param ecmp__id: ECMP container ID.
    @nh_params_list (list):     a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify external ECMP container, rc %d" % (rc)

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Modified ECMP container ID %d " % (ecmp_id))


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted  neighbor from rif %d, rc: %d" % (rif, rc))


######################################################
#    main
######################################################


def main():
    args = parse_args()

    if not args.force:
        test_infra_common.print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = test_infra_common.get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("This example is not supported on SPC1 - Exiting gracefully")
        sys.exit(0)

    port_list = test_infra_common.mapPortAndInterfaces(handle)
    PORT1 = port_list[0]
    PORT2 = port_list[1]

    # Init router
    router_init(handle)

    # Create vrid
    vrid = create_vrid(handle)

    # Configure vlans interfaces
    default_vlan = 1
    vlan1 = 5
    vlan2 = 6

    remove_ports_from_vlan(handle, default_vlan, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, vlan1, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(handle, default_vlan, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(handle, vlan2, {PORT2: SX_TAGGED_MEMBER})

    RIF1_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x01)
    port1_rif = create_vlan_rif(handle, vrid, vlan1, RIF1_MAC)
    RIF2_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x02)
    port2_rif = create_vlan_rif(handle, vrid, vlan2, RIF2_MAC)

    # Set rif to UP state
    set_rif_state_ipv4(handle, port1_rif)
    set_rif_state_ipv4(handle, port2_rif)

    print("Create ECMPx with one IP next-hop. Then create two ECMP's, each with one "
          "relookup next-hop pointing to ECMPx. (Illustration: ECMP1 --> ECMPx; ECMP2 --> ECMPx).")

    # Create ECMPx with an IP next hop
    NEIGH1_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x72)
    next_hop1_ip = "2.2.2.2"
    add_neigh(handle, port2_rif, next_hop1_ip, NEIGH1_MAC)

    next_hops_params_list = []
    next_hops_params_list.append({RIF_STR: port2_rif, IP_STR: next_hop1_ip, WEIGHT_STR: 64})
    ecmp_x_id = create_external_ecmp_container(handle, next_hops_params_list)

    # Create ECMP1 and ECMP2 both with re-lookup next hop to ECMPx
    next_hops_params_list = [{RELOOKUP_ECMP_ID: ecmp_x_id, WEIGHT_STR: 64}]
    ecmp_1_id = create_external_ecmp_container(handle, next_hops_params_list)
    ecmp_2_id = create_external_ecmp_container(handle, next_hops_params_list)

    # Create 2 UC Routes, one set to ECMP1 and the other to ECMP2
    net_1_ip = "10.10.0.0"
    net_2_ip = "10.7.0.0"
    onet_mask = "255.255.0.0"
    create_ecmp_uc_route(handle, vrid, net_1_ip, onet_mask, ecmp_1_id)
    create_ecmp_uc_route(handle, vrid, net_2_ip, onet_mask, ecmp_2_id)

    # Another side start sending traffic
    # Send packet to PORT1 (port1_rif), with vlan=5. With a destionation IP hitting one of the two UC Routes
    print("####################################################################")
    print("Another side send traffic")
    print(
        "Expect: traffic on both UC Routes reach to ECMPx and last goes throught rif %d (port 0x%x) "
        "with the destination MAC as of the IP next-hop in ECMPx" % (port2_rif, PORT2))
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    print("Now, let the re-lookup next-hop in ECMP2 point to a different")
    print("ECMP, y. (Illustration: ECMP1 --> ECMPx; ECMP2 --> ECMPy).")

    # Create ECMPy with another IP next hop
    NEIGH2_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x73)
    next_hop2_ip = "2.2.2.3"
    add_neigh(handle, port2_rif, next_hop2_ip, NEIGH2_MAC)

    next_hops_params_list = [{RIF_STR: port2_rif, IP_STR: next_hop2_ip, WEIGHT_STR: 64}]
    ecmp_y_id = create_external_ecmp_container(handle, next_hops_params_list)

    # Change ECMP2 to re-lookup to ECMPy instead of ECMPx
    next_hops_params_list = [{RELOOKUP_ECMP_ID: ecmp_y_id, WEIGHT_STR: 64}]
    modify_external_ecmp_container(handle, ecmp_2_id, next_hops_params_list)

    # Another side start sending traffic
    # Send packet to PORT1 (port1_rif), with vlan=5. With a destionation IP hitting the UC Route set to ECMP2
    print("####################################################################")
    print("Another side continue send traffic")
    print(
        "Expect: Taffic on UC Route set to ECMP2 start going through rif %d (port 0x%x) "
        "with the destination MAC as of the IP next-hop in ECMPy" % (port2_rif, PORT2))
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    print("Add IP next-hop to ECMP2, so ECMP2 contains an IP next-hop and its existing re-lookup next-hop to ECMPy")
    next_hops_params_list = []
    next_hops_params_list.append({RELOOKUP_ECMP_ID: ecmp_y_id,
                                  WEIGHT_STR: 64})
    next_hops_params_list.append({RIF_STR: port2_rif,
                                  IP_STR: next_hop1_ip,
                                  WEIGHT_STR: 64})
    modify_external_ecmp_container(handle, ecmp_2_id, next_hops_params_list)

    print("Unresolve the next-hop in ECMPy. Note that this the only next-hop in ECMPy")
    delete_neigh(handle, port2_rif, next_hop2_ip)
    print("Now, ECMPy has an empty active set and, as a result, all re-lookup next-hops to it become unresolved.")
    print(
        "As a result, ECMP2 has now only one resolved next-hop - the IP one -, since the other re-lookup next-hop become unresolved.")

    # Another side start sending traffic
    # Send packet to PORT1 (port1_rif), with vlan=5. With a destionation IP hitting the UC Route set to ECMP2
    print("####################################################################")
    print("Another side send traffic")
    print("Expect: traffic on uc route of ECMP2 goes through rif %d (port 0x%x) "
          "with the destination MAC as of the IP next-hop in ECMP2, and not going throught the unresolved re-lookup." % (port2_rif, PORT2))
    print("####################################################################\n")
    print("At this point user should uncomment sleep command based on his needs, and start sending traffic")
    # time.sleep(10)

    if args.deinit:
        # Destroy UC Routes
        delete_next_hops_uc_route(handle, vrid, net_2_ip, onet_mask, ipv=4)
        delete_next_hops_uc_route(handle, vrid, net_1_ip, onet_mask, ipv=4)

        # Destroy external ECMP containers.
        destroy_ecmp_container(handle, ecmp_2_id)
        destroy_ecmp_container(handle, ecmp_1_id)
        destroy_ecmp_container(handle, ecmp_y_id)
        destroy_ecmp_container(handle, ecmp_x_id)

        delete_neigh(handle, port2_rif, next_hop1_ip)

        # Destroy rif
        delete_rif(handle, vrid, port2_rif)
        delete_rif(handle, vrid, port1_rif)

        delete_vrid(handle, vrid)

        # Deinit router
        router_deinit(handle)

        remove_ports_from_vlan(handle, vlan2, {PORT2: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, default_vlan, {PORT2: SX_UNTAGGED_MEMBER})

        remove_ports_from_vlan(handle, vlan1, {PORT1: SX_TAGGED_MEMBER})
        add_ports_to_vlan(handle, default_vlan, {PORT1: SX_UNTAGGED_MEMBER})

    sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
