#!/usr/bin/env python
'''
This file contains Python command example for the Span module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different Span attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_span_encap example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

VID = 10
SWITCH_PRIO = 2
DEI = 1
PCP = 3
TP = 1
REMOTE_DMAC = "00:04:05:06:07:0F"
REMOTE_L3_SMAC = "00:04:05:06:07:0A"
REMOTE_L3_SIP = "2.2.2.2"
REMOTE_L3_DIP = "2.2.2.3"
REMOTE_L3_TTL = 64
REMOTE_L3_ENCAP_LEN = 42

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

""" ############################################################################################ """
port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]
PORT_2 = port_list[1]
PORT_3 = port_list[2]

""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def span_init():
    """SPAN INIT"""
    print("--------------- SPAN INIT------------------------------")

    init_params_p = new_sx_span_init_params_t_p()
    init_params = sx_span_init_params_t()
    init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    print(("sx_api_span_init_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("version = %d " % (init_params.version)))
    delete_sx_span_init_params_t_p(init_params_p)


""" ############################################################################################ """


def span_session_create(span_session_param_p):
    """SPAN SESSION CREATE"""
    print("--------------- SPAN SESSION CREATE------------------------------")

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


""" ############################################################################################ """


def span_session_destroy(span_session_id_p, span_session_param_p):
    """SPAN SESSION DESTROY"""
    print("--------------- SPAN SESSION DESTROY------------------------------")

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] destroyed" % (span_session_id)))


""" ############################################################################################ """


def span_analyzer_set(cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- SPAN ANALYZER ADD ------------------------------")
    else:
        print("--------------- SPAN ANALYZER DELETE ------------------------------")
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    print(("sx_api_span_analyzer_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_set(cmd, mirror_port, mirror_direction, session_id):
    """ADD/DELETE SPAN MIRROR PORT """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD SPAN MIRROR PORT ------------------------------")
    else:
        print("--------------- DELETE SPAN MIRROR PORT  ------------------------------")
    rc = sx_api_span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id)
    print(("sx_api_span_mirror_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_session_state_set(session_id, admin_state):
    """SPAN SESSION STATE SET """
    print("--------------- SPAN SESSION STATE SET  ------------------------------")
    print(("Span session id =%d, admin state =%d" % (session_id, admin_state)))
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    print(("sx_api_span_session_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_deinit():
    """SPAN DEINIT"""
    print("--------------- SPAN DEINIT------------------------------")

    rc = sx_api_span_deinit_set(handle)
    print(("sx_api_span_deinit_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """
# Calculate truncate size form MTU
analyzer_port = PORT_1
ingress_port = PORT_2
egress_port = PORT_3

mtu_size = 1522
rc = sx_api_port_mtu_set(handle, analyzer_port, mtu_size)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
rc = sx_api_port_mtu_set(handle, ingress_port, mtu_size)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
rc = sx_api_port_mtu_set(handle, egress_port, mtu_size)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

# encapsulation length is variable for different encapsulation type and mirror header
truncate_size = mtu_size - REMOTE_L3_ENCAP_LEN

# init span
span_init()
# create a span session
span_session_param_p = new_sx_span_session_params_t_p()
span_session_param = sx_span_session_params_t()
span_session_param.span_type = SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1
span_session_param.span_type_format.remote_eth_l3_type1.qos_mode = SX_SPAN_QOS_CONFIGURED
span_session_param.span_type_format.remote_eth_l3_type1.switch_prio = SWITCH_PRIO
span_session_param.span_type_format.remote_eth_l3_type1.vid = VID
span_session_param.span_type_format.remote_eth_l3_type1.vlan_ethertype_id = 0
span_session_param.span_type_format.remote_eth_l3_type1.dei = DEI
span_session_param.span_type_format.remote_eth_l3_type1.pcp = PCP
span_session_param.span_type_format.remote_eth_l3_type1.tp = TP
span_session_param.span_type_format.remote_eth_l3_type1.mac = ether_addr(REMOTE_DMAC)
span_session_param.span_type_format.remote_eth_l3_type1.smac = ether_addr(REMOTE_L3_SMAC)
span_session_param.span_type_format.remote_eth_l3_type1.ttl = REMOTE_L3_TTL
span_session_param.span_type_format.remote_eth_l3_type1.src_ip = make_sx_ip_addr_v4(REMOTE_L3_SIP)
span_session_param.span_type_format.remote_eth_l3_type1.dest_ip = make_sx_ip_addr_v4(REMOTE_L3_DIP)
span_session_param.truncate = True
span_session_param.truncate_size = truncate_size
sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
span_session_id_p = span_session_create(span_session_param_p)
span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
print(("Span session id [%d] created" % (span_session_id)))

# add analyzer port to span session created above
port_params_p = new_sx_span_analyzer_port_params_t_p()
port_params = sx_span_analyzer_port_params_t()
port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
span_analyzer_set(SX_ACCESS_CMD_ADD, analyzer_port, port_params_p, span_session_id)

# enable SPAN session admin state
span_session_state_set(span_session_id, True)

# add span mirror port
span_mirror_set(SX_ACCESS_CMD_ADD, ingress_port, SX_SPAN_MIRROR_INGRESS, span_session_id)

# Send traffic with packet size = mtu_size to ingress_port

# packet encapsulated with remote L3 header and truncated by mtu_size will get in the analyzer_port

if args.deinit:
    # delete span mirror port
    span_mirror_set(SX_ACCESS_CMD_DELETE, ingress_port, SX_SPAN_MIRROR_INGRESS, span_session_id)

    # disable SPAN session admin state
    span_session_state_set(span_session_id, False)

    # delete analyzer port to span session created above
    span_analyzer_set(SX_ACCESS_CMD_DELETE, PORT_1, port_params_p, span_session_id)

    # destroy span session
    span_session_destroy(span_session_id_p, span_session_param_p)
    delete_sx_span_session_params_t_p(span_session_param_p)
    delete_sx_span_session_id_t_p(span_session_id_p)
    delete_sx_span_analyzer_port_params_t_p(port_params_p)

    # deinit span
    span_deinit()

sx_api_close(handle)
