#!/usr/bin/env python
"""
This file contains Python command example for the FLEX parser and FLEX tunnel.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
1. Init router
2. Create Ingres RIF of type VLAN
3. Create ACL rule to fwd packets to Router ingress RIF
   a. match on GRE
   b. action1: PBS
   c. action2: Set bridge with FID = VLAN of ingress RIF
4. Create Ingress RIF ACL decap rule
   a. match on GRE
   b. action1: decap
   c. action2: set metadata XXX
5. Create Ingress TPORT ACL rule
   a. match on metadata XXX
   b. action: set bridge to egress Bridge

"""
import sys
import socket
import struct
import errno
import random
import argparse
from optparse import OptionParser, Option

import test_infra_common
from python_sdk_api.sx_api import *
from test_infra_common import *

SPECTRUM_SWID = 0

IN_VLAN = 100
OUT_VLAN = 2
DEFAULT_VLAN = 1
VNI = 200

OUTER_DIP = "192.168.203.1"
OUTER_SIP = "192.168.202.1"

FLEX0_TPORT = SX_TUNNEL_PORT_ID_FLEX0
FLEX1_TPORT = SX_TUNNEL_PORT_ID_FLEX1


def region_create(handle, key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    delete_sx_acl_region_id_t_p(region_id_p)
    return region_id


def region_destroy(handle, region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))
    delete_sx_acl_region_id_t_p(region_id_p)


def key_create(handle, key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    delete_sx_acl_key_type_t_p(key_handle_p)
    delete_sx_acl_key_t_arr(key_arr)
    return key_handle


def key_destroy(handle, key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))
    delete_sx_acl_key_type_t_p(key_handle_p)
    delete_sx_acl_key_t_arr(key_arr)


def acl_create(handle, region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)
    return acl_id


def acl_destroy(handle, acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def pbs_rule_set(handle, region_id, cmd, vlan_id, pbs_id, counter_id):
    " This function creates flex acl PBS rule to fwd relevant traffic to router "
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 5, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_FPP_3_TOUCHED
    key_desc.key.fpp_touched = 1
    key_desc.mask.fpp_touched = 1

    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_PBS
    action1.fields.action_pbs.pbs_id = pbs_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)

    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_SET_BRIDGE
    action2.fields.action_set_bridge.bridge_id = vlan_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)

    action3 = sx_flex_acl_flex_action_t()
    action3.type = SX_FLEX_ACL_ACTION_COUNTER
    action3.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)

    rule.action_count = 3

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    print("Set PBS ACL rule rc: %d " % (rc))
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def decap_rule_set(handle, region_id, cmd, tunnel_id, counter_id):
    " This function creates flex acl DECAP rule to decap relevant traffic"
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 5, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_IP_PROTO
    key_desc.key.ip_proto = 0x2f  # GRE
    key_desc.mask.ip_proto = 0xff

    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action0 = sx_flex_acl_flex_action_t()
    action0.type = SX_FLEX_ACL_ACTION_TUNNEL_DECAP
    action0.fields.action_tunnel_decap.tunnel_id = tunnel_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action0)

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_COUNTER
    action1.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action1)

    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_SET_USER_TOKEN
    action2.fields.action_set_user_token.user_token = 123
    action2.fields.action_set_user_token.mask = 0xff
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action2)

    rule.action_count = 3

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    print("Set ACL rule rc: %d " % (rc))
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def tport_rule_set(handle, region_id, cmd, out_vlan_id, counter_id):
    " This function creates flex acl rule to assign egress Bridge to decapsulated traffic"
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 5, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_USER_TOKEN
    key_desc.key.user_token = 123
    key_desc.mask.user_token = 0xFF

    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action0 = sx_flex_acl_flex_action_t()
    action0.type = SX_FLEX_ACL_ACTION_SET_BRIDGE
    action0.fields.action_set_bridge.bridge_id = out_vlan_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action0)

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_COUNTER
    action1.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action1)

    rule.action_count = 2

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    print("Set ACL rule rc: %d " % (rc))
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def tunnel_init(handle):
    params = new_sx_tunnel_general_params_t_p()
    params.nve.encap_sport = 0
    params.nve.encap_flowlabel = 0
    params.nve.flood_ecmp_enabled = False

    rc = sx_api_tunnel_init_set(handle, params)
    if rc:
        print("ERROR: SDK API sx_api_tunnel_init_set failed: rc:%d" % (rc))
        sys.exit(1)

    delete_sx_tunnel_general_params_t_p(params)


def tunnel_deinit(handle):
    rc = sx_api_tunnel_deinit_set(handle)
    if rc:
        print("ERROR: SDK API sx_api_tunnel_deinit_set failed: rc:%d" % (rc))
        sys.exit(1)


def router_init(handle):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def router_deinit(handle):
    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED, "Failed to deinit the router"

    print("Deinit the router, rc: %d" % (rc))


def make_sx_ip_addr_v4(addr):
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def create_vrid(handle):
    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created vrid: %d, rc: %d " % (vrid, rc))
    return vrid


def delete_vrid(handle, vrid):
    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print("Deleted VRID: %d, rc: %d " % (vrid, rc))
    delete_sx_router_id_t_p(vrid_p)


def bridge_vport_create(handle, port, vlan, tag_mode=SX_UNTAGGED_MEMBER):
    add_ports_to_vlan(vlan, {port: tag_mode})

    log_vport_p = new_sx_port_log_id_t_p()
    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_ADD, port, vlan, log_vport_p)
    log_vport = sx_port_log_id_t_p_value(log_vport_p)
    print("virtual port 0x%x created, rc: %d" % (log_vport, rc))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print("bridge %d created, rc: %d" % (bridge_id, rc))

    # add log_vport to bridge
    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    print("virtual port 0x%x added to bridge %d, rc: %d" % (log_vport, bridge_id, rc))

    # set port state to UP
    rc = sx_api_port_state_set(handle, log_vport, SX_PORT_ADMIN_STATUS_UP)
    print("Set virtual port 0x%x state to UP, rc: %d" % (log_vport, rc))

    delete_sx_port_log_id_t_p(log_vport_p)
    delete_sx_bridge_id_t_p(bridge_id_p)

    return (bridge_id, log_vport)


def bridge_vport_delete(handle, port, vlan, bridge_id, log_vport, tag_mode):

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    bridge_id_p = new_sx_bridge_id_t_p()
    sx_bridge_id_t_p_assign(bridge_id_p, bridge_id)

    # set port state to DOWN
    rc = sx_api_port_state_set(handle, log_vport, SX_PORT_ADMIN_STATUS_DOWN)
    print("Set virtual port 0x%x state to DOWN, rc: %d" % (log_vport, rc))

    # delete log_vport from bridge
    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    print("virtual port 0x%x remove from bridge %d, rc: %d " % (log_vport, bridge_id, rc))

    # delete bridge
    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
    print("bridge %d deleted, rc: %d" % (bridge_id, rc))

    # delete vport
    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_DELETE, port, vlan, log_vport_p)
    print("virtual port 0x%x deleted, rc: %d" % (log_vport, rc))

    remove_ports_from_vlan(vlan, {port: tag_mode})

    delete_sx_port_log_id_t_p(log_vport_p)
    delete_sx_bridge_id_t_p(bridge_id_p)


def flex_parser_init(handle):
    # init flex parser module
    parser_params_p = new_sx_flex_parser_param_t_p()
    rc = sx_api_flex_parser_init_set(handle, parser_params_p)
    if rc:
        print("sx_api_flex_parser_init_set failed with rc %d" % (rc))
        sys.exit(1)
    delete_sx_flex_parser_param_t_p(parser_params_p)

    # arbitrary picking FPP3
    fpp = SX_FLEX_PARSER_HEADER_FPP3

    # Create a regular FPH
    fpp_id_p = new_sx_flex_parser_fpp_id_t_p()
    fpp_cfg_p = new_sx_flex_parser_fpp_t_p()
    fpp_id_p.fpp_id = fpp
    fpp_cfg_p.type = SX_FLEX_PARSER_FPP_TYPE_FPH
    rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_CREATE, fpp_id_p, fpp_cfg_p)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_fpp_set failed on create. rc:%d" % (rc))
        sys.exit(1)

    # Set a regular FPH for ERSPANv2
    fpp_cfg_p.hdr_len_field.constant = 8
    fpp_cfg_p.protocol_field.offset = 0
    fpp_cfg_p.protocol_field.size = 0
    fpp_cfg_p.protocol_field.mask = 0
    rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_SET, fpp_id_p, fpp_cfg_p)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_fpp_set failed on set. rc:%d" % (rc))
        sys.exit(1)

    # Set the transition from GRE to our FPH (ERSPANv2)
    parser_header = sx_flex_parser_header_t()
    transition_cfg = sx_flex_parser_transition_t()
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    parser_header.hdr_data.parser_hdr_fpp = SX_FLEX_PARSER_HEADER_GRE_E
    transition_cfg.transition_value = 0x88be
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fpp = fpp
    rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, parser_header, transition_cfg)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. rc:%d" % (rc))
        sys.exit(1)

    # Set the transition from FPH to next MAC header and define the start of inner packet
    # from the beginning of MAC header
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
    parser_header.hdr_data.parser_hdr_fpp = SX_FLEX_PARSER_HEADER_FPP3
    transition_cfg.encap_level = SX_FLEX_PARSER_ENCAP_INNER_E
    transition_cfg.transition_value = 0
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_MAC_E
    rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_SET, parser_header, transition_cfg)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. rc:%d" % (rc))
        sys.exit(1)

    delete_sx_flex_parser_fpp_id_t_p(fpp_id_p)
    delete_sx_flex_parser_fpp_t_p(fpp_cfg_p)


def flex_parser_deinit(handle):
    parser_header = sx_flex_parser_header_t()
    transition_cfg = sx_flex_parser_transition_t()

    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
    parser_header.hdr_data.parser_hdr_fpp = SX_FLEX_PARSER_HEADER_FPP3
    transition_cfg.transition_value = 0
    rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_transition_set failed on unset. rc:%d" % (rc))
        sys.exit(1)

    fpp = SX_FLEX_PARSER_HEADER_FPP3
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_GRE_E
    transition_cfg.transition_value = 0x88be
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fpp = fpp
    rc = sx_api_flex_parser_transition_set(handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_transition_set failed on unset. rc:%d" % (rc))
        sys.exit(1)

        # Destroy a regular FPH
    fpp_id_p = new_sx_flex_parser_fpp_id_t_p()
    fpp_cfg_p = new_sx_flex_parser_fpp_t_p()
    fpp_id_p.fpp_id = fpp
    rc = sx_api_flex_parser_fpp_set(handle, SX_ACCESS_CMD_DESTROY, fpp_id_p, fpp_cfg_p)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_fpp_set failed on destroy. rc:%d" % (rc))
        sys.exit(1)

    rc = sx_api_flex_parser_deinit_set(handle)
    if rc:
        print("ERROR: SDK API sx_api_flex_parser_deinit_set failed. rc:%d" % (rc))
        sys.exit(1)

    delete_sx_flex_parser_fpp_id_t_p(fpp_id_p)
    delete_sx_flex_parser_fpp_t_p(fpp_cfg_p)


def tunnel_create(handle, tunnel_type):
    tunnel_attribute = sx_tunnel_attribute_t()
    tunnel_attribute.type = tunnel_type
    tunnel_attribute.direction = SX_TUNNEL_DIRECTION_DECAP
    tunnel_attribute.attributes.vxlan.nve_log_port = 0x80010000
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    tunnel_id_p = new_sx_tunnel_id_t_p()

    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute_p, tunnel_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    print("Created tunnel %d, rc: %d " % (tunnel_id, rc))

    delete_tunnel_attribute_t_p(tunnel_attribute_p)
    delete_sx_tunnel_id_t_p(tunnel_id_p)

    return tunnel_id


def tunnel_destroy(handle, tunnel_id):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    print("Destroyed tunnel %d, rc: %d " % (tunnel_id, rc))
    delete_sx_tunnel_id_t_p(tunnel_id_p)


def create_loopback_rif(handle, vrid):

    ifc_param = new_sx_router_interface_param_t_p()
    ifc_attr = new_sx_interface_attributes_t_p()

    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK
    LOOPBACK_ETHER_ADDR = ether_addr(0x00, 0x99, 0x99, 0x99, 0x99, 0x99)
    ifc_attr.mac_addr = LOOPBACK_ETHER_ADDR
    ifc_attr.mtu = 1500
    ifc_attr.loopback_enable = False

    rif_id_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_id_p)
    if rc:
        print("ERROR: SDK API sx_api_router_interface_set ADD failed: rc:%d " % (rc))
        sys.exit(1)
    rif_id = sx_router_interface_t_p_value(rif_id_p)
    print("Created loopback rif_id: %d, rc: %d " % (rif_id, rc))

    delete_sx_router_interface_param_t_p(ifc_param)
    delete_sx_interface_attributes_t_p(ifc_attr)

    return rif_id


def destroy_loopback_rif(handle, vrid, rif_id):
    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif_id)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    if rc:
        printf("ERROR: SDK API sx_api_router_interface_set DELETE failed: rc:%d" % (rc))
        sys.exit(1)
    delete_sx_router_interface_t_p(rif_p)


def flex_tunnel_create(handle, vrid, tunnel_log_port):

    # The loopback rif is the entry point to the router that will be used for the underlay
    #loopback_rif_id, rif_counter_id = create_loopback_rif(handle, vrid)
    loopback_rif_id = create_loopback_rif(handle, vrid)

    # Create the flex tunnel
    tunnel_attr = new_sx_tunnel_attribute_t_p()
    tunnel_attr.type = SX_TUNNEL_TYPE_L2_FLEX
    tunnel_attr.direction = SX_TUNNEL_DIRECTION_DECAP
    tunnel_attr.attributes.l2_flex.log_port = tunnel_log_port  # FLEX1_PORT
    tunnel_attr.attributes.l2_flex.tunnel_qos_profile.profile_id = SX_COS_TQ_PROFILE_ID_3_E  # Profiles 2 & 3 are configured by default
    tunnel_attr.attributes.l2_flex.decap.ethertype = 0x8100
    tunnel_attr.attributes.l2_flex.decap.underlay_rif = loopback_rif_id
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attr, tunnel_id_p)
    if rc:
        print("ERROR: sx_api_tunnel_set CREATE failed. rc:%d" % (rc))
        sys.exit(1)
    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)

    #  Enable the loopback rif - must be done after tunnel enable
    rif_state = new_sx_router_interface_state_t_p()
    rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    rif_state.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    rc = sx_api_router_interface_state_set(handle, loopback_rif_id, rif_state)
    if rc:
        print("ERROR: SDK API sx_api_router_interface_state_set failed: rc:%d" % (rc))
        sys.exit(1)

    delete_sx_tunnel_attribute_t_p(tunnel_attr)
    delete_sx_tunnel_id_t_p(tunnel_id_p)
    delete_sx_router_interface_state_t_p(rif_state)

    return tunnel_id, loopback_rif_id


def flex_tunnel_destroy(handle, tunnel_id, vrid, rif_id):
    # Destroy the flex tunnel we've created
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, None, tunnel_id_p)
    if rc:
        print("ERROR: sx_api_tunnel_set DESTROY failed. rc:%d" % (rc))
        sys.exit(1)
    delete_sx_tunnel_id_t_p(tunnel_id_p)
    destroy_loopback_rif(handle, vrid, rif_id)


def allocate_vlan_port_list(ports_dict):
    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)

    return port_list


def add_ports_to_vlan(handle, vlan_id, ports_dict):
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(ports_dict.keys()), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(handle, vlan_id, ports_dict):
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(ports_dict.keys()), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


def create_flow_counter(handle, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"
    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    delete_sx_flow_counter_id_t_p(counter_p)
    return counter_id


def counter_destroy(handle, counter_id):
    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)
    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, SX_FLOW_COUNTER_TYPE_PACKETS, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete flow counter"
    print("Deleted flow counter %d, rc: %d" % (counter_id, rc))
    delete_sx_flow_counter_id_t_p(counter_p)


def bridge_tunnel_decap_counter(handle, tunnel_id, bridge_id, counter_id, command):
    attr = sx_bridge_tunnel_counter_attr_t()
    attr.type = SX_BRIDGE_COUNTER_TUNNEL_DECAP_E
    attr.tunnel_id = tunnel_id

    attr_p = new_sx_bridge_tunnel_counter_attr_t_p()
    sx_bridge_tunnel_counter_attr_t_p_assign(attr_p, attr)

    # bind counter
    rc = sx_api_bridge_tunnel_counter_bind_set(handle, command, bridge_id, attr_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind tunnel bridge counter, rc: %d" % (rc)
    print("Bind/unbind tunnel %d bridge %d decap counter %d, rc: %d" % (tunnel_id, bridge_id, counter_id, rc))

    deletew_sx_bridge_tunnel_counter_attr_t_p(attr_p)


def create_rif(handle, vrid, port, vlan, tag):
    rif = create_vlan_rif(handle, vrid, vlan, ether_addr(0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
    set_rif_state_ipv4(handle, rif)
    return rif


def delete_rif(handle, port, vlan, vrid, rif, tag):
    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print("Deleted RIF: %d, rc: %d " % (rif, rc))

    delete_sx_router_interface_t_p(rif_p)


def set_rif_state_ipv4(handle, rif, enable=True):
    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = enable
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    print("Set rif %d state %d, rc: %d " % (rif, enable, rc))
    return rc


def create_vlan_rif(handle, vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    delete_sx_router_interface_t_p(rif_p)

    return rif


def add_pvid_to_port(handle, vlan_id, port):
    rc = sx_api_vlan_port_pvid_set(handle, SX_ACCESS_CMD_ADD, port, vlan_id)
    print("Set pvid %d for port 0x%x rc %d " % (vlan_id, port, rc))


def pbs_create(handle):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    pbs_entry = sx_acl_pbs_entry_t()
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_ROUTING
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_ADD,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create pbs, rc = %d" % (rc)
    print("Created pbs: %d, rc: %d " % (sx_acl_pbs_id_t_p_value(pbs_id_p), rc))

    pbs_id = sx_acl_pbs_id_t_p_value(pbs_id_p)
    delete_sx_acl_pbs_id_t_p(pbs_id_p)
    return pbs_id


def pbs_delete(handle, pbs_id):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    sx_acl_pbs_id_t_p_assign(pbs_id_p, pbs_id)
    pbs_entry = sx_acl_pbs_entry_t()
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_DELETE,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete pbs %d, rc = %d" % (pbs_id, rc)
    print("Deleted pbs: %d, rc: %d " % (pbs_id, rc))
    delete_sx_acl_pbs_id_t_p(pbs_id_p)


def create_ingress_acl_pbs_rule(handle, port, vlan_id):
    key_handle = key_create(handle, FLEX_ACL_KEY_FPP_3_TOUCHED)
    region_id = region_create(handle, key_handle, 10)
    acl_id = acl_create(handle, region_id, SX_ACL_DIRECTION_INGRESS)
    pbs_id = pbs_create(handle)
    counter_id = create_flow_counter(handle)
    pbs_rule_set(handle, region_id, SX_ACCESS_CMD_SET, vlan_id, pbs_id, counter_id)
    rc = sx_api_acl_port_bind_set(handle, SX_ACCESS_CMD_BIND, port, acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
    print("Created PBS acl rule: %d, vlan:%d , rc: %d " % (acl_id, vlan_id, rc))
    return key_handle, region_id, acl_id, counter_id, pbs_id


def create_decap_acl_rules(handle, port, tunnel_id, rif_id):
    key_handle = key_create(handle, FLEX_ACL_KEY_IP_PROTO)
    region_id = region_create(handle, key_handle, 10)
    acl_id = acl_create(handle, region_id, SX_ACL_DIRECTION_RIF_INGRESS)
    counter_id = create_flow_counter(handle)
    decap_rule_set(handle, region_id, SX_ACCESS_CMD_SET, tunnel_id, counter_id)
    rc = sx_api_acl_rif_bind_set(handle, SX_ACCESS_CMD_BIND, rif_id, acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_rif_bind_set failed, rc = %d" % (rc)
    print("Created DECAP acl rule: %d, rc: %d " % (acl_id, rc))
    return key_handle, region_id, acl_id, counter_id


def create_tport_acl_rules(handle, port, tport, out_vlan_id):
    key_handle = key_create(handle, FLEX_ACL_KEY_USER_TOKEN)
    region_id = region_create(handle, key_handle, 10)
    acl_id = acl_create(handle, region_id, SX_ACL_DIRECTION_TPORT_INGRESS)
    counter_id = create_flow_counter(handle)
    tport_rule_set(handle, region_id, SX_ACCESS_CMD_SET, out_vlan_id, counter_id)
    # bind acl to tport
    rc = sx_api_acl_port_bind_set(handle, SX_ACCESS_CMD_BIND, tport, acl_id)
    print("Created TPORT acl rule: %d, rc: %d " % (acl_id, rc))
    return key_handle, region_id, acl_id, counter_id


def delete_ingress_acl_pbs_rules(handle, port, counter_id, acl_id, region_id, key_handle, pbs_id):
    rc = sx_api_acl_port_bind_set(handle, SX_ACCESS_CMD_UNBIND, port, acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
    pbs_rule_set(handle, region_id, SX_ACCESS_CMD_DELETE, 0, pbs_id, 0)
    acl_destroy(handle, acl_id, region_id)
    region_destroy(handle, region_id)
    key_destroy(handle, key_handle)
    counter_destroy(handle, counter_id)
    pbs_delete(handle, pbs_id)


def delete_decap_acl_rules(handle, rif_id, counter_id, acl_id, region_id, key_handle):
    rc = sx_api_acl_rif_bind_set(handle, SX_ACCESS_CMD_UNBIND, rif_id, acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
    decap_rule_set(handle, region_id, SX_ACCESS_CMD_DELETE, 0, 0)
    acl_destroy(handle, acl_id, region_id)
    region_destroy(handle, region_id)
    key_destroy(handle, key_handle)
    counter_destroy(handle, counter_id)


def delete_tport_acl_rules(handle, port, counter_id, acl_id, region_id, key_handle):
    rc = sx_api_acl_port_bind_set(handle, SX_ACCESS_CMD_UNBIND, port, acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
    tport_rule_set(handle, region_id, SX_ACCESS_CMD_DELETE, 0, 0)
    acl_destroy(handle, acl_id, region_id)
    region_destroy(handle, region_id)
    key_destroy(handle, key_handle)
    counter_destroy(handle, counter_id)


def init_parser():
    '''
    @summary: init parser
    '''
    usage = "usage: %prog [options] arg, example for ERSPANv2 decap by flex tunnel.\n"
    usage += "example: %prog --deinit"

    parser = OptionParser(usage=usage)

    parser.add_option('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    (options, args) = parser.parse_args()

    return options


def main():

    print(" ")
    args = init_parser()
    print(" ")

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    port_list = mapPortAndInterfaces(handle)
    IN_PORT = port_list[0]
    OUT_PORT = port_list[1]
    print("IN_PORT:0x%x, OUT_PORT:0x%x" % (IN_PORT, OUT_PORT))

    # Validate chip type for examples not supported on specific chip types
    chip_type = test_infra_common.get_chip_type(handle)
    if (chip_type == SX_CHIP_TYPE_SPECTRUM or chip_type == SX_CHIP_TYPE_SPECTRUM_A1):
        print("Exit. This system is Spectrum. This example supported on Spectrum2 and above.")
        sys.exit(0)

    print("Init Setup:")

    router_init(handle)
    tunnel_init(handle)
    flex_parser_init(handle)

    add_ports_to_vlan(handle, OUT_VLAN, {OUT_PORT: SX_UNTAGGED_MEMBER})
    add_pvid_to_port(handle, IN_VLAN, IN_PORT)
    add_ports_to_vlan(handle, IN_VLAN, {IN_PORT: SX_UNTAGGED_MEMBER})

    # create underlay vrid
    vrid = create_vrid(handle)

    # create rif
    rif = create_rif(handle, vrid, IN_PORT, IN_VLAN, SX_UNTAGGED_MEMBER)

    # flex tunnel create
    tunnel_id, loopback_rif_id = flex_tunnel_create(handle, vrid, FLEX1_TPORT)

    # set acl rules
    pbs_key_handle, pbs_region_id, pbs_acl_id, pbs_counter_id, pbs_id = create_ingress_acl_pbs_rule(handle, IN_PORT, IN_VLAN)
    key_handle, region_id, acl_id, counter_id = create_decap_acl_rules(handle, IN_PORT, tunnel_id, rif)
    tport_key_handle, tport_region_id, tport_acl_id, tport_counter_id = create_tport_acl_rules(handle, IN_PORT, FLEX1_TPORT, OUT_VLAN)

    if args.deinit:
        print("Deinit Setup:")
        # delete acl rules
        delete_tport_acl_rules(handle, FLEX1_TPORT, tport_counter_id, tport_acl_id, tport_region_id, tport_key_handle)
        delete_decap_acl_rules(handle, rif, counter_id, acl_id, region_id, key_handle)
        delete_ingress_acl_pbs_rules(handle, IN_PORT, pbs_counter_id, pbs_acl_id, pbs_region_id, pbs_key_handle, pbs_id)

        # tunnel destroy
        flex_tunnel_destroy(handle, tunnel_id, vrid, loopback_rif_id)

        # delete rif
        delete_rif(handle, IN_PORT, IN_VLAN, vrid, rif, SX_UNTAGGED_MEMBER)

        # delete vrid
        delete_vrid(handle, vrid)

        add_pvid_to_port(handle, DEFAULT_VLAN, IN_PORT)
        remove_ports_from_vlan(handle, IN_VLAN, {IN_PORT: SX_UNTAGGED_MEMBER})
        remove_ports_from_vlan(handle, OUT_VLAN, {OUT_PORT: SX_UNTAGGED_MEMBER})

        flex_parser_deinit(handle)
        tunnel_deinit(handle)
        router_deinit(handle)


if __name__ == "__main__":
    main()
    print(" ")
