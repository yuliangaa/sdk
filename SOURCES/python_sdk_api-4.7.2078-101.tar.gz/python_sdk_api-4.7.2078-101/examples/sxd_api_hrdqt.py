#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev

EMAD_RDQ_INDEX = 33


def parse_args():
    parser = argparse.ArgumentParser(description='HRDQT Set/Get example.')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--rdq', default=0, type=int, help="RDQ Index.")
    parser.add_argument('--tac_en', default=0, type=int, help="Enadle/Disable Telemetry Aggregated Cache (TAC).")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    return args.cmd, args.rdq, args.tac_en, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute Set/Get request for the HRDQT EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--rdq <rdq>] [--tac_en <tac_en>]")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. Get by default.")
    print("rdq: RDQ Index to use. 0 by default. Note that RDQ %d is reserved by SDK for EMAD flow and can't be used at this example" % (EMAD_RDQ_INDEX))
    print("tac_en: enable (1) or disable (0). Disable by default.")
    print("")


def validate_input_parameters(cmd, rdq_idx, tac_en):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)

    if tac_en != 0 and tac_en != 1:
        print("Invalid input parameter: tac_en.")
        help_cmd()
        sys.exit(0)

    if rdq_idx == EMAD_RDQ_INDEX:
        print(("Invalid input parameter: rdq. %s rdq is used for EMAD handling." % (EMAD_RDQ_INDEX)))
        help_cmd()
        sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, rdq_idx, tac_en, deinit):

    reg_data = ku_hrdqt_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    reg_data.rdq = rdq_idx
    reg_data.tac_en = tac_en

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get HRDQT")
        print("[+] RDQ Index: ", reg_data.rdq)
    else:
        print("[+] Set HRDQT")
        print("[+] RDQ Index: ", reg_data.rdq)
        print("[+] tac_en: ", reg_data.tac_en)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        # Save data for later de-configuration
        original_reg_data = ku_hrdqt_reg()
        original_reg_data.rdq = rdq_idx
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_hrdqt(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_hrdqt failed")
            sys.exit(rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_hrdqt(reg_data, meta, 1, None, None)
    print("[+] rc: ", rc)
    print("====================")
    if rc == SXD_STATUS_SUCCESS and meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] RDQ Index: ", reg_data.rdq)
        print("[+] tac_en: ", reg_data.tac_en)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        print("Deinit")
        rc = sxd_access_reg_hrdqt(original_reg_data, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_hrdqt failed")
            sys.exit(rc)


def main():
    cmd, rdq_idx, tac_en, deinit = parse_args()

    validate_input_parameters(cmd, rdq_idx, tac_en)

    sxd_init()

    chip_type, _ = get_chip_type_and_rev()
    if chip_type != SXD_MGIR_HW_DEV_ID_SPECTRUM4 and chip_type != SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        print("[+] HRDQT register is not supported by the chip.")
    else:
        run_example(cmd, rdq_idx, tac_en, deinit)

    print("[+] HRDQT register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] HRDQT register access example")
    main()
