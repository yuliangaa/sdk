#!/usr/bin/env python
'''
This file contains Python command example for the trap group iterator get function.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import time
import traceback
import argparse
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_group_iter_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

from python_sdk_api.sx_api import *
print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
TEST_SUCCESS = 0
TEST_FAILED = 1

######################################################
#    main
######################################################


def main():

    try:
        ret_code = TEST_SUCCESS
        key_list = []
        MAX_KEY_NUM = 0

        trap_attr_p = new_sx_trap_group_attributes_t_p()
        trap_attr = sx_trap_group_attributes_t()
        trap_attr.prio = 2
        trap_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
        trap_attr.truncate_size = 0
        trap_attr.control_type = SX_CONTROL_TYPE_DEFAULT
        trap_attr.is_monitor = False

        trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
        # Create some trap group IDs.
        for i in range(0, 5):
            trap_attr.trap_group = i
            sx_trap_group_attributes_t_p_assign(trap_attr_p, trap_attr)
            rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, 0, i, trap_attr_p)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_host_ifc_trap_group_ext_set failed, rc=%d" % rc)
            key_list.append(sx_trap_group_attributes_t_p_value(trap_attr_p).trap_group)
            MAX_KEY_NUM = MAX_KEY_NUM + 1

        key_list.sort()
        num_keys = len(key_list)
        print("Created trap group ID list: (%d keys)" % num_keys)
        for x in key_list:
            print("trap group ID: %d" % x)

        print("--------------------------------GET---------------------------------------------------------------------------")

        key_cnt_p = new_uint32_t_p()
        key_list_p = new_sx_trap_group_t_arr(MAX_KEY_NUM)
        # Use GET to get all elements in the list
        key_get_list = []
        for key in key_list:
            uint32_t_p_assign(key_cnt_p, 1)
            print("GET    trap group ID: %d, key_cnt: %d" % (key, 1))
            rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GET, 0, key, None, key_list_p, key_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d" % rc)

            key_cnt = uint32_t_p_value(key_cnt_p)
            assert key_cnt == 1, "Returned key count is not 1"

            key_get = sx_trap_group_t_arr_getitem(key_list_p, 0)
            print("Return trap group ID: %d, key_cnt: %d" % (key_get, key_cnt))

        print("--------------------------------COUNT---------------------------------------------------------------------------")

        # Get Count
        uint32_t_p_assign(key_cnt_p, 0)

        rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GET, 0, 0, None, None, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        assert key_cnt == num_keys, "Count failed, expected %d, got %d" % (num_keys, key_cnt)
        print("Count successful, expected %d, got %d" % (num_keys, key_cnt))

        print("--------------------------------GET_FIRST---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        print("GET FIRST, requested count = %d, total count = %d" % (num_get, num_keys))
        rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, 0, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)

        print("GET FIRST, returned count = %d" % key_cnt)
        for i in range(0, key_cnt):
            key_get = sx_trap_group_t_arr_getitem(key_list_p, i)
            key = key_list[i]
            assert key == key_get, "The content returned by GET FIRST is incorrect"
            print("trap group ID: %d" % (key_get))

        print("--------------------------------GET_NEXT---------------------------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        key = key_list[index]
        print("GET NEXT %d keys after %dth key (trap group ID: %d), total count = %d" % (num_get, index + 1, key, num_keys))
        rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, key, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after %dth key (trap group ID: %d), returned %d keys" % (num_get, index + 1, key, key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_trap_group_t_arr_getitem(key_list_p, i)
            key = key_list[index + i + 1]
            assert key_get == key, "The content returned by GET NEXT is incorrect"
            print("trap group ID: %d" % (key_get))

        print("--------------------------------GET_NEXT with a non-existent key------------------------------------------------------")

        num_get = MAX_KEY_NUM // 2
        uint32_t_p_assign(key_cnt_p, num_get)
        index = 0
        rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GETNEXT, 0, SX_TRAP_GROUP_MAX + 1, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d" % rc)
        key_cnt = uint32_t_p_value(key_cnt_p)
        print("GET NEXT %d keys after key (trap group ID: %d), returned %d keys" % (num_get, SX_TRAP_GROUP_MAX + 1, key_cnt))
        for i in range(0, key_cnt):
            key_get = sx_trap_group_t_arr_getitem(key_list_p, i)
            key = key_list[index + i + 1]
            assert key_get == key, "The content returned by GET NEXT is incorrect"
            print("trap group ID: %d" % (key_get))

        # Corner cases

        # Call GET with count > 1
        case = "Test case: Call GET with count > 1"
        print(case)
        key_cnt = MAX_KEY_NUM // 2
        if key_cnt < 2:
            key_cnt = 2
        uint32_t_p_assign(key_cnt_p, key_cnt)
        index = 0
        key = key_list[index]
        rc = sx_api_host_ifc_trap_group_iter_get(handle, SX_ACCESS_CMD_GET, 0, key, None, key_list_p, key_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            raise Exception("sx_api_host_ifc_trap_group_iter_get failed, rc=%d in case %s" % (rc, case))
        key_cnt = uint32_t_p_value(key_cnt_p)
        assert key_cnt <= 1, "Data count not 0 or 1 as expected  in case %s" % (case)
        print(case + " passed\n")

        if args.deinit:
            for trap_group in key_list:
                sx_trap_group_attributes_t_p_assign(trap_attr_p, trap_attr)
                rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, 0, trap_group, trap_attr_p)
                if rc != SX_STATUS_SUCCESS:
                    raise Exception("sx_api_host_ifc_trap_group_ext_set failed [trap_group=%d, rc=%d]" % (trap_group, rc))

    except Exception as err:
        ret_code += TEST_FAILED
        print('Exception of type %s occurred:\n%s' % (str(type(err)), str(err)))
        traceback.print_exc()

    finally:
        if ret_code:
            print("Test failed: Return code = %d" % ret_code)
        else:
            print("All tests passed")
        sys.exit(ret_code)


if __name__ == "__main__":
    main()

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
