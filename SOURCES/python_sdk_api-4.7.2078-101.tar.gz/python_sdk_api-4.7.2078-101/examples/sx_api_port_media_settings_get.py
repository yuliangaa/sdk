#!/usr/bin/env python
"""
This example gets the port media settings using sx_api_port_media_settings_get API.
This example return media setting for all port available lanes).
If no ports will be provided - example will use default port 0x10001.
"""

import os
import sys
from python_sdk_api.sx_api import *
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    description_str = """
    This example gets the port media settings using sx_api_port_media_settings_get API.
    This example return media setting for all port available lanes).
    If no ports will be provided - example will use default port 0x10001.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument('--ports', type=test_infra_common.auto_int, default=[0x10001], nargs='+',
                        help='Logical ports to dump media settings. Expected in decimal/hex format, for example:'
                        '--ports 65585 0x10001 ')
    return parser.parse_args()


def main():
    args = parse_args()     # Parse given arguments

    # Open Handle
    print("[+] Opening SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate module managment init parameter for examples - not supported when not independent module / standalone
        sx_api_sx_sdk_init_p = new_sx_api_sx_sdk_init_t_p()
        rc = sx_api_sdk_init_params_get(handle, sx_api_sx_sdk_init_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to get sdk init params.\n")
            sys.exit(rc)
        sdk_init_attr = sx_api_sx_sdk_init_t_p_value(sx_api_sx_sdk_init_p)
        if (sdk_init_attr.mgmt_params.support_type != SX_MGMT_MODULE_SUPPORT_INDEPENDENT_E and sdk_init_attr.mgmt_params.support_type != SX_MGMT_MODULE_SUPPORT_STANDALONE_E):
            print("This example is supported only when SDK init with independent module / standalone support - Exiting gracefully")
            sys.exit(0)

        for log_port in args.ports:
            print("Media settings configured for port 0x{:x}".format(log_port))
            media_settings = sx_port_media_settings_t()
            media_settings.lane_cnt = 0
            media_settings_p = copy_sx_port_media_settings_t_p(media_settings)
            rc = sx_api_port_media_settings_get(handle, SX_ACCESS_CMD_GET, log_port, media_settings_p)
            if rc != SX_STATUS_SUCCESS:
                print("Failed to get port 0x{:x} media settings, rc = {}".format(log_port, test_infra_common.sx_status_dict[rc]))
                sys.exit(rc)
            # print_media_settings
            media_settings_dump = sx_port_media_settings_t_p_value(media_settings_p)
            lane_id_str = "Lane ID          "
            idriver_str = "idriver          "
            tx_fir_pre1_str = "tx_fir_pre1      "
            tx_fir_pre2_str = "tx_fir_pre2      "
            tx_fir_pre3_str = "tx_fir_pre3      "
            tx_fir_main_str = "tx_fir_main      "
            tx_fir_post1_str = "tx_fir_post1     "
            tx_pam4_ratio_str = "tx_pam4_ratio    "
            tx_out_cmmn_mod_str = "tx_out_cmmn_mod  "
            tx_pmos_cmmn_mod_str = "tx_pmos_cmmn_mod "
            tx_nmos_cmmn_mod = "tx_nmos_cmmn_mod "
            tx_pmos_vltg_reg_str = "tx_pmos_vltg_reg "
            tx_nmos_vltg_str = "tx_nmos_vltg_reg "
            for index in range(media_settings_dump.lane_cnt):
                lane_id = uint8_t_arr_getitem(media_settings_dump.lane_id, index)
                settings = sx_port_lane_media_settings_t_arr_getitem(media_settings_dump.media_settings, index)
                lane_id_str += "| {:4} ".format(lane_id)
                idriver_str += "| {:4} ".format(settings.idriver)
                tx_fir_pre1_str += "| {:4} ".format(settings.tx_fir_pre1)
                tx_fir_pre2_str += "| {:4} ".format(settings.tx_fir_pre2)
                tx_fir_pre3_str += "| {:4} ".format(settings.tx_fir_pre3)
                tx_fir_main_str += "| {:4} ".format(settings.tx_fir_main)
                tx_fir_post1_str += "| {:4} ".format(settings.tx_fir_post1)
                tx_pam4_ratio_str += "| {:4} ".format(settings.tx_pam4_ratio)
                tx_out_cmmn_mod_str += "| {:4} ".format(settings.tx_out_cmmn_mod)
                tx_pmos_cmmn_mod_str += "| {:4} ".format(settings.tx_pmos_cmmn_mod)
                tx_nmos_cmmn_mod += "| {:4} ".format(settings.tx_nmos_cmmn_mod)
                tx_pmos_vltg_reg_str += "| {:4} ".format(settings.tx_pmos_vltg_reg)
                tx_nmos_vltg_str += "| {:4} ".format(settings.tx_nmos_vltg_reg)

            print("=" * len(lane_id_str))
            print(lane_id_str)
            print("-" * len(lane_id_str))
            print(idriver_str)
            print(tx_fir_pre1_str)
            print(tx_fir_pre2_str)
            print(tx_fir_pre3_str)
            print(tx_fir_main_str)
            print(tx_fir_post1_str)
            print(tx_pam4_ratio_str)
            print(tx_out_cmmn_mod_str)
            print(tx_pmos_cmmn_mod_str)
            print(tx_nmos_cmmn_mod)
            print(tx_pmos_vltg_reg_str)
            print(tx_nmos_vltg_str)
            print("=" * len(lane_id_str))

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
