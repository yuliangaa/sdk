#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import pdb

######################################################
#    defines
######################################################


######################################################
#    functions
######################################################

def main():
    try:
        print("[+] opening sdk")
        rc, handle = sx_api_open(None)
        print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to open api handle.\nPlease check that SDK is running.")
            sys.exit(rc)

        # Check the current chip type
        chip_type = get_chip_type(handle)

        sx_port_isolate_mode_p = new_sx_port_isolate_mode_t_p()
        sx_port_isolate_mode = sx_port_isolate_mode_t()

        rc = sx_api_port_isolate_mode_get(handle, sx_port_isolate_mode_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_set failed. rc:%d" % rc

        sx_port_isolate_mode = sx_port_isolate_mode_t_p_value(sx_port_isolate_mode_p)
        print("sx_port_isolate_mode.pass_routed_frames: %d" % sx_port_isolate_mode.pass_routed_frames)
        if chip_type not in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM2]:
            print("sx_port_isolate_mode.isolate_bridged_and_routed: %d" % sx_port_isolate_mode.isolate_bridged_and_routed)
        print("Success.")

    finally:
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
