#!/usr/bin/env python
'''
This file contains Python command example for log port extended params (bulk) SET/GET.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of port ext params.
This example is supported on Spectrum3+ devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

FULL_TABLE_HDR_STR = "| Port ID  | Lane Count | Lane ID | Tx Precoding | Rx Precoding |"
FULL_TABLE_LINE_FMT = "|  0x{:>5x} | {:>10d} | {:>7d} | {:>12s} | {:>12s} |"
CAP_TABLE_HDR_STR = "| Lane Count | Lane ID | Tx Precoding Cap | Rx Precoding Cap |"
CAP_TABLE_HDR_FMT = "| {:>10d} | {:>7d} | {:>16s} | {:>16s} |"
INPUT_ERR_REPLY_PFX = "\n\t"
PRINT_INDENT = (4 * " ")
PRINT_INDENT2 = (2 * PRINT_INDENT)
TEST_CMD_GET_CAP = (SX_ACCESS_CMD_MAX + 1)

precoding_str_to_enum = {
    "enable": SX_PORT_EXT_PORT_LANE_PRECODING_ON_E,
    "disable": SX_PORT_EXT_PORT_LANE_PRECODING_OFF_E,
    "invalid": SX_PORT_EXT_PORT_LANE_PRECODING_INVALID_E
}

precoding_enum_to_str = {
    SX_PORT_EXT_PORT_LANE_PRECODING_ON_E: "enable",
    SX_PORT_EXT_PORT_LANE_PRECODING_OFF_E: "disable",
    SX_PORT_EXT_PORT_LANE_PRECODING_INVALID_E: "invalid"
}

precoding_cap_to_str = {
    False: "Not Supported",
    True: "Supported"
}


def rate_list_get(rate_struct):
    rate_list = []
    if rate_struct.rate_100M:
        rate_list.append("100M")
    if rate_struct.rate_1G:
        rate_list.append("1G")
    if rate_struct.rate_10G:
        rate_list.append("10G")
    if rate_struct.rate_25G:
        rate_list.append("25G")
    if rate_struct.rate_40G:
        rate_list.append("40G")
    if rate_struct.rate_50G:
        rate_list.append("50G")
    if rate_struct.rate_50Gx1:
        rate_list.append("50Gx1")
    if rate_struct.rate_50Gx2:
        rate_list.append("50Gx2")
    if rate_struct.rate_100G:
        rate_list.append("100G")
    if rate_struct.rate_100Gx1:
        rate_list.append("100Gx1")
    if rate_struct.rate_100Gx2:
        rate_list.append("100Gx2")
    if rate_struct.rate_100Gx4:
        rate_list.append("100Gx4")
    if rate_struct.rate_200G:
        rate_list.append("200G")
    if rate_struct.rate_200Gx2:
        rate_list.append("200Gx2")
    if rate_struct.rate_200Gx4:
        rate_list.append("200Gx4")
    if rate_struct.rate_400G:
        rate_list.append("400G")
    if rate_struct.rate_400Gx4:
        rate_list.append("400Gx4")
    if rate_struct.rate_400Gx8:
        rate_list.append("400Gx8")
    if rate_struct.rate_800G:
        rate_list.append("800G")
    if rate_struct.rate_800Gx8:
        rate_list.append("800Gx8")
    if rate_struct.rate_auto:
        rate_list.append("auto")
    return rate_list


def check_sdk_rc(rc, errmsg):
    if rc != SX_STATUS_SUCCESS:
        print("Fail: %s, rc=%d" % (errmsg, rc))
        return rc


def validate_on_set_op(cmd, precoding_str):
    if cmd != SX_ACCESS_CMD_SET and cmd != SX_ACCESS_CMD_UNSET:
        errmsg = "wrong input cmd {}".format(cmd)
        return SX_STATUS_PARAM_ERROR, errmsg
    if cmd == SX_ACCESS_CMD_SET and precoding_str not in precoding_str_to_enum:
        errmsg = "wrong input precoding string {}".format(precoding_str)
        return SX_STATUS_PARAM_ERROR, errmsg

    return SX_STATUS_SUCCESS, ""


def port_ext_params_set(handle, cmd, log_port, precoding_str, lane_cnt=0):
    """ SET/UNSET  """
    try:
        rc, errmsg = validate_on_set_op(cmd, precoding_str)
        check_sdk_rc(rc, errmsg)

        extended_params_p = new_sx_port_ext_port_params_t_p()

        precoding = SX_PORT_EXT_PORT_LANE_PRECODING_INVALID_E
        if cmd != SX_ACCESS_CMD_UNSET:
            precoding = precoding_str_to_enum[precoding_str]

        extended_params = sx_port_ext_port_params_t()
        extended_params.port_precoding.lane_cnt = lane_cnt
        setting = sx_port_ext_lane_precoding_t()
        setting.tx_precoding = precoding
        sx_port_ext_lane_precoding_t_arr_setitem(extended_params.port_precoding.precoding_settings, 0, setting)
        for i in range(0, lane_cnt):
            uint8_t_arr_setitem(extended_params.port_precoding.lane_id, i, i)
            print("PRECODING SET {}.".format(setting.tx_precoding))
            sx_port_ext_lane_precoding_t_arr_setitem(extended_params.port_precoding.precoding_settings, i, setting)
        sx_port_ext_port_params_t_p_assign(extended_params_p, extended_params)

        rc = sx_api_port_ext_params_set(handle,
                                        cmd,
                                        log_port,
                                        extended_params_p)
        check_sdk_rc(rc, "sx_api_port_ext_params_set failed, ret:{}.".format(rc))
        return rc

    finally:
        delete_sx_port_ext_port_params_t_p(extended_params_p)


def port_ext_params_dump(handle, log_port, lane_cnt=0):
    """ GET+DUMP EXT PARAMS """
    try:
        extended_params_p = new_sx_port_ext_port_params_t_p()
        extended_params = sx_port_ext_port_params_t()
        extended_params.port_precoding.lane_cnt = lane_cnt
        for i in range(0, lane_cnt):
            uint8_t_arr_setitem(extended_params.port_precoding.lane_id, i, i)
        sx_port_ext_port_params_t_p_assign(extended_params_p, extended_params)

        rc = sx_api_port_ext_params_get(handle,
                                        SX_ACCESS_CMD_GET,
                                        log_port,
                                        extended_params_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_ext_params_get failed, ret:{}.".format(rc))
            return rc

        extended_params = sx_port_ext_port_params_t_p_value(extended_params_p)
        lane_cnt = extended_params.port_precoding.lane_cnt
        table_hdr_str = FULL_TABLE_HDR_STR
        table_line_len = len(table_hdr_str)
        print(table_line_len * "=")
        print(table_hdr_str)
        for j in range(0, lane_cnt):
            print(table_line_len * "-")
            lid = uint8_t_arr_getitem(extended_params.port_precoding.lane_id, j)
            setting = sx_port_ext_lane_precoding_t_arr_getitem(extended_params.port_precoding.precoding_settings, j)
            print(FULL_TABLE_LINE_FMT
                  .format(log_port, lane_cnt, lid,
                          precoding_enum_to_str[setting.tx_precoding],
                          precoding_enum_to_str[setting.rx_precoding]))
        print(table_line_len * "=")
        return rc

    finally:
        delete_sx_port_ext_port_params_t_p(extended_params_p)


def portlist_ext_params_set(handle, cmd, log_port_list, precoding_str, lane_cnt=0):
    """ SET/UNSET  """
    try:
        port_cnt = len(log_port_list)
        if port_cnt == 1:
            clean_up = False
            return port_ext_params_set(handle, cmd, log_port_list[0], precoding_str, lane_cnt)

        clean_up = True
        rc, errmsg = validate_on_set_op(cmd, precoding_str)
        check_sdk_rc(rc, errmsg)
        precoding = precoding_str_to_enum[precoding_str]

        log_port_arr = new_sx_port_log_id_t_arr(port_cnt)
        extended_params_arr = new_sx_port_ext_port_params_t_arr(port_cnt)
        extended_params = sx_port_ext_port_params_t()
        setting = sx_port_ext_lane_precoding_t()
        setting.tx_precoding = precoding
        sx_port_ext_lane_precoding_t_arr_setitem(extended_params.port_precoding.precoding_settings, 0, setting)
        extended_params.port_precoding.lane_cnt = lane_cnt
        if lane_cnt > 0:
            for j in range(0, lane_cnt):
                uint8_t_arr_setitem(extended_params.port_precoding.lane_id, j, j)
                sx_port_ext_lane_precoding_t_arr_setitem(extended_params.port_precoding.precoding_settings, j, setting)

        for i in range(0, port_cnt):
            sx_port_log_id_t_arr_setitem(log_port_arr, i, log_port_list[i])
            sx_port_ext_port_params_t_arr_setitem(extended_params_arr, i, extended_params)

        rc = sx_api_port_ext_params_bulk_set(handle,
                                             cmd,
                                             log_port_arr,
                                             extended_params_arr,
                                             port_cnt)
        check_sdk_rc(rc, "sx_api_port_ext_params_bulk_set failed, ret:{}.".format(rc))
        return rc

    finally:
        if clean_up:
            delete_sx_port_log_id_t_arr(log_port_arr)
            delete_sx_port_ext_port_params_t_arr(extended_params_arr)


def portlist_ext_params_get_original(handle, log_port_list, lane_cnt=0):
    """ GET ORIGINAL SETTINGS """
    rc = SX_STATUS_SUCCESS
    port_cnt = len(log_port_list)
    log_port_arr = new_sx_port_log_id_t_arr(port_cnt)
    extended_params_arr = new_sx_port_ext_port_params_t_arr(port_cnt)
    extended_params = sx_port_ext_port_params_t()
    extended_params.port_precoding.lane_cnt = lane_cnt
    if lane_cnt > 0:
        for j in range(0, lane_cnt):
            uint8_t_arr_setitem(extended_params.port_precoding.lane_id, j, j)

    for i in range(0, port_cnt):
        sx_port_log_id_t_arr_setitem(log_port_arr, i, log_port_list[i])
        if lane_cnt > 0:
            sx_port_ext_port_params_t_arr_setitem(extended_params_arr, i, extended_params)

    # It may fail due to lane id mismatch, e.g. split port with other lane ids, then try to input lane_cnt=0 to further check
    rc = sx_api_port_ext_params_bulk_get(handle,
                                         SX_ACCESS_CMD_GET,
                                         log_port_arr,
                                         extended_params_arr,
                                         port_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_ext_params_bulk_get failed, ret:{}.".format(rc))
        delete_sx_port_log_id_t_arr(log_port_arr)
        delete_sx_port_ext_port_params_t_arr(extended_params_arr)
        return rc, 0, None, None
    return rc, port_cnt, log_port_arr, extended_params_arr


def portlist_ext_params_restore_original(handle, port_cnt, log_port_arr, extended_params_arr):
    """ RESTORE ORIGINAL SETTINGS """
    rc = sx_api_port_ext_params_bulk_set(handle,
                                         SX_ACCESS_CMD_SET,
                                         log_port_arr,
                                         extended_params_arr,
                                         port_cnt)
    check_sdk_rc(rc, "sx_api_port_ext_params_bulk_set failed, ret:{}.".format(rc))
    return rc


def portlist_ext_params_dump(handle, log_port_list, lane_cnt=0):
    """ GET+DUMP """
    try:
        port_cnt = len(log_port_list)
        if port_cnt == 1:
            clean_up = False
            return port_ext_params_dump(handle, log_port_list[0], lane_cnt)

        clean_up = True
        log_port_arr = new_sx_port_log_id_t_arr(port_cnt)
        extended_params_arr = new_sx_port_ext_port_params_t_arr(port_cnt)
        extended_params = sx_port_ext_port_params_t()
        extended_params.port_precoding.lane_cnt = lane_cnt
        if lane_cnt > 0:
            for j in range(0, lane_cnt):
                uint8_t_arr_setitem(extended_params.port_precoding.lane_id, j, j)

        for i in range(0, port_cnt):
            sx_port_log_id_t_arr_setitem(log_port_arr, i, log_port_list[i])
            if lane_cnt > 0:
                sx_port_ext_port_params_t_arr_setitem(extended_params_arr, i, extended_params)

        # It may fail due to lane id mismatch, e.g. split port with other lane ids, then try to input lane_cnt=0 to further check
        rc = sx_api_port_ext_params_bulk_get(handle,
                                             SX_ACCESS_CMD_GET,
                                             log_port_arr,
                                             extended_params_arr,
                                             port_cnt)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_ext_params_bulk_get failed, ret:{}.".format(rc))
            return rc

        table_hdr_str = "| Port ID  | Lane Count | Lane ID | Tx Precoding | Rx Precoding |"
        table_line_len = len(table_hdr_str)
        print(table_line_len * "=")
        print(table_hdr_str)
        for i in range(0, port_cnt):
            l_port = sx_port_log_id_t_arr_getitem(log_port_arr, i)
            extended_params = sx_port_ext_port_params_t_arr_getitem(extended_params_arr, i)
            lane_cnt = extended_params.port_precoding.lane_cnt
            for j in range(0, lane_cnt):
                print(table_line_len * "-")
                lid = uint8_t_arr_getitem(extended_params.port_precoding.lane_id, j)
                setting = sx_port_ext_lane_precoding_t_arr_getitem(extended_params.port_precoding.precoding_settings, j)
                print(FULL_TABLE_LINE_FMT
                      .format(l_port, lane_cnt, lid, precoding_enum_to_str[setting.tx_precoding], precoding_enum_to_str[setting.rx_precoding]))
        print(table_line_len * "=")
        return rc

    finally:
        if clean_up:
            delete_sx_port_log_id_t_arr(log_port_arr)
            delete_sx_port_ext_port_params_t_arr(extended_params_arr)


def portlist_ext_params_cap_dump(handle, log_port_list, lane_cnt=0):
    """ GET+DUMP EXT PARAM CAPS """
    try:
        capability_p = new_sx_port_ext_capability_t_p()
        capability = sx_port_ext_capability_t()
        for log_port in log_port_list:
            capability.precoding_capability.lane_cnt = lane_cnt
            for i in range(0, lane_cnt):
                uint8_t_arr_setitem(capability.precoding_capability.lane_id, i, i)
            sx_port_ext_capability_t_p_assign(capability_p, capability)

            rc = sx_api_port_ext_capability_get(handle,
                                                log_port,
                                                capability_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_ext_capability_get failed, ret:{}.".format(rc))
                return rc
            print("Log port: 0x{:x}".format(log_port))
            print(PRINT_INDENT + "Port precoding capabilites:")
            table_hdr_str = CAP_TABLE_HDR_STR
            table_line_len = len(table_hdr_str)
            print(PRINT_INDENT + table_line_len * "=")
            print(PRINT_INDENT + table_hdr_str)

            capability = sx_port_ext_capability_t_p_value(capability_p)
            lane_cnt = capability.precoding_capability.lane_cnt
            for j in range(0, lane_cnt):
                print(PRINT_INDENT + table_line_len * "-")
                lid = uint8_t_arr_getitem(capability.precoding_capability.lane_id, j)
                lane_cap = sx_port_ext_lane_precoding_cap_t_arr_getitem(capability.precoding_capability.precoding_caps, j)
                print(PRINT_INDENT + CAP_TABLE_HDR_FMT
                      .format(lane_cnt, lid, precoding_cap_to_str[lane_cap.tx_admin], precoding_cap_to_str[lane_cap.rx_admin]))
            print(PRINT_INDENT + table_line_len * "=")

            rate_list = rate_list_get(capability.speed_capability)
            print(PRINT_INDENT + "Port rate capabilites:")
            print(PRINT_INDENT + "{}\n".format(rate_list))
        return rc

    finally:
        delete_sx_port_ext_capability_t_p(capability_p)


def get_args():
    parser = argparse.ArgumentParser(description='sx_api_port_ext_params.py example. If no explicit action is given, the default will be to create a profile.')

    parser.add_argument('--log_port', default="", help='List of log port to set state for separated by ",". i.e. 0x10001,0x10005')

    operation = parser.add_mutually_exclusive_group()
    operation.add_argument('--set', action='store_true', help='Set log port extended params')
    operation.add_argument('--get', action='store_true', help='Get log port extended params')
    operation.add_argument('--unset', action='store_true', help='Set log port extended params to default values, i.e., "invalid"')
    operation.add_argument('--get_cap', action='store_true', help='Get log port extended param capabilities')

    parser.add_argument('--precoding', choices=["enable", "disable", "invalid"], help='Precoding - "enable", "disable" or "invalid"')
    parser.add_argument('--lane_cnt', default="0", help='lane count to be get, ignored (parsed as default 0) for set/unset')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Unset configurations done by the example')
    args = parser.parse_args()
    return args


def main():
    args = get_args()
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        rollback_available = False
        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_QUANTUM, SX_CHIP_TYPE_QUANTUM2, SX_CHIP_TYPE_SPECTRUM]:
            print(INPUT_ERR_REPLY_PFX + "port extended params GET/SET is supported from spectrum2 and above.")
            return rc
        print_api_example_disclaimer()

        if args.log_port:
            log_port_list = [int(log_port, 16) for log_port in args.log_port.split(",")]
        else:
            log_port_list = get_ports(handle, 1)

        if args.get:
            cmd = SX_ACCESS_CMD_GET
        elif args.unset:
            cmd = SX_ACCESS_CMD_UNSET
        elif args.set:
            cmd = SX_ACCESS_CMD_SET
        elif args.get_cap:
            cmd = TEST_CMD_GET_CAP
        else:
            # default operations
            cmd = SX_ACCESS_CMD_SET

        lane_cnt = int(args.lane_cnt)
        if cmd == SX_ACCESS_CMD_SET or cmd == SX_ACCESS_CMD_UNSET:
            if not args.force:
                print_modification_warning()
            rc, port_cnt, orgin_log_port_arr, orgin_extended_params_arr = portlist_ext_params_get_original(handle, log_port_list, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to get extended params for ports: {}, rc:{}.".format(log_port_list, rc))
                return rc
            rollback_available = True

        if cmd == SX_ACCESS_CMD_GET:
            rc = portlist_ext_params_dump(handle, log_port_list, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to get extended params for ports: {}, rc:{}.".format(log_port_list, rc))
                return rc
        elif cmd == SX_ACCESS_CMD_UNSET:
            lane_cnt = 0
            rc = portlist_ext_params_set(handle, SX_ACCESS_CMD_UNSET, log_port_list, None, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to unset extended params for ports: {}.".format(log_port_list))
                return rc
        elif cmd == SX_ACCESS_CMD_SET:
            lane_cnt = 0
            precoding_str = args.precoding
            if not args.precoding:
                precoding_str = "enable"
            rc = portlist_ext_params_set(handle, SX_ACCESS_CMD_SET, log_port_list, precoding_str, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to set extended params {} for ports: {}.".format(precoding_str, log_port_list))
                return rc
            rc = portlist_ext_params_dump(handle, log_port_list, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to dump extended params for ports: {}.".format(log_port_list))
                return rc
        elif cmd == TEST_CMD_GET_CAP:
            rc = portlist_ext_params_cap_dump(handle, log_port_list, lane_cnt)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to get extended params for ports: {}, rc:{}.".format(log_port_list, rc))
                return rc

        # handle deinit only in case of  '--set'/'--unset'
        if args.deinit and rollback_available:
            rc = portlist_ext_params_restore_original(handle, port_cnt, orgin_log_port_arr, orgin_extended_params_arr)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to restore extended params for ports: {}.".format(log_port_list))
                return rc

    finally:
        if rollback_available:
            delete_sx_port_log_id_t_arr(orgin_log_port_arr)
            delete_sx_port_ext_port_params_t_arr(orgin_extended_params_arr)
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
