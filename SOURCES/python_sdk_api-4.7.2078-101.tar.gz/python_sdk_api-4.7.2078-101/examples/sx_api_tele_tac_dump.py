#!/usr/bin/env python
"""
This file contains Python command example for dump TAC configuration of the Telemetry module.
This example is only valid when telemetry moduel is initialized.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

######################################################
#    functions
######################################################


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_tele_tac_dump example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def print_separator():
    print("==========================================================")


def tele_attributes_get(handle):
    " This function get telemetry attributes. "

    tele_attr_p = new_sx_tele_attrib_t_p()
    rc = sx_api_tele_attributes_get(handle, tele_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_tele_attributes_get failed with rc:%s " % (sx_status_dict[rc]))
        print("Please check if tele module was initialized.")
        exit(0)

    data = sx_tele_attrib_t_p_value(tele_attr_p)

    print_separator()
    print("Tele module attributes")
    print("TAC mode                           : %s " % (tele_tac_mode_dict[data.tac_attr.tac_mode]))
    print("TAC periodic action enabled        : %s " % (get_boolean_string(data.tac_attr.tac_periodic_action_enabled)))
    print("TAC periodic action                : %s " % (tele_tac_action_dict[data.tac_attr.tac_periodic_action]))
    print("TAC periodic action interval (msec): %d " % (data.tac_attr.tac_periodic_action_interval))
    print_separator()

    return data


def tele_tac_get(handle, trap_group):
    " This function get trap group TAC configuration"

    cmd = SX_ACCESS_CMD_GET
    tac_cfg_p = new_sx_tele_tac_cfg_t_p()
    rc = sx_api_tele_tac_get(handle, cmd, trap_group, tac_cfg_p)
    tac_cfg = sx_tele_tac_cfg_t_p_value(tac_cfg_p)

    return tac_cfg, rc


def dump_all_trap_group_tac_cfg(handle):

    print("TAC capable trap groups:")
    print("---------------------------------------------------")
    print("| Trap Group | Connected to TAC | SPAN Session ID |")
    print("---------------------------------------------------")
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    for trap_group in range(0, 63):
        rc = sx_api_host_ifc_trap_group_get(handle, 0, trap_group, trap_group_attr_p)
        if (rc != SX_STATUS_SUCCESS):
            continue

        if (trap_group_attr_p.is_tac_capable == False):
            continue

        tac_cfg, rc = tele_tac_get(handle, trap_group)
        if (rc != SX_STATUS_SUCCESS):
            tac_connected = False
            span_session_id = "N/A"
        else:
            tac_connected = True
            span_session_id = tac_cfg.tac_to_net_span_id
        print(("|%12s| %17s| %16s|" % (trap_group, get_boolean_string(tac_connected), span_session_id)))
        print("---------------------------------------------------")

    print_separator()


def tele_tac_action_get(handle):
    " This function get trap group TAC action status. "

    cmd = SX_ACCESS_CMD_GET
    tac_action_status_p = new_sx_tele_tac_action_status_t_p()

    rc = sx_api_tele_tac_action_status_get(handle, cmd, tac_action_status_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_cache_agg_action_get rc %d" % (rc)

    print("TAC Action status: %s " % (tele_tac_action_status_dict[tac_action_status_p.tac_action_status]))
    print_separator()

    return tac_action_status_p.tac_action_status


def tele_tac_stat_get(handle):
    " This function get TAC statstics. "

    cmd = SX_ACCESS_CMD_READ
    tac_stat_p = new_sx_tele_tac_statistics_t_arr(1)

    rc = sx_api_tele_tac_statistics_get(handle, cmd, tac_stat_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_cache_agg_stat_get rc %d" % (rc)

    print("TAC statistics")
    print("tac_ingress_pkt    : %d" % (tac_stat_p.global_tac_statistics.tac_ingress_pkt))
    print("tac_egress_pkt     : %d" % (tac_stat_p.global_tac_statistics.tac_egress_pkt))
    print("tac_egress_bytes   : %d" % (tac_stat_p.global_tac_statistics.tac_egress_bytes))
    print("tac_egress_pkt_drop: %d" % (tac_stat_p.global_tac_statistics.tac_egress_pkt_drop))
    print_separator()

    return rc


def host_ifc_module_veribosity_level_get(handle):
    " get module_verbosity_level and api_verbosity_level for later de-configuration "
    original_module_verbosity_level_p = new_sx_verbosity_level_t_p()
    original_api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_host_ifc_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, original_module_verbosity_level_p, original_api_verbosity_level_p)
    if (rc != SX_STATUS_SUCCESS):
        print("fail to get host ifc API log verbosity level")
        sys.exit(rc)
    original_module_verbosity_level = sx_verbosity_level_t_p_value(original_module_verbosity_level_p)
    original_api_verbosity_level = sx_verbosity_level_t_p_value(original_api_verbosity_level_p)

    return original_module_verbosity_level, original_api_verbosity_level


def host_ifc_module_verbosity_level_set(handle, module_verbosity_level, api_verbosity_level):
    " set module verbosity_level "
    rc = sx_api_host_ifc_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
    if (rc != SX_STATUS_SUCCESS):
        print("fail to set host ifc API log verbosity level")
        sys.exit(rc)


def tele_module_veribosity_level_get(handle):
    " get module_verbosity_level and api_verbosity_level for later de-configuration "
    original_module_verbosity_level_p = new_sx_verbosity_level_t_p()
    original_api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_tele_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, original_module_verbosity_level_p, original_api_verbosity_level_p)
    if (rc != SX_STATUS_SUCCESS):
        print("fail to get host ifc API log verbosity level")
        sys.exit(rc)
    original_module_verbosity_level = sx_verbosity_level_t_p_value(original_module_verbosity_level_p)
    original_api_verbosity_level = sx_verbosity_level_t_p_value(original_api_verbosity_level_p)

    return original_module_verbosity_level, original_api_verbosity_level


def tele_module_verbosity_level_set(handle, module_verbosity_level, api_verbosity_level):
    " set module verbosity_level "
    rc = sx_api_tele_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
    if (rc != SX_STATUS_SUCCESS):
        print("fail to set host ifc API log verbosity level")
        sys.exit(rc)


def tele_init(handle):
    " This function init tele. "

    tele_param_p = new_sx_tele_init_params_t_p()
    rc = sx_api_tele_init_set(handle, tele_param_p)
    return rc


def tele_deinit(handle):
    " This function deinit tele. "

    rc = sx_api_tele_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "tele deinit failed rc %d" % (rc)


######################################################
def main():
    args = parse_args()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return 1

    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
        print("TAC configuration is not supported on this chip type.")
        sx_api_close(handle)
        return 0

    host_ifc_orig_module_verbosity_level, host_ifc_orig_api_verbosity_level = host_ifc_module_veribosity_level_get(handle)
    host_ifc_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

    tele_orig_module_verbosity_level, tele_orig_api_verbosity_level = tele_module_veribosity_level_get(handle)
    # Changing modules verbosity to None, to avoid possibly expected errors during init
    tele_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

    rc = tele_init(handle)
    if rc != SX_STATUS_ALREADY_INITIALIZED:
        # If rc != SX_STATUS_ALREADY_INITIALIZED than tele module wasn't initialized
        print("TELE module isn't initialized.")
        host_ifc_module_verbosity_level_set(handle, host_ifc_orig_module_verbosity_level, host_ifc_orig_api_verbosity_level)
        tele_module_verbosity_level_set(handle, tele_orig_module_verbosity_level, tele_orig_api_verbosity_level)
        # tele module deinit is needed only if tele_init succeed before
        if rc == SX_STATUS_SUCCESS:
            tele_deinit(handle)
        sx_api_close(handle)
        return 0

    # Tele attributes get should succeed when called on any platform with any TAC configuration
    tele_attrib = tele_attributes_get(handle)

    # if TAC is disabled then return
    if tele_attrib.tac_attr.tac_mode == 0:
        host_ifc_module_verbosity_level_set(handle, host_ifc_orig_module_verbosity_level, host_ifc_orig_api_verbosity_level)
        tele_module_verbosity_level_set(handle, tele_orig_module_verbosity_level, tele_orig_api_verbosity_level)
        sx_api_close(handle)
        return 0

    # dump all TAC trap groups
    dump_all_trap_group_tac_cfg(handle)

    tele_tac_action_get(handle)

    tele_tac_stat_get(handle)

    host_ifc_module_verbosity_level_set(handle, host_ifc_orig_module_verbosity_level, host_ifc_orig_api_verbosity_level)
    tele_module_verbosity_level_set(handle, tele_orig_module_verbosity_level, tele_orig_api_verbosity_level)

    sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
