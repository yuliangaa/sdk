#!/usr/bin/env python

import sys
import time
import os
import argparse
import errno
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

ppcnt_cntr_grp = {0: 0x16,
                  1: 0x24}


def parse_args():
    parser = argparse.ArgumentParser(description='PPCNT PHY Statistics get example')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), GET_AND_CLEAR(1)")
    parser.add_argument('--local_port', default=1, type=int, help="Local Port")
    parser.add_argument('--cntr_grp', default=0, type=int, help="Counters group: 0 - PHY Statistics group (0x16); 1 - PHY USR group (0x24)")
    parser.add_argument('--port_type', default=0, type=int, help="0-default (Network Port); 1-near-end; 2-internal IC LR; 3-far-end; 4-usr main; 5-usr tile")

    args = parser.parse_args()
    return args.cmd, args.local_port, args.port_type, ppcnt_cntr_grp[args.cntr_grp]


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, local_port, port_type, cntr_grp):

    ppcnt = ku_ppcnt_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET
    ppcnt.clr = 0 if cmd == 0 else 1
    ppcnt.pnat = 0
    ppcnt.local_port, ppcnt.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    ppcnt.port_type = port_type

    ppcnt.grp = cntr_grp

    print("====================")
    print("[+] Get PPCNT")
    print("[+] local port: ", ppcnt.local_port)
    print("[+] lp_msb: ", ppcnt.lp_msb)
    print("[+] port_type: ", ppcnt.port_type)
    print("[+] cntr_group: ", hex(ppcnt.grp))
    print("[+] clr: ", ppcnt.clr)
    rc = sxd_access_reg_ppcnt(ppcnt, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to get PPCNT register, rc: %d" % (rc)

    print("[+] Get PPCNT done. rc:", rc)
    print("====================")

    if rc == SXD_STATUS_SUCCESS:
        if ppcnt.grp == 0x16:
            print("[+] cntr_group: ", hex(ppcnt.grp))
            cntr = ppcnt.counter_set.phys_layer_stat_cntrs
            print("[+] %-27s: %s" % ("time_since_last_clear_high", cntr.time_since_last_clear_high))
            print("[+] %-27s: %s" % ("time_since_last_clear_low", cntr.time_since_last_clear_low))
            print("[+] %-27s: %s" % ("phy_received_bits_high", cntr.phy_received_bits_high))
            print("[+] %-27s: %s" % ("phy_received_bits_low", cntr.phy_received_bits_low))
            print("[+] %-27s: %s" % ("phy_symbol_errors_high", cntr.phy_symbol_errors_high))
            print("[+] %-27s: %s" % ("phy_symbol_errors_low", cntr.phy_symbol_errors_low))
            print("[+] %-27s: %s" % ("phy_corrected_bits_high", cntr.phy_corrected_bits_high))
            print("[+] %-27s: %s" % ("phy_corrected_bits_low", cntr.phy_corrected_bits_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane0_high", cntr.phy_raw_errors_lane0_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane0_low", cntr.phy_raw_errors_lane0_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane1_high", cntr.phy_raw_errors_lane1_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane1_low", cntr.phy_raw_errors_lane1_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane2_high", cntr.phy_raw_errors_lane2_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane2_low", cntr.phy_raw_errors_lane2_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane3_high", cntr.phy_raw_errors_lane3_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane3_low", cntr.phy_raw_errors_lane3_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane4_high", cntr.phy_raw_errors_lane4_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane4_low", cntr.phy_raw_errors_lane4_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane5_high", cntr.phy_raw_errors_lane5_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane5_low", cntr.phy_raw_errors_lane5_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane6_high", cntr.phy_raw_errors_lane6_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane6_low", cntr.phy_raw_errors_lane6_low))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane7_high", cntr.phy_raw_errors_lane7_high))
            print("[+] %-27s: %s" % ("phy_raw_errors_lane7_low", cntr.phy_raw_errors_lane7_low))
            print("[+] %-27s: %s" % ("raw_ber_magnitude", cntr.raw_ber_magnitude))
            print("[+] %-27s: %s" % ("raw_ber_coef_float", cntr.raw_ber_coef_float))
            print("[+] %-27s: %s" % ("raw_ber_coef", cntr.raw_ber_coef))
            print("[+] %-27s: %s" % ("effective_ber_magnitude", cntr.effective_ber_magnitude))
            print("[+] %-27s: %s" % ("effective_ber_coef_float", cntr.effective_ber_coef_float))
            print("[+] %-27s: %s" % ("effective_ber_coef", cntr.effective_ber_coef))
            print("[+] %-27s: %s" % ("symbol_ber_magnitude", cntr.symbol_ber_magnitude))
            print("[+] %-27s: %s" % ("symbol_ber_coef_float", cntr.symbol_ber_coef_float))
            print("[+] %-27s: %s" % ("symbol_ber_coef", cntr.symbol_ber_coef))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane0", cntr.raw_ber_magnitude_lane0))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane0", cntr.raw_ber_coef_float_lane0))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane0", cntr.raw_ber_coef_lane0))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane1", cntr.raw_ber_magnitude_lane1))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane1", cntr.raw_ber_coef_float_lane1))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane1", cntr.raw_ber_coef_lane1))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane2", cntr.raw_ber_magnitude_lane2))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane2", cntr.raw_ber_coef_float_lane2))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane2", cntr.raw_ber_coef_lane2))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane3", cntr.raw_ber_magnitude_lane3))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane3", cntr.raw_ber_coef_float_lane3))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane3", cntr.raw_ber_coef_lane3))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane4", cntr.raw_ber_magnitude_lane4))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane4", cntr.raw_ber_coef_float_lane4))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane4", cntr.raw_ber_coef_lane4))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane5", cntr.raw_ber_magnitude_lane5))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane5", cntr.raw_ber_coef_float_lane5))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane5", cntr.raw_ber_coef_lane5))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane6", cntr.raw_ber_magnitude_lane6))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane6", cntr.raw_ber_coef_float_lane6))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane6", cntr.raw_ber_coef_lane6))
            print("[+] %-27s: %s" % ("raw_ber_magnitude_lane7", cntr.raw_ber_magnitude_lane7))
            print("[+] %-27s: %s" % ("raw_ber_coef_float_lane7", cntr.raw_ber_coef_float_lane7))
            print("[+] %-27s: %s" % ("raw_ber_coef_lane7", cntr.raw_ber_coef_lane7))
            print("[+] %-27s: %s" % ("phy_effective_errors_high", cntr.phy_effective_errors_high))
            print("[+] %-27s: %s" % ("phy_effective_errors_low", cntr.phy_effective_errors_low))

        elif ppcnt.grp == 0x24:
            print("[+] cntr_group: ", hex(ppcnt.grp))
            cntr = ppcnt.counter_set.usr_xsr_physical_layer

            print("[+] %-38s: %s" % ("time_since_last_clear_high", cntr.time_since_last_clear_high))
            print("[+] %-38s: %s" % ("time_since_last_clear_low", cntr.time_since_last_clear_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane0_high", cntr.fc_fec_corrected_blocks_lane0_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane0_low", cntr.fc_fec_corrected_blocks_lane0_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane1_high", cntr.fc_fec_corrected_blocks_lane1_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane1_low", cntr.fc_fec_corrected_blocks_lane1_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane2_high", cntr.fc_fec_corrected_blocks_lane2_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane2_low", cntr.fc_fec_corrected_blocks_lane2_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane3_high", cntr.fc_fec_corrected_blocks_lane3_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane3_low", cntr.fc_fec_corrected_blocks_lane3_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane4_high", cntr.fc_fec_corrected_blocks_lane4_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane4_low", cntr.fc_fec_corrected_blocks_lane4_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane5_high", cntr.fc_fec_corrected_blocks_lane5_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane5_low", cntr.fc_fec_corrected_blocks_lane5_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane6_high", cntr.fc_fec_corrected_blocks_lane6_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane6_low", cntr.fc_fec_corrected_blocks_lane6_low))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane7_high", cntr.fc_fec_corrected_blocks_lane7_high))
            print("[+] %-38s: %s" % ("fc_fec_corrected_blocks_lane7_low", cntr.fc_fec_corrected_blocks_lane7_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane0_high", cntr.fc_fec_uncorrectable_blocks_lane0_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane0_low", cntr.fc_fec_uncorrectable_blocks_lane0_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane1_high", cntr.fc_fec_uncorrectable_blocks_lane1_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane1_low", cntr.fc_fec_uncorrectable_blocks_lane1_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane2_high", cntr.fc_fec_uncorrectable_blocks_lane2_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane2_low", cntr.fc_fec_uncorrectable_blocks_lane2_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane3_high", cntr.fc_fec_uncorrectable_blocks_lane3_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane3_low", cntr.fc_fec_uncorrectable_blocks_lane3_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane4_high", cntr.fc_fec_uncorrectable_blocks_lane4_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane4_low", cntr.fc_fec_uncorrectable_blocks_lane4_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane5_high", cntr.fc_fec_uncorrectable_blocks_lane5_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane5_low", cntr.fc_fec_uncorrectable_blocks_lane5_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane6_high", cntr.fc_fec_uncorrectable_blocks_lane6_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane6_low", cntr.fc_fec_uncorrectable_blocks_lane6_low))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane7_high", cntr.fc_fec_uncorrectable_blocks_lane7_high))
            print("[+] %-38s: %s" % ("fc_fec_uncorrectable_blocks_lane7_low", cntr.fc_fec_uncorrectable_blocks_lane7_low))
            print("[+] %-38s: %s" % ("link_down_events", cntr.link_down_events))


def main():
    cmd, local_port, port_type, cntr_grp = parse_args()
    sxd_init()
    run_example(cmd, local_port, port_type, cntr_grp)
    print("[+] PPCNT register example end")


if __name__ == "__main__":
    print("[+] Get PPCNT register access example to query PHY counters group")
    main()
