#!/usr/bin/env python
"""
This file contains Python command example for extended user defined traps available in SPECTRUM2 and above asics.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""
import sys
import socket
import struct
from test_infra_common import *
from python_sdk_api.sx_api import *
import sys
from python_sdk_api import sxd_api
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_user_defined_traps example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

ETHERTYPE_IPv4 = 0x0800
ETHERTYPE_ARP = 0x0806
IP_PROTO_RDP = 27
TRAP_GROUP = 20

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0


def host_ifc_open(handle):
    ''' Opening fd for traps '''
    trap_fd = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to open host_ifc trap_fd, rc=[%d] " % (rc)))
        sys.exit(rc)
    return trap_fd


def host_ifc_close(handle, fd):
    ''' Closing host ifc '''
    trap_fd = new_sx_fd_t_p()
    sx_fd_t_p_assign(trap_fd, fd)

    rc = sx_api_host_ifc_close(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to close host_ifc trap_fd, rc=[%d] " % (rc)))
        sys.exit(rc)


def host_ifc_trap_group_set(handle, cmd, trap_group):
    ''' SET or UNSET trap group '''
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = 1
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = False
    trap_group_attr.trap_group = trap_group
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(rc)
    return sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group


def host_ifc_trap_id_set(handle, cmd, trap_id, trap_group):
    ''' SET/UNSET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group

    if cmd == SX_ACCESS_CMD_SET:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU
    else:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT

    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(rc)


def host_ifc_trap_id_register_set(handle, cmd, trap_id, user_channel, fd):
    ''' REGISTER/DEREGISTER trap id association to the relevant user channel '''
    user_channel_p = new_sx_user_channel_t_p()

    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t()
        user_channel.type = SX_USER_CHANNEL_TYPE_FD
        user_channel.channel.fd = copy_sx_fd_t_p(fd)

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, SPECTRUM_SWID, trap_id, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t_p_value(user_channel_p)

    return user_channel


def host_ifc_configure_user_defined_trap_key(handle, cmd, trap_id, key_type, key_val_list):
    ''' Add or Delete key type, key attributes to trap id'''
    trap_attributes_p = None
    key_arr = None
    if cmd == SX_ACCESS_CMD_ADD:
        user_defined_key = sx_trap_id_user_defined_key_t()
        user_defined_key.type = key_type
        key_arr = new_sx_trap_id_user_defined_key_t_arr(1)
        if key_type == SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E:
            user_defined_key.key.nve_decap_eth_attr.eth_type = key_val_list[0]
            user_defined_key.key.nve_decap_eth_attr.is_eth_type_valid = key_val_list[1]
            user_defined_key.key.nve_decap_eth_attr.tunnel_id = key_val_list[2]
            user_defined_key.key.nve_decap_eth_attr.is_tunnel_id_valid = key_val_list[3]
        if key_type == SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E:
            user_defined_key.key.next_proto_key_type_attr.is_ipv4 = key_val_list[0]
            user_defined_key.key.next_proto_key_type_attr.is_ipv4_valid = key_val_list[1]
            user_defined_key.key.next_proto_key_type_attr.ip_proto = key_val_list[2]
            user_defined_key.key.next_proto_key_type_attr.is_ip_proto_valid = key_val_list[3]
            user_defined_key.key.next_proto_key_type_attr.tunnel_id = key_val_list[4]
            user_defined_key.key.next_proto_key_type_attr.is_tunnel_id_valid = key_val_list[5]
        elif key_type == SX_TRAP_ID_USER_DEFINED_KEY_L4_PORT_E:
            user_defined_key.key.l4_port_key_type_attr.is_udp = key_val_list[0]
            user_defined_key.key.l4_port_key_type_attr.is_udp_valid = key_val_list[1]
            user_defined_key.key.l4_port_key_type_attr.is_ipv4 = key_val_list[2]
            user_defined_key.key.l4_port_key_type_attr.is_ipv4_valid = key_val_list[3]
            user_defined_key.key.l4_port_key_type_attr.l4_port = key_val_list[4]
            user_defined_key.key.l4_port_key_type_attr.is_l4_port_valid = key_val_list[5]
            user_defined_key.key.l4_port_key_type_attr.tunnel_id = key_val_list[6]
            user_defined_key.key.l4_port_key_type_attr.is_tunnel_id_valid = key_val_list[7]
        elif key_type == SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E:
            user_defined_key.key.icmp_key_type_attr.is_ipv4 = key_val_list[0]
            user_defined_key.key.icmp_key_type_attr.is_ipv4_valid = key_val_list[1]
            user_defined_key.key.icmp_key_type_attr.min_icmp_type = key_val_list[2]
            user_defined_key.key.icmp_key_type_attr.max_icmp_type = key_val_list[3]
            user_defined_key.key.icmp_key_type_attr.tunnel_id = key_val_list[4]
            user_defined_key.key.icmp_key_type_attr.is_tunnel_id_valid = key_val_list[5]
        elif key_type == SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E:
            user_defined_key.key.igmp_key_type_attr.min_igmp_type = key_val_list[0]
            user_defined_key.key.igmp_key_type_attr.max_igmp_type = key_val_list[1]
            user_defined_key.key.igmp_key_type_attr.tunnel_id = key_val_list[2]
            user_defined_key.key.igmp_key_type_attr.is_tunnel_id_valid = key_val_list[3]

        sx_trap_id_user_defined_key_t_arr_setitem(key_arr, 0, user_defined_key)
        trap_attributes = sx_trap_id_user_defined_attributes_t()
        trap_attributes.key_list = key_arr
        trap_attributes.key_list_cnt = 1
        trap_attributes_p = copy_sx_trap_id_user_defined_attributes_t_p(trap_attributes)

    rc = sx_api_host_ifc_user_defined_trap_id_set(handle, cmd, SPECTRUM_SWID, trap_id, trap_attributes_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def host_ifc_configure_user_def_trap(handle, trap_group, trap_id, key_type, key_list):
    # compose the user defined key attributes for given Trap ID
    host_ifc_configure_user_defined_trap_key(handle, SX_ACCESS_CMD_ADD, trap_id, key_type, key_list)
    # Associate trap group,trap ID and set action for Trap ID
    host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, trap_id, trap_group)
    # register channel to receive traps
    user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, trap_id, None, fd)

    return user_channel


if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("User defined extended traps are not available on SPC")
        sys.exit(0)

    # open the file descriptor
    fd = host_ifc_open(handle)
    # create trap group
    trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    trap_group = host_ifc_trap_group_set(handle, trap_group_set_cmd, TRAP_GROUP)

    # these two lists are used to save info for a later de-configuration
    trap_id_list = []
    user_channel_list = []

    # EthType example, Match on Non IP Ether types
    trap_id = SX_TRAP_ID_USER_CONF_SWITCH0
    key_type = SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E
    tunnel_id = 0
    tunnel_valid = False
    ether_type = ETHERTYPE_ARP
    ether_type_valid = True
    key_val_list = [ether_type, ether_type_valid, tunnel_id, tunnel_valid]
    user_channel = host_ifc_configure_user_def_trap(handle, trap_group, trap_id, key_type, key_val_list)
    trap_id_list.append(trap_id)
    user_channel_list.append(user_channel)

    # Match on IP Protos. TCP/UDP/ICMP/IGMP cannot be trapped with these key, Use L4/ICMP/IGMP keys.
    trap_id = SX_TRAP_ID_USER_CONF_SWITCH1
    key_type = SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E
    tunnel_id = 0
    tunnel_valid = False
    is_ipv4 = True
    is_ipv4_valid = True
    ip_proto = IP_PROTO_RDP
    is_ip_proto_valid = True
    key_val_list = [is_ipv4, is_ipv4_valid, ip_proto, is_ip_proto_valid, tunnel_id, tunnel_valid]
    user_channel = host_ifc_configure_user_def_trap(handle, trap_group, trap_id, key_type, key_val_list)
    trap_id_list.append(trap_id)
    user_channel_list.append(user_channel)

    # Match on IPtype and ICMP type attributes
    trap_id = SX_TRAP_ID_USER_CONF_SWITCH2
    key_type = SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E
    tunnel_id = 0
    tunnel_valid = False
    is_ipv4 = True
    is_ipv4_valid = True
    min_icmp_type = 0
    max_icmp_type = 255
    key_val_list = [is_ipv4, is_ipv4_valid, min_icmp_type, max_icmp_type, tunnel_id, tunnel_valid]
    user_channel = host_ifc_configure_user_def_trap(handle, trap_group, trap_id, key_type, key_val_list)
    trap_id_list.append(trap_id)
    user_channel_list.append(user_channel)

    # Match on IGMP type attributes
    trap_id = SX_TRAP_ID_USER_CONF_SWITCH3
    key_type = SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E
    tunnel_id = 0
    tunnel_valid = False
    min_igmp_type = 0
    max_igmp_type = 255
    key_val_list = [min_igmp_type, max_igmp_type, tunnel_id, tunnel_valid]
    user_channel = host_ifc_configure_user_def_trap(handle, trap_group, trap_id, key_type, key_val_list)
    trap_id_list.append(trap_id)
    user_channel_list.append(user_channel)

    if args.deinit:
        for trap_id, user_channel in zip(trap_id_list, user_channel_list):
            # unregister channel
            host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, trap_id, user_channel, None)
            # remove Trap ID, trap group association and set trap ID action to FW DEFAULT
            host_ifc_trap_id_set(handle, SX_ACCESS_CMD_UNSET, trap_id, trap_group)
            # Delete the key associated with the Trap ID
            host_ifc_configure_user_defined_trap_key(handle, SX_ACCESS_CMD_DELETE, trap_id, 0, None)

        host_ifc_trap_group_set(handle, trap_group_unset_cmd, trap_group)

    # close the file descriptor
    host_ifc_close(handle, fd)

    sx_api_close(handle)
