#!/usr/bin/env python

import sys

import time
import os
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sxd_api_mpilm example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] MPILM register access test start")
print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init failed rc: %d" % (rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

mpilm = ku_mpilm_reg()

mpilm.op = 0
mpilm.label_space = 1
mpilm.label_id = 200
mpilm.nhlfe_ptr = 0
mpilm.npop = 0
mpilm.ecmp_size = 64
mpilm.trap_action = 0
mpilm.trap_id = 1
mpilm.counter_set.type = SXD_COUNTER_SET_TYPE_NO_COUNT
mpilm.counter_set.index = 0

print("[+] Set MPILM content")
print("====================")
print("[+] op: ", mpilm.op)
print("[+] label_space: ", mpilm.label_space)
print("[+] label_id: ", mpilm.label_id)
print("[+] nhlfe_ptr: ", mpilm.nhlfe_ptr)
print("[+] npop: ", mpilm.npop)
print("[+] ecmp_size: ", mpilm.ecmp_size)
print("[+] trap_action: ", mpilm.trap_action)
print("[+] trap_id: ", mpilm.trap_id)
print("[+] counter_set_type: ", mpilm.counter_set.type)
print("[+] counter_index: ", mpilm.counter_set.index)

print("[+] Set MPILM ")
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_mpilm(mpilm, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set MPILM register, rc: %d" % (rc)

print("[+] Get MPILM")
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_mpilm(mpilm, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get MPILM register, rc: %d" % (rc)

print("[+] Get after Set MPILM content")
print("====================")
print("[+] op: ", mpilm.op)
print("[+] label_space: ", mpilm.label_space)
print("[+] label_id: ", mpilm.label_id)
print("[+] nhlfe_ptr: ", mpilm.nhlfe_ptr)
print("[+] npop: ", mpilm.npop)
print("[+] ecmp_size: ", mpilm.ecmp_size)
print("[+] trap_action: ", mpilm.trap_action)
print("[+] trap_id: ", mpilm.trap_id)
print("[+] counter_set_type: ", mpilm.counter_set.type)
print("[+] counter_index: ", mpilm.counter_set.index)

if args.deinit:
    mpilm.op = 3  # 3 for delete operation
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_mpilm(mpilm, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MPILM register, rc: %d" % (rc)

    print("[+] MPILM register access test end")

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
