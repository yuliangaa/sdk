#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='sxd_api_i2c example')
parser.add_argument('--cmd', default='w', choices=['w', 'r'], help='Choose command; w for write, r for read.')
parser.add_argument('--log_port', default=2, type=int, help="log_port")
parser.add_argument('--i2c_addr', default=0x40, type=int, help="i2c_addr")
parser.add_argument('--dev_addr', default=0x1, type=int, help="dev_addr")
parser.add_argument('--data', default=0x1234, type=int, help="data")
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

args = parser.parse_args()


def usage():
    print("For write ./sxd_api_i2c.py w log_port i2c_addr dev_addr data")
    print("Example   ./sxd_api_i2c.py w   2        0x40   0x1  0x1234")
    print("For read ./sxd_api_i2c.py r log_port i2c_addr dev_addr")
    print("Example  ./sxd_api_i2c.py r   2        0x40   0x1")


def sxd_i2c_reg_write(port, i2c_dev_address, reg, data):

    print("Writing Data to Port %d, i2c Address 0x%02X, Device Address 0x%02X, Data 0x%04X\n" % (port, i2c_dev_address, reg, data))

    mcia = ku_mcia_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_SET

    mcia.module = port - 1
    mcia.page_number = 0
    mcia.i2c_device_address = i2c_dev_address
    mcia.device_address = reg
    mcia.size = 2
    mcia.dword_0 = (data << 16) & 0xFFFF0000

    rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)


def sxd_i2c_reg_read(port, i2c_dev_address, reg):

    print("Reading Data from Port %d, i2c Address 0x%02X, Device Address 0x%02X\n" % (port, i2c_dev_address, reg))

    mcia = ku_mcia_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    mcia.page_number = 0
    mcia.module = port - 1
    mcia.i2c_device_address = i2c_dev_address
    mcia.device_address = reg
    mcia.size = 2

    rc = sxd_access_reg_mcia(mcia, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read MCIA register, rc: %d" % (rc)
    print("[+] dword0 : 0x%08x" % (mcia.dword_0))

    return mcia


def main():

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    log_port = args.log_port
    i2c = args.i2c_addr
    reg = args.dev_addr

    if args.cmd == 'w':
        data = args.data

        # Save for later de-configuration
        original_data = sxd_i2c_reg_read(log_port, i2c, reg)

        sxd_i2c_reg_write(log_port, i2c, reg, data)

        if args.deinit:
            print("Deinit")

            meta = sxd_reg_meta_t()
            meta.dev_id = 1
            meta.swid = 0
            meta.access_cmd = SXD_ACCESS_CMD_SET

            rc = sxd_access_reg_mcia(original_data, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set MCIA register, rc: %d" % (rc)

    elif args.cmd == 'r':
        sxd_i2c_reg_read(log_port, i2c, reg)

    else:
        usage()
        sys.exit(1)

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    main()
