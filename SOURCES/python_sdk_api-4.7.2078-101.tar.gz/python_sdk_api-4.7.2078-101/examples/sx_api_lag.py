#!/usr/bin/env python
"""
This file contains a python commands example for the LAG module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configuration operations:
1. Configures the fields which impact the LAG hash distribution function.
2. Creates a new LAG.
3. Adds 2 ports to the above LAG.
4. Enables collection on a specific port in a LAG port.
5. Retrieves the collection mode of a specific port in a LAG port.
6. Enables and disables distribution on a specific port in a LAG port.
7. Retrieves the distribution mode of a specific port in a LAG port.
8. Retrieves the above mentioned LAG information.
9. Deletes 2 ports from the above mentioned LAG.
10. Destroys the LAG.
"""

import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_lag example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]
PORT_2 = port_list[1]
INGRESS_PORT = port_list[2]


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def get_port_lag_hash_param(port):
    lag_hash_params_p = new_sx_lag_port_hash_params_t_p()
    hash_field_enable_list_cnt_p = new_uint32_t_p()
    hash_field_list_cnt_p = new_uint32_t_p()

    rc = sx_api_lag_port_hash_flow_params_get(
        handle, port, lag_hash_params_p, None, hash_field_enable_list_cnt_p, None, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    field_enable_cnt = uint32_t_p_value(hash_field_enable_list_cnt_p)
    field_cnt = uint32_t_p_value(hash_field_list_cnt_p)

    # Get actual values based on count
    hash_field_list_p = new_sx_lag_hash_field_t_arr(field_cnt)
    hash_field_enable_list_p = new_sx_lag_hash_field_enable_t_arr(field_enable_cnt)

    rc = sx_api_lag_port_hash_flow_params_get(handle, port, lag_hash_params_p, hash_field_enable_list_p,
                                              hash_field_enable_list_cnt_p, hash_field_list_p,
                                              hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    return lag_hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt


def set_port_lag_hash_param(port, cmd):
    port_lag_hash_field_en_set_arr = new_sx_lag_hash_field_enable_t_arr(2)
    port_lag_hash_field_set_arr = new_sx_lag_hash_field_t_arr(4)
    port_lag_hash_type_params = sx_lag_port_hash_params_t()
    port_lag_hash_type_params_p = new_sx_lag_port_hash_params_t_p()
    num_hdr_enables_cnt = 2
    num_fields_cnt = 4

    port_lag_hash_type_params.is_lag_hash_symmetric = False
    port_lag_hash_type_params.lag_hash_type = SX_LAG_HASH_TYPE_XOR
    port_lag_hash_type_params.lag_seed = 0

    sx_lag_port_hash_params_t_p_assign(port_lag_hash_type_params_p,
                                       port_lag_hash_type_params)

    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 0,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4)
    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 1,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP)

    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 0, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_0)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 1, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_1)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 2, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_2)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 3, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_3)

    rc = sx_api_lag_port_hash_flow_params_set(handle, cmd,
                                              port, port_lag_hash_type_params_p,
                                              port_lag_hash_field_en_set_arr, num_hdr_enables_cnt,
                                              port_lag_hash_field_set_arr, num_fields_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)


# 0. Get original RSTP States of used ports - They change during lag operations
original_rstp_modes = {}
stp_state_p = new_sx_mstp_inst_port_state_t_p()
for port in [PORT_1, PORT_2]:
    rc = sx_api_rstp_port_state_get(handle, port, stp_state_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_get failed, port 0x%x, rc: %d" % (port, rc)
    original_rstp_modes[port] = sx_mstp_inst_port_state_t_p_value(stp_state_p)
delete_sx_mstp_inst_port_state_t_p(stp_state_p)

# 1. Configures the fields which impact the LAG hash distribution function.
# lag_hash_param = sx_lag_hash_param_t()
# lag_hash_param.lag_hash_type = SX_LAG_HASH_TYPE_XOR
# lag_hash_param.lag_hash = 0xA
# lag_hash_param.lag_seed = 0
# rc = sx_api_lag_hash_flow_params_set(handle, lag_hash_param)
# assert rc == SX_STATUS_SUCCESS, "sx_api_lag_hash_flow_params_set failed, rc: %d" % (rc)
# print(("sx_api_lag_hash_flow_params_set , type %d , rc %d " % (lag_hash_param.lag_hash_type, rc)))
print("Setting lag_port_hash_flow_params per port. NOTE That instead you can use legacy global API 'sx_api_lag_hash_flow_params_set'\n"
      "(an example is commented above), which sets lag hash globally. Note also that once the new API is called\n"
      "legacy API is disabled.")
# Save port lag hash params for later de-configuration
lag_hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt = get_port_lag_hash_param(INGRESS_PORT)

# Sets a new lag hash on port
set_port_lag_hash_param(INGRESS_PORT, SX_ACCESS_CMD_SET)

# 2. Creates a new LAG.
swid = 0
lag_id_p = new_sx_port_log_id_t_p()
rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed, rc: %d" % (rc)
lag_id = sx_port_log_id_t_p_value(lag_id_p)
print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d" % (rc)
print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))

# 3. Adds 2 ports to the above LAG.
swid = 0
port_list = new_sx_port_log_id_t_arr(2)
sx_port_log_id_t_arr_setitem(port_list, 0, PORT_1)
sx_port_log_id_t_arr_setitem(port_list, 1, PORT_2)
rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_id_p, port_list, 2)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed, rc: %d" % (rc)
print(("sx_api_lag_port_group_set ADD ports 0x%x, 0x%x to lag_id 0x%x , rc %d " % (PORT_1, PORT_2, lag_id, rc)))

# 4. Enables collection on a specific port in a LAG port.
log_port = PORT_2
col_state = COLLECTOR_ENABLE
rc = sx_api_lag_port_collector_set(handle, lag_id, log_port, col_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_collector_set failed, rc: %d" % (rc)
print(("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, col_state, rc)))

# 5. Retrieves the collection mode of a specific port in a LAG port.
log_port = PORT_2
col_state_p = new_sx_collector_mode_t_p()
rc = sx_api_lag_port_collector_get(handle, lag_id, log_port, col_state_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_collector_get failed, rc: %d" % (rc)
col_state = sx_collector_mode_t_p_value(col_state_p)
print(("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, col_state, rc)))

# 6. Enables and disables distribution on a specific port in a LAG port.
log_port = PORT_2
distr_state = DISTRIBUTOR_ENABLE
rc = sx_api_lag_port_distributor_set(handle, lag_id, log_port, distr_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_distributor_set failed, rc: %d" % (rc)
print(("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, distr_state, rc)))

# 6. Enables and disables distribution on a specific port in a LAG port.
distr_state = DISTRIBUTOR_DISABLE
rc = sx_api_lag_port_distributor_set(handle, lag_id, log_port, distr_state)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_distributor_set failed, rc: %d" % (rc)
print(("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, distr_state, rc)))

# 7. Retrieves the distribution mode of a specific port in a LAG port.
log_port = PORT_2
distr_state_p = new_sx_distributor_mode_t_p()
rc = sx_api_lag_port_distributor_get(handle, lag_id, log_port, distr_state_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_distributor_get failed, rc: %d" % (rc)
distr_state = sx_distributor_mode_t_p_value(distr_state_p)
print(("sx_api_lag_port_distributor_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, distr_state, rc)))

# 8. Retrieves the above mentioned LAG information.
swid = 0
#port_list = new_sx_port_log_id_t_arr(2)
sx_port_log_id_t_arr_setitem(port_list, 0, 0)
sx_port_log_id_t_arr_setitem(port_list, 1, 0)
port_list_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_list_cnt_p, 2)
rc = sx_api_lag_port_group_get(handle, swid, lag_id, port_list, port_list_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_get failed, rc: %d" % (rc)
port_list_cnt = uint32_t_p_value(port_list_cnt_p)
log_port0 = sx_port_log_id_t_arr_getitem(port_list, 0)
log_port1 = sx_port_log_id_t_arr_getitem(port_list, 1)
print(("sx_api_lag_port_group_get %d ports 0x%x, 0x%x belong to lag_id 0x%x , rc %d " % (port_list_cnt, log_port0, log_port1, lag_id, rc)))

# 9. Set distribution list to 2 ports
fg_params = sx_lag_fine_grain_params_t()
fg_params.resolution = 512
fg_params_p = new_sx_lag_fine_grain_params_t_p()
sx_lag_fine_grain_params_t_p_assign(fg_params_p, fg_params)
fg_port_cnt = 2
fg_port_list = new_sx_lag_fine_grain_member_t_arr(fg_port_cnt)
fg_port = sx_lag_fine_grain_member_t()
fg_port.log_port = PORT_1
fg_port.weight = 10
sx_lag_fine_grain_member_t_arr_setitem(fg_port_list, 0, fg_port)
fg_port.log_port = PORT_2
fg_port.weight = 20
sx_lag_fine_grain_member_t_arr_setitem(fg_port_list, 1, fg_port)

rc = sx_api_lag_distributer_list_set(handle, SX_ACCESS_CMD_SET, lag_id, fg_params_p, fg_port_list, fg_port_cnt)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_distributer_list_set failed, rc: %d" % (rc)
print(("sx_api_lag_distributer_list_set (SET), lag_id 0x%x, rc %d " % (lag_id, rc)))

fgl_port_cnt_p = copy_uint32_t_p(0)
rc = sx_api_lag_distributer_list_get(handle, lag_id, fg_params_p, None, fgl_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_lag_distributer_list_get failed, rc: %d" % (rc)
sdk_count = uint32_t_p_value(fgl_port_cnt_p)
assert sdk_count == 2, "sx_api_lag_distributer_list_get (GET), with assign (0) lag_id = {:x}, port cnt = {}  ".format(lag_id, sdk_count)
print("sx_api_lag_distributer_list_get (GET), lag_id = 0x{:x}, port list cnt = {}  ".format(lag_id, sdk_count))

if args.deinit:
    # 10, Deletes 2 ports from the above mentioned LAG.
    swid = 0
    sx_port_log_id_t_arr_setitem(port_list, 0, PORT_1)
    sx_port_log_id_t_arr_setitem(port_list, 1, PORT_2)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_id_p, port_list, 2)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed, rc: %d" % (rc)
    print(("sx_api_lag_port_group_set DELETE ports 0x%x, 0x%x from lag_id 0x%x , rc %d " % (PORT_1, PORT_2, lag_id, rc)))

    # 11 Deletes distributer
    rc = sx_api_lag_distributer_list_set(handle, SX_ACCESS_CMD_DELETE_ALL, lag_id, None, None, 0)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_distributer_list_set failed, rc: %d" % (rc)
    print(("sx_api_lag_distributer_list_set (DELETE_ALL), lag_id 0x%x, rc %d " % (lag_id, rc)))

    # 12. Destroys the LAG.
    swid = 0
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, swid, lag_id_p, None, 0)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed, rc: %d" % (rc)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc)))

    # 13. Reset origin lag hash of port
    rc = sx_api_lag_port_hash_flow_params_set(handle, SX_ACCESS_CMD_SET,
                                              INGRESS_PORT, lag_hash_params_p, hash_field_enable_list_p,
                                              field_enable_cnt, hash_field_list_p, field_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)

    # 14. Add LAG Ports back to default vlan
    add_ports_to_vlan(1, {PORT_1: SX_UNTAGGED_MEMBER, PORT_2: SX_UNTAGGED_MEMBER})

    # 15. Restore vlan filter ingress on ports
    for port in [PORT_1, PORT_2]:
        rc = sx_api_vlan_port_ingr_filter_set(handle, port, SX_INGR_FILTER_ENABLE)
        assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)

    for port, rstp_state in original_rstp_modes.items():
        rc = sx_api_rstp_port_state_set(handle, port, rstp_state)
        assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, port 0x%x, rc: %d" % (port, rc)


# cleanup allocated objects
delete_sx_port_log_id_t_p(lag_id_p)
delete_sx_port_log_id_t_arr(port_list)
delete_sx_collector_mode_t_p(col_state_p)
delete_sx_lag_fine_grain_params_t_p(fg_params_p)
delete_sx_lag_fine_grain_member_t_arr(fg_port_list)
delete_uint32_t_p(fgl_port_cnt_p)

sx_api_close(handle)
