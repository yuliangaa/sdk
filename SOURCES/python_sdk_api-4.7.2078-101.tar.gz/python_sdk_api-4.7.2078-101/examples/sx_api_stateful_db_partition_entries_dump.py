#!/usr/bin/env python
'''
This file contains Python command example that dump stateful DB partition entries
This example is supported on Spectrum4 and later devices.
'''
import sys
import os
from python_sdk_api.sx_api import *
import test_infra_common
import flex_acl_common
import argparse


def parse_args():
    description_str = """
    This file contains Python command example that dump stateful DB partition entries
    This example is supported on Spectrum4 and later devices.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--partition_id", type=int, default=1, help="Partition ID to dump its entries, range is [0-7]. Default is [%(default)d]")
    parser.add_argument("--entries_num", type=int, help="Number of entries to dump. If not set, use partition max size")
    return parser.parse_args()


def stateful_db_set_verbosity(handle, module, api):
    rc = sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module, api)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to set stateful DB API log verbosity level")
        sys.exit(rc)


def partition_size_get(handle, partition_id):
    # Get original verbosity
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    rc = sx_api_stateful_db_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to retrieve stateful DB module verbosity")
        sys.exit(rc)

    orig_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    orig_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)
    delete_sx_verbosity_level_t_p(module_verbosity_level_p)
    delete_sx_verbosity_level_t_p(api_verbosity_level_p)

    # Set None verbosity
    stateful_db_set_verbosity(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

    exit_example = False

    # Get partition max size.
    # In API can fail on module not initialized or partition not allocated.
    # Both are consider good flow for this examples - No partition -> no entries to dump.
    partition_status_p = new_sx_stateful_db_partition_status_t_p()
    rc = sx_api_stateful_db_partition_get(handle, SX_ACCESS_CMD_GET, partition_id, partition_status_p)
    if rc == SX_STATUS_MODULE_UNINITIALIZED:
        print("Stateful DB module is not initialized")
        rc = SX_STATUS_SUCCESS
        exit_example = True
    elif rc == SX_STATUS_PARAM_ERROR:
        print("Partition ID {} is not set".format(partition_id))
        rc = SX_STATUS_SUCCESS
        exit_example = True
    elif rc != SX_STATUS_SUCCESS:
        print("Failed in stateful DB partition get, rc = {}".format(test_infra_common.sx_status_dict[rc]))
        exit_example = True

    partition_status = sx_stateful_db_partition_status_t_p_value(partition_status_p)
    delete_sx_stateful_db_partition_status_t_p(partition_status_p)

    # Restore original verbosity
    stateful_db_set_verbosity(handle, orig_module_level, orig_api_level)

    if exit_example:
        sys.exit(rc)

    return partition_status.partition_cfg.max_size


def host_ifc_fd_open(handle, uc_p):
    fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, fd_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open FD. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)

    uc_p.type = SX_USER_CHANNEL_TYPE_FD
    uc_p.channel.fd = fd_p
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, SPECTRUM_SWID, SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, uc_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to register to bulk counter done event. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)
    return fd_p


def host_ifc_fd_close(handle, uc_p):
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, SPECTRUM_SWID, SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, uc_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to de-register from bulk counter done event. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)

    rc = sx_api_host_ifc_close(handle, uc_p.channel.fd)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to close FD. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)


def wait_for_bulk_counter_done(fd_p):
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)
    pkt = new_uint8_t_arr(pkt_size)
    recv_info_p = new_sx_receive_info_t_p()

    rc = sx_lib_host_ifc_recv(fd_p, pkt, pkt_size_p, recv_info_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to receive BULK COUNTER DONE event. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)
    else:
        print("[+] Received BULK COUNTER DONE event, status {}".format(test_infra_common.bulk_cntr_done_status_str_dict[recv_info_p.event_info.bulk_cntr_done_info.status]))


def bulk_counter_buffer_set(handle, partition_id, entries_num_max):
    cntr_buffer_p = new_sx_bulk_cntr_buffer_t_p()
    key_p = new_sx_bulk_cntr_buffer_key_t_p()
    key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    key_p.key.stateful_db_key.key_id_filter_valid = False
    key_p.key.stateful_db_key.activity_filter_valid = False
    key_p.key.stateful_db_key.sem_lock_filter_valid = False
    key_p.key.stateful_db_key.entries_num_max = entries_num_max
    key_p.key.stateful_db_key.partition_id = partition_id
    rc = sx_api_bulk_counter_buffer_set(handle, SX_ACCESS_CMD_CREATE, key_p, cntr_buffer_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to allocate buffer. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)
    delete_sx_bulk_cntr_buffer_key_t_p(key_p)
    return cntr_buffer_p


def acl_key_data_to_str(acl_data_item):
    acl_key_data = sx_flex_acl_key_desc_t()
    acl_key_data.key_id = acl_data_item.key_id
    acl_key_data.key = acl_data_item.key_value

    key_value, key_mask = flex_acl_common.get_key_val_mask_str(acl_key_data)
    if acl_key_data.key_id in flex_acl_common.key_type_dict:
        key_type = flex_acl_common.key_type_dict[acl_key_data.key_id]
    else:
        key_type = "Unknown"
    return key_type, key_value


def partition_entries_dump(handle, cntr_buffer_p):
    counter_data_p = new_sx_bulk_cntr_data_t_p()
    read_key_p = new_sx_bulk_cntr_read_key_t_p()
    read_key_p.type = SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E
    read_key_p.key.stateful_db_key.type = SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_NUM_ENTRIES_GET_E
    print("[+] Get total number of entries")
    rc = sx_api_bulk_counter_transaction_get(handle, read_key_p, cntr_buffer_p, counter_data_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to get total number of entries. rc = {}".format(test_infra_common.sx_status_dict[rc]))
        sys.exit(rc)

    number_of_entries = counter_data_p.data.stateful_db_entry_data.stateful_db_entries_num_p.entries_num
    print("[+] Partition ID {} have {} entries".format(cntr_buffer_p.key.key.stateful_db_key.partition_id, number_of_entries))

    read_key_p.key.stateful_db_key.type = SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_ENTRY_DATA_GET_E
    for i in range(number_of_entries):
        print("-" * 100)
        print("Entry index:      {} ".format(i))
        read_key_p.key.stateful_db_key.read_key.entry_access.entry_index = i
        rc = sx_api_bulk_counter_transaction_get(handle, read_key_p, cntr_buffer_p, counter_data_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to get entry number {}. rc = {}".format(i, test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        counter_data = sx_bulk_cntr_data_t_p_value(counter_data_p)
        print("Entry value:      {}".format(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.db_entry_data.db_entry_value))
        print("Activity:         {}".format(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.db_entry_meta.entry_activity))
        print("Semaphore status: {}".format(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.db_entry_meta.entry_sem_status))
        print("Semaphore count:  {}".format(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.db_entry_meta.entry_sem_cnt))
        print("Key ID:           {}".format(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.key_id))
        print("Key description:")
        table_format = "{:<5}     {:<35} {:<35}"
        print(table_format.format("key #", "ACL key ID", "ACL key value"))
        print(table_format.format("-----", "----------", "-------------"))
        for j in range(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.key_data.acl_data.key_data_list_cnt):
            acl_key = sx_stateful_db_acl_key_data_t_arr_getitem(counter_data.data.stateful_db_entry_data.stateful_db_entry_p.key_data.acl_data.key_data_list_p, j)
            key_type, key_value = acl_key_data_to_str(acl_key)
            print(table_format.format(j, key_type, key_value))
    print("-" * 100)


def main():
    args = parse_args()
    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    # Open Handle
    print("[+] Open SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    uc_p = None

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("This example doesn't support below Spectrum4 - Exiting gracefully")
            sys.exit(0)

        # Validate partition ID exists and get partition max size
        entries_num_max = partition_size_get(handle, args.partition_id)
        if args.entries_num is not None:
            entries_num_max = args.entries_num

        # Open FD
        print("[+] Open FD")
        uc_p = new_sx_user_channel_t_p()
        fd_p = host_ifc_fd_open(handle, uc_p)

        # Allocate bulk buffer
        print("[+] Open Allocate bulk buffer")
        cntr_buffer_p = bulk_counter_buffer_set(handle, args.partition_id, entries_num_max)

        # Start transaction
        print("[+] Start transaction")
        rc = sx_api_bulk_counter_transaction_set(handle, SX_ACCESS_CMD_READ, cntr_buffer_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to start transaction. rc = {}".format(test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)

        # Wait for DONE event
        print("[+] Wait for DONE event")
        wait_for_bulk_counter_done(fd_p)

        # Dump partition entries
        print("[+] Dump partition entries")
        partition_entries_dump(handle, cntr_buffer_p)

        # Destroy buffer
        rc = sx_api_bulk_counter_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, cntr_buffer_p)
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to destroy buffer. rc = {}".format(test_infra_common.sx_status_dict[rc]))

        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer_p)
        print("SUCCESS")
    finally:
        if uc_p is not None:
            # Close FD
            host_ifc_fd_close(handle, uc_p)
            delete_sx_user_channel_t_p(uc_p)

        print("[+] Close SDK")
        sx_api_close(handle)


if __name__ == "__main__":
    SPECTRUM_SWID = 0
    sys.exit(main())
