#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of rate for 8x lanes port.
logic of the example is the following:
- Reset port API type usage
- Get the current port mapping configurations
- Reset port API type usage
'''


import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1
MAX_PORTS = 64


cmd_dict = {
    "ADD": SX_ACCESS_CMD_ADD,
    "SET": SX_ACCESS_CMD_SET,
    "DELETE": SX_ACCESS_CMD_DELETE,
    "DELETE_ALL": SX_ACCESS_CMD_DELETE_ALL,
    "add": SX_ACCESS_CMD_ADD,
    "set": SX_ACCESS_CMD_SET,
    "delete": SX_ACCESS_CMD_DELETE,
    "delete_all": SX_ACCESS_CMD_DELETE_ALL,
    "1": SX_ACCESS_CMD_ADD,
    "15": SX_ACCESS_CMD_SET,
    "3": SX_ACCESS_CMD_DELETE,
    "4": SX_ACCESS_CMD_DELETE_ALL,
}


def print_params(handle, cmd, egress_port, ingress_ports):
    print("---------------- Parameters --------------------")
    print("Cmd: %s (%d)" % (cmd, cmd_dict[cmd]))
    print("Egress port: 0x%x" % egress_port)
    if cmd_dict[cmd] != SX_ACCESS_CMD_DELETE_ALL:
        print("Ingress ports:", ingress_ports)


def ports_arr_to_list(ingress_ports_arr, ingress_ports_cnt):
    ports_list = []
    for i in range(ingress_ports_cnt):
        port = sx_port_log_id_t_arr_getitem(ingress_ports_arr, i)
        ports_list.append(port)
    return ports_list


def check_correctness(cmd, old_ports_list, new_ports_list, ingress_ports):
    assert len(new_ports_list) == len(set(new_ports_list)), "Test failed. port_isolate_get not as expected"

    if cmd_dict[cmd] == SX_ACCESS_CMD_SET:
        assert set(new_ports_list) == set(ingress_ports), "Test failed. port_isolate_get not as expected"

    elif cmd_dict[cmd] == SX_ACCESS_CMD_ADD:
        assert set(new_ports_list) == set(old_ports_list).union(set(ingress_ports)), "Test failed. port_isolate_get not as expected"

    elif cmd_dict[cmd] == SX_ACCESS_CMD_DELETE:
        assert set(new_ports_list) == set(old_ports_list).difference(set(ingress_ports)), "Test failed. port_isolate_get not as expected"

    elif cmd_dict[cmd] == SX_ACCESS_CMD_DELETE_ALL:
        assert len(new_ports_list) == 0, "Test failed. port_isolate_get not as expected"


def port_isolate_get(handle, egress_port):
    print("-----------------  Calling 'port_isolate_get' with the inserted egress port -----------------")
    try:
        ingress_ports_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(ingress_ports_cnt_p, MAX_PORTS)

        ingress_ports_arr = new_sx_port_log_id_t_arr(MAX_PORTS)
        for i in range(MAX_PORTS):
            sx_port_log_id_t_arr_setitem(ingress_ports_arr, i, 0)

        rc = sx_api_port_isolate_get(handle, egress_port, ingress_ports_arr, ingress_ports_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_get failed. [%d]" % rc

        ingress_ports_cnt = uint32_t_p_value(ingress_ports_cnt_p)
        ports_list = ports_arr_to_list(ingress_ports_arr, ingress_ports_cnt)

        print("Returned values of port_isolate_get:")
        print("    Ingress ports cnt: %d" % (ingress_ports_cnt))
        print("    Ingress ports:", ports_list)
    finally:
        delete_uint32_t_p(ingress_ports_cnt_p)
        delete_sx_port_log_id_t_arr(ingress_ports_arr)
    return ports_list


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_isolation_set API\n-----------------------------------------')
    parser.add_argument('--cmd', type=str, choices=list(cmd_dict.keys()), default="SET",
                        help='Command: ADD|SET|DELETE|DELETE_ALL. if not inserted, script will use SET command')
    parser.add_argument('--egress_port', type=auto_int, default=0x10001, help='Insert egress port. if not inserted, script will use a default choice')
    parser.add_argument('--ingress_ports', type=auto_int, nargs='+', default=None, help='Insert ingress ports. if not inserted, script will use a default choice')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    if not args.force:
        print_modification_warning()

    return args.cmd, args.egress_port, args.ingress_ports, args.deinit


def main():
    print_api_example_disclaimer()

    cmd, egress_port, ingress_ports, deinit = parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        if not ingress_ports:
            ingress_ports = get_ports(handle, 3)
            if egress_port in ingress_ports:
                ingress_ports.remove(egress_port)

        ingress_ports_arr = new_sx_port_log_id_t_arr(MAX_PORTS)
        ingress_ports_cnt = MAX_PORTS

        if cmd_dict[cmd] != SX_ACCESS_CMD_DELETE_ALL:
            for i, port in enumerate(ingress_ports):
                sx_port_log_id_t_arr_setitem(ingress_ports_arr, i, port)
            ingress_ports_cnt = len(ingress_ports)

        old_ports_list = port_isolate_get(handle, egress_port)

        print_params(handle, cmd, egress_port, ingress_ports)

        print("-----------------  Calling 'port_isolate_set' with the inserted parameters -----------------")
        rc = sx_api_port_isolate_set(handle, cmd_dict[cmd], egress_port, ingress_ports_arr, ingress_ports_cnt)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_set failed. [%d]" % rc
        print("----------------------------------  port_isolate_set done  ----------------------------------")

        new_ports_list = port_isolate_get(handle, egress_port)

        check_correctness(cmd, old_ports_list, new_ports_list, ingress_ports)

        if deinit:
            rc = sx_api_port_isolate_set(handle, SX_ACCESS_CMD_DELETE_ALL, egress_port, ingress_ports_arr, ingress_ports_cnt)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_set failed. [%d]" % rc

        sx_api_close(handle)

    finally:
        delete_sx_port_log_id_t_arr(ingress_ports_arr)

    print("Success.")


if __name__ == "__main__":
    sys.exit(main())
