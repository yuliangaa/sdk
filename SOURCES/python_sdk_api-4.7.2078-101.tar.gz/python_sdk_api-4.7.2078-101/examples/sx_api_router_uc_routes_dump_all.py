#!/usr/bin/env python
'''
This file contains Python command example for the ALL ROUTE DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

Usage:
sx_api_router_uc_routes_dump_all.py <num of virtual routers to dump>

default virtual routers num is 12
'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
from flex_acl_common import router_module_verbosity_level_get, router_module_verbosity_level_set

ip_dict = {0: 'NONE', 1: 'IPV4', 2: 'IPV6'}
action_dict = {0: 'DROP', 1: 'TRAP', 2: 'FORWARD', 3: 'TRAP_FORWARD', 4: 'SPAN'}
type_dict = {0: 'NEXT_HOP', 1: 'LOCAL', 2: 'IP2ME'}
trap_prio_dict = {0: 'BEST_EFFORT', 1: 'LOW', 2: 'MED', 3: 'HIGH', 4: 'CRITICAL'}

print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

uc_route_arr = new_sx_uc_route_get_entry_t_arr(128)
network_addr_p = new_sx_ip_prefix_t_p()
network_addr = sx_ip_prefix_t()
data_cnt_p = new_uint32_t_p()
vrid_cnt_p = new_uint32_t_p()
uint32_t_p_assign(vrid_cnt_p, 0)
vrid_key_p = new_sx_router_id_t_p()
sx_router_id_t_p_assign(vrid_key_p, 0)
vrid_key = sx_router_id_t_p_value(vrid_key_p)
vrid_cnt = 0
module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
rc = sx_api_router_vrid_iter_get(handle, SX_ACCESS_CMD_GET, vrid_key, None, None, vrid_cnt_p)
router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
if rc == SX_STATUS_MODULE_UNINITIALIZED:
    print("The router module is not initialized. Dump is not available.")
elif rc != SX_STATUS_SUCCESS:
    print("sx_api_router_vrid_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
else:
    vrid_cnt = uint32_t_p_value(vrid_cnt_p)
    vrid_list_p = new_sx_router_id_t_arr(vrid_cnt)
    rc = sx_api_router_vrid_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, vrid_key, None, vrid_list_p, vrid_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_router_vrid_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    vrid_cnt = uint32_t_p_value(vrid_cnt_p)


def get_all_routes_of_vrid(vrid, version):
    routes = []
    uint32_t_p_assign(data_cnt_p, 128)
    if version == SX_IP_VERSION_IPV4:
        network_addr.version = SX_IP_VERSION_IPV4
        network_addr.prefix.ipv4.addr.s_addr = 0
    else:
        network_addr.version = SX_IP_VERSION_IPV6
        for i in range(0, 15):
            uint8_t_arr_setitem(network_addr.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, 0)

    sx_ip_prefix_t_p_assign(network_addr_p, network_addr)
    rc = sx_api_router_uc_route_get(handle, SX_ACCESS_CMD_GET_FIRST, vrid, network_addr_p, None, uc_route_arr, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        # check if router module initialize
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("####################################")
            print("# Router is not initialized ")
            print("####################################")
            sys.exit(0)
        sys.exit(rc)

    read_number = 0
    while (data_cnt == 128):
        for i in range(0, data_cnt):
            route = sx_uc_route_get_entry_t_arr_getitem(uc_route_arr, i)
            if route.network_addr.version == version:
                routes.append((vrid, route))

        sx_ip_prefix_t_p_assign(network_addr_p, route.network_addr)
        rc = sx_api_router_uc_route_get(handle, SX_ACCESS_CMD_GETNEXT, vrid, network_addr_p, None, uc_route_arr, data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("An error was found in sx_api_router_uc_route_get. rc: %d" % (rc))
            sys.exit(rc)
        data_cnt = uint32_t_p_value(data_cnt_p)
        read_number = read_number + 1

    for i in range(0, data_cnt):
        route = sx_uc_route_get_entry_t_arr_getitem(uc_route_arr, i)
        if route.network_addr.version == version:
            routes.append((vrid, route))

    return routes


def print_all_routes(version):
    routes = []
    for i in range(0, vrid_cnt):
        vrid = sx_router_id_t_arr_getitem(vrid_list_p, i)
        routes = routes + get_all_routes_of_vrid(vrid, version)

    if len(routes) > 0:
        print("\n-----------------------------------")
        if version == SX_IP_VERSION_IPV4:
            print("IPv4 UC Routes")
        else:
            print("IPv6 UC Routes")
        print("-----------------------------------\n")

        print("------------------------------------------------------------------------------------------------------------------------------------------------")
        print("|%10s|%40s|%10s|%15s|%15s|%15s|%15s|%15s|" % ("VRID", "IP", "Mask Len", "Type", "Action", "Trap Prio", "Eg. RIF", "ECMP ID"))
        print("------------------------------------------------------------------------------------------------------------------------------------------------")
        for entry in routes:
            vrid = entry[0]
            route = entry[1]
            ip = ip_prefix_to_str(route.network_addr)
            mask_length = mask_len(route.network_addr)
            type = type_dict[route.route_data.type]
            action = "N/A"
            if type == "NEXT_HOP" or type == "LOCAL":
                action = action_dict[route.route_data.action]
            trap_prio = "N/A"
            if action == "TRAP" or action == "TRAP_FORWARD":
                trap_prio = trap_prio_dict[route.route_data.trap_attr.prio]
            eg_rif = "N/A"
            if type == "LOCAL" and (action == "FORWARD" or action == "TRAP_FORWARD" or action == "SPAN"):
                eg_rif = str(route.route_data.uc_route_param.local_egress_rif)
            ecmp_id = "N/A"
            if type == "NEXT_HOP" and (action == "FORWARD" or action == "TRAP_FORWARD" or action == "SPAN"):
                ecmp_id = str(route.route_data.uc_route_param.local_egress_rif)
            print("|%10d|%40s|%10d|%15s|%15s|%15s|%15s|%15s|" % (vrid,
                                                                 ip,
                                                                 mask_length,
                                                                 type,
                                                                 action,
                                                                 trap_prio,
                                                                 eg_rif,
                                                                 ecmp_id))
            print("------------------------------------------------------------------------------------------------------------------------------------------------")


print_all_routes(SX_IP_VERSION_IPV4)
print_all_routes(SX_IP_VERSION_IPV6)

sx_api_close(handle)
