#!/usr/bin/env python

import sys
import errno
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
import test_infra_common as common_lib

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] reading SBIB register")
sbib = ku_sbib_reg()
sbib.type = 0
sbib.int_buff_index = 0

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

""" Set port buff size """
print("[+] SET SBIB PORT #3 ")
meta.access_cmd = SXD_ACCESS_CMD_SET
sbib.local_port, sbib.lp_msb = common_lib.get_lsb_msb_of_local_port(0x21)

sbib.buff_size = 240
"""sbib.buff_size = 0"""
"""sxd_access_reg_sbib(sbib, meta, 1, None, None)"""

""" Get max port number for the device """
meta.access_cmd = SXD_ACCESS_CMD_GET

rsrc = ku_query_rsrc()
rsrc.rsrc_id = KU_RES_ID_CAP_MAX_SWITCH_PORTS

sxd_access_reg_query_rsrc_info(rsrc)

MIN_PORT = 1
MAX_PORT = rsrc.rsrc_val


""" Get all port buff size for those ports whic hare enabled """
pspa = ku_pspa_reg()

for local_port in range(MIN_PORT, MAX_PORT):
    meta.swid = 0
    pspa.swid = 0

    pspa.local_port, pspa.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    rc = sxd_access_reg_pspa(pspa, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read PSPA register, rc: %d" % (rc)

    if pspa.swid == 0xFF:
        # swid (0xFF) is disabled port
        continue

    sbib.local_port, sbib.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    rc = sxd_access_reg_sbib(sbib, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read SBIB register, rc: %d" % (rc)

    print("P# ", local_port, ": Buff_size = ", sbib.buff_size)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
