#!/usr/bin/env python
'''
This file contains Python command example for the Vlan QinQ DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''

import sys
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_attributes_list = new_sx_port_attributes_t_arr(64)
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 64)

swid = 0
dev_id = 1

rc = sx_api_port_device_get(handle, dev_id, swid, port_attributes_list, port_cnt_p)
port_cnt = uint32_t_p_value(port_cnt_p)
if (rc != SX_STATUS_SUCCESS):
    print("An error was found in sx_api_port_device_get.\nThe example will exit")
    sys.exit(rc)

qinq_mode_p = new_sx_qinq_mode_t_p()
prio_mode_p = new_sx_qinq_outer_prio_mode_t_p()

outer_prio_mode_dict = {0: 'PORT', 1: 'VLAN'}
qinq_mode_dict = {0: '802_1Q', 1: 'QINQ', 2: '802_1AD'}

print("----------------------------------")
header = ["log_port", "QinQ Mode", "Outer Prio"]
print("|%10s|%10s|%10s|" % (header[0], header[1], header[2]))
print("----------------------------------")

for i in range(0, port_cnt):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_vport or is_cpu:
        continue
    rc = sx_api_vlan_port_qinq_mode_get(handle, int(port_attributes.log_port), qinq_mode_p)
    if (rc != SX_STATUS_SUCCESS):
        continue
    rc = sx_api_vlan_port_qinq_outer_prio_mode_get(handle, int(port_attributes.log_port), prio_mode_p)
    if (rc != SX_STATUS_SUCCESS):
        continue
    log_port = "0x%x" % port_attributes.log_port
    print("|%10s|%10s|%10s|" % (log_port, qinq_mode_dict[sx_qinq_mode_t_p_value(qinq_mode_p)],
                                outer_prio_mode_dict[sx_qinq_outer_prio_mode_t_p_value(prio_mode_p)]))
    print("----------------------------------")
