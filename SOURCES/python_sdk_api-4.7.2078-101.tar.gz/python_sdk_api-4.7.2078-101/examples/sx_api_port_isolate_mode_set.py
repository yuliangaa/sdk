#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import pdb

######################################################
#    defines
######################################################


######################################################
#    functions
######################################################
def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_isolate_mode_set API')
    parser.add_argument("-p", '--pass_routed_frames', action="store_true", help='pass_routed_frames enable', default=False)
    parser.add_argument("-i", '--isolate_bridge_only', action="store_true", help='isolate_bridged_and_routed enable, Supported by Spectrum3 and above.', default=False)
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    return args.pass_routed_frames, args.isolate_bridge_only, args.deinit


def main():
    pass_routed_frames, isolate_bridge_only, deinit = parse_args()

    try:
        original_port_isolate_mode_p = None
        print("[+] opening sdk")
        rc, handle = sx_api_open(None)
        print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
        if (rc != SX_STATUS_SUCCESS):
            print("Failed to open api handle.\nPlease check that SDK is running.")
            sys.exit(rc)
        # Check the current chip type
        chip_type = get_chip_type(handle)

        print("---------------- Parameters --------------------")
        print("Value to be set for pass_routed_frames: %s" % pass_routed_frames)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5]:
            print("Value to be set for isolate_bridge_and_routed: %s" % isolate_bridge_only)
        print("------------------------------------------------")

        if deinit:
            original_port_isolate_mode_p = new_sx_port_isolate_mode_t_p()
            rc = sx_api_port_isolate_mode_get(handle, original_port_isolate_mode_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_mode_set failed. rc:%d" % rc

        sx_port_isolate_mode_p = new_sx_port_isolate_mode_t_p()
        sx_port_isolate_mode = sx_port_isolate_mode_t()
        sx_port_isolate_mode.pass_routed_frames = pass_routed_frames
        sx_port_isolate_mode.isolate_bridged_and_routed = isolate_bridge_only
        sx_port_isolate_mode_t_p_assign(sx_port_isolate_mode_p, sx_port_isolate_mode)

        rc = sx_api_port_isolate_mode_set(handle, sx_port_isolate_mode_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_mode_set failed. rc:%d" % rc

        rc = sx_api_port_isolate_mode_get(handle, sx_port_isolate_mode_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_mode_set failed. rc:%d" % rc

        sx_port_isolate_mode = sx_port_isolate_mode_t_p_value(sx_port_isolate_mode_p)
        print("New configuration:")
        print("  sx_port_isolate_mode.pass_routed_frames: %d" % sx_port_isolate_mode.pass_routed_frames)
        if chip_type not in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM2]:
            print("  sx_port_isolate_mode.isolate_bridged_and_routed: %d" % sx_port_isolate_mode.isolate_bridged_and_routed)

        if deinit:
            rc = sx_api_port_isolate_mode_set(handle, original_port_isolate_mode_p)
            assert rc == SX_STATUS_SUCCESS, "sx_api_port_isolate_mode_set failed. rc:%d" % rc

        print("Success.")

    finally:
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
