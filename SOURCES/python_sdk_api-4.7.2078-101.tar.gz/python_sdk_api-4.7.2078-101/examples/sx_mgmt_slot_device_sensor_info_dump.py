#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the slot device sensor information.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *


def generate_slot_device_sensor_info_dump(handle, slot_id):
    slot_count = get_slot_count(handle)
    if slot_count == 0:
        print("Slot device sensor dump is applicable only for modular systems.")
        return

    slot_info_list = get_slot_info(handle)
    print("=========================================================================================================")
    header = ["Slot", "Sensor Id", "Sensor name", "Current temp", "Max temp", "Warn enabled", "Shutdown enabled", "Th High", "Th Low"]
    print("|%4s|%10s|%20s|%12s|%8s|%12s|%16s|%7s|%6s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8]))
    print("=========================================================================================================")

    gb_type_enum_dict = get_enum_string_dict('SX_MGMT_SLOT_LC_DEV_GB_TYPE')
    for idx in range(len(slot_info_list)):
        slot_info = slot_info_list[idx]
        if slot_id != INVALID_SLOT_ID and slot_info.slot_id != slot_id:
            continue

        dev_info_arr = slot_info.dev_description.slot_device_info
        dev_count = slot_info.dev_description.slot_device_count
        if dev_count == 0:
            continue
        sensor_id_list_p = new_sx_sensor_id_t_arr(dev_count)
        sx_mgmt_temp_sensor_info_list_p = new_sx_mgmt_temp_sensor_info_t_arr(dev_count)

        for dev_idx in range(dev_count):
            dev_info = sx_mgmt_slot_device_info_t_arr_getitem(dev_info_arr, dev_idx)
            sx_sensor_id_t_arr_setitem(sensor_id_list_p, dev_idx, dev_info.device_temp_info.sensor_id)
        try:
            rc = sx_mgmt_temp_sensor_get(handle, SX_ACCESS_CMD_GET, slot_info.slot_id, sensor_id_list_p, dev_count, sx_mgmt_temp_sensor_info_list_p)
            if rc != SX_STATUS_SUCCESS:
                continue
            for sensor_idx in range(dev_count):
                sensor_info = sx_mgmt_temp_sensor_info_t_arr_getitem(sx_mgmt_temp_sensor_info_list_p, sensor_idx)
                print("|%4s|%10s|%20s|%12s|%8s|%12s|%16s|%7s|%6s|" % (slot_info.slot_id,
                                                                      sensor_info.sensor_id,
                                                                      sensor_info.sensor_name,
                                                                      sensor_info.curr_temp,
                                                                      sensor_info.max_temp,
                                                                      get_boolean_string(sensor_info.temp_warning_enabled),
                                                                      get_boolean_string(sensor_info.temp_shutdown_enabled),
                                                                      sensor_info.temp_threshold_high,
                                                                      sensor_info.temp_threshold_low))
        finally:
            delete_sx_mgmt_temp_sensor_info_t_arr(sx_mgmt_temp_sensor_info_list_p)
            delete_sx_sensor_id_t_arr(sensor_id_list_p)
    print("=========================================================================================================")


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='Slot sensor info dump utility')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    args = parser.parse_args()
    slot_id = args.slot_id
    return slot_id


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    slot_id = parse_example_attributes()

    # Run the example.
    generate_slot_device_sensor_info_dump(handle, slot_id)

    sx_api_close(handle)
