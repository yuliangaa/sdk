#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_filter_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################

# get 5 ports
log_port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(log_port_cnt_p, 5)
port_attributes_list = new_sx_port_attributes_t_arr(5)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, log_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_port_device_get failed, rc = %d." % (rc)
port_cnt = uint32_t_p_value(log_port_cnt_p)
assert port_cnt == 5, "the returned ports count is not correct."

# build log_port list
log_port_list = []
log_port_list_p = new_sx_port_log_id_t_arr(5)
port_attributes = sx_port_attributes_t()
for i in range(0, 5):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    sx_port_log_id_t_arr_setitem(log_port_list_p, i, port_attributes.log_port)
    log_port_list.append(port_attributes.log_port)

# set trap filter on ports
rc = sx_api_host_ifc_trap_filter_set(handle,
                                     SX_ACCESS_CMD_ADD,
                                     SX_SWID_ID_MIN,
                                     SX_TRAP_ID_MIN,
                                     log_port_list_p,
                                     log_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_filter_set failed, rc = %d." % (rc)

# get the total count
uint32_t_p_assign(log_port_cnt_p, 0)
rc = sx_api_host_ifc_trap_filter_get(handle,
                                     SX_ACCESS_CMD_GET,
                                     SX_SWID_ID_MIN,
                                     SX_TRAP_ID_MIN,
                                     log_port_list[0],
                                     None,
                                     log_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_filter_get failed, rc = %d." % (rc)
log_port_cnt = uint32_t_p_value(log_port_cnt_p)
assert log_port_cnt == 5, "the returned ports count is not correct."

# get the first two entries
uint32_t_p_assign(log_port_cnt_p, 2)
rc = sx_api_host_ifc_trap_filter_get(handle,
                                     SX_ACCESS_CMD_GET_FIRST,
                                     SX_SWID_ID_MIN,
                                     SX_TRAP_ID_MIN,
                                     log_port_list[0],
                                     log_port_list_p,
                                     log_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_filter_get failed, rc = %d." % (rc)
log_port_cnt = uint32_t_p_value(log_port_cnt_p)
assert log_port_cnt == 2, "the returned ports count is not correct."
assert sx_port_log_id_t_arr_getitem(log_port_list_p, 0) == log_port_list[0], "the returned logic port IDs are incorrect: received 0x%x, expected 0x%x" % (sx_port_log_id_t_arr_getitem(log_port_list_p, 0), log_port_list[0])
assert sx_port_log_id_t_arr_getitem(log_port_list_p, 1) == log_port_list[1], "the returned logic port IDs are incorrect: received 0x%x, expected 0x%x" % (sx_port_log_id_t_arr_getitem(log_port_list_p, 1), log_port_list[1])

# get the next three entries after an entry
uint32_t_p_assign(log_port_cnt_p, 3)
rc = sx_api_host_ifc_trap_filter_get(handle,
                                     SX_ACCESS_CMD_GETNEXT,
                                     SX_SWID_ID_MIN,
                                     SX_TRAP_ID_MIN,
                                     log_port_list[1],
                                     log_port_list_p,
                                     log_port_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_filter_get failed, rc = %d." % (rc)
log_port_cnt = uint32_t_p_value(log_port_cnt_p)
assert log_port_cnt == 3, "the returned ports count is not correct."
assert sx_port_log_id_t_arr_getitem(log_port_list_p, 0) == log_port_list[2], "the returned logic port IDs are incorrect: received 0x%x, expected 0x%x" % (sx_port_log_id_t_arr_getitem(log_port_list_p, 0), log_port_list[2])
assert sx_port_log_id_t_arr_getitem(log_port_list_p, 1) == log_port_list[3], "the returned logic port IDs are incorrect: received 0x%x, expected 0x%x" % (sx_port_log_id_t_arr_getitem(log_port_list_p, 1), log_port_list[3])
assert sx_port_log_id_t_arr_getitem(log_port_list_p, 2) == log_port_list[4], "the returned logic port IDs are incorrect: received 0x%x, expected 0x%x" % (sx_port_log_id_t_arr_getitem(log_port_list_p, 2), log_port_list[4])

if args.deinit:
    # delete the entries
    rc = sx_api_host_ifc_trap_filter_set(handle,
                                         SX_ACCESS_CMD_DELETE_ALL,
                                         SX_SWID_ID_MIN,
                                         SX_TRAP_ID_MIN,
                                         None,
                                         None)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_filter_set failed, rc = %d." % (rc)

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
