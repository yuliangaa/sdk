#!/usr/bin/env python
'''
This file contains Python command example for the Span module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different Span attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse
from test_infra_common import get_chip_type

parser = argparse.ArgumentParser(description='sx_api_span_tail_drop example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

VID = 10
SWITCH_PRIO = 2
DEI = 1
PCP = 3
TP = 1
REMOTE_DMAC = "00:04:05:06:07:0F"
REMOTE_L3_SMAC = "00:04:05:06:07:0A"
REMOTE_L3_SIP = "2.2.2.2"
REMOTE_L3_DIP = "2.2.2.3"
REMOTE_L3_TTL = 64
REMOTE_L3_ENCAP_LEN = 42

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

""" ############################################################################################ """
port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]
PORT_2 = port_list[1]
PORT_3 = port_list[2]

""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


""" ############################################################################################ """


def span_init():
    """SPAN INIT"""
    print("--------------- SPAN INIT------------------------------")

    init_params_p = new_sx_span_init_params_t_p()
    init_params = sx_span_init_params_t()
    init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    print(("sx_api_span_init_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("version = %d " % (init_params.version)))
    delete_sx_span_init_params_t_p(init_params_p)


""" ############################################################################################ """


def span_session_create(span_session_param_p):
    """SPAN SESSION CREATE"""
    print("--------------- SPAN SESSION CREATE------------------------------")

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


""" ############################################################################################ """


def span_session_destroy(span_session_id_p, span_session_param_p):
    """SPAN SESSION DESTROY"""
    print("--------------- SPAN SESSION DESTROY------------------------------")

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)
    print(("sx_api_span_session_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    print(("Span session id [%d] destroyed" % (span_session_id)))


""" ############################################################################################ """


def span_analyzer_set(cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- SPAN ANALYZER ADD ------------------------------")
    else:
        print("--------------- SPAN ANALYZER DELETE ------------------------------")
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    print(("sx_api_span_analyzer_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_set(cmd, mirror_port, mirror_direction, session_id):
    """ADD/DELETE SPAN MIRROR PORT """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD SPAN MIRROR PORT ------------------------------")
    else:
        print("--------------- DELETE SPAN MIRROR PORT  ------------------------------")
    rc = sx_api_span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id)
    print(("sx_api_span_mirror_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_tail_drop_set(cmd, port, session_id):
    """ADD/DELETE SPAN MIRROR Tail Drop """
    if cmd == SX_ACCESS_CMD_BIND:
        print("--------------- ADD SPAN MIRROR Tail Drop ------------------------------")
    else:
        print("--------------- DELETE SPAN MIRROR Tail Drop  ------------------------------")

    key = sx_span_mirror_bind_key_t()
    key.type = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E
    key.key.ing_sb_drop.log_port = port
    key_p = new_sx_span_mirror_bind_key_t_p()
    sx_span_mirror_bind_key_t_p_assign(key_p, key)

    attr = sx_span_mirror_bind_attr_t()
    attr.span_session_id = session_id
    attr_p = new_sx_span_mirror_bind_attr_t_p()
    sx_span_mirror_bind_attr_t_p_assign(attr_p, attr)

    rc = sx_api_span_mirror_bind_set(handle, cmd, key_p, attr_p)
    print(("sx_api_span_mirror_bind_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_tail_drop_get(port):
    key = sx_span_mirror_bind_key_t()
    key.type = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E
    key.key.ing_sb_drop.log_port = port
    key_p = new_sx_span_mirror_bind_key_t_p()
    sx_span_mirror_bind_key_t_p_assign(key_p, key)

    attr_p = new_sx_span_mirror_bind_attr_t_p()

    rc = sx_api_span_mirror_bind_get(handle, key_p, attr_p)
    print(("sx_api_span_mirror_bind_get [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    attr = sx_span_mirror_bind_attr_t_p_value(attr_p)
    return attr.span_session_id


""" ############################################################################################ """


def span_session_mirror_get(session_id):
    mirror_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(mirror_cnt_p, 0)
    rc = sx_api_span_session_mirror_get(handle, session_id, None, mirror_cnt_p)
    print(("span_session_mirror_get [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    mirror_cnt = uint32_t_p_value(mirror_cnt_p)
    mirror_arr = new_sx_span_mirror_t_arr(mirror_cnt)
    rc = sx_api_span_session_mirror_get(handle, session_id, mirror_arr, mirror_cnt_p)
    print(("span_session_mirror_get [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    mirror_list = []
    for i in range(0, mirror_cnt):
        mirror_list.append(sx_span_mirror_t_arr_getitem(mirror_arr, i))

    delete_uint32_t_p(mirror_cnt_p)
    delete_sx_span_mirror_t_arr(mirror_arr)

    return mirror_list


""" ############################################################################################ """


def span_session_state_set(session_id, admin_state):
    """SPAN SESSION STATE SET """
    print("--------------- SPAN SESSION STATE SET  ------------------------------")
    print(("Span session id =%d, admin state =%d" % (session_id, admin_state)))
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    print(("sx_api_span_session_state_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_disallow_set(port_list):
    """SPAN MIRROR DISALLOW SET:
    set disallow of mirror trigger 1 (with non-elephant traffic), allow of mirror trigger 2 (with elephant), allow of mirror trigger 3 (with elephant+non-elephant)
    """
    print("--------------- SPAN MIRROR DISALLOW SET  ------------------------------")
    print('Span mirror disallow set on ports:[{}]'.format(', '.join(hex(x) for x in port_list)))
    cfg_cnt = len(port_list)
    if cfg_cnt == 0:
        print("No input ports")
        return 0
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    for i in range(cfg_cnt):
        cfg_item = sx_span_mirror_enable_port_set_t_arr_getitem(cfg_item_list, i)
        cfg_item.ingress_log_port = port_list[i]
        # for non_elephant settings
        mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0)
        mirror_trigger_disallow.type = SX_SPAN_MIRROR_BIND_ING_WRED_E
        mirror_trigger_disallow.mirror_trigger_disallow = 1
        sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0, mirror_trigger_disallow)
        mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 1)
        mirror_trigger_disallow.type = SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E
        mirror_trigger_disallow.mirror_trigger_disallow = 1
        sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 1, mirror_trigger_disallow)
        cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt = 2
        # for elephant settings (we set all triggers for test)
        for j in range(SX_SPAN_MIRROR_BIND_TYPE_MAX_E + 1):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j)
            mirror_trigger_disallow.type = j
            mirror_trigger_disallow.mirror_trigger_disallow = j % 2
            sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j, mirror_trigger_disallow)
        cfg_item.mirror_disallow_elephant.mirror_trigger_disallow_cnt = SX_SPAN_MIRROR_BIND_TYPE_MAX_E + 1
        sx_span_mirror_enable_port_set_t_arr_setitem(cfg_item_list, i, cfg_item)
    rc = sx_api_span_mirror_enable_port_set(handle, SX_ACCESS_CMD_SET, cfg_item_list, cfg_cnt)
    print(("sx_api_span_mirror_enable_port_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_disallow_part1_unset(port_list):
    """SPAN MIRROR DISALLOW SET:
    set disallow of mirror trigger 1 (with non-elephant traffic), allow of mirror trigger 2 (with elephant), allow of mirror trigger 3 (with elephant+non-elephant)
    """
    print("--------------- SPAN MIRROR DISALLOW UNSET  ------------------------------")
    print(("Span mirror disallow set on ports:{}".format(port_list)))
    print('Span mirror disallow set on ports:[{}]'.format(', '.join(hex(x) for x in port_list)))
    cfg_cnt = len(port_list)
    if cfg_cnt == 0:
        print("No input ports")
        return 0
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    for i in range(cfg_cnt):
        cfg_item = sx_span_mirror_enable_port_set_t_arr_getitem(cfg_item_list, i)
        cfg_item.ingress_log_port = port_list[i]
        # for non_elephant settings
        mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0)
        mirror_trigger_disallow.type = SX_SPAN_MIRROR_BIND_ING_WRED_E
        sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0, mirror_trigger_disallow)
        cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt = 1
        # for elephant settings
        for j in range(3):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j)
            mirror_trigger_disallow.type = j + 2
            sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j, mirror_trigger_disallow)
        cfg_item.mirror_disallow_elephant.mirror_trigger_disallow_cnt = 3
        sx_span_mirror_enable_port_set_t_arr_setitem(cfg_item_list, i, cfg_item)
    rc = sx_api_span_mirror_enable_port_set(handle, SX_ACCESS_CMD_UNSET, cfg_item_list, cfg_cnt)
    print(("sx_api_span_mirror_enable_port_set (unset) [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_disallow_all_existing_unset():
    """SPAN MIRROR DISALLOW SET:
    set disallow of mirror trigger 1 (with non-elephant traffic), allow of mirror trigger 2 (with elephant), allow of mirror trigger 3 (with elephant+non-elephant)
    """
    print("--------------- SPAN MIRROR DISALLOW UNSET  ------------------------------")
    cfg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(cfg_cnt_p, 0)
    cmd = SX_ACCESS_CMD_GET
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, None, cfg_cnt_p)
    cfg_cnt = uint32_t_p_value(cfg_cnt_p)
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    cmd = SX_ACCESS_CMD_GET_FIRST
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, cfg_item_list, cfg_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_span_mirror_enable_port_iter_get, GET_FIRST, [rc=%d]" % (rc)))
        sys.exit(rc)
    rc = sx_api_span_mirror_enable_port_set(handle, SX_ACCESS_CMD_UNSET, cfg_item_list, cfg_cnt)
    print(("sx_api_span_mirror_enable_port_set (unset) [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_disallow_unset(port_list):
    """SPAN MIRROR DISALLOW SET:
    set disallow of mirror trigger 1 (with non-elephant traffic), allow of mirror trigger 2 (with elephant), allow of mirror trigger 3 (with elephant+non-elephant)
    """
    print("--------------- SPAN MIRROR DISALLOW UNSET  ------------------------------")
    print(("Span mirror disallow set on ports:{}".format(port_list)))
    print('Span mirror disallow set on ports:[{}]'.format(', '.join(hex(x) for x in port_list)))
    cfg_cnt = len(port_list)
    if cfg_cnt == 0:
        print("No input ports")
        return 0
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    for i in range(cfg_cnt):
        cfg_item = sx_span_mirror_enable_port_set_t_arr_getitem(cfg_item_list, i)
        cfg_item.ingress_log_port = port_list[i]
        # for non_elephant settings
        mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0)
        mirror_trigger_disallow.type = SX_SPAN_MIRROR_BIND_ING_WRED_E
        sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 0, mirror_trigger_disallow)
        mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 1)
        mirror_trigger_disallow.type = SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E
        sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, 1, mirror_trigger_disallow)
        cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt = 2
        # for elephant settings (we set all triggers for test)
        for j in range(SX_SPAN_MIRROR_BIND_TYPE_MAX_E + 1):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j)
            mirror_trigger_disallow.type = j
            sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j, mirror_trigger_disallow)
        cfg_item.mirror_disallow_elephant.mirror_trigger_disallow_cnt = SX_SPAN_MIRROR_BIND_TYPE_MAX_E + 1
        sx_span_mirror_enable_port_set_t_arr_setitem(cfg_item_list, i, cfg_item)
    rc = sx_api_span_mirror_enable_port_set(handle, SX_ACCESS_CMD_UNSET, cfg_item_list, cfg_cnt)
    print(("sx_api_span_mirror_enable_port_set (unset) [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def span_mirror_disallow_get(port_list=None):
    """SPAN MIRROR DISALLOW GET:
    get mirror disallow configs of the port_list
    """
    print("--------------- SPAN MIRROR DISALLOW GET  ------------------------------")
    if port_list:
        print('Span mirror disallow get on ports:[{}]'.format(', '.join(hex(x) for x in port_list)))
    cfg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(cfg_cnt_p, 0)
    cmd = SX_ACCESS_CMD_GET
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, None, cfg_cnt_p)
    cfg_cnt = uint32_t_p_value(cfg_cnt_p)
    cfg_item_list = new_sx_span_mirror_enable_port_set_t_arr(cfg_cnt)
    cmd = SX_ACCESS_CMD_GET_FIRST
    rc = sx_api_span_mirror_enable_port_iter_get(handle, cmd, 0, None, cfg_item_list, cfg_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_span_mirror_enable_port_iter_get, GET_FIRST, [rc=%d]" % (rc)))
        sys.exit(rc)
    type_enum_dict = get_enum_string_dict('SX_SPAN_MIRROR_BIND')
    for i in range(cfg_cnt):
        if i == 0:
            print("------------------------------------------------------------------------------------------")
            print(("|%-11s|%-16s|%-48s|%-10s|" % ("Port", "Flow_Type", "Mirror_Trigger_Type", "Disallow")))
            print("------------------------------------------------------------------------------------------")
        cfg_item = sx_span_mirror_enable_port_set_t_arr_getitem(cfg_item_list, i)
        # for elephant settings
        for j in range(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow_cnt):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_elephant.mirror_trigger_disallow, j)
            print(("|0x%-9x|%-16s|%-48s|%-10s|" % (cfg_item.ingress_log_port, "Elephant", type_enum_dict[mirror_trigger_disallow.type], get_boolean_string(mirror_trigger_disallow.mirror_trigger_disallow))))
        # for non_elephant settings
        for j in range(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt):
            mirror_trigger_disallow = sx_span_mirror_trigger_disallow_cfg_t_arr_getitem(cfg_item.mirror_disallow_non_elephant.mirror_trigger_disallow, j)
            print(("|0x%-9x|%-16s|%-48s|%-10s|" % (cfg_item.ingress_log_port, "None-elephant", type_enum_dict[mirror_trigger_disallow.type], get_boolean_string(mirror_trigger_disallow.mirror_trigger_disallow))))


""" ############################################################################################ """


def span_deinit():
    """SPAN DEINIT"""
    print("--------------- SPAN DEINIT------------------------------")

    rc = sx_api_span_deinit_set(handle)
    print(("sx_api_span_deinit_set [rc=%d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """

ingress_port = PORT_1
egress_port = PORT_2
analyzer_port = PORT_3

# FDB configuration
mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(1)
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 1)
mac_addr1 = ether_addr("00:02:03:04:0A:0F")

mac_entry1 = sx_fdb_uc_mac_addr_params_t()
mac_entry1.mac_addr = mac_addr1
mac_entry1.fid_vid = 1          # Filtering Identifier, VID for static MAC
mac_entry1.log_port = egress_port
mac_entry1.entry_type = SX_FDB_UC_STATIC
mac_entry1.action = SX_FDB_ACTION_FORWARD
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_fdb_uc_mac_addr_set failed [rc=%d]" % (rc)))
    sys.exit(rc)

# init span
span_init()
# create a span session
span_session_param_p = new_sx_span_session_params_t_p()
span_session_param = sx_span_session_params_t()
span_session_param.span_type = SX_SPAN_TYPE_LOCAL_ETH_TYPE1
span_session_param.span_type_format.local_eth_type1.qos_mode = SX_SPAN_QOS_MAINTAIN
span_session_param.span_type_format.local_eth_type1.switch_prio = 2
span_session_param.truncate = False
span_session_param.truncate_size = 32
sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
span_session_id_p = span_session_create(span_session_param_p)
span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
print(("Span session id [%d] created" % (span_session_id)))

# add analyzer port to span session created above
port_params_p = new_sx_span_analyzer_port_params_t_p()
port_params = sx_span_analyzer_port_params_t()
port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
span_analyzer_set(SX_ACCESS_CMD_ADD, analyzer_port, port_params_p, span_session_id)

# enable SPAN session admin state
span_session_state_set(span_session_id, True)

# add span mirror tail drop
span_mirror_tail_drop_set(SX_ACCESS_CMD_BIND, ingress_port, span_session_id)
bound_session_id = span_mirror_tail_drop_get(ingress_port)

disallow_port_list = [ingress_port, port_list[3]]

chip_type = get_chip_type(handle)

if chip_type >= SX_CHIP_TYPE_SPECTRUM4:
    # check conditional mirroring configs
    span_mirror_disallow_set(disallow_port_list)
    span_mirror_disallow_get(disallow_port_list)

    # check partial conditional mirroring unset
    print("Test partial conditional mirroring unset..")
    span_mirror_disallow_part1_unset(disallow_port_list)
    span_mirror_disallow_get(disallow_port_list)

    print("Test remaining part conditional mirroring unset..")
    span_mirror_disallow_all_existing_unset()
    span_mirror_disallow_get(disallow_port_list)
    print("set conditional mirroring again..")
    span_mirror_disallow_set(disallow_port_list)

    print("whole conditional mirroring unset..")
    span_mirror_disallow_unset(disallow_port_list)

# Send traffic

# packet due to tail drop will get in the analyzer_port

if args.deinit:
    # delete span mirror tail drop
    span_mirror_tail_drop_set(SX_ACCESS_CMD_UNBIND, ingress_port, span_session_id)

    # disable SPAN session admin state
    span_session_state_set(span_session_id, False)

    # delete analyzer port to span session created above
    span_analyzer_set(SX_ACCESS_CMD_DELETE, analyzer_port, port_params_p, span_session_id)

    # destroy span session
    span_session_destroy(span_session_id_p, span_session_param_p)
    delete_sx_span_session_params_t_p(span_session_param_p)
    delete_sx_span_session_id_t_p(span_session_id_p)
    delete_sx_span_analyzer_port_params_t_p(port_params_p)

    # deinit span
    span_deinit()

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_fdb_uc_mac_addr_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

sx_api_close(handle)
