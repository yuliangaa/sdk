#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates a region with size 254
    2. Creates a ACL
    3. Create ACL rule to swap vlans.
    4. Bind the ACL to the ingress port
"""
import sys
import socket
import struct
import errno
import random
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_vlan_swap_action example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = get_ports(handle, 2)
INGRESS_PORT = port_list[0]
EGRESS_PORT = port_list[1]


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def rule_set(region_id, start_offset, end_offset, cmd):
    ''' This function sets rule, where cmd is the choice for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_cnt = (end_offset - start_offset + 1)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    offsets_list = new_sx_acl_rule_offset_t_arr(rules_cnt)
    j = 0

    for i in range(start_offset, end_offset + 1):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 3, rule)

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_SIP
        key_desc.key.sip.version = SX_IP_VERSION_IPV4
        key_desc.key.sip.addr.ipv4.s_addr = 0x00000000 + i + 1
        key_desc.mask.sip.version = SX_IP_VERSION_IPV4
        key_desc.mask.sip.addr.ipv4.s_addr = 0x000000ff

        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
        rule.key_desc_count = 1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN

        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
        rule.action_count = 1

        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, j, rule)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, j, i)
        j = j + 1

    rc = sx_api_acl_flex_rules_set(handle,
                                   cmd,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)


def main():
    key_handle = key_create(FLEX_ACL_KEY_SIP)
    region_id = region_create(key_handle, 254)
    acl_id = acl_create(region_id, SX_ACL_DIRECTION_INGRESS)
    rule_set(region_id, 0, 179, SX_ACCESS_CMD_SET)
    rule_set(region_id, 180, 253, SX_ACCESS_CMD_SET)

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  INGRESS_PORT,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    if args.deinit:
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      INGRESS_PORT,
                                      acl_id)
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)
        rule_set(region_id, 0, 179, SX_ACCESS_CMD_DELETE)
        rule_set(region_id, 180, 253, SX_ACCESS_CMD_DELETE)
        acl_destroy(acl_id, region_id)
        region_destroy(region_id)
        key_destroy(key_handle)

    sx_api_close(handle)

    print("success")


if __name__ == "__main__":
    main()
