#!/usr/bin/env python
'''
This file contains Python command example for the CoS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different CoS attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import colorsys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_cos_port_default_prio_example')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

err = SX_STATUS_SUCCESS

ports = mapPortAndInterfaces(handle, 1)
log_port = ports[0]

priority_p = new_sx_cos_priority_t_p()

# get port prio for restoration
rc = sx_api_cos_port_default_prio_get(handle, log_port, priority_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
start_priority = sx_cos_priority_t_p_value(priority_p)
print(("sx_api_cos_port_default_prio_get [log_port=0x%x , priority=%d] " % (log_port, start_priority)))

# set prio
tmp_priority = 5
if start_priority == tmp_priority:  # make sure to set a value different from the one already set
    tmp_priority = 6
rc = sx_api_cos_port_default_prio_set(handle, log_port, tmp_priority)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
print(("sx_api_cos_port_default_prio_set [log_port=0x%x , priority=%d] " % (log_port, tmp_priority)))

# verify prio
rc = sx_api_cos_port_default_prio_get(handle, log_port, priority_p)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
priority = sx_cos_priority_t_p_value(priority_p)
print(("sx_api_cos_port_default_prio_get [log_port=0x%x , priority=%d] " % (log_port, priority)))
if priority != tmp_priority:
    print("port prio set failed. prio retrieved is not the same as set")
    err = 1

if args.deinit:
    # restore previous prio
    rc = sx_api_cos_port_default_prio_set(handle, log_port, start_priority)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_cos_port_default_prio_set [log_port=0x%x , priority=%d] " % (log_port, start_priority)))

    # verify prio
    rc = sx_api_cos_port_default_prio_get(handle, log_port, priority_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    priority = sx_cos_priority_t_p_value(priority_p)
    print(("sx_api_cos_port_default_prio_get [log_port=0x%x , priority=%d] " % (log_port, priority)))
    if priority != start_priority:
        print("port prio set failed. prio retrieved is not the same as set")
        err = 1

sx_api_close(handle)

if err == SX_STATUS_SUCCESS:
    print("Test Successful")
