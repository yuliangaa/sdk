#!/usr/bin/env python
"""
Example of user defined tree
"""

import os
import sys
from python_sdk_api.sx_api import *
import test_infra_common
import argparse
import collections


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    description_str = """ This is an example of how to create and get a user defined tree. """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")

    return parser.parse_args()


def router_init(handle):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to init the router, [rc = %d]" % (rc)))
        sys.exit(rc)

    print("Init the router, rc: %d" % (rc))


def create_vrid(handle, tree_id):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.ipv4_tree_id = tree_id

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to create VRID, [rc = %d]" % (rc)))
        sys.exit(rc)

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def delete_vrid(handle, vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to delete VRID, [rc = %d]" % (rc)))
        sys.exit(rc)

    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit(handle):
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def create_user_defined_tree(handle, nodes_list):
    """ Create user defined lpm tree. """
    nodes_arr = None
    nodes_len = 0
    tree_id_p = new_sx_lpm_tree_id_t_p()
    lpm_tree_attr = sx_router_lpm_tree_attributes_t()
    nodes_arr = new_sx_lpm_tree_node_t_arr(len(nodes_list))
    try:
        print("create_user_defined_tree with the following nodes:"
              "list of nodes [ (node, left, right) ] : {}".format(nodes_list))

        lpm_tree_attr.ip_version = SX_IP_VERSION_IPV4

        nodes_len = len(nodes_list)
        for i, node in enumerate(nodes_list):
            node_t = sx_lpm_tree_node_t()
            node_t.node, node_t.left_child, node_t.right_child = node
            sx_lpm_tree_node_t_arr_setitem(nodes_arr, i, node_t)

        rc = sx_api_router_user_defined_lpm_tree_set(handle, SX_ACCESS_CMD_CREATE, nodes_arr, nodes_len, lpm_tree_attr, tree_id_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_user_defined_lpm_tree_set failed to create lpm tree, [rc = %d], [nodes=%d]" % (rc, nodes_list))
            sys.exit(rc)

        tree_id = sx_lpm_tree_id_t_p_value(tree_id_p)
        print("Created tree ID: %d " % tree_id)

        return tree_id
    finally:
        delete_sx_lpm_tree_id_t_p(tree_id_p)
        delete_sx_lpm_tree_node_t_arr(nodes_arr)


def nodes_to_str(nodes):
    nodes_str = '(node_prefix, left_child, right_child) '
    for node in nodes:
        nodes_str += '({},{},{}) ; '.format(node.node, node.left_child, node.right_child)

    return nodes_str


def get_user_defined_tree(handle, tree_id, nodes_cnt=0):
    """ Get user defined lpm tree with given tree_id. """

    nodes_cnt_p = copy_uint8_t_p(nodes_cnt)
    nodes_arr = None
    try:
        print("Getting_user_defined_tree with ID: = {}".format(tree_id))
        if not nodes_cnt:
            rc = sx_api_router_user_defined_lpm_tree_get(
                handle, tree_id, None, nodes_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_router_user_defined_lpm_tree_get failed, [rc = %d], [tree_id=%d]" % (
                    rc, tree_id))
                sys.exit(rc)

            nodes_cnt = uint8_t_p_value(nodes_cnt_p)

        nodes_arr = new_sx_lpm_tree_node_t_arr(nodes_cnt)
        rc = sx_api_router_user_defined_lpm_tree_get(
            handle, tree_id, nodes_arr, nodes_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_user_defined_lpm_tree_get failed, [rc = %d], [tree_id=%d]" % (
                rc, tree_id))
            sys.exit(rc)

        nodes = [sx_lpm_tree_node_t_arr_getitem(nodes_arr, i) for i in range(nodes_cnt)]
        print("The list of returned nodes: Nodes = {}".format(nodes_to_str(nodes)))

        return nodes
    finally:
        delete_uint8_t_p(nodes_cnt_p)
        delete_sx_lpm_tree_node_t_arr(nodes_arr)


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    ''' longest prefix match node object '''
    LpmNode = collections.namedtuple("Node", "node_prefix left_child right_child")

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # init router
        router_init(handle)

        nodes_list_of_tuples = [(LpmNode(node_prefix=16, left_child=12, right_child=24)),
                                (LpmNode(node_prefix=17, left_child=SX_NODE_NO_CHILD, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=12, left_child=1, right_child=15)),
                                (LpmNode(node_prefix=18, left_child=17, right_child=23)),
                                (LpmNode(node_prefix=1, left_child=SX_NODE_NO_CHILD, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=24, left_child=18, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=22, left_child=20, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=23, left_child=22, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=15, left_child=SX_NODE_NO_CHILD, right_child=SX_NODE_NO_CHILD)),
                                (LpmNode(node_prefix=20, left_child=SX_NODE_NO_CHILD, right_child=SX_NODE_NO_CHILD))]

        # create the user defined tree
        tree_id = create_user_defined_tree(handle, nodes_list_of_tuples)

        vrid = create_vrid(handle, tree_id)

        nodes = get_user_defined_tree(handle, tree_id)

        nodes_list = [LpmNode(node_prefix=node.node, left_child=node.left_child, right_child=node.right_child) for node in nodes]

        assert set(nodes_list) == set(nodes_list_of_tuples), "got wrong nodes !!!"

        if args.deinit:

            # delete vrid
            delete_vrid(handle, vrid)

            # deinit router
            router_deinit(handle)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    main()
