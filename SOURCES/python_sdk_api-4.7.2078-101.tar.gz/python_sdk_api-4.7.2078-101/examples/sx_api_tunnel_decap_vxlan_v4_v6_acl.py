#!/usr/bin/env python
"""
The script create an ipv4 tunnel, bind an tunnel_decap/set_vni acl on ingress rif. That tunnel can decap ipv4 or ipv6 packet.
packet ingress to PORT2 can be ipv4 packet:
Ether(dst="00:02:03:04:05:07", src="E4:1D:2D:B4:89:71")/ Dot1Q(vlan=1) / IP(dst="1.1.1.88", src="1.1.1.66") /UDP(sport=4789,dport=4789) / VXLAN(vni=0x15,flags="Instance") / Ether() /IP() / TCP() / Raw(load=self.dummy_payload)
or ipv6 packet:
    Ether(dst="00:02:03:04:05:07", src="E4:1D:2D:B4:89:71")/ Dot1Q(vlan=1) / IPv6(src="2::1",dst="1::1") /UDP(sport=4789,dport=4789) / VXLAN(vni=0x25,flags="Instance") / Ether() /IP() / TCP() / Raw(load=self.dummy_payload)
the decaped packet will send out from PORT1
"""
import os
import sys
import sys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *
from common_infra_acl import *


def parse_args():
    description_str = """
    This is an example of using 1 tunnel to decap both ipv4/v6 packets.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    return parser.parse_args()


######################################################
#    Functions API
######################################################

def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def bridge_create_delete(cmd, bridge_id_p):
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_vport_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


def vlan_ports_add_delete(cmd, vid, vlan_port_list_p, port_cnt):
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VLAN MEMBER PORTS  ------------------------------")
    else:
        print("--------------- DELETE VLAN MEMBER PORTS  ------------------------------")

    rc = sx_api_vlan_ports_set(handle, cmd, SPECTRUM_SWID, vid, vlan_port_list_p, port_cnt)
    print(("sx_api_vlan_ports_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)
    return rc


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)
    return rc


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return rc, tunnel_id


def tunnel_get(tunnel_id):
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    rc = sx_api_tunnel_get(handle, tunnel_id, tunnel_attribute_p)
    print(("sx_api_tunnel_get  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    tunnel_attribute = sx_tunnel_attribute_t_p_value(tunnel_attribute_p)
    return rc, tunnel_attribute


def tunnel_destroy(tunnel_id_p):
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    return rc


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.mc_ecmp_enabled = False
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


def make_tunnel_attributes_vxlan(vrid, underlay_sip, log_port, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, ttl=255, underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0, decap_underlay_rif=0):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_ttl = ttl
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.vxlan.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.vxlan.underlay_domain_type = underlay_domain_type
    tunnel_attribute.attributes.vxlan.nve_log_port = log_port

    chip_type = get_chip_type(handle)
    if chip_type == SX_CHIP_TYPE_SPECTRUM4:
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mask = 0xF7FFFFFF00000000
    else:
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_IGNORE_E

    return tunnel_attribute


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def set_rif_state_ip(rif, enable=SX_ROUTER_ENABLE_STATE_ENABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    print("Set rif %d state %d, rc: %d " % (rif, enable, rc))
    return rc


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    print(("Delete RIF: %d, rc: %d " % (rif, rc)))
    return rc


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    return tunnel_init(general_param_p)


def example_vxlan_tunnel_create_flow(vrid, log_port=NVE_PORT, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, usip="192.168.0.1", ttl=255, underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0, decap_underlay_rif=0):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip and to correctly add to the struct
    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, log_port, direction, ttl, underlay_domain_type, encap_underlay_rif, decap_underlay_rif)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    return tunnel_destroy(tunnel_id_p)


def tunnel_map_entry_process(tunnel_id, bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5, delete=0):
    map_entry = make_tunnel_map_entry_params(bridge_id, tunnel_type, vni)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    if delete == 0:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)
    else:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE, tunnel_id, map_entry_p, 1)


def make_tunnel_map_entry_params(bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni

    return map_entry


def bridge_vport_create_example(vlan, port):
    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, port, vlan, log_vport_p_1)
    log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtula port 0x%x created" % (log_vport_1)))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge %d created" % (bridge_id)))

    # add log_vport_1 to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
    print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))

    # set port state to UP
    port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan, {port: SX_UNTAGGED_MEMBER})

    return bridge_id, log_vport_1


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "
    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def create_flow_counter(created_flow_counters, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    created_flow_counters.append(counter_id)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def destroy_flow_counter(counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function destroys a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed flow counter %d, rc: %d" % (counter_id, rc))


def main():
    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    print("[+] opening sdk")
    global handle
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    ######################################################
    #    defines
    ######################################################
    SPECTRUM_SWID = 0
    ol_vlan = 10
    vni = 5

    created_flow_counters = []
    port_list = get_ports(handle, 2)
    PORT1 = port_list[0]  # egress
    PORT2 = port_list[1]  # ingress

    try:
        router_init()
        print("init")
        rc = example_tunnel_init_flow()
        assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

        vrid = create_vrid()

        # create underlay rif
        ul_port_rif = create_vlan_rif(vrid, 1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
        set_rif_state_ip(ul_port_rif, True)

        log_port = NVE_PORT

        ulay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID
        rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid, log_port, SX_TUNNEL_DIRECTION_SYMMETRIC)

        assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

        # create overlay bridge
        ol_bridge_id, port1_vport = bridge_vport_create_example(ol_vlan, PORT1)

        rc = tunnel_map_entry_process(tunnel_id, ol_bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN, vni, 0)
        assert SX_STATUS_SUCCESS == rc, "Failed to add map entry, rc: %d" % (rc)

        # create decap acl
        key_handle_p = new_sx_acl_key_type_t_p()
        acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, [FLEX_ACL_KEY_ETHERTYPE])
        key_handle = sx_acl_key_type_t_p_value(key_handle_p)

        rules_list = new_sx_flex_acl_flex_rule_t_arr(100)
        rules = []
        acl_rules_init(rules, rules_list, 100, key_handle, 20)

        region_id_p = new_sx_acl_region_id_t_p()
        acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 10, region_id_p)
        region_id = sx_acl_region_id_t_p_value(region_id_p)

        acl_dir = SX_ACL_DIRECTION_RIF_INGRESS
        acl_id_p = new_sx_acl_id_t_p()
        acl_handle(handle, SX_ACCESS_CMD_CREATE, acl_dir, acl_id_p, region_id)
        acl_id = sx_acl_id_t_p_value(acl_id_p)

        group_id_p = new_sx_acl_id_t_p()
        acl_group_handle(handle, SX_ACCESS_CMD_CREATE, acl_dir, group_id_p, [acl_id])
        group_id = sx_acl_id_t_p_value(group_id_p)

        # packet must reach this RIF in order to be decapsulated
        rif_bind(handle, SX_ACCESS_CMD_BIND, ul_port_rif, group_id)

        offsets_list = new_sx_acl_rule_offset_t_arr(100)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
        rules[0].valid = 1
        rules[0].key_desc_count = 1

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_ETHERTYPE
        key_desc.key.ethertype = 0x1111
        key_desc.mask.ethertype = 0x0000  # match all
        sx_flex_acl_key_desc_t_arr_setitem(rules[0].key_desc_list_p, 0, key_desc)

        rules[0].action_count = 0

        action = sx_flex_acl_flex_action_t()
        action.type = SX_FLEX_ACL_ACTION_TUNNEL_DECAP
        action.fields.action_tunnel_decap.tunnel_id = tunnel_id
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        action = sx_flex_acl_flex_action_t()
        # Overwrite VNI in packet with this VNI so that tunnel map from VNI to bridge works and packet will egress after decap according to this VNI
        action.type = SX_FLEX_ACL_ACTION_SET_VNI
        action.fields.action_vni.vni_value = vni
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        counter_id = create_flow_counter(created_flow_counters)
        action = sx_flex_acl_flex_action_t()
        action.type = SX_FLEX_ACL_ACTION_COUNTER
        action.fields.action_counter.counter_id = counter_id
        sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, rules[0].action_count, action)
        rules[0].action_count = rules[0].action_count + 1

        sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rules[0])
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rules_list,
                                       1)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

        if args.deinit:
            print("Clean Up")

            rif_bind(handle, SX_ACCESS_CMD_UNBIND, ul_port_rif, group_id)

            sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
            rc = sx_api_acl_flex_rules_set(handle,
                                           SX_ACCESS_CMD_DELETE,
                                           region_id,
                                           offsets_list,
                                           rules_list,
                                           1)
            assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

            acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, acl_dir, group_id_p, [])
            acl_handle(handle, SX_ACCESS_CMD_DESTROY, acl_dir, acl_id_p, region_id)
            acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 10, region_id_p)

            acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p, [key_handle])

            port_state_set(port1_vport, SX_PORT_ADMIN_STATUS_DOWN)
            bridge_vport_add_delete(SX_ACCESS_CMD_DELETE_ALL, ol_bridge_id, PORT1)
            log_vport_p_1 = new_sx_port_log_id_t_p()
            vport_add_delete(SX_ACCESS_CMD_DELETE_ALL, PORT1, ol_vlan, log_vport_p_1)
            remove_ports_from_vlan(ol_vlan, {PORT1: SX_UNTAGGED_MEMBER})
            delete_rif(vrid, ul_port_rif)

            rc = tunnel_map_entry_process(tunnel_id, ol_bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN, vni, 1)
            assert SX_STATUS_SUCCESS == rc, "Failed to delete map entry, rc: %d" % (rc)

            rc = example_tunnel_destroy_flow(tunnel_id)
            rc = tunnel_deinit()
            destroy_flow_counter(counter_id)

            bridge_id_p = copy_sx_bridge_id_t_p(ol_bridge_id)
            bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)
            delete_sx_bridge_id_t_p(bridge_id_p)
            delete_vrid(vrid)
            router_deinit()

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
