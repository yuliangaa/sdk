#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sxd_api_mpgcr example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def main():
    args = parse_args()
    print("[+] MPGCR register access test start")

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d \n" % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Check chip type
    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("MPLS EMAD (MPGCR) Is supported only for SPC-1")
        sx_api_close(handle)
        sys.exit(0)

    sx_api_close(handle)
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init failed, rc: %d" % (rc)

    try:
        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0

        original_mpgcr = ku_mpgcr_reg()

        print("[+] Get MPGCR")
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_mpgcr(original_mpgcr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get MPGCR register, rc: %d" % (rc)

        print("[+] Get MPGCR content")
        print("====================")
        print("[+] mpls_et:", original_mpgcr.mpls_et)
        print("[+] mpls_pcp_rw:", original_mpgcr.mpls_pcp_rw)
        print("[+] ler_exp_rw:", original_mpgcr.ler_exp_rw)
        print("[+] ingress_ler_ttl:", original_mpgcr.ingress_ler_ttl)
        print("[+] egress_ler_ttl:", original_mpgcr.egress_ler_ttl)
        print("[+] lsr_egress_ttl:", original_mpgcr.lsr_egress_ttl)
        print("[+] ingress_ler_ttl_value:", original_mpgcr.ingress_ler_ttl_value)
        print("[+] hrlsn:", original_mpgcr.hrlsn)
        print("[+] label_id_min:", original_mpgcr.label_id_min)
        print("[+] label_id_max:", original_mpgcr.label_id_max)
        print("[+] entropy_msb:", original_mpgcr.entropy_msb)
        print("[+] activity_dis_mpnhlfe:", original_mpgcr.activity_dis_mpnhlfe)

        mpgcr = ku_mpgcr_reg()

        mpgcr.mpls_et = 3
        mpgcr.mpls_pcp_rw = 0
        mpgcr.ler_exp_rw = 2
        mpgcr.ingress_ler_ttl = 1
        mpgcr.egress_ler_ttl = 0
        mpgcr.lsr_egress_ttl = 1
        mpgcr.ingress_ler_ttl_value = 64
        mpgcr.hrlsn = 31
        mpgcr.label_id_min = 32
        mpgcr.label_id_max = 0xfffff
        mpgcr.entropy_msb = 0
        mpgcr.activity_dis_mpnhlfe = 0

        print("[+] Set MPGCR content")
        print("====================")
        print("[+] mpls_et:", mpgcr.mpls_et)
        print("[+] mpls_pcp_rw:", mpgcr.mpls_pcp_rw)
        print("[+] ler_exp_rw:", mpgcr.ler_exp_rw)
        print("[+] ingress_ler_ttl:", mpgcr.ingress_ler_ttl)
        print("[+] egress_ler_ttl:", mpgcr.egress_ler_ttl)
        print("[+] lsr_egress_ttl:", mpgcr.lsr_egress_ttl)
        print("[+] ingress_ler_ttl_value:", mpgcr.ingress_ler_ttl_value)
        print("[+] hrlsn:", mpgcr.hrlsn)
        print("[+] label_id_min:", mpgcr.label_id_min)
        print("[+] label_id_max:", mpgcr.label_id_max)
        print("[+] entropy_msb:", mpgcr.entropy_msb)
        print("[+] activity_dis_mpnhlfe:", mpgcr.activity_dis_mpnhlfe)

        print("[+] Set MPGCR ")

        meta.access_cmd = SXD_ACCESS_CMD_SET
        rc = sxd_access_reg_mpgcr(mpgcr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set MPGCR register, rc: %d" % (rc)

        print("[+] Get MPGCR")
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_mpgcr(mpgcr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get MPGCR register, rc: %d" % (rc)

        print("[+] Get after Set MPGCR content")
        print("====================")
        print("[+] mpls_et:", mpgcr.mpls_et)
        print("[+] mpls_pcp_rw:", mpgcr.mpls_pcp_rw)
        print("[+] ler_exp_rw:", mpgcr.ler_exp_rw)
        print("[+] ingress_ler_ttl:", mpgcr.ingress_ler_ttl)
        print("[+] egress_ler_ttl:", mpgcr.egress_ler_ttl)
        print("[+] lsr_egress_ttl:", mpgcr.lsr_egress_ttl)
        print("[+] ingress_ler_ttl_value:", mpgcr.ingress_ler_ttl_value)
        print("[+] hrlsn:", mpgcr.hrlsn)
        print("[+] label_id_min:", mpgcr.label_id_min)
        print("[+] label_id_max:", mpgcr.label_id_max)
        print("[+] entropy_msb:", mpgcr.entropy_msb)
        print("[+] activity_dis_mpnhlfe:", mpgcr.activity_dis_mpnhlfe)

        if args.deinit:
            print("Deinit")
            meta.access_cmd = SXD_ACCESS_CMD_SET
            rc = sxd_access_reg_mpgcr(original_mpgcr, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set MPGCR register, rc: %d" % (rc)
    finally:
        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)

    print("[+] MPGCR register access test end")


if __name__ == "__main__":
    main()
