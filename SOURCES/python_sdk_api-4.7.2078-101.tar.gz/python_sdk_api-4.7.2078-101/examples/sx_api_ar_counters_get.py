#!/usr/bin/env python
"""
This file contains Python command example for the Adaptive Router Counters-Get API.
"""

import os
import sys
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *        # Needed only when using SXD_APIs in the examples
import test_infra_common
import argparse


def parse_args():

    description_str = """
    Python Adaptive Routing counters get API Example.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--clear", action="store_true", help="Clear AR counters after read")
    return parser.parse_args()


def main():
    args = parse_args()

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("Adaptive routing is supported from spectrum2 and above - Exiting gracefully")
            sys.exit(0)

        ar_init_params = sx_ar_init_params_t()

        rc = sx_api_ar_init_set(handle, ar_init_params)
        if rc == SX_STATUS_ALREADY_INITIALIZED:
            print("AR Module already initialized, Continue")
            deinit_ar = False
        elif rc != SX_STATUS_SUCCESS:
            print("Failed to init adaptive routing module")
            sys.exit(rc)
        else:
            deinit_ar = True

        cmd = SX_ACCESS_CMD_READ_CLEAR if args.clear else SX_ACCESS_CMD_READ

        ar_counters_p = sx_ar_global_counters_t()

        rc = sx_api_ar_counters_get(handle, cmd, ar_counters_p)
        if rc != SX_STATUS_SUCCESS:
            if rc == SX_STATUS_MODULE_UNINITIALIZED:
                print("Adaptive Routing module is not initialized")
                sys.exit(SX_STATUS_SUCCESS)
            else:
                print(("sx_api_ar_counters_get failed, [cmd = %d, rc = %d]" % (cmd, rc)))
                sys.exit(rc)

        print("Adaptive Routing Counters")

        print("\tArCongestionChanges:  %10lu" % (ar_counters_p.ar_congestion_changes))

        if args.deinit and deinit_ar:
            rc = sx_api_ar_deinit_set(handle)
            if rc != SX_STATUS_SUCCESS:
                print("Failed to init adaptive routing module")
                sys.exit(rc)

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    main()
