#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

CMD_SET = 0
LOOPBACK_DICT = {0: 'DISABLED', 1: 'EXTERNAL', 2: 'INTERNAL', 3: 'BOTH', 4: 'INTERNAL_LR', 5: 'LOGICAL'}


parser = argparse.ArgumentParser(description='Port loopback')
parser.add_argument('--cmd', default=0, type=int, help="set(0), get(1)")
parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Logical port ID')
parser.add_argument('--loopback_type', default=0, type=int, help='disable(0), external(1), internal(2), both(3), internal_lr(4), logical(5)')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

sys_argv_len = len(sys.argv)
if args.deinit:
    sys_argv_len = sys_argv_len - 1

if sys_argv_len == 1:
    print("Note that for the current example will be used default parameters:\n\tlog_port: 0x%x \n\tloopback_type: %d" % (args.log_port, args.loopback_type))

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

log_port = args.log_port

if (args.cmd == CMD_SET):
    print("[+] Loopback get")
    original_loopback_type_p = new_sx_port_phys_loopback_t_p()
    rc = sx_api_port_phys_loopback_get(handle, log_port, original_loopback_type_p)
    if (rc != SX_STATUS_SUCCESS):
        sys.exit(rc)
    original_loopback_type = sx_port_phys_loopback_t_p_value(original_loopback_type_p)
    print(("sx_api_port_phys_loopback_get log_port 0x%x loopback_type:%s(%d), rc %d " %
           (log_port, LOOPBACK_DICT[original_loopback_type], original_loopback_type, rc)))

    if args.loopback_type == SX_PORT_PHYS_LOOPBACK_ENABLE_LOGICAL:
        """
        The loopback packet should not be changed as a result of Logical loopback.
        So, configure params to prevent changing the FCS field or dropping the packet as a result of bad CRC:
            i.   Disable RX timestamp over CRC: SX_TS_OVER_CRC_INGRESS_MODE_DISABLE_E
            ii.  Disable TX timestamp over CRC: SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT
            iii. Forward packets with bad CRC on ingress: SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
        """
        # Init tele module
        is_original_tele_module_enabled = True
        tele_param_p = new_sx_tele_init_params_t_p()
        rc = sx_api_tele_init_set(handle, tele_param_p)
        if (rc != SX_STATUS_SUCCESS):
            is_original_tele_module_enabled = False

        # 1. Tele module using 'tele_attributes_set': SX_TS_OVER_CRC_INGRESS_MODE_DISABLE_E
        original_tele_attr_t = sx_tele_attrib_t()
        rc = sx_api_tele_attributes_get(handle, original_tele_attr_t)
        if (rc != SX_STATUS_SUCCESS):
            print("rc = {}".format(rc))
            sys.exit(rc)

        tele_attr_t = sx_tele_attrib_t()
        tele_attr_t.internal_ts_enable = False
        rc = sx_api_tele_attributes_set(handle, tele_attr_t)
        if (rc != SX_STATUS_SUCCESS):
            print("rc = {}".format(rc))
            sys.exit(rc)

        # 2. Port module using 'port_crc_set': SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT ,SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
        original_crc_params_p = new_sx_port_crc_params_t_p()
        rc = sx_api_port_crc_params_get(handle, log_port, original_crc_params_p)
        if (rc != SX_STATUS_SUCCESS):
            print("rc = {}".format(rc))
            sys.exit(rc)

        crc_params_p = new_sx_port_crc_params_t_p()
        crc_params_p.bad_crc_ingress_mode = SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
        crc_params_p.crc_egress_recalc_mode = SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT
        rc = sx_api_port_crc_params_set(handle, log_port, crc_params_p)
        if (rc != SX_STATUS_SUCCESS):
            print("rc = {}".format(rc))
            sys.exit(rc)

    print("[+] Loopback set: log_port:0x%x loopback:%s(%d)" % (log_port, LOOPBACK_DICT[args.loopback_type], args.loopback_type))
    rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)
    if (rc != SX_STATUS_SUCCESS):
        sys.exit(rc)
    print(("sx_api_port_state_set log_port 0x%x Down, rc %d " % (log_port, rc)))
    rc = sx_api_port_phys_loopback_set(handle, log_port, args.loopback_type)
    if (rc != SX_STATUS_SUCCESS):
        sys.exit(rc)
    print(("sx_api_port_phys_loopback_set log_port 0x%x type %d, rc %d " % (log_port, args.loopback_type, rc)))
    rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
    if (rc != SX_STATUS_SUCCESS):
        sys.exit(rc)
    print(("sx_api_port_state_set log_port 0x%x Up, rc %d " % (log_port, rc)))

print("[+] Loopback get")
loopback_type_p = new_sx_port_phys_loopback_t_p()
rc = sx_api_port_phys_loopback_get(handle, log_port, loopback_type_p)
if (rc != SX_STATUS_SUCCESS):
    sys.exit(rc)
loopback_type = sx_port_phys_loopback_t_p_value(loopback_type_p)
print(("sx_api_port_phys_loopback_get log_port 0x%x loopback_type:%s(%d), rc %d " %
       (log_port, LOOPBACK_DICT[loopback_type], loopback_type, rc)))

if args.deinit:
    if (args.cmd == CMD_SET):
        print("[+] Loopback set: log_port:0x%x loopback:%s(%d)" % (
            log_port, LOOPBACK_DICT[original_loopback_type], original_loopback_type))
        rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)
        if (rc != SX_STATUS_SUCCESS):
            sys.exit(rc)
        print(("sx_api_port_state_set log_port 0x%x Down, rc %d " % (log_port, rc)))
        rc = sx_api_port_phys_loopback_set(handle, log_port, original_loopback_type)
        if (rc != SX_STATUS_SUCCESS):
            sys.exit(rc)
        print(("sx_api_port_phys_loopback_set log_port 0x%x type %d, rc %d " % (log_port, original_loopback_type, rc)))
        rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
        if (rc != SX_STATUS_SUCCESS):
            sys.exit(rc)
        print(("sx_api_port_state_set log_port 0x%x Up, rc %d " % (log_port, rc)))

        if args.loopback_type == SX_PORT_PHYS_LOOPBACK_ENABLE_LOGICAL:
            isEnabled = {True: 'Enabled', False: 'Disabled'}
            rc = sx_api_tele_attributes_set(handle, original_tele_attr_t)
            if (rc != SX_STATUS_SUCCESS):
                print("rc = {}".format(rc))
                sys.exit(rc)
            print(("sx_api_tele_attributes_set internal timestamp %s, rc %d " % (isEnabled[original_tele_attr_t.internal_ts_enable], rc)))

            rc = sx_api_port_crc_params_set(handle, log_port, original_crc_params_p)
            if (rc != SX_STATUS_SUCCESS):
                print("rc = {}".format(rc))
                sys.exit(rc)
            print(("sx_api_port_crc_params_set log_port 0x%x bad CRC ingress mode %s,  CRC egress recalc mode %s, rc %d " % (log_port, isEnabled[original_crc_params_p.bad_crc_ingress_mode], isEnabled[original_crc_params_p.crc_egress_recalc_mode], rc)))

            if not is_original_tele_module_enabled:
                rc = sx_api_tele_deinit_set(handle)
                if (rc != SX_STATUS_SUCCESS):
                    print("rc = {}".format(rc))
                    sys.exit(rc)
            print(("sx_api_tele_deinit_set rc %d " % (rc)))


sx_api_close(handle)
