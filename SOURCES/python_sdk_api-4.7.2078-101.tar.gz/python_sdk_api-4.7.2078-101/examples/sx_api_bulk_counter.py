#!/usr/bin/env python
"""
This file contains Python command example for the bulk flow counter.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""


import sys
import socket
import struct
import errno
import time

from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
from test_infra_common import *
from optparse import OptionParser
import argparse

INVALID_POOL_ID = 0xFFFFFFFF

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = get_ports(handle, 2)
PORT1 = port_list[0]
PORT2 = port_list[1]

ingress_ports = [PORT1, PORT2]

TEST_NUM_ACLS_IN_GROUP = 1
TEST_NUM_RULES = 4
TEST_NUM_FLOW_COUNTERS = (TEST_NUM_RULES)
TEST_NUM_ACTIONS = 1
TEST_NUM_PORTS = len(ingress_ports)
PACKET_SIZE = 1024
WAIT_HOSTIFC_INTV = 0.5
WAIT_HOSTIFC_LOOP = 10

TEST_FLOW_EST_RULES_NUM = 1
TEST_FLOW_EST_CNTR_NUM = 16
TEST_FLOW_EST_PROF_SIZE = 4 * TEST_FLOW_EST_CNTR_NUM
TEST_FLOW_EST_PROF_ID = 0

counter_buffer_counters_dict = {}
counters_per_buffer_list = []
counters_seq_list = []
direction = 0
group_list = []
acl_list = []
region_list = []
acl_rules_list = []
acl_key_list = [FLEX_ACL_KEY_L4_DESTINATION_PORT]
TEST_NUM_KEYS = len(acl_key_list)

IEEE_802_DOT_3_S = "ieee802_3"
RFC_2863_S = "rfc2863"
RFC_2819_S = "rfc2819"
RFC_3635_S = "rfc3635"
CLI_S = "cli"
PERF_S = "perf"
DISCARD_S = "discard"
PRIO_S = "prio"
TC_S = "tc"
BUFF_S = "buff"
PHY_LAYER_S = "phy_layer"
PHY_LAYER_STATS_S = "phy_layer_stats"
ALL_S = "all"
MACSEC_PORT_GRP0 = "macsec_port_group0"
MACSEC_PORT_GRP1 = "macsec_port_group1"
bulk_cntr_port_grp_list = [SX_BULK_CNTR_PORT_GRP_IEEE_802_DOT_3_E, SX_BULK_CNTR_PORT_GRP_RFC_2863_E,
                           SX_BULK_CNTR_PORT_GRP_RFC_2819_E, SX_BULK_CNTR_PORT_GRP_RFC_3635_E,
                           SX_BULK_CNTR_PORT_GRP_PRIO_E, SX_BULK_CNTR_PORT_GRP_TC_E,
                           SX_BULK_CNTR_PORT_GRP_BUFF_E, SX_BULK_CNTR_PORT_GRP_PERF_E,
                           SX_BULK_CNTR_PORT_GRP_DISCARD_E, SX_BULK_CNTR_PORT_GRP_PHY_LAYER_E,
                           SX_BULK_CNTR_PORT_GRP_PHY_LAYER_STATS_E]
bulk_cntr_macsec_port_grp_list = [SX_BULK_CNTR_MACSEC_PORT_GRP_0, SX_BULK_CNTR_MACSEC_PORT_GRP_1]
# All possible values of port, macsec port, tc, pg and prio can be passed using this single value
ALL_POSSIBLE_VALUES = 0xFFFFFFFF


def auto_int(x):
    return int(x, 0)


def print_all_attr_of_struct(struct):
    for attr in dir(struct):
        if not is_swig_internal_attribute(attr):
            print("%s = %s" % (attr, getattr(struct, attr)))


def host_ifc_open(handle):
    ''' Opening fd for traps '''
    trap_fd = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to open host_ifc trap_fd, rc=[%d] " % (rc))
        sys.exit(errno.EACCES)
    return trap_fd


def host_ifc_close(handle, fd):
    ''' Closing host ifc '''
    trap_fd = new_sx_fd_t_p()
    sx_fd_t_p_assign(trap_fd, fd)
    rc = sx_api_host_ifc_close(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to close host_ifc trap_fd, rc=[%d] " % (rc))
        sys.exit(errno.EACCES)


def host_ifc_trap_id_set(handle, cmd, trap_id, trap_group):
    ''' SET/UNSET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id
    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    if cmd == SX_ACCESS_CMD_SET:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU
    else:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT
    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc))
        sys.exit(errno.EACCES)


def host_ifc_trap_id_register_set(handle, cmd, trap_id, user_channel, fd):
    ''' REGISTER/DEREGISTER trap id association to the relevant user channel '''
    user_channel_p = new_sx_user_channel_t_p()
    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t()
        user_channel.type = SX_USER_CHANNEL_TYPE_FD
        user_channel.channel.fd = copy_sx_fd_t_p(fd)
    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, 0, trap_id, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)
    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t_p_value(user_channel_p)
    return user_channel


def check_sdk_rc(rc, errmsg):
    if rc != SX_STATUS_SUCCESS:
        print("Fail: %s, rc=%d" % (errmsg, rc))
        exit(1)


def key_create(handle):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(len(acl_key_list))
    for i, key in enumerate(acl_key_list):
        sx_acl_key_t_arr_setitem(key_arr, i, key)
    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 len(acl_key_list),
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    # free memory
    delete_sx_acl_key_t_arr(key_arr)
    return key_handle


def key_destroy(handle, key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)
    key_arr = new_sx_acl_key_t_arr(len(acl_key_list))
    for i, key in enumerate(acl_key_list):
        sx_acl_key_t_arr_setitem(key_arr, i, key)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)
    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 len(acl_key_list),
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"


def region_create(handle, key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               SX_ACL_ACTION_TYPE_EXTENDED,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    region_id = sx_acl_region_id_t_p_value(region_id_p)
    return region_id


def region_destroy(handle, region_id, key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)
    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               key_handle,
                               SX_ACL_ACTION_TYPE_EXTENDED,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"


def acl_create(handle, region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()
    acl_region_group.regions.acl_packet_agnostic.region = region_id
    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    return acl_id


def acl_destroy(handle, acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)
    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id
    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        SX_ACL_DIRECTION_INGRESS,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)
    delete_sx_acl_id_t_p(acl_id_p)


def group_create(handle, acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"
    group_id = sx_acl_id_t_p_value(group_id_p)
    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def group_destroy(handle, group_id):
    " This function destroy  flex acl key "
    group_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(group_id_p, group_id)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, group_id)
    direction = 0
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy group"
    delete_sx_acl_id_t_p(group_id_p)


def init_rule_with_counter(rule, layer4_port, counter_id, is_estimator=False, profile_id=0):
    rule.valid = 1
    rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(TEST_NUM_KEYS)
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    key_desc.key.l4_destination_port = layer4_port
    key_desc.mask.l4_destination_port = 0xffff
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(TEST_NUM_ACTIONS)
    rule.key_desc_count = TEST_NUM_KEYS
    rule.action_count = TEST_NUM_ACTIONS
    action = sx_flex_acl_flex_action_t()
    if is_estimator:
        action.type = SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR
        action.fields.action_flow_estimator.profile_key.profile_id = profile_id
        action.fields.action_flow_estimator.counter.base_counter_id = counter_id
    else:
        action.type = SX_FLEX_ACL_ACTION_COUNTER
        action.fields.action_counter.counter_id = counter_id
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action)


def create_test_acls(s_handle, tst_estimator=False, profile_id=0, rule_num=TEST_NUM_RULES):
    # 1. create acl key handle
    key_handle = key_create(s_handle)
    # 2. create acl region
    region_id = region_create(s_handle, key_handle, rule_num)
    region_list.append(region_id)
    # 3. create ACL, get acl_id;
    acl_id = acl_create(s_handle, region_id, SX_ACL_DIRECTION_INGRESS)
    acl_list.append(acl_id)
    # 4. create acl group
    # 5. Link acl to the group
    acl_id_arr = new_sx_acl_id_t_arr(1)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)
    group_id = group_create(s_handle, acl_id_arr, 1, SX_ACL_DIRECTION_INGRESS)
    group_list.append(group_id)
    # 6. init each rule
    rules_arr = new_sx_flex_acl_flex_rule_t_arr(rule_num)
    rule_p = new_sx_flex_acl_flex_rule_t_p()
    for i in range(rule_num):
        rule = sx_flex_acl_flex_rule_t()
        sx_flex_acl_flex_rule_t_p_assign(rule_p, rule)
        rc = sx_lib_flex_acl_rule_init(key_handle, TEST_NUM_ACTIONS, rule_p)
        check_sdk_rc(rc, 'Failed to initialize ACL rule')
        acl_rules_list.append(sx_flex_acl_flex_rule_t_p_value(rule_p))
        # 7. set each rule with (L4 port, bind with the spec counter (counter_id_index) )
        if tst_estimator:
            init_rule_with_counter(acl_rules_list[i], 8080, counters_seq_list[i], tst_estimator, profile_id)
        else:
            init_rule_with_counter(acl_rules_list[i], 8080 + i, counters_seq_list[i])
    for i in range(0, rule_num):
        sx_flex_acl_flex_rule_t_arr_setitem(rules_arr, i, acl_rules_list[i])
    # 8. set ACL rules
    acl_offsets_list = new_sx_acl_rule_offset_t_arr(rule_num)
    for x in range(0, rule_num):
        sx_acl_rule_offset_t_arr_setitem(acl_offsets_list, x, x)
    sx_api_acl_flex_rules_set(s_handle, SX_ACCESS_CMD_SET, region_id, acl_offsets_list, rules_arr, rule_num)
    # 9. bind ACLs to specified ports
    for i in ingress_ports:
        sx_api_acl_port_bind_set(s_handle, SX_ACCESS_CMD_BIND, i, group_id)
    return rules_arr, key_handle, acl_offsets_list


def delete_test_acls(s_handle, acl_rules_arr, key_handle, acl_offsets_list, rule_num=TEST_NUM_RULES):
    group_id = group_list.pop()
    region_id = region_list.pop()
    acl_id = acl_list.pop()
    # 1. unbind ACL group from ports
    for i in ingress_ports:
        sx_api_acl_port_bind_set(s_handle, SX_ACCESS_CMD_UNBIND, i, group_id)
    # 2. delete ACL rules
    rc = sx_api_acl_flex_rules_set(s_handle,
                                   SX_ACCESS_CMD_DELETE,
                                   region_id,
                                   acl_offsets_list,
                                   acl_rules_arr,
                                   rule_num)
    # 3 deinitialize ACL rules structure
    for i in range(rule_num):
        sx_lib_flex_acl_rule_deinit(acl_rules_list[i])
    # 4 destroy ACL group
    group_destroy(s_handle, group_id)
    # 5  destroy ACL
    acl_destroy(s_handle, acl_id, region_id)
    # 6 destroy ACL region
    region_destroy(s_handle, region_id, key_handle, rule_num)
    # 7 delete ACL key handle
    key_destroy(s_handle, key_handle)


def set_port_user_memory(s_handle, pum):
    port_user_memory_arr = new_sx_port_user_memory_params_t_arr(TEST_NUM_PORTS)
    for i in range(TEST_NUM_PORTS):
        port_pum_params = sx_port_user_memory_params_t()
        port_pum_params.log_port = ingress_ports[i]
        port_pum_params.port_user_memory_value = pum
        port_pum_params.port_user_memory_mask = 0xff
        sx_port_user_memory_params_t_arr_setitem(port_user_memory_arr, i, port_pum_params)
    sx_api_port_user_memory_set(s_handle, SX_ACCESS_CMD_SET, port_user_memory_arr, TEST_NUM_PORTS)


def read_flow_counters(s_handle, trap_fd, counter_buffer, count_id_list, trap_id, clear):
    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed ".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)
    ret = []
    print('\nFlow counters')
    print("#" * 80)
    for i in range(TEST_NUM_FLOW_COUNTERS):
        counter_id = count_id_list[i]
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_E
        cntr_read_key.key.flow_key.cntr_id = count_id_list[i]
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for counter id : {}".format(counter_id))
        flow_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
        print("#" * 5 + "\tBULK counter get: counter_id:'0x{:x}', packets:'{}', bytes:'{}'".format(
            counter_id,
            flow_counter_data.data.flow_counters.flow_cntr_p.flow_counter_packets,
            flow_counter_data.data.flow_counters.flow_cntr_p.flow_counter_bytes))
        ret.append({'counter_id': counter_id,
                    'packets': flow_counter_data.data.flow_counters.flow_cntr_p.flow_counter_packets,
                    'bytes': flow_counter_data.data.flow_counters.flow_cntr_p.flow_counter_bytes})
    print("#" * 80)
    return ret


def read_flow_estimator_counters(s_handle, trap_fd, counter_buffer, count_id_list, trap_id, clear):
    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed ".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)
    ret = []
    print('\nFlow counters')
    print("#" * 80)
    for i in range(TEST_FLOW_EST_CNTR_NUM):
        counter_id = count_id_list[i]
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E
        cntr_read_key.key.flow_estimator_key.cntr_id = count_id_list[i]
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for counter id : {}".format(counter_id))
        counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
        bin_arr = counter_data.data.flow_estimator_data.flow_counter_estimator_p.flow_estimator_bins
        print("#" * 5 + "\tBULK counter get: counter_id:'0x{:x}', bin[0-3]: {}, {}, {}, {}.".format(
            counter_id,
            sx_flow_estimator_bin_t_arr_getitem(bin_arr, 0),
            sx_flow_estimator_bin_t_arr_getitem(bin_arr, 1),
            sx_flow_estimator_bin_t_arr_getitem(bin_arr, 2),
            sx_flow_estimator_bin_t_arr_getitem(bin_arr, 3)))

        ret.append({'counter_id': counter_id,
                    'bin0': sx_flow_estimator_bin_t_arr_getitem(bin_arr, 0),
                    'bin1': sx_flow_estimator_bin_t_arr_getitem(bin_arr, 1),
                    'bin2': sx_flow_estimator_bin_t_arr_getitem(bin_arr, 2),
                    'bin3': sx_flow_estimator_bin_t_arr_getitem(bin_arr, 3)})
    print("#" * 80)
    return ret


def bulk_flow_counters_buffer_set(handle, cmd, flow_counters_list=None, counter_buffer_id=None, is_estimator=False):
    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            if is_estimator:
                counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E
                counter_buffer_key.key.flow_estimator_key.base_counter_id = flow_counters_list[0]
                counter_buffer_key.key.flow_estimator_key.num_of_counters = len(flow_counters_list)
            else:
                counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_E
                counter_buffer_key.key.flow_key.base_counter_id = flow_counters_list[0]
                counter_buffer_key.key.flow_key.num_of_counters = len(flow_counters_list)
        elif cmd == SX_ACCESS_CMD_DESTROY:
            cntr_buffer = counter_buffer_id
            counter_buffer_key = None

        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)


def bulk_flow_counter_set(handle, counter_cnt, cmd=SX_ACCESS_CMD_CREATE, base_counter_id=None,
                          counter_type=SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES):
    counter_id = new_sx_flow_counter_bulk_data_t_p()
    try:
        counter_key = sx_flow_counter_bulk_attr_t()
        counter_key.counter_type = counter_type
        counter_key.counter_num = counter_cnt

        if cmd == SX_ACCESS_CMD_DESTROY:
            counter_id.base_counter_id = base_counter_id

        rc = sx_api_flow_counter_bulk_set(handle, cmd, counter_key, counter_id)
        check_sdk_rc(rc, "sx_api_flow_counter_bulk_set failed for counter id : {}".format(counter_id))
        base_counter_id = sx_flow_counter_bulk_data_t_p_value(counter_id)

        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        flow_counter_get_list = []
        for i in range(counter_cnt):
            flow_counter_get_list.append(base_counter_id.base_counter_id + i)
        return flow_counter_get_list

    finally:
        delete_sx_flow_counter_bulk_data_t_p(counter_id)


def wait_bulk_counter_refresh_done(trap_fd, trap_id, cookie):
    trap_fd_p = copy_sx_fd_t_p(trap_fd)
    pkt_size_p = copy_uint32_t_p(PACKET_SIZE)
    pkt_p = new_uint8_t_arr(PACKET_SIZE)
    recv_info = sx_receive_info_t()
    recv_info_p = copy_sx_receive_info_t_p(recv_info)
    # wait for trap id
    received_packets_list = []
    for i in range(WAIT_HOSTIFC_LOOP):
        rc = sx_lib_host_ifc_recv(trap_fd_p, pkt_p, pkt_size_p, recv_info_p)
        check_sdk_rc(rc, "sx_lib_host_ifc_recv failed")
        recv_info2 = sx_receive_info_t_p_value(recv_info_p)
        recv_info = "recv_info" + str(i)
        received_packets_list.append({recv_info: {'acl_user_id': recv_info2.acl_user_id,
                                                  'dest_lag_port': recv_info2.dest_lag_port,
                                                  'dest_log_port': recv_info2.dest_log_port,
                                                  'dest_port_type': recv_info2.dest_port_type,
                                                  'event_info': recv_info2.event_info,
                                                  'buffer_id': recv_info2.event_info.bulk_cntr_done_info.buffer_id,
                                                  'bulk_cntr_done_status': recv_info2.event_info.bulk_cntr_done_info.status,
                                                  'is_lag': recv_info2.is_lag,
                                                  'original_packet_size': recv_info2.original_packet_size,
                                                  'source_lag_port': recv_info2.source_lag_port,
                                                  'source_log_port': recv_info2.source_log_port,
                                                  'trap_id': recv_info2.trap_id}})
        if recv_info2.trap_id == trap_id and recv_info2.event_info.bulk_cntr_refresh_done_info.counter_refresh_attr.cookie == cookie:
            break
        time.sleep(WAIT_HOSTIFC_INTV)


def refresh_accuflow_counters(handle, cookie):
    cmd = SX_ACCESS_CMD_SET
    cmd_str = "SET"
    counter_buffer_key = sx_bulk_cntr_refresh_attr_t()
    counter_buffer_key.cookie = cookie
    rc = sx_api_bulk_counter_refresh_set(handle, cmd, counter_buffer_key)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed ".format(cmd_str))


def reset_global_db():
    global counter_buffer_counters_dict
    counter_buffer_counters_dict = {}
    global counters_per_buffer_list
    counters_per_buffer_list = []
    global counters_seq_list
    counters_seq_list = []
    global direction
    direction = 0
    global group_list
    group_list = []
    global acl_list
    acl_list = []
    global region_list
    region_list = []
    global acl_rules_list
    acl_rules_list = []


def flow_estimator_profile_set(handle, cmd=SX_ACCESS_CMD_CREATE, profile_id=0, bin_group_size=0):
    """ CREATE/SET/DESTROY FLOW ESTIMATOR PROFILE """
    if cmd != SX_ACCESS_CMD_DESTROY and bin_group_size == 0:
        rc = SXD_STATUS_PARAM_ERROR
        print("Invalid param of bin group size {}.".format(bin_group_size))

    profile_key = sx_flow_estimator_profile_key_t()
    profile_key.profile_id = profile_id

    profile_cfg_p = new_sx_flow_estimator_profile_cfg_t_p()
    profile_cfg = sx_flow_estimator_profile_cfg_t()
    profile_cfg.bin_group_size = bin_group_size
    profile_cfg.hash_params_p = None
    sx_flow_estimator_profile_cfg_t_p_assign(profile_cfg_p, profile_cfg)

    # set with bin_group_size and default hash params
    rc = sx_api_flow_estimator_profile_set(handle,
                                           cmd,
                                           profile_key,
                                           profile_cfg_p)
    check_sdk_rc(rc, "sx_api_flow_estimator_profile_set failed for profile id : {}".format(profile_id))
    return rc


def bulk_flow_estimator_example(handle, trap_id, sx_fd, clear):
    counter_id_list = []
    reset_global_db()

    # alloc a flow estimator profile
    flow_estimator_profile_set(handle, SX_ACCESS_CMD_CREATE, TEST_FLOW_EST_PROF_ID, TEST_FLOW_EST_PROF_SIZE)
    print("created profile id:{}".format(TEST_FLOW_EST_PROF_ID))

    # alloc bulk flow counters
    counter_id_list = bulk_flow_counter_set(handle, counter_cnt=TEST_FLOW_EST_CNTR_NUM, cmd=SX_ACCESS_CMD_CREATE, counter_type=SX_FLOW_COUNTER_TYPE_ESTIMATOR)
    print("created bulk flow estimator counters:{}".format(counter_id_list))

    # alloc bulk flow estimator counters buffer
    counter_buffer_id = bulk_flow_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE, counter_id_list, None, True)
    counter_buffer_counters_dict[counter_buffer_id] = counter_id_list
    counters_seq_list.extend(counter_id_list)

    # create test acls and bind with related counters
    acl_arr, key_handle, acl_offsets_list = create_test_acls(handle, True, TEST_FLOW_EST_PROF_ID, TEST_FLOW_EST_RULES_NUM)

    # Wait traffic
    # input("Wait some traffic being sent before reading something...")

    # read bulk counters
    read_flow_estimator_counters(handle, sx_fd, counter_buffer_id, counter_id_list, trap_id, clear)

    # delete ACLs
    delete_test_acls(handle, acl_arr, key_handle, acl_offsets_list, TEST_FLOW_EST_RULES_NUM)

    # release bulk buffer
    bulk_flow_counter_set(handle, TEST_FLOW_EST_CNTR_NUM, SX_ACCESS_CMD_DESTROY, counter_id_list[0], SX_FLOW_COUNTER_TYPE_ESTIMATOR)

    # deallocate_flow_counters
    bulk_flow_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buffer_id)

    # delete a flow estimator profile
    flow_estimator_profile_set(handle, SX_ACCESS_CMD_DESTROY, TEST_FLOW_EST_PROF_ID, TEST_FLOW_EST_PROF_SIZE)
    print("deleted profile id:{}".format(TEST_FLOW_EST_PROF_ID))


def bulk_flow_counter_example(handle, trap_id, sx_fd, clear, counter_type_str):
    counter_id_list = []

    reset_global_db()

    if counter_type_str == "accuflow":
        counters_type = SX_FLOW_COUNTER_TYPE_ACCUMULATED
        refresh_sx_fdp = host_ifc_open(handle)
        refresh_sx_fd = sx_fd_t_p_value(refresh_sx_fdp)
        refresh_trap_id = SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT
        refresh_user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER,
                                                             refresh_trap_id, None, refresh_sx_fdp)
    else:
        counters_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES

    # alloc bulk flow counters
    counter_id_list = bulk_flow_counter_set(handle, counter_cnt=4 * TEST_NUM_FLOW_COUNTERS, cmd=SX_ACCESS_CMD_CREATE, counter_type=counters_type)

    # alloc bulk flow counters buffer
    counter_buffer_id = bulk_flow_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE, counter_id_list)
    counter_buffer_counters_dict[counter_buffer_id] = counter_id_list
    counters_seq_list.extend(counter_id_list)

    # create test acls and bind with related counters
    acl_arr, key_handle, acl_offsets_list = create_test_acls(handle)

    # Wait traffic
    # input("Wait some traffic being sent before reading something...")

    if counter_type_str == "accuflow":
        cookie = 32
        refresh_accuflow_counters(handle, cookie)
        wait_bulk_counter_refresh_done(refresh_sx_fd, refresh_trap_id, cookie)

    # read bulk counters
    read_flow_counters(handle, sx_fd, counter_buffer_id, counter_id_list, trap_id, clear)

    # delete ACLs
    delete_test_acls(handle, acl_arr, key_handle, acl_offsets_list)

    # release bulk buffer
    bulk_flow_counter_set(handle, 4 * TEST_NUM_FLOW_COUNTERS, SX_ACCESS_CMD_DESTROY, counter_id_list[0], counter_type=counters_type)

    # deallocate_flow_counters
    bulk_flow_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buffer_id)

    if counter_type_str == "accuflow":
        host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, refresh_trap_id,
                                      refresh_user_channel, None)
        host_ifc_close(handle, refresh_sx_fd)


def wait_bulk_counter_done(trap_fd, trap_id, buffer_id):
    trap_fd_p = copy_sx_fd_t_p(trap_fd)
    pkt_size_p = copy_uint32_t_p(PACKET_SIZE)
    pkt_p = new_uint8_t_arr(PACKET_SIZE)
    recv_info = sx_receive_info_t()
    recv_info_p = copy_sx_receive_info_t_p(recv_info)
    # wait for trap id
    received_packets_list = []
    for i in range(WAIT_HOSTIFC_LOOP):
        rc = sx_lib_host_ifc_recv(trap_fd_p, pkt_p, pkt_size_p, recv_info_p)
        check_sdk_rc(rc, "sx_lib_host_ifc_recv failed")
        recv_info2 = sx_receive_info_t_p_value(recv_info_p)
        recv_info = "recv_info" + str(i)
        received_packets_list.append({recv_info: {'acl_user_id': recv_info2.acl_user_id,
                                                  'dest_lag_port': recv_info2.dest_lag_port,
                                                  'dest_log_port': recv_info2.dest_log_port,
                                                  'dest_port_type': recv_info2.dest_port_type,
                                                  'event_info': recv_info2.event_info,
                                                  'buffer_id': recv_info2.event_info.bulk_cntr_done_info.buffer_id,
                                                  'bulk_cntr_done_status': recv_info2.event_info.bulk_cntr_done_info.status,
                                                  'is_lag': recv_info2.is_lag,
                                                  'original_packet_size': recv_info2.original_packet_size,
                                                  'source_lag_port': recv_info2.source_lag_port,
                                                  'source_log_port': recv_info2.source_log_port,
                                                  'trap_id': recv_info2.trap_id}})
        if recv_info2.trap_id == trap_id and recv_info2.event_info.bulk_cntr_done_info.buffer_id == buffer_id:
            break
        time.sleep(WAIT_HOSTIFC_INTV)


def cancel_counter(s_handle, trap_fd, counter_buffer, trap_id):
    rc = sx_api_bulk_counter_transaction_set(s_handle, SX_ACCESS_CMD_READ, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set READ failed ")

    rc = sx_api_bulk_counter_transaction_set(s_handle, SX_ACCESS_CMD_DISABLE, counter_buffer)

    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)


def read_shared_buffer_counters(s_handle, trap_fd, counter_buffer, trap_id, port_list, clear):
    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed ".format(cmd_str))

    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    ret = []
    print('\nShared buffer counters')
    for log_port in port_list:
        print("#" * 80)
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_SHARED_BUFFER_E

        # PORT statistics
        cntr_read_key.key.shared_buffer_key.type = SX_BULK_CNTR_SHARED_BUFFER_PORT_ATTR_E
        cntr_read_key.key.shared_buffer_key.attr.log_port = log_port
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port : '0x{:x}'".format(log_port))

        shared_buffer_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)

        # Port PG
        for pg in range(10):
            buff_stat = sx_cos_buff_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.port_pg, pg)
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', pg:'{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pg, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

        # Port TC
        for tc in range(17):
            buff_stat = sx_cos_buff_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.port_tc, tc)
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', tc:'{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, tc, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

        # Port ingress pool
        for pool_idx in range(16):
            pool_stat = sx_bulk_cntr_shared_buffer_pool_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.ingress_port,
                                                                                pool_idx)
            if pool_stat.pool_id == INVALID_POOL_ID:
                print("reach end of pool list")
                break
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', ingress pool: '{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pool_stat.pool_id, pool_stat.statistics.curr_occupancy, pool_stat.statistics.watermark))
        print("#" * 80)

        # Port egress pool
        for pool_idx in range(16):
            pool_stat = sx_bulk_cntr_shared_buffer_pool_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.egress_port,
                                                                                pool_idx)
            if pool_stat.pool_id == INVALID_POOL_ID:
                print("reach end of pool list")
                break
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', egress pool: '{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pool_stat.pool_id, pool_stat.statistics.curr_occupancy, pool_stat.statistics.watermark))
        print("#" * 80)

        # Port PG descriptor
        for pg in range(10):
            buff_stat = sx_cos_buff_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.port_pg_desc, pg)
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', pg desc:'{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pg, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

        # Port TC descriptor
        for tc in range(17):
            buff_stat = sx_cos_buff_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.port_tc_desc, tc)
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', tc desc:'{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, tc, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

        # Port ingress pool descriptor
        for pool_idx in range(16):
            pool_stat = sx_bulk_cntr_shared_buffer_pool_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.ingress_port_desc,
                                                                                pool_idx)
            if pool_stat.pool_id == INVALID_POOL_ID:
                print("reach end of pool list")
                break
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', ingress pool desc: '{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pool_stat.pool_id, pool_stat.statistics.curr_occupancy, pool_stat.statistics.watermark))
        print("#" * 80)

        # Port egress pool descriptor
        for pool_idx in range(16):
            pool_stat = sx_bulk_cntr_shared_buffer_pool_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.port_p.egress_port_desc,
                                                                                pool_idx)
            if pool_stat.pool_id == INVALID_POOL_ID:
                print("reach end of pool list")
                break
            print("#" * 5 + "\tBULK counter get: port:'0x{:x}', egress pool desc: '{}', curr_occupancy:'{}', watermark:'{}'".format(
                log_port, pool_stat.pool_id, pool_stat.statistics.curr_occupancy, pool_stat.statistics.watermark))
        print("#" * 80)

        # MC PORT statistics
        cntr_read_key.key.shared_buffer_key.type = SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_PORT_ATTR_E
        cntr_read_key.key.shared_buffer_key.attr.log_port = log_port
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port : '0x{:x}'".format(log_port))

        shared_buffer_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)

        # MC port
        buff_stat = cntr_val.data.shared_buffer_counters.mc_port_p.statistics
        print("#" * 5 + "\tBULK counter get: mc port:'0x{:x}', curr_occupancy:'{}', watermark:'{}'".format(
            log_port, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

    # MC SP statistics
    cntr_read_key.key.shared_buffer_key.type = SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_ATTR_E
    rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for MC SP statistics'")

    shared_buffer_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)

    # Multicast switch priority
    for sp in range(16):
        buff_stat = sx_cos_buff_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.mc_switch_prio_p.statistics, sp)
        print("#" * 5 + "\tBULK counter get: sp:'{}', curr_occupancy:'{}', watermark:'{}'".format(
            sp, buff_stat.curr_occupancy, buff_stat.watermark))
    print("#" * 80)

    # Pool statistics
    cntr_read_key.key.shared_buffer_key.type = SX_BULK_CNTR_SHARED_BUFFER_POOL_ATTR_E
    rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for pool statistics")

    shared_buffer_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)

    # Pool
    for pool_idx in range(65):
        pool_stat = sx_bulk_cntr_shared_buffer_pool_statistic_t_arr_getitem(cntr_val.data.shared_buffer_counters.pool_p.statistics,
                                                                            pool_idx)
        if pool_stat.pool_id == INVALID_POOL_ID:
            print("reach end of pool list")
            break
        print("#" * 5 + "\tBULK counter get: pool: '{}', curr_occupancy:'{}', watermark:'{}'".format(
            pool_stat.pool_id, pool_stat.statistics.curr_occupancy, pool_stat.statistics.watermark))
    print("#" * 80)

    return ret


def bulk_shared_buffer_counters_buffer_set(handle, cmd, counter_buffer_id=None):
    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_SHARED_BUFFER_E
            counter_buffer_key.key.shared_buffer_key.type = SX_BULK_CNTR_SHARED_BUFFER_CURRENT_E
        elif cmd == SX_ACCESS_CMD_DESTROY:
            cntr_buffer = counter_buffer_id
            counter_buffer_key = None

        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)


def bulk_shared_buffer_counter_example(handle, trap_id, sx_fd, port_list, clear):
    # alloc bulk counters buffer
    counter_buffer_id = bulk_shared_buffer_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE)

    # cancel counters
    cancel_counter(handle, sx_fd, counter_buffer_id, trap_id)

    # release bulk buffer
    bulk_shared_buffer_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, counter_buffer_id)

    # alloc bulk counters buffer
    counter_buffer_id = bulk_shared_buffer_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE)

    # read bulk counters
    read_shared_buffer_counters(handle, sx_fd, counter_buffer_id, trap_id, port_list, clear)

    # release bulk buffer
    bulk_shared_buffer_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, counter_buffer_id)


def read_headroom_counters(s_handle, trap_fd, counter_buffer, trap_id, port_list, clear):
    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed ".format(cmd_str))

    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    ret = []
    print('\nHeadroom counters')
    for log_port in port_list:
        print("#" * 80)
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_HEADROOM_E
        cntr_read_key.key.headroom_key.log_port = log_port
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port : '0x{:x}'".format(log_port))

        headroom_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)

        # Port PG
        for pg in range(10):
            headroom_stat = sx_bulk_cntr_headroom_statistic_t_arr_getitem(cntr_val.data.headroom_counters.headroom_p.port_pg, pg)
            print("#" * 5 + "\tBULK counter get: Port PG, port:'0x{:x}', pg:'{}', curr_occupancy:'{}', watermark:'{}', cnt:'{}'".format(
                  log_port, pg, headroom_stat.statistics.curr_occupancy, headroom_stat.statistics.watermark,
                  headroom_stat.occupancy_statistics_lst.cnt))
            for idx in range(headroom_stat.occupancy_statistics_lst.cnt):
                stat = sx_cos_buff_statistic_t_arr_getitem(headroom_stat.occupancy_statistics_lst.statistics, idx)
                print("#" * 5 + "\tBULK counter get: idx: '{}', curr_occupancy:'{}', watermark:'{}'".format(idx, stat.curr_occupancy, stat.watermark))
        print("#" * 80)

        # Port shared buffer
        headroom_stat = cntr_val.data.headroom_counters.headroom_p.port_shared_buffer
        print("#" * 5 + "\tBULK counter get: Port shared buffer, port:'0x{:x}', curr_occupancy:'{}', watermark:'{}', cnt:'{}'".format(
              log_port, headroom_stat.statistics.curr_occupancy, headroom_stat.statistics.watermark,
              headroom_stat.occupancy_statistics_lst.cnt))
        for idx in range(headroom_stat.occupancy_statistics_lst.cnt):
            stat = sx_cos_buff_statistic_t_arr_getitem(headroom_stat.occupancy_statistics_lst.statistics, idx)
            print("#" * 5 + "\tBULK counter get: idx: '{}', curr_occupancy:'{}', watermark:'{}'".format(idx, stat.curr_occupancy, stat.watermark))
        print("#" * 80)

        # Port shared headrooom
        buff_stat = cntr_val.data.headroom_counters.headroom_p.port_shared_headroom_pool_usage
        print("#" * 5 + "\tBULK counter get: Port shared headrooom, port:'0x{:x}', curr_occupancy:'{}', watermark:'{}'".format(
              log_port, buff_stat.curr_occupancy, buff_stat.watermark))
        print("#" * 80)

    # Compare to old API

    return ret


def bulk_headroom_counters_buffer_set(handle, cmd, port_list, counter_buffer_id=None):
    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_HEADROOM_E
            for i, port in enumerate(port_list):
                sx_port_log_id_t_arr_setitem(counter_buffer_key.key.headroom_key.port_list, i, port)
            counter_buffer_key.key.headroom_key.port_list_cnt = len(port_list)
        elif cmd == SX_ACCESS_CMD_DESTROY:
            cntr_buffer = counter_buffer_id
            counter_buffer_key = None

        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)


def bulk_headroom_counter_example(handle, trap_id, sx_fd, port_list, clear):
    # alloc bulk headroom counters buffer
    counter_buffer_id = bulk_headroom_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE, port_list)

    print("The cancel operation may not succeed due to the read transcation ends before cancel operation is issued, it's a normal scenario.")
    # cancel counters
    cancel_counter(handle, sx_fd, counter_buffer_id, trap_id)

    # release bulk buffer
    bulk_headroom_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, port_list, counter_buffer_id)

    # alloc bulk headroom counters buffer
    counter_buffer_id = bulk_headroom_counters_buffer_set(handle, SX_ACCESS_CMD_CREATE, port_list)

    # read bulk counters
    read_headroom_counters(handle, sx_fd, counter_buffer_id, trap_id, port_list, clear)

    # release bulk buffer
    bulk_headroom_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, port_list, counter_buffer_id)


def switch_to_grp_bitmap(cnt_type):
    grp_map = 0
    if cnt_type == ALL_S or cnt_type == IEEE_802_DOT_3_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_IEEE_802_DOT_3_E
    if cnt_type == ALL_S or cnt_type == RFC_2863_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_RFC_2863_E
    if cnt_type == ALL_S or cnt_type == RFC_2819_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_RFC_2819_E
    if cnt_type == ALL_S or cnt_type == RFC_3635_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_RFC_3635_E
    if cnt_type == ALL_S or cnt_type == PERF_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_PERF_E
    if cnt_type == ALL_S or cnt_type == DISCARD_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_DISCARD_E
    if cnt_type == ALL_S or cnt_type == PRIO_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_PRIO_E
    if cnt_type == ALL_S or cnt_type == TC_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_TC_E
    if cnt_type == ALL_S or cnt_type == BUFF_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_BUFF_E
    if cnt_type == ALL_S or cnt_type == PHY_LAYER_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_PHY_LAYER_E
    if cnt_type == ALL_S or cnt_type == PHY_LAYER_STATS_S:
        grp_map |= SX_BULK_CNTR_PORT_GRP_PHY_LAYER_STATS_E
    if grp_map == 0:
        print("Invalid input cnt_type: 0x{:x}".format(cnt_type))
    return grp_map


def generate_grp_bitmap(cnt_types):
    grp_map = 0
    for cnt_type in cnt_types:
        grp_map |= switch_to_grp_bitmap(cnt_type)
    return grp_map


def print_port_grp_type_cntrs(port_counter_data, grp_map, port, prio_tc_pg):
    if grp_map == SX_BULK_CNTR_PORT_GRP_IEEE_802_DOT_3_E:
        print("\nPort 0x%x - IEEE 802.3 Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_ieee_802_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_RFC_2863_E:
        print("\nPort 0x%x - RFC 2863 Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_rfc_2863_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_RFC_2819_E:
        print("\nPort 0x%x - RFC 2819 Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_rfc_2819_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_RFC_3635_E:
        print("\nPort 0x%x - RFC 3635 Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_rfc_3635_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_PERF_E:
        print("\nPort 0x%x - EXTENDED (perf) Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_perf_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_DISCARD_E:
        print("\nPort 0x%x - DISCARD Counters Group" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_discard_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_PRIO_E:
        print("\nPort 0x%x - PER PRIO Counters Group, prio:%d" % (port, prio_tc_pg))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_prio_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_TC_E:
        print("\nPort 0x%x - PER TC Counters Group, TC:%d" % (port, prio_tc_pg))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_tc_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_BUFF_E:
        print("\nPort 0x%x - PER BUFF Counters Group, Buff:%d" % (port, prio_tc_pg))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_buff_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_PHY_LAYER_E:
        print("\nPort 0x%x - PHY layer" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_phy_p)
    if grp_map == SX_BULK_CNTR_PORT_GRP_PHY_LAYER_STATS_E:
        print("\nPort 0x%x - PHY layer statistics" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.port_counters.port_cntr_phy_stats_p)


def read_ports_counters(s_handle, trap_fd, counter_buffer, cntr_keys, trap_id, clear):
    grp_types = cntr_keys["types"]
    port_list = cntr_keys["port_list"]
    prio_ids = cntr_keys["prio_ids"]
    tc_ids = cntr_keys["tc_ids"]
    prio_groups = cntr_keys["prio_groups"]
    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)
    ret = []
    print('\nPort counters')
    print("#" * 80)
    grp_bitmap = generate_grp_bitmap(grp_types)
    for port in port_list:
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_PORT_E
        cntr_read_key.key.port_key.log_port = port
        for grp_type_bit in bulk_cntr_port_grp_list:
            if grp_type_bit & grp_bitmap:
                cntr_read_key.key.port_key.grp = grp_type_bit
                if grp_type_bit == SX_BULK_CNTR_PORT_GRP_PRIO_E:
                    for prio in prio_ids:
                        cntr_read_key.key.port_key.grp_ex_param.prio_id = prio
                        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
                        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}, group type:0x{:x}, prio:{}".format(port, grp_type_bit, prio))
                        port_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
                        print_port_grp_type_cntrs(port_counter_data, grp_type_bit, port, prio)
                elif grp_type_bit == SX_BULK_CNTR_PORT_GRP_TC_E:
                    for tc in tc_ids:
                        cntr_read_key.key.port_key.grp_ex_param.tc_id = tc
                        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
                        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}, group type:0x{:x}, TC:{}".format(port, grp_type_bit, tc))
                        port_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
                        print_port_grp_type_cntrs(port_counter_data, grp_type_bit, port, tc)
                elif grp_type_bit == SX_BULK_CNTR_PORT_GRP_BUFF_E:
                    for prio_grp in prio_groups:
                        cntr_read_key.key.port_key.grp_ex_param.prio_group = prio_grp
                        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
                        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}, group type:0x{:x}, PG:{}".format(port, grp_type_bit, prio_grp))
                        port_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
                        print_port_grp_type_cntrs(port_counter_data, grp_type_bit, port, prio_grp)
                else:
                    rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
                    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}, group type:0x{:x}".format(port, grp_type_bit))
                    port_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
                    print_port_grp_type_cntrs(port_counter_data, grp_type_bit, port, 0)
    print("#" * 80)
    return ret


def get_port_list(cntr_keys):
    port_list = []
    if cntr_keys["port_list"][0] == ALL_POSSIBLE_VALUES:
        port_attr_list = ports_attributes_get(handle)  # Get all ports' attributes
        # filter out CPU and NVE ports
        port_attr_list = list(filter(
            lambda port: not check_cpu(int(port.log_port)) and not check_vport(int(port.log_port)) and not check_nve(int(port.log_port)),
            port_attr_list))
        for port_attr in port_attr_list:
            port_list.append(port_attr.log_port)
        cntr_keys["port_list"] = port_list
    else:
        port_list = cntr_keys["port_list"]
    return port_list


def is_macsec_supported():
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_SUCCESS:
            return True
        else:
            return False
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


def is_port_macsec_enabled(port):
    port_capability_p = new_sx_macsec_port_capability_t_p()
    try:
        rc = sx_api_macsec_port_capability_get(handle, port, port_capability_p)
        if bool(port_capability_p.macsec_supported) and bool(port_capability_p.macsec_enabled):
            return True
        else:
            return False
    finally:
        delete_sx_macsec_port_capability_t_p(port_capability_p)


def get_macsec_port_list(cntr_keys):
    port_list = []
    if cntr_keys["port_list"][0] == ALL_POSSIBLE_VALUES:
        if not is_macsec_supported():
            return port_list
        port_attr_list = ports_attributes_get(handle)  # Get all ports' attributes
        # filter out CPU and NVE ports
        port_attr_list = list(filter(
            lambda port: (not check_cpu(int(port.log_port)) and not check_vport(int(port.log_port)) and not check_nve(int(port.log_port)) and is_port_macsec_enabled(port.log_port)),
            port_attr_list))
        for port_attr in port_attr_list:
            port_list.append(port_attr.log_port)
        cntr_keys["port_list"] = port_list
    else:
        port_list = cntr_keys["port_list"]
    return port_list


def get_prio_list(cntr_keys):
    prio_ids = []
    if cntr_keys["prio_ids"][0] == ALL_POSSIBLE_VALUES:
        for prio_id in range(COS_IEEE_PRIO_MAX_NUM + 1):
            prio_ids.append(prio_id)
        cntr_keys["prio_ids"] = prio_ids
    else:
        prio_ids = cntr_keys["prio_ids"]
    return prio_ids


def get_tc_list(cntr_keys):
    tc_ids = []
    if cntr_keys["tc_ids"][0] == ALL_POSSIBLE_VALUES:
        mc_aware_p = new_boolean_t_p()
        rc = sx_api_cos_port_tc_mcaware_get(handle, port_list[0], mc_aware_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_tc_mcaware_get failed, rc = %d" % (rc))
            sys.exit(rc)

        sx_port_max_tc_val = SX_PORT_TC_ID_MAX
        mc_aware = boolean_t_p_value(mc_aware_p)
        if mc_aware:
            sx_port_max_tc_val = SX_PORT_TC_ID_7

        for tc in range(SX_PORT_TC_ID_MIN, sx_port_max_tc_val + 1):
            tc_ids.append(tc)
        cntr_keys["tc_ids"] = tc_ids
    else:
        tc_ids = cntr_keys["tc_ids"]
    return tc_ids


def get_prio_grp_list(cntr_keys):
    prio_groups = []
    if cntr_keys["prio_groups"][0] == ALL_POSSIBLE_VALUES:
        for pg in range(1, 8):
            prio_groups.append(pg)
        cntr_keys["prio_groups"] = prio_groups
    else:
        prio_groups = cntr_keys["prio_groups"]
    return prio_groups


def bulk_port_counters_buffer_set(handle, cmd, cntr_keys, counter_buffer_id=None):
    if cntr_keys is not None:
        types = cntr_keys["types"]
        port_list = get_port_list(cntr_keys)
        prio_ids = get_prio_list(cntr_keys)
        tc_ids = get_tc_list(cntr_keys)
        prio_groups = get_prio_grp_list(cntr_keys)
        grp_bitmap = generate_grp_bitmap(types)

    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    ports_array = new_sx_port_log_id_t_arr(MAX_PHYPORT_NUM + MAX_LAG_NUM)
    prio_array = new_sx_cos_ieee_prio_t_arr(SX_PORT_PRIO_ID_MAX - SX_PORT_PRIO_ID_MIN + 1)
    tc_array = new_sx_port_tc_id_t_arr(SX_PORT_TC_ID_MAX - SX_PORT_TC_ID_MIN + 1)
    pg_array = new_sx_cos_priority_group_t_arr(RM_API_COS_BUFFERS_NUM)
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_PORT_E
            counter_buffer_key.key.port_key.grp_bitmap = grp_bitmap
            for i, port in enumerate(port_list):
                sx_port_log_id_t_arr_setitem(ports_array, i, port)
            counter_buffer_key.key.port_key.port_list = ports_array
            counter_buffer_key.key.port_key.port_list_cnt = len(port_list)
            for i, prio in enumerate(prio_ids):
                sx_cos_ieee_prio_t_arr_setitem(prio_array, i, prio)
            counter_buffer_key.key.port_key.prio_id_list = prio_array
            counter_buffer_key.key.port_key.prio_id_list_cnt = len(prio_ids)
            for i, tc in enumerate(tc_ids):
                sx_port_tc_id_t_arr_setitem(tc_array, i, tc)
            counter_buffer_key.key.port_key.tc_id_list = tc_array
            counter_buffer_key.key.port_key.tc_id_list_cnt = len(tc_ids)
            for i, pg in enumerate(prio_groups):
                sx_cos_priority_group_t_arr_setitem(pg_array, i, pg)
            counter_buffer_key.key.port_key.prio_group_list = pg_array
            counter_buffer_key.key.port_key.prio_group_list_cnt = len(prio_groups)
        elif cmd == SX_ACCESS_CMD_DESTROY:
            cntr_buffer = counter_buffer_id
            counter_buffer_key = None
        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        delete_sx_port_log_id_t_arr(ports_array)


def bulk_ports_counter_example(handle, trap_id, sx_fd, cnt_keys, clear):
    # alloc bulk flow counters buffer
    counter_buff_id = bulk_port_counters_buffer_set(handle, cmd=SX_ACCESS_CMD_CREATE, cntr_keys=cnt_keys)

    # read bulk counters
    read_ports_counters(handle, sx_fd, counter_buff_id, cnt_keys, trap_id, clear)

    # deallocate_port_counters
    bulk_port_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buff_id)


def print_macsec_port_grp_type_cntrs(port_counter_data, grp_map, port):
    if grp_map == SX_BULK_CNTR_MACSEC_PORT_GRP_0:
        print("\nPort 0x%x - Port Counters Group 0" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.macsec_port_counters.port_stats_grp0_p)
    if grp_map == SX_BULK_CNTR_MACSEC_PORT_GRP_1:
        print("\nPort 0x%x - Port Counters Group 1" % (port))
        print("==================================================")
        print_all_attr_of_struct(port_counter_data.data.macsec_port_counters.port_stats_grp1_p)


def read_macsec_ports_counters(s_handle, trap_fd, counter_buffer, cntr_keys, trap_id, clear):
    cnt_types = cntr_keys["types"]
    port_list = get_macsec_port_list(cntr_keys)

    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"
    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    ret = []
    print('\nPort counters')
    print("#" * 80)

    grp_map = 0
    for cnt_type in cnt_types:
        if cnt_type == ALL_S or cnt_type == MACSEC_PORT_GRP0:
            grp_map |= SX_BULK_CNTR_MACSEC_PORT_GRP_0
        if cnt_type == ALL_S or cnt_type == MACSEC_PORT_GRP1:
            grp_map |= SX_BULK_CNTR_MACSEC_PORT_GRP_1

    for port in port_list:
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E
        cntr_read_key.key.macsec_port_key.log_port = port
        for grp_type_bit in bulk_cntr_macsec_port_grp_list:
            if grp_type_bit & grp_map:
                cntr_read_key.key.macsec_port_key.type = grp_type_bit
                rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
                check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}, group type:0x{:x}".format(port, grp_type_bit))
                port_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
                print_macsec_port_grp_type_cntrs(port_counter_data, grp_type_bit, port)


def bulk_macsec_port_counters_buffer_set(handle, cmd, cntr_keys, counter_buffer_id=None):
    cnt_types = []
    if cntr_keys is not None:
        cnt_types = cntr_keys["types"]
        port_list = get_macsec_port_list(cntr_keys)

    grp_map = 0
    for cnt_type in cnt_types:
        if cnt_type == ALL_S or cnt_type == MACSEC_PORT_GRP0:
            grp_map |= SX_BULK_CNTR_MACSEC_PORT_GRP_0
        if cnt_type == ALL_S or cnt_type == MACSEC_PORT_GRP1:
            grp_map |= SX_BULK_CNTR_MACSEC_PORT_GRP_1

    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    ports_array = new_sx_port_log_id_t_arr(MAX_PHYPORT_NUM + MAX_LAG_NUM)
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E
            counter_buffer_key.key.macsec_port_key.grp_bitmap = grp_map
            for i, port in enumerate(port_list):
                sx_port_log_id_t_arr_setitem(ports_array, i, port)
            counter_buffer_key.key.macsec_port_key.port_list = ports_array
            counter_buffer_key.key.macsec_port_key.port_list_cnt = len(port_list)
        rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
        check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
        if cmd == SX_ACCESS_CMD_DESTROY:
            return
        counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        delete_sx_port_log_id_t_arr(ports_array)


def bulk_macsec_ports_counter_example(handle, trap_id, sx_fd, cnt_keys, clear):
    # alloc bulk macsec port counters buffer
    counter_buff_id = bulk_macsec_port_counters_buffer_set(handle, cmd=SX_ACCESS_CMD_CREATE, cntr_keys=cnt_keys)

    # read bulk counters
    read_macsec_ports_counters(handle, sx_fd, counter_buff_id, cnt_keys, trap_id, clear)

    # deallocate_port_counters
    bulk_macsec_port_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buff_id)


def bulk_macsec_acl_counters_buffer_set(handle, cmd, cntr_keys, counter_buffer_id=None):
    if cntr_keys is not None:
        direction = cnt_keys["direction"]
        base_entity_id = cnt_keys["base_entity_id"]
        num_rec = cnt_keys["num_rec"]
        port_list = get_macsec_port_list(cntr_keys)

    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    ports_array = new_sx_port_log_id_t_arr(MAX_PHYPORT_NUM + MAX_LAG_NUM)
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E
            counter_buffer_key.key.macsec_acl_flow_key.base_entity_id = base_entity_id
            if direction == 'ingress':
                counter_buffer_key.key.macsec_acl_flow_key.direction = SX_MACSEC_DIR_INGRESS_E
            else:
                counter_buffer_key.key.macsec_acl_flow_key.direction = SX_MACSEC_DIR_EGRESS_E
            counter_buffer_key.key.macsec_acl_flow_key.num_of_counters = num_rec
            for i, port in enumerate(port_list):
                sx_port_log_id_t_arr_setitem(ports_array, i, port)
            counter_buffer_key.key.macsec_acl_flow_key.port_list = ports_array
            counter_buffer_key.key.macsec_acl_flow_key.port_list_cnt = len(port_list)
            rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
            check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
            if cmd == SX_ACCESS_CMD_DESTROY:
                return
            counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
            return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)
        delete_sx_port_log_id_t_arr(ports_array)


def read_macsec_acl_counters(s_handle, trap_fd, counter_buffer, cntr_keys, trap_id, clear):
    port_list = get_macsec_port_list(cntr_keys)
    direction = cnt_keys["direction"]
    base_entity_id = cnt_keys["base_entity_id"]
    num_rec = cnt_keys["num_rec"]

    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"

    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    ret = []
    print('\nMACSec ACL port counters')
    print("#" * 80)

    for port in port_list:
        cntr_val = new_sx_bulk_cntr_data_t_p()
        cntr_read_key = sx_bulk_cntr_read_key_t()
        cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E
        cntr_read_key.key.macsec_acl_flow_key.counter_id = 0
        cntr_read_key.key.macsec_acl_flow_key.counter_id = (((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS) << SX_MACSEC_PORT_OFFSET_OBJ_ID)
        cntr_read_key.key.macsec_acl_flow_key.counter_id |= 1 << SX_MACSEC_ACL_COUNTER_ENTITY_TYPE_OFFSET_OBJ_ID
        if direction == 'ingress':
            cntr_read_key.key.macsec_acl_flow_key.counter_id |= 1 << SX_MACSEC_INGRESS_DIR_OFFSET_OBJ_ID
        else:
            cntr_read_key.key.macsec_acl_flow_key.counter_id |= 1 << SX_MACSEC_EGRESS_DIR_OFFSET_OBJ_ID

        for i in range(num_rec):
            cntr_read_key.key.macsec_acl_flow_key.counter_id &= ~0xFFFF
            cntr_read_key.key.macsec_acl_flow_key.counter_id |= ((base_entity_id + i) & SX_MACSEC_ENTITY_ID_MASK_OBJ_ID)
            rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
            check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}".format(port))
            acl_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
            print("\nPort 0x{:x} - MacSec ACL Counters 0x{:x}" .format(port, cntr_read_key.key.macsec_acl_flow_key.counter_id))
            print("==================================================")
            print_all_attr_of_struct(acl_counter_data.data.macsec_acl_flow_counters.acl_counter_data_p)


def bulk_macsec_acl_counter_example(handle, trap_id, sx_fd, cnt_keys, clear):
    # alloc bulk macsec acl counters buffer
    counter_buff_id = bulk_macsec_acl_counters_buffer_set(handle, cmd=SX_ACCESS_CMD_CREATE, cntr_keys=cnt_keys)

    # read bulk counters
    read_macsec_acl_counters(handle, sx_fd, counter_buff_id, cnt_keys, trap_id, clear)

    # deallocate_macsec_acl_counters
    bulk_macsec_acl_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buff_id)


def bulk_macsec_sa_counters_buffer_set(handle, cmd, cntr_keys, counter_buffer_id=None):
    if cntr_keys is not None:
        direction = cnt_keys["direction"]
        base_entity_id = cnt_keys["base_entity_id"]
        num_rec = cnt_keys["num_rec"]
        port_list = get_macsec_port_list(cntr_keys)

        if len(port_list) > 1:
            print("MACSec SA counters can be fetched for only one port at a time\n")
            return

    cntr_buffer = new_sx_bulk_cntr_buffer_t_p()
    try:
        if cmd == SX_ACCESS_CMD_CREATE:
            counter_buffer_key = sx_bulk_cntr_buffer_key_t()
            counter_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E
            counter_buffer_key.key.macsec_sa_key.base_entity_id = base_entity_id
            if direction == 'ingress':
                counter_buffer_key.key.macsec_sa_key.direction = SX_MACSEC_DIR_INGRESS_E
            else:
                counter_buffer_key.key.macsec_sa_key.direction = SX_MACSEC_DIR_EGRESS_E
            counter_buffer_key.key.macsec_sa_key.num_of_counters = num_rec
            counter_buffer_key.key.macsec_sa_key.port = port_list[0]
            rc = sx_api_bulk_counter_buffer_set(handle, cmd, counter_buffer_key, cntr_buffer)
            check_sdk_rc(rc, "sx_api_bulk_counter_buffer_set failed")
            if cmd == SX_ACCESS_CMD_DESTROY:
                return
            counter_buffer = copy_sx_bulk_cntr_buffer_t_p(cntr_buffer)
            return counter_buffer
    finally:
        delete_sx_bulk_cntr_buffer_t_p(cntr_buffer)


def read_macsec_sa_counters(s_handle, trap_fd, counter_buffer, cntr_keys, trap_id, clear):
    port_list = get_macsec_port_list(cntr_keys)
    direction = cnt_keys["direction"]
    base_entity_id = cnt_keys["base_entity_id"]
    num_rec = cnt_keys["num_rec"]

    if clear:
        cmd = SX_ACCESS_CMD_READ_CLEAR
        cmd_str = "READ_CLEAR"
    else:
        cmd = SX_ACCESS_CMD_READ
        cmd_str = "READ"

    rc = sx_api_bulk_counter_transaction_set(s_handle, cmd, counter_buffer)
    check_sdk_rc(rc, "sx_api_bulk_counter_transaction_set {} failed".format(cmd_str))
    wait_bulk_counter_done(trap_fd, trap_id, counter_buffer.buffer_id)

    ret = []
    print('\nMACSec SA counters')
    print("#" * 80)

    port = port_list[0]
    cntr_val = new_sx_bulk_cntr_data_t_p()
    cntr_read_key = sx_bulk_cntr_read_key_t()
    cntr_read_key.type = SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E
    cntr_read_key.key.macsec_sa_key.sa_id = 0
    cntr_read_key.key.macsec_sa_key.sa_id = (((port & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS) << SX_MACSEC_PORT_OFFSET_OBJ_ID)
    cntr_read_key.key.macsec_sa_key.sa_id |= 1 << SX_MACSEC_SA_ENTITY_TYPE_OFFSET_OBJ_ID
    if direction == 'ingress':
        cntr_read_key.key.macsec_sa_key.sa_id |= 1 << SX_MACSEC_INGRESS_DIR_OFFSET_OBJ_ID
    else:
        cntr_read_key.key.macsec_sa_key.sa_id |= 1 << SX_MACSEC_EGRESS_DIR_OFFSET_OBJ_ID

    for i in range(num_rec):
        cntr_read_key.key.macsec_sa_key.sa_id &= ~0xFFFF
        cntr_read_key.key.macsec_sa_key.sa_id |= ((base_entity_id + i) & SX_MACSEC_ENTITY_ID_MASK_OBJ_ID)
        rc = sx_api_bulk_counter_transaction_get(s_handle, cntr_read_key, counter_buffer, cntr_val)
        check_sdk_rc(rc, "sx_api_bulk_counter_transaction_get failed for port:0x{:x}".format(port))
        sa_counter_data = sx_bulk_cntr_data_t_p_value(cntr_val)
        print("\nPort 0x{:x} - MacSec SA Counters 0x{:x}" .format(port, cntr_read_key.key.macsec_sa_key.sa_id))
        print("==================================================")
        print_all_attr_of_struct(sa_counter_data.data.macsec_sa_counters.sa_stats_data_p)


def bulk_macsec_sa_counter_example(handle, trap_id, sx_fd, cnt_keys, clear):
    # alloc bulk macsec sa counters buffer
    counter_buff_id = bulk_macsec_sa_counters_buffer_set(handle, cmd=SX_ACCESS_CMD_CREATE, cntr_keys=cnt_keys)

    # read bulk counters
    read_macsec_sa_counters(handle, sx_fd, counter_buff_id, cnt_keys, trap_id, clear)

    # deallocate_port_counters
    bulk_macsec_sa_counters_buffer_set(handle, SX_ACCESS_CMD_DESTROY, None, counter_buff_id)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Bulk Port/Flow Counter utility')
    parser.add_argument('--counter_type', default=ALL_S, choices=[ALL_S, 'flow', 'accuflow', 'port', 'shared_buff', 'headroom', "flow_estimator", "macsec_port", "macsec_acl", "macsec_sa"], help='select specific bulk counter')
    parser.add_argument('--log_ports', default=[0x10001], nargs='+', type=auto_int, help='Logical port ID list for port/shared_buff/headroom bulk counter, logport 0xFFFFFFFF denote all possible ports')
    parser.add_argument('--prio_ids', default=[0], nargs='+', type=auto_int, help='Priority ID list for port bulk counter, prio_id 0xFFFFFFFF denote all possible prio_id')
    parser.add_argument('--tc_ids', default=[0], nargs='+', type=auto_int, help='TC ID list for port bulk counter, tc_id 0xFFFFFFFF denote all possible prio_id')
    parser.add_argument('--prio_groups', default=[0], nargs='+', type=auto_int, help='Priority group list for port bulk counter, prio_group 0xFFFFFFFF denote all possible prio_groups')
    parser.add_argument('--types', default=[ALL_S], nargs='+',
                        choices=[ALL_S, IEEE_802_DOT_3_S, RFC_2863_S, RFC_2819_S, RFC_3635_S, PERF_S, DISCARD_S, PRIO_S, TC_S, BUFF_S, PHY_LAYER_S, PHY_LAYER_STATS_S],
                        help='only for port bulk counter: display specific counter set')
    parser.add_argument('--clear', action='store_true', help='Whether to clear the counters')
    parser.add_argument('--macsec_cnt_types', default=[ALL_S], nargs='+',
                        choices=[ALL_S, MACSEC_PORT_GRP0, MACSEC_PORT_GRP1],
                        help='only for macsec port bulk counter: display specific counter set')
    parser.add_argument('--direction', choices=['ingress', 'egress'], default="", help='Traffic direction')
    parser.add_argument('--base_entity_id', type=auto_int, default="0", help='base counter entity Id')
    parser.add_argument('--num_rec', type=auto_int, default="0", help='Number of records')
    args = parser.parse_args()

    chip_type = get_chip_type(handle)

    trap_id = SX_TRAP_ID_BULK_COUNTER_DONE_EVENT
    sx_fdp = host_ifc_open(handle)
    sx_fd = sx_fd_t_p_value(sx_fdp)
    user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, trap_id, None, sx_fdp)

    if args.counter_type == ALL_S or args.counter_type == "flow":
        bulk_flow_counter_example(handle, trap_id, sx_fd, args.clear, "flow")

    if args.counter_type == ALL_S or args.counter_type == "flow_estimator":
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("Skip flow estimator counters, not available on Spectrum1")
        else:
            bulk_flow_estimator_example(handle, trap_id, sx_fd, args.clear)

    if args.counter_type == ALL_S or args.counter_type == "accuflow":
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM5]:
            print("Skip accuflow counters, accuflow counters are supported starting from Spectrum-2 and on except Spectrum-5")
        else:
            bulk_flow_counter_example(handle, trap_id, sx_fd, args.clear, "accuflow")

    if args.counter_type == ALL_S or args.counter_type == "port":
        cnt_keys = {}
        cnt_keys["types"] = args.types
        cnt_keys["port_list"] = args.log_ports
        cnt_keys["prio_ids"] = args.prio_ids
        cnt_keys["tc_ids"] = args.tc_ids
        cnt_keys["prio_groups"] = args.prio_groups
        bulk_ports_counter_example(handle, trap_id, sx_fd, cnt_keys, args.clear)

    if args.counter_type == ALL_S or args.counter_type == "shared_buff":
        bulk_shared_buffer_counter_example(handle, trap_id, sx_fd, args.log_ports, args.clear)

    if args.counter_type == ALL_S or args.counter_type == "headroom":
        bulk_headroom_counter_example(handle, trap_id, sx_fd, args.log_ports, args.clear)

    if args.counter_type == "macsec_port":
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("Skip macsec port counters, not available on Spectrum1/2/3")
        else:
            cnt_keys = {}
            cnt_keys["types"] = args.macsec_cnt_types
            cnt_keys["port_list"] = args.log_ports
            bulk_macsec_ports_counter_example(handle, trap_id, sx_fd, cnt_keys, args.clear)

    if args.counter_type == "macsec_acl":
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("Skip macsec acl counters, not available on Spectrum1/2/3")
        else:
            cnt_keys = {}
            cnt_keys["direction"] = args.direction
            cnt_keys["base_entity_id"] = args.base_entity_id
            cnt_keys["num_rec"] = args.num_rec
            cnt_keys["port_list"] = args.log_ports
            bulk_macsec_acl_counter_example(handle, trap_id, sx_fd, cnt_keys, args.clear)

    if args.counter_type == "macsec_sa":
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("Skip macsec sa counters, not available on Spectrum1/2/3")
        else:
            cnt_keys = {}
            cnt_keys["direction"] = args.direction
            cnt_keys["base_entity_id"] = args.base_entity_id
            cnt_keys["num_rec"] = args.num_rec
            cnt_keys["port_list"] = args.log_ports
            bulk_macsec_sa_counter_example(handle, trap_id, sx_fd, cnt_keys, args.clear)

    user_channel = host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, trap_id, user_channel, None)
    host_ifc_close(handle, sx_fd)
