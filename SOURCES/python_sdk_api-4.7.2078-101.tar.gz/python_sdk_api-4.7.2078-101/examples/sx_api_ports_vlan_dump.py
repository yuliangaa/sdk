#!/usr/bin/env python
"""
This file contains a python commands example for the Port VLAN get API.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *


def main():
    # Constant Defines if needed
    membership_state_dict = {0: 'TAGGED', 1: 'UNTAGGED'}
    pass_state_dict = {0: 'BOTH_PASS', 1: 'INGRESS_PASS', 2: 'EGRESS_PASS'}

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        swid_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(swid_cnt_p, 0)

        # Getting num of SWIDs
        rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
            sys.exit(rc)

        swid_cnt = uint32_t_p_value(swid_cnt_p)
        swid_list_p = new_sx_swid_t_arr(swid_cnt)

        # Getting list of SWIDs
        rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
            sys.exit(rc)

        swid_cnt = uint32_t_p_value(swid_cnt_p)
        printed_header = False

        if swid_cnt == 0:
            print("No SWID entries found!")
            return 0

        for i in range(0, swid_cnt):
            swid = sx_swid_t_arr_getitem(swid_list_p, i)
            port_cnt_p = new_uint32_t_p()

            # Getting num of logical ports
            rc = sx_api_port_swid_port_list_get(handle, swid, None, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_swid_port_list_get failed, rc = %d" % (rc))
                sys.exit(rc)

            port_cnt = uint32_t_p_value(port_cnt_p)
            log_port_list_p = new_sx_port_log_id_t_arr(port_cnt)

            # Getting list of logical ports
            rc = sx_api_port_swid_port_list_get(handle, swid, log_port_list_p, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_swid_port_list_get failed, rc = %d" % (rc))
                sys.exit(rc)

            if port_cnt == 0 and not printed_header:
                print("No Ports found for SWID %d!" % (swid))

            if port_cnt > 0:
                if not printed_header:
                    print("\nLogical Port VLANs Membership Table")
                    print("===================================================================================")
                    print("|%5s|%15s|%5s|%16s|%20s|%15s|" % (
                        "SWID", "Logical Port", "PVID", "VLAN ID", "Membership State", "Pass State"))
                    print("===================================================================================")
                    printed_header = True
                for j in range(0, port_cnt):

                    log_port = sx_port_log_id_t_arr_getitem(log_port_list_p, j)

                    pvid_p = new_sx_vid_t_p()
                    rc = sx_api_vlan_port_pvid_get(handle, log_port, pvid_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_vlan_port_pvid_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    pvid = sx_vid_t_p_value(pvid_p)

                    log_port_str = "0x%x" % log_port

                    print("|%5s %15s %5d| " % (swid, log_port_str, pvid), end=" ")

                    vlan_cnt_p = new_uint16_t_p()

                    # Getting num of VLANs the port is member of
                    rc = sx_api_port_vlans_get(handle, swid, log_port, None, vlan_cnt_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_vlans_get failed, rc = %d" % (rc))
                        sys.exit(rc)

                    vlan_cnt = uint16_t_p_value(vlan_cnt_p)
                    uint16_t_p_assign(vlan_cnt_p, vlan_cnt)
                    port_vlan_list_p = new_sx_port_vlans_t_arr(vlan_cnt)

                    if vlan_cnt == 0:
                        continue

                    # Getting list of VLANs the port is member of
                    rc = sx_api_port_vlans_get(handle, swid, log_port, port_vlan_list_p, vlan_cnt_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_vlans_get failed, rc = %d" % (rc))
                        sys.exit(rc)

                    for k in range(0, vlan_cnt):
                        port_vlan = sx_port_vlans_t_arr_getitem(port_vlan_list_p, k)
                        vlan_id = port_vlan.vid
                        vlan_member_state = port_vlan.is_untagged
                        vlan_pass_state = port_vlan.pass_state

                        if k == 0:
                            print("%15s|%20s|%15s|" % (vlan_id, membership_state_dict[vlan_member_state], pass_state_dict[vlan_pass_state]))
                        else:
                            print("|%27s|%16s|%20s|%15s|" % ("", vlan_id, membership_state_dict[vlan_member_state], pass_state_dict[vlan_pass_state]))

                        if k == (vlan_cnt - 1):
                            print("===================================================================================")
                        else:
                            print("|%5s %15s %5s|------------------------------------------------------" % (
                                "", "", ""))
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
