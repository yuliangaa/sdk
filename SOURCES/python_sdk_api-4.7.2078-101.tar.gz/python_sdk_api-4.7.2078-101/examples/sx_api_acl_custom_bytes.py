#!/usr/bin/env python
# -*- python -*-

import sys
import os

import queue
import ctypes
import struct
import socket

from common_infra_acl import *
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_acl_custom_bytes example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    return args


def main():

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    args = parse_args()

    key_ids = new_sx_acl_key_t_arr(4)
    key_ids_count_p = new_uint32_t_p()
    uint32_t_p_assign(key_ids_count_p, 4)

    ingress_log_port = get_ports(handle, 1)[0]

    custom_bytes_set_attributes = sx_acl_custom_bytes_set_attributes_t()
    custom_bytes_set_attributes.extraction_point.extraction_group_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L3
    custom_bytes_set_attributes.extraction_point.params.extraction_l3_group.extraction_ipv4.extraction_point_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER
    custom_bytes_set_attributes.extraction_point.params.extraction_l3_group.extraction_ipv4.offset = 28
    custom_bytes_set_attributes.extraction_point.params.extraction_l3_group.extraction_ipv6.extraction_point_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER
    custom_bytes_set_attributes.extraction_point.params.extraction_l3_group.extraction_ipv6.offset = 48
    rc = sx_api_acl_custom_bytes_set(handle,
                                     SX_ACCESS_CMD_CREATE,
                                     custom_bytes_set_attributes,
                                     key_ids,
                                     key_ids_count_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create custom bytes set rc: %d" % (rc)

    key_ids_count = uint32_t_p_value(key_ids_count_p)

    key_handle_p = new_sx_acl_key_type_t_p()
    acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, [sx_acl_key_t_arr_getitem(key_ids, i) for i in range(0, key_ids_count)])
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)

    rules_list = new_sx_flex_acl_flex_rule_t_arr(100)
    rules = []
    acl_rules_init(rules, rules_list, 100, key_handle, 20)

    region_id_p = new_sx_acl_region_id_t_p()
    acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 10, region_id_p)
    region_id = sx_acl_region_id_t_p_value(region_id_p)

    dir = SX_ACL_DIRECTION_INGRESS
    acl_id_p = new_sx_acl_id_t_p()
    acl_handle(handle, SX_ACCESS_CMD_CREATE, dir, acl_id_p, region_id)
    acl_id = sx_acl_id_t_p_value(acl_id_p)

    group_id_p = new_sx_acl_id_t_p()
    acl_group_handle(handle, SX_ACCESS_CMD_CREATE, dir, group_id_p, [acl_id])
    group_id = sx_acl_id_t_p_value(group_id_p)

    port_bind(handle, SX_ACCESS_CMD_BIND, ingress_log_port, group_id)

    offsets_list = new_sx_acl_rule_offset_t_arr(100)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
    rules[0].valid = 1
    rules[0].key_desc_count = key_ids_count
    rules[0].action_count = 1

    for i in range(0, key_ids_count):
        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = sx_acl_key_t_arr_getitem(key_ids, 0)
        key_desc.key.custom_byte = 0x31 + i
        key_desc.mask.custom_byte = 0xff
        sx_flex_acl_key_desc_t_arr_setitem(rules[0].key_desc_list_p, i, key_desc)

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_SET_DSCP
    action1.fields.action_set_dscp.dscp_val = 28
    sx_flex_acl_flex_action_t_arr_setitem(rules[0].action_list_p, 0, action1)

    sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rules[0])
    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rules_list,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

    # Edit the custom byte set
    custom_bytes_set_attributes = sx_acl_custom_bytes_set_attributes_t()
    custom_bytes_set_attributes.extraction_point.extraction_group_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L2
    custom_bytes_set_attributes.extraction_point.params.extraction_l2_group.extraction_l2.extraction_point_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE
    custom_bytes_set_attributes.extraction_point.params.extraction_l2_group.extraction_l2.offset = 40
    rc = sx_api_acl_custom_bytes_set(handle,
                                     SX_ACCESS_CMD_EDIT,
                                     custom_bytes_set_attributes,
                                     key_ids,
                                     key_ids_count_p)
    assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_custom_bytes_set rc: %d" % (rc)

    key_ids_count = uint32_t_p_value(key_ids_count_p)

    if args.deinit:
        print("Clean up")
        port_bind(handle, SX_ACCESS_CMD_UNBIND, ingress_log_port, group_id)

        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_DELETE,
                                       region_id,
                                       offsets_list,
                                       rules_list,
                                       1)
        assert SX_STATUS_SUCCESS == rc, "API sx_api_acl_flex_rules_set failed rc: %d" % (rc)

        acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, dir, group_id_p, [])
        acl_handle(handle, SX_ACCESS_CMD_DESTROY, dir, acl_id_p, region_id)
        acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 10, region_id_p)

        acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p,
                              [sx_acl_key_t_arr_getitem(key_ids, i) for i in range(0, key_ids_count)])

        rc = sx_api_acl_custom_bytes_set(handle,
                                         SX_ACCESS_CMD_DESTROY,
                                         custom_bytes_set_attributes,
                                         key_ids,
                                         key_ids_count_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_acl_custom_bytes_set DESTROY failed rc: %d" % (rc)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
