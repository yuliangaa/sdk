#!/usr/bin/env python
'''
This file contains Python command example for the Tunneling module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import colorsys
import errno
import sys
import struct
import socket
import os
import sys
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_bridge_mc_container example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

rc = sx_api_bridge_log_verbosity_level_set(handle, 2, 5, 5)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to set verbosity.")
    sys.exit(rc)

rc = sx_api_mc_container_log_verbosity_level_set(handle, 2, 5, 5)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to set verbosity.")
    sys.exit(rc)
######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

ports_list = mapPortAndInterfaces(handle)
port_p = [0, 0, 0, 0]
lag = [0, 0, 0, 0]
lag_p = [0, 0, 0, 0]
log_port = [0, 0, 0, 0]
log_port_p = [0, 0, 0, 0]
vport1 = [0, 0, 0, 0]
vport2 = [0, 0, 0, 0]
vport1_p = [0, 0, 0, 0]
vport2_p = [0, 0, 0, 0]
bridge_id_p = [0, 0]
bridge_id = [0, 0]
fid = [0, 0, 0]
container_id_p = [0, 0, 0, 0, 0, 0]
mc_container_id = [0, 0, 0, 0, 0, 0]
mcc_attr_p = [0, 0, 0]
mcc_attr = [0, 0, 0]

ports_ingr_filter_mode = {}


######################################################
#    Functions API
######################################################

""" ############################################################################################ """


def make_lag():
    # 2. Creates a new LAG.
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

    rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
    print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))
    return lag_id


""" ############################################################################################ """


def destroy_lag(lag_id):
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, swid, lag_id_p, None, 0)
    print("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d, cmd=%d, log port =0x%x, vlan id=%d] " % (rc, cmd, log_port, vid)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d, cmd=%d] " % (rc, cmd)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d, cmd=%d] " % (rc, cmd)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """

######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def example_make_bridge_mc():
    swid = 0
    vlan1 = 1
    vlan2 = 2
    vlan3 = 3
    mac_pim = "01:00:5E:00:00:0D"

    print(" -------- Create 3 LAGs and 4 VPORTs -------- ")
    for i in range(0, 4):
        port_p[i] = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(port_p[i], ports_list[i])
        lag[i] = make_lag()
        lag_p[i] = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(lag_p[i], lag[i])
        vport1_p[i] = new_sx_port_log_id_t_p()
        vport2_p[i] = new_sx_port_log_id_t_p()

        ports_ingr_filter_mode[ports_list[i]] = ingr_filter_get(ports_list[i])
        if i != 0:
            log_port[i] = lag[i]
            log_port_p[i] = lag_p[i]
            rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_p[i], port_p[i], 1)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (ports_list[i], lag[i], rc)))
        else:
            log_port[i] = ports_list[i]
            log_port_p[i] = port_p[i]

        vport_add_delete(SX_ACCESS_CMD_ADD, log_port[i], vlan1, vport1_p[i])
        vport_add_delete(SX_ACCESS_CMD_ADD, log_port[i], vlan2, vport2_p[i])

        vport1[i] = sx_port_log_id_t_p_value(vport1_p[i])
        vport2[i] = sx_port_log_id_t_p_value(vport2_p[i])

        if i != 0:
            port_state_set(lag[i], SX_PORT_ADMIN_STATUS_UP)

        port_state_set(vport1[i], SX_PORT_ADMIN_STATUS_UP)
        port_state_set(vport2[i], SX_PORT_ADMIN_STATUS_UP)

        if i != 0:
            rc = sx_api_lag_port_collector_set(handle, lag[i], ports_list[i], COLLECTOR_ENABLE)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[i], lag[i], rc)))
            rc = sx_api_lag_port_distributor_set(handle, lag[i], ports_list[i], DISTRIBUTOR_ENABLE)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[i], lag[i], rc)))

    time.sleep(1)

    for i in range(0, 4):
        if i != 0:
            rc = sx_api_rstp_port_state_set(handle, lag[i], SX_MSTP_INST_PORT_STATE_FORWARDING)
            print(("sx_api_rstp_port_state_set set lag 0x%x FORWARDING, rc %d " % (lag[i], rc)))

        add_ports_to_vlan(vlan1, {log_port[i]: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(vlan2, {log_port[i]: SX_UNTAGGED_MEMBER})

    fid[2] = vlan3

    # create bridges
    print(" -------- Create 3 bridges -------- ")
    for i in range(0, 2):
        bridge_id_p[i] = new_sx_bridge_id_t_p()
        bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p[i])
        bridge_id[i] = sx_bridge_id_t_p_value(bridge_id_p[i])
        fid[i] = bridge_id[i]
        # add vport to bridge
        for j in range(0, 4):
            if i == 0:
                vport = vport1[j]
            if i == 1:
                vport = vport2[j]
            bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id[i], vport)
            print(("virtual port 0x%x added to bridge %d " % (vport, bridge_id[i])))

    # Create redirect
    print(" -------- Create redirect -------- ")
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag[1], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set create 0x%x to 0x%x, rc: %d " % (lag[1], lag[3], rc)))
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag[2], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set create 0x%x to 0x%x, rc: %d " % (lag[2], lag[3], rc)))

    # add mc container
    print(" ------- Add 3 bridge mc containers -------- ")
    count = 4
    for i in range(0, 3):
        mcc_attr_p[i] = new_sx_mc_container_attributes_t_p()
        mcc_attr[i] = sx_mc_container_attributes_t()
        mcc_attr[i].type = SX_MC_CONTAINER_TYPE_BRIDGE_MC
        mcc_attr[i].fid = fid[i]
        sx_mc_container_attributes_t_p_assign(mcc_attr_p[i], mcc_attr[i])

        next_hop_list = new_sx_mc_next_hop_t_arr(4)
        for j in range(0, 4):
            next_hop = sx_mc_next_hop_t()
            next_hop.type = SX_MC_NEXT_HOP_TYPE_LOG_PORT
            if i == 0:
                next_hop.data.log_port = vport1[j]
            if i == 1:
                next_hop.data.log_port = vport2[j]
            if i == 2:
                next_hop.data.log_port = log_port[j]
            sx_mc_next_hop_t_arr_setitem(next_hop_list, j, next_hop)

        container_id_p[i] = new_sx_mc_container_id_t_p()
        rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, container_id_p[i], next_hop_list, count, mcc_attr_p[i])
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        mc_container_id[i] = sx_mc_container_id_t_p_value(container_id_p[i])
        print(("sx_api_mc_container_set id %x created with %d enties, rc: %d " % (mc_container_id[i], count, rc)))

    print(" ------- Add 3 port mc containers -------- ")
    count = 4
    attr_p = new_sx_mc_container_attributes_t_p()
    attr = sx_mc_container_attributes_t()
    attr.type = SX_MC_CONTAINER_TYPE_PORT
    sx_mc_container_attributes_t_p_assign(attr_p, attr)
    next_hop_list = new_sx_mc_next_hop_t_arr(4)
    for j in range(0, 4):
        next_hop = sx_mc_next_hop_t()
        next_hop.type = SX_MC_NEXT_HOP_TYPE_LOG_PORT
        next_hop.data.log_port = log_port[j]
        sx_mc_next_hop_t_arr_setitem(next_hop_list, j, next_hop)
    for i in range(3, 6):
        container_id_p[i] = new_sx_mc_container_id_t_p()
        rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, container_id_p[i], next_hop_list, count, attr_p)
        mc_container_id[i] = sx_mc_container_id_t_p_value(container_id_p[i])
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_mc_container_set id %x created with %d enties, rc: %d " % (mc_container_id[i], count, rc)))

    print(" ------- Add FDB MC extend on container0 -------- ")
    mac_key = sx_fdb_mac_key_t()
    mac_data = sx_fdb_mac_data_t()
    mac_key.fid = bridge_id[0]
    mac_key.addr = ether_addr(mac_pim)
    mac_data.action = SX_FDB_ACTION_MIRROR_TO_CPU
    mac_data.mc_container_id = mc_container_id[0]
    mac_key_p = new_sx_fdb_mac_key_t_p()
    mac_data_p = new_sx_fdb_mac_data_t_p()
    sx_fdb_mac_key_t_p_assign(mac_key_p, mac_key)
    sx_fdb_mac_data_t_p_assign(mac_data_p, mac_data)
    rc = sx_api_fdb_mc_mac_addr_group_set(handle, SX_ACCESS_CMD_ADD, mac_key_p, mac_data_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_fdb_mc_mac_addr_group_set add bridge %d mc_cont_id %d rc: %d " % (bridge_id[0], mc_container_id[0], rc)))

    # destroy redirect
    print(" -------- Destroy redirect-------- ")
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag[1], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set destroy 0x%x to 0x%x, rc: %d " % (lag[1], lag[3], rc)))
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag[2], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set destroy 0x%x to 0x%x, rc: %d " % (lag[2], lag[3], rc)))

    # create redirect again
    print(" -------- Create redirect again -------- ")
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag[1], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set create 0x%x to 0x%x, rc: %d " % (lag[1], lag[3], rc)))
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag[2], lag[3])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_redirect_set create 0x%x to 0x%x, rc: %d " % (lag[2], lag[3], rc)))

    # remove lag 1, 3 from container0
    print(" -------- Remove lag1, 3 from container 0 -------- ")
    next_hop_list = new_sx_mc_next_hop_t_arr(2)
    for j in range(0, 2):
        next_hop = sx_mc_next_hop_t()
        next_hop.type = SX_MC_NEXT_HOP_TYPE_LOG_PORT
        if j == 0:
            next_hop.data.log_port = vport1[1]
        if j == 1:
            next_hop.data.log_port = vport1[3]

        sx_mc_next_hop_t_arr_setitem(next_hop_list, j, next_hop)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DELETE, container_id_p[0], next_hop_list, 2, mcc_attr_p[0])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_mc_container_set id %x delete 2 enties, rc: %d " % (mc_container_id[0], rc)))

    # add lag 1, 3 back to container0
    print(" -------- Add lag1, 3 back to container 0 -------- ")
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_ADD, container_id_p[0], next_hop_list, 2, mcc_attr_p[0])
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_mc_container_set id %x add 2 enties, rc: %d " % (mc_container_id[0], rc)))

    # remove port1 from lag1
    print(" -------- Remove port 1 from lag1 -------- ")
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_p[1], port_p[1], 1)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_group_set DELETE port 0x%x to lag 0x%x , rc %d " % (ports_list[1], lag[1], rc)))

    # add port1 to lag3
    print(" -------- Add port1 to lag3 -------- ")
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_p[3], port_p[1], 1)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (ports_list[1], lag[3], rc)))

    rc = sx_api_lag_port_collector_set(handle, lag[3], ports_list[1], COLLECTOR_ENABLE)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[1], lag[3], rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag[3], ports_list[1], DISTRIBUTOR_ENABLE)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[1], lag[3], rc)))
    rc = sx_api_lag_port_collector_set(handle, lag[3], ports_list[3], COLLECTOR_ENABLE)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[3], lag[3], rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag[3], ports_list[3], DISTRIBUTOR_ENABLE)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (ports_list[3], lag[3], rc)))
    # Now traffic is output to port1 or port3 in lag3

    if args.deinit:
        print(" -------- Remove port1 from lag3 -------- ")
        rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_p[3], port_p[1], 1)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (ports_list[1], lag[3], rc)))

        # destroy redirect
        print(" --------- Destroy redirect --------- ")
        rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag[1], lag[3])
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_lag_redirect_set destroy 0x%x to 0x%x, rc: %d " % (lag[1], lag[3], rc)))
        rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag[2], lag[3])
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_lag_redirect_set destroy 0x%x to 0x%x, rc: %d " % (lag[2], lag[3], rc)))

        # remove fdb mc and destroy container 0
        print(" --------- Remove fdb mc --------- ")
        rc = sx_api_fdb_mc_mac_addr_group_set(handle, SX_ACCESS_CMD_DELETE, mac_key_p, mac_data_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_fdb_mc_mac_addr_group_set delete bridge %d mc_cont_id %d rc: %d " % (bridge_id[0], mc_container_id[0], rc)))

        print(" --------- Destroy containers -------- ")
        for i in range(0, 6):
            rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, container_id_p[i], None, 0, None)
            if rc != SX_STATUS_SUCCESS:
                sys.exit(rc)
            print(("sx_api_mc_container_set id %x destroyed, rc: %d " % (mc_container_id[i], rc)))

        print(" -------- Destroy 3 bridges -------- ")
        for i in range(0, 2):
            # remove vport from bridge
            for j in range(0, 4):
                if i == 0:
                    vport = vport1[j]
                if i == 1:
                    vport = vport2[j]
                port_state_set(vport, SX_PORT_ADMIN_STATUS_DOWN)
                bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id[i], vport)
                print(("virtual port 0x%x removed from bridge %d " % (vport, bridge_id[i])))

            bridge_id_p[i] = new_sx_bridge_id_t_p()
            sx_bridge_id_t_p_assign(bridge_id_p[i], bridge_id[i])
            bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p[i])

        remove_ports_from_vlan(vlan1, {p: SX_UNTAGGED_MEMBER for p in log_port[:4]})
        remove_ports_from_vlan(vlan2, {p: SX_UNTAGGED_MEMBER for p in log_port[:4] + [ports_list[1]]})

        print(" -------- Destroy 3 LAGs and 4 VPORTs -------- ")
        for i in range(0, 4):
            if i != 0:
                port_state_set(lag[i], SX_PORT_ADMIN_STATUS_DOWN)

            vport_add_delete(SX_ACCESS_CMD_DELETE, log_port[i], vlan1, vport1_p[i])
            vport_add_delete(SX_ACCESS_CMD_DELETE, log_port[i], vlan2, vport2_p[i])

            if i != 0 and i != 1:
                rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_p[i], port_p[i], 1)
                if rc != SX_STATUS_SUCCESS:
                    sys.exit(rc)
                print(("sx_api_lag_port_group_set DELETE port 0x%x from lag 0x%x , rc %d " % (ports_list[i], lag[i], rc)))

            destroy_lag(lag[i])

        print("----- Restore vlan membership and ingress filter mode -----")
        for port, ingr_filter in list(ports_ingr_filter_mode.items()):
            ingr_filter_set(port, ingr_filter)
            add_ports_to_vlan(vlan1, {port: SX_UNTAGGED_MEMBER})


if __name__ == "__main__":
    example_make_bridge_mc()

    sx_api_close(handle)
