#!/usr/bin/env python
'''
This file contains Python command example for the Port module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import sys
import struct
import socket
import colorsys
import random
import traceback
import os
import inspect
import argparse

from python_sdk_api.sx_api import *

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../../python_traffic_test/test_infra')
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../../python_traffic_test/test_infra/sdk_common_infra')
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_ber_monitor')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()


def main():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    port_list = mapPortAndInterfaces(handle)
    PORT1 = port_list[0]

    original_threshold_data_p = new_sx_port_ber_fec_profile_threshold_data_t_p()
    print("get current BER monitor threshold")
    rc = sx_api_port_ber_threshold_get(handle, PORT1, SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E, original_threshold_data_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get thresholds for ber, rc = %d" % rc
    original_threshold_data = sx_port_ber_fec_profile_threshold_data_t_p_value(original_threshold_data_p)

    original_monitor_data_p = new_sx_port_ber_monitor_data_t_p()
    print("get current BER monitor parameters")
    rc = sx_api_port_ber_monitor_get(handle, PORT1, original_monitor_data_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get monitor config data for ber in port %d" % PORT1
    original_monitor_data = sx_port_ber_monitor_data_t_p_value(original_monitor_data_p)

    threshold_data = sx_port_ber_fec_profile_threshold_data_t()
    threshold_data_p = new_sx_port_ber_fec_profile_threshold_data_t_p()
    monitor_data = sx_port_ber_monitor_data_t()
    monitor_data_p = new_sx_port_ber_monitor_data_t_p()
    monitor_oper_data_p = new_sx_port_ber_monitor_oper_data_t_p()

    threshold_data.normal.mantissa = 1
    threshold_data.normal.exponent = -7
    threshold_data.warning.mantissa = 1
    threshold_data.warning.exponent = -6
    threshold_data.alarm.mantissa = 1
    threshold_data.alarm.exponent = -5
    fec_profile = SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E
    monitor_data.alarm_types.normal = SX_PORT_BER_ALARM_CONF_STATUS_ENABLED_E
    monitor_data.alarm_types.warning = SX_PORT_BER_ALARM_CONF_STATUS_ENABLED_E
    monitor_data.alarm_types.alarm = SX_PORT_BER_ALARM_CONF_STATUS_ENABLED_E
    monitor_data.pre_fec = SX_PORT_BER_PRE_FEC_ENABLE_E

    print("setting BER monitor thresholds")
    rc = sx_api_port_ber_threshold_set(handle, PORT1, SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E, threshold_data)
    assert rc == SX_STATUS_SUCCESS, "failed to set thresholds for ber, rc = %d" % rc

    print("validating BER monitor thresholds")
    rc = sx_api_port_ber_threshold_get(handle, PORT1, SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E, threshold_data_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get thresholds for ber, rc = %d" % rc

    threshold_data_get_val = sx_port_ber_fec_profile_threshold_data_t_p_value(threshold_data_p)
    assert (threshold_data_get_val.normal.mantissa == threshold_data.normal.mantissa), "normal mantissa do not match"
    assert (threshold_data_get_val.normal.exponent == threshold_data.normal.exponent), "normal exponent do not match"
    assert (threshold_data_get_val.warning.mantissa == threshold_data.warning.mantissa), "warning mantissa do not match"
    assert (threshold_data_get_val.warning.exponent == threshold_data.warning.exponent), "warning exponent do not match"
    assert (threshold_data_get_val.alarm.mantissa == threshold_data.alarm.mantissa), "normal alarm do not match"
    assert (threshold_data_get_val.alarm.exponent == threshold_data.alarm.exponent), "normal alarm do not match"

    print("setting BER monitor parameters")
    rc = sx_api_port_ber_monitor_set(handle, PORT1, monitor_data)
    assert rc == SX_STATUS_SUCCESS, "failed to set monitor config data for ber, rc = %d" % rc

    print("validating BER monitor parameters")
    rc = sx_api_port_ber_monitor_get(handle, PORT1, monitor_data_p)
    assert rc == SX_STATUS_SUCCESS, "failed to get monitor config data for ber in port %d" % PORT1

    monitor_data_get_val = sx_port_ber_monitor_data_t_p_value(monitor_data_p)

    print("retrieved normal monitor enable: %d " % monitor_data_get_val.alarm_types.normal)
    print("retrieved warning monitor enable: %d" % monitor_data_get_val.alarm_types.warning)
    print("retrieved alarm monitor enable: %d" % monitor_data_get_val.alarm_types.alarm)
    print("retrieved pre-FEC enable: %d" % monitor_data_get_val.pre_fec)

    assert (monitor_data_get_val.alarm_types.normal == monitor_data.alarm_types.normal), "normal alarms do not match"
    assert (monitor_data_get_val.alarm_types.warning == monitor_data.alarm_types.warning), "warning alarms do not match"
    assert (monitor_data_get_val.alarm_types.alarm == monitor_data.alarm_types.alarm), "alarm alarms do not match"
    assert (monitor_data_get_val.pre_fec == monitor_data.pre_fec), "monitor pre_fec status do not match"

    print("retrieving current monitor status")
    rc = sx_api_port_ber_monitor_operational_get(handle, PORT1, monitor_oper_data_p)

    monitor_oper_data_val = sx_port_ber_monitor_oper_data_t_p_value(monitor_oper_data_p)

    print("retrieved monitor status: %d" % monitor_oper_data_val.alarm_state)
    print("retrieved pre-FEC enable: %d" % monitor_oper_data_val.pre_fec)

    assert rc == SX_STATUS_SUCCESS, "failed to get monitor oper data for ber, rc = %d" % rc

    if args.deinit:
        print("setting original BER monitor parameters")
        rc = sx_api_port_ber_monitor_set(handle, PORT1, original_monitor_data)
        assert rc == SX_STATUS_SUCCESS, "failed to set monitor config data for ber, rc = %d" % rc

        print("setting original monitor thresholds")
        rc = sx_api_port_ber_threshold_set(handle, PORT1, SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E, original_threshold_data)
        assert rc == SX_STATUS_SUCCESS, "failed to set thresholds for ber, rc = %d" % rc

    sx_api_close(handle)


if __name__ == "__main__":
    handle = main()
