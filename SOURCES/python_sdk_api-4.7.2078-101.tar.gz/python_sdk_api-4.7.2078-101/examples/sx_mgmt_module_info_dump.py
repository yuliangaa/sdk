#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the module information.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *

global print_disc
print_disc = False


def print_disclaimer():
    print("*Oper State = SX_PORT_MODULE_STATUS_RESERVED_E if admin_status is not SXD_PMAOS_ADMIN_STATUS_DISABLED_BY_CONFIGURATION_E")
    print("**Error type = SX_PORT_MODULE_ERROR_TYPE_RESERVED_E if oper_status is not SX_PORT_MODULE_STATUS_PLUGGED_WITH_ERROR")


def generate_module_dump(handle, slot):
    ports_attributes_list = ports_attributes_get(handle)
    port_module_map, module_port_map = get_port_module_mapping(ports_attributes_list, len(ports_attributes_list))
    module_id_info_list = new_sx_mgmt_module_id_info_t_arr(len(ports_attributes_list))
    module_info_list = new_sx_mgmt_phy_module_info_t_arr(len(ports_attributes_list))

    module_count = 0
    for (slot_id, mod_id) in sorted(module_port_map.keys()):
        if slot != INVALID_SLOT_ID and slot != slot_id:
            continue
        module_id_info = sx_mgmt_module_id_info_t()
        module_id_info.slot_id = slot_id
        module_id_info.module_id = mod_id
        sx_mgmt_module_id_info_t_arr_setitem(module_id_info_list, module_count, module_id_info)
        module_count += 1

    if module_count == 0:
        print("No modules match the slot criteria or modules not present in system")
        return
    try:
        rc = sx_mgmt_phy_module_info_get(handle, module_id_info_list, module_count, module_info_list)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_phy_module_info_get failed"

        print("====================================================================================================================================================")
        header = ["Slot", "Module ID", "Module Type", "Module Width", "Oper State", "Error type"]
        print("|%4s|%10s|%40s|%12s|%35s|%40s|" % (header[0], header[1], header[2], header[3], header[4], header[5]))
        print("====================================================================================================================================================")

        module_type_enum_dict = get_enum_string_dict('SX_MGMT_PHY_MODULE_TYPE_')
        oper_state_type_enum_dict = get_enum_string_dict('SX_PORT_MODULE_STATUS_')
        error_type_enum_dict = get_enum_string_dict('SX_PORT_MODULE_ERROR_TYPE_')
        for idx in range(module_count):
            mod_info = sx_mgmt_phy_module_info_t_arr_getitem(module_info_list, idx)
            if mod_info.module_state.oper_state == SX_PORT_MODULE_STATUS_RESERVED_E or mod_info.module_state.error_type == SX_PORT_MODULE_ERROR_TYPE_RESERVED_E:
                global print_disc
                print_disc = True
            print("|%4s|%10s|%40s|%12s|%35s|%40s|" % (mod_info.slot_id, mod_info.module_id, module_type_enum_dict[mod_info.module_type],
                                                      mod_info.module_width, oper_state_type_enum_dict[mod_info.module_state.oper_state],
                                                      error_type_enum_dict[mod_info.module_state.error_type]))
        print("====================================================================================================================================================")

    finally:
        delete_sx_mgmt_module_id_info_t_arr(module_id_info_list)
        delete_sx_mgmt_phy_module_info_t_arr(module_info_list)


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='Module info dump utility')
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    args = parser.parse_args()
    slot_id = args.slot_id
    return slot_id


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    slot_id = parse_example_attributes()
    generate_module_dump(handle, slot_id)

    if print_disc:
        print_disclaimer()

    sx_api_close(handle)
