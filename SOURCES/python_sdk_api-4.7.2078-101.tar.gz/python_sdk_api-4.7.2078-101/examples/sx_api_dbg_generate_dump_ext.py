#!/usr/bin/env python
'''
This file contains Python command example for calling sx_api_dbg_generate_dump_extra.
'''

import sys
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import sxd_api_chip_type_rev_get as sxd_api_chip_type


def parse_args():
    parser = argparse.ArgumentParser(description='generate an extended debug dump',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--device_id', default=1, type=lambda x: int(x, 0), help='The device id to extract the FW info from')
    parser.add_argument('--path', default=None, help='a path where the dump will be saved')
    parser.add_argument('--ircore', default=False, action='store_true', help='Enables iriscs core dump')
    parser.add_argument('--is_async', default=False, action='store_true', help='Enables async mode')
    parser.add_argument('--fw_trace', default=False, action='store_true', help='Enables FW Trace dump')
    parser.add_argument('--amber', default=False, action='store_true', help='Enables AMBER dump')
    parser.add_argument('--mgir', default=False, action='store_true', help='Get chip UID using mgir and not using lspci')
    parser.add_argument('--sdk_threads_backtrace', default=False, action='store_true', help='Enables Sdk threads bt stack dump')

    return parser.parse_args()


def main():
    args = parse_args()

    # Use MGIR Only if requested by user. Default is using lspci, since FW Might be stuck
    device_id = sxd_api_chip_type.get_chip_type_and_rev(deinit=True)[0] if args.mgir else get_chip_id()
    if device_id not in [SXD_MGIR_HW_DEV_ID_SPECTRUM, SXD_MGIR_HW_DEV_ID_SPECTRUM2, SXD_MGIR_HW_DEV_ID_SPECTRUM3, SXD_MGIR_HW_DEV_ID_SPECTRUM4, SXD_MGIR_HW_DEV_ID_SPECTRUM5, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]:
        print("Example supported only on SPC1-5 and Quantum1-3 Chips")
        sys.exit(0)

    dbg_params_p = new_sx_dbg_extra_info_t_p()
    dbg_params_p.dev_id = args.device_id
    dbg_params_p.path = args.path
    dbg_params_p.timeout_usec = 0  # not yet supported
    dbg_params_p.is_async = args.is_async
    dbg_params_p.ir_dump_enable = args.ircore
    dbg_params_p.fw_trace_dump_enable = args.fw_trace
    dbg_params_p.amber_dump_enable = args.amber
    dbg_params_p.sdk_threads_backtrace_enable = args.sdk_threads_backtrace
    rc = sx_api_dbg_generate_dump_extra(0, dbg_params_p)
    delete_sx_dbg_extra_info_t_p(dbg_params_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to generate extended debug dump for device:{0}".format(dbg_params_p.dev_id)
    print("Success.")


if __name__ == "__main__":
    sys.exit(main())
