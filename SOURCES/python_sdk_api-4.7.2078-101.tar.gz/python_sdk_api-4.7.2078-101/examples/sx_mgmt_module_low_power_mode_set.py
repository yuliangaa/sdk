#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility set the power mode a given module.
'''
import sys
import argparse
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import python_sdk_api.sx_api as sx_api

INVALID_SLOT_ID = 99
######################################################
#  power mode and reset utility functions.
######################################################


def mgmt_phy_mod_pwr_attr_set(handle, slot_id, module_id, power_attr_type, admin_pwr_mode):
    sx_mgmt_phy_mod_pwr_attr = sx_mgmt_phy_mod_pwr_attr_t()
    sx_mgmt_phy_mod_pwr_mode_attr = sx_mgmt_phy_mod_pwr_mode_attr_t()
    sx_mgmt_phy_mod_pwr_attr.power_attr_type = power_attr_type
    sx_mgmt_phy_mod_pwr_mode_attr.admin_pwr_mode_e = admin_pwr_mode
    sx_mgmt_phy_mod_pwr_attr.pwr_mode_attr = sx_mgmt_phy_mod_pwr_mode_attr
    sx_mgmt_phy_mod_pwr_attr_p = new_sx_mgmt_phy_mod_pwr_attr_t_p()
    sx_mgmt_phy_mod_pwr_attr_t_p_assign(sx_mgmt_phy_mod_pwr_attr_p, sx_mgmt_phy_mod_pwr_attr)
    module_id_info = sx_mgmt_module_id_info_t()
    module_id_info.slot_id = slot_id
    module_id_info.module_id = module_id
    try:
        rc = sx_mgmt_phy_module_pwr_attr_set(handle, SX_ACCESS_CMD_SET, module_id_info, sx_mgmt_phy_mod_pwr_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_phy_module_pwr_attr_set failed"
    finally:
        delete_sx_mgmt_phy_mod_pwr_attr_t_p(sx_mgmt_phy_mod_pwr_attr_p)


def mgmt_phy_mod_pwr_attr_get(handle, slot_id, module_id, power_attr_type):
    sx_mgmt_phy_mod_pwr_attr_p = new_sx_mgmt_phy_mod_pwr_attr_t_p()
    sx_mgmt_phy_mod_pwr_attr = sx_mgmt_phy_mod_pwr_attr_t()
    sx_mgmt_phy_mod_pwr_attr.power_attr_type = power_attr_type
    sx_mgmt_phy_mod_pwr_attr_t_p_assign(sx_mgmt_phy_mod_pwr_attr_p, sx_mgmt_phy_mod_pwr_attr)
    module_id_info = sx_mgmt_module_id_info_t()
    module_id_info.slot_id = slot_id
    module_id_info.module_id = module_id
    try:
        rc = sx_mgmt_phy_module_pwr_attr_get(handle, module_id_info, sx_mgmt_phy_mod_pwr_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_phy_module_pwr_attr_get failed"
        sx_mgmt_phy_mod_pwr_attr = sx_mgmt_phy_mod_pwr_attr_t_p_value(sx_mgmt_phy_mod_pwr_attr_p)
        pwr_mode_attr = sx_mgmt_phy_mod_pwr_attr.pwr_mode_attr
        return pwr_mode_attr.admin_pwr_mode_e, pwr_mode_attr.oper_pwr_mode_e
    finally:
        delete_sx_mgmt_phy_mod_pwr_attr_t_p(sx_mgmt_phy_mod_pwr_attr_p)


def pwr_attr_set(slot_id, module_id, ports, attr_type, power_mode):
    # bring the port down
    for port in ports:
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    # set the desired power mode
    mgmt_phy_mod_pwr_attr_set(handle, slot_id, module_id, attr_type, power_mode)
    # get the current port power mode and make sure that it is as per the mode set.
    admin_pwr_mode, oper_pwr_mode = mgmt_phy_mod_pwr_attr_get(handle, slot_id, module_id, attr_type)
    assert power_mode == admin_pwr_mode, "power mode mismatch"
    # bring the port up
    for port in ports:
        port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)


def run_example(handle, cmd, slot_id, module_id):
    # construct the port module map.
    ports_attributes_list = ports_attributes_get(handle)
    port_module_map, module_port_map = get_port_module_mapping(ports_attributes_list, len(ports_attributes_list))

    if (slot_id, module_id) not in module_port_map.keys():
        print("Error: Invalid Module Id or Slot ID")
        sx_api_close(handle)
        sys.exit(1)

    if cmd == "enable":
        pwr_attr_set(slot_id, module_id, module_port_map[(slot_id, module_id)], SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E, SX_MGMT_PHY_MOD_PWR_MODE_LOW_E)
        print("Enabled low power mode for slot[%d] module [%d]" % (slot_id, module_id))
    elif cmd == "disable":
        pwr_attr_set(slot_id, module_id, module_port_map[(slot_id, module_id)], SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E, SX_MGMT_PHY_MOD_PWR_MODE_AUTO_E)
        print("Disabled low power mode for slot [%d] module [%d]" % (slot_id, module_id))
    else:
        print("Error: Invalid command")
        sx_api_close(handle)
        sys.exit(1)


def print_slot_warning():
    valid = {"yes": True, "y": True, "ye": True}
    print("Slot ID is assumed 0 and is applicable only for 1U system")
    print("Do you wish to continue? (y/N)")
    choice = input().lower()
    if choice not in valid:
        sx_api_close(handle)
        sys.exit(1)


def parse_example_attributes():

    parser = argparse.ArgumentParser(description='Module power mode set utility')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--cmd', default="enable", type=str, help="enable, disable")
    parser.add_argument('--slot_id', default=INVALID_SLOT_ID, type=int, help="Slot id is 0 for 1U and <1-N> for modular systems")
    parser.add_argument('--module_id', default=0, type=int, help="Module id")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    if not args.force:
        print_modification_warning()
    print_api_example_disclaimer()
    print("module takes 4 seconds to return to stable state after changing power mode")

    module_id = args.module_id
    if args.slot_id:
        slot_id = args.slot_id
    else:
        print_slot_warning()
        slot_id = 0
    cmd = args.cmd

    return cmd, slot_id, module_id, args.deinit


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    cmd, slot_id, module_id, do_deinit = parse_example_attributes()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    if slot_id == INVALID_SLOT_ID:
        slot_count = system_slot_count_get(handle)
        if slot_count > 0:
            slot_id = 1
        else:
            slot_id = 0

    state = phy_module_state_get(handle, slot_id, module_id)
    if state != SX_PORT_MODULE_STATUS_PLUGGED:
        print("Module state other than SX_PORT_MODULE_STATUS_PLUGGED is not compatible for power mode operation")
        sx_api_close(handle)
        sys.exit(0)

    # Run the  example with retrieved above parameters
    run_example(handle, cmd, slot_id, module_id)

    # revert back the configuration done by example
    if do_deinit:
        if cmd == "enable":
            cmd = "disable"
        else:
            cmd = "enable"

        time.sleep(3)
        state = phy_module_state_get(handle, slot_id, module_id)
        run_example(handle, cmd, slot_id, module_id)

    sx_api_close(handle)
