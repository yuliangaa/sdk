#!/usr/bin/env python
'''
This file contains Python command example for the PORT EXTENDED COUNTER DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='Port Extended Counter dump utility')
    parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Logical port ID, 0 means all ports')
    parser.add_argument('--clear', action='store_true', help='clear the counters after read')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('-a', action='store_true', help='display only active counter set (have non zero counters)')
    parser.add_argument('--cntr_type', default='all', choices=['all', 'rs_fec_histogram'], help='display specific counter set')
    args = parser.parse_args()
    return args


def devices_list_get(handle):
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 0)
    rc = sx_api_port_device_list_get(handle, None, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)

    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)

    device_id_list = []
    for i in range(0, device_info_cnt):
        device_info = sx_device_info_t_arr_getitem(device_info_list_p, i)
        device_id = device_info.dev_id
        device_id_list.append(device_id)

    return device_id_list


def device_port_list_get(handle, device_id):
    swid = 0
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    rc = sx_api_port_device_get(handle, device_id, swid, None, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)

    port_cnt = uint32_t_p_value(port_cnt_p)
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    # get all device ports
    rc = sx_api_port_device_get(handle, device_id, swid, port_attributes_list, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)

    port_cnt = uint32_t_p_value(port_cnt_p)
    # loop over all device ports
    device_port_list = []
    for k in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, k)
        log_port = port_attributes.log_port
        is_nve = check_nve(int(log_port))
        is_cpu = check_cpu(int(log_port))
        is_vport = check_vport(int(log_port))
        # skip if port is nve, vport or cpu
        if is_nve or is_vport or is_cpu:
            continue

        device_port_list.append(log_port)

    return device_port_list


def print_separator(separator_len, separator_char="-"):
    print(separator_char * separator_len)


def print_counter_ext_rs_fec_histogram(log_port, cntr_data, print_only_non_zero_cntrs):
    cntr_ext_data = sx_port_cntr_ext_data_t()
    cntr_ext_data = cntr_data.cntr_ext_data
    rs_fec_histogram = cntr_ext_data.rs_fec_histogram
    config_bin_arr = new_sx_port_cntr_phy_rs_fec_histogram_bin_config_t_arr(SX_PORT_CNTR_GRP_RS_FEC_HIST_BINS_NUM)
    data_bin_arr = new_sx_port_cntr_phy_rs_fec_histogram_bin_data_t_arr(SX_PORT_CNTR_GRP_RS_FEC_HIST_BINS_NUM)
    separator_len = 50
    print_separator(separator_len, "=")
    print("RS FEC Histogram dump")
    print("log_port             : 0x%x" % (log_port))
    print("max_errors_detectable: %d" % (rs_fec_histogram.histogram_config.max_errors_detectable))
    print("bins count           : %d" % (rs_fec_histogram.histogram_config.length))
    print_separator(separator_len)
    print("| Bin | Min | Max |  Errors")
    print_separator(separator_len)
    for i in range(0, rs_fec_histogram.histogram_config.length):
        config_bin_arr = rs_fec_histogram.histogram_config.bins
        config_bin = sx_port_cntr_phy_rs_fec_histogram_bin_config_t_arr_getitem(config_bin_arr, i)
        rs_fec_codeword_errors_min = config_bin.rs_fec_codeword_errors_min
        rs_fec_codeword_errors_max = config_bin.rs_fec_codeword_errors_max

        data_bin_arr = rs_fec_histogram.histogram_data.bins
        data_bin = sx_port_cntr_phy_rs_fec_histogram_bin_data_t_arr_getitem(data_bin_arr, i)
        rs_fec_codeword_corrected_errors = data_bin.rs_fec_codeword_corrected_errors

        if print_only_non_zero_cntrs and rs_fec_codeword_corrected_errors == 0:
            continue

        print("|    %d|    %d|    %d|  %d "
              % (i, rs_fec_codeword_errors_min,
                  rs_fec_codeword_errors_max,
                  rs_fec_codeword_corrected_errors))

    print_separator(separator_len, "=")


def print_counter_ext(log_port, cntr_data, print_only_non_zero_cntrs):
    if cntr_data.cntr_ext_type == SX_PORT_CNTR_EXT_TYPE_RS_FEC_HISTOGRAM_E:
        print_counter_ext_rs_fec_histogram(log_port, cntr_data, print_only_non_zero_cntrs)
    else:
        print("Counter ext type:%d isn't supported. exit" % (cntr_data_p.cntr_ext_type))
        sys.exit(-1)


def read_port_counters_ext_rs_fec_histogram(handle, log_port, cmd, print_only_non_zero_cntrs):
    cntr_key_p = sx_port_cntrs_key_t()
    cntr_key_p.key_types_bitmask = SX_PORT_CNTR_EXT_KEY_TYPE_LOG_PORT_E
    cntr_key_p.log_port = log_port

    cntr_data_p = sx_port_cntrs_data_t()
    cntr_data_p.cntr_ext_type = SX_PORT_CNTR_EXT_TYPE_RS_FEC_HISTOGRAM_E

    rc = sx_api_port_counter_ext_get(handle, cmd, cntr_key_p, cntr_data_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_counter_ext_get failed, rc = %d" % (rc))
        sys.exit(rc)

    print_counter_ext(log_port, cntr_data_p, print_only_non_zero_cntrs)


def read_port_counters_ext(handle, log_port, cmd, cntr_type, print_only_non_zero_cntrs):
    if cntr_type == 'all' or cntr_type == 'rs_fec_histogram':
        read_port_counters_ext_rs_fec_histogram(handle, log_port, cmd, print_only_non_zero_cntrs)


def read_all_port_counters_ext(handle, cmd, cntr_type, print_only_non_zero_cntrs):
    dev_id_list = devices_list_get(handle)
    for dev_id in dev_id_list:
        device_port_list = device_port_list_get(handle, dev_id)
        for log_port in device_port_list:
            read_port_counters_ext(handle, log_port, cmd, cntr_type, print_only_non_zero_cntrs)


def main():

    cmd = SX_ACCESS_CMD_READ
    swid = 0
    print_only_non_zero_cntrs = 0

    args = parse_args()

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(1)

    try:
        if args.clear and not args.force:
            print_modification_warning()

        if args.clear:
            cmd = SX_ACCESS_CMD_READ_CLEAR

        if args.a:
            print_only_non_zero_cntrs = 1

        # counter read
        if args.log_port == 0:
            read_all_port_counters_ext(handle, cmd, args.cntr_type, print_only_non_zero_cntrs)
        else:
            read_port_counters_ext(handle, args.log_port, cmd, args.cntr_type, print_only_non_zero_cntrs)

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
