#!/usr/bin/env python

import sys
import errno


import sys
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
import test_infra_common as common_lib
import sxd_api_chip_type_rev_get as sxd_api_chip_type
import argparse

parser = argparse.ArgumentParser(description='sxd_api_paos example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

admin_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 3: 'UP_ONCE'}
oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}

rc, handle = sx_api_open(None)
assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc: %d" % (rc)

print("[+] paos register access test start")

# Get ports Count
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 0)
port_attributes_list = new_sx_port_attributes_t_arr(0)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_device_get failed, rc = %d" % (rc))
    sys.exit(rc)
port_cnt = uint32_t_p_value(port_cnt_p)

# Get ports
port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
if (rc != SXD_STATUS_SUCCESS):
    print("An error was found in sx_api_port_device_get.\nThe example will exit")
    sys.exit(rc)

print("[+] get local port")
local_port = 0
for i in range(0, port_cnt):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = common_lib.check_vport(int(port_attributes.log_port))
    is_nve = common_lib.check_nve(int(port_attributes.log_port))
    is_cpu = common_lib.check_cpu(int(port_attributes.log_port))
    if is_nve or is_vport or is_cpu:
        continue
    else:
        local_port = port_attributes.port_mapping.local_port
        break

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("An error was found in sxd_access_reg_init.\nThe example will exit")
    sys.exit(rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

paos = ku_paos_reg()

paos.local_port, paos.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

paos.admin_status = 0
paos.ase = 0
paos.e = 0
paos.ee = 0
paos.oper_status = 0
paos.swid = 0

print("[+] Get paos\n")
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_paos(paos, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read PAOS register, rc: %d" % (rc)
print(("[+] Port admin_status is %s" % admin_dict[paos.admin_status]))
print(("[+] Port oper_status is %s\n" % oper_dict[paos.oper_status]))


print("[+] Set paos\n")
paos.ase = 1
save_admin_status = paos.admin_status
if paos.admin_status == 1 or paos.admin_status == 3:
    paos.admin_status = 2
else:
    paos.admin_status = 1
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_paos(paos, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)
print(("[+] Port admin_status is %s" % admin_dict[paos.admin_status]))
print(("[+] Port oper_status is %s\n" % oper_dict[paos.oper_status]))


if args.deinit:
    print("[+] Restore paos\n")
    paos.admin_status = save_admin_status
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_paos(paos, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)
    print(("[+] Port admin_status is %s" % admin_dict[paos.admin_status]))
    print(("[+] Port oper_status is %s\n" % oper_dict[paos.oper_status]))

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

sx_api_close(handle)
