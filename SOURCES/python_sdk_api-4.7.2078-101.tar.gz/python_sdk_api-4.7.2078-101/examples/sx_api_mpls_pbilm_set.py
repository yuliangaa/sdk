#!/usr/bin/env python
"""
The example demonstrates how to use acl pbilm action to strip all mpls labels. Every step we strip 1 or 2 label due to asic limitation.
                                               -> if no more mpls, go to out
                                              |
   ingress port --> pbilm to ecmp --> irif-> erif ->  loopback port
                       |                            |
                       |                            | has more mpls label, pbilm to ecmp again
                       |                            |
                       <-------------<--------------|
    packet format:
            Ether(dst='00:02:03:04:05:aa', src='E4:1D:2D:1E:6D:32') /\
            Dot1Q(vlan=6) /\
            MPLS(label=100, cos=0, s=0, ttl=63) /\
            MPLS(label=102, cos=0, s=0, ttl=63) /\
            MPLS(label=200, cos=0, s=1, ttl=63) /\
            IP(dst='172.168.1.1', src='22.33.0.2', ttl=64) /\
            TCP(dport=7777, sport=9876) / Raw(load=self.dummy_payload)
This example is supported on Spectrum devices.
"""
import os
import sys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


######################################################
#    functions
######################################################

def bridge_vport_create(handle, port, vlan, tag_mode=SX_UNTAGGED_MEMBER):
    add_ports_to_vlan(vlan, {port: tag_mode})

    log_vport_p = new_sx_port_log_id_t_p()
    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_ADD, port, vlan, log_vport_p)
    log_vport = sx_port_log_id_t_p_value(log_vport_p)
    print("virtual port 0x%x created, rc: %d" % (log_vport, rc))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    rc = sx_api_bridge_set(handle, SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print("bridge %d created, rc: %d" % (bridge_id, rc))

    # add log_vport to bridge
    rc = sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    print("virtual port 0x%x added to bridge %d, rc: %d" % (log_vport, bridge_id, rc))

    # set port state to UP
    rc = sx_api_port_state_set(handle, log_vport, SX_PORT_ADMIN_STATUS_UP)
    print("Set virtual port 0x%x state to UP, rc: %d" % (log_vport, rc))

    delete_sx_port_log_id_t_p(log_vport_p)
    delete_sx_bridge_id_t_p(bridge_id_p)

    return (bridge_id, log_vport)


def bridge_vport_add_delete(handle, cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    assert SX_STATUS_SUCCESS == rc, "sx_api_bridge_vport_set failed, cmd = %d, port = 0x%x, bridge = %d" % (cmd, log_port, bridge_id)


def bridge_create_delete(handle, cmd, bridge_id_p):
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    elif cmd == SX_ACCESS_CMD_DESTROY:
        print("--------------- BRIDGE DELETE ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_bridge_set failed, cmd = %d" % (cmd)


def vport_add_delete(handle, cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(1)

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_vport_set failed, cmd = %d, port = 0x%x, vid = %d" % (cmd, log_port, vid)


def bridge_vport_delete(handle, vlan, port1, bridge_id, log_vport):

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    bridge_id_p = new_sx_bridge_id_t_p()
    sx_bridge_id_t_p_assign(bridge_id_p, bridge_id)

    # set port state to DOWN
    port_state_set(handle, log_vport, SX_PORT_ADMIN_STATUS_DOWN)

    # delete log_vport_1 from bridge
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
    print(("virtual port 0x%x remove from bridge %d " % (log_vport, bridge_id)))

    # delete bridge
    bridge_create_delete(handle, SX_ACCESS_CMD_DESTROY, bridge_id_p)
    print(("bridge %d deleted" % (bridge_id)))

    vport_add_delete(handle, SX_ACCESS_CMD_DELETE, port1, vlan, log_vport_p)
    print(("virtual port 0x%x deleted" % (log_vport)))


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_all_neigh_per_rif(rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_neigh(rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def set_port_state(log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0, reduced_rif_counters=False):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = rpf_enable
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries
    router_resource.reduced_rif_counters = reduced_rif_counters

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                uc_default_action=SX_ROUTER_ACTION_DROP,
                mc_default_action=SX_ROUTER_ACTION_DROP):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = ipv4_enable
    router_attr.ipv6_enable = ipv6_enable
    router_attr.ipv4_mc_enable = ipv4_mc_enable
    router_attr.ipv6_mc_enable = ipv6_mc_enable
    router_attr.uc_default_rule_action = uc_default_action
    router_attr.mc_default_rule_action = mc_default_action

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def set_rif_state_ipv4(rif,
                       ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                       ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    ifc_attr.urpf_config.urpf_ipv4_enable = 1
    ifc_attr.urpf_config.urpf_ipv6_enable = 0
    ifc_attr.urpf_config.allow_default_route = 0
    ifc_attr.urpf_config.strict_mode = 0

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def mpls_init(tq_profile_type=0, tq_profile=2, underlay_domain=0):
    " This function init mpls. "

    general_params = sx_mpls_general_params_t()
    general_params.label_id_range_min = 100
    general_params.label_id_range_max = 888
    general_params.reserved_label_id_max = 1
    general_params.ttl_model = SX_MPLS_TTL_MODEL_TYPE_UNIFORM
    general_params.tq_profile_type = tq_profile_type
    general_params.tq_profile_data.single_profile.tq_profile = tq_profile
    general_params.underlay_domain = underlay_domain

    rc = sx_api_mpls_init_set(handle, general_params)
    assert SX_STATUS_SUCCESS == rc, "Failed to init mpls"

    print("sx_api_mpls_init_set, rc: %d" % (rc))


def mpls_deinit():
    " This function deinit mpls. "

    rc = sx_api_mpls_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit mpls"
    print("sx_api_mpls_deinit_set, rc: %d" % (rc))


def mpls_ilm_init(vrid):
    " This function init mpls ilm. "

    cmd = SX_ACCESS_CMD_CREATE
    ilm_table = vrid

    rc = sx_api_mpls_ilm_init_set(handle, cmd, ilm_table)
    assert SX_STATUS_SUCCESS == rc, "Failed to init mpls ilm"
    print("sx_api_mpls_ilm_init_set, rc: %d" % (rc))


def mpls_ilm_destroy(vrid):
    " This function destroy mpls ilm. "

    cmd = SX_ACCESS_CMD_DESTROY
    ilm_table = vrid

    rc = sx_api_mpls_ilm_init_set(handle, cmd, ilm_table)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mpls ilm"
    print("sx_api_mpls_ilm_init_set, rc: %d" % (rc))


def mpls_router_interface_attributes_set(rif_arr, mpls_enabled, vrid=0):
    " This function sets the MPLS interface attributes."

    rif_mpls_attr = sx_mpls_router_interface_attr_t()
    rif_mpls_attr.mpls_enabled = mpls_enabled
    rif_mpls_attr.ilm_table_id = vrid

    for rif in rif_arr:
        rc = sx_api_mpls_router_interface_attributes_set(handle, rif, rif_mpls_attr)
        assert SX_STATUS_SUCCESS == rc, "Failed to init mpls router interface attributes (%u)" % (rif)

    print("sx_api_mpls_router_interface_attributes_set, rc: %d" % (rc))


def make_mpls_ecmp_next_hop(rif, ipaddr, label_out_arr, weight, nh_type=SX_NEXT_HOP_TYPE_MPLS, eRIF=None, uRIF=None):
    " This function creates ecmp_mpls_next_hop struct with given parameters. "

    nh_key = make_sx_mpls_next_hop(rif, ipaddr, label_out_arr, nh_type, eRIF, uRIF)

    nh_data = sx_next_hop_data_t()
    nh_data.action = SX_ROUTER_ACTION_FORWARD
    nh_data.weight = weight

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = nh_data

    return next_hop


def make_sx_mpls_label_stack_entry(label_out_arr):
    " This function creates sx_mpls_label_stack_entry_t struct with given parameters. "

    mpls_label_stack_entry_arr = new_sx_mpls_label_stack_entry_t_arr(6)

    for i in range(len(label_out_arr)):
        mpls_label_entry = sx_mpls_label_stack_entry_t()
        mpls_label_entry.label = label_out_arr[i]
        sx_mpls_label_stack_entry_t_arr_setitem(mpls_label_stack_entry_arr, i, mpls_label_entry)

    return mpls_label_stack_entry_arr


def make_sx_mpls_ip_next_hop_data(rif, ipaddr):
    " This function creates sx_mpls_ip_next_hop_data_t struct with given parameters. "

    nh_sx_ip = sx_ip_next_hop_t()
    nh_sx_ip.rif = rif
    nh_sx_ip.address = make_sx_ip_addr_v4(ipaddr)

    nh_mpls_ip_data = sx_mpls_ip_next_hop_data_t()
    nh_mpls_ip_data.ip_next_hop = nh_sx_ip

    return nh_mpls_ip_data


def make_sx_mpls_next_hop(rif, ipaddr, label_out_arr, nh_type=SX_NEXT_HOP_TYPE_MPLS, eRIF=None, uRIF=None):
    " This function creates sx_mpls_next_hop_t struct with given parameters. "

    nh_key = sx_next_hop_key_t()
    nh_key.type = nh_type

    if nh_type == SX_NEXT_HOP_TYPE_MPLS:
        mpls_nh = sx_mpls_next_hop_t()
        mpls_nh.type = SX_MPLS_IP_NEXT_HOP_TYPE
        mpls_nh.label_cnt = len(label_out_arr)
        mpls_nh.label_list = make_sx_mpls_label_stack_entry(label_out_arr)
        mpls_nh.mpls_next_hop_entry.ip_next_hop_data = make_sx_mpls_ip_next_hop_data(rif, ipaddr)

        nh_key.next_hop_key_entry.mpls_next_hop = mpls_nh

    return nh_key


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                    RIF_STR, RIF_STR, LABEL_OUT_STR.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()

    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        nh_type = SX_NEXT_HOP_TYPE_MPLS
        nh_eRIF = None
        nh_uRIF = None

        next_hop = make_mpls_ecmp_next_hop(nh[RIF_STR], nh[IP_STR],
                                           nh[LABELS_OUT_STR], nh[WEIGHT_STR],
                                           nh_type, nh_eRIF, nh_uRIF)
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def create_empty_external_ecmp_container():
    """
    This function creates an empty external ECMP container.
    @return: ECMP container ID
    """
    uint32_ptr = new_uint32_t_p()
    uint32_t_p_assign(uint32_ptr, 0)

    nh_ptr = new_sx_next_hop_t_p()
    ecmp_id_p = new_sx_ecmp_id_t_p()

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_ptr, uint32_ptr)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def modify_external_ecmp_container(ecmp_id, nh_params_list=[]):
    """
    This function modify an external ECMP container with a given next hops list
    @param ecmp_id: ecmp container id.
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def set_ecmp_attributes(ecmp_id, ecmp_type, active_flow_timer=100, group_size=4096, max_unbalanced_time=200, container_type=SX_ECMP_CONTAINER_TYPE_IP, rif_valid=0, underlay_rif=0):
    """"
    This function sets ECMP external container attributes
    @param emcp_id: ECMP container ID
    @param type: External ECMP container type, e.g. SX_ECMP_TYPE_RESILIENT_E
    @param active_flow_timer: ECMP active flow timer
    @param groups_size:    ECMP container group size
    @param max_unbalanced_time: ECMP max unbalanced time
    @param container_type: ECMP container type, e.g. SX_ECMP_CONTAINER_TYPE_IP
    """
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = ecmp_type
    ecmp_attributes.container_type = container_type
    ecmp_attributes.active_flow_timer = active_flow_timer
    ecmp_attributes.group_size = group_size
    ecmp_attributes.max_unbalanced_time = max_unbalanced_time
    ecmp_attributes.mpls_attributes.rif_valid = rif_valid
    ecmp_attributes.mpls_attributes.underlay_rif = underlay_rif
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)


def destroy_flow_counter(flow_counter_id):
    " This function destroys router counter. "

    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS
    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, flow_counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy ecmp counter, rc: %d" % (rc)

    print("Destroyed flow counter %d" % (flow_counter_id))


def create_flow_counter():
    " This function creates ecmp flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter, rc: %d" % (rc)

    counter_id = sx_router_counter_id_t_p_value(counter_p)

    print("Created flow counter %x" % (counter_id))
    return counter_id


def read_flow_counters(flow_counter_id):
    " This function reads and clears router counters. "

    counter_set = sx_flow_counter_set_t()
    counter_set_p = new_sx_flow_counter_set_t_p()

    rc = sx_api_flow_counter_get(handle, SX_ACCESS_CMD_READ, flow_counter_id, counter_set_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read flow counter %d, rc: %d" % (flow_counter_id, rc)
    print("Read flow counter %d" % (flow_counter_id))

    counter_set = sx_flow_counter_set_t_p_value(counter_set_p)
    return counter_set


def acl_policy_based_ilm_set(handle, cmd, pbilm_p, pbilm_id_p):
    rc = sx_api_acl_policy_based_ilm_set(handle,
                                         cmd,
                                         pbilm_p,
                                         pbilm_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to acl_policy_based_ilm_set rc: %d" % (rc)


def mpls_router_deinit(vrid, rif_arr, PORT1, PORT2, PORT3):
    """
    This function deinit router and port, remove neighbors, router counters and
    flow counters
    """

    mac_entry1 = sx_fdb_uc_mac_addr_params_t()
    mac_entry1.mac_addr = DEST_MAC
    mac_entry1.fid_vid = 4          # Filtering Identifier, VID for static MAC
    mac_entry1.log_port = PORT3
    mac_entry1.entry_type = SX_FDB_UC_STATIC
    mac_entry1.action = SX_FDB_ACTION_FORWARD
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_fdb_uc_mac_addr_set"

    rc = sx_api_port_state_set(handle, PORT2, SX_PORT_ADMIN_STATUS_DOWN)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_state_set"

    rc = sx_api_port_phys_loopback_set(handle, PORT2, SX_PORT_PHYS_LOOPBACK_DISABLE)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_phys_loopback_set"

    rc = sx_api_port_state_set(handle, PORT2, SX_PORT_ADMIN_STATUS_UP)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_state_set up"

    # delete all neighbors per rif
    delete_all_neigh_per_rif(rif_arr[0])

    # delete rif
    delete_rif(vrid, rif_arr[0])
    delete_rif(vrid, rif_arr[1])

    remove_ports_from_vlan(6, {PORT1: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(4, {PORT2: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT2: SX_TAGGED_MEMBER})
    remove_ports_from_vlan(5, {PORT3: SX_TAGGED_MEMBER})

    # delete vrid
    delete_vrid(vrid)

    # deinit router
    router_deinit()


def acl_rule_delete(handle, region_id, offset):
    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    try:
        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)
        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_DELETE,
                                       region_id,
                                       offsets_list,
                                       None,
                                       1)

        assert SX_STATUS_SUCCESS == rc, "Failed to set ACL rule"
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)


def acl_rule_set(handle, region_id, rule, offset, key_list, action_list, expected_rc=SX_STATUS_SUCCESS,
                 rule_valid=True):
    " this function sets rule in acl region"
    offsets_list = new_sx_acl_rule_offset_t_arr(1)
    rules_list = new_sx_flex_acl_flex_rule_t_arr(1)
    try:
        rule.valid = rule_valid
        for i, action in enumerate(action_list):
            sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, i, action)
        rule.action_count = len(action_list)

        for i, key_desc in enumerate(key_list):
            sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, i, key_desc)
        rule.key_desc_count = len(key_list)

        sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, offset)

        sx_flex_acl_flex_rule_t_arr_setitem(rules_list, 0, rule)

        rc = sx_api_acl_flex_rules_set(handle,
                                       SX_ACCESS_CMD_SET,
                                       region_id,
                                       offsets_list,
                                       rules_list,
                                       1)

        assert SX_STATUS_SUCCESS == rc, "Failed to set ACL rule"
    finally:
        delete_sx_acl_rule_offset_t_arr(offsets_list)
        delete_sx_flex_acl_flex_rule_t_arr(rules_list)


def pbs_create(ports):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    pbs_entry = sx_acl_pbs_entry_t()
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_ROUTING
    pbs_entry.port_num = len(ports)
    pbs_entry.log_ports = new_sx_port_log_id_t_arr(len(ports))
    for i, port in enumerate(ports):
        sx_port_log_id_t_arr_setitem(pbs_entry.log_ports, i, port)
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_ADD,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create pbs, rc = %d" % (rc)
    return sx_acl_pbs_id_t_p_value(pbs_id_p)


def pbs_delete(pbs_id):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    sx_acl_pbs_id_t_p_assign(pbs_id_p, pbs_id)
    pbs_entry = sx_acl_pbs_entry_t()
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_DELETE,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete pbs %d, rc = %d" % (pbs_id, rc)


def mpls_router_init(PORT1, PORT2, PORT3):
    """
    This function init router and port, add neighbors, create router counters and
    flow counter
    @return: List of vrid id, rif array, ecmp counter id, list of router counters
    """

    # init router
    router_init()

    # create vrid
    vrid = create_vrid()

    add_ports_to_vlan(6, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(4, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(5, {PORT3: SX_TAGGED_MEMBER})

    rc = sx_api_port_state_set(handle, PORT2, SX_PORT_ADMIN_STATUS_DOWN)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_state_set"

    rc = sx_api_port_phys_loopback_set(handle, PORT2, SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_phys_loopback_set"

    rc = sx_api_port_state_set(handle, PORT2, SX_PORT_ADMIN_STATUS_UP)
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_port_state_set up"

    # init router port rif
    rif_arr = [None] * 2
    rif_arr[0] = create_vlan_rif(vrid, 4, IRIF_MAC, 1500)
    rif_arr[1] = create_vlan_rif(vrid, 5, ERIF_MAC, 1500)

    # rif state ipv4
    set_rif_state_ipv4(rif_arr[0])
    set_rif_state_ipv4(rif_arr[1])

    return vrid, rif_arr


def main():
    parser = argparse.ArgumentParser(description='The example demonstrates how to use acl pbilm action to strip all mpls labels')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    global handle
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        port_list = mapPortAndInterfaces(handle)
        PORT1 = port_list[0]
        PORT2 = port_list[1]
        PORT3 = port_list[2]

        vrid, rif_arr = mpls_router_init(PORT1, PORT2, PORT3)
        # init mpls
        mpls_init()
        mpls_ilm_init(vrid)
        mpls_router_interface_attributes_set(rif_arr, True, vrid)

        # resolve neighbor
        add_neigh(rif_arr[1], "22.33.0.7", NEIGH_MAC_1)

        # create empty external ECMP container
        ecmp_id = create_empty_external_ecmp_container()

        # set external ECMP container type MPLS
        set_ecmp_attributes(ecmp_id=ecmp_id, ecmp_type=SX_ECMP_TYPE_STATIC_E, container_type=SX_ECMP_CONTAINER_TYPE_MPLS)

        # modify external ECMP container with {MPLS,22.33.0.7} next hops
        next_hops_params_list = []
        next_hops_params_list.append({RIF_STR: rif_arr[1],
                                      IP_STR: "22.33.0.7",
                                      LABELS_OUT_STR: [],
                                      WEIGHT_STR: 1})
        modify_external_ecmp_container(ecmp_id, next_hops_params_list)

        # pbilm suport remove 1 or 2 label a time
        pbilm_p = new_sx_acl_pbilm_entry_t_p()
        pbilm_p.pbilm_params.action = SX_ROUTER_ACTION_FORWARD
        pbilm_p.pbilm_params.number_of_pops = 1
        pbilm_p.pbilm_params.ilm_fwd_action = SX_MPLS_ILM_GOTO_ECMP
        pbilm_p.pbilm_params.fwd_actions_params.ecmp_id = ecmp_id
        pbilm_p.pbilm_params.fwd_actions_params.goto_router_params.use_egress_rif = 0
        pbilm_id_p = new_sx_acl_pbilm_id_t_p()

        acl_policy_based_ilm_set(handle, SX_ACCESS_CMD_CREATE, pbilm_p, pbilm_id_p)

        pbilm_p1 = new_sx_acl_pbilm_entry_t_p()
        pbilm_p1.pbilm_params.action = SX_ROUTER_ACTION_FORWARD
        pbilm_p1.pbilm_params.number_of_pops = 2
        pbilm_p1.pbilm_params.ilm_fwd_action = SX_MPLS_ILM_GOTO_ECMP
        pbilm_p1.pbilm_params.fwd_actions_params.ecmp_id = ecmp_id
        pbilm_p1.pbilm_params.fwd_actions_params.goto_router_params.use_egress_rif = 0
        pbilm_id_p1 = new_sx_acl_pbilm_id_t_p()

        acl_policy_based_ilm_set(handle, SX_ACCESS_CMD_CREATE, pbilm_p1, pbilm_id_p1)

        counter_list = []
        for i in range(15):
            counter_list.append(create_flow_counter())

        key_arr = new_sx_acl_key_t_arr(3)
        sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_IS_MPLS)
        sx_acl_key_t_arr_setitem(key_arr, 1, FLEX_ACL_KEY_MPLS_LABELS_VALID)
        rule_list = []
        key_handle_p_list = []
        acl_id_p_list = []
        region_id_p_list = []
        region_id_list = []
        group_id_p_list = []
        group_id_list = []
        for i in range(0, 3):
            region_id_p = new_sx_acl_region_id_t_p()
            acl_region_group = sx_acl_region_group_t()
            acl_id_p = new_sx_acl_id_t_p()
            group_id_p = new_sx_acl_id_t_p()
            acl_id_arr = new_sx_acl_id_t_arr(5)
            rule = sx_flex_acl_flex_rule_t()
            key_handle_p = new_sx_acl_key_type_t_p()

            rc = sx_api_acl_flex_key_set(handle,
                                         SX_ACCESS_CMD_CREATE,
                                         key_arr,
                                         2,
                                         key_handle_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"
            key_handle = sx_acl_key_type_t_p_value(key_handle_p)
            key_handle_p_list.append(key_handle_p)

            rule = sx_flex_acl_flex_rule_t()
            rc = sx_lib_flex_acl_rule_init(key_handle, 10, rule)
            assert SX_STATUS_SUCCESS == rc, "Failed to sx_lib_flex_acl_rule_init"
            rule_list.append(rule)

            # creates acl region
            rc = sx_api_acl_region_set(handle,
                                       SX_ACCESS_CMD_CREATE,
                                       key_handle,
                                       0,
                                       16,
                                       region_id_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create region"
            region_id = sx_acl_region_id_t_p_value(region_id_p)
            region_id_p_list.append(region_id_p)
            region_id_list.append(region_id)
            if i == 2:
                direction = SX_ACL_DIRECTION_RIF_EGRESS
            else:
                direction = SX_ACL_DIRECTION_INGRESS
            # create acl
            acl_region_group.regions.acl_packet_agnostic.region = region_id
            rc = sx_api_acl_set(handle,
                                SX_ACCESS_CMD_CREATE,
                                SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                direction,
                                acl_region_group,
                                acl_id_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create acl"
            acl_id = sx_acl_id_t_p_value(acl_id_p)
            acl_id_p_list.append(acl_id_p)
            # Create ACL group
            rc = sx_api_acl_group_set(handle,
                                      SX_ACCESS_CMD_CREATE,
                                      direction,
                                      acl_id_arr,
                                      0,
                                      group_id_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create group"
            group_id_p_list.append(group_id_p)
            # add acl to acl group
            sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)
            rc = sx_api_acl_group_set(handle,
                                      SX_ACCESS_CMD_SET,
                                      direction,
                                      acl_id_arr,
                                      1,
                                      group_id_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"
            group_id = sx_acl_id_t_p_value(group_id_p)
            group_id_list.append(group_id)

        counter_idx = 0

        pbs_id = pbs_create([])
        # ingress acl on ingress port to do pbilm
        rule = rule_list[0]
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_BIND,
                                      PORT1,
                                      group_id_list[0])
        assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_IS_MPLS
        key_desc.key.is_mpls = 1
        key_desc.mask.is_mpls = 1

        key_desc1 = sx_flex_acl_key_desc_t()
        key_desc1.key_id = FLEX_ACL_KEY_MPLS_LABELS_VALID
        key_desc1.key.mpls_labels_valid = 0x0  # FLEX_ACL_KEY_MPLS_LABELS_VALID bit 2 is 0 means we have only 1 label.
        key_desc1.mask.mpls_labels_valid = 0x2

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_COUNTER
        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1

        # want to override the port's vlan and then send to another RIF
        action2 = sx_flex_acl_flex_action_t()
        action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
        action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
        action2.fields.action_set_vlan.vlan_id = 4

        # Set PBS Action to fwd to Router
        action3 = sx_flex_acl_flex_action_t()
        action3.type = SX_FLEX_ACL_ACTION_PBS
        action3.fields.action_pbs.pbs_id = pbs_id

        action4 = sx_flex_acl_flex_action_t()
        action4.type = SX_FLEX_ACL_ACTION_PBILM
        action4.fields.action_pbilm.pbilm_id = sx_acl_pbilm_id_t_p_value(pbilm_id_p)  # remove 1 label if only 1 mpls label. FLEX_ACL_KEY_MPLS_LABELS_VALID bit 2 will tell us if we have more than 1 label.

        acl_rule_set(handle, region_id_list[0], rule, 0, [key_desc, key_desc1], [action1, action2, action3, action4])

        # 2nd rule which handle more than 1 mpls label and pop 2 labels
        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1

        action4.fields.action_pbilm.pbilm_id = sx_acl_pbilm_id_t_p_value(pbilm_id_p1)  # remove 2 label
        acl_rule_set(handle, region_id_list[0], rule, 1, [key_desc], [action1, action2, action3, action4])

        # 3rd rule, catch all, just count
        key_desc.key.is_mpls = 0
        key_desc.mask.is_mpls = 0
        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1
        acl_rule_set(handle, region_id_list[0], rule, 2, [key_desc], [action1])

        # ingress acl on loobpack port to do pbilm, same as above, only counter is different
        key_desc.key.is_mpls = 1
        key_desc.mask.is_mpls = 1
        rule = rule_list[2]
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_BIND,
                                      PORT2,
                                      group_id_list[1])
        assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1
        action4.fields.action_pbilm.pbilm_id = sx_acl_pbilm_id_t_p_value(pbilm_id_p)  # remove 1 label
        acl_rule_set(handle, region_id_list[1], rule, 0, [key_desc, key_desc1], [action1, action2, action3, action4])

        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1

        action4.fields.action_pbilm.pbilm_id = sx_acl_pbilm_id_t_p_value(pbilm_id_p1)  # remove 2 label
        acl_rule_set(handle, region_id_list[1], rule, 1, [key_desc], [action1, action2, action3, action4])

        # 3rd rule, catch all, just count
        key_desc.key.is_mpls = 0
        key_desc.mask.is_mpls = 0
        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1
        acl_rule_set(handle, region_id_list[1], rule, 2, [key_desc], [action1])

        # egress acl on erif
        rule = rule_list[2]

        rc = sx_api_acl_rif_bind_set(handle,
                                     SX_ACCESS_CMD_BIND,
                                     rif_arr[1],
                                     group_id_list[2])
        assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_IS_MPLS
        key_desc.key.is_mpls = 1
        key_desc.mask.is_mpls = 1

        # rule 1, if there are any label, send it to loopback port PORT2
        # FLEX_ACL_KEY_MPLS_LABELS_VALID bit 1 can tell if there are any label left. FLEX_ACL_KEY_IS_MPLS is set at the begining and not updated after label remove.
        key_desc1 = sx_flex_acl_key_desc_t()
        key_desc1.key_id = FLEX_ACL_KEY_MPLS_LABELS_VALID
        key_desc1.key.mpls_labels_valid = 0x1
        key_desc1.mask.mpls_labels_valid = 0x1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_COUNTER
        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1

        bridge_id1, log_vport1 = bridge_vport_create(handle, PORT2, 5)
        action2 = sx_flex_acl_flex_action_t()
        action2.type = SX_FLEX_ACL_ACTION_SET_BRIDGE
        action2.fields.action_set_bridge.bridge_id = bridge_id1

        acl_rule_set(handle, region_id_list[2], rule, 0, [key_desc, key_desc1], [action1, action2])

        # rule 2, no lable, send it to egress port PORT3
        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_IS_MPLS
        key_desc.key.is_mpls = 1
        key_desc.mask.is_mpls = 1

        action1.fields.action_counter.counter_id = counter_list[counter_idx]
        counter_idx += 1

        bridge_id2, log_vport2 = bridge_vport_create(handle, PORT3, 5)
        action2.fields.action_set_bridge.bridge_id = bridge_id2

        action3 = sx_flex_acl_flex_action_t()
        action3.type = SX_FLEX_ACL_ACTION_SET_DST_MAC
        action3.fields.action_set_dst_mac.mac = DEST_MAC

        acl_rule_set(handle, region_id_list[2], rule, 1, [key_desc], [action1, action2, action3])
        '''
           send packets here if testing this script
        '''
        if args.deinit:
            acl_rule_delete(handle, region_id_list[0], 0)
            acl_rule_delete(handle, region_id_list[0], 1)
            acl_rule_delete(handle, region_id_list[0], 2)

            acl_rule_delete(handle, region_id_list[1], 0)
            acl_rule_delete(handle, region_id_list[1], 1)
            acl_rule_delete(handle, region_id_list[1], 2)

            acl_rule_delete(handle, region_id_list[2], 0)
            acl_rule_delete(handle, region_id_list[2], 1)

            pbs_delete(pbs_id)
            bridge_vport_delete(handle, 5, PORT2, bridge_id1, log_vport1)
            bridge_vport_delete(handle, 5, PORT3, bridge_id2, log_vport2)
            rc = sx_api_acl_port_bind_set(handle,
                                          SX_ACCESS_CMD_UNBIND,
                                          PORT1,
                                          group_id_list[0])
            assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_acl_port_bind_set"

            rc = sx_api_acl_port_bind_set(handle,
                                          SX_ACCESS_CMD_UNBIND,
                                          PORT2,
                                          group_id_list[1])
            assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_acl_port_bind_set"
            rc = sx_api_acl_rif_bind_set(handle,
                                         SX_ACCESS_CMD_UNBIND,
                                         rif_arr[1],
                                         group_id_list[2])
            assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

            acl_id_arr = new_sx_acl_id_t_arr(5)
            acl_region_group = sx_acl_region_group_t()
            for i in range(0, 3):
                if i == 2:
                    direction = SX_ACL_DIRECTION_RIF_EGRESS
                else:
                    direction = SX_ACL_DIRECTION_INGRESS

                rc = sx_api_acl_group_set(handle,
                                          SX_ACCESS_CMD_DESTROY,
                                          direction,
                                          acl_id_arr,
                                          0,
                                          group_id_p_list[i])
                acl_region_group.regions.acl_packet_agnostic.region = region_id_list[i]
                rc = sx_api_acl_set(handle,
                                    SX_ACCESS_CMD_DESTROY,
                                    SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                    0,
                                    acl_region_group,
                                    acl_id_p_list[i])
                assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id_p, rc)
                rc = sx_api_acl_region_set(handle,
                                           SX_ACCESS_CMD_DESTROY,
                                           0,
                                           0,
                                           0,
                                           region_id_p_list[i])
                assert SX_STATUS_SUCCESS == rc, "Failed to destroy region"
                rc = sx_api_acl_flex_key_set(handle,
                                             SX_ACCESS_CMD_DELETE,
                                             key_arr,
                                             2,
                                             key_handle_p_list[i])
                assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"

            # Delete neighbor
            delete_neigh(rif_arr[1], "22.33.0.7")

            acl_policy_based_ilm_set(handle, SX_ACCESS_CMD_DESTROY, pbilm_p, pbilm_id_p)
            acl_policy_based_ilm_set(handle, SX_ACCESS_CMD_DESTROY, pbilm_p1, pbilm_id_p1)
            # Delete ecmp container
            destroy_ecmp_container(ecmp_id)
            mpls_router_interface_attributes_set(rif_arr, False)
            mpls_ilm_destroy(vrid)
            mpls_deinit()

            mpls_router_deinit(vrid, rif_arr, PORT1, PORT2, PORT3)
            for i in range(15):
                destroy_flow_counter(counter_list[i])
    finally:
        rc = sx_api_close(handle)
        assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_close"


if __name__ == "__main__":

    NEIGH_MAC_1 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6C, 0x81)
    DEST_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x68, 0x88)
    IRIF_MAC = ether_addr("00:02:03:04:05:07")
    ERIF_MAC = ether_addr("00:02:03:04:05:08")

    # string constants
    RIF_STR = "RIF"
    IP_STR = "IP"
    LABELS_OUT_STR = "LABELS_OUT"
    NEXT_HOP_TYPE_STR = "NEXT_HOP_TYPE"
    WEIGHT_STR = "WEIGHT"
    iRIF_STR = "iRIF"
    eRIF_STR = "eRIF"
    uRIF_STR = "uRIF"

    sys.exit(main())
