#!/usr/bin/env python
'''
This file contains Python command example that reads all the Registers in the system
and displays their value.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
This example is supported on Spectrum2 and later devices
'''
import sys
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_register_dump example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

reg_type_dict = {
    SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E: 'GP register'
}


def reg_id_reg(reg_key):
    if reg_key.type == SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        return reg_key.key.gp_reg.reg_id
    return -1


def example_exit(rc):
    if args.deinit:
        sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_reg_module_level, orig_reg_api_level)
    sx_api_close(handle)
    sys.exit(rc)


old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

module_verbosity_level_p = new_sx_verbosity_level_t_p()
api_verbosity_level_p = new_sx_verbosity_level_t_p()

rc = sx_api_register_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
if rc != SX_STATUS_SUCCESS:
    print("Failed to retrieve the REGISTER Module current verbosity setting!")
    sys.exit(rc)

orig_reg_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
orig_reg_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

rc = sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
if rc != SX_STATUS_SUCCESS:
    print("fail to set register API log verbosity level")
    sys.exit(rc)

reg_cnt_p = new_uint32_t_p()
uint32_t_p_assign(reg_cnt_p, 0)
key = sx_register_key_t()

rc = sx_api_register_iter_get(handle, SX_ACCESS_CMD_GET, key, None, None, reg_cnt_p)
if (rc != SX_STATUS_SUCCESS):
    if rc == SX_STATUS_UNSUPPORTED:
        print("Register module is not supported on this chip type")
        sys.exit(0)
    else:
        print("Failed in register iter get: rc = " + str(rc))
    example_exit(rc)

reg_cnt = uint32_t_p_value(reg_cnt_p)
reg_list_p = new_sx_register_key_t_arr(reg_cnt)

rc = sx_api_register_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, key, None, reg_list_p, reg_cnt_p)
if (rc != SX_STATUS_SUCCESS):
    print("Failed in register get: rc = " + str(rc))
    example_exit(rc)

reg_cnt = uint32_t_p_value(reg_cnt_p)
if reg_cnt > 0:
    print("--------------------------")
    print("Allocated register:")
    print("--------------------------")
    print("| %12s | %7s |" % ("Type", "ID"))
    print("--------------------------")
else:
    print("No allocated registers")

for i in range(reg_cnt):
    reg_key = sx_register_key_t_arr_getitem(reg_list_p, i)
    print("| %12s | %7d |" % (reg_type_dict[reg_key.type], reg_id_reg(reg_key)))
    print("--------------------------")

example_exit(rc)
