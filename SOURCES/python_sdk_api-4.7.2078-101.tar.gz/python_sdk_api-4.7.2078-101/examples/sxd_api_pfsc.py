#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='sxd_api_pfsc example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] PFSC register access test start")
print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
assert rc == SXD_STATUS_SUCCESS, "sxd_access_reg_init failed, rc: %d" % (rc)

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

original_pfsc = ku_pfsc_reg()
original_pfsc.local_port, original_pfsc.lp_msb = common_lib.get_lsb_msb_of_local_port(1)

meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_pfsc(original_pfsc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PFSC register, rc: %d" % (rc)

pfsc = ku_pfsc_reg()

pfsc.local_port, pfsc.lp_msb = common_lib.get_lsb_msb_of_local_port(1)


print("[+] Get PFSC")
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_pfsc(pfsc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PFSC register, rc: %d" % (rc)

print("[+] local port: ", pfsc.local_port)
print("[+] lp_msb: ", pfsc.lp_msb)

print("[+] Get PFSC content")
print("====================")
print("[+] Admin Forward: ", pfsc.fwd_admin)
print("[+] Oper Forward: ", pfsc.fwd_oper)


print("[+] Set PFSC content")
print("====================")
pfsc.fwd_admin = 1
print("[+] Admin Forward: ", pfsc.fwd_admin)

print("[+] Set PFSC")
meta.access_cmd = SXD_ACCESS_CMD_SET

rc = sxd_access_reg_pfsc(pfsc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to set PFSC register, rc: %d" % (rc)

meta.access_cmd = SXD_ACCESS_CMD_GET

print("[+] Get PFSC")
rc = sxd_access_reg_pfsc(pfsc, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get PFSC register, rc: %d" % (rc)

print("[+] Get after Set PFSC content")
print("==============================")
print("[+] Admin Forward: ", pfsc.fwd_admin)
print("[+] Oper Forward: ", pfsc.fwd_oper)

if args.deinit:
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_pfsc(original_pfsc, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set PFSC register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("[+] PFSC register access test end")
