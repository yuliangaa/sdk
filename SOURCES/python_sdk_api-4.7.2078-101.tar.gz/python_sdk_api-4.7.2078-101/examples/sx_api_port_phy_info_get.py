#!/usr/bin/env python
'''
This file contains Python command example for the port module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the usage of SDK API sx_api_port_phy_info_get.
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

SWID = SPECTRUM_SWID
DEVICE_ID = 1


parser = argparse.ArgumentParser(description='Call to sx_api_port_phy_info_get')
parser.add_argument('--log_port', default=0, type=auto_int, help='Logical port ID')
parser.add_argument('--read_clear', default='false', choices=['true', 'false'], help='Whether to clear the port state change counter after read')
args = parser.parse_args()


def print_phy_stat(log_port, phy_stat):
    print(("port 0x%x" % log_port))
    print("=============================")
    if phy_stat.port_state == SX_PORT_OPER_STATUS_UP:
        print("Status: Up")
    else:
        print("Status: Down")
        print("Port Down Reason:")
        print(("  port_admin_down: %d" % phy_stat.port_down_reason.port_admin_down))
        print(("  auto_negotiation_failure: %d" % phy_stat.port_down_reason.auto_negotiation_failure))
        print(("  logical_mismatch_with_peer_link: %d" % phy_stat.port_down_reason.logical_mismatch_with_peer_link))
        print(("  link_training_failure: %d" % phy_stat.port_down_reason.link_training_failure))
        print(("  peer_is_sending_remote_faults: %d" % phy_stat.port_down_reason.peer_is_sending_remote_faults))
        print(("  bad_signal_integrity: %d" % phy_stat.port_down_reason.bad_signal_integrity))
        print(("  cable_transceiver_is_not_supported: %d" % phy_stat.port_down_reason.cable_transceiver_is_not_supported))
        print(("  calibration_failure: %d" % phy_stat.port_down_reason.calibration_failure))
        print(("  cable_transceiver_is_unplugged: %d" % phy_stat.port_down_reason.cable_transceiver_is_unplugged))
    print(("Port State Change Count: %d\n" % phy_stat.port_state_change_cnt))


def get_all_ports_phy_stat(handle, cmd):
    port_attributes_list_p = new_sx_port_attributes_t_arr(0)
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, port_attributes_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)

    port_attributes_list_p = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, port_attributes_list_p, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)

    for i in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list_p, i)
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if is_nve or is_vport or is_cpu:
            continue
        phy_stat_p = new_sx_port_phy_stat_t_p()
        rc = sx_api_port_phy_info_get(handle, cmd, port_attributes.log_port, phy_stat_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_phy_info_get failed, rc = %d" % (rc))
            sys.exit(rc)
        phy_stat = sx_port_phy_stat_t_p_value(phy_stat_p)
        print_phy_stat(port_attributes.log_port, phy_stat)


def get_one_port_phy_stat(handle, cmd, log_port):
    phy_stat_p = new_sx_port_phy_stat_t_p()
    rc = sx_api_port_phy_info_get(handle, cmd, log_port, phy_stat_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_phy_info_get failed, rc = %d" % (rc))
        sys.exit(rc)
    phy_stat = sx_port_phy_stat_t_p_value(phy_stat_p)
    print_phy_stat(log_port, phy_stat)


def main():

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    cmd = SX_ACCESS_CMD_READ
    if args.read_clear == 'true':
        cmd = SX_ACCESS_CMD_READ_CLEAR

    if args.log_port == 0:
        get_all_ports_phy_stat(handle, cmd)
    else:
        get_one_port_phy_stat(handle, cmd, args.log_port)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
