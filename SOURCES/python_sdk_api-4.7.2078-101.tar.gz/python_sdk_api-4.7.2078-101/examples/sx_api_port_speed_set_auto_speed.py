#!/usr/bin/env python
'''
Sets all port speed to mode auto
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_speed_set_auto_speed example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("This example is supported only on SPC1.")
        sys.exit(0)

    # Get ports count
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    port_attributes_list = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)

    # Get ports
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_port_device_get failed, rc = %d")
        sys.exit(rc)

    admin_speed_p = new_sx_port_speed_capability_t_p()

    orig_admin_speeds = {}
    for i in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        port = int(port_attributes.log_port)
        is_vport = check_vport(port)
        is_nve = check_nve(port)
        is_cpu = check_cpu(port)
        if is_nve or is_vport or is_cpu:
            continue

        if args.deinit:
            original_port_speed_capability_p = new_sx_port_speed_capability_t_p()
            original_port_oper_speed_p = new_sx_port_oper_speed_t_p()
            rc = sx_api_port_speed_get(handle, port, original_port_speed_capability_p, original_port_oper_speed_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_speed_get failed [rc=%d]" % (rc)))
                sys.exit(rc)
            orig_admin_speeds[port] = (original_port_speed_capability_p, original_port_oper_speed_p)

        rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
            sys.exit(rc)

        print(("[+] Setting log_port:0x%x admin state to DOWN." % (port_attributes.log_port)))
        admin_speed_p = new_sx_port_speed_capability_t_p()
        admin_speed_p.mode_auto = 1
        admin_speed_p.force = 0
        rc = sx_api_port_speed_admin_set(handle, port, admin_speed_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_speed_admin_set failed, rc=%d] " % (rc)))
            sys.exit(rc)
        print(("[+] Setting log_port:0x%x speed to mode auto." % (port_attributes.log_port)))

        rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed, rc=%d] " % (rc)))
            sys.exit(rc)
        print(("[+] Setting log_port:0x%x admin state to UP." % (port_attributes.log_port)))

    if args.deinit:
        print("Cleanup - Restore original port speeds")
        for port, speed_tuple in list(orig_admin_speeds.items()):
            rc = sx_api_port_speed_admin_set(handle, port, speed_tuple[0])
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_speed_admin_set failed restore orig speed, rc=%d, port = 0x%x] " % (rc, port)))
                sys.exit(rc)
            delete_sx_port_speed_capability_t_p(speed_tuple[0])
            delete_sx_port_oper_speed_t_p(speed_tuple[1])

    sx_api_close(handle)
