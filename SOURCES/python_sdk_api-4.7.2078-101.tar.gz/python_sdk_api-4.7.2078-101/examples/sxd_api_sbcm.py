#!/usr/bin/env python

import sys
import errno
import argparse

from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

print("[+] Read SBCM register")

parser = argparse.ArgumentParser(description='SBCM read utility')
parser.add_argument('--local_port', default=1, type=int, help="Local Port")
parser.add_argument('--dir', default=1, type=int, help="Ingress(0), Egress(1)")
parser.add_argument('--pg_or_tc', default=0, type=int, help="pg/tc")
parser.add_argument('--descriptors', default=0, type=int, help="Descriptors or data pol")
args = parser.parse_args()

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("Failed to initialize register access.\nPlease check that SDK is running.")
    sys.exit(rc)

sbcm = ku_sbcm_reg()

meta = sxd_reg_meta_t()
meta.dev_id = 1
meta.swid = 0

""" Get sbcm """
meta.access_cmd = SXD_ACCESS_CMD_GET
sbcm.local_port, sbcm.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

sbcm.pg_buff = args.pg_or_tc
sbcm.dir = args.dir
sbcm.desc = args.descriptors
print(("sbcm GET: Local port: %d, Dir:%d pg_buff:%d" % (sbcm.local_port, sbcm.dir, sbcm.pg_buff)))

rc = sxd_access_reg_sbcm(sbcm, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to get SBCM register, rc: %d" % (rc)

print(("local_port: %d" % sbcm.local_port))
print(("lp_msb: %d" % sbcm.lp_msb))
print(("dir: %d" % sbcm.dir))
print(("pg_buff: %d" % sbcm.pg_buff))
print(("min_buff: %d" % sbcm.min_buff))
print(("max_buff: %d" % sbcm.max_buff))
print(("infinite_size: %d" % sbcm.infinite_size))

print(("buff_occupancy: %d" % sbcm.buff_occupancy))
print(("max_buff_occupancy: %d" % sbcm.max_buff_occupancy))

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)

print("sbcm GET is Done")

sys.exit(0)
