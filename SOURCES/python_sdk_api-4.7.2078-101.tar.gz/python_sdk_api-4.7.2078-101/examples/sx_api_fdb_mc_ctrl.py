#!/usr/bin/env python
"""
This file contains Python command monitoring firware degug setting get/set.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.


"""
import sys
import traceback
import errno
import os
import inspect
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_fdb_mc_ctrl')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

vlan_id = 2

# get current multicast flood mode for later de-configuration
original_urmc_flood_mode_p = new_sx_fdb_unreg_flood_mode_t_p()
rc = sx_api_fdb_unreg_mc_flood_mode_get(handle, 0, vlan_id, original_urmc_flood_mode_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_unreg_mc_flood_mode_get failed. rc=%d" % rc
original_urmc_flood_mode = sx_fdb_unreg_flood_mode_t_p_value(original_urmc_flood_mode_p)

# set multicast flood  mode
urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD  # Can also be SX_FDB_UNREG_MC_PRUNE
rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_id, urmc_flood_mode)
print(("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode: %d, rc: %d " % (vlan_id, urmc_flood_mode, rc)))

# get multicast flood  mode
sx_fdb_unreg_flood_mode_t_ptr = new_sx_fdb_unreg_flood_mode_t_p()
rc = sx_api_fdb_unreg_mc_flood_mode_get(handle, 0, vlan_id, sx_fdb_unreg_flood_mode_t_ptr)
urmc_flood_mode = sx_fdb_unreg_flood_mode_t_p_value(sx_fdb_unreg_flood_mode_t_ptr)
print(("sx_api_fdb_unreg_mc_flood_mode_get swid 0  vlan id: %d, mode: %d, rc: %d " % (vlan_id, urmc_flood_mode, rc)))

# set multicast flood ports for vlan
total_dev_ports = 64
port_attributes_list = new_sx_port_attributes_t_arr(total_dev_ports)
dev_portcount_p = new_uint32_t_p()
uint32_t_p_assign(dev_portcount_p, total_dev_ports)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, dev_portcount_p)

# get current ports list for later de-configuration
port_cnt = 2
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, port_cnt)

set_portlist = []
port_list = new_sx_port_log_id_t_arr(port_cnt)
log_port = sx_port_attributes_t_arr_getitem(port_attributes_list, 0).log_port
sx_port_log_id_t_arr_setitem(port_list, 0, log_port)
set_portlist.append(log_port)
log_port = sx_port_attributes_t_arr_getitem(port_attributes_list, 1).log_port
sx_port_log_id_t_arr_setitem(port_list, 1, log_port)
set_portlist.append(log_port)
rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_id, port_list, port_cnt)
print(("sx_api_fdb_unreg_mc_flood_ports_set swid 0  vlan id: %d, rc: %d " % (vlan_id, rc)))


# get multicast flood ports count
portcount_p = new_uint32_t_p()
uint32_t_p_assign(portcount_p, 0)
rc = sx_api_fdb_unreg_mc_flood_ports_get(handle, 0, vlan_id, None, portcount_p)
portcount = uint32_t_p_value(portcount_p)
print(("sx_api_fdb_unreg_mc_flood_ports_get swid 0  vlan id: %d, port count=%d, rc: %d " % (vlan_id, portcount, rc)))

# get port list
get_portlist = []
portlist_arr = new_sx_port_log_id_t_arr(portcount)
rc = sx_api_fdb_unreg_mc_flood_ports_get(handle, 0, vlan_id, portlist_arr, portcount_p)
PORT1_GET = sx_port_log_id_t_arr_getitem(portlist_arr, 0)
get_portlist.append(PORT1_GET)
PORT2_GET = sx_port_log_id_t_arr_getitem(portlist_arr, 1)
get_portlist.append(PORT2_GET)
assert sorted(set_portlist) == sorted(get_portlist), "port list mismatch"
print(("sx_api_fdb_unreg_mc_flood_ports_get swid 0  vlan id: %d, port1=0x%x, port2=0x%x rc: %d " % (vlan_id, PORT1_GET, PORT2_GET, rc)))


if args.deinit:
    rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_id, None, 0)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_unreg_mc_flood_ports_set failed. rc=%d" % rc

    rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_id, original_urmc_flood_mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_unreg_mc_flood_mode_set failed. rc=%d" % rc

sx_api_close(handle)
