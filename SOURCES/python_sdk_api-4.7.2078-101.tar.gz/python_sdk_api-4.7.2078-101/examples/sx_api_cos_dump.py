#!/usr/bin/env python
"""
This file contains a python commands example for the BRIDGE module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


class QosDump(object):

    def __init__(self, port):
        if port is not None:
            self.ports = [port]
        else:
            SWID = 0
            DEVICE_ID = 1
            self.ports = []
            port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(port_cnt_p, 0)
            rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, None, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                exit(1)
            port_cnt = uint32_t_p_value(port_cnt_p)
            port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
            rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, port_attributes_list, port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                exit(1)
            for i in range(port_cnt):
                port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
                is_vport = check_vport(int(port_attributes.log_port))
                is_nve = check_nve(int(port_attributes.log_port))
                is_cpu = check_cpu(int(port_attributes.log_port))
                if not is_nve and not is_vport and not is_cpu:
                    self.ports.append(port_attributes.log_port)

    def dump_all(self):
        print('')
        self.dump_global()
        self.dump_per_port()

    def dump_global(self):
        print("SDK QOS GLOBAL DUMP")
        self.switch_prio_to_ieee_prio_dump()

    def dump_per_port(self):
        print(" SDK QOS PER PORT DUMP")
        for port in self.ports:
            print("Port 0x%X:" % (port))
            self.trust_state(port)
            self.default_conf(port)
            self.pcpdei_to_prio(port)
            self.dscp_to_prio(port)
            self.exp_to_prio(port)
            self.rewrite(port)
            self.prio_to_tc(port)
            self.ets_elements(port)
            self.prio_to_pcp(port)
            self.prio_to_dscp(port)
            self.prio_to_exp(port)
            print("")

    def switch_prio_to_ieee_prio_dump(self):
        print("Switch Priority to IEEE Priority")
        print("\t===============================")
        header = ["Switch Priority", "IEEE priority"]
        print("\t|%15s|%13s|" % (header[0], header[1]))
        print("\t===============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_prio_to_ieeeprio_get(handle, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        prio_p = new_sx_cos_priority_t_arr(element_cnt)
        ieee_prio_p = new_sx_cos_ieee_prio_t_arr(element_cnt)
        rc = sx_api_cos_prio_to_ieeeprio_get(handle, prio_p, ieee_prio_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            switch_prio = sx_cos_priority_t_arr_getitem(prio_p, i)
            ieee_prio = sx_cos_ieee_prio_t_arr_getitem(ieee_prio_p, i)
            print("\t|%15s|%13s|" % (switch_prio, ieee_prio))
            print("\t===============================")
        print("")

    def trust_state(self, port):
        trust_state = {SX_COS_TRUST_LEVEL_PORT: 'Port', SX_COS_TRUST_LEVEL_L2: 'L2',
                       SX_COS_TRUST_LEVEL_L3: 'L3', SX_COS_TRUST_LEVEL_BOTH: 'Both'}
        trust_p = new_sx_cos_trust_level_t_p()
        rc = sx_api_cos_port_trust_get(handle, port, trust_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        trust = sx_cos_trust_level_t_p_value(trust_p)
        print("\tTrust state: %s" % (trust_state[trust]))

    def default_conf(self, port):
        colors = {0: 'Green', 1: 'Yellow', 2: 'Red'}
        prio_p = new_sx_cos_priority_t_p()
        rc = sx_api_cos_port_default_prio_get(handle, port, prio_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        prio = sx_cos_priority_t_p_value(prio_p)
        color_p = new_sx_cos_color_t_p()
        rc = sx_api_cos_port_default_color_get(handle, port, color_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        color = sx_cos_color_t_p_value(color_p)
        pcp_dei_p = new_sx_cos_pcp_dei_t_p()
        rc = sx_api_cos_port_default_pcpdei_get(handle, port, pcp_dei_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        pcp_dei = sx_cos_pcp_dei_t_p_value(pcp_dei_p)
        print("\tDefault Switch Priority: %s" % (prio))
        print("\tDefault Color: %s (%s)" % (color, colors[color]))
        print("\tDefault PCP: %s" % (pcp_dei.pcp))
        print("\tDefault DEI: %s" % (pcp_dei.dei))

    def pcpdei_to_prio(self, port):
        print("\tPCP/DEI to Switch Priority and Color:")
        print("\t\t===============================")
        header = ["PCP", "DEI", "Switch Priority", "Color"]
        print("\t\t|%3s|%3s|%15s|%5s|" % (header[0], header[1], header[2], header[3]))
        print("\t\t===============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_pcpdei_to_prio_get(handle, port, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        rc = sx_api_cos_port_pcpdei_to_prio_get(handle, port, pcp_dei_p, prio_color_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            pcp_dei = sx_cos_pcp_dei_t_arr_getitem(pcp_dei_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            print("\t\t|%3s|%3s|%15s|%5s|" % (pcp_dei.pcp, pcp_dei.dei, prio_color.priority, prio_color.color))
            print("\t\t===============================")
        print("")

    def dscp_to_prio(self, port):
        print("\tDSCP to Switch Priority and Color:")
        print("\t\t============================")
        header = ["DSCP", "Switch Priority", "Color"]
        print("\t\t|%4s|%15s|%5s|" % (header[0], header[1], header[2]))
        print("\t\t============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_dscp_to_prio_get(handle, port, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        dscp_p = new_sx_cos_dscp_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        rc = sx_api_cos_port_dscp_to_prio_get(handle, port, dscp_p, prio_color_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            dscp = sx_cos_dscp_t_arr_getitem(dscp_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            print("\t\t|%4s|%15s|%5s|" % (dscp, prio_color.priority, prio_color.color))
            print("\t\t============================")
        print("")

    def exp_to_prio(self, port):
        print("\tEXP to Switch Priority, Color and ECN:")
        print("\t\t===============================")
        header = ["EXP", "Switch Priority", "Color", "ECN"]
        print("\t\t|%3s|%15s|%5s|%3s|" % (header[0], header[1], header[2], header[3]))
        print("\t\t===============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_exp_to_prio_get(handle, port, None, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        exp_p = new_sx_cos_exp_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        ecn_p = new_sx_cos_ecn_t_arr(element_cnt)
        rc = sx_api_cos_port_exp_to_prio_get(handle, port, exp_p, prio_color_p, ecn_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            exp = sx_cos_exp_t_arr_getitem(exp_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            ecn = sx_cos_ecn_t_arr_getitem(exp_p, i)
            print("\t\t|%3s|%15s|%5s|%3s|" % (exp, prio_color.priority, prio_color.color, ecn))
            print("\t\t===============================")
        print("")

    def rewrite(self, port):
        rewrite_enable_str = {0: 'Disabled', 1: 'Enabled'}
        print("\tRewrite Enabled:")
        rewrite_enable_p = new_sx_cos_rewrite_enable_t_p()
        rc = sx_api_cos_port_rewrite_enable_get(handle, port, rewrite_enable_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        rewrite_enable = sx_cos_rewrite_enable_t_p_value(rewrite_enable_p)
        print("\t\tRewrite PCP/DEI: %s" % (rewrite_enable_str[rewrite_enable.rewrite_pcp_dei]))
        print("\t\tRewrite DSCP: %s" % (rewrite_enable_str[rewrite_enable.rewrite_dscp]))
        print("\t\tRewrite EXP: %s" % (rewrite_enable_str[rewrite_enable.rewrite_exp]))
        print("")

    def prio_to_tc(self, port):
        mc_aware_str = {0: 'Disabled', 1: 'Enabled'}
        MAX_SWITCH_PRIO = 15
        mc_aware_p = new_boolean_t_p()
        rc = sx_api_cos_port_tc_mcaware_get(handle, port, mc_aware_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        mc_aware = boolean_t_p_value(mc_aware_p)
        print("\tMC Aware: %s" % (mc_aware_str[mc_aware]))
        print('')
        print("\tSwitch Priority to Traffic Class:")
        print("\t\t===============================")
        header = ["Switch Priority", "Traffic Class"]
        print("\t\t|%15s|%13s|" % (header[0], header[1]))
        print("\t\t===============================")
        tc_p = new_sx_cos_traffic_class_t_p()
        for prio in range(MAX_SWITCH_PRIO):
            rc = sx_api_cos_port_tc_prio_map_get(handle, port, prio, tc_p)
            if rc != SX_STATUS_SUCCESS:
                exit(1)
            tc = sx_cos_traffic_class_t_p_value(tc_p)
            print("\t\t|%15s|%13s|" % (prio, tc))
            print("\t\t===============================")
        print("")

    def ets_elements(self, port):
        hierarchy = {0: "Port", 1: "Group", 2: "Sub-Group", 3: "TC"}
        dwrr = {0: "Strict Prio", 1: "DWRR"}
        print("\tETS elements:")
        print("\t\t==========================================================================")
        header = ["Hierarchy", "Index", "Next Index", "Min Shaper", "Max Shaper", "DWRR/Strict", "DWRR weight"]
        print("\t\t|%9s|%5s|%10s|%10s|%10s|%11s|%11s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6]))
        print("\t\t==========================================================================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_ets_element_get(handle, port, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        ets_p = new_sx_cos_ets_element_config_t_arr(element_cnt)
        rc = sx_api_cos_port_ets_element_get(handle, port, ets_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            ets = sx_cos_ets_element_config_t_arr_getitem(ets_p, i)
            if ets.min_shaper_rate != 0:
                min_shaper = ets.min_shaper_rate
            else:
                min_shaper = 'Disabled'
            if bool(ets.max_shaper_enable):
                max_shaper = ets.max_shaper_rate
            else:
                max_shaper = 'Disabled'
            print("\t\t|%9s|%5s|%10s|%10s|%10s|%11s|%11s|" % (hierarchy[ets.element_hierarchy],
                                                              ets.element_index,
                                                              ets.next_element_index,
                                                              min_shaper,
                                                              max_shaper,
                                                              dwrr[ets.dwrr],
                                                              ets.dwrr_weight))
            print("\t\t==========================================================================")
        print("")

    def prio_to_pcp(self, port):
        print("\tSwitch Priority and Color to PCP/DEI Rewrite:")
        print("\t\t===============================")
        header = ["Switch Priority", "Color", "PCP", "DEI"]
        print("\t\t|%15s|%5s|%3s|%3s|" % (header[0], header[1], header[2], header[3]))
        print("\t\t===============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_prio_to_pcpdei_rewrite_get(handle, port, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        pcp_dei_p = new_sx_cos_pcp_dei_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        rc = sx_api_cos_port_prio_to_pcpdei_rewrite_get(handle, port, prio_color_p, pcp_dei_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            pcp_dei = sx_cos_pcp_dei_t_arr_getitem(pcp_dei_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            print("\t\t|%15s|%5s|%3s|%3s|" % (prio_color.priority, prio_color.color, pcp_dei.pcp, pcp_dei.dei))
            print("\t\t===============================")
        print("")

    def prio_to_dscp(self, port):
        print("\tSwitch Priority and Color to DSCP Rewrite:")
        print("\t\t============================")
        header = ["Switch Priority", "Color", "DSCP"]
        print("\t\t|%15s|%5s|%4s|" % (header[0], header[1], header[2]))
        print("\t\t============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_prio_to_dscp_rewrite_get(handle, port, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        dscp_p = new_sx_cos_dscp_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        rc = sx_api_cos_port_prio_to_dscp_rewrite_get(handle, port, prio_color_p, dscp_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            dscp = sx_cos_dscp_t_arr_getitem(dscp_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            print("\t\t|%15s|%5s|%4s|" % (prio_color.priority, prio_color.color, dscp))
            print("\t\t============================")
        print("")

    def prio_to_exp(self, port):
        print("\tSwitch Priority, Color and ECN to EXP Rewrite:")
        print("\t\t===============================")
        header = ["Switch Priority", "Color", "ECN", "EXP"]
        print("\t\t|%15s|%5s|%3s|%3s|" % (header[0], header[1], header[2], header[3]))
        print("\t\t===============================")
        element_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(element_cnt_p, 0)
        rc = sx_api_cos_port_prio_to_exp_rewrite_get(handle, port, None, None, None, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        element_cnt = uint32_t_p_value(element_cnt_p)
        ecn_p = new_sx_cos_ecn_t_arr(element_cnt)
        exp_p = new_sx_cos_exp_t_arr(element_cnt)
        prio_color_p = new_sx_cos_priority_color_t_arr(element_cnt)
        rc = sx_api_cos_port_prio_to_exp_rewrite_get(handle, port, prio_color_p, ecn_p, exp_p, element_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            exit(1)
        for i in range(element_cnt):
            ecn = sx_cos_ecn_t_arr_getitem(ecn_p, i)
            exp = sx_cos_exp_t_arr_getitem(exp_p, i)
            prio_color = sx_cos_priority_color_t_arr_getitem(prio_color_p, i)
            print("\t\t|%15s|%5s|%3s|%3s|" % (prio_color.priority, prio_color.color, ecn, exp))
            print("\t\t===============================")
        print("")


old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)
if len(sys.argv) >= 3:
    parser = argparse.ArgumentParser(description='QoS SDK Dump')
    parser.add_argument('--port', type=auto_int, help='Logical port')
    args = parser.parse_args()
    dump = QosDump(args.port)
else:
    print("No ports given, printing dump for all ports.")
    dump = QosDump(None)
dump.dump_all()
