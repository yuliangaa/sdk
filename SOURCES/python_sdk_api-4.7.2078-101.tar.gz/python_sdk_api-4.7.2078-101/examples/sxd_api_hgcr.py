#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from sxd_api_chip_type_rev_get import get_chip_type_and_rev


def parse_args():
    parser = argparse.ArgumentParser(description='HGCR Set/Get example.')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--tac_crawler_action', default=0, type=int, help="TAC crawler action to perform - flush_and_report(0), flush_no_report(1). Supported by SPC4.")
    parser.add_argument('--tac_crawler_timer', default=10, type=int, help="TAC crawler value to calculate period for every TAC crawler action to execute. Time=2^tac_crawler_timer msec. Supported by SPC4.")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    return args.cmd, args.tac_crawler_action, args.tac_crawler_timer, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute Set/Get request for the HGCR EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--action <tac_crawler_action>] [--timer <tac_crawler_timer>]")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. Get by default.")
    print("tac_crawler_action: crawler action - flush_and_report (0) or flush_no_report (1). 0 by default. Supported by SPC4.")
    print("tac_crawler_timer: crawler timer value to periodical flush and/no report. time=2^timer. 10 by default. Maximum value is 13. Supported by SPC4.")
    print("")


def validate_input_parameters(cmd, tac_crawler_action, tac_crawler_timer, chip_type):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)

    if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM4 or chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        if tac_crawler_action > 1:
            print("Invalid input parameter: tac_crawler_action.")
            help_cmd()
            sys.exit(0)

        if tac_crawler_timer > 13:
            print("Invalid input parameter: tac_crawler_timer.")
            help_cmd()
            sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, tac_crawler_action, tac_crawler_timer, chip_type, deinit):

    reg_data = ku_hgcr_reg()
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    reg_data.truncation_size = (16 * 1024 - 1)  # set default value from PRM 16K-1

    if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM4 or chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        reg_data.tac_crawler_action = tac_crawler_action
        reg_data.tac_crawler_timer = tac_crawler_timer

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get HGCR")
    else:
        print("[+] Set HGCR")
        print("[+] truncation_size: ", reg_data.truncation_size)

        if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM4 or chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM5:
            print("[+] tac_crawler_action: ", reg_data.tac_crawler_action)
            print("[+] tac_crawler_timer: ", reg_data.tac_crawler_timer)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        original_hgcr = ku_hgcr_reg()
        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_hgcr(original_hgcr, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_hgcr failed")
            sys.exit(rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    rc = sxd_access_reg_hgcr(reg_data, meta, 1, None, None)
    print("[+] rc: ", rc)
    print("====================")
    if rc == SXD_STATUS_SUCCESS and meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] truncation_size: ", reg_data.truncation_size)

        if chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM4 or chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM5:
            print("[+] tac_crawler_action: ", reg_data.tac_crawler_action)
            print("[+] tac_crawler_timer: ", reg_data.tac_crawler_timer)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        rc = sxd_access_reg_hgcr(original_hgcr, meta, 1, None, None)
        if (rc != SX_STATUS_SUCCESS):
            print("sxd_access_reg_hgcr failed")
            sys.exit(rc)


def main():
    cmd, tac_crawler_action, tac_crawler_timer, deinit = parse_args()

    sxd_init()

    chip_type, _ = get_chip_type_and_rev()
    if chip_type in [SXD_MGIR_HW_DEV_ID_SPECTRUM]:
        print("[+] HGCR is not supported! No need to run this example.")
        sys.exit(0)
    else:
        validate_input_parameters(cmd, tac_crawler_action, tac_crawler_timer, chip_type)
        run_example(cmd, tac_crawler_action, tac_crawler_timer, chip_type, deinit)

    print("[+] HGCR register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] HGCR register access example")
    main()
