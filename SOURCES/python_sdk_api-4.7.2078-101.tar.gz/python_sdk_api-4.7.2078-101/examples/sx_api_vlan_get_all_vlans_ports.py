#!/usr/bin/env python
"""
This file contains a example for the VLAN module.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""
import sys

from python_sdk_api.sx_api import *

rc, handle = sx_api_open(None)
print(("handle: 0x%x , rc: %d " % (handle, rc)))

port_list = new_sx_vlan_ports_t_arr(64)
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 64)
swid = 0

for vid in range(1, 4095):
    uint32_t_p_assign(port_cnt_p, 64)
    rc = sx_api_vlan_ports_get(handle, swid, vid, port_list, port_cnt_p)
    port_cnt = uint32_t_p_value(port_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("An error was found in sx_api_vlan_ports_get.\nThe example will exit")
        sys.exit(rc)
    else:
        if (port_cnt > 0):
            print("sx_api_vlan_ports_get vid:%d port_cnt:%d , rc %d, port_list :" % (vid, port_cnt, rc))
            print("VID %d: " % (vid))
            for index in range(0, port_cnt):
                sys.stdout.write("0x%x, " % sx_vlan_ports_t_arr_getitem(port_list, index).log_port)
            print("")
