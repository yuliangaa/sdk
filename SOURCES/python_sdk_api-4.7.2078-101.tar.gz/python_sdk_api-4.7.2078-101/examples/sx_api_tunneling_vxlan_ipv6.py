#!/usr/bin/env python

import os
import sys
import random
import errno
import sys
import struct
import socket
import colorsys
from python_sdk_api.sx_api import *
import test_infra_common as common_lib
import argparse

parser = argparse.ArgumentParser(description='sx_api_tunneling_vxlan_ipv6 example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

SPECTRUM_SWID = 0

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

###################################################################


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid

###################################################################


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))

###################################################################


def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))

###################################################################


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

###################################################################


def make_tunnel_attributes_vxlan_ipv6(vrid, underlay_sip, log_port, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, ttl=255):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_ttl = ttl
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.nve_log_port = log_port

    return tunnel_attribute

###################################################################


def make_tunnel_general_params(sport=0, nve_encap_flowlabel=0, flood_ecmp_enabled=False, ipinip_encap_flowlabel=0,
                               encap_gre_hash=0, fdb_resolution_valid=False,
                               fdb_resolution_action=SX_ROUTER_ACTION_FORWARD, mc_ecmp_enabled=False):
    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = sport
    general_params.nve.encap_flowlabel = nve_encap_flowlabel
    general_params.nve.flood_ecmp_enabled = flood_ecmp_enabled
    general_params.nve.mc_ecmp_enabled = mc_ecmp_enabled
    general_params.nve.fdb_resolution_valid = fdb_resolution_valid
    if fdb_resolution_valid:
        general_params.nve.fdb_resolution_action = fdb_resolution_action

    general_params.ipinip.encap_flowlabel = ipinip_encap_flowlabel
    general_params.ipinip.encap_gre_hash = encap_gre_hash

    return general_params

###################################################################


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data

###################################################################


def _ipv6_str_to_bytes(address):
    # Load the ipv6 string into 4 dwords
    dwords = struct.unpack("!IIII", socket.inet_pton(socket.AF_INET6, address))

    # Convert dwords endian using ntohl
    total_bytes = [socket.ntohl(i) for i in dwords]

    # Finally, convert back to bytes
    out = struct.pack(">IIII", total_bytes[0], total_bytes[1], total_bytes[2], total_bytes[3])
    return [i for i in out]

###################################################################


def make_sx_ip_addr_v6(addr):
    " This function creates ipv6 sx_ip_addr struct with given ip address. "
    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)
    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_addr.addr.ipv6._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
    return ip_addr

###################################################################


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    return rc

###################################################################


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    return tunnel_init(general_param_p)

###################################################################


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

###################################################################


def tunnel_create(tunnel_attribute):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return rc, tunnel_id

###################################################################


def example_vxlan_ipv6_tunnel_create_flow(vrid, log_port=common_lib.NVE_PORT, direction=SX_TUNNEL_DIRECTION_SYMMETRIC,
                                          usip="2001:0db8::7334", ttl=255):

    underlay_sip = make_sx_ip_addr_v6(usip)
    tunnel_attribute = make_tunnel_attributes_vxlan_ipv6(vrid, underlay_sip, log_port, direction, ttl)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)

###################################################################


def tunnel_destroy(tunnel_id_p):

    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    return rc

###################################################################


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    return tunnel_destroy(tunnel_id_p)

###################################################################


def bridge_create_delete(cmd, bridge_id_p):

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    return rc

##################################################################


def make_tunnel_map_entry_params(bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, vni=5):

    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni

    return map_entry

##################################################################


def tunnel_map_entry_process_ipv6(tunnel_id, bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, vni=5, delete=0):

    map_entry = make_tunnel_map_entry_params(bridge_id, tunnel_type, vni)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    if delete == 0:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)
    else:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE, tunnel_id, map_entry_p, 1)

##################################################################


def make_decap_key_ipv6(key_type, vrid, dip='2001::0370:7334',
                        sip="9988::0370:4337", tunnel_type=0):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v6(dip)
    decap_key.underlay_sip = make_sx_ip_addr_v6(sip)

    return decap_key

##################################################################


def tunnel_decap_rule_process(decap_key_p, decap_data_p, delete=0):

    if delete == 0:
        rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
        print(("sx_api_tunnel_decap_rules_set (create)  [rc = %d] " % (rc)))
    else:
        rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY, decap_key_p, decap_data_p)
        print(("sx_api_tunnel_decap_rules_set (destroy)  [rc = %d] " % (rc)))
    return rc

##################################################################


def example_decap_rules_flow(vrid, tunnel_id, delete=0):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key_ipv6(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN_IPV6)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    rc = tunnel_decap_rule_process(decap_key_p, decap_data_p, delete)
    return rc

###################################################################


def set_rif_state_ipv6(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = False
    rif_state.ipv6_enable = enable
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))

###################################################################


def add_neigh_ipv6(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    return rc

###################################################################


def delete_neigh_ipv6(rif, addr, mac_addr):
    " This function deletes neighbor from rif with given address. "

    ip_addr = make_sx_ip_addr_v6(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    return rc

###################################################################


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif

###################################################################


def delete_vlan_rif(rif, vrid):
    " This function deletes vlan rif. "

    ifc_param = sx_router_interface_param_t()
    ifc_attr = sx_interface_attributes_t()

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, ifc_param, ifc_attr, rif_p)
    return rc

###################################################################


def make_sx_ip_prefix_v6(addr, mask):
    " This function creates ipv6 sx_api_ip_prefix struct with given parametrs. "

    if isinstance(addr, str):
        addr = _ipv6_str_to_bytes(addr)

    if isinstance(mask, str):
        mask = _ipv6_str_to_bytes(mask)

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV6
    for i in range(0, 16):
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.addr._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, addr[i])
        uint8_t_arr_setitem(ip_prefix.prefix.ipv6.mask._in6_addr__in6_u._in6_addr___in6_u__u6_addr8, i, mask[i])
    return ip_prefix

###################################################################


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
        This function creates sx_uc_route_data struct for local route with given parameters.
        Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data

###################################################################


def create_local_route_ipv6(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    return rc

###################################################################


def delete_local_route_ipv6(vrid, rif, addr, mask):
    " This function deletes local route. "

    ip_prefix = make_sx_ip_prefix_v6(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, uc_route_data_p)
    return rc

###################################################################


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    return rc

###################################################################


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    return rc

###################################################################
    main
###################################################################


def main():

    router_init()
    print("Init tunnel")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to init tunnel, rc: %d" % rc

    print("Create vrid")
    vrid = create_vrid()

    print("Create IPv6 tunnel")
    rc, tunnel_id = example_vxlan_ipv6_tunnel_create_flow(vrid)
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to create tunnel, rc: %d" % rc

    # NVE port
    log_port = common_lib.NVE_PORT

    print("Get counter")
    counter = sx_tunnel_counter_t()
    cmd = SX_ACCESS_CMD_READ
    rc = sx_api_tunnel_counter_get(handle, cmd, tunnel_id, counter)
    assert rc == SX_STATUS_SUCCESS, \
        "Failed to get tunnel counter, expected rc = %d, rc: %d" % (SX_STATUS_SUCCESS, rc)

    # --------------- create bridge + mapping --------------------#
    print("Create new bridge")
    bridge_id_p = new_sx_bridge_id_t_p()
    rc = bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create a bridge, rc: %d" % rc
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)

    print("Create vport")
    log_vport_p = new_sx_port_log_id_t_p()
    vid = 1
    rc = vport_add_delete(SX_ACCESS_CMD_ADD, 0x10001, vid, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport, rc = %d" % rc
    log_vport = sx_port_log_id_t_p_value(log_vport_p)

    print("Add vport to the bridge")
    rc = bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport)
    assert SX_STATUS_SUCCESS == rc, "Failed to add vport to the bridge, rc = %d" % rc

    print("Add tunnel map entry")
    vni = 5
    rc = tunnel_map_entry_process_ipv6(tunnel_id, bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, vni)
    assert SX_STATUS_SUCCESS == rc, "Failed to add map entry, rc: %d" % (rc)

    # ----------- decap flow : add decap rule IPv6 + mapping ------#
    print("Create decap rule")
    rc = example_decap_rules_flow(vrid, tunnel_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule, rc: %d" % (rc)

    # ----------------- encap flow -------------------------------#
    # ----------- add static fdb v6 - IP_A -----------------------#
    ipv6_addr_str = "2001:0db8::7334"
    mask_str = "FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF"
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    mac_addr = ether_addr("00:02:c9:11:ad:c1")

    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac_addr

    mac_entry.fid_vid = bridge_id
    mac_entry.log_port = log_port
    mac_entry.entry_type = SX_FDB_UC_STATIC
    mac_entry.action = SX_FDB_ACTION_FORWARD
    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP

    mac_entry.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id

    ip_addr = make_sx_ip_addr_v6(ipv6_addr_str)
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_addr
    mac_entry.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD

    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry)

    print("Add static FDB entry (dest type = nexthop)")
    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, mac_list_p, data_cnt_p)
    assert SX_STATUS_SUCCESS == rc, \
        "Failed to set fdb static entry, rc: %d" % rc

    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # ----------- add local route and neigh for IP_A --------------#
    print("Create VLAN RIF")
    vlan = 4
    port_rif = create_vlan_rif(vrid, vlan, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    set_rif_state_ipv6(port_rif)

    print("Create local route IPv6 for rif = %d" % port_rif)
    create_local_route_ipv6(vrid, port_rif, ipv6_addr_str, mask_str)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route, rc: %d" % rc

    print("Add IPv6 neighbour to RIF %d" % port_rif)
    rc = add_neigh_ipv6(port_rif, ipv6_addr_str, mac_addr)
    assert SX_STATUS_SUCCESS == rc, \
        "Failed to add neigh to rif %d, rc = %d" % (rif, rc)

    # ----------- add flood entry ---------------------------------#
    " Create next_hop_list with random udips "
    " Only the first next_hop_list entry uses predefined IP address "
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    mcc_attr = sx_mc_container_attributes_t()
    mcc_attr.type = SX_MC_CONTAINER_TYPE_NVE_FLOOD
    mcc_attr.fid = bridge_id
    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mcc_attr)
    count = 4
    next_hop_list = new_sx_mc_next_hop_t_arr(count)
    next_hop = sx_mc_next_hop_t()
    next_hop.type = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP

    ip_addr = make_sx_ip_addr_v6(ipv6_addr_str)
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 0, next_hop)

    for i in range(1, count):
        ip_addr = make_sx_ip_addr_v6("2001:0db8::898" + str(i))
        next_hop.data.tunnel_ip.underlay_dip = ip_addr
        next_hop.data.tunnel_ip.tunnel_id = tunnel_id
        sx_mc_next_hop_t_arr_setitem(next_hop_list, i, next_hop)

    container_id_p = new_sx_mc_container_id_t_p()

    print("Create MC container")
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, container_id_p, next_hop_list, count, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(container_id_p)
    print(("sx_api_mc_container_set id %x created with %d enties, rc: %d " % (mc_container_id, count, rc)))

    print("Add flood entry")
    rc = sx_api_fdb_flood_set(handle, SX_ACCESS_CMD_ADD, 0, bridge_id, mc_container_id)
    assert SX_STATUS_SUCCESS == rc, "Failed sx_api_fdb_flood_set to add flood entry for bridge %d, rc: %d " % (bridge_id, rc)

    if args.deinit:
        # -------------------------- clean up --------------------------#
        print("Delete flood")
        rc = sx_api_fdb_flood_set(handle, SX_ACCESS_CMD_DELETE, 0, bridge_id, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete flooding for bridge %d, rc: %d " % (bridge_id, rc)

        print("Delete MC container")
        rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, container_id_p, next_hop_list, count, mcc_attr_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to destroy MC container %d, rc: %d " % (mc_container_id, rc)

        print("Delete FDB entry")
        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete fdb static entry, rc: %d" % rc

        print("Delete tunnel map entry")
        delete = 1
        vni = 5
        rc = tunnel_map_entry_process_ipv6(tunnel_id, bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, vni, delete)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete map entry, rc: %d" % rc

        print("Delete vport from the bridge")
        rc = bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge_id, log_vport)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete vport from the bridge, rc = %d" % rc

        print("Delete bridge")
        rc = bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete a bridge, rc: %d" % rc

        print("Delete vport")
        vid = 1
        rc = vport_add_delete(SX_ACCESS_CMD_DELETE, 0x10001, vid, log_vport_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete vport, rc = %d" % rc

        print("Delete decap rule")
        delete = 1
        rc = example_decap_rules_flow(vrid, tunnel_id, delete)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule, rc: %d" % (rc)

        print("Delete tunnel")
        rc = example_tunnel_destroy_flow(tunnel_id)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete tunnel, rc: %d" % rc

        print("Delete local route")
        rc = delete_local_route_ipv6(vrid, port_rif, ipv6_addr_str, mask_str)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete local route, rc: %d" % rc

        print("Delete IPv6 neighbour")
        rc = delete_neigh_ipv6(port_rif, ipv6_addr_str, mac_addr)
        assert SX_STATUS_SUCCESS == rc, \
            "Failed to delete neigh from rif %d, rc = %d" % (port_rif, rc)

        print("Delete VLAN RIF")
        rc = delete_vlan_rif(port_rif, vrid)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete VLAN RIF %d, rc: %d" % (port_rif, rc)

        print("Delete VRID")
        delete_vrid(vrid)

        print("Deinit tunnel")
        tunnel_deinit()

        print("Deinit router")
        router_deinit()

    sx_api_close(handle)


if __name__ == "__main__":
    main()
