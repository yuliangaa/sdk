#!/usr/bin/env python
'''
This file contains Python command example for "ACL Drop Trap Monitoring" feature.
This example demonstrates the following :
a. Configuring the Global setting for enabling/disabling the ACL DROP Trap
b. Show the current status of the Trap
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This example is supported on the Spectrum family of devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
import argparse
import os

from test_infra_common import *
from python_sdk_api.sx_api import *

delimiter = '***************************************************************'


def wjh_acl_drop_trap_status(handle):
    acl_global_attr_p = new_sx_acl_global_attributes_t_p()
    rc = sx_api_acl_global_attributes_get(handle, acl_global_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_global_attributes_get failed, rc = %d" % (rc))
        sys.exit(rc)
    acl_global_attr = sx_acl_global_attributes_t_p_value(acl_global_attr_p)

    if acl_global_attr.disable_acl_drop_trap:
        print(delimiter)
        print("ACL Drop Trap Monitoring is Currently OFF")
        print(delimiter)
    else:
        print(delimiter)
        print("ACL Drop Trap Monitoring is Currently ON")
        print(delimiter)
    delete_sx_acl_global_attributes_t_p(acl_global_attr_p)

    return acl_global_attr


def wjh_acl_drop_trap_enable(handle):
    acl_global_attr = sx_acl_global_attributes_t()
    acl_global_attr.disable_acl_drop_trap = False
    rc = sx_api_acl_global_attributes_set(handle, SX_ACCESS_CMD_SET, acl_global_attr)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_global_attributes_set failed, rc = %d" % (rc))
        sys.exit(rc)
    print(delimiter)
    print("Success! ACL Drop Trap Monitoring is ON")
    print(delimiter)


def wjh_acl_drop_trap_disable(handle):
    acl_global_attr = sx_acl_global_attributes_t()
    acl_global_attr.disable_acl_drop_trap = True
    rc = sx_api_acl_global_attributes_set(handle, SX_ACCESS_CMD_SET, acl_global_attr)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_acl_global_attributes_set failed, rc = %d" % (rc))
        sys.exit(rc)

    print(delimiter)
    print("Success! ACL Drop Trap Monitoring is OFF")
    print(delimiter)


def getOptions(args):
    parser = argparse.ArgumentParser(description="WJH Global ACL Drop Trap Config Utility.")

    parser.add_argument('--mode', default='on', choices=['on', 'off'], help="Turn ON/OFF ACL Drop Monitoring Trap.")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    options = parser.parse_args()
    return options


# *********************************************
#            main                            *
# *********************************************
rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

options = getOptions(sys.argv)
print_api_example_disclaimer()

current_acl_global_attr = wjh_acl_drop_trap_status(handle)

if options.mode is not None:

    if options.mode == "on":
        wjh_acl_drop_trap_enable(handle)
    elif options.mode == "off":
        wjh_acl_drop_trap_disable(handle)

    if options.deinit:
        print("Deinit")
        rc = sx_api_acl_global_attributes_set(handle, SX_ACCESS_CMD_SET, current_acl_global_attr)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_acl_global_attributes_set failed, rc = %d" % (rc))
            sys.exit(rc)
        wjh_acl_drop_trap_status(handle)

sx_api_close(handle)
