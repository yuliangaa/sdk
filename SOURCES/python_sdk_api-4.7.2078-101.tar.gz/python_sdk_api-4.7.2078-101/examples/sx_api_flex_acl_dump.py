#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
from flex_acl_common import *


parser = argparse.ArgumentParser(description='Flex ACL dump utility.')
parser.add_argument('--log_port', default=0, type=auto_int, help='Optional Logical port ID, when provided only bindings to this port will be dumped')
parser.add_argument('--vlan', default=0, type=auto_int, help='Optional VLAN ID, when provided only bindings to this VLAN ID will be dumped')
parser.add_argument('--rif', default=0, type=auto_int, help='Optional RIF ID, when provided only bindings to this RIF will be dumped')
parser.add_argument('--group', default=0, type=auto_int, help='Optional Group ID, when provided only Group and its regions are dumped')
args = parser.parse_args()


old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')


acl_group_id_cnt, acl_id_list, prev_group_dict, next_group_dict = get_acl_groups(handle)


def dump_all():
    region_set = print_acl_groups(handle, acl_group_id_cnt, acl_id_list, prev_group_dict, next_group_dict)

    region_list = sorted(region_set)
    acl_rule_header_printed = False
    for i in range(0, len(region_list)):
        if not acl_rule_header_printed:
            print_region_rules_header()
            acl_rule_header_printed = True

        region_id = region_list[i]
        print_region_rules(handle, region_id)

    binding_map = {}
    get_all_port_lag_bindings(handle, binding_map)
    get_all_rif_bindings(handle, binding_map)
    get_all_vlan_group_bindings(handle, binding_map)

    print_acl_bindings_header()
    for key in list(binding_map.keys()):
        print_acl_binding(key, binding_map)


if len(sys.argv) == 1:
    dump_all()
    exit(0)
else:
    if args.log_port != 0:
        binding_map = {}
        get_port_lag_bindings(handle, args.log_port, binding_map)
        for acl_id in binding_map:
            if acl_id in acl_id_list:
                region_set = print_acl_groups(handle, 1, [acl_id], prev_group_dict, next_group_dict)
                region_list = sorted(region_set)
                print_region_rules_header()
                for i in range(0, len(region_list)):
                    region_id = region_list[i]
                    print_region_rules(handle, region_id)
        if len(binding_map):
            print_acl_bindings_header()
        for acl_id in binding_map:
            print_acl_binding(acl_id, binding_map)
    if args.rif != 0:
        binding_map = {}
        get_all_rif_bindings(handle, binding_map, rif_id=args.rif)
        for acl_id in binding_map:
            if acl_id in acl_id_list:
                region_set = print_acl_groups(handle, 1, [acl_id], prev_group_dict, next_group_dict)
                region_list = sorted(region_set)
                print_region_rules_header()
                for i in range(0, len(region_list)):
                    region_id = region_list[i]
                    print_region_rules(handle, region_id)
        if len(binding_map):
            print_acl_bindings_header()
        for acl_id in binding_map:
            print_acl_binding(acl_id, binding_map)
    if args.vlan != 0:
        binding_map = {}
        vlan_group = get_vlan_vlan_group(handle, args.vlan)
        if vlan_group >= 0:
            get_vlan_group_bindings(handle, vlan_group, binding_map)
            for acl_id in binding_map:
                if acl_id in acl_id_list:
                    region_set = print_acl_groups(handle, 1, [acl_id], prev_group_dict, next_group_dict)
                    region_list = sorted(region_set)
                    print_region_rules_header()
                    for i in range(0, len(region_list)):
                        region_id = region_list[i]
                        print_region_rules(handle, region_id)
            if len(binding_map):
                print_acl_bindings_header()
            for acl_id in binding_map:
                print_acl_binding(acl_id, binding_map)
    if args.group != 0:
        region_set = print_acl_groups(handle, 1, [args.group], prev_group_dict, next_group_dict)
        region_list = sorted(region_set)
        print_region_rules_header()
        for i in range(0, len(region_list)):
            region_id = region_list[i]
            print_region_rules(handle, region_id)
