#!/usr/bin/env python
'''
This is an example how to unbind/bind a port.

'''
import colorsys
import errno
import sys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_swid_bind_set')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
log_port = 0x10001
swid = 0

######################################################
#    examples
######################################################


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def get_orig_swid():
    original_swid_p = new_sx_swid_t_p()
    rc = sx_api_port_swid_bind_get(handle, log_port, original_swid_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_port_swid_bind_get failed, rc = %d" % rc
    original_swid = sx_swid_t_p_value(original_swid_p)
    return original_swid


def example_port_swid_bind():
    if args.deinit:
        orig_swid = get_orig_swid()

    rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    rc = sx_api_port_swid_bind_set(handle, log_port, SX_SWID_ID_DISABLED)
    print(("sx_api_port_swid_bind_set unbind port 0x%x, rc=%d" % (log_port, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    rc = sx_api_port_swid_bind_set(handle, log_port, swid)
    print(("sx_api_port_swid_bind_set bind port 0x%x to swid: %d, rc=%d" % (log_port, swid, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    if args.deinit:
        if orig_swid != swid:
            rc = sx_api_port_swid_bind_set(handle, log_port, orig_swid)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_port_swid_bind_set failed. port 0x%x to swid: %d, rc=%d" % (log_port, original_swid, rc)))
                sys.exit(rc)

        rc = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_UP)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_setfailed [rc=%d] " % (rc)))
            sys.exit(rc)

        add_ports_to_vlan(1, {log_port: SX_UNTAGGED_MEMBER})
        rc = sx_api_rstp_port_state_set(handle, log_port, SX_MSTP_INST_PORT_STATE_FORWARDING)
        assert rc == SX_STATUS_SUCCESS, "sx_api_rstp_port_state_set failed, rc = %d" % rc

    sx_api_close(handle)

    return

######################################################
#    main
######################################################


def main():
    example_port_swid_bind()


if __name__ == "__main__":
    main()
