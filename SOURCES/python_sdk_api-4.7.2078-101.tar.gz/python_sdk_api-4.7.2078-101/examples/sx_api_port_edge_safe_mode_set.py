#!/usr/bin/env python
'''
This is an example how to enable and disable Edge Safe Mode on a Port.
    1. First we get the VLANs configured on the port
    2. We then delete those VLANs
    3. Then set the Acceptable Frame Types to drop ALL Packet Types
    4. From a host send a couple of packets to this port.
    5. Read the PPCNT register for the Counters and display them. Verify the counts match
    6. Clean up - revert the configuration.

'''

import errno
import sys
import colorsys
import time
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_edge_safe_mode_set')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()


def get_port_vlan_membership(port):
    '''
    returns the vlans that the given port is a member of
    @param port: The port to check
    @return: vlan_list - list of vlans that the port belongs to
    '''
    port_list = new_sx_vlan_ports_t_arr(64)
    port_cnt_p = new_uint32_t_p()
    swid = 0
    vlan_list = []
    for vid in range(1, 4094):
        uint32_t_p_assign(port_cnt_p, 64)
        rc = sx_api_vlan_ports_get(handle, swid, vid, port_list, port_cnt_p)
        port_cnt = uint32_t_p_value(port_cnt_p)
        if (rc != 0):
            print("An error was found in sx_api_vlan_ports_get.\nThe example will exit")
            sys.exit(rc)

        if (port_cnt > 0):
            temp_list = []
            for index in range(0, port_cnt):
                temp_list.append(sx_vlan_ports_t_arr_getitem(port_list, index).log_port)

            if port in temp_list:
                print(("This Port is a member of vlan %d. save it" % vid))
                vlan_list.append(vid)

    return vlan_list


def set_acceptable_frame_types_for_port(handle, log_port, allow_tagged,
                                        allow_untagged, allow_prio_tagged):
    """
    Configure port to accept or not to accept frame types, based on their tagging
    :param handle:
    :param log_port:
    :param allow_tagged: True to allow vlan tagged frame types on the port
    :param allow_untagged: True to allow untagged frame types on the port
    :param allow_priotagged: True to allow prio tagged frame types on the port
    """

    print(("Setting accepted frame types on port: "
           "%x, allow_untagged = %d, allow_prio_tagged = %d , allow_tagged =%d"
           % (log_port, int(allow_untagged), int(allow_prio_tagged), int(allow_tagged))))

    accptd_frame_type = sx_vlan_frame_types_t()
    accptd_frame_type.allow_untagged = int(allow_untagged)
    accptd_frame_type.allow_priotagged = int(allow_prio_tagged)
    accptd_frame_type.allow_tagged = int(allow_tagged)

    rc = sx_api_vlan_port_accptd_frm_types_set(handle, log_port, accptd_frame_type)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_vlan_port_accptd_frm_types_set failed RC=[%d]" % rc))
        sys.exit(rc)


def disp_port_ethernet_discard_counters(handle, log_port, cmd=SX_ACCESS_CMD_READ):
    eth_discard_cntr_p = new_sx_port_cntr_discard_t_p()

    rc = sx_api_port_counter_discard_get(handle, cmd, log_port, eth_discard_cntr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_counter_discard_get failed %s" % (rc)))
        sys.exit(rc)

    eth_discard_counter = sx_port_cntr_discard_t_p_value(eth_discard_cntr_p)
    print(("\r\n\r\nPort: %s\r\n\tIng Gen: %d\r\n\tIng Pol Eng: %d"
           "\r\n\tIng Vlan mbr: %d\r\n\tIng Acc Fr Typ: %d   <---\r\n\tEgr vlan mbr: %d"
           "\r\n\tLpbk Filt: %d\r\n\tEgr Gen: %d\r\n\tHLL Drop: %d"
           "\r\n\tport isol: %d\r\n\tEgr pol eng: %d\r\n\tIn lnk dn: %d\r\n\tEgr STP Filt: %d"
           "\r\n\tEgr HOQ Stall: %d\r\n\tSLL Drops: %d\r\n\tIngress discards all: %d\n"
           % (hex(log_port),
              eth_discard_counter.ingress_general,
              eth_discard_counter.ingress_policy_engine,
              eth_discard_counter.ingress_vlan_membership,
              eth_discard_counter.ingress_tag_frame_type,
              eth_discard_counter.egress_vlan_membership,
              eth_discard_counter.loopback_filter,
              eth_discard_counter.egress_general,
              eth_discard_counter.egress_hoq,
              eth_discard_counter.port_isolation,
              eth_discard_counter.egress_policy_engine,
              eth_discard_counter.ingress_tx_link_down,
              eth_discard_counter.egress_stp_filter,
              eth_discard_counter.egress_hoq_stall,
              eth_discard_counter.egress_sll,
              eth_discard_counter.ingress_discard_all)))

    return eth_discard_counter


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
log_port = port_list[0]

# log_port = 0x10001
vlan_port_p = new_sx_vlan_ports_t_p()
vlan_port = sx_vlan_ports_t()
vlan_port.log_port = log_port
vlan_port.is_tagged = SX_UNTAGGED_MEMBER
sx_vlan_ports_t_p_assign(vlan_port_p, vlan_port)
print(("Enabling Edge Safe Mode on Port %8x " % (log_port)))

# first get all VLANs that the port is a member of
port_vlan_list = get_port_vlan_membership(log_port)
vlan_count = len(port_vlan_list)
if vlan_count > 0:
    # set the VLAN membership to none by deleting all vlans from the port
    for vid in port_vlan_list:
        print(("deleting vid %d from port" % vid))
        rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, 0, vid, vlan_port_p, 1)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_vlan_ports_set failed to delete ports from vlan. RC =%d" % rc))
            sys.exit(rc)

# set the acceptable frame types to allow no packet
set_acceptable_frame_types_for_port(handle, log_port, False, False, False)
print("Clearing discard counters")
disp_port_ethernet_discard_counters(handle, log_port, cmd=SX_ACCESS_CMD_READ_CLEAR)

print("At this point - User may send some packets - they will be dropped\n"
      "Since this is an example, we don't wait for this to occur. User can add sleep based on need")

# Let us dump the PPCNT counters
print("read the discard counters. Check if any match")
disp_port_ethernet_discard_counters(handle, log_port)

if args.deinit:
    print("Clean up")
    set_acceptable_frame_types_for_port(handle, log_port, True, True, True)

    vlan_port.log_port = log_port
    vlan_port.is_untagged = SX_UNTAGGED_MEMBER
    sx_vlan_ports_t_p_assign(vlan_port_p, vlan_port)

    for vid in port_vlan_list:
        rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, vid, vlan_port_p, 1)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_vlan_ports_set failed to add ports to vlan. RC =%d" % rc))
            sys.exit(rc)

sx_api_close(handle)
