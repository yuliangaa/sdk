#!/usr/bin/env python
'''
This example gets ARN port counters.
'''

import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
p_ip_miss
    """

    description_str = """
    This example gets the ARN configuration and counters .
    Note: To run the script AR and ARN shaould be initialized.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument('--vrid', type=int, help='Virtual Router ID', default=0)
    parser.add_argument('--profile_id', type=int, help='AR profile ID', default=1)
    return parser.parse_args()


def int_to_ip(int_ip):
    packed_ip = struct.pack('!I', int_ip)
    string_ip = socket.inet_ntoa(packed_ip)
    return string_ip


def main():
    args = parse_args()     # Parse given arguments

    print("[+] Opening SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("This example doesn't support Spectrum1 - Exiting gracefully")
            sys.exit(0)

        module_verbosity_level_p = new_sx_verbosity_level_t_p()
        api_verbosity_level_p = new_sx_verbosity_level_t_p()

        rc = sx_api_ar_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to retrieve the router current verbosity setting!")
            sys.exit(rc)

        orig_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
        orig_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

        rc = sx_api_ar_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
        if rc != SX_STATUS_SUCCESS:
            print("Fail to set router log verbosity level")
            sys.exit(rc)

        # Get ARN general parameters
        general_params_p = new_sx_arn_general_params_t_p()
        try:
            rc = sx_api_ar_arn_get(handle, general_params_p)
            if rc != SX_STATUS_SUCCESS:
                if rc == SX_STATUS_MODULE_UNINITIALIZED:
                    print("AR is not initialized. Dump is not available.")
                    rc = 0
                else:
                    print("Failed to get ARN general params , rc = {}".format(test_infra_common.sx_status_dict[rc]))
            # Anyway exit example
                sys.exit(rc)
        finally:
            rc = sx_api_ar_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_module_level, orig_api_level)
            if rc != SX_STATUS_SUCCESS:
                print("Fail to set router log verbosity level")
                sys.exit(rc)

        general_params = sx_arn_general_params_t()
        general_params = sx_arn_general_params_t_p_value(general_params_p)
        print(" ARN general params ")
        print(" ===================")
        print(" Switch ID (for debug) = {}".format(general_params.switch_id))
        print(" Grade threshold = {}".format(general_params.grade_threshold))
        print(" Source IP address of ARN packets = {} ".format(int_to_ip(general_params.source_ip.addr.ipv4.s_addr)))
        print(" Qos profile used for ARN generation = {}".format(general_params.profile_id))
        print("")

        # Get ARN default parameters
        defaults_p = new_sx_arn_default_params_t_p()
        rc = sx_api_ar_arn_defaults_get(handle, defaults_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get ARN default params , rc = {}".format(test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        defaults = sx_arn_default_params_t()
        defaults = sx_arn_default_params_t_p_value(defaults_p)
        print(" ARN default params ")
        print(" ================== ")
        print(" UDP source port of ARN packet = {} ".format(defaults.udp_src_port))
        print(" UDP dest port of ARN packet = {} ".format(defaults.udp_dest_port))
        print(" ARN version (for debug ) = {} ".format(defaults.arn_version))
        print(" ARN generation UC route source IP lookup match type = {} ".format(defaults.sip_prefix_match_type))
        print(" Minimum time between consecutive ARN packets generated = {} ".format(defaults.gen_shaper_min_time))
        print(" Enables truncation when packet encapsulater in ARN = {}".format(defaults.truncate))
        print(" Trancation size = {}".format(defaults.truncate_size))
        print("")

        # Get AR profile config : SX_AR_PROFILE_0_E/SX_AR_PROFILE_1_E

        profile_attr_p = new_sx_arn_profile_attr_t_p()
        profile_key_p = new_sx_ar_profile_key_t_p()
        profile_key = sx_ar_profile_key_t()
        profile_key.profile = args.profile_id
        sx_ar_profile_key_t_p_assign(profile_key_p, profile_key)
        rc = sx_api_ar_arn_profile_get(handle, profile_key_p, profile_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get AR profile attributes , rc = {}".format(test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        profile_attr = sx_arn_profile_attr_t()
        profile_attr = sx_arn_profile_attr_t_p_value(profile_attr_p)
        print(" AR profile attributes")
        print(" =====================")
        print(" AR profile = {}".format(profile_key.profile))
        print(" ARN enable = {}".format(profile_attr.arn_enable))
        print(" Only Elepahnt = {}".format(profile_attr.only_elephant_enable))
        print(" ARN penalty = {}".format(profile_attr.arn_penalty))
        print(" ARN Aging time = {}".format(profile_attr.arn_aging_time))
        print(" ARN hold time = {}".format(profile_attr.arn_hold_time))
        print("")

        # Get ARN RIFS
        router_key_p = new_sx_arn_router_key_t_p()
        router_key = sx_arn_router_key_t()
        router_key.vrid = args.vrid
        sx_arn_router_key_t_p_assign(router_key_p, router_key)
        router_attr_p = new_sx_arn_router_attributes_t_p()
        rc = sx_api_ar_arn_router_gen_get(handle, router_key_p, router_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get ARN generation router attributes for VRID = {} , rc = {}".format(args.vrid, test_infra_common.sx_status_dict[rc]))

        router_attr = sx_arn_router_attributes_t()
        router_attr = sx_arn_router_attributes_t_p_value(router_attr_p)
        print(" ARN generation router attributes for VRID {} " .format(args.vrid))
        print(" =============================================")
        print(" ARN ingress RIF = {}".format(router_attr.irif))
        print(" ARN egress RIF = {}".format(router_attr.erif))
        print("")

        # Get global counters
        counters_p = new_sx_arn_counters_t_p()
        rc = sx_api_ar_arn_counters_get(handle, SX_ACCESS_CMD_READ, counters_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to get ARN counters , rc = {}".format(test_infra_common.sx_status_dict[rc]))
            sys.exit(rc)
        counters = sx_arn_counters_t()
        counters = sx_arn_counters_t_p_value(counters_p)
        print(" ARN global counters ")
        print(" ====================")
        print(" Drop no Next Hop = {}".format(counters.gen_drop_no_nexthop))
        print(" Drop IP miss  = {}".format(counters.gen_drop_ip_miss))
        print(" Receive Drop = {}".format(counters.arn_rcv_drop))
        print(" Received OK = {}".format(counters.arn_rcv_ok))
        print("")

        # Get port list
        print("Retrieving port list")
        port_list = mapPortAndInterfaces(handle)

        # Get port counters
        failed_ports = []

        print(" ARN transmits per port ")
        print(" ========================== ")
        print(" | port    | ARN Tx count | ")
        print(" ========================== ")

        port_counter_p = new_sx_arn_port_counters_t_p()
        for port in port_list:
            rc = sx_api_ar_arn_port_counters_get(handle, SX_ACCESS_CMD_READ, port, port_counter_p)
            if rc != SX_STATUS_SUCCESS:
                failed_ports.append(port)  # Store the port number in the list of failed ports
                continue  # Skip to the next iteration if rc is not equal to SX_STATUS_SUCCESS
            counter = sx_arn_port_counters_t_p_value(port_counter_p)
            print(" | 0x%x |%13d | " % (port, counter.arn_port_tx))
            print(" =========================")
        print("")
        if failed_ports:  # Check if the list of failed ports is not empty
            print("Ports with failed counter get:", [hex(port) for port in failed_ports])

    # delete allocated resources
        delete_sx_arn_general_params_t_p(general_params_p)
        delete_sx_arn_default_params_t_p(defaults_p)
        delete_sx_arn_profile_attr_t_p(profile_attr_p)
        delete_sx_arn_router_key_t_p(router_key_p)
        delete_sx_arn_counters_t_p(counters_p)
        delete_sx_arn_port_counters_t_p(port_counter_p)
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    cmds = {0: SX_ACCESS_CMD_READ, 1: SX_ACCESS_CMD_READ_CLEAR}

    sys.exit(main())
