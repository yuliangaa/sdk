#!/usr/bin/env python
'''
This file contains Python command example that dump one or all stateful DB partitions
in the system and displays their configuration and status.
This example is supported on Spectrum4 and later devices.
'''
import sys
import os
from python_sdk_api.sx_api import *
import test_infra_common
import argparse


def parse_args():
    description_str = """
    This file contains Python command example that dump one or all stateful DB partitions
    in the system and displays their configuration and status.
    This example is supported on Spectrum4 and later devices.
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    parser.add_argument("--partition", type=int, help="Partition ID to dump")
    return parser.parse_args()


def main():
    args = parse_args()

    # Open Handle
    print("[+] opening SDK")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
            print("This example doesn't support below Spectrum4 - Exiting gracefully")
            sys.exit(0)

        # Get original verbosity
        module_verbosity_level_p = new_sx_verbosity_level_t_p()
        api_verbosity_level_p = new_sx_verbosity_level_t_p()

        rc = sx_api_stateful_db_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
        if rc != SX_STATUS_SUCCESS:
            print("Failed to retrieve the stateful DB Module current verbosity setting!")
            sys.exit(rc)

        orig_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
        orig_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

        rc = sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
        if rc != SX_STATUS_SUCCESS:
            print("Fail to set staeful DB API log verbosity level")
            sys.exit(rc)

        # If dump for specific partition: check if partition was allocated, else: get all active partitions.
        # Iter get API can fail on "module not initialized".
        partition_p = new_sx_stateful_db_partition_id_e_p()
        partition_cnt_p = new_uint32_t_p()
        if args.partition is not None:
            partition_id = args.partition
            partition_cnt = 1
        else:
            partition_id = SX_STATEFUL_DB_PARTITION_MIN_E
            partition_cnt = 0
        uint32_t_p_assign(partition_cnt_p, partition_cnt)

        rc = sx_api_stateful_db_partition_iter_get(handle, SX_ACCESS_CMD_GET, partition_id, None, partition_p, partition_cnt_p)
        if (rc != SX_STATUS_SUCCESS):
            if rc == SX_STATUS_MODULE_UNINITIALIZED:
                print("Stateful DB module is not initialized. Partition dump is not available.")
                rc = 0
            else:
                print("Failed in stateful DB iter get, rc = " + str(rc))
            # Anyway exit example
            sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_module_level, orig_api_level)
            sys.exit(rc)

        # Restore original verbosity
        sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, orig_module_level, orig_api_level)
        # Free allocated object
        delete_sx_stateful_db_partition_id_e_p(partition_p)

        partition_cnt = uint32_t_p_value(partition_cnt_p)

        # Check for active partitions
        if partition_cnt == 0:
            if args.partition is not None:
                print("Partition %d was not allocated" % args.partition)
            else:
                print("No allocated partitions")
            sys.exit(0)

        # Dump active partitions
        partition_list_p = new_sx_stateful_db_partition_id_e_arr(partition_cnt)

        if args.partition is not None:
            sx_stateful_db_partition_id_e_arr_setitem(partition_list_p, 0, partition_id)
        else:
            rc = sx_api_stateful_db_partition_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, partition_id, None, partition_list_p, partition_cnt_p)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed in stateful DB partition iter get: rc = " + str(rc))
                sys.exit(rc)

        # Print title
        if args.partition is not None:
            print("Dump for Partition %d:" % args.partition)
        else:
            print("Dump allocated partitions:")

        # Print table header
        table_format = "| {:<5} | {:<10} | {:<10} | {:<11} | {}"
        print("-" * 100)
        print(table_format.format("ID", "Max size", "Warn size", "Entries num", "Partition name"))
        print("-" * 100)
        partition_status_p = new_sx_stateful_db_partition_status_t_p()

        for i in range(partition_cnt):
            # Get partition status and print table line
            partition = sx_stateful_db_partition_id_e_arr_getitem(partition_list_p, i)
            rc = sx_api_stateful_db_partition_get(handle, SX_ACCESS_CMD_GET, partition, partition_status_p)
            if (rc != SX_STATUS_SUCCESS):
                print("Failed to get stateful DB partition ID %d status, rc = %d" % (partition, rc))
                sys.exit(rc)
            partition_status = sx_stateful_db_partition_status_t_p_value(partition_status_p)
            print(table_format.format(partition, partition_status.partition_cfg.max_size, partition_status.partition_cfg.warn_size, partition_status.num_entries, partition_status.partition_cfg.partition_name))
            print("-" * 100)

        # Free allocated object
        delete_uint32_t_p(partition_cnt_p)
        delete_sx_stateful_db_partition_id_e_p(partition_list_p)
        delete_sx_stateful_db_partition_status_t_p(partition_status_p)
        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
