#!/usr/bin/env python
import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import subprocess
import re


def get_current_issu_version():
    cmd = 'sx_sdk --vers'
    result = subprocess.check_output(cmd, shell=True)
    lines = result.split(' ')
    version_idx = lines.index("ISSU") + 1
    return lines[version_idx].rstrip()


def get_new_issu_version(sdk_path):
    packages = os.listdir(sdk_path)
    sxd = [
        x for x in packages
        if x.startswith('sxd_libs')]
    assert sxd != [], "Failed to get new ISSU version.\nPlease check new SDK path."
    word_list = re.split(r'-|\.', sxd[0])
    return word_list[len(word_list) - 3]


def get_current_isfu_version():
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        sys.exit(-1)

    mgir = ku_mgir_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    rc = sxd_access_reg_mgir(mgir, meta, 1, None, None)
    assert SX_STATUS_SUCCESS == rc
    return mgir.fw_info.isfu_major


def get_new_isfu_version(fw_path):
    cmd = 'flint -i ' + fw_path + ' q'
    result = subprocess.check_output(cmd, shell=True)
    lines = re.split('       |\n', result)
    version_idx = lines.index('FW ISSU Version:') + 1
    return int(lines[version_idx])


def parse_args():
    parser = argparse.ArgumentParser(description='ISSU example')
    subparsers = parser.add_subparsers(dest='subparser_name', help='ISSU commands, you may provide -h or --help to see the optional arguments for each command. For example, "%s start -h".' % (parser.prog))
    init_parser = subparsers.add_parser('dvs_start', help='ISSU dvs_start flow.')
    init_parser.add_argument('--boot_mode', default='ISSU_NORMAL', choices=['ISSU_NORMAL', 'ISSU_FAST', 'ISSU_STARTED'], help='The DVS boot mode in ISSU dvs_start flow, default is ISSU_NORMAL.')
    update_fw_parser = subparsers.add_parser('update_fw', help='Update the FW.')
    update_fw_parser.add_argument('--fw_version', type=str, help='The FW version to burn, e.g. 13_1805_0006.', required=True)
    start_parser = subparsers.add_parser('start', help='ISSU start flow.')
    start_parser.add_argument('--kexec', action='store_true', help='To do kexec in the ISSU start flow, if not specified, dvs_stop.sh will be executed.')
    end_parser = subparsers.add_parser('end', help='ISSU end flow.')
    batch_parser = subparsers.add_parser('batch', help='ISSU Full Flow.')
    issu_parser = subparsers.add_parser('version_check', help='check if current issu version is compatible with new sdk issu version.')
    issu_parser.add_argument('--sdk_path', type=str, help='the path to the new sdk packages', required=False, default='None')
    issu_parser.add_argument('--fw_path', type=str, help='the path to the new fw image', required=False, default='None')
    args = parser.parse_args()

    return args


def execute_command(cmd):
    rc = os.system(cmd)
    assert rc == SX_STATUS_SUCCESS, '%s failed, rc = %d' % (cmd, rc)


def issu_dvs_start_flow(args):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc == SX_STATUS_SUCCESS:
        print("SDK is already running.\n")
        sys.exit(-1)

    execute_command('dvs_start.sh --sdk_bridge_mode=HYBRID --boot_mode=%s' % args.boot_mode)


def issu_update_fw(args):
    execute_command('rm -rf /tmp/fw_burn')
    execute_command('mkdir -p /tmp/fw_burn')
    execute_command('cp /mswg/release/sx_mlnx_fw/SPC/fw-SPC-rel-%s-EVB.mfa /tmp/fw_burn/' % args.fw_version)
    execute_command('mlxfwmanager -y -d mlnxsw-255 -D /tmp/fw_burn/ -u -f')


def issu_start_flow(args):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc != SX_STATUS_SUCCESS:
        print("SDK is not running.\n")
        sys.exit(-1)

    rc, handle = sx_api_open(None)
    assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc = %d" % rc

    rc = sx_api_issu_start_set(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_iss_start_set failed, rc = %d" % rc

    rc = sx_api_close(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc = %d" % rc

    print("\nISSU start flow has been succesfully executed.\n")

    if args.kexec:
        print("\nWe are going to do kexec now.\n")
        execute_command('dvs_kexec.sh --force')
    else:
        print("\nWe are going to stop SDK now.\n")
        execute_command('dvs_stop.sh')


def issu_end_flow(args):
    rc = os.system('pidof sx_sdk > /dev/null')
    if rc != SX_STATUS_SUCCESS:
        print("SDK is not running.\n")
        sys.exit(-1)

    rc, handle = sx_api_open(None)
    assert rc == SX_STATUS_SUCCESS, "sx_api_open failed, rc = %d" % rc

    rc = sx_api_issu_end_set(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_issu_end_set failed, rc = %d" % rc

    rc = sx_api_close(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc = %d" % rc

    print("\nISSU end flow has been succesfully executed.\n")


def issu_full_flow(args):
    execute_command('dvs_stop.sh')
    args.kexec = None
    args.boot_mode = 'ISSU_FAST'
    issu_dvs_start_flow(args)
    # configuration
    issu_start_flow(args)
    args.boot_mode = 'ISSU_STARTED'
    issu_dvs_start_flow(args)
    # configuration
    issu_end_flow(args)


def issu_version_check(args):

    if args.sdk_path != 'None':
        cur_issu_ver = get_current_issu_version()
        new_issu_ver = get_new_issu_version(args.sdk_path)

        if cur_issu_ver != new_issu_ver:
            print("sdk issu versions are NOT compatible current = " + str(cur_issu_ver) + " new = " + str(new_issu_ver))
        else:
            print("sdk issu versions match version = " + str(cur_issu_ver))
    else:
        print("No SDK path given")

    if args.fw_path != 'None':
        cur_isfu_ver = get_current_isfu_version()
        new_isfu_ver = get_new_isfu_version(args.fw_path)

        if cur_isfu_ver != new_isfu_ver:
            print("fw issu versions are NOT compatible current = " + str(cur_isfu_ver) + " new = " + str(new_isfu_ver))
        else:
            print("fw issu versions match version = " + str(cur_isfu_ver))
    else:
        print("No FW path given")


def main():
    args = parse_args()
    if args.subparser_name == 'dvs_start':
        issu_dvs_start_flow(args)
    elif args.subparser_name == 'start':
        issu_start_flow(args)
    elif args.subparser_name == 'end':
        issu_end_flow(args)
    elif args.subparser_name == 'update_fw':
        issu_update_fw(args)
    elif args.subparser_name == 'batch':
        issu_full_flow(args)
    elif args.subparser_name == 'version_check':
        issu_version_check(args)
    else:
        print("Arguments error.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
