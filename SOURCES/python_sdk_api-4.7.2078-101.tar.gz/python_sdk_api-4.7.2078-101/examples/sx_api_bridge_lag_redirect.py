#!/usr/bin/env python
'''
This file contains Python command example for the Tunneling module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import os
import sys
import errno
import sys
import struct
import socket
import colorsys
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_bridge_lag_redirect example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0
from test_infra_common import *

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

ports_ingr_filter_mode = {}
######################################################
#    Functions API
######################################################


""" ############################################################################################ """


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def make_lag():
    # 2. Creates a new LAG.
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

    rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
    print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))
    return lag_id


""" ############################################################################################ """


def destroy_lag(lag_id):
    swid = 0
    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, swid, lag_id_p, None, 0)
    print("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


""" ############################################################################################ """


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


""" ############################################################################################ """


def delete_all_ports_to_vlan(vlan_id):
    " This function deletes all ports from the given vlan. "
    print("--------------- DELETE ALL PORTS FROM VLAN ------------------------------")

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE_ALL, SPECTRUM_SWID, vlan_id, None, 0)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all ports from vlan %d" % (vlan_id)


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_make_redirect_lag():
    swid = 0
    vlan1 = 1
    vlan2 = 2
    vlan3 = 3
    mac_a = "E4:1D:2D:BD:07:12"
    #mac_a = "E4:1D:2D:16:32:B2"
    mac_m = "01:00:5E:00:00:20"

    if args.deinit:
        for port in [PORT1, PORT2, PORT3, PORT4]:
            ports_ingr_filter_mode[port] = ingr_filter_get(port)

    lag_server = make_lag()
    lag_peerlink = make_lag()

    lag_server_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_server_p, lag_server)
    port2_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port2_p, PORT2)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_server_p, port2_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT2, lag_server, rc)))

    lag_peerlink_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_peerlink_p, lag_peerlink)
    port3_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port3_p, PORT3)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_peerlink_p, port3_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT1, vlan1, log_vport_p_1)
    vport_uplink1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtula port 0x%x created" % (vport_uplink1)))

    log_vport_p_2 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, lag_server, vlan1, log_vport_p_2)
    vport_lag_server1 = sx_port_log_id_t_p_value(log_vport_p_2)
    print(("virtula port 0x%x created" % (vport_lag_server1)))

    log_vport_p_3 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, lag_peerlink, vlan1, log_vport_p_3)
    vport_lag_peerlink1 = sx_port_log_id_t_p_value(log_vport_p_3)
    print(("virtula port 0x%x created" % (vport_lag_peerlink1)))
    # create bridge1
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge1 = sx_bridge_id_t_p_value(bridge_id_p)
    # add vport to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge1, vport_uplink1)
    print(("virtual port 0x%x added to bridge %d " % (vport_uplink1, bridge1)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge1, vport_lag_server1)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_server1, bridge1)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge1, vport_lag_peerlink1)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_peerlink1, bridge1)))

    port_state_set(vport_uplink1, SX_PORT_ADMIN_STATUS_UP)
    port_state_set(lag_server, SX_PORT_ADMIN_STATUS_UP)
    port_state_set(vport_lag_server1, SX_PORT_ADMIN_STATUS_UP)

    rc = sx_api_lag_port_collector_set(handle, lag_server, PORT2, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT2, lag_server, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_server, PORT2, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT2, lag_server, rc)))

    port_state_set(lag_peerlink, SX_PORT_ADMIN_STATUS_UP)
    port_state_set(vport_lag_peerlink1, SX_PORT_ADMIN_STATUS_UP)

    rc = sx_api_lag_port_collector_set(handle, lag_peerlink, PORT3, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_peerlink, PORT3, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    rc = sx_api_rstp_port_state_set(handle, lag_server, SX_MSTP_INST_PORT_STATE_FORWARDING)
    print(("sx_api_rstp_port_state_set set lag 0x%x FORWARDING, rc %d " % (lag_server, rc)))
    rc = sx_api_rstp_port_state_set(handle, lag_peerlink, SX_MSTP_INST_PORT_STATE_FORWARDING)
    print(("sx_api_rstp_port_state_set set lag 0x%x FORWARDING, rc %d " % (lag_peerlink, rc)))

    add_ports_to_vlan(vlan1, {PORT1: SX_UNTAGGED_MEMBER})
    add_ports_to_vlan(vlan1, {lag_server: SX_UNTAGGED_MEMBER})
    add_ports_to_vlan(vlan1, {lag_peerlink: SX_UNTAGGED_MEMBER})

    # add fdb uc
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    mac_addr = ether_addr(mac_a)
    mac_entry1 = sx_fdb_uc_mac_addr_params_t()
    mac_entry1.mac_addr = mac_addr
    mac_entry1.fid_vid = bridge1          # Filtering Identifier, VID for static MAC
    mac_entry1.log_port = vport_lag_server1
    mac_entry1.entry_type = SX_FDB_UC_STATIC
    mac_entry1.action = SX_FDB_ACTION_FORWARD
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # add fdb mc
    group_addr = ether_addr(mac_m)
    vport_lag_server1_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(vport_lag_server1_p, vport_lag_server1)

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, swid, bridge1, group_addr, None, 0)
    print(("sx_api_fdb_mc_mac_addr_set added mc group, rc: %d " % (rc)))

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD_PORTS, swid, bridge1, group_addr, vport_lag_server1_p, 1)
    print(("sx_api_fdb_mc_mac_addr_set added 1 port, rc: %d " % (rc)))

    # Create redirect
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag_server, lag_peerlink)
    print(("sx_api_lag_redirect_set, rc: %d " % (rc)))

    # Now traffic is redirected in bridge1

    # add vport with different vlan to bridge1
    vport4_3_p = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT4, vlan3, vport4_3_p)
    vport4_3 = sx_port_log_id_t_p_value(vport4_3_p)
    print(("virtula port 0x%x created" % (vport4_3)))

    # create bridge2, add redirected lag to a new bridge2
    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT1, vlan2, log_vport_p_1)
    vport_uplink2 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtula port 0x%x created" % (vport_uplink2)))

    log_vport_p_2 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, lag_server, vlan2, log_vport_p_2)
    vport_lag_server2 = sx_port_log_id_t_p_value(log_vport_p_2)
    print(("virtula port 0x%x created" % (vport_lag_server2)))

    log_vport_p_3 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, lag_peerlink, vlan2, log_vport_p_3)
    vport_lag_peerlink2 = sx_port_log_id_t_p_value(log_vport_p_3)
    print(("virtula port 0x%x created" % (vport_lag_peerlink2)))

    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge2 = sx_bridge_id_t_p_value(bridge_id_p)

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport_uplink2)
    print(("virtual port 0x%x added to bridge %d " % (vport_uplink2, bridge1)))

    # add redirect lag to bridge2 and then add redirected lag
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport_lag_peerlink2)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_peerlink2, bridge2)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport_lag_server2)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_server2, bridge2)))

    port_state_set(vport_uplink2, SX_PORT_ADMIN_STATUS_UP)
    port_state_set(vport_lag_server2, SX_PORT_ADMIN_STATUS_UP)
    port_state_set(vport_lag_peerlink2, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan2, {PORT1: SX_UNTAGGED_MEMBER})
    add_ports_to_vlan(vlan2, {lag_server: SX_UNTAGGED_MEMBER})
    add_ports_to_vlan(vlan2, {lag_peerlink: SX_UNTAGGED_MEMBER})

    # add fdb uc
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    mac_addr = ether_addr(mac_a)
    mac_entry2 = sx_fdb_uc_mac_addr_params_t()
    mac_entry2.mac_addr = mac_addr
    mac_entry2.fid_vid = bridge2          # Filtering Identifier, VID for static MAC
    mac_entry2.log_port = vport_lag_server2
    mac_entry2.entry_type = SX_FDB_UC_STATIC
    mac_entry2.action = SX_FDB_ACTION_FORWARD
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry2)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # add fdb mc
    group_addr = ether_addr(mac_m)
    vport_lag_server2_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(vport_lag_server2_p, vport_lag_server2)

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, swid, bridge2, group_addr, None, 0)
    print(("sx_api_fdb_mc_mac_addr_set added mc group, rc: %d " % (rc)))

    rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_ADD_PORTS, swid, bridge2, group_addr, vport_lag_server2_p, 1)
    print(("sx_api_fdb_mc_mac_addr_set added 1 port, rc: %d " % (rc)))
    # Now traffic is also redirected in bridge2

    # Destroy the redirect lag
    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag_server, lag_peerlink)
    assert SX_STATUS_SUCCESS == rc, "sx_api_lag_redirect_set  [rc=%d] " % (rc)
    print(("sx_api_lag_redirect_set  [rc=%d] " % (rc)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport4_3)
    print(("virtual port 0x%x added to bridge %d " % (vport4_3, bridge2)))

    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport4_3)
    print(("virtual port 0x%x deleted from bridge %d " % (vport4_3, bridge2)))

    vport_add_delete(SX_ACCESS_CMD_DELETE, PORT4, vlan3, vport4_3_p)
    print(("virtual port 0x%x deleted" % (vport4_3)))

    # Create redirect where the redirect lag is not in the bridge
    port_state_set(vport_lag_peerlink2, SX_PORT_ADMIN_STATUS_DOWN)
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport_lag_peerlink2)
    print(("virtual port 0x%x deleted from bridge %d " % (vport_lag_peerlink2, bridge2)))
    port_state_set(vport_lag_peerlink2, SX_PORT_ADMIN_STATUS_UP)

    # Create redirect where the redirected lag is not in the bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport_lag_peerlink2)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_peerlink2, bridge2)))

    port_state_set(vport_lag_server2, SX_PORT_ADMIN_STATUS_DOWN)
    bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport_lag_server2)
    print(("virtual port 0x%x deleted from bridge %d " % (vport_lag_server2, bridge2)))

    rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_CREATE, lag_server, lag_peerlink)
    assert SX_STATUS_SUCCESS == rc, "sx_api_lag_redirect_set  [rc=%d] " % (rc)
    print(("sx_api_lag_redirect_set  [rc=%d] " % (rc)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport_lag_server2)
    print(("virtual port 0x%x added to bridge %d " % (vport_lag_server2, bridge2)))

    # Now traffic is redirected on bridge2 again

    port4_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(port4_p, PORT4)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_peerlink_p, port4_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT4, lag_peerlink, rc)))

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_peerlink_p, port3_p, 1)
    print(("sx_api_lag_port_group_set DELETE port 0x%x from lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_server_p, port3_p, 1)
    print(("sx_api_lag_port_group_set ADD port 0x%x to lag 0x%x , rc %d " % (PORT3, lag_server, rc)))

    rc = sx_api_lag_port_collector_set(handle, lag_peerlink, PORT4, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT4, lag_peerlink, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_peerlink, PORT4, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT4, lag_peerlink, rc)))

    rc = sx_api_lag_port_collector_set(handle, lag_server, PORT3, COLLECTOR_ENABLE)
    print(("sx_api_lag_port_collector_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))
    rc = sx_api_lag_port_distributor_set(handle, lag_server, PORT3, DISTRIBUTOR_ENABLE)
    print(("sx_api_lag_port_distributor_set enable port 0x%x in lag 0x%x , rc %d " % (PORT3, lag_peerlink, rc)))

    # Now traffic is got in PORT4, not in PORT3 and PORT2

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_server_p, port2_p, 1)
    print(("sx_api_lag_port_group_set DELETE port 0x%x from lag 0x%x , rc %d " % (PORT2, lag_server, rc)))

    vport2_2_p = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, PORT2, vlan2, vport2_2_p)
    vport2_2 = sx_port_log_id_t_p_value(vport2_2_p)
    print(("virtula port 0x%x created" % (vport2_2)))

    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge2, vport2_2)
    print(("virtual port 0x%x added to bridge %d " % (vport2_2, bridge2)))

    port_state_set(vport2_2, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan2, {PORT2: SX_UNTAGGED_MEMBER})

    # Now BC and flood traffic in bridge2 are in PORT2

    if args.deinit:
        print("Deinit")

        port_state_set(vport2_2, SX_PORT_ADMIN_STATUS_DOWN)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport2_2)

        vport_add_delete(SX_ACCESS_CMD_DELETE, PORT2, vlan2, vport2_2_p)

        rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_server_p, port3_p, 1)
        assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed; rc=%d" % (rc)

        rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_peerlink_p, port4_p, 1)
        assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_group_set failed; rc=%d" % (rc)

        rc = sx_api_lag_redirect_set(handle, SX_ACCESS_CMD_DESTROY, lag_server, lag_peerlink)
        assert rc == SX_STATUS_SUCCESS, "sx_api_lag_redirect_set failed; rc=%d" % (rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE_PORTS, swid, bridge2, group_addr, vport_lag_server2_p, 1)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_mc_mac_addr_set failed; rc=%d" % (rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, swid, bridge2, group_addr, None, 0)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_mc_mac_addr_set failed; rc=%d" % (rc)

        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry2)
        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_set failed; rc=%d" % (rc)

        port_state_set(vport_uplink2, SX_PORT_ADMIN_STATUS_DOWN)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport_uplink2)

        port_state_set(vport_lag_server2, SX_PORT_ADMIN_STATUS_DOWN)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport_lag_server2)

        port_state_set(vport_lag_peerlink2, SX_PORT_ADMIN_STATUS_DOWN)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge2, vport_lag_peerlink2)

        bridge_id_p = new_sx_bridge_id_t_p()
        sx_bridge_id_t_p_assign(bridge_id_p, bridge2)
        bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)

        log_vport_p_3 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_3, vport_lag_peerlink2)
        vport_add_delete(SX_ACCESS_CMD_DELETE, lag_peerlink, vlan2, log_vport_p_3)

        log_vport_p_2 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_2, vport_lag_server2)
        vport_add_delete(SX_ACCESS_CMD_DELETE, lag_server, vlan2, log_vport_p_2)

        log_vport_p_1 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_1, vport_uplink2)
        vport_add_delete(SX_ACCESS_CMD_DELETE, PORT1, vlan2, log_vport_p_1)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE_PORTS, swid, bridge1, group_addr, vport_lag_server1_p, 1)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_mc_mac_addr_set failed; rc=%d" % (rc)

        rc = sx_api_fdb_mc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, swid, bridge1, group_addr, None, 0)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_mc_mac_addr_set failed; rc=%d" % (rc)

        sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)
        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_set failed; rc=%d" % (rc)

        port_state_set(vport_lag_peerlink1, SX_PORT_ADMIN_STATUS_DOWN)
        port_state_set(vport_lag_server1, SX_PORT_ADMIN_STATUS_DOWN)
        port_state_set(vport_uplink1, SX_PORT_ADMIN_STATUS_DOWN)

        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge1, vport_lag_peerlink1)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge1, vport_lag_server1)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE, bridge1, vport_uplink1)

        bridge_id_p = new_sx_bridge_id_t_p()
        sx_bridge_id_t_p_assign(bridge_id_p, bridge1)
        bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)

        log_vport_p_3 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_3, vport_lag_peerlink1)
        vport_add_delete(SX_ACCESS_CMD_DELETE, lag_peerlink, vlan1, log_vport_p_3)

        log_vport_p_2 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_2, vport_lag_server1)
        vport_add_delete(SX_ACCESS_CMD_DELETE, lag_server, vlan1, log_vport_p_2)

        log_vport_p_1 = new_sx_port_log_id_t_p()
        sx_port_log_id_t_p_assign(log_vport_p_1, vport_uplink1)
        vport_add_delete(SX_ACCESS_CMD_DELETE, PORT1, vlan1, log_vport_p_1)

        destroy_lag(lag_peerlink)
        destroy_lag(lag_server)

        # Ports 3-4 added to vlan2 implicitly as part of lag which is member of this vlan
        remove_ports_from_vlan(vlan2, {port: SX_UNTAGGED_MEMBER for port in [PORT1, PORT2, PORT3, PORT4]})

        for port, ingr_filter in list(ports_ingr_filter_mode.items()):
            add_ports_to_vlan(vlan1, {port: SX_UNTAGGED_MEMBER})
            ingr_filter_set(port, ingr_filter)


def main():
    example_make_redirect_lag()
    sx_api_close(handle)


if __name__ == "__main__":
    main()
