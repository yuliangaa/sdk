#!/usr/bin/env python
"""
Note: sx_api_acl_hash_signature_set.py example is supported by SPC4 only

This file contains a python commands example for the TELE HASH Signature APIs.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configuration operations:
1. create GP REG 4
2. set ext_point for GP REG 4 to be SX_EXTRACTION_POINT_TYPE_HASH_SIG0_E
3. create ACL with 2 actions:
    1. TRAP with trap 467 and preserve user_id
    2. ALU load from GP REG to CQE.user_id[0..15]
4. configure trap 467 to be sent to netdev
5. Get and store default HASH Signature configuration of USER profile
6. Set new classifier and hash configuration of USER profile
7. Get and store default HASH Signature configuration of Default profile
8. Set new hash configuration of Default profile
9. In case deinit is enabled , restore USER and DEFAULT profile configuration to saved defaults
"""

import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

MY_TRAP_ID = 467
MY_TRAP_GROUP = 0
direction = 0
group_list = []
acl_list = []
region_list = []
key_handle_list = []


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_hash_signature_set example')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    return parser.parse_args()


def tele_init(handle):
    " This function init tele. "

    tele_param_p = new_sx_tele_init_params_t_p()


def tele_init(handle):
    " This function init tele. "

    tele_param_p = new_sx_tele_init_params_t_p()

    rc = sx_api_tele_init_set(handle, tele_param_p)
    assert SX_STATUS_SUCCESS == rc, "tele init failed rc: %d" % (rc)
    print("sx_api_tele_init_set rc: %d " % (rc))


def tele_deinit(handle):
    " This function deinit tele. "

    rc = sx_api_tele_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "tele deinit failed rc %d" % (rc)
    print("sx_api_tele_deinit_set rc: %d " % (rc))


def get_hash_sig_default_prof(handle):
    hash_sig_classifier_p = new_sx_tele_hash_sig_classifier_attr_t_p()
    hash_sig_params_p = new_sx_tele_hash_sig_params_t_p()
    hash_field_enable_list_cnt_p = new_uint32_t_p()
    hash_field_list_cnt_p = new_uint32_t_p()

    rc = sx_api_tele_hash_sig_default_prof_get(handle,
                                               hash_sig_params_p, None, hash_field_enable_list_cnt_p, None, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_params_get failed, rc = %d" % (rc)

    field_enable_cnt = uint32_t_p_value(hash_field_enable_list_cnt_p)
    field_cnt = uint32_t_p_value(hash_field_list_cnt_p)

    # Get actual values based on count
    hash_field_list_p = new_sx_tele_hash_sig_field_t_arr(field_cnt)
    hash_field_enable_list_p = new_sx_tele_hash_sig_field_enable_t_arr(field_enable_cnt)

    rc = sx_api_tele_hash_sig_default_prof_get(handle,
                                               hash_sig_params_p,
                                               hash_field_enable_list_p, hash_field_enable_list_cnt_p,
                                               hash_field_list_p, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_params_get failed, rc = %d" % (rc)

    return hash_sig_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt


def set_hash_sig_default_prof(handle, cmd):

    hash_field_en_set_arr = new_sx_tele_hash_sig_field_enable_t_arr(2)
    hash_field_set_arr = new_sx_tele_hash_sig_field_t_arr(4)
    num_hdr_enables_cnt = 2
    num_fields_cnt = 4

    if cmd == SX_ACCESS_CMD_SET:
        hash_sig_classifier_p = new_sx_tele_hash_sig_classifier_attr_t_p()
        hash_type_params = sx_tele_hash_sig_params_t()
        hash_type_params_p = new_sx_tele_hash_sig_params_t_p()

        hash_type_params.symmetric_hash_outer = True
        hash_type_params.symmetric_hash_inner = True
        hash_type_params.symmetric_hash_gp_reg = False
        sx_tele_hash_sig_params_t_p_assign(hash_type_params_p, hash_type_params)
    else:
        hash_sig_classifier_p = None
        hash_type_params_p = None

    if cmd == SX_ACCESS_CMD_SET or cmd == SX_ACCESS_CMD_DELETE:
        sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 0,
                                                    SX_TELE_HASH_SIG_FIELD_ENABLE_INNER_L2_IPV4)
        sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 1,
                                                    SX_TELE_HASH_SIG_FIELD_ENABLE_INNER_IPV4_NON_TCP_UDP)

        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 0, SX_TELE_HASH_SIG_OUTER_IPV4_DIP_BYTE_0)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 1, SX_TELE_HASH_SIG_OUTER_IPV4_DIP_BYTE_1)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 2, SX_TELE_HASH_SIG_OUTER_IPV4_DIP_BYTE_2)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 3, SX_TELE_HASH_SIG_OUTER_IPV4_DIP_BYTE_3)

    if cmd == SX_ACCESS_CMD_ADD:
        sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 0,
                                                    SX_TELE_HASH_SIG_FIELD_ENABLE_OUTER_L2_IPV4)
        sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 1,
                                                    SX_TELE_HASH_SIG_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP)

        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 0, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_0)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 1, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_1)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 2, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_2)
        sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 3, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_3)

    rc = sx_api_tele_hash_sig_default_prof_set(handle, cmd,
                                               hash_type_params_p,
                                               hash_field_en_set_arr, num_hdr_enables_cnt,
                                               hash_field_set_arr, num_fields_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_flow_params_set failed, rc = %d" % (rc)


def get_hash_sig_user_prof(handle, prof_id):
    hash_sig_classifier_p = new_sx_tele_hash_sig_classifier_attr_t_p()
    hash_sig_params_p = new_sx_tele_hash_sig_params_t_p()
    hash_field_enable_list_cnt_p = new_uint32_t_p()
    hash_field_list_cnt_p = new_uint32_t_p()

    hash_sig_prof_idx_p = new_sx_tele_hash_sig_prof_t_p()
    hash_sig_prof_idx_p.prof_index = prof_id

    rc = sx_api_tele_hash_sig_prof_get(handle, hash_sig_prof_idx_p,
                                       hash_sig_classifier_p, hash_sig_params_p, None, hash_field_enable_list_cnt_p, None, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_params_get failed, rc = %d" % (rc)

    field_enable_cnt = uint32_t_p_value(hash_field_enable_list_cnt_p)
    field_cnt = uint32_t_p_value(hash_field_list_cnt_p)

    # Get actual values based on count
    hash_field_list_p = new_sx_tele_hash_sig_field_t_arr(field_cnt)
    hash_field_enable_list_p = new_sx_tele_hash_sig_field_enable_t_arr(field_enable_cnt)

    rc = sx_api_tele_hash_sig_prof_get(handle, hash_sig_prof_idx_p,
                                       hash_sig_classifier_p, hash_sig_params_p,
                                       hash_field_enable_list_p, hash_field_enable_list_cnt_p,
                                       hash_field_list_p, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_params_get failed, rc = %d" % (rc)

    return hash_sig_classifier_p, hash_sig_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt


def set_hash_sig_user_prof(handle, prof_id, cmd):
    hash_sig_classifier_p = new_sx_tele_hash_sig_classifier_attr_t_p()
    hash_field_en_set_arr = new_sx_tele_hash_sig_field_enable_t_arr(2)
    hash_field_set_arr = new_sx_tele_hash_sig_field_t_arr(4)
    hash_type_params = sx_tele_hash_sig_params_t()
    hash_type_params_p = new_sx_tele_hash_sig_params_t_p()
    num_hdr_enables_cnt = 2
    num_fields_cnt = 4

    hash_type_params.symmetric_hash_outer = False
    hash_type_params.symmetric_hash_inner = True
    hash_type_params.symmetric_hash_gp_reg = False

    sx_tele_hash_sig_params_t_p_assign(hash_type_params_p, hash_type_params)

    sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 0,
                                                SX_TELE_HASH_SIG_FIELD_ENABLE_OUTER_L2_IPV4)
    sx_tele_hash_sig_field_enable_t_arr_setitem(hash_field_en_set_arr, 1,
                                                SX_TELE_HASH_SIG_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP)

    sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 0, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_0)
    sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 1, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_1)
    sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 2, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_2)
    sx_tele_hash_sig_field_t_arr_setitem(hash_field_set_arr, 3, SX_TELE_HASH_SIG_OUTER_IPV4_SIP_BYTE_3)

    hash_sig_prof_idx_p = new_sx_tele_hash_sig_prof_t_p()
    hash_sig_prof_idx_p.prof_index = prof_id

    rc = sx_api_tele_hash_sig_prof_set(handle, cmd, hash_sig_prof_idx_p,
                                       hash_sig_classifier_p, hash_type_params_p,
                                       hash_field_en_set_arr, num_hdr_enables_cnt,
                                       hash_field_set_arr, num_fields_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_flow_params_set failed, rc = %d" % (rc)


def SdkException(msg, rc):
    assert rc == SX_STATUS_SUCCESS, msg + ", rc = %d" % (rc)


def flex_parser_init(handle):
    """
        Flex parse initialization

        Args:
           handle: SDK handle.

        Raises:
            SdkException: In case of SDK error
    """
    print('Flex parser init')
    fpp_param_t_p = new_sx_flex_parser_param_t_p()
    try:
        rc = sx_api_flex_parser_init_set(handle, fpp_param_t_p)
        SdkException('sx_api_flex_parser_init_set failed', rc)
    finally:
        delete_sx_flex_parser_param_t_p(fpp_param_t_p)


def flex_parser_deinit(handle):
    """
        Flex parse de-initialization

        Args:
           handle: SDK handle.

        Raises:
            SdkException: In case of SDK error
    """
    print('flex parser deinit')
    rc = sx_api_flex_parser_deinit_set(handle)
    SdkException('sx_api_flex_parser_deinit_set failed', rc)


def flex_parser_reg_ext_point_set(handle, cmd, reg_id, ext_point_type_list, ext_point_offset_list, fexp_id=None):
    """
        Sets / Un-sets list of an extraction points for a given register key.
        Note that this API together with sx_api_register_set are mutually exclusive with
        sx_api_acl_custom_bytes_set, so per single SDK life cycle only one of them can be used.

        Args:
            handle (int):                                                           SDK handle
            cmd (enum sx_access_cmd_t):                                             SET / UNSET
            reg_id (sx_gp_register_e):                                              Register id
            ext_point_type_list (sx_extraction_point_type_e  list):                 Extraction point type list
            ext_point_offset_list (int list):                                       Extraction point offset list
            fexp_id (int):                                                          Flex parser extraction point id

        Raises:
            SdkException: In case of SDK error
        """
    ext_point_arr = new_sx_extraction_point_t_arr(len(ext_point_type_list))
    ext_point_cnt_p = copy_uint32_t_p(len(ext_point_type_list))
    try:
        gp_reg = sx_gp_register_key_t()
        gp_reg.reg_id = reg_id
        reg_key_attr = sx_register_key_attr_t()
        reg_key_attr.gp_reg = gp_reg
        reg_key = sx_register_key_t()
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
        reg_key.key = reg_key_attr

        for i, (ext_type, ext_offset) in enumerate(zip(ext_point_type_list, ext_point_offset_list)):
            ext_point = sx_extraction_point_t()
            ext_point.type = ext_type
            ext_point.offset = ext_offset
            if fexp_id:
                ext_point.attr.fexp_attr.fexp_id.fexp_id = fexp_id
            sx_extraction_point_t_arr_setitem(ext_point_arr, i, ext_point)

        print("Setting extraction points for register {}".format(reg_id))
        rc = sx_api_flex_parser_reg_ext_point_set(handle, cmd, reg_key, ext_point_arr, ext_point_cnt_p)
        if rc:
            print('Failed to set extraction points for register %d , rc:%d' % (reg_id, rc))
            raise exception

    finally:
        delete_sx_extraction_point_t_arr(ext_point_arr)
        delete_uint32_t_p(ext_point_cnt_p)


def flex_parser_reg_ext_point_get(handle, reg_id):
    """
        get the list of extraction points for a given register key.
        Note that this API together with sx_api_register_set are mutually exclusive with
        sx_api_acl_custom_bytes_set, so per single SDK life cycle only one of them can be used.

        Args:
            handle (int):                                                           SDK handle
            reg_id (sx_gp_register_e):                                              register id

        Returns:
            (ex_point_type, exp_point_offset) list

        Raises:
            SdkException: In case of SDK error
        """
    ext_point_cnt_p = copy_uint32_t_p(0)
    ext_point_arr = None

    try:

        gp_reg = sx_gp_register_key_t()
        gp_reg.reg_id = reg_id
        reg_key_attr = sx_register_key_attr_t()
        reg_key_attr.gp_reg = gp_reg
        reg_key = sx_register_key_t()
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
        reg_key.key = reg_key_attr

        print("Getting extraction points for register {}".format(reg_id))
        rc = sx_api_flex_parser_reg_ext_point_get(handle, reg_key, None, ext_point_cnt_p)
        if rc:
            print('Failed to get extraction points for register%d, rc:%d' % (reg_id, rc))
            raise exception

        num_of_ex_points = uint32_t_p_value(ext_point_cnt_p)
        ext_point_arr = new_sx_extraction_point_t_arr(num_of_ex_points)
        rc = sx_api_flex_parser_reg_ext_point_get(handle, reg_key, ext_point_arr, ext_point_cnt_p)
        if rc:
            print('Failed to get extraction points for register %d, rc:%d{}' % (reg_id, rc))
            raise exception

        ex_point_list = []
        for i in range(num_of_ex_points):
            ex_point = sx_extraction_point_t_arr_getitem(ext_point_arr, i)
            ex_point_list.append((ex_point.type, ex_point.offset))
        return ex_point_list

    finally:
        if ext_point_arr:
            delete_sx_extraction_point_t_arr(ext_point_arr)
        delete_uint32_t_p(ext_point_cnt_p)


def _register_set(handle, cmd, reg_id_list):
    """
    Set registers. User can set an extraction point on the allocated register and use it as ACL key.

    Args:
        handle (int):                                   SDK handle
        cmd (enum sx_access_cmd_t):                     CREATE / DESTROY
        reg_key_list (sx_gp_register_e list):           List of registers

    Raises:
        SdkException: In case of SDK error
    """

    reg_key_arr = new_sx_register_key_t_arr(len(reg_id_list))
    reg_key_cnt_p = copy_uint32_t_p(len(reg_id_list))
    try:
        for i, reg_id in enumerate(reg_id_list):
            gp_reg = sx_gp_register_key_t()
            gp_reg.reg_id = reg_id

            reg_key_attr = sx_register_key_attr_t()
            reg_key_attr.gp_reg = gp_reg

            reg_key = sx_register_key_t()
            reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
            reg_key.key = reg_key_attr

            sx_register_key_t_arr_setitem(reg_key_arr, i, reg_key)

        print("Setting registers {}".format(reg_id_list))

        rc = sx_api_register_set(handle, cmd, reg_key_arr, reg_key_cnt_p)
        SdkException('Failed to set registers {}'.format(reg_id_list), rc)
    finally:
        delete_sx_register_key_t_arr(reg_key_arr)
        delete_uint32_t_p(reg_key_cnt_p)


def register_create(handle, reg_id_list):
    """
    Create registers. User can set an extraction point on the allocated register and use it as ACL key.

    Args:
        handle (int):                                   SDK handle
        reg_key_list (sx_gp_register_e list):           List of registers

    Raises:
        SdkException: In case of SDK error
    """

    _register_set(handle, SX_ACCESS_CMD_CREATE, reg_id_list)


def register_destroy(handle, reg_id_list):
    """
    Destroy registers.
    Args:
        handle (int):                                   SDK handle
        reg_key_list (sx_gp_register_e list):           List of registers

    Raises:
        SdkException: In case of SDK error
    """

    _register_set(handle, SX_ACCESS_CMD_DESTROY, reg_id_list)


def unset_trap_to_netdev(handle, trap_group=MY_TRAP_GROUP):
    # Unset trap ID
    user_channel_p = new_sx_user_channel_t_p()
    user_channel = sx_user_channel_t()
    user_channel.type = SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, 0, MY_TRAP_ID, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed, [cmd = SX_ACCESS_CMD_DEREGISTER, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)

    # Set trap ID back to discard (default)
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = MY_TRAP_ID

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_DISCARD

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_ext_set failed, [cmd = %d, rc = %d]" % (SX_ACCESS_CMD_UNSET, rc))
        sys.exit(errno.EACCES)

    # Remove trap group
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    # trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    trap_group_unset_cmd = SX_ACCESS_CMD_DESTROY
    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, 0, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (trap_group_unset_cmd, rc))
        sys.exit(errno.EACCES)


def set_trap_to_netdev(handle, trap_group=MY_TRAP_GROUP):
    # Trap group handling
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = 1
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = False
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    # trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    trap_group_set_cmd = SX_ACCESS_CMD_CREATE
    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, 0, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (trap_group_set_cmd, rc))
        sys.exit(errno.EACCES)
    trap_group = sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group
    print("NOTE: Created trap group ID Is %d" % trap_group)
    # SET/UNSET trap id association to the relevant trap group
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = MY_TRAP_ID

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_ext_set failed, [cmd = SX_ACCESS_CMD_SET, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)

    # Set Trap to go out on netdev
    user_channel_p = new_sx_user_channel_t_p()
    user_channel = sx_user_channel_t()
    user_channel.type = SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, 0, MY_TRAP_ID, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed, [cmd = SX_ACCESS_CMD_REGISTER, rc = %d]" % (rc)))
        sys.exit(errno.EACCES)
    return trap_group


def region_create(handle, key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(handle, region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(handle):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_L4_DESTINATION_PORT)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(handle, key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(handle, region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(handle, acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def group_create(handle, acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

    group_id = sx_acl_id_t_p_value(group_id_p)
    print("Created group %d, rc: %d" % (group_id, rc))
    for i in range(0, acls_num):
        print("acl id = %d " % sx_acl_id_t_arr_getitem(acl_id_arr, i))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def group_destroy(handle, group_id):
    " This function destroy  flex acl key "
    group_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(group_id_p, group_id)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, group_id)

    direction = 0
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy group"

    print("Destroyed group %d, rc: %d" % (group_id, rc))
    delete_sx_acl_id_t_p(group_id_p)


def rule_set(handle, region_id, offset, access):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 10, rule)

    # any key
    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    key_desc.key.l4_destination_port = 0
    key_desc.mask.l4_destination_port = 0

    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_TRAP
    action1.fields.action_trap.action = SX_ACL_TRAP_ACTION_TYPE_TRAP
    action1.fields.action_trap.trap_id = MY_TRAP_ID
    action1.fields.action_trap.preserve_user_id = 1

    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_REGISTER_ACCESS
    action2.fields.action_register_access.command = SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE
    src_register_arr = new_sx_gp_register_e_arr(2)
    sx_gp_register_e_arr_setitem(src_register_arr, 0, SX_GP_REGISTER_4_E)
    action2.fields.action_register_access.src_register_list = src_register_arr
    action2.fields.action_register_access.list_size = 1
    action2.fields.action_register_access.field = SX_FLEX_ACL_FIELD_SELECT_TRAP_USER_ID
    action2.fields.action_register_access.field_offset = 0

    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
    rule.action_count = 2

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(5)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    if access == SX_ACCESS_CMD_SET:
        print("Added rule offset  %d, to region %d,  rc: %d" % (offset, region_id, rc))
    else:
        print("Deleted rule offset  %d, region %d,  rc: %d" % (offset, region_id, rc))

    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def add_acl_config(handle, log_port):
    # direction = 0
    # group_list = []
    # acl_list = []
    # region_list = []

    key_handle = key_create(handle)
    key_handle_list.append(key_handle)
    print("Created key_handle 0x%x" % (key_handle))

    region_id = region_create(handle, key_handle, 10)
    region_list.append(region_id)

    direction = SX_ACL_DIRECTION_INGRESS
    acl_id = acl_create(handle, region_id, direction)
    acl_list.append(acl_id)

    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)

    group_id = group_create(handle, acl_id_arr, 1, 0)
    group_list.append(group_id)

    # the rule hard coded now with action trap with trap id MY_TRAP_ID
    rule_set(handle, region_id, 0, SX_ACCESS_CMD_SET)

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  log_port,
                                  group_list[0])
    print("Port %d is bound to group %d  rc: %d" % (log_port, group_id, rc))


def delete_acl_config(handle, log_port):
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_UNBIND,
                                  log_port,
                                  group_list[0])
    print("port %d unbound from group %d  rc: %d" % (log_port, group_list[0], rc))

    group_destroy(handle, group_list[0])
    rule_set(handle, region_list[0], 0, SX_ACCESS_CMD_DELETE)
    acl_destroy(handle, acl_list[0], region_list[0])
    region_destroy(handle, region_list[0])

    print("Delete key_handle 0x%x" % (key_handle_list[0]))
    key_destroy(handle, key_handle_list[0])


######################################################
#    main
######################################################
def main():
    args = parse_args()

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return 1

    port_list = mapPortAndInterfaces(handle)
    log_port = port_list[0]

    chip_type = get_chip_type(handle)
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5]:
        print("sx_api_tele_hash_sig.py is not supported on this chip type.")
        sx_api_close(handle)
        return 0

    tele_init(handle)
    flex_parser_init(handle)

    # create GP REG 1
    reg_key = SX_GP_REGISTER_4_E  # an arbitrary non-zero id (it is preferable not to test on zero values)
    register_create(handle, [reg_key])

    # set ext_point for GP REG 1
    ext_point_type = SX_EXTRACTION_POINT_TYPE_HASH_SIG0_E
    ext_point_offset = 0
    flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_SET, reg_key, [ext_point_type], [ext_point_offset])

    # create ACL with 2 actions:
    # 1. TRAP and preserve user_id
    # 2. ALU load from GP REG to CQE.user_id[0..15]
    add_acl_config(handle, log_port)

    set_trap_to_netdev(handle)

    print("save USER profile hash signature params for later de-configuration")
    hash_sig_classifier_p, hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt = get_hash_sig_user_prof(handle, 0)

    print("Sets a new hash params for user profile 0")
    set_hash_sig_user_prof(handle, 0, SX_ACCESS_CMD_SET)

    print("save DEFAULT hash signature profile params")
    def_hash_params_p, def_hash_field_enable_list_p, def_field_enable_cnt, def_hash_field_list_p, def_field_cnt = get_hash_sig_default_prof(handle)

    print("set new default hash signature profile params")
    set_hash_sig_default_prof(handle, SX_ACCESS_CMD_SET)

    print("set new default hash signature profile params")
    set_hash_sig_default_prof(handle, SX_ACCESS_CMD_ADD)

    print("set new default hash signature profile params")
    set_hash_sig_default_prof(handle, SX_ACCESS_CMD_DELETE)

    if args.deinit:
        print("restore user and default hash signature profiles values")
        hash_sig_prof_idx_p = new_sx_tele_hash_sig_prof_t_p()
        hash_sig_prof_idx_p.prof_index = 0
        rc = sx_api_tele_hash_sig_prof_set(handle, SX_ACCESS_CMD_SET, hash_sig_prof_idx_p,
                                           hash_sig_classifier_p, hash_params_p,
                                           hash_field_enable_list_p, field_enable_cnt,
                                           hash_field_list_p, field_cnt)
        assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_prof_set failed, rc = %d" % (rc)

        rc = sx_api_tele_hash_sig_default_prof_set(handle, SX_ACCESS_CMD_SET,
                                                   def_hash_params_p,
                                                   def_hash_field_enable_list_p, def_field_enable_cnt,
                                                   def_hash_field_list_p, def_field_cnt)
        assert rc == SX_STATUS_SUCCESS, "sx_api_tele_hash_sig_default_prof_set failed, rc = %d" % (rc)

        unset_trap_to_netdev(handle)
        delete_acl_config(handle, log_port)
        flex_parser_reg_ext_point_set(handle, SX_ACCESS_CMD_UNSET, reg_key, [ext_point_type], [ext_point_offset])
        register_destroy(handle, [reg_key])
        flex_parser_deinit(handle)
        tele_deinit(handle)

    rc = sx_api_close(handle)
    assert rc == SX_STATUS_SUCCESS, "sx_api_close failed, rc = %d" % rc


if __name__ == "__main__":
    sys.exit(main())
