#!/usr/bin/env python

import os
import sys
import errno
import sys
import struct
import socket
import colorsys

from python_sdk_api.sx_api import *
# from sx_tunnel_error_flows import *
from test_infra_common import *
from optparse import OptionParser, Option

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = get_ports(handle, 4)
PORT1 = port_list[0]
PORT2 = port_list[1]

MAX_RIF_NUM = 400
######################################################
#    Functions API
######################################################


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


'''
This part contains all the calls to that sdk API functions
'''
""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_vport_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


def vlan_ports_add_delete(cmd, vid, vlan_port_list_p, port_cnt):
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VLAN MEMBER PORTS  ------------------------------")
    else:
        print("--------------- DELETE VLAN MEMBER PORTS  ------------------------------")

    rc = sx_api_vlan_ports_set(handle, cmd, SPECTRUM_SWID, vid, vlan_port_list_p, port_cnt)
    print(("sx_api_vlan_ports_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(errno.EACCES)


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    print(("sx_api_tunnel_init_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    print(("sx_api_tunnel_deinit_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % (rc)

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    return rc, tunnel_id


""" ############################################################################################ """


def tunnel_get(tunnel_id):
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    rc = sx_api_tunnel_get(handle, tunnel_id, tunnel_attribute_p)
    print(("sx_api_tunnel_get  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    tunnel_attribute = sx_tunnel_attribute_t_p_value(tunnel_attribute_p)
    return rc, tunnel_attribute


""" ############################################################################################ """


def tunnel_destroy(tunnel_id_p):
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    print(("sx_api_tunnel_set  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_decap_rule_create(decap_key_p, decap_data_p):
    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_CREATE, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set(create)  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_decap_rule_destroy(decap_key_p, decap_data_p):
    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_DESTROY, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set(destroy)  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel decap rule, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def tunnel_decap_rule_edit(decap_key_p, decap_data_p):
    rc = sx_api_tunnel_decap_rules_set(handle, SX_ACCESS_CMD_EDIT, decap_key_p, decap_data_p)
    print(("sx_api_tunnel_decap_rules_set(edit)  [rc = %d] " % (rc)))
    # assert SX_STATUS_SUCCESS == rc, "Failed to edit tunnel decap rule, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def create_loopback_rif(vrid, mtu=1500):
    " This function creates loopback rif with given parameters. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 255
    ifc_attr.loopback_enable = True

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    # assert SX_STATUS_SUCCESS == rc, "Failed to create loopback rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created loopback rif: %d, rc: %d " % (rif, rc))

    return rif, rc


######################################################
#    Structs Function
######################################################
'''
This part contains all the calls to functions that create the necessary structs
'''
""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def process_neigh(rif, addr, mac_addr, delete=0):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    if delete == 0:
        rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
        assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)
        print("Added neighbor to rif %d, rc: %d" % (rif, rc))
    else:
        rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh to rif %d" % (rif)
        print("Deleted neighbor to rif %d, rc: %d" % (rif, rc))


""" ############################################################################################ """


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.flood_ecmp_enabled = False
    general_params.nve.mc_ecmp_enabled = False
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


""" ############################################################################################ """


def make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif, underlay_rif=0, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p.underlay_rif = underlay_rif  # =underlay_rif -- not supported

    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.ipinip_p2p.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_mode = 0
    tunnel_attribute.attributes.ipinip_p2p.encap.gre_key = 0

    tunnel_attribute.attributes.ipinip_p2p.decap.gre_check_key = 0
    tunnel_attribute.attributes.ipinip_p2p.decap.gre_expected_key = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_ipinip_gre(vrid, underlay_sip, overlay_rif, underlay_rif=0, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE
    tunnel_attribute.direction = direction

    # IPinIP attribute
    tunnel_attribute.attributes.ipinip_p2p_gre.overlay_rif = overlay_rif
    tunnel_attribute.attributes.ipinip_p2p_gre.underlay_rif = underlay_rif  # =underlay_rif -- not supported

    tunnel_attribute.attributes.ipinip_p2p_gre.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.ipinip_p2p_gre.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.ipinip_p2p_gre.encap.gre_mode = 0
    tunnel_attribute.attributes.ipinip_p2p_gre.encap.gre_key = 0

    tunnel_attribute.attributes.ipinip_p2p_gre.decap.gre_check_key = 0
    tunnel_attribute.attributes.ipinip_p2p_gre.decap.gre_expected_key = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan(vrid, underlay_sip, log_port, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, ttl=255, underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0, decap_underlay_rif=0):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_ttl = ttl
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.vxlan.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.vxlan.underlay_domain_type = underlay_domain_type
    tunnel_attribute.attributes.vxlan.nve_log_port = log_port

    chip_type = get_chip_type(handle)
    if chip_type >= SX_CHIP_TYPE_SPECTRUM4:
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mask = 0xF7FFFFFF00000000
    else:
        tunnel_attribute.attributes.vxlan.decap.reserved_bits_check.mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_IGNORE_E

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_vxlan_gre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_VXLAN_GPE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_ttl = 255
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan_gpe.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_geneve(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP):

    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = SX_TUNNEL_TYPE_NVE_GENEVE
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.vxlan_gre.encap.underlay_vrid = vrid
    tunnel_attribute.vxlan_gre.encap.underlay_ttl = 255
    tunnel_attribute.vxlan_gre.encap.underlay_sip = underlay_sip
    tunnel_attribute.vxlan_gre.encap.underlay_dport = 0

    return tunnel_attribute


""" ############################################################################################ """


def make_tunnel_attributes_nvgre(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_DECAP, log_port=NVE_PORT,
                                 underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0,
                                 decap_underlay_rif=0, tun_type=SX_TUNNEL_TYPE_NVE_NVGRE, tag_mode=SX_VLAN_TAG_MODE_802_1Q_E):
    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = tun_type
    tunnel_attribute.direction = direction

    # NVE - nvgre attributes
    tunnel_attribute.attributes.nvgre.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.nvgre.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.nvgre.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.nvgre.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.nvgre.decap.tag_mode = tag_mode
    tunnel_attribute.attributes.nvgre.nve_log_port = log_port
    tunnel_attribute.attributes.nvgre.underlay_domain_type = underlay_domain_type

    return tunnel_attribute


""" ############################################################################################ """
'''def make_decap_key(key_type, vrid, tunnel_type = SX_TUNNEL_TYPE_NVE_VXLAN, underlay_dip = "192.168.1.2"):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4(underlay_dip) # need to change to valid ip
    decap_key.underlay_sip = make_sx_ip_addr_v4("192.168.1.3") # need to change to valid ip

    return decap_key
'''
""" ############################################################################################ """


def make_decap_data(tunnel_id, action, counter_id):

    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data.tunnel_id = tunnel_id
    decap_data.action = action
    decap_data.counter_id = counter_id
    decap_data.trap_attr.prio = 2
    decap_data.span_session_id = 0

    return decap_data


def make_bridge_tunnel_counter_attr(tunnel_id, type=SX_BRIDGE_COUNTER_TUNNEL_DECAP_E):
    attr = sx_bridge_tunnel_counter_attr_t()
    attr.type = type
    attr.tunnel_id = tunnel_id

    attr_p = new_sx_bridge_tunnel_counter_attr_t_p()
    sx_bridge_tunnel_counter_attr_t_p_assign(attr_p, attr)
    return attr_p


###################################################################
# Router related functions
###################################################################
def router_init():
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def process_local_route(vrid, rif, addr, mask, delete=0):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    if delete == 0:
        rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to create local route"
        print("Created local route for rif %d, rc: %d " % (rif, rc))
    else:
        rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE, vrid, ip_prefix_p, uc_route_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete local route"
        print("Deleted local route for rif %d, rc: %d " % (rif, rc))


def create_ip2me_route(vrid, rif, addr, mask="255.255.255.255"):
    " This function creates ip2me route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_IP2ME
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create ip2me route"

    print("Created ip2me route for rif %d, rc: %d " % (rif, rc))


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = enable
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    print("Set rif %d state %d, rc: %d " % (rif, enable, rc))
    return rc


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    print(("Delete RIF: %d, rc: %d " % (rif, rc)))
    return rc


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def generate_ips_list(lower_ip, upper_ip, IPs_amount):
    '''
    @summary         : generate a list with ips in the given limits
    @param lower_ip  : lower ip bound,
    @param upper_ip  : upper ip bound
    @param IPs_amount:  amount of needed ips
    @return          : a list of ips
    '''
    lower_ip_int = (int(lower_ip.split(".")[0]) << 24) + (int(lower_ip.split(".")[1]) << 16) + (int(lower_ip.split(".")[2]) << 8) + int(lower_ip.split(".")[3])
    upper_ip_int = (int(upper_ip.split(".")[0]) << 24) + (int(upper_ip.split(".")[1]) << 16) + (int(upper_ip.split(".")[2]) << 8) + int(upper_ip.split(".")[3])

    if upper_ip_int - lower_ip_int < IPs_amount:
        print("error, required ip's amount can not be supplied from within provided range")
        return 0

    ips = []
    ip_int_range = range(lower_ip_int, upper_ip_int)
    for index in range(0, IPs_amount):
        item = ip_int_range[index]
        IP = "%d." % ((item & 0xff000000) >> 24)
        IP += "%d." % ((item & 0xff0000) >> 16)
        IP += "%d." % ((item & 0xff00) >> 8)
        IP += "%d" % (item & 0xff)

        ips.append(IP)

    return ips

# 3


def create_tunnel_good_flow(vrid):
    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    (rif, rc) = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    (rc, tunnel_id) = example_ipinip_tunnel_create_flow(vrid, rif)
    assert rc == SX_STATUS_SUCCESS, "Failed to create ipinip tunnel, rc: %d" % (rc)

    print("set RIF state - ENABLE")
    rc = set_rif_state_ipv4(rif, True)
    assert rc == SX_STATUS_SUCCESS, "Failed to enable loopback, rc: %d" % (rc)

    print("set RIF state - DISABLE")
    rc = set_rif_state_ipv4(rif, False)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable loopback, rc: %d" % (rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert rc == SX_STATUS_SUCCESS, "Failed to destroy ipinip tunnel, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)


def create_tunnel_good_flow_with_decap(vrid):
    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    (rif, rc) = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    (rc, tunnel_id) = example_ipinip_tunnel_create_flow(vrid, rif)
    assert rc == SX_STATUS_SUCCESS, "Failed to create ipinip tunnel, rc: %d" % (rc)

    print("set RIF state - ENABLE")
    rc = set_rif_state_ipv4(rif, True)
    assert rc == SX_STATUS_SUCCESS, "Failed to enable loopback, rc: %d" % (rc)

    example_decap_rules_flow(vrid, tunnel_id)

    print("set RIF state - DISABLE")
    rc = set_rif_state_ipv4(rif, False)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable loopback, rc: %d" % (rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert rc == SX_STATUS_SUCCESS, "Failed to destroy ipinip tunnel, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

###########################################################################
# 1. Create tunnel without init; Should return SX_STATUS_MODULE_UNINITIALIZED.
#   1.1. With init
#   1.2. Without init
#   1.3. With init
###########################################################################


def test_tunnel_with_init_flow():
    vrid = create_vrid()

    print("1. Create tunnel without init;")
    create_tunnel_good_flow(vrid)

    ###########################################################################
    print("1.2. bad flow (without init)")

    print("create tunnel")
    rc, tunnel_id = example_ipinip_tunnel_create_flow(vrid, 0)
    assert rc == SX_STATUS_MODULE_UNINITIALIZED, "Failed to create tunnel expected SX_STATUS_MODULE_UNINITIALIZED = 33, rc: %d" % (rc)

    ###########################################################################

    print("1.3. good flow (with init)")

    create_tunnel_good_flow(vrid)

    delete_vrid(vrid)

###########################################################################
# 2. Create tunnel with Multicast Underlay SIP address; Should return SX_STATUS_UNSUPPORTED.
#   2.1. Unicast SIP
#   2.2. Multicast SIP
#   2.3  Unicast SIP
###########################################################################


def test_tunnel_sip_flow():

    vrid = create_vrid()

    print("2. Create tunnel with Multicast Underlay SIP address.")
    print("2.1. good flow (valid USIP)")
    create_tunnel_good_flow(vrid)

    ###########################################################################
    print("2.2. bad flow (invalid USIP)")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("224.0.0.5")
    tunnel_attribute = make_tunnel_attributes_ipinip(vrid, underlay_sip, rif, 0, SX_TUNNEL_DIRECTION_SYMMETRIC)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    (rc, tunnel_id) = tunnel_create(tunnel_attribute_p)
    assert rc == SX_STATUS_UNSUPPORTED, "Failed to create ipinip tunnel, expected rc = %d, rc: %d" % (SX_STATUS_UNSUPPORTED, rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("2.3. good flow (valid USIP)")
    create_tunnel_good_flow(vrid)

    delete_vrid(vrid)

###########################################################################
# 3. Create tunnel with invalid VRID; Should return SX_STATUS_ENTRY_NOT_FOUND.
#   3.1. Valid VRID
#   3.2. Invalid VRID
#   3.3. Valid VRID
###########################################################################


def test_tunnel_vrid_flow():

    vrid = create_vrid()

    print("3.1. good flow (valid VRID)")
    create_tunnel_good_flow(vrid)

    ###########################################################################
    print("3.2. bad flow (invalid VRID)")
    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("192.168.1.2")
    tunnel_attribute = make_tunnel_attributes_ipinip(vrid + 1, underlay_sip, rif, 0, SX_TUNNEL_DIRECTION_SYMMETRIC)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    (rc, tunnel_id) = tunnel_create(tunnel_attribute_p)
    assert rc == SX_STATUS_ENTRY_NOT_FOUND, "Failed to create tunnel expected rc = %d, rc: %d" % (SX_STATUS_ENTRY_NOT_FOUND, rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("3.3. good flow (valid VRID)")
    create_tunnel_good_flow(vrid)
    delete_vrid(vrid)

###########################################################################
# 4. Delete Loopback RIF when tunnel is still attached
#   4.1. Delete RIF after detach
#   4.2. Delete RIF before detach
#        Try attach more than 1 tunnel to rif
#   4.3. Delete RIF after detach
###########################################################################


def test_tunnel_with_rif_flow():

    print("4. Delete Loopback RIF when tunnel is still attached;")

    vrid = create_vrid()

    print("4.1. good flow (Delete RIF after detach)")
    create_tunnel_good_flow(vrid)

    ###########################################################################
    print("4.2. bad flow (Delete RIF before detach)")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    rc, tunnel_id = example_ipinip_tunnel_create_flow(vrid, rif)
    assert rc == SX_STATUS_SUCCESS, "Failed to create ipinip tunnel, rc: %d" % (rc)

    print("set RIF state - ENABLE")
    rc = set_rif_state_ipv4(rif, True)
    assert rc == SX_STATUS_SUCCESS, "Failed to enable loopback, rc: %d" % (rc)

    print("set RIF state - DISABLE")
    rc = set_rif_state_ipv4(rif, False)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable loopback, rc: %d" % (rc)

    print("delete RIF")
    rc = delete_rif(vrid, rif)
    assert rc == SX_STATUS_RESOURCE_IN_USE, "Failed to delete loopback, expected rc = %d, rc: %d" % (SX_STATUS_RESOURCE_IN_USE, rc)

    print("create second tunnel")
    rc, tunnel_id_2 = example_ipinip_tunnel_create_flow(vrid, rif)
    assert rc == SX_STATUS_RESOURCE_IN_USE, "Failed to create ipinip tunnel, expected rc = %d, rc: %d" % (SX_STATUS_RESOURCE_IN_USE, rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert rc == SX_STATUS_SUCCESS, "Failed to destroy ipinip tunnel, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("4.3. good flow (Delete RIF after detach)")
    create_tunnel_good_flow(vrid)

    delete_vrid(vrid)

###########################################################################
# 5. Configure DECAP rule for non-existing tunnel id
#   5.1. With an existing tunnel id
#   5.2. With non-existing tunnel id
#   5.3. With an existing tunnel id
###########################################################################


def test_decap_without_tunnel_flow():

    print("5. Configure DECAP rule for non-existing tunnel id;")

    vrid = create_vrid()
    create_tunnel_good_flow_with_decap(vrid)

    ###########################################################################
    print("5.2. bad flow (With non-existing tunnel id)")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("set decap rules")
    tunnel_id = 12345
    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert rc != SX_STATUS_SUCCESS, "Failed on create decap rule for non-existing tunnel, rc: %d" % (rc)

    rc = tunnel_decap_rule_destroy(decap_key_p, decap_data_p)
    assert rc != SX_STATUS_SUCCESS, "Failed on destroy decap rule for non-existing tunnel, rc: %d" % (rc)

    rc = tunnel_decap_rule_edit(decap_key_p, decap_data_p)
    assert rc != SX_STATUS_SUCCESS, "Failed on destroy decap rule for non-existing tunnel, rc: %d" % (rc)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("5.3. good flow (With an existing tunnel id)")

    create_tunnel_good_flow_with_decap(vrid)
    delete_vrid(vrid)

###########################################################################
# 6. Set ENABLE state for Loopback RIF when tunnel is not yet attached.
#   6.1. Tunnel is attached
#   6.2. Tunnel is not attached
#   6.3. Tunnel is attached
###########################################################################


def test_loopback_with_tunnel_flow():

    print("6. Set ENABLE state for Loopback RIF when tunnel is not yet attached;")

    vrid = create_vrid()

    print("6.1. good flow (Tunnel is attached)")
    create_tunnel_good_flow_with_decap(vrid)

    ###########################################################################
    print("6.2. bad flow (Tunnel is not attached)")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("set RIF state - ENABLE")
    rc = set_rif_state_ipv4(rif, True)
    assert rc != SX_STATUS_SUCCESS, "Failed on enable unconfigured loopback, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("6.3. good flow (Tunnel is attached)")

    create_tunnel_good_flow_with_decap(vrid)
    delete_vrid(vrid)

###########################################################################
# 7. Set DISABLE state for Loopback RIF when tunnel is not yet attached.
#   7.1. Tunnel is attached
#   7.2. Tunnel is not attached
#   7.3. Tunnel is attached
###########################################################################


def test_loopback_with_tunnel_flow_2():

    print("7. Set DISABLE state for Loopback RIF when tunnel is not yet attached;")

    vrid = create_vrid()

    print("7.1. good flow (Tunnel is attached)")
    create_tunnel_good_flow_with_decap(vrid)

    ###########################################################################
    print("7.2. bad flow (Tunnel is not attached)")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("set RIF state - DISABLE")
    rc = set_rif_state_ipv4(rif, False)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable unconfigured loopback, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("7.3. good flow (Tunnel is attached)")
    create_tunnel_good_flow_with_decap(vrid)
    delete_vrid(vrid)

###########################################################################
# 8. Detach tunnel when Loopback RIF is UP
#   8.1. Detach tunnel when Loopback RIF is Down
#   8.2. Detach tunnel when Loopback RIF is UP
#   8.3. Detach tunnel when Loopback RIF is Down
###########################################################################


def test_tunnel_without_rif_state_flow():

    print("8. Detach tunnel when Loopback RIF is UP;")

    vrid = create_vrid()

    print("8.1. good flow (Detach tunnel when Loopback RIF is Down)")
    create_tunnel_good_flow(vrid)

    ###########################################################################
    print("8.2. Detach tunnel when Loopback RIF is UP")

    print("init")
    rc = example_tunnel_init_flow()
    assert rc == SX_STATUS_SUCCESS, "Failed to init tunnel, rc: %d" % (rc)

    print("create RIF")
    rif, rc = create_loopback_rif(vrid)
    assert rc == SX_STATUS_SUCCESS, "Failed to create loopback, rc: %d" % (rc)

    print("create tunnel")
    rc, tunnel_id = example_ipinip_tunnel_create_flow(vrid, rif)
    assert rc == SX_STATUS_SUCCESS, "Failed to create ipinip tunnel, rc: %d" % (rc)

    print("set RIF state - ENABLE")
    rc = set_rif_state_ipv4(rif, True)
    assert rc == SX_STATUS_SUCCESS, "Failed to enable loopback, rc: %d" % (rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert rc == SX_STATUS_RESOURCE_IN_USE, "Tunnel destroy should return fail, rc: %d" % (rc)

    print("set RIF state - DISABLE")
    rc = set_rif_state_ipv4(rif, False)
    assert rc == SX_STATUS_SUCCESS, "Failed to disable loopback, rc: %d" % (rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert rc == SX_STATUS_SUCCESS, "Failed to destroy ipinip tunnel, rc: %d" % (rc)

    print("delete RIF")
    delete_rif(vrid, rif)

    print("deinit")
    rc = tunnel_deinit()
    assert rc == SX_STATUS_SUCCESS, "Failed to deinit tunnel, rc: %d" % (rc)

    ###########################################################################
    print("8.3. good flow (Detach tunnel when Loopback RIF is Down)")
    create_tunnel_good_flow(vrid)
    delete_vrid(vrid)


######################################################
#    Example Function
######################################################
'''
This part contains all the calls to functions that demonstrate the example flows
'''
""" ############################################################################################ """


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    return tunnel_init(general_param_p)


""" ############################################################################################ """


def example_vxlan_tunnel_create_flow(vrid, log_port=NVE_PORT, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, usip="192.168.0.1", ttl=255, underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0, decap_underlay_rif=0):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip and to correctly add to the struct
    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, log_port, direction, ttl, underlay_domain_type, encap_underlay_rif, decap_underlay_rif)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)


""" ############################################################################################ """


def example_tunnel_destroy_flow(tunnel_id):

    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)

    return tunnel_destroy(tunnel_id_p)


""" ############################################################################################ """


def example_ipinip_tunnel_create_flow(vrid, overlay_rif):

    underlay_sip = sx_ip_addr_t()
    underlay_sip = make_sx_ip_addr_v4("192.168.1.2")  # need to change to valid ip and to correctly add to the struct

    tunnel_attribute = make_tunnel_attributes_ipinip(vrid, underlay_sip, overlay_rif)
    tunnel_attribute_p = new_sx_tunnel_attribute_t_p()
    sx_tunnel_attribute_t_p_assign(tunnel_attribute_p, tunnel_attribute)
    return tunnel_create(tunnel_attribute_p)


""" ############################################################################################ """


def example_decap_rules_flow(vrid, tunnel_id):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule, rc: %d" % (rc)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_DROP, 0)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)
    rc = tunnel_decap_rule_edit(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to edit decap rule, rc: %d" % (rc)

    rc = tunnel_decap_rule_destroy(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy decap rule, rc: %d" % (rc)

    """ ############################################################################################ """


def example_decap_rules_create_flow(vrid, tunnel_id):

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)

    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    return rc


""" ############################################################################################ """


def example_decap_rules_complex_flow(tunnel_id):
    low_prio_decap_key_p_list = []
    high_prio_decap_key_p_list = []

    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)
    for i in range(0, 100):
        for vrid in range(0, 16):
            decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
            decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
            sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
            low_prio_decap_key_p_list.append(decap_key_p)
            print("create low rule, vrid: %d" % (vrid))
            rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule, rc: %d" % (rc)

            decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
            decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid + 16, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
            sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
            high_prio_decap_key_p_list.append(decap_key_p)
            print("create high rule, vrid: %d" % (vrid + 16))
            rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule, rc: %d" % (rc)

        for vrid in range(0, 16):
            print("destroy low rule, vrid: %d" % (vrid))
            rc = tunnel_decap_rule_destroy(low_prio_decap_key_p_list[vrid], decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to destroy decap rule, rc: %d" % (rc)
            print("destroy high rule, vrid: %d" % (vrid + 16))
            rc = tunnel_decap_rule_destroy(high_prio_decap_key_p_list[vrid], decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to destroy decap rule, rc: %d" % (rc)


""" ############################################################################################ """


def init_parser():
    '''
    @summary: init parser
    '''
    usage = "usage: %prog [options] arg, script will run python test with traffic.\n"
    usage += "example: %prog --tunnel= vxlan --traffic"

    parser = OptionParser(usage=usage)

    parser.add_option('--tunnel', dest='tunnel_type', default="vxlan",
                      help="Insert the tunnel type. example --tunnel= vxlan  ------ default = vxlan")

    parser.add_option('--traffic', dest='traffic',
                      action="store_true", default=False, help="if the test run with traffic add this flag")

    parser.add_option('--config_test', dest='config_test',
                      action="store_true", default=False, help="if we wont to run the configuration test init/deinit")
    parser.add_option('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    # use logger see examlpe in

    (options, args) = parser.parse_args()

    # if not options.tunnel_type:
    #   parser.error('tunnel_type not given, for more info run script with --help')
    #    sys.exit(1)

    return options


""" ############################################################################################ """


def tunnel_init_set_test():

    print("good flow init then deinit")
    print("init")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    print("deinit")
    rc = tunnel_deinit()
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

    print("bad flow")
    print("tring to create tunnel before init")
    vrid = create_vrid()

    print("create tunnel")
    rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid)
    assert SX_STATUS_MODULE_UNINITIALIZED == rc, "Failed to create tunnel expected SX_STATUS_MODULE_UNINITIALIZED =33, rc: %d" % (rc)

    print("deinit before destroying all created tunnels")
    print("init")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    print("create tunnel")
    rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid)
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    print("try to deinit")
    rc = tunnel_deinit()
    assert SX_STATUS_DB_NOT_EMPTY == rc, "try to deinit before destroing all tunnels expected SX_STATUS_DB_NOT_EMPTY = 19, rc: %d" % (rc)

    print("destroy tunnel")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)
    print("try to deinit after destroing tunnel")
    rc = tunnel_deinit()
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

    print("tring to deinit after we all ready did deinit")
    rc = tunnel_deinit()
    assert SX_STATUS_MODULE_UNINITIALIZED == rc, "trying to deinit after deinit expected SX_STATUS_MODULE_UNINITIALIZED = 33, rc: %d" % (rc)

    print("init 2 times in a row")
    print("init first time")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    print("second time")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_ALREADY_INITIALIZED == rc, "trying to deinit after deinit expected SX_STATUS_ALREADY_INITIALIZED = 31, rc: %d" % (rc)

    print("deinit")
    rc = tunnel_deinit()
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

    loopback_rif = list()
    tunnel_id = list()
    print("creating max+1 tunnels destroy them and deinit")
    print("init")
    rc = example_tunnel_init_flow()
    for i in range(0, MAX_RIF_NUM):
        rif, rc = create_loopback_rif(vrid)
        loopback_rif.append(rif)
        print("creating tunnel num %d" % (i))
        rc, tmp_tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif[i])
        tunnel_id.append(tmp_tunnel_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)

    for i in range(0, MAX_RIF_NUM):
        print("destroy tunnel %d" % tunnel_id[i])
        rc = example_tunnel_destroy_flow(tunnel_id[i])
        assert SX_STATUS_SUCCESS == rc, "Failed to delete tunnel , rc: %d" % (rc)
        delete_rif(vrid, loopback_rif[i])

    print("try to deinit after destroing tunnel")
    rc = tunnel_deinit()
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit  , rc: %d" % (rc)
    delete_vrid(vrid)


def tunnel_set_get_test():
    print("creating max tunnels")
    print("init")
    loopback_rif = list()
    loopback_rif_list = list()
    tunnel_id = list()
    rc = example_tunnel_init_flow()
    tmp_tunnel_attr = sx_tunnel_attribute_t()
    tmp_tunnel_attr.attributes.ipinip_p2p = sx_tunnel_ipinip_p2p_attribute_t()
    vrid = create_vrid()
    for j in range(0, 10):
        for i in range(0, MAX_RIF_NUM):
            rif, rc = create_loopback_rif(vrid)
            loopback_rif.append(rif)
            print("creating tunnel num %d" % (i + (j * MAX_RIF_NUM)))
            rc, tmp_tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif[i + (j * MAX_RIF_NUM)])
            tunnel_id.append(tmp_tunnel_id)
            assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)

        print("getting max tunnels")
        for i in range(0, MAX_RIF_NUM):
            print("getting tunnel %d attributes" % tunnel_id[i + (j * MAX_RIF_NUM)])
            rc, tmp_tunnel_attr = tunnel_get(tunnel_id[i + (j * MAX_RIF_NUM)])
            assert SX_STATUS_SUCCESS == rc, "Failed to get tunnel attr, rc: %d" % (rc)
            print("recieved overlay rif %d" % (tmp_tunnel_attr.attributes.ipinip_p2p.overlay_rif))
            print("expected overlay rif %d" % (loopback_rif[i + (j * MAX_RIF_NUM)]))
            if tmp_tunnel_attr.attributes.ipinip_p2p.overlay_rif != loopback_rif[i + (j * MAX_RIF_NUM)]:
                print("recv attr.overlay_rif (%d) is diffrent from expected overlay_rif (%d)" % (tmp_tunnel_attr.attributes.ipinip_p2p.overlay_rif, loopback_rif[i + (j * MAX_RIF_NUM)]))
                exit

        print("deleting max tunnels")
        for i in range(0, MAX_RIF_NUM):
            print("destroy tunnel %d" % tunnel_id[i + (j * MAX_RIF_NUM)])
            rc = example_tunnel_destroy_flow(tunnel_id[i + (j * MAX_RIF_NUM)])
            assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel , rc: %d" % (rc)
            delete_rif(vrid, loopback_rif[i + (j * MAX_RIF_NUM)])

    print(" ------------------------------- random testing -------------------------------------")
    print("---------------- create max tunnel and delete from random places --------------------")
    for i in range(0, MAX_RIF_NUM):
        rif, rc = create_loopback_rif(vrid)
        assert SX_STATUS_SUCCESS == rc, "Failed to create rif , rc: %d" % (rc)
        loopback_rif_list.append(rif)
        print("creating tunnel num %d" % (i))
        rc, tmp_tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif_list[i])
        tunnel_id.append(tmp_tunnel_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)
    print("--------- deleting from random places ---------")
    for i in range(0, MAX_RIF_NUM):
        del_indx = 0
        print("destroy tunnel %d" % tunnel_id[del_indx])
        rc = example_tunnel_destroy_flow(tunnel_id[del_indx])
        assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel , rc: %d" % (rc)
        delete_rif(vrid, loopback_rif_list[del_indx])
        tunnel_id.pop(del_indx)
        loopback_rif_list.pop(del_indx)

    print(" -------------------------------create and delete in a random way --------------------")
    number_of_tunnels_are_active = 0
    select = ['create', 'delete']
    tunnel_id_list = list()
    for i in range(0, 1000):
        print("number of tunnels that are active is %d" % (number_of_tunnels_are_active))
        if number_of_tunnels_are_active == 0:
            create_or_delete = 'create'
        elif number_of_tunnels_are_active == MAX_RIF_NUM:
            create_or_delete = 'delete'
        else:
            create_or_delete = 'create'

        if create_or_delete == 'create':
            rif, rc = create_loopback_rif(vrid)
            assert SX_STATUS_SUCCESS == rc, "Failed to create rif , rc: %d" % (rc)
            loopback_rif_list.append(rif)
            print("creating tunnel ", end="")
            rc, tmp_tunnel_id = example_ipinip_tunnel_create_flow(vrid, loopback_rif_list[-1])
            print("%d" % (tmp_tunnel_id))
            tunnel_id_list.append(tmp_tunnel_id)
            assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)
            number_of_tunnels_are_active += 1
        else:
            del_indx = 0
            print("destroy tunnel %d" % tunnel_id_list[del_indx])
            rc = example_tunnel_destroy_flow(tunnel_id_list[del_indx])
            assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel , rc: %d" % (rc)
            delete_rif(vrid, loopback_rif_list[del_indx])
            tunnel_id_list.pop(del_indx)
            loopback_rif_list.pop(del_indx)
            number_of_tunnels_are_active -= 1

    for i in range(0, number_of_tunnels_are_active):
        del_indx = 0
        print("destroy tunnel %d" % tunnel_id_list[del_indx])
        rc = example_tunnel_destroy_flow(tunnel_id_list[del_indx])
        assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel , rc: %d" % (rc)
        delete_rif(vrid, loopback_rif_list[del_indx])
        tunnel_id_list.pop(del_indx)
        loopback_rif_list.pop(del_indx)

    print("--------------------------bad flow-------------------------")
    print("getting non exist tunnel attribute")
    rc, tmp_tunnel_attr = tunnel_get(1)
    assert SX_STATUS_ENTRY_NOT_FOUND == rc, "expected rc =21 entry not found ,acualy rc: %d" % (rc)

    print(" deinit")
    rc = tunnel_deinit()
    delete_vrid(vrid)


def tunnel_flow_test():
    test_tunnel_with_init_flow()
    test_tunnel_sip_flow()
    test_tunnel_vrid_flow()
    test_tunnel_with_rif_flow()
    # test_decap_without_tunnel_flow()
    test_loopback_with_tunnel_flow()
    test_loopback_with_tunnel_flow_2()
    test_tunnel_without_rif_state_flow()


def decap_set_test():
    high_decap_key_p_list = list()
    low_decap_key_p_list = list()
    ip_list = list()
    print("----------decap_setting_test----------")
    print("----------init----------------------")

    rc = example_tunnel_init_flow()
    vrid = create_vrid()

    print("creating tunnel")
    (loopback_rif, rc) = create_loopback_rif(vrid)
    assert SX_STATUS_SUCCESS == rc, "Failed to create_loopback_rif , rc: %d" % (rc)
    print("loopback_rif %d" % loopback_rif)
    (rc, tunnel_id) = example_ipinip_tunnel_create_flow(vrid, loopback_rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel , rc: %d" % (rc)

    example_decap_rules_flow(vrid, tunnel_id)
    example_decap_rules_complex_flow(tunnel_id)

    ############ creating decap data #######
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)
    print("---------bad flow:----------------------")
    print("-----creating 2 same decap key ---------")
    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4)
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    print("-------------create 1------------------- ")
    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule , rc: %d" % (rc)
    print("-------------create 2------------------ ")
    rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
    assert SX_STATUS_ENTRY_ALREADY_EXISTS == rc, "expecated entry already exists acualy rc = %d" % (rc)
    rc = tunnel_decap_rule_destroy(decap_key_p, decap_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule , rc: %d" % (rc)

    ip_list = generate_ips_list('000.000.000.000', '255.255.255.255', 14000)  # need to be set for more than the max decap rules (i change it to be 1000 in spectrum.h for this test)
    print("------creating max high priorety decap rule entries----------")

    max_decap_rules = 20000  # need to be set for the max decap rules (i change it to be 1000 in spectrum.h for this test)
    for i in range(0, max_decap_rules):
        print("%d " % (i), end="")
        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, ip_list[i])
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        high_decap_key_p_list.append(decap_key_p)
        rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule , rc: %d" % (rc)

    for i in range(max_decap_rules, max_decap_rules + 9):
        sys.stdout.write("%d " % (i))
        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, ip_list[i])
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        high_decap_key_p_list.append(decap_key_p)
        rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
        assert SX_STATUS_NO_RESOURCES == rc, "Failed expecated SX_STATUS_NO_RESOURCES rc = 5  acualy , rc: %d" % (rc)

    for i in range(0, max_decap_rules):
        del_indx = 0
        sys.stdout.write("%d delete index = %d " % (i, del_indx))
        rc = tunnel_decap_rule_destroy(high_decap_key_p_list[del_indx], decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule , rc: %d" % (rc)
        high_decap_key_p_list.pop(del_indx)

    print("------creating max low priorety decap rule entries----------")

    for i in range(0, max_decap_rules):
        sys.stdout.write("%d " % (i))
        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, ip_list[i])
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        low_decap_key_p_list.append(decap_key_p)
        rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule , rc: %d" % (rc)

    for i in range(max_decap_rules, max_decap_rules + 9):
        sys.stdout.write("%d " % (i))
        decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
        decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, ip_list[i])
        sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
        high_decap_key_p_list.append(decap_key_p)
        rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
        assert SX_STATUS_NO_RESOURCES == rc, "Failed expecated SX_STATUS_NO_RESOURCES rc = 5  acualy , rc: %d" % (rc)

    for i in range(0, max_decap_rules):
        sys.stdout.write("%d " % (i))
        rc = tunnel_decap_rule_destroy(low_decap_key_p_list[i], decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule , rc: %d" % (rc)

    print("---------------------------random decap test------------------")
    number_of_decap_rules_active = 0
    select = ['create', 'delete']
    priority = [SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP]
    decap_key_p_list = list()
    for i in range(0, 1000):
        print("number of decap rules that are active is %d" % (number_of_decap_rules_active))
        if number_of_decap_rules_active == 0:
            create_or_delete = 'create'
        elif number_of_decap_rules_active == max_decap_rules:
            create_or_delete = 'delete'
        else:
            create_or_delete = 'create'

        if create_or_delete == 'create':
            sys.stdout.write("%d " % (i))
            decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
            decap_key = make_decap_key(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, vrid, SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, ip_list[i])
            sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
            decap_key_p_list.append(decap_key_p)
            rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to create decap rule , rc: %d" % (rc)
            number_of_decap_rules_active += 1
        else:
            del_indx = 0
            sys.stdout.write("%d delete index = %d " % (i, del_indx))
            rc = tunnel_decap_rule_destroy(high_decap_key_p_list[del_indx], decap_data_p)
            assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule , rc: %d" % (rc)
            high_decap_key_p_list.pop(del_indx)
            number_of_decap_rules_active -= 1

    for i in range(0, number_of_decap_rules_active):
        del_indx = 0
        sys.stdout.write("%d delete index = %d " % (i, del_indx))
        rc = tunnel_decap_rule_destroy(high_decap_key_p_list[del_indx], decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete decap rule , rc: %d" % (rc)
        high_decap_key_p_list.pop(del_indx)

    print("------------------ deinit-----------------------------")
    rc = example_tunnel_destroy_flow(tunnel_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to deletetunnle , rc: %d" % (rc)
    rc = tunnel_deinit()
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit , rc: %d" % (rc)
    delete_rif(vrid, loopback_rif)
    delete_vrid(vrid)


def tunnel_map_entry_process(tunnel_id, bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5, delete=0):
    map_entry = make_tunnel_map_entry_params(bridge_id, tunnel_type, vni)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    if delete == 0:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)
    else:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE, tunnel_id, map_entry_p, 1)


def make_tunnel_map_entry_params(bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni

    return map_entry


def bridge_vport_create_example(vlan, port1):
    log_vport_p_1 = new_sx_port_log_id_t_p()
    vport_add_delete(SX_ACCESS_CMD_ADD, port1, vlan, log_vport_p_1)
    log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
    print(("virtula port 0x%x created" % (log_vport_1)))

    # create bridge
    bridge_id_p = new_sx_bridge_id_t_p()
    bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
    bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
    print(("bridge %d created" % (bridge_id)))

    # add log_vport_1 to bridge
    bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
    print(("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id)))

    # set port state to UP
    port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_UP)

    add_ports_to_vlan(vlan, {PORT1: SX_UNTAGGED_MEMBER})

    return bridge_id, log_vport_1


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = False
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "
    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)
    created_flow_counters.append(counter_id)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


def destroy_flow_counter(counter_id, counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function destroys a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()
    sx_flow_counter_id_t_p_assign(counter_p, counter_id)

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_DESTROY, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy router counter"

    print("Destroyed flow counter %d, rc: %d" % (counter_id, rc))


def make_decap_key(key_type, vrid, dip="1.1.1.1", sip="1.1.1.100", tunnel_type=0):  # SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4):

    decap_key = sx_tunnel_decap_entry_key_t()
    decap_key.tunnel_type = tunnel_type
    decap_key.type = key_type
    decap_key.underlay_vrid = vrid
    decap_key.underlay_dip = make_sx_ip_addr_v4(dip)
    decap_key.underlay_sip = make_sx_ip_addr_v4(sip)

    return decap_key


""" ############################################################################################ """


def create_decap_rule_flow(handle, vrid, key_type, dip, sip, tunnel_id, tunnel_type):

    print("Create decap rule vrid : %d key_type : %d, tunnel : %d tunnel_type : %d dip : %s sip : %s" % (vrid, key_type, tunnel_id, tunnel_type, dip, sip))
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_key = make_decap_key(key_type, vrid, dip, sip, tunnel_type)
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    tunnel_decap_rule_create(handle, decap_key_p, decap_data_p)
    return (decap_key_p, decap_data_p)


def example_nve_decap_rules_flow(vrid, key_type, dip, sip, tunnel_id, tunnel_type, delete=0):
    print("Create decap rule vrid : %d key_type : %d, tunnel : %d tunnel_type : %d dip : %s sip : %s" % (vrid, key_type, tunnel_id, tunnel_type, dip, sip))
    c = create_flow_counter()
    decap_data = make_decap_data(tunnel_id, SX_ROUTER_ACTION_FORWARD, 0)
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()
    sx_tunnel_decap_entry_data_t_p_assign(decap_data_p, decap_data)

    decap_key_p = new_sx_tunnel_decap_entry_key_t_p()
    decap_key = make_decap_key(key_type, vrid, dip, sip, tunnel_type)
    sx_tunnel_decap_entry_key_t_p_assign(decap_key_p, decap_key)
    if delete == 0:
        rc = tunnel_decap_rule_create(decap_key_p, decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to create vxlan decap rule , rc: %d" % (rc)
    else:
        rc = tunnel_decap_rule_destroy(decap_key_p, decap_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete vxlan decap rule , rc: %d" % (rc)

    return (decap_key_p, decap_data_p)


#####################################################
    main
######################################################


created_flow_counters = []


def main():
    router_init()
    print("init")
    rc = example_tunnel_init_flow()
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)

    # create underlay vrid
    vrid = create_vrid()

    remove_ports_from_vlan(1, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(4, {PORT2: SX_TAGGED_MEMBER})
    port_rif = create_vlan_rif(vrid, 4, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07))
    set_rif_state_ipv4(port_rif)
    c1 = create_router_counter()
    bind_router_counter(c1, port_rif)

    log_port = NVE_PORT
    #################################
    ulay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID
    # ulay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF
    if ulay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF:
        # In spectrum2: user can configure underlay domain type rif and use encap and decap loopback rif.
        (loopback_ul_rif_encap, rc) = create_loopback_rif(vrid)
        assert rc == SX_STATUS_SUCCESS, "Failed to create loopback rif, rc: %d" % (rc)
        loopback_ul_rif_decap = loopback_ul_rif_encap
        rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid, log_port, SX_TUNNEL_DIRECTION_SYMMETRIC, "192.168.0.1", 255, ulay_domain_type, loopback_ul_rif_encap, loopback_ul_rif_decap)
    else:
        rc, tunnel_id = example_vxlan_tunnel_create_flow(vrid, log_port, SX_TUNNEL_DIRECTION_SYMMETRIC)

    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    # create bridge
    bridge_id, port1_vport = bridge_vport_create_example(20, PORT1)

    rc = tunnel_map_entry_process(tunnel_id, bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN, 5, 0)
    assert SX_STATUS_SUCCESS == rc, "Failed to add map entry, rc: %d" % (rc)

    # create bridge tunnel decap counter
    counter_id = create_flow_counter()
    counter_attr_decap_p = make_bridge_tunnel_counter_attr(tunnel_id, SX_BRIDGE_COUNTER_TUNNEL_DECAP_E)
    # bind counter
    rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_BIND, bridge_id, counter_attr_decap_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind tunnel bridge counter, rc: %d" % (rc)
    # get counter
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_bridge_tunnel_counter_bind_get(handle, bridge_id, counter_attr_decap_p, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get bound tunnel bridge counter, rc: %d" % (rc)
    counter_id_decap_read = sx_flow_counter_id_t_p_value(counter_p)
    assert counter_id == counter_id_decap_read, "Counter value missmatch"

    # create bridge tunnel encap UC counter
    counter_id = create_flow_counter()
    counter_attr_encap_uc_p = make_bridge_tunnel_counter_attr(tunnel_id, SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E)
    # bind counter
    rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_BIND, bridge_id, counter_attr_encap_uc_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind tunnel bridge counter, rc: %d" % (rc)
    # get counter
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_bridge_tunnel_counter_bind_get(handle, bridge_id, counter_attr_encap_uc_p, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get bound tunnel bridge counter, rc: %d" % (rc)
    counter_id_encap_uc_read = sx_flow_counter_id_t_p_value(counter_p)
    assert counter_id == counter_id_encap_uc_read, "Counter value missmatch"

    # create bridge tunnel encap MC counter
    counter_id = create_flow_counter()
    counter_attr_encap_mc_p = make_bridge_tunnel_counter_attr(tunnel_id, SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E)
    # bind counter
    rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_BIND, bridge_id, counter_attr_encap_mc_p, counter_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind tunnel bridge counter, rc: %d" % (rc)
    # get counter
    counter_p = new_sx_flow_counter_id_t_p()
    rc = sx_api_bridge_tunnel_counter_bind_get(handle, bridge_id, counter_attr_encap_mc_p, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get bound tunnel bridge counter, rc: %d" % (rc)
    counter_id_encap_mc_read = sx_flow_counter_id_t_p_value(counter_p)
    assert counter_id == counter_id_encap_mc_read, "Counter value missmatch"

    # decap rules
    example_nve_decap_rules_flow(vrid, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, "1.1.1.10", "1.1.1.100", tunnel_id, SX_TUNNEL_TYPE_NVE_VXLAN)

    # add static fdb
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 1)
    mac_addr = ether_addr("00:02:c9:11:ad:c1")

    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac_addr

    mac_entry.fid_vid = bridge_id
    mac_entry.log_port = log_port
    mac_entry.entry_type = SX_FDB_UC_STATIC
    mac_entry.action = SX_FDB_ACTION_FORWARD
    mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP

    mac_entry.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4("16.16.16.2")
    mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_addr
    mac_entry.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD

    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)

    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    # enable router interface and create route for encapsulated packet
    process_local_route(vrid, port_rif, "15.15.15.0", "255.255.255.0")
    process_local_route(vrid, port_rif, "16.16.16.0", "255.255.255.0")
    process_local_route(vrid, port_rif, "17.17.17.0", "255.255.255.0")
    process_local_route(vrid, port_rif, "18.18.18.0", "255.255.255.0")
    process_neigh(port_rif, "16.16.16.2", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc1))
    process_neigh(port_rif, "15.15.15.15", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2))
    process_neigh(port_rif, "17.17.17.17", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2))
    process_neigh(port_rif, "18.18.18.18", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2))

    # add mc container
    # container_id_p = new_sx_mc_container_id_t_p()
    # container_id_p = new_uint32_t_p()
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    mcc_attr = sx_mc_container_attributes_t()
    mcc_attr.type = SX_MC_CONTAINER_TYPE_NVE_FLOOD
    mcc_attr.min_mtu = 100
    mcc_attr.fid = bridge_id
    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mcc_attr)
    next_hop_list = new_sx_mc_next_hop_t_arr(3)
    next_hop = sx_mc_next_hop_t()
    next_hop.type = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP

    ip_addr = sx_ip_addr_t()
    ip_addr = make_sx_ip_addr_v4("15.15.15.15")
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 0, next_hop)

    ip_addr = make_sx_ip_addr_v4("17.17.17.17")
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 1, next_hop)

    ip_addr = make_sx_ip_addr_v4("18.18.18.18")
    next_hop.data.tunnel_ip.underlay_dip = ip_addr
    next_hop.data.tunnel_ip.tunnel_id = tunnel_id
    sx_mc_next_hop_t_arr_setitem(next_hop_list, 2, next_hop)

    count = 3
    container_id_p = new_sx_mc_container_id_t_p()
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, container_id_p, next_hop_list, count, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(container_id_p)
    print(("sx_api_mc_container_set id %x created with %d enties, rc: %d " % (mc_container_id, count, rc)))

    next_hop_cnt = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt, count)
    rc = sx_api_mc_container_get(handle, SX_ACCESS_CMD_GET, mc_container_id, next_hop_list, next_hop_cnt, mcc_attr_p)
    mc_attr = sx_mc_container_attributes_t()
    mc_attr = sx_mc_container_attributes_t_p_value(mcc_attr_p)
    print(("sx_api_mc_container_get attr from container %x: container type: %s, min_mtu - %d, fid - %d, rc: %d " %
           (mc_container_id, mc_attr.type, mc_attr.min_mtu, mc_attr.fid, rc)))

    # add flood entry
    rc = sx_api_fdb_flood_set(handle, SX_ACCESS_CMD_ADD, 0, bridge_id, mc_container_id)
    print(("sx_api_fdb_flood_set add to bridge %d mc_cont_id 1 rc: %d " % (bridge_id, rc)))

    # Set FDB limit to 0x10
    rc = sx_api_fdb_uc_limit_fid_set(handle, SX_ACCESS_CMD_SET, 0, bridge_id, 0x10)
    print(("sx_api_fdb_uc_limit_fid_set for bridge %d lfdb limit 0x10 rc: %d " % (bridge_id, rc)))

    # Set learning mode for tunnel logical port
    rc = sx_api_fdb_port_learn_mode_set(handle, log_port, SX_FDB_LEARN_MODE_AUTO_LEARN)
    print(("sx_api_fdb_port_learn_mode_set set autolearning for log_port 0x%x rc: %d " % (log_port, rc)))

    options = init_parser()

    if options.deinit:
        print("Clean Up")
        example_nve_decap_rules_flow(vrid, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP,
                                     "1.1.1.10", "1.1.1.100", tunnel_id, SX_TUNNEL_TYPE_NVE_VXLAN, 1)

        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_fdb_uc_mac_addr_set delete failed rc: %d " % (rc)

        rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, bridge_id, counter_attr_decap_p, counter_id_decap_read)
        assert SX_STATUS_SUCCESS == rc, "Failed to unbind tunnel bridge decap counter, rc: %d" % (rc)

        rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, bridge_id, counter_attr_encap_uc_p, counter_id_encap_uc_read)
        assert SX_STATUS_SUCCESS == rc, "Failed to unbind tunnel bridge encap uc counter, rc: %d" % (rc)

        rc = sx_api_bridge_tunnel_counter_bind_set(handle, SX_ACCESS_CMD_UNBIND, bridge_id, counter_attr_encap_mc_p, counter_id_encap_mc_read)
        assert SX_STATUS_SUCCESS == rc, "Failed to unbind tunnel bridge encap mc counter, rc: %d" % (rc)

        rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DELETE, container_id_p, next_hop_list, count, mcc_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_mc_container_set delete all failed, rc: %d " % (rc)

        rc = sx_api_fdb_flood_set(handle, SX_ACCESS_CMD_DELETE, 0, bridge_id, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "sx_api_fdb_flood_set delete failed, rc: %d " % (rc)

        rc = tunnel_map_entry_process(tunnel_id, bridge_id, SX_TUNNEL_TYPE_NVE_VXLAN, 5, 1)
        assert SX_STATUS_SUCCESS == rc, "Failed to delete map entry, rc: %d" % (rc)

        port_state_set(port1_vport, SX_PORT_ADMIN_STATUS_DOWN)
        bridge_vport_add_delete(SX_ACCESS_CMD_DELETE_ALL, bridge_id, PORT1)
        log_vport_p_1 = new_sx_port_log_id_t_p()
        vport_add_delete(SX_ACCESS_CMD_DELETE_ALL, PORT1, 20, log_vport_p_1)

        process_neigh(port_rif, "16.16.16.2", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc1), 1)
        process_neigh(port_rif, "15.15.15.15", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2), 1)
        process_neigh(port_rif, "17.17.17.17", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2), 1)
        process_neigh(port_rif, "18.18.18.18", ether_addr(0x00, 0x02, 0xc9, 0x11, 0xad, 0xc2), 1)
        process_local_route(vrid, port_rif, "15.15.15.0", "255.255.255.0", 1)
        process_local_route(vrid, port_rif, "16.16.16.0", "255.255.255.0", 1)
        process_local_route(vrid, port_rif, "17.17.17.0", "255.255.255.0", 1)
        process_local_route(vrid, port_rif, "18.18.18.0", "255.255.255.0", 1)
        delete_rif(vrid, port_rif)

        add_ports_to_vlan(1, {PORT2: SX_UNTAGGED_MEMBER})

        rc = example_tunnel_destroy_flow(tunnel_id)
        rc = tunnel_deinit()
        if ulay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF:
            # No need to delete loopback_ul_rif_decap since we set it to same value
            delete_rif(vrid, loopback_ul_rif_encap)

        for counter_id in created_flow_counters:
            destroy_flow_counter(counter_id)

        remove_ports_from_vlan(20, {PORT1: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(4, {PORT2: SX_TAGGED_MEMBER})
        bridge_id_p = copy_sx_bridge_id_t_p(bridge_id)
        bridge_create_delete(SX_ACCESS_CMD_DESTROY, bridge_id_p)
        delete_sx_bridge_id_t_p(bridge_id_p)
        delete_vrid(vrid)
        router_deinit()

    sx_api_close(handle)


if __name__ == "__main__":
    main()
