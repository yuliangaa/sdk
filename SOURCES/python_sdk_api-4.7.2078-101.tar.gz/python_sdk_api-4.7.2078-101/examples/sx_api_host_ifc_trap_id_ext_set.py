#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration using following APIs:
- sx_api_host_ifc_trap_group_ext_set
- sx_api_host_ifc_trap_id_ext_set
- sx_api_host_ifc_trap_id_register_set

Example below covers the following flow:
  1. Open File descriptor (user channel)
  2. Create trap gtroup
  3. Bind trap id to created trap group
  4. Register trap id to user channel
  5. De-register trap id
  6. Un-bind trap id from trap group
  7. Remove trap group
  8. Close File descriptor
'''
import sys
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_id_ext_set example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

SPECTRUM_SWID = 0


def host_ifc_open(handle):
    ''' Opening fd for traps '''
    trap_fd = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to open host_ifc trap_fd, rc=[%d] " % (rc)))
        sys.exit(rc)
    return trap_fd


def host_ifc_close(handle, fd):
    ''' Closing host ifc '''
    trap_fd = new_sx_fd_t_p()
    sx_fd_t_p_assign(trap_fd, fd)

    rc = sx_api_host_ifc_close(handle, trap_fd)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to close host_ifc trap_fd, rc=[%d] " % (rc)))
        sys.exit(rc)


def host_ifc_trap_group_handle(handle, cmd, trap_group):
    ''' SET or UNSET trap group '''
    trap_group_attr_p = new_sx_trap_group_attributes_t_p()
    trap_group_attr = sx_trap_group_attributes_t()
    trap_group_attr.prio = 1
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_group_attr.truncate_size = 0
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_group_attr.is_monitor = False
    trap_group_attr.trap_group = trap_group
    sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_group_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(rc)

    return sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group


def host_ifc_trap_id_set_handle(handle, cmd, trap_id, trap_group):
    ''' SET/UNSET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group

    if cmd == SX_ACCESS_CMD_SET:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU
    else:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_DISCARD

    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_ext_set failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(rc)


def host_ifc_trap_id_register_handle(handle, cmd, trap_id, user_channel, fd):
    ''' REGISTER/DEREGISTER trap id association to the relevant user channel '''
    user_channel_p = new_sx_user_channel_t_p()

    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t()
        user_channel.type = SX_USER_CHANNEL_TYPE_FD
        user_channel.channel.fd = copy_sx_fd_t_p(fd)

    sx_user_channel_t_p_assign(user_channel_p, user_channel)
    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, SPECTRUM_SWID, trap_id, user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    if cmd == SX_ACCESS_CMD_REGISTER:
        user_channel = sx_user_channel_t_p_value(user_channel_p)

    return user_channel


def trap_ext_configuration_example(handle, trap_id, trap_group):
    ''' Go through trap id full configuration and deconfiguration flows '''

    print("--- HOST IFC OPEN---------------------------------------")
    fd = host_ifc_open(handle)

    print("--- HOST IFC TRAP GROUP EXT SET  ---------------------------")
    trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    trap_group = host_ifc_trap_group_handle(handle, trap_group_set_cmd, trap_group)

    print("--- HOST IFC TRAP ID SET--------------------------------")
    host_ifc_trap_id_set_handle(handle, SX_ACCESS_CMD_SET, trap_id, trap_group)

    print("--- HOST IFC TRAP ID REGISTER --------------------------")
    user_channel = host_ifc_trap_id_register_handle(handle, SX_ACCESS_CMD_REGISTER, trap_id, None, fd)

    """ ############################################################################################ """
    print("--- SEND TRAFFIC WHICH WILL MATCH TO CONFIGURED TRAP ---")
    """ ############################################################################################ """

    if args.deinit:
        print("--- HOST IFC TRAP ID DEREGISTER ------------------------")
        host_ifc_trap_id_register_handle(handle, SX_ACCESS_CMD_DEREGISTER, trap_id, user_channel, None)

        print("--- HOST IFC TRAP ID UNSET------------------------------")
        host_ifc_trap_id_set_handle(handle, SX_ACCESS_CMD_UNSET, trap_id, trap_group)

        print("--- HOST IFC TRAP GROUP UNSET  -------------------------")
        host_ifc_trap_group_handle(handle, trap_group_unset_cmd, trap_group)

    print("--- HOST IFC CLOSE--------------------------------------")
    host_ifc_close(handle, fd)

    print("--- DONE -----------------------------------------------")


""" ############################################################################################ """
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    ''' Following routine contains full trap configuration and deconfiguration flow '''
    trap_id = SX_TRAP_ID_ETH_L3_MTUERROR
    trap_group = 12
    trap_ext_configuration_example(handle, trap_id, trap_group)

    sx_api_close(handle)
