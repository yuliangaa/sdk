#!/usr/bin/env python
'''
This file contains Python command example for the PORT DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''

oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}
admin_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 3: 'UP_ONCE'}
module_dict = {0: 'INITIALIZING', 1: 'PLUGGED', 2: 'UNPLUGGED', 3: 'PLUGGED-ERR', 4: 'PLUGGED-DIS', 5: 'UNKNOWN', 255: 'RESERVED'}
oper_speed_dict = {0: 'N/A', 1: '1GB_CX_SGMII', 2: '1GB_KX', 3: '10GB_CX4_XAUI', 4: '10GB_KX4', 5: '10GB_KR', 6: '20GB_KR2', 7: '40GB_CR4',
                   8: '40GB_KR4', 9: '56GB_KR4', 10: '56GB_KX4', 11: '10GB_CR', 12: '10GB_SR', 13: '10GB_ER_LR', 14: '40GB_SR4', 15: '40GB_LR4_ER4',
                   16: '100GB_CR4', 17: '100GB_SR4', 18: '100GB_KR4', 19: '100GB_LR4_ER4', 20: '25GB_CR', 21: '25GB_KR', 22: '25GB_SR', 23: '50GB_CR2',
                   24: '50GB_KR2', 25: '50GB_SR2', 26: '10MB', 27: '100MB', 28: 'Not Supported'}
fec_mode_dict = {0: 'Auto', 1: 'None', 2: 'FC', 4: 'RS', 8: 'LL_RS'}

oper_rate_dict = {0: "N/A",  # Not connected
                  1: "100M",
                  2: "1G",
                  3: "10G",
                  4: "25G",
                  5: "40G",
                  6: "50Gx1",
                  7: "50Gx2",
                  8: "100Gx2",
                  9: "100Gx4",
                  10: "200Gx4",
                  11: "400Gx8"}

import sys
import errno
import os
from test_infra_common import *
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import sxd_api_chip_type_rev_get as sxd_api_chip_type
import argparse

parser = argparse.ArgumentParser(description='sx_api_ports_mapping_dump example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


unsupported_phy_mode_devices = [SXD_MGIR_HW_DEV_ID_SX, SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]

# For the IB devices we shouldn't display some of the fields, since they are not applicable
ib_devices_list = [SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]

# For the IB devices we shouldn't display some of the fields, since they are not applicable
ib_devices_list = [SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2, SXD_MGIR_HW_DEV_ID_QUANTUM, SXD_MGIR_HW_DEV_ID_QUANTUM2, SXD_MGIR_HW_DEV_ID_QUANTUM3]

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


def port_speed_param_get(handle, log_port):
    admin_speed_p = new_sx_port_speed_capability_t_p()
    oper_speed_p = new_sx_port_oper_speed_t_p()
    oper_rate_p = new_sx_port_rate_t_p()
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    # retrieve the current verbosity level settings
    rc = sx_api_port_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Error: failed to retrieve the current verbosity setting!\n")
        sys.exit(rc)
    module_verbosity_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    api_verbosity_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    ''' Modify the port module verbosity level to hide additional log messages
        in case if different API type were used for port speed set and get.
    '''
    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_log_verbosity_level_set failed!\n")
        sys.exit(rc)

    # get the current port speed value
    rc = sx_api_port_speed_get(handle, int(port_attributes.log_port), admin_speed_p, oper_speed_p)
    if rc == SX_STATUS_SUCCESS:
        port_speed = oper_speed_dict[sx_port_oper_speed_t_p_value(oper_speed_p)]

    elif rc == SX_STATUS_CMD_UNPERMITTED:
        # looks like port was configured with the 'RATE'-type of API
        rc = sx_api_port_rate_get(handle, int(port_attributes.log_port), oper_rate_p)
        if rc == SX_STATUS_SUCCESS:
            port_speed = oper_rate_dict[sx_port_rate_t_p_value(oper_rate_p)]

    if rc != SX_STATUS_SUCCESS:
        port_speed = "N/A"
        print(("Error: something went wrong - can not retrieve the current port speed value, rc = %u.\n" % (rc)))
        sys.exit(rc)

    if args.deinit:
        # restore original verbosity setting
        rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level, api_verbosity_level)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_port_log_verbosity_level_set failed\n")
            sys.exit(rc)

    return port_speed


def port_swid_bind_get(handle, port):
    sx_swid_p = new_sx_swid_t_p()
    rc = sx_api_port_swid_bind_get(handle, port, sx_swid_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to bind port."
    swid = sx_swid_t_p_value(sx_swid_p)
    return swid


##################################################################################################################
max_mtu_size_p = new_sx_port_mtu_t_p()
oper_mtu_size_p = new_sx_port_mtu_t_p()
oper_state_p = new_sx_port_oper_state_t_p()
admin_state_p = new_sx_port_admin_state_t_p()
module_state_p = new_sx_port_module_state_t_p()
vid_p = new_sx_vid_t_p()
admin_speed_p = new_sx_port_speed_capability_t_p()
oper_speed_p = new_sx_port_oper_speed_t_p()
admin_mode_p = new_sx_port_phy_mode_t_p()
oper_mode_p = new_sx_port_phy_mode_t_p()

# Get ports count
port_cnt_p = new_uint32_t_p()
uint32_t_p_assign(port_cnt_p, 0)
port_attributes_list = new_sx_port_attributes_t_arr(0)
rc = sx_api_port_device_get(handle, 1, 253, port_attributes_list, port_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_device_get failed, rc = %d" % (rc))
    sys.exit(rc)
port_cnt = uint32_t_p_value(port_cnt_p)

# Get ports
port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
rc = sx_api_port_device_get(handle, 1, 253, port_attributes_list, port_cnt_p)
if (rc != SX_STATUS_SUCCESS):
    print("sx_api_port_device_get failed, rc = %d")
    sys.exit(rc)

print("=====================================================================================")
header = ["log_port", "local_port", "slot", "label_port", "mode", "width", "lane_bmap", "swid"]
print("|%10s|%10s|%4s|%10s|%10s|%6s|%10s|%5s|" %
      (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7]))
print("=====================================================================================")
device_id, device_hw_revision = sxd_api_chip_type.get_chip_type_and_rev()

# Check whether we are going to dump IB ports
is_ib = True if device_id in ib_devices_list else False

for i in range(0, port_cnt):

    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_vport = check_vport(int(port_attributes.log_port))
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_vport or is_cpu:
        continue
    swid = port_swid_bind_get(handle, port_attributes.log_port)
    log_port = "0x%x" % port_attributes.log_port
    lane_bmap = "0x%02X" % port_attributes.port_mapping.lane_bmap
    if port_attributes.port_mapping.mapping_mode == 1:
        module_port = port_attributes.port_mapping.module_port + 1
    else:
        module_port = 0
    if port_attributes.port_mapping.mapping_mode == 0:
        mode = "DISABLED"
    else:
        mode = "ENABLED"

    print("|%10s|%10d|%4d|%10d|%10s|%6s|%10s|%5d|" %
          (log_port,
           port_attributes.port_mapping.local_port,
           port_attributes.port_mapping.slot,
           module_port,
           mode,
           port_attributes.port_mapping.width,
           #             hex(port_attributes.port_mapping.lane_bmap),
           lane_bmap,
           swid))

print("=====================================================================================")
sx_api_close(handle)
