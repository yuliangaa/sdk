#!/usr/bin/env python
'''
This file contains Python command example that shows how to SET/GET the Parsing Depth .
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
.
This example is supported on Spectrum and later devices
Some key info about the Parsing depth and its implications on System Performance
* The parser hardware block parses the packet in real time and fills the internal packet
    descriptor.
* The larger the parsing depth the greater the information available
    about the incoming packet
* The default system value is 96 Bytes
* Note a typical L4 TCP packet requires 54 bytes. A VXLAN packet with an inner UDP packet
    is about 92 bytes of headers. Therefore the default value should handle most packets.
* Increasing the depth will allow greater deeper packet inspection. This is useful
    when the system needs to match custom bytes, inner TCP header fields,
    ACLs on inner data etc
* While this is useful for certain use cases , increasing the depth does increase the
    pipeline/processing latency marginally
'''
import sys
import errno
import sys
import colorsys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_parser_attr_set/get')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if rc != SX_STATUS_SUCCESS:
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

COMMON_PARSE_DEPTHS = [96, 128, 160]
####################################################################################
print("\n------- PORT PARSE DEPTH GET ------------")
####################################################################################
parse_attrs_p = new_sx_parser_attributes_t_p()
rc = sx_api_port_parser_attr_get(handle, parse_attrs_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parser_attr_get failed , rc=%d] " % (rc)))
    sys.exit(rc)

parse_attrs = sx_parser_attributes_t_p_value(parse_attrs_p)
print("\nCurrent Parsing Depth Configured = %d Bytes\n" % parse_attrs.parsing_depth)
print("Current L4 Header parse state = %s \n" % ('True' if parse_attrs.l4_raw_hdr_parse_en == 1 else 'False'))
parse_depth_initial = parse_attrs.parsing_depth
l4_raw_hdr_parse_initial = parse_attrs.l4_raw_hdr_parse_en

####################################################################################
print("------- PORT PARSE DEPTH SET ------------")
####################################################################################
new_parse_attrs_p = new_sx_parser_attributes_t_p()
new_parse_attrs = sx_parser_attributes_t()
new_parse_attrs.parsing_depth_valid = True
new_parse_attrs.l4_raw_parsing_valid = False
new_parse_attrs.parsing_depth = COMMON_PARSE_DEPTHS[0]
for new_parse_attrs.parsing_depth in COMMON_PARSE_DEPTHS:
    if new_parse_attrs.parsing_depth != parse_depth_initial:
        break

sx_parser_attributes_t_p_assign(new_parse_attrs_p, new_parse_attrs)
print("\nSetting new Parsing Depth = %d Bytes\n" % new_parse_attrs.parsing_depth)
rc = sx_api_port_parser_attr_set(handle, new_parse_attrs_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parser_attr_set API failed for %d bytes , rc=%d] " % (new_parse_attrs.parsing_depth, rc)))
    sys.exit(rc)

####################################################################################
print("------- GET PORT PARSE DEPTH AFTER SET ------------")
####################################################################################
rc = sx_api_port_parser_attr_get(handle, parse_attrs_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parser_attr_get failed , rc=%d] " % (rc)))
    sys.exit(rc)

parse_attrs = sx_parser_attributes_t_p_value(parse_attrs_p)
print("\nNew Parsing Depth Configured = %d Bytes\n" % parse_attrs.parsing_depth)
print("L4 Header parse state = %s \n" % ('True' if parse_attrs.l4_raw_hdr_parse_en == 1 else 'False'))


####################################################################################
print("------- SET L4 Raw parse enable ------------")
####################################################################################
new_parse_attrs.parsing_depth_valid = False
new_parse_attrs.l4_raw_parsing_valid = True
new_parse_attrs.l4_raw_hdr_parse_en = not l4_raw_hdr_parse_initial
sx_parser_attributes_t_p_assign(new_parse_attrs_p, new_parse_attrs)

rc = sx_api_port_parser_attr_set(handle, new_parse_attrs_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parser_attr_set API failed for %d bytes , rc=%d] " % (new_parse_attrs.parsing_depth, rc)))
    sys.exit(rc)


####################################################################################
print("------- GET PORT PARSE ATTR AFTER SET ------------")
####################################################################################
rc = sx_api_port_parser_attr_get(handle, parse_attrs_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parser_attr_get failed , rc=%d] " % (rc)))
    sys.exit(rc)

parse_attrs = sx_parser_attributes_t_p_value(parse_attrs_p)
print("\nCurrent Parsing Depth Configured = %d Bytes\n" % parse_attrs.parsing_depth)
print("New L4 Header parse state = %s \n" % ('True' if parse_attrs.l4_raw_hdr_parse_en == 1 else 'False'))


if args.deinit:
    ####################################################################################
    print("------- REVERT PORT ATTRIBUTES TO INITIAL VALUES ------------")
    ####################################################################################
    print("\nReverting Parsing Depth to %d Bytes\n" % parse_depth_initial)
    print("Reverting L4 Parse state  to %s \n" % ('True' if l4_raw_hdr_parse_initial == 1 else 'False'))
    new_parse_attrs.parsing_depth_valid = True
    new_parse_attrs.l4_raw_parsing_valid = True
    new_parse_attrs.parsing_depth = parse_depth_initial
    new_parse_attrs.l4_raw_hdr_parse_en = l4_raw_hdr_parse_initial
    sx_parser_attributes_t_p_assign(new_parse_attrs_p, new_parse_attrs)

    rc = sx_api_port_parser_attr_set(handle, new_parse_attrs_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_parser_attr_set API failed rc=%d] " % (rc)))
        sys.exit(rc)

    print("=================================================================")
    ####################################################################################

sx_api_close(handle)
####################################################################################
