#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration port state event delay flow.
'''

import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_state_event_delay_set')
    parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
    parser.add_argument('--log_port', type=auto_int, nargs='+', help='List of log port to set state event delay timers')
    parser.add_argument('--up_event_timeout', default="10", help='Port state event delay UP timeout - range [0-5000]')
    parser.add_argument('--down_event_timeout', default="10", help='Port state event delay DOWN timeout - range [0-5000]')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    return parser.parse_args()


def main():
    args = parse_args()

    if not args.force:
        test_infra_common.print_modification_warning()

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        log_port_list = args.log_port or mapPortAndInterfaces(handle, num_ports=1)

        port_state_delay_p = new_sx_port_state_delay_t_p()
        orig_port_state_delay_p = new_sx_port_state_delay_t_p()

        port_state_delay_p.up_event_timeout = int(args.up_event_timeout)
        port_state_delay_p.down_event_timeout = int(args.down_event_timeout)

        for port in log_port_list:

            rc = sx_api_port_state_event_delay_get(handle, port, orig_port_state_delay_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_state_event_delay_get returns rc:%d" % (rc)))
                sys.exit(rc)
            print(
                ("log_port:0x%x original state event delay timers: UP [%d] DOWN [%d]." % (
                    port, orig_port_state_delay_p.up_event_timeout, orig_port_state_delay_p.down_event_timeout)))

            print(("Setting log_port:0x%x state event delay timers: UP [%d] DOWN [%d]." % (
                port, port_state_delay_p.up_event_timeout, port_state_delay_p.down_event_timeout)))

            rc = sx_api_port_state_event_delay_set(handle, SX_ACCESS_CMD_SET, port, port_state_delay_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_state_event_delay_set returns rc:%d" % (rc)))
                sys.exit(rc)

            print(("rc %d , Setting log_port:0x%x state event delay timers: UP [%d] DOWN [%d]." % (
                rc, port, port_state_delay_p.up_event_timeout, port_state_delay_p.down_event_timeout)))

            rc = sx_api_port_state_event_delay_get(handle, port, port_state_delay_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Error: sx_api_port_state_event_delay_get returns rc:%d" % (rc)))
                sys.exit(rc)
            print(
                ("log_port:0x%x state event delay timers: UP [%d] DOWN [%d].\n" % (
                    port, port_state_delay_p.up_event_timeout, port_state_delay_p.down_event_timeout)))

            if args.deinit:
                rc = sx_api_port_state_event_delay_set(handle, SX_ACCESS_CMD_SET, port, orig_port_state_delay_p)
                if rc != SX_STATUS_SUCCESS:
                    print(("Error: sx_api_port_state_event_delay_set returns rc:%d" % (rc)))
                    sys.exit(rc)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
