#!/usr/bin/env python
'''
This file contains Python command example that shows how to SET/GET the Parsing Depth .
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
.
This example is supported on Spectrum and later devices
Some key info about the Parsing depth and its implications on System Performance
* The parser hardware block parses the packet in real time and fills the internal packet
    descriptor.
* The larger the parsing depth the greater the information available
    about the incoming packet
* The default system value is 96 Bytes
* Note a typical L4 TCP packet requires 54 bytes. A VXLAN packet with an inner UDP packet
    is about 92 bytes of headers. Therefore the default value should handle most packets.
* Increasing the depth will allow greater deeper packet inspection. This is useful
    when the system needs to match custom bytes, inner TCP header fields,
    ACLs on inner data etc
* While this is useful for certain use cases , increasing the depth does increase the
    pipeline/processing latency marginally
'''
import sys
import errno
import sys
import colorsys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_parse_depth')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if rc != SX_STATUS_SUCCESS:
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

COMMON_PARSE_DEPTHS = [96, 128, 160]
####################################################################################
print("\n------- PORT PARSE DEPTH GET ------------")
####################################################################################
parse_depth_p = new_uint16_t_p()
rc = sx_api_port_parsing_depth_get(handle, parse_depth_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parsing_depth_get failed , rc=%d] " % (rc)))
    sys.exit(rc)

parse_depth_initial = uint16_t_p_value(parse_depth_p)
print("\nCurrent Parsing Depth Configured = %d Bytes\n" % parse_depth_initial)

####################################################################################
print("------- PORT PARSE DEPTH SET ------------")
####################################################################################

new_parse_depth = COMMON_PARSE_DEPTHS[0]
for new_parse_depth in COMMON_PARSE_DEPTHS:
    if new_parse_depth != parse_depth_initial:
        break

print("\nSetting new Parsing Depth = %d Bytes\n" % new_parse_depth)
rc = sx_api_port_parsing_depth_set(handle, new_parse_depth)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parsing_depth_set API failed for %d bytes , rc=%d] " % (new_parse_depth, rc)))
    sys.exit(rc)

####################################################################################
print("------- GET PORT PARSE DEPTH AFTER SET ------------")
####################################################################################
new_parse_depth = 0
rc = sx_api_port_parsing_depth_get(handle, parse_depth_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parsing_depth_get failed , rc=%d] " % (rc)))
    sys.exit(rc)
new_parse_depth = uint16_t_p_value(parse_depth_p)
print(("\nNew Parsing Depth Configured = %d Bytes\n" % (new_parse_depth)))

####################################################################################
print("------- SET UNCONVENTIONAL PORT PARSE DEPTH  ------------")
####################################################################################
new_parse_depth = 100
print("\nSetting new Parsing Depth = %d Bytes\n" % new_parse_depth)
rc = sx_api_port_parsing_depth_set(handle, new_parse_depth)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parsing_depth_set API failed for %d bytes , rc=%d] " % (new_parse_depth, rc)))
    sys.exit(rc)

print("Success. Now lets read what was set")

rc = sx_api_port_parsing_depth_get(handle, parse_depth_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_port_parsing_depth_get failed , rc=%d] " % (rc)))
    sys.exit(rc)
new_parse_depth = uint16_t_p_value(parse_depth_p)
print(("\nNew Parsing Depth Configured = %d Bytes\n" % (new_parse_depth)))

if args.deinit:
    ####################################################################################
    print("------- REVERT PORT PARSE DEPTH TO INITIAL VALUE ------------")
    ####################################################################################
    print("\nReverting Parsing Depth to %d Bytes\n" % parse_depth_initial)
    rc = sx_api_port_parsing_depth_set(handle, parse_depth_initial)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_parsing_depth_set API failed for %d bytes , rc=%d] " % (new_parse_depth, rc)))
        sys.exit(rc)

    print("=================================================================")
    ####################################################################################

sx_api_close(handle)
####################################################################################
