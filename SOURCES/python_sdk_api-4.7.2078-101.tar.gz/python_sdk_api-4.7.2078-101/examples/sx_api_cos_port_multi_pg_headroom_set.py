#!/usr/bin/env python
'''
This file contains Python command example for configuration of multiple lossless priorities.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

In ROCE configurartion Priority 0 is lossy and Priority 1 is lossless
This script align all provided priorities INGRESS BUFFER configuration according to lossless Priority 1

Example to configure all priorities 2,3,4,5,6,7 (without prio 1) with the same configuration like priority 1 on logical port 0x10001:
sx_api_cos_port_multi_pg_headroom_example3.py --force --priolist 2 3 4 5 6 7 --log_port 0x10001

Example to configure all priorities 2,3,4,5,6,7 (without prio 3) with the same configuration like priority 1 on all ports:
sx_api_cos_port_multi_pg_headroom_example3.py --force --priolist 2 3 4 5 6 7 --log_port 0
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

shared_pool_direction_dict = {SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E: "INGRESS",
                              SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E: "EGRESS"}

shared_pool_mode_dict = {SX_COS_BUFFER_MAX_MODE_STATIC_E: "PERCENTAGE",
                         SX_COS_BUFFER_MAX_MODE_DYNAMIC_E: "DYNAMIC",
                         SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E: "CELLS"}


def cos_port_pg_buff_set(handle, log_port, pg, pool_id, lossy, size, xon=0, xoff=0):
    port_buffer_attr_cnt = 1
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(1)

    attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, 0)

    attr_item_min.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    attr_item_min.attr.ingress_port_pg_buff_attr.pg = pg
    attr_item_min.attr.ingress_port_pg_buff_attr.pool_id = pool_id
    attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy = lossy
    attr_item_min.attr.ingress_port_pg_buff_attr.xon = xon
    attr_item_min.attr.ingress_port_pg_buff_attr.xoff = xoff
    attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom = 0
    attr_item_min.attr.ingress_port_pg_buff_attr.size = size

    print("\nSetting Port 0x%x PG %d:" % (log_port, pg))
    print("type   = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E")
    print("size  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.size))
    print("PG    = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.pg))
    print("is_lossy (0=Lossless)  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy))
    print("Xon   = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.xon))
    print("Xoff  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.xoff))

    attr_item_min = sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, attr_item_min)

    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, port_buffer_attr_list_p, 1)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, log_port, 1, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def cos_port_pg_buff_get(handle, log_port, pg):
    port_sb_attr_cnt_p = new_uint32_t_p()

    port_sb_attr_cnt = 1
    uint32_t_p_assign(port_sb_attr_cnt_p, port_sb_attr_cnt)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)
    port_buffer_attr_item = new_sx_cos_port_buffer_attr_t_arr(1)
    port_buffer_attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pg = pg
    sx_cos_port_buffer_attr_t_arr_setitem(port_sb_attr_list, 0, port_buffer_attr_item)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)
    assert (port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))

    port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_sb_attr_list, 0)

    # PG_SIZE, PG_XON, PG_XOFF, LOSSY
    POOL_ID = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pool_id
    PG_SIZE = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.size
    IS_LOSSY = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.is_lossy
    PG_XON = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xon
    PG_XOFF = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xoff

    print("\nGetting Port 0x%x PG %d:" % (log_port, pg))
    print("type  = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E")
    print("pool_id = %d" % (POOL_ID))
    print("size    = %d" % (PG_SIZE))
    print("is_lossy= %d (0=Lossless) " % (IS_LOSSY))
    print("Xon     = %d" % (PG_XON))
    print("Xoff    = %d" % (PG_XOFF))

    return POOL_ID, PG_SIZE, IS_LOSSY, PG_XON, PG_XOFF


def cos_port_pg_shared_buff_get(handle, log_port, pg):
    count = 1
    port_shared_buffer_attr_cnt = new_uint32_t_p()
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)
    port_shared_buffer_attr_item = new_sx_cos_port_shared_buffer_attr_t_arr(1)
    uint32_t_p_assign(port_shared_buffer_attr_cnt, count)

    port_shared_buffer_attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg = pg
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, port_shared_buffer_attr_item)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_shared_buffer_attr_list_p, port_shared_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)
    print("sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc))

    attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, 0)
    POOL_ID = attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id
    MAX_MODE = attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode
    if MAX_MODE == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
        print("Max mode    = Dynamic")
        print("Max (Alpha) = %d" % (attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha))
        MAX = attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha
    else:
        print("Max mode    = Static")
        print("Max  = %d" % (attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size))
        MAX = attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size

    print("PG  = %d" % (attr_item.attr.ingress_port_pg_shared_buff_attr.pg))
    print("Pool id  = %d" % (POOL_ID))

    return POOL_ID, MAX_MODE, MAX


def cos_port_pg_shared_buff_set(handle, log_port, pg, pool_id, max_mode, max_value):

    print("\nSetting Port 0x%x PG %d shared buff:" % (log_port, pg))
    print("Pool id = %d" % (pool_id))
    if max_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
        print("Max mode    = Dynamic")
        print("Max (Alpha) = %d" % (max_value))
    else:
        print("Max mode    = Static")
        print("Max  = %d" % (max_value))

    count = 1
    port_shared_buffer_attr_cnt = count
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)
    port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t()

    port_shared_buffer_attr_item.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pg = pg
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id = pool_id
    port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode = max_mode
    if max_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
        ''' Dynamic '''
        port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha = max_value
    else:
        ''' Static '''
        port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size = max_value
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, port_shared_buffer_attr_item)
    rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, port_shared_buffer_attr_list_p, port_shared_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)


def cos_port_shared_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)
    assert (port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt


def cos_prio_to_pg_set(handle, log_port, prio, pg):
    # set Switch Priority To PG mapping so packet with correct pcp/dscp can enter the PG buffer and trigger pfc.
    prio_to_buff_p = new_sx_cos_port_prio_buff_t_p()
    rc = sx_api_cos_port_prio_buff_map_get(handle, log_port, prio_to_buff_p)
    if rc != SX_STATUS_SUCCESS:
        print(("ERROR at sx_api_cos_port_prio_buff_map_get [log_port=0x%x ] " % (log_port)))
        sys.exit(rc)

    sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, prio, pg)

    rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, log_port, prio_to_buff_p)
    if rc != SX_STATUS_SUCCESS:
        print(("ERROR at sx_api_cos_port_prio_buff_map_set [log_port=0x%x ] " % (log_port)))
        sys.exit(rc)

    print(("sx_api_cos_port_prio_buff_map_set [log_port=0x%x] prio %d to PG %d" % (log_port, prio, pg)))


def prio_to_pg(prio):
    '''
    In ROCE configuration Prio 3 by default mapped to PG 1
    So this function mapped :
    Prio 1 to PG 3
    For all other N , it will map Prio N to PG N
    '''
    pg = prio
    if prio == 3:
        pg = 1
    if prio == 1:
        pg = 3
    return pg

# set default configursation for priority 3 for debug purpose


def set_prio3_dbg_config(handle):
    log_port = 0x10001
    PRIO = 3
    PG = prio_to_pg(PRIO)
    POOL_ID = 0
    PG_SIZE = 200
    PG_XON = 4
    PG_XOFF = 4
    IS_LOSSY = 0  # 0 - lossless
    SHARED_POOL_ID = 0
    MAX_MODE = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E
    MAX = SX_COS_PORT_BUFF_ALPHA_8_E

    cos_port_pg_buff_set(handle, log_port, PG, POOL_ID, IS_LOSSY, PG_SIZE, PG_XON, PG_XOFF)
    cos_port_pg_shared_buff_set(handle, log_port, PG, SHARED_POOL_ID, MAX_MODE, MAX)
    # cos_prio_to_pg_set(handle, log_port, PRIO, PG)


def get_all_ports(handle):
    SWID = 0
    DEVICE_ID = 1
    ports_list = []
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, None, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(-1)
    port_cnt = uint32_t_p_value(port_cnt_p)
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, DEVICE_ID, SWID, port_attributes_list, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(-1)
    for i in range(port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
        is_vport = check_vport(int(port_attributes.log_port))
        is_nve = check_nve(int(port_attributes.log_port))
        is_cpu = check_cpu(int(port_attributes.log_port))
        if not is_nve and not is_vport and not is_cpu:
            ports_list.append(port_attributes.log_port)

    return ports_list


def reduce_pool_size(handle, pool_id, reduce_size):
    shared_pool_attr_p = new_sx_cos_pool_attr_t_arr(1)
    rc = sx_api_cos_shared_buff_pool_get(handle, pool_id, shared_pool_attr_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(-1)

    print(("sx_api_cos_shared_buff_pool_get [pool_id=%d , rc=%d] " % (pool_id, rc)))
    print("================================================================================================")

    pool_attr_item = sx_cos_pool_attr_t_arr_getitem(shared_pool_attr_p, 0)
    print(("[Pool ID: %d] Pool direction = %s" % (pool_id, shared_pool_direction_dict[pool_attr_item.pool_dir])))
    print(("[Pool ID: %d] Pool size  = %d" % (pool_id, pool_attr_item.pool_size)))
    print(("[Pool ID: %d] Pool mode  = %s" % (pool_id, shared_pool_mode_dict[pool_attr_item.mode])))

    if (pool_attr_item.pool_size - reduce_size) < 0:
        print("Pool ID %d is size if too small %d and can't be reduced by %d" % (pool_id, pool_attr_item.pool_size, reduce_size))
        sys.exit(-1)

    pool_attr_item.pool_size = pool_attr_item.pool_size - reduce_size

    pool_id_p = new_uint32_t_p()
    uint32_t_p_assign(pool_id_p, pool_id)
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr_item)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_EDIT, pool_attr_p, pool_id_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(-1)

    print(("sx_api_cos_shared_buff_pool_set [pool_id=%d , rc=%d] " % (shared_pool_id, rc)))
    print("================================================================================================")


######################################################
#    main
######################################################


def main():

    parser = argparse.ArgumentParser(description='SX-API sx_api_cos_port_multi_pg_headroom_example')
    parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Log port, 0 - for all ports')
    parser.add_argument('--priolist', default=[4, 5, 6, 7], nargs='+', type=int, help='A list of priorities, ex: --priolist 2 3 4')
    parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    parser.add_argument('--dbg_cfg', action='store_true', help='Initialize prio 3 with default ingress lossless buffer configuration')
    args = parser.parse_args()

    log_port = args.log_port
    priolist = args.priolist

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    # if specific log_port wasn't provided set the configuration for all ports
    set_all_ports = 0
    if args.log_port == 0:
        set_all_ports = 1

    # for debug purpose only , init priority 3 with default config
    dbg_cfg = 0
    if args.dbg_cfg:
        dbg_cfg = args.dbg_cfg

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    if set_all_ports:
        ports_list = get_all_ports(handle)
        REF_LOG_PORT = ports_list[0]
    else:
        ports_list = [log_port]
        REF_LOG_PORT = log_port

    # Save for later de-configuration
    original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all(handle, REF_LOG_PORT)
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(handle, REF_LOG_PORT)

    # In ROCE configuration Priority 3 is lossless by default
    # This script align all provided priorities INGRESS BUFFER configuration according to lossless Priority 3
    LOSSLESS_DEFAULT_PRIO = 3
    # to simulate ROCE configuration
    if dbg_cfg:
        set_prio3_dbg_config(handle)

    PG = prio_to_pg(LOSSLESS_DEFAULT_PRIO)
    POOL_ID, PG_SIZE, IS_LOSSY, PG_XON, PG_XOFF = cos_port_pg_buff_get(handle, REF_LOG_PORT, PG)
    SHARED_POOL_ID, MAX_MODE, MAX = cos_port_pg_shared_buff_get(handle, REF_LOG_PORT, PG)

    # default pool id 0 can't be changed, so adjust the size of all other pools
    # The adjustment will remove the size used for headrooms from pool size
    if POOL_ID != 0:
        reduce_size = PG_SIZE * len(priolist) * len(ports_list)
        reduce_pool_size(handle, POOL_ID, reduce_size)

    # Set port PG
    for log_port in ports_list:
        for PRIO in priolist:
            PG = prio_to_pg(PRIO)
            cos_port_pg_buff_set(handle, log_port, PG, POOL_ID, IS_LOSSY, PG_SIZE, PG_XON, PG_XOFF)
            cos_port_pg_shared_buff_set(handle, log_port, PG, SHARED_POOL_ID, MAX_MODE, MAX)
            cos_prio_to_pg_set(handle, log_port, PRIO, PG)

    if args.deinit:
        print("Deinit")
        for log_port in ports_list:
            rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list, original_port_buff_attr_cnt)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_cos_port_buff_type_set failed rc = %d" % (rc))
                sys.exit(rc)

            rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list,
                                                      original_port_sb_attr_cnt)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_cos_port_shared_buff_type_set failed rc = %d" % (rc))
                sys.exit(rc)

        for PRIO in priolist:
            cos_prio_to_pg_set(handle, log_port, PRIO, 0)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
