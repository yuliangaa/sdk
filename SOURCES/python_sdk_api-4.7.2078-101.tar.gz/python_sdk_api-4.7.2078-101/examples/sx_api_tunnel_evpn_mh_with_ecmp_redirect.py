#!/usr/bin/env python
"""

This file contains Python command example for ECMP Redirect feature which enables to redirect all entries from one ECMP to another.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

"""
import sys
import socket
import struct
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import time
import argparse

parser = argparse.ArgumentParser(description='sx_api_tunnel_evpn_mh_with_ecmp_redirect example')
parser.add_argument('--fdb', default="uc", choices=["uc", "mc"], help='Select the fdb you want to set. Default is "uc".')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

# string constants
TUNN_ID = "TUNN"
IP_STR = "IP"
WEIGHT_STR = "weight"
RIF_STR = "RIF"

######################################################
#    functions
######################################################


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 16
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router, rc: %d" % rc
    print("Init the router")


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router, rc: %d" % rc
    print("Deinit router")


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID, rc: %d" % rc
    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d" % vrid)

    return vrid


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)
    print("Removed %s port from vlan %d" % (str(list(ports_dict.keys())), vlan_id))


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc)
    print("Added %s port to vlan %d" % (str(list(ports_dict.keys())), vlan_id))


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif, rc: %d" % rc
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d" % rif)

    return rif


def example_tunnel_init_flow():

    general_param = make_tunnel_general_params()
    general_param.nve.flood_ecmp_enabled = True
    general_param.nve.mc_ecmp_enabled = True
    general_param.nve.ecmp_max_size = 16
    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_param)
    tunnel_init(general_param_p)


def make_tunnel_general_params():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = True
    general_params.nve.mc_ecmp_enabled = True
    general_params.nve.fdb_resolution_valid = False
    general_params.nve.fdb_resolution_action = SX_ROUTER_ACTION_MAX + 1

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    return general_params


def tunnel_init(tunnel_general_params):

    rc = sx_api_tunnel_init_set(handle, tunnel_general_params)
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % rc
    print("sx_api_tunnel_init_set")


def example_create_vxlan_tunnel_flow(vrid, log_port=NVE_PORT, direction=SX_TUNNEL_DIRECTION_SYMMETRIC,
                                     usip="192.168.0.1", underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID,
                                     encap_underlay_rif=0, decap_underlay_rif=0, tun_type=SX_TUNNEL_TYPE_NVE_VXLAN):
    underlay_sip = make_sx_ip_addr_v4(usip)
    tunnel_attribute = make_tunnel_attributes_vxlan(vrid, underlay_sip, direction, log_port, underlay_domain_type,
                                                    encap_underlay_rif, decap_underlay_rif, tun_type)
    tunnel_id = tunnel_create(tunnel_attribute)
    return tunnel_id


def make_tunnel_attributes_vxlan(vrid, underlay_sip, direction=SX_TUNNEL_DIRECTION_SYMMETRIC, log_port=NVE_PORT,
                                 underlay_domain_type=SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, encap_underlay_rif=0,
                                 decap_underlay_rif=0, tun_type=SX_TUNNEL_TYPE_NVE_VXLAN, tag_mode=SX_VLAN_TAG_MODE_802_1Q_E):
    tunnel_attribute = sx_tunnel_attribute_t()

    tunnel_attribute.type = tun_type
    tunnel_attribute.direction = direction

    # NVE - vxlan attributes
    tunnel_attribute.attributes.vxlan.encap.underlay_vrid = vrid
    tunnel_attribute.attributes.vxlan.encap.underlay_rif = encap_underlay_rif
    tunnel_attribute.attributes.vxlan.encap.underlay_sip = underlay_sip
    tunnel_attribute.attributes.vxlan.decap.underlay_rif = decap_underlay_rif
    tunnel_attribute.attributes.vxlan.nve_log_port = log_port
    tunnel_attribute.attributes.vxlan.underlay_domain_type = underlay_domain_type
    tunnel_attribute.attributes.vxlan.decap.tag_mode = tag_mode

    return tunnel_attribute


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def tunnel_create(tunnel_attribute):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_CREATE, tunnel_attribute, tunnel_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create tunnel, rc: %d" % rc

    tunnel_id = sx_tunnel_id_t_p_value(tunnel_id_p)
    print("Created tunnel: %d" % tunnel_id)
    return tunnel_id


def tunnel_destroy(tunnel_id):
    tunnel_id_p = new_sx_tunnel_id_t_p()
    sx_tunnel_id_t_p_assign(tunnel_id_p, tunnel_id)
    tunnel_attribute = sx_tunnel_attribute_t()
    rc = sx_api_tunnel_set(handle, SX_ACCESS_CMD_DESTROY, tunnel_attribute, tunnel_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy tunnel, rc: %d" % rc
    print("Destroyed tunnel: %d" % tunnel_id)


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_interface_state_set failed, rc: %d" % rc
    print("Delete RIF: %d" % rif)


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % rc
    print("sx_api_tunnel_deinit_set")


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d, rc: %d " % (vrid, rc)
    print("Deleted VRID: %d" % vrid)


def create_external_ecmp_container(nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container, rc: %d" % rc
    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    print("Created ECMP container ID %d" % ecmp_id)

    return ecmp_id


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        for key in nh:
            if key == TUNN_ID:
                next_hop = make_ecmp_next_hop_tunnel(nh[TUNN_ID], nh[IP_STR], nh[WEIGHT_STR])
            elif key == RIF_STR:
                next_hop = make_ecmp_next_hop_ip(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def make_ecmp_next_hop_tunnel(tunn_id, dst_ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
            This function creates ecmp_next_hop struct with given parametrs.
            action, counter_id and trap priority are optional.
    """
    address = make_sx_ip_addr_v4(dst_ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
    nh_key.next_hop_key_entry.ip_tunnel.underlay_dip = address
    nh_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunn_id

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def make_ecmp_next_hop_ip(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
        This function creates ecmp_next_hop struct with given parameters.
        action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def destroy_ecmp_container(ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d, rc: %d" % (ecmp_id, rc)
    print("Destroyed ECMP container ID %d" % ecmp_id)


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    # set rif2 state to ipv4 enable
    rif_state_2 = sx_router_interface_state_t()
    rif_state_2.ipv4_enable = enable
    rif_state_2.ipv6_enable = False
    rif_state_2.ipv4_mc_enable = False
    rif_state_2.ipv6_mc_enable = False
    rif_state_p_2 = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p_2, rif_state_2)
    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p_2)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_interface_state_set failed, rc: %d" % rc
    print("Set rif %d state" % rif)


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)
    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_uc_route_set failed, rc: %d" % rc
    print("Created local route for rif %d" % rif)


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_neigh_set failed, rc: %d" % rc
    print("Added neighbor to rif %d" % rif)


def set_ecmp_attributes(ecmp_id):
    "This function sets ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = SX_ECMP_TYPE_STATIC_E
    ecmp_attributes.container_type = SX_ECMP_CONTAINER_TYPE_NVE_MC
    ecmp_attributes.active_flow_timer = 100
    ecmp_attributes.group_size = 4096
    ecmp_attributes.max_unbalanced_time = 200000000
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)
    print("ecmp: %d attributes set" % ecmp_id)


def read_ecmp_attributes(ecmp_id):
    "This function reads ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_get(handle, ecmp_id, ecmp_attributes_p)
    ecmp_attributes = sx_ecmp_attributes_t_p_value(ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read ECMP %d attributes, rc: %d" % (ecmp_id, rc)
    print_ecmp_attributes(ecmp_id, ecmp_attributes)


def print_ecmp_attributes(ecmp_id, ecmp_attributes):
    print("####################################################################")
    print("Router ECMP ID  %d:\n" % (ecmp_id))

    print("ECMP type:                {:>10}".format(ecmp_attributes.ecmp_type))
    print("ECMP container_type:      {:>10}".format(ecmp_attributes.container_type))
    print("ECMP active_flow_timer:   {:>10}".format(ecmp_attributes.active_flow_timer))
    print("ECMP group_size:          {:>10}".format(ecmp_attributes.group_size))
    print("ECMP max_unbalanced_time: {:>10}".format(ecmp_attributes.max_unbalanced_time))
    print("####################################################################\n")


def modify_external_ecmp_container(handle, ecmp_id, nh_params_list=[]):

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify external ECMP container, rc: %d" % rc
    print("Modified ECMP container ID %d " % ecmp_id)


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh, rc: %d" % rc
    print("Deleted  neighbor from rif %d" % rif)


def delete_all_local_routes(handle, vrid):
    " This function deletes all local uc routes from given vrid. "

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)
    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_router_uc_route_set failed to all uc_routes, rc: %d" % rc
    print("Deleted all local UC routes")


def tunnel_map_entry_process(tunnel_id, bridge_id, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5, delete=0):
    map_entry = tunnel_map_entry_t_make(bridge_id, tunnel_type, vni)
    map_entry_p = new_sx_tunnel_map_entry_t_p()
    sx_tunnel_map_entry_t_p_assign(map_entry_p, map_entry)
    if delete == 0:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_ADD, tunnel_id, map_entry_p, 1)
    else:
        return sx_api_tunnel_map_set(handle, SX_ACCESS_CMD_DELETE, tunnel_id, map_entry_p, 1)


def tunnel_map_entry_t_make(bridge_id, tunnel_type, vni, direction=SX_TUNNEL_MAP_DIR_BIDIR):
    map_entry = sx_tunnel_map_entry_t()
    map_entry.type = tunnel_type
    map_entry.params.nve.bridge_id = bridge_id
    map_entry.params.nve.vni = vni
    map_entry.params.nve.direction = direction

    return map_entry


def vxlan_create_mac_entry(bridge_id, tunnel_id, mac_addr, u_dip, entry_type=SX_FDB_UC_REMOTE,
                           ecmp_id=None):
    mac_entry = sx_fdb_uc_mac_addr_params_t()
    mac_entry.mac_addr = mac_addr
    mac_entry.fid_vid = bridge_id
    mac_entry.entry_type = entry_type
    mac_entry.action = SX_FDB_ACTION_FORWARD
    ip_addr = sx_ip_addr_t()

    if ecmp_id is None:
        mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP

    if u_dip is not None:
        ip_addr = make_sx_ip_addr_v4(u_dip)

        mac_entry.dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP
        mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id
        mac_entry.dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip = ip_addr
        mac_entry.dest.next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD
    else:
        mac_entry.dest_type = SX_FDB_UC_MAC_ADDR_DEST_TYPE_ECMP_NEXT_HOP_CONTAINER
        mac_entry.dest.ecmp = ecmp_id

    return mac_entry


def tunnel_uc_fdb_set_flow(cmd, tunnel_id, bridge_id, mac_addr, u_dip=None,
                           entry_type=SX_FDB_UC_REMOTE, ecmp_id=None):
    if cmd == SX_ACCESS_CMD_ADD:
        print('Create UC fdb entry on tunnel %d, with key [%d, %s], to dip %s' % (
            tunnel_id, bridge_id, mac_addr.to_str(), u_dip))
    else:
        print('Delete UC fdb entry on tunnel %d, with key [%d, %s]' % (
            tunnel_id, bridge_id, mac_addr))

    mac_entry = vxlan_create_mac_entry(bridge_id, tunnel_id, mac_addr, u_dip, entry_type, ecmp_id)

    data_cnt_p = copy_uint32_t_p(1)
    mac_arr = new_sx_fdb_uc_mac_addr_params_t_arr(1)
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_arr, 0, mac_entry)

    rc = sx_api_fdb_uc_mac_addr_set(handle, cmd, 0, mac_arr, data_cnt_p)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ACCEPTED == rc, "sx_api_fdb_uc_mac_addr_set failed  rc: %d" % rc
    print('Created uc_fdb entry on tunnel %d' % tunnel_id)


def tunnel_mc_fdb_set_flow(cmd, mc_container_id, bridge_id, action, mac_addr):
    print("Set tunnel mc fdb entry. mc container id %d, fid %d and mac %s" % (
        mc_container_id, bridge_id, mac_addr.to_str()))
    mac_key = sx_fdb_mac_key_t()
    mac_data = sx_fdb_mac_data_t()
    mac_key.fid = bridge_id
    mac_key.addr = mac_addr
    mac_data.action = action
    mac_data.mc_container_id = mc_container_id

    mac_key_p = copy_sx_fdb_mac_key_t_p(mac_key)
    mac_data_p = copy_sx_fdb_mac_data_t_p(mac_data)
    rc = sx_api_fdb_mc_mac_addr_group_set(handle, cmd, mac_key_p, mac_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set mc_fdb flow, rc: %d" % rc
    print('Created mc_fdb entry on fid: %d' % bridge_id)


def destroy_mc_container(mc_container_id):
    mcc_attr = make_mc_container_attributes(0, 0, 0)
    mcc_attr_p = copy_sx_mc_container_attributes_t_p(mcc_attr)
    mc_container_id_p = copy_sx_mc_container_id_t_p(mc_container_id)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, mc_container_id_p, None, 0, mcc_attr_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete mc_container, rc: %d" % rc
    print('Destroyed MC container %d' % mc_container_id)


def create_mc_container(ecmp_id, fid=0, container_type=SX_MC_CONTAINER_TYPE_BRIDGE_MC, mtu=1522):

    next_hop_arr = new_sx_mc_next_hop_t_arr(1)
    next_hop_cnt = 1
    sx_mc_next_hop = sx_mc_next_hop_t()
    sx_mc_next_hop.type = SX_MC_NEXT_HOP_TYPE_ECMP
    sx_mc_next_hop.data.ecmp_id = ecmp_id
    sx_mc_next_hop_t_arr_setitem(next_hop_arr, 0, sx_mc_next_hop)

    mcc_attr = make_mc_container_attributes(fid, container_type, mtu)
    mcc_attr_p = copy_sx_mc_container_attributes_t_p(mcc_attr)
    mc_container_id_p = copy_sx_mc_container_id_t_p(0)
    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, mc_container_id_p, next_hop_arr, next_hop_cnt, mcc_attr_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create mc_container, rc: %d" % rc
    mc_container_id = sx_mc_container_id_t_p_value(mc_container_id_p)
    print("Created new MC Container, ID: %d" % mc_container_id)

    return mc_container_id


def make_mc_container_attributes(fid=1, container_type=SX_MC_CONTAINER_TYPE_BRIDGE_MC, mtu=1522):
    mc_container_attribute = sx_mc_container_attributes_t()

    mc_container_attribute.min_mtu = mtu
    mc_container_attribute.fid = fid
    mc_container_attribute.type = container_type

    return mc_container_attribute


def ecmp_redirect_set(cmd, ecmp, redirect_ecmp):
    rc = sx_api_router_ecmp_redirect_set(handle, cmd, ecmp, redirect_ecmp)
    assert SX_STATUS_SUCCESS == rc, "sx_api_ecmp_redirect_set failed, rc: %d" % rc
    print('ecmp redirect set ecmp_id: %d, redirected_ecmp: %d' % (ecmp, redirect_ecmp))


def ecmp_redirect_get(ecmp_id, expected_redirected, expected_ecmp):
    redirected_ecmp_p = new_sx_ecmp_id_t_p()
    is_redirected_p = new_boolean_t_p()
    rc = sx_api_router_ecmp_redirect_get(handle, ecmp_id, is_redirected_p, redirected_ecmp_p)
    assert SX_STATUS_SUCCESS == rc, "sx_api_ecmp_redirect_get failed, rc: %d" % rc
    is_redirected = boolean_t_p_value(is_redirected_p)
    redirected_ecmp = sx_ecmp_id_t_p_value(redirected_ecmp_p)
    print('ecmp redirect get is_redirected: %d, redirected_ecmp: %d' % (is_redirected, redirected_ecmp))
    assert bool(is_redirected) == expected_redirected or (expected_ecmp == redirected_ecmp)
    return bool(is_redirected), redirected_ecmp


######################################################
#    main
######################################################

def main():
    if args.fdb == "uc":
        ecmp_redirect(uc_fdb=True)
    else:
        ecmp_redirect(uc_fdb=False)

    sx_api_close(handle)


def ecmp_redirect(uc_fdb):

    ul_vlan = 4
    ol_vlan = 5
    URIF_1_MAC = ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07)
    MC_NEIGH_MAC_STR = "01:00:5e:00:01:20"
    MC_NEIGH_MAC = ether_addr(MC_NEIGH_MAC_STR)

    U_NEIGH_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x71)
    NEIGH_MAC = ether_addr(0xE4, 0x1D, 0x2D, 0xB4, 0x89, 0x72)

    u_neigh_ip = "1.1.1.20"
    u_neigh_2_ip = "1.1.1.30"
    u_neigh_3_ip = "1.1.1.40"
    unet_ip = "1.1.0.0"
    unet_mask = "255.255.0.0"

    # init router
    router_init()

    # create overlay and underlay vrids
    ul_vrid = create_vrid()

    # add port to vlan and create rif
    remove_ports_from_vlan(1, {PORT2: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ul_vlan, {PORT2: SX_TAGGED_MEMBER})
    port_rif_u = create_vlan_rif(ul_vrid, ul_vlan, URIF_1_MAC)

    remove_ports_from_vlan(1, {PORT1: SX_TAGGED_MEMBER})
    add_ports_to_vlan(ol_vlan, {PORT1: SX_TAGGED_MEMBER})

    create_local_route(ul_vrid, port_rif_u, unet_ip, unet_mask)
    add_neigh(port_rif_u, u_neigh_ip, U_NEIGH_MAC)

    # init tunnel
    example_tunnel_init_flow()

    # create vxlan tunnel
    tunnel_id = example_create_vxlan_tunnel_flow(ul_vrid)
    print("tunnel id = 0x%x" % tunnel_id)

    # create map_entry from vlan to vni
    tunnel_map_entry_process(tunnel_id, ol_vlan, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5, delete=0)

    # set rifs to UP state
    set_rif_state_ipv4(port_rif_u)

    # create empty next hops list and empty ECMP container
    next_hops_params_list = []
    ecmp_id = create_external_ecmp_container(next_hops_params_list)

    # set contaiter type to NVE MC
    set_ecmp_attributes(ecmp_id)
    read_ecmp_attributes(ecmp_id)

    # add tunnel to ECMP container
    next_hops_params_list.append({TUNN_ID: tunnel_id,
                                  IP_STR: u_neigh_ip,
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    print("Tunnel: 0x%x to container %d added" % (tunnel_id, ecmp_id))

    if uc_fdb:
        tunnel_uc_fdb_set_flow(SX_ACCESS_CMD_ADD, tunnel_id, ol_vlan, NEIGH_MAC, ecmp_id=ecmp_id)
    else:
        # set mc_fdb entry that points to ecmp_id
        mc_container_id = create_mc_container(ecmp_id, fid=ol_vlan)
        tunnel_mc_fdb_set_flow(SX_ACCESS_CMD_ADD, mc_container_id, ol_vlan, SX_FDB_ACTION_FORWARD, MC_NEIGH_MAC)

    print("Send traffic and expect that traffic will go through tunnel")

    # create another empty next hops list and empty ECMP container
    next_hops_params_list = []
    redirected_ecmp = create_external_ecmp_container(next_hops_params_list)

    # set contaiter type to NVE MC
    set_ecmp_attributes(redirected_ecmp)
    read_ecmp_attributes(redirected_ecmp)

    # add tunnel to redirected ECMP container
    next_hops_params_list.append({TUNN_ID: tunnel_id,
                                  IP_STR: u_neigh_2_ip,
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(handle, redirected_ecmp, next_hops_params_list)
    print("Tunnel: 0x%x to container %d added" % (tunnel_id, redirected_ecmp))

    print("perform ecmp_redirect from ecmp_id: %d to redirected_ecmp: %d" % (ecmp_id, redirected_ecmp))
    ecmp_redirect_set(SX_ACCESS_CMD_CREATE, ecmp_id, redirected_ecmp)

    print("Send traffic and expect that traffic will go through redirected ecmp to tunnel")

    # modfiy original ECMP container
    next_hops_params_list = []
    next_hops_params_list.append({TUNN_ID: tunnel_id,
                                  IP_STR: u_neigh_3_ip,
                                  WEIGHT_STR: 1})
    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)
    print("Tunnel: 0x%x to container %d added" % (tunnel_id, ecmp_id))

    print("Send traffic and expect that traffic will still go through redirected ecmp to tunnel")

    is_redirected, received_redirected_ecmp = ecmp_redirect_get(ecmp_id, expected_redirected=True, expected_ecmp=redirected_ecmp)
    print("ecmp_redirect_get: is_redirected: %s, received_redirected_ecmp: %d" % (is_redirected, received_redirected_ecmp))

    print("cancel ecmp_redirect from ecmp_id: %d to redirected_ecmp: %d" % (ecmp_id, redirected_ecmp))
    ecmp_redirect_set(SX_ACCESS_CMD_DESTROY, ecmp_id, redirected_ecmp)

    is_redirected, received_redirected_ecmp = ecmp_redirect_get(ecmp_id, expected_redirected=False, expected_ecmp=None)
    print("ecmp_redirect_get: is_redirected: %s, received_redirected_ecmp: %d" % (
        is_redirected, received_redirected_ecmp))

    print("Send traffic and expect that traffic will go through original ecmp with new next hops to tunnel")

    if args.deinit:
        # free resources
        if uc_fdb:
            tunnel_uc_fdb_set_flow(SX_ACCESS_CMD_DELETE, tunnel_id, ol_vlan, NEIGH_MAC, ecmp_id=ecmp_id)
        else:
            tunnel_mc_fdb_set_flow(SX_ACCESS_CMD_DELETE, mc_container_id, ol_vlan, SX_FDB_ACTION_FORWARD, MC_NEIGH_MAC)
            destroy_mc_container(mc_container_id)

        # destroy external ECMP container
        destroy_ecmp_container(redirected_ecmp)
        destroy_ecmp_container(ecmp_id)

        set_rif_state_ipv4(port_rif_u, False)

        # delete tunnel map entry
        tunnel_map_entry_process(tunnel_id, ol_vlan, tunnel_type=SX_TUNNEL_TYPE_NVE_VXLAN, vni=5, delete=1)

        # tunnel destroy
        tunnel_destroy(tunnel_id)

        delete_neigh(handle, port_rif_u, u_neigh_ip)
        delete_all_local_routes(handle, ul_vrid)

        # destroy rif
        delete_rif(ul_vrid, port_rif_u)

        # delete vrid
        delete_vrid(ul_vrid)

        # deinit router
        router_deinit()

        # deinit tunnel
        tunnel_deinit()

        remove_ports_from_vlan(ul_vlan, {PORT2: SX_TAGGED_MEMBER})
        remove_ports_from_vlan(ol_vlan, {PORT1: SX_TAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT1: SX_UNTAGGED_MEMBER})
        add_ports_to_vlan(1, {PORT2: SX_UNTAGGED_MEMBER})


if __name__ == "__main__":
    main()
