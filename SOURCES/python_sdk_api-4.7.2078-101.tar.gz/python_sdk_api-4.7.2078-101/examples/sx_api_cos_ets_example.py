#!/usr/bin/env python
'''
This file contains Python command example for the CoS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different CoS attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *


def get_all_cos_port_ets_element():
    element_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(element_cnt_p, 0)
    rc = sx_api_cos_port_ets_element_get(handle, PORT1, None, element_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    element_cnt = uint32_t_p_value(element_cnt_p)
    ets_p = new_sx_cos_ets_element_config_t_arr(element_cnt)
    rc = sx_api_cos_port_ets_element_get(handle, PORT1, ets_p, element_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return ets_p, element_cnt


""" ############################################################################################ """


def get_cos_port_ets_element(count):
    # sx_api_cos_port_ets_element_get 0x1002f 35
    """ COS PORT ETS ELEMENT GET"""
    print("-------------------- COS PORT ETS ELEMENT GET --------------------")

    element_count_p = new_uint32_t_p()
    """ Set cnt = 8 """
    uint32_t_p_assign(element_count_p, count)
    """ Get value from PTR """
    element_count = uint32_t_p_value(element_count_p)
    print(("element_count (returned from API = %d)" % (element_count)))

    ets_element_p = new_sx_cos_ets_element_config_t_arr(element_count)

    rc = sx_api_cos_port_ets_element_get(handle, PORT1, ets_element_p, element_count_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_cos_port_ets_element_get for log_port=0x%x " % (PORT1)))

    for i in range(0, element_count):
        ets_element = sx_cos_ets_element_config_t_arr_getitem(ets_element_p, i)

        print(("--------------> Element %d <--------------" % (i)))
        print(("element hierarchy  = %d " % (ets_element.element_hierarchy)))
        print(("element index      = %d " % (ets_element.element_index)))
        print(("element next index = %d " % (ets_element.next_element_index)))
        print(("min shaper enable  = %r " % (ets_element.min_shaper_enable)))
        print(("packets mode       = %r " % (ets_element.packets_mode)))
        print(("min shaper rate    = %d " % (ets_element.min_shaper_rate)))
        print(("max shaper enable  = %r " % (ets_element.max_shaper_enable)))
        print(("max shaper rate    = %d " % (ets_element.max_shaper_rate)))
        print(("dwrr enable        = %r " % (ets_element.dwrr_enable)))
        print(("dwrr               = %r " % (ets_element.dwrr)))
        print(("dwrr_weight        = %d " % (ets_element.dwrr_weight)))

    return ets_element_p,


""" ############################################################################################ """


def set_cos_port_ets_element(hierarchy, element_index, next_element_index,
                             min_shaper_enable, packets_mode,
                             min_shaper_rate, max_shaper_enable,
                             max_shaper_rate, dwrr_enable, dwrr,
                             dwrr_weight, count, profile_log_port=None):
    # sx_api_cos_port_ets_element_set 0x1002f SX_ACCESS_CMD_EDIT 0x1002f
    # [{3;0;0;0;0;0;1;2000000;0;0;0},{3;1;1;0;0;0;1;2000000;0;0;0},{3;2;2;0;0;0;1;2000000;0;0;0}] 3
    """ COS PORT ETS ELEMENT SET"""
    print("-------------------- COS PORT ETS ELEMENT SET --------------------")

    cmd = SX_ACCESS_CMD_ADD

    element_count_p = new_uint32_t_p()
    """ Set cnt = 3 """
    uint32_t_p_assign(element_count_p, count)
    """ Get value from PTR """
    element_count = uint32_t_p_value(element_count_p)
    print(("element_count (returned from API = %d)" % (element_count)))

    ets_element_p = new_sx_cos_ets_element_config_t_arr(element_count)

    for i in range(0, element_count):
        ets_element = sx_cos_ets_element_config_t_arr_getitem(ets_element_p, i)

        ets_element.element_hierarchy = hierarchy
        ets_element.element_index = element_index + i
        if hierarchy == 3:
            ets_element.next_element_index = next_element_index + i
        if hierarchy == 2:
            ets_element.next_element_index = next_element_index
        if hierarchy == 0:
            ets_element.next_element_index = next_element_index
        ets_element.min_shaper_enable = min_shaper_enable
        ets_element.packets_mode = packets_mode
        ets_element.min_shaper_rate = min_shaper_rate
        ets_element.max_shaper_enable = max_shaper_enable
        ets_element.max_shaper_rate = max_shaper_rate
        ets_element.dwrr_enable = dwrr_enable
        ets_element.dwrr = dwrr
        ets_element.dwrr_weight = dwrr_weight

        sx_cos_ets_element_config_t_arr_setitem(ets_element_p, i, ets_element)

    port = profile_log_port or PORT1

    rc = sx_api_cos_port_ets_element_set(handle, cmd, port, ets_element_p, element_count)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_cos_port_ets_element_set for log_port=0x%x " % (PORT1)))

    for i in range(0, element_count):
        ets_element = sx_cos_ets_element_config_t_arr_getitem(ets_element_p, i)

        print(("--------------> Element %d <--------------" % (i)))
        print(("element hierarchy  = %d " % (ets_element.element_hierarchy)))
        print(("element index      = %d " % (ets_element.element_index)))
        print(("element next index = %d " % (ets_element.next_element_index)))
        print(("min shaper enable  = %r " % (ets_element.min_shaper_enable)))
        print(("packets mode       = %r " % (ets_element.packets_mode)))
        print(("min shaper rate    = %d " % (ets_element.min_shaper_rate)))
        print(("max shaper enable  = %r " % (ets_element.max_shaper_enable)))
        print(("max shaper rate    = %d " % (ets_element.max_shaper_rate)))
        print(("dwrr enable        = %r " % (ets_element.dwrr_enable)))
        print(("dwrr               = %r " % (ets_element.dwrr)))
        print(("dwrr_weight        = %d " % (ets_element.dwrr_weight)))


""" ############################################################################################ """


def delete_cos_port_ets_element():
    # sx_api_cos_port_ets_element_set 0x1002f SX_ACCESS_CMD_DESTROY 0x1002f [] 0
    """ COS PORT ETS ELEMENT SET - DESTOY"""
    print("-------------------- COS PORT ETS ELEMENT SET - DESTROY --------------------")

    cmd = SX_ACCESS_CMD_DESTROY

    element_count_p = new_uint32_t_p()
    """ Set cnt = 0 """
    uint32_t_p_assign(element_count_p, 0)
    """ Get value from PTR """

    element_count = uint32_t_p_value(element_count_p)
    print(("element_count (returned from API = %d)" % (element_count)))

    ets_element_p = new_sx_cos_ets_element_config_t_arr(element_count)

    rc = sx_api_cos_port_ets_element_set(handle, cmd, PORT1, ets_element_p, element_count)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("sx_api_cos_port_ets_element_set - destroy for log_port=0x%x " % (PORT1)))


""" ############################################################################################ """


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='sx_api_cos_ets_example')
    parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    """ ############################################################################################ """
    port_list = mapPortAndInterfaces(handle)
    PORT1 = port_list[0]
    """ ############################################################################################ """

    #
    # Save current ets element for later de-configuration
    original_element, original_cnt = get_all_cos_port_ets_element()

    get_cos_port_ets_element(35)
    set_cos_port_ets_element(3, 0, 0, False, False, 0, True, 2000000, False, False, 0, 3)
    get_cos_port_ets_element(35)
    delete_cos_port_ets_element()
    get_cos_port_ets_element(35)
    set_cos_port_ets_element(2, 1, 0, False, False, 0, True, 0, True, True, 20, 5)
    get_cos_port_ets_element(35)
    delete_cos_port_ets_element()
    get_cos_port_ets_element(35)
    set_cos_port_ets_element(0, 0, 0, False, False, 0, False, 0, False, False, 0, 1)
    get_cos_port_ets_element(35)
    delete_cos_port_ets_element()
    get_cos_port_ets_element(35)

    if args.deinit:
        print("Deinit..")
        rc = sx_api_cos_port_ets_element_set(handle, SX_ACCESS_CMD_ADD, PORT1, original_element, original_cnt)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)
        print(("sx_api_cos_port_ets_element_set for log_port=0x%x " % (PORT1)))

    """ ############################################################################################ """
    sx_api_close(handle)
    """ ############################################################################################ """
