#!/usr/bin/env python

import sys
import time
import argparse
import glob
import sxd_api_chip_type_rev_get as sxd_api_chip_type
from python_sdk_api.sxd_api import *


def parse_arguments():
    parser = argparse.ArgumentParser("Example for getting switch fans RPM & Tempartures")
    parser.add_argument("-n", "--no_timeout",
                        dest="no_timeout",
                        action="store_true",
                        help="Run example until force stop (ctrl+c)")
    return parser.parse_args()


def main():
    comex_indicator = "/sys/devices/platform/mlxplat/mlxreg-io/hwmon/hwmon*/*comex*"
    device_id, _ = sxd_api_chip_type.get_chip_type_and_rev()
    if device_id not in [SXD_MGIR_HW_DEV_ID_SPECTRUM, SXD_MGIR_HW_DEV_ID_SWITCH_IB, SXD_MGIR_HW_DEV_ID_SWITCH_IB2] or \
            glob.glob(comex_indicator):
        print("This example supported only on SPC1 (None-Comex) or SIB/SIB2 Switches - Exiting")
        return 0

    args = parse_arguments()

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initializing register access.\nPlease check that SDK is running.")
        return rc

    print("[+] reading fan speed")
    mfsm = ku_mfsm_reg()
    mfsm.tacho = 9

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    mfcr = ku_mfcr_reg()
    sxd_access_reg_mfcr(mfcr, meta, 1, None, None)

    tacho_active_list = []
    # the total mfcr.tacho_active is 16 (bit) at most
    for i in range(16):
        if (1 << i) & mfcr.tacho_active:
            tacho_active_list.append(i)

    names = "\t".join(["Fan #{0}".format(x) for x in tacho_active_list])
    names += "\tTemp"
    print(names)

    fans = [ku_mfsm_reg() for _ in tacho_active_list]
    for x, y in enumerate(tacho_active_list):
        fans[x].tacho = y

    mtmp = ku_mtmp_reg()
    sxd_access_reg_mtmp(mtmp, meta, 1, None, None)

    while True:
        rpms = []
        for fan in fans:
            sxd_access_reg_mfsm(fan, meta, 1, None, None)
            rpms.append(str(fan.rpm))

        sxd_access_reg_mtmp(mtmp, meta, 1, None, None)
        rpms.append(str(mtmp.temperature * 0.125) + " C")
        sys.stdout.write("\t".join(rpms) + "\r")
        sys.stdout.flush()
        if not args.no_timeout:
            sys.stdout.write("\n")
            return 0
        time.sleep(1)

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        return rc


if __name__ == "__main__":
    sys.exit(main())
