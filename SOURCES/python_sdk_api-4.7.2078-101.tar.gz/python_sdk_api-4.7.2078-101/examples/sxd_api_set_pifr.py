#!/usr/bin/env python
from python_sdk_api.sx_api import *
import sys
import argparse
from python_sdk_api.sxd_api import *

"""
This example demonstrates set port->port isolation by sending PIFR EMAD.
EMAD's fields values are received as args or used default values.
"""

print("[+] initializing register access")
rc = sxd_access_reg_init(0, None, 4)
if (rc != SXD_STATUS_SUCCESS):
    print("[+] Failed to initializing register access.\nPlease check that SDK is running.")
    sys.exit(rc)

print("[+] Writing PIFR register:")
parser = argparse.ArgumentParser(description='PIFR write utility')
parser.add_argument("--port", default=1, type=int, help="local egress port number")
parser.add_argument("--table", default=0, type=int, help="Isolation table id. 0-GLOBAL, 1-BRIDGE_ONLY")
parser.add_argument("--in_port", default=1, type=int, help="Ingress local port number to isolate")
parser.add_argument("--en", default=1, type=int, help="'1' - isolate ingress local port, '0' - clear ingress port isolation")
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

meta = sxd_reg_meta_t()
meta.dev_id = 1

# Store original configuration (Used for deinit configuration )
original_pifr = ku_pifr_reg()
original_pifr.local_port = args.port
original_pifr.table_id = args.table
meta.access_cmd = SXD_ACCESS_CMD_GET
rc = sxd_access_reg_pifr(original_pifr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to read PIFR register, rc: %d" % (rc)

# Send new configuration
pifr = ku_pifr_reg()
pifr.local_port = args.port
pifr.table_id = args.table
ingress_port = args.in_port
isolation_en = args.en
uint8_t_arr_setitem(pifr.ports_bitmap, ingress_port, isolation_en)
uint8_t_arr_setitem(pifr.mask_bitmap, ingress_port, 1)
meta.access_cmd = SXD_ACCESS_CMD_SET
rc = sxd_access_reg_pifr(pifr, meta, 1, None, None)
assert rc == SXD_STATUS_SUCCESS, "Failed to write PIFR register, rc: %d" % rc

print("[+] Finished example write PIFR register:")
print("[+] Egress port #{}, {} isolation table, Ingress port #{} isolation {}".format
      (pifr.local_port, 'BRIDGE_ONLY' if pifr.table_id else 'GLOBAL', ingress_port, 'enable' if isolation_en else 'clear'))

# Restore configuration that made during this example
if args.deinit:
    uint8_t_arr_setitem(original_pifr.mask_bitmap, ingress_port, 1)
    rc = sxd_access_reg_pifr(original_pifr, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to write PIFR register, rc: %d" % (rc)

rc = sxd_access_reg_deinit()
if rc != SXD_STATUS_SUCCESS:
    print("sxd_access_reg_deinit failed; rc=%d" % (rc))
    sys.exit(rc)
