#!/usr/bin/env python
'''
This file contains Python command example for controlling log verbosity
level of different SDK modules.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1
EXAMPEL_DEFAULT_VERBOSITY = 'error'

######################################################
#    Local Functions
######################################################


def system_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_system_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_system_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New System Wide Log verbosity level = %d" % log_level))


def acl_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Acl Log verbosity level = %d" % log_level))


def bfd_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_bfd_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_bfd_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Bfd Log verbosity level = %d" % log_level))


def bridge_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_bridge_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_bridge_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Bridge Log verbosity level = %d" % log_level))


def cos_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_cos_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Cos Log verbosity level = %d" % log_level))


def cos_redecn_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_cos_redecn_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)  # todo rename acc to api naming convention
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_redecn_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Cos Redecn Log verbosity level = %d" % log_level))


def fdb_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_fdb_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Fdb Log verbosity level = %d" % log_level))


def flex_parser_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_flex_parser_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Flex Parser Log verbosity level = %d" % log_level))


def flow_cntr_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_flow_counter_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_flow_counter_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Flow Counter Log verbosity level = %d" % log_level))


def host_ifc_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_host_ifc_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New host Ifc Log verbosity level = %d" % log_level))


def issu_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_issu_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_issu_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Issu Log verbosity level = %d" % log_level))


def lag_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_lag_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Lag Log verbosity level = %d" % log_level))


def mc_cont_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_mc_container_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mc_container_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New MC Container Log verbosity level = %d" % log_level))


def mpls_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_mpls_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mpls_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Mpls Log verbosity level = %d" % log_level))


def mstp_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_mstp_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_mstp_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Mstp Log verbosity level = %d" % log_level))


def policer_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_policer_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_policer_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Policer Log verbosity level = %d" % log_level))


def port_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_port_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Port Log verbosity level = %d" % log_level))


def ptp_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_ptp_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_ptp_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Ptp Log verbosity level = %d" % log_level))


def router_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_router_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_router_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Router Log verbosity level = %d" % log_level))


def span_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_span_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_span_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Span Log verbosity level = %d" % log_level))


def telemetry_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_tele_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tele_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Telemetry Log verbosity level = %d" % log_level))


def topology_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_topo_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_topo_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Topology Log verbosity level = %d" % log_level))


def tunnel_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_tunnel_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Tunnel Log verbosity level = %d" % log_level))


def vlan_verbosity_set(log_level=SX_VERBOSITY_LEVEL_NOTICE):
    rc = sx_api_vlan_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_MODULE, log_level, SX_VERBOSITY_LEVEL_NOTICE)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_log_verbosity_level_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    print(("New Vlan Log verbosity level = %d" % log_level))


def getCmdLineOptions(args):

    parser = argparse.ArgumentParser(description="Set Log Verbosity levels for SDK Modules.")
    parser.add_argument('-m', dest='module', choices=list(sdk_module_dict.keys()), default='system', help='specify module to set Log Level of')
    parser.add_argument('-l', dest='level', choices=list(log_verbosity_level.keys()), default=EXAMPEL_DEFAULT_VERBOSITY, help='Log Verbosity Level')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    options = parser.parse_args()
    return options


def usage():
    print("usage: sx_api_sdk_module_log_verbosity_set.py \n-[h ]print this help")
    print(("-m [ " + '{}'.format(', '.join(x for x in list(sdk_module_dict.keys()))) + ' ]'))
    print(("-l [ " + '{}'.format(', '.join(x for x in list(log_verbosity_level.keys()))) + ' ]'))


######################################################
#    Local Data Structures
######################################################
sdk_module_dict = {
    'system': system_verbosity_set,
    'acl': acl_verbosity_set,
    'bfd': bfd_verbosity_set,
    'bridge': bridge_verbosity_set,
    'cos': cos_verbosity_set,
    'redecn': cos_redecn_verbosity_set,
    'fdb': fdb_verbosity_set,
    'flex_parser': flex_parser_verbosity_set,
    'flow_counter': flow_cntr_verbosity_set,
    'host_ifc': host_ifc_verbosity_set,
    'issu': issu_verbosity_set,
    'lag': lag_verbosity_set,
    'mc_cont': mc_cont_verbosity_set,
    'mpls': mpls_verbosity_set,
    'mstp': mstp_verbosity_set,
    'policer': policer_verbosity_set,
    'port': port_verbosity_set,
    'ptp': ptp_verbosity_set,
    'router': router_verbosity_set,
    'span': span_verbosity_set,
    'tele': telemetry_verbosity_set,
    'topo': topology_verbosity_set,
    'tunnel': tunnel_verbosity_set,
    'vlan': vlan_verbosity_set,
}
# *********************************************
#            main                            *
# *********************************************
print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

options = getCmdLineOptions(sys.argv)
module = options.module
log_level = options.level

if (module is None) or (log_level is None):
    print("insufficient parameters.")
    print(usage())
else:
    sdk_module_dict[module](log_verbosity_level[log_level])

    if options.deinit:
        sdk_module_dict[module](log_verbosity_level[EXAMPEL_DEFAULT_VERBOSITY])

sx_api_close(handle)
