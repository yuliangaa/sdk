#!/usr/bin/env python
"""
Example detailed description

#inputes :
#ecmp_id   SX_ARN_STATE_HOLD_AFTER_CHANGE_E/ SX_ARN_STATE_RECEIVED_E /SX_ARN_STATE_IDLE_E
#profile ID   -  SX_AR_PROFILE_0_E/ SX_AR_PROFILE_1_E


#The script will print :
# -----------------------------------------------------------------------------------------
#| entry num | profile ID         | ARN status                           | cur egress port |
#------------------------------------------------------------------------------------------
#|    1      | SX_AR_PROFILE_0_E  |  SX_ARN_STATE_HOLD_AFTER_CHANGE_E    | 0x10001         |
#-------------------------------------------------------------------------------------------
#|    2      | SX_AR_PROFILE_0_E  |  SX_ARN_STATE_IDLE_E                 | 0x10001         |
#-------------------------------------------------------------------------------------------

"""

import os
import sys
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *        # Needed only when using SXD_APIs in the examples
import test_infra_common
import argparse


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    # Description str can be same as header in lines 2-4: It will be printed to user when doing <py_example>.py --help
    description_str = """
    This API prints the entries of the AR flow table associated with the given ECMP ID and profile ID
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument('--ecmp_id', type=int, default=1, help='ECMP ID (e.g., 6)')
    parser.add_argument('--profile_id', type=int, default=1,
                        help='Profile ID (1 for profile 0 , 2 for profile 1)')
    return parser.parse_args()


def print_table(data):
    # Dictionary to translate numerical profile IDs to their corresponding string values
    profile_translation = {1: 'SX_AR_PROFILE_0_E', 2: 'SX_AR_PROFILE_1_E'}

    # Dictionary to translate numerical ARN states to their corresponding string values
    arn_state_translation = {
        0: 'SX_ARN_STATE_IDLE_E',
        1: 'SX_ARN_STATE_RECEIVED_E',
        3: 'SX_ARN_STATE_HOLD_AFTER_CHANGE_E'
    }

    # Print the header
    headers = ['Serial No.', 'Profile ID', 'ARN State', 'Log Port (Hex)']
    header_format = '{:<10} | {:<15} | {:<30} | {:<15}'
    print(header_format.format(*headers))

    # Calculate the length of the separator based on the formatted header
    separator_length = len(header_format.format(*headers))
    print('-' * separator_length)

    # Print each row with a serial number
    for i, row in enumerate(data, start=1):
        profile_string = profile_translation.get(row[0], 'Unknown Profile')  # Translate the profile ID
        arn_state_string = arn_state_translation.get(row[1], 'Unknown ARN State')  # Translate the ARN State
        log_port_hex = format(row[2], 'X')  # Convert log port to hexadecimal
        # Print with '|' as column separators
        print(header_format.format(i, profile_string, arn_state_string, log_port_hex))
        # Print a separator line of the same length as the row
        print('-' * separator_length)


def main():
    args = parse_args()     # Parse given arguments

    # For SWID = 0, One can use SPECTRUM_SWID Defined in test_infra_common directly, or by assigning it to local const
    SWID = test_infra_common.SPECTRUM_SWID

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

     # Get original verbosity
    module_verbosity_level_p = new_sx_verbosity_level_t_p()
    api_verbosity_level_p = new_sx_verbosity_level_t_p()

    rc = sx_api_ar_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, module_verbosity_level_p, api_verbosity_level_p)
    if rc != SX_STATUS_SUCCESS:
        print("Failed to retrieve adaptive routing Module current verbosity setting!")
        sys.exit(rc)

    orig_module_level = sx_verbosity_level_t_p_value(module_verbosity_level_p)
    orig_api_level = sx_verbosity_level_t_p_value(api_verbosity_level_p)

    rc = sx_api_ar_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    if rc != SX_STATUS_SUCCESS:
        print("Fail to set adaptive routing API log verbosity level")
        sys.exit(rc)

    # read ARFT info
    cmd = SX_ACCESS_CMD_READ
    flow_status_key = sx_arn_flow_status_key_t()
    flow_status_key.type = SX_ARN_FLOW_STATUS_KEY_ECMP_E
    flow_status_key.key.ecmp_key.profile_id = args.profile_id
    flow_status_key.key.ecmp_key.ecmp_id = args.ecmp_id
    flow_status_key_p = new_sx_arn_flow_status_key_t_p()
    sx_arn_flow_status_key_t_p_assign(flow_status_key_p, flow_status_key)
    flow_status_data = sx_arn_flow_status_data_t()
    flow_status_data_p = new_sx_arn_flow_status_data_t_p()
    sx_arn_flow_status_data_t_p_assign(flow_status_data_p, flow_status_data)
    rc = sx_api_ar_arn_flow_status_get(handle, cmd,
                                       flow_status_key_p,
                                       flow_status_data_p)

    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("AR module is uninitialized")
            sx_api_close(handle)
            print("API handle closed")
            sys.exit(0)
        print(("sx_api_ar_arn_flow_status_get failed, [cmd = %d, rc = %d]" % (cmd, rc)))
        sys.exit(rc)

    actual_data = sx_arn_flow_status_data_t_p_value(flow_status_data_p)
    table_size = actual_data.flow_status_cnt
    arft = []
    for i in range(table_size):
        arft_entry = []
        flow_entry = sx_arn_flow_entry_status_t_arr_getitem(actual_data.flow_status_list_p, i)
        arft_entry.append(flow_entry.profile_id)
        arft_entry.append(flow_entry.current_arn_state)
        arft_entry.append(flow_entry.current_egress_log_port)
        arft.append(arft_entry)

    print_table(arft)

    try:
        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
            print("This example doesn't support SPC1 Example - Exiting gracefully")
            sys.exit(0)

        print("SUCCESS")
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
