#!/usr/bin/env python
'''
This example shows how to read SPMS_V2 configuration.
'''

import sys
import argparse

from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib

spms_states_dict = {0x1: "DISCARDING",
                    0x2: "LEARNING",
                    0x3: "FORWARDING"}


def get_and_parse_spms_v2(spms_v2, meta, states):
    rc = sxd_access_reg_spms_v2(spms_v2, meta, 1, None, None)
    if rc != SXD_STATUS_SUCCESS:
        raise RuntimeError("Failed to get SPMS_V2 register, rc: %d" % (rc))

    for idx in range(spms_v2.num_rec):
        vlan_record = sxd_spms_v2_vid_record_t_arr_getitem(spms_v2.vid_record, idx)
        states[vlan_record.vid] = vlan_record.state

    return states


def read_spms_v2(log_port, vlans):
    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET

    spms_v2 = ku_spms_v2_reg()

    local_port = common_lib.get_local_port(log_port)
    spms_v2.local_port, spms_v2.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    states = {}
    spms_v2.num_rec = 0

    for vlan in vlans:
        vlan_record = sxd_spms_v2_vid_record_t()
        vlan_record.vid = vlan

        sxd_spms_v2_vid_record_t_arr_setitem(spms_v2.vid_record, spms_v2.num_rec, vlan_record)
        spms_v2.num_rec += 1

        if spms_v2.num_rec == SXD_SPMS_V2_VID_RECORD_NUM:
            get_and_parse_spms_v2(spms_v2, meta, states)
            spms_v2.num_rec = 0

    if spms_v2.num_rec > 0:
        get_and_parse_spms_v2(spms_v2, meta, states)

    return states


def print_spms_states(log_port, states):
    print("Logical port: 0x{:x} ({:d})".format(log_port, log_port))
    for k, v in states.items():
        print("\tVLAN: {} - {}".format(k, spms_states_dict[v]))


def main():
    print("[+] Read SPMS_V2 register")

    parser = argparse.ArgumentParser(description='SPMS_V2 read utility')
    parser.add_argument('--log_port', default=0x10001, type=common_lib.auto_int, help='Logical port ID')
    parser.add_argument('--all_vlans', action='store_true', help='Get STP states on all VLANs')
    parser.add_argument('--vlan', default=1, type=int, help="Get the STP state for given VLAN")

    args = parser.parse_args()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        return rc

    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if rc != SXD_STATUS_SUCCESS:
        print("Failed to initialize register access.\nPlease check that SDK is running.\n")
        sx_api_close(handle)
        return rc

    try:
        if args.all_vlans:
            vlans = [vid for vid in range(1, 4096)]
        else:
            vlans = [args.vlan]
        states = read_spms_v2(args.log_port, vlans)
        print_spms_states(args.log_port, states)
    finally:
        sx_api_close(handle)
        sxd_access_reg_deinit()

    print("[+] Done")
    return 0


if __name__ == '__main__':
    sys.exit(main())
