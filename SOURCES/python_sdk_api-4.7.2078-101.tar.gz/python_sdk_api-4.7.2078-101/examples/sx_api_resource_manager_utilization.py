#!/usr/bin/env python
'''
This file contains Python command example for the RM module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

need to add description
'''
import sys
import struct
import socket
import argparse
from python_sdk_api.sx_api import *
from python_sdk_api import sxd_api

import sx_api_router
from test_infra_common import *
from common_infra_acl import *
from sx_api_resource_manager_apis import *

parser = argparse.ArgumentParser(description='sx_api_resource_manager_utilization_example')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################

port_list = mapPortAndInterfaces(sx_api_router.handle)
chip_type = 0
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]
DONT_CARE_RIF = 1001
# certain resources cannot be initialized because they are not legacy resources that do not exist in SPC
# so when trying to get free entry count of those resources error are generated therefore we query only for resources that exist in SPC
EXAMPLE_RESOURCES = [RM_SDK_TABLE_TYPE_UC_MAC_E, RM_SDK_TABLE_TYPE_MC_MAC_E, RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E,
                     RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E, RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E, RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E,
                     RM_SDK_TABLE_TYPE_ARP_IPV4_E, RM_SDK_TABLE_TYPE_ARP_IPV6_E, RM_SDK_TABLE_TYPE_ADJACENCY_E,
                     RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E, RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E, RM_SDK_TABLE_TYPE_ACL_PBS_E,
                     RM_SDK_TABLE_TYPE_ERIF_LIST_E, RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, RM_SDK_TABLE_TYPE_VLAN_E,
                     RM_SDK_TABLE_TYPE_VPORTS_E, RM_SDK_TABLE_TYPE_FID_E, RM_SDK_TABLE_TYPE_VNI_E, RM_SDK_TABLE_TYPE_ACL_E,
                     RM_SDK_TABLE_TYPE_RIPS_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV4_E, RM_SDK_TABLE_TYPE_IGMP_V3_IPV6_E,
                     RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E, RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E, RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E,
                     RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E, RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E,
                     RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E, RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, RM_SDK_TABLE_TYPE_ACL_GROUPS_E]

######################################################
#    Functions API
######################################################


def prepare_vlan_rif(vrid, port, vlan, mac, mtu=1500):
    sx_api_router.add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})
    rif = sx_api_router.create_vlan_rif(vrid, vlan, mac, mtu)
    return rif


def destroy_vlan_rif(vrid, port, vlan, rif):
    sx_api_router.delete_rif(vrid, rif)
    sx_api_router.remove_ports_from_vlan(vlan, {port: SX_TAGGED_MEMBER})


def make_ipv4_mc_route_key(ingress_rif, s_addr, s_mask, g_addr, g_mask):
    mc_route_key = sx_mc_route_key_t()
    mc_route_key.source_addr = sx_api_router.make_sx_ip_prefix_v4(s_addr, s_mask)
    mc_route_key.mc_group_addr = sx_api_router.make_sx_ip_prefix_v4(g_addr, g_mask)
    mc_route_key.ingress_rif = ingress_rif
    return mc_route_key


def make_mc_route_attributes(rpf_action=SX_ROUTER_RPF_ACTION_DISABLED,
                             ttl_cmd=SX_ROUTE_TTL_CMD_DEC,
                             ttl_val=0,
                             prio_type=SX_PRIO_TYPE_MANUAL,
                             manual_prio=1,
                             rpf_group_id=0):
    mc_attr = sx_mc_route_attributes_t()
    mc_attr.rpf_action = rpf_action
    mc_attr.ttl_cmd = ttl_cmd
    mc_attr.ttl_val = ttl_val
    mc_attr.prio.type = prio_type
    mc_attr.prio.manual_prio = manual_prio
    mc_attr.rpf_group_id = rpf_group_id
    return mc_attr


def add_mc_route(vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_ADD,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add MC route to VRID %d, rc: %d" % (vrid, rc)
    print("Added MC route to VRID %d" % (vrid))


def delete_all_mc_routes(vrid, protocol=SX_IP_VERSION_NONE):
    if (protocol == SX_IP_VERSION_IPV4):
        mc_route_key = make_ipv4_mc_route_key(0, '0.0.0.0', '0.0.0.0', '0.0.0.0', '0.0.0.0')
        mc_route_key_p = new_sx_mc_route_key_t_p()
        sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)
    else:
        mc_route_key_p = None

    rc = sx_api_router_mc_route_set(sx_api_router.handle,
                                    SX_ACCESS_CMD_DELETE_ALL,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all MC routes from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted all MC routes from VRID %d" % (vrid))


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "
    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    prefix = sx_ip_v4_prefix_t()
    ip_prefix.prefix.ipv4 = prefix
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "
    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_mc_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_mc_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_mc_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_mc_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


""" ############################################################################################ """


def create_next_hops_arr(ports_list=[]):
    """
    This function creates a next hops list
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for port in ports_list:
        sx_mc_next_hop = sx_mc_next_hop_t()
        sx_mc_next_hop.type = SX_MC_NEXT_HOP_TYPE_LOG_PORT
        sx_mc_next_hop.data.log_port = port

        next_hop_arr = add_to_next_hop_arr(sx_mc_next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, uint32_t_p_value(next_hop_cnt_p)


def mc_container_create(ports_list, fid=0):
    mc_container_attribute = sx_mc_container_attributes_t()

    mc_container_attribute.min_mtu = 128
    mc_container_attribute.fid = fid
    mc_container_attribute.type = SX_MC_CONTAINER_TYPE_BRIDGE_MC

    mcc_attr_p = new_sx_mc_container_attributes_t_p()

    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mc_container_attribute)
    mc_container_id_p = new_sx_mc_container_id_t_p()

    sx_mc_next_hop_arr, next_hop_cnt = create_next_hops_arr(ports_list)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, mc_container_id_p, sx_mc_next_hop_arr, next_hop_cnt, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(mc_container_id_p)
    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create mc_container, rc: %d" % (rc)

    return mc_container_id


""" ############################################################################################ """


def mc_container_destroy(mc_container_id):
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    sx_mc_next_hop_p = new_sx_mc_next_hop_t_p()

    mc_container_id_p = new_sx_mc_container_id_t_p()
    sx_mc_container_id_t_p_assign(mc_container_id_p, mc_container_id)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, mc_container_id_p, sx_mc_next_hop_p, 0, mcc_attr_p)

    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mc_container, rc: %d" % (rc)
    return rc


def mc_fdb_ip_key_create(sip, dip, fid=0):
    mc_fdb_mc_ip_key = sx_fdb_mc_ip_key_t()
    mc_fdb_mc_ip_key.destination_ip_addr = dip
    mc_fdb_mc_ip_key.source_ip_addr = sip
    mc_fdb_mc_ip_key.fid = fid
    return mc_fdb_mc_ip_key


def fdb_mc_ip_addr_group_set_sip_dip(cmd, sip, dip, fid, mc_container=0, action=SX_FDB_ACTION_FORWARD):

    mc_fdb_mc_ip_key = mc_fdb_ip_key_create(sip, dip, fid)
    mc_fdb_mc_ip_key_p = new_sx_fdb_mc_ip_key_t_p()
    sx_fdb_mc_ip_key_t_p_assign(mc_fdb_mc_ip_key_p, mc_fdb_mc_ip_key)

    sx_fdb_mc_ip_action_p = new_sx_fdb_mc_ip_action_t_p()
    sx_fdb_mc_ip_action = sx_fdb_mc_ip_action_t()

    sx_fdb_mc_ip_action.action = action
    sx_fdb_mc_ip_action.container_id = mc_container
    sx_fdb_mc_ip_action.trap_attr.prio = 0

    sx_fdb_mc_ip_action_t_p_assign(sx_fdb_mc_ip_action_p, sx_fdb_mc_ip_action)

    return sx_api_fdb_mc_ip_addr_group_set(handle, cmd, mc_fdb_mc_ip_key_p, sx_fdb_mc_ip_action_p)


def __dump_all_rm_apis():
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_TCAM_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_KVD_HASH_E)
    if chip_type == SX_CHIP_TYPE_SPECTRUM:
        get_hw_utilization(handle, RM_HW_TABLE_TYPE_KVD_LINEAR_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_PGT_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_FLOW_COUNTER_E)
    get_hw_utilization(handle, RM_HW_TABLE_TYPE_ACL_REGIONS_TABLE_E)
    get_logical_free_entries_count(handle, EXAMPLE_RESOURCES)
    get_logical_utilization(handle, [])


def get_chip_type():
    """
    :return: SX_CHIP_TYPE_SPECTRUM \ SX_CHIP_TYPE_SPECTRUM2 \ SX_CHIP_TYPE_SPECTRUM3
    """
    print("Retrieving Chip Type from SDK")
    device_info_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(device_info_cnt_p, 1)
    device_info_cnt = uint32_t_p_value(device_info_cnt_p)
    device_info_list_p = new_sx_device_info_t_arr(device_info_cnt)
    rc = sx_api_port_device_list_get(handle, device_info_list_p, device_info_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_list_get failed, rc = %d" % (rc))
        sys.exit(rc)

    device_info = sx_device_info_t_arr_getitem(device_info_list_p, 0)
    chip_type = device_info.dev_type
    if chip_type == SX_CHIP_TYPE_SPECTRUM_A1:
        chip_type = SX_CHIP_TYPE_SPECTRUM

    return chip_type


def get_chip_dev_id_and_rev():
    mgir = sxd_api.ku_mgir_reg()
    meta = sxd_api.sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = sxd_api.SXD_ACCESS_CMD_GET

    rc = sxd_api.sxd_access_reg_init(0, None, 2)
    if rc:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_mgir(mgir, meta, 1, None, None)
    if rc:
        sys.exit(rc)

    rc = sxd_api.sxd_access_reg_deinit()
    if rc:
        sys.exit(rc)
    return mgir.hw_info.device_id, mgir.hw_info.device_hw_revision


def router_init(ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"


def router_deinit():
    " This function deinit the router. "
    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"


def tunnel_init():

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_params)
    rc = sx_api_tunnel_init_set(handle, general_param_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)


def tunnel_deinit():

    rc = sx_api_tunnel_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel, rc: %d" % (rc)

######################################################
#    main
######################################################


def main():

    chip_type = get_chip_type()

    print("\n\n\n")

    # Initialize router
    router_init()

    # init tunnel
    tunnel_init()

    # init igmpv3
    vlan_1 = 3000
    rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
    assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"

    print("After startup\n")
    __dump_all_rm_apis()
    print(" Create an ACL with 18B Key Width\n")

    key_handle_p = new_sx_acl_key_type_t_p()
    acl_key_create_delete(handle, SX_ACCESS_CMD_CREATE, key_handle_p, [FLEX_ACL_KEY_L4_DESTINATION_PORT])
    key_handle = sx_acl_key_type_t_p_value(key_handle_p)

    region_id_p = new_sx_acl_region_id_t_p()
    acl_region_handle(handle, SX_ACCESS_CMD_CREATE, key_handle, 32, region_id_p)
    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print(("Created ACL region with region_id %d" % region_id))

    rules_list = new_sx_flex_acl_flex_rule_t_arr(100)
    rules = []
    acl_rules_init(rules, rules_list, 100, key_handle, 20)

    dir = SX_ACL_DIRECTION_INGRESS
    acl_id_p = new_sx_acl_id_t_p()
    acl_handle(handle, SX_ACCESS_CMD_CREATE, dir, acl_id_p, region_id)
    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print(("Created ACL with ACL ID %d" % acl_id))

    group_id_p = new_sx_acl_id_t_p()
    acl_group_handle(handle, SX_ACCESS_CMD_CREATE, dir, group_id_p, [acl_id])
    group_id = sx_acl_id_t_p_value(group_id_p)
    print(("Created ACL Group with ID %d" % group_id))

    __dump_all_rm_apis()

    # Use some resource e.g add IGMPv3 groups
    # Create VRID that supports IPv4, both UC and MC
    vrid = sx_api_router.create_vrid(ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                                     ipv6_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                                     ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_ENABLE)

    print(" Created VRID with IPv4 & IPv6 MC enabled\n")

    __dump_all_rm_apis()

    print(" Create 3 IGMPv3 Groups\n")
    # IGMP
    vlan_2 = 3001
    vlan_3 = 3002

    sip = []
    dip = []
    DONT_CARE_RIF = 1001

    # 1-st group key
    dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
    sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
    # 2-st group key
    dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
    sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("224.2.2.3", "255.255.255.0"))
    sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))

    rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_ENABLE_E)
    assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
    rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3, SX_FDB_IGMPV3_STATE_ENABLE_E)
    assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"

    mc_container_id = mc_container_create([PORT1], vlan_1)
    erif_container_id = mc_container_create([PORT2], vlan_2)
    erif_container_id_2 = mc_container_create([PORT3], vlan_3)

    # create vlan_1 igmpv3 group

    rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_ADD, sip[0], dip[0], vlan_1, mc_container_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    print("fdb_mc_ip_addr_group_set ADD first group - Success")

    # create vlan_2 igmpv3 group
    rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_ADD, sip[1], dip[1], vlan_2, erif_container_id)
    assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    print("fdb_mc_ip_addr_group_set ADD first group - Success")

    # create vlan_3 igmpv3 group
    rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_ADD, sip[2], dip[2], vlan_3, erif_container_id_2)
    assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    print("fdb_mc_ip_addr_group_set ADD first group - Success")

    __dump_all_rm_apis()

    print(" Add 4 FDB entries\n")
    # Add some more resources
    mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(4)
    data_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(data_cnt_p, 4)
    mac_addr = ether_addr("00:02:c9:11:ad:ca")

    mac_entry1 = sx_fdb_uc_mac_addr_params_t()
    mac_entry1.mac_addr = mac_addr
    mac_entry1.fid_vid = 5          # Filtering Identifier, VID for static MAC
    mac_entry1.log_port = PORT1
    mac_entry1.entry_type = SX_FDB_UC_STATIC
    mac_entry1.action = SX_FDB_ACTION_MIRROR_TO_CPU
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

    mac_entry2 = sx_fdb_uc_mac_addr_params_t()
    mac_entry2.mac_addr = mac_addr
    mac_entry2.fid_vid = 15          # Filtering Identifier, VID for static MAC
    mac_entry2.log_port = PORT2
    mac_entry2.entry_type = SX_FDB_UC_STATIC
    mac_entry2.action = SX_FDB_ACTION_MIRROR_TO_CPU
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

    mac_entry3 = sx_fdb_uc_mac_addr_params_t()
    mac_entry3.mac_addr = mac_addr
    mac_entry3.fid_vid = 2          # Filtering Identifier, VID for static MAC
    mac_entry3.log_port = PORT3
    mac_entry3.entry_type = SX_FDB_UC_STATIC
    mac_entry3.action = SX_FDB_ACTION_MIRROR_TO_CPU
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 2, mac_entry3)

    mac_entry4 = sx_fdb_uc_mac_addr_params_t()
    mac_entry4.mac_addr = mac_addr
    mac_entry4.fid_vid = 12          # Filtering Identifier, VID for static MAC
    mac_entry4.log_port = PORT4
    mac_entry4.entry_type = SX_FDB_UC_STATIC
    mac_entry4.action = SX_FDB_ACTION_MIRROR_TO_CPU
    sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 3, mac_entry4)

    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
    data_cnt = uint32_t_p_value(data_cnt_p)
    print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

    __dump_all_rm_apis()

    if args.deinit:
        # Cleanup
        print("Begin cleanup\n")

        print("Remove IGMPv3 groups")

        # Destroy vlan_1 igmpv3 group
        rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_DELETE, sip[0], dip[0], vlan_1)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
        print("fdb_mc_ip_addr_group_set Delete  - Success")

        # create vlan_2 igmpv3 group
        rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_DELETE, sip[1], dip[1], vlan_2)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
        print("fdb_mc_ip_addr_group_set Delete  - Success")

        # create vlan_3 igmpv3 group
        rc = fdb_mc_ip_addr_group_set_sip_dip(SX_ACCESS_CMD_DELETE, sip[2], dip[2], vlan_3)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
        print("fdb_mc_ip_addr_group_set Delet  - Success")

        mc_container_destroy(mc_container_id)
        mc_container_destroy(erif_container_id)
        mc_container_destroy(erif_container_id_2)

        rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
        assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
        rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_DISABLE_E)
        assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
        rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3, SX_FDB_IGMPV3_STATE_DISABLE_E)
        assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"

        # Destroy VRID
        sx_api_router.delete_vrid(vrid)

        # deinit tunnel
        tunnel_deinit()

        # Deinitialize router
        router_deinit()

        rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to delete FDB Entry, rc = %d" % rc
        print(("sx_api_fdb_uc_mac_addr_set deleted %d enties, rc: %d " % (data_cnt, rc)))

        acl_group_handle(handle, SX_ACCESS_CMD_DESTROY, dir, group_id_p, [])
        acl_handle(handle, SX_ACCESS_CMD_DESTROY, dir, acl_id_p, region_id)
        acl_region_handle(handle, SX_ACCESS_CMD_DESTROY, key_handle, 32, region_id_p)
        acl_key_create_delete(handle, SX_ACCESS_CMD_DELETE, key_handle_p, [FLEX_ACL_KEY_L4_DESTINATION_PORT])

    sx_api_close(handle)


if __name__ == "__main__":
    main()
