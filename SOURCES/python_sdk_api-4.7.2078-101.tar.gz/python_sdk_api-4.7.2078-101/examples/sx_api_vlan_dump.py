#!/usr/bin/env python
"""
This file contains a python commands example for the VLAN module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import os
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

tagged_dict = {0: 'Tagged Member', 1: 'Untagged Member'}
pass_state_dict = {0: 'BOTH', 1: 'INGRESS', 2: 'EGRESS'}
get_all = True
get_ports_for_vlan = False
get_vlans_for_port = False
input_vlan = 0
input_port = 0


def check_vlan(vlan):
    value = int(vlan, 0)
    if value < 1 or value > 4095:
        raise argparse.ArgumentTypeError("%s is an invalid VLAN number" % value)
    return value


parser = argparse.ArgumentParser(description='VLAN dump utility')
group = parser.add_mutually_exclusive_group(required=False)
group.add_argument('--vlan', default=None, type=check_vlan, help='VLAN number')
group.add_argument('--log_port', default=None, type=auto_int, help='Logical Port ID')
args = parser.parse_args()

if args.vlan:
    get_ports_for_vlan = True
    get_all = False
    input_vlan = args.vlan
if args.log_port:
    get_vlans_for_port = True
    get_all = False
    input_port = args.log_port

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')

swid_cnt_p = new_uint32_t_p()
uint32_t_p_assign(swid_cnt_p, 0)
rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)

swid_cnt = uint32_t_p_value(swid_cnt_p)
swid_list_p = new_sx_swid_t_arr(swid_cnt)
rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)
printed_header = False

for i in range(0, swid_cnt):
    swid = sx_swid_t_arr_getitem(swid_list_p, i)
    port_list = []
    vlan_list = []

    for vid in range(1, 4096):
        port_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(port_cnt_p, 0)
        rc = sx_api_vlan_ports_get(handle, swid, vid, None, port_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
            sys.exit(rc)
        port_cnt = uint32_t_p_value(port_cnt_p)
        if get_all:
            if port_cnt > 0:
                if not printed_header:
                    print("==============================================================================")
                    print("|%6s|%6s|%15s|%17s|%8s|%17s|" % ("SWID", "VLAN", "Log Port ID", "Egress State", "Pass state", "Hw_egress_state"))
                    print("==============================================================================")
                    printed_header = True

                print("|%6s %6s|" % (swid, vid), end="")

        vlan_port_list_p = new_sx_vlan_ports_t_arr(port_cnt)
        rc = sx_api_vlan_ports_get(handle, swid, vid, vlan_port_list_p, port_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_vlan_ports_get failed, rc = %d" % (rc))
            sys.exit(rc)
        port_cnt = uint32_t_p_value(port_cnt_p)
        port_qinq_mode_p = new_sx_qinq_mode_t_p()
        for j in range(0, port_cnt):
            vlan_ports = sx_vlan_ports_t_arr_getitem(vlan_port_list_p, j)
            if get_all:
                port_id_str = "0x%x" % vlan_ports.log_port
                rc = sx_api_vlan_port_qinq_mode_get(handle, vlan_ports.log_port, port_qinq_mode_p)
                port_qinq_mode = sx_qinq_mode_t_p_value(port_qinq_mode_p)
                if rc != SX_STATUS_SUCCESS:
                    print("sx_api_vlan_qinq_mode_get, rc = %d" % (rc))
                    sys.exit(rc)
                if port_qinq_mode == SX_QINQ_MODE_QINQ:
                    hw_egress_state = SX_UNTAGGED_MEMBER
                else:
                    hw_egress_state = vlan_ports.is_untagged
                if j == 0:
                    print("%15s|%17s|%10s|%17s|" % (port_id_str, tagged_dict[vlan_ports.is_untagged], pass_state_dict[vlan_ports.pass_state], tagged_dict[hw_egress_state]))
                else:
                    print("|%6s %6s|%15s|%17s|%10s|%17s|" % ("", "", port_id_str, tagged_dict[vlan_ports.is_untagged], pass_state_dict[vlan_ports.pass_state], tagged_dict[hw_egress_state]))
                if j == (port_cnt - 1):
                    print("=============================================================================")
                else:
                    print("|%6s %6s|--------------------------------------------------------------" % ("", ""))
            if get_ports_for_vlan and vid == input_vlan:
                port_list.append(vlan_ports.log_port)

            if get_vlans_for_port and vlan_ports.log_port == input_port:
                vlan_list.append(vid)

    if get_ports_for_vlan:
        print("SWID %d, VLAN %d" % (swid, input_vlan))
        print("----------------------------")
        print("Ports: ", end="")
        for i in range(0, len(port_list)):
            port_id_str = "0x%x" % (port_list[i])
            if i % 10 == 0:
                if i == 0:
                    print("%10s" % (port_id_str), end="")
                else:
                    print("%7s%10s" % ("", port_id_str), end="")
            if i % 10 != 0:
                print(", %10s" % (port_id_str), end="")
                if i % 10 == 9:
                    print("")
        print("\n")

    if get_vlans_for_port:
        print("SWID %d, Port 0x%x" % (swid, input_port))
        print("----------------------------")
        print("VLANs: ", end="")
        for i in range(0, len(vlan_list)):
            if i % 16 == 0:
                if i == 0:
                    print("%4d" % (vlan_list[i]), end="")
                else:
                    print("%7s%4d" % ("", vlan_list[i]), end="")
            if i % 16 != 0:
                print(", %4d" % (vlan_list[i]), end="")
                if i % 16 == 15:
                    print("")
        print("\n")
