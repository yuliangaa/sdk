#!/usr/bin/env python
"""
This file contains Python command example for the ROUTER module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. Router and adaptive routing modules initialization
    2. Adaptive routing parameters:
        a. AR profile
        b. AR default classifier
        c. AR classifier
        d. AR congestion thresholds
        e. AR shapers
        f. AR link utilization
	3. Adaptive routing RIF
	4. Adaptive ECMP
	5. neighbors
	6. UC route

"""
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################

# string constants
RIF_STR = "RIF"
IP_STR = "IP"
WEIGHT_STR = "weight"

######################################################
#    functions
######################################################


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_router_adaptive example')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()
    return args

# layer 2


def ecmp_hash_params_get(handle):
    print("get global ECMP hash params")
    params_p = new_sx_router_ecmp_hash_params_t_p()
    rc = sx_api_router_ecmp_hash_params_get(handle, params_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get global ECMP hash params, rc: %d" % (rc)
    params = sx_router_ecmp_hash_params_t_p_value(params_p)
    return (params.ecmp_hash_type, params.symmetric_hash, params.seed, params.ecmp_hash)


def ecmp_hash_params_get_and_validate(handle, hash_type, symmetric, seed, hash):
    (rtype, rsymmetric, rseed, rhash) = ecmp_hash_params_get(handle, hash_type, symmetric, seed, hash)
    assert rtype == hash_type, "got wrong ECMP hash params, hash_type: received: %d, expected %d" % (rtype, hash_type)
    assert rsymmetric == symmetric, "got wrong ECMP hash params, symmetric hash indication: received: %d, expected %d" % (rsymmetric, symmetric)
    assert rhash == hash, "got wrong ECMP hash params, hash value: received: %d, expected %d" % (rhash, hash)
    assert rseed == seed, "got wrong ECMP hash params, seed: received: %d, expected %d" % (rseed, seed)


def ecmp_hash_params_set(handle, hash_type, symmetric, seed, hash):
    print("set global ECMP hash params")
    params = sx_router_ecmp_hash_params_t()
    params.ecmp_hash_type = hash_type
    params.symmetric_hash = symmetric
    params.seed = seed
    params.ecmp_hash = hash
    rc = sx_api_router_ecmp_hash_params_set(handle, params)
    assert SX_STATUS_SUCCESS == rc, "Failed to set global ECMP hash params, rc: %d" % (rc)


def ecmp_port_hash_params_get(handle, port, enables_cnt, fields_cnt):
    print("set ECMP hash params on port %s" % (str(hex(port))))
    params_p = new_sx_router_ecmp_port_hash_params_t_p()
    fields_arr = new_sx_router_ecmp_hash_field_t_arr(fields_cnt)
    enables_arr = new_sx_router_ecmp_hash_field_enable_t_arr(enables_cnt)
    enables_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(enables_cnt_p, enables_cnt)
    fields_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(fields_cnt_p, fields_cnt)
    rc = sx_api_router_ecmp_port_hash_params_get(handle, port, params_p, enables_arr, enables_cnt_p, fields_arr, fields_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get port %s ECMP hash params, rc: %d" % (str(hex(port)), rc)

    params = sx_router_ecmp_port_hash_params_t_p_value(params_p)
    enables = [sx_router_ecmp_hash_field_enable_t_arr_getitem(enables_arr, i) for i in range(enables_cnt)]
    fields = [sx_router_ecmp_hash_field_t_arr_getitem(fields_arr, i) for i in range(fields_cnt)]
    enables_cnt = uint32_t_p_value(enables_cnt_p)
    fields_cnt = uint32_t_p_value(fields_cnt_p)

    return (params.ecmp_hash_type, params.symmetric_hash, params.seed, enables, enables_cnt, fields, fields_cnt)


def ecmp_port_hash_params_get_and_validate(handle, port, hash_type, symmetric, seed, enables, fields):
    (rtype, rsymmetric, rseed, renables, renable_cnt, rfields, rfields_cnt) = ecmp_port_hash_params_get(handle, port, len(enables), len(fields))
    assert rtype == hash_type, "got wrong ECMP hash params on port %s, hash_type: received: %d, expected %d" % (str(hex(port)), rtype, hash_type)
    assert rsymmetric == symmetric, "got wrong ECMP hash params on port %s, seed: received: %d, expected %d" % (str(hex(port)), rsymmetric, symmetric)
    assert rseed == seed, "got wrong ECMP hash params on port %s, seed: received: %d, expected %d" % (str(hex(port)), params_val.seed, seed)
    assert rfields_cnt == len(fields), "got wrong ECMP hash params on port %s, fields cnt: received: %d, expected %d" % (str(hex(port)), rfields_cnt, len(fields))
    assert renable_cnt == len(enables), "got wrong ECMP hash params on port %s, enables cnt: received: %d, expected %d" % (str(hex(port)), renable_cnt, len(enables))
    assert set(rfields) == set(fields), "got wrong ECMP hash params on port %s, fields arr" % (str(hex(port)))
    assert set(renables) == set(enables), "got wrong ECMP hash params on port %s, fields arr" % (str(hex(port)))


def ecmp_port_hash_params_set_api_call(handle, cmd, port, type, symmetric, seed, enables, fields):
    print("set ECMP hash params on port %s" % (str(hex(port))))
    params = sx_router_ecmp_port_hash_params_t()
    params.ecmp_hash_type = type
    params.symmetric_hash = symmetric
    params.seed = seed
    enables_arr = new_sx_router_ecmp_hash_field_enable_t_arr(len(enables))
    for i, enable in enumerate(enables):
        sx_router_ecmp_hash_field_enable_t_arr_setitem(enables_arr, i, enable)
    fields_arr = new_sx_router_ecmp_hash_field_t_arr(len(fields))
    for i, field in enumerate(fields):
        sx_router_ecmp_hash_field_t_arr_setitem(fields_arr, i, field)
    rc = sx_api_router_ecmp_port_hash_params_set(handle, cmd, port, params, enables_arr, len(enables), fields_arr, len(fields))
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP hash params on port %s, rc: %d" % (str(hex(port)), rc)


def ecmp_port_hash_params_add(handle, port, enables, fields):
    ecmp_port_hash_params_set_api_call(handle, SX_ACCESS_CMD_ADD, port, 0, 0, 0, enables, fields)


def ecmp_port_hash_params_delete(handle, port, enables, fields):
    ecmp_port_hash_params_set_api_call(handle, SX_ACCESS_CMD_DELETE, port, 0, 0, 0, enables, fields)


def ecmp_port_hash_params_set(handle, port, hash_type, symmetric, seed, enables, fields):
    ecmp_port_hash_params_set_api_call(handle, SX_ACCESS_CMD_SET, port, hash_type, symmetric, seed, enables, fields)


def set_port_state(handle, log_vport, admin_state):
    " This function sets port state. "

    rc = sx_api_port_state_set(handle, log_vport, admin_state)
    assert SX_STATUS_SUCCESS == rc, "Failed to set port %d state" % (log_vport)
    print("Set port %d state , rc: %d" % (log_vport, rc))


def set_auto_learn_port(handle, log_port, auto_learn):
    " This function disables autolearn for given port. "

    rc = sx_api_fdb_port_learn_mode_set(handle, log_port, auto_learn)
    assert SX_STATUS_SUCCESS == rc, "Failed to set autolearn of port 0x%x to %d" % (log_port, auto_learn)
    print("set autolearn for port 0x%d to %d, rc: %d " % (log_port, auto_learn, rc))


def get_auto_learn_port(handle, log_port):
    original_learn_mode_p = new_sx_fdb_learn_mode_t_p()
    rc = sx_api_fdb_port_learn_mode_get(handle, log_port, original_learn_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_port_learn_mode_get failed; rc=%d, port=0x%x" % (rc, log_port)
    return sx_fdb_learn_mode_t_p_value(original_learn_mode_p)


def create_vport(handle, log_port, vlan_id, egress_mode):
    " This function creates vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_ADD, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vport for port %d and vlan %d" % (log_port, vlan_id)

    log_vport = sx_port_log_id_t_p_value(log_vport_p)
    print("Create vport %d for port %d and vlan %d, rc: %d" % (log_vport, log_port, vlan_id, rc))
    return log_vport


def delete_vport(handle, log_port, log_vport, vlan_id, egress_mode):
    " This function deletes vport with given parametrs. "

    log_vport_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(log_vport_p, log_vport)

    rc = sx_api_port_vport_set(handle, SX_ACCESS_CMD_DELETE, log_port, vlan_id, log_vport_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete vport %d" % (log_vport)
    print("Deleted vport %d from port %d and vlan %d, rc: %d " % (log_vport, log_port, vlan_id, rc))

# router


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def router_init(handle, ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE, ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE, ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                rpf_enable=SX_ROUTER_ENABLE_STATE_DISABLE, max_virtual_routers_num=12,
                max_router_interfaces=400, min_ipv4_neighbor_entries=10, min_ipv6_neighbor_entries=10,
                min_ipv4_uc_route_entries=10, min_ipv6_uc_route_entries=10, min_ipv4_mc_route_entries=0,
                min_ipv6_mc_route_entries=0, max_ipv4_neighbor_entries=1000, max_ipv6_neighbor_entries=1000,
                max_ipv4_uc_route_entries=1000, max_ipv6_uc_route_entries=1000, max_ipv4_mc_route_entries=0,
                max_ipv6_mc_route_entries=0):
    " This function init the router with following values. "

    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = ipv4_enable
    general_params.ipv6_enable = ipv6_enable
    general_params.ipv4_mc_enable = ipv4_mc_enable
    general_params.ipv6_mc_enable = ipv6_mc_enable
    general_params.rpf_enable = rpf_enable
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = max_virtual_routers_num
    router_resource.max_router_interfaces = max_router_interfaces
    router_resource.min_ipv4_neighbor_entries = min_ipv4_neighbor_entries
    router_resource.min_ipv6_neighbor_entries = min_ipv6_neighbor_entries
    router_resource.min_ipv4_uc_route_entries = min_ipv4_uc_route_entries
    router_resource.min_ipv6_uc_route_entries = min_ipv6_uc_route_entries
    router_resource.min_ipv4_mc_route_entries = min_ipv4_mc_route_entries
    router_resource.min_ipv6_mc_route_entries = min_ipv6_mc_route_entries
    router_resource.max_ipv4_neighbor_entries = max_ipv4_neighbor_entries
    router_resource.max_ipv6_neighbor_entries = max_ipv6_neighbor_entries
    router_resource.max_ipv4_uc_route_entries = max_ipv4_uc_route_entries
    router_resource.max_ipv6_uc_route_entries = max_ipv6_uc_route_entries
    router_resource.max_ipv4_mc_route_entries = max_ipv4_mc_route_entries
    router_resource.max_ipv6_mc_route_entries = max_ipv6_mc_route_entries

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc, "Failed to init the router"

    print("Init the router, rc: %d" % (rc))


def create_vrid(handle,
                ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                uc_default_action=SX_ROUTER_ACTION_DROP,
                mc_default_action=SX_ROUTER_ACTION_DROP):
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = ipv4_enable
    router_attr.ipv6_enable = ipv6_enable
    router_attr.ipv4_mc_enable = ipv4_mc_enable
    router_attr.ipv6_mc_enable = ipv6_mc_enable
    router_attr.uc_default_rule_action = uc_default_action
    router_attr.mc_default_rule_action = mc_default_action

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


def set_rif_state_ipv4(handle,
                       rif,
                       ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                       ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                       ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


def add_neigh(handle, rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "

    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def make_ecmp_next_hop(rif, ipaddr, weight, action=SX_ROUTER_ACTION_FORWARD, trap_attr_prio=SX_TRAP_PRIORITY_MED, counter_id=0):
    """
            This function creates ecmp_next_hop struct with given parametrs.
            action, counter_id and trap priority are optional.
    """

    ip_nh = sx_ip_next_hop_t()
    ip_nh.rif = rif
    ip_nh.address = make_sx_ip_addr_v4(ipaddr)

    nh_key = sx_next_hop_key_t()
    nh_key.type = SX_NEXT_HOP_TYPE_IP
    nh_key.next_hop_key_entry.ip_next_hop = ip_nh

    next_hop_data = sx_next_hop_data_t()
    next_hop_data.weight = weight
    next_hop_data.action = action
    next_hop_data.trap_attr.prio = trap_attr_prio
    next_hop_data.counter_id = counter_id

    next_hop = sx_next_hop_t()
    next_hop.next_hop_key = nh_key
    next_hop.next_hop_data = next_hop_data

    return next_hop


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "

    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


def create_next_hops_arr(nh_params_list=[]):
    """
    This function creates a next hops list
    @param nh_params_list: List of next hop parameters dictionary, with relevant fields:
                                                                    RIF_STR, RIF_STR, WEIGHT_STR, etc.
    @return: List of next hop items, next hop count
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for nh in nh_params_list:
        next_hop = make_ecmp_next_hop(nh[RIF_STR], nh[IP_STR], nh[WEIGHT_STR])
        next_hop_arr = add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, next_hop_cnt_p


def make_ar_uc_route_data(ecmp_id, action=SX_ROUTER_ACTION_FORWARD, ar_flow_action_type=SX_AR_CLASSIFIER_ACTION_STATIC_E):
    """
    Creates adaptive routing uc_route_data structure with given parameters.

    Args:
        ecmp_id (int):                          Ecmp container ID
        action (sx_router_action_t, optional):  Default is SX_ROUTER_ACTION_FORWARD
        ar_flow_action_type                     Adaptive routing action (STATIC | PROFILE_0 | PROFILE_1)

    Returns:
        (sx_uc_route_data) Ecmp uc_route_data structure
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP
    uc_route_data.uc_route_param.ecmp_id = ecmp_id
    uc_route_data.ar_classifier_action.ar_flow_classification = ar_flow_action_type
    return uc_route_data


def create_ar_uc_route(handle, vrid, addr, mask, ecmp_id, type_ipv6=False, ar_flow_action_type=SX_AR_CLASSIFIER_ACTION_STATIC_E):
    """
    Creates adaptive routing uc route with given parameters.

    Args:
        Handle                          SDK handle
        vrid (int):                     Virtual router ID
        addr (string):                  Ip address
        mask (string, optional):        Mask for ip address, default is "255.255.255.255"
        ecmp_id (int):                  Ecmp container ID
        type_ipv6 (boolean, optional):  If True - ipv6, default is False
        ar_flow_action_type             Adaptive routing action (STATIC | PROFILE_0 | PROFILE_1)

    Raises:
        SdkException: In case of SDK error
    """
    ip_prefix_p = new_sx_ip_prefix_t_p()
    uc_route_data_p = new_sx_uc_route_data_t_p()
    try:
        if type_ipv6:
            ip_prefix = make_sx_ip_prefix_v6(addr, mask)
        else:
            ip_prefix = make_sx_ip_prefix_v4(addr, mask)

        sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

        uc_route_data = make_ar_uc_route_data(ecmp_id, SX_ROUTER_ACTION_FORWARD, ar_flow_action_type)
        sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

        rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to create adaptive uc route"
    finally:
        delete_sx_ip_prefix_t_p(ip_prefix_p)
        delete_sx_uc_route_data_t_p(uc_route_data_p)


def create_adaptive_routing_rif(handle, vrid, log_vport, mac_addr, mtu=1500):
    " This function creates adaptive routing rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_ADAPTIVE_ROUTING
    ifc_param.ifc.adaptive_routing.vport = log_vport

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = True
    rif_p = new_sx_router_interface_t_p()

    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create adaptive routing RIF"
    rif = sx_router_interface_t_p_value(rif_p)
    print("Created adaptive routing RIF: %d, rc: %d " % (rif, rc))
    return rif


def delete_neigh(handle, rif, addr):
    " This function deletes neighbor from given rif. "

    ip_addr = make_sx_ip_addr_v4(addr)
    neigh_data = sx_neigh_data_t()

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete neigh"

    print("Deleted neighbor from rif %d, rc: %d" % (rif, rc))


def destroy_ecmp_container(handle, ecmp_id):
    " This function destroys external ecmp container. "

    next_hop_cnt_p = new_uint32_t_p()

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_DESTROY, ecmp_id_p, None, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy external ecmp container %d" % (ecmp_id)
    print("Destroyed ECMP container ID %d, rc: %d" % (ecmp_id, rc))


def delete_all_next_hops_uc_routes_per_vrid(handle, vrid):
    " This function deletes all next hops from given vrid. "

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_DELETE_ALL, vrid, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all next hops of VRID %d" % (vrid)
    print("Deleted all next hops of VRID %d, rc: %d" % (vrid, rc))


def delete_all_neigh_per_rif(handle, rif):
    " This function deletes all neighbors from given rif. "

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_DELETE_ALL, rif, None, None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete all neighbors of RIF %d" % (rif)
    print("Deleted all neighbors of RIF %d, rc: %d" % (rif, rc))


def delete_rif(handle, vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


def delete_vrid(handle, vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


def router_deinit(handle):
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))

# router examples


def create_external_ecmp_container(handle, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    @return: ECMP container ID
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create external ECMP container"

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Created ECMP container ID %d, rc: %d " % (ecmp_id, rc))

    return ecmp_id


def read_ecmp_attributes(handle, ecmp_id):
    "This function reads ECMP external container attributes"
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_get(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to read ECMP %d attributes, rc: %d" % (ecmp_id, rc)
    ecmp_attributes = sx_ecmp_attributes_t_p_value(ecmp_attributes_p)
    print_ecmp_attributes(ecmp_id, ecmp_attributes)


def set_ecmp_attributes(handle, ecmp_id, ecmp_type, active_flow_timer=100, group_size=4096, max_unbalanced_time=200):
    """"
    This function sets ECMP external container attributes
    @param emcp_id: ECMP container ID
    @param type: External ECMP container type, e.g. SX_ECMP_TYPE_RESILIENT_E
    @param active_flow_timer: ECMP active flow timer
    @param groups_size:	ECMP container group size
    @param max_unbalanced_time: ECMP max unbalanced time
    """
    ecmp_attributes = sx_ecmp_attributes_t()
    ecmp_attributes_p = new_sx_ecmp_attributes_t_p()
    ecmp_attributes.ecmp_type = ecmp_type
    ecmp_attributes.active_flow_timer = active_flow_timer
    ecmp_attributes.group_size = group_size
    ecmp_attributes.max_unbalanced_time = max_unbalanced_time
    sx_ecmp_attributes_t_p_assign(ecmp_attributes_p, ecmp_attributes)
    rc = sx_api_router_ecmp_attributes_set(handle, ecmp_id, ecmp_attributes_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ECMP %d attributes, rc: %d" % (ecmp_id, rc)


def print_ecmp_attributes(ecmp_id, ecmp_attributes):
    print("####################################################################")
    print("Router ECMP ID  %d:\n" % (ecmp_id))

    print("ECMP type:                {:>10}".format(ecmp_attributes.ecmp_type))
    print("ECMP active_flow_timer:   {:>10}".format(ecmp_attributes.active_flow_timer))
    print("ECMP group_size:          {:>10}".format(ecmp_attributes.group_size))
    print("ECMP max_unbalanced_time: {:>10}".format(ecmp_attributes.max_unbalanced_time))
    print("####################################################################\n")


def modify_external_ecmp_container(handle, ecmp_id, nh_params_list=[]):
    """
    This function creates an external ECMP container with a given next hops list
    @param ecmp__id: ECMP container ID.
    @param nh_params_list: a list to be passed to create_next_hops_arr. Please refer to the latter doc.
    """

    nh_arr, next_hop_cnt_p = create_next_hops_arr(nh_params_list)

    ecmp_id_p = new_sx_ecmp_id_t_p()
    sx_ecmp_id_t_p_assign(ecmp_id_p, ecmp_id)

    rc = sx_api_router_ecmp_set(handle, SX_ACCESS_CMD_SET, ecmp_id_p, nh_arr, next_hop_cnt_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to modify external ECMP container [ecmp_id=%d], rc %d" % (ecmp_id, rc)

    ecmp_id = sx_ecmp_id_t_p_value(ecmp_id_p)
    active_cnt = uint32_t_p_value(next_hop_cnt_p)
    print("Modified ECMP container ID %d " % (ecmp_id))


def ar_init(handle):
    """
    Initiates the adaptive routing module in SDK.

    """
    print("Initializing Adaptive Routing")
    ar_init_params = sx_ar_init_params_t()
    ar_init_params.buffer_mode = 1
    rc = sx_api_ar_init_set(handle, ar_init_params)
    assert SX_STATUS_SUCCESS == rc, "sx_api_ar_init_set failed, rc %d" % (rc)


def ar_deinit(handle):
    """
    Deinitialize adaptive routing.

    """

    print("Deinitializing adaptive routing")

    rc = sx_api_ar_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "sx_api_ar_deinit_set failed, rc %d" % (rc)


def ar_profile_create(handle, profile, profile_mode, free_thresh,
                      busy_thresh, to_shaper_is_enable, from_shaper_is_enable, bind_time):
    """
    This API creates adaptive routing profile
    Args:
        Handle                  SDK handle
        profile (int):          profile enum
        profile_mode (int):     profile mode enum
        free_thresh (int):      free threshold
        busy_thresh (int):      busy threshold
        rate_to_enable (bool)
        rate_from_enable (bool)
        bind_time (int)

    Returns:
       void

    """

    ar_profile_p = new_sx_ar_profile_attr_t_p()
    ar_key_p = new_sx_ar_profile_key_t_p()

    try:
        ar_profile = sx_ar_profile_attr_t()
        ar_key = sx_ar_profile_key_t()

        ar_key.profile = profile
        ar_profile.mode = profile_mode

        profile_thresh = sx_ar_profile_threshold_t()
        profile_thresh.free_threshold = free_thresh
        profile_thresh.busy_threshold = busy_thresh

        ar_profile.profile_threshold = profile_thresh

        ar_profile.only_elephant_en = False

        ar_shaper = sx_ar_shaper_attr_filter_t()
        ar_shaper.to_shaper_is_enable = to_shaper_is_enable
        ar_shaper.from_shaper_is_enable = from_shaper_is_enable
        ar_profile.shaper_attr_filter = ar_shaper

        ar_profile.bind_time = bind_time

        sx_ar_profile_attr_t_p_assign(ar_profile_p, ar_profile)
        sx_ar_profile_key_t_p_assign(ar_key_p, ar_key)

        rc = sx_api_ar_profile_set(handle, SX_ACCESS_CMD_SET, ar_key_p, ar_profile_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_profile_set failed [ar_profile=%d], rc %d" % (profile, rc)

        print("Configured AR PROFILE %d, rc: %d " % (profile - 1, rc))

    finally:
        delete_sx_ar_profile_attr_t_p(ar_profile_p)
        delete_sx_ar_profile_key_t_p(ar_key_p)


def ar_config_default_classification(handle, cmd, action_type):
    """
    This API creates adaptive routing default classifier
    Args:
        Handle                  SDK handle
        action_type (int):      classification action enum

    """

    ar_class_p = new_sx_ar_classifier_action_t_p()

    try:
        ar_class = sx_ar_classifier_action_t()

        ar_class.ar_flow_classification = action_type

        sx_ar_classifier_action_t_p_assign(ar_class_p, ar_class)

        rc = sx_api_ar_default_classification_set(handle, cmd, ar_class_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_default_classification_set failed [action_type=%d], rc %d" % (action_type, rc)

        print("Configured AR default classifier action %d, rc: %d " % (action_type, rc))

    finally:
        delete_sx_ar_classifier_action_t_p(ar_class_p)


def ar_config_classification_set(handle, classifier_id=None,
                                 action_type=None, log_ports=None,
                                 switch_priorities=None, bth_opcodes_4_0=None,
                                 bth_opcodes_7_5=None, inner_bth_opcodes_4_0=None,
                                 inner_bth_opcodes_7_5=None, l3=None, inner_l3=None,
                                 l4=None, inner_l4=None, bth_ar=None,
                                 inner_bth_ar=None, port_ranges=None):
    """
    This API configures adaptive routing classifier
    Args:
        Handle                  SDK handle
        action_type (int):      classification action enum
        log_ports (int array)
        switch_priorities (bool array)
        bth_opcodes_4_0 (int array)
        bth_opcodes_7_5 (int array)
        inner_bth_opcodes_4_0 (int array)
        inner_bth_opcodes_7_5 (int array)
        l3 (sx_ar_classifier_header_type_l3_e)
        inner_l3 (sx_ar_classifier_header_type_l3_e)
        l4 (sx_ar_classifier_header_type_l3_e)
        inner_l4 (sx_ar_classifier_header_type_l3_e)
        bth_ar (sx_ar_classifier_bth_header_state_e)
        inner_bth_ar (sx_ar_classifier_bth_header_state_e)
        port_ranges (array {port_low, port_high, protocol, port_type})

    """

    action_p = new_sx_ar_classifier_action_t_p()
    attr_p = new_sx_ar_classifier_attr_t_p()

    ports_arr = None
    bth_arr1 = None
    bth_arr2 = None
    bth_arr3 = None
    bth_arr4 = None
    ports_range_arr = None

    try:
        ar_class = sx_ar_classifier_action_t()
        ar_class.ar_flow_classification = action_type
        sx_ar_classifier_action_t_p_assign(action_p, ar_class)

        attr = sx_ar_classifier_attr_t()
        if log_ports:
            ports_arr = new_sx_port_log_id_t_arr(len(log_ports))
            for i, port in enumerate(log_ports):
                sx_port_log_id_t_arr_setitem(ports_arr, i, port)
            attr.key.log_ports = ports_arr
            attr.key.log_ports_cnt = len(log_ports)
        else:
            attr.key.log_ports_cnt = 0
        if switch_priorities:
            switch_prio_arr = new_sx_cos_priority_t_arr(len(switch_priorities))
            for i, prio in enumerate(switch_priorities):
                sx_cos_priority_t_arr_setitem(switch_prio_arr, i, prio)
            attr.key.switch_priorities = switch_prio_arr
            attr.key.switch_priorities_cnt = len(switch_priorities)
        else:
            attr.key.switch_priorities_cnt = 0
        if bth_opcodes_4_0:
            bth_arr1 = new_uint8_t_arr(len(bth_opcodes_4_0))
            for i, bth in enumerate(bth_opcodes_4_0):
                uint8_t_arr_setitem(bth_arr1, i, bth)
            attr.key.bth_opcodes.bth_opcode_4_0 = bth_arr1
            attr.key.bth_opcodes.bth_opcode_4_0_cnt = len(bth_opcodes_4_0)
        else:
            attr.key.bth_opcodes.bth_opcode_4_0_cnt = 0
        if bth_opcodes_7_5:
            bth_arr2 = new_uint8_t_arr(len(bth_opcodes_7_5))
            for i, bth in enumerate(bth_opcodes_7_5):
                uint8_t_arr_setitem(bth_arr2, i, bth)
            attr.key.bth_opcodes.bth_opcode_7_5 = bth_arr2
            attr.key.bth_opcodes.bth_opcode_7_5_cnt = len(bth_opcodes_7_5)
        else:
            attr.key.bth_opcodes.bth_opcode_7_5_cnt = 0
        if inner_bth_opcodes_4_0:
            bth_arr3 = new_uint8_t_arr(len(inner_bth_opcodes_4_0))
            for i, bth in enumerate(inner_bth_opcodes_4_0):
                uint8_t_arr_setitem(bth_arr3, i, bth)
            attr.key.inner_bth_opcodes.bth_opcodes_4_0 = bth_arr3
            attr.key.inner_bth_opcodes.bth_opcode_4_0_cnt = len(inner_bth_opcodes_4_0)
        else:
            attr.key.inner_bth_opcodes.bth_opcode_4_0_cnt = 0
        if inner_bth_opcodes_7_5:
            bth_arr4 = new_uint8_t_arr(len(inner_bth_opcodes_7_5))
            for i, bth in enumerate(inner_bth_opcodes_7_5):
                uint8_t_arr_setitem(bth_arr4, i, bth)
            attr.key.inner_bth_opcodes.bth_opcode_7_5 = bth_arr4
            attr.key.inner_bth_opcodes.bth_opcode_7_5_cnt = len(inner_bth_opcodes_7_5)
        else:
            attr.key.inner_bth_opcodes.bth_opcode_7_5_cnt = 0
        if l3:
            attr.key.l3 = l3
        if inner_l3:
            attr.key.inner_l3 = inner_l3
        if l4:
            attr.key.l4 = l4
        if inner_l4:
            attr.key.inner_l4 = inner_l4
        if port_ranges:
            ports_range_arr = new_sx_ar_classifier_l4_port_range_t_arr(len(port_ranges))
            for i, port in enumerate(port_ranges):
                port_range = sx_ar_classifier_l4_port_range_t()
                port_range.port_low = port[0]
                port_range.port_high = port[1]
                port_range.protocol = port[2]
                port_range.port = port[3]
                sx_ar_classifier_l4_port_range_t_arr_setitem(ports_range_arr, i, port_range)
            attr.key.port_ranges = ports_range_arr
            attr.key.port_ranges_cnt = len(port_ranges)
        else:
            attr.key.port_ranges_cnt = 0

        sx_ar_classifier_attr_t_p_assign(attr_p, attr)

        rc = sx_api_ar_classifier_set(handle, SX_ACCESS_CMD_SET, classifier_id, attr_p, action_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_classifier_set failed [classifier_id=%d], rc %d" % (classifier_id, rc)

        print("Configured AR classifier ID  %d, rc: %d " % (classifier_id, rc))

    finally:
        delete_sx_ar_classifier_action_t_p(action_p)
        delete_sx_ar_classifier_attr_t_p(attr_p)
        if ports_arr:
            delete_sx_port_log_id_t_arr(ports_arr)
        if bth_arr1:
            delete_uint8_t_arr(bth_arr1)
        if bth_arr2:
            delete_uint8_t_arr(bth_arr2)
        if bth_arr3:
            delete_uint8_t_arr(bth_arr3)
        if bth_arr4:
            delete_uint8_t_arr(bth_arr4)
        if ports_range_arr:
            delete_sx_ar_classifier_l4_port_range_t_arr(ports_range_arr)


def ar_config_threshold(handle, cmd, congestion_thresh_lo, congestion_thresh_med, congestion_thresh_hi):
    """
    This API configures adaptive routing threshold values
    Args:
        Handle                  SDK handle
        cmd (int):              command enum
        congestion_thresh_lo (int)
        congestion_thresh_med (int)
        congestion_thresh_hi (int)

    """

    ar_threshold_p = new_sx_ar_congestion_threshold_attr_t_p()

    try:
        port_threshold = sx_ar_congestion_threshold_values_t()

        port_threshold.congestion_thresh_lo = congestion_thresh_lo
        port_threshold.congestion_thresh_med = congestion_thresh_med
        port_threshold.congestion_thresh_hi = congestion_thresh_hi

        ar_congestion = sx_ar_congestion_threshold_attr_t()
        ar_congestion.port_threshold = port_threshold

        sx_ar_congestion_threshold_attr_t_p_assign(ar_threshold_p, ar_congestion)

        rc = sx_api_ar_congestion_threshold_set(handle, cmd, ar_threshold_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_congestion_threshold_set failed, rc %d" % (rc)

        print("Configured AR threshold values, rc: %d " % (rc))

    finally:
        delete_sx_ar_congestion_threshold_attr_t_p(ar_threshold_p)


def ar_config_shaper_rate_set(handle, rate_from, rate_to):
    """
    This API sets the AR shaper rate configuration parameters.
      To prevent moving a large amount of flows from one egress port
      to another egress port in a short period of time
      two types of shapers per port are used:

      A shaper per egress port for the number of flows that changed their destination to the egress port
      A shaper per egress port for the number of flows that changed their destination from the egress port

    Args:
        Handle                  SDK handle
        rate_from (short)
        rate_to (short)

    """

    shaper_attr_p = new_sx_ar_shaper_attr_t_p()

    try:
        shaper_attr = sx_ar_shaper_attr_t()
        shaper_attr.shaper_rate_from = rate_from
        shaper_attr.shaper_rate_to = rate_to

        sx_ar_shaper_attr_t_p_assign(shaper_attr_p, shaper_attr)

        rc = sx_api_ar_shaper_rate_set(handle, SX_ACCESS_CMD_SET, shaper_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_shaper_rate_set failed [rate_from=%d, rate_to=%d], rc %d" % (rate_from, rate_to, rc)

        print("Configured AR shaper rates rate_from=%d rate_to=%d, rc: %d " % (rate_from, rate_to, rc))

    finally:
        delete_sx_ar_shaper_attr_t_p(shaper_attr_p)


def ar_config_link_utilization(handle, cmd, log_port, link_utilization_thresh):
    """
    This API configures adaptive routing link utilization threshold
    Args:
        Handle                          SDK handle
        cmd (int):                      command enum
        log_port(int)
        link_utilization_thresh (int)   Units of 1000 bps and 200mbps granularity.
                                        Link utilization = link_utilization_threshold * 1000,
                                        Should be a multiplication of 200mbps.
                                        Default value: 70% of link speed.

    """

    ar_link_utilization_attr_p = new_sx_ar_link_utilization_attr_t_p()

    try:
        ar_link_utilization_attr = sx_ar_link_utilization_attr_t()

        ar_link_utilization_attr.link_utilization_threshold = link_utilization_thresh

        sx_ar_link_utilization_attr_t_p_assign(ar_link_utilization_attr_p, ar_link_utilization_attr)

        rc = sx_api_ar_link_utilization_threshold_set(handle, cmd, log_port, ar_link_utilization_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_ar_link_utilization_threshold_set failed [log_port=0x%x], rc %d" % (log_port, rc)

        print("Configured AR link utilization on port 0x%x, rc: %d " % (log_port, rc))

    finally:
        delete_sx_ar_link_utilization_attr_t_p(ar_link_utilization_attr_p)


def example_adaptive_routing_rif_init(handle, vrid, log_port):

    # disable autolearn
    set_auto_learn_port(handle, log_port, SX_FDB_LEARN_MODE_DONT_LEARN)

    # vport init
    log_vport = create_vport(handle, log_port, 5, SX_TAGGED_MEMBER)

    # set port state to up
    set_port_state(handle, log_vport, SX_PORT_ADMIN_STATUS_UP)

    # create adaptive routing rif
    rif = create_adaptive_routing_rif(handle, vrid, log_vport, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08))

    return rif, log_vport


def example_adaptive_routing_rif_deinit(handle, log_port, log_vport):
    # vport deinit
    delete_vport(handle, log_port, log_vport, 5, SX_TAGGED_MEMBER)


def example_ecmp_hash(handle, log_port, deinit_flag):
    # Set global ECMP hash params
    hash_type = SX_ROUTER_ECMP_HASH_TYPE_XOR
    symmetric = True
    seed = 14142
    # Since symmetric hash is True, enabling in hash bitmask should be in couples, source and destination.
    # Here both SX_ROUTER_ECMP_HASH_SRC_IP, SX_ROUTER_ECMP_HASH_DST_IP are enabled.
    hash = 3
    ecmp_hash_params_set(handle, hash_type, symmetric, seed, hash)
    # Set ECMP hash params on PORT1
    hash_type = SX_ROUTER_ECMP_HASH_TYPE_CRC
    symmetric = False
    seed = 31415

    # Set ECMP hash params of PORT1
    # SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4 - Enable L2 fields for IPv4 and IPV6 packets.
    # SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP - Enable IPv4 fields for TCP/UDP packets.
    enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4,
               SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP]
    fields = [SX_ROUTER_ECMP_HASH_OUTER_SMAC,
              SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_0,
              SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_0]
    ecmp_port_hash_params_set(handle, log_port, hash_type, symmetric, seed, enables, fields)
    ecmp_port_hash_params_get_and_validate(handle, log_port, hash_type, symmetric, seed, enables, fields)

    # After calling sx_api_router_ecmp_port_hash_params_set, legacy API sx_api_router_ecmp_hash_params_set is disabled

    # Add enables and fields to ECMP hash params of PORT1
    add_enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV6,
                   SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP]
    add_fields = [SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7]
    enables += add_enables
    fields += add_fields
    ecmp_port_hash_params_add(handle, log_port, add_enables, add_fields)
    ecmp_port_hash_params_get_and_validate(handle, log_port, hash_type, symmetric, seed, enables, fields)

    if deinit_flag:
        # Delete enables and fields from ECMP hash params on PORT1
        delete_enables = [SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4]
        delete_fields = [SX_ROUTER_ECMP_HASH_OUTER_SMAC]
        enables = [enable for enable in enables if enable not in delete_enables]
        fields = [field for field in fields if field not in delete_fields]
        ecmp_port_hash_params_delete(handle, log_port, delete_enables, delete_fields)
        ecmp_port_hash_params_get_and_validate(handle, log_port, hash_type, symmetric, seed, enables, fields)


def adaptive_router_flow(handle, vrid, rif, log_port, deinit_flag):

    NEIGH_MAC_1 = ether_addr(0xE4, 0x1D, 0x2D, 0x1E, 0x6C, 0x81)

    # Adaptive routing library init
    ar_init(handle)

    # Configure AR PROFILE 0
    ar_profile_create(handle, SX_AR_PROFILE_0_E, SX_AR_PROFILE_MODE_FREE_E, 0, 2, True, True, 100)

    # Set AR default classification
    ar_config_default_classification(handle, SX_ACCESS_CMD_SET, SX_AR_CLASSIFIER_ACTION_PROFILE0_E)

    # Set AR classifier 0
    ar_config_classification_set(handle,
                                 classifier_id=SX_AR_CLASSIFIER_INDEX_0_E,
                                 action_type=SX_AR_CLASSIFIER_ACTION_PROFILE0_E,
                                 log_ports=[log_port],
                                 l3=SX_AR_CLASSIFIER_L3_IPV4_E,
                                 l4=SX_AR_CLASSIFIER_L4_TCP_E,
                                 switch_priorities=list(range(14)),
                                 bth_opcodes_4_0=[0, 1, 2, 3, 6],
                                 port_ranges=[(1, 65000, SX_AR_CLASSIFIER_L4_PROTO_TCP_E, SX_AR_CLASSIFIER_L4_PORT_SRC_E), (100, 60000, SX_AR_CLASSIFIER_L4_PROTO_UDP_E, SX_AR_CLASSIFIER_L4_PORT_DEST_E)])

    # Set adaptive routing threshold values
    ar_config_threshold(handle, SX_ACCESS_CMD_SET, 100, 200, 300)

    # Set adaptive routing shapers rates
    ar_config_shaper_rate_set(handle, 5, 5)

    # Set AR link utilization threshold
    ar_config_link_utilization(handle, SX_ACCESS_CMD_SET, log_port, 200000)

    # create empty external ECMP container
    next_hops_params_list = []

    ecmp_id = create_external_ecmp_container(handle, next_hops_params_list)

    # Set ECMP container attributes
    container_group_size = 4096
    set_ecmp_attributes(handle, ecmp_id, SX_ECMP_TYPE_ADAPTIVE_E, group_size=container_group_size)

    # Add Next hops to Adaptive ECMP
    next_hops_params_list.append({RIF_STR: rif,
                                  IP_STR: "22.33.0.2",
                                  WEIGHT_STR: 1})
    next_hops_params_list.append({RIF_STR: rif,
                                  IP_STR: "22.33.0.3",
                                  WEIGHT_STR: 2})
    next_hops_params_list.append({RIF_STR: rif,
                                  IP_STR: "22.33.0.4",
                                  WEIGHT_STR: 3})
    next_hops_params_list.append({RIF_STR: rif,
                                  IP_STR: "22.33.0.5",
                                  WEIGHT_STR: 4})
    next_hops_params_list.append({RIF_STR: rif,
                                  IP_STR: "22.33.0.6",
                                  WEIGHT_STR: 5})

    modify_external_ecmp_container(handle, ecmp_id, next_hops_params_list)

    create_ar_uc_route(handle, vrid, "100.100.128.0", "255.255.255.0", ecmp_id, False, SX_AR_CLASSIFIER_ACTION_PROFILE0_E)

    # resolve neighbors
    add_neigh(handle, rif, "22.33.0.2", NEIGH_MAC_1)
    add_neigh(handle, rif, "22.33.0.3", NEIGH_MAC_1)
    add_neigh(handle, rif, "22.33.0.4", NEIGH_MAC_1)
    add_neigh(handle, rif, "22.33.0.5", NEIGH_MAC_1)
    add_neigh(handle, rif, "22.33.0.6", NEIGH_MAC_1)

    if deinit_flag:

        # delete all next hop uc routes
        delete_all_next_hops_uc_routes_per_vrid(handle, vrid)

        # destroy external ECMP container
        destroy_ecmp_container(handle, ecmp_id)

        # delete all neighbors per rif
        delete_all_neigh_per_rif(handle, rif)

        # delete rif
        delete_rif(handle, vrid, rif)

        # Adaptive routing library init
        ar_deinit(handle)


def adaptive_routing_example(handle, vrid, log_port, deinit_flag):
    rif, log_vport = example_adaptive_routing_rif_init(handle, vrid, log_port)
    adaptive_router_flow(handle, vrid, rif, log_port, deinit_flag)
    if deinit_flag:
        example_adaptive_routing_rif_deinit(handle, log_port, log_vport)

######################################################
#    main
######################################################


def main():
    SPECTRUM_SWID = 0

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    port_list = mapPortAndInterfaces(handle)
    PORT1 = port_list[0]

    args = parse_args()

    # Check chip type
    chip_type = get_chip_type(handle, False)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("Adaptive routing is not available on SPC1")
        sx_api_close(handle)
        sys.exit(0)

    try:
        orig_learn_mode = get_auto_learn_port(handle, PORT1)

        router_init(handle, ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE)

        example_ecmp_hash(handle, PORT1, args.deinit)

        vrid = create_vrid(handle)

        adaptive_routing_example(handle, vrid, PORT1, args.deinit)

        if args.deinit:
            delete_vrid(handle, vrid)
            router_deinit(handle)
            set_auto_learn_port(handle, PORT1, orig_learn_mode)

    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
