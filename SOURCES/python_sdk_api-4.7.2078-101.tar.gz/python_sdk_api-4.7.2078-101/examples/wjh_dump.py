#!/usr/bin/env python
'''
This file contains Python front end for "What just happened" client feature and does the following with respective options
1. --enable-discard - starts the wjh tool agent with monitoring enabled for normal discard traps This needs to be executed with root privileges.
2. --enable-discard-ex - starts the wjh tool agent with monitoring enabled for extended discard traps. This needs to be executed with root privileges.
2. --count - counts the packets trapped in WJH specific queue.
3. --save -  saves the packets trapped in WJH queue into a file.
4. --flush - flushes the packets trapped in WJH queue.
5. --disable  - stops the WJH tool agent.
6. --status - shows the status of WJH tool agent.
'''

import argparse
import subprocess
import socket
import time
import os
import sys

######################################################
#    defines
######################################################
WJH_BACKEND_SCRIPT = 'server_wjh_tool.py'
WJH_DIR_SLASH = '/'
WJH_MONITOR_SERVER_PORT = 10000
WJH_TOOL_BUF_SIZE = 1024
WJH_SOCKET_TIMEOUT = 5
WJH_SERVER_UPTIME_WAIT_PERIOD = 2
WJH_CMD_MONITOR_ENABLE = 'e'
WJH_CMD_MONITOR_ENABLEX = 'x'
WJH_CMD_MONITOR_DISABLE = 'd'
WJH_CMD_COUNT_PACKETS = 'c'
WJH_CMD_SAVE_PACKETS = 's'
WJH_CMD_FLUSH_PACKETS = 'f'
WJH_CMD_QUERY_STATUS = 'q'

WJH_CMD_TRAP_GROUP_MODE_AUTO = 'a'
WJH_CMD_TRAP_GROUP_MODE_STATIC = 's'
WJH_CMD_TRAP_GROUP_MODE_DYNAMIC = 'd'

trap_group_mode_to_cmd = {
    "auto": WJH_CMD_TRAP_GROUP_MODE_AUTO,
    "static": WJH_CMD_TRAP_GROUP_MODE_STATIC,
    "dynamic": WJH_CMD_TRAP_GROUP_MODE_DYNAMIC,
}

# API to send/receive message to/from WJH tool server


def wjh_client_send(buf):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(WJH_SOCKET_TIMEOUT)
    server_address = ('localhost', WJH_MONITOR_SERVER_PORT)
    data = None
    buf = buf.encode()

    try:
        sock.connect(server_address)
        sock.sendall(buf)
        data = sock.recv(WJH_TOOL_BUF_SIZE)
    except Exception:
        pass
    finally:
        from time import sleep
        sleep(1)
        sock.close()
        if type(data) is bytes:
            data = str(data.decode())
        return data


def wjh_action_enable(trap_group_mode):
    path = os.path.dirname(sys.argv[0])
    python_version = sys.version_info.major
    subprocess.Popen(["python{}".format(python_version), path + WJH_DIR_SLASH + WJH_BACKEND_SCRIPT])
    time.sleep(WJH_SERVER_UPTIME_WAIT_PERIOD)
    data = wjh_client_send(WJH_CMD_MONITOR_ENABLE + trap_group_mode_to_cmd[trap_group_mode])
    if data:
        print(('%s' % data))
    else:
        print("Failed to enable the tool - please try again")


def wjh_action_enablex(trap_group_mode):
    path = os.path.dirname(sys.argv[0])
    python_version = sys.version_info.major
    subprocess.Popen(["python{}".format(python_version), path + WJH_DIR_SLASH + WJH_BACKEND_SCRIPT])
    time.sleep(WJH_SERVER_UPTIME_WAIT_PERIOD)
    data = wjh_client_send(WJH_CMD_MONITOR_ENABLEX + trap_group_mode_to_cmd[trap_group_mode])
    if data:
        print(('%s' % data))
    else:
        print("Failed to enable the tool - please try again")


def wjh_action_count():
    data = wjh_client_send(WJH_CMD_COUNT_PACKETS)
    if data:
        print(('%s' % data))
    else:
        print("Failed to get count - please enable the tool")


def wjh_action_flush():
    data = wjh_client_send(WJH_CMD_FLUSH_PACKETS)
    if data:
        print(('%s' % data))
    else:
        print("Failed to flush the packets - please enable the tool")


def wjh_action_save():
    data = wjh_client_send(WJH_CMD_SAVE_PACKETS)
    if data:
        print(('%s' % data))
    else:
        print("Failed to save the packets - please enable the tool")


def wjh_action_disable():
    data = wjh_client_send(WJH_CMD_MONITOR_DISABLE)
    if data:
        print(('%s' % data))
    else:
        print("Failed to disable the tool - please check status and try again")


def wjh_action_status():
    data = wjh_client_send(WJH_CMD_QUERY_STATUS)
    if data:
        print(('%s' % data))
    else:
        print("WJH packet dump utility - Monitoring is Off")


parser = argparse.ArgumentParser(description='WJH packet dump utility')
parser.add_argument('--count', action='store_true', help='shows the count of WJH captured packets')
parser.add_argument('--disable', action='store_true', help='disables the WJH packet dump utility')
parser.add_argument('--enable-discard', action='store_true', help='enables the WJH packet dump utility with normal traps')
parser.add_argument('--enable-discard-ex', action='store_true', help='enables the WJH packet dump utility with extended traps')
parser.add_argument('--trap_group_mode', default='auto', choices=trap_group_mode_to_cmd.keys(), help='trap group allocation mode when enable the utility')
parser.add_argument('--flush', action='store_true', help='flushes the WJH captured packets')
parser.add_argument('--save', action='store_true', help='saves the WJH captured packets')
args = parser.parse_args()

wjh_action_status()

if args.enable_discard:
    wjh_action_enable(args.trap_group_mode)
elif args.enable_discard_ex:
    wjh_action_enablex(args.trap_group_mode)
elif args.disable:
    wjh_action_disable()
elif args.save:
    wjh_action_save()
elif args.count:
    wjh_action_count()
elif args.flush:
    wjh_action_flush()
else:
    print("usage: wjh_dump.py [-h|--help] [--count] [--disable] [--enable-discard] [--enable-discard-ex] [--trap_group_mode] [--flush] [--save]")
