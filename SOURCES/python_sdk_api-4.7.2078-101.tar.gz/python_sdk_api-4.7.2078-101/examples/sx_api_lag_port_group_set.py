#!/usr/bin/env python
"""
This file contains a python commands example for the LAG module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################

SWID = 0
DEVICE_ID = 1
MAX_PORTS = 64
port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

parser = argparse.ArgumentParser(description='sx_api_lag_port_group_set API')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

""" ############################################################################################ """


def make_lag():
    # Creates a new LAG.
    lag_id_p = new_sx_port_log_id_t_p()
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, SWID, lag_id_p, None, 0)
    lag_id = sx_port_log_id_t_p_value(lag_id_p)
    print(("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc)))

    rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
    print(("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    return lag_id


""" ############################################################################################ """


def add_delete_lag_ports(cmd, swid, lag_id_p, port_list, port_cnt):
    """ ############################################################################################ """
    """ ADD/DELETE LAG MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD PORTS TO LAG ------------------------------")
    elif cmd == SX_ACCESS_CMD_DELETE:
        print("--------------- DELETE PORTS FROM LAG ------------------------------")
    else:
        print("--------------- Wrong cmd  ------------------------------")
        sys.exit(errno.EACCES)

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_id_p, port_list, port_cnt)
    print(("sx_api_lag_port_group_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def destroy_lag(lag_id):
    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)
    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, SWID, lag_id_p, None, 0)
    print("sx_api_lag_port_group_set DESTROY lag_id 0x%x , rc %d " % (lag_id, rc))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


""" ############################################################################################ """


def main():
    # 0. Get original RSTP States of used ports - They change during lag operations
    original_rstp_modes = {}
    stp_state_p = new_sx_mstp_inst_port_state_t_p()
    for port in [PORT1, PORT2]:
        rc = sx_api_rstp_port_state_get(handle, port, stp_state_p)
        assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_get failed, port 0x%x, rc: %d" % (port, rc)
        original_rstp_modes[port] = sx_mstp_inst_port_state_t_p_value(stp_state_p)
    delete_sx_mstp_inst_port_state_t_p(stp_state_p)

    lag_id = make_lag()

    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)

    ports_arr = new_sx_port_log_id_t_arr(2)
    sx_port_log_id_t_arr_setitem(ports_arr, 0, PORT1)
    sx_port_log_id_t_arr_setitem(ports_arr, 1, PORT2)

    ports_ingr_filter_mode = {}
    ports_ingr_filter_mode[PORT1] = ingr_filter_get(PORT1)
    ports_ingr_filter_mode[PORT2] = ingr_filter_get(PORT2)

    add_delete_lag_ports(SX_ACCESS_CMD_ADD, SWID, lag_id_p, ports_arr, 2)

    if args.deinit:
        add_delete_lag_ports(SX_ACCESS_CMD_DELETE, SWID, lag_id_p, ports_arr, 2)
        destroy_lag(lag_id)

        for port, ingr_filter in list(ports_ingr_filter_mode.items()):
            add_ports_to_vlan(1, {port: SX_UNTAGGED_MEMBER})
            ingr_filter_set(port, ingr_filter)

        for port, rstp_state in original_rstp_modes.items():
            rc = sx_api_rstp_port_state_set(handle, port, rstp_state)
            assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, port 0x%x, rc: %d" % (port, rc)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()

sx_api_close(handle)
