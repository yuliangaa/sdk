#!/usr/bin/env python
'''
This file contains Python command example for the VxLAN Tunnel Dump module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''

import sys
import errno
import os
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='VXLAN Tunnel COS Dump utility')
parser.add_argument('-t', dest='vxlan_tunnel_id', default=None, type=auto_int, help='Optional VxLAN Tunnel ID')
args = parser.parse_args()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

tunnel_input = args.vxlan_tunnel_id
tunnel_id_list = []

if tunnel_input is None:
    # VXLAN
    tunnel_id_cnt_p = new_uint32_t_p()
    tunnel_id_cnt_v6_p = new_uint32_t_p()
    filter_p = new_sx_tunnel_filter_t_p()
    filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
    filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN

    uint32_t_p_assign(tunnel_id_cnt_p, 0)
    module_verbosity, api_verbosity = tunnel_module_verbosity_level_get(handle)
    tunnel_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_p)
    tunnel_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if tunnel module is initialized.
            print("####################################")
            print("# Tunnel Module is not initialized ")
            print("####################################")
        else:
            print("Tunnel Iterator failed with rc (%d)" % (rc))
            sys.exit(rc)
    else:
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)
        tunnel_id_list_p = new_sx_tunnel_id_t_arr(tunnel_id_cnt)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p, tunnel_id_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)

        # VXLAN v6
        filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
        filter_p.type = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6
        uint32_t_p_assign(tunnel_id_cnt_v6_p, 0)
        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)
        tunnel_id_cnt_v6 = uint32_t_p_value(tunnel_id_cnt_v6_p)
        tunnel_id_list_p_v6 = new_sx_tunnel_id_t_arr(tunnel_id_cnt_v6)

        rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p_v6, tunnel_id_cnt_v6_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_tunnel_iter_get failed for VxLAN IPv6, rc = %d" % (rc))
            sys.exit(rc)

        for i in range(tunnel_id_cnt):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p, i)
            tunnel_id_list.append(tunnel_id)

        for i in range(tunnel_id_cnt_v6):
            tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p_v6, i)
            tunnel_id_list.append(tunnel_id)

else:
    tunnel_id_cnt = 1
    tunnel_id_list = [tunnel_input]

tunnel_encap_cos_data_p = new_sx_tunnel_cos_data_t_p()
tunnel_decap_cos_data_p = new_sx_tunnel_cos_data_t_p()
tunnel_attr_p = new_sx_tunnel_attribute_t_p()


for tunnel_id in tunnel_id_list:
    rc1 = sx_api_tunnel_get(handle, tunnel_id, tunnel_attr_p)
    if rc1 == SX_STATUS_MODULE_UNINITIALIZED:
        # Check if tunnel module is initialized.
        print("####################################")
        print("# Tunnel Module is not initialized ")
        print("####################################")
        sys.exit(1)

    if (rc1 == SX_STATUS_SUCCESS):
        tunnel_attr = sx_tunnel_attribute_t_p_value(tunnel_attr_p)
        type = vxlan_type_dict.get(tunnel_attr.type)
        if type is None:
            print("Unsupported tunnel type (:%d)" % (type))
            sys.exit(0)
        tunnel_id_str = hex(tunnel_id)
        enc_cos_priority = 0
        enc_cos_color = 0
        enc_dscp_rewrite_action = 'N/A'
        enc_cos_dscp_action = 'N/A'
        enc_dscp_value = 0
        dec_cos_priority = 0
        dec_cos_color = 0
        dec_dscp_rewrite_action = 'N/A'
        dec_cos_dscp_action = 'N/A'
        dec_dscp_value = 0

        if tunnel_attr.direction in [SX_TUNNEL_DIRECTION_ENCAP, SX_TUNNEL_DIRECTION_SYMMETRIC]:
            tunnel_cos_data = sx_tunnel_cos_data_t()
            tunnel_cos_data.param_type = SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E
            sx_tunnel_cos_data_t_p_assign(tunnel_encap_cos_data_p, tunnel_cos_data)
            rc2 = sx_api_tunnel_cos_get(handle, tunnel_id, tunnel_encap_cos_data_p)
            if (rc2 == SX_STATUS_SUCCESS):
                tunnel_data = sx_tunnel_cos_data_t_p_value(tunnel_encap_cos_data_p)
                enc_cos_priority = tunnel_data.prio_color.priority
                enc_cos_color = tunnel_data.prio_color.color
                enc_dscp_rewrite_action = dscp_rewrite_action_dict[tunnel_data.dscp_rewrite]
                enc_dscp_action = dscp_action_dict[tunnel_data.dscp_action]
                enc_dscp_value = tunnel_data.dscp_value
                encap_data_t_p = tunnel_data.cos_ecn_params.ecn_encap.ecn_encap_map
                print()
                print('-' * 128)
                print("Encap")
                print('-' * 128)
                print("|%20s|%20s|%20s|%20s|%20s|%20s|" % ("Tunnel ID", "Priority", "Color", "DSCP Rewrite Action", "DSCP Action", "DSCP Value"))
                print('-' * 128)
                print("|%20s|%20s|%20s|%20s|%20s|%20s|" % (tunnel_id_str, enc_cos_priority, enc_cos_color, enc_dscp_rewrite_action, enc_dscp_action, enc_dscp_value))
                print('-' * 128)

                print("Overlay ECN")
                print('-' * 53)
                print("|%12s|%12s|%12s|%12s|" % ("Non ECT(00)", "ECT1(01)", "ECT0(10)", "CE(11)"))
                print('-' * 53)
                for i in range(0, 4):
                    item_t = sx_tunnel_cos_ecn_encap_data_t_arr_getitem(encap_data_t_p, i)
                    print("|%11s" % (ecn_map_dict[item_t.egress_ecn]), end="")

                print("|")
                print('-' * 53)
                print()

        if tunnel_attr.direction in [SX_TUNNEL_DIRECTION_DECAP, SX_TUNNEL_DIRECTION_SYMMETRIC]:
            tunnel_cos_data.param_type = SX_TUNNEL_COS_PARAM_TYPE_DECAP_E
            sx_tunnel_cos_data_t_p_assign(tunnel_decap_cos_data_p, tunnel_cos_data)
            rc3 = sx_api_tunnel_cos_get(handle, tunnel_id, tunnel_decap_cos_data_p)

            if rc3 == SX_STATUS_SUCCESS:
                tunnel_data = sx_tunnel_cos_data_t_p_value(tunnel_decap_cos_data_p)
                dec_cos_priority = tunnel_data.prio_color.priority
                dec_cos_color = tunnel_data.prio_color.color
                dec_dscp_rewrite_action = dscp_rewrite_action_dict[tunnel_data.dscp_rewrite]
                dec_dscp_action = dscp_action_dict[tunnel_data.dscp_action]
                dec_dscp_value = tunnel_data.dscp_value

                print('-' * 128)

                print("Decap")
                print('-' * 128)
                print("|%20s|%20s|%20s|%20s|%20s|%20s|" % ("Tunnel ID", "Priority", "Color", "DSCP Rewrite Action", "DSCP Action", "DSCP Value"))
                print('-' * 128)
                print("|%20s|%20s|%20s|%20s|%20s|%20s|" % (tunnel_id_str, dec_cos_priority, dec_cos_color, dec_dscp_rewrite_action, dec_dscp_action, dec_dscp_value))
                print('-' * 128)

                print('-' * 108)
                print("|%10s|%10s|%20s|%20s|%20s|%20s|" % ("Inner", "Outer", "Non ECT(00)", "ECT1(01)", "ECT0(10)", "CE(11)"))
                print('-' * 108)

                for i in range(0, 4):
                    print("|%20s" % (ecn_map_dict[i]), end="")
                    for j in range(0, 4):
                        item_t = sx_tunnel_cos_ecn_decap_data_t()
                        rc = sx_tunnel_cos_ecn_decap_params_t_enc_decap_map_item_get(tunnel_data, item_t, i, j)
                        if rc != SX_STATUS_SUCCESS:
                            print("Could not retrieve decap cos data: rc=%d" % (rc))
                            sys.exit(0)
                        print("|%19s" % (ecn_map_dict[item_t.egress_ecn]), end="")
                    print("|")
                    print('-' * 108)

sx_api_close(handle)
