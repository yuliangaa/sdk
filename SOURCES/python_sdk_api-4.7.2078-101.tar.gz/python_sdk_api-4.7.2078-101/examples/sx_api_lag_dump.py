#!/usr/bin/env python
"""
This file contains a python commands example for the LAG module.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import errno
import os
from python_sdk_api.sx_api import *
from test_infra_common import *

print_api_example_disclaimer()


def build_vlag(lag, vlan):
    return SX_PORT_TYPE_VLAG << SX_PORT_TYPE_ID_OFFS | (vlan << SX_PORT_VLAN_ID_OFFS) | (lag)


oper_dict = {0: 'NONE', 1: 'UP', 2: 'DOWN', 4: 'DOWN_BY_FAIL'}
collector_dict = {0: 'Enable', 1: 'Disable'}
distributor_dict = {0: 'Enable', 1: 'Disable'}

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

swid_cnt_p = new_uint32_t_p()
uint32_t_p_assign(swid_cnt_p, 0)
rc = sx_api_port_swid_list_get(handle, None, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)
swid_list_p = new_sx_swid_t_arr(swid_cnt)
rc = sx_api_port_swid_list_get(handle, swid_list_p, swid_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_port_swid_list_get failed, rc = %d" % (rc))
    sys.exit(rc)
swid_cnt = uint32_t_p_value(swid_cnt_p)

lag_id_cnt_p = new_uint32_t_p()
uint32_t_p_assign(lag_id_cnt_p, 0)
lag_id = 0
printed_header = False

if swid_cnt == 0:
    print("No SWID entries found!")

for i in range(0, swid_cnt):
    swid = sx_swid_t_arr_getitem(swid_list_p, i)
    rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET, swid, lag_id, None, None, lag_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)
    lag_id_list_p = new_sx_port_log_id_t_arr(lag_id_cnt)
    rc = sx_api_lag_port_group_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, swid, lag_id, None, lag_id_list_p,
                                        lag_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_lag_port_group_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    lag_id_cnt = uint32_t_p_value(lag_id_cnt_p)

    # Get ports count
    port_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(port_cnt_p, 0)
    port_attributes_list = new_sx_port_attributes_t_arr(0)
    rc = sx_api_port_device_get(handle, 1, swid, port_attributes_list, port_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_device_get failed, rc = %d" % (rc))
        sys.exit(rc)
    port_cnt = uint32_t_p_value(port_cnt_p)

    # Get ports
    port_attributes_list = new_sx_port_attributes_t_arr(port_cnt)
    rc = sx_api_port_device_get(handle, 1, swid, port_attributes_list, port_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_port_device_get failed, rc = %d")
        sys.exit(rc)

    port_map = {}
    for p in range(0, port_cnt):
        port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, p)
        port_map[port_attributes.log_port] = port_attributes

    if lag_id_cnt == 0 and not printed_header:
        print("No LAG found!")

    if lag_id_cnt > 0:
        if not printed_header:
            print("LAG Members Table")
            print("===============================================================================================================")
            print("|%5s|%17s|%15s|%5s|%15s|%11s|%10s|%12s|%11s|" % (
                "SWID", "LAG Logical Port", "LAG Oper State", "PVID", "Member Port ID", "Port Label", "Collector",
                "Distributor", "Oper State"))
            print("===============================================================================================================")
            printed_header = True

        for j in range(0, lag_id_cnt):
            lag_id = sx_port_log_id_t_arr_getitem(lag_id_list_p, j)
            oper_state_p = new_sx_port_oper_state_t_p()
            admin_state_p = new_sx_port_admin_state_t_p()
            module_state_p = new_sx_port_module_state_t_p()
            rc = sx_api_port_state_get(handle, lag_id, oper_state_p, admin_state_p, module_state_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_state_get failed, rc = %d" % (rc))
                sys.exit(rc)

            pvid_p = new_sx_vid_t_p()
            rc = sx_api_vlan_port_pvid_get(handle, lag_id, pvid_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_vlan_port_pvid_get failed, rc = %d" % (rc))
                sys.exit(rc)
            pvid = sx_vid_t_p_value(pvid_p)

            lag_id_str = "0x%x" % lag_id

            print("|%5s %17s %15s %5d|" % (
                swid, lag_id_str, oper_dict[sx_port_oper_state_t_p_value(oper_state_p)], pvid), end="")

            log_port_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(log_port_cnt_p, port_cnt)
            log_port_list_p = new_sx_port_log_id_t_arr(port_cnt)
            rc = sx_api_lag_port_group_get(handle, swid, lag_id, log_port_list_p, log_port_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_lag_port_group_get failed, rc = %d" % (rc))
                sys.exit(rc)
            log_port_cnt = uint32_t_p_value(log_port_cnt_p)
            if log_port_cnt == 0:
                print("%14s|%11s|%10s|%12s|%11s|" % ("", "", "", "", ""))
                print("===============================================================================================================")
            else:
                for k in range(0, log_port_cnt):
                    log_port_id = sx_port_log_id_t_arr_getitem(log_port_list_p, k)
                    collector_mode_p = new_sx_collector_mode_t_p()
                    rc = sx_api_lag_port_collector_get(handle, lag_id, log_port_id, collector_mode_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_lag_port_collector_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    collector_mode = sx_collector_mode_t_p_value(collector_mode_p)

                    distributor_mode_p = new_sx_distributor_mode_t_p()
                    rc = sx_api_lag_port_distributor_get(handle, lag_id, log_port_id, distributor_mode_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_lag_port_distributor_get failed, rc = %d" % (rc))
                        sys.exit(rc)
                    distributor_mode = sx_distributor_mode_t_p_value(distributor_mode_p)

                    rc = sx_api_port_state_get(handle, log_port_id, oper_state_p, admin_state_p, module_state_p)
                    if rc != SX_STATUS_SUCCESS:
                        print("sx_api_port_state_get failed, rc = %d" % (rc))
                        sys.exit(rc)

                    log_port_id_str = "0x%x" % log_port_id
                    if k == 0:
                        print("%14s|%11d|%10s|%12s|%11s|" % (log_port_id_str,
                                                             port_map[log_port_id].port_mapping.module_port + 1,
                                                             collector_dict[collector_mode],
                                                             distributor_dict[distributor_mode],
                                                             oper_dict[sx_port_oper_state_t_p_value(oper_state_p)]))
                    else:
                        print("|%45s|%15s|%11d|%10s|%12s|%11s|" % ("", log_port_id_str,
                                                                   port_map[log_port_id].port_mapping.module_port + 1,
                                                                   collector_dict[collector_mode],
                                                                   distributor_dict[distributor_mode],
                                                                   oper_dict[
                                                                       sx_port_oper_state_t_p_value(oper_state_p)]))
                    if k == (log_port_cnt - 1):
                        print("===============================================================================================================")
                    else:
                        print("|%5s %17s %15s %5s|----------------------------------------------------------------" % (
                            "", "", "", ""))

        print("")
        print("LAG Vport table")
        print("===================================================================================")
        print("|%5s|%17s|%15s|%5s|%13s|%5s|%15s|" % (
            "SWID", "LAG Logical Port", "LAG Oper State", "PVID", "Virtual Port", "Vlan", "Flow Counter ID"))
        print("===================================================================================")
        printed_header = True

        for j in range(0, lag_id_cnt):
            lag_id = sx_port_log_id_t_arr_getitem(lag_id_list_p, j)
            oper_state_p = new_sx_port_oper_state_t_p()
            admin_state_p = new_sx_port_admin_state_t_p()
            module_state_p = new_sx_port_module_state_t_p()
            rc = sx_api_port_state_get(handle, lag_id, oper_state_p, admin_state_p, module_state_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_state_get failed, rc = %d" % (rc))
                sys.exit(rc)

            pvid_p = new_sx_vid_t_p()
            rc = sx_api_vlan_port_pvid_get(handle, lag_id, pvid_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_vlan_port_pvid_get failed, rc = %d" % (rc))
                sys.exit(rc)
            pvid = sx_vid_t_p_value(pvid_p)

            lag_id_str = "0x%x" % lag_id

            print("|%5s %17s %15s %5d|" % (
                swid, lag_id_str, oper_dict[sx_port_oper_state_t_p_value(oper_state_p)], pvid), end=" ")

            vport_cnt_p = new_uint32_t_p()
            uint32_t_p_assign(vport_cnt_p, 0)
            rc = sx_api_port_vport_get(handle, lag_id, None, vport_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_vport_get failed, rc = %d" % (rc))
                sys.exit(rc)
            vport_cnt = uint32_t_p_value(vport_cnt_p)
            vlan_list_p = new_sx_vlan_id_t_arr(vport_cnt)
            rc = sx_api_port_vport_get(handle, lag_id, vlan_list_p, vport_cnt_p)
            if rc != SX_STATUS_SUCCESS:
                print("sx_api_port_vport_get failed, rc = %d" % (rc))
                sys.exit(rc)
            if vport_cnt == 0:
                print("%12s|%5s|%15s|" % ("", "", ""))
                print("===================================================================================")
            else:
                for k in range(0, vport_cnt):
                    vlan = sx_vlan_id_t_arr_getitem(vlan_list_p, k)
                    vport = build_vlag(lag_id, vlan)
                    counter_p = new_sx_flow_counter_id_t_p()
                    rc = sx_api_port_vport_counter_bind_get(handle, vport, counter_p)
                    if rc == SX_STATUS_ENTRY_NOT_FOUND:
                        counter = "N/A"
                    else:
                        if rc != SX_STATUS_SUCCESS:
                            print("sx_api_port_vport_counter_bind_get failed, rc = %d" % (rc))
                            sys.exit(rc)
                        counter = sx_flow_counter_id_t_p_value(counter_p)

                    vport_str = "0x%x" % vport
                    if k == 0:
                        print("%12s|%5d|%15s|" % (vport_str,
                                                  vlan,
                                                  str(counter)))
                    else:
                        print("|%45s|%13s|%5d|%15s|" % ("",
                                                        vport_str,
                                                        vlan,
                                                        str(counter)))
                    if k == (vport_cnt - 1):
                        print("===================================================================================")
                    else:
                        print("|%5s %17s %5s %15s|------------------------------------" % ("", "", "", ""))

sx_api_close(handle)
