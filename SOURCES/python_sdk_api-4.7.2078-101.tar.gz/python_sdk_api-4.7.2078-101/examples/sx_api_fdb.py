#!/usr/bin/env python
'''
This file contains a Python commands example for the FDB module.

Python commands syntax is very similar to the Switch SDK APIs.

You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

\section cases Example Flow

The example below performs the following configuration operations:

1. Sets and gets FDB age time.

2. Sets FDB polling interval.

3. Sets global/per SWID learning modes.

4. Adds/Gets multiple unicast MAC address to/from FDB with different actions.

5. Gets amount of unicast MAC addresses - global, per port, per FID.

6. Sets/Gets limit on the amount of dynamic macs learned on port and FID.

7. Few options to delete (flush) unicast FDB entries.

8. Add/Get multicast MAC address to/from FDB.

9. Few options to delete (flush) multicast FDB entries.

'''
import errno
import sys
import argparse

from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_fdb')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]

# get current FDB age time for later de-configuration
original_age_time_p = new_sx_fdb_age_time_t_p()
rc = sx_api_fdb_age_time_get(handle, 0, original_age_time_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_age_time_get failed; rc=%d" % (rc)
original_age_time = sx_fdb_age_time_t_p_value(original_age_time_p)

# set FDB age time
rc = sx_api_fdb_age_time_set(handle, 0, 300)
print(("sx_api_fdb_age_time_set swid 0  age time: 300 sec, rc: %d " % (rc)))

# get FDB age time
age_time_p = new_sx_fdb_age_time_t_p()
rc = sx_api_fdb_age_time_get(handle, 0, age_time_p)
age_time = sx_fdb_age_time_t_p_value(age_time_p)
print(("sx_api_fdb_age_time_get swid 0  age time: %d sec, rc: %d " % (age_time, rc)))

# get current FDB poll interval of swid 0 for later de-configuration
original_polling_interval_p = new_sx_fdb_polling_interval_t_p()
rc = sx_api_fdb_polling_interval_get(handle, 0, original_polling_interval_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_polling_interval_get failed; rc=%d" % (rc)
original_polling_interval = sx_fdb_polling_interval_t_p_value(original_polling_interval_p)

# set FDB poll interval of swid 0 to 360 sec
rc = sx_api_fdb_polling_interval_set(handle, 0, 3600)
print(("sx_api_fdb_polling_interval_set swid 0 poll_int: %d sec, rc: %d " % (360, rc)))

# get current global FBD learn mode for later de-configuration
original_learn_mode_p = new_sx_fdb_learn_mode_t_p()
rc = sx_api_fdb_learn_mode_get(handle, 0, original_learn_mode_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_learn_mode_get failed; rc=%d" % (rc)
original_learn_mode = sx_fdb_learn_mode_t_p_value(original_learn_mode_p)

# set global FBD learn mode to DONT_LEARN
rc = sx_api_fdb_learn_mode_set(handle, 0, SX_FDB_LEARN_MODE_DONT_LEARN)
print(("sx_api_fdb_learn_mode_set swid 0 lean_mode disable, rc: %d " % (rc)))

# set global FBD learn mode to AUTO_LEARN
rc = sx_api_fdb_learn_mode_set(handle, 0, SX_FDB_LEARN_MODE_AUTO_LEARN)
print(("sx_api_fdb_learn_mode_set swid 0 lean_mode auto_learn, rc: %d " % (rc)))

# get current global FDB params for later de-configuration
original_learn_ctrl_p = new_sx_fdb_learn_ctrl_t_p()
rc = sx_api_fdb_global_params_get(handle, 0, original_learn_ctrl_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_global_params_get failed; rc=%d" % (rc)
original_learn_ctrl = sx_fdb_learn_ctrl_t_p_value(original_learn_ctrl_p)

# set global FDB params
learn_ctrl = sx_fdb_learn_ctrl_t()
learn_ctrl.svl_mode = SX_FDB_INDEPENDENT_VLAN_LEARNING
learn_ctrl.roam_mode = SX_FDB_LEARN_ROAM_MODE_DONT_LEARN
rc = sx_api_fdb_global_params_set(handle, 0, learn_ctrl)
print(("sx_api_fdb_global_params_set swid 0 INDEPENDENT_VLAN_LEARN and ROAM_MODE_DONT_LEARN, rc: %d " % (rc)))

learn_ctrl.svl_mode = SX_FDB_INDEPENDENT_VLAN_LEARNING
learn_ctrl.roam_mode = SX_FDB_LEARN_ROAM_MODE_LEARN
rc = sx_api_fdb_global_params_set(handle, 0, learn_ctrl)
print(("sx_api_fdb_global_params_set swid 0 INDEPENDENT_VLAN_LEARN and LEARN_ROAM_MODE_LEARN, rc: %d " % (rc)))

mac_list_p = new_sx_fdb_uc_mac_addr_params_t_arr(2)
data_cnt_p = new_uint32_t_p()
uint32_t_p_assign(data_cnt_p, 2)
mac_addr = ether_addr("00:02:c9:11:ad:ca")

mac_entry1 = sx_fdb_uc_mac_addr_params_t()
mac_entry1.mac_addr = mac_addr
mac_entry1.fid_vid = 5          # Filtering Identifier, VID for static MAC
mac_entry1.log_port = PORT1
mac_entry1.entry_type = SX_FDB_UC_STATIC
mac_entry1.action = SX_FDB_ACTION_MIRROR_TO_CPU
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 0, mac_entry1)

mac_entry2 = sx_fdb_uc_mac_addr_params_t()
mac_entry2.mac_addr = mac_addr
mac_entry2.fid_vid = 15          # Filtering Identifier, VID for static MAC
mac_entry2.log_port = PORT2
mac_entry2.entry_type = SX_FDB_UC_STATIC
mac_entry2.action = SX_FDB_ACTION_MIRROR_TO_CPU
sx_fdb_uc_mac_addr_params_t_arr_setitem(mac_list_p, 1, mac_entry2)

rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_ADD, 0, mac_list_p, data_cnt_p)
data_cnt = uint32_t_p_value(data_cnt_p)
print(("sx_api_fdb_uc_mac_addr_set added %d enties, rc: %d " % (data_cnt, rc)))

if args.deinit:
    rc = sx_api_fdb_uc_mac_addr_set(handle, SX_ACCESS_CMD_DELETE, 0, mac_list_p, data_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_uc_mac_addr_set failed; rc=%d" % rc

    rc = sx_api_fdb_global_params_set(handle, 0, original_learn_ctrl)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_global_params_set failed; rc=%d" % rc

    rc = sx_api_fdb_learn_mode_set(handle, 0, original_learn_mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_learn_mode_set failed; rc=%d" % rc

    rc = sx_api_fdb_polling_interval_set(handle, 0, original_polling_interval)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_polling_interval_set failed; rc=%d" % rc

    rc = sx_api_fdb_age_time_set(handle, 0, original_age_time)
    assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_age_time_set failed; rc=%d" % rc

sx_api_close(handle)

'''
\section usage Using Python

The example above demonstrates the parameter syntax of each command and is meant to help you get started.

You can start by running the example commands on your EVB or by using the iPython application.

Later on you can use the examples in order to build your own configuration flows.

You can also find specific syntax help by running the command name followed by a question mark or get a general syntax explanation by running the help command from any location.
'''
