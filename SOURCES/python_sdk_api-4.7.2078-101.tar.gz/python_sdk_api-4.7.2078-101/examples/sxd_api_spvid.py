#!/usr/bin/env python

import sys
import time
import os
import argparse
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib


def parse_args():
    parser = argparse.ArgumentParser(description='SPVID Set/Get example')
    parser.add_argument('--cmd', default=0, type=int, help="GET(0), SET(1).")
    parser.add_argument('--tport', default=0, type=int, help="Port is tunnel port.")
    parser.add_argument('--local_port', default=1, type=int, help="Local Port.")
    parser.add_argument('--egr_et_set', default=0, type=int, help="Derive Ethrtype at the egress port.")
    parser.add_argument('--et_vlan', default=0, type=int, help="Egress ethertype index value.")
    parser.add_argument('--pvid', default=1, type=int, help="Port VLAN ID.")
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    args = parser.parse_args()
    return args.cmd, args.tport, args.local_port, args.egr_et_set, args.et_vlan, args.pvid, args.deinit


def help_cmd():
    print("")
    print("The following example allows to execute Set/Get request for the SPVID EMAD.")
    print(sys.argv[0] + " [--cmd <cmd>] [--tport <tport>] [--local_port <port>] [--egr_et_set <et_vlan>] [--et_vlan <et_vlan>] [--pvid <pvid>]")
    print("")
    print("cmd: 0 - GET operation, 1 - SET operation. 0 by default.")
    print("tport: 0 - local_port is not tunnel port, 1 - local_port is tunnel port. 0 by default.")
    print("local_port: local port to use. 1 by default.")
    print("egr_et_set: 0 - derivce ethertype from ingress port, 1 - derive ethertype from egress port. 0 by default.")
    print("et_vlan: ethertype index to use for ingress port configuration. 0 by default.")
    print("pvid: default port VLAN ID. 1 by default.")
    print("")


def validate_input_parameters(cmd, tport, local_port, egr_et_set, et_vlan, pvid):
    if cmd != 0 and cmd != 1:
        print("Invalid input parameter: cmd.")
        help_cmd()
        sys.exit(0)

    if tport > 1:
        print("Invalid input parameter: tport.")
        help_cmd()
        sys.exit(0)

    if egr_et_set > 1:
        print("Invalid input parameter: egr_et_set.")
        help_cmd()
        sys.exit(0)


def sxd_init():
    print("[+] initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)


def run_example(cmd, tport, local_port, egr_et_set, et_vlan, pvid, deinit):

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0

    meta.access_cmd = SXD_ACCESS_CMD_GET if cmd == 0 else SXD_ACCESS_CMD_SET

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        original_spvid = ku_spvid_reg()

        original_spvid.tport = tport

        original_spvid.local_port, original_spvid.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

        meta.access_cmd = SXD_ACCESS_CMD_GET
        rc = sxd_access_reg_spvid(original_spvid, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get SPVID register, rc: %d" % (rc)

        meta.access_cmd = SXD_ACCESS_CMD_SET

    spvid = ku_spvid_reg()

    spvid.tport = tport

    spvid.local_port, spvid.lp_msb = common_lib.get_lsb_msb_of_local_port(local_port)

    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get SPVID Parameters:")
        print("[+] tport: ", spvid.tport)
        print("[+] local port: ", spvid.local_port)
        print("[+] lp_msb: ", spvid.lp_msb)
    else:
        spvid.egr_et_set = egr_et_set
        spvid.et_vlan = et_vlan
        spvid.port_default_vid = pvid
        print("[+] Set SPVID Parameters:")
        print("[+] tport: ", spvid.tport)
        print("[+] local port: ", spvid.local_port)
        print("[+] lp_msb: ", spvid.lp_msb)
        print("[+] egr_et_set: ", spvid.egr_et_set)
        print("[+] et_vlan: ", spvid.et_vlan)
        print("[+] port_default_vid: ", spvid.port_default_vid)

    rc = sxd_access_reg_spvid(spvid, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to query SPVID register, rc: %d" % (rc)

    print("[+] rc: ", rc)
    print("====================")
    if meta.access_cmd == SXD_ACCESS_CMD_GET:
        print("[+] Get SPVID Returned values from FW:")
        print("[+] tport: ", spvid.tport)
        print("[+] local port: ", spvid.local_port)
        print("[+] lp_msb: ", spvid.lp_msb)
        print("[+] egr_et_set: ", spvid.egr_et_set)
        print("[+] et_vlan: ", spvid.et_vlan)
        print("[+] port_default_vid: ", spvid.port_default_vid)

    if deinit and meta.access_cmd == SXD_ACCESS_CMD_SET:
        print("Deinit")
        rc = sxd_access_reg_spvid(original_spvid, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set SPVID register, rc: %d" % (rc)


def main():
    cmd, tport, local_port, egr_et_set, et_vlan, pvid, deinit = parse_args()

    validate_input_parameters(cmd, tport, local_port, egr_et_set, et_vlan, pvid)

    sxd_init()
    run_example(cmd, tport, local_port, egr_et_set, et_vlan, pvid, deinit)
    print("[+] SPVID register example end")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


if __name__ == "__main__":
    print("[+] SPVID register access example")
    main()
