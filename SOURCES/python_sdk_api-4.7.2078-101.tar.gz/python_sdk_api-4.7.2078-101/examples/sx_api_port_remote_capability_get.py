#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below shows API usage to determine speed and flow control supported by remote peer port.
'''

import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description='sx_api_port_remote_capability_get')
    parser.add_argument('--log_port', default=0x10001, type=auto_int, help='logical port whose remote peer speed capability needs to be retrieved.')
    args = parser.parse_args()
    return args.log_port


def init():
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)
    return handle


def deinit(handle):
    sx_api_close(handle)


def print_remote_capability(log_port, remote_speed, remote_fc_adv):
    print("=========================================================================")
    print("|%30s|%40s|" % ("logport", str(hex(log_port))))
    print("-------------------------------------------------------------------------")
    if remote_speed.is_remote_speed_capability_valid:
        advertised_str = "Yes"
    else:
        advertised_str = "No"
    print("|%30s|%40s|" % ("Remote speed advertised", advertised_str))
    print("-------------------------------------------------------------------------")
    speed_valid = remote_speed.is_remote_speed_capability_valid
    if remote_speed.speed_capab_type == SX_PORT_REMOTE_SPEED_CAPABILITY_EXTENDED_E:
        print("|%30s|%40s|" % ("Capab type", "Extended"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10MB_SGMII", (remote_speed.speed_capab_info.capab_ext.mode_10MB_SGMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100MB_SGMII", (remote_speed.speed_capab_info.capab_ext.mode_100MB_SGMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("1000MB_X_SGMII", (remote_speed.speed_capab_info.capab_ext.mode_1000MB_X_SGMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("2500MB_X_GMII", (remote_speed.speed_capab_info.capab_ext.mode_2500MB_X_GMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("5GB_R", (remote_speed.speed_capab_info.capab_ext.mode_5GB_R) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_XFI_XAUI1", (remote_speed.speed_capab_info.capab_ext.mode_10GB_XFI_XAUI1) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("40GB_XLAUI4_XLPPI4", (remote_speed.speed_capab_info.capab_ext.mode_40GB_XLAUI4_XLPPI4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("25GB_GAUI1_CR_KR", (remote_speed.speed_capab_info.capab_ext.mode_25GB_GAUI1_CR_KR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_GAUI2_LAUI2_CR2_KR2", (remote_speed.speed_capab_info.capab_ext.mode_50GB_GAUI2_LAUI2_CR2_KR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_GAUI1_CR_KR", (remote_speed.speed_capab_info.capab_ext.mode_50GB_GAUI1_CR_KR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_CAUI4_CR4_KR4", (remote_speed.speed_capab_info.capab_ext.mode_100GB_CAUI4_CR4_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_GAUI2_CR2_KR2", (remote_speed.speed_capab_info.capab_ext.mode_100GB_GAUI2_CR2_KR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_GAUI1_CR_KR", (remote_speed.speed_capab_info.capab_ext.mode_100GB_GAUI1_CR_KR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("200GB_GAUI4_CR4_KR4", (remote_speed.speed_capab_info.capab_ext.mode_200GB_GAUI4_CR4_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("200GB_GAUI2_CR2_KR2", (remote_speed.speed_capab_info.capab_ext.mode_200GB_GAUI2_CR2_KR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("400GB_GAUI8_CR8", (remote_speed.speed_capab_info.capab_ext.mode_400GB_GAUI8_CR8) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("400GB_GAUI4_CR4", (remote_speed.speed_capab_info.capab_ext.mode_400GB_GAUI4_CR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("800GB_GAUI8_CR8", (remote_speed.speed_capab_info.capab_ext.mode_800GB_GAUI8_CR8) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
    elif remote_speed.speed_capab_type == SX_PORT_REMOTE_SPEED_CAPABILITY_LEGACY_E:
        print("|%30s|%40s|" % ("Capab type", "Legacy"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("SGMII", (remote_speed.speed_capab_info.capab_legacy.mode_SGMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100MB_SGMII", (remote_speed.speed_capab_info.capab_legacy.mode_100MB_SGMII) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("1000MB_KX", (remote_speed.speed_capab_info.capab_legacy.mode_1000MB_KX) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_CX4", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_CX4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_KX4", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_KX4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_KR", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_KR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("40GB_CR4", (remote_speed.speed_capab_info.capab_legacy.mode_40GB_CR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("40GB_KR4", (remote_speed.speed_capab_info.capab_legacy.mode_40GB_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_CR", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_CR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_SR", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_SR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_ER_LR", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_ER_LR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("40GB_SR4", (remote_speed.speed_capab_info.capab_legacy.mode_40GB_SR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("40GB_LR4_ER4", (remote_speed.speed_capab_info.capab_legacy.mode_40GB_LR4_ER4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_SR2", (remote_speed.speed_capab_info.capab_legacy.mode_50GB_SR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_KR4", (remote_speed.speed_capab_info.capab_legacy.mode_50GB_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_CR4", (remote_speed.speed_capab_info.capab_legacy.mode_100GB_CR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_SR4", (remote_speed.speed_capab_info.capab_legacy.mode_100GB_SR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_KR4", (remote_speed.speed_capab_info.capab_legacy.mode_100GB_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_ER_LR", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_ER_LR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_KR4", (remote_speed.speed_capab_info.capab_legacy.mode_100GB_KR4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100GB_LR4_ER4", (remote_speed.speed_capab_info.capab_legacy.mode_100GB_LR4_ER4) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10MB_T", (remote_speed.speed_capab_info.capab_legacy.mode_10MB_T) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("100MB_T", (remote_speed.speed_capab_info.capab_legacy.mode_100MB_T) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("1000MB_T", (remote_speed.speed_capab_info.capab_legacy.mode_1000MB_T) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("10GB_T", (remote_speed.speed_capab_info.capab_legacy.mode_10GB_T) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("25GB_CR", (remote_speed.speed_capab_info.capab_legacy.mode_25GB_CR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("25GB_KR", (remote_speed.speed_capab_info.capab_legacy.mode_25GB_KR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("25GB_SR", (remote_speed.speed_capab_info.capab_legacy.mode_25GB_SR) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_CR2", (remote_speed.speed_capab_info.capab_legacy.mode_50GB_CR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")
        print("|%30s|%40s|" % ("50GB_KR2", (remote_speed.speed_capab_info.capab_legacy.mode_50GB_KR2) if (speed_valid) else "N/A"))
        print("-------------------------------------------------------------------------")

    fc_dict = get_enum_string_dict('SX_PORT_FLOW_CTRL_MODE_')
    print("|%30s|%40s|" % ("Remote FC advertisement", fc_dict[remote_fc_adv]))
    print("=========================================================================")


def run_example(handle, log_port):
    remote_port_capability_p = new_sx_port_remote_port_capability_t_p()
    rc = sx_api_port_remote_capability_get(handle, log_port, remote_port_capability_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_port_remote_capability_get failed, rc = %d" % (rc))
        sys.exit(rc)
    remote_capability = sx_port_remote_port_capability_t_p_value(remote_port_capability_p)
    print_remote_capability(log_port, remote_capability.remote_speed, remote_capability.remote_fc_advertisement)


def main():
    log_port = parse_args()
    handle = init()
    run_example(handle, log_port)
    deinit(handle)


if __name__ == "__main__":
    main()
