#!/usr/bin/env python
'''
This file contains Python command example for the Host Ifc Counters-Get module.
'''

import sys
import errno
import os
import pprint
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_counters_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

#######################################################################################################################
# TEST CONFIG
#######################################################################################################################

to_do_config_port = 0
to_do_config_trap_groups = 0
to_do_config_trap_groups_policers = 0
to_do_config_traps = 0
clear_after_read = 0

#######################################################################################################################
# Variables
#######################################################################################################################

SPECTRUM_SWID = 0
trap_group = 10
cmd = SX_ACCESS_CMD_READ_CLEAR

port_capabilities = new_sx_port_speed_capability_t_p()
trap_group_attr_p = new_sx_trap_group_attributes_t_p()
policer_attr_p = new_sx_policer_attributes_t_p()
policer_id_p = new_sx_policer_id_t_p()
policer_id = sx_policer_id_t_p_value(policer_id_p)
sx_fd_p = new_sx_fd_t_p()
pkt_size = 2000
pkt = new_uint8_t_arr(pkt_size)
filter_p = new_sx_host_ifc_counters_filter_t_p()
host_ifc_cnt_p = new_sx_host_ifc_counters_t_p()

#######################################################################################################################
# HELPER FUNCTIONS
#######################################################################################################################


def print_stats(host_ifc_cnt_p):
    print("Global")
    print("\tEvents:               %10lu" % (host_ifc_cnt_p.global_counters.event_counter))
    print("\tFromCpuControlPacket: %10lu" % (host_ifc_cnt_p.global_counters.fromcpu_control_packet))
    print("\tFromCpuControlByte:   %10lu" % (host_ifc_cnt_p.global_counters.fromcpu_control_byte))
    print("\tFromCpuDataPacket:    %10lu" % (host_ifc_cnt_p.global_counters.fromcpu_data_packet))
    print("\tFromCpuDataByte:      %10lu" % (host_ifc_cnt_p.global_counters.fromcpu_data_byte))
    print("\tToCpuBufferDrop:      %10lu" % (host_ifc_cnt_p.global_counters.tocpu_buffer_drop))
    print("\tToCpuPacket:          %10lu" % (host_ifc_cnt_p.global_counters.tocpu_packet))
    print("\tToCpuByte:            %10lu" % (host_ifc_cnt_p.global_counters.tocpu_byte))

    print("Group Counters")
    for trap_group in range(0, host_ifc_cnt_p.trap_group_counters_cnt):
        gc = sx_host_ifc_trap_group_counters_t_arr_getitem(host_ifc_cnt_p.trap_group_counters, trap_group)
        print("\tGroup %02d:             ToCpuPacket:%10lu   ToCpuByte:%10lu   Events:%10lu   Drops:%10lu" % (gc.trap_group, gc.tocpu_packet, gc.tocpu_byte, gc.event_counter, gc.tocpu_drop_exceed_rate_packet.violation_counter))

    print("Trap Counters")
    for trap_id in range(0, host_ifc_cnt_p.trap_id_counters_cnt):
        tc = sx_host_ifc_trap_id_counters_t_arr_getitem(host_ifc_cnt_p.trap_id_counters, trap_id)
        if (tc.trap_type == HOST_IFC_TRAP_TYPE_PACKET):
            print("\tTrap %3d (Group %02d):  ToCpuPacket:%10lu   ToCpuByte:%10lu" % (tc.trap_id, tc.trap_group, tc.u_trap_type.packet.tocpu_packet, tc.u_trap_type.packet.tocpu_byte))
        else:
            print("\tTrap %3d (Group %02d):  Events:     %10lu Drops: %10lu" % (tc.trap_id, tc.trap_group, tc.u_trap_type.event.event_counter, tc.u_trap_type.event.drop_counter))


def host_ifc_trap_id_set(handle, cmd, trap_id, trap_group, trap_action):
    ''' SET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group
    trap_attr_p.attr.trap_id_attr.trap_action = trap_action

    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    return rc

#######################################################################################################################
# Initialize environment
#######################################################################################################################


print("Initializing environment")
rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed. Please check that SDK is running.")
    sys.exit(rc)


# save current module_verbosity_level and api_verbosity_level for later de-configuration
original_module_verbosity_level_p = new_sx_verbosity_level_t_p()
original_api_verbosity_level_p = new_sx_verbosity_level_t_p()
rc = sx_api_host_ifc_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_TARGET_API, original_module_verbosity_level_p, original_api_verbosity_level_p)
if (rc != 0):
    print("fail to get host ifc API log verbosity level")
    exit(rc)
original_module_verbosity_level = sx_verbosity_level_t_p_value(original_module_verbosity_level_p)
original_api_verbosity_level = sx_verbosity_level_t_p_value(original_api_verbosity_level_p)

print("Setting log verbosity")
rc = sx_api_host_ifc_log_verbosity_level_set(handle,
                                             SX_LOG_VERBOSITY_TARGET_API,
                                             SX_VERBOSITY_LEVEL_NONE,
                                             SX_VERBOSITY_LEVEL_NONE)
if (rc != 0):
    print("Failed")
    exit(rc)


print("Open host-interface channel")
rc = sx_api_host_ifc_open(handle, sx_fd_p)
if rc != SX_STATUS_SUCCESS:
    print(("Failed [rc=%d]" % (rc)))
    sys.exit(rc)

port_list = get_ports(handle, 1)
port = port_list[0]

#######################################################################################################################
# Configure port
#######################################################################################################################

if to_do_config_port != 0:
    # save current port speed for later de-configuration
    original_port_speed_capability_p = new_sx_port_speed_capability_t_p()
    original_port_oper_speed_p = new_sx_port_oper_speed_t_p()
    rc = sx_api_port_speed_get(handle, port, original_port_speed_capability_p, original_port_oper_speed_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_speed_get failed [rc=%d]" % (rc)))
        sys.exit(rc)

    # admin-state
    print("Configuring port admin-state to DOWN")
    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    # bandwidth to 100G
    print("Configuring port bandwidth")
    port_capabilities.mode_1GB_CX_SGMII = 0
    port_capabilities.mode_1GB_KX = 0
    port_capabilities.mode_10GB_CX4_XAUI = 0
    port_capabilities.mode_10GB_KX4 = 0
    port_capabilities.mode_10GB_KR = 0
    port_capabilities.mode_20GB_KR2 = 0
    port_capabilities.mode_40GB_CR4 = 0
    port_capabilities.mode_40GB_KR4 = 0
    port_capabilities.mode_56GB_KR4 = 0
    port_capabilities.mode_56GB_KX4 = 0
    port_capabilities.mode_10GB_CR = 0
    port_capabilities.mode_10GB_SR = 0
    port_capabilities.mode_10GB_ER_LR = 0
    port_capabilities.mode_40GB_SR4 = 0
    port_capabilities.mode_40GB_LR4_ER4 = 0
    port_capabilities.mode_100GB_CR4 = 1
    port_capabilities.mode_100GB_SR4 = 1
    port_capabilities.mode_100GB_KR4 = 0
    port_capabilities.mode_100GB_LR4_ER4 = 1
    port_capabilities.mode_25GB_CR = 0
    port_capabilities.mode_25GB_KR = 0
    port_capabilities.mode_25GB_SR = 0
    port_capabilities.mode_50GB_CR2 = 0
    port_capabilities.mode_50GB_KR2 = 0
    port_capabilities.mode_auto = 0
    port_capabilities.force = 0
    rc = sx_api_port_speed_admin_set(handle, port, port_capabilities)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_speed_admin_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    # admin-state
    print("Configuring port admin-state to UP")
    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_state_set failed [rc=%d]" % (rc)))
        sys.exit(rc)
else:
    print("SKIP configuring port")

#######################################################################################################################
# Configure trap-groups
#######################################################################################################################

trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
trap_groups_used = []

if to_do_config_trap_groups != 0:
    for trap_group in range(0, 4):
        print(("Configuring trap-group #%d" % (trap_group)))
        trap_group_attr_p.prio = 1
        trap_group_attr_p.truncate_mode = SX_TRUNCATE_MODE_DISABLE
        trap_group_attr_p.truncate_size = 0
        trap_group_attr_p.control_type = SX_CONTROL_TYPE_DEFAULT
        trap_group_attr_p.is_monitor = False
        rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_host_ifc_trap_group_ext_set failed [rc=%d]" % (rc)))
            sys.exit(rc)
        trap_groups_used.append(sx_trap_group_attributes_t_p_value(trap_group_attr_p).trap_group)
else:
    print("SKIP configuring trap-groups")

#######################################################################################################################
# Configure policers for trap-groups
#######################################################################################################################

if to_do_config_trap_groups_policers != 0:
    policer_attr_p.meter_type = SX_POLICER_METER_PACKETS
    policer_attr_p.cbs = 10
    policer_attr_p.ebs = 10
    policer_attr_p.cir = 1000
    policer_attr_p.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR
    policer_attr_p.red_action = SX_POLICER_ACTION_DISCARD
    policer_attr_p.eir = 1000
    policer_attr_p.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E
    policer_attr_p.color_aware = 0
    policer_attr_p.is_host_ifc_policer = 1
    policer_attr_p.ir_units = SX_POLICER_IR_UNITS_10_POWER_3_E

    print("Creating policer for trap-group 0")
    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_CREATE, policer_attr_p, policer_id_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring policer for trap-group 0")
    policer_id0 = sx_policer_id_t_p_value(policer_id_p)
    rc = sx_api_host_ifc_policer_bind_set(handle, SX_ACCESS_CMD_BIND, SPECTRUM_SWID, 0, policer_id0)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_policer_bind_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Creating policer for trap-group 1")
    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_CREATE, policer_attr_p, policer_id_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring policer for trap-group 1")
    policer_id1 = sx_policer_id_t_p_value(policer_id_p)
    rc = sx_api_host_ifc_policer_bind_set(handle, SX_ACCESS_CMD_BIND, SPECTRUM_SWID, 1, policer_id1)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_policer_bind_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Creating policer for trap-group 2")
    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_CREATE, policer_attr_p, policer_id_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring policer for trap-group 2")
    policer_id2 = sx_policer_id_t_p_value(policer_id_p)
    rc = sx_api_host_ifc_policer_bind_set(handle, SX_ACCESS_CMD_BIND, SPECTRUM_SWID, 2, policer_id2)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_policer_bind_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Creating policer for trap-group 3")
    rc = sx_api_policer_set(handle, SX_ACCESS_CMD_CREATE, policer_attr_p, policer_id_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_policer_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring policer for trap-group 3")
    policer_id3 = sx_policer_id_t_p_value(policer_id_p)
    rc = sx_api_host_ifc_policer_bind_set(handle, SX_ACCESS_CMD_BIND, SPECTRUM_SWID, 3, policer_id3)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_policer_bind_set failed [rc=%d]" % (rc)))
        sys.exit(rc)
else:
    print("SKIP creating & configuring policers")

#######################################################################################################################
# Configure traps
######################################################################################################################

if to_do_config_traps != 0:
    print("Configuring trap SX_TRAP_ID_ETH_L2_LACP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_LACP, 0, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_LLDP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_LLDP, 0, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_MMRP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_MMRP, 0, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_MVRP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_MVRP, 1, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_RPVST")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_RPVST, 1, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_FCOE_FIP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_FCOE_FIP, 1, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY, 1, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT, 2, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT, 2, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE, 3, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT, 3, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

    print("Configuring trap SX_TRAP_ID_ETH_L2_STP")
    rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_SET, SX_TRAP_ID_ETH_L2_STP, 3, SX_TRAP_ACTION_TRAP_2_CPU)
    if rc != SX_STATUS_SUCCESS:
        print(("host_ifc_trap_id_set failed [rc=%d]" % (rc)))
        sys.exit(rc)

else:
    print("SKIP configuring traps")

#######################################################################################################################
# Send unicast control
#######################################################################################################################

print("Sending unicast control")
rc = sx_lib_host_ifc_unicast_ctrl_send(sx_fd_p, pkt, pkt_size, 0, port, 0)
if rc != SX_STATUS_SUCCESS:
    printf("sx_lib_host_ifc_unicast_ctrl_send failed [rc=%d]" % (rc))
    sys.exit(rc)

#######################################################################################################################
# Send data
#######################################################################################################################

print("Sending data")
rc = sx_lib_host_ifc_data_send(sx_fd_p, pkt, pkt_size, 0, 0)
if rc != SX_STATUS_SUCCESS:
    printf("sx_lib_host_ifc_data_send failed [rc=%d]" % (rc))
    sys.exit(rc)

#######################################################################################################################
# Show statistics
#######################################################################################################################

if clear_after_read != 0:
    print("Getting statistics (Read/Clear)")
    cmd = SX_ACCESS_CMD_READ_CLEAR
else:
    print("Getting statistics (Read)")
    cmd = SX_ACCESS_CMD_READ

host_ifc_cnt_p.trap_group_counters_cnt = SX_TRAP_GROUP_MAX
host_ifc_cnt_p.trap_id_counters_cnt = SX_TRAP_ID_MAX
rc = sx_api_host_ifc_counters_get(handle, cmd, None, host_ifc_cnt_p)
if rc != SX_STATUS_SUCCESS:
    print(("sx_api_host_ifc_counters_get failed [rc=%d]" % (rc)))
    sys.exit(rc)

print_stats(host_ifc_cnt_p)

#######################################################################################################################

if args.deinit:
    if to_do_config_traps != 0:
        print("Unset traps")

        traps_set = {SX_TRAP_ID_ETH_L2_LACP: 0,
                     SX_TRAP_ID_ETH_L2_LLDP: 0,
                     SX_TRAP_ID_ETH_L2_MMRP: 0,
                     SX_TRAP_ID_ETH_L2_MVRP: 1,
                     SX_TRAP_ID_ETH_L2_RPVST: 1,
                     SX_TRAP_ID_FCOE_FIP: 1,
                     SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY: 1,
                     SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT: 2,
                     SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT: 2,
                     SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE: 3,
                     SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT: 3,
                     SX_TRAP_ID_ETH_L2_STP: 3}

        for trap_id, group in traps_set.items():
            rc = host_ifc_trap_id_set(handle, SX_ACCESS_CMD_UNSET, trap_id, group, SX_TRAP_ACTION_TRAP_2_CPU)
            if rc != SX_STATUS_SUCCESS:
                print(("Failed to unset trap [trap_id =%d, trap_group=%d; rc=%d]" % (trap_id, group, rc)))
                sys.exit(rc)

    if to_do_config_trap_groups_policers != 0:
        print("Destroy policers")

        policers_set = {policer_id0: 0,
                        policer_id1: 1,
                        policer_id2: 2,
                        policer_id3: 3}

        for policer_id, group in policers_set.items():
            sx_policer_id_t_p_assign(policer_id_p, policer_id)

            rc = sx_api_host_ifc_policer_bind_set(handle, SX_ACCESS_CMD_UNBIND, SPECTRUM_SWID, group, policer_id)
            if rc != SX_STATUS_SUCCESS:
                print(("Failed to unbind policer [policer_id=%d, group=%d; rc=%d]" % (policer_id, trap, rc)))
                sys.exit(rc)

            rc = sx_api_policer_set(handle, SX_ACCESS_CMD_DESTROY, policer_attr_p, policer_id_p)
            if rc != SX_STATUS_SUCCESS:
                print(("Failed to destroy policer [policer_id=%d; rc=%d]" % (policer_id, rc)))
                sys.exit(rc)

    if to_do_config_trap_groups != 0:
        for trap_group in trap_groups_used:
            print(("Unset trap-group #%d" % (trap_group)))
            rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SPECTRUM_SWID, trap_group,
                                                    trap_group_attr_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_host_ifc_trap_group_ext_set failed [trap_group=%d, rc=%d]" % (trap_group, rc)))
                sys.exit(rc)

    if to_do_config_port != 0:
        print("Set back to the port original speed")
        rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed [rc=%d]" % (rc)))
            sys.exit(rc)

        rc = sx_api_port_speed_admin_set(handle, port, original_port_speed_capability_p)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_speed_admin_set failed [rc=%d]" % (rc)))
            sys.exit(rc)

        rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
        if rc != SX_STATUS_SUCCESS:
            print(("sx_api_port_state_set failed [rc=%d]" % (rc)))
            sys.exit(rc)

    print("Set back to the port original verbosity level")
    rc = sx_api_host_ifc_log_verbosity_level_set(handle,
                                                 SX_LOG_VERBOSITY_TARGET_API,
                                                 original_module_verbosity_level,
                                                 original_api_verbosity_level)
    if (rc != SX_STATUS_SUCCESS):
        print("sx_api_host_ifc_log_verbosity_level_set failed")
        sys.exit(rc)

sx_api_close(handle)
