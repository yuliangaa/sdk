#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the module power mode.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
import test_infra_common as common_lib
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *

######################################################
#  power mode and reset utility functions.
######################################################


def mgmt_phy_mod_pwr_attr_get(handle, slot_id, module_id, power_attr_type):
    sx_mgmt_phy_mod_pwr_attr_p = new_sx_mgmt_phy_mod_pwr_attr_t_p()
    sx_mgmt_phy_mod_pwr_attr = sx_mgmt_phy_mod_pwr_attr_t()
    sx_mgmt_phy_mod_pwr_attr.power_attr_type = power_attr_type
    sx_mgmt_phy_mod_pwr_attr_t_p_assign(sx_mgmt_phy_mod_pwr_attr_p, sx_mgmt_phy_mod_pwr_attr)
    module_id_info = sx_mgmt_module_id_info_t()
    module_id_info.slot_id = slot_id
    module_id_info.module_id = module_id
    try:
        rc = sx_mgmt_phy_module_pwr_attr_get(handle, module_id_info, sx_mgmt_phy_mod_pwr_attr_p)
        assert SX_STATUS_SUCCESS == rc, "sx_mgmt_phy_module_pwr_attr_get failed"
        sx_mgmt_phy_mod_pwr_attr = sx_mgmt_phy_mod_pwr_attr_t_p_value(sx_mgmt_phy_mod_pwr_attr_p)
        pwr_mode_attr = sx_mgmt_phy_mod_pwr_attr.pwr_mode_attr
        return pwr_mode_attr.admin_pwr_mode_e, pwr_mode_attr.oper_pwr_mode_e
    finally:
        delete_sx_mgmt_phy_mod_pwr_attr_t_p(sx_mgmt_phy_mod_pwr_attr_p)


##############################################################################
#  utility functions to set port state, get module port mapping, retrieve enum
##############################################################################

def get_cable_type(port_list):
    cable_data_dict = {}
    cable_types_dict = {0: "UNIDENTIFIED_CABLE",
                        1: "ACTIVE_CABLE",
                        2: "OPTICAL_CABLE",
                        3: "PASSIVE_COPPER_CABLE",
                        4: "CABLE_UNPLUGGED"}

    localport = (port_list[0] & SX_PORT_PHY_ID_MASK) >> SX_PORT_PHY_ID_OFFS

    pddr = ku_pddr_reg()
    pddr.local_port, pddr.lp_msb = common_lib.get_lsb_msb_of_local_port(localport)

    pddr.page_select = SXD_PDDR_PAGE_SELECT_MODULE_INFO_PAGE_E

    meta = sxd_reg_meta_t()
    meta.dev_id = 1
    meta.swid = 0
    meta.access_cmd = SXD_ACCESS_CMD_GET
    sxd_access_reg_pddr(pddr, meta, 1, None, None)

    return cable_types_dict[pddr.page_data.pddr_module_info.cable_type]


###########################################################################################################

def generate_module_dump(handle, port_module_map, module_port_map):
    sxd_access_reg_init(0, None, SX_VERBOSITY_LEVEL_NONE)
    print("======================================================================================================================")
    header = ["Slot", "Module ID", "Panel", "Admin Power Mode", "Oper Power Mode", "Cable Type"]
    print("|%4s|%10s|%5s|%35s|%35s|%22s|" % (header[0], header[1], header[2], header[3], header[4], header[5]))
    print("======================================================================================================================")

    pwr_mode_enum_dict = common_lib.get_enum_string_dict('SX_MGMT_PHY_MOD_PWR_MODE')
    for (slot_id, mod_id) in sorted(module_port_map.keys()):
        admin_pwr_mode, oper_pwr_mode = mgmt_phy_mod_pwr_attr_get(handle, slot_id, mod_id, SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E)
        print("|%4s|%10s|%5s|%35s|%35s|%22s|" % (slot_id, mod_id, (mod_id + 1), pwr_mode_enum_dict[admin_pwr_mode],
                                                 pwr_mode_enum_dict[oper_pwr_mode], get_cable_type(module_port_map[(slot_id, mod_id)])))
    sxd_access_reg_deinit()


def run_example(handle, slot_id, module_id):
    # construct the port module map.
    ports_attributes_list = common_lib.ports_attributes_get(handle)
    port_module_map, module_port_map = common_lib.get_port_module_mapping(ports_attributes_list, len(ports_attributes_list))

    if module_id == "all" or slot_id == "all":
        generate_module_dump(handle, port_module_map, module_port_map)
    else:
        mod_id = int(module_id)
        slot_id = int(slot_id)
        if (slot_id, mod_id) not in module_port_map.keys():
            print("Error: Invalid slot/module Id")
            sys.exit(0)
        admin_pwr_mode, oper_pwr_mode = mgmt_phy_mod_pwr_attr_get(handle, slot_id, mod_id, SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E)
        pwr_mode_enum_dict = common_lib.get_enum_string_dict('SX_MGMT_PHY_MOD_PWR_MODE')
        print("Current power mode for module: [%d]" % (mod_id))
        print("Admin power mode: [%s]" % (pwr_mode_enum_dict[admin_pwr_mode]))
        print("Operational power mode: [%s]" % (pwr_mode_enum_dict[oper_pwr_mode]))


def parse_example_attributes():

    parser = argparse.ArgumentParser(description='Module power mode dump utility')
    parser.add_argument('--module_id', default='all', type=str, help="Module id")
    parser.add_argument('--slot_id', default='all', type=str, help="Slot id")
    args = parser.parse_args()

    if len(sys.argv) < 1:
        print("Usage:")
        print("Example: Dump module power mode sx_mgmt_module_power_mode_dump.py --module_id all --slot_id all")
        print("Example: Dump module power mode sx_mgmt_module_power_mode_dump.py --module_id 1 --slot_id 1")
        sys.exit(0)

    module_id = args.module_id
    slot_id = args.slot_id

    return slot_id, module_id


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":
    slot_id, module_id = parse_example_attributes()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    # Run the  example with retrieved above parameters
    run_example(handle, slot_id, module_id)

    sx_api_close(handle)
