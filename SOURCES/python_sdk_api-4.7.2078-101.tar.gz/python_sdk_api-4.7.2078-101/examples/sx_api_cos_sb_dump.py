#!/usr/bin/env python
'''
This file contains Python command example for the PORT module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *

port_buffer_type_dict = {SX_COS_INGRESS_PORT_ATTR_E: "INGRESS_PORT",
                         SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E: "INGRESS_PORT_PRIORITY_GROUP",
                         SX_COS_EGRESS_PORT_ATTR_E: "EGRESS_PORT",
                         SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E: "EGRESS_PORT_TRAFFIC_CLASS",
                         SX_COS_MULTICAST_ATTR_E: "MULTICAST",
                         SX_COS_MULTICAST_PORT_ATTR_E: "MULTICAST_PORT",
                         SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E: "PRIORITY_GROUP_PIPELINE_LATENCY",
                         SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E: "PRIORITY_GROUP_HEADROOM",
                         SX_COS_PORT_BUFF_ATTR_RESERVED1_E: "RESERVED_1",
                         SX_COS_PORT_BUFF_ATTR_RESERVED2_E: "RESERVED_2",
                         SX_COS_PORT_BUFF_ATTR_RESERVED3_E: "RESERVED_3",
                         SX_COS_PORT_BUFF_ATTR_RESERVED4_E: "RESERVED_4",
                         SX_COS_PORT_SHARED_HEADROOM_E: "PORT SHARED HEADROOM"}

shared_pool_direction_dict = {SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E: "INGRESS",
                              SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E: "EGRESS"}

shared_pool_mode_dict = {SX_COS_BUFFER_MAX_MODE_STATIC_E: "PERCENTAGE",
                         SX_COS_BUFFER_MAX_MODE_DYNAMIC_E: "DYNAMIC",
                         SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E: "CELLS"}

port_shared_buffer_alpha_dict = {SX_COS_PORT_BUFF_ALPHA_0_E: "SX_COS_PORT_BUFF_ALPHA_0",
                                 SX_COS_PORT_BUFF_ALPHA_1_128_E: "SX_COS_PORT_BUFF_ALPHA_1_128",
                                 SX_COS_PORT_BUFF_ALPHA_1_64_E: "SX_COS_PORT_BUFF_ALPHA_1_64",
                                 SX_COS_PORT_BUFF_ALPHA_1_32_E: "SX_COS_PORT_BUFF_ALPHA_1_32",
                                 SX_COS_PORT_BUFF_ALPHA_1_16_E: "SX_COS_PORT_BUFF_ALPHA_1_16",
                                 SX_COS_PORT_BUFF_ALPHA_1_8_E: "SX_COS_PORT_BUFF_ALPHA_1_8",
                                 SX_COS_PORT_BUFF_ALPHA_1_4_E: "SX_COS_PORT_BUFF_ALPHA_1_4",
                                 SX_COS_PORT_BUFF_ALPHA_1_2_E: "SX_COS_PORT_BUFF_ALPHA_1_2",
                                 SX_COS_PORT_BUFF_ALPHA_1_E: "SX_COS_PORT_BUFF_ALPHA_1",
                                 SX_COS_PORT_BUFF_ALPHA_2_E: "SX_COS_PORT_BUFF_ALPHA_2",
                                 SX_COS_PORT_BUFF_ALPHA_4_E: "SX_COS_PORT_BUFF_ALPHA_4",
                                 SX_COS_PORT_BUFF_ALPHA_8_E: "SX_COS_PORT_BUFF_ALPHA_8",
                                 SX_COS_PORT_BUFF_ALPHA_16_E: "SX_COS_PORT_BUFF_ALPHA_16",
                                 SX_COS_PORT_BUFF_ALPHA_32_E: "SX_COS_PORT_BUFF_ALPHA_32",
                                 SX_COS_PORT_BUFF_ALPHA_64_E: "SX_COS_PORT_BUFF_ALPHA_64",
                                 SX_COS_PORT_BUFF_ALPHA_INFINITY_E: "SX_COS_PORT_BUFF_ALPHA_INFINITY"}

type_buffer_cnt = 63


def print_all_port_props(log_port):
    port_buffer_attr_cnt = new_uint32_t_p()
    uint32_t_p_assign(port_buffer_attr_cnt, 0)
    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    type_buffer_cnt = uint32_t_p_value(port_buffer_attr_cnt)
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(type_buffer_cnt)
    print("---------------  PORT TYPE BUFF GET (MIN - Reserved Buffers) (Size units = Cell (96 Bytes)) ----")
    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_buffer_attr_list_p, port_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
    print("------------------------------------------------------------------------------------------------")

    for i in range(0, attr_cnt):
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
        print(("[%d] type = %s" % (i, port_buffer_type_dict[attr_item_min.type])))

        if attr_item_min.type == SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.size)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.size)))
            print(("[%d] PG    = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pg)))
            print(("[%d] is_lossy (0=Lossless)  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy)))
            print(("[%d] Xon  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xon)))
            print(("[%d] Xoff  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xoff)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_EGRESS_PORT_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.size)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.size)))
            print(("[%d] TC  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.tc)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_MULTICAST_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.multicast_buff_attr.size)))
            print(("[%d] SP  = %d" % (i, attr_item_min.attr.multicast_buff_attr.sp)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.multicast_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_MULTICAST_PORT_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.multicast_port_buff_attr.size)))

        if attr_item_min.type == SX_COS_PORT_BUFF_ATTR_RESERVED1_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.size)))

        if attr_item_min.type == SX_COS_PORT_BUFF_ATTR_RESERVED2_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.size)))
            print(("[%d] PG    = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pg)))

        if attr_item_min.type == SX_COS_PORT_BUFF_ATTR_RESERVED3_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.size)))

        if attr_item_min.type == SX_COS_PORT_BUFF_ATTR_RESERVED4_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.size)))
            print(("[%d] TC  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.tc)))

        if attr_item_min.type == SX_COS_PORT_SHARED_HEADROOM_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.size)))
            print(("[%d] Xon  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.xon)))
            print(("[%d] Xoff  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.xoff)))
            print(("[%d] SHP ID  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.xoff)))
            print(("[%d] max_pool_loan  = %d" % (i, attr_item_min.attr.port_shared_headroom_attr.max_pool_loan)))

        if attr_item_min.type > SX_COS_PORT_SHARED_HEADROOM_E or attr_item_min.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item_min.type)))

    """ PORT SHARED BUFF GET """
    print("---------------  PORT SHARED BUFF GET (MAX - Shared Buffers) (Size units = Cell (96 Bytes)) ----")
    port_shared_buffer_attr_cnt = new_uint32_t_p()
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(type_buffer_cnt)
    uint32_t_p_assign(port_shared_buffer_attr_cnt, type_buffer_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_shared_buffer_attr_list_p, port_shared_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
    print("------------------------------------------------------------------------------------------------")
    for i in range(0, attr_cnt):
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
        print(("[%d] type = %s" % (i, port_buffer_type_dict[attr_item.type])))
        if attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
            if attr_item.attr.ingress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha])))

            print(("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.pool_id)))

        if attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            if attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha])))

            print(("[%d] PG  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id)))

        if attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
            if attr_item.attr.egress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.egress_port_shared_buff_attr.max.max.alpha])))

            print(("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.pool_id)))
        if attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            if attr_item.attr.egress_port_tc_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha])))

            print(("[%d] TC  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.pool_id)))
        if attr_item.type == SX_COS_MULTICAST_ATTR_E:
            if attr_item.attr.multicast_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.multicast_shared_buff_attr.max.max.alpha])))

            print(("[%d] SP  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.sp)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.pool_id)))
        if attr_item.type == SX_COS_MULTICAST_PORT_ATTR_E:
            print(("[%d] Max  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size)))

        if attr_item.type == SX_COS_PORT_BUFF_ATTR_RESERVED1_E:
            if attr_item.attr.ingress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.
                                                                                   ingress_port_shared_buff_attr.max.max.alpha])))

        if attr_item.type == SX_COS_PORT_BUFF_ATTR_RESERVED2_E:
            if attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.
                                                                                   ingress_port_pg_shared_buff_attr.max.max.alpha])))

            print(("[%d] PG  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg)))

        if attr_item.type == SX_COS_PORT_BUFF_ATTR_RESERVED3_E:
            if attr_item.attr.egress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.
                                                                                   egress_port_shared_buff_attr.max.max.alpha])))

        if attr_item.type == SX_COS_PORT_BUFF_ATTR_RESERVED4_E:
            if attr_item.attr.egress_port_tc_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.
                                                                                   egress_port_tc_shared_buff_attr.max.max.alpha])))

            print(("[%d] TC  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc)))

        if attr_item.type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or attr_item.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item.type)))


def print_all_shared_pool_props():
    shared_pool_id = new_uint32_t_p()
    shared_pool_attr_p = new_sx_cos_pool_attr_t_arr(1)
    default_pools = []

    shared_pool_cnt = new_uint32_t_p()
    uint32_t_p_assign(shared_pool_cnt, 0)

    rc = sx_api_cos_pools_list_get(handle, shared_pool_cnt, None)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    pool_cnt = uint32_t_p_value(shared_pool_cnt)

    shared_pool_list = new_sx_cos_pool_id_t_arr(pool_cnt)
    rc = sx_api_cos_pools_list_get(handle, shared_pool_cnt, shared_pool_list)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    for i in range(pool_cnt):
        default_pools.append(uint32_t_arr_getitem(shared_pool_list, i))

    print(default_pools)
    print("---------------  SHARED POOL GET (Size units = Cell (96 Bytes)) --------------------------------")
    for shared_pool_id in default_pools:
        rc = sx_api_cos_shared_buff_pool_get(handle, shared_pool_id, shared_pool_attr_p)
        if rc != SX_STATUS_SUCCESS:
            sys.exit(rc)

        print(("sx_api_cos_shared_buff_pool_get [pool_id=%d , rc=%d] " % (shared_pool_id, rc)))
        print("================================================================================================")

        pool_attr_item = sx_cos_pool_attr_t_arr_getitem(shared_pool_attr_p, 0)
        print(("[Pool ID: %d] Pool direction = %s" % (shared_pool_id, shared_pool_direction_dict[pool_attr_item.pool_dir])))
        print(("[Pool ID: %d] Pool size  = %d" % (shared_pool_id, pool_attr_item.pool_size)))
        print(("[Pool ID: %d] Pool mode  = %s" % (shared_pool_id, shared_pool_mode_dict[pool_attr_item.mode])))
    print("\n")


def print_eport_pool_props(log_port):
    num_entries = 4
    port_buffer_attr_cnt = new_uint32_t_p()
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(num_entries)
    uint32_t_p_assign(port_buffer_attr_cnt, num_entries)
    port_buffer_attr_item = new_sx_cos_port_buffer_attr_t_arr(1)
    port_buffer_attr_item.type = SX_COS_EGRESS_PORT_ATTR_E
    port_buffer_attr_item.attr.egress_port_buff_attr.pool_id = 4
    sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, port_buffer_attr_item)
    port_buffer_attr_item.attr.egress_port_buff_attr.pool_id = 5
    sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 1, port_buffer_attr_item)
    port_buffer_attr_item.attr.egress_port_buff_attr.pool_id = 6
    sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 2, port_buffer_attr_item)
    port_buffer_attr_item.attr.egress_port_buff_attr.pool_id = 7
    sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 3, port_buffer_attr_item)

    print("---------------  PORT TYPE BUFF GET (MIN - Reserved Buffers) (Size units = Cell (96 Bytes)) ----")
    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_buffer_attr_list_p, port_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
    print(("sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
    print("------------------------------------------------------------------------------------------------")
    for i in range(0, attr_cnt):
        attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, i)
        print(("[%d] type = %s" % (i, port_buffer_type_dict[attr_item_min.type])))

        if attr_item_min.type == SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.size)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.size)))
            print(("[%d] PG    = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pg)))
            print(("[%d] is_lossy (0=Lossless)  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy)))
            print(("[%d] Xon  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xon)))
            print(("[%d] Xoff  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.xoff)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.ingress_port_pg_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_EGRESS_PORT_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.size)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.size)))
            print(("[%d] TC  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.tc)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.egress_port_tc_buff_attr.pool_id)))

        if attr_item_min.type == SX_COS_MULTICAST_ATTR_E:
            print(("[%d] Size  = %d" % (i, attr_item_min.attr.multicast_buff_attr.size)))
            print(("[%d] SP  = %d" % (i, attr_item_min.attr.multicast_buff_attr.sp)))
            print(("[%d] pool_id  = %d" % (i, attr_item_min.attr.multicast_buff_attr.pool_id)))

        if attr_item_min.type > SX_COS_MULTICAST_ATTR_E or attr_item_min.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item_min.type)))

    """ PORT SHARED BUFF GET """
    print("---------------  PORT SHARED BUFF GET (MAX - Shared Buffers) (Size units = Cell (96 Bytes)) ----")
    port_shared_buffer_attr_cnt = new_uint32_t_p()
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(num_entries)
    uint32_t_p_assign(port_shared_buffer_attr_cnt, num_entries)

    port_shared_buffer_attr_item = new_sx_cos_port_shared_buffer_attr_t_arr(1)
    port_shared_buffer_attr_item.type = SX_COS_EGRESS_PORT_ATTR_E
    port_shared_buffer_attr_item.attr.egress_port_shared_buff_attr.pool_id = 4
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, port_shared_buffer_attr_item)
    port_shared_buffer_attr_item.attr.egress_port_shared_buff_attr.pool_id = 5
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 1, port_shared_buffer_attr_item)
    port_shared_buffer_attr_item.attr.egress_port_shared_buff_attr.pool_id = 6
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 2, port_shared_buffer_attr_item)
    port_shared_buffer_attr_item.attr.egress_port_shared_buff_attr.pool_id = 7
    sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 3, port_shared_buffer_attr_item)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_shared_buffer_attr_list_p, port_shared_buffer_attr_cnt)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)

    attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
    print(("sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
    print("------------------------------------------------------------------------------------------------")
    for i in range(0, attr_cnt):
        attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, i)
        print(("[%d] type = %s" % (i, port_buffer_type_dict[attr_item.type])))
        if attr_item.type == SX_COS_INGRESS_PORT_ATTR_E:
            if attr_item.attr.ingress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.ingress_port_shared_buff_attr.max.max.alpha])))

            print(("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_shared_buff_attr.pool_id)))

        if attr_item.type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
            if attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha])))

            print(("[%d] PG  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pg)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.ingress_port_pg_shared_buff_attr.pool_id)))

        if attr_item.type == SX_COS_EGRESS_PORT_ATTR_E:
            if attr_item.attr.egress_port_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.egress_port_shared_buff_attr.max.max.alpha])))

            print(("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_shared_buff_attr.pool_id)))
        if attr_item.type == SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E:
            if attr_item.attr.egress_port_tc_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha])))

            print(("[%d] TC  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.tc)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.egress_port_tc_shared_buff_attr.pool_id)))
        if attr_item.type == SX_COS_MULTICAST_ATTR_E:
            if attr_item.attr.multicast_shared_buff_attr.max.mode != SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                """ Static """
                print(("[%d] Max  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.max.max.size)))
            else:
                """ Dynamic """
                print(("[%d] Max (Alpha) = %s" % (i, port_shared_buffer_alpha_dict[attr_item.attr.multicast_shared_buff_attr.max.max.alpha])))

            print(("[%d] SP  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.sp)))
            print(("[%d] pool_id  = %d" % (i, attr_item.attr.multicast_shared_buff_attr.pool_id)))
        if attr_item.type > SX_COS_MULTICAST_ATTR_E or attr_item.type < SX_COS_INGRESS_PORT_ATTR_E:
            print(("[%d] Unsupported union type = %d" % (i, attr_item.type)))


print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


""" PORT [MC] TYPE BUFF GET (MIN) """
print("\n")
print("1) Get count")
print("#####################")
print("##### CNT = 0 #######")
print("#####################")
print("---------------  MC: PORT TYPE BUFF GET (MIN) ------------------------------")
count = 0
log_port = SX_MC_PORT_LOG_ID
port_buffer_attr_cnt = new_uint32_t_p()
uint32_t_p_assign(port_buffer_attr_cnt, count)

rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
print(("*sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))

print("--------------------------------------------------------------------")


""" PORT [MC] SHARED BUFF GET """
print("---------------  MC: PORT SHARED BUFF GET ------------------------------")
count = 0
log_port = SX_MC_PORT_LOG_ID

port_shared_buffer_attr_cnt = new_uint32_t_p()
uint32_t_p_assign(port_shared_buffer_attr_cnt, count)

rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_shared_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)
print(("*sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))
print("#############################")

print("--------------- PORT = 0x10001:  PORT TYPE BUFF GET (MIN) ------------------------------")
count = 0
log_port = 0x10001
port_buffer_attr_cnt = new_uint32_t_p()
uint32_t_p_assign(port_buffer_attr_cnt, count)

rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_buffer_attr_cnt)
print(("*sx_api_cos_port_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))

print("--------------------------------------------------------------------")


""" PORT SHARED BUFF GET """
print("--------------- PORT = 0x10001: PORT SHARED BUFF GET ------------------------------")
count = 0
log_port = 0x10001

port_shared_buffer_attr_cnt = new_uint32_t_p()
uint32_t_p_assign(port_shared_buffer_attr_cnt, count)

rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_shared_buffer_attr_cnt)
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

attr_cnt = uint32_t_p_value(port_shared_buffer_attr_cnt)
print(("*sx_api_cos_port_shared_buff_type_get [log_port=0x%x , cnt=%d, rc=%d] " % (log_port, attr_cnt, rc)))

print("\n")
print("2) Get all port buffers (One port)")

port_cnt_p = new_uint32_t_p()
port_attributes_list = new_sx_port_attributes_t_arr(1)
port_attributes = sx_port_attributes_t()
uint32_t_p_assign(port_cnt_p, 1)
rc = sx_api_port_device_get(handle, 1, 0, port_attributes_list, port_cnt_p)
port_cnt = uint32_t_p_value(port_cnt_p)
print(("sx_api_port_device_get port_cnt:%d , rc %d, port_list : " % (port_cnt, rc)))
print("====================================================================================================")
for i in range(0, port_cnt):
    port_attributes = sx_port_attributes_t_arr_getitem(port_attributes_list, i)
    is_nve = check_nve(int(port_attributes.log_port))
    is_cpu = check_cpu(int(port_attributes.log_port))
    if is_nve or is_cpu:
        continue
    cnt = sx_port_cntr_cli_t()
    rc = sx_api_port_counter_cli_get(handle, SX_ACCESS_CMD_READ, port_attributes.log_port, cnt)
    print_all_port_props(port_attributes.log_port)


print("\n")
print("3) Get MC all buffers ")
print("##########################*******####")
print("##### Port = SX_MC_PORT_LOG_ID ######")
print("#########################*******#####")
print("----------------------Printing Multicast buffers ---------------------------------------------------")
print_all_port_props(SX_MC_PORT_LOG_ID)

print("\n")
print("4) Get POOLS buffers ")
print("##############################")
print("##### Get POOLS buffers ######")
print("##############################")
print("---------------------- Printing Global Shared Pools ------------------------------------------------")
print_all_shared_pool_props()

print("\n")
print("5) Get Egress port.pool buffers ")
print("##############################")
print("##### Port = 0x10001 ######")
print("##############################")
print_eport_pool_props(0x10001)
