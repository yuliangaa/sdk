#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates N regions
    2. Creates N acls
    3. Add each acl to group
    4. adds rule to regions
    5. Bind between groups
    6. Bind head group to port
    7. Print dump
    8. Unbind head group from port
    9. Unbind between groups
    10 . Destroy groups
    11. Delete rules
    12. Destroy created acls and regions

"""
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
import argparse
from test_infra_common import get_chip_type, get_ports

parser = argparse.ArgumentParser(description='sx_api_flex_acl example')
parser.add_argument('--multi_dir', action='store_true', help='Run an configuration example that creates a multi-direction ACL table.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################

######################################################
#    functions
######################################################
# layer 2


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create():
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, FLEX_ACL_KEY_L4_DESTINATION_PORT)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def group_create(acl_id_arr, acls_num, direction):
    " This function creates flex acl and returns acl id  "
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_CREATE,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create group"

    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_SET,
                              direction,
                              acl_id_arr,
                              acls_num,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add acls to group"

    group_id = sx_acl_id_t_p_value(group_id_p)
    print("Created group %d, rc: %d" % (group_id, rc))
    for i in range(0, acls_num):
        print("acl id = %d " % sx_acl_id_t_arr_getitem(acl_id_arr, i))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id


def group_destroy(group_id):
    " This function destroy  flex acl key "
    group_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(group_id_p, group_id)
    acl_id_arr = new_sx_acl_id_t_arr(5)
    sx_acl_id_t_arr_setitem(acl_id_arr, 0, group_id)

    direction = 0
    rc = sx_api_acl_group_set(handle,
                              SX_ACCESS_CMD_DESTROY,
                              direction,
                              acl_id_arr,
                              0,
                              group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy group"

    print("Destroyed group %d, rc: %d" % (group_id, rc))
    delete_sx_acl_id_t_p(group_id_p)


def rule_set(region_id, offset, access):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''
    rule = sx_flex_acl_flex_rule_t()
    rule.valid = 1
    sx_lib_flex_acl_rule_init(0, 10, rule)

    key_desc = sx_flex_acl_key_desc_t()
    key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
    key_desc.key.l4_destination_port = 7
    key_desc.mask.l4_destination_port = 11

    # rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
    sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
    rule.key_desc_count = 1

    action1 = sx_flex_acl_flex_action_t()
    action1.type = SX_FLEX_ACL_ACTION_SET_TTL
    action1.fields.action_set_ttl.ttl_val = 100
    action2 = sx_flex_acl_flex_action_t()
    action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
    action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
    action2.fields.action_set_vlan.vlan_id = 6
    action3 = sx_flex_acl_flex_action_t()
    action3.type = SX_FLEX_ACL_ACTION_FORWARD
    action3.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

    # rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
    sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
    rule.action_count = 3

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(5)
    sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, 0, rule)

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 0)

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   1)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    if access == SX_ACCESS_CMD_SET:
        print("Added rule offset  %d, to region %d,  rc: %d" % (offset, region_id, rc))
    else:
        print("Deleted rule offset  %d, region %d,  rc: %d" % (offset, region_id, rc))

    # delete_sx_flex_acl_key_desc_t_arr(rule.key_desc_list_p)
    # delete_sx_flex_acl_flex_action_t_arr(rule.action_list_p)
    delete_sx_flex_acl_flex_rule_t_arr(rule_arr)
    delete_sx_acl_rule_offset_t_arr(offsets_list)


def set_50_rules(region_id):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    # sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 10)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(25)
    rules_list = []
    for x in range(0, 16):
        rule = sx_flex_acl_flex_rule_t()
        sx_lib_flex_acl_rule_init(0, 10, rule)
        rule.valid = 1
        rules_list.append(rule)

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
        key_desc.key.l4_destination_port = 7 + x
        key_desc.mask.l4_destination_port = 11 + x

        # rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
        rule.key_desc_count = 1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_SET_TTL
        action1.fields.action_set_ttl.ttl_val = 100
        action2 = sx_flex_acl_flex_action_t()
        action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
        action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
        action2.fields.action_set_vlan.vlan_id = 20

        action3 = sx_flex_acl_flex_action_t()
        action3.type = SX_FLEX_ACL_ACTION_FORWARD
        action3.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

        # rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
        rule.action_count = 2 + x % 2

        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x])

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    for x in range(0, 16):
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x)

    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   16)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    for x in range(0, 16):
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x + 16)

    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   16)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"

    for x in range(0, 16):
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x + 32)

    rc = sx_api_acl_flex_rules_set(handle,
                                   SX_ACCESS_CMD_SET,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   16)
    assert SX_STATUS_SUCCESS == rc, "Failed to add rule"


def get_50_rules(region_id):

    offsets_list = new_sx_acl_rule_offset_t_arr(50)
    print("Before first rules get")
    # sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 10)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(50)
    rules_list = []
    check_rules_list = []

    for x in range(0, 48):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 10, rule)
        rules_list.append(rule)
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x])

    print("Before first rules get")
    rules_cnt = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt, 0)
    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   None,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rule get count is = %d,  rc: %d" % (cnt, rc))
    assert cnt == 48, "Rules count is wrong"

    print("Get the counters of each rule")

    offsets_list = new_sx_acl_rule_offset_t_arr(50)

    rule_arr_2 = new_sx_flex_acl_flex_rule_t_arr(50)
    rule = sx_flex_acl_flex_rule_t()
    rule.key_desc_list_p = None
    rule.action_list_p = None
    rule.valid = 1
    for x in range(0, 48):
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr_2, x, rule)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, 0)

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr_2,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rules count is %d" % (cnt))
    for x in range(0, 48):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr_2, x)
        print("Action count is %d, key count is %d, rule idx %d" % (rule_get.action_count, rule_get.key_desc_count, x))
        assert rule_get.action_count == (2 + x % 2)
        assert rule_get.key_desc_count == 1

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rules count is %d" % (cnt))
    rule_get = sx_flex_acl_flex_rule_t()
    for x in range(0, 48):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr, x)
        key_desc = sx_flex_acl_key_desc_t_arr_getitem(rule_get.key_desc_list_p, 0)
        print("x are %d" % (x))
        print(" key_desc.key.l4_destination_port = %d" % (key_desc.key.l4_destination_port))
        assert key_desc.key.l4_destination_port == (7 + x % 16)
        assert key_desc.mask.l4_destination_port == (11 + x % 16)

        action1 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 0)
        action2 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 1)
        assert action1.type == SX_FLEX_ACL_ACTION_SET_TTL
        assert action2.type == SX_FLEX_ACL_ACTION_SET_VLAN
        if (x % 2):
            action3 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 2)
            assert action3.type == SX_FLEX_ACL_ACTION_FORWARD
            assert action3.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

        assert action1.fields.action_set_ttl.ttl_val == 100
        assert action2.fields.action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH

        offset = sx_acl_rule_offset_t_arr_getitem(offsets_list, x)
        assert offset == x


def set_mirror_enable_port_rules(region_id, access):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rule_arr = new_sx_flex_acl_flex_rule_t_arr(25)
    rules_list = []
    for x in range(0, 16):
        rule = sx_flex_acl_flex_rule_t()
        sx_lib_flex_acl_rule_init(0, 10, rule)
        rule.valid = 1
        rules_list.append(rule)

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT
        key_desc.key.l4_destination_port = 7 + x
        key_desc.mask.l4_destination_port = 11 + x

        # rule.key_desc_list_p = new_sx_flex_acl_key_desc_t_arr(5)
        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
        rule.key_desc_count = 1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW
        # test_bind_type_count = random.randrange(SX_SPAN_MIRROR_BIND_TYPE_MIN_E,SX_SPAN_MIRROR_BIND_TYPE_MAX_E)
        test_bind_type_count = x % SX_SPAN_MIRROR_BIND_TYPE_MAX_E
        action1.fields.action_mirror_disallow.cfg_list.mirror_trigger_disallow_cnt = test_bind_type_count
        for i in range(SX_SPAN_MIRROR_BIND_TYPE_MIN_E, test_bind_type_count):
            cfg_elem = sx_span_mirror_trigger_disallow_cfg_t()
            cfg_elem.type = i
            cfg_elem.mirror_trigger_disallow = i % 2
            sx_span_mirror_trigger_disallow_cfg_t_arr_setitem(action1.fields.action_mirror_disallow.cfg_list.mirror_trigger_disallow, i, cfg_elem)
        action2 = sx_flex_acl_flex_action_t()
        action2.type = SX_FLEX_ACL_ACTION_SET_VLAN
        action2.fields.action_set_vlan.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH
        action2.fields.action_set_vlan.vlan_id = 20

        action3 = sx_flex_acl_flex_action_t()
        action3.type = SX_FLEX_ACL_ACTION_FORWARD
        action3.fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

        # rule.action_list_p = new_sx_flex_acl_flex_action_t_arr(5)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
        rule.action_count = 2 + x % 2

        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x])

    offsets_list = new_sx_acl_rule_offset_t_arr(25)
    for x in range(0, 16):
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, x)

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   16)
    if access == SX_ACCESS_CMD_SET:
        assert SX_STATUS_SUCCESS == rc, "Failed to add rules"
        print("Added rules to region %d,  rc: %d" % (region_id, rc))
    else:
        assert SX_STATUS_SUCCESS == rc, "Failed to delete rules"
        print("Deleted rules from region %d,  rc: %d" % (region_id, rc))


def get_mirror_enable_port_rules(region_id):

    offsets_list = new_sx_acl_rule_offset_t_arr(16)
    print("Before first rules get")
    # sx_acl_rule_offset_t_arr_setitem(offsets_list, 0, 10)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(16)
    rules_list = []
    check_rules_list = []

    for x in range(0, 16):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 10, rule)
        rules_list.append(rule)
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, x, rules_list[x])

    print("Before first rules get")
    rules_cnt = new_uint32_t_p()
    uint32_t_p_assign(rules_cnt, 0)
    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   None,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rule get count is = %d,  rc: %d" % (cnt, rc))
    assert cnt == 16, "Rules count is wrong"

    print("Get the counters of each rule")

    offsets_list = new_sx_acl_rule_offset_t_arr(16)

    rule_arr_2 = new_sx_flex_acl_flex_rule_t_arr(16)
    rule = sx_flex_acl_flex_rule_t()
    rule.key_desc_list_p = None
    rule.action_list_p = None
    rule.valid = 1
    for x in range(0, 16):
        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr_2, x, rule)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, x, 0)

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr_2,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rules count is %d" % (cnt))
    for x in range(0, 16):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr_2, x)
        print("Action count is %d, key count is %d, rule idx %d" % (rule_get.action_count, rule_get.key_desc_count, x))
        assert rule_get.action_count == (2 + x % 2)
        assert rule_get.key_desc_count == 1

    rc = sx_api_acl_flex_rules_get(handle,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to get rule counters"
    cnt = uint32_t_p_value(rules_cnt)
    print("Rules count is %d" % (cnt))

    rule_get = sx_flex_acl_flex_rule_t()
    for x in range(0, 16):
        rule_get = sx_flex_acl_flex_rule_t_arr_getitem(rule_arr, x)
        key_desc = sx_flex_acl_key_desc_t_arr_getitem(rule_get.key_desc_list_p, 0)
        print("x are %d" % (x))
        print(" key_desc.key.l4_destination_port = %d" % (key_desc.key.l4_destination_port))
        assert key_desc.key.l4_destination_port == (7 + x % 16)
        assert key_desc.mask.l4_destination_port == (11 + x % 16)

        action1 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 0)
        action2 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 1)
        assert action1.type == SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW
        assert action2.type == SX_FLEX_ACL_ACTION_SET_VLAN
        if (x % 2):
            action3 = sx_flex_acl_flex_action_t_arr_getitem(rule_get.action_list_p, 2)
            assert action3.type == SX_FLEX_ACL_ACTION_FORWARD
            assert action3.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD

        # assert action1.fields.action_set_ttl.ttl_val == 100
        assert action2.fields.action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH

        offset = sx_acl_rule_offset_t_arr_getitem(offsets_list, x)
        assert offset == x


def group_bind_get(group_id_prev):
    "This example gets the group bind in context pof rev->next and returns next group id"
    group_id_p = new_sx_acl_id_t_p()

    rc = sx_api_acl_group_bind_get(handle,
                                   group_id_prev,
                                   group_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to get bind between groups"

    group_id_next = sx_acl_id_t_p_value(group_id_p)
    print("Group %d is bound to group %d  rc: %d" % (group_id_prev, group_id_next, rc))

    delete_sx_acl_id_t_p(group_id_p)
    return group_id_next


def acl_attr_set(acl_id, acl_drop_trap_en, acl_name="", expected_rc=SX_STATUS_SUCCESS, acl_direction_bitmap=0):
    '''
    SET  ACL Attributes

    Parameters
    ----------
    @handle - SDK handle.
    @param acl_id: The ACL id whose attributes to set/modify
    @param acl_drop_trap_en: Enable/Disable Trapping packets dropped by ACL
    @param acl_name: String Name Description of ACL
    '''
    acl_attr = sx_acl_attributes_t()

    acl_attr.disable_acl_drop_monitoring_trap = not acl_drop_trap_en
    if acl_name != "":
        acl_attr.acl_desc.acl_name_str = acl_name
        acl_attr.acl_desc.acl_name_str_len = len(acl_name)
    acl_attr.multi_direction.acl_direction_bitmap = acl_direction_bitmap

    cmd = SX_ACCESS_CMD_SET
    rc = sx_api_acl_attributes_set(handle, cmd, acl_id, acl_attr)
    assert SX_STATUS_SUCCESS == rc, "Failed to set ACL Attributes"


def main():
    "This example uses a predefined function to bind group to region "
    acl_direction = SX_ACL_DIRECTION_INGRESS
    acl_group_direction = SX_ACL_DIRECTION_INGRESS
    group_list = []
    acl_list = []
    region_list = []
    chip_type = get_chip_type(handle)

    key_handle = key_create()

    if args.multi_dir:
        acl_direction = SX_ACL_DIRECTION_MULTI_POINTS_E
        acl_direction_bitmap = 0 | (1 << SX_ACL_DIRECTION_INGRESS) \
                                 | (1 << SX_ACL_DIRECTION_EGRESS)

    for i in range(0, 2):
        region_id = region_create(key_handle, 60)
        region_list.append(region_id)

        acl_id = acl_create(region_id, acl_direction)
        acl_list.append(acl_id)

        if args.multi_dir:
            acl_attr_set(acl_id, False, acl_name="TEST_ACL", acl_direction_bitmap=acl_direction_bitmap)

        acl_id_arr = new_sx_acl_id_t_arr(5)
        sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)

        group_id = group_create(acl_id_arr, 1, acl_group_direction)
        group_list.append(group_id)

        # the rule hard coded now with action discard
        rule_set(region_id, 0, SX_ACCESS_CMD_SET)

    rc = sx_api_acl_group_bind_set(handle,
                                   SX_ACCESS_CMD_BIND,
                                   group_list[0],
                                   group_list[1])
    assert SX_STATUS_SUCCESS == rc, "Failed to bind between groups"
    print("Group %d is bound to group %d  rc: %d" % (group_list[0], group_list[1], rc))
    # bind port to existing group
    port = get_ports(handle, 1)[0]
    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  port,
                                  group_list[0])
    print("Port %d is bound to group %d  rc: %d" % (port, group_id, rc))

    if args.multi_dir:
        acl_group_direction = SX_ACL_DIRECTION_EGRESS
        egress_group_id = group_create(acl_id_arr, 1, acl_group_direction)

        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_BIND,
                                      port,
                                      egress_group_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to bind ACL group in the EGRESS direction"

    set_50_rules(region_list[0])
    sx_api_dbg_generate_dump(handle, "/tmp/flex_acl_dump_log")
    get_50_rules(region_list[0])

    if chip_type == SX_CHIP_TYPE_SPECTRUM4 or chip_type == SX_CHIP_TYPE_SPECTRUM5:
        acl_direction = SX_ACL_DIRECTION_INGRESS
        cond_mirror_region_id = region_create(key_handle, 60)
        cond_mirror_acl_id = acl_create(cond_mirror_region_id, acl_direction)
        acl_id_arr = new_sx_acl_id_t_arr(5)
        sx_acl_id_t_arr_setitem(acl_id_arr, 0, acl_id)
        cond_mirror_group_id = group_create(acl_id_arr, 1, 0)
        set_mirror_enable_port_rules(cond_mirror_region_id, SX_ACCESS_CMD_SET)
        get_mirror_enable_port_rules(cond_mirror_region_id)

    if args.deinit:
        if args.multi_dir:
            rc = sx_api_acl_port_bind_set(handle,
                                          SX_ACCESS_CMD_UNBIND,
                                          port,
                                          egress_group_id)
            assert SX_STATUS_SUCCESS == rc, "Failed to unbind EGRESS ACL group"

            group_destroy(egress_group_id)

        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      port,
                                      group_list[0])
        print("port %d unbound frop  group %d  rc: %d" % (port, group_id, rc))
        group_bind_get(group_list[0])

        rc = sx_api_acl_group_bind_set(handle,
                                       SX_ACCESS_CMD_UNBIND,
                                       group_list[0],
                                       group_list[1])
        print("group %d unbound from group %d  rc: %d" % (group_list[0], group_list[1], rc))

        if chip_type == SX_CHIP_TYPE_SPECTRUM4 or chip_type == SX_CHIP_TYPE_SPECTRUM5:
            set_mirror_enable_port_rules(cond_mirror_region_id, SX_ACCESS_CMD_DELETE)
            group_destroy(cond_mirror_group_id)
            acl_destroy(cond_mirror_acl_id, cond_mirror_region_id)
            region_destroy(cond_mirror_region_id)

        for i in range(0, 2):
            group_destroy(group_list[i])
            rule_set(region_list[i], 0, SX_ACCESS_CMD_DELETE)
            acl_destroy(acl_list[i], region_list[i])
            region_destroy(region_list[i])
        key_destroy(key_handle)

    sx_api_close(handle)

    print("finished")


if __name__ == "__main__":
    main()
