#!/usr/bin/env python
'''
This file contains Python command example for Host interface Trap module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_id_register_get example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(errno.EACCES)

######################################################
#    defines
######################################################
user_channel_dict_list = [
    {
        "type": SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV
    },

    {
        "type": SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV
    },

    {
        "type": SX_USER_CHANNEL_TYPE_L3_NETDEV
    },

    {
        "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
        "channel": {
            "l2_tunnel_params": {
                "dmac": 0x12345678,
                "vid": 100,
                "prio": 1
            }
        }
    },

    {
        "type": SX_USER_CHANNEL_TYPE_L2_TUNNEL,
        "channel": {
            "l2_tunnel_params": {
                "dmac": 0x12345678,
                "vid": 99,
                "prio": 1
            }
        }
    }
]


def make_user_channel_list(user_channel_dict_list):
    return_list = []

    for entry in user_channel_dict_list:
        user_channel_obj = sx_user_channel_t()
        for key in entry:
            if key == "type":
                user_channel_obj.type = entry[key]
            elif key == "channel":
                channel = entry[key]
                for sub_key2 in channel:
                    if sub_key2 == "fd":
                        fd = channel[sub_key2]
                        fd_obj = sx_fd_t()
                        for sub_key3 in fd:
                            if sub_key3 == "fd":
                                fd_obj.fd = fd[sub_key3]
                            elif sub_key3 == "driver_handle":
                                fd_obj.driver_handle = fd[sub_key3]
                            elif sub_key3 == "valid":
                                fd_obj.valid = fd[sub_key3]

                        user_channel_obj.channel.fd = fd_obj

                    elif sub_key2 == "l2_tunnel_params":
                        l2_tunnel_params = channel[sub_key2]
                        l2_tunnel_params_obj = ku_l2_tunnel_params()
                        for sub_key3 in l2_tunnel_params:
                            if sub_key3 == "dmac":
                                l2_tunnel_params_obj.dmac = l2_tunnel_params[sub_key3]
                            elif sub_key3 == "vid":
                                l2_tunnel_params_obj.vid = l2_tunnel_params[sub_key3]
                            elif sub_key3 == "prio":
                                l2_tunnel_params_obj.prio = l2_tunnel_params[sub_key3]

                        user_channel_obj.channel.l2_tunnel_params = l2_tunnel_params_obj

        return_list.append(user_channel_obj)

    return return_list


def are_two_user_channels_equal(user_channel1, user_channel2):

    if user_channel1.type != user_channel2.type:
        return False

    if user_channel1.type == SX_USER_CHANNEL_TYPE_FD:
        if user_channel1.channel.fd.fd != user_channel2.channel.fd.fd:
            return False

        if user_channel1.channel.fd.driver_handle != user_channel2.channel.fd.driver_handle:
            return False

        if user_channel1.channel.fd.valid and (not user_channel2.channel.fd.valid):
            return False

        if (not user_channel1.channel.fd.valid) and user_channel2.channel.fd.valid:
            return False

    if user_channel1.type == SX_USER_CHANNEL_TYPE_L2_TUNNEL:
        if user_channel1.channel.l2_tunnel_params.dmac != user_channel2.channel.l2_tunnel_params.dmac:
            return False

        if user_channel1.channel.l2_tunnel_params.vid != user_channel2.channel.l2_tunnel_params.vid:
            return False

        if user_channel1.channel.l2_tunnel_params.prio != user_channel2.channel.l2_tunnel_params.prio:
            return False

    return True


user_channels = make_user_channel_list(user_channel_dict_list)

for i in range(0, 5):
    rc = sx_api_host_ifc_trap_id_register_set(handle,
                                              SX_ACCESS_CMD_REGISTER,
                                              SX_SWID_ID_MIN,
                                              SX_TRAP_ID_MIN,
                                              user_channels[i])
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_set failed, rc = %d" % (rc)

# get the total count
user_channel_cnt_p = new_uint32_t_p()
user_channel_list_p = new_sx_user_channel_t_arr(5)
uint32_t_p_assign(user_channel_cnt_p, 0)
rc = sx_api_host_ifc_trap_id_register_get(handle,
                                          SX_ACCESS_CMD_GET,
                                          SX_SWID_ID_MIN,
                                          SX_TRAP_ID_MIN,
                                          None,
                                          None,
                                          user_channel_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_get failed, rc = %d" % (rc)
user_channel_cnt = uint32_t_p_value(user_channel_cnt_p)
assert user_channel_cnt == 5, "the returned count is not correct"

# get the first two entries
uint32_t_p_assign(user_channel_cnt_p, 2)
rc = sx_api_host_ifc_trap_id_register_get(handle,
                                          SX_ACCESS_CMD_GET_FIRST,
                                          SX_SWID_ID_MIN,
                                          SX_TRAP_ID_MIN,
                                          None,
                                          user_channel_list_p,
                                          user_channel_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_get failed, rc = %d" % (rc)
user_channel_cnt = uint32_t_p_value(user_channel_cnt_p)
assert user_channel_cnt == 2, "the returned count is not correct"
assert are_two_user_channels_equal(sx_user_channel_t_arr_getitem(user_channel_list_p, 0), user_channels[2]), "the returned user_channels are incorrect"
assert are_two_user_channels_equal(sx_user_channel_t_arr_getitem(user_channel_list_p, 1), user_channels[0]), "the returned user_channels are incorrect"

# get the next three entries after an entry
uint32_t_p_assign(user_channel_cnt_p, 3)
rc = sx_api_host_ifc_trap_id_register_get(handle,
                                          SX_ACCESS_CMD_GETNEXT,
                                          SX_SWID_ID_MIN,
                                          SX_TRAP_ID_MIN,
                                          user_channels[0],
                                          user_channel_list_p,
                                          user_channel_cnt_p)
assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_get failed, rc = %d" % (rc)
user_channel_cnt = uint32_t_p_value(user_channel_cnt_p)
assert user_channel_cnt == 3, "the returned count is not correct"
assert are_two_user_channels_equal(sx_user_channel_t_arr_getitem(user_channel_list_p, 0), user_channels[1]), "the returned user_channels are incorrect"
assert are_two_user_channels_equal(sx_user_channel_t_arr_getitem(user_channel_list_p, 1), user_channels[4]), "the returned user_channels are incorrect"
assert are_two_user_channels_equal(sx_user_channel_t_arr_getitem(user_channel_list_p, 2), user_channels[3]), "the returned user_channels are incorrect"

if args.deinit:
    # deregister the entries
    for i in range(0, 5):
        rc = sx_api_host_ifc_trap_id_register_set(handle,
                                                  SX_ACCESS_CMD_DEREGISTER,
                                                  SX_SWID_ID_MIN,
                                                  SX_TRAP_ID_MIN,
                                                  user_channels[i])
        assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_id_register_set failed; id=%d, rc = %d" % (i, rc)

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
