#!/usr/bin/env python
'''
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

This utility dumps the MACSec SC objects.
'''
import sys
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *
from python_sdk_api.sxd_api import *


def macsec_flow_obj_get(handle, flow_id):
    macsec_flow_obj_id = flow_id
    macsec_flow_attr_p = new_sx_macsec_flow_attribute_t_p()
    try:
        rc = sx_api_macsec_flow_obj_get(handle, SX_ACCESS_CMD_GET, macsec_flow_obj_id, macsec_flow_attr_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_flow_obj_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
        macsec_flow_attr = sx_macsec_flow_attribute_t_p_value(macsec_flow_attr_p)
        return macsec_flow_attr
    finally:
        delete_sx_macsec_flow_attribute_t_p(macsec_flow_attr_p)


def macsec_sc_obj_iter(handle, access_cmd, sc_obj_id, flow_obj_id, direction, count):
    if access_cmd == SX_ACCESS_CMD_GET:
        if sc_obj_id is None:
            raise Exception("Valid SC object ID is needed")

    sc_filter = sx_macsec_sc_filter_t()
    if direction is not None:
        if direction == 'ingress':
            sc_filter.direction = SX_MACSEC_DIR_INGRESS_E
        elif direction == 'egress':
            sc_filter.direction = SX_MACSEC_DIR_EGRESS_E
        sc_filter.filter_by_dir = SX_KEY_FILTER_FIELD_VALID
    else:
        sc_filter.filter_by_dir = SX_KEY_FILTER_FIELD_NOT_VALID

    if flow_obj_id is not None:
        sc_filter.flow_obj_id = int(args.flow_obj_id, 16)
        sc_filter.filter_by_flow = SX_KEY_FILTER_FIELD_VALID

    macsec_sc_attr_list_p = new_sx_macsec_sc_attribute_t_arr(count)
    macsec_sc_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(macsec_sc_cnt_p, count)
    sc_filter_p = new_sx_macsec_sc_filter_t_p()
    sx_macsec_sc_filter_t_p_assign(sc_filter_p, sc_filter)

    try:
        rc = sx_api_macsec_sc_obj_iter_get(handle, access_cmd, sc_obj_id, sc_filter_p, macsec_sc_attr_list_p, macsec_sc_cnt_p)
        assert rc == SX_STATUS_SUCCESS, "sx_api_macsec_sc_obj_iter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
        if count == 0:
            # count retrieval
            return uint32_t_p_value(macsec_sc_cnt_p)
        else:
            # object retrieval
            count = uint32_t_p_value(macsec_sc_cnt_p)
            return [sx_macsec_sc_attribute_t_arr_getitem(macsec_sc_attr_list_p, i) for i in range(count)]
    finally:
        delete_sx_macsec_sc_filter_t_p(sc_filter_p)
        delete_uint32_t_p(macsec_sc_cnt_p)
        delete_sx_macsec_sc_attribute_t_arr(macsec_sc_attr_list_p)


def generate_sc_dump(handle, args):
    macsec_dir_type_enum_dict = get_enum_string_dict('SX_MACSEC_DIR_')
    macsec_cipher_type_enum_dict = get_enum_string_dict('SX_MACSEC_CIPHER_')
    if args.sc_obj_id is not None:
        sc_id = int(args.sc_obj_id, 16)
        macsec_sc_attr = macsec_sc_obj_iter(handle, SX_ACCESS_CMD_GET, sc_id, None, None, 1)
        print("SC obj ID[0x%8x]" % (macsec_sc_attr.sc_obj_id))
        print("Flow Obj ID[0x%8x]" % (macsec_sc_attr.flow_obj_id))
        print("Protcol SC ID[0x%x]" % (macsec_sc_attr.sc_profile.sc_id))
        print("Cipher suite [%s]" % (macsec_cipher_type_enum_dict[macsec_sc_attr.sc_profile.sc_cipher_suite]))
        print("Confidentiality offset  [%d]" % (sc_attr.sc_profile.confid_offset))
        macsec_flow_attr = macsec_flow_obj_get(handle, macsec_sc_attr.flow_obj_id)
        if macsec_flow_attr.direction == SX_MACSEC_DIR_INGRESS_E:
            if sc_attr.sc_profile.sc_dir_attr.sc_rx_attr.replay_protection_enable:
                print("Protection Enable = TRUE")
            else:
                print("Protection Enable = FALSE")
            print("Window size [%d]" % (sc_attr.sc_profile.sc_dir_attr.sc_rx_attr.replay_protection_window_sz))
        else:
            if sc_attr.sc_profile.sc_dir_attr.sc_tx_attr.explicit_sci_enable:
                print("Explicit SCI Enable = TRUE")
            else:
                print("Explicit SCI Enable = FALSE")
        return

    iter_fetch_count = 50
    sc_obj_attr_list = macsec_sc_obj_iter(handle, SX_ACCESS_CMD_GET_FIRST, 0, args.flow_obj_id, args.direction, 1)
    iter_get_list_len = len(sc_obj_attr_list)
    print("=========================================================================================================================================================================================")
    header = ["SC Obj", "Flow Obj", "Direction", "Proto SC", "Cipher", "Protection", "Window Size", "Explicit SCI", "Confidentiality Offset"]
    print("|%20s|%20s|%28s|%9s|%40s|%10s|%11s|%12s|%25s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8]))
    print("=========================================================================================================================================================================================")
    while (iter_get_list_len > 0):
        for macsec_sc_attr in sc_obj_attr_list:
            sc_obj = "0x%x" % macsec_sc_attr.sc_obj_id
            flow_obj = "0x%x" % macsec_sc_attr.flow_obj_id
            macsec_flow_attr = macsec_flow_obj_get(handle, macsec_sc_attr.flow_obj_id)
            profile_attr = macsec_sc_attr.sc_profile
            direction = macsec_dir_type_enum_dict[macsec_flow_attr.direction]
            cipher = macsec_cipher_type_enum_dict[macsec_sc_attr.sc_profile.sc_cipher_suite]
            confid_offset = profile_attr.confid_offset
            if macsec_flow_attr.direction == SX_MACSEC_DIR_INGRESS_E:
                if macsec_sc_attr.sc_profile.sc_dir_attr.sc_rx_attr.replay_protection_enable:
                    protect = "TRUE"
                else:
                    protect = "FALSE"
                window_sz = profile_attr.sc_dir_attr.sc_rx_attr.replay_protection_window_sz
                print("|%20s|%20s|%28s|%9d|%40s|%10s|%11d|%12s|%25d|" % (sc_obj, flow_obj, direction, profile_attr.sc_id, cipher, protect, window_sz, "N/A", confid_offset))
            else:
                if macsec_sc_attr.sc_profile.sc_dir_attr.sc_tx_attr.explicit_sci_enable:
                    sci_enable = "TRUE"
                else:
                    sci_enable = "FALSE"
                print("|%20s|%20s|%28s|%9d|%40s|%10s|%11s|%12s|%25d|" % (sc_obj, flow_obj, direction, profile_attr.sc_id, cipher, "N/A", "N/A", sci_enable, confid_offset))
        # get next set of flow objects.
        sc_obj_attr_list = macsec_sc_obj_iter(handle, SX_ACCESS_CMD_GETNEXT, macsec_sc_attr.sc_obj_id, args.flow_obj_id, args.direction, iter_fetch_count)
        iter_get_list_len = len(sc_obj_attr_list)
    print("=========================================================================================================================================================================================")


def check_macsec_init_status(handle):
    macsec_init_params_p = new_sx_macsec_init_params_t_p()
    try:
        rc = sx_api_macsec_init_params_get(handle, macsec_init_params_p)
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            print("MACSec module is not initialized")
            sys.exit()
    finally:
        delete_sx_macsec_init_params_t_p(macsec_init_params_p)


def parse_example_attributes():
    parser = argparse.ArgumentParser(description='MACSec SC dump utility')
    parser.add_argument('--flow_obj_id', '-p', help="SC object filter flow")
    parser.add_argument('--direction', '-d', choices=['ingress', 'egress'], help="SC object filter direction")
    parser.add_argument('--sc_obj_id', '-sc', help='SC obj for flow iterator get')
    args = parser.parse_args()
    return args


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(errno.EACCES)

    chip_type = get_chip_type(handle, True)
    if chip_type != SX_CHIP_TYPE_SPECTRUM4:
        print("MACSec is only supported on SPECTRUM4 ASIC")
        sys.exit()

    check_macsec_init_status(handle)

    args = parse_example_attributes()
    generate_sc_dump(handle, args)

    sx_api_close(handle)
