#!/usr/bin/env python
'''
Stateful DB example for configuration flows
1. Edit of global attributes
2. Configuring partition and writing entry using sw access
3. Ordering enable /disable flow
'''

import errno
import sys
import argparse
import test_infra_common

from python_sdk_api.sx_api import *
from test_infra_common import *


def parse_args():
    description_str = """
    Stateful DB example for configuration flows
    1. Edit of global attributes
    2. Configuring partition and writing entry using sw access
    3. Ordering enable /disable flow
    """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")
    return parser.parse_args()


def stateful_db_attributes_get(handle):
    # Get stateful DB attributes
    conf_attr_p = new_sx_stateful_db_attributes_t_p()
    cont_attr = sx_stateful_db_attributes_t()
    rc = sx_api_stateful_db_attr_get(handle, SX_ACCESS_CMD_GET, conf_attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB attribute get failed ")
        sys.exit(rc)
    conf_attr = sx_stateful_db_attributes_t_p_value(conf_attr_p)
    return conf_attr


def stateful_db_attributes_dump(global_attr):
    print(" --------Stateful DB attributes-----------")
    print(" max_sem_retries = %d" % global_attr.max_sem_retries)
    print(" entry_not_found_sem_unlock_failure  = %s" % bool(global_attr.entry_not_found_sem_unlock_failure))
    print(" force_ordering_enable  = %s" % bool(global_attr.force_ordering_enable))
    print(" ordering register = %d" % global_attr.ordering_register.key.gp_reg.reg_id)
    print(" -----------------------------------------")


def stateful_db_attributes_compare(conf_attr, expected_attr):
    if (conf_attr.max_sem_retries != expected_attr.max_sem_retries):
        print("Stateful DB attribute get value mismatch! expected = %d got = %d" % (expected_attr.max_sem_retries, conf_attr.max_sem_retries))
        sys.exit(1)
    if (conf_attr.entry_not_found_sem_unlock_failure != expected_attr.entry_not_found_sem_unlock_failure):
        print("Stateful DB attribute get value mismatch! expected = %s got = %s" % (bool(expected_attr.entry_not_found_sem_unlock_failure), bool(conf_attr.entry_not_found_sem_unlock_failure)))
        sys.exit(1)
    if (conf_attr.force_ordering_enable != expected_attr.force_ordering_enable):
        print("Stateful DB attribute get value mismatch! expected = %s got = %s" % (bool(expected_attr.force_ordering_enable), bool(conf_attr.force_ordering_enable)))
        sys.exit(1)
    if (conf_attr.ordering_register.key.gp_reg.reg_id != expected_attr.ordering_register.key.gp_reg.reg_id):
        print("Stateful DB attribute get value mismatch! expected = %d got = %d" % (expected_attr.ordering_register.key.gp_reg.reg_id, conf_attr.ordering_register.key.gp_reg.reg_id))
        sys.exit(1)
    print("Global attributes compare OK")


def stateful_db_attr_edit(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id):
    attr_p = new_sx_stateful_db_attributes_t_p()
    attr_p.entry_not_found_sem_unlock_failure = sem_unlock_fail
    attr_p.max_sem_retries = max_sem_retries
    attr_p.force_ordering_enable = force_ordering_enable
    attr_p.ordering_register.key.gp_reg.reg_id = ordering_register_id
    rc = sx_api_stateful_db_attr_set(handle, SX_ACCESS_CMD_EDIT, attr_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB attribute set failed")
        sys.exit(rc)


def stateful_db_init(handle, sem_unlock_fail=False, max_sem_retries=1, force_ordering_enable=False, ordering_register_id=0):
    print("[+] Init stateful DB")

    init_param_p = new_sx_stateful_db_init_param_t_p()
    init_param_p.stateful_db_attr.entry_not_found_sem_unlock_failure = sem_unlock_fail
    init_param_p.stateful_db_attr.max_sem_retries = max_sem_retries
    init_param_p.stateful_db_attr.force_ordering_enable = force_ordering_enable
    init_param_p.stateful_db_attr.ordering_register.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    init_param_p.stateful_db_attr.ordering_register.key.gp_reg.reg_id = ordering_register_id

    rc = sx_api_stateful_db_init_set(handle, init_param_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB init set failed")
        sys.exit(rc)


def partition_info_get(handle, partition_id):
    partition_state_p = new_sx_stateful_db_partition_status_t_p()
    rc = sx_api_stateful_db_partition_get(handle, SX_ACCESS_CMD_GET, partition_id, partition_state_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition get failed")
        sys.exit(rc)
    partition_state = sx_stateful_db_partition_status_t_p_value(partition_state_p)
    return partition_state


def dump_partition_info(partition_id, partition_state):
    print("------Partition Info----------------")
    print(" Partition %d  " % partition_id)
    print(" Partition name = %s" % (partition_state.partition_cfg.partition_name))
    print(" Partition size = %d" % (partition_state.partition_cfg.max_size))
    print(" Partition warning threshold = %d. " % (partition_state.partition_cfg.warn_size))
    print(" Partition ocupancy = %d" % (partition_state.num_entries))
    print("-----------------------------------")


def partition_info_compare(partition_state, partition_size, partition_warn_threshold):
    if (partition_state.partition_cfg.max_size != partition_size):
        print("Partition size mismatch! got  = %d expected= %d" % (partition_state.partition_cfg.max_size, partition_size))
        sys.exit(1)
    if (partition_state.partition_cfg.warn_size != partition_warn_threshold):
        print("Stateful DB attribute get value mismatch! got = %d expected = %d" % (partition_state.partition_cfg.warn_size, partition_warn_threshold))
        sys.exit(1)
    print("partition info compared OK")


def partition_create(handle, partition_id, partition_size, partition_warn_threshold, name):
    partition_cfg_p = new_sx_stateful_db_partition_cfg_t_p()
    partition_cfg_p.max_size = partition_size
    partition_cfg_p.warn_size = partition_warn_threshold
    partition_cfg_p.partition_name = name
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_CREATE, partition_id, partition_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition create failed")
        sys.exit(rc)
    print(" Partition %d, size %d created" % (partition_id, partition_size))


def partition_edit(handle, partition_id, partition_size, partition_warn_threshold, name):
    partition_cfg_p = new_sx_stateful_db_partition_cfg_t_p()
    partition_cfg_p.max_size = partition_size
    partition_cfg_p.warn_size = partition_warn_threshold
    partition_cfg_p.partition_name = name
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_EDIT, partition_id, partition_cfg_p)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition edit failed")
        sys.exit(rc)
    print(" Partition %d, size %d warning %d edited" % (partition_id, partition_size, partition_warn_threshold))


def partition_destroy(handle, partition_id):
    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_DESTROY, partition_id, None)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB partition destroy failed")
        sys.exit(rc)


def stateful_db_deinit(handle):
    rc = sx_api_stateful_db_deinit_set(handle)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB Deinit failed")
        sys.exit(rc)


def dump_ordering_ports_status(handle, log_port_list):
    list_cnt = len(log_port_list)
    ret_port_config = sx_stateful_db_ordering_cfg_t()
    ret_ordering_cfg_list_p = new_sx_stateful_db_ordering_cfg_t_arr(list_cnt)
    # Configuring list of ports to check ordering for")
    port_config = sx_stateful_db_ordering_cfg_t()
    for i in range(list_cnt):
        port_config.ingress_log_port = log_port_list[i]
        port_config.force_ordering = 0
        sx_stateful_db_ordering_cfg_t_arr_setitem(ret_ordering_cfg_list_p, i, port_config)

    rc = sx_api_stateful_db_ordering_get(handle, SX_ACCESS_CMD_GET, ret_ordering_cfg_list_p, list_cnt)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB ordering failed")
        sys.exit(rc)

    print("---- Ordering per port status --")
    print("-----------------------")
    print("|  Port    | Ordering |")
    print("-----------------------")
    for i in range(0, list_cnt):
        ret_port_config = sx_stateful_db_ordering_cfg_t_arr_getitem(ret_ordering_cfg_list_p, i)
        print("| 0x%x  |  %s   |" % (ret_port_config.ingress_log_port, bool(ret_port_config.force_ordering)))
        print("-----------------------")


def gp_register_set(handle, reg_id, cmd):
    reg_cnt = 1
    reg_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(reg_cnt_p, reg_cnt)
    key = sx_register_key_t()
    key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E
    key.key.gp_reg.reg_id = reg_id
    reg_list_p = new_sx_register_key_t_arr(reg_cnt)
    sx_register_key_t_arr_setitem(reg_list_p, 0, key)
    rc = sx_api_register_set(handle, cmd,
                             reg_list_p,
                             reg_cnt_p)
    if (rc != SX_STATUS_SUCCESS):
        print("GP register set failed ")
        sys.exit(rc)
    if (cmd == SX_ACCESS_CMD_CREATE):
        print(" GP register set to %d" % (key.key.gp_reg.reg_id))
    if (cmd == SX_ACCESS_CMD_DESTROY):
        print(" GP register %d is cleared" % (key.key.gp_reg.reg_id))


def key_create(handle):

    key_p = new_sx_stateful_db_key_t_p()
    key_id_p = new_sx_stateful_db_key_id_t_p()
    acl_key = sx_stateful_db_acl_key_t()

    key_p.key_name = "Stateful DB key example"
    key_p.key_desc.acl_key_desc.acl_key_cnt = 1
    acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    acl_key.mask.ethertype = 0xffff
    sx_stateful_db_acl_key_t_arr_setitem(key_p.key_desc.acl_key_desc.acl_key_list_p, 0, acl_key)

    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_CREATE, key_p, key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_set create failed.")
        sys.exit(rc)

    key_size = key_p.key_size
    key_id = sx_stateful_db_key_id_t_p_value(key_id_p)
    print("key ID is %d, key_size is %d." % (key_id, key_p.key_size))

    return key_size, key_id


def key_destroy(handle, key_id):

    key_id_p = new_sx_stateful_db_key_id_t_p()
    sx_stateful_db_key_id_t_p_assign(key_id_p, key_id)
    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_DESTROY, None, key_id_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_set destroy failed")
        sys.exit(rc)


def key_dump(handle, key_id):
    key_p = new_sx_stateful_db_key_t_p()
    acl_key = sx_stateful_db_acl_key_t()

    rc = sx_api_stateful_db_key_get(handle, SX_ACCESS_CMD_GET, key_id, key_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_key_get failed")
        sys.exit(rc)

    print("--------- Key info ----------")
    print("Dump for key ID %d" % key_id)
    print("Key name: %s" % key_p.key_name)
    print("Key size: %d" % key_p.key_size)
    print("Key type: %d" % key_p.key_type)
    for i in range(key_p.key_desc.acl_key_desc.acl_key_cnt):
        acl_key = sx_stateful_db_acl_key_t_arr_getitem(key_p.key_desc.acl_key_desc.acl_key_list_p, i)
        print("[%d] ACL key ID %d" % (i, acl_key.key_id))
    print("------------------------------")


def entry_set(handle, key_id, partition_id, ethr, op_db, op_sem, val):
    key = sx_stateful_db_sw_access_key_t()
    key_p = new_sx_stateful_db_sw_access_key_t_p()
    data = sx_stateful_db_sw_access_data_t()
    data_p = new_sx_stateful_db_sw_access_data_t_p()
    stateful_db_acl_key = sx_stateful_db_acl_key_data_t()

    key.db_op = op_db
    key.sem_op = op_sem
    key.key_id = key_id
    key.partition_id = partition_id
    key.key_data.acl_data.key_data_list_cnt = 1
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    stateful_db_acl_key.key_value.ethertype = ethr
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 0, stateful_db_acl_key)

    if (op_db == SX_STATEFUL_DB_OP_WRITE_E):
        data.entry_data.db_entry_value = val

    sx_stateful_db_sw_access_key_t_p_assign(key_p, key)
    sx_stateful_db_sw_access_data_t_p_assign(data_p, data)

    rc = sx_api_stateful_db_entry_set(handle, SX_ACCESS_CMD_SET, key_p, data_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_entry_set failed.")
        sys.exit(rc)

    print("------ Entry set info -----------")
    print("Entry data:")
    print("Access status  [%d]" % data.db_op_status)
    print("Entry found? [%d]" % data.entry_found)
    print("Data value [ 0x%x ]" % data.entry_data.db_entry_value)
    print("---------------------------------")


def entry_meta_get(handle, key_id, partition_id, ethr):

    key = sx_stateful_db_sw_access_key_t()
    key_p = new_sx_stateful_db_sw_access_key_t_p()
    data_p = new_sx_stateful_db_sw_access_data_t_p()
    meta_p = new_sx_stateful_db_entry_meta_t_p()
    stateful_db_acl_key = sx_stateful_db_acl_key_data_t()

    key.key_id = key_id
    key.partition_id = partition_id
    key.key_data.acl_data.key_data_list_cnt = 1
    stateful_db_acl_key.key_id = FLEX_ACL_KEY_ETHERTYPE
    stateful_db_acl_key.key_value.ethertype = ethr
    sx_stateful_db_acl_key_data_t_arr_setitem(key.key_data.acl_data.key_data_list_p, 0, stateful_db_acl_key)
    sx_stateful_db_sw_access_key_t_p_assign(key_p, key)

    rc = sx_api_stateful_db_entry_meta_get(handle, SX_ACCESS_CMD_GET, key_p, data_p, meta_p)
    if (rc != SX_STATUS_SUCCESS):
        print("ERROR: SDK API sx_api_stateful_db_entry_meta_get failed.")
        sys.exit(rc)

    data = sx_stateful_db_sw_access_data_t_p_value(data_p)
    meta = sx_stateful_db_entry_meta_t_p_value(meta_p)

    print("--------- Entry info ---------------")
    print("Entry data:")
    print("  Access status [%d]" % data.db_op_status)
    print("  Entry found?[%d]" % data.entry_found)
    print("  Data value[ 0x%x ]" % data.entry_data.db_entry_value)
    print("Entry meta:")
    print("  Activity [%d]" % meta.entry_activity)
    print("  Semaphore state [%d]" % meta.entry_sem_status)
    print("  Semaphore count[%d]" % meta.entry_sem_cnt)
    print("------------------------------------")


def stateful_db_ordering_enable_disable(handle, log_port_list, reg_id, enable):
    list_cnt = len(log_port_list)
    ordering_cfg_list_p = new_sx_stateful_db_ordering_cfg_t_arr(list_cnt)
    port_config = sx_stateful_db_ordering_cfg_t()
    for i in range(list_cnt):
        port_config.ingress_log_port = log_port_list[i]
        port_config.force_ordering = enable
        sx_stateful_db_ordering_cfg_t_arr_setitem(ordering_cfg_list_p, i, port_config)

    rc = sx_api_stateful_db_ordering_set(handle, SX_ACCESS_CMD_SET, ordering_cfg_list_p, list_cnt)
    if (rc != SX_STATUS_SUCCESS):
        print("Stateful DB ordering failed ")
        sys.exit(rc)


def main():
    args = parse_args()     # Parse given arguments
    if not args.force:      # Print modification warning if user didn't provide force flag
        test_infra_common.print_modification_warning()

    print("[+] Open SDK")
    SWID = 0
    DEVICE_ID = 1
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)
    try:

        # Validate chip type for examples not supported on specific chip types
        chip_type = test_infra_common.get_chip_type(handle)
        if (chip_type < SX_CHIP_TYPE_SPECTRUM4):
            print("This example is supported only from Spectrum4 - Exiting gracefully")
            sys.exit(0)

        print("stateful DB init and configure global attributes")
        # set globbal attributes
        sem_unlock_fail = False
        max_sem_retries = 2
        force_ordering_enable = False
        ordering_register_id = 0

        stateful_db_init(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id)
        # For validation only : get attributes and compare to configured values
        expected_attr = stateful_db_attributes_get(handle)
        stateful_db_attributes_dump(expected_attr)

        print("[+] Example 1: Edit stateful Db attributes")
        # edit attributes - max semaphore retries changed from 2 to 25
        max_sem_retries = 25
        expected_attr.max_sem_retries = max_sem_retries
        stateful_db_attr_edit(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id)
        # For validation only : get attributes and compare to configured values
        conf_attr = stateful_db_attributes_get(handle)
        print(" -->  Max semaphore should be changed to 25")
        stateful_db_attributes_compare(conf_attr, expected_attr)
        stateful_db_attributes_dump(conf_attr)
        print("[+] End of Example 1")
        print("\n")

        print("[+] Example 2: Create key,partition & write entry to partition ")
        print("  [+] Create key")
        key_size, key_id = key_create(handle)
        # For validation purpose: dump created stateful key.
        key_dump(handle, key_id)
        # partition create
        print("  [+] Create partition")
        MAX_ENTRIES_IN_PARTITION = 100
        HALF_ENTRIES_IN_PARTITION = 50
        ENTRIES_WARNING_THRESHOLD = 80
        HALF_ENTRIES_WARNING_THRESHOLD = 40
        partition_id = SX_STATEFUL_DB_PARTITION_1_E
        partition_size = MAX_ENTRIES_IN_PARTITION * key_size
        partition_warn_threshold = ENTRIES_WARNING_THRESHOLD * key_size
        name = "Example Partition"
        partition_create(handle, partition_id, partition_size, partition_warn_threshold, name)
        # For validation purpose
        partition_info = sx_stateful_db_partition_status_t()
        partition_info = partition_info_get(handle, partition_id)
        dump_partition_info(partition_id, partition_info)

        # For validation purpose: query non exist entry.
        EXAMPLE_ETHR_TYPE = 0x88cc
        EXAMPLE_ENTRY_VAL = 23
        print("  [+] For validation purpose querry non existing entry")
        entry_meta_get(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE)
        print("  [+] Write new entry to stateful DB")
        entry_set(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_SEM_NOP_E, EXAMPLE_ENTRY_VAL)
        print("  [+] Read new entry from stateful DB")
        entry_set(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_SEM_NOP_E, 0)
        print(" [+] For validation- data and meta data of new entry")
        entry_meta_get(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE)
        print("  [+] partition occupancy should increase by 1 ")
        partition_info = partition_info_get(handle, partition_id)
        dump_partition_info(partition_id, partition_info)

        print(" [+] Resize partition ")
        partition_size = HALF_ENTRIES_IN_PARTITION * key_size
        partition_warn_threshold = HALF_ENTRIES_WARNING_THRESHOLD * key_size
        partition_edit(handle, partition_id, partition_size, partition_warn_threshold, name)
        # For validation purposes
        partition_info = partition_info_get(handle, partition_id)
        dump_partition_info(partition_id, partition_info)

        # Remove entry from stateful DB.
        entry_set(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE, SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E, SX_STATEFUL_DB_SEM_NOP_E, 0)
        # For validation purpose: dump data and meta data of removed entry */
        entry_meta_get(handle, key_id, partition_id, EXAMPLE_ETHR_TYPE)

        partition_destroy(handle, partition_id)
        key_destroy(handle, key_id)
        print("[+] End of Example 2")
        print("\n")

        print("[+] Example 3: Ordering configuration")
        reg_id = SX_GP_REGISTER_2_E
        ordering_register_id = reg_id
        ports_num = 3

        print(" Ordering Enable Flow:")
        print("  [1] Allocate GP register 2  ")
        cmd = SX_ACCESS_CMD_CREATE
        gp_register_set(handle, reg_id, cmd)

        print("  [2] Edit globbal attributes to enable ordering and set GP resgiter as ordering register")
        force_ordering_enable = True
        stateful_db_attr_edit(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id)
        # For validation only : get attributes and compare to configured values
        print(" -->  Ordering should be enabled")
        print(" -->  Ordering register should be 2")
        conf_attr = stateful_db_attributes_get(handle)
        stateful_db_attributes_dump(conf_attr)

        print("  [3] Enable ordering per port")
        log_ports = []
        log_ports_cnt = 3
        log_ports = get_ports(handle, log_ports_cnt)
        enable = True
        stateful_db_ordering_enable_disable(handle, log_ports, reg_id, enable)
        # For valisation only: dump ordering for ports
        dump_ordering_ports_status(handle, log_ports)
        print("\n")

        print("Disable Ordering Flow:")
        print("  [1] Disable ordering per port")
        enable = False
        stateful_db_ordering_enable_disable(handle, log_ports, reg_id, enable)
        # For validation purpose : dump ordering for ports
        dump_ordering_ports_status(handle, log_ports)

        print("  [2] Edit globbal attributes to disable ordering ")
        force_ordering_enable = False
        stateful_db_attr_edit(handle, sem_unlock_fail, max_sem_retries, force_ordering_enable, ordering_register_id)
        print(" -->  Force ordering should be disabled")
        conf_attr = stateful_db_attributes_get(handle)
        stateful_db_attributes_dump(conf_attr)

        print("  [3] Deallocate GP register 2  ")
        cmd = SX_ACCESS_CMD_DESTROY
        gp_register_set(handle, reg_id, cmd)

        print("[+] End of Example 3")

        print("[+] Deinit stateful DB ")
        stateful_db_deinit(handle)

    finally:
        print("[+] Close SDK ")
        sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    sys.exit(main())
