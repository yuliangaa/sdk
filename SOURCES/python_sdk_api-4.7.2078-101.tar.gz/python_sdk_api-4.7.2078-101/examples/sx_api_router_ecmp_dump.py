#!/usr/bin/env python
'''
This file contains Python command example for the ROUTER ECMP READ module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''

import sys
import errno
from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
from flex_acl_common import router_module_verbosity_level_get, router_module_verbosity_level_set

ecmp_type_dict = {0: 'STATIC', 1: 'RESILIENT', 2: 'CONSISTENT', 3: 'DYNAMIC', 4: 'ADAPTIVE', 5: 'ORDERED'}
container_type_dict = {0: 'IP', 1: 'MPLS', 2: 'NVE FLOOD', 3: 'NVE MC'}
prio_dict = {0: 'Best Effort', 1: 'Low', 2: 'Medium', 3: 'High', 4: 'Critical'}
next_hop_type_dict = {1: 'IP', 2: 'Tunnel Encap', 3: 'MC Container', 4: 'MPLS'}
action_dict = {0: 'Drop', 1: 'Trap', 2: 'Forward', 3: 'Mirror', 4: 'Trap Forward', 5: 'Span'}

print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

ecmp_cnt = 0
ecmp_cnt_p = new_uint32_t_p()
uint32_t_p_assign(ecmp_cnt_p, 0)

# The following is used to prevent error messages if the router is not initialized
module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)

rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET, 0, None, None, ecmp_cnt_p)
router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
if rc == SX_STATUS_MODULE_UNINITIALIZED:
    print("The ECMP module is not initialized. Dump is not available.")
elif rc != SX_STATUS_SUCCESS:
    print("sx_api_router_ecmp_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
else:
    ecmp_cnt = uint32_t_p_value(ecmp_cnt_p)
    ecmp_list_p = new_sx_ecmp_id_t_arr(ecmp_cnt)
    rc = sx_api_router_ecmp_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, ecmp_list_p, ecmp_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_router_ecmp_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    ecmp_cnt = uint32_t_p_value(ecmp_cnt_p)
    header_printed = False

    for i in range(0, ecmp_cnt):
        if not header_printed:
            print("======================================================================================================================================================================================================================================")
            print("|%8s|%11s|%15s|%8s|%5s|%13s|%5s|%10s|%9s|%40s|%13s|%11s|%12s|%10s|%10s|%10s|%10s|%10s|" % ("ECMP ID", "ECMP Type", "Container Type", "Ref Cnt", "NH Idx", "Type", "RIF", "Tunnel ID", "Relookup",
                                                                                                              "IP", "Action", "Counter ID", "Attr Prio", "Weight", "Label Num", "Label1", "Label2", "Label3"))
            print("|%8s|%11s|%15s|%8s|%6s|%13s|%5s|%10s|%9s|%40s|%13s|%11s|%12s|%10s|%10s|%10s|%10s|%10s|" % ("", "", "", "", "", "", "", "", "ECMP/VRID", "", "", "", "", "", "", "", "", ""))
            print("======================================================================================================================================================================================================================================")
            header_printed = True

        ecmp_id = sx_ecmp_id_t_arr_getitem(ecmp_list_p, i)
        ecmp_attr_p = new_sx_ecmp_attributes_t_p()
        rc = sx_api_router_ecmp_attributes_get(handle, ecmp_id, ecmp_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_ecmp_attributes_get failed, rc = %d" % (rc))
            sys.exit(rc)
        ecmp_attr = sx_ecmp_attributes_t_p_value(ecmp_attr_p)

        object_id = sx_object_id_t()
        object_id.object_type = SX_OBJECT_TYPE_ECMP
        object_id.object_id.ecmp_id = ecmp_id
        refcount_p = new_uint32_t_p()
        object_id_p = new_sx_object_id_t_p()
        sx_object_id_t_p_assign(object_id_p, object_id)
        rc = sx_api_object_refcount_get(handle, object_id_p, refcount_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_object_refcount_get failed, rc = %d" % (rc))
            sys.exit(rc)
        refcount = uint32_t_p_value(refcount_p)

        sys.stdout.write("|%8d %11s %15s %8d|" % (ecmp_id, ecmp_type_dict[ecmp_attr.ecmp_type], container_type_dict[ecmp_attr.container_type], refcount))

        next_hop_cnt_p = new_uint32_t_p()
        uint32_t_p_assign(next_hop_cnt_p, 0)
        rc = sx_api_router_ecmp_get(handle, ecmp_id, None, next_hop_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_ecmp_get failed, rc = %d" % (rc))
            sys.exit(rc)
        next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)

        next_hop_list_p = new_sx_next_hop_t_arr(next_hop_cnt)
        rc = sx_api_router_ecmp_get(handle, ecmp_id, next_hop_list_p, next_hop_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_ecmp_get failed, rc = %d" % (rc))
            sys.exit(rc)
        next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)

        if next_hop_cnt == 0:
            print("%5s|%13s|%5s|%10s|%9s|%40s|%13s|%11s|%12s|%10s|%10s|%10s|%10s|%10s|" % ("", "", "", "", "", "", "", "", "", "", "", "", "", ""))
            print("======================================================================================================================================================================================================================================")
        else:
            for j in range(0, next_hop_cnt):
                next_hop = sx_next_hop_t_arr_getitem(next_hop_list_p, j)
                next_hop_index_str = "%d" % (j)
                if next_hop.next_hop_key.type != SX_NEXT_HOP_TYPE_RELOOKUP:
                    next_hop_type_str = next_hop_type_dict[next_hop.next_hop_key.type]
                else:
                    if next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_ECMP_E:
                        next_hop_type_str = "ECMP Relookup"
                    elif next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_LPM_E:
                        next_hop_type_str = "LPM Relookup"
                next_hop_rif_str = ""
                next_hop_tunnel_id_str = ""
                next_hop_relookup_id_str = ""
                ip_str = ""
                action_str = action_dict[next_hop.next_hop_data.action]
                counter_id_str = "%d" % (next_hop.next_hop_data.counter_id)
                attr_prio_str = prio_dict[next_hop.next_hop_data.trap_attr.prio]
                weight_str = "%d" % (next_hop.next_hop_data.weight)
                label_num_str = ""
                label1_str = ""
                label2_str = ""
                label3_str = ""

                if next_hop.next_hop_key.type == SX_NEXT_HOP_TYPE_TUNNEL_ENCAP:
                    ip_tunnel = next_hop.next_hop_key.next_hop_key_entry.ip_tunnel
                    next_hop_tunnel_id_str = "0x%x" % (ip_tunnel.tunnel_id)
                    ip_str = ip_addr_to_str(ip_tunnel.underlay_dip)
                elif next_hop.next_hop_key.type == SX_NEXT_HOP_TYPE_RELOOKUP:
                    if next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_ECMP_E:
                        next_hop_relookup_id_str = "%d" % (next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_data.ecmp_container)
                    elif next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_type == SX_NEXT_HOP_RELOOKUP_LPM_E:
                        next_hop_relookup_id_str = "%d" % (next_hop.next_hop_key.next_hop_key_entry.relookup_next_hop.relookup_data.vrid)
                else:
                    ip_next_hop = None
                    if next_hop.next_hop_key.type == SX_NEXT_HOP_TYPE_IP:
                        ip_next_hop = next_hop.next_hop_key.next_hop_key_entry.ip_next_hop
                    elif next_hop.next_hop_key.type == SX_NEXT_HOP_TYPE_MPLS:
                        if next_hop.next_hop_key.next_hop_key_entry.mpls_next_hop.type == SX_MPLS_IP_NEXT_HOP_TYPE:
                            ip_next_hop = next_hop.next_hop_key.next_hop_key_entry.mpls_next_hop.mpls_next_hop_entry.ip_next_hop_data.ip_next_hop

                        label_num = next_hop.next_hop_key.next_hop_key_entry.mpls_next_hop.label_cnt
                        label_num_str = "%d" % (label_num)
                        k = 0

                        labels = []
                        while (k < label_num and k < SX_NEXT_HOP_TYPE_MPLS):
                            labels.append(sx_mpls_label_stack_entry_t_arr_getitem(next_hop.next_hop_key.next_hop_key_entry.mpls_next_hop.label_list, k))
                            k = k + 1

                        if len(labels) > 0:
                            label1_str = "%d" % (labels[0].label)
                        if len(labels) > 1:
                            label2_str = "%d" % (labels[1].label)
                        if len(labels) > 2:
                            label3_str = "%d" % (labels[2].label)

                    if ip_next_hop is not None:
                        next_hop_rif_str = "%d" % (ip_next_hop.rif)
                        ip_str = ip_addr_to_str(ip_next_hop.address)

                if j == 0:
                    print("%5s|%13s|%5s|%10s|%9s|%40s|%13s|%11s|%12s|%10s|%10s|%10s|%10s|%10s|" % (next_hop_index_str, next_hop_type_str, next_hop_rif_str, next_hop_tunnel_id_str, next_hop_relookup_id_str,
                                                                                                   ip_str, action_str, counter_id_str, attr_prio_str, weight_str, label_num_str,
                                                                                                   label1_str, label2_str, label3_str))
                else:
                    print("|%45s|%6s|%13s|%5s|%10s|%9s|%40s|%13s|%11s|%12s|%10s|%10s|%10s|%10s|%10s|" % ("", next_hop_index_str, next_hop_type_str, next_hop_rif_str, next_hop_tunnel_id_str, next_hop_relookup_id_str,
                                                                                                         ip_str, action_str, counter_id_str, attr_prio_str, weight_str, label_num_str,
                                                                                                         label1_str, label2_str, label3_str))

                if j == (next_hop_cnt - 1):
                    print("======================================================================================================================================================================================================================================")
                else:
                    print("|%45s|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" % (""))

sx_api_close(handle)
