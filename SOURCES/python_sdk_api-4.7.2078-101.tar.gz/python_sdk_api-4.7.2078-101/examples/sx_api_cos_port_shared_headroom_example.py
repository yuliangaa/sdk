#!/usr/bin/env python
'''
This file contains Python command example for the COS module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below creates a complete Port shared headroom configuration for a given port.
'''
import sys
import errno
import sys
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse


def cos_pg_buff_set(handle, log_port, pg, lossy, size, xon=0, xoff=0, use_shared_headroom=0):
    port_buffer_attr_cnt = 1
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(1)

    attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, 0)

    attr_item_min.type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
    attr_item_min.attr.ingress_port_pg_buff_attr.pg = pg
    attr_item_min.attr.ingress_port_pg_buff_attr.pool_id = 0
    attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy = lossy
    attr_item_min.attr.ingress_port_pg_buff_attr.xon = xon
    attr_item_min.attr.ingress_port_pg_buff_attr.xoff = xoff
    attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom = use_shared_headroom
    attr_item_min.attr.ingress_port_pg_buff_attr.size = size

    print("\nSetting Port PG:")
    print("type  = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E")
    print(("size  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.size)))
    print(("PG    = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.pg)))
    print(("is_lossy (0=Lossless)  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.is_lossy)))
    print(("Xon  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.xon)))
    print(("Xoff  = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.xoff)))
    print(("use_shared_headroom = %d" % (attr_item_min.attr.ingress_port_pg_buff_attr.use_shared_headroom)))

    attr_item_min = sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, attr_item_min)

    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, port_buffer_attr_list_p, 1)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, log_port, 1, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def cos_port_shared_headroom_set(handle, log_port, shp_id, size, max_pool_loan, xon=0, xoff=0):
    port_buffer_attr_cnt = 1
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(1)

    attr_item_min = sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, 0)

    attr_item_min.type = SX_COS_PORT_SHARED_HEADROOM_E
    attr_item_min.attr.port_shared_headroom_attr.max_pool_loan = max_pool_loan
    attr_item_min.attr.port_shared_headroom_attr.shared_pool_id = shp_id
    attr_item_min.attr.port_shared_headroom_attr.xon = xon
    attr_item_min.attr.port_shared_headroom_attr.xoff = xoff
    attr_item_min.attr.port_shared_headroom_attr.size = size

    print("\ntype  = SX_COS_PORT_SHARED_HEADROOM_E")
    print(("size  = %d" % (attr_item_min.attr.port_shared_headroom_attr.size)))
    print(("Xon  = %d" % (attr_item_min.attr.port_shared_headroom_attr.xon)))
    print(("Xoff  = %d" % (attr_item_min.attr.port_shared_headroom_attr.xoff)))
    print(("SHP  = %d" % (attr_item_min.attr.port_shared_headroom_attr.shared_pool_id)))
    print(("Max pool loan = %d" % (attr_item_min.attr.port_shared_headroom_attr.max_pool_loan)))

    attr_item_min = sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, attr_item_min)

    rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, port_buffer_attr_list_p, 1)
    print(("sx_api_cos_port_buff_type_set [cmd=%d, log_port=0x%x , cnt=%d, rc=%d] " % (SX_ACCESS_CMD_SET, log_port, 1, rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def create_shared_headroom_pool(handle, size):
    pool_attr = sx_cos_pool_attr_t()
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    pool_id_p = new_uint32_t_p()

    pool_attr.pool_dir = SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E
    pool_attr.pool_size = size
    pool_attr.mode = SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E
    pool_attr.buffer_type = SX_COS_SHARED_HEADROOM_BUFFER_E
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_CREATE, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)

    shared_headroom_pool_id = uint32_t_p_value(pool_id_p)
    print(("\nSet Shared headroom Pool ID = %d Size %d" % (shared_headroom_pool_id, size)))
    return shared_headroom_pool_id


def destroy_shared_headroom_pool(handle, pool_id):
    pool_attr = sx_cos_pool_attr_t()
    pool_attr_p = new_sx_cos_pool_attr_t_p()
    pool_id_p = new_uint32_t_p()

    pool_attr.pool_dir = 0
    pool_attr.pool_size = 0
    pool_attr.mode = 0
    pool_attr.buffer_type = 0
    sx_cos_pool_attr_t_p_assign(pool_attr_p, pool_attr)
    uint32_t_p_assign(pool_id_p, pool_id)
    rc = sx_api_cos_shared_buff_pool_set(handle, SX_ACCESS_CMD_DESTROY, pool_attr_p, pool_id_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_cos_shared_buff_pool_set failed, rc = %d\n" % (rc)


def cos_port_shared_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_shared_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_shared_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    return port_sb_attr_list, port_sb_attr_cnt


def cos_port_buff_get_all(handle, log_port):
    port_sb_attr_cnt_p = new_uint32_t_p()

    rc = sx_api_cos_port_buff_type_get(handle, log_port, None, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)

    port_sb_attr_cnt = uint32_t_p_value(port_sb_attr_cnt_p)
    port_sb_attr_list = new_sx_cos_port_buffer_attr_t_arr(port_sb_attr_cnt)

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_sb_attr_list, port_sb_attr_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_cos_port_buff_type_get failed rc = %d " % (rc))
        sys.exit(rc)
    assert(port_sb_attr_cnt == uint32_t_p_value(port_sb_attr_cnt_p))
    return port_sb_attr_list, port_sb_attr_cnt


######################################################
#    main
######################################################


def main():

    parser = argparse.ArgumentParser(description='SX-API sx_api_cos_port_shared_headroom_example')
    parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Log port')
    parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
    parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
    args = parser.parse_args()

    log_port = args.log_port

    print_api_example_disclaimer()
    if not args.force:
        print_modification_warning()

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Save for later de-configuration
    original_port_buff_attr_list, original_port_buff_attr_cnt = cos_port_buff_get_all(handle, log_port)
    original_port_sb_attr_list, original_port_sb_attr_cnt = cos_port_shared_buff_get_all(handle, log_port)

    PG = 3
    PG_SIZE = 200
    PG_XON = 100
    PG_XOFF = 100
    PG_USE_SBP = 1
    LOSSY = 1
    LOSSLESS = 0
    PSB_SIZE = 8
    PSB_XOFF = 2000
    PSB_XON = 2000
    MAX_POOL_LOAN = 1000
    SHP_SIZE = 3000

    # Create global shared headroom pool (SHP):
    shp_id = create_shared_headroom_pool(handle, SHP_SIZE)

    # Set Port shared buffer
    cos_port_shared_headroom_set(handle, log_port, shp_id, PSB_SIZE, MAX_POOL_LOAN, PSB_XON, PSB_XOFF)

    # Set port PG to use the port shared headroom
    cos_pg_buff_set(handle, log_port, PG, LOSSLESS, PG_SIZE, PG_XON, PG_XOFF, PG_USE_SBP)

    if args.deinit:
        print("Deinit")
        rc = sx_api_cos_port_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_buff_attr_list, original_port_buff_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_buff_type_set failed rc = %d" % (rc))
            sys.exit(rc)

        rc = sx_api_cos_port_shared_buff_type_set(handle, SX_ACCESS_CMD_SET, log_port, original_port_sb_attr_list,
                                                  original_port_sb_attr_cnt)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_cos_port_shared_buff_type_set failed rc = %d" % (rc))
            sys.exit(rc)

        destroy_shared_headroom_pool(handle, shp_id)


if __name__ == "__main__":
    main()
