#!/usr/bin/env python
'''
This file contains Python command example for setting and reading atcam counters.
It can be used as a debugging utility for reading the atcam & erp counters.
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse
import time

######################################################
#    defines
######################################################
dump_format_to_enum_dict = {
    'all': SX_DBG_DUMP_FORMAT_ALL_E,
    'plain_text': SX_DBG_DUMP_FORMAT_PLAIN_TEXT_E,
    'json': SX_DBG_DUMP_FORMAT_JSON_E
}

dump_modules_dict = {
    'default': SX_DBG_DUMP_MODULE_DEFAULT_E,
    'all': SX_DBG_DUMP_MODULE_ALL_E,
    'init_params': SX_DBG_DUMP_MODULE_INIT_PARAMS_E,
    'issu': SX_DBG_DUMP_MODULE_ISSU_E,
    'xm': SX_DBG_DUMP_MODULE_XM_E,
    'rm': SX_DBG_DUMP_MODULE_RM_E,
    'gc': SX_DBG_DUMP_MODULE_GC_E,
    'cos_sb': SX_DBG_DUMP_MODULE_COS_SB_E,
    'fid_manager': SX_DBG_DUMP_MODULE_FID_MANAGER_E,
    'bridge': SX_DBG_DUMP_MODULE_BRIDGE_E,
    'port': SX_DBG_DUMP_MODULE_PORT_E,
    'fdb': SX_DBG_DUMP_MODULE_FDB_E,
    'cos': SX_DBG_DUMP_MODULE_COS_E,
    'policer': SX_DBG_DUMP_MODULE_POLICER_E,
    'vlan': SX_DBG_DUMP_MODULE_VLAN_E,
    'mstp': SX_DBG_DUMP_MODULE_MSTP_E,
    'lag': SX_DBG_DUMP_MODULE_LAG_E,
    'kvd_linear': SX_DBG_DUMP_MODULE_KVD_LINEAR_E,
    'pgt_linear': SX_DBG_DUMP_MODULE_PGT_LINEAR_E,
    'span': SX_DBG_DUMP_MODULE_SPAN_E,
    'red_ecn': SX_DBG_DUMP_MODULE_RED_ECN_E,
    'bin_allocator': SX_DBG_DUMP_MODULE_BIN_ALLOCATOR_E,
    'tunnel': SX_DBG_DUMP_MODULE_TUNNEL_E,
    'sniffer': SX_DBG_DUMP_MODULE_SNIFFER_E,
    'refcount': SX_DBG_DUMP_MODULE_REFCOUNT_E,
    'flex_acl': SX_DBG_DUMP_MODULE_FLEX_ACL_E,
    'mpe': SX_DBG_DUMP_MODULE_MPE_E,
    'mc': SX_DBG_DUMP_MODULE_MC_E,
    'router': SX_DBG_DUMP_MODULE_ROUTER_E,
    'mpls': SX_DBG_DUMP_MODULE_MPLS_E,
    'host_ifc': SX_DBG_DUMP_MODULE_HOST_IFC_E,
    'tele': SX_DBG_DUMP_MODULE_TELE_E,
    'register': SX_DBG_DUMP_MODULE_REGISTER_E,
    'flex_parser': SX_DBG_DUMP_MODULE_FLEX_PARSER_E,
    'bfd': SX_DBG_DUMP_MODULE_BFD_E,
    'async_core': SX_DBG_DUMP_MODULE_ASYNC_CORE_E,
    'reg_bulk': SX_DBG_DUMP_MODULE_REG_BULK_E,
    'driver': SX_DBG_DUMP_MODULE_DRIVER_E,
    'atcam': SX_DBG_DUMP_MODULE_ATCAM_E,
    'memory': SX_DBG_DUMP_MODULE_MEMORY_E,
    'mgmt_lib': SX_DBG_DUMP_MODULE_MGMT_LIB_E,
    'flex_modifier': SX_DBG_DUMP_MODULE_FLEX_MODIFIER_E,
    'flow_counter': SX_DBG_DUMP_MODULE_FLOW_COUNTER_E,
    'cl_pool': SX_DBG_DUMP_MODULE_CL_POOL_DB_E,
    'td_drop_counter': SX_DBG_DUMP_MODULE_TD_DROP_COUNTERS_E,
    'port_profile': SX_DBG_DUMP_MODULE_PORT_PROFILE_E,
    'macsec': SX_DBG_DUMP_MODULE_MACSEC_E,
    'flex_pm': SX_DBG_DUMP_MODULE_FLEX_PM_E,
    'stateful_db': SX_DBG_DUMP_MODULE_STATEFUL_DB_E,
    'cff': SX_DBG_DUMP_MODULE_CFF_E,
    'truncation_profile': SX_DBG_DUMP_MODULE_TRUNCATION_PROFILE_E,
}

parser = argparse.ArgumentParser(description='generate a debug dump',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--dump_format', default='all', choices=list(dump_format_to_enum_dict.keys()), help='The dump format')
parser.add_argument('--plain_text_path', default=None, help='The plain text dump file path')
parser.add_argument('--json_path', default=None, help='The json dump file path')
parser.add_argument('--modules_list', default=[], nargs='+', choices=list(dump_modules_dict.keys()), help='Dump only modules on the list')
args = parser.parse_args()


def main():

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    dump_info_p = new_sx_dbg_dump_info_t_p()
    dump_info_p.dump_format = dump_format_to_enum_dict[args.dump_format]
    dump_info_p.hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    dump_info_p.text_info.path = args.plain_text_path
    dump_info_p.json_info.path = args.json_path
    for module in args.modules_list:
        # Preserve unsigned long int value by using bitwise and
        dump_info_p.modules_select += dump_modules_dict[module]

    start_time = time.time()
    rc = sx_api_dbg_dump(handle, dump_info_p)
    time_to_generate_dump = time.time() - start_time
    print("sx_api_dbg_dump took {:.2f} seconds".format(time_to_generate_dump))
    delete_sx_dbg_dump_info_t_p(dump_info_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_dbg_dump failed, err: {0}".format(rc)

    print("Success.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
