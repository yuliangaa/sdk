#!/usr/bin/env python
'''
This file contains Python command example for the VxLAN Tunnel Dump module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''


ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

import sys
import errno
import os

from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
######################################################
#    Local Data Structures
######################################################

tunnel_type_dict =\
    {
        'vxlan': SX_TUNNEL_TYPE_NVE_VXLAN,
        'vxlan_gpe': SX_TUNNEL_TYPE_NVE_VXLAN_GPE,
        'geneve': SX_TUNNEL_TYPE_NVE_GENEVE,
        'nvgre': SX_TUNNEL_TYPE_NVE_NVGRE,
        'vxlan_ipv6': SX_TUNNEL_TYPE_NVE_VXLAN_IPV6,
        'nvgre_ipv6': SX_TUNNEL_TYPE_NVE_NVGRE_IPV6,
        'ipinip': SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4,
        'ipingre': SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE,
        'ipv6inip': SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4,
        'ipv6inipgre': SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE,
        'ipinipv6': SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6,
        'ipinipv6gre': SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE,
        'ipv6inipv6': SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6,
        'ipv6ingre': SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE,
    }


######################################################
#    Local Functions
######################################################


def router_init(handle):
    " This function init the router with following values. "
    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    if not rc == SX_STATUS_ALREADY_INITIALIZED:
        assert SX_STATUS_SUCCESS == rc, "Failed to init router, rc: %d" % (rc)

    return rc


def router_deinit(handle):
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


def tunnel_init(handle):

    general_params = sx_tunnel_general_params_t()

    general_params.nve.encap_sport = 0
    general_params.nve.encap_flowlabel = 0
    general_params.nve.flood_ecmp_enabled = False

    general_params.ipinip.encap_flowlabel = 0
    general_params.ipinip.encap_gre_hash = 0

    general_param_p = new_sx_tunnel_general_params_t_p()
    sx_tunnel_general_params_t_p_assign(general_param_p, general_params)
    rc = sx_api_tunnel_init_set(handle, general_param_p)
    if not rc == SX_STATUS_ALREADY_INITIALIZED:
        assert SX_STATUS_SUCCESS == rc, "Failed to init tunnel, rc: %d" % (rc)

    return rc


def tunnel_deinit(handle):
    " This function deinit the tunnel. "

    rc = sx_api_tunnel_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit tunnel"
    print("Deinit tunnel, rc: %d" % (rc))


def tunnel_id_iter_get_all(handle):
    ret_tunnel_id_list = []
    tunnel_id_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(tunnel_id_cnt_p, 0)
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if tunnel module is initialized.
            print("####################################")
            print("# Tunnel Module is not initialized ")
            print("####################################")
            sys.exit(0)
        print("Tunnel Iterator failed with rc (%d)" % (rc))
        sys.exit(rc)

    tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)
    tunnel_id_list_p = new_sx_tunnel_id_t_arr(tunnel_id_cnt)
    # we can have max of 4K tunnels (due to 4k RIFs on spc2/3). So we should get all ids in one call
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p, tunnel_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_tunnel_iter_get failed for VxLAN, rc = %d" % (rc))
        sys.exit(rc)
    tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)

    for i in range(tunnel_id_cnt):
        tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p, i)
        ret_tunnel_id_list.append(tunnel_id)

    return ret_tunnel_id_list, len(ret_tunnel_id_list)


def tunnel_id_iter_get_by_type(handle, type):
    ret_tunnel_id_list = []
    tunnel_id_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(tunnel_id_cnt_p, 0)
    filter_p = new_sx_tunnel_filter_t_p()
    filter_p.filter_by_type = SX_TUNNEL_KEY_FILTER_FIELD_VALID
    filter_p.type = type
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET, 0, filter_p, None, tunnel_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        if rc == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if tunnel module is initialized.
            print("####################################")
            print("# Tunnel Module is not initialized ")
            print("####################################")
            sys.exit(0)
        print("Tunnel Iterator failed with rc (%d)" % (rc))
        sys.exit(rc)

    tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)
    tunnel_id_list_p = new_sx_tunnel_id_t_arr(tunnel_id_cnt)
    rc = sx_api_tunnel_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, filter_p, tunnel_id_list_p, tunnel_id_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_tunnel_iter_get failed for VxLAN, rc = %d" % (rc))
        sys.exit(rc)
    tunnel_id_cnt = uint32_t_p_value(tunnel_id_cnt_p)

    for i in range(tunnel_id_cnt):
        tunnel_id = sx_tunnel_id_t_arr_getitem(tunnel_id_list_p, i)
        ret_tunnel_id_list.append(tunnel_id)

    delete_uint32_t_p(tunnel_id_cnt_p)
    delete_sx_tunnel_filter_t_p(filter_p)

    return ret_tunnel_id_list, len(ret_tunnel_id_list)


def tunnel_decap_rules_action_get(handle, decap_key):

    decap_key_p = copy_sx_tunnel_decap_entry_key_t_p(decap_key)
    decap_data = sx_tunnel_decap_entry_data_t()
    decap_data_p = new_sx_tunnel_decap_entry_data_t_p()

    rc = sx_api_tunnel_decap_rules_get(handle, decap_key_p, decap_data_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_decap_rules_get failed Rc={}".format(rc)

    decap_data = sx_tunnel_decap_entry_data_t_p_value(decap_data_p)

    delete_sx_tunnel_decap_entry_key_t_p(decap_key_p)
    delete_sx_tunnel_decap_entry_data_t_p(decap_data_p)

    return decap_data


def tunnel_decap_rules_key_iter_get(handle, cmd, count, tunnel_type=None,
                                    decap_key_type=None, ulay_vrid=None,
                                    ulay_sip=None, ulay_dip=None,
                                    filter_tunnel_id=None,
                                    filter_tunnel_type=None, ulay_sip_mask=None, ulay_dip_mask=None, priority=None):

    decap_rule_list_p = None
    filter = sx_tunnel_decap_entry_filter_t()
    filter_p = new_sx_tunnel_decap_entry_filter_t_p()
    decap_rule_key_p = None
    rule_cnt_p = copy_uint32_t_p(count)
    decap_entry_key_fields = ['tunnel_type', 'type', 'underlay_vrid', 'underlay_sip', 'underlay_sip_mask', 'underlay_dip', 'underlay_dip_mask', 'priority']

    if (cmd == SX_ACCESS_CMD_GET_FIRST):
        decap_rule_list_p = new_sx_tunnel_decap_entry_key_t_arr(count)

    elif ((cmd == SX_ACCESS_CMD_GETNEXT)
          or ((cmd == SX_ACCESS_CMD_GET) and (count != 0))):
        decap_rule_key = sx_tunnel_decap_entry_key_t()
        decap_rule_key.tunnel_type = tunnel_type
        decap_rule_key.type = decap_key_type
        decap_rule_key.underlay_vrid = ulay_vrid
        decap_rule_key.underlay_sip = ulay_sip
        decap_rule_key.underlay_sip_mask = ulay_sip_mask
        decap_rule_key.underlay_dip = ulay_dip
        decap_rule_key.underlay_dip_mask = ulay_dip_mask
        decap_rule_key.priority = priority

        decap_rule_key_p = copy_sx_tunnel_decap_entry_key_t_p(decap_rule_key)
        decap_rule_list_p = new_sx_tunnel_decap_entry_key_t_arr(count)

    if filter_tunnel_id is not None:
        filter.filter_by_tunnel_id = True
        filter.tunnel_id = filter_tunnel_id
    else:
        filter.filter_by_tunnel_id = False

    if filter_tunnel_type is not None:
        filter.filter_by_tunnel_type = True
        filter.tunnel_type = filter_tunnel_type
    else:
        filter.filter_by_tunnel_type = False
    sx_tunnel_decap_entry_filter_t_p_assign(filter_p, filter)

    rc = sx_api_tunnel_decap_rule_iter_get(handle, cmd, decap_rule_key_p, filter_p,
                                           decap_rule_list_p, rule_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to get total number of decap rules"

    sdk_count = uint32_t_p_value(rule_cnt_p)
    if ((count == 0) or (sdk_count == 0)):
        return sdk_count, {}

    ret_rule_dict_list = []
    for i in range(sdk_count):
        decap_entry_key_values = {}
        decap_rule_key = sx_tunnel_decap_entry_key_t_arr_getitem(decap_rule_list_p, i)
        decap_entry_key_values['tunnel_type'] = decap_rule_key.tunnel_type
        decap_entry_key_values['type'] = decap_rule_key.type
        decap_entry_key_values['underlay_vrid'] = decap_rule_key.underlay_vrid
        decap_entry_key_values['underlay_sip'] = ip_addr_to_str(decap_rule_key.underlay_sip)
        decap_entry_key_values['underlay_sip_mask'] = ip_addr_to_str(decap_rule_key.underlay_sip_mask)
        decap_entry_key_values['underlay_dip'] = ip_addr_to_str(decap_rule_key.underlay_dip)
        decap_entry_key_values['underlay_dip_mask'] = ip_addr_to_str(decap_rule_key.underlay_dip_mask)
        decap_entry_key_values['priority'] = decap_rule_key.priority
        ret_rule_dict_list.insert(i, dict(decap_entry_key_values))

    if decap_rule_list_p is not None:
        delete_sx_tunnel_decap_entry_key_t_arr(decap_rule_list_p)
    if filter_p is not None:
        delete_sx_tunnel_decap_entry_filter_t_p(filter_p)
    if decap_rule_key_p is not None:
        delete_sx_tunnel_decap_entry_key_t_p(decap_rule_key_p)
    delete_uint32_t_p(rule_cnt_p)

    return sdk_count, ret_rule_dict_list


def tunnel_decap_rule_print(key, data):
    print("{:20s}:{}".format("Tunnel Id", hex(data.tunnel_id)))
    print("{:20s}:{}".format("Tunnel Type", tunnel_type_str_dict[key.tunnel_type]))
    print("{:20s}:{}".format("Key Type", tnl_decap_rule_key_type_str_dict[key.type]))
    print("{:20s}:{}".format("Underlay VRID", key.underlay_vrid))
    print("{:20s}:{}".format("Underlay SIP", ip_addr_to_str(key.underlay_sip)))
    if key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET:
        print("{:20s}:{}".format("Underlay SIP mask", ip_addr_to_str(key.underlay_sip_mask)))
    print("{:20s}:{}".format("Underlay DIP", ip_addr_to_str(key.underlay_dip)))
    if key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET:
        print("{:20s}:{}".format("Underlay DIP mask", ip_addr_to_str(key.underlay_dip_mask)))
        print("{:20s}:{}".format("Priority", key.priority))
    print("{:20s}:{}\n".format("Action", router_action_str_dict[data.action]), end="")
    print("{:20s}:{}\n".format("Counter Id", data.counter_id), end="")
    print("{:20s}:{}\n".format("Span Session Id", data.span_session_id), end="")
    print("{:20s}:{}\n".format("Trap Attr.Prio", trap_attr_prio_str_dict[data.trap_attr.prio]), end="")
    print("{:20s}:{}\n".format("User Token Data", hex(data.user_token.user_token), end=""))
    print("{:20s}:{}\n".format("User Token Mask", hex(data.user_token.mask), end=""))
    print('-' * 64)


def getOptions(args):
    parser = argparse.ArgumentParser(description="Tunnel Decap Rules Dump utility.")

    group = parser.add_mutually_exclusive_group()
    group.add_argument('--tunnel_id', dest='tunnel_id', default=None, type=auto_int,
                       help='Optional Tunnel ID')
    group.add_argument('--tunnel_type', dest='tunnel_type', choices=list(tunnel_type_dict.keys()),
                       default=None, help='Optional Tunnel Type')
    group.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

    options = parser.parse_args()
    return options


def dump_decap_rules_all(handle, tunnel_type=None, tunnel_id=None):

    # ret_tunnel_id_list,  tunnel_id_cnt = tunnel_id_iter_get_all(handle)
    cmd = SX_ACCESS_CMD_GET
    tmp_tunnel_type = None
    if tunnel_type:
        tmp_tunnel_type = tunnel_type_dict[tunnel_type]
    total_rule_count, _ = tunnel_decap_rules_key_iter_get(handle, cmd, 0,
                                                          filter_tunnel_id=tunnel_id,
                                                          filter_tunnel_type=tmp_tunnel_type)

    if total_rule_count == 0:
        if tunnel_type is not None:
            print('No decap dules present for Tunnel Type "{}"'.format(tunnel_type))
        elif tunnel_id is not None:
            print('No decap rules present for Tunnel Id "{}"'.format(hex(tunnel_id)))
        else:
            print("No decap rules configured in system")
    else:
        print(" Got total rule count = {}".format(total_rule_count))

    cmd = SX_ACCESS_CMD_GET_FIRST
    rules_count, rule_list = tunnel_decap_rules_key_iter_get(handle, cmd, total_rule_count,
                                                             filter_tunnel_id=tunnel_id,
                                                             filter_tunnel_type=tunnel_type)
    print(" Read {} rule".format(rules_count))
    print('*' * 64)
    print(" Tunnel Decap Rules Dump")
    print('*' * 64)

    decap_rule_key = sx_tunnel_decap_entry_key_t()
    print(len(rule_list))
    for i in range(len(rule_list)):

        decap_rule_key.tunnel_type = rule_list[i]['tunnel_type']
        decap_rule_key.type = rule_list[i]['type']
        decap_rule_key.underlay_vrid = rule_list[i]['underlay_vrid']
        decap_rule_key.underlay_sip = make_sx_ip_addr(rule_list[i]['underlay_sip'])
        decap_rule_key.underlay_sip_mask = make_sx_ip_addr(rule_list[i]['underlay_sip_mask'])
        decap_rule_key.underlay_dip = make_sx_ip_addr(rule_list[i]['underlay_dip'])
        decap_rule_key.underlay_dip_mask = make_sx_ip_addr(rule_list[i]['underlay_dip_mask'])
        decap_rule_key.priority = rule_list[i]['priority']

        decap_rule_data = tunnel_decap_rules_action_get(handle, decap_rule_key)

        tunnel_decap_rule_print(decap_rule_key, decap_rule_data)


# *********************************************
#            main                            *
# *********************************************
print_api_example_disclaimer()

file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

old_stdout = redirect_stdout()
rc, handle = sx_api_open(None)
sys.stdout = os.fdopen(old_stdout, 'w')
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

# No way to check if Router and Tunnel are initialized, thus try init them anyway
router_rc = router_init(handle)
tunnel_rc = tunnel_init(handle)

options = getOptions(sys.argv)
if options.tunnel_id:
    dump_decap_rules_all(handle, tunnel_id=options.tunnel_id)
elif options.tunnel_type:
    dump_decap_rules_all(handle, tunnel_type=options.tunnel_type)
else:
    print(" No Tunnel id or Tunnel Type provided. Dumping all Configured Rules")
    dump_decap_rules_all(handle)

if options.deinit:
    if tunnel_rc == SX_STATUS_SUCCESS:
        tunnel_deinit(handle)

    if router_rc == SX_STATUS_SUCCESS:
        router_deinit(handle)

sx_api_close(handle)
