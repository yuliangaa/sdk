#!/usr/bin/env python
"""
This file contains a python commands example for the SDK.
Python commands syntax is very similar to the SwitchX SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
"""

import sys
import errno
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1
MAX_PORTS = 64

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'


ingress_filter_mode_dict = {
    "ENABLE": SX_INGR_FILTER_ENABLE,
    "DISABLE": SX_INGR_FILTER_DISABLE,
    "enable": SX_INGR_FILTER_ENABLE,
    "disable": SX_INGR_FILTER_DISABLE,
    "1": SX_INGR_FILTER_ENABLE,
    "0": SX_INGR_FILTER_DISABLE,
}


parser = argparse.ArgumentParser(description='sx_api_vlan_port_ingr_filter_set')
parser.add_argument('--log_port', default=0x10001, type=auto_int, help='Log port')
parser.add_argument('--ingress_filter_mode', type=str, choices=list(ingress_filter_mode_dict.keys()), default="ENABLE",
                    help='ingress_filter_mode')
parser.add_argument('--force', action="store_true", help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()


print("log_port: 0x%x" % args.log_port)
print("ingress_filter_mode: %d" % ingress_filter_mode_dict[args.ingress_filter_mode])


######################################################
#    functions
######################################################


def main():
    #     pdb.set_trace()
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # save for later de-configuration
    original_ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, args.log_port, original_ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    original_ingr_filter_mode = sx_ingr_filter_mode_t_p_value(original_ingress_filter_mode_p)

    rc = sx_api_vlan_port_ingr_filter_set(handle, args.log_port, ingress_filter_mode_dict[args.ingress_filter_mode])
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()

    rc = sx_api_vlan_port_ingr_filter_get(handle, args.log_port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    ingr_filter_mode = sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)
    print("GET results")
    print("    Log port:0x%x " % args.log_port)
    print("    ingress_filter_mode:%d " % ingr_filter_mode)

    if args.deinit:
        print("Deinit")
        rc = sx_api_vlan_port_ingr_filter_set(handle, args.log_port, original_ingr_filter_mode)
        assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. [%s(%d)]" % (sx_status_dict[rc], rc)

    print("[+] Closing sdk")
    rc = sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
