#!/usr/bin/env python

import sys
import time
from python_sdk_api.sxd_api import *
import test_infra_common as common_lib
import argparse

##############################################################################################################
# PRM ENUMS DICTIONARIES & AUX FUNCTIONS
##############################################################################################################

paos_status_dict = {
    0: 'NONE',
    1: 'UP',
    2: 'DOWN',
    3: 'UP_ONCE',
    4: 'DOWN_BY_PORT_FAILURE'
}

paos_enable_dict = {
    0: 'PAOS_SET_DISABLED',
    1: 'PAOS_SET_ENABLED'
}

paos_event_update_dict = {
    0: 'EVENT_UPDATE_DISABLED',
    1: 'EVENT_UPDATE_ENABLED'
}
paos_event_generation_dict = {
    0: 'DO_NO_GENERATE_EVENT',
    1: 'GENERATE_EVENT',
    2: 'GENERATE_SINGLE_EVENT'
}

pplr_status_dict = {
    0: 'NO_LOOPBACK',
    2: 'PHY_LOCAL_LOOPBACK'
}

pmaos_status_dict = {
    0: 'INITIALIZING',
    1: 'PLUGGED_ENABLED',
    2: 'UNPLUGGED',
    3: 'PLUGGED_WITH_ERROR',
    4: 'PLUGGED_DISABLED',
    5: 'UNKNOWN'
}

phy_test_mode_status_dict = {
    0: 'PHY_TEST_MODE_OFF',
    1: 'PHY_TEST_MODE_ON'
}

modulation_dict = {
    0: 'NRZ',
    1: 'PAM4_GRAY',
    2: 'PAM4_GRAY_PRECODING',
    3: 'PAM4',
    4: 'PAM4_PRECODING'
}

lane_rate_admin_dict = {
    0: 'SDR',
    1: 'DDR',
    2: 'QDR',
    3: 'FDR10',
    4: 'FDR',
    5: 'EDR',
    6: 'HDR',
    7: 'NDR',
    8: 'XDR',
    9: 'RESERVED',
    10: '1GE',
    11: 'XAUI',
    12: '50GE-KR4'
}

lane_rate_cap_dict = {
    0: '1GE',
    1: 'SDR',
    2: 'XAUI',
    3: 'DDR',
    4: 'QDR',
    5: 'FDR10',
    6: 'FDR',
    7: 'EDR',
    8: '50GE-KR4',
    9: 'HDR',
    10: 'NDR',
    11: 'XDR',
}

tuning_status_dict = {
    0: 'TUNING_NOT_PERFORMED',
    1: 'PERFORMING_TUNING',
    2: 'TUNING_COMPLETED',
    3: 'SIGNAL_DETECT_IN_PROGRESS'
}

perform_tuning_dict = {
    0: 'DO_NOT_PERFORM_TUNING',
    1: 'PERFORM_TUNING'
}

enable_prbs_bit_dict = {
    0: 'PRBS_DISABLED',
    1: 'PRBS_ENABLED'
}

ppcnt_clr_bit_dict = {
    0: 'DO_NOT_CLEAR_COUNTERS',
    1: 'CLEAR_COUNTERS'
}

ppcnt_group_dict = {
    16: 'PHYSICAL_LAYER_STATISTICAL_COUNTERS',
}

prbs_mode_dict = {
    0: 'PRBS31',
    1: 'PRBS23A',
    2: 'PRBS23B',
    3: 'PRBS23C',
    4: 'PRBS23D',
    5: 'PRBS7',
    6: 'PRBS11',
    7: 'PRBS11A',
    8: 'PRBS11B',
    9: 'PRBS11C',
    10: 'PRBS11D',
    11: 'PRBS9',
    12: 'IDLES',
    13: 'SquareWave8',
    14: 'SquareWave4',
    15: 'SquareWave2',
    16: 'SquareWave1',
    17: 'PRBS13A',
    18: 'PRBS13B',
    19: 'PRBS13C',
    20: 'PRBS13D',
    21: 'SSPR',
    22: 'SSPRQ',
    23: 'LT_FRAMES',
    24: 'PRBS15',
    25: 'PRBS28',
    26: 'SquareWave3',
    27: 'SquareWave13',
    28: 'SquareWave30',
    29: 'PRBS58'
}


def map_str_to_int(dict_map, map_str):
    return [i for i in dict_map if (dict_map[i] == map_str)][0]


def is_value_supported(map_dict, capability_mask, value_string):
    value_bit = (1 << map_str_to_int(map_dict, value_string))
    return (capability_mask & value_bit) != 0


def prbs_cap_to_str(prbs_cap_int):

    if prbs_cap_int == 0:
        return 'NONE'

    return ','.join([prbs_mode_dict[i] for i in prbs_mode_dict if is_value_supported(prbs_mode_dict, prbs_cap_int, prbs_mode_dict[i])])


def lane_rate_cap_to_str(lane_rate_cap_int):

    if lane_rate_cap_int == 0:
        return 'NONE'

    return ','.join([lane_rate_cap_dict[i] for i in lane_rate_cap_dict if is_value_supported(lane_rate_cap_dict, lane_rate_cap_int, lane_rate_cap_dict[i])])


def parse_arguments():
    parser = argparse.ArgumentParser(description='SXD API PRBS Test Example - Testing lanes lock and BER quality on a specified PRBS pattern. \
                                                    --loopback flag will get the port into phy local loopback mode which will test register \
                                                    configurations only (without testing the module/cable & serdes at all). Note that if a \
                                                    port without any cable plugged into it runs this test, the port will automatically get into \
                                                    phy local loopback mode while running the test and return to the previous state after the test.')

    parser.add_argument('-l', '--local_port',
                        type=int,
                        default=1,
                        help='Local port number. Default local port number is 1')
    parser.add_argument('-p', '--prbs_mode',
                        choices=prbs_mode_dict.values(),
                        default='PRBS31',
                        help='PRBS pattertn. Default PRBS pattern is "PRBS31"')
    parser.add_argument('-s', '--speed',
                        choices=lane_rate_cap_dict.values(),
                        default='EDR',
                        help='Speed configuration (data rate). Default rate is "EDR"')
    parser.add_argument('-m', '--modulation',
                        choices=modulation_dict.values(),
                        default='NRZ',
                        help='Modulation type. Default modulation is "NRZ"')
    parser.add_argument('--loopback',
                        action='store_true',
                        help='Configures the port to be in PHY local loopback before starting PRBS test mode')
    parser.add_argument('--deinit',
                        action='store_true',
                        help='Cleanup all configuration done by the example')
    parser.add_argument('--force',
                        action='store_true',
                        help='Override prompt for SDK configuration change.')

    return parser.parse_args()


def main():
    args = parse_arguments()

    common_lib.print_api_example_disclaimer()
    if not args.force:
        common_lib.print_modification_warning()

    print("\nInitializing access register")

    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SXD_STATUS_SUCCESS):
        print("Failed to initialize access register.\nPlease check that SDK is running.")
        sys.exit(rc)

    try:
        meta = sxd_reg_meta_t()
        meta.dev_id = 1
        meta.swid = 0

        meta.access_cmd = SXD_ACCESS_CMD_GET

        if args.deinit:
            print("\nDeinit was set, saving data for deconfiguration when test finishes")

            original_paos = ku_paos_reg()
            original_paos.swid = 0
            original_paos.local_port, original_paos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

            rc = sxd_access_reg_paos(original_paos, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to get PAOS register, rc: %d" % (rc)

            original_pplr = ku_pplr_reg()
            original_pplr.swid = 0
            original_pplr.local_port, original_pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

            rc = sxd_access_reg_pplr(original_pplr, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to get PPLR register, rc: %d" % (rc)

            original_ppaos = ku_ppaos_reg()
            original_ppaos.swid = 0
            original_ppaos.local_port, original_ppaos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

            rc = sxd_access_reg_ppaos(original_ppaos, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to get PPAOS register, rc: %d" % (rc)

        pmdr = ku_pmdr_reg()
        pmaos = ku_pmaos_reg()
        paos = ku_paos_reg()
        pplr = ku_pplr_reg()
        ppaos = ku_ppaos_reg()
        pptt = ku_pptt_reg()
        pprt = ku_pprt_reg()
        ppcnt = ku_ppcnt_reg()

        print("\n########## PRE-TEST CONFIGURATIONS ##########\n")

        ########## checking MODULE status ##########
        # get module number first by sending PMDR
        pmdr.local_port, pmdr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pmdr.pnat = 0

        rc = sxd_access_reg_pmdr(pmdr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PMDR register, rc: %d" % (rc)

        # check module status
        pmaos.local_port, pmaos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pmaos.pnat = 0
        pmaos.module = pmdr.module

        rc = sxd_access_reg_pmaos(pmaos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PMAOS register, rc: %d" % (rc)

        if pmaos_status_dict[pmaos.oper_status] != 'PLUGGED_ENABLED':
            print("# MODULE is unplugged, turning on phy_local_loopback in order to test PRBS configurations."
                  + "\n  This configuration will be reverted at the end of the test.\n")

            args.loopback = True

        ########## reset PHY_TEST_MODE state ##########
        meta.access_cmd = SXD_ACCESS_CMD_GET

        ppaos.swid = 0
        ppaos.local_port, ppaos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)

        rc = sxd_access_reg_ppaos(ppaos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PPAOS register, rc: %d" % (rc)

        if phy_test_mode_status_dict[ppaos.phy_test_mode_admin] == 'PHY_TEST_MODE_ON':
            print("# PHY_TEST_MODE is ON, probably from a previous test. Taking it OFF before starting test.\n")
            meta.access_cmd = SXD_ACCESS_CMD_SET
            ppaos.phy_test_mode_admin = map_str_to_int(phy_test_mode_status_dict, 'PHY_TEST_MODE_OFF')
            rc = sxd_access_reg_ppaos(ppaos, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set PPAOS register, rc: %d" % (rc)

            # wait for PPAOS OFF to be configured
            time.sleep(1)

        # PHY_TEST_MODE configuration can only be done when port is down.
        print("# Sending PAOS DOWN before starting test.\n")
        meta.access_cmd = SXD_ACCESS_CMD_SET

        paos.swid = 0
        paos.local_port, paos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        paos.admin_status = map_str_to_int(paos_status_dict, 'DOWN')
        paos.ase = map_str_to_int(paos_enable_dict, 'PAOS_SET_ENABLED')
        paos.ee = map_str_to_int(paos_event_update_dict, 'EVENT_UPDATE_ENABLED')
        paos.e = map_str_to_int(paos_event_generation_dict, 'GENERATE_SINGLE_EVENT')

        rc = sxd_access_reg_paos(paos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)

        print("# Clearing PPCNT register error counters before starting test.")

        ppcnt.swid = 0
        ppcnt.local_port, ppcnt.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        ppcnt.pnat = 0
        ppcnt.grp = map_str_to_int(ppcnt_group_dict, 'PHYSICAL_LAYER_STATISTICAL_COUNTERS')
        ppcnt.clr = map_str_to_int(ppcnt_clr_bit_dict, 'CLEAR_COUNTERS')

        rc = sxd_access_reg_ppcnt(ppcnt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPCNT register, rc: %d" % (rc)

        print("\n---------- PRBS TEST OVER SXD - START ----------")
        print("\n########## STARTING PRBS TEST REGISTER CONFIGURATIONS ##########")

        if args.loopback:
            print("\nSet PPLR")
            print("====================")

            pplr.local_port, pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
            pplr.lb_en = map_str_to_int(pplr_status_dict, 'PHY_LOCAL_LOOPBACK')

            rc = sxd_access_reg_pplr(pplr, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set PPLR register, rc: %d" % (rc)

            print("local_port: " + str(pplr.local_port))
            print("lp_msb: " + str(pplr.lp_msb))
            print("lb_en: " + pplr_status_dict[pplr.lb_en])

        print("\nSet PPTT")
        print("====================")

        pptt.pnat = 0
        pptt.local_port, pptt.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pptt.prbs_mode_admin = map_str_to_int(prbs_mode_dict, args.prbs_mode)
        pptt.lane_rate_admin = map_str_to_int(lane_rate_admin_dict, args.speed)
        pptt.modulation = map_str_to_int(modulation_dict, args.modulation)
        pptt.e = map_str_to_int(enable_prbs_bit_dict, 'PRBS_ENABLED')

        rc = sxd_access_reg_pptt(pptt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPTT register, rc: %d" % (rc)

        print("pnat: " + str(pptt.pnat))
        print("local_port: " + str(pptt.local_port))
        print("lp_msb: " + str(pptt.lp_msb))
        print("prbs_mode_admin: " + prbs_mode_dict[pptt.prbs_mode_admin])
        print("lane_rate_admin: " + lane_rate_admin_dict[pptt.lane_rate_admin])
        print("modulation: " + modulation_dict[pptt.modulation])
        print("e: " + enable_prbs_bit_dict[pptt.e])

        print("\nSet PPRT")
        print("====================")

        pprt.pnat = 0
        pprt.local_port, pprt.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pprt.e = map_str_to_int(enable_prbs_bit_dict, 'PRBS_ENABLED')
        pprt.s = map_str_to_int(perform_tuning_dict, 'DO_NOT_PERFORM_TUNING')
        pprt.prbs_mode_admin = map_str_to_int(prbs_mode_dict, args.prbs_mode)
        pprt.lane_rate_oper = map_str_to_int(lane_rate_admin_dict, args.speed)
        pprt.modulation = map_str_to_int(modulation_dict, args.modulation)

        print("pnat: " + str(pprt.pnat))
        print("local_port: " + str(pprt.local_port))
        print("lp_msb: " + str(pprt.lp_msb))
        print("prbs_mode_admin: " + prbs_mode_dict[pprt.prbs_mode_admin])
        print("lane_rate_oper: " + lane_rate_admin_dict[pprt.lane_rate_oper])
        print("modulation: " + modulation_dict[pprt.modulation])
        print("s: " + perform_tuning_dict[pprt.s])
        print("e: " + enable_prbs_bit_dict[pprt.e])

        rc = sxd_access_reg_pprt(pprt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPRT register, rc: %d" % (rc)

        print("\nSet PPAOS")
        print("====================")

        ppaos.swid = 0
        ppaos.local_port, ppaos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        ppaos.phy_test_mode_admin = map_str_to_int(phy_test_mode_status_dict, 'PHY_TEST_MODE_ON')

        rc = sxd_access_reg_ppaos(ppaos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPAOS register, rc: %d" % (rc)

        print("swid: " + str(ppaos.swid))
        print("local_port: " + str(ppaos.local_port))
        print("lp_msb: " + str(ppaos.lp_msb))
        print("phy_test_mode_admin: " + phy_test_mode_status_dict[ppaos.phy_test_mode_admin])

        # wait for PPRT & PPTT configuration to finish before starting tuning on RX
        time.sleep(1)

        print("\nSet PPRT - tuning stage")
        print("====================")

        pprt.pnat = 0
        pprt.local_port, pprt.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pprt.s = map_str_to_int(perform_tuning_dict, 'PERFORM_TUNING')

        print("pnat: " + str(pprt.pnat))
        print("local_port: " + str(pprt.local_port))
        print("lp_msb: " + str(pprt.lp_msb))
        print("prbs_mode_admin: " + prbs_mode_dict[pprt.prbs_mode_admin])
        print("lane_rate_oper: " + lane_rate_admin_dict[pprt.lane_rate_oper])
        print("modulation: " + modulation_dict[pprt.modulation])
        print("s: " + perform_tuning_dict[pprt.s])
        print("e: " + enable_prbs_bit_dict[pprt.e])

        rc = sxd_access_reg_pprt(pprt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPRT register, rc: %d" % (rc)

        print("\n########## CHECKING PRBS TEST REGISTER CONFIGURATIONS ##########")
        meta.access_cmd = SXD_ACCESS_CMD_GET

        print("\nGet PAOS")
        print("====================")

        rc = sxd_access_reg_paos(paos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PAOS register, rc: %d" % (rc)

        print("oper_status: " + paos_status_dict[paos.oper_status])
        print("ase: " + paos_enable_dict[paos.ase])
        print("ee: " + paos_event_update_dict[paos.ee])
        print("e: " + paos_event_generation_dict[paos.e])

        print("\nGet PPAOS")
        print("====================")

        rc = sxd_access_reg_ppaos(ppaos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PPAOS register, rc: %d" % (rc)

        print("phy_test_mode_status: " + phy_test_mode_status_dict[ppaos.phy_test_mode_status])

        print("\nGet PPTT")
        print("====================")

        rc = sxd_access_reg_pptt(pptt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PPTT register, rc: %d" % (rc)

        print("prbs_modes_cap: " + prbs_cap_to_str(pptt.prbs_modes_cap))
        print("prbs_mode_admin: " + prbs_mode_dict[pptt.prbs_mode_admin])
        print("lane_rate_cap: " + lane_rate_cap_to_str(pptt.lane_rate_cap))
        print("lane_rate_admin: " + lane_rate_admin_dict[pptt.lane_rate_admin])

        print("\nGet PPRT")
        print("====================")

        # wait for tuning to finish
        time.sleep(1)

        rc = sxd_access_reg_pprt(pprt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PPRT register, rc: %d" % (rc)

        lanes_0_3_lock_status = bin(pprt.prbs_lock_status).replace("0b", "")
        lanes_4_7_lock_status = bin(pprt.prbs_lock_status_ext).replace("0b", "")

        print("prbs_modes_cap: " + prbs_cap_to_str(pprt.prbs_modes_cap))
        print("prbs_mode_admin: " + prbs_mode_dict[pprt.prbs_mode_admin])
        print("lane_rate_cap: " + lane_rate_cap_to_str(pprt.lane_rate_cap))
        print("lane_rate_oper: " + lane_rate_admin_dict[pprt.lane_rate_oper])
        print("prbs_rx_tuning_status: " + tuning_status_dict[pprt.prbs_rx_tuning_status])
        print("prbs_lock_status_lanes_0_3 (bit mask): " + ','.join(lanes_0_3_lock_status))
        print("prbs_lock_status_lanes_4_7 (bit mask): " + ','.join(lanes_4_7_lock_status))

        print("\nGet PPCNT - RAW BER per lane")
        print("====================")

        ppcnt.grp = map_str_to_int(ppcnt_group_dict, 'PHYSICAL_LAYER_STATISTICAL_COUNTERS')
        ppcnt.clr = map_str_to_int(ppcnt_clr_bit_dict, 'DO_NOT_CLEAR_COUNTERS')

        rc = sxd_access_reg_ppcnt(ppcnt, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to get PPCNT register, rc: %d" % (rc)

        print("\nPPCNT Group:\n\t" + ppcnt_group_dict[ppcnt.grp])

        print("\nRaw BER magnitude lane0: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane0))
        print("Raw BER coef lane0: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane0))
        print("Raw BER magnitude lane1: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane1))
        print("Raw BER coef lane1: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane1))
        print("Raw BER magnitude lane2: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane2))
        print("Raw BER coef lane2: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane2))
        print("Raw BER magnitude lane3: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane3))
        print("Raw BER coef lane3: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane3))
        print("Raw BER magnitude lane4: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane4))
        print("Raw BER coef lane4: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane4))
        print("Raw BER magnitude lane5: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane5))
        print("Raw BER coef lane5: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane5))
        print("Raw BER magnitude lane6: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane6))
        print("Raw BER coef lane6: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane6))
        print("Raw BER magnitude lane7: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_magnitude_lane7))
        print("Raw BER coef lane7: " + str(ppcnt.counter_set.phys_layer_stat_cntrs.raw_ber_coef_lane7))

        ########## returning to operational mode ##########
        meta.access_cmd = SXD_ACCESS_CMD_SET

        # set PPAOS - PHY_TEST_MODE_OFF
        ppaos.swid = 0
        ppaos.local_port, ppaos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        ppaos.phy_test_mode_admin = map_str_to_int(phy_test_mode_status_dict, 'PHY_TEST_MODE_OFF')

        rc = sxd_access_reg_ppaos(ppaos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPAOS register, rc: %d" % (rc)

        # set PPLR - NO_LOOPBACK
        pplr.local_port, pplr.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        pplr.lb_en = map_str_to_int(pplr_status_dict, 'NO_LOOPBACK')

        rc = sxd_access_reg_pplr(pplr, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PPLR register, rc: %d" % (rc)

        # set PAOS - DOWN
        paos.swid = 0
        paos.local_port, paos.lp_msb = common_lib.get_lsb_msb_of_local_port(args.local_port)
        paos.admin_status = 2
        paos.ase = 1
        paos.ee = 1
        paos.e = 2

        # cannot send PAOS DOWN before PHY_TEST_MODE_OFF to be configured, wait for PPAOS to be configured
        time.sleep(1)

        rc = sxd_access_reg_paos(paos, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)

        print("\n---------- PRBS TEST OVER SXD - END ----------\n")

        ##########################################################################
        # DE-CONFIGURATION
        ##########################################################################

        if args.deinit:
            print("\nRestoring data")
            print("====================")

            rc = sxd_access_reg_ppaos(original_ppaos, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set PPAOS register, rc: %d" % (rc)

            rc = sxd_access_reg_pplr(original_pplr, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set PPLR register, rc: %d" % (rc)

            rc = sxd_access_reg_paos(original_paos, meta, 1, None, None)
            assert rc == SXD_STATUS_SUCCESS, "Failed to set PAOS register, rc: %d" % (rc)

            print("Data restored successfully\n")

    finally:
        rc = sxd_access_reg_deinit()
        if rc != SXD_STATUS_SUCCESS:
            print("sxd_access_reg_deinit failed; rc=%d" % (rc))
            sys.exit(rc)


if __name__ == '__main__':
    sys.exit(main())
