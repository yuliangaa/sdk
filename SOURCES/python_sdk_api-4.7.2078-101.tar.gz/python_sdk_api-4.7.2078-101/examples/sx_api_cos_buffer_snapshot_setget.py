#!/usr/bin/env python
"""
Example of buffer snapshot
"""

import os
import sys
import time
from python_sdk_api.sx_api import *
from test_infra_common import *
from threading import Thread
import argparse

######################################################
#    defines
######################################################
SWID = 0


def parse_args():
    """
    Parse user given arguments functions
        1. Support regression needed flags
        2. Add custom flags if needed, with default values
    """

    description_str = """ This is an example of how to set/get buffer snapshot action. """
    parser = argparse.ArgumentParser(description=description_str)
    parser.add_argument("--force", action="store_true", help="Force configurations which requires user input")
    parser.add_argument("--deinit", action="store_true", help="Roll-back configuration done by the example at its end")

    return parser.parse_args()


def sx_recv(fd_p, handle):
    # recv parameters
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)
    pkt_p = new_uint8_t_arr(pkt_size)
    recv_info_p = new_sx_receive_info_t_p()

    print("[recv] recv buffer snapshot trap on the fd")
    rc = sx_lib_host_ifc_recv(fd_p, pkt_p, pkt_size_p, recv_info_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sys.exit with error, rc %d" % rc))
        sys.exit(rc)

    # print the event parametes
    print(("Recv trap id: %d" % recv_info_p.trap_id))

    assert recv_info_p.event_info.sb_snapshot.snapshot_information.sb_snapshot_status == SX_SB_SNAPSHOT_ACTION_TAKE_E, \
        "snapshot status is expected to be = SX_SB_SNAPSHOT_ACTION_TAKE_E, " \
        "but got %d" % recv_info_p.event_info.sb_snapshot.snapshot_information.sb_snapshot_status
    print("Recv snapshot status: %d" % recv_info_p.event_info.sb_snapshot.snapshot_information.sb_snapshot_status)

    print("[recv] recv done")


def main():
    trap_group = 1
    trap_id = SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT

    args = parse_args()     # Parse given arguments

    if not args.force:      # Print modification warning if user didn't provide force flag
        print_modification_warning()

    # Open Handle
    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    # Check chip type
    chip_type = get_chip_type(handle)
    if chip_type in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1]:
        print("Buffer snapshot is not available on SPC1")
        sx_api_close(handle)
        sys.exit(0)

    print("--------------- HOST IFC OPEN------------------------------")
    fd_p = new_sx_fd_t_p()
    rc = sx_api_host_ifc_open(handle, fd_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_open failed rc %d" % rc))
        sys.exit(rc)
    fd = sx_fd_t_p_value(fd_p)
    print(("sx_api_host_ifc_open,fd = %d rc=%d] " % (fd.fd, rc)))

    print("[+] set trap attributes for trap group %d" % trap_group)
    trap_grp = sx_trap_group_attributes_t()
    trap_grp.control_type = SX_CONTROL_TYPE_DEFAULT
    trap_grp.prio = 1
    trap_grp.truncate_mode = SX_TRUNCATE_MODE_DISABLE
    trap_grp.truncate_size = 0
    trap_grp.is_monitor = False
    trap_grp.trap_group = trap_group
    trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SWID, trap_group, trap_grp)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, rc %d" % rc)
        sys.exit(rc)

    trap_group = sx_trap_group_attributes_t_p_value(trap_grp).trap_group

    print("registering to receive buffer snapshot trap")
    sx_user_channel_p = new_sx_user_channel_t_p()
    sx_user_channel_p.type = SX_USER_CHANNEL_TYPE_FD
    sx_user_channel_p.channel.fd = fd
    rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, SWID,
                                              SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT,
                                              sx_user_channel_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_host_ifc_trap_id_register_set failed rc %d" % rc))
        sys.exit(rc)
    print(("sx_api_host_ifc_trap_id_register_set  rc %d " % (rc)))

    trap_action = SX_TRAP_ACTION_TRAP_2_CPU
    sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
    sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
    sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

    sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
    sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
    sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E

    sx_host_ifc_trap_key.trap_key_attr.trap_id = SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT
    sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)

    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_ext_set failed, rc %d" % rc)
        sys.exit(rc)

    try:
        # open rx threads to recive the trap
        rx = Thread(target=sx_recv, args=(fd_p, handle))
        rx.setDaemon(True)
        rx.start()

        print("Take snapshot")
        rc = sx_api_cos_sb_snapshot_action_set(handle, SX_SB_SNAPSHOT_ACTION_TAKE_E)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to take snapshot, [rc = %d]" % (rc)))
            sys.exit(rc)

        print("Get snapshot status")
        snapshot_info = sx_sb_snapshot_information_t()
        rc = sx_api_cos_sb_snapshot_info_get(handle, snapshot_info)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to get snapshot information, [rc = %d]" % (rc)))
            sys.exit(rc)

        assert snapshot_info.sb_snapshot_status == SX_SB_SNAPSHOT_ACTION_TAKE_E, "snapshot status is expected to be = SX_SB_SNAPSHOT_ACTION_TAKE_E, " \
            "but got %d" % snapshot_info.sb_snapshot_status

        assert snapshot_info.sb_last_snapshot_trigger.type == SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E, "snapshot trigger is expected to be " \
            "= SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E, but got %d" % snapshot_info.sb_last_snapshot_trigger.type

        print("Release snapshot")
        sx_api_cos_sb_snapshot_action_set(handle, SX_SB_SNAPSHOT_ACTION_RELEASE_E)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to release snapshot, [rc = %d]" % (rc)))
            sys.exit(rc)

        print("Get snapshot status")
        snapshot_info = sx_sb_snapshot_information_t()
        rc = sx_api_cos_sb_snapshot_info_get(handle, snapshot_info)
        if rc != SX_STATUS_SUCCESS:
            print(("Failed to get snapshot information, [rc = %d]" % (rc)))
            sys.exit(rc)

        assert snapshot_info.sb_snapshot_status == SX_SB_SNAPSHOT_ACTION_RELEASE_E, "snapshot status is expected to be = SX_SB_SNAPSHOT_ACTION_RELEASE_E,"
        "but got %d" % snapshot_info.sb_snapshot_status

        # wait for the trap to arrive
        trap_rc = 0
        rx.join(timeout=5)
        if rx.is_alive():
            print("ERROR: Buffer snapshot trap didn't arrive!")
            trap_rc = 1
        else:
            print("SUCCESS.")

        if args.deinit:

            rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, SWID, trap_id, sx_user_channel_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_host_ifc_trap_id_register_set failed [rc=%d]" % (rc)))
                sys.exit(rc)

            rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p,
                                                 sx_host_ifc_trap_attr_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_host_ifc_trap_id_ext_set failed [rc=%d]" % (rc)))
                sys.exit(rc)

            rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SWID, trap_group, trap_grp)
            if rc != SX_STATUS_SUCCESS:
                print(("sx_api_host_ifc_trap_group_ext_set set failed; [rc=%d]" % (rc)))
                sys.exit(rc)

            # release snapshot
            sx_api_cos_sb_snapshot_action_set(handle, SX_SB_SNAPSHOT_ACTION_RELEASE_E)

            print("[+] close host ifc recv fd")
            rc = sx_api_host_ifc_close(handle, fd_p)
            delete_sx_fd_t_p(fd_p)
            if rc != SX_STATUS_SUCCESS:
                print(("sys.exit with error, rc %d" % rc))
                sys.exit(rc)

        delete_sx_user_channel_t_p(sx_user_channel_p)
        print("SUCCESS")
        sys.exit(trap_rc or rc)
    finally:
        sx_api_close(handle)


if __name__ == "__main__":
    sys.exit(main())
