#!/usr/bin/env python
'''
This file contains Python command example for the Lib Host Ifc module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.
'''


dest_port_type_dict = {0: 'INVALID', 1: 'MULTI_PORT', 2: 'NETWORK_PORT', 4: 'LAG_PORT'}

import sys
import errno
import os
import time
from test_infra_common import *
from python_sdk_api.sx_api import *
from threading import Thread
import argparse

parser = argparse.ArgumentParser(description='sx_api_host_ifc_trap_recv example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def sx_recv(fd_p):
    # recv parameters
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)
    pkt = new_uint8_t_arr(pkt_size)
    recv_info_p = new_sx_receive_info_t_p()

    print("[recv] recv on fd")
    rc = sx_lib_host_ifc_recv(fd_p, pkt, pkt_size_p, recv_info_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_lib_host_ifc_recv failed, rc %d" % rc)
        sys.exit(rc)

    print("[recv] Packet recv info:")
    print("=" * 50)
    if recv_info_p.is_lag:
        print("Source LAG 0x%x" % recv_info_p.source_lag_port)
    print("Source log port 0x%x" % recv_info_p.source_log_port)

    print("Recv trap id: %d" % recv_info_p.trap_id)

    print("Destination port type : %s" % dest_port_type_dict[recv_info_p.dest_port_type])
    if recv_info_p.dest_port_type == SX_RECEIVE_DEST_PORT_NETWORK_PORT_E:
        print("Destination log port 0x%x" % recv_info_p.dest_log_port)
    if recv_info_p.dest_port_type == SX_RECEIVE_DEST_PORT_LAG_PORT_E:
        print("Destination LAG 0x%x" % recv_info_p.dest_lag_port)
        print("Destination log port 0x%x" % recv_info_p.dest_log_port)

    print("ACL user id: %d" % recv_info_p.acl_user_id)

    pkt_size = uint32_t_p_value(pkt_size_p)
    print("Packet size: %d" % pkt_size)

    print("Packet content:")

    if (pkt_size > 0):
        for iii in range(0, pkt_size):
            if (iii and (0 == iii % 16)):
                print("")
            print("%02x " % uint8_t_arr_getitem(pkt, iii), end="")
        print("")
    print("=" * 50)

    print("[recv] recv done")


def sx_send(fd_p):
    # packet to send
    pkt_size = 2000
    pkt = new_uint8_t_arr(pkt_size)
    dmac = [0x01, 0x80, 0xc2, 0x0, 0x0, 0x0]  # STP DMAC
    smac = [0xF4, 0x52, 0x14, 0x10, 0xD1, 0xA2]
    ethertype = [0x88, 0xcc]
    length = 60
    pkt_payload = [0x55] * length

    # build packet
    base = 0
    for i in range(len(dmac)):
        uint8_t_arr_setitem(pkt, base + i, dmac[i])
    base = base + len(dmac)
    for i in range(len(smac)):
        uint8_t_arr_setitem(pkt, base + i, smac[i])
    base = base + len(smac)
    for i in range(len(ethertype)):
        uint8_t_arr_setitem(pkt, base + i, ethertype[i])
    base = base + len(ethertype)
    for i in range(len(pkt_payload)):
        uint8_t_arr_setitem(pkt, base + i, pkt_payload[i])
    base = base + len(pkt_payload)

    # loopback send parameters
    pkt_size = base
    swid = 0
    prio = 0
    ingress_port = 0x10001
    is_lag = 0
    ingress_lag = 0
    trap_id = SX_TRAP_ID_ETH_L2_STP

    sleep_time = 2
    print("[send] sleep %d sec before send packet" % sleep_time)
    time.sleep(sleep_time)

    print("[send] send loopback packet on fd")
    rc = sx_lib_host_ifc_loopback_ctrl_send(fd_p, pkt, pkt_size, swid, trap_id, ingress_port, is_lag, ingress_lag)
    if rc != SX_STATUS_SUCCESS:
        print("sx_lib_host_ifc_loopback_ctrl_send failed, rc %d" % rc)
        sys.exit(rc)

    print("[send] packet send done")

# main start


ERR_FILE_LOCATION = '/tmp/python_err_log.txt'
print("[+] Redirecting stderr to: %s" % ERR_FILE_LOCATION)
file_exist = os.path.isfile(ERR_FILE_LOCATION)
sys.stderr = open(ERR_FILE_LOCATION, 'w')
if not file_exist:
    os.chmod(ERR_FILE_LOCATION, 0o777)

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print("sx_api_open handle:0x%x , rc %d " % (handle, rc))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.sys.exit(rc)

print("[+] opening host ifc recv fd")
rx_fd_p = new_sx_fd_t_p()
rc = sx_api_host_ifc_open(handle, rx_fd_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_host_ifc_open failed, rc %d" % rc)
    sys.exit(rc)

print("[+] opening host ifc send fd")
tx_fd_p = new_sx_fd_t_p()
rc = sx_api_host_ifc_open(handle, tx_fd_p)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_host_ifc_open failed, rc %d" % rc)
    sys.exit(rc)

# general host ifc parameters
swid = 0
trap_group = 1

print("[+] set trap attributes for trap group %d" % trap_group)
trap_grp = sx_trap_group_attributes_t()
trap_grp.control_type = SX_CONTROL_TYPE_DEFAULT
trap_grp.prio = 1
trap_grp.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_grp.truncate_size = 0
trap_grp.is_monitor = False
trap_grp.trap_group = trap_group
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)

rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, swid, trap_group, trap_grp)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_host_ifc_trap_group_ext_set failed, rc %d" % rc)
    sys.exit(rc)

trap_group = sx_trap_group_attributes_t_p_value(trap_grp).trap_group

# trap id set and trap id register parameters
cmd = SX_ACCESS_CMD_REGISTER

uc_p = new_sx_user_channel_t_p()
uc_p.type = SX_USER_CHANNEL_TYPE_FD
uc_p.channel.fd = rx_fd_p

trap_ids = [SX_TRAP_ID_ETH_L2_STP]
trap_action = SX_TRAP_ACTION_TRAP_2_CPU

sx_host_ifc_trap_key_p = new_sx_host_ifc_trap_key_t_p()
sx_host_ifc_trap_key = sx_host_ifc_trap_key_t()
sx_host_ifc_trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E

sx_host_ifc_trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
sx_host_ifc_trap_attr = sx_host_ifc_trap_attr_t()
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_group = trap_group
sx_host_ifc_trap_attr.attr.trap_id_attr.trap_action = trap_action
sx_host_ifc_trap_attr_t_p_assign(sx_host_ifc_trap_attr_p, sx_host_ifc_trap_attr)

for trap_id in trap_ids:
    print("[+] set trap id %d" % trap_id)

    sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
    sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)

    rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)

    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_ext_set failed, rc %d" % rc)
        sys.sys.exit(rc)

    print("[+] register on trap id %d" % trap_id)
    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, swid, trap_id, uc_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_id_register_set failed, rc %d" % rc)
        sys.exit(rc)

# open rx and tx threads
rx = Thread(target=sx_recv, args=(rx_fd_p,))
tx = Thread(target=sx_send, args=(tx_fd_p,))
rx.start()
tx.start()
rx.join()
tx.join()

if args.deinit:
    # trap id register parameters
    for trap_id in trap_ids:
        print("[+] de-register on trap id %d" % trap_id)
        rc = sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_DEREGISTER, swid, trap_id, uc_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_host_ifc_trap_id_register_set failed, rc %d" % rc)
            sys.exit(rc)

        sx_host_ifc_trap_key.trap_key_attr.trap_id = trap_id
        sx_host_ifc_trap_key_t_p_assign(sx_host_ifc_trap_key_p, sx_host_ifc_trap_key)
        print("[+] unset trap")
        rc = sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_UNSET, sx_host_ifc_trap_key_p, sx_host_ifc_trap_attr_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_host_ifc_trap_id_ext_set failed, rc %d" % rc)
            sys.exit(rc)

    print("[+] unset trap group")
    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, swid, trap_group, trap_grp)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_trap_group_ext_set failed, rc %d" % rc)
        sys.exit(rc)

    print("[+] close host ifc recv fd")
    rc = sx_api_host_ifc_close(handle, rx_fd_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_close failed, rc %d" % rc)
        sys.exit(rc)

    print("[+] close host ifc send fd")
    rc = sx_api_host_ifc_close(handle, tx_fd_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_host_ifc_close failed, rc %d" % rc)
        sys.exit(rc)

print("[+] close sdk")
rc = sx_api_close(handle)
if rc != SX_STATUS_SUCCESS:
    print("sx_api_close failed, rc %d" % rc)
    sys.exit(rc)

print("[+] example script done")
