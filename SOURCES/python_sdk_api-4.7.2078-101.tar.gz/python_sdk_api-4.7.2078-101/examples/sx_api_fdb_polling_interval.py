#!/usr/bin/env python
'''
This file contains Python command example for the FDB module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of rate for 8x lanes port.
logic of the example is the following:
- Reset port API type usage
- Get the current port mapping configurations
- Reset port API type usage
'''
import sys
import errno
import pdb
import time
from python_sdk_api.sx_api import *
from python_sdk_api.sxd_api import *
from test_infra_common import *
import argparse

######################################################
#    defines
######################################################
SWID = 0
DEVICE_ID = 1

ERR_FILE_LOCATION = '/tmp/python_err_log.txt'

parser = argparse.ArgumentParser(description='Get/Set FDB polling interval',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--polling_interval', default=0, type=int, help='Polling interval')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()


def main():

    print("[+] opening sdk")
    rc, handle = sx_api_open(None)
    print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
        sys.exit(rc)

    polling_interval_p = new_sx_fdb_polling_interval_t_p()

    rc = sx_api_fdb_polling_interval_get(handle, SWID, polling_interval_p)
    assert rc == SX_STATUS_SUCCESS, "Failed to get FDB polling interval."

    polling_interval_get = sx_fdb_polling_interval_t_p_value(polling_interval_p)
    print(("Original FDB polling interval:%d" % (polling_interval_get)))

    if (args.polling_interval > 0):
        rc = sx_api_fdb_polling_interval_set(handle, SWID, args.polling_interval)
        assert rc == SX_STATUS_SUCCESS, "Failed to disable mapping. rc=%d" % rc

        rc = sx_api_fdb_polling_interval_get(handle, SWID, polling_interval_p)
        assert rc == SX_STATUS_SUCCESS, "Failed to disable mapping. rc=%d" % rc

        polling_interval_get = sx_fdb_polling_interval_t_p_value(polling_interval_p)
        print(("New FDB polling interval:%d" % (polling_interval_get)))

    if args.deinit:
        rc = sx_api_fdb_polling_interval_set(handle, SWID, polling_interval_get)
        assert rc == SX_STATUS_SUCCESS, "sx_api_fdb_polling_interval_set failed. rc=%d" % rc

    print("Success.")

    sx_api_close(handle)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == "__main__":
    main()
