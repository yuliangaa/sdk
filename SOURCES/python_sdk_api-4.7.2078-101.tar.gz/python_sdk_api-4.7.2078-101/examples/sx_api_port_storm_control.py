#!/usr/bin/env python
'''
This file contains Python command example for the Policer module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different storm control attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_port_storm_control')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))

port_list = mapPortAndInterfaces(handle)
PORT_1 = port_list[0]

""" ############################################################################################ """


def storm_control_build_params_p(uc, mc, bc, uuc, umc, meter_type,
                                 cbs, ebs, cir, yellow_action, red_action, eir, rate_type,
                                 color_aware, is_host_ifc_policer, ir_units):
    storm_control_params_p = new_sx_port_storm_control_params_t_p()
    storm_control_attr = sx_port_storm_control_params_t()

    storm_control_attr.packet_types.uc = uc
    storm_control_attr.packet_types.mc = mc
    storm_control_attr.packet_types.bc = bc
    storm_control_attr.packet_types.uuc = uuc
    storm_control_attr.packet_types.umc = umc
    storm_control_attr.policer_params.meter_type = meter_type
    storm_control_attr.policer_params.cbs = cbs
    storm_control_attr.policer_params.ebs = ebs
    storm_control_attr.policer_params.cir = cir
    storm_control_attr.policer_params.yellow_action = yellow_action
    storm_control_attr.policer_params.red_action = red_action
    storm_control_attr.policer_params.eir = eir
    storm_control_attr.policer_params.rate_type = rate_type
    storm_control_attr.policer_params.color_aware = color_aware
    storm_control_attr.policer_params.is_host_ifc_policer = is_host_ifc_policer
    storm_control_attr.policer_params.ir_units = ir_units

    print(("uc = %d " % (storm_control_attr.packet_types.uc)))
    print(("mc = %d " % (storm_control_attr.packet_types.mc)))
    print(("bc = %d " % (storm_control_attr.packet_types.bc)))
    print(("uuc = %d " % (storm_control_attr.packet_types.uuc)))
    print(("umc = %d " % (storm_control_attr.packet_types.umc)))
    print(("meter type = %d " % (storm_control_attr.policer_params.meter_type)))
    print(("cbs = %d " % (storm_control_attr.policer_params.cbs)))
    print(("ebs = %d " % (storm_control_attr.policer_params.ebs)))
    print(("cir = %d " % (storm_control_attr.policer_params.cir)))
    print(("yellow action = %d " % (storm_control_attr.policer_params.yellow_action)))
    print(("red action = %d " % (storm_control_attr.policer_params.red_action)))
    print(("eir = %d " % (storm_control_attr.policer_params.eir)))
    print(("rate type = %d " % (storm_control_attr.policer_params.rate_type)))
    print(("color aware = %d " % (storm_control_attr.policer_params.color_aware)))
    print(("host ifc policer = %d " % (storm_control_attr.policer_params.is_host_ifc_policer)))
    print(("ir units = %d " % (storm_control_attr.policer_params.ir_units)))

    sx_port_storm_control_params_t_p_assign(storm_control_params_p, storm_control_attr)
    return storm_control_params_p


def storm_control_set(log_port, storm_control_id, storm_control_params_p, cmd):
    """ ############################################################################################ """
    print("--------------- STORM CONTROL SET ------------------------------")
    cmd_str = {SX_ACCESS_CMD_ADD: "ADD", SX_ACCESS_CMD_DELETE: "DELETE"}
    rc = sx_api_port_storm_control_set(handle, cmd, log_port, storm_control_id, storm_control_params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_storm_control_set. [log_port=0x%x, storm_control_id=%d, cmd=%s, rc = %d]"
               % (log_port, storm_control_id, cmd_str[cmd], rc)))
        sys.exit(rc)
    print("sx_api_port_storm_control_set. [log_port=0x%x, storm_control_id=%d, cmd=%s, rc = %d]"
          % (log_port, storm_control_id, cmd_str[cmd], rc))


def storm_control_get(log_port, storm_control_id):
    """ STORM CONTROL  GET """
    print("--------------- STORM CONTROL GET ------------------------")
    storm_control_params_p = new_sx_port_storm_control_params_t_p()

    rc = sx_api_port_storm_control_get(handle, log_port, storm_control_id, storm_control_params_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_storm_control_get. [log_port=0x%x, storm_control_id=%d, rc = %d]" % (log_port, storm_control_id, rc)))
        sys.exit(rc)
    print(("sx_api_port_storm_control_get. [log_port=0x%x, storm_control_id=%d, rc = %d]" % (log_port, storm_control_id, rc)))

    storm_control_attr = sx_port_storm_control_params_t_p_value(storm_control_params_p)

    print(("log_port = %d " % (log_port)))
    print(("storm_control_id = %d " % (storm_control_id)))
    print(("uc = %d " % (storm_control_attr.packet_types.uc)))
    print(("mc = %d " % (storm_control_attr.packet_types.mc)))
    print(("bc = %d " % (storm_control_attr.packet_types.bc)))
    print(("uuc = %d " % (storm_control_attr.packet_types.uuc)))
    print(("umc = %d " % (storm_control_attr.packet_types.umc)))
    print(("meter type = %d " % (storm_control_attr.policer_params.meter_type)))
    print(("cbs = %d " % (storm_control_attr.policer_params.cbs)))
    print(("ebs = %d " % (storm_control_attr.policer_params.ebs)))
    print(("cir = %d " % (storm_control_attr.policer_params.cir)))
    print(("yellow action = %d " % (storm_control_attr.policer_params.yellow_action)))
    print(("red action = %d " % (storm_control_attr.policer_params.red_action)))
    print(("eir = %d " % (storm_control_attr.policer_params.eir)))
    print(("rate type = %d " % (storm_control_attr.policer_params.rate_type)))
    print(("color aware = %d " % (storm_control_attr.policer_params.color_aware)))
    print(("host ifc policer = %d " % (storm_control_attr.policer_params.is_host_ifc_policer)))
    print(("ir units = %d " % (storm_control_attr.policer_params.ir_units)))

    return storm_control_params_p


def get_storm_control_counters(log_port, storm_control_id):
    """ STORM CONTROL COUNTERS GET """
    print("--------------- STORM CONTROL COUNTERS GET ----------------------")
    policer_counters_p = new_sx_policer_counters_t_p()

    rc = sx_api_port_storm_control_counters_get(handle, log_port, storm_control_id, policer_counters_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_storm_control_counters_get, rc = %d " % (rc)))
        sys.exit(rc)
    print(("sx_api_port_storm_control_counters_get, rc = %d " % (rc)))

    policer_counters = sx_policer_counters_t_p_value(policer_counters_p)

    print(("log_port = %d " % (log_port)))
    print(("storm control id = %d " % (storm_control_id)))
    print(("violation counter =%d " % (policer_counters.violation_counter)))

    return policer_counters.violation_counter


def clear_storm_control_counters_set(log_port, storm_control_id, clear_violation_counter):
    """ CLEAR STORM CONTROL COUNTERS SET"""
    print("--------------- CLEAR STORM CONTROL COUNTERS SET -------------------------")
    clear_counters_p = new_sx_policer_counters_clear_t_p()
    clear_counters = sx_policer_counters_clear_t()

    clear_counters.clear_violation_counter = clear_violation_counter
    sx_policer_counters_clear_t_p_assign(clear_counters_p, clear_counters)

    rc = sx_api_port_storm_control_counters_clear_set(handle, log_port, storm_control_id, clear_counters_p)
    if rc != SX_STATUS_SUCCESS:
        print(("sx_api_port_storm_control_counters_clear_set, rc = %d " % (rc)))
        sys.exit(rc)
    print(("sx_api_port_storm_control_counters_clear_set, rc = %d " % (rc)))

    clear_counters = sx_policer_counters_clear_t_p_value(clear_counters_p)

    print(("log_port = %d " % (log_port)))
    print(("storm control id = %d " % (storm_control_id)))
    print(("clear violation counter = %d " % (clear_counters.clear_violation_counter)))


""" ############################################################################################ """

storm_control_id_1 = 1
log_port_1 = PORT_1

storm_control_params_1_p = storm_control_build_params_p(1, 0, 0, 0, 0, SX_POLICER_METER_PACKETS, 10, 10, 1000, SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR,
                                                        SX_POLICER_ACTION_DISCARD, 1000, SX_POLICER_RATE_TYPE_SINGLE_RATE_E, 0, 0,
                                                        SX_POLICER_IR_UNITS_10_POWER_3_E)

storm_control_set(log_port_1, storm_control_id_1, storm_control_params_1_p, SX_ACCESS_CMD_ADD)

storm_control_get(log_port_1, storm_control_id_1)

""" ############################################################################################ """

storm_control_id_2 = 2
log_port_2 = PORT_1

storm_control_params_2_p = storm_control_build_params_p(0, 1, 1, 0, 0, SX_POLICER_METER_TRAFFIC, 10, 10, 1000, SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR,
                                                        SX_POLICER_ACTION_DISCARD, 1000, SX_POLICER_RATE_TYPE_SINGLE_RATE_E, 0, 0,
                                                        SX_POLICER_IR_UNITS_10_POWER_6_E)

storm_control_set(log_port_2, storm_control_id_2, storm_control_params_2_p, SX_ACCESS_CMD_ADD)

storm_control_get(log_port_2, storm_control_id_2)

""" ############################################################################################ """

# get, clear storm control counters for storm_control_id_1
original_clear_violation_counter1 = get_storm_control_counters(log_port_1, storm_control_id_1)
clear_storm_control_counters_set(log_port_1, storm_control_id_1, 1)

# get, clear storm control counters for storm_control_id_2
original_clear_violation_counter2 = get_storm_control_counters(log_port_2, storm_control_id_2)
clear_storm_control_counters_set(log_port_2, storm_control_id_2, 1)

if args.deinit:
    clear_storm_control_counters_set(log_port_2, storm_control_id_2, original_clear_violation_counter2)
    storm_control_set(log_port_2, storm_control_id_2, storm_control_params_2_p, SX_ACCESS_CMD_DELETE)

    clear_storm_control_counters_set(log_port_1, storm_control_id_1, original_clear_violation_counter1)
    storm_control_set(log_port_1, storm_control_id_1, storm_control_params_1_p, SX_ACCESS_CMD_DELETE)

""" ############################################################################################ """
sx_api_close(handle)
""" ############################################################################################ """
