#!/usr/bin/env python

import sys
import time
import os
from python_sdk_api.sxd_api import *
from python_sdk_api.sx_api import *
import argparse

parser = argparse.ArgumentParser(description='get / set MFGD',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--device_id', default=1, type=lambda x: int(x, 0), help='The device id to set the FW MFGD on')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()


def main():

    print("[+] MFGD register access Example Test start")
    print("[+] Initializing register access")
    rc = sxd_access_reg_init(0, None, 4)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to initialize register access.\nPlease check that SDK is running.")
        sys.exit(rc)

    mfgd = ku_mfgd_reg()
    orig_mfgd = ku_mfgd_reg()

    meta = sxd_reg_meta_t()
    meta.dev_id = args.device_id
    meta.swid = 0

    orig_mfgd.en_debug_assert = 0
    orig_mfgd.fw_fatal_event_test = 0
    orig_mfgd.fw_fatal_event_mode = 0

    print("\n========================")
    print("[+] GET original MFGD content")
    print("========================")
    print("[+] Performing get MFGD")
    meta.access_cmd = SXD_ACCESS_CMD_GET
    rc = sxd_access_reg_mfgd(orig_mfgd, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read MFGD register, rc: %d" % (rc)
    print("[+] MFGD original content:")
    print("------------------------")
    print("[+] en_debug_as-sert:", orig_mfgd.en_debug_assert)
    print("[+] fw_fatal_event_test:", orig_mfgd.fw_fatal_event_test)
    print("[+] fw_fatal_event_mode:", orig_mfgd.fw_fatal_event_mode)
    print("")

    print("\n=========================")
    print("[+] Performing set MFGD content:")
    print("==========================")
    fw_fatal_event_mode_set_value = SXD_MFGD_FW_FATAL_EVENT_MODE_CHECK_FW_FATAL_E
    mfgd.en_debug_assert = orig_mfgd.en_debug_assert
    mfgd.fw_fatal_event_test = orig_mfgd.fw_fatal_event_test
    mfgd.fw_fatal_event_mode = fw_fatal_event_mode_set_value
    print("--------------------------------")
    print("[+] fw_fatal_event_mode to set: ", mfgd.fw_fatal_event_mode)
    print("[+] Set MFGD ")
    meta.access_cmd = SXD_ACCESS_CMD_SET
    rc = sxd_access_reg_mfgd(mfgd, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to set MFGD register, rc: %d" % (rc)
    print("")

    print("\n=========================")
    print("[+] Get MFGD (verify Set worked as expected)")
    print("\n=========================")
    meta.access_cmd = SXD_ACCESS_CMD_GET
    rc = sxd_access_reg_mfgd(mfgd, meta, 1, None, None)
    assert rc == SXD_STATUS_SUCCESS, "Failed to read MFGD register, rc: %d" % (rc)
    print("[+] MFGD content:")
    print("------------------------")
    print("[+] en_debug_as-sert: ", mfgd.en_debug_assert)
    print("[+] fw_fatal_event_test:", mfgd.fw_fatal_event_test)
    print("[+] fw_fatal_event_mode:", mfgd.fw_fatal_event_mode)
    assert mfgd.fw_fatal_event_mode == fw_fatal_event_mode_set_value, "MFGD mode after set (%d) is not as we tried to set (%d)".format(mfgd.fw_fatal_event_mode, fw_fatal_event_mode_set_value)
    print("")

    if args.deinit:
        print("\n=============================")
        print("[+] Deinit. Set MFGD to original value.")
        print("==============================")
        meta.access_cmd = SXD_ACCESS_CMD_SET
        rc = sxd_access_reg_mfgd(orig_mfgd, meta, 1, None, None)
        assert rc == SXD_STATUS_SUCCESS, "Failed to set MFGD register, rc: %d" % (rc)

    print("\n\n=========================================")
    print("[+] MFGD register access example test end rc: %d" % (rc))
    print("=========================================\n\n")

    rc = sxd_access_reg_deinit()
    if rc != SXD_STATUS_SUCCESS:
        print("sxd_access_reg_deinit failed; rc=%d" % (rc))
        sys.exit(rc)


################################################################################
#                             Main                                             #
################################################################################
if __name__ == '__main__':
    main()
