#!/usr/bin/env python
'''
This file contains Python command example for the ALL ROUTER INTERFACE DUMP module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
qos_mode_dict = {0: 'NOP', 1: 'PRIO_FROM_DSCP', 2: 'PRESERVE_PRIO'}
egress_mode_dict = {0: 'TAGGED_MEMBER', 1: 'UNTAGGED_MEMBER'}
type_dict = {0: 'VLAN', 1: 'PORT_VLAN', 2: 'VPORT', 3: 'PKEY', 4: 'BRIDGE_PORT', 5: 'BRIDGE', 6: 'LOOPBACK', 7: 'ADAPTIVE'}
state_dict = {0: 'DISABLE', 1: 'ENABLE', 2: 'UNKOWN', 3: 'UNKOWN', 4: 'UNKOWN'}

import sys
import errno
import os

from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
from flex_acl_common import router_module_verbosity_level_get, router_module_verbosity_level_set

print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

vrid_p = new_sx_router_id_t_p()
sx_router_id_t_p_assign(vrid_p, 0)
ifc_param_p = sx_router_interface_param_t()
ifc_attr_p = sx_interface_attributes_t()
ifc_state_p = sx_router_interface_state_t()
rif_cnt_p = new_uint32_t_p()

tables = []
# The following is used to prevent error messages if the router is not initialized
module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
uint32_t_p_assign(rif_cnt_p, 0)
rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET, None, None, None, rif_cnt_p)
router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
if rc == SX_STATUS_MODULE_UNINITIALIZED:
    print("The router module is not initialized. Dump is not available.")
elif rc != SX_STATUS_SUCCESS:
    print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
    sys.exit(rc)
else:
    rif_cnt = uint32_t_p_value(rif_cnt_p)
    rif_list_p = new_sx_router_interface_t_arr(rif_cnt)
    rc = sx_api_router_interface_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, None, None, rif_list_p, rif_cnt_p)
    if rc != SX_STATUS_SUCCESS:
        print("sx_api_router_interface_iter_get failed, rc = %d" % (rc))
        sys.exit(rc)
    rif_cnt = uint32_t_p_value(rif_cnt_p)

    for i in range(0, rif_cnt):
        rif = sx_router_interface_t_arr_getitem(rif_list_p, i)
        rc1 = sx_api_router_interface_get(handle, rif, vrid_p, ifc_param_p, ifc_attr_p)
        if rc1 == SX_STATUS_MODULE_UNINITIALIZED:
            # Check if router module is initialized.
            print("####################################")
            print("# Router is not initialized ")
            print("####################################")
            sys.exit()
        rc2 = sx_api_router_interface_state_get(handle, rif, ifc_state_p)
        vrid = sx_router_id_t_p_value(vrid_p)
        ifc_param = sx_router_interface_param_t_p_value(ifc_param_p)
        ifc_attr = sx_interface_attributes_t_p_value(ifc_attr_p)
        ifc_state = sx_router_interface_state_t_p_value(ifc_state_p)

        if (rc1 == 0 and rc2 == 0):
            type = type_dict[ifc_param.type]
            swid = 0
            vlan = 0
            port = 0
            bridge = 0
            egress_mode = "0"
            if (type == "VLAN"):
                swid = ifc_param.ifc.vlan.swid
                vlan = ifc_param.ifc.vlan.vlan
            elif (type == "PORT_VLAN"):
                port = ifc_param.ifc.port_vlan.port
                vlan = ifc_param.ifc.port_vlan.vlan
            elif (type == "VPORT"):
                port = ifc_param.ifc.vport.vport
            elif (type == "BRIDGE"):
                swid = ifc_param.ifc.bridge.swid
                bridge = ifc_param.ifc.bridge.bridge
            elif (type == "BRIDGE_PORT"):
                port = ifc_param.ifc.bridge_port.port
                vlan = ifc_param.ifc.bridge_port.vlan
                egress_mode = egress_mode_dict[ifc_param.ifc.bridge_port.egress_mode]
            elif (type == "ADAPTIVE"):
                port = ifc_param.ifc.adaptive_routing.vport
            port = "0x%x" % port
            mac = ifc_attr.mac_addr.to_str()
            mtu = ifc_attr.mtu
            ttl = ifc_attr.multicast_ttl_threshold
            qos_mode = qos_mode_dict[ifc_attr.qos_mode]
            ipv4_en = state_dict[ifc_state.ipv4_enable]
            ipv6_en = state_dict[ifc_state.ipv6_enable]
            ipv4_mc_en = state_dict[ifc_state.ipv4_mc_enable]
            ipv6_mc_en = state_dict[ifc_state.ipv6_mc_enable]
            loopback_enabled = state_dict[ifc_attr.loopback_enable]

            table = [rif, vrid, type, swid, vlan, port, bridge, egress_mode, mac, mtu, ttl, qos_mode, ipv4_en, ipv6_en, ipv4_mc_en, ipv6_mc_en, loopback_enabled]
            tables.append(table)
header = ["RIF", "Router ID", "TYPE", "L2 SWID", "L2 VLAN", "LOG PORT", "BRIDGE", "EGRESS_MODE", "L2 MAC", "L2 MTU", "L3 TTL", "QOS", "ipv4 UC state", "ipv6 UC state", "ipv4 MC state", "ipv6 MC state", "LB Enabled"]
print("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("|%6s|%10s|%11s|%8s|%8s|%10s|%7s|%15s|%18s|%7s|%7s|%15s|%14s|%14s|%14s|%14s|%11s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6], header[7], header[8], header[9], header[10], header[11], header[12], header[13], header[14], header[15], header[16]))
print("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")

for table in tables:
    print("|%6d|%10d|%11s|%8d|%8d|%10s|%7s|%15s|%18s|%7d|%7d|%15s|%14s|%14s|%14s|%14s|%11s|" % (table[0], table[1], table[2], table[3], table[4], table[5], table[6], table[7], table[8], table[9], table[10], table[11], table[12], table[13], table[14], table[15], table[16]))
    print("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")

sx_api_close(handle)
