#!/usr/bin/env python
'''
This file contains Python command example for the VRID READ module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different port attributes.
'''
action_dict = {0: 'DROP', 1: 'TRAP', 2: 'FORWARD', 3: 'MIRROR',
               4: 'TRAP_FORWARD', 5: 'SPAN', 6: 'DROP', 7: 'SPAN'}
state_dict = {0: 'DISABLE', 1: 'ENABLE', 2: 'UNKOWN', 3: 'UNKOWN', 4: 'UNKOWN'}

MIN = 0
MAX = 254
import sys
import errno
import os

from python_sdk_api.sx_api import *
from pprint import pprint
from test_infra_common import *
from flex_acl_common import router_module_verbosity_level_get, router_module_verbosity_level_set


print_api_example_disclaimer()

rc, handle = sx_api_open(None)
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

router_attr_p = sx_router_attributes_t()
vrid_array = new_sx_router_id_t_arr(MAX)
data_cnt_p = new_uint32_t_p()
tables = []
vrid_get_list = []

num_get = MAX
uint32_t_p_assign(data_cnt_p, num_get)

module_verbosity, api_verbosity = router_module_verbosity_level_get(handle)
router_module_verbosity_level_set(handle, SX_VERBOSITY_LEVEL_NONE, SX_VERBOSITY_LEVEL_NONE)
rc = sx_api_router_vrid_iter_get(handle, SX_ACCESS_CMD_GET_FIRST, 0, None, vrid_array, data_cnt_p)
router_module_verbosity_level_set(handle, module_verbosity, api_verbosity)
if rc == SX_STATUS_MODULE_UNINITIALIZED:
    print("The router module is not initialized. Dump is not available.")
elif rc != SX_STATUS_SUCCESS:
    print("sx_api_router_vrid_iter_get failed, rc=%d" % rc)
    sys.exit(rc)
else:
    data_cnt = uint32_t_p_value(data_cnt_p)
    for i in range(0, data_cnt):
        vrid_get = sx_router_id_t_arr_getitem(vrid_array, i)
        vrid_get_list.append(vrid_get)
    while data_cnt == MAX:
        rc = sx_api_router_vrid_iter_get(handle, SX_ACCESS_CMD_GETNEXT, vrid_get, None, vrid_array, data_cnt_p)
        if rc != SX_STATUS_SUCCESS:
            print("sx_api_router_vrid_iter_get failed, rc=%d" % rc)
            sys.exit(rc)
        data_cnt = uint32_t_p_value(data_cnt_p)
        for i in range(0, data_cnt):
            vrid_get = sx_router_id_t_arr_getitem(vrid_array, i)
            vrid_get_list.append(vrid_get)

    for vrid in vrid_get_list:
        rc = sx_api_router_get(handle, vrid, router_attr_p)
        if rc == SX_STATUS_SUCCESS:
            router_attr = sx_router_attributes_t_p_value(router_attr_p)

            ipv4_enable = state_dict[router_attr.ipv4_enable]
            ipv6_enable = state_dict[router_attr.ipv6_enable]
            ipv4_mc_enable = state_dict[router_attr.ipv4_mc_enable]
            ipv6_mc_enable = state_dict[router_attr.ipv6_mc_enable]
            uc_default_rule_action = action_dict[router_attr.uc_default_rule_action]
            mc_default_rule_action = action_dict[router_attr.mc_default_rule_action]

            table = [vrid, ipv4_enable, ipv6_enable, ipv4_mc_enable, ipv6_mc_enable, uc_default_rule_action, mc_default_rule_action]
            tables.append(table)
header = ["VRID", "IPv4_enable", "IPv6_enable", "IPv4_mc_enable", "IPv6_mc_enable", "UC default rule action", "MC default rule action"]
print("-----------------------------------------------------------------------------------------------------------------------")
print("|%7s|%15s|%15s|%15s|%15s|%22s|%22s|" % (header[0], header[1], header[2], header[3], header[4], header[5], header[6]))
print("-----------------------------------------------------------------------------------------------------------------------")
for table in tables:
    print("|%7d|%15s|%15s|%15s|%15s|%22s|%22s|" % (table[0], table[1], table[2], table[3], table[4], table[5], table[6]))
    print("-----------------------------------------------------------------------------------------------------------------------")

sx_api_close(handle)
