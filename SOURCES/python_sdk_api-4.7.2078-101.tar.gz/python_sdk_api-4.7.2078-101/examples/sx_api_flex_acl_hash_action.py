#!/usr/bin/env python
"""
This file contains Python command example for the FLEX ACL module.
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below performs the following configurations:
    1. creates a region with size 254
    2. Creates a ACL
    3. Create a LAG with 3 member ports
    4. Create a unicast PBS with dest port LAG
    5. Configure the ingress port to use hash on SIP
    6. Create 254 ACL rules in the region
       key: SIP, value (*.*.*.[1...254]), mask (0x000000ff))
       actions: 1) HASH (type LAG, command SET, hash value 0)
                2) HASH (type LAG, command XOR, hash value random)
                3) PSB (unicast, dst port = LAG)
    7. Bind the ACL to the ingress port
"""
import sys
import socket
import struct
import errno
from python_sdk_api.sx_api import *
from test_infra_common import *
import argparse

parser = argparse.ArgumentParser(description='sx_api_flex_acl_hash_action example')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

port_list = mapPortAndInterfaces(handle)
INGRESS_PORT = port_list[0]
LAG_MEMBER1 = port_list[1]
LAG_MEMBER2 = port_list[2]
LAG_MEMBER3 = port_list[3]

ports_ingr_filter_mode = {}


def region_create(key_handle, region_size):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               key_handle,
                               0,
                               region_size,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"

    region_id = sx_acl_region_id_t_p_value(region_id_p)
    print("Created region %d, rc: %d" % (region_id, rc))
    return region_id


def region_destroy(region_id):
    " This function creates acl region  "
    region_id_p = new_sx_acl_region_id_t_p()
    sx_acl_region_id_t_p_assign(region_id_p, region_id)

    rc = sx_api_acl_region_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               0,
                               0,
                               0,
                               region_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create region"
    print("Destroyed region %d, rc: %d" % (region_id, rc))


def key_create(key):
    " This function creates flex acl key and returns handle to it  "
    key_handle_p = new_sx_acl_key_type_t_p()
    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, key)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_CREATE,
                                 key_arr,
                                 1,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flex key"

    key_handle = sx_acl_key_type_t_p_value(key_handle_p)
    print("Created key %d, rc: %d" % (key_handle, rc))
    return key_handle


def key_destroy(key_handle):
    " This function destroy  flex acl key "
    key_handle_p = new_sx_acl_key_type_t_p()
    sx_acl_key_type_t_p_assign(key_handle_p, key_handle)

    key_arr = new_sx_acl_key_t_arr(1)
    sx_acl_key_t_arr_setitem(key_arr, 0, 0)

    rc = sx_api_acl_flex_key_set(handle,
                                 SX_ACCESS_CMD_DELETE,
                                 key_arr,
                                 0,
                                 key_handle_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy flex key"
    print("Destroyed key %d, rc: %d" % (key_handle, rc))


def acl_create(region_id, direction):
    " This function creates flex acl and returns acl id  "
    acl_region_group = sx_acl_region_group_t()
    acl_id_p = new_sx_acl_id_t_p()

    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_CREATE,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        direction,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create acl"

    acl_id = sx_acl_id_t_p_value(acl_id_p)
    print("Created acl %d, rc: %d" % (acl_id, rc))
    return acl_id


def acl_destroy(acl_id, region_id):
    " This function destroy  flex acl key "
    acl_id_p = new_sx_acl_id_t_p()
    sx_acl_id_t_p_assign(acl_id_p, acl_id)

    acl_region_group = sx_acl_region_group_t()
    acl_region_group.regions.acl_packet_agnostic.region = region_id

    rc = sx_api_acl_set(handle,
                        SX_ACCESS_CMD_DESTROY,
                        SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                        0,
                        acl_region_group,
                        acl_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy acl%d , rc = %d" % (acl_id, rc)

    print("Destroyed acl %d, rc: %d" % (acl_id, rc))
    delete_sx_acl_id_t_p(acl_id_p)


def pbs_create(ports):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    pbs_entry = sx_acl_pbs_entry_t()
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_UNICAST
    pbs_entry.port_num = len(ports)
    pbs_entry.log_ports = new_sx_port_log_id_t_arr(len(ports))
    for i, port in enumerate(ports):
        sx_port_log_id_t_arr_setitem(pbs_entry.log_ports, i, port)
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_ADD,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create pbs, rc = %d" % (rc)
    return sx_acl_pbs_id_t_p_value(pbs_id_p)


def pbs_delete(pbs_id):
    pbs_id_p = new_sx_acl_pbs_id_t_p()
    sx_acl_pbs_id_t_p_assign(pbs_id_p, pbs_id)
    pbs_entry = sx_acl_pbs_entry_t()
    rc = sx_api_acl_policy_based_switching_set(handle,
                                               SX_ACCESS_CMD_DELETE,
                                               0,
                                               pbs_entry,
                                               pbs_id_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete pbs %d, rc = %d" % (pbs_id, rc)


def ingr_filter_get(port):
    ingress_filter_mode_p = new_sx_ingr_filter_mode_t_p()
    rc = sx_api_vlan_port_ingr_filter_get(handle, port, ingress_filter_mode_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_ingr_filter_set failed. rc = [%s(%d)], port = 0x%x" % (sx_status_dict[rc], rc, port)
    return sx_ingr_filter_mode_t_p_value(ingress_filter_mode_p)


def ingr_filter_set(port, mode):
    rc = sx_api_vlan_port_ingr_filter_set(handle, port, mode)
    assert rc == SX_STATUS_SUCCESS, "sx_api_vlan_port_ingr_filter_set failed, rc: %d, port: 0x%x" % (rc, port)


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


def lag_create(port_list):
    lag_id_p = new_sx_port_log_id_t_p()

    port_cnt = len(port_list)
    port_arr = new_sx_port_log_id_t_arr(port_cnt)
    for i, log_port in enumerate(port_list):
        sx_port_log_id_t_arr_setitem(port_arr, i, log_port)
        ports_ingr_filter_mode[log_port] = ingr_filter_get(log_port)

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, 0, lag_id_p, None, 0)
    assert SX_STATUS_SUCCESS == rc, "Failed to create lag, rc = %d" % (rc)

    lag_id = sx_port_log_id_t_p_value(lag_id_p)

    ingr_filter_set(lag_id, SX_INGR_FILTER_ENABLE)

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, 0, lag_id_p, port_arr, port_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to create lag, rc = %d" % (rc)

    for port in port_list:
        rc = sx_api_lag_port_collector_set(handle, lag_id, port, COLLECTOR_ENABLE)
        assert SX_STATUS_SUCCESS == rc, "Failed to enable collector on port 0x%x, rc = %d" % (port, rc)

        rc = sx_api_lag_port_distributor_set(handle, lag_id, port, DISTRIBUTOR_ENABLE)
        assert SX_STATUS_SUCCESS == rc, "Failed to enable distributor on port 0x%x, rc = %d" % (port, rc)

    rc = sx_api_port_state_set(handle, lag_id, SX_PORT_ADMIN_STATUS_UP)
    assert SX_STATUS_SUCCESS == rc, "sx_api_port_state_set failed, rc = %d" % (rc)

    rc = sx_api_rstp_port_state_set(handle, lag_id, SX_MSTP_INST_PORT_STATE_FORWARDING)
    assert SX_STATUS_SUCCESS == rc, "sx_api_rstp_port_state_set failed, rc = %d" % (rc)

    vlan_arr_one = new_sx_vlan_ports_t_arr(1)
    vlan_port = sx_vlan_ports_t()
    vlan_port.log_port = lag_id
    vlan_port.is_untagged = 1
    sx_vlan_ports_t_arr_setitem(vlan_arr_one, 0, vlan_port)

    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, 0, 1, vlan_arr_one, 1)
    assert SX_STATUS_SUCCESS == rc, "sx_api_vlan_ports_set failed, rc = %d" % (rc)

    return lag_id


def lag_delete(lag_id, port_list):
    lag_id_p = new_sx_port_log_id_t_p()
    sx_port_log_id_t_p_assign(lag_id_p, lag_id)

    port_cnt = len(port_list)
    port_arr = new_sx_port_log_id_t_arr(port_cnt)
    for i, log_port in enumerate(port_list):
        sx_port_log_id_t_arr_setitem(port_arr, i, log_port)

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, 0, lag_id_p, port_arr, port_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete ports from lag, rc = %d" % (rc)

    rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DESTROY, 0, lag_id_p, None, 0)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete lag 0x%x, rc = %d" % (lag_id, rc)


def rule_set(region_id, pbs_id, start_offset, end_offset, access):
    ''' This function sets rule, where access is the choose for adding or deleting rule
    SX_ACCESS_CMD_SET - set the Rule
    SX_ACCESS_CMD_DELETE - remove the rule'''

    rules_cnt = (end_offset - start_offset + 1)
    rule_arr = new_sx_flex_acl_flex_rule_t_arr(rules_cnt)
    offsets_list = new_sx_acl_rule_offset_t_arr(rules_cnt)
    j = 0

    for i in range(start_offset, end_offset + 1):
        rule = sx_flex_acl_flex_rule_t()
        rule.valid = 1
        sx_lib_flex_acl_rule_init(0, 3, rule)

        key_desc = sx_flex_acl_key_desc_t()
        key_desc.key_id = FLEX_ACL_KEY_SIP
        key_desc.key.sip.version = SX_IP_VERSION_IPV4
        key_desc.key.sip.addr.ipv4.s_addr = 0x00000000 + i + 1
        key_desc.mask.sip.version = SX_IP_VERSION_IPV4
        key_desc.mask.sip.addr.ipv4.s_addr = 0x000000ff

        sx_flex_acl_key_desc_t_arr_setitem(rule.key_desc_list_p, 0, key_desc)
        rule.key_desc_count = 1

        action1 = sx_flex_acl_flex_action_t()
        action1.type = SX_FLEX_ACL_ACTION_HASH
        action1.fields.action_hash.command = SX_ACL_ACTION_HASH_COMMAND_SET
        action1.fields.action_hash.type = SX_ACL_ACTION_HASH_TYPE_LAG
        action1.fields.action_hash.hash_value = 0
        action2 = sx_flex_acl_flex_action_t()
        action2.type = SX_FLEX_ACL_ACTION_HASH
        action2.fields.action_hash.command = SX_ACL_ACTION_HASH_COMMAND_XOR
        action2.fields.action_hash.type = SX_ACL_ACTION_HASH_TYPE_LAG
        action2.fields.action_hash.hash_value = 1
        action3 = sx_flex_acl_flex_action_t()
        action3.type = SX_FLEX_ACL_ACTION_PBS
        action3.fields.action_pbs.pbs_id = pbs_id

        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 0, action1)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 1, action2)
        sx_flex_acl_flex_action_t_arr_setitem(rule.action_list_p, 2, action3)
        rule.action_count = 3

        sx_flex_acl_flex_rule_t_arr_setitem(rule_arr, j, rule)
        sx_acl_rule_offset_t_arr_setitem(offsets_list, j, i)
        j = j + 1

    rc = sx_api_acl_flex_rules_set(handle,
                                   access,
                                   region_id,
                                   offsets_list,
                                   rule_arr,
                                   rules_cnt)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rule, rc = %d" % (rc)


def get_port_lag_hash_param(port):
    lag_hash_params_p = new_sx_lag_port_hash_params_t_p()
    hash_field_enable_list_cnt_p = new_uint32_t_p()
    hash_field_list_cnt_p = new_uint32_t_p()

    rc = sx_api_lag_port_hash_flow_params_get(
        handle, port, lag_hash_params_p, None, hash_field_enable_list_cnt_p, None, hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    field_enable_cnt = uint32_t_p_value(hash_field_enable_list_cnt_p)
    field_cnt = uint32_t_p_value(hash_field_list_cnt_p)

    # Get actual values based on count
    hash_field_list_p = new_sx_lag_hash_field_t_arr(field_cnt)
    hash_field_enable_list_p = new_sx_lag_hash_field_enable_t_arr(field_enable_cnt)

    rc = sx_api_lag_port_hash_flow_params_get(handle, port, lag_hash_params_p, hash_field_enable_list_p,
                                              hash_field_enable_list_cnt_p, hash_field_list_p,
                                              hash_field_list_cnt_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_get failed, rc = %d" % (rc)

    return lag_hash_params_p, hash_field_enable_list_p, field_enable_cnt, hash_field_list_p, field_cnt


def set_port_lag_hash_param(port, cmd):
    port_lag_hash_field_en_set_arr = new_sx_lag_hash_field_enable_t_arr(2)
    port_lag_hash_field_set_arr = new_sx_lag_hash_field_t_arr(4)
    port_lag_hash_type_params = sx_lag_port_hash_params_t()
    port_lag_hash_type_params_p = new_sx_lag_port_hash_params_t_p()
    num_hdr_enables_cnt = 2
    num_fields_cnt = 4

    port_lag_hash_type_params.is_lag_hash_symmetric = False
    port_lag_hash_type_params.lag_hash_type = SX_LAG_HASH_TYPE_CRC
    port_lag_hash_type_params.lag_seed = 0

    sx_lag_port_hash_params_t_p_assign(port_lag_hash_type_params_p,
                                       port_lag_hash_type_params)

    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 0,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP)
    sx_lag_hash_field_enable_t_arr_setitem(port_lag_hash_field_en_set_arr, 1,
                                           SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP)

    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 0, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_0)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 1, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_1)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 2, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_2)
    sx_lag_hash_field_t_arr_setitem(port_lag_hash_field_set_arr, 3, SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_3)

    rc = sx_api_lag_port_hash_flow_params_set(handle, cmd,
                                              port, port_lag_hash_type_params_p,
                                              port_lag_hash_field_en_set_arr, num_hdr_enables_cnt,
                                              port_lag_hash_field_set_arr, num_fields_cnt)
    assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)


def main():

    key_handle = key_create(FLEX_ACL_KEY_SIP)

    region_id = region_create(key_handle, 254)

    acl_id = acl_create(region_id, SX_ACL_DIRECTION_INGRESS)

    lag_id = lag_create([LAG_MEMBER1, LAG_MEMBER2, LAG_MEMBER3])

    pbs_id = pbs_create([lag_id])

    # Save port lag hash params for later de-configuration
    lag_hash_params_p, hash_field_enable_list_p, hash_field_enable_list_cnt, hash_field_list_p, hash_field_list_cnt = get_port_lag_hash_param(INGRESS_PORT)

    # Sets a new lag hash on port
    set_port_lag_hash_param(INGRESS_PORT, SX_ACCESS_CMD_SET)

    rule_set(region_id, pbs_id, 0, 179, SX_ACCESS_CMD_SET)

    rule_set(region_id, pbs_id, 180, 253, SX_ACCESS_CMD_SET)

    rc = sx_api_acl_port_bind_set(handle,
                                  SX_ACCESS_CMD_BIND,
                                  INGRESS_PORT,
                                  acl_id)
    assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

    if args.deinit:
        rc = sx_api_acl_port_bind_set(handle,
                                      SX_ACCESS_CMD_UNBIND,
                                      INGRESS_PORT,
                                      acl_id)
        assert rc == SX_STATUS_SUCCESS, "sx_api_acl_port_bind_set failed, rc = %d" % (rc)

        rule_set(region_id, pbs_id, 180, 253, SX_ACCESS_CMD_DELETE)

        rule_set(region_id, pbs_id, 0, 179, SX_ACCESS_CMD_DELETE)

        rc = sx_api_lag_port_hash_flow_params_set(handle, SX_ACCESS_CMD_SET,
                                                  INGRESS_PORT, lag_hash_params_p, hash_field_enable_list_p,
                                                  hash_field_enable_list_cnt, hash_field_list_p, hash_field_list_cnt)
        assert rc == SX_STATUS_SUCCESS, "sx_api_lag_port_hash_flow_params_set failed, rc = %d" % (rc)

        pbs_delete(pbs_id)

        lag_delete(lag_id, [LAG_MEMBER1, LAG_MEMBER2, LAG_MEMBER3])

        for port, ingr_filter in list(ports_ingr_filter_mode.items()):
            add_ports_to_vlan(1, {port: SX_UNTAGGED_MEMBER})
            ingr_filter_set(port, ingr_filter)

        acl_destroy(acl_id, region_id)

        region_destroy(region_id)

        key_destroy(key_handle)

    sx_api_close(handle)


if __name__ == "__main__":
    main()
