#!/usr/bin/env python
import time
import sys
import socket
import struct
import errno
import argparse
from python_sdk_api.sx_api import *
from test_infra_common import *

parser = argparse.ArgumentParser(description='sx_api_fdb_ignp_v3')
parser.add_argument('--force', action='store_true', help='Override prompt for SDK configuration change.')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')

args = parser.parse_args()

print_api_example_disclaimer()
if not args.force:
    print_modification_warning()

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)


######################################################
#    defines
######################################################
SPECTRUM_SWID = 0

port_list = mapPortAndInterfaces(handle)
PORT1 = port_list[0]
PORT2 = port_list[1]
PORT3 = port_list[2]
PORT4 = port_list[3]

DONT_CARE_RIF = 1001

""" ############################################################################################ """


def router_init():
    " This function init the router with following values. "
    general_params = sx_router_general_param_t()
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE
    router_resource = sx_router_resources_param_t()
    router_resource.max_virtual_routers_num = 12
    router_resource.max_router_interfaces = 400
    router_resource.min_ipv4_neighbor_entries = 10
    router_resource.min_ipv6_neighbor_entries = 10
    router_resource.min_ipv4_uc_route_entries = 10
    router_resource.min_ipv6_uc_route_entries = 10
    router_resource.min_ipv4_mc_route_entries = 0
    router_resource.min_ipv6_mc_route_entries = 0
    router_resource.max_ipv4_neighbor_entries = 1000
    router_resource.max_ipv6_neighbor_entries = 1000
    router_resource.max_ipv4_uc_route_entries = 1000
    router_resource.max_ipv6_uc_route_entries = 1000
    router_resource.max_ipv4_mc_route_entries = 0
    router_resource.max_ipv6_mc_route_entries = 0

    rc = sx_api_router_init_set(handle, general_params, router_resource)
    assert SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc, "Failed to init the router"
    print("Init the router, rc: %d" % (rc))


""" ############################################################################################ """


def print_router_counter(counter_id, counter_set):
    print("####################################################################")
    print("Router counter ID %d:\n" % (counter_id))

    print("Router ingress good unicast packets:             {:>10}".format(counter_set.router_ingress_good_unicast_packets))
    print("Router ingress good multicast packets:           {:>10}".format(counter_set.router_ingress_good_multicast_packets))
    print("Router ingress good unicast bytes:               {:>10}".format(counter_set.router_ingress_good_unicast_bytes))
    print("Router ingress good multicast bytes:             {:>10}".format(counter_set.router_ingress_good_multicast_bytes))
    print("Router egress good unicast packets:              {:>10}".format(counter_set.router_egress_good_unicast_packets))
    print("Router egress good multicast packets:            {:>10}".format(counter_set.router_egress_good_multicast_packets))
    print("Router egress good unicast bytes:                {:>10}".format(counter_set.router_egress_good_unicast_bytes))
    print("Router egress good multicast bytes:              {:>10}".format(counter_set.router_egress_good_multicast_bytes))
    print("Router ingress good broadcast packets:           {:>10}".format(counter_set.router_ingress_good_broadcast_packets))
    print("Router ingress discard packets:                  {:>10}".format(counter_set.router_ingress_discard_packets))
    print("Router ingress good broadcast bytes:             {:>10}".format(counter_set.router_ingress_good_broadcast_bytes))
    print("Router ingress discard bytes:                    {:>10}".format(counter_set.router_ingress_discard_bytes))
    print("Router egress good broadcast packets:            {:>10}".format(counter_set.router_egress_good_broadcast_packets))
    print("Router egress discard packets:                   {:>10}".format(counter_set.router_egress_discard_packets))
    print("Router egress good broadcast bytes:              {:>10}".format(counter_set.router_egress_good_broadcast_bytes))
    print("Router egress discard bytes:                     {:>10}".format(counter_set.router_egress_discard_bytes))
    print("####################################################################\n")


""" ############################################################################################ """


def create_router_counter():
    " This function creates router counter. "

    counter_p = new_sx_router_counter_id_t_p()

    rc = sx_api_router_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create router counter"

    counter_id = sx_router_counter_id_t_p_value(counter_p)
    print("Created router counter %d, rc: %d" % (counter_id, rc))

    return counter_id


""" ############################################################################################ """


def read_clear_router_counters(counter_id_arr):
    " This function reads and clears router counters. "

    for i, counter_id in enumerate(counter_id_arr):
        counter_set = sx_router_counter_set_t()
        counter_set_p = new_sx_router_counter_set_t_p()
        sx_router_counter_set_t_p_assign(counter_set_p, counter_set)

        rc = sx_api_router_counter_get(handle, SX_ACCESS_CMD_READ_CLEAR, counter_id, counter_set_p)
        assert SX_STATUS_SUCCESS == rc, "Failed to read and clear router counter %d" % (counter_id)

        counter_set = sx_router_counter_set_t_p_value(counter_set_p)

        print("Read and cleared router counter %d, rc: %d" % (counter_id, rc))
        print_router_counter(counter_id, counter_set)


""" ############################################################################################ """


def bind_router_counter(counter_id, rif):
    " This function binds router counter to rif. "

    rc = sx_api_router_interface_counter_bind_set(handle, SX_ACCESS_CMD_BIND, counter_id, rif)
    assert SX_STATUS_SUCCESS == rc, "Failed to bind router counter %d to rif %d" % (counter_id, rif)
    print("Binded router counter %d to rif %d, rc: %d" % (counter_id, rif, rc))


""" ############################################################################################ """


def add_mc_route(handle, vrid, mc_route_key, mc_route_attr, mc_route_data):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    mc_route_attr_p = new_sx_mc_route_attributes_t_p()
    sx_mc_route_attributes_t_p_assign(mc_route_attr_p, mc_route_attr)

    mc_route_data_p = new_sx_mc_route_data_t_p()
    sx_mc_route_data_t_p_assign(mc_route_data_p, mc_route_data)

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_ADD,
                                    vrid,
                                    mc_route_key_p,
                                    mc_route_attr_p,
                                    mc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to add MC route to VRID %d, rc: %d" % (vrid, rc)


#    print "Added MC route to VRID %d" % (vrid)
""" ############################################################################################ """


def delete_mc_route(vrid, mc_route_key):
    mc_route_key_p = new_sx_mc_route_key_t_p()
    sx_mc_route_key_t_p_assign(mc_route_key_p, mc_route_key)

    rc = sx_api_router_mc_route_set(handle,
                                    SX_ACCESS_CMD_DELETE,
                                    vrid,
                                    mc_route_key_p,
                                    None,
                                    None)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete MC route from VRID %d, rc: %d" % (vrid, rc)
    print("Deleted MC route from VRID %d" % (vrid))


def router_deinit():
    " This function deinit the router. "

    rc = sx_api_router_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "Failed to deinit router"
    print("Deinit router, rc: %d" % (rc))


""" ############################################################################################ """


def create_vrid():
    " This function creates vrid. "

    router_attr = sx_router_attributes_t()
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP

    vrid_p = new_sx_router_id_t_p()
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_ADD, router_attr, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create VRID"

    vrid = sx_router_id_t_p_value(vrid_p)
    print("Created VRID: %d, rc: %d " % (vrid, rc))

    return vrid


""" ############################################################################################ """


def make_sx_ip_prefix_v4(addr, mask):
    " This function creates ipv4 sx_api_ip_prefix struct with given parametrs. "

    ip_prefix = sx_ip_prefix_t()
    ip_prefix.version = SX_IP_VERSION_IPV4
    ip_prefix.prefix.ipv4.addr.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    ip_prefix.prefix.ipv4.mask.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, mask))[0]
    return ip_prefix


""" ############################################################################################ """


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]

    return ip_addr


""" ############################################################################################ """


def make_sx_ip_addr_v6(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV6
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET6, addr))[0]

    return ip_addr


""" ############################################################################################ """


def create_flow_counter(counter_type=SX_FLOW_COUNTER_TYPE_PACKETS):
    " This function creates a flow counter. "

    counter_p = new_sx_flow_counter_id_t_p()

    rc = sx_api_flow_counter_set(handle, SX_ACCESS_CMD_CREATE, counter_type, counter_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create flow counter"

    counter_id = sx_flow_counter_id_t_p_value(counter_p)

    print("Created flow counter %d, rc: %d" % (counter_id, rc))

    return counter_id


""" ############################################################################################ """


def make_mc_container_attributes(fid=1):

    mc_container_attribute = sx_mc_container_attributes_t()

    mc_container_attribute.min_mtu = 128
    mc_container_attribute.fid = fid
    mc_container_attribute.type = SX_MC_CONTAINER_TYPE_BRIDGE_MC

    return mc_container_attribute


""" ############################################################################################ """


def add_to_next_hop_arr(next_hop, next_hop_arr, next_hop_cnt_p):
    " This function adds next_hop to given next_hop_arr. "
    next_hop_cnt = uint32_t_p_value(next_hop_cnt_p)
    next_hop_arr_new = new_sx_mc_next_hop_t_arr(next_hop_cnt + 1)
    for i in range(next_hop_cnt):
        old_next_hop = sx_mc_next_hop_t_arr_getitem(next_hop_arr, i)
        sx_mc_next_hop_t_arr_setitem(next_hop_arr_new, i, old_next_hop)
    sx_mc_next_hop_t_arr_setitem(next_hop_arr_new, next_hop_cnt, next_hop)
    uint32_t_p_assign(next_hop_cnt_p, next_hop_cnt + 1)
    return next_hop_arr_new


""" ############################################################################################ """


def create_next_hops_arr(ports_list=[]):
    """
    This function creates a next hops list
    """
    next_hop_arr = new_sx_next_hop_t_arr(0)
    next_hop_cnt_p = new_uint32_t_p()
    uint32_t_p_assign(next_hop_cnt_p, 0)
    for port in ports_list:
        sx_mc_next_hop = sx_mc_next_hop_t()
        sx_mc_next_hop.type = SX_MC_NEXT_HOP_TYPE_LOG_PORT
        sx_mc_next_hop.data.log_port = port

        next_hop_arr = add_to_next_hop_arr(sx_mc_next_hop, next_hop_arr, next_hop_cnt_p)
    return next_hop_arr, uint32_t_p_value(next_hop_cnt_p)


""" ############################################################################################ """


def mc_container_create(ports_list, fid=0):
    mcc_attr = make_mc_container_attributes(fid)
    mcc_attr_p = new_sx_mc_container_attributes_t_p()

    sx_mc_container_attributes_t_p_assign(mcc_attr_p, mcc_attr)
    mc_container_id_p = new_sx_mc_container_id_t_p()

    sx_mc_next_hop_arr, next_hop_cnt = create_next_hops_arr(ports_list)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_CREATE, mc_container_id_p, sx_mc_next_hop_arr, next_hop_cnt, mcc_attr_p)
    mc_container_id = sx_mc_container_id_t_p_value(mc_container_id_p)
    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to create mc_container, rc: %d" % (rc)

    return mc_container_id


""" ############################################################################################ """


def mc_container_destroy(mc_container_id):
    mcc_attr_p = new_sx_mc_container_attributes_t_p()
    sx_mc_next_hop_p = new_sx_mc_next_hop_t_p()

    mc_container_id_p = new_sx_mc_container_id_t_p()
    sx_mc_container_id_t_p_assign(mc_container_id_p, mc_container_id)

    rc = sx_api_mc_container_set(handle, SX_ACCESS_CMD_DESTROY, mc_container_id_p, sx_mc_next_hop_p, 0, mcc_attr_p)

    print(("sx_api_mc_container_set  [rc = %d] " % (rc)))
    assert SX_STATUS_SUCCESS == rc, "Failed to destroy mc_container, rc: %d" % (rc)
    return rc


""" ############################################################################################ """


def mc_fdb_ip_key_create(sip, dip, fid=0):
    mc_fdb_mc_ip_key = sx_fdb_mc_ip_key_t()
    mc_fdb_mc_ip_key.destination_ip_addr = dip
    mc_fdb_mc_ip_key.source_ip_addr = sip
    mc_fdb_mc_ip_key.fid = fid
    return mc_fdb_mc_ip_key


""" ############################################################################################ """


def fdb_mc_ip_addr_group_set(cmd, sip, dip, fid, mc_container=0, action=SX_FDB_ACTION_FORWARD):
    mc_fdb_mc_ip_key = mc_fdb_ip_key_create(sip, dip, fid)
    mc_fdb_mc_ip_key_p = new_sx_fdb_mc_ip_key_t_p()
    sx_fdb_mc_ip_key_t_p_assign(mc_fdb_mc_ip_key_p, mc_fdb_mc_ip_key)

    sx_fdb_mc_ip_action_p = new_sx_fdb_mc_ip_action_t_p()
    sx_fdb_mc_ip_action = sx_fdb_mc_ip_action_t()

    sx_fdb_mc_ip_action.action = SX_FDB_ACTION_FORWARD
    sx_fdb_mc_ip_action.container_id = mc_container
    sx_fdb_mc_ip_action.trap_attr.prio = 1

    sx_fdb_mc_ip_action_t_p_assign(sx_fdb_mc_ip_action_p, sx_fdb_mc_ip_action)

    return sx_api_fdb_mc_ip_addr_group_set(handle, cmd, mc_fdb_mc_ip_key_p, sx_fdb_mc_ip_action_p)


""" ############################################################################################ """


def fdb_mc_ip_addr_group_get(sip, dip, fid):

    mc_fdb_mc_ip_key = mc_fdb_ip_key_create(sip, dip, fid)
    mc_fdb_mc_ip_key_p = new_sx_fdb_mc_ip_key_t_p()
    sx_fdb_mc_ip_key_t_p_assign(mc_fdb_mc_ip_key_p, mc_fdb_mc_ip_key)

    sx_fdb_mc_ip_action = sx_fdb_mc_ip_action_t()
    sx_fdb_mc_ip_action_p = new_sx_fdb_mc_ip_action_t_p()

    rc = sx_api_fdb_mc_ip_addr_group_get(handle, mc_fdb_mc_ip_key_p, sx_fdb_mc_ip_action_p)

    sx_fdb_mc_ip_action = sx_fdb_mc_ip_action_t_p_value(sx_fdb_mc_ip_action_p)

    return rc, sx_fdb_mc_ip_action


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


""" ############################################################################################ """


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_vlan_ports_set ADD"

    print("Added %s port to vlan %d, rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))


""" ############################################################################################ """


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to sx_api_vlan_ports_set DELETE"

    print("Removed %s port from vlan %d , rc: %d" % (str(list(ports_dict.keys())), vlan_id, rc))
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def delete_rif(vrid, rif):
    " This function deletes rif from given vrid. "

    rif_p = new_sx_router_interface_t_p()
    sx_router_interface_t_p_assign(rif_p, rif)
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_DELETE, vrid, None, None, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete RIF %d" % (rif)
    print(("Deleted RIF: %d, rc: %d " % (rif, rc)))


""" ############################################################################################ """


def create_vlan_rif(vrid, vlan, mac_addr, mtu=1500):
    " This function creates vlan rif with given parametrs. "

    ifc_param = sx_router_interface_param_t()
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN
    ifc_param.ifc.vlan.swid = SPECTRUM_SWID
    ifc_param.ifc.vlan.vlan = vlan

    ifc_attr = sx_interface_attributes_t()
    ifc_attr.mac_addr = mac_addr
    ifc_attr.mtu = mtu
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP
    ifc_attr.multicast_ttl_threshold = 0
    ifc_attr.loopback_enable = False

    rif_p = new_sx_router_interface_t_p()
    rc = sx_api_router_interface_set(handle, SX_ACCESS_CMD_ADD, vrid, ifc_param, ifc_attr, rif_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create vlan rif"

    rif = sx_router_interface_t_p_value(rif_p)
    print("Created vlan rif: %d, rc: %d " % (rif, rc))

    return rif


""" ############################################################################################ """


def set_rif_state_ipv4(rif, enable=True):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = True
    rif_state.ipv6_enable = False
    rif_state.ipv4_mc_enable = True
    rif_state.ipv6_mc_enable = False
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


""" ############################################################################################ """


def set_rif_state(handle, rif,
                  ipv4_enable=SX_ROUTER_ENABLE_STATE_ENABLE,
                  ipv6_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                  ipv4_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE,
                  ipv6_mc_enable=SX_ROUTER_ENABLE_STATE_DISABLE):
    " This function sets given rif ipv_4_uc state. "

    rif_state = sx_router_interface_state_t()
    rif_state.ipv4_enable = ipv4_enable
    rif_state.ipv6_enable = ipv6_enable
    rif_state.ipv4_mc_enable = ipv4_mc_enable
    rif_state.ipv6_mc_enable = ipv6_mc_enable
    rif_state_p = new_sx_router_interface_state_t_p()
    sx_router_interface_state_t_p_assign(rif_state_p, rif_state)

    rc = sx_api_router_interface_state_set(handle, rif, rif_state_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to set rif state of rif %d" % (rif)

    print("Set rif %d state, rc: %d " % (rif, rc))


""" ############################################################################################ """


def make_local_route_data(rif, action=SX_ROUTER_ACTION_FORWARD):
    """
            This function creates sx_uc_route_data struct for local route with given parametrs.
            Action is optional.
    """

    uc_route_data = sx_uc_route_data_t()
    uc_route_data.action = action
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL
    uc_route_data.uc_route_param.local_egress_rif = rif
    return uc_route_data


""" ############################################################################################ """


def create_local_route(vrid, rif, addr, mask):
    " This function creates local route with given parametrs. "

    ip_prefix = make_sx_ip_prefix_v4(addr, mask)
    ip_prefix_p = new_sx_ip_prefix_t_p()
    sx_ip_prefix_t_p_assign(ip_prefix_p, ip_prefix)

    uc_route_data = make_local_route_data(rif)
    uc_route_data_p = new_sx_uc_route_data_t_p()
    sx_uc_route_data_t_p_assign(uc_route_data_p, uc_route_data)

    rc = sx_api_router_uc_route_set(handle, SX_ACCESS_CMD_ADD, vrid, ip_prefix_p, uc_route_data_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to create local route"

    print("Created local route for rif %d, rc: %d " % (rif, rc))


""" ############################################################################################ """


def prepare_port(vrid, port, vlan=1, mac=ether_addr(0x0, 0x1, 0x3, 0x4, 0x5, 0x7)):
    remove_ports_from_vlan(1, {port: SX_TAGGED_MEMBER})
    add_ports_to_vlan(vlan, {port: SX_TAGGED_MEMBER})
    port_rif = create_vlan_rif(vrid, vlan, mac, 1500)
    set_rif_state_ipv4(port_rif)

    return port_rif


""" ############################################################################################ """


def add_neigh(rif, addr, mac_addr):
    " This function adds neighbor to rif with given parametrs. "
    ip_addr = make_sx_ip_addr_v4(addr)

    neigh_data = sx_neigh_data_t()
    neigh_data.action = SX_ROUTER_ACTION_FORWARD
    neigh_data.mac_addr = mac_addr
    neigh_data.rif = rif

    rc = sx_api_router_neigh_set(handle, SX_ACCESS_CMD_ADD, rif, ip_addr, neigh_data)
    assert SX_STATUS_SUCCESS == rc, "Failed to add neigh to rif %d" % (rif)

    print("Added neighbor to rif %d, rc: %d" % (rif, rc))


def delete_vrid(vrid):
    " This function deletes vrid. "

    vrid_p = new_sx_router_id_t_p()
    sx_router_id_t_p_assign(vrid_p, vrid)
    rc = sx_api_router_set(handle, SX_ACCESS_CMD_DELETE, None, vrid_p)
    assert SX_STATUS_SUCCESS == rc, "Failed to delete VRID %d" % (vrid)
    print(("Deleted VRID: %d, rc: %d " % (vrid, rc)))


""" ############################################################################################ """


def print_group_data_db(index, group_data):
    print("Index = %d" % (index))
    print("Group action = %d" % (group_data.action))
    print("Group Cont ID = %d" % (group_data.container_id))
    print("Group Trap Prio = %d" % (group_data.trap_attr.prio))
    print("=====================" % ())


""" ############################################################################################ """


def vport_add_delete(cmd, log_port, vid, log_vport_p):
    """ VIRTUAL PORT CREATE AND DELETE """

    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------")
    else:
        print("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------")

    print(("log port =0x%x " % (log_port)))
    print(("vlan id=%d " % (vid)))

    rc = sx_api_port_vport_set(handle, cmd, log_port, vid, log_vport_p)
    print(("sx_api_port_vport_set [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_create_delete(cmd, bridge_id_p):
    """ ############################################################################################ """
    """ BRIDGE CREATE/DELETE"""

    if cmd == SX_ACCESS_CMD_CREATE:
        print("--------------- BRIDGE CREATE ------------------------------")
    else:
        print("--------------- BRIDGE DELETE ------------------------------")

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def bridge_vport_add_delete(cmd, bridge_id, log_port):
    """ ADD/DELETE VPORT TO/FROM BRIDGE """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VPORT TO BRIDGE  ------------------------------")
    else:
        print("--------------- DELETE VPORT FROM BRIDGE  ------------------------------")

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port)
    print(("sx_api_bridge_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def port_state_set(log_port, admin_state):
    """ PORT STATE SET """
    print("--------------- PORT STATE SET  ------------------------------")

    rc = sx_api_port_state_set(handle, log_port, admin_state)
    print(("sx_api_port_state_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)
    print(("log port = 0x%x, admin state = %d" % (log_port, admin_state)))


""" ############################################################################################ """


def vlan_ports_add_delete(cmd, vid, vlan_port_list_p, port_cnt):
    """ ADD/DELETE VLAN MEMBER PORTS """
    if cmd == SX_ACCESS_CMD_ADD:
        print("--------------- ADD VLAN MEMBER PORTS  ------------------------------")
    else:
        print("--------------- DELETE VLAN MEMBER PORTS  ------------------------------")

    rc = sx_api_vlan_ports_set(handle, cmd, SPECTRUM_SWID, vid, vlan_port_list_p, port_cnt)
    print(("sx_api_vlan_ports_set  [rc=%d] " % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


""" ############################################################################################ """


def allocate_vlan_port_list(ports_dict):
    " This function allocates sx_vlan_ports_t array, out of port dictionary. "

    port_list = new_sx_vlan_ports_t_arr(len(ports_dict))
    for i, port_id in enumerate(ports_dict.keys()):
        vlan_port = sx_vlan_ports_t()
        vlan_port.log_port = port_id
        vlan_port.is_untagged = ports_dict[port_id]
        sx_vlan_ports_t_arr_setitem(port_list, i, vlan_port)
    return port_list


""" ############################################################################################ """


def add_ports_to_vlan(vlan_id, ports_dict):
    " This function adds speificed ports_dict into target vlan. "
    print("--------------- ADD PORT VLAN MEMBERSHIP  ------------------------------")

    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to add port %s to vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Added port 0x%x to vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


def remove_ports_from_vlan(vlan_id, ports_dict):
    " This function removes ports from given vlan. "
    print("--------------- REMOVE PORT VLAN MEMBERSHIP  ------------------------------")
    port_list = allocate_vlan_port_list(ports_dict)
    rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, vlan_id, port_list, len(ports_dict))
    assert SX_STATUS_SUCCESS == rc, "Failed to remove ports %s from vlan %d" % (str(list(ports_dict.keys())), vlan_id)
    for port in ports_dict:
        print("Removed port 0x%x from vlan %d, rc: %d" % (port, vlan_id, rc))


""" ############################################################################################ """


######################################################
#    main
######################################################

# ERIF bound flow - group add --> RIF create
# def main():
#
#     sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)
#
#     # ingress port
#     i_port = PORT1
#
#     igmp_port_list = [PORT2]
#     erif_port_list = [PORT3]
#     erif_port_list_2 = [PORT4]
#
#     sip = []
#     dip = []
#
#     # 1-st group key
#     vlan_1 = 3
#     dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
#     sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
#     # 2-st group key
#     vlan_2 = 100
#     dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
#     sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
#     vlan_3 = 200
#     dip.append(make_sx_ip_prefix_v4("224.2.2.3", "255.255.255.0"))
#     sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
#     flow_handling = 1
#     if (flow_handling == 1 or flow_handling == 3):
#         #     # set multicast flood  mode
#         #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_2, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_2, urmc_flood_mode, rc))

#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#         mc_container_id = mc_container_create(igmp_port_list, vlan_1)
#         erif_container_id = mc_container_create(erif_port_list, vlan_2)
#         erif_container_id_2 = mc_container_create(erif_port_list_2, vlan_3)
#         print "mc_container_create - Success"
#
#         # create vlan_1 igmpv3 group
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[0], dip[0], vlan_1, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#         #create vlan_2 igmpv3 group
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[1], dip[1], vlan_2, erif_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#         # create vlan_3 igmpv3 group
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[2], dip[2], vlan_3, erif_container_id_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#
# ######## Create RIF - Vlan interface ###################
#         print "################### SET CONFIGURATION ####################"
#         # Initialize router
#         print "[LANDMARK] STARTED - ROUTER INIT"
#         router_init()
#         print "[LANDMARK] COMPLETED - ROUTER INIT"
#
#         # Create VRID that supports IPv4 and IPv6 MC
#         vrid = create_vrid()
#
#         # vlan init
#         add_ports_to_vlan(vlan_1, {PORT1: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT2: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT3: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT4: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_3, {PORT2: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_3, {PORT3: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_3, {PORT4: SX_TAGGED_MEMBER})
#
#         add_ports_to_vlan(vlan_1, {PORT2: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_1, {PORT3: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_1, {PORT4: SX_TAGGED_MEMBER})
#
#         # create vlan rif and vport rif
#         rif_arr = [None] * 3
#         rif_arr[0] = create_vlan_rif(vrid, vlan_1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07), 1500)
#         rif_arr[1] = create_vlan_rif(vrid, vlan_2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08), 1500)
#         rif_arr[2] = create_vlan_rif(vrid, vlan_3, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08), 1500)
#
# #         import pdb
# #         pdb.set_trace()
#         # Enable IPv4 MC on each RIF
#         for rif in rif_arr:
#             set_rif_state(handle, rif,
#                           ipv4_enable=True,
#                           ipv6_enable=False,
#                           ipv4_mc_enable=True,
#                           ipv6_mc_enable=False)
#
#         erif_list = [rif_arr[1]]
#         erif_list_2 = [rif_arr[2]]
#
#         # 1) Create MC route (S = 0.0.0.0/0, G = 224.2.2.2/32),(S = ::/0, G = FF02:0:0:0:0:0:0:1/128)  with one egress RIF
#         mc_route_key_ipv4 = sx_api_mc_router.make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', '224.2.2.2', '255.255.255.255')
#         mc_route_attr = sx_api_mc_router.make_mc_route_attributes()
#         mc_route_data = sx_api_mc_router.make_mc_route_data(erif_list)
#         add_mc_route(handle, vrid, mc_route_key_ipv4, mc_route_attr, mc_route_data)
#
#         # 2) Create MC route (S = 0.0.0.0/0, G = 224.2.2.2/32),(S = ::/0, G = FF02:0:0:0:0:0:0:1/128)  with one egress RIF
#         mc_route_key_ipv4_2 = sx_api_mc_router.make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', '224.2.2.3', '255.255.255.255')
#         mc_route_attr = sx_api_mc_router.make_mc_route_attributes()
#         mc_route_data = sx_api_mc_router.make_mc_route_data(erif_list_2)
#         add_mc_route(handle, vrid, mc_route_key_ipv4_2, mc_route_attr, mc_route_data)
##################  END  RIF configuration  ########################

#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"

#     # set multicast flood  mode
#         urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         #urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_2, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_2, urmc_flood_mode, rc))

# ######### DELETE ##########
#     if (flow_handling == 2 or flow_handling == 3):
#         print "################### DELETE CONFIGURATION ####################"
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[0], dip[0], vlan_1)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set DELETE group - Success"
#
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[1], dip[1], vlan_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set DELETE group - Success"
#
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[2], dip[2], vlan_3)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set DELETE group - Success"
#
# #         mc_container_destroy(mc_container_id);
# #         print "mc_container_destroy - Success"
# #         mc_container_destroy(erif_container_id);
# #         print "mc_container_destroy - Success"
#
#         # disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         # disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         # disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         if(flow_handling == 3):
#             print "################### DELETE ROUTER CONFIGURATION ####################"
#             # delete rif
#             delete_mc_route(vrid, mc_route_key_ipv4)
#             delete_mc_route(vrid, mc_route_key_ipv4_2)
#             delete_rif(vrid, rif_arr[0])
#             delete_rif(vrid, rif_arr[1])
#             delete_rif(vrid, rif_arr[2])
#             delete_vrid(vrid)
#             router_deinit()
#
#     if (flow_handling == 4):
#         # Enable ipv4 MC on RIF
#         print "----> ENABLE RIF ipv4 MC"
#         set_rif_state(handle, 0,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=True,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 5):
#         # Disable ipv4 MC on RIF
#         print "----> DISABLE RIF ipv4 MC"
#         set_rif_state(handle, 0,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=False,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 6):
#         # Enable ipv4 MC on RIF
#         print "----> ENABLE RIF ipv4 MC"
#         set_rif_state(handle, 1,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=True,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 7):
#         # Disable ipv4 MC on RIF
#         print "----> DISABLE RIF ipv4 MC"
#         set_rif_state(handle, 1,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=False,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 8):
#         # Enable ipv6 MC on RIF
#         print "----> ENABLE RIF ipv6 MC"
#         set_rif_state(handle, 1,
#                       ipv4_enable=True,
#                       ipv6_enable=True,
#                       ipv4_mc_enable=False,
#                       ipv6_mc_enable=True)
#
#     if (flow_handling == 9):
#         # Disable ipv6 MC on RIF
#         print "----> DISABLE RIF ipv6 MC"
#         set_rif_state(handle, 1,
#                       ipv4_enable=True,
#                       ipv6_enable=True,
#                       ipv4_mc_enable=False,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 10):
#         # Enable ipv4 MC on RIF
#         print "----> ENABLE RIF ipv4 MC"
#         set_rif_state(handle, 2,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=True,
#                       ipv6_mc_enable=False)
#
#     if (flow_handling == 11):
#         # Disable ipv4 MC on RIF
#         print "----> DISABLE RIF ipv4 MC"
#         set_rif_state(handle, 2,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=False,
#                       ipv6_mc_enable=False)
#
#
# #     #enable igmp on fid
# #     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
# #     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
# #     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
# if __name__ == "__main__":
#     main()

# """ ############################################################################################ """
# sx_api_close(handle)
# """ ############################################################################################ """

# ERIF bound flow - RIF create --> group add
# def main():
#
#     sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)
#
#     # ingress port
#     i_port = PORT1
#
#     igmp_port_list = [PORT2]
#     erif_port_list = [PORT3]
#
#     sip = []
#     dip = []
#
#     # 1-st group key
#     vlan_1 = 3
#     dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
#     sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
#     # 2-st group key
#     vlan_2 = 100
#     dip.append(make_sx_ip_prefix_v4("224.2.2.2", "255.255.255.0"))
#     sip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
# ######## Create RIF - Vlan interface ###################
#     flow_handling = 1
#     if (flow_handling == 1 or flow_handling == 3):
#         print "################### SET CONFIGURATION ####################"
#         # Initialize router
#         print "[LANDMARK] STARTED - ROUTER INIT"
#         router_init()
#         print "[LANDMARK] COMPLETED - ROUTER INIT"
#
#         # Create VRID that supports IPv4 and IPv6 MC
#         vrid = create_vrid()
#
#         # vlan init
#         add_ports_to_vlan(vlan_1, {PORT1: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT2: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT3: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_2, {PORT4: SX_TAGGED_MEMBER})
#
#         add_ports_to_vlan(vlan_1, {PORT2: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_1, {PORT3: SX_TAGGED_MEMBER})
#         add_ports_to_vlan(vlan_1, {PORT4: SX_TAGGED_MEMBER})
#
#         # create vlan rif and vport rif
#         rif_arr = [None] * 2
#         rif_arr[0] = create_vlan_rif(vrid, vlan_1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07), 1500)
#         rif_arr[1] = create_vlan_rif(vrid, vlan_2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08), 1500)
#
#         # Enable IPv4 MC on each RIF
#         for rif in rif_arr:
#             set_rif_state(handle, rif,
#                           ipv4_enable=True,
#                           ipv6_enable=False,
#                           ipv4_mc_enable=True,
#                           ipv6_mc_enable=False)
#
#         erif_list = [rif_arr[1]]
#
#         # Create MC route (S = 0.0.0.0/0, G = 224.2.2.2/32),(S = ::/0, G = FF02:0:0:0:0:0:0:1/128)  with one egress RIF
#         mc_route_key_ipv4 = sx_api_mc_router.make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', '224.2.2.2', '255.255.255.255')
#         mc_route_attr = sx_api_mc_router.make_mc_route_attributes()
#         mc_route_data = sx_api_mc_router.make_mc_route_data(erif_list)
#         add_mc_route(handle, vrid, mc_route_key_ipv4, mc_route_attr, mc_route_data)

#         #Router counters - create and bind
#         router_counter_arr = [None] * 2
#         router_counter_arr[0] = create_router_counter()
#         router_counter_arr[1] = create_router_counter()
#         bind_router_counter(router_counter_arr[0], rif_arr[0])
#         bind_router_counter(router_counter_arr[1], rif_arr[1])

##################  END  RIF configuration  ########################
#         print "----START sleep"
#         time.sleep(1)
#         print "----END sleep"

#         import pdb
#         pdb.set_trace()

#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"

#         # Add port to prune list
#         port_cnt = 1
#         set_portlist = []
#         port_list = new_sx_port_log_id_t_arr(port_cnt)
#         sx_port_log_id_t_arr_setitem(port_list, 0, PORT3)
#         set_portlist.append(PORT3)
#         rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_1, port_list, port_cnt)
#         print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  vlan id: %d, rc: %d " % (vlan_1, rc))
#
#         #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))

#         # Add port to prune list
#         port_cnt = 1
#         set_portlist = []
#         port_list = new_sx_port_log_id_t_arr(port_cnt)
#         sx_port_log_id_t_arr_setitem(port_list, 0, PORT3)
#         set_portlist.append(PORT3)
#         rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_1, port_list, port_cnt)
#         print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  vlan id: %d, rc: %d " % (vlan_1, rc))

#         # Add LG to prune list
#         # Create LAG
#         swid = 0
#         lag_id_p = new_sx_port_log_id_t_p()
#         rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_CREATE, swid, lag_id_p, None, 0)
#         lag_id = sx_port_log_id_t_p_value(lag_id_p)
#         print ("sx_api_lag_port_group_set CREATE lag_id 0x%x , rc %d " % (lag_id, rc))
#
#         rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE)
#         print ("sx_api_vlan_port_ingr_filter_set SX_INGR_FILTER_ENABLE lag_id 0x%x , rc %d " % (lag_id, rc))
#
#         # Add LAG + port3 to prune list
#         port_cnt = 2
#         set_portlist = []
#         port_list = new_sx_port_log_id_t_arr(port_cnt)
#         sx_port_log_id_t_arr_setitem(port_list, 0, lag_id)
#         sx_port_log_id_t_arr_setitem(port_list, 1, PORT3)
#         set_portlist.append(lag_id)
#         set_portlist.append(PORT3)
#         rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_1, port_list, port_cnt)
#         print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  vlan id: %d, rc: %d " % (vlan_1, rc))
#
#         # Add LAG to vlan
#         add_ports_to_vlan(vlan_1, {lag_id: SX_TAGGED_MEMBER})

#         # Add port to LAG
#         swid = 0
#         port_list = new_sx_port_log_id_t_arr(2)
#         sx_port_log_id_t_arr_setitem(port_list, 0, PORT1)
#         sx_port_log_id_t_arr_setitem(port_list, 1, PORT2)
#         rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_ADD, swid, lag_id_p, port_list, 2)
#         print ("sx_api_lag_port_group_set ADD ports 0x%x, 0x%x to lag_id 0x%x , rc %d " % (PORT1, PORT2, lag_id, rc))
#
#         # Disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#         # Disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         # Enables collection on a specific port in a LAG port.
#         log_port = PORT2
#         col_state = COLLECTOR_ENABLE
#         rc = sx_api_lag_port_collector_set(handle, lag_id, log_port, col_state)
#         print ("sx_api_lag_port_collector_set lag_id 0x%x , port 0x%x, state: %d,  rc %d " % (lag_id, log_port, col_state, rc))
#
#         # Remove port from LAG
#         swid = 0
#         port_list = new_sx_port_log_id_t_arr(1)
#         sx_port_log_id_t_arr_setitem(port_list, 0, PORT1)
#         rc = sx_api_lag_port_group_set(handle, SX_ACCESS_CMD_DELETE, swid, lag_id_p, port_list, 1)
#         print ("sx_api_lag_port_group_set DELETE ports 0x%x from lag_id 0x%x , rc %d " % (PORT1, lag_id, rc))
#
#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"

#         import pdb
#         pdb.set_trace()

#         # Disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"

#         urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         #urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))

#         urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         #urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))


#         #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#         urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#         rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#         print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))


#
#         #enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#         print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#         mc_container_id = mc_container_create(igmp_port_list, vlan_1)
#         erif_container_id = mc_container_create(erif_port_list, vlan_2)
#         print "mc_container_create - Success"
#
#         #create vlan_1 igmpv3 group
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[0], dip[0], vlan_1, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#         #create vlan_2 igmpv3 group
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[1], dip[1], vlan_2, erif_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#         #get igmp_v3 group
#         rc , sx_fdb_mc_ip_action = fdb_mc_ip_addr_group_get(sip[0], dip[0], vlan_1)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group get"
#         print "fdb_mc_ip_addr_group_get first group - Success"
#
#         #get igmp_v3 group
#         rc , sx_fdb_mc_ip_action = fdb_mc_ip_addr_group_get(sip[1], dip[1], vlan_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group get"
#         print "fdb_mc_ip_addr_group_get first group - Success"
#
#     if (flow_handling == 4):
#         #read and clear router counters
#         router_counter_arr = [None] * 2
#         router_counter_arr[0]=4095
#         router_counter_arr[1]=4096
#         read_clear_router_counters(router_counter_arr)


######### DELETE ##########
#     if (flow_handling == 2 or flow_handling == 3):
#         print "################### DELETE CONFIGURATION ####################"
#
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[0], dip[0], vlan_1)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set DELETE group - Success"
#
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[1], dip[1], vlan_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set DELETE group - Success"
#
# #         mc_container_destroy(mc_container_id);
# #         print "mc_container_destroy - Success"
# #         mc_container_destroy(erif_container_id);
# #         print "mc_container_destroy - Success"
#
#         # disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         # disable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2, SX_FDB_IGMPV3_STATE_DISABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#         print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#         if(flow_handling == 3):
#             print "################### DELETE ROUTER CONFIGURATION ####################"
#             # delete rif
#             delete_mc_route(vrid, mc_route_key_ipv4)
#             delete_rif(vrid, rif_arr[0])
#             delete_rif(vrid, rif_arr[1])
#             delete_vrid(vrid)
#             router_deinit()
#
#
# if __name__ == "__main__":
#     main()
#
# """ ############################################################################################ """
# sx_api_close(handle)
# """ ############################################################################################ """


###### Standard flow #######
# def main():
#
#     print "###### Standard flow #######"
#     print "[LANDMARK] STARTED - ROUTER INIT"
#     router_init()
#     print "[LANDMARK] COMPLETED - ROUTER INIT"
#
#     sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)
#
#     # ingress port
#     i_port = PORT1
#
#     igmp_port_list = [PORT2, PORT3, PORT4]
#
#     sip = []
#     dip = []
#
#     # 1-st group key
#     vlan_1 = 4
#     sip.append(make_sx_ip_prefix_v4("192.168.0.2", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.2", "255.255.255.0"))
#
#     # 2-st group key
#     vlan_2 = 5
#     vlan_3 = 33
#     vlan_4 = 34
#     vlan_5 = 35
#     vlan_6 = 36
#     vlan_7 = 37
#     vlan_8 = 38
#     vlan_9 = 39
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.3", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.4", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.5", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.6", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.7", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.8", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.9", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.10", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.11", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.12", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.13", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.14", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.15", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.16", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.17", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.18", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.19", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.20", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.21", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.22", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.23", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.24", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.25", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.26", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.27", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.28", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.29", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     """ ############################################################################################ """
#     ## BRIDGE & VPORT SET ##
#     # create a vport for port 0x10001 and vlan 20
#     log_vport_p_1 = new_sx_port_log_id_t_p()
#     vport_add_delete(SX_ACCESS_CMD_ADD, PORT1, vlan_1, log_vport_p_1)
#     log_vport_1 = sx_port_log_id_t_p_value(log_vport_p_1)
#     print("virtula port 0x%x created" % (log_vport_1))
#     """ ############################################################################################ """
#
#     # create a vport for port 0x10003 and vlan 30
#     log_vport_p_2 = new_sx_port_log_id_t_p()
#     vport_add_delete(SX_ACCESS_CMD_ADD, PORT2, vlan_1, log_vport_p_2)
#     log_vport_2 = sx_port_log_id_t_p_value(log_vport_p_2)
#     print("virtual port 0x%x created" % (log_vport_2))
#     """ ############################################################################################ """
#
#     # create bridge
#     bridge_id_p = new_sx_bridge_id_t_p()
#     bridge_create_delete(SX_ACCESS_CMD_CREATE, bridge_id_p)
#     bridge_id = sx_bridge_id_t_p_value(bridge_id_p)
#     print("bridge %d created" % (bridge_id))
#     """ ############################################################################################ """
#
#     # add log_vport_1 to bridge
#     bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_1)
#     print ("virtual port 0x%x added to bridge %d " % (log_vport_1, bridge_id))
#     """ ############################################################################################ """
#
#     # add log_vport_2 to bridge
#     bridge_vport_add_delete(SX_ACCESS_CMD_ADD, bridge_id, log_vport_2)
#     print ("virtual port 0x%x added to bridge %d " % (log_vport_2, bridge_id))
#     """ ############################################################################################ """
#
#     # set port state to UP
#     port_state_set(log_vport_1, SX_PORT_ADMIN_STATUS_UP)
#     """ ############################################################################################ """
#
#     # set port state to UP
#     port_state_set(log_vport_2, SX_PORT_ADMIN_STATUS_UP)
#     """ ############################################################################################ """
#
#     #########################################################################################
#
#
#     ##VLAN - PRUNE LIST
#     # set multicast flood ports for vlan
#     total_dev_ports = 64
#     port_attributes_list = new_sx_port_attributes_t_arr(total_dev_ports)
#     dev_portcount_p = new_uint32_t_p()
#     uint32_t_p_assign(dev_portcount_p, total_dev_ports)
#     rc = sx_api_port_device_get(handle, 1 , 0, port_attributes_list,  dev_portcount_p)
#
#     port_cnt = 2
#     set_portlist = []
#     port_list = new_sx_port_log_id_t_arr(port_cnt)
#     log_port = sx_port_attributes_t_arr_getitem(port_attributes_list, 0).log_port
#     sx_port_log_id_t_arr_setitem(port_list, 0, log_port)
#     set_portlist.append(log_port)
#     log_port = sx_port_attributes_t_arr_getitem(port_attributes_list, 1).log_port
#     sx_port_log_id_t_arr_setitem(port_list, 1, log_port)
#     set_portlist.append(log_port)
#     rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_1, port_list, port_cnt)
#     print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  vlan id: %d, rc: %d " %(vlan_1, rc))
#
#      ## BRIDGE - PRUNE LIST
#     # set multicast flood ports for vlan
#     port_cnt = 2
#     set_portlist = []
#     port_list = new_sx_port_log_id_t_arr(port_cnt)
#     sx_port_log_id_t_arr_setitem(port_list, 0, log_vport_1)
#     sx_port_log_id_t_arr_setitem(port_list, 1, log_vport_2)
#     rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, bridge_id, port_list, port_cnt)
#     print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  bridge_id: %d, rc: %d " % (bridge_id, rc))
#     ####################################
#
#     ####################################
#     ## VLAN Create/ Destroy ##
#     swid = 0
#     vlan_id = vlan_1
#     #cmd = SX_ACCESS_CMD_ADD
#     cmd = SX_ACCESS_CMD_DELETE
#
#     vlan_list_p = new_sx_vlan_id_t_p()
#     sx_vlan_id_t_p_assign(vlan_list_p, vlan_id)
#
#      # add/delete VLAN
#      data_cnt_p = new_uint32_t_p()
#      uint32_t_p_assign(data_cnt_p, 1)
#      port_get_sftr 1 0 2 3 3
#      rc = sx_api_vlan_set(handle, cmd, swid, vlan_list_p, data_cnt_p)
#      if rc != SX_STATUS_SUCCESS:
#          print ("sx_api_port_vlan_set failed, rc=[%d], cmd=[%d] " % (rc, cmd))
#          sys.exit(rc)
#      print ("## sx_api_port_vlan_set , rc=[%d], cmd=[%d] " % (rc, cmd))
#
#      time.sleep(3)
#      ###################################
#
#     # enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     # set multicast flood  mode
#     #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#     urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#     rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#     print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))
#
#     ##BRIDGE - PRUNE LIST
#     # set multicast flood ports for vlan
#     port_cnt = 1
#     set_portlist = []
#     port_list = new_sx_port_log_id_t_arr(port_cnt)
#     sx_port_log_id_t_arr_setitem(port_list, 0, log_vport_1)
#     sx_port_log_id_t_arr_setitem(port_list, 1, log_vport_2)
#     rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, bridge_id, port_list, port_cnt)
#     print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  bridge_id: %d, rc: %d " % (bridge_id, rc))
#
#     # VLAN - PRUNE LIST
#     # set multicast flood ports for vlan
#     port_cnt = 2
#     set_portlist = []
#     port_list = new_sx_port_log_id_t_arr(port_cnt)
#     sx_port_log_id_t_arr_setitem(port_list, 0, PORT3)
#     sx_port_log_id_t_arr_setitem(port_list, 1, PORT4)
#     rc = sx_api_fdb_unreg_mc_flood_ports_set(handle, 0, vlan_1, port_list, port_cnt)
#     print("sx_api_fdb_unreg_mc_flood_ports_set swid 0  bridge_id: %d, rc: %d " % (vlan_1, rc))
#
#     # enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1, SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"

#######################################
#     ## VLAN PORT SET - Add ports to Vlan ##
#     # Adds multiple ports to a specific VLAN.
#     vlan_arr = new_sx_vlan_ports_t_arr(2)
#     vlan_port0 = sx_vlan_ports_t()
#     vlan_port0.log_port = PORT3
#     vlan_port0.is_untagged = 1
#     vlan_port1 = sx_vlan_ports_t()
#     vlan_port1.log_port = PORT4
#     vlan_port1.is_untagged = 1
#     sx_vlan_ports_t_arr_setitem(vlan_arr, 0, vlan_port0)
#     sx_vlan_ports_t_arr_setitem(vlan_arr, 1, vlan_port1)
#     swid = 0
#     vid = vlan_1
#     rc = sx_api_vlan_ports_set(handle, SX_ACCESS_CMD_ADD, swid, vid, vlan_arr, 2)
#     print("Add %d ports to vlan %d , rc: %d " %(2, vid, rc))
#
# ############################
#
#     # set multicast flood  mode
#     urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#     #urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#     rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_1, urmc_flood_mode)
#     print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode [2=Prune]: %d, rc: %d " % (vlan_1, urmc_flood_mode, rc))
#
#
#     # set multicast flood  mode
#     #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#     urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#     rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_2, urmc_flood_mode)
#     print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode: %d, rc: %d " %(vlan_1, urmc_flood_mode, rc))
#
#     # set multicast flood  mode
#     #urmc_flood_mode = SX_FDB_UNREG_MC_FLOOD
#     urmc_flood_mode = SX_FDB_UNREG_MC_PRUNE
#     rc = sx_api_fdb_unreg_mc_flood_mode_set(handle, 0, vlan_3, urmc_flood_mode)
#     print("sx_api_fdb_unreg_mc_flood_mode_set swid 0  vlan id: %d, mode: %d, rc: %d " %(vlan_1, urmc_flood_mode, rc))
#
#     time.sleep(1)
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1 ,SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     time.sleep(1)
#     #disable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1 ,SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#     print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#     time.sleep(1)
#     #disable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#     print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_3 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_4 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_5 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_6 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_7 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_8 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     #enable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_9 ,SX_FDB_IGMPV3_STATE_ENABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#     print "sx_api_fdb_igmpv3_state_set ENABLE - Success"
#
#     mc_container_id = mc_container_create(igmp_port_list, 1)
#     print "mc_container_create - Success"
#
#     #create first igmpv3 group
#     rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[0], dip[0], vlan_1, mc_container_id)
#     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#     print "fdb_mc_ip_addr_group_set ADD first group - Success"
#
#     for i in range(1, 25):
#         rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[i], dip[i], vlan_2, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD group - Success"
#
#     #get igmp_v3 group
#     rc , sx_fdb_mc_ip_action = fdb_mc_ip_addr_group_get(sip[0], dip[0], vlan_1)
#     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group get"
#     print "fdb_mc_ip_addr_group_get first group - Success"
#
#     for i in range(1, 25):
#         #GET #3 igmp_v3 group
#         rc , sx_fdb_mc_ip_action = fdb_mc_ip_addr_group_get(sip[i], dip[i], vlan_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group get - X"
#         # Print retrieved data
#         print_group_data_db(i, sx_fdb_mc_ip_action)
#
#     mc_fdb_mc_ip_key =  mc_fdb_ip_key_create(sip[1], dip[1], vlan_2)
#     mc_fdb_mc_ip_key_p = new_sx_fdb_mc_ip_key_t_p()
#     sx_fdb_mc_ip_key_t_p_assign(mc_fdb_mc_ip_key_p, mc_fdb_mc_ip_key)
#
#     counter = create_flow_counter()
#     counter_p = new_sx_flow_counter_id_t_p()
#
#     rc = sx_api_fdb_mc_ip_addr_group_counter_bind_set(handle, SX_ACCESS_CMD_ADD, mc_fdb_mc_ip_key_p, counter);
#     assert SX_STATUS_SUCCESS == rc, "failed to add fdb mc addr group counter"
#     print "sx_api_fdb_mc_ip_addr_group_counter_bind_set ADD first group - Success"
#
#     rc = sx_api_fdb_mc_ip_addr_group_counter_bind_get(handle, mc_fdb_mc_ip_key_p, counter_p);
#     assert SX_STATUS_SUCCESS == rc, "Failed to get fdb mc addr group counter"
#     print "sx_api_fdb_mc_ip_addr_group_counter_bind_get first group - Success"
#
#     counter_id = sx_flow_counter_id_t_p_value(counter_p)
#     assert counter_id == counter, "Failed to get fdb mc addr group counter. Counter ID are differ"
#
#     rc = sx_api_fdb_mc_ip_addr_group_counter_bind_set(handle, SX_ACCESS_CMD_DELETE, mc_fdb_mc_ip_key_p, counter);
#     assert SX_STATUS_SUCCESS == rc, "failed to delete fdb mc addr group counter"
#     print "sx_api_fdb_mc_ip_addr_group_counter_bind_set DELETE first group - Success"
#
#     rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[0], dip[0], vlan_1)
#     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#     print "fdb_mc_ip_addr_group_set ADD group - Success"
#
#     for i in range(1, 25):
#         rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[i], dip[i], vlan_2)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD group - Success"
#
#     for i in range(0, 5):
#         rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[i], dip[i], vlan_1, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         print "fdb_mc_ip_addr_group_set ADD group - Success"
#
#     #delete all igmpv3 groups
#     rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE_ALL, sip[1], dip[1], vlan_2)
#     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group del all"
#     print "fdb_mc_ip_addr_group_set DELETE_ALL groups - Success"
#
#     mc_container_destroy(mc_container_id);
#     print "mc_container_destroy - Success"
#
#     #disable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_1 ,SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#     print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#     #disable igmp on fid
#     rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, vlan_2 ,SX_FDB_IGMPV3_STATE_DISABLE_E)
#     assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable"
#     print "sx_api_fdb_igmpv3_state_set DISABLE - Success"
#
#     router_deinit()
#
#
# if __name__ == "__main__":
#     main()
#
# """ ############################################################################################ """
# sx_api_close(handle)
# """ ############################################################################################ """
##### Massive configuration flow ######
def main():

    print("[LANDMARK] STARTED - ROUTER INIT")
    router_init()
    print("[LANDMARK] COMPLETED - ROUTER INIT")

    # save tunnel log verbosity level for later de-configuration
    original_module_verbosity_level_p = new_sx_verbosity_level_t_p()
    original_api_verbosity_level_p = new_sx_verbosity_level_t_p()
    rc = sx_api_tunnel_log_verbosity_level_get(handle, SX_LOG_VERBOSITY_BOTH, original_module_verbosity_level_p,
                                               original_api_verbosity_level_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_tunnel_log_verbosity_level_get failed. [%s(%d)]" % (sx_status_dict[rc], rc)
    original_module_verbosity_level = sx_verbosity_level_t_p_value(original_module_verbosity_level_p)
    original_api_verbosity_level = sx_verbosity_level_t_p_value(original_api_verbosity_level_p)

    rc = sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tunnel_log_verbosity_level_set failed. rc=%d" % rc

    # ingress port
    i_port = PORT1

    igmp_port_list = [PORT2, PORT3, PORT4]

    sip = []
    dip = []

    # group key
    vlan_2 = 5
    sip.append(make_sx_ip_prefix_v4("192.168.0.3", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))

    sip.append(make_sx_ip_prefix_v4("192.168.0.4", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))

    sip.append(make_sx_ip_prefix_v4("192.168.0.5", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))

    sip.append(make_sx_ip_prefix_v4("192.168.0.6", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))

    sip.append(make_sx_ip_prefix_v4("192.168.0.7", "255.255.255.0"))
    dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))

    mc_container_id = mc_container_create(igmp_port_list, 1)
    print("mc_container_create = %d - Success" % (mc_container_id))
#
# #     for i in range(1, 1):
# #         mc_container_id = mc_container_create(igmp_port_list, 1)
# #         print "mc_container_create - Success"
# #    mc_container_id = 1
#

    for i in range(1, 10):
        # enable igmp on fid
        rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, i, SX_FDB_IGMPV3_STATE_ENABLE_E)
        assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable. rc=%d" % rc
        print("sx_api_fdb_igmpv3_state_set ENABLE - Success")
        rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[0], dip[0], i, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
        print("fdb_mc_ip_addr_group_set ADD group - Success")
        rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[1], dip[1], i, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
        print("fdb_mc_ip_addr_group_set ADD group - Success")
        rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[2], dip[2], i, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
        print("fdb_mc_ip_addr_group_set ADD group - Success")
        rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[3], dip[3], i, mc_container_id)
        assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
        print("fdb_mc_ip_addr_group_set ADD group - Success")

    if args.deinit:
        for i in range(1, 10):
            rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[0], dip[0], i)
            assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
            print("fdb_mc_ip_addr_group_set DEL group - Success")
            rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[1], dip[1], i)
            assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
            print("fdb_mc_ip_addr_group_set DEL group - Success")
            rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[2], dip[2], i)
            assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
            print("fdb_mc_ip_addr_group_set DEL group - Success")
            rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[3], dip[3], i)
            assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set. rc=%d" % rc
            print("fdb_mc_ip_addr_group_set DEL group - Success")

    #         ## Delete wil return with error as entry already deleted
    #         rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[1], dip[1], i)
    #         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    #         print "fdb_mc_ip_addr_group_set DEL group - Success"

            # disable igmp on fid
            rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, i, SX_FDB_IGMPV3_STATE_DISABLE_E)
            assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set disable. rc=%d" % rc
            print("sx_api_fdb_igmpv3_state_set DISABLE - Success")

        mc_container_destroy(mc_container_id)

        rc = sx_api_tunnel_log_verbosity_level_set(handle, 2, original_module_verbosity_level, original_api_verbosity_level)
        assert SX_STATUS_SUCCESS == rc, "sx_api_tunnel_log_verbosity_level_set failed. rc=%d" % rc

        router_deinit()

        #     rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[2], dip[2], 3372, mc_container_id)
    #     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    #     print "fdb_mc_ip_addr_group_set ADD group - Success"
    #     rc  = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_DELETE, sip[0], dip[0], 3371)
    #     assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
    #     print "fdb_mc_ip_addr_group_set DEL group - Success"
    #
    #     mc_container_id = mc_container_destroy(2)
    #     print "mc_container_destroy - Success"


if __name__ == "__main__":
    main()


sx_api_close(handle)


# """ ############################################################################################ """
#     sx_api_close(handle)
# """ ############################################################################################ """
# Performance test:
# IGMPV3 = 5000 entries
# Route vlna interface = 9000 entries
# def main():
#
#     sx_api_tunnel_log_verbosity_level_set(handle, 2, 5, 5)
#
#     # ingress port
#     i_port = PORT1
#     igmp_port_list = [PORT2, PORT3, PORT4]
#     sip = []
#     dip = []
#     # group key
#     vlan_2 = 5
#     sip.append(make_sx_ip_prefix_v4("192.168.0.3", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.4", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.5", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.6", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     sip.append(make_sx_ip_prefix_v4("192.168.0.7", "255.255.255.0"))
#     dip.append(make_sx_ip_prefix_v4("192.168.1.3", "255.255.255.0"))
#
#     mc_container_id = mc_container_create(igmp_port_list, 1)
#     print "mc_container_create = %d - Success" % (mc_container_id)
#
#     for i in range(1, 1000):
#         # enable igmp on fid
#         rc = sx_api_fdb_igmpv3_state_set(handle, SX_ACCESS_CMD_SET, i, SX_FDB_IGMPV3_STATE_ENABLE_E)
#         assert SX_STATUS_SUCCESS == rc, "Failed to igmpv3_state_set enable"
#
#     print "Entry count = %d [real time = %d]" % (0, time.time() % 60)
#     for i in range(1, 1000):
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[0], dip[0], i, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[1], dip[1], i, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[2], dip[2], i, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[3], dip[3], i, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         rc = fdb_mc_ip_addr_group_set(SX_ACCESS_CMD_ADD, sip[4], dip[4], i, mc_container_id)
#         assert SX_STATUS_SUCCESS == rc, "Failed to mc ip group set"
#         if (i % 200 == 0):
#             print "Entry count = %d [real time = %d]" % (i * 5, time.time() % 60)
#
# ######## Create RIF - Vlan interface ###################
#     print "################### SET CONFIGURATION ####################"
#     # Initialize router
#     print "[LANDMARK] STARTED - ROUTER INIT"
#     router_init()
#     print "[LANDMARK] COMPLETED - ROUTER INIT"
#
#     vlan_1 = 4
#     vlan_2 = 5
#     mc_addr = '224.1.'
#
#     # Create VRID that supports IPv4 and IPv6 MC
#     vrid = create_vrid()
#     # create vlan rif and vport rif
#     rif_arr = [None] * 2
#     rif_arr[0] = create_vlan_rif(vrid, vlan_1, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x07), 1500)
#     rif_arr[1] = create_vlan_rif(vrid, vlan_2, ether_addr(0x00, 0x02, 0x03, 0x04, 0x05, 0x08), 1500)
#
#     # Enable IPv4 MC on each RIF
#     for rif in rif_arr:
#         set_rif_state(handle, rif,
#                       ipv4_enable=True,
#                       ipv6_enable=False,
#                       ipv4_mc_enable=True,
#                       ipv6_mc_enable=False)
#
#     erif_list = [rif_arr[1]]
#     count = 0
#     for addr_1 in range(36):
#         for addr_2 in range(250):
#             mc_comp_addr = mc_addr + repr(addr_1) + '.' + repr(addr_2)
#             mc_route_key_ipv4 = sx_api_mc_router.make_ipv4_mc_route_key(DONT_CARE_RIF, '0.0.0.0', '0.0.0.0', mc_comp_addr, '255.255.255.255')
#             mc_route_attr = sx_api_mc_router.make_mc_route_attributes()
#             mc_route_data = sx_api_mc_router.make_mc_route_data(erif_list)
#             add_mc_route(handle, vrid, mc_route_key_ipv4, mc_route_attr, mc_route_data)
#             count += 1
#             if (count % 500 == 0):
#                 print "MC route ADD Entry count = %d [real time = %d]" % (count, time.time() % 60)
#             if count >= 3000:
#                 break
#         if count >= 3000:
#             break
#
#     print "count %d " % (count)
#
#
# if __name__ == "__main__":
#     main()
