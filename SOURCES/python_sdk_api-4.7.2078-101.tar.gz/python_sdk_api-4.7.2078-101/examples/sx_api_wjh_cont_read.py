#!/usr/bin/env python
'''
This file contains Python command example for "What just happened" feature.
This example demonstrates the following :
a. configuration of trap group for WJH feature.
b. Retrieval of packets from the Queue associated with WJH
Python commands syntax is very similar to the Switch SDK APIs.
You can learn more about each command and its parameters by reading the SwitchX API Reference Manual.

The example below demonstrates the configuration of different host interface trap attributes.
This example is supported on Spectrum devices.
'''
import sys
import errno
import sys
import colorsys
import cmd
import argparse
from test_infra_common import *

from python_sdk_api.sx_api import *

dest_port_type_dict = {0: 'INVALID', 1: 'MULTI_PORT', 2: 'NETWORK_PORT', 4: 'LAG_PORT'}
chip_types_list = [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3, SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5]

trap_id_dict = {
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC: "DISCARD_ING_PACKET_SMAC_MC",
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC: "DISCARD_ING_PACKET_SMAC_DMAC",
    SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC: "DISCARD_ING_PACKET_RSV_MAC",
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0: "DISCARD_ING_PACKET_SMAC0",


    SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW: "DISCARD_ING_SWITCH_VTAG_ALLOW",
    SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN: "DISCARD_ING_SWITCH_VLAN",
    SX_TRAP_ID_DISCARD_ING_SWITCH_STP: "DISCARD_ING_SWITCH_STP",

    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC: "DISCARD_LOOKUP_SWITCH_UC",
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL: "DISCARD_LOOKUP_SWITCH_MC_NULL",
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB: "DISCARD_LOOKUP_SWITCH_LB",
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS: "DISCARD_LOOKUP_SWITCH_NO_PORTS",

    SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR: "DISCARD_ING_ROUTER_NO_HDR",
    SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC: "DISCARD_ING_ROUTER_UC_DIP_MC_DMAC",
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB: "DISCARD_ING_ROUTER_DIP_LB",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC: "DISCARD_ING_ROUTER_SIP_MC",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E: "DISCARD_ING_ROUTER_SIP_CLASS_E",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB: "DISCARD_ING_ROUTER_SIP_LB",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP: "DISCARD_ING_ROUTER_SIP_UNSP",
    SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR: "DISCARD_ING_ROUTER_IP_HDR",
    SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC: "DISCARD_ING_ROUTER_MC_DMAC",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP: "DISCARD_ING_ROUTER_SIP_DIP",
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC: "DISCARD_ING_ROUTER_SIP_BC",
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET: "DISCARD_ING_ROUTER_DIP_LOCAL_NET",
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL: "DISCARD_ING_ROUTER_DIP_LINK_LOCAL",

    SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL: "DISCARD_ING_LSR_NO_LABEL",
    SX_TRAP_ID_DISCARD_ING_LSR_UC_ET: "DISCARD_ING_LSR_UC_ET",
    SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC: "DISCARD_ING_LSR_MC_DMAC",

    SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN: "DISCARD_ROUTER_IRIF_EN",
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN: "DISCARD_ROUTER_ERIF_EN",
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD: "DISCARD_ROUTER_ERIF_FWD",
    SX_TRAP_ID_DISCARD_ROUTER_LPM4: "DISCARD_ROUTER_LPM4",
    SX_TRAP_ID_DISCARD_ROUTER_LPM6: "DISCARD_ROUTER_LPM6",

    SX_TRAP_ID_DISCARD_LSR_MIN_LABEL: "DISCARD_LSR_MIN_LABEL",
    SX_TRAP_ID_DISCARD_LSR_MAX_LABEL: "DISCARD_LSR_MAX_LABEL",
    SX_TRAP_ID_DISCARD_LSR_LB: "DISCARD_LSR_LB",

    SX_TRAP_ID_DISCARD_DEC_PKT: "DISCARD_DEC_PKT",
    SX_TRAP_ID_DISCARD_DEC_DIS: "DISCARD_DEC_DIS",

    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC: "DISCARD_OVERLAY_SWITCH_SMAC_MC",
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC: "DISCARD_OVERLAY_SWITCH_SMAC_DMAC",
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0: "DISCARD_OVERLAY_SWITCH_SMAC0",
    SX_TRAP_ID_DISCARD_ENC_ISOLATION: "DISCARD_ENC_ISOLATION",

    SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS: "DISCARD_DEC_NVE_OPTIONS",

    SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL: "DISCARD_EGR_LSR_NO_LABEL",
    SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP: "DISCARD_EGR_LSR_NO_IP",
    SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP: "DISCARD_EGR_LSR_PHP_NO_IP",

    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0: "DISCARD_MC_SCOPE_IPV6_0",
    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1: "DISCARD_MC_SCOPE_IPV6_1",
}

trap_id_is_supported_dict = {
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0: [SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5],


    SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_SWITCH_STP: chip_types_list,

    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC: chip_types_list,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL: chip_types_list,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB: chip_types_list,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS: chip_types_list,

    SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL: chip_types_list,

    SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_LSR_UC_ET: chip_types_list,
    SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC: chip_types_list,

    SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN: chip_types_list,
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN: chip_types_list,
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD: chip_types_list,
    SX_TRAP_ID_DISCARD_ROUTER_LPM4: chip_types_list,
    SX_TRAP_ID_DISCARD_ROUTER_LPM6: chip_types_list,

    SX_TRAP_ID_DISCARD_LSR_MIN_LABEL: chip_types_list,
    SX_TRAP_ID_DISCARD_LSR_MAX_LABEL: chip_types_list,
    SX_TRAP_ID_DISCARD_LSR_LB: chip_types_list,

    SX_TRAP_ID_DISCARD_DEC_PKT: chip_types_list,
    SX_TRAP_ID_DISCARD_DEC_DIS: chip_types_list,

    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC: chip_types_list,
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC: chip_types_list,
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0: [SX_CHIP_TYPE_SPECTRUM4, SX_CHIP_TYPE_SPECTRUM5],
    SX_TRAP_ID_DISCARD_ENC_ISOLATION: chip_types_list,

    SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS: chip_types_list,

    SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL: chip_types_list,
    SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP: chip_types_list,
    SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP: chip_types_list,

    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0: chip_types_list,
    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1: chip_types_list,
}


def analyze_DISCARD_ING_PACKET_SMAC_MC(recv_info_p, pkt_size_p, pkt):
    iii = 6
    print(("Discard reason: SMAC is MC %02x:%02x:%02x:%02x:%02x:%02x" %
           (uint8_t_arr_getitem(pkt, iii),
            uint8_t_arr_getitem(pkt, iii + 1),
            uint8_t_arr_getitem(pkt, iii + 2),
            uint8_t_arr_getitem(pkt, iii + 3),
            uint8_t_arr_getitem(pkt, iii + 4),
            uint8_t_arr_getitem(pkt, iii + 5))))


def analyze_DISCARD_ING_PACKET_SMAC_DMAC(recv_info_p, pkt_size_p, pkt):
    iii = 0
    print(("Discard reason: SMAC = DMAC = %02x:%02x:%02x:%02x:%02x:%02x" %
           (uint8_t_arr_getitem(pkt, iii),
            uint8_t_arr_getitem(pkt, iii + 1),
            uint8_t_arr_getitem(pkt, iii + 2),
            uint8_t_arr_getitem(pkt, iii + 3),
            uint8_t_arr_getitem(pkt, iii + 4),
            uint8_t_arr_getitem(pkt, iii + 5))))


def analyze_DISCARD_ING_PACKET_SMAC0(recv_info_p, pkt_size_p, pkt):
    print("Discard reason: SMAC is Zero (00:00:00:00:00:00")


def analyze_DISCARD_ING_PACKET_RSV_MAC(recv_info_p, pkt_size_p, pkt):
    iii = 0
    print(("Discard reason: Reserved DMAC (01:80:c2:00:00:0x): %02x:%02x:%02x:%02x:%02x:%02x" %
           (uint8_t_arr_getitem(pkt, iii),
            uint8_t_arr_getitem(pkt, iii + 1),
            uint8_t_arr_getitem(pkt, iii + 2),
            uint8_t_arr_getitem(pkt, iii + 3),
            uint8_t_arr_getitem(pkt, iii + 4),
            uint8_t_arr_getitem(pkt, iii + 5))))


def analyze_DISCARD_ING_SWITCH_VTAG_ALLOW(recv_info_p, pkt_size_p, pkt):
    print("Discard reason vlan tag allow")


def analyze_DISCARD_ING_SWITCH_VLAN(recv_info_p, pkt_size_p, pkt):
    iii = 14
    vlan_id = ((uint8_t_arr_getitem(pkt, iii) << 8) + (uint8_t_arr_getitem(pkt, iii + 1))) & 0xFFF
    # sx_api_vlan_ports_get
    print(("Discard reason: ingress vlan filter, pkt vlan: %d" %
           (vlan_id)))


mstp_state_dict = {
    SX_MSTP_INST_PORT_STATE_DISCARDING: "DISCARDING",
    SX_MSTP_INST_PORT_STATE_LEARNING: "LEARNING",
    SX_MSTP_INST_PORT_STATE_FORWARDING: "FORWARDING"
}

mstp_mode_dict = {
    SX_MSTP_MODE_MSTP: "MSTP",
    SX_MSTP_MODE_RSTP: "RSTP"
}


def analyze_DISCARD_ING_SWITCH_STP(recv_info_p, pkt_size_p, pkt):
    print("Discard reason: ingress STP filter")

    mstp_mode_p = new_sx_mstp_mode_t_p()
    sx_api_mstp_mode_get(handle, 0, mstp_mode_p)
    mstp_mode = sx_mstp_mode_t_p_value(mstp_mode_p)
    print(("MSTP mode: %s" % mstp_mode_dict[mstp_mode]))
    if mstp_mode == SX_MSTP_MODE_RSTP:
        rstp_port_state_p = new_sx_mstp_inst_port_state_t_p()
        log_port = recv_info_p.source_log_port
        sx_api_rstp_port_state_get(handle, log_port, rstp_port_state_p)
        rstp_port_state = sx_mstp_inst_port_state_t_p_value(rstp_port_state_p)
        print(("Logport 0x%x RSTP state: %s" % (log_port, mstp_state_dict[rstp_port_state])))


def analyze_DISCARD_LOOKUP_SWITCH_UC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  eth uc fdb filter (fdb discard)")


def analyze_DISCARD_LOOKUP_SWITCH_MC_NULL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  eth mc fdb filter (tx list is empty)")


def analyze_DISCARD_LOOKUP_SWITCH_LB(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  eth loopback filter")


def analyze_DISCARD_LOOKUP_SWITCH_NO_PORTS(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  eth not allowed port (tx list becomes empty)")


def analyze_DISCARD_ING_ROUTER_NO_HDR(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  packet to router is not ip/mpls/arp (no ip header)")


def analyze_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  uc dip over mc or bc dmac")


def analyze_DISCARD_ING_ROUTER_DIP_LB(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  dip is loopback address, ipv4 127.0.0.0 , ipv6 ::1/128 or 0:0:0:0:0:ffff:7f00:0/104")


def analyze_DISCARD_ING_ROUTER_SIP_MC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  sip is mc")


def analyze_DISCARD_ING_ROUTER_SIP_CLASS_E(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  sip is in class e")


def analyze_DISCARD_ING_ROUTER_SIP_LB(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  sip is loopback, ipv4 127.0.0.0 , ipv6 ::1/128")


def analyze_DISCARD_ING_ROUTER_SIP_UNSP(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  sip is unspecified, ipv4 sip == 0.0.0.0/32")


def analyze_DISCARD_ING_ROUTER_IP_HDR(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ip header not okay, due to header checksum or IPver or IPv4 IHL too short")


def analyze_DISCARD_ING_ROUTER_MC_DMAC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mc mac mismatch, DMAC isn't according MC DIP ")


def analyze_DISCARD_ING_ROUTER_SIP_DIP(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  sip equal dip")


def analyze_DISCARD_ING_ROUTER_SIP_BC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ipv4 sip is limited broadcast, sip == 255.255.255.255")


def analyze_DISCARD_ING_ROUTER_DIP_LOCAL_NET(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ipv4 dip is local network, dip = 0.0.0.0/8")


def analyze_DISCARD_ING_ROUTER_DIP_LINK_LOCAL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ipv4 uc dip is link local, dip=169.254.0.0/16")


def analyze_DISCARD_ING_LSR_NO_LABEL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  outer label is not valid")


def analyze_DISCARD_ING_LSR_UC_ET(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mpls uc Ethertype (0x8847) over mc or bc mac")


def analyze_DISCARD_ING_LSR_MC_DMAC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mpls mc Ethertype (0x8848) over not allowed, dmac != 01-00-5e-8x-xx-xx")


def analyze_DISCARD_ROUTER_IRIF_EN(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  disabled irif")


def analyze_DISCARD_ROUTER_ERIF_EN(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  disabled_erif")


def analyze_DISCARD_ROUTER_ERIF_FWD(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  disable erif forwarding")


def analyze_DISCARD_ROUTER_LPM4(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  lpm no route uc ipv4")


def analyze_DISCARD_ROUTER_LPM6(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  lpm no route uc ipv6")


def analyze_DISCARD_LSR_MIN_LABEL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mpls min ingress label allowed (label too low)")


def analyze_DISCARD_LSR_MAX_LABEL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mpls max ingress label allowed (label too high)")


def analyze_DISCARD_LSR_LB(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  mpls loopback filter")


def analyze_DISCARD_DEC_PKT(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  decap failed due to packet (pkt after decap is too short)")


def analyze_DISCARD_DEC_NVE_OPTIONS(fd, recv_info_p, pkt_size_p, pkt):
    fd.write("Discard reason:  decap failed due to packet (pkt after decap has non-zero reserved bits)")


def analyze_DISCARD_DEC_DIS(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  nve decap disable (due to TNGCR.type)")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC_MC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  overlay switch : smac is multicast")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC_DMAC(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  overlay switch : smac eqauls dmac")


def analyze_DISCARD_OVERLAY_SWITCH_SMAC0(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  overlay switch : smac is zero")


def analyze_DISCARD_ENC_ISOLATION(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  Encapsulation port isolation")


def analyze_DISCARD_EGR_LSR_NO_LABEL(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  MPLS prevent sending MPLS packet with no labels available")


def analyze_DISCARD_EGR_LSR_NO_IP(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  Expected IP version after mpls decap")


def analyze_DISCARD_EGR_LSR_PHP_NO_IP(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  php decap and no ip header")


def analyze_DISCARD_MC_SCOPE_IPV6_0(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ipv6_mc_scope_0, dip = FFx0:/16")


def analyze_DISCARD_MC_SCOPE_IPV6_1(recv_info_p, pkt_size_p, pkt):
    print("Discard reason:  ipv6_mc_scope_1, dip = FFx1:/16")


discard_trap_id_handler_dict = {
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC: analyze_DISCARD_ING_PACKET_SMAC_MC,
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC: analyze_DISCARD_ING_PACKET_SMAC_DMAC,
    SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC: analyze_DISCARD_ING_PACKET_RSV_MAC,
    SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0: analyze_DISCARD_ING_PACKET_SMAC0,


    SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW: analyze_DISCARD_ING_SWITCH_VTAG_ALLOW,
    SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN: analyze_DISCARD_ING_SWITCH_VLAN,
    SX_TRAP_ID_DISCARD_ING_SWITCH_STP: analyze_DISCARD_ING_SWITCH_STP,

    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC: analyze_DISCARD_LOOKUP_SWITCH_UC,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL: analyze_DISCARD_LOOKUP_SWITCH_MC_NULL,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB: analyze_DISCARD_LOOKUP_SWITCH_LB,
    SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS: analyze_DISCARD_LOOKUP_SWITCH_NO_PORTS,

    SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR: analyze_DISCARD_ING_ROUTER_NO_HDR,
    SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC: analyze_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB: analyze_DISCARD_ING_ROUTER_DIP_LB,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC: analyze_DISCARD_ING_ROUTER_SIP_MC,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E: analyze_DISCARD_ING_ROUTER_SIP_CLASS_E,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB: analyze_DISCARD_ING_ROUTER_SIP_LB,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP: analyze_DISCARD_ING_ROUTER_SIP_UNSP,
    SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR: analyze_DISCARD_ING_ROUTER_IP_HDR,
    SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC: analyze_DISCARD_ING_ROUTER_MC_DMAC,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP: analyze_DISCARD_ING_ROUTER_SIP_DIP,
    SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC: analyze_DISCARD_ING_ROUTER_SIP_BC,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET: analyze_DISCARD_ING_ROUTER_DIP_LOCAL_NET,
    SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL: analyze_DISCARD_ING_ROUTER_DIP_LINK_LOCAL,

    SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL: analyze_DISCARD_ING_LSR_NO_LABEL,
    SX_TRAP_ID_DISCARD_ING_LSR_UC_ET: analyze_DISCARD_ING_LSR_UC_ET,
    SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC: analyze_DISCARD_ING_LSR_MC_DMAC,

    SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN: analyze_DISCARD_ROUTER_IRIF_EN,
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN: analyze_DISCARD_ROUTER_ERIF_EN,
    SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD: analyze_DISCARD_ROUTER_ERIF_FWD,
    SX_TRAP_ID_DISCARD_ROUTER_LPM4: analyze_DISCARD_ROUTER_LPM4,
    SX_TRAP_ID_DISCARD_ROUTER_LPM6: analyze_DISCARD_ROUTER_LPM6,

    SX_TRAP_ID_DISCARD_LSR_MIN_LABEL: analyze_DISCARD_LSR_MIN_LABEL,
    SX_TRAP_ID_DISCARD_LSR_MAX_LABEL: analyze_DISCARD_LSR_MAX_LABEL,
    SX_TRAP_ID_DISCARD_LSR_LB: analyze_DISCARD_LSR_LB,

    SX_TRAP_ID_DISCARD_DEC_PKT: analyze_DISCARD_DEC_PKT,
    SX_TRAP_ID_DISCARD_DEC_DIS: analyze_DISCARD_DEC_DIS,

    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC: analyze_DISCARD_OVERLAY_SWITCH_SMAC_MC,
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC: analyze_DISCARD_OVERLAY_SWITCH_SMAC_DMAC,
    SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0: analyze_DISCARD_OVERLAY_SWITCH_SMAC0,
    SX_TRAP_ID_DISCARD_ENC_ISOLATION: analyze_DISCARD_ENC_ISOLATION,

    SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS: analyze_DISCARD_DEC_NVE_OPTIONS,

    SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL: analyze_DISCARD_EGR_LSR_NO_LABEL,
    SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP: analyze_DISCARD_EGR_LSR_NO_IP,
    SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP: analyze_DISCARD_EGR_LSR_PHP_NO_IP,

    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0: analyze_DISCARD_MC_SCOPE_IPV6_0,
    SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1: analyze_DISCARD_MC_SCOPE_IPV6_1,
}

print("[+] opening sdk")
rc, handle = sx_api_open(None)
print(("sx_api_open handle:0x%x , rc %d " % (handle, rc)))
if (rc != SX_STATUS_SUCCESS):
    print("Failed to open api handle.\nPlease check that SDK is running.")
    sys.exit(rc)

######################################################
#    defines
######################################################
SPECTRUM_SWID = 0
WAIT_FOR_KEY = 0
DO_INF_LOOP = 0

parser = argparse.ArgumentParser(description='Port Counter dump utility')
parser.add_argument('--wait_enable', default='false', choices=['true', 'false'], help='Wait for key after WJH operations')
parser.add_argument('--infinite_read', default='false', choices=['true', 'false'], help='Read the packets arrived to WJH in infinite loop')
parser.add_argument('--deinit', action='store_true', help='Cleanup all configuration done by the example')
args = parser.parse_args()
if args.wait_enable == 'true':
    WAIT_FOR_KEY = 1
if args.infinite_read == 'true':
    DO_INF_LOOP = 1
print(("DO_INF_LOOP %s , WAIT_FOR_KEY: %s " % (DO_INF_LOOP, WAIT_FOR_KEY)))


def local_raw_input(msg):
    if WAIT_FOR_KEY != 0:
        input(msg)


def print_recv_info(recv_info_p, pkt_size_p, pkt):
    pkt_size = pkt_size_p

    trap_name = "Unknown"
    if recv_info_p.trap_id in discard_trap_id_handler_dict:
        trap_name = trap_id_dict[recv_info_p.trap_id]

    print(("TRAP_ID:%s(%d,0x%x), PKT_SZ:%d, S_IS_LAG:%d, S_LOGPORT:0x%x, D_PORT_TYPE:%s, D_LOGPORT:0x%x" %
           (trap_name, recv_info_p.trap_id, recv_info_p.trap_id, pkt_size, recv_info_p.is_lag, recv_info_p.source_log_port,
            dest_port_type_dict[recv_info_p.dest_port_type], recv_info_p.dest_lag_port)))

    print("Packet content:")
    if (pkt_size > 0):
        for iii in range(0, pkt_size):
            if (0 == iii % 8):
                print(("%02x %02x %02x %02x %02x %02x %02x %02x " %
                       (uint8_t_arr_getitem(pkt, iii),
                        uint8_t_arr_getitem(pkt, iii + 1),
                        uint8_t_arr_getitem(pkt, iii + 2),
                        uint8_t_arr_getitem(pkt, iii + 3),
                        uint8_t_arr_getitem(pkt, iii + 4),
                        uint8_t_arr_getitem(pkt, iii + 5),
                        uint8_t_arr_getitem(pkt, iii + 6),
                        uint8_t_arr_getitem(pkt, iii + 7))))

        print("  ")

    if recv_info_p.trap_id in discard_trap_id_handler_dict:
        discard_trap_handler = discard_trap_id_handler_dict[recv_info_p.trap_id]
        discard_trap_handler(recv_info_p, pkt_size_p, pkt)
    else:
        print(("Trap id %d isn't supported for analyze . Check if it is DISCARDED trap id.\n" % (recv_info_p.trap_id)))


def sx_recv_multi_count(fd_p):

    pkt_info_arr_len_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_info_arr_len_p, 0)

    print("[recv] Count WJH fd")
    rc = sx_lib_host_ifc_recv_list(fd_p, None, pkt_info_arr_len_p)
    if rc != SX_STATUS_SUCCESS:
        print(("exit with error, rc %d" % rc))
        sys.exit(rc)
    pkt_info_arr_len = uint32_t_p_value(pkt_info_arr_len_p)

    print(("[recv] %d Packet count in queue :" % (pkt_info_arr_len)))


def sx_recv_multi_flush(fd_p):

    print("[recv] Flush WJH fd")
    rc = sx_lib_host_ifc_recv_list(fd_p, None, None)
    if rc != SX_STATUS_SUCCESS:
        print(("exit with error, rc %d" % rc))
        sys.exit(rc)
    print("[recv] Flush of WJH fd is succeeded,")


def sx_recv_multi(fd_p):

    pkt_arr = []
    # recv parameters
    pkt_size = 2000
    pkt_size_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_size_p, pkt_size)
    pkt0 = new_uint8_t_arr(pkt_size)
    pkt1 = new_uint8_t_arr(pkt_size)
    pkt2 = new_uint8_t_arr(pkt_size)
    # pkt_arr[0] = new_uint8_t_arr(pkt_size)
    pkt_arr.append(pkt0)
    pkt_arr.append(pkt1)
    pkt_arr.append(pkt2)

    recv_info_p = new_sx_receive_info_t_p()
    pkt_info_arr = new_sx_packet_info_t_arr(10)
    pkt_info = sx_packet_info_t()
    pkt_info.packet_p = pkt0
    pkt_info.packet_size = pkt_size
    sx_packet_info_t_arr_setitem(pkt_info_arr, 0, pkt_info)
    pkt_info = sx_packet_info_t()
    pkt_info.packet_p = pkt1
    pkt_info.packet_size = pkt_size
    sx_packet_info_t_arr_setitem(pkt_info_arr, 1, pkt_info)
    pkt_info = sx_packet_info_t()
    pkt_info.packet_p = pkt2
    pkt_info.packet_size = pkt_size
    sx_packet_info_t_arr_setitem(pkt_info_arr, 2, pkt_info)
    pkt_info_arr_len_p = new_uint32_t_p()
    uint32_t_p_assign(pkt_info_arr_len_p, 3)

    print("[recv] recv_multi on fd")
    rc = sx_lib_host_ifc_recv_list(fd_p, pkt_info_arr, pkt_info_arr_len_p)
    if rc != SX_STATUS_SUCCESS:
        print(("exit with error, rc %d" % rc))
        sys.exit(rc)
    pkt_info_arr_len = uint32_t_p_value(pkt_info_arr_len_p)

    print(("[recv] %d Packet recved. Recv  info:" % (pkt_info_arr_len)))
    pkt_info = sx_packet_info_t()
    recv_info_p = sx_receive_info_t()

    for i in range(pkt_info_arr_len):
        print(("=" * 50))
        print(("Read packet from index %d " % (i)))
        pkt_info = sx_packet_info_t_arr_getitem(pkt_info_arr, i)
        recv_info_p = pkt_info.receive_info
        print_recv_info(recv_info_p, pkt_info.packet_size, pkt_arr[i])

    print(("=" * 50))
    return


def host_ifc_trap_id_register(cmd, trap_id, user_channel_p):
    """ HOST IFC TRAP ID REGISTER/UNREGISTER """
    if cmd == SX_ACCESS_CMD_REGISTER:
        print("--------------- HOST IFC TRAP ID REGISTER------------------------------")
    else:
        print("--------------- HOST IFC TRAP ID DEREGISTER------------------------------")

    rc = sx_api_host_ifc_trap_id_register_set(handle, cmd, SPECTRUM_SWID, trap_id, user_channel_p)
    print(("sx_api_host_ifc_trap_id_register_set [rc = %d]" % (rc)))

    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)


def host_ifc_trap_id_set_handle(handle, cmd, trap_id, trap_group):
    ''' SET/UNSET trap id association to the relevant trap group '''
    trap_key_p = new_sx_host_ifc_trap_key_t_p()
    trap_key_p.type = HOST_IFC_TRAP_KEY_TRAP_ID_E
    trap_key_p.trap_key_attr.trap_id = trap_id

    trap_attr_p = new_sx_host_ifc_trap_attr_t_p()
    trap_attr_p.attr.trap_id_attr.trap_group = trap_group

    if cmd == SX_ACCESS_CMD_SET:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP
    else:
        trap_attr_p.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT

    rc = sx_api_host_ifc_trap_id_ext_set(handle, cmd, trap_key_p, trap_attr_p)
    if rc != SX_STATUS_SUCCESS:
        print(("Failed to set trap id %s (%d)" % (trap_id_dict[trap_id], trap_id)))
        sys.exit(rc)
    print(("Set trap id %s (%d) succeed." % (trap_id_dict[trap_id], trap_id)))


""" ############################################################################################ """
""" HOST IFC OPEN """
print("--------------- HOST IFC OPEN------------------------------")

fd_p = new_sx_fd_t_p()

rc = sx_api_host_ifc_open(handle, fd_p)
print(("sx_api_host_ifc_open, rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
fd = sx_fd_t_p_value(fd_p)
print(("fd = %d" % (fd.fd)))


""" ############################################################################################ """
# sx_api_host_ifc_trap_group_ext_set 0 1 {1;SX_TRUNCATE_MODE_DISABLE;0;SX_CONTROL_TYPE_DEFAULT}
""" HOST IFC TRAP GROUP SET """
print("--------------- HOST IFC TRAP GROUP EXT SET ------------------------------")

trap_group = 1
trap_group_attr_p = new_sx_trap_group_attributes_t_p()
trap_group_attr = sx_trap_group_attributes_t()
# trap_group_attr.prio = 1
trap_group_attr.prio = 5
trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE
trap_group_attr.truncate_size = 0
trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT
trap_group_attr.is_monitor = 1
trap_group_attr.monitor_fd = fd
trap_group_attr.trap_group = trap_group
sx_trap_group_attributes_t_p_assign(trap_group_attr_p, trap_group_attr)
trap_group_set_cmd, trap_group_unset_cmd = trap_group_set_unset_cmd_get(handle)
rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_set_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
print(("sx_api_host_ifc_trap_group_ext_set [rc = %d]" % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)

trap_group_attr = sx_trap_group_attributes_t_p_value(trap_group_attr_p)
trap_group = trap_group_attr.trap_group
print(("trap_group =%d " % (trap_group)))
print("--- trap_group attributes ---")
print(("prio  =%d " % (trap_group_attr.prio)))
print(("truncate mode  =%d " % (trap_group_attr.truncate_mode)))
print(("truncate size  =%d " % (trap_group_attr.truncate_size)))
print(("control type  =%d " % (trap_group_attr.control_type)))

""" ############################################################################################ """

# sx_api_host_ifc_trap_id_ext_set 0 SX_TRAP_ID_ETH_L2_STP 1 SX_TRAP_ACTION_TRAP_2_CPU
""" HOST IFC TRAP ID SET """
print("--------------- HOST IFC TRAP ID SET------------------------------")

chip_type = get_chip_type(handle)
for trap_id in trap_id_dict:
    if chip_type in trap_id_is_supported_dict[trap_id]:
        host_ifc_trap_id_set_handle(handle, SX_ACCESS_CMD_SET, trap_id, trap_group)

local_raw_input("Press key to read the packets from monitor ...")
# sx_recv(fd_p)
while True:
    sx_recv_multi(fd_p)
    local_raw_input("Press Enter key to read count ...")
    sx_recv_multi_count(fd_p)
    local_raw_input("Press Enter key to flush ...")
    sx_recv_multi_flush(fd_p)
    local_raw_input("Press Enter key to continue to recv packets ...")
    if DO_INF_LOOP == 0:
        break

if args.deinit:
    for trap_id in trap_id_dict:
        if chip_type in trap_id_is_supported_dict[trap_id]:
            host_ifc_trap_id_set_handle(handle, SX_ACCESS_CMD_UNSET, trap_id, trap_group)

    rc = sx_api_host_ifc_trap_group_ext_set(handle, trap_group_unset_cmd, SPECTRUM_SWID, trap_group, trap_group_attr_p)
    print(("sx_api_host_ifc_trap_group_set [rc = %d]" % (rc)))
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

rc = sx_api_host_ifc_close(handle, fd_p)
print(("sx_api_host_ifc_close, rc=%d] " % (rc)))
if rc != SX_STATUS_SUCCESS:
    sys.exit(rc)
fd = sx_fd_t_p_value(fd_p)
print(("fd = %d" % (fd.fd)))

sx_api_close(handle)
