#!/usr/bin/env python3

"""
Owner               : Julian Peller <julianp@mellanox.com>

Created on          : July 27th, 2016

Description         : Make sx(d?)_api friendly again.
"""

#############################
# Python built-in imports
#############################

import sys
import socket
import struct
import inspect
import time
import os
import traceback
from types import MethodType, FunctionType, NoneType
from collections import defaultdict
from functools import wraps

#############################
# Local imports
#############################

from python_sdk_api.sx_api import *
import python_sdk_api.sx_api as sx_api
from python_sdk_api.sxd_api import *
import python_sdk_api.sxd_api as sxd_api

#############################
# Globals
#############################


def color_text(text, color="cyan"):
    MAPPING = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "purple": "35",
               "cyan": "36", "white": "29"}
    return "\x1b[" + MAPPING[color] + "m" + text + "\x1b[0m"


# When to break the line on docstrings and on tables. Adjust if the tables or the doctrings look bad.
MAX_CHARS_LINE_BREAK = 150

# Set to True to see all the functions that are created and more information
VERBOSE = False

SCRIPT_PATH = os.path.dirname(os.path.realpath(__file__))

TAGS = ["%s/sx_tags" % SCRIPT_PATH, "%s/sxd_tags" % SCRIPT_PATH]

# The name of the new constructors attached to classes binding structs and unions
# Constructor name __init__ will affect the logic and replace the current constructors
STRUCT_CONSTRUCTOR_NAME = "__init__"
# STRUCT_CONSTRUCTOR_NAME = "create"

FAILED_TO_EXPLAIN = "No explanation available"

# Don't process these API calls because of reasons
EXCLUDE_API_CALLS = ["sx_api_open", "sx_api_close", "sxd_access_reg_init"]

# Don't process these structs/unions because of reasons
EXCLUDE_CLASSES = ['ether_addr']

# Whether the nested structs should be printed or just mentioned
# Affects struct_improve_print_functions()
NEST_STR_REPRESENTATIONS = True

# Wheter struct_improve_print_functions() should replace __repr__ or only __str__
# __repr__ affects: 1) typing the variable name 2) a list of objects
# __str__ only affects print <varible name>
# Check this http://stackoverflow.com/questions/1436703/difference-between-str-and-repr-in-python
# And this: https://docs.python.org/2.7/reference/datamodel.html
REPLACE_REPR = True

# Global values for lazy init-ing
CTAGS_LONG_TEXT = None
CTAGS = None
CLASSES = None  # Populated by get_all_classes()
API_CALLS = None  # Populated by get_all_api_calls()
TYPE_EXPLANATIONS = {}  # Slowly populated by get_type_explanation(). Read its docstring
ATTRIBUTES_FOR_CLASS = {}  # Slowyly populated by get_attributes_for_class(). Read its docstring.

# Importan types that are not handled by main approaches
SPECIAL_TYPES_EXPLANATION = {
    'in_addr_t': ('special', 'No explanation available'),
    'in_port_t': ('special', 'No explanation available'),
    'sx_api_handle_t': ('special', 'SX API handle - create with this oneliner: `rc, ' + color_text("handle") + ' = sx_api_open(None)`')
}

# These types are skipped
KNOWN_TYPES_WITHOUT_EXPLANATION = ['enum sxd_acl_ffar_op',
                                   'enum sxd_group_or_acl_binding_type',
                                   'enum ku_flood_table_type',
                                   'sxd_command_ifc_hw_t *',
                                   'enum ku_user_channel_type',
                                   'sx_l2_tunnel_params_t',
                                   'enum sxd_cpcs_operation',
                                   'enum spms_mstp_state [4096]',
                                   'enum spgt_operation',
                                   'rm_sdk_table_type_e',
                                   'struct iovec *',
                                   'sx_fc_addr_t',
                                   'enum ku_swid_type',
                                   'enum sfd_action',
                                   'enum sfgc_fid_bridge_type',
                                   'enum sfgc_flooding_type',
                                   'enum pci_profile_e',
                                   'enum ku_l2_type',
                                   'enum sxd_chip_rev',
                                   'enum sxd_chip_types',
                                   'enum sxd_ptce2_next_type',
                                   'enum sldr_operation',
                                   'enum ku_l2_type [8]',
                                   'enum sxd_vni_flex_action_type',
                                   'enum fdb_flush_type',
                                   'enum sxd_mrsr_command',
                                   'enum mhsr_health_mode',
                                   'enum sfd_policy',
                                   'cl_spinlock_t',
                                   'enum sxd_binding_cmd',
                                   'struct ibmad_port *',
                                   'enum ku_pkt_type',
                                   'enum ku_dpt_path_type',
                                   'void *',
                                   'cl_plock_t',
                                   'rm_hw_table_type_e',
                                   'enum sfd_operation',
                                   'enum sfn_type', 'enum sfd_type [64]']

SWIG_ARRAY_CONSTRUCTOR_PREFIX = "new_"
SWIG_ARRAY_CONSTRUCTOR_SUFFIX = "_t_arr"
NEW_ARRAY_CONSTRUCTOR_PREFIX = "create_"
NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PREFIX = "list_to_"

# This is a nasty thing to do. I'm using old % string replacement mechanism
# to generate a string which in turn is going to be parameterized with .format(type=)
# Patterns are, with currently defined **_PREFIXes: create_{type}_t_arr and list_to_{type}_t_arr
NEW_ARRAY_CONSTRUCTOR_PATTERN = "%s{type}%s" % (NEW_ARRAY_CONSTRUCTOR_PREFIX, SWIG_ARRAY_CONSTRUCTOR_SUFFIX)
NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN = "%s{type}%s" % (NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PREFIX, SWIG_ARRAY_CONSTRUCTOR_SUFFIX)


MAINTAINER = "julianp@mellanox.com"

#############################
# Main functions
#############################


def improve_api():
    """
    @summary: entry point, should be executed once to attach all the new improvements to sx_api and sxd_api
        it does the following:
            1) improves docstrings for all api calls (improve_api_calls_docstrings)
            2) adds wrappers for all api calls so they understand SwigArrayWrapper objects instead of normal arrays
            3) creates a create_XXX_arr() function for each existing new_XXX_arr() function which creates a
                 SwigArrayWrapper instead of a normal array
            4) adds constructors for structs and unions with all the attributes and docstrings
            5) add print mechanism for structs and unions
    """

    sdk_help()
    print('\nLoading {sx_api}, {sxd_api} and {sdk_api_cli}. It takes a few seconds, please wait...'.format(
        sx_api=color_text('sx_api', 'green'),
        sxd_api=color_text('sx_api', 'blue'),
        sdk_api_cli=color_text('sdk_api_cli', 'red')))
    ts = time.time()

    modify_api_calls()
    modify_structs()
    array_create_new_functions()

    amount, unit = get_time(ts)
    print('[%s] It took %2.2f %s' % (color_text("OK!", 'green'), amount, unit))


def get_time(start_time):
    amount = time.time() - start_time
    unit = "secs"

    if amount > 60:
        amount = amount / 60
        unit = "mins"
    return amount, unit


def sdk_help():
    """
    @summary: print a quick overview of the CLI, mostly for entertaining the user while the module loads
    """
    help = ("""

                        {welcome}

Quick overview:

    {b} sx_api and sxd_api modules are been imported to the environment now, so their objects are available
        {a} Try: type sx{tab} or sxd_api{tab}

    {b} Assistance functions:
        {a} {f1} and {f2}- List API calls
        {a} {f3} and {f4} - List classes (structs and unions)

        {b} Use them with or without filters. For example: {ex1}, {ex2}

        {a} Print this help with {help_func}

    {b} Need help? Ask! Use {qmark} or {help}()
        Check the parameters for API calls or classes, for example:
            {a} sx_api_span_mirror_tables_set{qmark}
            {a} {help}(sx_api_span_mirror_tables_set)
            {a} {cls_example}{qmark}
            {a} {help}({cls_example})"""
            ).format(welcome=color_text("~~~~") + color_text("Welcome to SDK API cli!", "green") + color_text("~~~~"),
                     constructor=STRUCT_CONSTRUCTOR_NAME,
                     cls_example="sx_port_attributes_t" if STRUCT_CONSTRUCTOR_NAME == '__init__' else ("sx_port_attributes_t.%s" % STRUCT_CONSTRUCTOR_NAME),
                     b=color_text("*", "red"),
                     a=color_text("->", "green"),
                     f1=color_text("sx_api_calls()"),
                     f2=color_text("sxd_api_calls()"),
                     f3=color_text("sx_classes()"),
                     f4=color_text("sxd_classes()"),
                     help=color_text("help"),
                     tab=color_text("<tab>"),
                     ex1=color_text('sx_classes(') + color_text('"router"', "green") + color_text(')'),
                     ex2=color_text('sx_api_calls()'),
                     qmark=color_text("?"),
                     help_func=color_text("sdk_help()"))
    # {b} Class constructor is {constructor}()
    # {b} List all the pointer types with
    print(help)


def print_elems_in_columns(elems):
    """
    @summary: print @elems 3 per row with colors
    """
    table_row = "\n{v}   {e1:<45} {v}   {e2:<45} {v}   {e3:<45} {v}"
    horizontal_border = color_text("-")
    vertical_border = color_text("|")
    table = (horizontal_border * 151)
    i = 0
    for i in range(0, len(elems) - 3, 3):
        table += table_row.format(v=vertical_border, e1=elems[i], e2=elems[i + 1], e3=elems[i + 2])

    if i + 3 == len(elems) - 1:
        table += table_row.format(v=vertical_border, e1=elems[i + 3], e2="", e3="")
    elif i + 4 == len(elems) - 1:
        table += table_row.format(v=vertical_border, e1=elems[i + 3], e2=elems[i + 4], e3="")
    elif i + 5 == len(elems) - 1:
        table += table_row.format(v=vertical_border, e1=elems[i + 3], e2=elems[i + 4], e3=elems[i + 5])

    table += "\n" + (horizontal_border * 151)
    print(table)


def print_api_calls(mod, contains=None):
    """
    @summary: print api calls for some module @mod
    @param mod: "sx_api" or "sxd_api"
    @param contains: if provided, a string to filter api calls that contains it
    """
    elems = []
    for api_call, module, _, _ in get_all_api_calls():
        if module == mod:
            if not contains or contains in api_call:
                elems.append(api_call)
    print_elems_in_columns(elems)


def print_classes(mod, contains=None):
    """
    @summary: print api calls for some module @mod
    @param mod: "sx" or "sxd"
    @param contains: if provided, a string to filter api calls that contains it
    """
    elems = []
    for cls, _, module in get_all_classes():
        if module == mod:
            if not contains or contains in cls:
                elems.append(cls)
    print_elems_in_columns(elems)


def sx_classes(contains=None):
    print_classes("sx", contains)


def sxd_classes(contains=None):
    print_classes("sxd", contains)


def sx_api_calls(contains=None):
    print_api_calls("sx_api", contains)


def sxd_api_calls(contains=None):
    print_api_calls("sxd_api", contains)


def get_all_api_calls():
    """
    @summary get all the api calls from sx_api and sxd_api
    @return [(function name (string), module name (string, "sx_api" or "sxd_api", function reference, module reference))]
    """
    global API_CALLS
    if not API_CALLS:
        API_CALLS = []
        for mod in [sx_api, sxd_api]:
            API_CALLS += [(func, mod.__name__, getattr(mod, func), mod) for func in dir(mod)
                          if not func.endswith(("assign", "value", "setitem", "getitem", "_arr", "_p", "_t", "register"))
                          and not func.startswith(("_"))
                          and isinstance(getattr(mod, func), FunctionType)
                          and func not in EXCLUDE_API_CALLS]
    return API_CALLS


def get_all_classes():
    """
    @summary: return all classes in sx_api and sxd_api modules
    @return [(class name (string), class object, "sx" or "sxd" - depending on module in which the class was found)]
    """
    global CLASSES
    if not CLASSES:
        sx_cls = [(class_name, class_object, "sx") for (class_name, class_object) in inspect.getmembers(sys.modules["python_sdk_api.sx_api"], inspect.isclass)
                  if not class_name.startswith("_") and class_name not in EXCLUDE_CLASSES]
        sxd_cls = [(class_name, class_object, "sxd") for (class_name, class_object) in inspect.getmembers(sys.modules["python_sdk_api.sxd_api"], inspect.isclass)
                   if not class_name.startswith("_") and class_name not in EXCLUDE_CLASSES]
        CLASSES = sx_cls + sxd_cls
    return CLASSES


def read_ctags(get_text=False):
    """
    @summary lazy load ctags for sx and sxd headers.
            tags generated this way: ctags --fields=afmikKlnsStz *
            applibs/include/sx/sdk/
            sxd_libs/include/sx/sxd/
    """
    global CTAGS, CTAGS_LONG_TEXT
    if not CTAGS or not CTAGS_LONG_TEXT:
        with open(TAGS[0]) as fp1:
            with open(TAGS[1]) as fp2:
                tags1 = fp1.read()
                tags2 = fp2.read()
                ctags1 = [["sx"] + line.split("\t") for line in tags1.splitlines()]
                ctags2 = [["sxd"] + line.split("\t") for line in tags2.splitlines()]
                CTAGS = ctags1 + ctags2
                CTAGS_LONG_TEXT = tags1 + tags2

    return (CTAGS_LONG_TEXT if get_text else CTAGS)


def is_base_type(a_type):
    return is_int(a_type) or is_bool(a_type) or is_char(a_type) or is_float(a_type)


def is_int(a_type):
    return a_type.startswith("uint") or a_type.startswith("u_int") or a_type.startswith("int") or\
        a_type in ['u_int16_t', 'uint16_t'] or a_type.startswith("unsigned int")


def is_char(a_type):
    return a_type in ['unsigned char', 'char']


def is_bool(a_type):
    return a_type == 'sxd_boolean_t' or a_type.startswith("boolean")


def is_float(a_type):
    return a_type in ['double', 'unsigned long']


def is_struct(a_type):
    try:
        res = getattr(sx_api, a_type)
    except BaseException:
        try:
            res = getattr(sxd_api, a_type)
        except BaseException:
            res = False
    return res


def get_type_explanation(a_type):
    """
    @summary: find out what is @a_type, categorize it, and propose an human-friendly explanation of how to locate and create it
    @return (category_token, explanation string)
    """
    global TYPE_EXPLANATIONS

    original_type = a_type

    # quick exits for list-based or dict-based cases
    if a_type in KNOWN_TYPES_WITHOUT_EXPLANATION:
        return ("skip", FAILED_TO_EXPLAIN)

    if a_type in SPECIAL_TYPES_EXPLANATION:
        TYPE_EXPLANATIONS[a_type] = SPECIAL_TYPES_EXPLANATION[a_type]

    # this dictionary is lazy initialized by this function
    if a_type in TYPE_EXPLANATIONS:
        return TYPE_EXPLANATIONS[a_type]

    res = FAILED_TO_EXPLAIN
    is_array = False
    is_pointer = False

    # Sometimes types come with these prefixes, remove them and keep the rest
    if " " in a_type and a_type.startswith("enum "):
        a_type = a_type.replace("enum ", "")

    if " " in a_type and a_type.startswith("struct "):
        a_type = a_type.replace("struct ", "")

    # Remove array suffix "[XXX]" and note is_array=True, will modify the explanation with this info later
    if " " in a_type and a_type.strip().endswith("]") and "[" in a_type and a_type.count("[") == 1:
        is_array = True
        a_type = a_type[0:a_type.find("[") - 1]

    # Remove pointer suffix "*" and note is_pointer=True, will modify the explanation with this info
    if " " in a_type and a_type.strip().endswith("*"):
        is_pointer = True
        a_type = a_type.strip()[:-1].strip()

    # Same as before, but after striping annoying parts
    if a_type in SPECIAL_TYPES_EXPLANATION:
        TYPE_EXPLANATIONS[a_type] = SPECIAL_TYPES_EXPLANATION[a_type]
        return SPECIAL_TYPES_EXPLANATION[a_type]

    if a_type in KNOWN_TYPES_WITHOUT_EXPLANATION:
        return ("skip", FAILED_TO_EXPLAIN)

    # We don't support matrixes explanations. They are edge cases.
    if " " in a_type and a_type.strip().endswith("]") and "[" in a_type and a_type.count("[") > 1:
        return ("matrix", "Matrix: %s" % FAILED_TO_EXPLAIN)

    # Main cases

    if is_base_type(a_type):  # Base types (int, boolean, float, char) => handled by a helper function
        res = _get_base_type_explanation(a_type)
    elif " " in a_type:  # This case is now happening now, but the case may appear later on
        res = ("unknown_space", a_type)
    else:  # structs or use ctags
        try:
            getattr(sx_api, a_type)  # struct from sx_api
            res = ("sx_api_struct", "Struct belonging to sx_api, sx_api.{type}".format(type=a_type))
        except BaseException:
            try:
                getattr(sxd_api, a_type)  # struct from sxd_api
                res = ("sxd_api_struct", "Struct belonging to sxd_api, sxd_api.{type}".format(type=a_type))
            except BaseException:  # check with ctags files
                res = _get_ctags_type_explanation(a_type)

    # Add information if it's an array or a pointer
    if is_array:
        if res[0] == "enum":
            res = ("enum_array", res[1])
        else:
            res = (res[0], "%s [] (an array, create with create_%s_arr or use a python list of %s)" % (res[1], a_type, res[1]))

    if is_pointer:
        res = (res[0], "%s *" % res[1])

    # Save type information
    TYPE_EXPLANATIONS[original_type] = res
    return res


def _get_base_type_explanation(a_type):
    """
    @summary: an auxiliary function for get_type_explanation(), handles base types expalantion
    """
    if is_int(a_type):
        doc = "int"
    elif is_bool(a_type):
        doc = "boolean"
    elif is_char(a_type):
        doc = "char (int < 8)"
    elif is_float(a_type):
        doc = "float"
    return ("base_type", doc)


def _get_ctags_type_explanation(a_type):
    """
    @summary: search in the ctag files (there is one for sx_api and one for sxd_api)
              for information about @a_type with ad-hoc mechanisms
    @note the function is pretty obscure, since it's parsing a file which is obscure
    @return (category_token, explanation string)
    """
    # Check if the type appears in the full text of both files, to save time. Maybe it doesn't.
    if a_type not in read_ctags(get_text=True):
        return ("failed", FAILED_TO_EXPLAIN)

    ctags = read_ctags()

    for ctag in [ctag for ctag in ctags if a_type in ''.join(ctag)]:
        # This means: "It's the name of an enum typedef"
        if len(ctag) == 8 and a_type == ctag[1] and ctag[7].startswith("typeref:enum:"):
            # Since enums typedefs have 2 names (typedef TYPE1 {} TYPE2;), here we translate one to the other
            real_type = ctag[7].strip().replace("typeref:enum:", "")

            # And in this for we search for the possible values of the enum, and save them in values_for_enum
            # values_for_enum is a list of (enum value name (string), module name (string))
            values_for_enum = []
            for ctag2 in ctags:
                if len(ctag2) == 8 and ctag2[7].strip() == ("enum:%s" % real_type):
                    value_for_enum = ctag2[1]
                    try:
                        getattr(sx_api, value_for_enum)
                        values_for_enum.append((value_for_enum, "sx_api"))
                    except BaseException:
                        try:
                            getattr(sxd_api, value_for_enum)
                            values_for_enum.append((value_for_enum, "sxd_api"))
                        except BaseException:  # A value was found, but was not located in any known module
                            values_for_enum.append((value_for_enum, "Not found"))

            if not values_for_enum:
                return ("enum_no_values", "It's an enum, but no values could be found for it")
            else:
                return ("enum", values_for_enum)
        elif len(ctag) == 7 and a_type == ctag[1] and ctag[4] == "kind:typedef":
            # This case is for typedefs.
            # We handle:
            #   1) synonyms of base types
            #   2) synonyms of synonyms^N of basetypes (with recursion, this can be improved if needs time improvement)
            #   3) Any other case is a FAILED_TO_EXPLAIN case
            the_type = ctag[3].split()[1]
            if is_base_type(the_type):  # 1) synonyms of base types
                return _get_base_type_explanation(the_type)
            else:
                res = get_type_explanation(the_type)  # indirect recursion
                if res[0] == 'base_type_syn' or res[0] == 'base_type':  # 2) synonyms of synonyms^N of basetypes
                    return res
                else:
                    return ("ctag_mapped_to_unknown", FAILED_TO_EXPLAIN)  # 3) Any other case is a FAILED_TO_EXPLAIN case

    # If no other return catched it, it's a FAILED_TO_EXPLAIN case
    return ("Unhandled CTAG", FAILED_TO_EXPLAIN)


def modify_structs():
    """
    @summary: add a constructor and improve print functiosn for each existing class (struct + unions)
    """
    ctags = read_ctags()
    classes = get_all_classes()
    for cls_name, cls, _ in classes:
        res = struct_add_constructor(cls)
        struct_improve_print_functions(cls)


def struct_add_constructor(cls):
    """
    @summary: add constructor with all attributes as parameters and nice docstrings to @cls
    @see struct_create_constructor()
    @see get_type_explanation()
    """
    explanations = {}
    attrs = get_attributes_for_class(cls)
    for attr, a_type in attrs:
        explanations[attr] = get_type_explanation(a_type)
    func = struct_create_constructor(attrs, cls, explanations)
    if STRUCT_CONSTRUCTOR_NAME == "__init__":
        setattr(cls, STRUCT_CONSTRUCTOR_NAME, func)
    else:
        setattr(cls, STRUCT_CONSTRUCTOR_NAME, classmethod(func))


def struct_create_constructor(attrs, cls, explanations):
    """
    @summary: create a constructor which receives attrs
    @parameter attrs: [(attr_name, attr_type)] as returned by get_attributes_for_class()
    @parameter cls: the class object to which we are creating to constructor to
    @parameter explanations: a dictionary with attr_names as keys and (type_category, explanation data) as values
    @return the created constructor (a function object)
    """
    # This is the parameter list for the function signature
    params = ', '.join([("%s=None" % attr) for attr, _ in attrs])

    # This is the main body of the function, where objects attributes are set based on parameters
    params_set = '\n    '.join([("if %s is not None: obj.%s=%s" % (attr, attr, attr)) for attr, _ in attrs])

    def handle_nested_attribute(attr, a_type, nest_list):
        """
        @summary: handle one attribute if it's a nested one, by getting in the structure
                    since the SWIG unions don't assign correctly
                  it enters recursively in the data structures assigning each element
        @example:
            try:
                if ifc is not None and ifc.vlan is not None: obj.ifc.vlan = ifc.vlan
            except:
                pass

            try:
                if ifc is not None and ifc.vlan is not None and ifc.vlan.swid is not None: obj.ifc.vlan.swid = ifc.vlan.swid
            except:
                pass

            try:
                if ifc is not None and ifc.vlan is not None and ifc.vlan.vlan is not None: obj.ifc.vlan.vlan = ifc.vlan.vlan
            except:
                pass

            try:
                if ifc is not None and ifc.vport is not None: obj.ifc.vport = ifc.vport
            except:
                pass


        """
        params_set = ""
        new_nest_list = nest_list[:] + [attr]
        struct = is_struct(a_type)
        if struct:
            nested_attrs = get_attributes_for_class(struct)
            for nested_attr, nested_type in nested_attrs:
                full_stack_of_elements = new_nest_list + [nested_attr]
                if_clauses = []
                for i in range(1, len(full_stack_of_elements) + 1):
                    if_clauses.append(full_stack_of_elements[:i])
                clause = ' and '.join(['.'.join(clause_items) + " is not None" for clause_items in if_clauses])
                if_condition = "if %s:" % clause

                assignation = '.'.join(full_stack_of_elements)
                assignation = "obj.%s = %s" % (assignation, assignation)

                params_set += """\n    try:
        {if_condition} {assignation}
    except:
        pass
""".format(if_condition=if_condition, assignation=assignation)
                params_set += handle_nested_attribute(nested_attr, nested_type, new_nest_list)
        return params_set

    # This is a params_set concept, but nested, since unions don't work as one would want to
    for attr, a_type in attrs:
        params_set += handle_nested_attribute(attr, a_type, [])

    # This are helpers for the docstring
    params_explanation = get_docstring_for_elements([(attr, a_type, explanations[attr][0], explanations[attr][1]) for attr, a_type in attrs])

    # This is the docstring
    docstring = """
    @summary: {func_name}({params}) --> {cls}
    @parameters:
        {params_explanation}

                """.format(func_name=STRUCT_CONSTRUCTOR_NAME, params=', '.join([attr for attr, _ in attrs]),
                           cls=cls.__name__, params_explanation=params_explanation
                           )

    if STRUCT_CONSTRUCTOR_NAME != '__init__':

        # And this is the code
        code = '''def {func_name}(cls, {params}):
    """ {docstring}
    """
    obj = cls()
    {params_set}
    return obj
'''.format(func_name=STRUCT_CONSTRUCTOR_NAME,
           params=params,
           params_set=params_set, docstring=docstring)
    else:
        # And this is the code
        code = '''def {func_name}(self, {params}):
    """ {docstring}
    """
    import _sx_api
    this = _sx_api.new_{cls_name}()
    try: self.this.append(this)
    except: self.this = this
    obj = self
    {params_set}
'''.format(func_name=STRUCT_CONSTRUCTOR_NAME,
           params=params, cls_name=cls.__name__,
           params_set=params_set, docstring=docstring)

    if VERBOSE:
        print(code)

    # Text => Code (the "cleaner" procedure I found)
    d = {}
    exec(code, d)
    constructor = d[STRUCT_CONSTRUCTOR_NAME]

    return constructor


def get_attributes_for_class(class_obj):
    """
    @summary: extract attributes from class
    @param class_obj: the class object to extract the attributes from
    @return [(attribute, attribute type string)]
    @note the attribute type string may be something strange
    """
    global ATTRIBUTES_FOR_CLASS
    if class_obj.__name__ not in ATTRIBUTES_FOR_CLASS:
        try:
            ATTRIBUTES_FOR_CLASS[class_obj.__name__] = [(elem, getattr(class_obj, elem).__doc__.splitlines()[1].split("->")[1].strip()) for elem in dir(class_obj) if not elem.startswith("__")]
        except BaseException:
            import pdb
            pdb.set_trace()
    return ATTRIBUTES_FOR_CLASS[class_obj.__name__]


def get_attributes_specification(cls):
    """
    @summary: auxiliary function for struct_improve_print_functions()
              construct a json-dictionary-like string for the object
    @note NEST_STR_REPRESENTATIONS will print nested structs, in other case the type name plus the string "[nested]"
    @example:
        it's creating the of this:
            sx_port_attributes_t(log_port: 65537, port_mapping: sx_port_mapping_t(lane_bmap: 15, local_port: 1, mapping_mode: 1, module_port: 8, width: 4)[sx_port_mapping_t *][0x2cfe6c0], port_mode: 0)[sx_port_attributes_t *][0x2cfe5d0]
        i.e.:
            log_port: 65537, port_mapping: sx_port_mapping_t[nested], port_mode: 0
    """
    attrs = get_attributes_for_class(cls)
    the_str = ""

    for attr, attr_type in attrs:
        if is_struct(attr_type):
            if NEST_STR_REPRESENTATIONS:
                pattern = "{0}: ' + str(getattr(self, '{0}')) + ', "
            else:
                pattern = "{0}: ' + str(type(getattr(self, '{0}')).__name__) + '[nested], "
        else:
            pattern = "{0}: ' + str(getattr(self, '{0}')) + ', "
        the_str += pattern.format(attr)

    if the_str != "":
        the_str = the_str[:-2]
    return the_str


def struct_improve_print_functions(cls):
    """
    @summary: replace __str__ and __repr__ for all structs and unions
    @parameter attrs: [(attr_name, attr_type)] as returned by get_attributes_for_class()
    @parameter cls: the class object to which we are creating to constructor to
    @parameter explanations: a dictionary with attr_names as keys and (type_category, explanation data) as values
    @return the created constructor (a function object)
    """
    attr_spec = get_attributes_specification(cls)
    # And this is the code
    code = '''def __str__(self):
    """ @summary: a replacement of the original __str__(), it's located in use old_str()
    """
    import re
    old_str = self.old_str()
    the_type = old_str[old_str.find(".")+1:old_str.find(";")]
    match = re.search("Swig Object of type '(.*)' at (.*)> >", old_str)
    if match:
        swig_type = match.group(1)
        hexa = match.group(2)
        new_str = ('{the_type}(%s)[{swig_type}][{hexa}]').format(the_type=the_type,
                                                                 swig_type=swig_type,
                                                                 hexa=hexa)
    else:
        new_str = ('{the_type}(%s)').format(the_type=the_type)
    return new_str
''' % (attr_spec, attr_spec)

    if VERBOSE:
        print(code)

    # Text => Code (the "cleaner" procedure I found)
    d = {}
    exec(code, d)
    repr_func = d["__str__"]

    # Check this http://stackoverflow.com/questions/1436703/difference-between-str-and-repr-in-python
    # And this: https://docs.python.org/2.7/reference/datamodel.html
    if REPLACE_REPR:
        setattr(cls, "old_str", cls.__repr__)
        setattr(cls, "__repr__", repr_func)
    else:
        setattr(cls, "old_str", cls.__str__)
        setattr(cls, "__str__", repr_func)


def array_create_new_functions():
    """
    @summary: create a create_TYPE_t_arr and a list_to_TYPE_t_arr
                for each existing new_TYPE_t_arr
        * new_TYPE_t_arr ==> provided by swig, creates a swig array
        * create_TYPE_t_arr ==> provided by array_create_new_function(), appened to relevant module
                it creates a SwigArrayWrapper
                it's an objects that wraps a swig array but works as a python list
        * list_to_TYPE_t_arr ==> provided by array_create_new_function_from_list()
                it receives a python list of objects and translated it to a SwigArrayWrapper

        The functions are exposed but this will probably change soon.
        IMPORTANT: The main utility of this functions is to collaborate in the API calls wrapping
            The actual flow is the following:
                --> list_to_TYPE_t_arr uses create_TYPE_t_arr, which in turn uses new_TYPE_t_arr
                --> The API call wrapper uses list_to_TYPE_t_arr to create a SwigArrayWrapper + the method .to_swig() of this object
    @see api_call_decorate() <-- Here is where this is used.
    @see SwigArrayWrapper
    @see array_create_new_function()
    @see array_create_new_function_from_list()
    """
    for module in [sx_api, sxd_api]:
        new_arr = [x for x in dir(module) if x.startswith(SWIG_ARRAY_CONSTRUCTOR_PREFIX) and x.endswith(SWIG_ARRAY_CONSTRUCTOR_SUFFIX)]
        keywords = [x[len(SWIG_ARRAY_CONSTRUCTOR_PREFIX):-(len(SWIG_ARRAY_CONSTRUCTOR_SUFFIX))] for x in new_arr]
        for a_type in keywords:
            array_create_new_function(a_type, module)
            array_create_new_function_from_list(a_type, module)


def array_create_new_function(a_type, module):
    """
    @summary: create a create_{@a_type}_t_arr, which creates a SwigArrayWrapper,
              and append it to @module
              create_{@a_type}_t_arr() signature is:
              create_{@a_type}_t_arr(int length) --> SwigArrayWrapper object for type @a_type with length @length
    @note the create_TYPE_t_arr function set is not supposed to be used by the user
           since the API calls wrapping is already doing everything.
    @see array_create_new_functions() for a detailed explanation of the use of this function
    """

    ARRAY_CREATE_FUNC = NEW_ARRAY_CONSTRUCTOR_PATTERN.format(type=a_type)

    docstring = """
    @summary: create an array wrapper class
    @parameters:
        length of the array

                """.format(func_name=ARRAY_CREATE_FUNC)

    code = '''def {func_name}(length=0):
    """ {docstring}
    """
    from sdk_api_cli import SwigArrayWrapper
    try:
        from python_sdk_api.sx_api import {prefix}{type}{suffix}
    except:
        try:
            from python_sdk_api.sxd_api import {prefix}{type}{suffix}
        except:
            raise Exception("Type {type} is unknown")
    # Create a SwigArrayWrapper of type {type} with the actual swig array as first parameter
    array = SwigArrayWrapper({prefix}{type}{suffix}(length), length, "{type}")
    return array
'''.format(func_name=ARRAY_CREATE_FUNC,
           type=a_type,
           docstring=docstring,
           module=module.__name__,
           suffix=SWIG_ARRAY_CONSTRUCTOR_SUFFIX,
           prefix=SWIG_ARRAY_CONSTRUCTOR_PREFIX)

    if VERBOSE:
        print(code)
    d = {}
    exec(code, d)

    setattr(module, ARRAY_CREATE_FUNC, d[ARRAY_CREATE_FUNC])


def array_create_new_function_from_list(a_type, module):
    """
    @summary: create a list_to{@a_type}_t_arr, and append it to @module

        list_to{@a_type}_t_arr() signature is:
         list_to{@a_type}_t_arr(list a_list) --> SwigArrayWrapper object of length len(@a_list)
            With the type inferred from the types of the elements of the lists.
            The elements should have the same type
            None is allowed, and will increase the size of the created array once it's translated
    @see array_create_new_functions() for a detailed explanation of the use of this function
    """

    ARRAY_CREATE_FROM_LIST_FUNC = NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=a_type)

    # First function: create_name_t_arr
    docstring = """
    @summary: create an array wrapper class from a list
    @parameters:
        @a_list: a list of swig objects of the same type.
            It can have None too, in which case they will affect the length of the swig array.
            No more than one type can be provided, i.e.: all the elements should be None or of the same type

                """.format(func_name=ARRAY_CREATE_FROM_LIST_FUNC)

    code = '''def {func_name}(a_list):
    """ {docstring}
    """
    try:
        from python_sdk_api.sx_api import {prefix}{type}{suffix}
    except:
        try:
            from python_sdk_api.sxd_api import {prefix}{type}{suffix}
        except:
            raise Exception("Type {type} is unknown")
    # Create a SwigArrayWrapper of type {type} and length len(a_list)
    array = {prefix}{type}{suffix}(len(a_list))

    # Append the elements to the array
    for item in a_list:
        #if item is not None:
        array.append(item)

    return array
'''.format(func_name=ARRAY_CREATE_FROM_LIST_FUNC,
           type=a_type,
           docstring=docstring,
           module=module.__name__,
           prefix=NEW_ARRAY_CONSTRUCTOR_PREFIX,
           suffix=SWIG_ARRAY_CONSTRUCTOR_SUFFIX)

    if VERBOSE:
        print(code)
    d = {}
    exec(code, d)

    setattr(module, ARRAY_CREATE_FROM_LIST_FUNC, d[ARRAY_CREATE_FROM_LIST_FUNC])


def modify_api_calls():
    """
    @summary: improve api call docstrings and replace each api call with a wrapped version of itself
               that understands python lists
    @see api_call_new_docstring()
    @see api_call_decorate()
    """
    for function_name, module_name, function, module in get_all_api_calls():
        # preserve the order between api_call_new_docstring() and api_call_decorate() just in case

        # improve docstrings
        new_doc = api_call_new_docstring(function.__doc__)
        function.__doc__ = new_doc

        # replace function with a wrapped version of itself
        setattr(module, function_name, api_call_decorate(getattr(module, function_name)))


def api_call_decorate(func):
    """
    @summary: wrap the function @func with new_api_call(), which has the following functionality:
                Before calling the function:
                    1) Map SwigArrayWrapper intro an actual swig array
                    2) Map a list of objects into a SwigArrayWrapper and this into a swig array
                After calling the function:
                    1) Recreate the list parameters to point to the modified objects
    @note called only from modify_api_calls()
    """

    @wraps(func)
    def new_api_call(*args, **kwargs):
        if VERBOSE:
            print(("Calling function %s with parameters %s and %s" % (func.__name__, args, kwargs)))

        # The replacements of args and kwargs
        new_args = []
        new_kwargs = {}

        # Old the original reference and the new one to override to do original=new on return-time
        lists_map = []

        for arg in args:
            # For lists, get the types of the elements: one type + None is permitted.
            # A list with elements of different types raises and exception
            if arg.__class__.__name__ in ('list'):

                types = list(set([type(elem) for elem in arg]))
                if not arg:
                    raise Exception("Can't pass empty python list, use constructors.")
                if len(types) > 1 and NoneType not in types:
                    raise Exception("Can't pass more than one type per list")
                if len(types) > 1:
                    types = [a_type for a_type in types if a_type != NoneType]

                the_type = (types[0].__name__)[:-2]

                # Get the function which translates python lists into swig arrays (try with sx_api and sxd_api)
                # These functions are created in array_create_new_functions()
                try:
                    wrapped_array_constructor = getattr(sx_api, NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                except BaseException:
                    try:
                        wrapped_array_constructor = getattr(sxd_api, NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                    except BaseException:
                        raise Exception("Can't find %s anywhere" % NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                print("Mapped list to swig")
                # The function translates the python list into a SwigArrayWrapper

                wrapped_list = wrapped_array_constructor(arg)

                # Save the link with the argument and the new object
                lists_map.append((arg, wrapped_list))

                # Ask the SwigArrayWrapper to translate itself into a swig array
                # and append it to the parameters of the final function call
                new_args.append(wrapped_list.to_swig())

            elif arg.__class__.__name__ == "SwigArrayWrapper":
                # For a SwigArrayWrapper we just need to translate it
                # This object is exposed, but it will probably not be used and this clause may be removed later on.
                print("Mapped SwigArrayWrapper to swig")
                new_args.append(arg.to_swig())
            else:
                # Forward the rest of the arguments
                new_args.append(arg)
        # All the same for keywords. Code is replied because I don't want to depend upon functions here.
        for key, value in list(kwargs.items()):
            if value.__class__.__name__ in ('list'):
                types = list(set([type(elem) for elem in value]))
                if not value:
                    raise Exception("Can't pass empty python list, use constructors.")
                if len(types) > 1 and NoneType not in types:
                    raise Exception("Can't pass more than one type per list")
                if len(types) > 1:
                    types = [a_type for a_type in types if a_type != NoneType]

                the_type = (types[0].__name__)[:-2]
                try:
                    wrapped_array_constructor = getattr(sx_api, NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                except BaseException:
                    try:
                        wrapped_array_constructor = getattr(sxd_api, NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                    except BaseException:
                        raise Exception("Can't find %s anywhere" % NEW_ARRAY_FROM_LIST_CONSTRUCTOR_PATTERN.format(type=the_type))
                print("Mapped list to swig")
                wrapped_list = wrapped_array_constructor(value)
                lists_map.append((arg, wrapped_list))
                new_kwargs[key] = wrapped_list.to_swig()
            elif value.__class__.__name__ == "SwigArrayWrapper":
                print("Mapped SwigArrayWrapper to swig")
                new_kwargs[key] = value.to_swig()
            else:
                new_kwargs[key] = value

        # Call the API here!
        res = func(*new_args, **new_kwargs)

        # Populate the original lists in the arguments with the populated elements actually passed as parameters
        for original, new in lists_map:
            for i in range(0, len(original)):
                original[i] = new[i]

        # Note:In/out arrays are handled correctly and "re-wrapped"
        #       We don't handle returned arrays in this version
        #       That involves deternining the type of `res` and wrapping it if it's the case

        # The wrapper finally returns the wrapped function result
        return res
    # The wrapping function return the wrapper function
    return new_api_call


def api_call_new_docstring(old_doc):
    """
    @summary: parse existing docstring for some API call (@old_doc), extract parameters and types
              and call get_docstring_for_elements() to generate an docstring,
              then append it to the old_doc and return it

    @param old_doc: the full docstring of a function, as swig is creating them (func_obj.__doc__)
    @return old_doc + new_explanations (i.e., this has a lot of sense: func_obj.__doc__ = api_call_new_docstring(func_obj.__doc__)

    @example: we are parsing something like the following
    sx_api_span_mirror_tables_set(sx_api_handle_t const handle, sx_access_cmd_t const cmd, sx_span_session_id_t const span_session_id) -> sx_status_t

    Parameters:
        handle: sx_api_handle_t const
        cmd: enum sx_access_cmd_t const
        span_session_id: sx_span_session_id_t const

    And appending something as the following:
     Parameter name       Parameter type           Explanation
     * handle:            sx_api_handle_t          SX API handle - create with this oneliner: `rc, handle = sx_api_open(None)`
     * cmd:               sx_access_cmd_t          Enum from module sx_api with values:
                                                       SX_ACCESS_CMD_ADD, SX_ACCESS_CMD_ADD_PORTS, SX_ACCESS_CMD_APPLY, SX_ACCESS_CMD_BIND,
                                                       SX_ACCESS_CMD_COUNT, SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DELETE, (...There are more...)
     * span_session_id:   sx_span_session_id_t     int

    """

    in_params = False  # Points if we are "in the parameters section", i.e.: After this line "Parameters:"

    # List of tuples with (parameter name, parameter type, parameter explanation keyword, parameter human explanation)
    # To be populated in the for
    params = []

    for line in old_doc.splitlines():
        # Continue until "Parameters:" line is reached
        if line.strip() and in_params:
            try:
                split_1 = line.split(":")
                param = split_1[0].strip()
                split_2 = split_1[1].split()
                if split_2[0].strip() in ["enum"]:
                    split_2 = split_2[1:]

                param_type = split_2[0].strip()
                x = get_type_explanation(a_type=param_type)
                params.append((param, param_type, x[0], x[1]))

            except BaseException:
                traceback.print_exc()
                print(('Warning, there was an unexpected exception in api_call_new_docstring(), report it to %s' % MAINTAINER))

        # Enter the parameters section
        if line.strip() == "Parameters:":
            in_params = True

    new_doc = old_doc + get_docstring_for_elements(params, element_type="Parameter")
    return new_doc


def get_docstring_for_elements(elements_types_and_explanations, element_type="Attribute"):
    """
    @summary: generate the full new section of the docstrings, which consists of 3 "columns":
              attribute or parameter ("element") name, element type and human readable explanation
    @note called from api_call_new_docstring() and from struct_create_constructor()
            it is basically the same, in one we are generating a docstring for parameters and in the other for attributes
    @param elements_types_and_explanations: [(element, element_type, type_category, data_for_explanation)]
            where data_for_explanation is a straigthforward string in the general case
            and:
                if type_category == 'enum' or 'enum_array': then the data_for_explanation is a list of values for the enums [(enum name, enum module)]

    """

    first_column_length = max(max([0] + [len(elem) for elem, _, _, _ in elements_types_and_explanations]), len("%s name" % element_type)) + 5
    second_column_length = max(max([0] + [len(a_type) for _, a_type, _, _ in elements_types_and_explanations]), len("%s type" % element_type)) + 5

    header_format = "%-{first}s %-{second}s%-{third}s".format(first=first_column_length, second=second_column_length, third=40)

    elems_format = "* %-{first}s %-{second}s%-{third}s".format(first=first_column_length - 2, second=second_column_length, third=40)

    # This for is just for reformulating enums and enum_arrays, calling _generate_enum_presentation
    # The rest is just passed directly from elements_types_and_explanations to new_explanations
    # new_explanations = [(elem, elem_type, type_category, explanation_data)]
    new_explanations = []
    for elem, elem_type, type_category, explanation_data in elements_types_and_explanations:
        if type_category in ['enum', 'enum_array']:
            if type_category == 'enum_array':
                prefix = "List of enums"
            else:
                prefix = "Enum"
            spaces = (first_column_length + second_column_length + 10) * ' '
            try:
                modules = list(set([mod for _, mod in explanation_data]))
            except BaseException:
                pass
            if len(modules) == 1:
                values = _generate_enum_presentation(spaces, [value for value, _ in explanation_data])
                explanation_data = ("{prefix} from module {module} with values: {values}").format(values=values, module=modules[0], prefix=prefix)
            else:
                values = _generate_enum_presentation(spaces, ["%s (%s)" % (value, mod) for value, mod in explanation_data])
                explanation_data = "{prefix} with values: {values}".format(values=values, prefix=prefix)

        new_explanations.append((elem, elem_type, type_category, explanation_data))

    # The actual header line
    header = header_format % ("%s name" % element_type, "%s type" % element_type, "Explanation")
    # And the rest of the rows, based on new_explanations items
    elems_explained = [(elems_format % ("%s:" % elem, a_type, explanation)) for elem, a_type, _, explanation in new_explanations]

    # Put header and rows together and return them
    return '\n     ' + ('\n     '.join([header] + elems_explained))


def _generate_enum_presentation(spaces, values):
    """
    @summary: auxiliary function for get_docstring_for_elements(), creates the presentation for enums and its values
              indenting to be aligned with the third column (i.e.: "Explanation")
              and wrapping the line at MAX_CHARS_LINE_BREAK
    @note set MAX_CHARS_LINE_BREAK in the header of this file
    @param spaces: the indentation
    @param values: the list of values to present
    @return string
    @example: it does this part of the docstring:
                                       SX_ACCESS_CMD_ADD, SX_ACCESS_CMD_ADD_PORTS, SX_ACCESS_CMD_APPLY, SX_ACCESS_CMD_BIND,
                                       SX_ACCESS_CMD_COUNT, SX_ACCESS_CMD_CREATE, SX_ACCESS_CMD_DELETE, SX_ACCESS_CMD_DELETE_ALL,
                                       SX_ACCESS_CMD_DELETE_PORT, SX_ACCESS_CMD_DELETE_PORTS, SX_ACCESS_CMD_DEREGISTER,
                                       SX_ACCESS_CMD_DISABLE, SX_ACCESS_CMD_EDIT, SX_ACCESS_CMD_ENABLE, SX_ACCESS_CMD_GET,
                                       SX_ACCESS_CMD_GET_ALL, SX_ACCESS_CMD_GET_FIRST, SX_ACCESS_CMD_MAX, SX_ACCESS_CMD_MIN,
                                       SX_ACCESS_CMD_READ, SX_ACCESS_CMD_READY, SX_ACCESS_CMD_READ_CLEAR, SX_ACCESS_CMD_REGISTER,
                                       SX_ACCESS_CMD_SET, SX_ACCESS_CMD_SOFT_ADD, SX_ACCESS_CMD_SOFT_DELETE, SX_ACCESS_CMD_SOFT_EDIT,
                                       SX_ACCESS_CMD_TEST_HW, SX_ACCESS_CMD_UNBIND, SX_ACCESS_CMD_UNSET

    """
    lines = ""
    current_line = spaces
    for value in values:
        # line break when exceeded MAX_CHARS_LINE_BREAK
        if len(current_line + value + ", ") > MAX_CHARS_LINE_BREAK:
            lines += '\n' + current_line
            current_line = spaces
        else:
            current_line += value + ", "
    if current_line != spaces:
        lines += '\n' + current_line
    if lines.endswith(", "):
        lines = lines[:-2]
    return lines


class SwigArrayWrapper(object):
    """
    @summary: Wrap a Swig Array of some type with some length offering a iterable and a collection (list) interface

    The idea of the class is just to keep a simpler interface for the swig arrays

    Basically, it's a fixed array which supports
        1) Indexation for getting and setting, i.e.: print obj[i] or obj[i] = value
        2) For loops iteration
        3) Appending with obj.append() - up to length
        3) Translate itself to the base swig array with obj.to_swig()

    """

    def __init__(self, array, length, type):
        self.index = 0
        self.array = array
        self.type = type
        self.length = length
        self.get_func = globals()["%s_t_arr_getitem" % type]
        self.set_func = globals()["%s_t_arr_setitem" % type]  # sx_acl_key_t_arr_setitem

    def __getattr__(self, name):
        if name not in ['array', 'length', 'get_func', 'set_func', 'type', 'index']:
            return getattr(self.array, name)
        elif name == 'array':
            return self.array
        else:
            return self.length

    def __setattr__(self, name, value):
        if name not in ['array', 'length', 'get_func', 'set_func', 'type', 'index']:
            return setattr(self.array, name, value)
        else:
            self.__dict__[name] = value

    def __repr__(self):
        return self.array.__repr__() + " (Wrapped)"

    def __str__(self):
        return self.array.__str__() + " (Wrapped)"

    def __getitem__(self, index):
        if index >= self.length:
            raise IndexError("Array has up to %s items" % self.length)
        return self.get_func(self.array, index)

    def __setitem__(self, index, value):
        if index >= self.length:
            raise IndexError("Array has up to %s items" % self.length)
        return self.set_func(self.array, index, value)

    def append(self, value):
        if self.index >= self.length:
            raise IndexError("Array has up to %s items, can't append more." % self.length)
        elif value is None:
            self.index += 1
        else:
            self[self.index] = value
            self.index += 1

    def __len__(self):
        return self.length

    def __iter__(self):
        for index in range(0, self.length):
            yield self[index]

    def to_swig(self):
        return self.array


if __name__ == '__main__':
    # Go!
    improve_api()
    # This re-import is needed to have the environment with the new array functions
    from python_sdk_api.sx_api import *
    from python_sdk_api.sxd_api import *
