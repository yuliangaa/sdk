/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_thread.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_shared_memory.h>
#include <complib/cl_mem.h>
#include <complib/cl_math.h>
#include "sx/obj_desc/sx_obj_desc_lib.h"

#undef  __MODULE__
#define __MODULE__ SX_OBJ_DESC_LIB

/************************************************
 *  Local Macros
 ***********************************************/
#define OBJ_DESC_MAX_LEN             (1024)
#define OBJ_DESC_POOL_MIN_ENTRY_NUM  (8 * 1024)
#define OBJ_DESC_POOL_GROW_ENTRY_NUM (8 * 1024)
#define OBJ_DESC_POOL_MAX_ENTRY_NUM  (256 * 1024)
#define OBJ_DESC_SHM_PATH            "/obj_desc"
#define OBJ_DESC_DEFAULT_DUMP_PATH   "/tmp/obj_desc_dump"

#define ACL_OBJ_MAP_KEY(region,                                                        \
                        offset)         ((((uint64_t)SX_OBJ_DESC_OBJECT_TYPE_ACL_E) << \
                                          56) | ((uint64_t)region << 32) | (offset));
#define ACL_OBJ_REGION_ID_GET(key_id)   ((key_id >> 32) & 0x00FFFFFF)
#define ACL_OBJ_RULE_OFFSET_GET(key_id) (key_id & 0xFFFFFFFF)
#define OBJ_KEY_TYPE_GET(key_id)        (key_id >> 56)
/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct obj_desc_plock {
    pthread_mutex_t mutex;
} obj_desc_lock_t;

typedef struct obj_desc_record {
    uint64_t key;
    char     desc[OBJ_DESC_MAX_LEN];
} obj_desc_record_t;

typedef struct obj_desc_shm_db {
    obj_desc_lock_t   lock;
    uint32_t          max_entry_num;
    uint32_t          free_slot_index;         /** First free slot index */
    obj_desc_record_t obj_desc_record[0];      /** Place keeper, actual size determined on init */
} obj_desc_shm_db_t;

typedef struct obj_desc_db {
    int                shm_id;
    size_t             shm_size;
    uint32_t           max_entry_num;
    obj_desc_shm_db_t *obj_desc_shm_db_p;
} obj_desc_db_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static obj_desc_db_t obj_desc_db_s;
static boolean_t     obj_desc_lib_initialized_s = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
static inline sx_obj_desc_status_t __lock_init(obj_desc_lock_t * const lock_p)
{
    int                 err = 0;
    pthread_mutexattr_t mutex_attr;

    err = pthread_mutexattr_init(&mutex_attr);
    if (err) {
        return SX_OBJ_DESC_STATUS_ERROR;
    }
    err = pthread_mutexattr_setpshared(&mutex_attr, PTHREAD_PROCESS_SHARED);
    if (err) {
        pthread_mutexattr_destroy(&mutex_attr);
        return SX_OBJ_DESC_STATUS_ERROR;
    }
    err = pthread_mutexattr_setrobust(&mutex_attr, PTHREAD_MUTEX_ROBUST);
    if (err) {
        pthread_mutexattr_destroy(&mutex_attr);
        return SX_OBJ_DESC_STATUS_ERROR;
    }
    err = pthread_mutex_init(&lock_p->mutex, &mutex_attr);
    pthread_mutexattr_destroy(&mutex_attr);
    if (err) {
        return SX_OBJ_DESC_STATUS_ERROR;
    }

    return SX_OBJ_DESC_STATUS_SUCCESS;
}

static inline void __lock_acquire(obj_desc_lock_t * const lock_p)
{
    int err = 0;

    err = pthread_mutex_lock(&lock_p->mutex);
    if (err) {
        if (err == EOWNERDEAD) {
            SX_LOG_WRN("The owner process acquired the lock crashed, recover it\n");
            err = pthread_mutex_consistent(&lock_p->mutex);
            if (err) {
                SX_LOG_ERR("Set mutex consistent err %d\n", err);
            }
        } else {
            SX_LOG_ERR("lock err %d\n", err);
        }
    }
}

static inline void __lock_release(obj_desc_lock_t * const lock_p)
{
    int err;

    err = pthread_mutex_unlock(&lock_p->mutex);
    if (err) {
        SX_LOG_ERR("unlock err %d\n", err);
    }
}

static sx_obj_desc_status_t __remap_shm(uint32_t max_entry_num, boolean_t resize)
{
    int                  err;
    size_t               size = 0;
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;
    obj_desc_shm_db_t   *obj_desc_shm_db_p = NULL;

    size = sizeof(obj_desc_shm_db_t) + sizeof(obj_desc_record_t) * max_entry_num;

    if (resize) {
        err = ftruncate(obj_desc_db_s.shm_id, size);
        if (err) {
            SX_LOG_ERR("truncate error %s\n", strerror(errno));
            return SX_OBJ_DESC_STATUS_ERROR;
        }
    }

    obj_desc_shm_db_p = mremap(obj_desc_db_s.obj_desc_shm_db_p, obj_desc_db_s.shm_size, size, MREMAP_MAYMOVE);
    if (obj_desc_shm_db_p == MAP_FAILED) {
        SX_LOG_ERR("Failed to map the shared memory of object description\n");
        return SX_OBJ_DESC_STATUS_ERROR;
    }

    obj_desc_shm_db_p->max_entry_num = max_entry_num;
    obj_desc_db_s.obj_desc_shm_db_p = obj_desc_shm_db_p;
    obj_desc_db_s.shm_size = size;
    obj_desc_db_s.max_entry_num = max_entry_num;

    return rc;
}

static sx_obj_desc_status_t __check_remap_shm()
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;

    if (obj_desc_db_s.obj_desc_shm_db_p->max_entry_num != obj_desc_db_s.max_entry_num) {
        rc = __remap_shm(obj_desc_db_s.obj_desc_shm_db_p->max_entry_num, FALSE);
        if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remap shared memory.\n");
            goto out;
        }
    }

out:
    return rc;
}

static sx_obj_desc_status_t __init_shm_db(void)
{
    int                  shm_id, err;
    size_t               size;
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;
    boolean_t            shm_create = FALSE;
    obj_desc_shm_db_t   *obj_desc_shm_db_p = NULL;
    boolean_t            shm_locked = FALSE;

    size = sizeof(obj_desc_shm_db_t) + sizeof(obj_desc_record_t) * OBJ_DESC_POOL_MIN_ENTRY_NUM;
    obj_desc_db_s.shm_size = size;

    err = cl_shm_create(OBJ_DESC_SHM_PATH, &shm_id);
    if (err) {
        if (errno == EEXIST) {
            err = cl_shm_open(OBJ_DESC_SHM_PATH, &shm_id);
        }

        if (err) {
            SX_LOG_ERR("Failed to open the obj desc mapping shared memory shm_id = %d err=%s\n", shm_id, strerror(
                           errno));
            return SX_OBJ_DESC_STATUS_ERROR;
        }
    } else {
        shm_create = TRUE;
    }
    obj_desc_db_s.shm_id = shm_id;

    if (shm_create) {
        err = ftruncate(shm_id, size);
        if (err) {
            SX_LOG_ERR("truncate error %s\n", strerror(errno));
            rc = SX_OBJ_DESC_STATUS_ERROR;
            goto out;
        }
    }

    obj_desc_shm_db_p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_id, 0);
    if (obj_desc_shm_db_p == MAP_FAILED) {
        SX_LOG_ERR("Failed to map the shared memory of object description\n");
        rc = SX_OBJ_DESC_STATUS_ERROR;
        goto out;
    }
    obj_desc_db_s.obj_desc_shm_db_p = obj_desc_shm_db_p;
    obj_desc_db_s.max_entry_num = OBJ_DESC_POOL_MIN_ENTRY_NUM;

    if (shm_create) {
        if (__lock_init(&obj_desc_shm_db_p->lock) != SX_OBJ_DESC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to init obj desc shared memory lock\n");
            rc = SX_OBJ_DESC_STATUS_ERROR;
            goto out;
        }
        __lock_acquire(&obj_desc_shm_db_p->lock);
        shm_locked = TRUE;
        obj_desc_shm_db_p->max_entry_num = OBJ_DESC_POOL_MIN_ENTRY_NUM;
        memset(obj_desc_shm_db_p->obj_desc_record, 0, sizeof(obj_desc_record_t) * OBJ_DESC_POOL_MIN_ENTRY_NUM);
        err = msync((void*)obj_desc_shm_db_p, size, MS_SYNC);
        if (err == -1) {
            SX_LOG_ERR("Failed to sync obj desc shared memory.\n");
            rc = SX_OBJ_DESC_STATUS_MEMORY_ERROR;
            goto out;
        }
    }

out:
    if (shm_locked) {
        __lock_release(&obj_desc_shm_db_p->lock);
    }
    return rc;
}

static sx_obj_desc_status_t __deinit_shm_db(void)
{
    int                  err = 0;
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;

    err = munmap((void*)obj_desc_db_s.obj_desc_shm_db_p, obj_desc_db_s.shm_size);
    if (err == -1) {
        SX_LOG_ERR("Failed to unmap obj desc shared memory.\n");
        rc = SX_OBJ_DESC_STATUS_MEMORY_ERROR;
        goto out;
    }

out:
    return rc;
}

sx_obj_desc_status_t sx_obj_desc_lib_init(sx_obj_desc_lib_init_param_t init_params)
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;

    UNUSED_PARAM(init_params);

    memset(&obj_desc_db_s, 0, sizeof(obj_desc_db_t));

    if (sx_log_init(TRUE, NULL, NULL) != 0) {
        rc = SX_OBJ_DESC_STATUS_ERROR;
        fprintf(stderr, "Log initialization failed.\n");
        goto out;
    }

    rc = __init_shm_db();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init shm db.\n");
        goto out;
    }

    obj_desc_lib_initialized_s = TRUE;

out:
    return rc;
}

sx_obj_desc_status_t sx_obj_desc_lib_deinit(void)
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;

    rc = __deinit_shm_db();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit shm db.\n");
        goto out;
    }

    obj_desc_lib_initialized_s = FALSE;

out:
    return rc;
}

static inline sx_obj_desc_status_t __obj_desc_get_map_key(sx_obj_desc_object_key_t obj_key, uint64_t *map_key_p)
{
    sx_obj_desc_status_t err = SX_OBJ_DESC_STATUS_SUCCESS;

    switch (obj_key.key_type) {
    case SX_OBJ_DESC_OBJECT_TYPE_ACL_E:
        *map_key_p = ACL_OBJ_MAP_KEY(obj_key.obj_id.acl_obj_id.acl_region, obj_key.obj_id.acl_obj_id.acl_rule_offset);
        break;

    default:
        SX_LOG_ERR("sx obj desc key type %u is not supported yet.\n", obj_key.key_type);
        err = SX_OBJ_DESC_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

static sx_obj_desc_status_t __obj_desc_get(uint64_t  map_key,
                                           uint32_t *index_p,
                                           char     *obj_desc_p,
                                           uint32_t *obj_desc_len_p)
{
    sx_obj_desc_status_t err = SX_OBJ_DESC_STATUS_SUCCESS;
    uint32_t             i = 0;

    err = SX_OBJ_DESC_STATUS_ENTRY_NOT_FOUND;
    for (i = 0; i < obj_desc_db_s.obj_desc_shm_db_p->free_slot_index; i++) {
        if (obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].key == map_key) {
            if ((obj_desc_p) && (obj_desc_len_p)) {
                strncpy(obj_desc_p, obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].desc, *obj_desc_len_p);
                obj_desc_p[*obj_desc_len_p - 1] = 0;
            }
            if (obj_desc_len_p) {
                *obj_desc_len_p = strlen(obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].desc);
            }
            if (index_p) {
                *index_p = i;
            }
            err = SX_OBJ_DESC_STATUS_SUCCESS;
            goto out;
        }
    }

out:
    return err;
}

sx_obj_desc_status_t sx_obj_desc_lib_object_description_set(sx_obj_desc_access_cmd_t cmd,
                                                            sx_obj_desc_set_param_t  obj_desc_set_params)
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;
    int                  err = 0;
    uint64_t             map_key = 0;
    obj_desc_shm_db_t   *obj_desc_shm_db_p = NULL;
    uint32_t             i = 0;
    uint32_t             index = 0;
    size_t               size = 0;
    uint32_t             max_entry_num = 0;
    boolean_t            shm_locked = FALSE;

    if (obj_desc_lib_initialized_s != TRUE) {
        rc = SX_OBJ_DESC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    rc = __obj_desc_get_map_key(obj_desc_set_params.obj_key, &map_key);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    __lock_acquire(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    shm_locked = TRUE;

    rc = __check_remap_shm();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check and remap shared memory.\n");
        goto out;
    }

    obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;

    switch (cmd) {
    case SX_OBJ_DESC_ACCESS_CMD_SET:
        if (obj_desc_set_params.obj_desc_p == NULL) {
            rc = SX_OBJ_DESC_STATUS_PARAM_NULL;
            SX_LOG_ERR("Object description string is NULL.\n");
            goto out;
        }
        if (obj_desc_set_params.obj_desc_len > OBJ_DESC_MAX_LEN) {
            rc = SX_OBJ_DESC_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Object description length %d exceed the max value %d.\n",
                       obj_desc_set_params.obj_desc_len, OBJ_DESC_MAX_LEN);
            goto out;
        }
        rc = __obj_desc_get(map_key, NULL, NULL, NULL);
        if (rc == SX_OBJ_DESC_STATUS_SUCCESS) {
            rc = SX_OBJ_DESC_STATUS_ENTRY_ALEADY_EXISTS;
            SX_LOG_WRN("Object already exists.\n");
            goto out;
        }

        rc = SX_OBJ_DESC_STATUS_SUCCESS;

        i = obj_desc_shm_db_p->free_slot_index;

        if (i >= obj_desc_shm_db_p->max_entry_num) {
            /* No free slot, enlarge the shared memory */
            max_entry_num = obj_desc_shm_db_p->max_entry_num + OBJ_DESC_POOL_GROW_ENTRY_NUM;
            if (max_entry_num > OBJ_DESC_POOL_MAX_ENTRY_NUM) {
                rc = SX_OBJ_DESC_STATUS_NO_RESOURCES;
                SX_LOG_ERR("No more resources to set object description.\n");
                goto out;
            }
            rc = __remap_shm(max_entry_num, TRUE);
            if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to enlarge shared memory.\n");
                goto out;
            }
            obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;
            memset(
                &obj_desc_shm_db_p->obj_desc_record[obj_desc_shm_db_p->max_entry_num - OBJ_DESC_POOL_GROW_ENTRY_NUM],
                0,
                sizeof(obj_desc_record_t) * OBJ_DESC_POOL_GROW_ENTRY_NUM);
        }

        obj_desc_shm_db_p->obj_desc_record[i].key = map_key;
        memset(obj_desc_shm_db_p->obj_desc_record[i].desc, 0, OBJ_DESC_MAX_LEN);
        strncpy(obj_desc_shm_db_p->obj_desc_record[i].desc,
                obj_desc_set_params.obj_desc_p, obj_desc_set_params.obj_desc_len);
        obj_desc_shm_db_p->obj_desc_record[i].desc[OBJ_DESC_MAX_LEN - 1] = 0;
        obj_desc_shm_db_p->free_slot_index++;

        err = msync((void*)obj_desc_shm_db_p, size, MS_SYNC);
        if (err == -1) {
            SX_LOG_ERR("Failed to sync obj desc shared memory.\n");
            rc = SX_OBJ_DESC_STATUS_MEMORY_ERROR;
            goto out;
        }

        break;

    case SX_OBJ_DESC_ACCESS_CMD_UNSET:
        rc = __obj_desc_get(map_key, &index, NULL, NULL);
        if (rc == SX_OBJ_DESC_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_WRN("Object is not found.\n");
            goto out;
        }

        obj_desc_shm_db_p->obj_desc_record[index].key = 0;
        memset(obj_desc_shm_db_p->obj_desc_record[index].desc, 0, OBJ_DESC_MAX_LEN);

        /* Relocate: move last one to fill the hole */
        obj_desc_shm_db_p->free_slot_index--;
        if (index < (obj_desc_shm_db_p->free_slot_index)) {
            obj_desc_shm_db_p->obj_desc_record[index].key =
                obj_desc_shm_db_p->obj_desc_record[obj_desc_shm_db_p->free_slot_index].key;
            memcpy(obj_desc_shm_db_p->obj_desc_record[index].desc,
                   obj_desc_shm_db_p->obj_desc_record[obj_desc_shm_db_p->free_slot_index].desc,
                   OBJ_DESC_MAX_LEN);
        }

        if ((obj_desc_shm_db_p->free_slot_index + OBJ_DESC_POOL_GROW_ENTRY_NUM) <= obj_desc_shm_db_p->max_entry_num) {
            /* No many entries, Shrink shared memory */
            max_entry_num = obj_desc_shm_db_p->max_entry_num - OBJ_DESC_POOL_GROW_ENTRY_NUM;
            if (max_entry_num >= OBJ_DESC_POOL_MIN_ENTRY_NUM) {
                rc = __remap_shm(max_entry_num, TRUE);
                if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to shrink shared memory.\n");
                    goto out;
                }
                obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;
            }
        }

        err = msync((void*)obj_desc_shm_db_p, size, MS_SYNC);
        if (err == -1) {
            SX_LOG_ERR("Failed to sync obj desc shared memory.\n");
            rc = SX_OBJ_DESC_STATUS_MEMORY_ERROR;
            goto out;
        }

        break;

    default:
        rc = SX_OBJ_DESC_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command %u is not allowed.\n", cmd);
        goto out;
        break;
    }

out:
    if (shm_locked == TRUE) {
        __lock_release(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    }
    return rc;
}

sx_obj_desc_status_t sx_obj_desc_lib_object_description_get(sx_obj_desc_get_param_t *obj_desc_get_params_p)
{
    sx_obj_desc_status_t err = SX_OBJ_DESC_STATUS_SUCCESS;
    uint64_t             map_key = 0;
    boolean_t            shm_locked = FALSE;

    if (obj_desc_lib_initialized_s != TRUE) {
        err = SX_OBJ_DESC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    if (obj_desc_get_params_p == NULL) {
        err = SX_OBJ_DESC_STATUS_PARAM_NULL;
        SX_LOG_ERR("obj_desc_get_params_p is NULL.\n");
        goto out;
    }

    err = __obj_desc_get_map_key(obj_desc_get_params_p->obj_key, &map_key);
    if (err != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    __lock_acquire(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    shm_locked = TRUE;

    err = __check_remap_shm();
    if (err != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check and remap shared memory.\n");
        goto out;
    }

    err = __obj_desc_get(map_key, NULL, obj_desc_get_params_p->obj_desc_p, &obj_desc_get_params_p->obj_desc_len);
    if (err != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_DBG("Object is not existed.\n");
        goto out;
    }

out:
    if (shm_locked) {
        __lock_release(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    }
    return err;
}

sx_obj_desc_status_t sx_obj_desc_lib_object_description_cleanup(sx_obj_desc_access_cmd_t  cmd,
                                                                sx_obj_desc_object_type_t type)
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;
    int                  err = 0;
    obj_desc_shm_db_t   *obj_desc_shm_db_p = NULL;
    uint32_t             max_entry_num = 0;
    boolean_t            shm_locked = FALSE;
    uint32_t             i = 0;
    uint32_t             j = 0;

    if (obj_desc_lib_initialized_s != TRUE) {
        rc = SX_OBJ_DESC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    switch (cmd) {
    case SX_OBJ_DESC_ACCESS_CMD_DELETE:
        if (type != SX_OBJ_DESC_OBJECT_TYPE_ACL_E) {
            rc = SX_OBJ_DESC_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Unsupported type %u.\n", type);
            goto out;
        }
        break;

    case SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL:
        break;

    default:
        rc = SX_OBJ_DESC_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported command %u.\n", cmd);
        goto out;
        break;
    }

    __lock_acquire(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    shm_locked = TRUE;

    rc = __check_remap_shm();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check and remap shared memory.\n");
        goto out;
    }

    obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;

    switch (cmd) {
    case SX_OBJ_DESC_ACCESS_CMD_DELETE:
        i = 0;

        if (obj_desc_shm_db_p->free_slot_index > 0) {
            j = obj_desc_shm_db_p->free_slot_index - 1;
            while (i <= j) {
                if (OBJ_KEY_TYPE_GET(obj_desc_shm_db_p->obj_desc_record[i].key) == type) {
                    while ((j > i) && (OBJ_KEY_TYPE_GET(obj_desc_shm_db_p->obj_desc_record[j].key) == type)) {
                        j--;
                    }
                    if (j > i) {
                        obj_desc_shm_db_p->obj_desc_record[i].key = obj_desc_shm_db_p->obj_desc_record[j].key;
                        memcpy(obj_desc_shm_db_p->obj_desc_record[i].desc,
                               obj_desc_shm_db_p->obj_desc_record[j].desc,
                               OBJ_DESC_MAX_LEN);
                        j--;
                    } else {
                        break;
                    }
                }
                i++;
            }
        }

        if (obj_desc_shm_db_p->free_slot_index > i) {
            memset(&obj_desc_shm_db_p->obj_desc_record[i], 0,
                   sizeof(obj_desc_record_t) * (obj_desc_shm_db_p->free_slot_index - i));
            obj_desc_shm_db_p->free_slot_index = i;
        }

        max_entry_num = OBJ_DESC_POOL_MIN_ENTRY_NUM +
                        (obj_desc_shm_db_p->free_slot_index /
                         OBJ_DESC_POOL_GROW_ENTRY_NUM) * OBJ_DESC_POOL_GROW_ENTRY_NUM;
        if (max_entry_num < obj_desc_shm_db_p->max_entry_num) {
            /* No many entries, Shrink shared memory */
            rc = __remap_shm(max_entry_num, TRUE);
            if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to shrink shared memory.\n");
                goto out;
            }
            obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;
        }

        break;

    case SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL:
        memset(obj_desc_shm_db_p->obj_desc_record, 0, sizeof(obj_desc_record_t) * obj_desc_db_s.max_entry_num);
        rc = __remap_shm(OBJ_DESC_POOL_MIN_ENTRY_NUM, TRUE);
        if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remap shared memory.\n");
            goto out;
        }
        obj_desc_shm_db_p = obj_desc_db_s.obj_desc_shm_db_p;
        obj_desc_shm_db_p->free_slot_index = 0;
        break;

    default:
        rc = SX_OBJ_DESC_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported command %u.\n", cmd);
        goto out;
        break;
    }

    err = msync((void*)obj_desc_shm_db_p, obj_desc_db_s.shm_size, MS_SYNC);
    if (err == -1) {
        SX_LOG_ERR("Failed to sync obj desc shared memory.\n");
        rc = SX_OBJ_DESC_STATUS_MEMORY_ERROR;
        goto out;
    }

out:
    if (shm_locked) {
        __lock_release(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    }
    return rc;
}

sx_obj_desc_status_t sx_obj_desc_lib_generate_dump(const char *file_path)
{
    sx_obj_desc_status_t      rc = SX_OBJ_DESC_STATUS_SUCCESS;
    sx_obj_desc_object_type_t type = SX_OBJ_DESC_OBJECT_TYPE_NONE_E;
    FILE                    * stream_p = NULL;
    uint32_t                  i = 0;
    boolean_t                 shm_locked = FALSE;

    if (obj_desc_lib_initialized_s != TRUE) {
        rc = SX_OBJ_DESC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to get map key from object key.\n");
        goto out;
    }

    if (file_path == NULL) {
        file_path = OBJ_DESC_DEFAULT_DUMP_PATH;
    }

    stream_p = fopen(file_path, "w");
    if (stream_p == NULL) {
        SX_LOG_ERR("Failed to open dump file.\n");
        rc = SX_OBJ_DESC_STATUS_ERROR;
        goto out;
    }

    __lock_acquire(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    shm_locked = TRUE;

    rc = __check_remap_shm();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check and remap shared memory.\n");
        goto out;
    }

    fprintf(stream_p, "######## Object Entries #########\n");
    fprintf(stream_p, "Total count = %d\n", obj_desc_db_s.obj_desc_shm_db_p->free_slot_index);

    for (i = 0; i < obj_desc_db_s.obj_desc_shm_db_p->free_slot_index; ++i) {
        type = OBJ_KEY_TYPE_GET(obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].key);
        fprintf(stream_p, "type[%d] ", type);
        if (type == SX_OBJ_DESC_OBJECT_TYPE_ACL_E) {
            fprintf(stream_p, "region[%" PRIu64 "], rule offset[%" PRIu64 "], description[%s]",
                    ACL_OBJ_REGION_ID_GET(obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].key),
                    ACL_OBJ_RULE_OFFSET_GET(obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].key),
                    obj_desc_db_s.obj_desc_shm_db_p->obj_desc_record[i].desc);
        }
        fprintf(stream_p, "\n");
    }

out:
    if (shm_locked) {
        __lock_release(&obj_desc_db_s.obj_desc_shm_db_p->lock);
    }
    if (stream_p) {
        fclose(stream_p);
    }

    return rc;
}
