#!/usr/bin/env python3

import argparse
import ctypes
from ctypes import *

SX_OBJ_DESC_ACCESS_CMD_SET = 1
SX_OBJ_DESC_ACCESS_CMD_UNSET = 2
SX_OBJ_DESC_ACCESS_CMD_DELETE = 3
SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL = 4

SX_OBJ_DESC_OBJECT_TYPE_NONE_E = 0
SX_OBJ_DESC_OBJECT_TYPE_ACL_E = 1

SX_OBJ_DESC_STATUS_SUCCESS = 0
SX_OBJ_DESC_STATUS_ERROR = 1
SX_OBJ_DESC_STATUS_PARAM_ERROR = 2
SX_OBJ_DESC_STATUS_PARAM_NULL = 3
SX_OBJ_DESC_STATUS_ENTRY_NOT_FOUND = 4
SX_OBJ_DESC_STATUS_ENTRY_ALEADY_EXISTS = 5
SX_OBJ_DESC_STATUS_NOT_INITIALIZED = 6
SX_OBJ_DESC_STATUS_ALREADY_INITIALIZED = 7
SX_OBJ_DESC_STATUS_NO_RESOURCES = 8
SX_OBJ_DESC_STATUS_NO_MEMORY = 9
SX_OBJ_DESC_STATUS_MEMORY_ERROR = 10


class SxObjDescInitParam(Structure):
    _fields_ = [("reserved", c_uint64)]


class SxObjDescAclObjId(Structure):
    _fields_ = [("acl_region", c_uint32), ("acl_rule_offset", c_uint32)]


class SxObjDescBridgeObjId(Structure):
    _fields_ = [("bridge_id", c_uint32)]


class SxObjDescFdbObjId(Structure):
    _fields_ = [("fdb_fid", c_uint32)]


class SxObjDescPortObjId(Structure):
    _fields_ = [("port_id", c_uint32)]


class SxObjDescRouterObjId(Structure):
    _fields_ = [("vrid", c_uint32), ("rif", c_uint32)]


class SxObjDescSpanObjId(Structure):
    _fields_ = [("span_id", c_uint32)]


class SxObjDescTunnelObjId(Structure):
    _fields_ = [("tunnel_id", c_uint32)]


class SxObjDescObjectId(Union):
    _fields_ = [("acl_obj_id", SxObjDescAclObjId), ("bridge_obj_id", SxObjDescBridgeObjId), ("fdb_obj_id", SxObjDescFdbObjId),
                ("port_lag_obj_id", SxObjDescPortObjId), ("router_obj_id", SxObjDescRouterObjId), ("span_obj_id", SxObjDescSpanObjId),
                ("tunnel_obj_id", SxObjDescTunnelObjId)]


class SxObjDescObjectKey(Structure):
    _fields_ = [("key_type", c_int), ("obj_id", SxObjDescObjectId)]


class SxObjDescSetParam(Structure):
    _fields_ = [("obj_key", SxObjDescObjectKey), ("obj_desc_p", c_char_p), ("obj_desc_len", c_uint32)]


class SxObjDescGetParam(Structure):
    _fields_ = [("obj_key", SxObjDescObjectKey), ("obj_desc_p", POINTER(c_char)), ("obj_desc_len", c_uint32)]


def main():
    sx_obj_desc_lib = ctypes.CDLL('libsxobjdesc.so', mode=ctypes.RTLD_GLOBAL)

    init_param = SxObjDescInitParam()
    set_param = SxObjDescSetParam()
    get_param = SxObjDescGetParam()

    rc = sx_obj_desc_lib.sx_obj_desc_lib_init(init_param)
    assert 0 == rc, "Failed to init obj desc lib"

    rc = sx_obj_desc_lib.sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE, SX_OBJ_DESC_OBJECT_TYPE_ACL_E)
    assert 0 == rc, "Failed to cleanup obj desc"

    set_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E
    set_param.obj_key.obj_id.acl_obj_id.acl_region = 10
    set_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = 1010
    set_param.obj_desc_p = "Acl example string for region 10 and offset 1010".encode()
    set_param.obj_desc_len = len(set_param.obj_desc_p)

    rc = sx_obj_desc_lib.sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_SET, set_param)
    assert 0 == rc, "Failed to set obj desc string"

    rc = sx_obj_desc_lib.sx_obj_desc_lib_generate_dump("/tmp/obj_desc_dump".encode())
    assert 0 == rc, "Failed to generate dump"

    get_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E
    get_param.obj_key.obj_id.acl_obj_id.acl_region = 10
    get_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = 1010
    get_param.obj_desc_p = create_string_buffer(1024)
    get_param.obj_desc_len = 1024

    rc = sx_obj_desc_lib.sx_obj_desc_lib_object_description_get(byref(get_param))
    assert 0 == rc, "Failed to get obj desc string"

    print(get_param.obj_desc_p[:get_param.obj_desc_len])

    rc = sx_obj_desc_lib.sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_UNSET, set_param)
    assert 0 == rc, "Failed to unset obj desc string"

    rc = sx_obj_desc_lib.sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL, SX_OBJ_DESC_OBJECT_TYPE_NONE_E)
    assert 0 == rc, "Failed to cleanup obj desc"

    rc = sx_obj_desc_lib.sx_obj_desc_lib_deinit()
    assert 0 == rc, "Failed to deinit obj desc lib"


if __name__ == "__main__":
    main()
