/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdlib.h>
#include "sx/obj_desc/sx_obj_desc_lib.h"
#include <signal.h>

sx_obj_desc_status_t basic_flow()
{
    sx_obj_desc_status_t         rc = SX_OBJ_DESC_STATUS_SUCCESS;
    sx_obj_desc_lib_init_param_t init_params;
    sx_obj_desc_set_param_t      set_param;
    sx_obj_desc_get_param_t      get_param;
    char                       * obj_desc_string = NULL;

    memset(&init_params, 0, sizeof(sx_obj_desc_lib_init_param_t));
    memset(&set_param, 0, sizeof(sx_obj_desc_set_param_t));
    memset(&get_param, 0, sizeof(sx_obj_desc_get_param_t));

    rc = sx_obj_desc_lib_init(init_params);

    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to init obj desc lib.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE, SX_OBJ_DESC_OBJECT_TYPE_ACL_E);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to cleanup obj desc.\n");
        goto out;
    }

    obj_desc_string = "Acl example string for region 1 and offset 1";

    set_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
    set_param.obj_key.obj_id.acl_obj_id.acl_region = 1;
    set_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = 1;
    set_param.obj_desc_p = obj_desc_string;
    set_param.obj_desc_len = strlen(set_param.obj_desc_p);

    rc = sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_SET, set_param);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to set obj desc string.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_generate_dump(NULL);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to generate dump.\n");
        goto out;
    }

    get_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
    get_param.obj_key.obj_id.acl_obj_id.acl_region = 1;
    get_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = 1;
    get_param.obj_desc_len = 1024;
    get_param.obj_desc_p = malloc(get_param.obj_desc_len);
    memset(get_param.obj_desc_p, 0, get_param.obj_desc_len);

    rc = sx_obj_desc_lib_object_description_get(&get_param);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to get obj desc string.\n");
        goto out;
    }
    printf("Got obj desc string: %s\n", get_param.obj_desc_p);

    free(get_param.obj_desc_p);
    get_param.obj_desc_p = NULL;

    /* User need to UNSET it or do cleanup before deinit */
    rc = sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_UNSET, set_param);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to unset obj desc string.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL, SX_OBJ_DESC_OBJECT_TYPE_NONE_E);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to cleanup obj desc.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_deinit();

    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to deinit obj desc lib.\n");
        goto out;
    }

out:
    return rc;
}

sx_obj_desc_status_t scale_flow()
{
    sx_obj_desc_status_t         rc = SX_OBJ_DESC_STATUS_SUCCESS;
    sx_obj_desc_lib_init_param_t init_params;
    sx_obj_desc_set_param_t      set_param;
    sx_obj_desc_get_param_t      get_param;
    char                         obj_desc_string[1024];
    char                         obj_desc_got[1024];
    uint32_t                     region_num = 32;
    uint32_t                     rule_num = 1024;
    uint32_t                     i = 0;
    uint32_t                     j = 0;

    memset(&init_params, 0, sizeof(sx_obj_desc_lib_init_param_t));
    memset(&set_param, 0, sizeof(sx_obj_desc_set_param_t));
    memset(&get_param, 0, sizeof(sx_obj_desc_get_param_t));

    rc = sx_obj_desc_lib_init(init_params);

    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to init obj desc lib.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE, SX_OBJ_DESC_OBJECT_TYPE_ACL_E);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to cleanup obj desc.\n");
        goto out;
    }

    for (i = 0; i < region_num; i++) {
        for (j = 0; j < rule_num; j++) {
            sprintf(obj_desc_string, "acl rule in region %d on offset %d", i, j);
            set_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
            set_param.obj_key.obj_id.acl_obj_id.acl_region = i;
            set_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = j;
            set_param.obj_desc_p = obj_desc_string;
            set_param.obj_desc_len = strlen(set_param.obj_desc_p);

            rc = sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_SET, set_param);

            if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                printf("Failed to set obj desc string of region %d, offset %d.\n", i, j);
                goto out;
            }
        }
    }

    for (i = 0; i < region_num; i++) {
        for (j = 0; j < rule_num; j++) {
            sprintf(obj_desc_string, "acl rule in region %d on offset %d", i, j);
            get_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
            get_param.obj_key.obj_id.acl_obj_id.acl_region = i;
            get_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = j;
            get_param.obj_desc_len = 1024;
            get_param.obj_desc_p = obj_desc_got;
            memset(get_param.obj_desc_p, 0, get_param.obj_desc_len);

            rc = sx_obj_desc_lib_object_description_get(&get_param);
            if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                printf("Failed to get obj desc string on offset %d in region %d.\n", i, j);
                goto out;
            }

            if (strcmp(obj_desc_string, obj_desc_got)) {
                printf("Failed to get obj desc string in region %d on offset %d: expected[%s], got[%s].\n",
                       i, j, obj_desc_string, obj_desc_got);
            }
        }
    }

    for (i = 0; i < region_num; i++) {
        for (j = 0; j < rule_num; j += 2) {
            set_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
            set_param.obj_key.obj_id.acl_obj_id.acl_region = i;
            set_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = j;

            rc = sx_obj_desc_lib_object_description_set(SX_OBJ_DESC_ACCESS_CMD_UNSET, set_param);
            if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                printf("Failed to unset obj desc string in region %d on offset %d\n", i, j);
                goto out;
            }
        }
    }

    for (i = 0; i < region_num; i++) {
        for (j = 0; j < rule_num; j++) {
            sprintf(obj_desc_string, "acl rule in region %d on offset %d", i, j);
            get_param.obj_key.key_type = SX_OBJ_DESC_OBJECT_TYPE_ACL_E;
            get_param.obj_key.obj_id.acl_obj_id.acl_region = i;
            get_param.obj_key.obj_id.acl_obj_id.acl_rule_offset = j;
            get_param.obj_desc_len = 1024;
            get_param.obj_desc_p = obj_desc_got;
            memset(get_param.obj_desc_p, 0, get_param.obj_desc_len);

            rc = sx_obj_desc_lib_object_description_get(&get_param);
            if (j % 2 == 1) {
                if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
                    printf("Failed to get obj desc string in region %d on offset %d.\n", i, j);
                    goto out;
                }

                if (strcmp(obj_desc_string, obj_desc_got)) {
                    printf("Failed to get obj desc string in region %d on offset %d: expected[%s], got[%s].\n",
                           i, j, obj_desc_string, obj_desc_got);
                }
            } else {
                if (rc == SX_OBJ_DESC_STATUS_SUCCESS) {
                    printf("Get obj desc string from UNSET entry, region %d, offset %d.\n", i, j);
                    goto out;
                }
            }
        }
    }

    rc = sx_obj_desc_lib_object_description_cleanup(SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL, SX_OBJ_DESC_OBJECT_TYPE_NONE_E);
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to cleanup obj desc.\n");
        goto out;
    }

    rc = sx_obj_desc_lib_deinit();

    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed to deinit obj desc lib.\n");
        goto out;
    }

out:
    return rc;
}

int main(int argc, const char *argv[])
{
    sx_obj_desc_status_t rc = SX_OBJ_DESC_STATUS_SUCCESS;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    rc = basic_flow();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed on basic flow.\n");
        return -1;
    }

    rc = scale_flow();
    if (rc != SX_OBJ_DESC_STATUS_SUCCESS) {
        printf("Failed on scale flow.\n");
        return -1;
    }

    return 0;
}
