/*
 * SPDX-FileCopyrightText: Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "complib/sx_log.h"
#include "sdk_router_lib.h"
#include "sx_core/sx_core_cmd_db.h"
#include "sx_core/sx_core_api.h"
#include "sx_api/sx_api_internal.h"
#include "include/resource_manager/resource_manager.h"
#include "hwi/sdk_router/sdk_router_be.h"
#include "hwi/uc_route/uc_route_be.h"
#include "hwi/sdk_router_vrid/sdk_router_vrid_be.h"
#include "hwi/ecmp/router_ecmp_be.h"
#include "hwi/sdk_router/sdk_router_impl.h"
#include "ethl3/hwi/neigh/router_neigh.h"
#include "hwi/rif/rif_be.h"
#include "hwi/cos/sdk_router_cos_be.h"
#include "ethl3/hwi/mc_route/mc_route_be.h"
#include "ethl3/hwi/mc_route/mc_rpf_group_be.h"
#include <sx/sxd/sxd_access_register.h>

#include "hwi/nat_4to6/nat_4to6_be.h"

#undef  __MODULE__
#define __MODULE__ ROUTER

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/
/* SDK Router Verbosity is not defined local, but shared by all SDK router modules */
/* todo: separate verbosity per router sub-module */
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/*************************************************
 *  Local Functions
 ************************************************/
static sx_status_t __sdk_router_verbosity(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_deinit_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_vrid_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size);
static sx_status_t __sdk_ecmp_background_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                             uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __sdk_uc_route_tree_background_optimize(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size);
static sx_status_t __sdk_lpm_tree_background_opt_trigger(sx_core_td_event_src_t *event,
                                                         uint8_t                *cmd_body,
                                                         uint32_t                cmd_body_size);
static sx_status_t __sdk_lpm_tree_background_opt_trigger_ipv4(sx_core_td_event_src_t *event,
                                                              uint8_t                *cmd_body,
                                                              uint32_t                cmd_body_size);
static sx_status_t __sdk_lpm_tree_background_opt_trigger_ipv6(sx_core_td_event_src_t *event,
                                                              uint8_t                *cmd_body,
                                                              uint32_t                cmd_body_size);
static sx_status_t __sdk_ecmp_load_balancing_background_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_set(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __router_ecmp_clone_set(sx_core_td_event_src_t *event,
                                           uint8_t                *cmd_body,
                                           uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_action_set(sx_core_td_event_src_t *event,
                                            uint8_t                *cmd_body,
                                            uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_action_suppress_filter_iter_get(sx_core_td_event_src_t *event,
                                                                 uint8_t                *cmd_body,
                                                                 uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_get(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __router_ecmp_iter_get(sx_core_td_event_src_t *event,
                                          uint8_t                *cmd_body,
                                          uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_hash_set(sx_core_td_event_src_t *event,
                                              uint8_t                *cmd_body,
                                              uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_hash_get(sx_core_td_event_src_t *event,
                                              uint8_t                *cmd_body,
                                              uint32_t                cmd_body_size);
static sx_status_t __router_operational_ecmp_get(sx_core_td_event_src_t *event,
                                                 uint8_t               * cmd_body,
                                                 uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_port_hash_set(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_port_hash_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_bind_get(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_clear_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_counter_bind_set(sx_core_td_event_src_t *event,
                                                  uint8_t               * cmd_body,
                                                  uint32_t                cmd_body_size);
static sx_status_t __router_ecmp_fine_grain_counter_bind_set(sx_core_td_event_src_t *event,
                                                             uint8_t               * cmd_body,
                                                             uint32_t                cmd_body_size);
static sx_status_t __sdk_router_neigh_set(sx_core_td_event_src_t *event,
                                          uint8_t                *cmd_body,
                                          uint32_t                cmd_body_size);
static sx_status_t __sdk_router_neigh_get(sx_core_td_event_src_t *event,
                                          uint8_t                *cmd_body,
                                          uint32_t                cmd_body_size);
static sx_status_t __sdk_router_neigh_activity_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size);
static sx_status_t __sdk_uc_route_set(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_uc_route_get(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_uc_route_ecmp_get(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size);
static sx_status_t __sdk_router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size);
static sx_status_t __sdk_router_interface_iter_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_state_set(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_state_get(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_alloc_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_extended_alloc_set(sx_core_td_event_src_t *event,
                                                                     uint8_t                *cmd_body,
                                                                     uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_get(sx_core_td_event_src_t *event,
                                                      uint8_t                *cmd_body,
                                                      uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_extended_get(sx_core_td_event_src_t *event,
                                                               uint8_t                *cmd_body,
                                                               uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_counter_bind_set(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_mac_set(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_mac_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_rewrite_pcpdei_enable_set(sx_core_td_event_src_t *event,
                                                              uint8_t               * cmd_body,
                                                              uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_rewrite_pcpdei_enable_get(sx_core_td_event_src_t *event,
                                                              uint8_t               * cmd_body,
                                                              uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_prio_update_enable_set(sx_core_td_event_src_t *event,
                                                           uint8_t               * cmd_body,
                                                           uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_prio_update_enable_get(sx_core_td_event_src_t *event,
                                                           uint8_t               * cmd_body,
                                                           uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_dscp_to_prio_set(sx_core_td_event_src_t *event,
                                                     uint8_t               * cmd_body,
                                                     uint32_t                cmd_body_size);
static sx_status_t __sdk_router_cos_dscp_to_prio_get(sx_core_td_event_src_t *event,
                                                     uint8_t               * cmd_body,
                                                     uint32_t                cmd_body_size);
static sx_status_t __sdk_router_neigh_activity_notify(sx_core_td_event_src_t *event,
                                                      uint8_t               * cmd_body,
                                                      uint32_t                cmd_body_size);
static sx_status_t __sdk_router_activity_notifier_cb(sx_core_td_event_src_t *event,
                                                     uint8_t               * cmd_body,
                                                     uint32_t                cmd_body_size);
static sx_status_t __sdk_router_uc_route_counter_bind_set(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size);
static sx_status_t __sdk_router_uc_route_counter_bind_get(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_attributes_set(sx_core_td_event_src_t *event,
                                                    uint8_t               * cmd_body,
                                                    uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_attributes_get(sx_core_td_event_src_t *event,
                                                    uint8_t               * cmd_body,
                                                    uint32_t                cmd_body_size);
static sx_status_t __sdk_router_mc_route_set(sx_core_td_event_src_t *event,
                                             uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_get(sx_core_td_event_src_t *event,
                                             uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_activity_get(sx_core_td_event_src_t *event,
                                                      uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_activity_notify(sx_core_td_event_src_t *event,
                                                         uint8_t                *cmd_body,
                                                         uint32_t                cmd_body_size);
static sx_status_t __sdk_router_mc_route_activity_notify_job_process_cb(sx_core_td_event_src_t *event,
                                                                        uint8_t                *cmd_body,
                                                                        uint32_t                cmd_body_size);
static sx_status_t __sdk_router_mc_route_egress_rif_set(sx_core_td_event_src_t *event,
                                                        uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_egress_rif_get(sx_core_td_event_src_t *event,
                                                        uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_counter_bind_set(sx_core_td_event_src_t *event,
                                                          uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_route_counter_bind_get(sx_core_td_event_src_t *event,
                                                          uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_rpf_group_set(sx_core_td_event_src_t *event,
                                                 uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_mc_rpf_group_get(sx_core_td_event_src_t *event,
                                                 uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_ecmp_redirect_set(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size);
static sx_status_t __sdk_router_ecmp_redirect_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size);
static sx_status_t __sdk_uc_route_background_set(sx_core_td_event_src_t *event,
                                                 uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_completion_info_get(sx_core_td_event_src_t *event,
                                                    uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_user_defined_lpm_tree_set(sx_core_td_event_src_t *event,
                                                          uint8_t *cmd_body, uint32_t cmd_body_size);
static sx_status_t __sdk_router_user_defined_lpm_tree_get(sx_core_td_event_src_t *event,
                                                          uint8_t *cmd_body, uint32_t cmd_body_size);

static sx_status_t __sdk_router_ecmp_update_set(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size);
static sx_status_t __sdk_router_nat_set(sx_core_td_event_src_t *event,
                                        uint8_t                *cmd_body,
                                        uint32_t                cmd_body_size);
static sx_status_t __sdk_router_nat_get(sx_core_td_event_src_t *event,
                                        uint8_t                *cmd_body,
                                        uint32_t                cmd_body_size);
static sx_status_t __sdk_router_lpm_tree_optimize_set(sx_core_td_event_src_t *event,
                                                      uint8_t                *cmd_body,
                                                      uint32_t                cmd_body_size);
static sx_status_t __sdk_router_lpm_tree_balance_factor_get(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_cntr_ext_get(sx_core_td_event_src_t *event,
                                                       uint8_t                *cmd_body,
                                                       uint32_t                cmd_body_size);
static sx_status_t __sdk_router_interface_cntr_attr_get(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size);
/************************************************
 *  Local variables
 ***********************************************/
/*SPC1, SPCA1, SPC2, SPC3, SPC4 */
#define SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP (ALL_SPC_ETH_ASIC_BITMAP)
static sx_api_command_t sx_core_api_sx_router_cmd_table[] = {
    {SX_API_INT_CMD_ROUTER_VERBOSITY_E,     "SX_API_INT_CMD_ROUTER_VERBOSITY_E",        __sdk_router_verbosity,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_HASH_SET_E,     "SX_API_INT_CMD_ROUTER_ECMP_HASH_SET_E",   __sdk_router_ecmp_hash_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_HASH_GET_E,     "SX_API_INT_CMD_ROUTER_ECMP_HASH_GET_E",   __sdk_router_ecmp_hash_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_PARAMS_SET_E,     "SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_SET_E",
     __sdk_router_ecmp_port_hash_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_PARAMS_GET_E,     "SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_GET_E",
     __sdk_router_ecmp_port_hash_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INIT_E,          "SX_API_INT_CMD_ROUTER_INIT_E",   __sdk_router_init_param,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_DEINIT_E,            "SX_API_INT_CMD_ROUTER_DEINIT_E",  __sdk_router_deinit_param,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_SET_E,           "SX_API_INT_CMD_ROUTER_SET_E",  __sdk_router_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_GET_E,           "SX_API_INT_CMD_ROUTER_GET_E",  __sdk_router_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_VRID_ITER_GET_E,           "SX_API_INT_CMD_ROUTER_VRID_ITER_GET_E",
     __sdk_router_vrid_iter_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_SET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_SET_E",   __sdk_router_interface_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_GET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_GET_E",   __sdk_router_interface_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_ITER_GET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_ITER_GET_E",
     __sdk_router_interface_iter_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_STATE_SET_E,   "SX_API_INT_CMD_ROUTER_INTERFACE_STATE_SET_E",
     __sdk_router_interface_state_set,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_STATE_GET_E,   "SX_API_INT_CMD_ROUTER_INTERFACE_STATE_GET_E",
     __sdk_router_interface_state_get,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_MAC_SET_E, "SX_API_INT_CMD_ROUTER_INTERFACE_MAC_SET_E",
     __sdk_router_interface_mac_set,     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_MAC_GET_E, "SX_API_INT_CMD_ROUTER_INTERFACE_MAC_GET_E",
     __sdk_router_interface_mac_get,     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_SET_E,     "SX_API_INT_CMD_ROUTER_NEIGH_SET_E",        __sdk_router_neigh_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_GET_E,     "SX_API_INT_CMD_ROUTER_NEIGH_GET_E",        __sdk_router_neigh_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_GET_E,        "SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_GET_E",
     __sdk_router_neigh_activity_get,            SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_SET_E,      "SX_API_INT_CMD_ROUTER_UC_ROUTE_SET_E",     __sdk_uc_route_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_GET_E,      "SX_API_INT_CMD_ROUTER_UC_ROUTE_GET_E",     __sdk_uc_route_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_OPERATIONAL_ECMP_GET_E, "SX_API_INT_CMD_ROUTER_UC_ROUTE_OPERATIONAL_ECMP_GET_E",
     __sdk_uc_route_ecmp_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_ALLOC_SET_E,        "SX_API_INT_CMD_ROUTER_CNTR_ALLOC_SET_E",
     __sdk_router_interface_counter_alloc_set,        SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_ALLOC_SET_E,        "SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_ALLOC_SET_E",
     __sdk_router_interface_counter_extended_alloc_set,        SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_SET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_SET_E",
     __sdk_router_interface_counter_bind_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_GET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_GET_E",
     __sdk_router_interface_counter_bind_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_GET_E,      "SX_API_INT_CMD_ROUTER_CNTR_GET_E",     __sdk_router_interface_counter_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_GET_E,      "SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_GET_E",
     __sdk_router_interface_counter_extended_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_EXT_GET_E,      "SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_EXT_GET_E",
     __sdk_router_interface_cntr_ext_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_ATTR_GET_E,      "SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_ATTR_GET_E",
     __sdk_router_interface_cntr_attr_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_CLEAR_SET_E,        "SX_API_INT_CMD_ROUTER_CNTR_CLEAR_SET_E",
     __sdk_router_interface_counter_clear_set,        SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_SET_E,      "SX_API_INT_CMD_ROUTER_MC_ROUTE_SET_E",     __sdk_router_mc_route_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_GET_E,      "SX_API_INT_CMD_ROUTER_MC_ROUTE_GET_E",     __sdk_router_mc_route_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_GET_E,     "SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_GET_E",
     __sdk_router_mc_route_activity_get,         SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_NOTIFY_E,     "SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_NOTIFY_E",
     __sdk_router_mc_route_activity_notify,         SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_NOTIFY_JOB_PROCESS_E,
     "SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_NOTIFY_JOB_PROCESS_E",
     __sdk_router_mc_route_activity_notify_job_process_cb,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_SET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_SET_E",
     __sdk_router_mc_route_egress_rif_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_GET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_GET_E",
     __sdk_router_mc_route_egress_rif_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_SET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_SET_E",
     __sdk_router_mc_route_counter_bind_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_GET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_GET_E",
     __sdk_router_mc_route_counter_bind_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_SET_E,   "SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_SET_E",
     __sdk_router_mc_rpf_group_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_GET_E,   "SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_GET_E",
     __sdk_router_mc_rpf_group_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_SET_E,   "SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_SET_E",
     __sdk_router_ecmp_redirect_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_GET_E,   "SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_GET_E",
     __sdk_router_ecmp_redirect_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ECMP_BACKGROUND_SET_E,      "SX_API_INT_CMD_ECMP_BACKGROUND_SET_E",     __sdk_ecmp_background_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E,      "SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E",
     __sdk_ecmp_load_balancing_background_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_SET_E,   "SX_API_INT_CMD_ROUTER_ECMP_SET_E",
     __router_ecmp_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_CLONE_SET_E,   "SX_API_INT_CMD_ROUTER_ECMP_CLONE_SET_E",
     __router_ecmp_clone_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_ACTION_SET_E,   "SX_API_INT_CMD_ROUTER_ECMP_ACTION_SET_E",
     __router_ecmp_action_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_ACTION_SUPPRESS_FILTER_ITER_GET_E,
     "SX_API_INT_CMD_ROUTER_ECMP_ACTION_SUPPRESS_FILTER_ITER_GET_E",
     __router_ecmp_action_suppress_filter_iter_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_GET_E,   "SX_API_INT_CMD_ROUTER_ECMP_GET_E",
     __router_ecmp_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_ITER_GET_E,   "SX_API_INT_CMD_ROUTER_ECMP_ITER_GET_E",
     __router_ecmp_iter_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_OPERATIONAL_GET_E,   "SX_API_INT_CMD_ROUTER_ECMP_OPERATIONAL_GET_E",
     __router_operational_ecmp_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ECMP_CNTR_BIND_SET_E,   "SX_API_INT_CMD_ECMP_CNTR_BIND_SET_E",
     __router_ecmp_counter_bind_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_FINE_GRAIN_COUNTER_BIND_SET_E,
     "SX_API_INT_CMD_ROUTER_ECMP_FINE_GRAIN_COUNTER_BIND_SET_E",
     __router_ecmp_fine_grain_counter_bind_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_SET_E,   "SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_SET_E",
     __sdk_router_cos_rewrite_pcpdei_enable_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_GET_E,   "SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_GET_E",
     __sdk_router_cos_rewrite_pcpdei_enable_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_SET_E,   "SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_SET_E",
     __sdk_router_cos_prio_update_enable_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_GET_E,   "SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_GET_E",
     __sdk_router_cos_prio_update_enable_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_SET_E,   "SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_SET_E",
     __sdk_router_cos_dscp_to_prio_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_GET_E,   "SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_GET_E",
     __sdk_router_cos_dscp_to_prio_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_NOTIFY_E,   "SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_NOTIFY_E",
     __sdk_router_neigh_activity_notify,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ACTIVITY_NOTIFIER_E,   "SX_API_INT_CMD_ROUTER_ACTIVITY_NOTIFIER_E",
     __sdk_router_activity_notifier_cb,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_SET_E,   "SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_SET_E",
     __sdk_router_uc_route_counter_bind_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_GET_E,   "SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_GET_E",
     __sdk_router_uc_route_counter_bind_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_SET_E,   "SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_SET_E",
     __sdk_router_ecmp_attributes_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_GET_E,   "SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_GET_E",
     __sdk_router_ecmp_attributes_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_BACKGROUND_SET_E,      "SX_API_INT_CMD_ROUTER_UC_ROUTE_BACKGROUND_SET_E",
     __sdk_uc_route_background_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_E,      "SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_E",
     __sdk_lpm_tree_background_opt_trigger,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV4_E,
     "SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV4_E",
     __sdk_lpm_tree_background_opt_trigger_ipv4,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV6_E,
     "SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV6_E",
     __sdk_lpm_tree_background_opt_trigger_ipv6,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_TREE_BACKGROUND_OPTIMIZE_E,      "SX_API_INT_CMD_ROUTER_UC_TREE_BACKGROUND_OPTIMIZE_E",
     __sdk_uc_route_tree_background_optimize,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_COMPLETION_INFO_GET_E,   "SX_API_INT_CMD_ROUTER_COMPLETION_INFO_GET_E",
     __sdk_router_completion_info_get,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_SET_E,           "SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_SET_E",
     __sdk_router_user_defined_lpm_tree_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_GET_E,           "SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_GET_E",
     __sdk_router_user_defined_lpm_tree_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_UPDATE_SET_E,           "SX_API_INT_CMD_ROUTER_ECMP_UPDATE_SET_E",
     __sdk_router_ecmp_update_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NAT_SET_E,           "SX_API_INT_CMD_ROUTER_NAT_SET_E",
     __sdk_router_nat_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NAT_GET_E,           "SX_API_INT_CMD_ROUTER_NAT_GET_E",
     __sdk_router_nat_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_SET_E,    "SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_SET_E",
     __sdk_router_lpm_tree_optimize_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_LPM_TREE_BALANCE_FACTOR_GET_E,    "SX_API_INT_CMD_ROUTER_LPM_TREE_BALANCE_FACTOR_GET_E",
     __sdk_router_lpm_tree_balance_factor_get, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_NUM_E, "", NULL, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E,
     SDK_ROUTER_LIB_ALLOWED_ASIC_BITMAP}                                                                                   /* NULL Entry. Keep at end!! */
};


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
int sdk_router_lib_init(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    int               iii = 0;
    sx_api_command_t* cmd = &sx_core_api_sx_router_cmd_table[iii++];
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG(SX_LOG_DEBUG, " system ASIC bit="BYTE_TO_BINARY_PATTERN,  BYTE_TO_BINARY((uint32_t)(1UL << asic_type)));

    do {
        if ((cmd->supported_asic_types) & (1UL << asic_type)) {
            SX_LOG(SX_LOG_DEBUG, "i=%d Add cmd %s to SDK Router Lib CMD table.\n", iii, cmd->name);

            err = sx_core_set_api_command(cmd);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx router api cmd initialization failed \n");
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_DEBUG, "Supported ASIC bitmap="BYTE_TO_BINARY_PATTERN,
                   BYTE_TO_BINARY((uint32_t)(cmd->supported_asic_types)));
            SX_LOG(SX_LOG_DEBUG, "Skip adding unsupported cmd %s to SDK Router table.\n", cmd->name);
        }
        cmd = &sx_core_api_sx_router_cmd_table[iii++];
    } while (cmd->cmd_id != SX_API_INT_CMD_NUM_E);

    LOG_VAR_NAME(__MODULE__) = default_verbosity;

    err = sdk_router_be_log_verbosity_level_set(default_verbosity);

    SX_LOG_INF("SX ROUTER LIB is loaded\n");

out:
    return (int)err;
}

static sx_status_t __sdk_router_verbosity(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size)
{
    sx_api_command_log_verbosity_t *params = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_command_log_verbosity_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_command_log_verbosity_t*)cmd_body;

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = params->verbosity_level;
        err = sdk_router_be_log_verbosity_level_set(params->verbosity_level);
        break;

    case SX_ACCESS_CMD_GET:
        err = sdk_router_be_log_verbosity_level_get(&(params->verbosity_level));
        break;

    default:
        break;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    params->cmd == SX_ACCESS_CMD_GET ?
                                    sizeof(sx_api_command_log_verbosity_t) : 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_init_params_t *params = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_init_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_init_params_t*)cmd_body;
    err = sdk_router_be_init_param(&(params->general_params_p), &(params->router_resource_p));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_deinit_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    err = sdk_router_be_deinit_param(FALSE);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_set_params_t *params = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_set_params_t*)cmd_body;

    err = sdk_router_vrid_be_set(params->cmd, &params->vrid, &(params->router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_get_params_t *params = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_get_params_t*)cmd_body;

    err = sdk_router_vrid_be_get(params->vrid, &(params->router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_vrid_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_vrid_iter_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              size = 0;
    uint16_t                              vrid_cnt;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_vrid_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_vrid_iter_get_params_t*)cmd_body;
    vrid_cnt = params->vrid_cnt;

    err = sdk_router_vrid_be_iter_get(params->cmd,
                                      params->vrid_key,
                                      &(params->vrid_filter),
                                      params->vrid_list,
                                      &vrid_cnt);

    if (params->vrid_cnt > 0) {
        size = sizeof(sx_api_router_vrid_iter_get_params_t) +
               (vrid_cnt * sizeof(sx_router_id_t));
    } else {
        size = sizeof(sx_api_router_vrid_iter_get_params_t);
    }

    params->vrid_cnt = vrid_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)params, size);


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_interface_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_set_params_t*)cmd_body;

    err = sdk_router_interface_set(params->cmd, params->vrid, &(params->ifc),
                                   &(params->ifc_attr), &(params->rif));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_interface_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_get_params_t*)cmd_body;

    err = sdk_router_interface_get(params->rif, &(params->vrid), &(params->ifc),
                                   &(params->ifc_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_iter_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_router_interface_iter_get_params_t *params = NULL;
    uint32_t                                   rif_list_cnt;

    SX_LOG_ENTER();

    if (cmd_body_size < sizeof(sx_api_router_interface_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR,
                                        NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_iter_get_params_t*)cmd_body;
    rif_list_cnt = params->rif_list_cnt;
    err = sdk_router_interface_iter_get(params->cmd,
                                        &(params->rif_key),
                                        &(params->filter),
                                        params->rif_list,
                                        &rif_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in sdk_router_interface_iter_get() , error: %s\n",
                   sx_status_str(err));
    }
    params->rif_list_cnt = rif_list_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    cmd_body_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Send reply got err, error: %s\n", sx_status_str(err));
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_state_set(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_router_interface_state_set_params_t *params = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_state_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_state_set_params_t*)cmd_body;

    err = sdk_router_interface_state_set(params->rif, &(params->rif_state));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_state_get(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_router_interface_state_get_params_t *params = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_state_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_state_get_params_t*)cmd_body;

    err = sdk_router_interface_state_get(params->rif, &(params->rif_state));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_state_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_completion_info_get(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_router_completion_info_get_params_t *params = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_completion_info_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_completion_info_get_params_t*)cmd_body;

    err = sdk_router_async_completion_info_get(&(params->uc_route_info));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_completion_info_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_user_defined_lpm_tree_set(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    sx_api_router_user_defined_lpm_tree_set_params_t *params = NULL;
    sx_status_t                                       err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_user_defined_lpm_tree_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_user_defined_lpm_tree_set_params_t*)cmd_body;

    err = sdk_router_user_defined_tree_be_set(params->cmd, &(params->lpm_tree_attributes), params->nodes_cnt,
                                              params->nodes_list_p, &(params->tree_id));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in creating user defined LPM tree, error: %s\n",
                   sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_user_defined_lpm_tree_get(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    sx_api_router_user_defined_lpm_tree_get_params_t *params = NULL;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    uint8_t                                           nodes_cnt = 0;
    uint32_t                                          reply_body_size = 0;

    if (cmd_body_size < sizeof(sx_api_router_user_defined_lpm_tree_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_user_defined_lpm_tree_get_params_t*)cmd_body;

    nodes_cnt = params->nodes_cnt;

    err = sdk_router_user_defined_tree_be_get(params->tree_id,
                                              &(params->nodes_cnt),
                                              params->nodes_list_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed getting user defined LPM tree, error: %s\n",
                   sx_status_str(err));
    }

    if (nodes_cnt != 0) {
        params->nodes_cnt = MIN(params->nodes_cnt, nodes_cnt);
        nodes_cnt = params->nodes_cnt;
    }

    reply_body_size = sizeof(sx_api_router_user_defined_lpm_tree_get_params_t) +
                      (sizeof(sx_lpm_tree_node_t) * nodes_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_router_interface_mac_set(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    uint32_t                                  size = 0;
    sx_api_router_interface_mac_set_params_t *params = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_interface_mac_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_mac_set_params_t*)cmd_body;
    size = sizeof(sx_api_router_interface_mac_set_params_t) +
           (params->mac_addr_num * sizeof(sx_mac_addr_t));

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_interface_mac_set(params->cmd, params->rif,
                                       params->mac_addr_arr,
                                       params->mac_addr_num);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_counter_get(sx_core_td_event_src_t *event,
                                                      uint8_t                *cmd_body,
                                                      uint32_t                cmd_body_size)
{
    uint32_t                         size = 0;
    sx_api_router_cntr_get_params_t *params = NULL;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_router_counter_set_extended_t cntr_data;

    cntr_data.type = SX_ROUTER_COUNTER_TYPE_BASIC;

    if (cmd_body_size != sizeof(sx_api_router_cntr_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_get_params_t*)cmd_body;

    err = sdk_router_interface_counter_get(params->cmd, params->cntr, &cntr_data);

    size = sizeof(sx_api_router_cntr_get_params_t) +
           sizeof(sx_router_counter_set_t);

    params->cntr_set[0] = cntr_data.data.rif_basic;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);


out:
    return err;
}

static sx_status_t __sdk_router_interface_counter_extended_get(sx_core_td_event_src_t *event,
                                                               uint8_t                *cmd_body,
                                                               uint32_t                cmd_body_size)
{
    sx_api_router_cntr_extended_get_params_t *params = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_extended_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_extended_get_params_t*)cmd_body;

    err = sdk_router_interface_counter_get(params->cmd, params->cntr, &(params->cntr_data));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_extended_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

/* This function returns the counter id and the values of a router counter that is bound to
 * the given RIF id. The above function returns the counter values of a router counter
 */
static sx_status_t __sdk_router_interface_cntr_ext_get(sx_core_td_event_src_t *event,
                                                       uint8_t                *cmd_body,
                                                       uint32_t                cmd_body_size)
{
    sx_api_router_interface_cntr_ext_get_params_t *params = NULL;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_cntr_ext_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_cntr_ext_get_params_t*)cmd_body;
    err = sdk_router_interface_cntr_ext_get(params->cmd, params->rif, &(params->cntr_id), &(params->cntr_data));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_cntr_ext_get_params_t));

out:
    SX_LOG_EXIT();

    return err;
}

/* This function returns the attributes of the given counter id */
static sx_status_t __sdk_router_interface_cntr_attr_get(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size)
{
    sx_api_router_interface_cntr_attr_get_params_t *params = NULL;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_cntr_attr_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_cntr_attr_get_params_t*)cmd_body;
    err = sdk_router_interface_cntr_attr_get(params->cntr_id, &(params->cntr_attributes));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_cntr_attr_get_params_t));

out:
    SX_LOG_EXIT();

    return err;
}
static sx_status_t __sdk_router_interface_counter_alloc_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size)
{
    sx_api_router_cntr_alloc_set_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_router_counter_attributes_t         cntr_attributes;

    if (cmd_body_size != sizeof(sx_api_router_cntr_alloc_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cntr_attributes.type = SX_ROUTER_COUNTER_TYPE_BASIC;

    params = (sx_api_router_cntr_alloc_set_params_t*)cmd_body;
    err = sdk_router_interface_counter_alloc_set(params->cmd, &(params->cntr), cntr_attributes);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_alloc_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_counter_extended_alloc_set(sx_core_td_event_src_t *event,
                                                                     uint8_t                *cmd_body,
                                                                     uint32_t                cmd_body_size)
{
    sx_api_router_cntr_extended_alloc_set_params_t *params = NULL;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_extended_alloc_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_extended_alloc_set_params_t*)cmd_body;
    err = sdk_router_interface_counter_alloc_set(params->cmd, &(params->cntr), params->cntr_attributes);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_extended_alloc_set_params_t));

out:
    return err;
}


static sx_status_t __sdk_router_interface_counter_bind_set(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size)
{
    sx_api_router_cntr_bind_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_cntr_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_bind_set_params_t*)cmd_body;

    err = sdk_router_interface_counter_bind_set(params->cmd, params->cntr, params->rif);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_counter_bind_get(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size)
{
    sx_api_router_cntr_bind_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_cntr_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_bind_get_params_t*)cmd_body;

    err = sdk_router_interface_counter_bind_get(params->cntr, &(params->rif));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_bind_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_interface_counter_clear_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size)
{
    sx_api_router_cntr_clear_set_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_clear_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_clear_set_params_t*)cmd_body;

    err = sdk_router_interface_counter_clear(params->cntr, params->all);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_router_interface_mac_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    uint32_t                                  size = 0;
    sx_api_router_interface_mac_get_params_t *params = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_interface_mac_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_mac_get_params_t*)cmd_body;

    err = sdk_router_interface_mac_get(params->rif, params->mac_addr_arr,
                                       &(params->mac_addr_num));

    size = sizeof(sx_api_router_interface_mac_get_params_t) +
           (params->cmd == SX_ACCESS_CMD_COUNT ? 0 :
            (params->mac_addr_num * sizeof(sx_mac_addr_t)));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __router_ecmp_set(sx_core_td_event_src_t *event,
                                     uint8_t                *cmd_body,
                                     uint32_t                cmd_body_size)
{
    uint32_t                         size = 0;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_set_params_t *params = NULL;

    if (cmd_body_size < sizeof(sx_api_router_ecmp_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_set_params_t*)cmd_body;

    err = sdk_router_ecmp_set(params->cmd, &(params->ecmp_id), params->next_hop_list,
                              &(params->next_hop_cnt));

    size = MIN(sizeof(sx_api_router_ecmp_set_params_t) + params->next_hop_cnt * sizeof(params->next_hop_list[0]),
               cmd_body_size);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_clone_set(sx_core_td_event_src_t *event,
                                           uint8_t                *cmd_body,
                                           uint32_t                cmd_body_size)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_clone_set_params_t *params = NULL;

    if (cmd_body_size < sizeof(sx_api_router_ecmp_clone_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_clone_set_params_t*)cmd_body;

    err = sdk_router_ecmp_clone_set(params->old_ecmp_id, &(params->new_ecmp_id));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_action_set(sx_core_td_event_src_t *event,
                                            uint8_t                *cmd_body,
                                            uint32_t                cmd_body_size)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_action_set_params_t *params = NULL;

    UNUSED_PARAM(params);

    if (cmd_body_size < sizeof(sx_api_router_ecmp_action_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_action_set_params_t*)cmd_body;
    err = sdk_router_ecmp_be_action_set(params->cmd, &params->action, &params->action_filter, &params->action_stat);

    err =
        sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                  sizeof(sx_api_router_ecmp_action_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_action_suppress_filter_iter_get(sx_core_td_event_src_t *event,
                                                                 uint8_t                *cmd_body,
                                                                 uint32_t                cmd_body_size)
{
    sx_status_t                                                  err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_action_suppress_filter_iter_get_params_t *params = NULL;
    sx_api_router_ecmp_action_suppress_filter_iter_get_params_t *reply_body = NULL;
    sx_api_reply_head_t                                          reply_head;
    uint32_t                                                     reply_body_size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(reply_head);

    if (cmd_body_size < sizeof(sx_api_router_ecmp_action_suppress_filter_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_action_suppress_filter_iter_get_params_t*)cmd_body;

    reply_body_size = sizeof(sx_api_router_ecmp_action_suppress_filter_iter_get_params_t) +
                      (params->action_cnt * sizeof(sx_router_ecmp_action_filter_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    err = utils_clr_memory_get((void**)&reply_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        goto err_out;
    }

    SX_MEM_CPY_P(reply_body, params);

    err = sdk_router_ecmp_be_suppress_action_get(reply_body->cmd, &reply_body->action, &reply_body->action_filter,
                                                 reply_body->action_list_p, &reply_body->action_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed ecmp suppress action get, error: %s\n", sx_status_str(err));
        goto err_out;
    }

    reply_head.retcode = SX_STATUS_SUCCESS;
    reply_head.version = SX_API_INT_VERSION;
    reply_head.msg_size = sizeof(sx_api_reply_head_t) + reply_body_size;
    reply_head.list_size = params->action_cnt;

    err = sx_api_send_reply(&(event->commchnl), &reply_head, (uint8_t*)reply_body);

    goto out;

err_out:
    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    if (reply_body) {
        /* free allocated memory */
        M_UTILS_MEM_PUT(reply_body, UTILS_MEM_TYPE_ID_API_E,
                        "reply body memory put failed\n", err);
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_get(sx_core_td_event_src_t *event,
                                     uint8_t                *cmd_body,
                                     uint32_t                cmd_body_size)
{
    uint32_t                         reply_body_size = 0;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_get_params_t *params = NULL;
    boolean_t                        update_cnt = FALSE;

    if (cmd_body_size < sizeof(sx_api_router_ecmp_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_get_params_t*)cmd_body;

    if (0 != params->next_hop_cnt) {
        update_cnt = TRUE;
    }
    reply_body_size = sizeof(sx_api_router_ecmp_get_params_t);

    err = sdk_router_ecmp_get(params->ecmp_id, params->next_hop_list,
                              &(params->next_hop_cnt));

    if ((TRUE == update_cnt) && (0 != params->next_hop_cnt)) {
        reply_body_size = sizeof(sx_api_router_ecmp_get_params_t) + params->next_hop_cnt *
                          sizeof(params->next_hop_list[0]);
    }
    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_iter_get(sx_core_td_event_src_t *event,
                                          uint8_t                *cmd_body,
                                          uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_iter_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              size = 0;
    uint32_t                              ecmp_list_cnt;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_ecmp_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_iter_get_params_t*)cmd_body;
    ecmp_list_cnt = params->ecmp_list_cnt;

    err = sdk_router_ecmp_iter_get(params->cmd,
                                   params->ecmp_key,
                                   &(params->filter),
                                   params->ecmp_list,
                                   &ecmp_list_cnt);

    if (params->ecmp_list_cnt > 0) {
        size = sizeof(sx_api_router_ecmp_iter_get_params_t) +
               (ecmp_list_cnt * sizeof(sx_ecmp_id_t));
    } else {
        size = sizeof(sx_api_router_ecmp_iter_get_params_t);
    }

    params->ecmp_list_cnt = ecmp_list_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)params, size);


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_operational_ecmp_get(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    uint32_t                                     reply_body_size = 0;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sx_api_router_operational_ecmp_get_params_t *params = NULL;
    boolean_t                                    update_cnt = FALSE;

    params = (sx_api_router_operational_ecmp_get_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_operational_ecmp_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_operational_ecmp_get_params_t);

    if (0 != params->next_hop_cnt) {
        update_cnt = TRUE;
    }
    err = sdk_router_operational_ecmp_get(params->ecmp_id, params->next_hop_list,
                                          &(params->next_hop_cnt));

    if ((TRUE == update_cnt) && (0 != params->next_hop_cnt)) {
        reply_body_size = sizeof(sx_api_router_operational_ecmp_get_params_t) + params->next_hop_cnt *
                          sizeof(params->next_hop_list[0]);
    }
    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_counter_bind_set(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_api_ecmp_counter_bind_set_params_t *params = NULL;
    uint32_t                               curr_offset = 0;

    if (cmd_body_size < sizeof(sx_api_ecmp_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_ecmp_counter_bind_set_params_t*)cmd_body;

    /* deserialize cmd body */
    if (params->elements_cnt > 0) {
        curr_offset = sizeof(*params);
        /* counter ids list */
        params->counter_ids_list = (sx_flow_counter_id_t*)((uint8_t*)cmd_body + curr_offset);
        curr_offset += params->elements_cnt * sizeof(params->counter_ids_list[0]);
        /* offsets list */
        params->offset_list = (uint32_t*)((uint8_t*)cmd_body + curr_offset);
        curr_offset += params->elements_cnt * sizeof(params->offset_list[0]);
    }
    /* done */

    err = sdk_router_ecmp_counter_bind_set(params->cmd, params->ecmp_id, params->counter_ids_list,
                                           params->offset_list, params->elements_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_fine_grain_counter_bind_set(sx_core_td_event_src_t *event,
                                                             uint8_t                *cmd_body,
                                                             uint32_t                cmd_body_size)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_ecmp_fine_grain_counter_bind_set_params_t *params = NULL;
    uint32_t                                          curr_offset = 0;

    if (cmd_body_size < sizeof(sx_api_ecmp_fine_grain_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_ecmp_fine_grain_counter_bind_set_params_t*)cmd_body;

    /* deserialize cmd body */
    if (params->elements_cnt > 0) {
        curr_offset = sizeof(*params);
        /* offsets list */
        params->offset_list = (uint32_t*)((uint8_t*)cmd_body + curr_offset);
    }

    err = sdk_router_ecmp_fine_grain_counter_bind_set(params->cmd, params->ecmp_id, params->counter_id,
                                                      params->offset_list, params->elements_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_ecmp_background_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t err;

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    err = sdk_router_impl_background_checker();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SX_API_INT_CMD_ECMP_BACKGROUND_SET_E : SDK Router failed background processing(err=%d)\n", err);
    }

    return err;
}


static sx_status_t __sdk_uc_route_background_set(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    /* Until Router is initialized, do nothing, after that it will be handled by the Async Infra*/

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_uc_route_tree_background_optimize(sx_core_td_event_src_t *event,
                                                           uint8_t                *cmd_body,
                                                           uint32_t                cmd_body_size)
{
    /* Until Router is initialized, do nothing, after that it will be handled by the Async Infra*/

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_lpm_tree_background_opt_trigger(sx_core_td_event_src_t *event,
                                                         uint8_t                *cmd_body,
                                                         uint32_t                cmd_body_size)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS, internal_job_err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_optimize_trigger_params_t *cmd_params;
    sx_api_router_lpm_tree_optimize_trigger_params_t  local_params;

    memset(&local_params, 0, sizeof(sx_api_router_lpm_tree_optimize_trigger_params_t));

    if (cmd_body_size < sizeof(sx_api_router_lpm_tree_optimize_trigger_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    cmd_params = (sx_api_router_lpm_tree_optimize_trigger_params_t*)cmd_body;
    local_params.cmd = cmd_params->cmd;
    local_params.tree_params.protocol = cmd_params->tree_params.protocol;
    local_params.internal_trigger = cmd_params->internal_trigger;

    err = sdk_router_impl_lpm_tree_optimize_trigger(local_params.cmd,
                                                    &local_params.tree_params,
                                                    &local_params.opt_type);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to trigger LPM optimize - [%s]\n", sx_status_str(err));
        goto out;
    }
    if (cmd_params->cmd != SX_ACCESS_CMD_CLEAR) {
        internal_job_err = sx_core_api_add_internal_job(
            SX_API_INT_CMD_ROUTER_UC_TREE_BACKGROUND_OPTIMIZE_E,
            (uint8_t*)&local_params,
            sizeof(local_params), SX_CORE_LOW_PRIO_BUF_E);
        if (SX_CHECK_FAIL(internal_job_err)) {
            if ((internal_job_err == SX_STATUS_NO_RESOURCES) && (local_params.internal_trigger == 1)) {
                goto out; /* internal background optimization job can fail due to queue overflow */
            }
            err = internal_job_err;
            SX_LOG_ERR("Failed in tree background optimization - [%s]\n", sx_status_str(err));
        }
    }
out:
    if (local_params.internal_trigger != 1) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
    }
    return err;
}

static sx_status_t __sdk_lpm_tree_background_opt_trigger_ipv4(sx_core_td_event_src_t *event,
                                                              uint8_t                *cmd_body,
                                                              uint32_t                cmd_body_size)
{
    sx_api_router_lpm_tree_optimize_trigger_params_t lpm_opt_cmd_body;
    uint32_t                                         lpm_opt_cmd_body_size;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    /* Execute the UC Route BG task only every configured interval in seconds */
    lpm_opt_cmd_body.cmd = SX_ACCESS_CMD_READ_CLEAR;
    lpm_opt_cmd_body.internal_trigger = 1;
    lpm_opt_cmd_body.tree_params.protocol = SX_IP_VERSION_IPV4;
    lpm_opt_cmd_body_size = sizeof(lpm_opt_cmd_body);
    return __sdk_lpm_tree_background_opt_trigger(event, (uint8_t*)&lpm_opt_cmd_body, lpm_opt_cmd_body_size);
}

static sx_status_t __sdk_lpm_tree_background_opt_trigger_ipv6(sx_core_td_event_src_t *event,
                                                              uint8_t                *cmd_body,
                                                              uint32_t                cmd_body_size)
{
    sx_api_router_lpm_tree_optimize_trigger_params_t lpm_opt_cmd_body;
    uint32_t                                         lpm_opt_cmd_body_size;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    /* Execute the UC Route BG task only every configured interval in seconds */
    lpm_opt_cmd_body.cmd = SX_ACCESS_CMD_READ_CLEAR;
    lpm_opt_cmd_body.internal_trigger = 1;
    lpm_opt_cmd_body.tree_params.protocol = SX_IP_VERSION_IPV6;
    lpm_opt_cmd_body_size = sizeof(lpm_opt_cmd_body);
    return __sdk_lpm_tree_background_opt_trigger(event, (uint8_t*)&lpm_opt_cmd_body, lpm_opt_cmd_body_size);
}

static sx_status_t __sdk_ecmp_load_balancing_background_set(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    err = sdk_router_ecmp_be_load_balancing_background_checker();

    return err;
}

static sx_status_t __sdk_router_neigh_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_router_neigh_set_params_t *params = NULL;

    if (cmd_body_size < sizeof(sx_api_router_neigh_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_set_params_t*)cmd_body;

    err = sdk_router_neigh_set(params->cmd, params->rif, &params->ip_addr,
                               &params->neigh_data);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_neigh_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_neigh_get_params_t *params = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    uint32_t                          reply_body_size;
    uint32_t                          neigh_entry_cnt;

    if (cmd_body_size != sizeof(sx_api_router_neigh_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_get_params_t*)cmd_body;
    neigh_entry_cnt = params->neigh_entry_cnt;

    err = sdk_router_neigh_get(params->cmd,
                               params->rif,
                               &params->neigh_key,
                               &params->filter,
                               params->neigh_entry_list,
                               &neigh_entry_cnt);


    if (params->neigh_entry_cnt > 0) {
        reply_body_size = sizeof(sx_api_router_neigh_get_params_t) +
                          (neigh_entry_cnt * sizeof(sx_neigh_get_entry_t));
    } else {
        reply_body_size = sizeof(sx_api_router_neigh_get_params_t);
    }

    params->neigh_entry_cnt = neigh_entry_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_router_neigh_activity_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size)
{
    sx_api_router_neigh_get_activity_params_t *params = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_neigh_get_activity_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_get_activity_params_t*)cmd_body;

    err = sdk_router_neigh_activity_get(params->cmd, params->rif, &(params->ip_addr),
                                        &(params->activity));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_neigh_get_activity_params_t));
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_uc_route_set(sx_core_td_event_src_t *event,
                                      uint8_t                *cmd_body,
                                      uint32_t                cmd_body_size)
{
    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);


    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_uc_route_get(sx_core_td_event_src_t *event,
                                      uint8_t                *cmd_body,
                                      uint32_t                cmd_body_size)
{
    uint32_t                             size = 0;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_api_router_uc_route_get_params_t *params = NULL;
    uint32_t                             entries_num = 0;

    if (cmd_body_size < sizeof(sx_api_router_uc_route_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_get_params_t*)cmd_body;

    entries_num = params->uc_route_get_entries_cnt;

    err = sdk_router_uc_route_get(params->cmd, params->vrid, &(params->network_addr), &(params->filter),
                                  params->uc_route_get_entries_list, &entries_num);

    size = sizeof(sx_api_router_uc_route_get_params_t) +
           (params->uc_route_get_entries_cnt * sizeof(sx_uc_route_get_entry_t));

    params->uc_route_get_entries_cnt = entries_num;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_uc_route_ecmp_get(sx_core_td_event_src_t *event,
                                           uint8_t                *cmd_body,
                                           uint32_t                cmd_body_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_UNPERMITTED, NULL, 0);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_cos_rewrite_pcpdei_enable_set(sx_core_td_event_src_t *event,
                                                              uint8_t               * cmd_body,
                                                              uint32_t                cmd_body_size)
{
    sx_api_router_cos_rewrite_pcpdei_enable_set_params_t *cmd_body_p = NULL;
    sx_status_t                                           err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_cos_rewrite_pcpdei_enable_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_rewrite_pcpdei_enable_set_params_t*)cmd_body;

    err = sdk_router_cos_be_rewrite_pcpdei_enable_set(cmd_body_p->rewrite_pcp_dei);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_rewrite_pcpdei_enable_set() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_router_cos_rewrite_pcpdei_enable_get(sx_core_td_event_src_t *event,
                                                              uint8_t               * cmd_body,
                                                              uint32_t                cmd_body_size)
{
    sx_api_router_cos_rewrite_pcpdei_enable_get_params_t *cmd_body_p = NULL;
    sx_status_t                                           err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_cos_rewrite_pcpdei_enable_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_rewrite_pcpdei_enable_get_params_t*)cmd_body;

    err = sdk_router_cos_be_rewrite_pcpdei_enable_get(&(cmd_body_p->rewrite_pcp_dei));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_rewrite_pcpdei_enable_get() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)cmd_body_p, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_router_cos_prio_update_enable_set(sx_core_td_event_src_t *event,
                                                           uint8_t               * cmd_body,
                                                           uint32_t                cmd_body_size)
{
    sx_api_router_cos_prio_update_enable_set_params_t *cmd_body_p = NULL;
    sx_status_t                                        err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_cos_prio_update_enable_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_prio_update_enable_set_params_t*)cmd_body;

    err = sdk_router_cos_be_prio_update_enable_set(cmd_body_p->update_priority_color);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_prio_update_enable_set() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_router_cos_prio_update_enable_get(sx_core_td_event_src_t *event,
                                                           uint8_t               * cmd_body,
                                                           uint32_t                cmd_body_size)
{
    sx_api_router_cos_prio_update_enable_get_params_t *cmd_body_p = NULL;
    sx_status_t                                        err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_cos_prio_update_enable_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_prio_update_enable_get_params_t*)cmd_body;

    err = sdk_router_cos_be_prio_update_enable_get(&(cmd_body_p->update_priority_color));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_prio_update_enable_get() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)cmd_body_p, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_router_cos_dscp_to_prio_set(sx_core_td_event_src_t *event,
                                                     uint8_t               * cmd_body,
                                                     uint32_t                cmd_body_size)
{
    sx_api_router_cos_dscp_to_prio_set_params_t *cmd_body_p = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size < sizeof(sx_api_router_cos_dscp_to_prio_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_dscp_to_prio_set_params_t*)cmd_body;

    err = sdk_router_cos_be_dscp_to_prio_set(cmd_body_p->dscp_switch_prio_list,
                                             cmd_body_p->element_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_dscp_to_prio_set() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_router_cos_dscp_to_prio_get(sx_core_td_event_src_t *event,
                                                     uint8_t               * cmd_body,
                                                     uint32_t                cmd_body_size)
{
    sx_api_router_cos_dscp_to_prio_get_params_t *cmd_body_p = NULL;
    uint32_t                                     reply_body_size;
    uint32_t                                     element_cnt;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size < sizeof(sx_api_router_cos_dscp_to_prio_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_cos_dscp_to_prio_get_params_t*)cmd_body;
    element_cnt = cmd_body_p->element_cnt;

    UNUSED_PARAM(cmd_body_p);
    err = sdk_router_cos_be_dscp_to_prio_get(cmd_body_p->dscp_switch_prio_list,
                                             &element_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_cos_dscp_to_prio_get() , error: %s\n", sx_status_str(err));
        goto err_out;
    }
    if (element_cnt > 0) {
        reply_body_size = sizeof(sx_api_router_cos_dscp_to_prio_get_params_t) +
                          (element_cnt * sizeof(sx_cos_dscp_switch_prio_color_t));
    } else {
        reply_body_size = sizeof(sx_api_router_cos_dscp_to_prio_get_params_t);
    }

    cmd_body_p->element_cnt = element_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)cmd_body_p, reply_body_size);

    goto out;

err_out:
    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_neigh_activity_notify(sx_core_td_event_src_t *event,
                                                      uint8_t               * cmd_body,
                                                      uint32_t                cmd_body_size)
{
    sx_api_router_neigh_activity_notify_params_t *cmd_body_p = NULL;
    sx_status_t                                   err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_neigh_activity_notify_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_neigh_activity_notify_params_t*)cmd_body;

    err = sdk_router_neigh_activity_notify(cmd_body_p->cmd,
                                           cmd_body_p->filter);
    if (SX_CHECK_FAIL(err)) {
        if (err == SX_STATUS_RESOURCE_IN_USE) {
            SX_LOG_NTC("Neighbour activity notification is still in process, err: %s.\n",
                       sx_status_str(err));
        } else {
            SX_LOG_ERR("Failed in router_neigh_activity_notify() , error: %s\n", sx_status_str(err));
        }
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_activity_notifier_cb(sx_core_td_event_src_t *event,
                                                     uint8_t                *cmd_body,
                                                     uint32_t                cmd_body_size)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    status = sdk_router_neigh_activity_notifier_cb();

    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed in sdk_router_neigh_activity_notifier_cb() , error: %s\n", sx_status_str(status));
        return SX_STATUS_SUCCESS;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_router_mc_route_activity_notify_job_process_cb(sx_core_td_event_src_t *event,
                                                                        uint8_t                *cmd_body,
                                                                        uint32_t                cmd_body_size)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    status = sdk_router_mc_route_activity_notify_job_process();

    if (SX_CHECK_FAIL(status)) {
        if ((status == SX_STATUS_SDK_NOT_INITIALIZED) || (status == SX_STATUS_MODULE_UNINITIALIZED)) {
            SX_LOG_NTC("Failed to process activity notify job, error: %s\n", sx_status_str(status));
        } else {
            SX_LOG_ERR("Failed to process activity notify job, error: %s\n", sx_status_str(status));
        }
        return SX_STATUS_SUCCESS;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_router_ecmp_hash_set(sx_core_td_event_src_t *event,
                                              uint8_t                *cmd_body,
                                              uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_hash_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_ecmp_hash_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_hash_set_params_t*)cmd_body;

    err = sdk_router_ecmp_hash_params_set(&(params->ecmp_hash_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_hash_get(sx_core_td_event_src_t *event,
                                              uint8_t                *cmd_body,
                                              uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_hash_get_params_t params;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);

    if (cmd_body_size != 0) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_ecmp_hash_params_get(&(params.ecmp_hash_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)&params,
                                    sizeof(sx_api_router_ecmp_hash_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_port_hash_set(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_port_hash_set_params_t *params_p = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_ecmp_port_hash_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params_p = (sx_api_router_ecmp_port_hash_set_params_t*)cmd_body;

    if (cmd_body_size < (sizeof(sx_api_router_ecmp_port_hash_set_params_t) +
                         params_p->hash_field_list_cnt * sizeof(sx_router_ecmp_hash_field_t))) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_ecmp_port_hash_params_set(params_p->cmd,
                                               params_p->log_port,
                                               &(params_p->ecmp_hash_params),
                                               params_p->hash_field_enable_list_p,
                                               params_p->hash_field_enable_list_cnt,
                                               params_p->hash_field_list_p,
                                               params_p->hash_field_list_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_port_hash_get(sx_core_td_event_src_t *event,
                                                   uint8_t                *cmd_body,
                                                   uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_port_hash_get_params_t *params_p;
    uint32_t                                   size = 0;
    sx_status_t                                err = SX_STATUS_SUCCESS;
    uint32_t                                   hash_field_list_size = 0;

    UNUSED_PARAM(cmd_body);

    if (cmd_body_size < sizeof(sx_api_router_ecmp_port_hash_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params_p = (sx_api_router_ecmp_port_hash_get_params_t*)cmd_body;
    hash_field_list_size = params_p->hash_field_list_cnt;

    err = sdk_router_ecmp_port_hash_params_get(params_p->log_port,
                                               &(params_p->ecmp_hash_params),
                                               params_p->hash_field_enable_list_p,
                                               &(params_p->hash_field_enable_list_cnt),
                                               params_p->hash_field_list_p,
                                               &(params_p->hash_field_list_cnt));
    if (hash_field_list_size == 0) {
        size = sizeof(sx_api_router_ecmp_port_hash_get_params_t);
    } else {
        size = sizeof(sx_api_router_ecmp_port_hash_get_params_t) +
               (params_p->hash_field_list_cnt * sizeof(sx_router_ecmp_hash_field_t));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params_p,
                                    size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_uc_route_counter_bind_set(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    uint32_t                                          size = 0;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_uc_route_counter_bind_set_params_t *params = NULL;

    if (cmd_body_size < sizeof(sx_api_router_uc_route_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_counter_bind_set_params_t*)cmd_body;

    err = sdk_router_uc_route_counter_bind_set(params->cmd, params->vrid, &(params->network_addr), params->counter_id);

    size = sizeof(sx_api_router_uc_route_counter_bind_set_params_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_uc_route_counter_bind_get(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    uint32_t                                          size = 0;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_uc_route_counter_bind_get_params_t *params = NULL;

    if (cmd_body_size < sizeof(sx_api_router_uc_route_counter_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_counter_bind_get_params_t*)cmd_body;

    err = sdk_router_uc_route_counter_bind_get(params->vrid, &(params->network_addr), &params->counter_id);

    size = sizeof(sx_api_router_uc_route_counter_bind_get_params_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_attributes_set(sx_core_td_event_src_t *event,
                                                    uint8_t               * cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_attributes_set_params_t *cmd_body_p = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_ecmp_attributes_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    cmd_body_p = (sx_api_router_ecmp_attributes_set_params_t*)cmd_body;

    err = sdk_router_ecmp_be_attributes_set(cmd_body_p->ecmp_id,
                                            &(cmd_body_p->attr));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_ecmp_attributes_set() , error: %s\n", sx_status_str(err));
    }
    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_set_params_t *params = NULL;
    sx_mc_route_key_t                    mc_route_key;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size != sizeof(sx_api_router_mc_route_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_set_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;

    err = sdk_router_mc_route_set(params->cmd, params->vrid, &mc_route_key,
                                  &params->mc_router_attr, &params->mc_route_data);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_get_params_t *params = NULL;
    sx_mc_route_key_t                    mc_route_key;
    uint32_t                             reply_body_size = 0;
    uint32_t                             mc_route_cnt = 0;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size != sizeof(sx_api_router_mc_route_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_get_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;
    mc_route_cnt = params->mc_route_get_entries_cnt_p;

    err = sdk_router_mc_route_get(params->cmd, params->vrid, &mc_route_key,
                                  &params->filter, params->mc_route_get_entries_list_p,
                                  &params->mc_route_get_entries_cnt_p);

    if (mc_route_cnt != 0) {
        params->mc_route_get_entries_cnt_p = MIN(params->mc_route_get_entries_cnt_p, mc_route_cnt);
        mc_route_cnt = params->mc_route_get_entries_cnt_p;
    }

    reply_body_size = sizeof(sx_api_router_mc_route_get_params_t) +
                      (sizeof(sx_mc_route_get_entry_t) * mc_route_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_activity_get(sx_core_td_event_src_t *event,
                                                      uint8_t                *cmd_body,
                                                      uint32_t                cmd_body_size)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_activity_get_params_t *params = NULL;
    sx_mc_route_key_t                             mc_route_key;

    SX_MEM_CLR(mc_route_key);


    if (cmd_body_size != sizeof(sx_api_router_mc_route_activity_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_activity_get_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;

    err = sdk_router_mc_route_activity_get(params->cmd, params->vrid,
                                           &mc_route_key, &params->activity);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_activity_notify(sx_core_td_event_src_t *event,
                                                         uint8_t                *cmd_body,
                                                         uint32_t                cmd_body_size)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_activity_notify_params_t *cmd_body_p = NULL;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_mc_route_activity_notify_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_mc_route_activity_notify_params_t*)cmd_body;

    err = sdk_router_mc_route_activity_notify(cmd_body_p->cmd,
                                              cmd_body_p->filter);
    if (SX_CHECK_FAIL(err)) {
        if (err == SX_STATUS_RESOURCE_IN_USE) {
            SX_LOG_NTC("MC activity notification process is already running, err: %s.\n",
                       sx_status_str(err));
        } else {
            SX_LOG_ERR("Failed to notify active mc route entries, error: %s\n", sx_status_str(err));
        }
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_egress_rif_set(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_router_mc_egress_rifs_set_params_t *params = NULL;
    sx_mc_route_key_t                          mc_route_key;
    uint32_t                                   expected_cmd_body_size = 0;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size < sizeof(sx_api_router_mc_egress_rifs_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_egress_rifs_set_params_t*)cmd_body;
    expected_cmd_body_size = sizeof(sx_api_router_mc_egress_rifs_set_params_t) +
                             (sizeof(sx_router_interface_t) * params->egress_rifs_num);
    if (cmd_body_size != expected_cmd_body_size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;

    err = sdk_router_mc_egress_rif_set(params->cmd, params->vrid, &mc_route_key,
                                       params->egress_rifs_arr, params->egress_rifs_num);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_egress_rif_get(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_router_mc_egress_rifs_get_params_t *params = NULL;
    sx_mc_route_key_t                          mc_route_key;
    uint32_t                                   reply_body_size = 0;
    uint32_t                                   egress_rifs_num = 0;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size != sizeof(sx_api_router_mc_egress_rifs_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_egress_rifs_get_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;
    egress_rifs_num = params->egress_rifs_num;

    err = sdk_router_mc_egress_rif_get(params->vrid, &mc_route_key,
                                       params->egress_rifs_arr, &params->egress_rifs_num);

    if (egress_rifs_num != 0) {
        params->egress_rifs_num = MIN(params->egress_rifs_num, egress_rifs_num);
        egress_rifs_num = params->egress_rifs_num;
    }

    reply_body_size = sizeof(sx_api_router_mc_egress_rifs_get_params_t) +
                      (sizeof(sx_router_interface_t) * egress_rifs_num);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_counter_bind_set(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_counter_bind_set_params_t *params = NULL;
    sx_mc_route_key_t                                 mc_route_key;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size != sizeof(sx_api_router_mc_route_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_counter_bind_set_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;

    err = sdk_router_mc_route_counter_bind_set(params->cmd, params->vrid,
                                               &mc_route_key, params->flow_counter_id);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_attributes_get(sx_core_td_event_src_t *event,
                                                    uint8_t               * cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_router_ecmp_attributes_get_params_t *cmd_body_p = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_router_ecmp_attributes_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_router_ecmp_attributes_get_params_t*)cmd_body;

    err = sdk_router_ecmp_be_attributes_get(cmd_body_p->ecmp_id,
                                            &(cmd_body_p->attr));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in router_ecmp_attributes_get() , error: %s\n", sx_status_str(err));
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_route_counter_bind_get(sx_core_td_event_src_t *event,
                                                          uint8_t                *cmd_body,
                                                          uint32_t                cmd_body_size)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_mc_route_counter_bind_get_params_t *params = NULL;
    sx_mc_route_key_t                                 mc_route_key;

    SX_MEM_CLR(mc_route_key);

    if (cmd_body_size != sizeof(sx_api_router_mc_route_counter_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_counter_bind_get_params_t*)cmd_body;
    mc_route_key.source_addr = params->source_addr;
    mc_route_key.mc_group_addr = params->mc_group_addr;
    mc_route_key.ingress_rif = params->ingress_rif;

    err = sdk_router_mc_route_counter_bind_get(params->vrid,
                                               &mc_route_key, &params->flow_counter_id);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_rpf_group_set(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_router_mc_rpf_group_set_params_t *params = NULL;
    uint32_t                                 expected_cmd_body_size = 0;

    if (cmd_body_size < sizeof(sx_api_router_mc_rpf_group_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_rpf_group_set_params_t*)cmd_body;
    expected_cmd_body_size = sizeof(sx_api_router_mc_rpf_group_set_params_t) +
                             (params->rpf_vif_cnt * sizeof(sx_router_vinterface_t));

    if (cmd_body_size != expected_cmd_body_size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_mc_rpf_group_set(params->cmd, &params->rpf_group_id,
                               params->rpf_vif_list_p, params->rpf_vif_cnt);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_mc_rpf_group_get(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_router_mc_rpf_group_get_params_t *params = NULL;
    uint32_t                                 reply_body_size = 0;
    uint32_t                                 rpf_vif_cnt = 0;

    if (cmd_body_size != sizeof(sx_api_router_mc_rpf_group_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_rpf_group_get_params_t*)cmd_body;

    rpf_vif_cnt = params->rpf_vif_cnt;

    err = sdk_mc_rpf_group_get(params->cmd, &params->rpf_group_id,
                               params->rpf_vif_list_p, &params->rpf_vif_cnt);

    if (rpf_vif_cnt != 0) {
        params->rpf_vif_cnt = MIN(params->rpf_vif_cnt, rpf_vif_cnt);
        rpf_vif_cnt = params->rpf_vif_cnt;
    }

    reply_body_size = sizeof(sx_api_router_mc_rpf_group_get_params_t) +
                      (rpf_vif_cnt * sizeof(sx_router_vinterface_t));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_redirect_set(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_redirect_set_params_t *params = (sx_api_router_ecmp_redirect_set_params_t*)cmd_body;

    if (cmd_body_size != sizeof(sx_api_router_ecmp_redirect_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_ecmp_be_redirect_set(params->cmd, params->ecmp, params->redirect_ecmp);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_redirect_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_redirect_get_params_t *params = (sx_api_router_ecmp_redirect_get_params_t*)cmd_body;

    if (cmd_body_size != sizeof(sx_api_router_ecmp_redirect_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_ecmp_be_redirect_get(params->ecmp, &params->is_redirected, &params->redirect_ecmp);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_ecmp_update_set(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_update_set_params_t *params = (sx_api_router_ecmp_update_set_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_ecmp_update_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_ecmp_be_update_set(params->cmd,
                                        params->ecmp_id,
                                        params->next_hop_update_list_cnt,
                                        params->next_hop_update_list_p);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_nat_set(sx_core_td_event_src_t *event,
                                        uint8_t                *cmd_body,
                                        uint32_t                cmd_body_size)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_api_router_nat_set_params_t *params = (sx_api_router_nat_set_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_nat_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_nat_4to6_be_set(params->cmd,
                              &params->nat_cfg,
                              &params->nat_id);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_nat_get(sx_core_td_event_src_t *event,
                                        uint8_t                *cmd_body,
                                        uint32_t                cmd_body_size)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_api_router_nat_get_params_t *params = (sx_api_router_nat_get_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_nat_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_nat_4to6_be_get(params->cmd,
                              params->nat_id,
                              &params->nat_cfg);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_lpm_tree_optimize_set(sx_core_td_event_src_t *event,
                                                      uint8_t                *cmd_body,
                                                      uint32_t                cmd_body_size)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_optimize_set_params_t *params = (sx_api_router_lpm_tree_optimize_set_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_lpm_tree_optimize_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = sdk_router_impl_lpm_tree_optimize_set(params->cmd, &params->tree_params, &params->opt_data);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_router_lpm_tree_balance_factor_get(sx_core_td_event_src_t *event,
                                                            uint8_t                *cmd_body,
                                                            uint32_t                cmd_body_size)
{
    sx_status_t                                         err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_balance_factor_get_params_t *params =
        (sx_api_router_lpm_tree_balance_factor_get_params_t*)cmd_body;

    if (cmd_body_size < sizeof(sx_api_router_lpm_tree_balance_factor_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    err = sdk_router_uc_lpm_tree_balance_factor_get(params->tree_params,
                                                    &params->balance_data);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}
