/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWD_TELE_REG_H__
#define __HWD_TELE_REG_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <sx/sdk/sx_types.h>

#include "tele/hwi/tele_impl.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#define MOGCR_SET_CONFIG_F_POLICER_ID_BASE (1 << 0)
#define MOGCR_SET_CONFIG_F_TOC_FMT         (1 << 1)

typedef struct mogcr_set_config {
    uint32_t            config_bitmask;
    uint16_t            pid_base;
    sxd_mogcr_toc_fmt_t toc_fmt;
} mogcr_set_config_t;

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_tele_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity);

sx_status_t access_reg_SBHBR(boolean_t                           is_delete,
                             sx_tele_histogram_key_t             key,
                             sx_tele_histogram_attributes_data_t data,
                             sx_tele_id_t                        tele_id);

sx_status_t access_reg_SBHRR(boolean_t                 is_clear,
                             sx_tele_id_t              tele_id,
                             sx_tele_histogram_data_t *histogram_p);

sx_status_t access_reg_SBHBR_v2(sx_tele_histogram_key_t             key,
                                sx_tele_histogram_attributes_data_t data,
                                boolean_t                           is_enable);

sx_status_t access_reg_PHBR(const sx_tele_histogram_key_t             *key_p,
                            const sx_tele_histogram_attributes_data_t *data_p);

sx_status_t access_reg_PHRR(const sx_tele_histogram_key_t *key_p,
                            boolean_t                      is_clear,
                            sx_tele_histogram_data_t      *histogram_p);

sx_status_t access_reg_SBHRR_v2(sx_tele_histogram_key_t   key,
                                boolean_t                 is_clear,
                                sx_tele_histogram_data_t *histogram_p);

sx_status_t access_reg_SBCTC(sxd_access_cmd_t          cmd,
                             sx_port_log_id_t          log_port,
                             uint8_t                   direction,
                             const uint8_t            *tc_pg_p,
                             uint32_t                  tc_pg_cnt,
                             sx_tele_threshold_data_t *data_p);

sx_status_t access_reg_SBCTR(sx_port_log_id_t log_port,
                             uint8_t          direction,
                             uint8_t          ievent,
                             uint64_t        *crossed_data_p,
                             uint8_t         *entity,
                             uint8_t         *fp);

sx_status_t access_reg_SBGCR(sx_tele_threshold_entity_e        tele_entity,
                             sx_tele_threshold_congestion_fp_e cong_fp);

sx_status_t access_reg_CHLTR(uint8_t             threshold_id,
                             sx_tele_threshold_t threshold);

sx_status_t access_reg_CHLTM(uint8_t                threshold_id,
                             sx_port_log_id_t       log_port,
                             sx_cos_traffic_class_t tc);

sx_status_t access_reg_CHLMM(uint8_t           threshold_id,
                             sx_cos_priority_t sp);

sx_status_t access_reg_MOGCR(const sx_dev_id_t         dev_id,
                             const mogcr_set_config_t *set_config);

sx_status_t access_reg_PCMR(sx_port_log_id_t              log_port,
                            sx_ts_over_crc_ingress_mode_e ts_over_crc_ingress_mode);

sx_status_t access_reg_PBWC(sx_tele_gauge_config_t *gauge_config_p);

sx_status_t access_reg_PBWR(sx_tele_gauge_key_t  *gauge_key_p,
                            sx_tele_gauge_data_t *gauge_data_p);


#endif /* __HWD_TELE_REG_H__ */
