/*
 * SPDX-FileCopyrightText: Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_timer.h>
#include <complib/cl_byteswap.h>
#include <sx/utils/sx_utils_status.h>
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include "utils/sx_adviser.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>

#include "resource_manager/resource_manager_sdk_table.h"
#include "include/resource_manager/resource_manager.h"

#include <host_ifc/host_ifc.h>
#include <ethl2/fdb_common.h>
#include <sx/sxd/sxd_access_register.h>
#include <hwi/tele_impl.h>
#include <hwi/tele_db.h>
#include <hwd/hwd_tele.h>
#include <hwd/hwd_tele_reg.h>

#undef  __MODULE__
#define __MODULE__ TELE

#define TELE_HWD_INIT_CHECK(operation, err)                                             \
    if (FALSE == g_is_initialized) {                                                    \
        err = SX_STATUS_DB_NOT_INITIALIZED;                                             \
        SX_LOG_ERR("Failed to %s, tele HWD module is not initialized.\n", (operation)); \
        goto out;                                                                       \
    }

#define BUILD_MASK_FOR_VAR(var) ((typeof(var)) - 1)

typedef enum {
    HCPNC_CNT_TYPE_CPU = 0, /* Ingress CPU port to network (from host to network) */
    HCPNC_CNT_TYPE_TAC = 1, /* Spectrum4 only */
} hcpnc_cnt_type_e;

#define HGCR_TRUNCATION_MAX_SIZE (0x3FFF)

/************************************************
 *  Global variables
 ***********************************************/
const uint8_t tac_opt_tvl_len[] = {
    [TAC_OPT_TLV_TYPE_UID_LSB_E] = TAC_OPT_TLV_TYPE_UID_LSB_LEN,
    [TAC_OPT_TLV_TYPE_UID_MSB_E] = TAC_OPT_TLV_TYPE_UID_MSB_LEN,
    [TAC_OPT_TLV_TYPE_MAX_LIFETIME_E] = TAC_OPT_TLV_TYPE_MAX_LIFETIME_LEN,
    [TAC_OPT_TLV_TYPE_TAC_COMMAND_E] = TAC_OPT_TLV_TYPE_TAC_COMMAND_LEN,
    [TAC_OPT_TLV_TYPE_LIST_LOCAL_PORTS_E] = TAC_OPT_TLV_TYPE_LIST_LOCAL_PORTS_LEN,
    [TAC_OPT_TLV_TYPE_NOP_E] = TAC_OPT_TLV_TYPE_NOP_LEN
};

#define TAC_TLV_LEN_LIST_SIZE (sizeof(tac_opt_tvl_len) / sizeof(tac_opt_tvl_len[0]))
#define TAC_MSG_GET_TLV_LEN(type) (tac_opt_tvl_len[type])

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_is_initialized = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static int __compare_tele_crossed_data_key_ports(const void* data1,
                                                 const void* data2);
static int __compare_tele_crossed_data_key_indices(const void* data1,
                                                   const void* data2);
static sx_status_t __tele_set_port_tc_over_crc_ingress_mode(sx_port_id_t                  port_id,
                                                            sx_ts_over_crc_ingress_mode_e ts_mode);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t hwd_tele_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    hwd_tele_reg_log_verbosity_level_set(verbosity_level);

    return status;
}


sx_status_t hwd_tele_init(sx_tele_init_params_t *params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == g_is_initialized) {
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Failed to init HWD tele module, module is already initialized.\n");
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(params_p,
                                                      "params_p"))) {
        goto out;
    }

    sx_status = access_reg_SBGCR(SX_TELE_THRESHOLD_ENTITY_PORT_TC_E, SX_TELE_THRESHOLD_CONGESTION_FP_ENABLED_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to init tele module - failed to init SBGCR register.\n");
    }

    g_is_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_deinit(boolean_t is_forced)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        if (FALSE == is_forced) {
            sx_status = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("Failed to deinit tele HWD module, module is not initialized.\n");
        }
        goto out;
    }

    g_is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_init_spc2(sx_tele_init_params_t *params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    UNUSED_PARAM(params_p);

    if (TRUE == g_is_initialized) {
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Failed to init HWD tele module, module is already initialized.\n");
        goto out;
    }

    g_is_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_assign_ops_spc(hwi_tele_ops_t* valid_operations_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_operations_p, "valid_operations_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR_P(valid_operations_p);

    valid_operations_p->hwd_tele_init_pfn = hwd_tele_init;
    valid_operations_p->hwd_tele_deinit_pfn = hwd_tele_deinit;
    valid_operations_p->hwd_tele_histogram_type_validation_pfn = hwd_tele_histogram_type_validation_spc;
    valid_operations_p->hwd_tele_histogram_create_pfn = hwd_tele_histogram_create_spc;
    valid_operations_p->hwd_tele_histogram_edit_pfn = hwd_tele_histogram_edit_spc;
    valid_operations_p->hwd_tele_histogram_destroy_pfn = hwd_tele_histogram_destroy_spc;
    valid_operations_p->hwd_tele_histogram_data_get_pfn = hwd_tele_histogram_data_get_spc;
    valid_operations_p->hwd_tele_threshold_default_set_pfn = NULL;
    valid_operations_p->hwd_tele_threshold_edit_pfn = hwd_tele_threshold_edit;
    valid_operations_p->hwd_tele_threshold_destroy_pfn = hwd_tele_threshold_destroy;
    valid_operations_p->hwd_tele_threshold_crossed_data_get_pfn = hwd_tele_threshold_crossed_data_get;
    valid_operations_p->hwd_tele_threshold_key_validation_pfn = hwd_tele_threshold_key_validation_spectrum;
    valid_operations_p->hwd_tele_threshold_data_validation_pfn = hwd_tele_threshold_data_validation_spectrum;
    valid_operations_p->hwd_tele_threshold_latency_alloc_pfn = NULL;
    valid_operations_p->hwd_tele_threshold_latency_bind_pfn = NULL;
    valid_operations_p->hwd_tele_global_configuration_init_pfn = NULL;
    valid_operations_p->hwd_tele_attr_set_pfn = NULL;
    valid_operations_p->hwd_tele_hash_sig_prof_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_attr_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_sw_header_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_get_pfn = NULL;
    valid_operations_p->hwd_tele_tac_statistics_get_pfn = NULL;
    valid_operations_p->hwd_tele_counter_histogram_type_validation_pfn = NULL;
    valid_operations_p->hwd_tele_port_bw_gauge_set_pfn = NULL;
    valid_operations_p->hwd_tele_port_bw_gauge_data_get_pfn = NULL;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_assign_ops_spc2(hwi_tele_ops_t* valid_operations_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_operations_p, "valid_operations_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR_P(valid_operations_p);

    valid_operations_p->hwd_tele_init_pfn = hwd_tele_init_spc2;
    valid_operations_p->hwd_tele_deinit_pfn = hwd_tele_deinit;
    valid_operations_p->hwd_tele_histogram_type_validation_pfn = hwd_tele_histogram_type_validation_spc2;
    valid_operations_p->hwd_tele_histogram_create_pfn = hwd_tele_histogram_create_spc2;
    valid_operations_p->hwd_tele_histogram_edit_pfn = hwd_tele_histogram_edit_spc2;
    valid_operations_p->hwd_tele_histogram_destroy_pfn = hwd_tele_histogram_destroy_spc2;
    valid_operations_p->hwd_tele_histogram_data_get_pfn = hwd_tele_histogram_data_get_spc2;
    valid_operations_p->hwd_tele_threshold_default_set_pfn = hwd_tele_threshold_default_set;
    valid_operations_p->hwd_tele_threshold_edit_pfn = hwd_tele_threshold_edit;
    valid_operations_p->hwd_tele_threshold_destroy_pfn = hwd_tele_threshold_destroy;
    valid_operations_p->hwd_tele_threshold_crossed_data_get_pfn = hwd_tele_threshold_crossed_data_get;
    valid_operations_p->hwd_tele_threshold_key_validation_pfn = hwd_tele_threshold_key_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_data_validation_pfn = hwd_tele_threshold_data_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_latency_alloc_pfn = hwd_tele_threshold_latency_alloc;
    valid_operations_p->hwd_tele_threshold_latency_bind_pfn = hwd_tele_threshold_latency_bind;
    valid_operations_p->hwd_tele_global_configuration_init_pfn = hwd_tele_global_configuration_init;
    valid_operations_p->hwd_tele_attr_set_pfn = hwd_tele_attr_set_spc2;
    valid_operations_p->hwd_tele_hash_sig_prof_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_attr_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_sw_header_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_get_pfn = NULL;
    valid_operations_p->hwd_tele_tac_statistics_get_pfn = NULL;
    valid_operations_p->hwd_tele_counter_histogram_type_validation_pfn =
        hwd_tele_counter_histogram_type_validation_spectrum2;
    valid_operations_p->hwd_tele_port_bw_gauge_set_pfn = NULL;
    valid_operations_p->hwd_tele_port_bw_gauge_data_get_pfn = NULL;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_assign_ops_spc3(hwi_tele_ops_t* valid_operations_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_operations_p, "valid_operations_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR_P(valid_operations_p);

    valid_operations_p->hwd_tele_init_pfn = hwd_tele_init_spc2;
    valid_operations_p->hwd_tele_deinit_pfn = hwd_tele_deinit;
    valid_operations_p->hwd_tele_histogram_type_validation_pfn = hwd_tele_histogram_type_validation_spc2;
    valid_operations_p->hwd_tele_histogram_create_pfn = hwd_tele_histogram_create_spc2;
    valid_operations_p->hwd_tele_histogram_edit_pfn = hwd_tele_histogram_edit_spc2;
    valid_operations_p->hwd_tele_histogram_destroy_pfn = hwd_tele_histogram_destroy_spc2;
    valid_operations_p->hwd_tele_histogram_data_get_pfn = hwd_tele_histogram_data_get_spc2;
    valid_operations_p->hwd_tele_threshold_default_set_pfn = hwd_tele_threshold_default_set;
    valid_operations_p->hwd_tele_threshold_edit_pfn = hwd_tele_threshold_edit;
    valid_operations_p->hwd_tele_threshold_destroy_pfn = hwd_tele_threshold_destroy;
    valid_operations_p->hwd_tele_threshold_crossed_data_get_pfn = hwd_tele_threshold_crossed_data_get;
    valid_operations_p->hwd_tele_threshold_key_validation_pfn = hwd_tele_threshold_key_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_data_validation_pfn = hwd_tele_threshold_data_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_latency_alloc_pfn = hwd_tele_threshold_latency_alloc;
    valid_operations_p->hwd_tele_threshold_latency_bind_pfn = hwd_tele_threshold_latency_bind;
    valid_operations_p->hwd_tele_global_configuration_init_pfn = hwd_tele_global_configuration_init;
    valid_operations_p->hwd_tele_attr_set_pfn = hwd_tele_attr_set_spc2;
    valid_operations_p->hwd_tele_hash_sig_prof_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_attr_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_sw_header_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_set_pfn = NULL;
    valid_operations_p->hwd_tele_tac_action_get_pfn = NULL;
    valid_operations_p->hwd_tele_tac_statistics_get_pfn = NULL;
    valid_operations_p->hwd_tele_counter_histogram_type_validation_pfn =
        hwd_tele_counter_histogram_type_validation_spectrum3;
    valid_operations_p->hwd_tele_port_bw_gauge_set_pfn = NULL;
    valid_operations_p->hwd_tele_port_bw_gauge_data_get_pfn = NULL;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_assign_ops_spc4(hwi_tele_ops_t* valid_operations_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_operations_p, "valid_operations_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR_P(valid_operations_p);

    valid_operations_p->hwd_tele_init_pfn = hwd_tele_init_spc2;
    valid_operations_p->hwd_tele_deinit_pfn = hwd_tele_deinit;
    valid_operations_p->hwd_tele_histogram_type_validation_pfn = hwd_tele_histogram_type_validation_spc2;
    valid_operations_p->hwd_tele_histogram_create_pfn = hwd_tele_histogram_create_spc2;
    valid_operations_p->hwd_tele_histogram_edit_pfn = hwd_tele_histogram_edit_spc2;
    valid_operations_p->hwd_tele_histogram_destroy_pfn = hwd_tele_histogram_destroy_spc2;
    valid_operations_p->hwd_tele_histogram_data_get_pfn = hwd_tele_histogram_data_get_spc2;
    valid_operations_p->hwd_tele_threshold_default_set_pfn = hwd_tele_threshold_default_set;
    valid_operations_p->hwd_tele_threshold_edit_pfn = hwd_tele_threshold_edit;
    valid_operations_p->hwd_tele_threshold_destroy_pfn = hwd_tele_threshold_destroy;
    valid_operations_p->hwd_tele_threshold_crossed_data_get_pfn = hwd_tele_threshold_crossed_data_get;
    valid_operations_p->hwd_tele_threshold_key_validation_pfn = hwd_tele_threshold_key_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_data_validation_pfn = hwd_tele_threshold_data_validation_spectrum2;
    valid_operations_p->hwd_tele_threshold_latency_alloc_pfn = hwd_tele_threshold_latency_alloc;
    valid_operations_p->hwd_tele_threshold_latency_bind_pfn = hwd_tele_threshold_latency_bind;
    valid_operations_p->hwd_tele_global_configuration_init_pfn = hwd_tele_global_configuration_init;
    valid_operations_p->hwd_tele_attr_set_pfn = hwd_tele_attr_set_spc2;
    valid_operations_p->hwd_tele_hash_sig_prof_set_pfn = hwd_tele_hash_sig_prof_set;
    valid_operations_p->hwd_tele_tac_attr_set_pfn = hwd_tele_tac_attr_set_spc4;
    valid_operations_p->hwd_tele_tac_sw_header_set_pfn = hwd_tele_tac_sw_header_set_spc4;
    valid_operations_p->hwd_tele_tac_set_pfn = hwd_tele_tac_set_spc4;
    valid_operations_p->hwd_tele_tac_action_set_pfn = hwd_tele_tac_action_set_spc4;
    valid_operations_p->hwd_tele_tac_action_get_pfn = hwd_tele_tac_action_get_spc4;
    valid_operations_p->hwd_tele_tac_statistics_get_pfn = hwd_tele_tac_statistics_get_spc4;
    valid_operations_p->hwd_tele_counter_histogram_type_validation_pfn =
        hwd_tele_counter_histogram_type_validation_spectrum4;
    valid_operations_p->hwd_tele_port_bw_gauge_set_pfn = hwd_tele_port_bw_gauge_set;
    valid_operations_p->hwd_tele_port_bw_gauge_data_get_pfn = hwd_tele_port_bw_gauge_data_get;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_type_validation_spc(const sx_tele_histogram_key_t *key_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (key_p->type != SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E) {
        SX_LOG_ERR("Invalid histogram type %s.\n", sx_tele_histogram_type_str(key_p->type));
        sx_status = SX_STATUS_PARAM_ERROR;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_create_spc(const sx_tele_histogram_key_t             key,
                                          const sx_tele_histogram_attributes_data_t data,
                                          const sx_tele_id_t                        tele_id,
                                          uint8_t                                  *num_of_emads)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    *num_of_emads = 2;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to create tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(key.key.port_tc.log_port) == SX_PORT_TYPE_PROFILE) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create tele entry HWD module, port profile is not supported.\n");
        goto out;
    }

    sx_status = access_reg_SBHBR(FALSE, key, data, tele_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBHBR register (rc=%d)\n", sx_status);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_edit_spc(const sx_tele_histogram_key_t             key,
                                        const sx_tele_histogram_attributes_data_t data,
                                        const sx_tele_id_t                        tele_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to edit tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_SBHBR(FALSE, key, data, tele_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBHBR register (rc=%d)\n", sx_status);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_destroy_spc(const sx_tele_histogram_key_t key, const sx_tele_id_t tele_id)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_tele_histogram_attributes_data_t data;

    SX_LOG_ENTER();

    SX_MEM_CLR(data);

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to delete tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_SBHBR(TRUE, key, data, tele_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBHBR register (rc=%d)\n", sx_status);
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_data_get_spc(const sx_tele_histogram_key_t key,
                                            const sx_tele_id_t            tele_id,
                                            boolean_t                     is_clear,
                                            sx_tele_histogram_data_t     *histogram_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(key);

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to delete tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_SBHRR(is_clear, tele_id, histogram_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBHRR register (rc=%d)\n", sx_status);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_type_validation_spc2(const sx_tele_histogram_key_t *key_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!SX_CHECK_RANGE(SX_TELE_HISTOGRAM_TYPE_MIN_E, key_p->type, SX_TELE_HISTOGRAM_TYPE_MAX_E)) {
        SX_LOG_ERR("Invalid histogram type %s.\n", sx_tele_histogram_type_str(key_p->type));
        sx_status = SX_STATUS_PARAM_ERROR;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_create_spc2(const sx_tele_histogram_key_t             key,
                                           const sx_tele_histogram_attributes_data_t data,
                                           const sx_tele_id_t                        tele_id,
                                           uint8_t                                  *num_of_emads)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(tele_id);

    SX_LOG_ENTER();
    *num_of_emads = 1;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to create tele entry HWD module, module is not initialized.\n");
        goto out;
    }
    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
        /* clear the bins values before creating the histogram, this is to cover the case the user created a histogram with */
        /* control=STOP and then tried to read the histogram bins. if we don't clear the bins the user might read garbage values. */


        if (SX_PORT_TYPE_ID_GET(key.key.port_counter.log_port) != SX_PORT_TYPE_PROFILE) {
            sx_status = access_reg_PHRR(&key, TRUE, NULL);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update PHRR register (rc=%d)\n", sx_status);
                goto out;
            }
        }

        sx_status = access_reg_PHBR(&key, &data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update PHBR register (rc=%d)\n", sx_status);
            goto out;
        }
    } else {
        sx_status = access_reg_SBHBR_v2(key, data, TRUE);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update SBHBR_V2 register (rc=%d)\n", sx_status);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_edit_spc2(const sx_tele_histogram_key_t             key,
                                         const sx_tele_histogram_attributes_data_t data,
                                         const sx_tele_id_t                        tele_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(tele_id);

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to edit tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
        sx_status = access_reg_PHBR(&key, &data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update PHBR register (rc=%d)\n", sx_status);
            goto out;
        }
    } else {
        sx_status = access_reg_SBHBR_v2(key, data, TRUE);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update SBHBR_V2 register (rc=%d)\n", sx_status);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_destroy_spc2(const sx_tele_histogram_key_t key, const sx_tele_id_t tele_id)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_tele_histogram_attributes_data_t data;

    UNUSED_PARAM(tele_id);

    SX_LOG_ENTER();

    SX_MEM_CLR(data);

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E) {
        SX_LOG_INF("FW does not support in destroying latency histogram\n");
        goto out;
    }

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to delete tele entry HWD module, module is not initialized.\n");
        goto out;
    }


    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
        data.data.port_counter.control = SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_STOP_E;
        sx_status = access_reg_PHBR(&key, &data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update PHBR register (rc=%d)\n", sx_status);
            goto out;
        }
    } else {
        sx_status = access_reg_SBHRR_v2(key, TRUE, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to clear histogram data with SBHRR_V2 register (rc=%d)\n", sx_status);
            goto out;
        }

        sx_status = access_reg_SBHBR_v2(key, data, FALSE);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update SBHBR_V2 register (rc=%d)\n", sx_status);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_histogram_data_get_spc2(const sx_tele_histogram_key_t key,
                                             const sx_tele_id_t            tele_id,
                                             const boolean_t               is_clear,
                                             sx_tele_histogram_data_t     *histogram_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(tele_id);

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to delete tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
        sx_status = access_reg_PHRR(&key, is_clear, histogram_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update PHRR register (rc=%d)\n", sx_status);
        }
    } else {
        sx_status = access_reg_SBHRR_v2(key, is_clear, histogram_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get histogram data - SBHRR_V2 register (rc=%d)\n", sx_status);
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_threshold_default_set(const sx_tele_threshold_key_t key)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t                log_port = 0;
    tele_threshold_direction_type_e direction = 0;

    if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
        log_port = key.key.port_tc.log_port;
        direction = TELE_THRESHOLD_DIRECTION_EGRESS_E;
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
        log_port = key.key.port_pg.log_port;
        direction = TELE_THRESHOLD_DIRECTION_INGRESS_E;
    } else {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set default congestion threshold: invalid key type %s\n",
                   sx_tele_threshold_type_str(key.key_type));
        goto out;
    }

    sx_status = access_reg_SBCTC(SXD_ACCESS_CMD_SET, log_port, direction, NULL, 0, NULL);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBCTC register (rc=%d)\n", sx_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_threshold_edit(const sx_port_log_id_t                log_port,
                                    const tele_threshold_direction_type_e direction,
                                    const sx_cos_traffic_class_t         *tc_pg_p,
                                    const uint8_t                         tc_pg_cnt,
                                    const sx_tele_threshold_data_t        data)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t threshold_data;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to edit tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    threshold_data = data;

    sx_status = access_reg_SBCTC(SXD_ACCESS_CMD_SET, log_port, direction, tc_pg_p, tc_pg_cnt, &threshold_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBCTC register (rc=%d)\n", sx_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_threshold_destroy(const sx_port_log_id_t                log_port,
                                       const tele_threshold_direction_type_e direction,
                                       const sx_cos_traffic_class_t         *tc_pg_p,
                                       const uint8_t                         tc_pg_cnt)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t data;

    SX_MEM_CLR(data);

    /* In Spectrum/2, threshold is apply on all port TC/PG's.
     * User key for threshold set command is (port, tc) / (port, pg).
     * Destroy command perform an update of the port TC/PG's list.
     * The value of port's current operational threshold is queried from FW */

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to delete tele entry HWD module, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_SBCTC(SXD_ACCESS_CMD_GET, log_port, direction, NULL, 0, &data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to read SBCTC register (rc=%d)\n", sx_status);
        goto out;
    }

    sx_status = access_reg_SBCTC(SXD_ACCESS_CMD_SET, log_port, direction, tc_pg_p, tc_pg_cnt, &data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update SBCTC register (rc=%d)\n", sx_status);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_threshold_crossed_data_get(sx_tele_threshold_crossed_data_keys_t *data_p, const uint32_t list_cnt)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    uint64_t         crossed_data_vec = 0;
    uint8_t          entity = 0;
    uint8_t          fp = 0;
    uint8_t          direction = 0;
    uint32_t         i = 0;
    sx_port_log_id_t log_port = 0;
    sx_port_log_id_t log_port_next = 0;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to create tele threshold entry HWD module, module is not initialized.\n");
        goto out;
    }

    /* sort the array according to log_port for minimal HW access */
    qsort(data_p, list_cnt, sizeof(sx_tele_threshold_crossed_data_keys_t), &__compare_tele_crossed_data_key_ports);

    for (i = 0; i < list_cnt;) {
        if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            log_port = data_p[i].key.key.port_tc.log_port;
            direction = 0;
        } else if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_E) {
            log_port = data_p[i].key.key.port.log_port;
            direction = 0;
        } else if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            log_port = data_p[i].key.key.port_pg.log_port;
            direction = 1;
        } else {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid key type (key_type=%u)\n", data_p[i].key.key_type);
            goto out;
        }
        /* get the data for all TC/PG's in the port */
        sx_status = access_reg_SBCTR(log_port, direction, 1, &crossed_data_vec, &entity, &fp);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update SBCTR register (rc=%s)\n", sx_status_str(sx_status));
            goto out;
        }

        /* update crossed_data for all keys corresponding to the port */
        do {
            switch (entity) {
            case SX_TELE_THRESHOLD_ENTITY_PORT_TC_E:
                if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                    data_p[i].crossed_data.type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E;
                    data_p[i].crossed_data.data.port_tc = (crossed_data_vec >> (data_p[i].key.key.port_tc.tc)) & 1;
                } else if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                    data_p[i].crossed_data.type = SX_TELE_THRESHOLD_TYPE_PORT_PG_E;
                    data_p[i].crossed_data.data.port_pg = (crossed_data_vec >> (data_p[i].key.key.port_pg.pg)) & 1;
                } else {
                    sx_status = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Invalid key type (key_type=%u)\n", data_p[i].key.key_type);
                    goto out;
                }
                break;

            case SX_TELE_THRESHOLD_ENTITY_PORT_E:
                data_p[i].crossed_data.type = SX_TELE_THRESHOLD_TYPE_PORT_E;
                if (fp == SX_TELE_THRESHOLD_CONGESTION_FP_DISABLED_E) {
                    data_p[i].crossed_data.data.port = SX_TELE_THRESHOLD_CONGESTED_E;
                } else {
                    data_p[i].crossed_data.data.port = SX_TELE_THRESHOLD_MAYBE_CONGESTED_E;
                }
                break;
            }
            i++;
            if (i < list_cnt) {
                if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                    log_port_next = data_p[i].key.key.port_tc.log_port;
                } else if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_E) {
                    log_port_next = data_p[i].key.key.port.log_port;
                } else if (data_p[i].key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                    log_port_next = data_p[i].key.key.port_pg.log_port;
                }
            }
        } while ((i < list_cnt) &&
                 (log_port == log_port_next));
    }

    /* restore the original order of the array */
    qsort(data_p, list_cnt, sizeof(sx_tele_threshold_crossed_data_keys_t), &__compare_tele_crossed_data_key_indices);


out:
    SX_LOG_EXIT();
    return sx_status;
}

static int __compare_tele_crossed_data_key_ports(const void* data1, const void* data2)
{
    const sx_tele_threshold_crossed_data_keys_t* dat1 = data1;
    const sx_tele_threshold_crossed_data_keys_t* dat2 = data2;
    sx_port_log_id_t                             log_port1 = 0;
    sx_port_log_id_t                             log_port2 = 0;

    sdk_tele_impl_threshold_key_log_port_get(dat1->key, &log_port1);
    sdk_tele_impl_threshold_key_log_port_get(dat2->key, &log_port2);

    return (log_port1 - log_port2);
}

static int __compare_tele_crossed_data_key_indices(const void* data1, const void* data2)
{
    const sx_tele_threshold_crossed_data_keys_t* dat1 = data1;
    const sx_tele_threshold_crossed_data_keys_t* dat2 = data2;

    return (dat1->key_index - dat2->key_index);
}

static sx_status_t __threshold_port_pg_key_verify(const sx_tele_threshold_key_t *key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (IS_PORT_TYPE_NETWORK_OR_LAG(key_p->key.port_pg.log_port) == FALSE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port (0x%x) type [%s] is invalid. Only types NETWORK and LAG are supported. err = %s \n",
                   key_p->key.port_pg.log_port,
                   sx_port_type_str(SX_PORT_TYPE_ID_GET(key_p->key.port_pg.log_port)),
                   sx_status_str(err));
        goto out;
    }

    if (RM_PORT_INGRESS_SHARED_BUFFER_PG_ID_CHECK_RANGE(key_p->key.port_pg.pg) == FALSE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port (0x%x) PG (%d) exceeds range\n", key_p->key.port_pg.log_port, key_p->key.port_pg.pg);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __threshold_port_tc_key_verify(const sx_tele_threshold_key_t *key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (IS_PORT_TYPE_NETWORK_OR_LAG(key_p->key.port_tc.log_port) == FALSE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port (0x%x) type [%s] is invalid. Only types NETWORK and LAG are supported. err = %s \n",
                   key_p->key.port_pg.log_port,
                   sx_port_type_str(SX_PORT_TYPE_ID_GET(key_p->key.port_tc.log_port)),
                   sx_status_str(err));
        goto out;
    }

    if (key_p->key.port_tc.tc > rm_resource_global.cos_port_ets_traffic_class_max) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Traffic class [%u] > max traffic class [%u]. err = %s.\n",
                   key_p->key.port_tc.tc,
                   rm_resource_global.cos_port_ets_traffic_class_max,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __threshold_legacy_data_verify(const sx_tele_threshold_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (data_p->data.port_tc_threshold > TELE_THRESHOLD_STATIC_MAX_VALUE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold value [%u] exceeds range. max allowed threshold: [%u]. err = %s \n",
                   data_p->data.port_tc_threshold,
                   TELE_THRESHOLD_STATIC_MAX_VALUE,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __threshold_static_data_verify(const sx_tele_threshold_key_t  *key_p,
                                                  const sx_tele_threshold_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((key_p->key_type != SX_TELE_THRESHOLD_TYPE_PORT_TC_E) &&
        (key_p->key_type != SX_TELE_THRESHOLD_TYPE_PORT_PG_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold data type static valid for threshold key types "
                   "port_tc and port_pg only. Threshold key (%s).\n", sx_tele_threshold_type_str(key_p->key_type));
        goto out;
    }
    if (data_p->threshold_data.threshold_low > data_p->threshold_data.threshold_high) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold low value (%d) is higher than high value (%d).\n",
                   data_p->threshold_data.threshold_low,
                   data_p->threshold_data.threshold_high);
        goto out;
    }
    if (data_p->threshold_data.threshold_high > TELE_THRESHOLD_STATIC_MAX_VALUE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold high value (%u) exceeds range. Max allowed threshold: (%u).\n",
                   data_p->threshold_data.threshold_high,
                   TELE_THRESHOLD_STATIC_MAX_VALUE);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __threshold_percentage_data_verify(const sx_tele_threshold_key_t  *key_p,
                                                      const sx_tele_threshold_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((key_p->key_type != SX_TELE_THRESHOLD_TYPE_PORT_TC_E) &&
        (key_p->key_type != SX_TELE_THRESHOLD_TYPE_PORT_PG_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold data type percentage valid for threshold key types "
                   "port_tc and port_pg only. Threshold key type (%s)\n", sx_tele_threshold_type_str(key_p->key_type));
        goto out;
    }
    if (data_p->threshold_data.threshold_low > data_p->threshold_data.threshold_high) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold low value (%d) is higher than high value (%d).\n",
                   data_p->threshold_data.threshold_low,
                   data_p->threshold_data.threshold_high);
        goto out;
    }
    if (data_p->threshold_data.threshold_high > 100) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold high value (%u) exceeds range. Max allowed threshold: (%u).\n",
                   data_p->threshold_data.threshold_high,
                   100);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __threshold_latency_data_verify(const sx_tele_threshold_key_t  *key_p,
                                                   const sx_tele_threshold_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((key_p->key_type != SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) &&
        (key_p->key_type != SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold data type latency valid for threshold key types "
                   "Latency Port TC and Latency MC SP only. Threshold key type (%s)\n",
                   sx_tele_threshold_type_str(key_p->key_type));
        goto out;
    }
    if (data_p->threshold_data.threshold_high > rm_resource_global.tele_threshold_latency_thr_max) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Latency threshold high value (%u) exceeds range. Max allowed threshold: (%u).\n",
                   data_p->threshold_data.threshold_high,
                   rm_resource_global.tele_threshold_latency_thr_max);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tele_threshold_key_validation_spectrum(const sx_tele_threshold_key_t key)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
        err = __threshold_port_tc_key_verify(&key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("threshold key type [%s] is invalid. err = %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t hwd_tele_threshold_key_validation_spectrum2(const sx_tele_threshold_key_t key)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E:
        err = __threshold_port_tc_key_verify(&key);
        break;

    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        err = __threshold_port_pg_key_verify(&key);
        break;

    case SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E:
        err = cos_check_port_priority(key.key.mc_sp.sp);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("threshold key type [%s] is invalid. err = %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }
out:
    return err;
}


sx_status_t hwd_tele_threshold_data_validation_spectrum2(const sx_tele_threshold_key_t  key,
                                                         const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (data.threshold_data_type) {
    case SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E:
        err = __threshold_legacy_data_verify(&data);
        break;

    case SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E:
        err = __threshold_static_data_verify(&key, &data);
        break;

    case SX_TELE_THRESHOLD_DATA_TYPE_PERCENTAGE_E:
        err = __threshold_percentage_data_verify(&key, &data);
        break;

    case SX_TELE_THRESHOLD_DATA_TYPE_LATENCY_E:
        err = __threshold_latency_data_verify(&key, &data);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("threshold data type [%d] is invalid. err = %s\n",
                   data.threshold_data_type,
                   sx_status_str(err));
        goto out;
    }
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold data validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t hwd_tele_threshold_data_validation_spectrum(const sx_tele_threshold_key_t  key,
                                                        const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (key.key_type != data.data_type) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("key and data types do not comply, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = __threshold_legacy_data_verify(&data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold data validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t hwd_tele_threshold_latency_alloc(const uint8_t latency_id, const sx_tele_threshold_data_t data)
{
    return access_reg_CHLTR(latency_id, data.threshold_data.threshold_high);
}

sx_status_t hwd_tele_threshold_latency_bind(const uint8_t latency_id, const sx_tele_threshold_key_t key)
{
    if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) {
        return access_reg_CHLTM(latency_id, key.key.port_tc.log_port, key.key.port_tc.tc);
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E) {
        return access_reg_CHLMM(latency_id, key.key.mc_sp.sp);
    }

    return SX_STATUS_PARAM_ERROR;
}

sx_status_t hwd_tele_global_configuration_init(const sx_dev_id_t dev_id)
{
    mogcr_set_config_t config;

    SX_MEM_CLR(config);
    config.config_bitmask = MOGCR_SET_CONFIG_F_POLICER_ID_BASE;
    config.pid_base = rm_resource_global.policer_host_ifc_pool_size + rm_resource_global.policer_pool_size;
    return access_reg_MOGCR(dev_id, &config);
}

static sx_status_t __tele_set_port_tc_over_crc_ingress_mode(sx_port_id_t                  port_id,
                                                            sx_ts_over_crc_ingress_mode_e ts_mode)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = access_reg_PCMR(port_id, ts_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" Failed to set port (%u) CRC parameters (%s).\n",
                   port_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_attr_set_spc2(const sx_tele_attrib_t attr, sx_port_id_t *port, const sx_swid_id_t swid)
{
    sx_status_t   sx_status = SX_STATUS_SUCCESS;
    uint32_t      i = 0, port_num = 0;
    sx_port_id_t *port_list_p = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to set telemetry attributes, module is not initialized.\n");
        goto out;
    }

    if (port == NULL) {
        sx_status = port_swid_get(SX_ACCESS_CMD_COUNT, swid, NULL, &port_num);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve number of swid (%u) ports (%s).\n",
                       swid, sx_status_str(sx_status));
            goto out;
        }

        if (port_num == 0) {
            goto out;
        }
        port_list_p = (sx_port_id_t*)cl_malloc(port_num * sizeof(sx_port_id_t));
        if (port_list_p == NULL) {
            sx_status = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed in memory allocation for port list(%s).\n", sx_status_str(sx_status));
            goto out;
        }
        sx_status = port_swid_get(SX_ACCESS_CMD_GET, swid, port_list_p, &port_num);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve swid (%u) ports (%s).\n",
                       swid, sx_status_str(sx_status));
            goto out;
        }
    } else {
        port_list_p = port;
        port_num = 1;
    }

    for (i = 0; i < port_num; i++) {
        if (SX_PORT_TYPE_ID_GET(port_list_p[i]) != SX_PORT_TYPE_NETWORK) {
            continue;
        }
        sx_status = __tele_set_port_tc_over_crc_ingress_mode(port_list_p[i], attr.internal_ts_enable);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set port (%u) CRC parameters (%s).\n",
                       port_list_p[i], sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if ((port_list_p != NULL) && (port == NULL)) {
        CL_FREE_N_NULL(port_list_p);
    }

    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __hwd_tele_hash_sig_profile_set(const uint8_t                          prof_idx,
                                                   const sx_tele_hash_sig_params_t       *hash_params_p,
                                                   const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                                   const uint32_t                         hash_field_enable_list_cnt,
                                                   const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                                   const uint32_t                         hash_field_list_cnt)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     ihsr_reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_ihsr_reg ihsr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    uint32_t           offset;
    uint32_t           field_idx;

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Set tele hash sig params on REG IHSR\n");

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(ihsr_reg_meta[dev_idx]);
    ihsr_reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    ihsr_reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;

    SX_MEM_CLR(ihsr_reg_data[dev_idx]);
    ihsr_reg_data[dev_idx].hash_profile = prof_idx;
    ihsr_reg_data[dev_idx].type = SXD_IHSR_HASH_TYPE_CRC;

    if (hash_params_p->symmetric_hash_outer) {
        ihsr_reg_data[dev_idx].gsh |= (1 << SXD_IHSR_SYMMETRIC_HASH_OUTER);
    }

    if (hash_params_p->symmetric_hash_inner) {
        ihsr_reg_data[dev_idx].gsh |= (1 << SXD_IHSR_SYMMETRIC_HASH_INNER);
    }

    if (hash_params_p->symmetric_hash_gp_reg) {
        ihsr_reg_data[dev_idx].gsh |= (1 << SXD_IHSR_SYMMETRIC_HASH_GP_REG);
    }

    for (field_idx = 0; field_idx < hash_field_enable_list_cnt; field_idx++) {
        if (SX_TELE_HASH_SIG_IS_FIELD_ENABLE_OUTER(hash_field_enable_list_p[field_idx])) {
            offset = hash_field_enable_list_p[field_idx]
                     - SX_TELE_HASH_SIG_OUTER_ENABLES_OFFSET;
            ihsr_reg_data[dev_idx].outer_header_enables |= (1 << offset);
        } else if (SX_TELE_HASH_SIG_IS_FIELD_ENABLE_INNER(hash_field_enable_list_p[field_idx])) {
            offset = hash_field_enable_list_p[field_idx]
                     - SX_TELE_HASH_SIG_INNER_ENABLES_OFFSET;
            ihsr_reg_data[dev_idx].inner_header_enables |= (1 << offset);
        } else {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "__hwd_tele_hash_sig_profile_set Failed."
                   "hash field enable [%u] is not in range.\n",
                   hash_field_enable_list_p[field_idx]);
            goto out;
        }
    }

    for (field_idx = 0; field_idx < hash_field_list_cnt; field_idx++) {
        if (SX_TELE_HASH_SIG_IS_FIELD_OUTER(hash_field_list_p[field_idx])) {
            offset = hash_field_list_p[field_idx]
                     - SX_TELE_HASH_SIG_OUTER_FIELDS_OFFSET;
            /* outer_header_fields_enable bit field 0 is in the lower 32bit */
            ihsr_reg_data[dev_idx].outer_header_fields_enable[SXD_IHSR_OUTER_HEADER_FIELDS_ENABLE_NUM - 1 -
                                                              (offset / BITS_IN_UINT32)]
                |= (1 << (offset % BITS_IN_UINT32));
        } else if (SX_TELE_HASH_SIG_IS_FIELD_INNER(hash_field_list_p[field_idx])) {
            offset = hash_field_list_p[field_idx]
                     - SX_TELE_HASH_SIG_INNER_FIELDS_OFFSET;
            ihsr_reg_data[dev_idx].inner_header_fields_enable |=
                (UINT64_C(1) << offset);
        } else if (SX_TELE_HASH_SIG_IS_FIELD_GENERAL(
                       hash_field_list_p[field_idx])) {
            if (SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(hash_field_list_p[field_idx])) {
                offset = SX_TELE_HASH_SIG_GP_REGISTER_TO_OFFSET(hash_field_list_p[field_idx]);
            } else {
                offset = hash_field_list_p[field_idx] - SX_TELE_HASH_SIG_GENERAL_FIELDS_OFFSET;
            }
            ihsr_reg_data[dev_idx].general_fields |= (1 << offset);
        } else {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "__hwd_tele_hash_sig_profile_set Failed."
                   "hash field [%u] is not in range.\n",
                   hash_field_list_p[field_idx]);
            goto out;
        }
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IHSR_E, ihsr_reg_data, ihsr_reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set IHSR: [%s].\n",
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __ihscr_create_port_bitmask(const sx_port_log_id_t *log_ports_p,
                                               const uint32_t          port_cnt,
                                               uint32_t               *port_bitmask_p)
{
    uint32_t              i = 0, port_idx;
    uint32_t              port_num = 0;
    sx_device_id_t        device_id = 1;
    sx_port_attributes_t *port_attributes_p = NULL;
    sx_status_t           err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_ARRAY(port_bitmask_p, SXD_IHSCR_PORTS_BITMAP_NUM, uint32_t);
    if (port_cnt == 0) {
        /*get device's number of ports*/
        err = port_device_get(SX_ACCESS_CMD_COUNT, device_id, SX_SWID_ID_DONTCARE, NULL, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve number of ports, Error: (%s).\n",
                       sx_status_str(err));
            goto out;
        }

        port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
        if (port_attributes_p == NULL) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed in memory allocation (%s).\n", sx_status_str(err));
            goto out;
        }

        /*Get device logical ports list*/
        err = port_device_get(SX_ACCESS_CMD_GET, device_id, SX_SWID_ID_DONTCARE, port_attributes_p, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve ports info, Error: (%s).\n",
                       sx_status_str(err));
            goto out;
        }
        /* For the catch all ports */
        for (port_idx = 0; port_idx < rm_resource_global.port_ext_num_max; port_idx++) {
            if (SX_PORT_TYPE_ID_GET(port_attributes_p[port_idx].log_port) != SX_PORT_TYPE_NETWORK) {
                continue;
            }
            SXD_BITMAP_REVERSE_SET(port_bitmask_p,
                                   SXD_IHSCR_PORTS_BITMAP_NUM,
                                   sizeof(port_bitmask_p[0]) * 8,
                                   SX_PORT_PHY_ID_GET(port_attributes_p[port_idx].log_port));
        }
    } else {
        /* Get all the ports into the bitmask */
        for (i = 0; i < port_cnt; i++) {
            SXD_BITMAP_REVERSE_SET(port_bitmask_p,
                                   SXD_IHSCR_PORTS_BITMAP_NUM,
                                   sizeof(port_bitmask_p[0]) * 8,
                                   SX_PORT_PHY_ID_GET(log_ports_p[i]));
        }
    }

out:
    if (port_attributes_p) {
        cl_free(port_attributes_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tele_hash_sig_classifier_set(const uint8_t                             profile_index,
                                                      const sx_tele_hash_sig_classifier_attr_t *hash_sig_classifier_attr_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      ihscr_reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_ihscr_reg ihscr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Set tele hash sig classifier params on REG IHSCR\n");

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(ihscr_reg_meta[dev_idx]);
    ihscr_reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    ihscr_reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;

    SX_MEM_CLR(ihscr_reg_data[dev_idx]);
    ihscr_reg_data[dev_idx].profile_index = profile_index;

    ihscr_reg_data[dev_idx].inner_l2_type = 0xFF;
    if (hash_sig_classifier_attr_p->inner_l2_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_L2_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].inner_l2_type = hash_sig_classifier_attr_p->inner_l2_type_classifiers;
    }

    ihscr_reg_data[dev_idx].l3_type = 0xFF;
    if (hash_sig_classifier_attr_p->l3_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_L3_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].l3_type = hash_sig_classifier_attr_p->l3_type_classifiers;
    }

    ihscr_reg_data[dev_idx].inner_l3_type = 0xFF;
    if (hash_sig_classifier_attr_p->inner_l3_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_L3_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].inner_l3_type = hash_sig_classifier_attr_p->inner_l3_type_classifiers;
    }

    ihscr_reg_data[dev_idx].ip_frag = 0xFF;
    if (hash_sig_classifier_attr_p->ip_fragment_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_IP_FRAGMENT_ANY_E) {
        ihscr_reg_data[dev_idx].ip_frag = hash_sig_classifier_attr_p->ip_fragment_classifiers;
    }

    ihscr_reg_data[dev_idx].inner_ip_frag = 0xFF;
    if (hash_sig_classifier_attr_p->inner_ip_fragment_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_IP_FRAGMENT_ANY_E) {
        ihscr_reg_data[dev_idx].inner_ip_frag = hash_sig_classifier_attr_p->inner_ip_fragment_classifiers;
    }

    ihscr_reg_data[dev_idx].l4_type = 0xFF;
    if (hash_sig_classifier_attr_p->l4_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_L4_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].l4_type = hash_sig_classifier_attr_p->l4_type_classifiers;
    }

    ihscr_reg_data[dev_idx].inner_l4_type = 0xFF;
    if (hash_sig_classifier_attr_p->inner_l4_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_L4_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].inner_l4_type = hash_sig_classifier_attr_p->inner_l4_type_classifiers;
    }

    ihscr_reg_data[dev_idx].tunnel_type = 0xFF;
    if (hash_sig_classifier_attr_p->tunnel_type_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_TUNNEL_TYPE_ANY_E) {
        ihscr_reg_data[dev_idx].tunnel_type = hash_sig_classifier_attr_p->tunnel_type_classifiers;
    }

    ihscr_reg_data[dev_idx].fpp_index = 0xFF;
    if (hash_sig_classifier_attr_p->fpp_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_FPP_ANY_E) {
        ihscr_reg_data[dev_idx].fpp_index = hash_sig_classifier_attr_p->fpp_classifiers;
    }

    ihscr_reg_data[dev_idx].inner_fpp_index = 0xFF;
    if (hash_sig_classifier_attr_p->inner_fpp_classifiers != SX_TELE_HASH_SIG_CLASSIFIER_FPP_ANY_E) {
        ihscr_reg_data[dev_idx].inner_fpp_index = hash_sig_classifier_attr_p->inner_fpp_classifiers;
    }

    sx_status = __ihscr_create_port_bitmask(hash_sig_classifier_attr_p->ports_classifiers.port_list,
                                            hash_sig_classifier_attr_p->ports_classifiers.port_cnt,
                                            ihscr_reg_data[dev_idx].ports_bitmap);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to create port bitmask for ihscr, err: %s.\n",
               sx_status_str(sx_status));
        goto out;
    }

    ihscr_reg_data[dev_idx].mask_inner = 0;
    ihscr_reg_data[dev_idx].mask_outer = 0;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IHSCR_E, ihscr_reg_data, ihscr_reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set IHSCR: [%s].\n",
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_hash_sig_prof_set(const uint8_t                             prof_idx,
                                       const sx_tele_hash_sig_classifier_attr_t *hash_sig_classifier_attr_p,
                                       const sx_tele_hash_sig_params_t          *hash_params_p,
                                       const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                       const uint32_t                            hash_field_enable_list_cnt,
                                       const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                       const uint32_t                            hash_field_list_cnt)
{
    sx_status_t sx_status;

    SX_LOG_ENTER();

    sx_status = __hwd_tele_hash_sig_profile_set(prof_idx, hash_params_p,
                                                hash_field_enable_list_p, hash_field_enable_list_cnt,
                                                hash_field_list_p, hash_field_list_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "__hwd_tele_hash_sig_profile_set failed: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    /* classifier will be updated only for user profile
     * in this case hash_sig_classifier_attr_p != NULL */
    if (hash_sig_classifier_attr_p != NULL) {
        sx_status = __hwd_tele_hash_sig_classifier_set(prof_idx, hash_sig_classifier_attr_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__hwd_tele_hash_sig_classifier_set failed: [%s].\n",
                   SX_STATUS_MSG(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __handle_htec(sxd_access_cmd_t access_cmd, struct ku_htec_reg *htec_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     htec_reg_meta;
    struct ku_htec_reg htec_reg_data;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HTEC %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(htec_reg_meta);
    SX_MEM_CLR(htec_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (access_cmd == SXD_ACCESS_CMD_SET) {
        htec_reg_data = *htec_reg_data_p;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    htec_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    htec_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTEC_E,
                                                     &htec_reg_data, &htec_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HTEC: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (access_cmd == SXD_ACCESS_CMD_GET) {
        *htec_reg_data_p = htec_reg_data;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __handle_hrdqt(sxd_access_cmd_t access_cmd, struct ku_hrdqt_reg *hrdqt_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      hrdqt_reg_meta;
    struct ku_hrdqt_reg hrdqt_reg_data;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HRDQT %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(hrdqt_reg_meta);
    SX_MEM_CLR(hrdqt_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }


    hrdqt_reg_data = *hrdqt_reg_data_p;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    hrdqt_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    hrdqt_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HRDQT_E,
                                                     &hrdqt_reg_data, &hrdqt_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HRDQT: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (access_cmd == SXD_ACCESS_CMD_GET) {
        *hrdqt_reg_data_p = hrdqt_reg_data;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __handle_htacg(sxd_access_cmd_t access_cmd, struct ku_htacg_reg *htacg_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      htacg_reg_meta;
    struct ku_htacg_reg htacg_reg_data;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HTACG %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(htacg_reg_meta);
    SX_MEM_CLR(htacg_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }


    htacg_reg_data = *htacg_reg_data_p;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    htacg_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    htacg_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTACG_E,
                                                     &htacg_reg_data, &htacg_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HTACG: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    /* we will take the return data for SET and GET because status returned always for both */
    *htacg_reg_data_p = htacg_reg_data;

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __handle_htcr(sxd_access_cmd_t access_cmd, struct ku_htcr_reg *htcr_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     htcr_reg_meta;
    struct ku_htcr_reg htcr_reg_data;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HTCR %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(htcr_reg_meta);
    SX_MEM_CLR(htcr_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }


    htcr_reg_data = *htcr_reg_data_p;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    htcr_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    htcr_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTCR_E,
                                                     &htcr_reg_data, &htcr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HTCR: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (access_cmd == SXD_ACCESS_CMD_GET) {
        *htcr_reg_data_p = htcr_reg_data;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __handle_hcpnc(sxd_access_cmd_t access_cmd, struct ku_hcpnc_reg *hcpnc_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      hcpnc_reg_meta;
    struct ku_hcpnc_reg hcpnc_reg_data;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HCPNC %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(hcpnc_reg_meta);
    SX_MEM_CLR(hcpnc_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    hcpnc_reg_data = *hcpnc_reg_data_p;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    hcpnc_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    hcpnc_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HCPNC_E,
                                                     &hcpnc_reg_data, &hcpnc_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HCPNC: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (access_cmd == SXD_ACCESS_CMD_GET) {
        *hcpnc_reg_data_p = hcpnc_reg_data;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __sx_to_sxd_hgcr_tac_action(sx_tele_tac_action_e           sx_tac_action,
                                        sxd_hgcr_tac_crawler_action_t *sxd_tac_action_p)
{
    switch (sx_tac_action) {
    case SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E:
        *sxd_tac_action_p = SXD_HGCR_TAC_CRAWLER_ACTION_FLUSH_AND_REPORT_E;
        break;

    case SX_TELE_TAC_ACTION_REPORT_E:
        *sxd_tac_action_p = SXD_HGCR_TAC_CRAWLER_ACTION_REPORT_ONLY_E;
        break;

    case SX_TELE_TAC_ACTION_FLUSH_E:
        *sxd_tac_action_p = SXD_HGCR_TAC_CRAWLER_ACTION_FLUSH_NO_REPORT_E;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported tac_action : %d \n", sx_tac_action);
        return SX_STATUS_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t __sx_to_sxd_htacg_tac_action(sx_tele_tac_action_e sx_tac_action, sxd_htacg_tac_flush_t *sxd_tac_action_p)
{
    switch (sx_tac_action) {
    case SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E:
        *sxd_tac_action_p = SXD_HTACG_TAC_FLUSH_FLUSH_AND_REPORT_E;
        break;

    case SX_TELE_TAC_ACTION_REPORT_E:
        *sxd_tac_action_p = SXD_HTACG_TAC_FLUSH_REPORT_ONLY_E;
        break;

    case SX_TELE_TAC_ACTION_FLUSH_E:
        *sxd_tac_action_p = SXD_HTACG_TAC_FLUSH_FLUSH_NO_REPORT_E;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported tac_action : %d \n", sx_tac_action);
        return SX_STATUS_ERROR;
    }

    return SX_STATUS_SUCCESS;
}


sx_status_t hwd_tele_tac_attr_set_spc4(const sx_tele_tac_attr_t *tac_attr_p)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    struct ku_hgcr_reg hgcr_reg_data;

    SX_LOG_ENTER();

    /* read the HGCR */
    sx_status = __handle_hgcr(SXD_ACCESS_CMD_GET, &hgcr_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "tac_attr set failed: Failed to get HGCR: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (tac_attr_p->tac_mode == SX_TELE_TAC_MODE_TO_NETWORK_E) {
        hgcr_reg_data.tac_mirror_action = SXD_HGCR_TAC_MIRROR_ACTION_TAC_TO_MIRROR_E;
    }

    if (tac_attr_p->tac_periodic_action_enabled) {
        __sx_to_sxd_hgcr_tac_action(tac_attr_p->tac_periodic_action,
                                    &hgcr_reg_data.tac_crawler_action);
        hgcr_reg_data.tac_crawler_timer = tac_attr_p->tac_periodic_action_interval;
    } else {
        hgcr_reg_data.tac_crawler_timer = SXD_HGCR_TAC_CRAWLER_STOP;
    }

    /* update the tac attributes and write it back */
    sx_status = __handle_hgcr(SXD_ACCESS_CMD_SET, &hgcr_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "tac_attr set failed: Failed to set HGCR: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


void uint64_to_bytes_array(uint64_t value, uint8_t* bytes_array_p, uint8_t bytes_array_len)
{
    int i;

    if (bytes_array_len > sizeof(uint64_t)) {
        return;
    }

    for (i = bytes_array_len - 1; i >= 0; i--) {
        bytes_array_p[i] = value & 0xFF;
        value >>= 8;
    }
}


sx_status_t __build_htec_sw_header(const sx_tele_tac_sw_header_info_t *tac_sw_header_p,
                                   struct ku_htec_reg                 *htec_reg_data_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    sx_tele_tac_msg_sw_header tac_msg_sw_header;
    uint32_t                  i;

    UNUSED_PARAM(tac_sw_header_p);
    UNUSED_PARAM(htec_reg_data_p);

    if (sizeof(htec_reg_data_p->tac_event_header) < sizeof(tac_msg_sw_header)) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG(SX_LOG_ERROR, "__build_htec_sw_header failed tac_ev_hdr (%u) < tac_msg_sw_hdr (%u), err:%s\n",
               (unsigned int)sizeof(htec_reg_data_p->tac_event_header),
               (unsigned int)sizeof(tac_msg_sw_header), sx_status_str(sx_status));
    }

    SX_MEM_CLR(tac_msg_sw_header);

    uint64_to_bytes_array(TAC_MSG_SW_HDR_DMAC, tac_msg_sw_header.tac_msg_hdr.dmac, ETHER_ADDR_LENGTH);
    uint64_to_bytes_array(TAC_MSG_SW_HDR_SMAC, tac_msg_sw_header.tac_msg_hdr.smac, ETHER_ADDR_LENGTH);
    tac_msg_sw_header.tac_msg_hdr.eth_type = cl_hton16(TAC_MSG_SW_HDR_ETH_TYPE);
    tac_msg_sw_header.tac_msg_hdr.version_msg_type =
        TAC_MSG_SW_HDR_VERSION_MSG_TYPE_BUILD(TAC_MSG_SW_HDR_VERSION, TAC_MSG_TYPE_EVENT_SW_HDR_E);
    tac_msg_sw_header.tac_msg_hdr.msg_total_len = TAC_MSG_EVENT_SW_HDR_OPT_LIST_LEN;

    tac_msg_sw_header.opt_tlv_list[0].opt_type = TAC_OPT_TLV_TYPE_UID_MSB_E;
    tac_msg_sw_header.opt_tlv_list[0].opt_len = TAC_MSG_GET_TLV_LEN(tac_msg_sw_header.opt_tlv_list[0].opt_type);
    tac_msg_sw_header.opt_tlv_list[0].opt_data = cl_hton16((tac_sw_header_p->uid_device_id >> 16) & 0xFFFF);

    tac_msg_sw_header.opt_tlv_list[1].opt_type = TAC_OPT_TLV_TYPE_UID_LSB_E;
    tac_msg_sw_header.opt_tlv_list[1].opt_len = TAC_MSG_GET_TLV_LEN(tac_msg_sw_header.opt_tlv_list[1].opt_type);
    tac_msg_sw_header.opt_tlv_list[1].opt_data = cl_hton16(tac_sw_header_p->uid_device_id & 0xFFFF);

    tac_msg_sw_header.opt_tlv_list[2].opt_type = TAC_OPT_TLV_TYPE_MAX_LIFETIME_E;
    tac_msg_sw_header.opt_tlv_list[2].opt_len = TAC_MSG_GET_TLV_LEN(tac_msg_sw_header.opt_tlv_list[2].opt_type);
    tac_msg_sw_header.opt_tlv_list[2].opt_data = cl_hton16(tac_sw_header_p->max_lifetime);

    memcpy(&(htec_reg_data_p->tac_event_header), &(tac_msg_sw_header), sizeof(tac_msg_sw_header));

    /* we need to convert to network order because this is uint32_t */
    for (i = 0; i < SXD_HTEC_TAC2MIRROR_RAW_DATA_NUM; i++) {
        htec_reg_data_p->tac_event_header.tac2mirror.raw_data[i] = cl_hton32(
            htec_reg_data_p->tac_event_header.tac2mirror.raw_data[i]);
    }

    /* to keep the original flow in the SXD parser with the tac 2 mirror action */
    htec_reg_data_p->dummy = SXD_HTEC_DUMMY_DUMMY_2_E;

    return sx_status;
}

sx_status_t hwd_tele_tac_sw_header_set_spc4(const sx_tele_tac_sw_header_info_t *tac_sw_header_p)
{
    sx_status_t        sx_status;
    struct ku_htec_reg htec_reg_data;

    SX_LOG_ENTER();

    /* read HTEC register */
    sx_status = __handle_htec(SXD_ACCESS_CMD_GET, &htec_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "tac_sw_header set failed: Failed to get HTEC: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    __build_htec_sw_header(tac_sw_header_p, &htec_reg_data);

    /* update the SW event header and write it back */
    sx_status = __handle_htec(SXD_ACCESS_CMD_SET, &htec_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "tac_sw_header set failed: Failed to set HTEC: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __get_hw_trap_group(sx_trap_group_t trap_group, uint8_t         *rdq_p)
{
    sx_status_t                sx_status;
    sx_swid_id_t               swid = 0;
    sx_trap_group_attributes_t trap_group_attributes;

    SX_MEM_CLR(trap_group_attributes);

    sx_status = host_ifc_trap_group_get(trap_group, swid,
                                        &trap_group_attributes);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get trap group,rc [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    *rdq_p = trap_group_attributes.hw_trap_group;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_tac_set_spc4(sx_access_cmd_t cmd, sx_trap_group_t trap_group, uint8_t hw_span_session_id)
{
    sx_status_t         sx_status;
    struct ku_hrdqt_reg hrdqt_reg_data;

    SX_LOG_ENTER();

    sx_status = __get_hw_trap_group(trap_group, &hrdqt_reg_data.rdq);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get hw trap group for trap group %d, rc: [%s].\n",
               trap_group, SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        hrdqt_reg_data.tac_en = 1;
        hrdqt_reg_data.mirror_agent = hw_span_session_id;
    } else {
        hrdqt_reg_data.tac_en = 0;
        hrdqt_reg_data.mirror_agent = 0;
    }

    /* update the SW event header and write it back */
    sx_status = __handle_hrdqt(SXD_ACCESS_CMD_SET, &hrdqt_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set HRDQT: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_tac_action_set_spc4(sx_access_cmd_t              cmd,
                                         sx_tele_tac_action_filter_t *tac_action_filter_p,
                                         sx_tele_tac_action_info_t   *tac_action_info_p,
                                         sx_tele_tac_action_status_e *tac_action_status_p)
{
    sx_status_t         sx_status;
    struct ku_htacg_reg htacg_reg_data;

    UNUSED_PARAM(cmd);

    SX_LOG_ENTER();

    SX_MEM_CLR(htacg_reg_data);

    __sx_to_sxd_htacg_tac_action(tac_action_info_p->tac_action, &htacg_reg_data.tac_flush);

    if (tac_action_filter_p->filter_by_span_mirror_reason) {
        htacg_reg_data.fields.mirror_reason = tac_action_filter_p->span_mirror_reason;
        htacg_reg_data.mask.mirror_reason = BUILD_MASK_FOR_VAR(htacg_reg_data.mask.mirror_reason);
    }
    if (tac_action_filter_p->filter_by_trap_group) {
        sx_status = __get_hw_trap_group(tac_action_filter_p->trap_group,
                                        &(htacg_reg_data.fields.rdq));
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__get_hw_trap_group failed for trap group %d , err: [%s].\n",
                   tac_action_filter_p->trap_group, SX_STATUS_MSG(sx_status));
            goto out;
        }
        htacg_reg_data.mask.rdq = BUILD_MASK_FOR_VAR(htacg_reg_data.mask.rdq);
    }

    if (tac_action_filter_p->filter_by_trap_id) {
        htacg_reg_data.fields.trap_id = tac_action_filter_p->trap_id;
        htacg_reg_data.mask.trap_id = BUILD_MASK_FOR_VAR(htacg_reg_data.mask.trap_id);
    }

    sx_status = __handle_htacg(SXD_ACCESS_CMD_SET, &htacg_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set HTACG: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (htacg_reg_data.status == SXD_TAC_ACTION_STATUS_BUSY_E) {
        *tac_action_status_p = SX_TELE_TAC_ACTION_STATUS_BUSY_E;
    } else {
        *tac_action_status_p = SX_TELE_TAC_ACTION_STATUS_FREE_E;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_tac_action_get_spc4(sx_tele_tac_action_status_e *tac_action_status_p)
{
    sx_status_t         sx_status;
    struct ku_htacg_reg htacg_reg_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(htacg_reg_data);

    sx_status = __handle_htacg(SXD_ACCESS_CMD_GET, &htacg_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get HTACG: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (htacg_reg_data.status == SXD_TAC_ACTION_STATUS_BUSY_E) {
        *tac_action_status_p = SX_TELE_TAC_ACTION_STATUS_BUSY_E;
    } else {
        *tac_action_status_p = SX_TELE_TAC_ACTION_STATUS_FREE_E;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_tac_statistics_get_spc4(sx_tele_tac_statistics_t *tele_tac_statistics_p, boolean_t is_read_clear)
{
    sx_status_t         sx_status;
    struct ku_htcr_reg  htcr_reg_data;
    struct ku_hcpnc_reg hcpnc_reg_data;
    uint32_t            i;
    uint8_t             rdq;
    sx_trap_group_t     trap_group;

    SX_LOG_ENTER();

    SX_MEM_CLR(htcr_reg_data);

    htcr_reg_data.clr = (is_read_clear) ? 1 : 0;
    sx_status = __handle_htcr(SXD_ACCESS_CMD_GET, &htcr_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get HTCR: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    hcpnc_reg_data.clr = (is_read_clear) ? 1 : 0;
    hcpnc_reg_data.cnt_type = HCPNC_CNT_TYPE_TAC;
    sx_status = __handle_hcpnc(SXD_ACCESS_CMD_GET, &hcpnc_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get HCPNC: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    for (i = 0; i < tele_tac_statistics_p->trap_group_tac_statistics_cnt; i++) {
        trap_group = tele_tac_statistics_p->trap_group_tac_statistics[i].trap_group;
        sx_status = __get_hw_trap_group(trap_group, &rdq);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to get hw trap group for trap group %d, rc: [%s].\n",
                   trap_group, SX_STATUS_MSG(sx_status));
            goto out;
        }
        tele_tac_statistics_p->trap_group_tac_statistics[i].tac_ingress_drop =
            htcr_reg_data.ingress_drop_rdq[rdq];
    }

    tele_tac_statistics_p->global_tac_statistics.tac_ingress_pkt =
        htcr_reg_data.tac_received_pkts;        /**< Total number of packets entered to TAC. */
    tele_tac_statistics_p->global_tac_statistics.tac_egress_pkt =
        hcpnc_reg_data.pkt_ok_cnt;               /**< number of packet transmitted from TAC. */
    tele_tac_statistics_p->global_tac_statistics.tac_egress_bytes =
        hcpnc_reg_data.byte_ok_cnt;             /**< number of bytes transmitted from TAC. */
    tele_tac_statistics_p->global_tac_statistics.tac_egress_pkt_drop =
        hcpnc_reg_data.pkt_discard_cnt;         /**< number of packet drop on the egress from TAC */


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tele_counter_histogram_type_validation_spectrum2(const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BUFFER_OVERFLOW_PG_0_BYTE_E,
                       data_p->data.port_counter.port_counter_type,
                       SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BUFFER_OVERFLOW_PG_7_BYTE_E)
        || SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BYTE_RECEIVED_OK_INC_IPG_E,
                          data_p->data.port_counter.port_counter_type,
                          SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BYTE_TRANSMIT_OK_INC_IPG_E)
        || SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_ECN_PACKETS_TRANSMIT_E,
                          data_p->data.port_counter.port_counter_type,
                          SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_ECN_PACKETS_TRANSMIT_TC_16_E)) {
        SX_LOG_ERR("Invalid counter histogram type %d.\n", data_p->data.port_counter.port_counter_type);
        err = SX_STATUS_PARAM_ERROR;
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tele_counter_histogram_type_validation_spectrum3(const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BUFFER_OVERFLOW_PG_0_BYTE_E,
                       data_p->data.port_counter.port_counter_type,
                       SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BUFFER_OVERFLOW_PG_7_BYTE_E)
        || SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BYTE_RECEIVED_OK_INC_IPG_E,
                          data_p->data.port_counter.port_counter_type,
                          SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_BYTE_TRANSMIT_OK_INC_IPG_E)) {
        SX_LOG_ERR("Invalid counter histogram type %d.\n", data_p->data.port_counter.port_counter_type);
        err = SX_STATUS_PARAM_ERROR;
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tele_counter_histogram_type_validation_spectrum4(const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t hwd_tele_port_bw_gauge_set(sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to set port BW gauge, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_PBWC(gauge_config_p);

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update PBWC register (rc=%d)\n", sx_status);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tele_port_bw_gauge_data_get(sx_tele_gauge_key_t *gauge_key_p, sx_tele_gauge_data_t *gauge_data_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to get port BW gauge data, module is not initialized.\n");
        goto out;
    }

    sx_status = access_reg_PBWR(gauge_key_p, gauge_data_p);

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update PBWC register (rc=%d)\n", sx_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
