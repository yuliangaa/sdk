/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_TELE_BE_H__
#define __HWI_TELE_BE_H__

#include <sx/sdk/sx_types.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/
#define TELE_MAP_GET_MAX_NUM 20

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define TELE_HISTOGRAM_MAX_BOUNDRY                  \
    (rm_resource_global.shared_buff_max_pool_size / \
     rm_resource_global.shared_buff_buffer_unit_size)


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_tele_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t sdk_tele_be_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

/*
 * Init telemetry module.
 */
sx_status_t sdk_tele_init(const sx_tele_init_params_t * params_p);

/*
 * Deinit telemetry module.
 */
sx_status_t sdk_tele_deinit(boolean_t is_forced);

void sdk_tele_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_tele_histogram_set(const sx_access_cmd_t                     cmd,
                                   const sx_tele_histogram_key_t             key,
                                   const sx_tele_histogram_attributes_data_t data);

sx_status_t sdk_tele_histogram_get(const sx_access_cmd_t                cmd,
                                   const sx_tele_histogram_key_t        key,
                                   sx_tele_histogram_attributes_data_t *data_p);

sx_status_t sdk_tele_histogram_iter_get(const sx_access_cmd_t      cmd,
                                        sx_tele_histogram_key_t    hist_key,
                                        sx_tele_histogram_filter_t hist_filter,
                                        sx_tele_histogram_key_t   *hist_list_p,
                                        uint32_t                  *hist_cnt_p);

sx_status_t sdk_tele_histogram_data_get(const sx_access_cmd_t         cmd,
                                        const sx_tele_histogram_key_t key,
                                        sx_tele_histogram_data_t     *histogram_p);

sx_status_t sdk_tele_threshold_set(const sx_access_cmd_t          cmd,
                                   const sx_tele_threshold_key_t  key,
                                   const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_threshold_get(const sx_access_cmd_t         cmd,
                                   const sx_tele_threshold_key_t key,
                                   sx_tele_threshold_data_t     *data_p);

sx_status_t sdk_tele_threshold_iter_get(const sx_access_cmd_t      cmd,
                                        sx_tele_threshold_key_t    key,
                                        sx_tele_threshold_filter_t filter,
                                        sx_tele_threshold_key_t   *key_list_p,
                                        uint32_t                  *key_cnt_p);

sx_status_t sdk_tele_threshold_crossed_data_get(const sx_access_cmd_t                  cmd,
                                                sx_tele_threshold_crossed_data_keys_t *data_p,
                                                uint32_t                               list_cnt);

sx_status_t sdk_tele_attributes_set(const sx_tele_attrib_t attr);

sx_status_t sdk_tele_attributes_get(sx_tele_attrib_t *attr_p);

sx_status_t sdk_tele_hash_sig_default_set(const sx_access_cmd_t                  cmd,
                                          const sx_tele_hash_sig_params_t       *hash_params_p,
                                          const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                          const uint32_t                         hash_field_enable_list_cnt,
                                          const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                          const uint32_t                         hash_field_list_cnt);

sx_status_t sdk_tele_hash_sig_default_get(sx_tele_hash_sig_params_t       *hash_params_p,
                                          sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                          uint32_t                        *hash_field_enable_list_cnt_p,
                                          sx_tele_hash_sig_field_t        *hash_field_list_p,
                                          uint32_t                        *hash_field_list_cnt_p);

sx_status_t sdk_tele_hash_sig_prof_set(const sx_access_cmd_t                  cmd,
                                       sx_tele_hash_sig_prof_t                hash_sig_prof_idx,
                                       sx_tele_hash_sig_classifier_attr_t    *hash_sig_prof_class_p,
                                       const sx_tele_hash_sig_params_t       *hash_params_p,
                                       const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                       const uint32_t                         hash_field_enable_list_cnt,
                                       const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                       const uint32_t                         hash_field_list_cnt);

sx_status_t sdk_tele_hash_sig_prof_get(sx_tele_hash_sig_prof_t             hash_sig_prof_idx,
                                       sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                       sx_tele_hash_sig_params_t          *hash_params_p,
                                       sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                       uint32_t                           *hash_field_enable_list_cnt_p,
                                       sx_tele_hash_sig_field_t           *hash_field_list_p,
                                       uint32_t                           *hash_field_list_cnt_p);

sx_status_t sdk_tele_tac_set(sx_access_cmd_t    cmd,
                             sx_trap_group_t    trap_group,
                             sx_tele_tac_cfg_t *tac_cfg_p);
sx_status_t sdk_tele_tac_get(sx_access_cmd_t    cmd,
                             sx_trap_group_t    trap_group,
                             sx_tele_tac_cfg_t *tac_cfg_p);
sx_status_t sdk_tele_tac_action_set(sx_access_cmd_t              cmd,
                                    sx_tele_tac_action_filter_t *tac_action_filter_p,
                                    sx_tele_tac_action_info_t   *tac_action_info_p);
sx_status_t sdk_tele_tac_action_status_get(sx_access_cmd_t              cmd,
                                           sx_tele_tac_action_status_e *tac_action_status_p);
sx_status_t sdk_tele_tac_stat_get(sx_access_cmd_t           cmd,
                                  sx_tele_tac_statistics_t *tac_stat_p);
sx_status_t sdk_tele_tac_oob_msg_send(sx_access_cmd_t             cmd,
                                      sx_tele_tac_oob_send_cfg_t *tac_msg_cfg_p);
sx_status_t sdk_tele_port_bw_gauge_set(const sx_access_cmd_t   cmd,
                                       sx_tele_gauge_config_t *gauge_config_p);

sx_status_t sdk_tele_port_bw_gauge_get(const sx_access_cmd_t   cmd,
                                       sx_tele_gauge_config_t *gauge_config_p);

sx_status_t sdk_tele_port_bw_gauge_data_get(const sx_access_cmd_t cmd,
                                            sx_tele_gauge_key_t  *gauge_key_p,
                                            sx_tele_gauge_data_t *gauge_data_p);

#endif      /* __HWI_TELE_BE_H__ */
