/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "tele_be.h"

#include <sx/sdk/sx_types.h>
#include <utils/sx_mem.h>
#include <utils/utils.h>
#include "ethl2/port_db.h"
#include "sx/sdk/sx_status.h"
#include "complib/sx_log.h"
#include "tele_impl.h"
#include "ethl2/brg.h"
#include "acl/flex_acl.h"

#undef  __MODULE__
#define __MODULE__ TELE

/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __verify_histogram_key(const sx_tele_histogram_key_t *key_p);
static sx_status_t __verify_histogram_attributes_data(const sx_tele_histogram_key_t             *key_p,
                                                      const sx_tele_histogram_attributes_data_t *data_p);

static sx_status_t __verify_port_bw_config_params(const sx_tele_gauge_config_t * gauge_config);
static sx_status_t __verify_port_bw_gauge_key(const sx_tele_gauge_key_t * gauge_key);

/************************************************
*  Function implementations
************************************************/
sx_status_t sdk_tele_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    sdk_tele_impl_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t sdk_tele_be_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(verbosity_level_p, "verbosity_level_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);
out:
    return status;
}

sx_status_t sdk_tele_init(const sx_tele_init_params_t *params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   initialised = FALSE;

    SX_LOG_ENTER();

    sdk_tele_impl_params_get(&initialised);

    if (utils_check_pointer(params_p, "params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tele_impl_init(params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize tele module, err = %s\n", sx_status_str(err));
        goto out;
    }

out:

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tele_impl_deinit(is_forced);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinitialize tele module, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    sdk_tele_impl_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

static sx_status_t __histogram_key_port_get(IN const sx_tele_histogram_key_t *key,
                                            OUT sx_port_log_id_t             *key_port)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (key->type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        *key_port = key->key.port_tc.log_port;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        *key_port = key->key.port_pg.log_port;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        *key_port = key->key.port_counter.log_port;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        *key_port = 0;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __verify_histogram_key(const sx_tele_histogram_key_t *key_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    uint32_t         port_type = SX_PORT_TYPE_INVALID;
    sx_port_log_id_t key_port = 0;

    SX_LOG_ENTER();

    /* Validate Port */
    err = __histogram_key_port_get(key_p, &key_port);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
        goto out;
    }
    port_type = SX_PORT_TYPE_ID_GET(key_port);

    switch (key_p->type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:

        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_PROFILE)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%08X) is of illegal type [%s]. Only NETWORK port allowed.\n",
                       key_port,
                       sx_port_type_str(port_type));
            goto out;
        }

        if ((key_p->key.port_pg.pg > rm_resource_global.cos_port_prio_max)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("PG [%u] > max traffic class [%u].\n",
                       key_p->key.port_pg.pg,
                       rm_resource_global.cos_port_prio_max);
            goto out;
        }
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
        switch (port_type) {
        case SX_PORT_TYPE_NETWORK:
        case SX_PORT_TYPE_PROFILE:
            if (key_p->key.port_tc.tc > rm_resource_global.cos_port_ets_traffic_class_max) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("TC [%u] > max allowed TC for network port [%u].\n",
                           key_p->key.port_tc.tc,
                           rm_resource_global.cos_port_ets_traffic_class_max);
                goto out;
            }
            break;

        case SX_PORT_TYPE_CPU:
            if (key_p->key.port_tc.tc > rm_resource_global.hw_cpu_ingress_tclass_max) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("TC [%u] > max allowed TC for CPU port [%u].\n",
                           key_p->key.port_tc.tc,
                           rm_resource_global.hw_cpu_ingress_tclass_max);
                goto out;
            }
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%08X) is of illegal type [%s]. Only NETWORK and CPU ports allowed.\n",
                       key_p->key.port_tc.log_port,
                       sx_port_type_str(SX_PORT_TYPE_ID_GET(key_p->key.port_tc.log_port)));
            goto out;
        }
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:

        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_PROFILE)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%08X) is of illegal type [%s]. Only NETWORK port allowed.\n",
                       key_port,
                       sx_port_type_str(port_type));
            goto out;
        }

        if ((key_p->key.port_tc.tc > rm_resource_global.cos_port_ets_traffic_class_max)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("PG [%u] > max traffic class [%u].\n",
                       key_p->key.port_tc.tc,
                       rm_resource_global.cos_port_ets_traffic_class_max);
            goto out;
        }
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:

        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_PROFILE)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%08X) is of illegal type [%s]. Only NETWORK port allowed.\n",
                       key_port,
                       sx_port_type_str(port_type));
            goto out;
        }

        if (!SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_ID_MIN_E, key_p->key.port_counter.histogram_id,
                            SX_TELE_HISTOGRAM_PORT_COUNTER_ID_MAX_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid histogram counter ID [%s].\n",
                       sx_tele_histogram_port_counter_id_str(key_p->key.port_counter.histogram_id));

            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Illegal histogram type [%s]\n", sx_tele_histogram_type_str(key_p->type));
        goto out;
        break;
    }


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __verify_port_bw_gauge_key(const sx_tele_gauge_key_t * gauge_key)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < gauge_key->port_cnt; i++) {
        if (SX_PORT_TYPE_ID_GET(gauge_key->port_list[i]) != SX_PORT_TYPE_NETWORK) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%08X) is of illegal type [%s]. Only NETWORK port allowed.\n",
                       gauge_key->port_list[i],
                       sx_port_type_str(SX_PORT_TYPE_ID_GET(gauge_key->port_list[i])));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __verify_port_bw_config_params(const sx_tele_gauge_config_t * gauge_config)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!SX_CHECK_MAX(gauge_config->log_time_interval,
                      TELE_HISTOGRAM_PORT_BW_GAUGE_MAX_LOG_TIME_INTERVAL)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Port BW gauge log time interval [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
            gauge_config->log_time_interval,
            TELE_HISTOGRAM_PORT_BW_GAUGE_MIN_LOG_TIME_INTERVAL,
            TELE_HISTOGRAM_PORT_BW_GAUGE_MAX_LOG_TIME_INTERVAL,
            sx_status_str(err));
        goto out;
    }

    if (!SX_CHECK_MAX(gauge_config->alpha_factor,
                      TELE_HISTOGRAM_PORT_BW_GAUGE_MAX_ALPHA_FACTOR)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Port BW gauge alpha factor [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
            gauge_config->alpha_factor,
            TELE_HISTOGRAM_PORT_BW_GAUGE_MIN_ALPHA_FACTOR,
            TELE_HISTOGRAM_PORT_BW_GAUGE_MAX_ALPHA_FACTOR,
            sx_status_str(err));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __verify_histogram_attributes_data(const sx_tele_histogram_key_t             *key_p,
                                                      const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    min_resolution = 0;
    uint32_t    max_resolution = 0;
    uint32_t    min_boundary_min = 0;
    uint32_t    histogram_calc_max = 0;
    boolean_t   is_valid = FALSE;

    SX_LOG_ENTER();

    switch (data_p->type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        if (data_p->data.queue_depth.sample_time_resolution >
            rm_resource_global.tele_histogram_sample_time_resolution_max) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Histogram sample time [%u] exceeds range. max sample time resolution [%u]. err = %s \n",
                       data_p->data.queue_depth.sample_time_resolution,
                       rm_resource_global.tele_histogram_sample_time_resolution_max,
                       sx_status_str(err));
            goto out;
        }

        if (data_p->data.queue_depth.mode == SX_TELE_HISTOGRAM_MODE_LINEAR_E) {
            max_resolution = rm_resource_global.tele_histogram_bin_size_resolution_queue_depth_linear_max;
        } else {
            max_resolution = rm_resource_global.tele_histogram_bin_size_resolution_queue_depth_exponent_max;
        }
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        err = sdk_tele_impl_latency_histogram_port_tc_validate(key_p, data_p, &is_valid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Latency histogram data validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
        if (is_valid == FALSE) {
            SX_LOG_ERR(
                "Latency histogram configuration is different than configuration on another TC of port = 0x%x.\n",
                key_p->key.port_tc.log_port);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (data_p->data.queue_depth.mode == SX_TELE_HISTOGRAM_MODE_LINEAR_E) {
            max_resolution = rm_resource_global.tele_histogram_bin_size_resolution_latency_linear_max;
        } else {
            max_resolution = rm_resource_global.tele_histogram_bin_size_resolution_latency_exponent_max;
        }
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        if (data_p->data.port_counter.sample_time_resolution >
            rm_resource_global.tele_histogram_sample_time_resolution_max) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Histogram sample time [%u] exceeds range. max sample time resolution [%u]. err = %s \n",
                       data_p->data.port_counter.sample_time_resolution,
                       rm_resource_global.tele_histogram_sample_time_resolution_max,
                       sx_status_str(err));
            goto out;
        }

        if (!SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_MIN_E, data_p->data.port_counter.control,
                            SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_MAX_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram port counter control [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
                data_p->data.port_counter.control,
                SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_MIN_E,
                SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_MAX_E,
                sx_status_str(err));
            goto out;
        }

        if (!SX_CHECK_RANGE(SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_MIN_E, data_p->data.port_counter.port_counter_type,
                            SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_MAX_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram port counter type  [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
                data_p->data.port_counter.port_counter_type,
                SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_MIN_E,
                SX_TELE_HISTOGRAM_PORT_COUNTER_TYPE_MAX_E,
                sx_status_str(err));
            goto out;
        }

        err = sdk_tele_impl_counter_histogram_type_validation(data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Histogram counter type validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }


        if (!SX_CHECK_RANGE(TELE_HISTOGRAM_PORT_COUNTER_MIN_BOUNDRY, data_p->data.port_counter.min_boundary,
                            TELE_HISTOGRAM_PORT_COUNTER_MAX_BOUNDRY)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram min boundary [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
                data_p->data.port_counter.min_boundary,
                TELE_HISTOGRAM_PORT_COUNTER_MIN_BOUNDRY,
                TELE_HISTOGRAM_PORT_COUNTER_MAX_BOUNDRY,
                sx_status_str(err));
            goto out;
        }

        if (!SX_CHECK_RANGE(TELE_HISTOGRAM_PORT_COUNTER_MIN_BOUNDRY, data_p->data.port_counter.bin_size_resolution,
                            TELE_HISTOGRAM_PORT_COUNTER_MAX_BIN_SIZE)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram bin size [%u] must be larger than [%u] and smaller than [%u]. err = %s \n",
                data_p->data.port_counter.bin_size_resolution,
                TELE_HISTOGRAM_PORT_COUNTER_MIN_BOUNDRY,
                TELE_HISTOGRAM_PORT_COUNTER_MAX_BOUNDRY,
                sx_status_str(err));
            goto out;
        }

        if (data_p->data.port_counter.repetition.number_of_repetitions >
            TELE_HISTOGRAM_PORT_COUNTER_MAX_REPETITION) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram repetition [%u] must be smaller  than [%u] . err = %s \n",
                data_p->data.port_counter.repetition.number_of_repetitions,
                TELE_HISTOGRAM_PORT_COUNTER_MAX_REPETITION,
                sx_status_str(err));
            goto out;
        }


        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Illegal histogram type [%s]\n", sx_tele_histogram_type_str(data_p->type));
        goto out;
    }

    if (data_p->type != SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
        if (data_p->data.queue_depth.mode == SX_TELE_HISTOGRAM_MODE_LINEAR_E) {
            min_resolution = rm_resource_global.tele_histogram_bin_size_resolution_linear_min;
            min_boundary_min = rm_resource_global.tele_histogram_min_boundary_min;
            histogram_calc_max = data_p->data.queue_depth.min_boundary +
                                 (8 * (1 << data_p->data.queue_depth.bin_size_resolution));
        } else {
            min_resolution = rm_resource_global.tele_histogram_bin_size_resolution_exponent_min;
            min_boundary_min = MAX(rm_resource_global.tele_histogram_min_boundary_min,
                                   (uint32_t)1 + (1 << data_p->data.queue_depth.bin_size_resolution));
            histogram_calc_max = data_p->data.queue_depth.min_boundary +
                                 (255 * (1 << data_p->data.queue_depth.bin_size_resolution));
        }

        if (!SX_CHECK_RANGE(min_resolution,
                            data_p->data.queue_depth.bin_size_resolution,
                            max_resolution)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram bin size resolution [%u] exceeds range. "
                "min value is [%u], max value is [%u], mode is %s. err = %s \n",
                data_p->data.queue_depth.bin_size_resolution,
                min_resolution,
                max_resolution,
                sx_tele_histogram_mode_str(data_p->data.queue_depth.mode),
                sx_status_str(err));
            goto out;
        }

        if (histogram_calc_max < data_p->data.queue_depth.min_boundary) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram max boundary [%u] is smaller than min boundary [%u]. Bin size resolution = %u. err = %s \n",
                histogram_calc_max,
                data_p->data.queue_depth.min_boundary,
                data_p->data.queue_depth.bin_size_resolution,
                sx_status_str(err));
            goto out;
        }

        if (!SX_CHECK_MIN(min_boundary_min, data_p->data.queue_depth.min_boundary)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram min boundary [%u] must be larger than min [%u]. err = %s \n",
                data_p->data.queue_depth.min_boundary,
                min_boundary_min,
                sx_status_str(err));
            goto out;
        }

        if (!SX_CHECK_MAX(histogram_calc_max,
                          TELE_HISTOGRAM_MAX_BOUNDRY)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Histogram min boundary [%u] and bin size resolution [%u] are combined to max boundary [%u] larger than allowed [%u]. err = %s \n",
                data_p->data.queue_depth.min_boundary,
                data_p->data.queue_depth.bin_size_resolution,
                rm_resource_global.tele_histogram_min_boundary_min,
                histogram_calc_max,
                sx_status_str(err));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_histogram_set(const sx_access_cmd_t                     cmd,
                                   const sx_tele_histogram_key_t             key,
                                   const sx_tele_histogram_attributes_data_t data)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    boolean_t        tele_initialised = FALSE;
    sx_port_log_id_t key_port = 0;


    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Histogram Set: Command [%s] is not supported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    /* Validate Port */
    err = __histogram_key_port_get(&key, &key_port);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
        goto out;
    }

    if ((SX_PORT_TYPE_ID_GET(key_port) == SX_PORT_TYPE_PROFILE) && (cmd != SX_ACCESS_CMD_SET)) {
        SX_LOG_ERR("Histogram Set: Command [%s] is not supported.\n, port profile support just Command [%s]",
                   sx_access_cmd_str(cmd), sx_access_cmd_str(SX_ACCESS_CMD_SET));
        goto out;
    }


    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_EDIT))
        && (key.type != data.type)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Histogram key type [%s] != data type [%s]. err = %s\n",
                   sx_tele_histogram_type_str(key.type),
                   sx_tele_histogram_type_str(data.type),
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_histogram_type_validation(&key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Histogram type validation failed, type = %s, err = %s.\n",
                   sx_tele_histogram_type_str(key.type),
                   sx_status_str(err));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_EDIT) && (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Latency histogram cannot be edited, use DELETE and CREATE commands. err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = __verify_histogram_key(&key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Histogram key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        err = __verify_histogram_attributes_data(&key, &data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Histogram attributes data validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tele_impl_histogram_set(cmd, key, data);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to set histogram, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_histogram_get(const sx_access_cmd_t                cmd,
                                   const sx_tele_histogram_key_t        key,
                                   sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_histogram_type_validation(&key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Histogram type validation failed, type = %s, err = %s.\n",
                   sx_tele_histogram_type_str(key.type),
                   sx_status_str(err));
        goto out;
    }

    err = __verify_histogram_key(&key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Histogram key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_histogram_get(cmd, key, data_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get histogram data, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_histogram_iter_get(const sx_access_cmd_t      cmd,
                                        sx_tele_histogram_key_t    hist_key,
                                        sx_tele_histogram_filter_t hist_filter,
                                        sx_tele_histogram_key_t   *hist_list_p,
                                        uint32_t                  *hist_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(hist_cnt_p, "hist_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_histogram_iter_get(cmd, hist_key, hist_filter, hist_list_p, hist_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get histogram data, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_histogram_data_get(const sx_access_cmd_t         cmd,
                                        const sx_tele_histogram_key_t key,
                                        sx_tele_histogram_data_t     *histogram_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(histogram_p, "histogram_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_histogram_data_get(cmd, key, histogram_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get histogram data, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_threshold_set(const sx_access_cmd_t          cmd,
                                   const sx_tele_threshold_key_t  key,
                                   const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = tele_impl_threshold_key_validation(key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_EDIT)) {
        err = tele_impl_threshold_data_validation(key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("threshold data validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        err = sdk_tele_impl_threshold_set(cmd, key, data);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to set telemetry threshold, err: %s\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    case SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E:
        err = sdk_tele_impl_latency_threshold_set(cmd, key, data);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to set latency threshold. [%s]\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold key type [%s] is invalid. err = %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_threshold_get(const sx_access_cmd_t         cmd,
                                   const sx_tele_threshold_key_t key,
                                   sx_tele_threshold_data_t     *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }
    err = tele_impl_threshold_key_validation(key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        err = sdk_tele_impl_threshold_get(cmd, key, data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get threshold data, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E:
        err = sdk_tele_impl_latency_threshold_get(key, data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get latency threshold data. [%s]\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold key type [%s] is invalid. err = %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_threshold_iter_get(const sx_access_cmd_t      cmd,
                                        sx_tele_threshold_key_t    key,
                                        sx_tele_threshold_filter_t filter,
                                        sx_tele_threshold_key_t   *key_list_p,
                                        uint32_t                  *key_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(key_cnt_p, "key_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    if ((*key_cnt_p > 0) && (cmd != SX_ACCESS_CMD_GET_FIRST)) {
        err = tele_impl_threshold_key_validation(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        err = sdk_tele_impl_threshold_iter_get(cmd, key, filter, key_list_p, key_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get threshold data, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold key type [%s] is invalid. err = %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_threshold_crossed_data_get(const sx_access_cmd_t                  cmd,
                                                sx_tele_threshold_crossed_data_keys_t *data_p,
                                                uint32_t                               list_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    for (i = 0; i < list_cnt; i++) {
        switch (data_p[i].key.key_type) {
        case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
        case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
            err = tele_impl_threshold_key_validation(data_p[i].key);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                           sx_status_str(err));
                goto out;
            }
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Threshold key type [%s] is invalid. err = %s\n",
                       sx_tele_threshold_type_str(data_p[i].key.key_type),
                       sx_status_str(err));
            goto out;
        }
    }
    err = sdk_tele_impl_threshold_crossed_data_get(cmd, data_p, list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get threshold data, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_attributes_set(const sx_tele_attrib_t attr)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_attributes_set(attr, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set telemetry attributes, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_attributes_get(sx_tele_attrib_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_attributes_get(attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get telemetry attributes, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t __sdk_tele_hash_sig_prof_set(const sx_access_cmd_t                  cmd,
                                         sx_tele_hash_sig_prof_idx_int_t        hash_sig_prof_idx,
                                         sx_tele_hash_sig_classifier_attr_t    *hash_sig_prof_class_p,
                                         const sx_tele_hash_sig_params_t       *hash_params_p,
                                         const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                         const uint32_t                         hash_field_enable_list_cnt,
                                         const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                         const uint32_t                         hash_field_list_cnt)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    uint32_t          field_idx, i;
    sx_register_key_t reg_key;
    boolean_t         is_allocated = FALSE;
    sx_port_info_t    port_info;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_ADD)
        && (cmd != SX_ACCESS_CMD_DELETE)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "sdk_tele_hash_sig_prof_set failed: "
               "CMD %s is not supported.\n",
               sx_access_cmd_str(cmd));
        goto out;
    }

    if (NULL == hash_field_enable_list_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "sdk_tele_hash_sig_prof_set, hash_field_enable_list_p is NULL\n");
        goto out;
    }

    if (NULL == hash_field_list_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "sdk_tele_hash_sig_prof_set, hash_field_list_p is NULL\n");
        goto out;
    }

    SX_LOG_DBG("sdk_tele_hash_sig_prof_set cmd: %s\n",
               sx_access_cmd_str(cmd));

    if ((SX_ACCESS_CMD_SET == cmd) && (NULL == hash_params_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_DEBUG,
               "sdk_tele_hash_sig_prof_set, hash_params_p is NULL\n");
        goto out;
    }

    if (hash_field_enable_list_cnt > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "sdk_tele_hash_sig_prof_set: "
               "hash_field_enable_list_cnt [%u] exceeds max number of fields [%u].\n",
               hash_field_enable_list_cnt, SX_LAG_HASH_FIELD_ENABLES_NUM);
        goto out;
    }

    for (field_idx = 0; field_idx < hash_field_enable_list_cnt; field_idx++) {
        if (FALSE == SX_TELE_HASH_SIG_FIELD_ENABLE_CHECK_RANGE(
                hash_field_enable_list_p[field_idx])) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "sdk_tele_hash_sig_prof_set: "
                   "hash field enable [%u] exceeds range.\n",
                   hash_field_enable_list_p[field_idx]);
            goto out;
        }
    }

    if (hash_field_list_cnt > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "sdk_tele_hash_sig_prof_set: "
               "hash_field_list_cnt [%u] exceeds max number of fields [%u].\n",
               hash_field_list_cnt, SX_LAG_HASH_FIELDS_NUM);
        goto out;
    }

    for (field_idx = 0; field_idx < hash_field_list_cnt; field_idx++) {
        if (FALSE == SX_TELE_HASH_SIG_FIELD_CHECK_RANGE(
                hash_field_list_p[field_idx])) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "sdk_tele_hash_sig_prof_set: "
                   "hash field [%u] exceeds range.\n",
                   hash_field_list_p[field_idx]);
            goto out;
        }

        if ((hash_field_list_p[field_idx] >= SX_TELE_HASH_SIG_GENERAL_FIELDS_CUSTOM_BYTE_0) &&
            (hash_field_list_p[field_idx] <= SX_TELE_HASH_SIG_GENERAL_FIELDS_CUSTOM_BYTE_LAST)) {
            err = flex_acl_keys_custom_byte_id_is_valid(
                (sx_acl_key_t)(hash_field_list_p[field_idx]));
            if (SX_CHECK_FAIL(err)) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG(SX_LOG_ERROR, "Custom byte ID [%d] is not valid\n",
                       hash_field_list_p[field_idx]);
                goto out;
            }
        }

        if (SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(hash_field_list_p[field_idx])) {
            SX_MEM_CLR(reg_key);
            reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
            reg_key.key.gp_reg.reg_id = SX_TELE_HASH_SIG_FIELD_GP_REGISTER_GET(hash_field_list_p[field_idx]);
            err = sdk_register_impl_is_allocated(reg_key, &is_allocated);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }

            if (is_allocated == FALSE) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG(SX_LOG_ERROR, "GP register ID [%d] is not allocated.\n",
                       reg_key.key.gp_reg.reg_id);
                goto out;
            }
        }
    }

    if (hash_sig_prof_class_p != NULL) {
        for (i = 0; i < hash_sig_prof_class_p->ports_classifiers.port_cnt; i++) {
            if ((SX_PORT_TYPE_ID_GET(hash_sig_prof_class_p->ports_classifiers.port_list[i])
                 != SX_PORT_TYPE_NETWORK)) {
                err = SX_STATUS_UNSUPPORTED;
                SX_LOG(SX_LOG_ERROR, "Port [0x%08X] type isn't supported. Only network port is supported. (%s).\n",
                       hash_sig_prof_class_p->ports_classifiers.port_list[i],
                       sx_status_str(err));
                goto out;
            }

            err = port_db_info_get(hash_sig_prof_class_p->ports_classifiers.port_list[i],
                                   &port_info);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG(SX_LOG_ERROR, "Can't Get Port [0x%08X] Info (%s).\n",
                       hash_sig_prof_class_p->ports_classifiers.port_list[i],
                       sx_status_str(err));
                goto out;
            }
        }
    }

    err = sdk_tele_impl_hash_sig_prof_set(cmd,
                                          hash_sig_prof_idx,
                                          hash_sig_prof_class_p,
                                          hash_params_p,
                                          hash_field_enable_list_p,
                                          hash_field_enable_list_cnt,
                                          hash_field_list_p,
                                          hash_field_list_cnt);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "sdk_tele_impl_hash_sig_prof_set failed. "
               "rc: %s.\n",
               sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tele_hash_sig_prof_get(sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                         sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                         sx_tele_hash_sig_params_t          *hash_params_p,
                                         sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                         uint32_t                           *hash_field_enable_list_cnt_p,
                                         sx_tele_hash_sig_field_t           *hash_field_list_p,
                                         uint32_t                           *hash_field_list_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((*hash_field_enable_list_cnt_p > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "__sdk_tele_hash_sig_prof_get: NULL == hash_field_enable_list_p, while *hash_field_enable_list_cnt_p = %d\n",
               *hash_field_enable_list_cnt_p);
        goto out;
    }

    if ((*hash_field_list_cnt_p > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR,
               "__sdk_tele_hash_sig_prof_get: NULL == hash_field_list_p, while *hash_field_list_cnt_p = %d\n",
               *hash_field_list_cnt_p);
        goto out;
    }

    if (*hash_field_enable_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "__sdk_tele_hash_sig_prof_get: "
               "hash_field_enable_list_cnt [%u] exceeds max number of fields [%u].\n",
               *hash_field_enable_list_cnt_p, SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);
        goto out;
    }

    if (*hash_field_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "__sdk_tele_hash_sig_prof_get: "
               "hash_field_list_cnt [%u] exceeds max number of fields [%u].\n",
               *hash_field_list_cnt_p, SX_TELE_HASH_SIG_FIELDS_NUM);
        goto out;
    }

    err = sdk_tele_db_hash_sig_params_get(hash_sig_prof_idx, hash_sig_prof_class_p, hash_params_p,
                                          hash_field_enable_list_p, hash_field_enable_list_cnt_p,
                                          hash_field_list_p, hash_field_list_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to get hash params of profile [%d]."
               " sdk_tele_db_hash_sig_params_get failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_hash_sig_default_set(const sx_access_cmd_t                  cmd,
                                          const sx_tele_hash_sig_params_t       *hash_params_p,
                                          const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                          const uint32_t                         hash_field_enable_list_cnt,
                                          const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                          const uint32_t                         hash_field_list_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised, is_hash_sig_supported;

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_is_hash_sig_supported(&is_hash_sig_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_hash_sig_supported == FALSE) {
        SX_LOG_ERR("Signature Hash isn't supported on this system.\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_set(cmd,
                                       SX_TELE_HASH_SIG_PROF_DEFAULT,
                                       NULL,
                                       hash_params_p,
                                       hash_field_enable_list_p,
                                       hash_field_enable_list_cnt,
                                       hash_field_list_p,
                                       hash_field_list_cnt);

out:
    return err;
}

sx_status_t sdk_tele_hash_sig_default_get(sx_tele_hash_sig_params_t       *hash_params_p,
                                          sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                          uint32_t                        *hash_field_enable_list_cnt_p,
                                          sx_tele_hash_sig_field_t        *hash_field_list_p,
                                          uint32_t                        *hash_field_list_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised, is_hash_sig_supported;

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_is_hash_sig_supported(&is_hash_sig_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_hash_sig_supported == FALSE) {
        SX_LOG_ERR("Signature Hash isn't supported on this system.\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_get(SX_TELE_HASH_SIG_PROF_DEFAULT,
                                       NULL,
                                       hash_params_p,
                                       hash_field_enable_list_p,
                                       hash_field_enable_list_cnt_p,
                                       hash_field_list_p,
                                       hash_field_list_cnt_p);
out:
    return err;
}

static sx_status_t __sdk_tele_hash_sig_prof_get_internal_idx(sx_tele_hash_sig_prof_t          hash_sig_prof_idx,
                                                             sx_tele_hash_sig_prof_idx_int_t *hash_sig_prof_internal_idx_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (hash_sig_prof_internal_idx_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (hash_sig_prof_idx.prof_index) {
    case SX_TELE_HASH_SIG_PROF0:
        *hash_sig_prof_internal_idx_p = SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_0_E;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR,
               "hash sig profile [%d] is out of range. err: [%s]\n",
               hash_sig_prof_idx.prof_index, sx_status_str(err));
        goto out;
    }

out:
    return err;
}
sx_status_t sdk_tele_hash_sig_prof_set(const sx_access_cmd_t                  cmd,
                                       sx_tele_hash_sig_prof_t                hash_sig_prof_idx,
                                       sx_tele_hash_sig_classifier_attr_t    *hash_sig_prof_class_p,
                                       const sx_tele_hash_sig_params_t       *hash_params_p,
                                       const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                       const uint32_t                         hash_field_enable_list_cnt,
                                       const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                       const uint32_t                         hash_field_list_cnt)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_tele_hash_sig_prof_idx_int_t hash_sig_prof_internal_idx;
    boolean_t                       tele_initialised, is_hash_sig_supported;

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_is_hash_sig_supported(&is_hash_sig_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_hash_sig_supported == FALSE) {
        SX_LOG_ERR("Signature Hash isn't supported on this system.\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_get_internal_idx(hash_sig_prof_idx,
                                                    &hash_sig_prof_internal_idx);
    if (err) {
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_set(cmd,
                                       hash_sig_prof_internal_idx,
                                       hash_sig_prof_class_p,
                                       hash_params_p,
                                       hash_field_enable_list_p,
                                       hash_field_enable_list_cnt,
                                       hash_field_list_p,
                                       hash_field_list_cnt);
out:
    return err;
}

sx_status_t sdk_tele_hash_sig_prof_get(sx_tele_hash_sig_prof_t             hash_sig_prof_idx,
                                       sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                       sx_tele_hash_sig_params_t          *hash_params_p,
                                       sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                       uint32_t                           *hash_field_enable_list_cnt_p,
                                       sx_tele_hash_sig_field_t           *hash_field_list_p,
                                       uint32_t                           *hash_field_list_cnt_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_tele_hash_sig_prof_idx_int_t hash_sig_prof_internal_idx;
    boolean_t                       tele_initialised, is_hash_sig_supported;

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_is_hash_sig_supported(&is_hash_sig_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_hash_sig_supported == FALSE) {
        SX_LOG_ERR("Signature Hash isn't supported on this system.\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_get_internal_idx(hash_sig_prof_idx,
                                                    &hash_sig_prof_internal_idx);
    if (err) {
        goto out;
    }

    err = __sdk_tele_hash_sig_prof_get(hash_sig_prof_internal_idx,
                                       hash_sig_prof_class_p,
                                       hash_params_p,
                                       hash_field_enable_list_p,
                                       hash_field_enable_list_cnt_p,
                                       hash_field_list_p,
                                       hash_field_list_cnt_p);
out:
    return err;
}

sx_status_t sdk_tele_impl_is_tac_enabled(boolean_t *tele_tac_enabled_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    boolean_t        tele_initialised;
    sx_tele_attrib_t attr;

    *tele_tac_enabled_p = FALSE;

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    /* tele module tac attr mode isn't disable */
    err = sdk_tele_impl_attributes_get(&attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_attributes_get failed, err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    if (attr.tac_attr.tac_mode == SX_TELE_TAC_MODE_DISABLE_E) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("TELE module attr TAC mode is disabled, err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    *tele_tac_enabled_p = TRUE;

out:
    return err;
}

sx_status_t sdk_tele_tac_set(sx_access_cmd_t cmd, sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_enabled;

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_enabled);
    if (!tele_tac_enabled) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_set(cmd, trap_group, tac_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_set failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_tac_get(sx_access_cmd_t cmd, sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_enabled;

    UNUSED_PARAM(cmd);

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_enabled);
    if (!tele_tac_enabled) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module TAC is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_get(trap_group, tac_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_INF("sdk_tele_impl_tac_get failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_tac_action_set(sx_access_cmd_t              cmd,
                                    sx_tele_tac_action_filter_t *tac_action_filter_p,
                                    sx_tele_tac_action_info_t   *tac_action_info_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_enabled;

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_enabled);
    if (!tele_tac_enabled) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module TAC is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_action_set(cmd, tac_action_filter_p, tac_action_info_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_action_set failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_tac_action_status_get(sx_access_cmd_t cmd, sx_tele_tac_action_status_e *tac_action_status_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_initialised;

    UNUSED_PARAM(cmd);

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_initialised);
    if (!tele_tac_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module TAC is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_action_get(tac_action_status_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_action_status_get failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_tac_stat_get(sx_access_cmd_t cmd, sx_tele_tac_statistics_t *tac_stat_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_enabled;

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_enabled);
    if (!tele_tac_enabled) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module TAC is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_statistics_get(cmd, tac_stat_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_statistics_get failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_tac_oob_msg_send(sx_access_cmd_t cmd, sx_tele_tac_oob_send_cfg_t *tac_msg_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_tac_enabled;

    SX_LOG_ENTER();

    sdk_tele_impl_is_tac_enabled(&tele_tac_enabled);
    if (!tele_tac_enabled) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module TAC is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_tac_oob_msg_send(cmd, tac_msg_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_oob_msg_send failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_port_bw_gauge_set(const sx_access_cmd_t cmd, sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port bw gauge set: Command [%s] is not supported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }


    if (cmd != SX_ACCESS_CMD_DESTROY) {
        if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = __verify_port_bw_config_params(gauge_config_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Port BW gauge configuration validation failed, err = %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tele_impl_port_bw_gauge_set(cmd, gauge_config_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to set port BW gauge configuration, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_port_bw_gauge_get(const sx_access_cmd_t cmd, sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = sdk_tele_impl_port_bw_gauge_get(gauge_config_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to get port BW gauge configuration, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_port_bw_gauge_data_get(const sx_access_cmd_t cmd,
                                            sx_tele_gauge_key_t  *gauge_key_p,
                                            sx_tele_gauge_data_t *gauge_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tele_initialised = FALSE;

    if (utils_check_pointer(gauge_data_p, "gauge_data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(gauge_key_p, "gauge_key_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }


    sdk_tele_impl_params_get(&tele_initialised);
    if (!tele_initialised) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tele module is uninitialized.\n");
        goto out;
    }

    err = __verify_port_bw_gauge_key(gauge_key_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Port BW gauge key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_port_bw_gauge_data_get(gauge_key_p, gauge_data_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to get port BW gauge data, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

    goto out;


out:
    SX_LOG_EXIT();
    return err;
}
