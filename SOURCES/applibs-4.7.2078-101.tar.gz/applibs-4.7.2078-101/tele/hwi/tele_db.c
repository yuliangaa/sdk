/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/sdk_refcount.h>
#include <sx/sdk/sx_status_convertor.h>
#include <utils/utils.h>

#include "ethl2/fdb.h"
#include "tele_db.h"
#include "tele_impl.h"
#include "ethl2/lag.h"
#include "register/hwi/register_impl.h"
#include "acl/flex_acl.h"

#undef  __MODULE__
#define __MODULE__ TELE_DB

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t                                    histogram_pool;
static cl_qpool_t                                    threshold_pool;
static cl_qmap_t                                     histogram_map;
static cl_qmap_t                                     threshold_map;
static cl_qmap_t                                     g_last_congestion_threshold_map;
static cl_qlist_t                                    histogram_free_id_list;
static tele_id_item_t                              * histogram_id_item_s = NULL;
static cl_qpool_t                                    g_latency_threshold_key_pool;
static cl_qmap_t                                     g_latency_threshold_key_map;
static cl_qpool_t                                    g_latency_threshold_data_pool;
static cl_qmap_t                                     g_latency_threshold_data_map;
static uint8_t                                       g_latency_threshold_id_cnt_s = 0;
static boolean_t                                     g_latency_threshold_key_initialized = FALSE;
static boolean_t                                     g_latency_threshold_data_initialized = FALSE;
static tele_db_histogram_port_latency_config_data_t *g_latency_histogram_port_tcs_config_p = NULL;
static tele_db_gauge_config_t                        g_gauge_config =
{ DEFAULT_LOG_TIME_ITNERVAL, DEFAULT_ALPHA_FACTOR };

/**
 * hash db params
 */

typedef struct sdk_tele_db_hash_sig_params {
    sx_tele_hash_sig_classifier_attr_t hash_sig_prof_classifier;
    sx_tele_hash_sig_params_t          hash_params;
    sx_tele_hash_sig_field_enable_t    enables[SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM];
    uint32_t                           enables_cnt;
    sx_tele_hash_sig_field_t           fields[SX_TELE_HASH_SIG_FIELDS_NUM];
    uint32_t                           fields_cnt;
    sdk_ref_t                          ref[SX_TELE_HASH_SIG_GP_REGISTER_FIELDS_NUM];
} sdk_tele_db_hash_sig_params_t;

sdk_tele_db_hash_sig_params_t g_sdk_tele_db_hash_sig[SX_TELE_HASH_SIG_PROF_INTERNAL_MAX + 1];

/**
 * TAC DB
 */
typedef struct sdk_tele_db_tac_params {
    sx_tele_tac_sw_header_info_t sw_header_info;
    cl_qpool_t                   tac_trap_group_map_pool;
    cl_qmap_t                    tac_trap_group_map;
} sdk_tele_db_tac_params_t;

boolean_t                g_tele_tac_db_initialized = FALSE;
sdk_tele_db_tac_params_t g_tele_tac_db;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __tele_db_last_congestion_threshold_build_key(const sx_tele_threshold_key_t *tele_key,
                                                                 uint64_t                      *key);
static sx_status_t __tele_db_last_congestion_threshold_lookup(const sx_tele_threshold_key_t              *tele_key_p,
                                                              tele_db_last_congestion_threshold_entry_t **entry_pp);
static sx_status_t __sdk_tele_db_last_congestion_threshold_allocate_entry(
    const sx_tele_threshold_key_t              *key_p,
    tele_db_last_congestion_threshold_entry_t **entry_pp);
static sx_status_t __sdk_tele_db_last_congestion_threshold_free_entry(
    tele_db_last_congestion_threshold_entry_t *entry_p);
static sx_status_t __sdk_tele_db_last_congestion_threshold_add(const sx_tele_threshold_key_t  *key_p,
                                                               const sx_tele_threshold_data_t *data_p);
static sx_status_t __sdk_tele_db_last_congestion_threshold_modify(const sx_access_cmd_t           cmd,
                                                                  const sx_tele_threshold_key_t  *key_p,
                                                                  const sx_tele_threshold_data_t *data_p);
static sx_status_t __sdk_tele_db_last_congestion_threshold_delete(const sx_tele_threshold_key_t *key_p);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sdk_tele_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

cl_status_t __latency_threshold_data_pool_init(void * const            p_object,
                                               void                  * context_p,
                                               cl_pool_item_t ** const pp_pool_item_p)
{
    tele_db_latency_threshold_data_entry_t * entry_p = (tele_db_latency_threshold_data_entry_t*)p_object;

    UNUSED_PARAM(context_p);

    entry_p->latency_id = --g_latency_threshold_id_cnt_s;
    *pp_pool_item_p = &(entry_p->pool_item);

    return CL_SUCCESS;
}

sx_status_t sdk_tele_db_init(const uint32_t histogram_max_count,
                             const uint32_t threshold_max_count,
                             const uint32_t latency_threshold_key_count,
                             const uint32_t latency_threshold_data_count)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   initialised = FALSE;
    uint32_t    i = 0;
    cl_status_t cl_status = CL_SUCCESS;
    boolean_t   free_id_insert = FALSE;
    boolean_t   histogram_initialized = FALSE;
    boolean_t   threshold_initialized = FALSE;

    SX_LOG_ENTER();
    sdk_tele_impl_params_get(&initialised);

    if (TRUE == initialised) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Tele module is already initialized\n");
        goto out;
    }

    if (histogram_max_count > rm_resource_global_default.tele_histogram_num_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("DB can't allocate more histograms (%d) than supported(%d)\n",
                   histogram_max_count,
                   rm_resource_global_default.tele_histogram_num_max);
        goto out;
    }

    /* Allocate a list of the free histogram ids. */
    err = utils_clr_memory_get((void**)(&histogram_id_item_s),
                               histogram_max_count, sizeof(tele_id_item_t),
                               UTILS_MEM_TYPE_ID_TELEMETRY_E);

    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the telegram ids list\n");
        goto out;
    }

    cl_qlist_init(&histogram_free_id_list);

    for (i = 0; i < histogram_max_count; i++) {
        histogram_id_item_s[i].tele_id = i;
        cl_qlist_insert_tail(&histogram_free_id_list, &histogram_id_item_s[i].list_item);
    }
    free_id_insert = TRUE;

    cl_status = CL_QPOOL_INIT(&histogram_pool, histogram_max_count, histogram_max_count, 0,
                              sizeof(tele_db_histogram_entry_t), NULL, NULL, NULL);

    histogram_initialized = TRUE;

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate histogram pool.\n");
        goto out;
    }

    cl_qmap_init(&histogram_map);

    /* Latency histograms - the configuration must be homogeneous for all TCs per port */
    err = utils_clr_memory_get((void**)(&g_latency_histogram_port_tcs_config_p),
                               rm_resource_global.port_ext_num_max + PORT_PROFILE_NUM_MAX,
                               sizeof(tele_db_histogram_port_latency_config_data_t),
                               UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the latency histogram port TCs configuration\n");
        goto out;
    }

    cl_status = CL_QPOOL_INIT(&threshold_pool, threshold_max_count, threshold_max_count, 0,
                              sizeof(tele_db_threshold_entry_t), NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate threshold pool.\n");
        goto out;
    }

    threshold_initialized = TRUE;
    cl_qmap_init(&g_last_congestion_threshold_map);
    cl_qmap_init(&threshold_map);

    /* Latency threshold */
    g_latency_threshold_id_cnt_s = latency_threshold_data_count;
    cl_qmap_init(&g_latency_threshold_key_map);
    cl_qmap_init(&g_latency_threshold_data_map);

    if (latency_threshold_data_count == 0) {
        goto out;
    }

    /* Init latency threshold key DB */
    cl_status = CL_QPOOL_INIT(&g_latency_threshold_key_pool, latency_threshold_key_count,
                              latency_threshold_key_count, 0,
                              sizeof(tele_db_latency_threshold_key_entry_t), NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate latency threshold key pool.\n");
        goto out;
    }
    g_latency_threshold_key_initialized = TRUE;

    /* Init latency threshold data DB */
    cl_status = CL_QPOOL_INIT(&g_latency_threshold_data_pool, latency_threshold_data_count,
                              latency_threshold_data_count, 0,
                              sizeof(tele_db_latency_threshold_data_entry_t),
                              __latency_threshold_data_pool_init, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate latency threshold data pool.\n");
        goto out;
    }
    g_latency_threshold_data_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (histogram_initialized) {
            CL_QPOOL_DESTROY(&histogram_pool);
            if (TRUE == free_id_insert) {
                for (i = 0; i < histogram_max_count; i++) {
                    cl_qlist_remove_head(&histogram_free_id_list);
                }
            }
        }
        if (threshold_initialized) {
            CL_QPOOL_DESTROY(&threshold_pool);
        }

        if (NULL != histogram_id_item_s) {
            utils_memory_put(histogram_id_item_s, UTILS_MEM_TYPE_ID_TELEMETRY_E);
            histogram_id_item_s = NULL;
        }

        if (g_latency_threshold_key_initialized) {
            CL_QPOOL_DESTROY(&g_latency_threshold_key_pool);
        }

        if (g_latency_threshold_data_initialized) {
            CL_QPOOL_DESTROY(&g_latency_threshold_data_pool);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_deinit(boolean_t is_forced)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    boolean_t                                  initialised = FALSE;
    tele_db_histogram_entry_t                 *histogram_entry_p = NULL;
    tele_db_threshold_entry_t                 *threshold_entry_p = NULL;
    tele_db_latency_threshold_key_entry_t     *key_entry_p = NULL;
    tele_db_latency_threshold_data_entry_t    *data_entry_p = NULL;
    cl_map_item_t                             *map_item_p = NULL;
    cl_map_item_t                             *next_map_item_p = NULL;
    const cl_map_item_t                       *map_end_p = NULL;
    tele_db_last_congestion_threshold_entry_t *entry_p = NULL;

    SX_LOG_ENTER();

    sdk_tele_impl_params_get(&initialised);
    if (FALSE == initialised) {
        if (FALSE == is_forced) {
            err = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("Tele module is not initialised.\n");
        }
        /* return success on force deinit if not initialized */
        goto out;
    }

    /* Clear tele DB */
    map_item_p = cl_qmap_head(&histogram_map);
    map_end_p = cl_qmap_end(&histogram_map);
    if ((FALSE == is_forced) && (map_item_p != map_end_p)) {
        err = SX_STATUS_DB_NOT_EMPTY;
        SX_LOG_ERR("Failed to delete DB, there are still histogram entries allocated in map\n");
        goto out;
    }

    while (map_item_p != map_end_p) {
        histogram_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        if (histogram_entry_p->data.list_item != NULL) {
            cl_qmap_remove_item(&histogram_map, &histogram_entry_p->map_item);
            cl_qlist_insert_head(&histogram_free_id_list, histogram_entry_p->data.list_item);
            cl_qpool_put(&histogram_pool, &histogram_entry_p->pool_item);
        }
    }

    CL_QPOOL_DESTROY(&histogram_pool);
    cl_qlist_remove_all(&histogram_free_id_list);
    if (NULL != histogram_id_item_s) {
        err = utils_memory_put(histogram_id_item_s, UTILS_MEM_TYPE_ID_TELEMETRY_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to free histogram ID list (telemetry DB), err = %s\n",
                       sx_status_str(err));
            goto out;
        }
    }
    histogram_id_item_s = NULL;

    if (NULL != g_latency_histogram_port_tcs_config_p) {
        err = utils_memory_put(g_latency_histogram_port_tcs_config_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to free latency histogram port TCs configuration, err = %s\n",
                       sx_status_str(err));
            goto out;
        }
    }
    g_latency_histogram_port_tcs_config_p = NULL;

    map_item_p = cl_qmap_head(&threshold_map);
    map_end_p = cl_qmap_end(&threshold_map);
    if ((FALSE == is_forced) && (map_item_p != map_end_p)) {
        err = SX_STATUS_DB_NOT_EMPTY;
        SX_LOG_ERR("Failed to delete DB, there are still thresholds allocated\n");
        goto out;
    }

    while (map_item_p != map_end_p) {
        threshold_entry_p = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        cl_qmap_remove_item(&threshold_map, &threshold_entry_p->map_item);
        cl_qpool_put(&threshold_pool, &threshold_entry_p->pool_item);
    }

    CL_QPOOL_DESTROY(&threshold_pool);

    /* De-init latency threshold key DB */
    if (g_latency_threshold_key_initialized) {
        map_item_p = cl_qmap_head(&g_latency_threshold_key_map);
        map_end_p = cl_qmap_end(&g_latency_threshold_key_map);
        if ((FALSE == is_forced) && (map_item_p != map_end_p)) {
            err = SX_STATUS_DB_NOT_EMPTY;
            SX_LOG_ERR("Failed to delete DB, there are still latency thresholds key allocated\n");
            goto out;
        }

        while (map_item_p != map_end_p) {
            key_entry_p = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_key_entry_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);
            cl_qmap_remove_item(&g_latency_threshold_key_map, &key_entry_p->map_item);
            cl_qpool_put(&g_latency_threshold_key_pool, &key_entry_p->pool_item);
        }
        CL_QPOOL_DESTROY(&g_latency_threshold_key_pool);
    }

    /* De-init latency threshold data DB */
    if (g_latency_threshold_data_initialized) {
        map_item_p = cl_qmap_head(&g_latency_threshold_data_map);
        map_end_p = cl_qmap_end(&g_latency_threshold_data_map);
        if ((FALSE == is_forced) && (map_item_p != map_end_p)) {
            err = SX_STATUS_DB_NOT_EMPTY;
            SX_LOG_ERR("Failed to delete DB, there are still latency thresholds data allocated\n");
            goto out;
        }

        while (map_item_p != map_end_p) {
            data_entry_p = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_data_entry_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);
            cl_qmap_remove_item(&g_latency_threshold_data_map, &data_entry_p->map_item);
            cl_qpool_put(&g_latency_threshold_data_pool, &data_entry_p->pool_item);
        }
        CL_QPOOL_DESTROY(&g_latency_threshold_data_pool);
    }

    map_item_p = cl_qmap_head(&g_last_congestion_threshold_map);
    map_end_p = cl_qmap_end(&g_last_congestion_threshold_map);
    while (map_item_p != map_end_p) {
        next_map_item_p = cl_qmap_next(map_item_p);
        cl_qmap_remove_item(&g_last_congestion_threshold_map, map_item_p);
        entry_p = PARENT_STRUCT(map_item_p, tele_db_last_congestion_threshold_entry_t, map_item);
        err = utils_memory_put(entry_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("utils_memory_put failed, err = %s\n",
                       sx_status_str(err));
            goto out;
        }
        map_item_p = next_map_item_p;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_db_histogram_build_key(const sx_tele_histogram_key_t *tele_key, uint64_t *key)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (tele_key->type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
        *key = BUILD_HISTOGRAM_KEY(tele_key->key.port_tc.log_port,
                                   tele_key->key.port_tc.tc,
                                   SX_TELE_HISTOGRAM_DIRECTION_EGRESS,
                                   SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH);
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        *key = BUILD_HISTOGRAM_KEY(tele_key->key.port_pg.log_port,
                                   tele_key->key.port_pg.pg,
                                   SX_TELE_HISTOGRAM_DIRECTION_INGRESS,
                                   SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH);
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        *key = BUILD_HISTOGRAM_KEY(tele_key->key.port_tc.log_port,
                                   tele_key->key.port_tc.tc,
                                   SX_TELE_HISTOGRAM_DIRECTION_EGRESS,
                                   SX_TELE_HISTOGRAM_TYPE_ID_LATENCY);
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        *key = BUILD_HISTOGRAM_KEY(tele_key->key.port_counter.log_port,
                                   tele_key->key.port_counter.histogram_id,
                                   SX_TELE_HISTOGRAM_DIRECTION_EGRESS,
                                   SX_TELE_HISTOGRAM_TYPE_ID_COUNTER);
        break;

    default:
        SX_LOG_ERR("Unknown histogram type %d\n", tele_key->type);
        *key = 0;
        err = SX_STATUS_PARAM_ERROR;
    }

    SX_LOG_EXIT();
    return err;
}

static void __tele_db_histogram_lookup(const sx_tele_histogram_key_t *tele_key, tele_db_histogram_entry_t **entry_pp)
{
    cl_map_item_t *map_item_p = NULL;
    uint64_t       map_key = 0;

    __tele_db_histogram_build_key(tele_key, &map_key);

    map_item_p = cl_qmap_get(&histogram_map, map_key);
    if (map_item_p == cl_qmap_end(&histogram_map)) {
        *entry_pp = NULL;
        return;
    }

    *entry_pp = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
}

static sx_status_t __tele_db_last_congestion_threshold_build_key(const sx_tele_threshold_key_t *tele_key,
                                                                 uint64_t                      *key)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (tele_key->key_type) {
    case (SX_TELE_THRESHOLD_TYPE_PORT_TC_E):
        *key = BUILD_LAST_CONGESTION_THRESHOLD_KEY(tele_key->key.port_tc.log_port,
                                                   TELE_THRESHOLD_DIRECTION_EGRESS_E);
        break;

    case (SX_TELE_THRESHOLD_TYPE_PORT_PG_E):
        *key = BUILD_LAST_CONGESTION_THRESHOLD_KEY(tele_key->key.port_pg.log_port,
                                                   TELE_THRESHOLD_DIRECTION_INGRESS_E);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("key type %s not supported.\n", sx_tele_threshold_type_str(tele_key->key_type));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_db_last_congestion_threshold_lookup(const sx_tele_threshold_key_t              *tele_key_p,
                                                              tele_db_last_congestion_threshold_entry_t **entry_pp)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;
    uint64_t       map_key = 0;

    SX_LOG_ENTER();

    err = __tele_db_last_congestion_threshold_build_key(tele_key_p, &map_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to build last congestion threshold key, err: %s.\n", sx_status_str(err));
        goto out;
    }

    map_item_p = cl_qmap_get(&g_last_congestion_threshold_map, map_key);
    if (map_item_p == cl_qmap_end(&g_last_congestion_threshold_map)) {
        *entry_pp = NULL;
        goto out;
    }

    *entry_pp = PARENT_STRUCT(map_item_p, tele_db_last_congestion_threshold_entry_t, map_item);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_last_congestion_threshold_data_get(const sx_tele_threshold_key_t *key_p,
                                                           sx_tele_threshold_data_t      *data_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *entry_p = NULL;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(err = sdk_tele_check_init())) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(key_p, "key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(data_p, "data_p"))) {
        goto out;
    }

    err = __tele_db_last_congestion_threshold_lookup(key_p, &entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Telemetry last congestion threshold entry lookup failed, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    if (entry_p == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to get last congestion threshold data, err: %s\n", sx_status_str(err));
        goto out;
    }
    SX_MEM_CPY_P(data_p, &(entry_p->congestion_data));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_last_congestion_threshold_allocate_entry(
    const sx_tele_threshold_key_t              *key_p,
    tele_db_last_congestion_threshold_entry_t **entry_pp)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *new_entry_p = NULL;
    uint64_t                                   map_key = 0;

    SX_LOG_ENTER();

    err = utils_clr_memory_get((void**)(&new_entry_p), 1,
                               sizeof(tele_db_last_congestion_threshold_entry_t),
                               UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get memory for last congestion threshold entry, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    err = __tele_db_last_congestion_threshold_build_key(key_p, &map_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to build last congestion threshold key, err: %s\n", sx_status_str(err));
        goto out;
    }

    cl_qmap_insert(&g_last_congestion_threshold_map, map_key, &new_entry_p->map_item);

    *entry_pp = new_entry_p;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_last_congestion_threshold_free_entry(
    tele_db_last_congestion_threshold_entry_t *entry_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint64_t                map_key = 0;
    sx_tele_threshold_key_t tele_key;

    SX_MEM_CLR(tele_key);
    SX_LOG_ENTER();

    tele_key.key_type = entry_p->key_type;
    switch (tele_key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        tele_key.key.port_pg.log_port = entry_p->log_port;
        break;

    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
        tele_key.key.port_tc.log_port = entry_p->log_port;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("key type %s not supported.\n", sx_tele_threshold_type_str(tele_key.key_type));
        goto out;
    }

    err = __tele_db_last_congestion_threshold_build_key(&tele_key, &map_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to build last congestion threshold key, err: %s\n", sx_status_str(err));
        goto out;
    }

    cl_qmap_remove(&g_last_congestion_threshold_map, map_key);

    err = utils_memory_put(entry_p,
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to put memory for last congestion threshold entry, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    entry_p = NULL;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_last_congestion_threshold_add(const sx_tele_threshold_key_t  *key_p,
                                                               const sx_tele_threshold_data_t *data_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *last_congestion_entry_p = NULL;

    SX_LOG_ENTER();

    err = __sdk_tele_db_last_congestion_threshold_allocate_entry(key_p, &last_congestion_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Telemetry last congestion threshold entry allocation failed, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    last_congestion_entry_p->cnt = 1;
    last_congestion_entry_p->key_type = key_p->key_type;

    switch (key_p->key_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        last_congestion_entry_p->log_port = key_p->key.port_pg.log_port;
        break;

    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
        last_congestion_entry_p->log_port = key_p->key.port_tc.log_port;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("tele key type %s not supported.\n", sx_tele_threshold_type_str(key_p->key_type));
        goto out;
    }

    SX_MEM_CPY_P(&(last_congestion_entry_p->congestion_data), data_p);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_last_congestion_threshold_modify(const sx_access_cmd_t           cmd,
                                                                  const sx_tele_threshold_key_t  *key_p,
                                                                  const sx_tele_threshold_data_t *data_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *last_congestion_entry_p = NULL;

    SX_LOG_ENTER();

    /* lookup for the entry to modify */
    err = __tele_db_last_congestion_threshold_lookup(key_p, &last_congestion_entry_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get last congestion threshold entry, err = %s\n", sx_status_str(err));
        goto out;
    }
    if (last_congestion_entry_p == NULL) {
        SX_LOG_ERR("Tele last congestion threshold entry not found\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    if (cmd == SX_ACCESS_CMD_SET) {
        last_congestion_entry_p->cnt++;
    }

    SX_MEM_CPY_P(&last_congestion_entry_p->congestion_data, data_p);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_last_congestion_threshold_delete(const sx_tele_threshold_key_t *key_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *last_congestion_entry_p = NULL;

    SX_LOG_ENTER();

    /* lookup for the entry to delete */
    err = __tele_db_last_congestion_threshold_lookup(key_p, &last_congestion_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get last congestion threshold entry, err = %s\n", sx_status_str(err));
        goto out;
    }
    if (last_congestion_entry_p == NULL) {
        SX_LOG_ERR("Tele last congestion threshold entry not found \n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    last_congestion_entry_p->cnt--;
    if (last_congestion_entry_p->cnt == 0) {
        err = __sdk_tele_db_last_congestion_threshold_free_entry(last_congestion_entry_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Telemetry last congestion threshold entry free failed, err: %s\n",
                       sx_status_str(err));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_last_congestion_threshold_entry_update(const sx_access_cmd_t           cmd,
                                                               const sx_tele_threshold_key_t  *key_p,
                                                               const sx_tele_threshold_data_t *data_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    tele_db_last_congestion_threshold_entry_t *entry_p = NULL;
    sx_tele_threshold_data_t                   data;
    sx_port_id_t                              *port_list_p = NULL;
    length_t                                   port_cnt = 0;
    sx_tele_threshold_key_t                    log_port_key;
    sx_port_log_id_t                           log_port = 0;
    uint32_t                                   i = 0;

    SX_MEM_CLR(data);
    SX_MEM_CLR(log_port_key);

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = sdk_tele_check_init())) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(key_p, "key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(data_p, "data_p"))) {
        goto out;
    }

    err = sdk_tele_db_threshold_get(*key_p, &data);
    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_STATUS_ENTRY_NOT_FOUND != err) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele threshold entry get check failed, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    } else { /* CMD = EDIT or DESTROY */
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele threshold entry get check failed, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    sdk_tele_impl_threshold_key_log_port_get(*key_p, &log_port);
    err = utils_memory_get((void**)&port_list_p,
                           rm_resource_global.lag_port_members_max * sizeof(sx_port_id_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
        port_cnt = rm_resource_global.lag_port_members_max;
        err = sx_lag_port_group_get(log_port, port_list_p, &port_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in sx_lag_port_group_get(), error: %s\n", sx_status_str(err));
            goto out;
        }
    } else if ((SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_NETWORK)) {
        port_cnt = 1;
        port_list_p[0] = log_port;
    } else {
        SX_LOG_ERR("port type [%u] is not NETWORK nor LAG.\n", SX_PORT_TYPE_ID_GET(log_port));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CPY(log_port_key, *key_p);
    for (i = 0; i < port_cnt; i++) {
        if (log_port_key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            log_port_key.key.port_tc.log_port = port_list_p[i];
        } else {
            log_port_key.key.port_pg.log_port = port_list_p[i];
        }

        switch (cmd) {
        case SX_ACCESS_CMD_SET:
            err = __tele_db_last_congestion_threshold_lookup(&log_port_key, &entry_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get last congestion threshold entry, err = %s\n", sx_status_str(err));
                goto out;
            }
            if (entry_p == NULL) {
                err = __sdk_tele_db_last_congestion_threshold_add(&log_port_key, data_p);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to add issu congestion entry, err: %s\n",
                               sx_status_str(err));
                    goto out;
                }
                break;
            }

        /* Fall through */
        case SX_ACCESS_CMD_EDIT:
            err = __sdk_tele_db_last_congestion_threshold_modify(cmd, &log_port_key, data_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to modify last congestion threshold entry, err: %s\n",
                           sx_status_str(err));
                goto out;
            }
            break;

        case SX_ACCESS_CMD_DESTROY:
            err = __sdk_tele_db_last_congestion_threshold_delete(&log_port_key);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to delete last congestion entry, err: %s\n",
                           sx_status_str(err));
                goto out;
            }
            break;

        default:
            err = SX_STATUS_CMD_UNSUPPORTED;
            SX_LOG_ERR("cmd %s not supported.\n", sx_access_cmd_str(cmd));
            break;
        }
    }
out:
    if (port_list_p) {
        utils_memory_put(port_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_db_histogram_examine_filter(const sx_tele_histogram_filter_t *filter_p,
                                                      const sx_tele_histogram_key_t    *key_p,
                                                      boolean_t                        *is_match)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     filter_bitmap = 0;
    uint8_t     key_values_bitmap = 0;

    SX_LOG_ENTER();

    if (filter_p->filter_port_valid) {
        filter_bitmap |= 1 << PORT_BIT;
        switch (key_p->type) {
        case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
        case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
            if (key_p->key.port_tc.log_port == filter_p->port_filter) {
                key_values_bitmap |= 1 << PORT_BIT;
            }
            break;

        case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
            if (key_p->key.port_pg.log_port == filter_p->port_filter) {
                key_values_bitmap |= 1 << PORT_BIT;
            }
            break;

        case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
            if (key_p->key.port_counter.log_port == filter_p->port_filter) {
                key_values_bitmap |= 1 << PORT_BIT;
            }
            break;


        case SX_TELE_HISTOGRAM_TYPE_INVALID:
        default:
            break;
        }
    }
    if (filter_p->filter_tc_valid) {
        filter_bitmap |= 1 << TC_BIT;
        if (key_p->key.port_tc.tc == filter_p->tc_filter) {
            key_values_bitmap |= 1 << TC_BIT;
        }
    } else if (filter_p->filter_pg_valid) {
        filter_bitmap |= 1 << PG_BIT;
        if (key_p->key.port_pg.pg == filter_p->pg_filter) {
            key_values_bitmap |= 1 << PG_BIT;
        }
    }

    if (filter_bitmap == key_values_bitmap) {
        *is_match = TRUE;
    } else {
        *is_match = FALSE;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __verify_threshold_filter(const sx_tele_threshold_filter_t *filter_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = 0;

    SX_LOG_ENTER();
    if ((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E) &&
        (filter_p->tc_filter_valid == SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E)) {
        SX_LOG_ERR("Filter has both PORT and TC enabled. Only one can be valid\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E) &&
        (filter_p->pg_filter_valid)) {
        SX_LOG_ERR("Filter has both PORT and PG enabled. Only one can be valid\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E) {
        port_type = SX_PORT_TYPE_ID_GET(filter_p->port_filter);
        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%x) type [%s] is invalid. only types NETWORK and LAG are supported. err = %s \n",
                       filter_p->port_filter,
                       sx_port_type_str(port_type),
                       sx_status_str(err));
            goto out;
        }
    }

    if (filter_p->tc_filter_valid == SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E) {
        if ((rm_resource_global.cos_port_ets_traffic_class_max < filter_p->tc_filter)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Traffic class [%u] > max traffic class [%u]. err = %s.\n",
                       filter_p->tc_filter,
                       rm_resource_global.cos_port_ets_traffic_class_max,
                       sx_status_str(err));
            goto out;
        }
    }

    if (filter_p->pg_filter_valid) {
        if (RM_PORT_INGRESS_SHARED_BUFFER_PG_ID_CHECK_RANGE(filter_p->pg_filter) == FALSE) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("PG (%d) exceeds range\n", filter_p->pg_filter);
            goto out;
        }
    }

    /* filter is valid but disabled */

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_histogram_get(const sx_tele_histogram_key_t        tele_key,
                                      sx_tele_histogram_attributes_data_t *data_p,
                                      uint32_t                            *tele_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    tele_id_item_t            *tele_id_item_p = NULL;

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    __tele_db_histogram_lookup(&tele_key, &histogram_entry_p);
    if (histogram_entry_p == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (data_p != NULL) {
        SX_MEM_CPY_P(data_p, &histogram_entry_p->data.tele_attr);
    }

    if (tele_id_p != NULL) {
        tele_id_item_p = PARENT_STRUCT(histogram_entry_p->data.list_item,
                                       tele_id_item_t, list_item);

        SX_MEM_CPY_P(tele_id_p, &tele_id_item_p->tele_id);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_histogram_iter_get_first(const sx_tele_histogram_filter_t    *filter_p,
                                                 sx_tele_histogram_key_t             *key_list_p,
                                                 sx_tele_histogram_attributes_data_t *data_list_p,
                                                 uint32_t                            *hist_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;
    boolean_t                  is_match = TRUE;

    if (utils_check_pointer(hist_cnt_p, "hist_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    map_item_p = cl_qmap_head(&histogram_map);
    end_item_p = cl_qmap_end(&histogram_map);
    while ((map_item_p != end_item_p) && (list_count < *hist_cnt_p)) {
        histogram_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (filter_p != NULL) {
            err = __tele_db_histogram_examine_filter(filter_p, &(histogram_entry_p->data.tele_key), &is_match);
            if (err) {
                SX_LOG_ERR("Histogram iterator failed to examine key against filter\n");
                goto out;
            }
            if (is_match == FALSE) {
                continue;
            }
        }

        if (key_list_p != NULL) {
            SX_MEM_CPY(key_list_p[list_count], histogram_entry_p->data.tele_key);
        }

        if (data_list_p != NULL) {
            SX_MEM_CPY(data_list_p[list_count], histogram_entry_p->data.tele_attr);
        }

        list_count++;
    }

out:
    SX_MEM_CPY_P(hist_cnt_p, &list_count);
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_histogram_iter_get(const sx_tele_histogram_filter_t    *filter_p,
                                           sx_tele_histogram_key_t             *key_p,
                                           sx_tele_histogram_key_t             *key_list_p,
                                           sx_tele_histogram_attributes_data_t *data_list_p,
                                           uint32_t                            *hist_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;
    boolean_t                  is_match = TRUE;

    if (utils_check_pointer(hist_cnt_p, "hist_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*hist_cnt_p > 0) {
        if (utils_check_pointer(key_p, "key_p")) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *hist_cnt_p = 1;

        __tele_db_histogram_lookup(key_p, &histogram_entry_p);
        if (histogram_entry_p == NULL) {
            *hist_cnt_p = 0;
            goto out;
        } else {
            if (filter_p != NULL) {
                err = __tele_db_histogram_examine_filter(filter_p, &(histogram_entry_p->data.tele_key), &is_match);
                if (err) {
                    SX_LOG_ERR("Histogram iterator failed to examine key against filter\n");
                    goto out;
                }
                if (is_match == FALSE) {
                    *hist_cnt_p = 0;
                    goto out;
                }
            }

            if (key_list_p != NULL) {
                SX_MEM_CPY(key_list_p[0], histogram_entry_p->data.tele_key);
            }

            if (data_list_p != NULL) {
                SX_MEM_CPY(data_list_p[0], histogram_entry_p->data.tele_attr);
            }
        }
    } else {
        map_item_p = cl_qmap_head(&histogram_map);
        end_item_p = cl_qmap_end(&histogram_map);
        while (map_item_p != end_item_p) {
            histogram_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);

            if (filter_p != NULL) {
                err = __tele_db_histogram_examine_filter(filter_p, &(histogram_entry_p->data.tele_key), &is_match);
                if (err) {
                    SX_LOG_ERR("Histogram iterator failed to examine key against filter\n");
                    goto out;
                }
                if (is_match == FALSE) {
                    continue;
                }
            }

            list_count++;
        }

        SX_MEM_CPY_P(hist_cnt_p, &list_count);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_histogram_iter_get_next(const sx_tele_histogram_filter_t    *filter_p,
                                                sx_tele_histogram_key_t              key,
                                                sx_tele_histogram_key_t             *key_list_p,
                                                sx_tele_histogram_attributes_data_t *data_list_p,
                                                uint32_t                            *hist_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;
    uint64_t                   map_key = 0;
    boolean_t                  is_match = TRUE;

    if (utils_check_pointer(hist_cnt_p, "hist_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __tele_db_histogram_build_key(&key, &map_key);
    if (err) {
        SX_LOG_ERR("Histogram iterator failed to handle key\n");
        goto out;
    }

    map_item_p = cl_qmap_get_next(&histogram_map, map_key);
    end_item_p = cl_qmap_end(&histogram_map);
    while ((map_item_p != end_item_p) && (list_count < *hist_cnt_p)) {
        histogram_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (filter_p != NULL) {
            err = __tele_db_histogram_examine_filter(filter_p, &(histogram_entry_p->data.tele_key), &is_match);
            if (err) {
                SX_LOG_ERR("Histogram iterator failed to examine key against filter\n");
                goto out;
            }
            if (is_match == FALSE) {
                continue;
            }
        }

        if (key_list_p != NULL) {
            SX_MEM_CPY(key_list_p[list_count], histogram_entry_p->data.tele_key);
        }

        if (data_list_p != NULL) {
            SX_MEM_CPY(data_list_p[list_count], histogram_entry_p->data.tele_attr);
        }
        list_count++;
    }

    if (hist_cnt_p != NULL) {
        SX_MEM_CPY_P(hist_cnt_p, &list_count);
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_tele_db_histogram_key_iter_p_get(sx_access_cmd_t cmd, const sx_tele_histogram_key_t **key_pp)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    uint64_t                   map_key = 0;

    SX_LOG_ENTER();

    err = utils_check_pointer(key_pp, "key_pp");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = sdk_tele_check_init();
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
        map_item_p = cl_qmap_head(&histogram_map);
        break;

    case SX_ACCESS_CMD_GETNEXT:
        err = __tele_db_histogram_build_key(*key_pp, &map_key);
        if (err) {
            SX_LOG_ERR("Histogram iter_p failed to handle key\n");
            goto out;
        }
        map_item_p = cl_qmap_get_next(&histogram_map, map_key);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command not supported\n");
        break;
    }

    if (map_item_p == cl_qmap_end(&histogram_map)) {
        *key_pp = NULL;
        goto out;
    }
    histogram_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
    *key_pp = &(histogram_entry_p->data.tele_key);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tele_db_histogram_allocate_entry(const sx_tele_histogram_key_t *tele_key,
                                                          tele_db_histogram_entry_t    **histogram_entry_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    cl_list_item_t            *list_item_p = NULL;
    cl_pool_item_t            *pool_item_p = NULL;
    tele_db_histogram_entry_t *new_tele_entry_p = NULL;
    tele_id_item_t            *tele_id_item_p = NULL;
    boolean_t                  id_get_passed_rollback = FALSE;
    uint64_t                   map_key = 0;

    list_item_p = cl_qlist_remove_head(&histogram_free_id_list);
    if (cl_qlist_end(&histogram_free_id_list) == list_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR_RESOURCE_COND(err, "Can't add new histogram entry to DB, err = %s\n",
                                 sx_status_str(err));
        goto out;
    }
    tele_id_item_p = PARENT_STRUCT(list_item_p, tele_id_item_t, list_item);
    id_get_passed_rollback = TRUE;

    pool_item_p = cl_qpool_get(&histogram_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out resources in tele DB\n");
        goto out;
    }
    new_tele_entry_p = PARENT_STRUCT(pool_item_p, tele_db_histogram_entry_t, pool_item);

    SX_MEM_CLR(new_tele_entry_p->data);

    new_tele_entry_p->data.list_item = &tele_id_item_p->list_item;
    new_tele_entry_p->pool_item = *pool_item_p;

    err = __tele_db_histogram_build_key(tele_key, &map_key);
    if (err) {
        SX_LOG_ERR("Histogram iterator failed to handle key\n");
        goto out;
    }

    cl_qmap_insert(&histogram_map, map_key, &new_tele_entry_p->map_item);

    *histogram_entry_p = new_tele_entry_p;

out:
    if (SX_CHECK_FAIL(err)) {
        if (id_get_passed_rollback) {
            cl_qlist_insert_head(&histogram_free_id_list, &tele_id_item_p->list_item);
        }
    }
    return err;
}
/* add a new telemetry entry to the database */
sx_status_t sdk_tele_db_histogram_add(const sx_tele_histogram_key_t             key,
                                      const sx_tele_histogram_attributes_data_t data,
                                      uint32_t                                 *tele_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    tele_id_item_t            *tele_id_item_p = NULL;
    sx_port_phy_id_t           local_port = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("Add tele entry to hwi DB\n");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __sdk_tele_db_histogram_allocate_entry(&key, &histogram_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR_RESOURCE_COND(err, "Telemetry histogram allocation failed, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

    tele_id_item_p = PARENT_STRUCT(histogram_entry_p->data.list_item,
                                   tele_id_item_t, list_item);

    SX_MEM_CPY_P(&histogram_entry_p->data.tele_key, &key);
    SX_MEM_CPY_P(&histogram_entry_p->data.tele_attr, &data);

    SX_MEM_CPY_P(tele_id_p, &tele_id_item_p->tele_id);

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E) {
        if (SX_PORT_TYPE_ID_GET(key.key.port_tc.log_port) == SX_PORT_TYPE_PROFILE) {
            local_port = rm_resource_global.port_ext_num_max + SX_PORT_PROFILE_IDX_GET(key.key.port_tc.log_port);
        } else {
            local_port = SX_PORT_PHY_ID_GET(key.key.port_tc.log_port);
        }

        if (!SX_CHECK_RANGE(1, local_port, rm_resource_global.port_ext_num_max + PORT_PROFILE_NUM_MAX)) {
            SX_LOG_ERR("Port %d (log_port %d) is out of range [1-%d]\n",
                       local_port, key.key.port_tc.log_port, rm_resource_global.port_ext_num_max);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (g_latency_histogram_port_tcs_config_p[local_port - 1].num_of_configured_tcs == 0) {
            g_latency_histogram_port_tcs_config_p[local_port -
                                                  1].data.min_boundary = data.data.queue_depth.min_boundary;
            g_latency_histogram_port_tcs_config_p[local_port - 1].data.mode = data.data.queue_depth.mode;
            g_latency_histogram_port_tcs_config_p[local_port - 1].data.bin_size_resolution =
                data.data.queue_depth.bin_size_resolution;
        }
        g_latency_histogram_port_tcs_config_p[local_port - 1].num_of_configured_tcs++;
    }

out:

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_histogram_modify(const sx_tele_histogram_key_t             key,
                                         const sx_tele_histogram_attributes_data_t data,
                                         uint32_t                                 *tele_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    tele_id_item_t            *tele_id_item_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to modify */
    __tele_db_histogram_lookup(&key, &histogram_entry_p);
    if (histogram_entry_p == NULL) {
        SX_LOG_ERR("Tele entry not found in HWI DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    tele_id_item_p = PARENT_STRUCT(histogram_entry_p->data.list_item,
                                   tele_id_item_t, list_item);

    SX_MEM_CPY_P(&histogram_entry_p->data.tele_attr, &data);

    SX_MEM_CPY_P(tele_id_p, &tele_id_item_p->tele_id);

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_histogram_delete(const sx_tele_histogram_key_t key, uint32_t *tele_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_histogram_entry_t *histogram_entry_p = NULL;
    tele_id_item_t            *tele_id_item_p = NULL;
    uint64_t                   map_key = 0;
    sx_port_phy_id_t           local_port = 0;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to delete */
    __tele_db_histogram_lookup(&key, &histogram_entry_p);
    if (histogram_entry_p == NULL) {
        SX_LOG_ERR("Tele entry not found in HWI DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    tele_id_item_p = PARENT_STRUCT(histogram_entry_p->data.list_item,
                                   tele_id_item_t, list_item);

    SX_MEM_CPY_P(tele_id_p, &tele_id_item_p->tele_id);

    __tele_db_histogram_build_key(&key, &map_key);
    cl_qmap_remove(&histogram_map, map_key);
    cl_qpool_put(&histogram_pool, &histogram_entry_p->pool_item);
    cl_qlist_insert_head(&histogram_free_id_list, histogram_entry_p->data.list_item);

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E) {
        if (SX_PORT_TYPE_ID_GET(key.key.port_tc.log_port) == SX_PORT_TYPE_PROFILE) {
            local_port = rm_resource_global.port_ext_num_max + SX_PORT_PROFILE_IDX_GET(key.key.port_tc.log_port);
        } else {
            local_port = SX_PORT_PHY_ID_GET(key.key.port_tc.log_port);
        }
        if (!SX_CHECK_RANGE(1, local_port, rm_resource_global.port_ext_num_max + PORT_PROFILE_NUM_MAX)) {
            SX_LOG_ERR("Port %d (log_port %d) is out of range [1-%d]\n",
                       local_port, key.key.port_tc.log_port, rm_resource_global.port_ext_num_max);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        g_latency_histogram_port_tcs_config_p[local_port - 1].num_of_configured_tcs--;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_histogram_port_tc_validate(const sx_port_log_id_t                     log_port,
                                                           const sx_tele_histogram_attributes_data_t *data,
                                                           boolean_t                                 *is_valid_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_port_phy_id_t local_port = 0;

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_PROFILE) {
        local_port = rm_resource_global.port_ext_num_max + SX_PORT_PROFILE_IDX_GET(log_port);
    } else {
        local_port = SX_PORT_PHY_ID_GET(log_port);
    }
    if (!SX_CHECK_RANGE(1, local_port, rm_resource_global.port_ext_num_max + PORT_PROFILE_NUM_MAX)) {
        SX_LOG_ERR("Port %d (log_port %d) is out of range [1-%d]\n",
                   local_port, log_port, rm_resource_global.port_ext_num_max);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    *is_valid_p = TRUE;
    if (g_latency_histogram_port_tcs_config_p[local_port - 1].num_of_configured_tcs > 0) {
        if ((g_latency_histogram_port_tcs_config_p[local_port - 1].data.bin_size_resolution !=
             data->data.queue_depth.bin_size_resolution) ||
            (g_latency_histogram_port_tcs_config_p[local_port - 1].data.min_boundary !=
             data->data.queue_depth.min_boundary) ||
            (g_latency_histogram_port_tcs_config_p[local_port - 1].data.mode != data->data.queue_depth.mode)) {
            *is_valid_p = FALSE;
            SX_LOG_ERR("Latency histogram configuration for port %d (log_port %d) is invalid.\n"
                       "bin_size_resolution: must be %d, cannot be %d\n"
                       "min_boundary: must be %d, cannot be %d\n"
                       "mode: must be %s, cannot be %s\n",
                       local_port,
                       log_port,
                       g_latency_histogram_port_tcs_config_p[local_port - 1].data.bin_size_resolution,
                       data->data.queue_depth.bin_size_resolution,
                       g_latency_histogram_port_tcs_config_p[local_port - 1].data.min_boundary,
                       data->data.queue_depth.min_boundary,
                       sx_tele_histogram_mode_str(g_latency_histogram_port_tcs_config_p[local_port - 1].data.mode),
                       sx_tele_histogram_mode_str(data->data.queue_depth.mode));
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static inline uint64_t build_threshold_congestion_key(const sx_tele_threshold_key_t key)
{
    if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
        return BUILD_CONGGESTION_THRESHOLD_KEY(key.key.port_tc.log_port,
                                               TELE_THRESHOLD_DIRECTION_EGRESS_E,
                                               key.key.port_tc.tc);
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
        return BUILD_CONGGESTION_THRESHOLD_KEY(key.key.port_pg.log_port,
                                               TELE_THRESHOLD_DIRECTION_INGRESS_E,
                                               key.key.port_pg.pg);
    }
    return 0;
}

static void __tele_db_threshold_lookup(const sx_tele_threshold_key_t thr_key, tele_db_threshold_entry_t **entry_pp)
{
    cl_map_item_t *map_item_p = NULL;
    uint64_t       __key = build_threshold_congestion_key(thr_key);


    map_item_p = cl_qmap_get(&threshold_map, __key);
    if (map_item_p == cl_qmap_end(&threshold_map)) {
        *entry_pp = NULL;
        return;
    }

    *entry_pp = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
}

static sx_status_t __sdk_tele_db_threshold_allocate_entry(const sx_tele_threshold_key_t *key,
                                                          tele_db_threshold_entry_t    **threshold_entry_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    cl_pool_item_t            *pool_item_p = NULL;
    tele_db_threshold_entry_t *new_thr_entry_p = NULL;
    uint64_t                   map_key;

    pool_item_p = cl_qpool_get(&threshold_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to allocate Telemetry threshold entry, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }
    new_thr_entry_p = PARENT_STRUCT(pool_item_p, tele_db_threshold_entry_t, pool_item);

    SX_MEM_CLR(new_thr_entry_p->data);

    new_thr_entry_p->pool_item = *pool_item_p;

    map_key = build_threshold_congestion_key(*key);

    cl_qmap_insert(&threshold_map, map_key, &new_thr_entry_p->map_item);

    *threshold_entry_p = new_thr_entry_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_get(const sx_tele_threshold_key_t tele_key, sx_tele_threshold_data_t     *data_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    __tele_db_threshold_lookup(tele_key, &threshold_entry_p);
    if (threshold_entry_p == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (data_p != NULL) {
        SX_MEM_CPY_P(data_p, &threshold_entry_p->data.data);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_iter_get_first(const sx_tele_threshold_filter_t *filter_p,
                                                 sx_tele_threshold_key_t          *key_list_p,
                                                 sx_tele_threshold_data_t         *data_list_p,
                                                 uint32_t                         *thr_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;

    if (utils_check_pointer(thr_cnt_p, "thr_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (filter_p == NULL) {
        SX_LOG_ERR("filter_p is NULL \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    err = __verify_threshold_filter(filter_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid threshold filter \n");
        goto out;
    }

    map_item_p = cl_qmap_head(&threshold_map);
    end_item_p = cl_qmap_end(&threshold_map);
    while ((map_item_p != end_item_p) && (list_count < *thr_cnt_p)) {
        threshold_entry_p = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            if (((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E)
                 && (threshold_entry_p->data.key.key.port_tc.log_port != filter_p->port_filter))
                || ((filter_p->tc_filter_valid == SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E)
                    && (threshold_entry_p->data.key.key.port_tc.tc != filter_p->tc_filter))) {
                continue;
            }
        }
        if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            if (((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E)
                 && (threshold_entry_p->data.key.key.port_pg.log_port != filter_p->port_filter))
                || (filter_p->pg_filter_valid
                    && (threshold_entry_p->data.key.key.port_pg.pg != filter_p->pg_filter))) {
                continue;
            }
        }

        if (key_list_p != NULL) {
            SX_MEM_CPY(key_list_p[list_count], threshold_entry_p->data.key);
        }

        if (data_list_p != NULL) {
            SX_MEM_CPY(data_list_p[list_count], threshold_entry_p->data.data);
        }

        list_count++;
    }

    SX_MEM_CPY_P(thr_cnt_p, &list_count);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_iter_get_next(const sx_tele_threshold_filter_t *filter_p,
                                                sx_tele_threshold_key_t           key,
                                                sx_tele_threshold_key_t          *key_list_p,
                                                sx_tele_threshold_data_t         *data_list_p,
                                                uint32_t                         *thr_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;
    uint64_t                   map_key = 0;

    if (utils_check_pointer(thr_cnt_p, "thr_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (filter_p == NULL) {
        SX_LOG_ERR("filter_p is NULL \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    err = __verify_threshold_filter(filter_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid threshold filter \n");
        goto out;
    }

    map_key = build_threshold_congestion_key(key);

    map_item_p = cl_qmap_get_next(&threshold_map, map_key);
    end_item_p = cl_qmap_end(&threshold_map);
    while ((map_item_p != end_item_p) && (list_count < *thr_cnt_p)) {
        threshold_entry_p = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            if (((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E)
                 && (threshold_entry_p->data.key.key.port_tc.log_port != filter_p->port_filter))
                || ((filter_p->tc_filter_valid == SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E)
                    && (threshold_entry_p->data.key.key.port_tc.tc != filter_p->tc_filter))) {
                continue;
            }
        }
        if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            if (((filter_p->port_filter_valid == SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E)
                 && (threshold_entry_p->data.key.key.port_pg.log_port != filter_p->port_filter))
                || (filter_p->pg_filter_valid
                    && (threshold_entry_p->data.key.key.port_pg.pg != filter_p->pg_filter))) {
                continue;
            }
        }

        if (key_list_p != NULL) {
            SX_MEM_CPY(key_list_p[list_count], threshold_entry_p->data.key);
        }

        if (data_list_p != NULL) {
            SX_MEM_CPY(data_list_p[list_count], threshold_entry_p->data.data);
        }
        list_count++;
    }

    if (thr_cnt_p != NULL) {
        SX_MEM_CPY_P(thr_cnt_p, &list_count);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_iter_get(const sx_tele_threshold_filter_t *filter_p,
                                           sx_tele_threshold_key_t          *key_p,
                                           sx_tele_threshold_key_t          *key_list_p,
                                           sx_tele_threshold_data_t         *data_list_p,
                                           uint32_t                         *thr_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    const cl_map_item_t       *end_item_p = NULL;
    uint32_t                   list_count = 0;

    if (utils_check_pointer(thr_cnt_p, "thr_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*thr_cnt_p > 0) {
        if (utils_check_pointer(key_p, "key_p")) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *thr_cnt_p = 1;

        __tele_db_threshold_lookup(*key_p, &threshold_entry_p);
        if (threshold_entry_p == NULL) {
            *thr_cnt_p = 0;
            goto out;
        } else {
            if (filter_p != NULL) {
                if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                    if (filter_p->port_filter_valid &&
                        (threshold_entry_p->data.key.key.port_tc.log_port != filter_p->port_filter)) {
                        *thr_cnt_p = 0;
                        goto out;
                    }

                    if (filter_p->tc_filter_valid &&
                        (threshold_entry_p->data.key.key.port_tc.tc != filter_p->tc_filter)) {
                        *thr_cnt_p = 0;
                        goto out;
                    }
                }

                if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                    if (filter_p->port_filter_valid &&
                        (threshold_entry_p->data.key.key.port_pg.log_port != filter_p->port_filter)) {
                        *thr_cnt_p = 0;
                        goto out;
                    }

                    if (filter_p->pg_filter_valid &&
                        (threshold_entry_p->data.key.key.port_pg.pg != filter_p->pg_filter)) {
                        *thr_cnt_p = 0;
                        goto out;
                    }
                }
            }

            if (key_list_p != NULL) {
                SX_MEM_CPY(key_list_p[0], threshold_entry_p->data.key);
            }

            if (data_list_p != NULL) {
                SX_MEM_CPY(data_list_p[0], threshold_entry_p->data.data);
            }
        }
    } else {
        map_item_p = cl_qmap_head(&threshold_map);
        end_item_p = cl_qmap_end(&threshold_map);
        while (map_item_p != end_item_p) {
            threshold_entry_p = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);
            if (filter_p != NULL) {
                if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                    if (filter_p->port_filter_valid &&
                        (threshold_entry_p->data.key.key.port_tc.log_port != filter_p->port_filter)) {
                        continue;
                    }

                    if (filter_p->tc_filter_valid &&
                        (threshold_entry_p->data.key.key.port_tc.tc != filter_p->tc_filter)) {
                        continue;
                    }
                }
                if (threshold_entry_p->data.key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                    if (filter_p->port_filter_valid &&
                        (threshold_entry_p->data.key.key.port_pg.log_port != filter_p->port_filter)) {
                        continue;
                    }

                    if (filter_p->pg_filter_valid &&
                        (threshold_entry_p->data.key.key.port_pg.pg != filter_p->pg_filter)) {
                        continue;
                    }
                }
            }

            list_count++;
        }

        SX_MEM_CPY_P(thr_cnt_p, &list_count);
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_threshold_add(const sx_tele_threshold_key_t key, const sx_tele_threshold_data_t data)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __sdk_tele_db_threshold_allocate_entry(&key, &threshold_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR_RESOURCE_COND(err, "Telemetry threshold entry allocation failed, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(&(threshold_entry_p->data.key), &key);
    SX_MEM_CPY_P(&(threshold_entry_p->data.data), &data);


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_modify(const sx_tele_threshold_key_t key, const sx_tele_threshold_data_t data)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to modify */
    __tele_db_threshold_lookup(key, &threshold_entry_p);
    if (threshold_entry_p == NULL) {
        SX_LOG_ERR("Tele threshold entry not found in HWI DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CPY_P(&threshold_entry_p->data.data, &data);


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_threshold_delete(const sx_tele_threshold_key_t key)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    tele_db_threshold_entry_t *threshold_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to delete */
    __tele_db_threshold_lookup(key, &threshold_entry_p);
    if (threshold_entry_p == NULL) {
        SX_LOG_ERR("Tele threshold entry not found in HWI DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    cl_qmap_remove(&threshold_map, build_threshold_congestion_key(key));
    cl_qpool_put(&threshold_pool, &threshold_entry_p->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}


static inline uint64_t build_threshold_latency_key(const sx_tele_threshold_key_t key)
{
    if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) {
        return BUILD_LATENCY_THRESHOLD_KEY(key.key.port_tc.log_port,
                                           key.key.port_tc.tc);
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E) {
        return BUILD_LATENCY_THRESHOLD_KEY(0, key.key.mc_sp.sp);
    }
    return 0;
}

static void __tele_db_latency_threshold_key_lookup(const sx_tele_threshold_key_t           key,
                                                   tele_db_latency_threshold_key_entry_t **entry_pp)
{
    cl_map_item_t *map_item_p = NULL;
    uint64_t       map_key = build_threshold_latency_key(key);


    map_item_p = cl_qmap_get(&g_latency_threshold_key_map, map_key);
    if (map_item_p == cl_qmap_end(&g_latency_threshold_key_map)) {
        *entry_pp = NULL;
        return;
    }

    *entry_pp = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_key_entry_t, map_item);
    return;
}

static sx_status_t __sdk_tele_db_latency_threshold_allocate_key_entry(const sx_tele_threshold_key_t          *key,
                                                                      tele_db_latency_threshold_key_entry_t **entry_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    cl_pool_item_t                        *pool_item_p = NULL;
    tele_db_latency_threshold_key_entry_t *new_entry_p = NULL;
    uint64_t                               map_key;

    pool_item_p = cl_qpool_get(&g_latency_threshold_key_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to allocate latency threshold key entry, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }
    new_entry_p = PARENT_STRUCT(pool_item_p, tele_db_latency_threshold_key_entry_t, pool_item);

    SX_MEM_CLR(new_entry_p->key);
    SX_MEM_CLR(new_entry_p->data);

    new_entry_p->pool_item = *pool_item_p;

    map_key = build_threshold_latency_key(*key);

    cl_qmap_insert(&g_latency_threshold_key_map, map_key, &new_entry_p->map_item);

    *entry_p = new_entry_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_key_add(const sx_tele_threshold_key_t  key,
                                                  const sx_tele_threshold_data_t data)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_key_entry_t *key_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __sdk_tele_db_latency_threshold_allocate_key_entry(&key, &key_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR_RESOURCE_COND(err, "Latency threshold key entry allocation failed, err: %s\n",
                                 sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(&(key_entry_p->key), &key);
    SX_MEM_CPY_P(&(key_entry_p->data), &data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_key_modify(const sx_tele_threshold_key_t  key,
                                                     const sx_tele_threshold_data_t data)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_key_entry_t *key_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to modify */
    __tele_db_latency_threshold_key_lookup(key, &key_entry_p);
    if (key_entry_p == NULL) {
        SX_LOG_ERR("Latency threshold key entry not found in DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CPY_P(&key_entry_p->data, &data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_key_delete(const sx_tele_threshold_key_t key)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_key_entry_t *key_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to delete */
    __tele_db_latency_threshold_key_lookup(key, &key_entry_p);
    if (key_entry_p == NULL) {
        SX_LOG_ERR("Latency threshold key entry not found in DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    cl_qmap_remove(&g_latency_threshold_key_map, build_threshold_latency_key(key));
    cl_qpool_put(&g_latency_threshold_key_pool, &key_entry_p->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_key_get(const sx_tele_threshold_key_t key,
                                                  sx_tele_threshold_data_t     *data_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_key_entry_t *key_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    __tele_db_latency_threshold_key_lookup(key, &key_entry_p);
    if (key_entry_p == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (data_p != NULL) {
        SX_MEM_CPY_P(data_p, &key_entry_p->data);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static void __tele_db_latency_threshold_data_lookup(const sx_tele_threshold_data_t           data,
                                                    tele_db_latency_threshold_data_entry_t **entry_pp)
{
    cl_map_item_t *map_item_p = NULL;
    uint64_t       map_key = (uint64_t)data.threshold_data.threshold_high;

    map_item_p = cl_qmap_get(&g_latency_threshold_data_map, map_key);
    if (map_item_p == cl_qmap_end(&g_latency_threshold_data_map)) {
        *entry_pp = NULL;
        return;
    }

    *entry_pp = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_data_entry_t, map_item);
    return;
}

sx_status_t sdk_tele_db_latency_threshold_data_alloc(const sx_tele_threshold_data_t data,
                                                     uint8_t                       *letancy_id_p,
                                                     boolean_t                     *is_new_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_data_entry_t *data_entry_p = NULL;
    cl_pool_item_t                         *pool_item_p = NULL;
    uint64_t                                map_key;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    __tele_db_latency_threshold_data_lookup(data, &data_entry_p);
    if (data_entry_p != NULL) {
        *letancy_id_p = data_entry_p->latency_id;
        *is_new_p = FALSE;
        data_entry_p->ref_count++;
        goto out;
    }

    pool_item_p = cl_qpool_get(&g_latency_threshold_data_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR_RESOURCE_COND(err, "Failed to allocate latency threshold data entry. [%s]\n",
                                 sx_status_str(err));
        goto out;
    }

    data_entry_p = PARENT_STRUCT(pool_item_p, tele_db_latency_threshold_data_entry_t, pool_item);

    data_entry_p->pool_item = *pool_item_p;

    map_key = (uint64_t)data.threshold_data.threshold_high;

    cl_qmap_insert(&g_latency_threshold_data_map, map_key, &data_entry_p->map_item);

    SX_MEM_CPY_P(&data_entry_p->data, &data);
    data_entry_p->ref_count = 1;
    *is_new_p = TRUE;
    *letancy_id_p = data_entry_p->latency_id;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_data_free(const sx_tele_threshold_data_t data)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_data_entry_t *data_entry_p = NULL;
    uint64_t                                map_key = 0;

    SX_LOG_ENTER();

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* lookup for the entry to delete */
    __tele_db_latency_threshold_data_lookup(data, &data_entry_p);
    if (data_entry_p == NULL) {
        SX_LOG_ERR("Latency threshold data entry not found in DB\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    data_entry_p->ref_count--;
    if (data_entry_p->ref_count == 0) {
        SX_MEM_CLR(data_entry_p->data);
        map_key = (uint64_t)data.threshold_data.threshold_high;
        cl_qmap_remove(&g_latency_threshold_data_map, map_key);
        cl_qpool_put(&g_latency_threshold_data_pool, &data_entry_p->pool_item);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __verify_latency_threshold_filter(const sx_tele_latency_threshold_filter_t *filter_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (filter_p->port_filter_valid && filter_p->tc_filter_valid) {
        SX_LOG_ERR("Latency filter has both PORT and TC enabled. Only one can be valid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (filter_p->port_filter_valid) {
        if (IS_PORT_TYPE_NETWORK_OR_LAG(filter_p->port_filter) == FALSE) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port (0x%x) type is invalid. only types NETWORK and LAG are supported.\n",
                       filter_p->port_filter);
            goto out;
        }
    }

    if (filter_p->tc_filter_valid) {
        if ((rm_resource_global.cos_port_ets_traffic_class_max < filter_p->tc_filter)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Traffic class [%u] > max traffic class [%u]. err = %s.\n",
                       filter_p->tc_filter,
                       rm_resource_global.cos_port_ets_traffic_class_max,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_latency_threshold_key_iter_get_first(sx_tele_latency_threshold_filter_t *filter_p,
                                                             sx_tele_threshold_key_t            *key_list_p,
                                                             sx_tele_threshold_data_t           *data_list_p,
                                                             uint32_t                           *list_cnt_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tele_db_latency_threshold_key_entry_t *entry_p = NULL;
    cl_map_item_t                         *map_item_p = NULL;
    const cl_map_item_t                   *end_item_p = NULL;
    uint32_t                               list_count = 0;

    if (utils_check_pointer(list_cnt_p, "list_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (filter_p == NULL) {
        SX_LOG_ERR("filter_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __verify_latency_threshold_filter(filter_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid latency threshold filter\n");
        goto out;
    }

    map_item_p = cl_qmap_head(&g_latency_threshold_key_map);
    end_item_p = cl_qmap_end(&g_latency_threshold_key_map);
    while (map_item_p != end_item_p && list_count < *list_cnt_p) {
        entry_p = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_key_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (entry_p->key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) {
            if (((filter_p->port_filter_valid == TRUE) && (entry_p->key.key.port_tc.log_port != filter_p->port_filter))
                || ((filter_p->tc_filter_valid == TRUE) && (entry_p->key.key.port_tc.tc != filter_p->tc_filter))) {
                continue;
            }
        }

        if (key_list_p != NULL) {
            SX_MEM_CPY(key_list_p[list_count], entry_p->key);
        }

        if (data_list_p != NULL) {
            SX_MEM_CPY(data_list_p[list_count], entry_p->data);
        }

        list_count++;
    }

    SX_MEM_CPY_P(list_cnt_p, &list_count);

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_db_histogram_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item_p = NULL;
    tele_db_histogram_entry_t *hist_entry_p = NULL;
    tele_db_histogram_data_t  *hist_db_data = NULL;
    tele_id_item_t            *hist_id_item_p = NULL;
    uint32_t                   hist_count = 0, time = 0, max_boundary = 0, min_boundary = 0, bin_size_resolution = 0,
                               sample_time_resolution = 0, hist_id = 0;
    sx_tele_histogram_mode_e  hist_mode = SX_TELE_HISTOGRAM_MODE_LINEAR_E;
    sx_tele_histogram_type_e  hist_type = 0;
    sx_port_log_id_t          log_port = 0;
    uint8_t                   tc_pg = 0;
    dbg_utils_table_columns_t hist_entry_table[] = {
        {"Hist ID",       7,  PARAM_UINT32_E,  &hist_id},
        {"Port",          12, PARAM_PORT_ID_E, &log_port},
        {"Type",          19, PARAM_STRING_E,  NULL},
        {"Mode",          11, PARAM_STRING_E,  NULL},
        {"Sample Time",   11, PARAM_UINT32_E,  &sample_time_resolution},
        {"Time(128nSec)", 13, PARAM_UINT32_E,  &time},
        {"Resolution",    10, PARAM_UINT32_E,  &bin_size_resolution},
        {"Min Boundary",  12, PARAM_UINT32_E,  &min_boundary},
        {"Max Boundary",  12, PARAM_STRING_E,  NULL},
        {"TC/PG",         5,  PARAM_STRING_E,  NULL},
        {"Counter Type",  35, PARAM_STRING_E,  NULL},
        {"Control",       10, PARAM_STRING_E,  NULL},
        {"Repetition",    10, PARAM_STRING_E,  NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;
    char                      max_boundary_buff[32];
    char                      tc_pg_buff[32];
    char                      repetitions_buff[32];
    const char               *na_str = "N/A";

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI Tele Histogram DB");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_tele_db_histogram_iter_get(NULL, NULL, NULL, NULL, &hist_count);

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Can't get histogram count statistic\n");
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "Total histogram entries:", &hist_count, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");

    dbg_utils_pprinter_table_headline_print(stream, hist_entry_table);

    map_item_p = cl_qmap_head(&histogram_map);
    while (cl_qmap_end(&histogram_map) != map_item_p) {        /* first stage. Print brief tele data */
        hist_entry_p = PARENT_STRUCT(map_item_p, tele_db_histogram_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        hist_db_data = &hist_entry_p->data;
        hist_id_item_p = PARENT_STRUCT(hist_entry_p->data.list_item, tele_id_item_t, list_item);

        hist_type = hist_db_data->tele_key.type;
        hist_id = hist_id_item_p->tele_id;

        if (hist_type == SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E) {
            hist_mode = hist_db_data->tele_attr.data.port_counter.mode;
            min_boundary = hist_db_data->tele_attr.data.port_counter.min_boundary;
            bin_size_resolution = hist_db_data->tele_attr.data.port_counter.bin_size_resolution;
            sample_time_resolution = hist_db_data->tele_attr.data.port_counter.sample_time_resolution;
            time = 1 << hist_db_data->tele_attr.data.port_counter.sample_time_resolution;
            log_port = hist_db_data->tele_key.key.port_counter.log_port;

            hist_entry_table[DBG_HIST_MAX_BOUNDERY_E].data = na_str;
            hist_entry_table[DBG_HIST_TC_PG_E].data = na_str;
            hist_entry_table[DBG_HIST_COUNTER_TYPE_E].data = sx_tele_histogram_port_counter_type_str(
                hist_db_data->tele_attr.data.port_counter.port_counter_type);
            hist_entry_table[DBG_HIST_CONTROL_E].data = sx_tele_histogram_port_counter_ctl_str(
                hist_db_data->tele_attr.data.port_counter.control);
            snprintf(repetitions_buff,
                     sizeof(repetitions_buff),
                     "%u",
                     hist_db_data->tele_attr.data.port_counter.repetition.number_of_repetitions);
            hist_entry_table[DBG_HIST_REPETITION_E].data = repetitions_buff;
        } else {
            hist_mode = hist_db_data->tele_attr.data.queue_depth.mode;
            min_boundary = hist_db_data->tele_attr.data.queue_depth.min_boundary;
            bin_size_resolution = hist_db_data->tele_attr.data.queue_depth.bin_size_resolution;
            sample_time_resolution = hist_db_data->tele_attr.data.queue_depth.sample_time_resolution;
            time = 1 << hist_db_data->tele_attr.data.queue_depth.sample_time_resolution;
            if (hist_mode == SX_TELE_HISTOGRAM_MODE_LINEAR_E) {
                max_boundary = min_boundary + 8 * (1 << bin_size_resolution);
            } else if (hist_mode == SX_TELE_HISTOGRAM_MODE_EXPONENT_E) {
                max_boundary = min_boundary + 255 * (1 << bin_size_resolution);
            }
            if (hist_type == SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E) {
                log_port = hist_db_data->tele_key.key.port_pg.log_port;
                tc_pg = hist_db_data->tele_key.key.port_pg.pg;
            } else {
                log_port = hist_db_data->tele_key.key.port_tc.log_port;
                tc_pg = hist_db_data->tele_key.key.port_tc.tc;
            }

            snprintf(max_boundary_buff, sizeof(max_boundary_buff), "%u", max_boundary);
            hist_entry_table[DBG_HIST_MAX_BOUNDERY_E].data = max_boundary_buff;
            snprintf(tc_pg_buff, sizeof(tc_pg_buff), "%u", tc_pg);
            hist_entry_table[DBG_HIST_TC_PG_E].data = tc_pg_buff;
            hist_entry_table[DBG_HIST_COUNTER_TYPE_E].data = na_str;
            hist_entry_table[DBG_HIST_CONTROL_E].data = na_str;
            hist_entry_table[DBG_HIST_REPETITION_E].data = na_str;
        }

        hist_entry_table[DBG_HIST_TYPE_E].data = sx_tele_histogram_type_str(hist_type);
        hist_entry_table[DBG_HIST_MODE_E].data = sx_tele_histogram_mode_str(hist_mode);

        dbg_utils_pprinter_table_data_line_print(stream, hist_entry_table);
    }

out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_db_bw_gauge_attributes_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    dbg_utils_table_columns_t tele_attr_entry_table[] = {
        {"alpha factor", 30, PARAM_UINT8_E, &g_gauge_config.alpha_factor},
        {"log time interval", 30, PARAM_UINT8_E, &g_gauge_config.log_time_interval},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "BW GAUGE ATTRIBUTES");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    dbg_utils_pprinter_print(stream, "\n");
    dbg_utils_pprinter_table_headline_print(stream, tele_attr_entry_table);
    dbg_utils_pprinter_table_data_line_print(stream, tele_attr_entry_table);

out:
    SX_LOG_EXIT();
    return;
}


void sdk_tele_db_latency_histogram_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_port_phy_id_t          port = 0;
    dbg_utils_table_columns_t hist_port_entry_table[] = {
        {"Port",          9, PARAM_UINT16_E, NULL},
        {"TCs number",   12, PARAM_UINT32_E, NULL},
        {"Min Boundary", 13, PARAM_UINT32_E, NULL},
        {"Mode",         12, PARAM_STRING_E, NULL},
        {"Resolution",   11, PARAM_UINT32_E, NULL},
        {NULL,            0, PARAM_LAST_E,   NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI Tele Latency Histogram DB");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, hist_port_entry_table);

    for (port = 1; port <= rm_resource_global.port_ext_num_max; port++) {
        hist_port_entry_table[DBG_LATENCY_HIST_PORT_E].data = &port;
        hist_port_entry_table[DBG_LATENCY_HIST_TC_NUM_E].data =
            &g_latency_histogram_port_tcs_config_p[port - 1].num_of_configured_tcs;
        hist_port_entry_table[DBG_LATENCY_HIST_MIN_BOUNDERY_E].data =
            &g_latency_histogram_port_tcs_config_p[port - 1].data.min_boundary;
        hist_port_entry_table[DBG_LATENCY_HIST_MODE_E].data = sx_tele_histogram_mode_str(
            g_latency_histogram_port_tcs_config_p[port - 1].data.mode);
        hist_port_entry_table[DBG_LATENCY_HIST_RESOLUTION_E].data =
            &g_latency_histogram_port_tcs_config_p[port - 1].data.sample_time_resolution;

        dbg_utils_pprinter_table_data_line_print(stream, hist_port_entry_table);
    }

out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_db_threshold_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t                  initialised = FALSE;
    cl_map_item_t             *map_item_p = NULL;
    tele_db_threshold_entry_t *thr_entry_p = NULL;
    tele_db_threshold_data_t  *thr_db_data = NULL;
    uint32_t                   threshold_low = 0;
    char                       dir_str[20];
    char                       mode_str[20];
    dbg_utils_table_columns_t  thr_entry_table[] = {
        {"Port", 10, PARAM_PORT_ID_E, NULL},
        {"Direction", 10, PARAM_STRING_E, &dir_str},
        {"TC / PG", 8, PARAM_UINT8_E, NULL},
        {"Mode", 14, PARAM_STRING_E, &mode_str},
        {"High Threshold", 15, PARAM_UINT32_E, NULL},
        {"Low Threshold", 15, PARAM_UINT32_E, &threshold_low},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                      *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI Tele Threshold DB");

    sdk_tele_impl_params_get(&initialised);
    if (FALSE == initialised) {
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, thr_entry_table);

    map_item_p = cl_qmap_head(&threshold_map);
    while (cl_qmap_end(&threshold_map) != map_item_p) {
        thr_entry_p = PARENT_STRUCT(map_item_p, tele_db_threshold_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        thr_db_data = &thr_entry_p->data;

        if (thr_db_data->key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            thr_entry_table[DBG_THR_PORT_E].data = &thr_db_data->key.key.port_tc.log_port;
            thr_entry_table[DBG_THR_TC_PG_E].data = &thr_db_data->key.key.port_tc.tc;
            strcpy(dir_str, "EGRESS");
        } else if (thr_db_data->key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            thr_entry_table[DBG_THR_PORT_E].data = &thr_db_data->key.key.port_pg.log_port;
            thr_entry_table[DBG_THR_TC_PG_E].data = &thr_db_data->key.key.port_pg.pg;
            strcpy(dir_str, "INGRESS");
        }

        if (thr_db_data->data.threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E) {
            thr_entry_table[DBG_THR_THRESHOLD_E].data = &thr_db_data->data.data.port_tc_threshold;
            strcpy(mode_str, "STATIC");
            threshold_low = 0;
        } else {
            thr_entry_table[DBG_THR_THRESHOLD_E].data = &thr_db_data->data.threshold_data.threshold_high;
            threshold_low = thr_db_data->data.threshold_data.threshold_low;
            if (thr_db_data->data.threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E) {
                strcpy(mode_str, "STATIC");
            } else {
                strcpy(mode_str, "PERCENTAGE");
            }
        }


        dbg_utils_pprinter_table_data_line_print(stream, thr_entry_table);
    }


out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_db_last_congestion_threshold_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t                                  initialised = FALSE;
    cl_map_item_t                             *map_item_p = NULL;
    const cl_map_item_t                       *map_end_p = NULL;
    tele_db_last_congestion_threshold_entry_t *thr_entry_p = NULL;
    sx_tele_threshold_data_t                  *thr_data = NULL;
    sx_tele_threshold_t                        threshold_low = 0;
    sx_tele_threshold_t                        threshold_high = 0;
    char                                       dir_str[20];
    char                                       mode_str[20];
    sx_port_log_id_t                           port_id = 0;
    uint8_t                                    cnt = 0;
    dbg_utils_table_columns_t                  thr_entry_table[] = {
        {"Port", 10, PARAM_PORT_ID_E, &port_id},
        {"Direction", 10, PARAM_STRING_E, &dir_str},
        {"TC/PG enabled cnt", 18, PARAM_UINT8_E, &cnt},
        {"Mode", 14, PARAM_STRING_E, &mode_str},
        {"High Threshold", 15, PARAM_UINT32_E, &threshold_high},
        {"Low Threshold", 15, PARAM_UINT32_E, &threshold_low},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                                      *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Tele Last Congestion Threshold");

    sdk_tele_impl_params_get(&initialised);
    if (FALSE == initialised) {
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, thr_entry_table);

    map_item_p = cl_qmap_head(&g_last_congestion_threshold_map);
    map_end_p = cl_qmap_end(&g_last_congestion_threshold_map);
    while (map_end_p != map_item_p) {
        thr_entry_p = PARENT_STRUCT(map_item_p, tele_db_last_congestion_threshold_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        thr_data = &thr_entry_p->congestion_data;
        port_id = thr_entry_p->log_port;
        cnt = thr_entry_p->cnt;

        if (thr_entry_p->key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
            strcpy(dir_str, "EGRESS");
        } else if (thr_entry_p->key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            strcpy(dir_str, "INGRESS");
        } else {
            /* Should not get here */
            SX_LOG_DBG("tele key type %s not supported\n", sx_tele_threshold_type_str(thr_entry_p->key_type));
        }

        if (thr_data->threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E) {
            threshold_high = thr_data->data.port_tc_threshold;
            strcpy(mode_str, "STATIC");
            threshold_low = 0;
        } else {
            threshold_high = thr_data->threshold_data.threshold_high;
            threshold_low = thr_data->threshold_data.threshold_low;
            if (thr_data->threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E) {
                strcpy(mode_str, "STATIC");
            } else {
                strcpy(mode_str, "PERCENTAGE");
            }
        }
        dbg_utils_pprinter_table_data_line_print(stream, thr_entry_table);
    }


out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_db_threshold_latency_key_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t                              initialised = FALSE;
    cl_map_item_t                         *map_item_p = NULL;
    const cl_map_item_t                   *end_item_p = NULL;
    tele_db_latency_threshold_key_entry_t *entry_p = NULL;
    uint32_t                               invalid_val = 0;
    dbg_utils_table_columns_t              entry_table[] = {
        {"Key type", 16, PARAM_STRING_E, NULL},
        {"Port", 10, PARAM_PORT_ID_E, NULL},
        {"TC", 8, PARAM_UINT8_E, NULL},
        {"SP", 8, PARAM_UINT8_E, NULL},
        {"High Threshold", 15, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                                  *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Latency Threshold Key DB");

    sdk_tele_impl_params_get(&initialised);
    if (FALSE == initialised) {
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, entry_table);

    map_item_p = cl_qmap_head(&g_latency_threshold_key_map);
    end_item_p = cl_qmap_end(&g_latency_threshold_key_map);
    while (end_item_p != map_item_p) {
        entry_p = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_key_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        entry_table[0].data = sx_tele_threshold_type_str(entry_p->key.key_type);
        if (entry_p->key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) {
            entry_table[1].data = &entry_p->key.key.port_tc.log_port;
            entry_table[2].data = &entry_p->key.key.port_tc.tc;
            entry_table[3].data = &invalid_val;
        } else if (entry_p->key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E) {
            entry_table[1].data = &invalid_val;
            entry_table[2].data = &invalid_val;
            entry_table[3].data = &entry_p->key.key.mc_sp.sp;
        }
        entry_table[4].data = &entry_p->data.threshold_data.threshold_high;

        dbg_utils_pprinter_table_data_line_print(stream, entry_table);
    }


out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_db_threshold_latency_data_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    cl_map_item_t                          *map_item_p = NULL;
    const cl_map_item_t                    *end_item_p = NULL;
    boolean_t                               initialised = FALSE;
    tele_db_latency_threshold_data_entry_t *entry_p = NULL;
    dbg_utils_table_columns_t               entry_table[] = {
        {"Latency ID", 15, PARAM_UINT8_E, NULL},
        {"High Threshold", 15, PARAM_UINT32_E, NULL},
        {"Ref count", 15, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                                   *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Latency Threshold Data DB");

    sdk_tele_impl_params_get(&initialised);
    if (FALSE == initialised) {
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, entry_table);

    map_item_p = cl_qmap_head(&g_latency_threshold_data_map);
    end_item_p = cl_qmap_end(&g_latency_threshold_data_map);
    while (end_item_p != map_item_p) {
        entry_p = PARENT_STRUCT(map_item_p, tele_db_latency_threshold_data_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        entry_table[0].data = &entry_p->latency_id;
        entry_table[1].data = &entry_p->data.threshold_data.threshold_high;
        entry_table[2].data = &entry_p->ref_count;

        dbg_utils_pprinter_table_data_line_print(stream, entry_table);
    }


out:
    SX_LOG_EXIT();
    return;
}

const char* get_tele_hash_sig_prof_name(char *name_buf, size_t name_size, void *hash_sig_prof_idx)
{
    snprintf(name_buf, name_size, "HASH Sig profile [%d]", *(sx_tele_hash_sig_prof_idx_int_t*)hash_sig_prof_idx);
    return name_buf;
}


sx_status_t sdk_tele_db_hash_sig_gp_register_ref_update(boolean_t                       is_inc,
                                                        sx_tele_hash_sig_prof_idx_int_t hash_sig_prof_idx,
                                                        sdk_tele_db_hash_sig_params_t  *tele_hash_sig_params_p,
                                                        sx_tele_hash_sig_field_t        hash_field)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_register_key_t reg_key;
    uint32_t          index = 0;
    ref_name_data_t   ref_name_data = {.print_func_p = get_tele_hash_sig_prof_name,
                                       .ref_data_p = &hash_sig_prof_idx,
                                       .data_size = sizeof(hash_sig_prof_idx)};

    SX_LOG_ENTER();

    if (SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(hash_field)) {
        SX_MEM_CLR(reg_key);
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
        reg_key.key.gp_reg.reg_id = SX_TELE_HASH_SIG_FIELD_GP_REGISTER_GET(hash_field);
        index = SX_TELE_HASH_SIG_FIELD_GP_REGISTER_INDEX_GET(hash_field);
        if (is_inc) {
            err = sdk_register_impl_ref_increase(reg_key, &ref_name_data, &tele_hash_sig_params_p->ref[index]);
        } else {
            err = sdk_register_impl_ref_decrease(reg_key, &tele_hash_sig_params_p->ref[index]);
        }
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to %s hash sig profile (%d) GP register [%u] reference, error: [%s]\n",
                       is_inc ? "increase" : "decrease",
                       hash_sig_prof_idx,
                       reg_key.key.gp_reg.reg_id,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_hash_sig_params_set(const sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                            const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                            const sx_tele_hash_sig_params_t          *hash_params_p,
                                            const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                            const uint32_t                            hash_field_enable_list_cnt,
                                            const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                            const uint32_t                            hash_field_list_cnt)
{
    sdk_tele_db_hash_sig_params_t *tele_hash_sig_params_p = NULL;
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       i = 0;

    SX_LOG_ENTER();

    tele_hash_sig_params_p = &g_sdk_tele_db_hash_sig[hash_sig_prof_idx];

    for (i = 0; i < hash_field_list_cnt; i++) {
        if (SX_TELE_HASH_SIG_IS_FIELD_CUSTOM_BYTE(hash_field_list_p[i])) {
            err = flex_acl_keys_custom_bytes_set_lock_unlock((sx_acl_key_t)(hash_field_list_p[i]),
                                                             SX_ACCESS_CMD_DELETE, FALSE);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }
        } else if (SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(hash_field_list_p[i])) {
            err = sdk_tele_db_hash_sig_gp_register_ref_update(FALSE,
                                                              hash_sig_prof_idx,
                                                              tele_hash_sig_params_p,
                                                              tele_hash_sig_params_p->fields[i]);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }
        }
    }

    SX_MEM_CPY_P(&tele_hash_sig_params_p->hash_params, hash_params_p);

    if (hash_sig_prof_class_p != NULL) {
        SX_MEM_CPY_P(&tele_hash_sig_params_p->hash_sig_prof_classifier, hash_sig_prof_class_p);
    }

    tele_hash_sig_params_p->enables_cnt = hash_field_enable_list_cnt;
    tele_hash_sig_params_p->fields_cnt = hash_field_list_cnt;

    SX_MEM_CPY_ARRAY(tele_hash_sig_params_p->enables, hash_field_enable_list_p,
                     hash_field_enable_list_cnt, sx_tele_hash_sig_field_enable_t);
    SX_MEM_CPY_ARRAY(tele_hash_sig_params_p->fields, hash_field_list_p,
                     hash_field_list_cnt, sx_tele_hash_sig_field_t);

    for (i = 0; i < hash_field_list_cnt; i++) {
        if (SX_TELE_HASH_SIG_IS_FIELD_CUSTOM_BYTE(tele_hash_sig_params_p->fields[i])) {
            err = flex_acl_keys_custom_bytes_set_lock_unlock((sx_acl_key_t)(hash_field_list_p[i]),
                                                             SX_ACCESS_CMD_CREATE,
                                                             FALSE);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }
        } else if (SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(tele_hash_sig_params_p->fields[i])) {
            err = sdk_tele_db_hash_sig_gp_register_ref_update(TRUE,
                                                              hash_sig_prof_idx,
                                                              tele_hash_sig_params_p,
                                                              tele_hash_sig_params_p->fields[i]);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_hash_sig_params_get(sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                            sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_classifier_p,
                                            sx_tele_hash_sig_params_t          *hash_params_p,
                                            sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                            uint32_t                           *hash_field_enable_list_cnt_p,
                                            sx_tele_hash_sig_field_t           *hash_field_list_p,
                                            uint32_t                           *hash_field_list_cnt_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sdk_tele_db_hash_sig_params_t *tele_hash_sig_params_p;

    SX_LOG_ENTER();

    CL_ASSERT(*hash_field_list_cnt_p <= SX_TELE_HASH_SIG_FIELDS_NUM);
    CL_ASSERT(*hash_field_enable_list_cnt_p <= SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);

    if (*hash_field_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_NUM) {
        SX_LOG(SX_LOG_ERROR, "Hash field list Count is not in range [%d]\n", *hash_field_list_cnt_p);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (*hash_field_enable_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        SX_LOG(SX_LOG_ERROR, "Hash field Enable list Count is not in range [%d]\n", *hash_field_enable_list_cnt_p);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    tele_hash_sig_params_p = &g_sdk_tele_db_hash_sig[hash_sig_prof_idx];

    SX_MEM_CPY_P(hash_params_p, &tele_hash_sig_params_p->hash_params);

    /* classifier should not be returned for default profile */
    if (hash_sig_prof_classifier_p != NULL) {
        SX_MEM_CPY_P(hash_sig_prof_classifier_p, &tele_hash_sig_params_p->hash_sig_prof_classifier);
    }

    if (0 == *hash_field_enable_list_cnt_p) {
        SX_LOG_DBG("Get Hash Signature Params of profile %d from DB, Get only fields enables count\n",
                   hash_sig_prof_idx);
        *hash_field_enable_list_cnt_p = tele_hash_sig_params_p->enables_cnt;
    } else {
        *hash_field_enable_list_cnt_p = MIN(tele_hash_sig_params_p->enables_cnt, *hash_field_enable_list_cnt_p);
        SX_MEM_CPY_ARRAY(hash_field_enable_list_p, tele_hash_sig_params_p->enables,
                         *hash_field_enable_list_cnt_p, sx_tele_hash_sig_field_enable_t);
    }

    if (0 == *hash_field_list_cnt_p) {
        SX_LOG_DBG("Get Hash Signature Params of profile %d from DB, Get only fields count\n", hash_sig_prof_idx);
        *hash_field_list_cnt_p = tele_hash_sig_params_p->fields_cnt;
    } else {
        *hash_field_list_cnt_p = MIN(tele_hash_sig_params_p->fields_cnt, *hash_field_list_cnt_p);
        SX_MEM_CPY_ARRAY(hash_field_list_p, tele_hash_sig_params_p->fields,
                         *hash_field_list_cnt_p, sx_tele_hash_sig_field_t);
    }
out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_db_hash_sig_classifiers_debug_dump(dbg_dump_params_t                  *dbg_dump_params_p,
                                                 sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_classifier_p)
{
    dbg_utils_table_columns_t classifiers_dump_columns[] = {
        { "Inner L2 Type",    14,   PARAM_HEX_E,       NULL     },     /* 7 */
        { "L3 Type",          14,   PARAM_HEX_E,       NULL     },     /* 8 */
        { "Inner L3 Type",    14,   PARAM_HEX_E,       NULL     },     /* 9 */
        { "IP Fragment",      14,   PARAM_HEX_E,       NULL     },     /* 10 */
        { "Inner IP Frag",    14,   PARAM_HEX_E,       NULL     },     /* 11 */
        { "L4 Type",          14,   PARAM_HEX_E,       NULL     },     /* 12 */
        { "Inner L4 type",    14,   PARAM_HEX_E,       NULL     },     /* 13 */
        { "Tunnel Type",      14,   PARAM_HEX_E,       NULL     },     /* 14 */
        { "FPP",              14,   PARAM_HEX_E,       NULL     },     /* 15 */
        { "Inner FPP",        14,   PARAM_HEX_E,       NULL     },     /* 16 */
        {NULL, 0, 0, NULL}
    };
    char                      ports_list_buf[SX_TELE_DBG_DUMP_PORT_LIST_BUF_SIZE] = {0};
    dbg_utils_table_columns_t ports_dump_columns[] = {
        { "Ports",      100,  PARAM_EXT_STRING_E,  ports_list_buf},
        {NULL, 0, 0, NULL}
    };
    char                      port_buf[SX_TELE_DBG_DUMP_PORT_LIST_BUF_SIZE] = {0};
    uint32_t                  space_in_buf, port_str_len, i;
    FILE                     *stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_secondary_header_print(stream, "Hash Signature classifiers:");
    dbg_utils_pprinter_table_headline_print(stream, classifiers_dump_columns);
    classifiers_dump_columns[0].data = &hash_sig_prof_classifier_p->inner_l2_type_classifiers;
    classifiers_dump_columns[1].data = &hash_sig_prof_classifier_p->l3_type_classifiers;
    classifiers_dump_columns[2].data = &hash_sig_prof_classifier_p->inner_l3_type_classifiers;
    classifiers_dump_columns[3].data = &hash_sig_prof_classifier_p->ip_fragment_classifiers;
    classifiers_dump_columns[4].data = &hash_sig_prof_classifier_p->inner_ip_fragment_classifiers;
    classifiers_dump_columns[5].data = &hash_sig_prof_classifier_p->l4_type_classifiers;
    classifiers_dump_columns[6].data = &hash_sig_prof_classifier_p->inner_l4_type_classifiers;
    classifiers_dump_columns[7].data = &hash_sig_prof_classifier_p->tunnel_type_classifiers;
    classifiers_dump_columns[8].data = &hash_sig_prof_classifier_p->fpp_classifiers;
    classifiers_dump_columns[9].data = &hash_sig_prof_classifier_p->inner_fpp_classifiers;
    dbg_utils_pprinter_table_data_line_print(stream, classifiers_dump_columns);

    dbg_utils_pprinter_secondary_header_print(stream, "Hash Signature port classifiers:");
    dbg_utils_pprinter_table_headline_print(stream, ports_dump_columns);
    space_in_buf = sizeof(ports_list_buf) - 1;
    for (i = 0; i < hash_sig_prof_classifier_p->ports_classifiers.port_cnt; i++) {
        port_str_len = snprintf(port_buf, sizeof(port_buf) - 1, "0x%x,",
                                hash_sig_prof_classifier_p->ports_classifiers.port_list[i]);
        if (port_str_len > space_in_buf) {
            dbg_utils_pprinter_table_data_line_print(stream, ports_dump_columns);
            SX_MEM_CLR_BUF(ports_list_buf, sizeof(ports_list_buf));
        }
        strncat(ports_list_buf, port_buf,
                sizeof(ports_list_buf) - strlen(ports_list_buf) - 1);
        space_in_buf = sizeof(ports_list_buf) - strlen(ports_list_buf) - 1;
    }

    if (strlen(ports_list_buf)) {
        dbg_utils_pprinter_table_data_line_print(stream, ports_dump_columns);
    }

    dbg_utils_pprinter_counter_with_level_print(stream, "Hash Signature ports classifiers count",
                                                hash_sig_prof_classifier_p->ports_classifiers.port_cnt,
                                                DBG_UTILS_LEVEL_HEADER_E);
}

void sdk_tele_db_hash_sig_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    dbg_utils_table_columns_t hash_sig_profile_entry_table[] = {
        {"Profile ID",  10, PARAM_UINT16_E, NULL},
        {"Sym outer",   10, PARAM_BOOL_E, NULL},
        {"Sym inner",   10, PARAM_BOOL_E, NULL},
        {"Sym cbset",   10, PARAM_BOOL_E, NULL},
        {"Is default",  10, PARAM_BOOL_E, NULL},
        {NULL,           0, PARAM_LAST_E,   NULL}
    };
    FILE                     *stream = NULL;
    uint32_t                  profile_id, field_id, hdr_enable_idx;
    boolean_t                 is_hash_sig_supported, is_default;

    SX_LOG_ENTER();

    err = sdk_tele_impl_is_hash_sig_supported(&is_hash_sig_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_hash_sig_supported == FALSE) {
        goto out;
    }

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI Tele Hash Signature DB");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    for (profile_id = SX_TELE_HASH_SIG_PROF_INTERNAL_MIN;
         profile_id <= SX_TELE_HASH_SIG_PROF_INTERNAL_MAX;
         profile_id++) {
        hash_sig_profile_entry_table[DBG_HASH_SIG_PROFILE_ID_E].data = &profile_id;
        hash_sig_profile_entry_table[DBG_HASH_SIG_GSH_OUTER_E].data =
            &g_sdk_tele_db_hash_sig[profile_id].hash_params.symmetric_hash_outer;
        hash_sig_profile_entry_table[DBG_HASH_SIG_GSH_INNER_E].data =
            &g_sdk_tele_db_hash_sig[profile_id].hash_params.symmetric_hash_inner;
        hash_sig_profile_entry_table[DBG_HASH_SIG_GSH_CBSET_E].data =
            &g_sdk_tele_db_hash_sig[profile_id].hash_params.symmetric_hash_gp_reg;

        is_default = profile_id == SX_TELE_HASH_SIG_PROF_DEFAULT ? TRUE : FALSE;
        hash_sig_profile_entry_table[DBG_HASH_SIG_IS_DEFAULT].data = &is_default;

        dbg_utils_pprinter_table_headline_print(stream, hash_sig_profile_entry_table);
        dbg_utils_pprinter_table_data_line_print(stream, hash_sig_profile_entry_table);

        /* Headers enables */
        dbg_utils_pprinter_secondary_header_print(stream, "Hash Signature Headers enables ID %d:", profile_id);
        for (hdr_enable_idx = 0; hdr_enable_idx < g_sdk_tele_db_hash_sig[profile_id].enables_cnt; hdr_enable_idx++) {
            dbg_utils_pprinter_field_print(stream,
                                           /*sdk_hash_sig_hash_enable_to_str(g_sdk_tele_db_hash_sig[profile_id].enables[hdr_enable_idx]), */
                                           sx_tele_hash_sig_field_enable_str(g_sdk_tele_db_hash_sig[profile_id].enables
                                                                             [
                                                                                 hdr_enable_idx]),
                                           "", PARAM_STRING_E);
        }
        dbg_utils_pprinter_counter_print(stream,
                                         "Hash Signature Headers enables count",
                                         g_sdk_tele_db_hash_sig[profile_id].enables_cnt);

        /* Fields enables */
        dbg_utils_pprinter_secondary_header_print(stream, "Hash Signature fields ID %d:", profile_id);
        for (field_id = 0; field_id < g_sdk_tele_db_hash_sig[profile_id].fields_cnt; field_id++) {
            dbg_utils_pprinter_field_print(stream,
                                           /*sdk_hash_sig_hash_field_to_str(g_sdk_tele_db_hash_sig[profile_id].fields[field_id]), */
                                           sx_tele_hash_sig_field_str(g_sdk_tele_db_hash_sig[profile_id].fields[
                                                                          field_id
                                                                      ]),
                                           "", PARAM_STRING_E);
        }
        dbg_utils_pprinter_counter_print(stream,
                                         "Hash Signature fields count",
                                         g_sdk_tele_db_hash_sig[profile_id].fields_cnt);

        /* Classifiers */
        dbg_utils_pprinter_user_defined_header_print(stream,
                                                     DBG_UTILS_LEVEL_USER_DEFINED_1_E,
                                                     "Hash Signature classifiers ID %d:",
                                                     profile_id);
        sdk_tele_db_hash_sig_classifiers_debug_dump(dbg_dump_params_p,
                                                    &g_sdk_tele_db_hash_sig[profile_id].hash_sig_prof_classifier);
    }


out:
    SX_LOG_EXIT();
    return;
}

sx_status_t sdk_tele_db_tac_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   tac_trap_group_map_initialized = FALSE;
    cl_status_t cl_status;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == TRUE) {
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_ERR("TAC DB init failed , err = %s\n",  sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(g_tele_tac_db);

    /* init sw header default dev id */
    g_tele_tac_db.sw_header_info.uid_device_id = TAC_MSG_SW_HDR_DEFAULT_DEV_ID;

    cl_status = CL_QPOOL_INIT(&g_tele_tac_db.tac_trap_group_map_pool, SX_TRAP_GROUP_MAX + 1, SX_TRAP_GROUP_MAX + 1, 0,
                              sizeof(tele_db_tac_trap_group_entry_t), NULL, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate tac_trap_group_map_pool pool.\n");
        goto out;
    }
    cl_qmap_init(&g_tele_tac_db.tac_trap_group_map);
    tac_trap_group_map_initialized = TRUE;

    g_tele_tac_db_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (tac_trap_group_map_initialized) {
            CL_QPOOL_DESTROY(&g_tele_tac_db.tac_trap_group_map_pool);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_deinit(boolean_t is_forced)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_map_item_t                  *next_map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    tele_db_tac_trap_group_entry_t *tac_trap_group_entry_p;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized != TRUE) {
        if (FALSE == is_forced) {
            err = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("TAC DB deinit failed , err = %s\n",  sx_status_str(err));
        }
        /* return success on force deinit if not initialized */
        goto out;
    }

    /* deinit DB */
    /* Clear TAC trap group tele DB */
    map_item_p = cl_qmap_head(&g_tele_tac_db.tac_trap_group_map);
    map_end_p = cl_qmap_end(&g_tele_tac_db.tac_trap_group_map);
    if ((FALSE == is_forced) && (map_item_p != map_end_p)) {
        err = SX_STATUS_DB_NOT_EMPTY;
        SX_LOG_ERR("Failed to delete tac trap group map, there are still entries allocated\n");
        goto out;
    }

    while (map_item_p != map_end_p) {
        tac_trap_group_entry_p = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
        next_map_item_p = cl_qmap_next(map_item_p);
        cl_qmap_remove_item(&g_tele_tac_db.tac_trap_group_map, map_item_p);
        cl_qpool_put(&g_tele_tac_db.tac_trap_group_map_pool, &tac_trap_group_entry_p->pool_item);
        map_item_p = next_map_item_p;
    }

    CL_QPOOL_DESTROY(&g_tele_tac_db.tac_trap_group_map_pool);

    g_tele_tac_db_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_tac_sw_header_set(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    g_tele_tac_db.sw_header_info = *tac_sw_header_info_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_sw_header_get(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    *tac_sw_header_info_p = g_tele_tac_db.sw_header_info;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_debug_dump_tac_trap_group_db(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_map_item_t                  *next_map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    tele_db_tac_trap_group_entry_t *tac_trap_group_entry_p;
    tele_db_tac_trap_group_data_t   data;
    dbg_utils_table_columns_t       tac_trap_group_table[] = {
        {"Trap Group",          16, PARAM_UINT16_E, &data.trap_group},
        {"Span Session Valid",  20, PARAM_BOOL_E, &data.tac_trap_group_info.span_session_id_valid},
        {"Span Session",        16, PARAM_UINT16_E, &data.tac_trap_group_info.span_session_id},
        {"HW Trap Group Valid", 20, PARAM_BOOL_E, &data.tac_trap_group_info.hw_trap_group_valid},
        {"HW Trap Group",       16, PARAM_UINT16_E, &data.tac_trap_group_info.hw_trap_group},
        {"TAC connected",       20, PARAM_BOOL_E, &data.tac_trap_group_info.tac_connected},
        {"GC handle Valid",     20, PARAM_BOOL_E, &data.tac_trap_group_info.gc_handle_valid},

        {NULL,           0, PARAM_LAST_E,   NULL}
    };
    FILE                           *stream = NULL;

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_secondary_header_print(stream, "TAC Trap Group DB:");

    /* deinit DB */
    /* Clear TAC trap group tele DB */
    map_item_p = cl_qmap_head(&g_tele_tac_db.tac_trap_group_map);
    map_end_p = cl_qmap_end(&g_tele_tac_db.tac_trap_group_map);
    if (map_item_p == map_end_p) {
        /* DB is empty goto out */
        goto out;
    }

    dbg_utils_pprinter_table_headline_print(stream, tac_trap_group_table);
    while (map_item_p != map_end_p) {
        tac_trap_group_entry_p = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
        data = tac_trap_group_entry_p->data;
        dbg_utils_pprinter_table_data_line_print(stream, tac_trap_group_table);
        next_map_item_p = cl_qmap_next(map_item_p);
        map_item_p = next_map_item_p;
    }

out:
    SX_LOG_EXIT();
    return err;
}


void sdk_tele_db_tac_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    dbg_utils_table_columns_t sw_header_info_table[] = {
        {"UID Device ID",  16, PARAM_HEX_E, &g_tele_tac_db.sw_header_info.uid_device_id},
        {"Max Lifetime",   10, PARAM_UINT16_E, &g_tele_tac_db.sw_header_info.max_lifetime},
        {NULL,           0, PARAM_LAST_E,   NULL}
    };
    FILE                     *stream = NULL;
    boolean_t                 is_tac_supported;

    SX_LOG_ENTER();

    err = sdk_tele_impl_is_tac_supported(&is_tac_supported);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (is_tac_supported == FALSE) {
        goto out;
    }

    if (g_tele_tac_db_initialized == FALSE) {
        goto out;
    }

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI Tele TAC DB");

    dbg_utils_pprinter_secondary_header_print(stream, "SW Header Info:");
    dbg_utils_pprinter_table_headline_print(stream, sw_header_info_table);
    dbg_utils_pprinter_table_data_line_print(stream, sw_header_info_table);

    sdk_tele_db_tac_debug_dump_tac_trap_group_db(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
    return;
}

sx_status_t sdk_tele_db_tac_trap_group_map_add(sx_trap_group_t                trap_group,
                                               tele_db_tac_trap_group_info_t *tac_trap_group_info_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_pool_item_t                 *pool_item = NULL;
    tele_db_tac_trap_group_entry_t *entry = NULL;
    uint64_t                        key;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    /* prepare an item for tac trap group map */
    pool_item = cl_qpool_get(&(g_tele_tac_db.tac_trap_group_map_pool));
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_NOTICE, "Could not get free tac trap group item from pool.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    entry = PARENT_STRUCT(pool_item, tele_db_tac_trap_group_entry_t, pool_item);
    SX_MEM_CLR(entry->data.tac_trap_group_info);
    entry->data.trap_group = trap_group;

    if (tac_trap_group_info_p != NULL) {
        if (tac_trap_group_info_p->hw_trap_group_valid == TRUE) {
            entry->data.tac_trap_group_info.hw_trap_group_valid = TRUE;
            entry->data.tac_trap_group_info.hw_trap_group =
                tac_trap_group_info_p->hw_trap_group;
        }

        if (tac_trap_group_info_p->span_session_id_valid == TRUE) {
            entry->data.tac_trap_group_info.span_session_id_valid = TRUE;
            entry->data.tac_trap_group_info.span_session_id =
                tac_trap_group_info_p->span_session_id;
            entry->data.tac_trap_group_info.tac_connected =
                entry->data.tac_trap_group_info.span_session_id_valid;
        }
    }

    key = trap_group;
    cl_qmap_insert(&(g_tele_tac_db.tac_trap_group_map), key, &(entry->map_item));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_trap_group_map_delete(sx_trap_group_t trap_group)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint64_t                        key = 0;
    tele_db_tac_trap_group_entry_t *entry = NULL;
    cl_map_item_t                  *map_item_p = NULL;
    const cl_map_item_t            *map_end = NULL;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    key = trap_group;
    map_item_p = cl_qmap_remove(&(g_tele_tac_db.tac_trap_group_map), key);
    map_end = cl_qmap_end(&(g_tele_tac_db.tac_trap_group_map));
    if (map_item_p == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR,
               "g_tele_tac_db.tac_trap_group_map delete failed. Could not find entry trap_group 0x%x in tac trap group map\n",
               trap_group);
        goto out;
    }

    entry = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
    SX_MEM_CLR(entry->data);

    cl_qpool_put(&(g_tele_tac_db.tac_trap_group_map_pool), &(entry->pool_item));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_trap_group_map_get(sx_trap_group_t trap_group, tele_db_tac_trap_group_data_t *data_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint64_t                        key = 0;
    tele_db_tac_trap_group_entry_t *entry = NULL;
    cl_map_item_t                  *map_item_p = NULL;
    const cl_map_item_t            *map_end = NULL;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    key = trap_group;
    map_item_p = cl_qmap_get(&(g_tele_tac_db.tac_trap_group_map), key);
    map_end = cl_qmap_end(&(g_tele_tac_db.tac_trap_group_map));
    if (map_item_p == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_INFO,
               "g_tele_tac_db.tac_trap_group_map delete failed. Could not find entry trap_group 0x%x in tac trap group map\n",
               trap_group);
        goto out;
    }

    entry = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
    *data_p = entry->data;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_tac_trap_group_map_set(tele_db_tac_trap_group_info_mask_e mask,
                                               sx_trap_group_t                    trap_group,
                                               tele_db_tac_trap_group_data_t     *data_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint64_t                        key = 0;
    tele_db_tac_trap_group_entry_t *entry = NULL;
    cl_map_item_t                  *map_item_p = NULL;
    const cl_map_item_t            *map_end = NULL;

    SX_LOG_ENTER();

    if (g_tele_tac_db_initialized == FALSE) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("TAC DB isn't initialized , err = %s\n",  sx_status_str(err));
        goto out;
    }

    key = trap_group;
    map_item_p = cl_qmap_get(&(g_tele_tac_db.tac_trap_group_map), key);
    map_end = cl_qmap_end(&(g_tele_tac_db.tac_trap_group_map));
    if (map_item_p == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR,
               "g_tele_tac_db.tac_trap_group_map delete failed. Could not find entry trap_group 0x%x in tac trap group map\n",
               trap_group);
        goto out;
    }

    entry = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);

    if (mask & TELE_DB_TAC_TRAP_GROUP_INFO_MASK_HW_TRAP_GROUP) {
        entry->data.tac_trap_group_info.hw_trap_group_valid = data_p->tac_trap_group_info.hw_trap_group_valid;
        entry->data.tac_trap_group_info.hw_trap_group = data_p->tac_trap_group_info.hw_trap_group;
    }

    if (mask & TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID) {
        entry->data.tac_trap_group_info.span_session_id_valid = data_p->tac_trap_group_info.span_session_id_valid;
        entry->data.tac_trap_group_info.span_session_id = data_p->tac_trap_group_info.span_session_id;

        /* if SPAN session id is valid then TAC is enabled */
        entry->data.tac_trap_group_info.tac_connected = entry->data.tac_trap_group_info.span_session_id_valid;
    }

    if (mask & TELE_DB_TAC_TRAP_GROUP_INFO_MASK_GC_HANDLE) {
        entry->data.tac_trap_group_info.gc_handle_valid = data_p->tac_trap_group_info.gc_handle_valid;
        entry->data.tac_trap_group_info.gc_handle = data_p->tac_trap_group_info.gc_handle;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_tac_trap_group_foreach(tele_db_tac_trap_group_db_update_pfn_t func, void *param_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_map_item_t                  *next_map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    tele_db_tac_trap_group_entry_t *tac_trap_group_entry_p;
    tele_db_tac_trap_group_data_t   data;

    SX_LOG_ENTER();

    /* Clear TAC trap group tele DB */
    map_item_p = cl_qmap_head(&g_tele_tac_db.tac_trap_group_map);
    map_end_p = cl_qmap_end(&g_tele_tac_db.tac_trap_group_map);
    if (map_item_p == map_end_p) {
        /* DB is empty goto out */
        goto out;
    }

    while (map_item_p != map_end_p) {
        tac_trap_group_entry_p = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
        data = tac_trap_group_entry_p->data;
        err = func(data.trap_group, param_p);
        next_map_item_p = cl_qmap_next(map_item_p);
        map_item_p = next_map_item_p;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_fill_stats_with_tac_trap_groups(sx_tele_tac_statistics_t *tac_stat_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_map_item_t                  *next_map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    tele_db_tac_trap_group_entry_t *tac_trap_group_entry_p;
    tele_db_tac_trap_group_data_t   data;

    SX_LOG_ENTER();

    SX_MEM_CLR_P(tac_stat_p);

    /* Clear TAC trap group tele DB */
    map_item_p = cl_qmap_head(&g_tele_tac_db.tac_trap_group_map);
    map_end_p = cl_qmap_end(&g_tele_tac_db.tac_trap_group_map);
    if (map_item_p == map_end_p) {
        /* DB is empty goto out */
        goto out;
    }

    while (map_item_p != map_end_p) {
        tac_trap_group_entry_p = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
        data = tac_trap_group_entry_p->data;

        /* in case TAC capable Trap Group was added but it wasn't connected to TAC yet */
        if ((data.tac_trap_group_info.tac_connected == FALSE) ||
            data.tac_trap_group_info.gc_handle_valid) {
            next_map_item_p = cl_qmap_next(map_item_p);
            map_item_p = next_map_item_p;
            continue;
        }

        tac_stat_p->trap_group_tac_statistics[tac_stat_p->trap_group_tac_statistics_cnt].trap_group = data.trap_group;
        tac_stat_p->trap_group_tac_statistics_cnt++;

        if (tac_stat_p->trap_group_tac_statistics_cnt >= SX_TRAP_GROUP_MAX) {
            SX_LOG(SX_LOG_ERROR,
                   "get_trap_group_all failed. number of TAC trap groups exceed MAX number of Trap Groups.\n");
            goto out;
        }

        next_map_item_p = cl_qmap_next(map_item_p);
        map_item_p = next_map_item_p;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_db_tac_connected_trap_group_count_get(uint32_t *tac_trap_group_count_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_map_item_t                  *next_map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    tele_db_tac_trap_group_entry_t *tac_trap_group_entry_p;
    tele_db_tac_trap_group_data_t   data;
    uint32_t                        tac_trap_group_count = 0;

    SX_LOG_ENTER();

    *tac_trap_group_count_p = 0;

    /* Clear TAC trap group tele DB */
    map_item_p = cl_qmap_head(&g_tele_tac_db.tac_trap_group_map);
    map_end_p = cl_qmap_end(&g_tele_tac_db.tac_trap_group_map);
    if (map_item_p == map_end_p) {
        /* DB is empty goto out */
        goto out;
    }

    while (map_item_p != map_end_p) {
        tac_trap_group_entry_p = PARENT_STRUCT(map_item_p, tele_db_tac_trap_group_entry_t, map_item);
        data = tac_trap_group_entry_p->data;

        /* in case TAC capable Trap Group was added but it wasn't connected to TAC yet */
        if ((data.tac_trap_group_info.tac_connected == TRUE) &&
            (data.tac_trap_group_info.gc_handle_valid == FALSE)) {
            tac_trap_group_count++;
        }

        next_map_item_p = cl_qmap_next(map_item_p);
        map_item_p = next_map_item_p;
    }

    *tac_trap_group_count_p = tac_trap_group_count;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_port_bw_gauge_set(const sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    g_gauge_config.alpha_factor = gauge_config_p->alpha_factor;
    g_gauge_config.log_time_interval = gauge_config_p->log_time_interval;

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_db_port_bw_gauge_get(sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    gauge_config_p->alpha_factor = g_gauge_config.alpha_factor;
    gauge_config_p->log_time_interval = g_gauge_config.log_time_interval;

    SX_LOG_EXIT();
    return err;
}
