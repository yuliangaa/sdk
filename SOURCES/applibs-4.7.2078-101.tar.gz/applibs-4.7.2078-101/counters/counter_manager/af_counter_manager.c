/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ AF_COUNTER_MANAGER

#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <resource_manager/resource_manager.h>
#include <sx/utils/gbin_allocator.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxdev.h>
#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_status_convertor.h>
#include <sx/sdk/sx_strings.h>
#include <utils/sx_mem.h>
#include <utils/utils.h>
#include <complib/sx_log.h>
#include <complib/cl_types_osd.h>
#include <complib/cl_qmap.h>
#include <complib/cl_qlist.h>
#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>

#include "af_counter_manager.h"
#include "sx_reg_bulk/sx_reg_bulk.h"

/************************************************
 *  Local Defines
 ***********************************************/
#define AFCM_COUNTERS_MAX            400                /* In the second phase we will enable relocation and allow more counters to allocate */
#define AFCM_COUNTER_LID_INVALID     (0x7FFFF)
#define AFCM_BA_RELOCATION_THRESHOLD 12
#define AFCM_BA_RELOCATION_COUNT     5
#define AFCM_BA_GROUP_TYPE_FREE      0
#define AFCM_BA_GROUP_TYPE_ACCUFLOW  1

/************************************************
 *  Local Macros
 ***********************************************/
#define AFCM_MODULE_INIT_CHECK(sx_status)                                      \
    do {                                                                       \
        if (afcm_init_done_g != TRUE) {                                        \
            SX_LOG_ERR("Accumulated Counters Manager is not initialized. \n"); \
            sx_status = SX_STATUS_MODULE_UNINITIALIZED;                        \
            goto out;                                                          \
        }                                                                      \
    } while (0)

#define AFCM_COUNTER_TYPE_CHECK(lid, sx_status)                            \
    do {                                                                   \
        if ((CM_LID_BANK_TYPE_GET(lid) != CM_ACCUFLOW_COUNTERS_BANKS_E) || \
            (lid == AFCM_COUNTER_LID_INVALID)) {                           \
            SX_LOG_ERR("LID is invalid! \n");                              \
            sx_status = SX_STATUS_PARAM_ERROR;                             \
            goto out;                                                      \
        }                                                                  \
    } while (0)

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct af_counter_entry {
    cl_pool_item_t  af_counters_pool_item;
    cl_map_item_t   af_counters_qmap_by_cm_lid_item;
    cl_map_item_t   af_counters_qmap_by_ba_lid_item;
    cm_logical_id_t af_counter_id;
    ba_logical_id_t ba_logical_id;
} af_counter_entry_t;

typedef struct af_counters_manager_db {
    sxd_handle  device_handle;
    ba_handle_t af_ba_handle;
    ba_group_t *af_groups_p;
    uint16_t    af_total_groups_cnt;
    uint16_t    af_free_groups_cnt;

    /* helper for LID generator */
    uint32_t af_counters_allocated;

    /* map/pool of af_counter_entry_t objects */
    cl_qmap_t  af_counters_qmap_by_cm_lid;
    cl_qmap_t  af_counters_qmap_by_ba_lid;
    cl_qpool_t af_counters_qpool;
} af_counters_manager_db_t;

typedef struct afcm_forced_relocation_info {
    cm_logical_id_t relocated_lid;
    ba_index_t      ba_index;
    ba_index_t      new_ba_index;
    uint32_t        cntx;
} afcm_forced_relocation_info_t;


/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t rm_resource_global;

static af_counters_manager_db_t      afcm_db_g;
static boolean_t                     afcm_init_done_g = FALSE;
static afcm_cb_relocate_t            afcm_relocate_cb_g = NULL;
static afcm_forced_relocation_info_t afcm_forced_relocation_info_g;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local Function declarations
 ***********************************************/
static sx_status_t __afcm_db_init(uint32_t flow_counter_accumulated_type_max_number);
static sx_status_t __afcm_db_deinit(void);
static sx_status_t __afcm_kernel_init(uint32_t flow_counter_accumulated_type_max_number);
static sx_status_t __afcm_kernel_deinit(void);
static sx_status_t __afcm_counters_mapping_prm_idx_get(ba_logical_id_t ba_logical_id,
                                                       uint32_t        offset,
                                                       uint32_t       *prm_idx_p);
static sx_status_t __afcm_db_counter_entry_by_cm_lid_get(cm_logical_id_t      lid,
                                                         af_counter_entry_t **af_counter_entry_p);
static sx_status_t __afcm_db_counter_entry_by_ba_lid_get(ba_logical_id_t      lid,
                                                         af_counter_entry_t **af_counter_entry_p);
static sx_status_t __afcm_db_counter_entry_remove(cm_logical_id_t lid);
static sx_status_t __afcm_db_counter_entry_add(cm_type_e type, uint32_t size, cm_logical_id_t *lid_p);
static sx_status_t __afcm_counters_manager_ba_client_init(void);
static sx_status_t __afcm_counters_manager_ba_client_deinit(void);
static cl_status_t __afcm_counters_pool_init_cb(void *const p_object, void *context,
                                                cl_pool_item_t **const pp_pool_item);
static sx_status_t __afcm_ioctl(ku_accuflow_counters_params_t *data_p);
static sx_status_t __afcm_counter_get(uint32_t prm_idx, sx_flow_counter_set_t *counters_values_p);
static sx_status_t __afcm_open_local_device(void);
static sx_status_t __afcm_close_local_device(void);
static sx_status_t __afcm_hal_hw_type(cm_type_e type, uint8_t  *hw_type_p,
                                      uint32_t *hw_len_p, uint32_t *ba_type_p);
static inline boolean_t __afcm_counter_hw_id_check(ba_index_t hw_id);
static inline sx_status_t __afcm_counter_clear(uint32_t prm_idx, uint32_t num_cntr);
static inline sx_status_t __afcm_counter_kernel_alloc(uint32_t prm_idx, uint32_t num_of_counters);
static inline sx_status_t __afcm_counter_kernel_move(uint32_t old_prm_idx,
                                                     uint32_t new_prm_idx,
                                                     uint32_t num_of_counters);

/**
 * Handle group allocation requests from BA
 *
 * @param[in] handle - Must match handle returned by client open request
 * @param[in] type - AFCM_BA_GROUP_TYPE_ACCUFLOW
 * @param[in] group_p - Pointer to where to return group info
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - Unsupported type or bad handle
 * @return SX_UTILS_STATUS_PARAM_NULL - group_p is NULL
 * @return SX_UTILS_STATUS_ERROR - Internal SDK logic error
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - No group available
 */
static sx_utils_status_t __afcm_page_alloc_cb(ba_handle_t handle, uint32_t type, const ba_group_t **group_p);

/**
 * Handle group free requests
 *
 * @param[in] handle - The client handle
 * @param[out] group_p - Pointer to the group that is not empty.
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - Bad group info or handle
 * @return SX_UTILS_STATUS_PARAM_NULL - group_p is NULL
 * @return SX_UTILS_STATUS_ERROR - Internal SDK logic error
 */
static sx_utils_status_t __afcm_page_free_cb(ba_handle_t handle, ba_group_t *group_p);

/**
 * Process a relocation request
 *
 * @param[in] handle - The client handle that owns the lid
 * @param[in] lid  - The logical ID of the counter being relocated
 * @param[in] cntx - Current value of user context associated with this lid
 * @param[in] old_id  - The old PRM counter ID associated with lid
 * @param[in] new_id  - The new relocated PRM counter id
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_UTILS_STATUS_ERROR - Callback was unable to update HW; keep old
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Cleanup failed; keep both
 */
static sx_utils_status_t __afcm_counter_relocate_cb(ba_handle_t     handle,
                                                    ba_logical_id_t lid,
                                                    uint32_t        cntx,
                                                    ba_index_t      old_id,
                                                    ba_index_t      new_id,
                                                    void          * relocate_cntx);

static void __afcm_ba_index_get_aligned(cm_index_t ba_index, cm_index_t *aligned_index_p);

/************************************************
 *  Function definitions
 ***********************************************/
sx_status_t afcm_init(sx_flow_counter_params_t *init_params_p, afcm_cb_relocate_t relocate_cb)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    boolean_t   is_local_device_opened = FALSE;
    boolean_t   is_kernel_inited = FALSE;
    uint32_t    flow_counter_accumulated_type_max_number = 0;

    SX_LOG_ENTER();

    if (init_params_p->flow_counter_accumulated_type_max_number == 0) {
        goto out;
    }

    /*
     * Only initialize AFCM if HW supports Accumulated counters
     *   Do not set the afcm_init_done_g flag so callers of SW counter allocation
     * receive the "not initialized" error.
     */
    if (rm_resource_global.accuflow_cntr_banks == 0) {
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (rm_resource_global.accuflow_cntr_lines_per_bank > rm_resource_global.accuflow_cntr_lines_per_hw_bank) {
        SX_LOG_ERR("The size [%d] of SW AccuFlow bank is bigger than the size [%d] of HW AccuFlow bank! \n",
                   rm_resource_global.accuflow_cntr_lines_per_bank,
                   rm_resource_global.accuflow_cntr_lines_per_hw_bank);
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Check if AFCM has already been initialized */
    if (afcm_init_done_g != FALSE) {
        SX_LOG_ERR("Accumulated Counter Manager has already been initialized! \n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* Check maximum value of Accumulated counters.
     * Accumulated counter-set range is [1K..400K] (in K (1024) units).
     * Zero is default value (means "Disable") */
    if (init_params_p->flow_counter_accumulated_type_max_number > AFCM_COUNTERS_MAX) {
        SX_LOG_ERR("Maximum number of Accumulated counters %d exceed the limit %u.\n",
                   init_params_p->flow_counter_accumulated_type_max_number,
                   AFCM_COUNTERS_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    flow_counter_accumulated_type_max_number = 1024 * init_params_p->flow_counter_accumulated_type_max_number;

    /* Try to open a local device */
    err = __afcm_open_local_device();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to open a local device, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    is_local_device_opened = TRUE;

    err = __afcm_kernel_init(flow_counter_accumulated_type_max_number);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init Accumulated counters in the kernel, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    is_kernel_inited = TRUE;

    /* Try to initialize an internal database */
    err = __afcm_db_init(flow_counter_accumulated_type_max_number);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize a DB, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    /* Remember the provided relocation callback */
    afcm_relocate_cb_g = relocate_cb;

    /* Initialization is completed successfully */
    afcm_init_done_g = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (is_kernel_inited == TRUE) {
            rb_err = __afcm_kernel_deinit();
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to deinitialize Accumulated counters in the kernel in rollback, err: %s\n",
                           sx_status_str(rb_err));
            }
        }
        if (is_local_device_opened == TRUE) {
            rb_err = __afcm_close_local_device();
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to close a local device in rollback, err: %s\n",
                           sx_status_str(rb_err));
            }
        }
    }

    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_deinit(void)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (afcm_init_done_g != TRUE) {
        SX_LOG_NTC("Accumulated Counter Manager was not initialized. \n");
        goto out;
    }

    /* Perform the FENCE operation for all Accumulated counters existed in DB */
    utils_err = gc_object_process_queue(GC_OBJECT_TYPE_ACCUFLOW_COUNTERS);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to process GC queue for object type ACCUFLOW_COUNTERS\n");
        goto out;
    }

    /* Try to deinitialize the internal database */
    err = __afcm_db_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize a DB, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = __afcm_kernel_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize Accumulated counters in the kernel, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    /* Try to close a local device */
    err = __afcm_close_local_device();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to close a local device, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    /* Deinitialization is completed successfully */
    afcm_init_done_g = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __afcm_counter_alloc(ba_logical_id_t ba_logical_id, uint32_t size)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    prm_idx = 0;

    err = __afcm_counters_mapping_prm_idx_get(ba_logical_id, 0, &prm_idx);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get a PRM index for a counter with LID[%u], err: %s \n",
                   ba_logical_id, sx_status_str(err));
        goto out;
    }

    err = __afcm_counter_kernel_alloc(prm_idx, size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate an accumulated counter in the kernel, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t afcm_bulk_counter_add(cm_type_e type, uint32_t size, cm_logical_id_t *lid_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);

    /* Check the counter type */
    if (type != CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E) {
        SX_LOG_ERR("Unsupported counter type - %u.\n", type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check size of bulk request */
    if (size > CM_BLOCK_SIZE_MASK) {
        SX_LOG_ERR("Internal error - bulk size %u too big!\n", size);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure they provided a return pointer */
    if (utils_check_pointer(lid_p, "lid_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Create an entry for new allocated counter inside DB */
    err = __afcm_db_counter_entry_add(type, size, lid_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_add(cm_type_e type, cm_logical_id_t *lid_p)
{
    return afcm_bulk_counter_add(type, 1, lid_p);
}

sx_status_t afcm_counter_delete(cm_logical_id_t lid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_remove(lid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to remove the counter entry[%u] from DB, err: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_clear(cm_logical_id_t lid, uint32_t offset)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;
    uint32_t            prm_idx = 0;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = __afcm_counters_mapping_prm_idx_get(counter_entry_p->ba_logical_id, offset, &prm_idx);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get a PRM index for a counter with LID[%u] to clear it, err: %s \n",
                   counter_entry_p->ba_logical_id, sx_status_str(err));
        goto out;
    }

    err = __afcm_counter_clear(prm_idx, 1);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to clear the counter with PRM index %u, err: %s \n",
                   prm_idx, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_clear_all()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    prm_idx = 0;
    uint32_t    num_cntr = 0;

    SX_LOG_ENTER();
    if (afcm_init_done_g != TRUE) {
        goto out;
    }

    prm_idx = rm_resource_global.accuflow_cntr_start_idx_offset;
    num_cntr = (rm_resource_global.accuflow_cntr_banks *
                rm_resource_global.accuflow_cntr_lines_per_hw_bank -
                rm_resource_global.accuflow_cntr_lines_reserved) /
               rm_resource_global.accuflow_cntr_lines_flow_both;
    err = __afcm_counter_clear(prm_idx, num_cntr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to clear all counters  err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_get(cm_logical_id_t lid, uint32_t offset, sx_flow_counter_set_t *counter_set_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;
    uint32_t            prm_idx = 0;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = __afcm_counters_mapping_prm_idx_get(counter_entry_p->ba_logical_id, offset, &prm_idx);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get a PRM index for a counter with LID[%u] to read it, err: %s \n",
                   counter_entry_p->ba_logical_id, sx_status_str(err));
        goto out;
    }

    err = __afcm_counter_get(prm_idx, counter_set_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get a value of the counter with PRM index %u, err: %s \n",
                   prm_idx, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_lock(cm_logical_id_t lid,
                              cm_type_e      *type_p,
                              cm_hw_type_t   *hw_type_p,
                              cm_index_t     *index_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    cm_type_e           type = 0;
    cm_hw_type_t        hw_type = 0;
    cm_index_t          tmp_index = 0;
    cm_index_t          ba_index = 0;
    uint32_t            cntx = 0;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    if (index_p == NULL) {
        SX_LOG_ERR("Index pointer is NULL!\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err =
        sx_utils_status_to_sx_status(ba_lock(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id, &ba_index,
                                             &cntx));
    if (err) {
        goto out;
    }

    __afcm_ba_index_get_aligned(ba_index, &tmp_index);

    if (__afcm_counter_hw_id_check(tmp_index) == FALSE) {
        SX_LOG_ERR("Internal error: BA returns invalid HW ID[%u]. \n", tmp_index);
        err = SX_STATUS_ERROR;
        goto out;
    }

    *index_p = tmp_index + rm_resource_global.accuflow_cntr_start_idx_offset;

    /* Type is the lower 8 bits of context */
    type = CM_CNTX_TYPE_GET(cntx);

    if (type_p) {
        *type_p = type;
    }

    /* If not needed save the cycles in performance path */
    if (hw_type_p) {
        /* Calculate the hw_type based on HW independent type */
        err = __afcm_hal_hw_type(type, &hw_type, NULL, NULL);
        if (err) {
            goto out;
        }

        *hw_type_p = hw_type;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_unlock(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = sx_utils_status_to_sx_status(ba_unlock(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id));
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_ref_inc(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = sx_utils_status_to_sx_status(ba_ref_inc(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id));
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_ref_dec(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = sx_utils_status_to_sx_status(ba_ref_dec(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id));
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

sx_status_t afcm_counter_ref_modify(cm_logical_id_t lid, int32_t val)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    /* Pass directly to Bin Allocator to free */
    err = sx_utils_status_to_sx_status(ba_ref_modify(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id, val));
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();

    return err;
}

static sx_status_t __afcm_hal_hw_type(cm_type_e type, cm_hw_type_t *hw_type_p, uint32_t *hw_len_p, uint32_t *ba_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    ba_type = 0, hw_len = 0;
    uint8_t     hw_type = 0;

    if ((hw_type_p == NULL) && (hw_len_p == NULL) && (ba_type_p == NULL)) {
        SX_LOG_ERR("All return parameters pointers are NULL!\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (type) {
    case CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E:
        ba_type = AFCM_BA_GROUP_TYPE_ACCUFLOW;
        hw_type = rm_resource_global.accuflow_cntr_type_flow_both;
        hw_len = rm_resource_global.accuflow_cntr_lines_flow_both;
        break;

    default:
        SX_LOG_ERR("type=%u is unknown!\n", type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (hw_type_p) {
        *hw_type_p = hw_type;
    }

    if (hw_len_p) {
        *hw_len_p = hw_len;
    }

    if (ba_type_p) {
        *ba_type_p = ba_type;
    }

out:
    return err;
}

static sx_status_t __afcm_mafri_send(uint32_t counter_index_base,
                                     uint8_t  num_rec,
                                     uint8_t  fsf,
                                     uint8_t  event,
                                     uint32_t user_val)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_mafri_reg mafri_reg_data;

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mafri_reg_data);

    /* the register is for reading counters updates from HW.
     *  In the destroy flow, we don't care about those values,
     *  we just need to read them and clear HW. */
    reg_meta.dev_id = 1;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.mode = SXD_ACCESS_MODE_SYNC_NO_DEPARSE;

    mafri_reg_data.counter_index_base = counter_index_base;
    mafri_reg_data.num_rec = num_rec;
    mafri_reg_data.fsf = fsf;
    mafri_reg_data.event = event;
    mafri_reg_data.user_val = user_val;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MAFRI_E, &mafri_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to send MAFRI to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    return err;
}

static sx_status_t __afcm_counter_group_mafri_process(uint32_t prm_idx,
                                                      uint32_t size,
                                                      uint8_t  fsf,
                                                      uint8_t  event,
                                                      uint32_t user_val)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    leftover = 0;
    uint32_t    mafri_size = SXD_MAFRI_RECORD_NUM;
    uint32_t    cycles = 0;
    uint32_t    cycle_idx = 0;

    /* Send MAFRI for freed counters to clear HW banks. */
    if (size <= SXD_MAFRI_RECORD_NUM) {
        cycles = 1;
        mafri_size = size;
        leftover = 0;
    } else {
        cycles = size / SXD_MAFRI_RECORD_NUM;
        leftover = size - cycles * SXD_MAFRI_RECORD_NUM;
    }

    while (cycle_idx < cycles) {
        err = __afcm_mafri_send(prm_idx, mafri_size, fsf, event, user_val);
        if (err) {
            SX_LOG_ERR("Failed to send a MAFRI.\n");
            goto out;
        }

        prm_idx += SXD_MAFRI_RECORD_NUM * rm_resource_global.accuflow_cntr_lines_flow_both;
        cycle_idx++;
    }

    if (leftover) {
        err = __afcm_mafri_send(prm_idx, leftover, fsf, event, user_val);
        if (err) {
            SX_LOG_ERR("Failed to send the last MAFRI.\n");
            goto out;
        }
    }

out:
    return err;
}

static sx_utils_status_t __afcm_ba_free_object_cb(ba_handle_t     handle,
                                                  ba_reloc_flow_t reloc_flow,
                                                  ba_logical_id_t lid,
                                                  uint32_t        cntx,
                                                  ba_index_t      ba_idx)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          size = 0;
    uint32_t          prm_idx = 0;
    cm_index_t        tmp_index = 0;

    UNUSED_PARAM(handle);
    UNUSED_PARAM(lid);

    /* We should clear counters only during their deletion. */
    if (reloc_flow != BA_RELOC_FLOW_NONE) {
        goto out;
    }

    size = CM_CNTX_SIZE_GET(cntx);

    __afcm_ba_index_get_aligned(ba_idx, &tmp_index);

    prm_idx = tmp_index + rm_resource_global.accuflow_cntr_start_idx_offset;

    /* Send MAFRI for freed counters to clear HW banks. */
    err = __afcm_counter_group_mafri_process(prm_idx, size, TRUE, FALSE, 0);
    if (err) {
        SX_LOG_ERR("Failed to send a MAFRI to clear counters.\n");
        goto out;
    }

out:
    if (err) {
        utils_err = SX_UTILS_STATUS_ERROR;
    }

    return utils_err;
}

static sx_status_t __afcm_counters_manager_ba_client_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    uint32_t    group_cnt = 0, group_size = 0, idx = 0;
    ba_param_t  param;
    boolean_t   is_af_groups_allocated = FALSE;
    /* alloc_sizes:
     *   Array of up to BIN_ALLOC_MAX_ALLOC_SIZES non-zero allocation sizes
     *   supported by this type.
     *   Sizes should be sorted smallest first.
     *   Unused entries at the end of the array are marked with 0.
     */
    uint16_t alloc_sizes[BIN_ALLOC_MAX_ALLOC_SIZES] = {1, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 0};

    SX_MEM_CLR(param);

    /* Calculate the geometry of Accumulated counters banks*/
    group_size = rm_resource_global.accuflow_cntr_lines_per_bank;
    group_cnt = rm_resource_global.accuflow_cntr_banks;

    /* Allocate memory for BA groups (Accumulated groups) */
    err = utils_clr_memory_get((void**)&afcm_db_g.af_groups_p,
                               group_cnt, sizeof(ba_group_t),
                               UTILS_MEM_TYPE_ID_ACCUFLOW_COUNTER_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for BA groups (Accumulated groups) \n");
        goto out;
    }
    is_af_groups_allocated = TRUE;

    afcm_db_g.af_total_groups_cnt = group_cnt;
    afcm_db_g.af_free_groups_cnt = group_cnt;

    /* BA client init params */
    param.version = BIN_ALLOC_VERSION;
    param.array_size = group_cnt * group_size;
    param.group_cnt = group_cnt;
    param.alignment = group_size;
    param.options = RELOC_SYNC_E | RELOC_ASYNC_E;
    param.r_thresh = AFCM_BA_RELOCATION_THRESHOLD;
    param.r_count = AFCM_BA_RELOCATION_COUNT;

    /* Garbage collector init params for Accumulated counters */
    param.gc_object_type = GC_OBJECT_TYPE_ACCUFLOW_COUNTERS;
    param.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    param.gc_attr.fence_type = GC_FENCE_TYPE_SLOW;
    param.gc_attr.free_objects_threshold = rm_resource_global.accuflow_cntr_lines_per_bank * 0.1;
    param.gc_attr.per_object_threshold = rm_resource_global.accuflow_cntr_lines_per_bank * 0.1;
    param.gc_attr.hw_operation_needed = TRUE;
    param.gc_attr.immediate_fence_needed = FALSE;
    param.gc_attr.max_object_count = (group_cnt * group_size);
    param.gc_post_completion_cb = NULL;
    param.free_object_cb = __afcm_ba_free_object_cb;

    /* Accumulated counter template */
    param.templates[0].type = AFCM_BA_GROUP_TYPE_ACCUFLOW;
    param.templates[0].length = param.alignment;
    param.templates[0].align = ALIGN_NONE_E;
    param.templates[0].cb_relocate = __afcm_counter_relocate_cb;
    param.templates[0].cb_alloc = __afcm_page_alloc_cb;
    param.templates[0].cb_free = __afcm_page_free_cb;

    for (idx = 0; idx < BIN_ALLOC_MAX_ALLOC_SIZES; idx++) {
        if (alloc_sizes[idx] == 0) {
            break;
        }

        param.templates[0].alloc_sizes[idx] = alloc_sizes[idx] * rm_resource_global.accuflow_cntr_lines_flow_both;
    }

    if (idx < BIN_ALLOC_MAX_ALLOC_SIZES) {
        param.templates[0].alloc_sizes[idx] = 0;
    }

    /* Try to register a new BA client for Accumulated counters banks management */
    err = sx_utils_status_to_sx_status(ba_client_init(&afcm_db_g.af_ba_handle, &param));
    if (err) {
        goto out;
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (is_af_groups_allocated == TRUE) {
            rb_err = utils_memory_put(afcm_db_g.af_groups_p,
                                      UTILS_MEM_TYPE_ID_ACCUFLOW_COUNTER_E);
            if (rb_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to free memory for BA groups (Accumulated groups) in rollback. \n");
            }
        }
    }

    return err;
}

static sx_utils_status_t __afcm_page_alloc_cb(ba_handle_t handle, uint32_t type, const ba_group_t **group_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint16_t          idx = 0;
    ba_group_t       *tmp_group_p = NULL;

    SX_LOG_ENTER();

    if (handle != afcm_db_g.af_ba_handle) {
        SX_LOG_ERR("Internal error - BA handle(%p) does not match cached(%p)!\n",
                   handle, afcm_db_g.af_ba_handle);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(group_p, "group_p")) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* No point in looking now */
    if (afcm_db_g.af_free_groups_cnt == 0) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    for (idx = 0; idx < afcm_db_g.af_total_groups_cnt; idx++) {
        tmp_group_p = &afcm_db_g.af_groups_p[idx];

        if (tmp_group_p->type == AFCM_BA_GROUP_TYPE_FREE) {
            tmp_group_p->type = type;
            tmp_group_p->grp_index = idx;

            break;
        }

        tmp_group_p = NULL;
    }

    /* Internal DB inconsistent */
    if (!tmp_group_p) {
        SX_LOG_ERR("Internal error - free=%u but allocation fails!\n",
                   afcm_db_g.af_free_groups_cnt);
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Book keeping */
    afcm_db_g.af_free_groups_cnt--;

    *group_p = tmp_group_p;

out:
    SX_LOG_EXIT();

    return err;
}

static sx_utils_status_t __afcm_page_free_cb(ba_handle_t handle, ba_group_t *group_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (handle != afcm_db_g.af_ba_handle) {
        SX_LOG_ERR("Internal error - BA handle(%p) does not match cached(%p)!\n",
                   handle, afcm_db_g.af_ba_handle);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(group_p, "group_p")) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Can't free any group if all groups are already free */
    if (afcm_db_g.af_free_groups_cnt == afcm_db_g.af_total_groups_cnt) {
        SX_LOG_ERR("All groups already free!\n");
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (group_p->type) {
    case AFCM_BA_GROUP_TYPE_ACCUFLOW:
        break;

    default:
        SX_LOG_ERR("Internal error - type=%u not supported!\n",
                   group_p->type);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure the group is allocated to the requested type */
    if (group_p->type != afcm_db_g.af_groups_p[group_p->grp_index].type) {
        SX_LOG_ERR("Group type mismatch %u != group[%u].type=%u!\n",
                   group_p->type, afcm_db_g.af_groups_p[group_p->grp_index].type,
                   afcm_db_g.af_groups_p[group_p->grp_index].type);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Release the Accumulated page */
    afcm_db_g.af_free_groups_cnt++;
    afcm_db_g.af_groups_p[group_p->grp_index].type = AFCM_BA_GROUP_TYPE_FREE;

out:
    SX_LOG_ENTER();
    return err;
}

static sx_utils_status_t __afcm_counter_relocate_cb(ba_handle_t     handle,
                                                    ba_logical_id_t ba_lid,
                                                    uint32_t        cntx,
                                                    ba_index_t      old_ba_id,
                                                    ba_index_t      new_ba_id,
                                                    void          * relocate_cntx)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;
    cm_logical_id_t     cm_lid = 0;
    cm_type_e           type = 0;
    cm_hw_type_t        hw_type = 0;
    uint32_t            hw_len = 0;
    uint32_t            idx = 0;
    uint32_t            size = 0;
    uint32_t            old_prm_idx = 0;
    uint32_t            new_prm_idx = 0;
    cm_index_t          old_cm_index = 0;
    cm_index_t          new_cm_index = 0;
    uint32_t            offset = 0;

    UNUSED_PARAM(handle);
    UNUSED_PARAM(relocate_cntx);

    SX_LOG_ENTER();

    size = CM_CNTX_SIZE_GET(cntx);
    type = CM_CNTX_TYPE_GET(cntx);

    __afcm_ba_index_get_aligned(old_ba_id, &old_cm_index);
    __afcm_ba_index_get_aligned(new_ba_id, &new_cm_index);

    old_prm_idx = old_cm_index + rm_resource_global.accuflow_cntr_start_idx_offset;
    new_prm_idx = new_cm_index + rm_resource_global.accuflow_cntr_start_idx_offset;

    /* 1. Clear new PRM counters in the kernel DB */
    err = __afcm_counter_clear(new_prm_idx, size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to clear new counters during the relocation process, error: %s \n", sx_status_str(err));
        goto out;
    }

    /* 2. Rebind Accuflow counters using the new PRM indices */
    err = __afcm_hal_hw_type(type, &hw_type, &hw_len, NULL);
    if (err) {
        SX_LOG_ERR("Failed to get HW type and length by SW type for relocated Accuflow counter, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = __afcm_db_counter_entry_by_ba_lid_get(ba_lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    cm_lid = counter_entry_p->af_counter_id;

    for (idx = 0; idx < size; idx++) {
        offset = idx * hw_len;
        err =
            sx_utils_status_to_sx_status(afcm_relocate_cb_g(cm_lid, idx, type, hw_type, old_prm_idx + offset,
                                                            new_prm_idx + offset));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to rebind Accuflow counters during the relocation process, error: %s \n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* 3. Get the value of old PRM counters */
    err = __afcm_counter_group_mafri_process(old_prm_idx, size, TRUE, TRUE, 0);
    if (err) {
        SX_LOG_ERR("Failed to send a MAFRI to clear counters.\n");
        goto out;
    }

    /* 4. Move the values of old PRM counters to new ones */
    err = __afcm_counter_kernel_move(old_prm_idx, new_prm_idx, size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to move values of old counter to new ones during the relocation process, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return SX_STATUS_TO_SX_UTILS_STATUS(err);
}

static sx_status_t __afcm_db_init(uint32_t flow_counter_accumulated_type_max_number)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    cl_status_t cl_err = CL_SUCCESS;
    uint32_t    counters_pool_max_size = 0;
    uint32_t    counters_pool_min_size = 0;
    uint32_t    counters_pool_grow_size = 0;
    boolean_t   is_ba_client_inited = FALSE;

    /* Register the BA client */
    err = __afcm_counters_manager_ba_client_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to register a new BA client, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    is_ba_client_inited = TRUE;

    /* This is needed to make sure that all IDs will be in a valid range.
     *  In second phase, we might think about a bit vector as a pool for valid IDs. */
    counters_pool_max_size = flow_counter_accumulated_type_max_number;
    counters_pool_min_size = flow_counter_accumulated_type_max_number;
    counters_pool_grow_size = 0;

    afcm_db_g.af_counters_allocated = 0;
    cl_err = CL_QPOOL_INIT(&afcm_db_g.af_counters_qpool,
                           counters_pool_min_size,
                           counters_pool_max_size,
                           counters_pool_grow_size,
                           sizeof(af_counter_entry_t),
                           __afcm_counters_pool_init_cb,
                           NULL,
                           &afcm_db_g.af_counters_allocated);
    if (cl_err != CL_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize Accumulated counters pool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    /* Initialize helper maps / lists */
    cl_qmap_init(&afcm_db_g.af_counters_qmap_by_cm_lid);
    cl_qmap_init(&afcm_db_g.af_counters_qmap_by_ba_lid);

out:
    if (SX_CHECK_FAIL(err)) {
        if (is_ba_client_inited == TRUE) {
            rb_err = __afcm_counters_manager_ba_client_deinit();
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to destroy the BA client in rollback, err: %s\n",
                           sx_status_str(rb_err));
                goto out;
            }
        }
    }

    return err;
}

static sx_status_t __afcm_db_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Destroy the BA client */
    err = __afcm_counters_manager_ba_client_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to destroy the BA client, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    /* Destroy the Accumulated counters pool */
    afcm_db_g.af_counters_allocated = 0;
    CL_QPOOL_DESTROY(&afcm_db_g.af_counters_qpool);

out:
    return err;
}

static sx_status_t __afcm_counters_manager_ba_client_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Try to deinit the BA client */
    err = sx_utils_status_to_sx_status(ba_client_deinit(afcm_db_g.af_ba_handle));
    if (err) {
        goto out;
    }

    /* Free memory of BA groups (Accumulated groups) */
    err = utils_memory_put(afcm_db_g.af_groups_p,
                           UTILS_MEM_TYPE_ID_ACCUFLOW_COUNTER_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to free memory for BA groups (Accumulated groups) \n");
        goto out;
    }

out:
    return err;
}

static cl_status_t __afcm_counters_pool_init_cb(void *const            p_object,
                                                void                  *context,
                                                cl_pool_item_t **const pp_pool_item)
{
    cl_status_t         cl_err = CL_SUCCESS;
    uint32_t           *last_allocated_lid_p = (uint32_t*)context;
    af_counter_entry_t *af_counter_entry_p = (af_counter_entry_t*)p_object;

    CL_ASSERT(last_allocated_lid_p);
    CL_ASSERT(af_counter_entry_p);
    CL_ASSERT(pp_pool_item);

    af_counter_entry_p->af_counter_id = ++(*last_allocated_lid_p);

    if (af_counter_entry_p->af_counter_id == AFCM_COUNTER_LID_INVALID) {
        SX_LOG_ERR("Invalid LID reached!\n");
        cl_err = CL_ERROR;
        goto out;
    }
    *pp_pool_item = &af_counter_entry_p->af_counters_pool_item;

out:
    return cl_err;
}

static sx_status_t __afcm_open_local_device(void)
{
    int         err = 0, i = 0;
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    char        dev_name[MAX_SX_DEVS][MAX_NAME_LEN];
    char       *dev_name_p[MAX_SX_DEVS];
    uint32_t    dev_num = MAX_SX_DEVS;

    for (i = 0; i < MAX_SX_DEVS; ++i) {
        dev_name_p[i] = dev_name[i];
    }

    err = sxd_get_dev_list(dev_name_p, &dev_num);
    if (err < 0) {
        SX_LOG_ERR("sxd_get_dev_list error: %s\n", strerror(errno));
        sx_status = sxd_status_to_sx_status(SXD_STATUS_DEVICE_GET_ERROR);
        goto out;
    } else if (err > 0) {
        SX_LOG_ERR("Unsupported SX device number: %u\n", dev_num);
        sx_status = sxd_status_to_sx_status(SXD_STATUS_DEVICE_GET_ERROR);
        goto out;
    }

    /* there should be only 1 char device - use the first one*/
    err = sxd_open_device(dev_name[0], &(afcm_db_g.device_handle));
    if (err != 0) {
        SX_LOG_ERR("sxd_open_device error: %s\n", strerror(errno));
        sx_status = sxd_status_to_sx_status(SXD_STATUS_DEVICE_OPEN_ERROR);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __afcm_mafcr_init(uint16_t *packets_inc_units_p, uint16_t *bytes_inc_units_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_mafcr_reg mafcr_reg_data;

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mafcr_reg_data);

    reg_meta.dev_id = 1;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    mafcr_reg_data.clear = 1;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MAFCR_E, &mafcr_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to read MAFCR to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mafcr_reg_data);

    reg_meta.dev_id = 1;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MAFCR_E, &mafcr_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to send MAFCR to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

    *bytes_inc_units_p = mafcr_reg_data.bytes_inc_units;
    *packets_inc_units_p = mafcr_reg_data.packets_inc_units;

out:
    return err;
}

static sx_status_t __afcm_kernel_init(uint32_t flow_counter_accumulated_type_max_number)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    ku_accuflow_counters_params_t accuflow_params;

    SX_MEM_CLR(accuflow_params);

    /* In the first release, the kernel will pre-allocate all counters,
     *  so we could disable the BA relocation. */
    UNUSED_PARAM(flow_counter_accumulated_type_max_number);

    accuflow_params.op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_INIT_E;
    accuflow_params.op_data.init_data.prm_counters_num = rm_resource_global.accuflow_cntr_lines_per_hw_bank *
                                                         rm_resource_global.accuflow_cntr_banks;
    accuflow_params.op_data.init_data.prm_cntr_banks = rm_resource_global.accuflow_cntr_banks;
    accuflow_params.op_data.init_data.prm_cntr_lines_per_bank = rm_resource_global.accuflow_cntr_lines_per_hw_bank;
    accuflow_params.op_data.init_data.prm_cntr_lines_flow_both = rm_resource_global.accuflow_cntr_lines_flow_both;
    accuflow_params.op_data.init_data.prm_cntr_type_flow_both = rm_resource_global.accuflow_cntr_type_flow_both;
    accuflow_params.op_data.init_data.prm_cntr_start_idx_offset = rm_resource_global.accuflow_cntr_start_idx_offset;

    err = __afcm_mafcr_init(&accuflow_params.op_data.init_data.packets_inc_unit,
                            &accuflow_params.op_data.init_data.bytes_inc_unit);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get MAFCR data: %s \n", sx_status_str(err));
        goto out;
    }

    err = __afcm_ioctl(&accuflow_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize Accumulated counters in the kernel: %s \n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __afcm_kernel_deinit(void)
{
    ku_accuflow_counters_params_t accuflow_params;

    SX_MEM_CLR(accuflow_params);

    accuflow_params.op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_DEINIT_E;

    return __afcm_ioctl(&accuflow_params);
}

static sx_status_t __afcm_close_local_device(void)
{
    int         err = 0;
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    err = sxd_close_device(afcm_db_g.device_handle);
    if (err != 0) {
        SX_LOG_ERR("sxd_close_device error: %s\n", strerror(errno));
        sx_status = sxd_status_to_sx_status(SXD_STATUS_DEVICE_CLOSE_ERROR);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __afcm_db_counter_entry_by_cm_lid_get(cm_logical_id_t lid, af_counter_entry_t **af_counter_entry_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;

    map_item_p = cl_qmap_get(&afcm_db_g.af_counters_qmap_by_cm_lid, lid);
    if (map_item_p == cl_qmap_end(&afcm_db_g.af_counters_qmap_by_cm_lid)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *af_counter_entry_p = PARENT_STRUCT(map_item_p, af_counter_entry_t, af_counters_qmap_by_cm_lid_item);

out:
    return err;
}

static sx_status_t __afcm_db_counter_entry_by_ba_lid_get(ba_logical_id_t lid, af_counter_entry_t **af_counter_entry_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;

    map_item_p = cl_qmap_get(&afcm_db_g.af_counters_qmap_by_ba_lid, lid);
    if (map_item_p == cl_qmap_end(&afcm_db_g.af_counters_qmap_by_ba_lid)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *af_counter_entry_p = PARENT_STRUCT(map_item_p, af_counter_entry_t, af_counters_qmap_by_ba_lid_item);

out:
    return err;
}

static sx_status_t __afcm_db_counter_entry_remove(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    counter_entry_p->af_counter_id = CM_LID_BANK_TYPE_CLR(counter_entry_p->af_counter_id);

    /* Free a counter's related entry inside Bin Allocator */
    err = sx_utils_status_to_sx_status(ba_free(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id));
    if (err) {
        goto out;
    }

    cl_qmap_remove_item(&afcm_db_g.af_counters_qmap_by_cm_lid, &counter_entry_p->af_counters_qmap_by_cm_lid_item);
    cl_qmap_remove_item(&afcm_db_g.af_counters_qmap_by_ba_lid, &counter_entry_p->af_counters_qmap_by_ba_lid_item);

    cl_qpool_put(&afcm_db_g.af_counters_qpool, &counter_entry_p->af_counters_pool_item);

out:
    return err;
}

static sx_status_t __afcm_db_counter_entry_add(cm_type_e type, uint32_t size, cm_logical_id_t *lid_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *af_counter_entry_p = NULL;
    cl_pool_item_t     *pool_item_p = NULL;
    uint32_t            ba_type = 0, len = 0, cntx = 0;
    ba_logical_id_t     ba_lid = 0;
    boolean_t           is_pool_item_allocated = FALSE;

    /* Get the HW specific details on the requested HW independent type */
    err = __afcm_hal_hw_type(type, NULL, &len, &ba_type);
    if (err) {
        goto out;
    }

    pool_item_p = cl_qpool_get(&afcm_db_g.af_counters_qpool);
    if (pool_item_p == NULL) {
        SX_LOG_NTC("Cannot allocate Accumulated counter entry from pool\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    is_pool_item_allocated = TRUE;

    af_counter_entry_p = PARENT_STRUCT(pool_item_p, af_counter_entry_t, af_counters_pool_item);

    /* Put the interesting bits into context */
    cntx = CM_CNTX_SET(type, size);

    /* Ask Bin Allocator for a block */
    err = sx_utils_status_to_sx_status(ba_allocate(afcm_db_g.af_ba_handle, ba_type, len * size, cntx, &ba_lid));
    if (err) {
        SX_LOG_NTC("Unable to allocate block %u\n", err);
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    err = __afcm_counter_alloc(ba_lid, size);
    if (err) {
        SX_LOG_ERR("Failed to allocate a counter in the kernel, error: %u\n", err);
        goto out;
    }

    af_counter_entry_p->af_counter_id = CM_LID_BANK_TYPE_SET(af_counter_entry_p->af_counter_id,
                                                             CM_ACCUFLOW_COUNTERS_BANKS_E);

    af_counter_entry_p->ba_logical_id = ba_lid;

    cl_qmap_insert(&afcm_db_g.af_counters_qmap_by_cm_lid,
                   af_counter_entry_p->af_counter_id,
                   &af_counter_entry_p->af_counters_qmap_by_cm_lid_item);
    cl_qmap_insert(&afcm_db_g.af_counters_qmap_by_ba_lid,
                   af_counter_entry_p->ba_logical_id,
                   &af_counter_entry_p->af_counters_qmap_by_ba_lid_item);

    *lid_p = af_counter_entry_p->af_counter_id;

out:
    if (SX_CHECK_FAIL(err)) {
        if (is_pool_item_allocated == TRUE) {
            cl_qpool_put(&afcm_db_g.af_counters_qpool,
                         &af_counter_entry_p->af_counters_pool_item);
        }
    }

    return err;
}

static sx_status_t __afcm_counters_mapping_prm_idx_get(ba_logical_id_t ba_logical_id,
                                                       uint32_t        offset,
                                                       uint32_t       *prm_idx_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cm_index_t  ba_index = 0;
    cm_index_t  prm_index = 0;
    uint32_t    cntx = 0;
    uint32_t    size = 0;

    SX_LOG_ENTER();

    *prm_idx_p = 0;
    err = sx_utils_status_to_sx_status(ba_lock(afcm_db_g.af_ba_handle, ba_logical_id, &ba_index, &cntx));
    if (err) {
        SX_LOG_ERR("Failed to lock a counter with LID [%u]. \n", ba_logical_id);
        goto out;
    }

    __afcm_ba_index_get_aligned(ba_index, &prm_index);

    size = CM_CNTX_SIZE_GET(cntx);
    if (offset >= size) {
        SX_LOG_ERR("Requested counter at offset %u is outside the counter group [BA ID: %u, SIZE: %u]. \n",
                   offset, ba_logical_id, size);
        err = SX_STATUS_ERROR;
        goto out;
    }

    prm_index = prm_index + offset * rm_resource_global.accuflow_cntr_lines_flow_both;

    if (__afcm_counter_hw_id_check(prm_index) == FALSE) {
        SX_LOG_ERR("Internal error: BA returns invalid HW ID[%u]. \n", prm_index);
        err = SX_STATUS_ERROR;
        goto out;
    }

    prm_index = prm_index + rm_resource_global.accuflow_cntr_start_idx_offset;

    err = sx_utils_status_to_sx_status(ba_unlock(afcm_db_g.af_ba_handle, ba_logical_id));
    if (err) {
        SX_LOG_ERR("Failed to unlock a counter with LID [%u]. \n", ba_logical_id);
        goto out;
    }

    *prm_idx_p = prm_index;

out:
    SX_LOG_EXIT();
    return err;
}

/* hw_id - should be zero-based, not a prm idx */
static inline boolean_t __afcm_counter_hw_id_check(ba_index_t hw_id)
{
    boolean_t is_valid = FALSE;

    if (hw_id <=
        (rm_resource_global.accuflow_cntr_banks * rm_resource_global.accuflow_cntr_lines_per_hw_bank -
         rm_resource_global.accuflow_cntr_lines_flow_both)) {
        is_valid = TRUE;
    }

    return is_valid;
}

sx_status_t afcm_counter_attr_get(cm_logical_id_t lid, cm_attr_t *attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_utils_status_t   utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t            cntx = 0;
    af_counter_entry_t *counter_entry_p = NULL;
    uint32_t            ref = 0;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter entry in DB, err: %s \n",
                   sx_status_str(err));
        goto out;
    }

    /* Get BA context that holds our stuff */
    utils_err = ba_client_cntx_get(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id, &cntx, &ref);
    if (utils_err) {
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    /* Extract the counter type from the context where we put it */
    attr_p->type = CM_CNTX_TYPE_GET(cntx);
    attr_p->size = CM_CNTX_SIZE_GET(cntx);
    attr_p->ref = ref;

    err = __afcm_hal_hw_type(attr_p->type, &attr_p->hw_type, &attr_p->hw_len, NULL);
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __afcm_ioctl(ku_accuflow_counters_params_t *data_p)
{
    sxd_ctrl_pack_t ctrl_pack;
    sxd_status_t    sxd_st;
    sx_status_t     err = SX_STATUS_SUCCESS;

    ctrl_pack.ctrl_cmd = CTRL_CMD_ACCUFLOW_COUNTERS_SET;
    ctrl_pack.cmd_body = (void *)data_p;
    sxd_st = sxd_ioctl(afcm_db_g.device_handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_st)) {
        SX_LOG_ERR("Accumulated counters manage: ioctl failed error %s\n", strerror(errno));
        switch (errno) {
        case EBUSY:
            SX_LOG_ERR("Accumulated counters manage: transaction is in progress.\n");
            break;

        case ENOENT:
            SX_LOG_ERR("Accumulated counters manage: transaction does not exist.\n");
            break;

        case EINVAL:
            SX_LOG_ERR("Accumulated counters manage: transaction parameter is invalid.\n");
            break;

        default:
            break;
        }
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
    }

    return err;
}

static sx_status_t __afcm_counter_get(uint32_t prm_idx, sx_flow_counter_set_t *counters_values_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    ku_accuflow_counters_params_t *params_p = NULL;

    counters_values_p->flow_counter_packets = 0;
    counters_values_p->flow_counter_bytes = 0;

    params_p = malloc(sizeof(ku_accuflow_counters_params_t) + sizeof(sx_flow_counter_set_t));
    if (params_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for counters values.\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    params_p->op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_READ_E;
    params_p->op_data.read_data.num_of_counters = 1;
    params_p->op_data.read_data.prm_counter_idx = prm_idx;

    err = __afcm_ioctl(params_p);
    if (err) {
        SX_LOG_ERR("Failed to get counters' values from the kernel.\n");
        goto out;
    }

    counters_values_p->flow_counter_packets = params_p->op_data.read_data.counters_values[0].flow_counter_packets;
    counters_values_p->flow_counter_bytes = params_p->op_data.read_data.counters_values[0].flow_counter_bytes;

out:
    if (params_p) {
        free(params_p);
    }
    return err;
}

static inline sx_status_t __afcm_counter_clear(uint32_t prm_idx, uint32_t num_cntr)
{
    ku_accuflow_counters_params_t params;

    SX_MEM_CLR(params);

    params.op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_CLEAR_E;
    params.op_data.clear_data.num_of_counters = num_cntr;
    params.op_data.clear_data.prm_counter_idx = prm_idx;

    return __afcm_ioctl(&params);
}


static inline sx_status_t __afcm_counter_kernel_alloc(uint32_t prm_idx, uint32_t num_of_counters)
{
    ku_accuflow_counters_params_t params;

    SX_MEM_CLR(params);

    params.op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_ALLOC_E;
    params.op_data.alloc_data.num_of_counters = num_of_counters;
    params.op_data.alloc_data.prm_counter_idx = prm_idx;

    return __afcm_ioctl(&params);
}

static inline sx_status_t __afcm_counter_kernel_move(uint32_t old_prm_idx,
                                                     uint32_t new_prm_idx,
                                                     uint32_t num_of_counters)
{
    ku_accuflow_counters_params_t params;

    SX_MEM_CLR(params);

    params.op = KU_ACCUFLOW_COUNTERS_PARAMS_OP_MOVE_E;
    params.op_data.move_data.num_of_counters = num_of_counters;
    params.op_data.move_data.old_prm_counter_idx = old_prm_idx;
    params.op_data.move_data.new_prm_counter_idx = new_prm_idx;

    return __afcm_ioctl(&params);
}

/*
 * This function converts SW bank indices to HW bank indices.
 *
 * The allocation will be done by using Bin Allocator but after that
 * block index will be aligned according HW bank size.
 * The function below will do the alignment :
 * 1. SW_BANK_SIZE is number of lines in counter bank which is exposed to user:
 *    rm_resource_global.accuflow_cntr_lines_per_bank
 * 2. HW_BANK_SIZE is number of lines in counter bank as appears in PRM
 *     rm_resource_global.accuflow_cntr_lines_per_hw_bank
 * 3. Bin allocator is initialized with SW_BANK_SIZE.
 *    So it will allocate block with start index between 0 .. SW_BANK_SIZE-1
 * 4. So bank_id and offset will be :
 *    counter_bank_id = ba_index / SW_BANK_SIZE
 *    counter_offset = ba_index % SW_BANK_SIZE
 * 5. aligned_index  = counter_bank_id * HW_BANK_SIZE + counter_offset
 *
 * Example:
 * SW_BANK_SIZE = 4000
 * HW_BANK_SIZE = 4096
 *
 * ba_index | aligned_index
 * -----------------------------------------------
 * 4000     | (4000 / 4000) * 4096 + (4000 % 4000) = 4096 + 0 = 4096
 * 4001     | (4001 / 4000) * 4096 + (4001 % 4000) = 4096 + 1 = 4097
 * 4096     | (4096 / 4000) * 4096 + (4096 % 4000) = 4096 + 96 = 4182
 * 5000     | (5000 / 4000) * 4096 + (5000 % 4000) = 4096 + 1000 = 5096
 *
 */
static void __afcm_ba_index_get_aligned(cm_index_t ba_index, cm_index_t *aligned_index_p)
{
    uint16_t        bank_id = 0;
    ba_logical_id_t offset = 0;

    /* if sw_bank == hw_bank than int_ba_lid equal to external */
    if (rm_resource_global.accuflow_cntr_lines_per_bank ==
        rm_resource_global.accuflow_cntr_lines_per_hw_bank) {
        *aligned_index_p = ba_index;
        return;
    }

    /* if sw_bank or hw_bank is 0 than int_ba_lid equal to external */
    if ((rm_resource_global.accuflow_cntr_lines_per_bank == 0) ||
        (rm_resource_global.accuflow_cntr_lines_per_hw_bank == 0)) {
        *aligned_index_p = ba_index;
        return;
    }

    bank_id = ba_index / rm_resource_global.accuflow_cntr_lines_per_bank;
    offset = ba_index % rm_resource_global.accuflow_cntr_lines_per_bank;

    *aligned_index_p = bank_id * rm_resource_global.accuflow_cntr_lines_per_hw_bank + offset;
}

sx_status_t afcm_counter_relocate_force(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;
    ba_index_t          ba_index = 0;
    ba_index_t          new_ba_index = 0;
    uint32_t            cntx = 0;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    if (afcm_forced_relocation_info_g.relocated_lid != 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Cannot relocate counter[%u], other counter[%u] is already relocated, error: %s \n",
                   lid, afcm_forced_relocation_info_g.relocated_lid, sx_status_str(err));
        goto out;
    }

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter[%u] entry in DB to perform a forced relocation, error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    err =
        sx_utils_status_to_sx_status(ba_lock(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id, &ba_index,
                                             &cntx));
    if (err) {
        SX_LOG_ERR("Failed to lock the counter[%u] during a forced relocation, error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    new_ba_index = rm_resource_global.accuflow_cntr_lines_per_bank * rm_resource_global.accuflow_cntr_banks -
                   rm_resource_global.accuflow_cntr_lines_flow_both * CM_CNTX_SIZE_GET(cntx) -
                   rm_resource_global.accuflow_cntr_lines_reserved;

    err =
        sx_utils_status_to_sx_status(__afcm_counter_relocate_cb(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id,
                                                                cntx, ba_index, new_ba_index, NULL));
    if (err) {
        SX_LOG_ERR("Failed to perform forced relocation of the counter[%u], error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    afcm_forced_relocation_info_g.relocated_lid = lid;
    afcm_forced_relocation_info_g.ba_index = ba_index;
    afcm_forced_relocation_info_g.new_ba_index = new_ba_index;
    afcm_forced_relocation_info_g.cntx = cntx;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t afcm_counter_relocate_undo(cm_logical_id_t lid)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    af_counter_entry_t *counter_entry_p = NULL;

    SX_LOG_ENTER();

    AFCM_MODULE_INIT_CHECK(err);
    AFCM_COUNTER_TYPE_CHECK(lid, err);

    if (afcm_forced_relocation_info_g.relocated_lid != lid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Failed to undo forced relocation of the counter[%u], this counter was not force to move, error: %s \n",
            lid,
            sx_status_str(err));
        goto out;
    }

    err = __afcm_db_counter_entry_by_cm_lid_get(lid, &counter_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to find the counter[%u] entry in DB to undo a forced relocation, error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    err =
        sx_utils_status_to_sx_status(__afcm_counter_relocate_cb(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id,
                                                                afcm_forced_relocation_info_g.cntx,
                                                                afcm_forced_relocation_info_g.new_ba_index,
                                                                afcm_forced_relocation_info_g.ba_index, NULL));
    if (err) {
        SX_LOG_ERR("Failed to undo a forced relocation of the counter[%u], error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    err = sx_utils_status_to_sx_status(ba_unlock(afcm_db_g.af_ba_handle, counter_entry_p->ba_logical_id));
    if (err) {
        SX_LOG_ERR("Failed to unlock the counter[%u] as a part of canceling a forced relocation, error: %s \n",
                   lid, sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(afcm_forced_relocation_info_g);

out:
    SX_LOG_EXIT();
    return err;
}
