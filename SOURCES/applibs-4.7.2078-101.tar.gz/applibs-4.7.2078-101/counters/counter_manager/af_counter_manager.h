/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __AF_COUNTER_MANAGER_H__
#define __AF_COUNTER_MANAGER_H__


#include "counters/counter_manager/counter_manager.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Accumulated Counter relocation callback function.
 * This callback is called when the bin allocator relocates a block.
 * It is up to the user provided handler to decide if it needs to do anything
 * based on the lid.
 *
 * @param[in] lid  - The logical ID being relocated
 * @param[in] type - The hardware independent type of this LID
 * @param[in] hw_type - The hardware dependent type of this LID
 * @param[in] old_index  - The old offset associated with 'lid'
 * @param[in] new_index  - The new offset into array for 'lid'
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_UTILS_STATUS_ERROR - Callback was unable to update HW
 *
 * NOTE:
 *   The callback will never be called while any user holds a lock on the
 *   block. While all the callbacks for a block are being called, the counter
 *   manager will not grant any user lock for the block so the callback
 *   handlers MUST NOT attempt to get the lock.
 */
typedef sx_utils_status_t (*afcm_cb_relocate_t)(cm_logical_id_t lid,
                                                uint32_t        offset,
                                                cm_type_e       type,
                                                cm_hw_type_t    hw_type,
                                                cm_index_t      old_index,
                                                cm_index_t      new_index);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize the Accumulated counter manager module
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_ALREADY_INITIALIZED - module already initialized
 * @return SX_STATUS_ERROR - Internal SDK error
 */
sx_status_t afcm_init(sx_flow_counter_params_t *init_params_p, afcm_cb_relocate_t relocate_cb);

/**
 * Deinitialize the Accumulated counter manager module
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED if module not initialized
 * @return SX_STATUS_RESOURCE_IN_USE if at least one user still active
 */
sx_status_t afcm_deinit(void);

/**
 * This function provides SW allocation of an Accumulated counter bulk
 *
 * @param[in] type - Type of counter to allocate
 * @param[in] size - Number of counter to allocate
 * @param[out] lid_p - Location to return logical counter ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR if type is invalid or lid_p is NULL
 * @return SX_STATUS_PARAM_NULL - lid_p is NULL
 * @return SX_STATUS_NO_RESOURCES if no counters are available
 */
sx_status_t afcm_bulk_counter_add(cm_type_e        type,
                                  uint32_t         size,
                                  cm_logical_id_t *lid_p);

/**
 * This function provides SW allocation of an Accumulated counter
 *
 * @param[in] type - Type of counter to allocate
 * @param[out] lid_p - Location to return logical counter ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR if type is invalid or lid_p is NULL
 * @return SX_STATUS_PARAM_NULL - lid_p is NULL
 * @return SX_STATUS_NO_RESOURCES if no counters are available
 */
sx_status_t afcm_counter_add(cm_type_e        type,
                             cm_logical_id_t *lid_p);

/**
 * This function provides SW deallocation of a counter
 *
 * @param[in] lid - Logical counter ID to release
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Reference count > 1
 */
sx_status_t afcm_counter_delete(cm_logical_id_t lid);

/**
 * This function clears a value of Accumulated counter
 *
 * @param[in] lid - Logical counter group ID
 * @param[in] offset - offset of the counter to clear
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 */
sx_status_t afcm_counter_clear(cm_logical_id_t lid, uint32_t offset);

/**
 * This function returns a value of counter.
 *
 * @param[in] lid - Logical counter group ID
 * @param[in] offset - offset of the counter to read
 * @param[in/out] counter_set_p - Counter value
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 */
sx_status_t afcm_counter_get(cm_logical_id_t lid, uint32_t offset, sx_flow_counter_set_t *counter_set_p);

/**
 * Lock a counter in order to perform HW operations
 *
 * @param[in] lid - The logical ID of the counter to lock
 * @param[out] type_p - The hardware independent type of this LID
 * @param[out] hw_type_p - The hardware dependent type of this LID
 * @param[out] index_p - Current index into counter array for this lid
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_NULL - index_p is null
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Lock already active on resource
 */
sx_status_t afcm_counter_lock(cm_logical_id_t lid,
                              cm_type_e      *type_p,
                              cm_hw_type_t   *hw_type_p,
                              cm_index_t     *index_p);

/**
 * Release a locked counter
 *
 * @param[in] lid - The logical ID of the counter to unlock
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - LID is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_NO_RESOURCES - Lock not held on counter ID
 */
sx_status_t afcm_counter_unlock(cm_logical_id_t lid);

/**
 * Add a reference to a previously allocated counter
 *
 * @param[in] lid - The logical ID of the counter being referenced
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 */
sx_status_t afcm_counter_ref_inc(cm_logical_id_t lid);

/**
 * Delete a reference to a previously allocated counter
 *
 * @param[in] lid - The logical ID of the counter being de-referenced
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is not allocated or invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Ref count 1 so block must be deleted
 */
sx_status_t afcm_counter_ref_dec(cm_logical_id_t lid);

/**
 * Modify the reference count associated with an allocated counter
 *
 * @param[in] lid - The logical ID of the counter being de-referenced
 * @param[in] val - The increment/decrement value
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is not allocated or invalid
 * @return SX_STATUS_ERROR - Internal error
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE - Updated count would be outside valid range
 */
sx_status_t afcm_counter_ref_modify(cm_logical_id_t lid, int32_t val);

/**
 * Return the lid counter attributes
 *
 * @param[in] lid - The logical ID of the counter
 * @param[out] attr_p - Pointer to where to store lid attributes
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - LID is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_PARAM_NULL - attr_p is NULL
 */
sx_status_t afcm_counter_attr_get(cm_logical_id_t lid, cm_attr_t *attr_p);

/**
 * This function clears the value of all Accumulated counters
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 */
sx_status_t afcm_counter_clear_all();

sx_status_t afcm_counter_relocate_force(cm_logical_id_t lid);
sx_status_t afcm_counter_relocate_undo(cm_logical_id_t lid);

#endif /* __AF_COUNTER_MANAGER_H__ */
