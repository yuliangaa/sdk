/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __COUNTER_INTERNAL_H__
#define __COUNTER_INTERNAL_H__

#include <sx/sdk/sx_status_convertor.h>

/************************************************
 *  Local Defines
 ***********************************************/

/*
 * CM_MAX_USERS
 *   The maximum number of clients that Counter Manager (CM) supports.
 *
 * CM_MAX_GROUPS
 * CM_MAX_TYPES
 *   The maximum number of groups and types supported.
 *
 * CM_THRESHOLD
 * CM_COUNT
 *   Parameters used to control aggressiveness and CPU usage of defragmentation
 *
 * CM_TYPE_FLOW
 * CM_TYPE_RIF
 *   The two basic types of counter allocations
 *
 * CM_MIN_FLOW
 * CM_MIN_RIF
 *   The minimum number of groups that must be reserved for each type
 *
 * INVALID_LID
 *   This uint32_t is never presented as a valid LID; comes from BA
 */
#define CM_MAX_USERS (30)

#define CM_MAX_GROUPS (10)
#define CM_MAX_TYPES  (4)

#define CM_THRESHOLD (80)
#define CM_COUNT     (5)

#define CM_TYPE_FREE (0)
#define CM_TYPE_FLOW (1)
#define CM_TYPE_RIF  (2)

#define CM_MIN_FLOW (1)
#define CM_MIN_RIF  (1)

#define INVALID_LID (0)

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/*
 * Internal user context
 */
typedef struct cmi_user {
    boolean_t         allocated;
    hal_cb_relocate_t relocate;
    hal_cb_clear_t    clear;
    hal_cb_add_t      add;
} cmi_user_t;


/*
 * Group allocation tracking
 */
typedef struct cmi_group {
    uint16_t   group_cnt;
    uint16_t   free_cnt;
    ba_group_t groups[CM_MAX_GROUPS];
    uint32_t   type_counts[CM_MAX_TYPES];
} cmi_group_t;


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t rm_resource_global;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Extract HW dependent type info for a given HW independent counter type
 *
 * @param[in] type - HW independent counter type value
 * @param[out] hw_type_p - Hardware dependent type value (8 bits)
 * @param[out] hw_len_p - Number of lines consumed by hw_type
 * @param[out] ba_type_p - Block Allocator type used for this 'type'
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - All return parameters are NULL
 */
sx_status_t cm_hal_hw_type(cm_type_e type,
                           uint8_t  *hw_type_p,
                           uint32_t *hw_len_p,
                           uint32_t *ba_type_p);

#endif /* __COUNTER_INTERNAL_H__ */
