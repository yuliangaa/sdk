/*
 * Copyright (C) 2015-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __COUNTER_MANAGER_H__
#define __COUNTER_MANAGER_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_api.h>
#include <sx/utils/gbin_allocator.h>


/**
 * Counter logical ID
 *   This is the logical ID used by counter manager and clients to
 *   describe a block.
 *
 * Field composition:
 * |32        |18                0|
 * +----------+-------------------+
 * | reserved |           id      |
 * +----------+-------------------+
 *
 *  bits 0-18    - Counter Identifier. 19 bits gives 512K unique IDs:
 *                  Today, SDK can have up to 39K unique IDs for Flow counters
 *                  and up to 200K unique IDs for Accumulated counters.
 *  id          - Counter bank:
 *                      [0..100000)    - SHARED BANK for Flow and RIF counters.
 *                      [100000..512K) - ACCUFLOW BANK for Accumulated counters.
 *  bits 19-32   - Reserved for offset on the Flow counters layer.
 *                  13 bits gives 8K unique indices and
 *                  the size of the biggest counter group is 8K.
 */
typedef uint32_t cm_logical_id_t;

#define CM_LID_BANK_TYPE_SET(id, bank_type) (((bank_type) == CM_SHARED_COUNTERS_BANKS_E) ? (id) : (id + 100000))
#define CM_LID_BANK_TYPE_GET(id) \
    (((id) <                     \
      100000) ? CM_SHARED_COUNTERS_BANKS_E : CM_ACCUFLOW_COUNTERS_BANKS_E)
#define CM_LID_BANK_TYPE_CLR(id) (((id) < 100000) ? (id) : (id - 100000))


/**
 * Counter banks
 */
typedef enum {
    CM_SHARED_COUNTERS_BANKS_E = 0,
    CM_ACCUFLOW_COUNTERS_BANKS_E,
    CM_BANKS_TYPE_MIN_E = CM_SHARED_COUNTERS_BANKS_E,
    CM_BANKS_TYPE_MAX_E = CM_ACCUFLOW_COUNTERS_BANKS_E
} cm_banks_type_e;


/* General defines */
#define CM_BLOCK_SIZE_MASK (0x3FFF)            /* Bulk block size mask */

/* Context processing macros */
#define CM_CNTX_TYPE_GET(cntx)  (cntx & UINT8_MAX)
#define CM_CNTX_SIZE_GET(cntx)  ((cntx >> 8) & CM_BLOCK_SIZE_MASK)
#define CM_CNTX_SET(type, size) (((size & CM_BLOCK_SIZE_MASK) << 8) | (type & UINT8_MAX))

/**
 * Counter index
 *   This is the block allocator index that contains the element offset of the first line
 * of a block.  It must be of the same base type as ba_index_t.
 */
typedef ba_index_t cm_index_t;

/**
 * Counter client handle
 *   This is the handle associated with a single client of the counter
 * manager.  It is returned when the client registers a set of
 * callback handlers and used only to unregister that client.
 */
typedef void *cntr_client_handle_t;

/**
 * Counter Set Type
 *   This is the hardware independent counter type value.
 */
#define FOREACH_COUNTER_MANAGER_TYPE(F)                               \
    F(CM_TYPE_INVALID = 0,                "INVALID")                  \
    F(CM_TYPE_PACKET_COUNTER_E = 1,       "PACKET")                   \
    F(CM_TYPE_BYTE_COUNTER_E,             "BYTE")                     \
    F(CM_TYPE_PACKET_AND_BYTE_E,          "PACKET AND BYTE")          \
    F(CM_TYPE_RIF_BASIC_E,                "RIF_BASIC")                \
    F(CM_TYPE_RIF_ENHANCED_E,             "RIF_ENHANCED")             \
    F(CM_TYPE_RIF_MIXED_1_E,              "RIF_MIXED_1")              \
    F(CM_TYPE_RIF_MIXED_2_E,              "RIF_MIXED_2")              \
    F(CM_TYPE_RIF_BASIC_REDUCED_E,        "RIF_BASIC_REDUCED")        \
    F(CM_TYPE_RIF_ENHANCED_REDUCED_E,     "RIF_ENHANCED_REDUCED")     \
    F(CM_TYPE_RIF_MIXED_1_REDUCED_E,      "RIF_MIXED_1_REDUCED")      \
    F(CM_TYPE_RIF_MIXED_2_REDUCED_E,      "RIF_MIXED_2_REDUCED")      \
    F(CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E, "ACCUFLOW_PACKET_AND_BYTE") \
    F(CM_TYPE_ESTIMATOR_E, "ESTIMATOR")                               \
    F(CM_TYPE_MAX_E = CM_TYPE_ESTIMATOR_E, "")                        \
    F(CM_TYPE_NUM_E = CM_TYPE_MAX_E + 1, "")

typedef enum cm_type {
    FOREACH_COUNTER_MANAGER_TYPE(SX_GENERATE_ENUM) \
} cm_type_e;

/**
 * Hardware counter set type
 *   This is the PRM encoding of the hardware independent counter set
 * type.
 */
typedef uint8_t cm_hw_type_t;

typedef struct cm_attr {
    cm_type_e    type;
    cm_hw_type_t hw_type;
    uint32_t     hw_len;
    uint32_t     size;
    uint32_t     ref;
} cm_attr_t;

/**
 * Counter relocation callback function.
 *   This callback is called when the bin allocator relocates a block.  It
 * is up to the user provided handler to decide if it needs to do anything
 * based on the lid.
 *
 * @param[in] lid  - The logical ID being relocated
 * @param[in] type - The hardware independent type of this LID
 * @param[in] hw_type - The hardware dependent type of this LID
 * @param[in] old_index  - The new offset associated with 'lid'
 * @param[in] new_index  - The new offset into array for 'lid'
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_STATUS_ERROR - Callback was unable to update HW
 *
 * NOTE:
 *   The callback will never be called while any user holds a lock on the
 * block.  While all the callbacks for a block are being called, the counter
 * manager will not grant any user lock for the block so the callback
 * handlers MUST NOT attempt to get the lock.
 */
typedef sx_status_t (*hal_cb_relocate_t)(cm_logical_id_t lid,
                                         uint32_t        offset,
                                         cm_type_e       type,
                                         cm_hw_type_t    hw_type,
                                         cm_index_t      old_index,
                                         cm_index_t      new_index);


/**
 * Counter clear callback function
 *   This callback is called as part of counter relocation.  It is used to
 * clear the new HW counter prior to the first use of it.
 *
 * @param[in] lid - The logical ID of the counter being relocated
 * @param[in] type - The hardware independent type of this LID
 * @param[in] hw_type - The hardware dependent type of this LID
 * @param[in] new_index - The counter offset in array to clear
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_CMD_UNSUPPORTED - lid not supported by callback
 * @return SX_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_STATUS_ERROR - Callback was unable to update HW
 *
 * NOTE:
 *   If the callback handler does not support clear on the provided logical
 * handle, it returns SX_STATUS_UNSUPPORTED.  Once the first callback handler
 * returns SX_STATUS_SUCCESS, the counter manager will stop calling
 * handlers.
 */
typedef sx_status_t (*hal_cb_clear_t)(cm_logical_id_t lid,
                                      cm_type_e       type,
                                      cm_hw_type_t    hw_type,
                                      cm_index_t      new_index);


/**
 * Counter add function
 *   This callback is called as part of counter relocation.  It is used
 * to add the contents of the old HW counter to the new counter once
 * all users of the old_id have switched to the new_id.
 *
 * @param[in] lid - The logical ID of the counter being relocated
 * @param[in] type - The hardware independent type of this LID
 * @param[in] hw_type - The hardware dependent type of this LID
 * @param[in] old_index - The index into counter array of source counter
 * @param[in] new_index - The index into counter array of target counter
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_CMD_UNSUPPORTED - lid not supported by callback
 * @return SX_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_STATUS_ERROR - Callback was unable to update HW
 *
 * NOTE:
 *   If the callback handler does not support add on the provided logical
 * ID, it returns SX_STATUS_UNSUPPORTED.  Once the first callback handler
 * returns SX_STATUS_SUCCESS, the counter manager will stop calling
 * handlers.
 */
typedef sx_status_t (*hal_cb_add_t)(cm_logical_id_t lid,
                                    cm_type_e       type,
                                    cm_hw_type_t    hw_type,
                                    cm_index_t      old_index,
                                    cm_index_t      new_index);

sx_status_t cm_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t cm_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

const char * cm_type_str(cm_type_e type);

/**
 * Initialize the counter manager module
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_ALREADY_INITIALIZED - module already initialized
 * @return SX_STATUS_ERROR - Internal SDK error
 */
sx_status_t cm_init(sx_flow_counter_params_t *init_params_p);


/**
 * Deinitialize counter manager module
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED if module not initialized
 * @return SX_STATUS_RESOURCE_IN_USE if at least one user still active
 */
sx_status_t cm_deinit(void);

/**
 * Initialize a user of the counter manager
 *
 * @param[in] relocate - HAL function to relocate counters
 * @param[in] clear - HAL function to clear a counter
 * @param[in] add - HAL function to add contents of old counter to new
 *                  after relocation.
 * @param[out] user_handle_p - Handle to be used for for deinit
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_NULL - No return handle provided
 * @return SX_STATUS_NO_RESOURCES if no more clients are allowed
 *
 * NOTE:
 *   A user is not required to provide all callbacks.  Multiple users
 * that are always active together may coordinate callbacks to minimize
 * the number of separate calls needed for relocation.
 */
sx_status_t cm_user_init(hal_cb_relocate_t     relocate,
                         hal_cb_clear_t        clear,
                         hal_cb_add_t          add,
                         cntr_client_handle_t *user_handle_p);


/**
 * Deinitialize a user of the counter manager
 *
 * @param[in] handle - The handle returned by cm_user_init()
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - Invalid handle
 *
 * NOTE:
 *   It is the responsibility of each user to dereference or delete all
 * counters that it has allocated or referenced prior to calling this API.
 */
sx_status_t cm_user_deinit(cntr_client_handle_t handle);

/**
 * This function provides SW allocation of a counter bulk
 *
 * @param[in] type - Type of counter to allocate
 * @param[in] size - Number of counter to allocate
 * @param[out] lid_p - Location to return logical counter ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR if type is invalid or lid_p is NULL
 * @return SX_STATUS_PARAM_NULL - lid_p is NULL
 * @return SX_STATUS_NO_RESOURCES if no counters are available
 */
sx_status_t cm_bulk_block_add(cm_type_e type, uint32_t size, cm_logical_id_t *lid_p);

/**
 * This function provides SW allocation of a counter
 *
 * @param[in] type - Type of counter to allocate
 * @param[out] lid_p - Location to return logical counter ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR if type is invalid or lid_p is NULL
 * @return SX_STATUS_PARAM_NULL - lid_p is NULL
 * @return SX_STATUS_NO_RESOURCES if no counters are available
 */
sx_status_t cm_block_add(cm_type_e type, cm_logical_id_t *lid_p);


/**
 * This function provides SW deallocation of a counter
 *
 * @param[in] lid - Logical counter ID to release
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Reference count > 1
 */
sx_status_t cm_block_delete(cm_logical_id_t lid);


/**
 * Add a reference to a previously allocated counter
 *
 * @param[in] lid - The logical ID of the counter being referenced
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 */
sx_status_t cm_ref_inc(cm_logical_id_t lid);


/**
 * Delete a reference to a previously allocated counter
 *
 * @param[in] lid - The logical ID of the counter being de-referenced
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is not allocated or invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Ref count 1 so block must be deleted
 */
sx_status_t cm_ref_dec(cm_logical_id_t lid);


/**
 * Modify the reference count associated with an allocated counter
 *
 * @param[in] lid - The logical ID of the counter being de-referenced
 * @param[in] val - The increment/decrement value
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is not allocated or invalid
 * @return SX_STATUS_ERROR - Internal error
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE - Updated count would be outside valid range
 */
sx_status_t cm_ref_modify(cm_logical_id_t lid, int32_t val);


/**
 * Lock a counter in order to perform HW operations
 *
 * @param[in] lid - The logical ID of the counter to lock
 * @param[out] type_p - The hardware independent type of this LID
 * @param[out] hw_type_p - The hardware dependent type of this LID
 * @param[out] index_p - Current index into counter array for this lid
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_NULL - index_p is null
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_RESOURCE_IN_USE - Lock already active on resource
 */
sx_status_t cm_lock(cm_logical_id_t lid,
                    cm_type_e      *type_p,
                    cm_hw_type_t   *hw_type_p,
                    cm_index_t     *index_p);


/**
 * Release a locked counter
 *
 * @param[in] lid - The logical ID of the counter to unlock
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - LID is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_NO_RESOURCES - Lock not held on counter ID
 */
sx_status_t cm_unlock(cm_logical_id_t lid);


/**
 * Return the lid counter attributes
 *
 * @param[in] lid - The logical ID of the counter
 * @param[out] attr_p - Pointer to where to store lid attributes
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - LID is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_PARAM_NULL - attr_p is NULL
 */
sx_status_t cm_lid_attr_get(cm_logical_id_t lid, cm_attr_t *attr_p);


/**
 * This function clears a value of counter.
 *
 * NOTE:
 *   This function supports only Accumulated counters.
 *
 * @param[in] lid - Logical counter group ID
 * @param[in] offset - offset of the counter to clear
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_UNSUPPORTED - if lid points to unsupported counter type
 */
sx_status_t cm_block_clear(cm_logical_id_t lid, uint32_t offset);

/**
 * This function returns a value of counter.
 *
 * NOTE:
 *   This function supports only Accumulated counters.
 *
 * @param[in] lid - Logical counter group ID
 * @param[in] offset - offset of the counter to read
 * @param[in/out] counter_set_p -
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_MODULE_UNINITIALIZED - counter manager not initialized
 * @return SX_STATUS_PARAM_ERROR - lid is invalid
 * @return SX_STATUS_ERROR - Handle is invalid
 * @return SX_STATUS_UNSUPPORTED - if lid points to unsupported counter type
 */
sx_status_t cm_block_get(cm_logical_id_t lid, uint32_t offset, sx_flow_counter_set_t *counter_set_p);

/**
 * Function get type of the counter bank by its logical ID.
 *
 * @param[in] lid - The logical ID of the counter that has to be checked
 *
 * @return CM_SHARED_COUNTERS_BANKS_E - counter is usual flow counter.
 * @return CM_ACCUFLOW_COUNTERS_BANKS_E - counter is Accumulated counter.
 */
cm_banks_type_e cm_counter_bank_type_get(cm_logical_id_t lid);

sx_status_t cm_counter_relocate_force(cm_logical_id_t lid);
sx_status_t cm_counter_relocate_undo(cm_logical_id_t lid);

#endif /* __COUNTER_MANAGER_H__ */
