#!/bin/sh
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#


rm -rf aclocal.m4 autom4te.cache stamp-h1 libtool configure config.* Makefile.in Makefile
rm -rf config/*

for a in utils dbg_dump_modules flow_counter bulk_counter kvd policer host_ifc ethl2 pgt ethl3 acl bridge span sx_api net_lib sx_core sx_api_ib ibl3 ibl2 tcal3 sx_ib_lib resource_manager dbg timer tunnel sx_api_utils sx_api_utils/player sx_api_utils/sniffer bridge_lib router_lib counters counters/counter_manager policer_lib mpe_manager tid_manager sx_reg_bulk issu gc mc_container mpls tele atcam bfd register stateful_db flex_parser flex_modifier flex_pm fuse_dbg linear_manager sx_debug_cmd_client xm adaptive_routing truncation_profile; do
	rm -rf $a/Makefile 2>&1
	rm -rf $a/Makefile.in 2>&1
done
