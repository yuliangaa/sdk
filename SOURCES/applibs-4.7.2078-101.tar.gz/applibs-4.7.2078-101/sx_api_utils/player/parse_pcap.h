/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __PARSE_PCAP_H_INCLUDED__
#define __PARSE_PCAP_H_INCLUDED__

#include <stdint.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

#define PREFIX_ON_MISMATCH "[Stop on mismatch] "
#define PREFIX_BEFORE_FAIL "[Stop before fail] "
#define PREFIX_STOP_ON_ID  "[Stop on ID] "

/************************************************
 *  Local Macros
 ***********************************************/

#define WAIT_FOR_ENTER_PRESS(prefix, ch)                \
    {                                                   \
        printf(prefix "Press 'Enter' to continue ..."); \
        while ((ch = getchar()) != '\n' && ch != EOF) { \
            /* Flush user input until newline */        \
        }                                               \
    }

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Function prototype for parsing packets from the pcap
 *
 * @param[in] hContext                 - context object provided in parse_pcap function.
 * @param[in] tv_sec                   - timestamp seconds of the packet (as written in file)
 * @param[in] tv_usec                  - timestamp microseconds of the packet (as written in file)
 * @param[in] buffer                   - current packet data from the pcap file
 * @param[in] buffer_size              - current packet data size
 *
 * @return 0 on success.
 *         non-zero code on failure. (Will stop parsing)
 */
typedef int (* parse_func)(void * hContext, uint32_t tv_sec, uint32_t tv_usec, const char * const buffer,
                           uint32_t buffer_size);

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function will parse the pcap file provided,
 * and then call the parser function provided for each
 * packet frame in the file.
 *
 * @param[in] file_path                - path of the pcap file provided
 * @param[in] expected_linktype        - expected link type field
 * @param[in] parser				   - parser function to call for each frame
 * @param[in] hContext                 - (optional) context object for the parser function.
 * @param[in] max_snaplen              - maximum supported snaplen (compared against file header)
 *
 * @return 0 on success.
 *         non-zero code on failure.
 */
int parse_pcap(const char * file_path,
               uint32_t     expected_linktype,
               parse_func   parser,
               void       * hContext,
               uint32_t     max_snaplen);

#endif /* __PARSE_PCAP_H_INCLUDED__ */
