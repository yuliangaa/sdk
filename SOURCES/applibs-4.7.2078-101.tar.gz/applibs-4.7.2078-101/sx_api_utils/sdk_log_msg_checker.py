#!/usr/bin/env python3
"""
# SDK Log Messages Checker
#
# Performs validation and automated fixing of log
# messages use in the SDK source files.
#
"""
__title__ = 'SDK_LOG_MSG_CHECKER'
__author__ = 'oleksandrv, ypasichnyk'
__version__ = '0.4.0'
__release__ = 'June-2022'


from io import open
import os
import re
import argparse

from utils.utils import g_logger, g_pbar, AdbParser, LogLevel as llvl, FontColor as fc


class SdkLogMsgChecker():
    """ Object for SX layer sources validation
    """

    def __init__(self):
        """ Constructor parses arguments and defines working mode
        """
        parser = argparse.ArgumentParser(add_help=False)
        cmd_group = parser.add_mutually_exclusive_group(required=True)

        # SDK log message checker arguments
        cmd_group.add_argument('-f', '--fix', type=str, nargs='?', const='default', metavar='FILE')
        cmd_group.add_argument('-v', '--validate', type=str, nargs='?', const='default', metavar='FILE')
        cmd_group.add_argument('-h', '--help', action='store_true')

        parser.add_argument('-d', '--debug', action='store_true')

        self.args = parser.parse_args()

    def _help(self):
        # prepare program head
        head = '  {}{{}}[version {} | {}]'.format(__title__, __version__, __release__)
        ready_head = head.format(' ' * (92 - len(head)))
        # create initial header text
        help_text = ' {0:-^90}\n{1}\n {0:-^90}\n'.format('', ready_head)

        help_text += '  The tool provides functionality for validation and automated fixing of the log messages\n' + \
                     '  in the SDK source files.\n\n' + \
                     '   1. Run SDK log messages validation:\n' + \
                     '      {} -v [--debug]\n\n'.format(os.path.basename(__file__)) + \
                     '   2. Run SDK log messages automated fixing:\n' + \
                     '      {} -f [--debug]\n\n'.format(os.path.basename(__file__)) + \
                     '   3. Get a help:\n' + \
                     '      {} -h\n\n'.format(os.path.basename(__file__)) + \
                     '{:-^90}\n'.format('')

        g_logger.normal(help_text, end='\n', label=False)

    def _get_sdk_files(self, types):
        """ Lookup all SX layer files in the applibs """
        sdk_files = []
        black_list = ('./builds',)

        g_logger.normal('Looking for {} files in the sys_sdk/ ..'.format(', '.join(['\'%s\'' % t for t in types])))
        g_logger.normal('Files from {} will be ingnored'.format(', '.join(['\'%s\'' % f for f in black_list])))

        applibs_path = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../../')
        for root, _, files in os.walk(applibs_path):
            if root.startswith(black_list):
                continue

            sdk_files += [os.path.join(root, file) for file in files if file.endswith(tuple(types))]

        g_logger.success('Found {} files'.format(len(sdk_files)))

        return sdk_files

    def run(self):
        """ Run commands execution """

        if self.args.help:
            # user requested a help
            self._help()
            return

        elif self.args.validate or self.args.fix:
            """ run validation and, possibly, logs fixing """

            if self.args.debug:
                # enable debug logs
                g_logger.set_level(llvl.DEBUG)

                # disable progress bar when verbosity is high
                g_pbar.disable()

            # validate log messages
            invalid_msg, failed_msg = self.validate_msg_new_lines(self._get_sdk_files(('.h', '.c')))

            # print messages where parsing has failed
            failed_messages_num = sum([len(msgs) for msgs in failed_msg.values()])
            if failed_messages_num:
                g_logger.error('There are {} log messages in {} files where parsing has failed'.format(failed_messages_num, len(failed_msg)))
                for sdk_file, logs in failed_msg.items():
                    g_logger.error('  {} ({} logs):\n      - {}\n'.format(sdk_file, len(logs), '\n      - '.join(logs)), end='\n', label=False)
            else:
                g_logger.success('All log messages were parsed normally')

            # print results of the validation
            invalid_messages_num = sum([len(msgs) for msgs in invalid_msg.values()])
            if invalid_messages_num:
                g_logger.warning('There are {} log messages in {} files that should be fixed'.format(invalid_messages_num, len(invalid_msg)))
                for sdk_file, logs in invalid_msg.items():
                    g_logger.debug('  {} ({} logs):\n      - {}\n'.format(sdk_file, len(logs), '\n      - '.join(logs)), end='\n', label=False)
            else:
                g_logger.success('All log messages are just fine')

            if self.args.fix:
                # fix log messages
                self.fix_msg_new_lines(invalid_msg)

    def validate_msg_new_lines(self, sdk_files):
        """ Function lookup and validates all log messages in the SDK """

        # global counters
        g_counters = {
            'ERR': 0, 'WRN': 0, 'NTC': 0, 'INF': 0, 'DBG': 0,
            'ERROR': 0, 'WARNING': 0, 'NOTICE': 0, 'INFO': 0, 'DEBUG': 0,
            'FAILED': 0, 'WITH_LOGS': 0, 'TOTAL': 0, 'WRAPPED': 0, 'STRING': 0, 'END_NL': 0
        }

        # dictionary with SDK files and list of messages without newlines
        invalid_msg = {}
        failed_msg = {}

        # print statistics per file
        per_file_tmpl = ' | {:80} |' + ' {:^4} |' * 10
        separator = (' + {0:-^80} +' + ' {0:-^4} +' * 10).format('')

        # header
        columns_help = '[Columns legend]\n\n' + \
                       '  FILE - name of the SDK source file.\n' + \
                       '  LOGS - number of log messages found in the file.\n' + \
                       '  FAIL - number of log messages where parsing failed.\n' + \
                       '  WRAP - number of log messages that use indirect LOG macros.\n' + \
                       '  STR  - number of log messages that are strings.\n' + \
                       '  NL   - number of log messages with new-line symbol at the end.\n' + \
                       '  ERR  - number of log messages that have error log level.\n' + \
                       '  WRN  - number of log messages that have warning log level.\n' + \
                       '  NTC  - number of log messages that have notice log level.\n' + \
                       '  INF  - number of log messages that have info log level.\n' + \
                       '  DBG  - number of log messages that have debug log level.\n'
        g_logger.normal(columns_help, end='\n')

        head_line = per_file_tmpl.format('FILE', 'LOGS', 'FAIL', 'WRAP', 'STR', 'NL', 'ERR', 'WRN', 'NTC', 'INF', 'DBG')

        # check each file
        for sdk_file in sdk_files:
            # local counters
            l_counters = {
                'ERR': 0, 'WRN': 0, 'NTC': 0, 'INF': 0, 'DBG': 0,
                'ERROR': 0, 'WARNING': 0, 'NOTICE': 0, 'INFO': 0, 'DEBUG': 0,
                'FAILED': 0, 'TOTAL': 0, 'WRAPPED': 0, 'STRING': 0, 'END_NL': 0
            }

            # go through each sdk file
            with open(sdk_file, 'r', errors='ignore') as fp:
                f_content = fp.read()
                f_lines = f_content.split('\n')

            # match API functions using regex
            pattern = r'SX_LOG(?:_(?P<level>(?:ERR|WRN|NTC|INF|DBG))\(|\(SX_LOG_(?P<inlevel>(?:ERROR|WARNING|NOTICE|INFO|DEBUG)),)\s*(?P<msg>(?:\"[\w\ \%\,\.\-\\\/\:\=\#\[\]\(\)\*\"\'\s\!\?\<\>\&\^\$\@\~\`]*\"|\w*))\s*(?:,|\);)'
            entries = re.findall(pattern, f_content)

            for match in entries:
                # check parsed data is correct
                if (match[0] and match[1]) or not (match[0] or match[1]):
                    # log call is recognized as raw and wrapped simultaneously
                    # or log call has no recognized level feature at all
                    l_counters['FAILED'] += 1

                    if sdk_file in failed_msg:
                        failed_msg[sdk_file].append(match[2])
                    else:
                        failed_msg[sdk_file] = [match[2]]

                    continue

                # check out if message is ended somewhere in the middle
                msg_end_pattern = r'(?P<end_feature>(?<!PRI(x|u)8 )(?<!PRI(x|u)64 )(?<!\\)\"\s*,)'
                end_index = re.search(msg_end_pattern, match[2])

                if end_index:
                    log_msg = match[2][:end_index.start()] + '"'
                else:
                    log_msg = match[2]

                if log_msg.count('"') % 2 != 0:
                    l_counters['FAILED'] += 1
                    # g_logger.error('Failed to parse following message:\n    {}\n  Parsed string:\n    {}'.format(match[2], log_msg), end='\n')

                    if sdk_file in failed_msg:
                        failed_msg[sdk_file].append(match[2])
                    else:
                        failed_msg[sdk_file] = [match[2]]

                    continue

                is_wrapped = bool(match[0])  # log call use one of the wrappers, not SX_LOG()
                is_msg_str = log_msg and log_msg.startswith('"')  # msg is a string, not variable
                is_end_nl = is_msg_str and log_msg.endswith('\\n"')  # msg is ended with new line symbol

                # statistics counting
                l_counters['WRAPPED'] += 1 if is_wrapped else 0
                l_counters['STRING'] += 1 if is_msg_str else 0
                l_counters['END_NL'] += 1 if is_end_nl else 0

                # increase log level statistics
                if is_wrapped:
                    l_counters[match[0]] += 1
                else:
                    l_counters[match[1]] += 1

                # store lines with missed new lines
                if is_msg_str and not is_end_nl:
                    if sdk_file in invalid_msg:
                        invalid_msg[sdk_file].append(log_msg)
                    else:
                        invalid_msg[sdk_file] = [log_msg]

            # statistics counting
            if len(entries):
                # print head line for better UX
                if g_counters['WITH_LOGS'] % 50 == 0:
                    g_logger.normal(separator, end='\n', label=False)
                    g_logger.normal(head_line, end='\n', label=False)
                    g_logger.normal(separator, end='\n', label=False)

                g_counters['WITH_LOGS'] += 1
                l_counters['TOTAL'] += len(entries)

            # update global statistics
            for k, v in l_counters.items():
                if k not in g_counters:
                    g_logger.error('Key mismatch between local and global statistics. Key "{}"'.format(k))

                g_counters[k] += v

            # print file statistics
            if len(entries):
                g_logger.normal(per_file_tmpl.format(sdk_file, l_counters['TOTAL'], l_counters['FAILED'], l_counters['WRAPPED'],
                                                     l_counters['STRING'], l_counters['END_NL'],
                                                     l_counters['ERR'] + l_counters['ERROR'],
                                                     l_counters['WRN'] + l_counters['WARNING'],
                                                     l_counters['NTC'] + l_counters['NOTICE'],
                                                     l_counters['INF'] + l_counters['INFO'],
                                                     l_counters['DBG'] + l_counters['DEBUG']),
                                end='\n', label=False)

        g_logger.normal(separator, end='\n', label=False)
        g_logger.normal(columns_help, end='\n\n')

        g_logger.success('[General statistics]')
        g_logger.normal('  SDK source files found ......... {}'.format(len(sdk_files)), end='\n', label=False)
        g_logger.normal('  SDK source files with logs ..... {}'.format(g_counters['WITH_LOGS']), end='\n', label=False)
        g_logger.normal('  Total log messages found ....... {}'.format(g_counters['TOTAL']), end='\n', label=False)
        g_logger.normal('  Incorrectly proceed messages ... {}'.format(g_counters['FAILED']), end='\n', label=False)
        g_logger.normal('  Wrapped log messages (LM) ...... {}'.format(g_counters['WRAPPED']), end='\n', label=False)
        g_logger.normal('  Log messages as a sting ........ {}'.format(g_counters['STRING']), end='\n', label=False)
        g_logger.normal('  Log messages with new line ..... {}'.format(g_counters['END_NL']), end='\n\n', label=False)

        g_logger.success('[Per-type statistics]')
        g_logger.normal('  ERROR level messages ........... {} / wrapped {}'.format(g_counters['ERR'] + g_counters['ERROR'], g_counters['ERR']), end='\n', label=False)
        g_logger.normal('  WARNING level messages ......... {} / wrapped {}'.format(g_counters['WRN'] + g_counters['WARNING'], g_counters['WRN']), end='\n', label=False)
        g_logger.normal('  NOTICE level messages .......... {} / wrapped {}'.format(g_counters['NTC'] + g_counters['NOTICE'], g_counters['NTC']), end='\n', label=False)
        g_logger.normal('  INFO level messages ............ {} / wrapped {}'.format(g_counters['INF'] + g_counters['INFO'], g_counters['INF']), end='\n', label=False)
        g_logger.normal('  DEBUG level messages ........... {} / wrapped {}'.format(g_counters['DBG'] + g_counters['DEBUG'], g_counters['DBG']), end='\n\n', label=False)

        return invalid_msg, failed_msg

    def fix_msg_new_lines(self, invalid_msg):
        """ Function run over SDK files and fix them """
        def fix_new_lines(raw_msg):
            """ Function fixes newlines at the end of message """
            if raw_msg.endswith('\\n'):
                # message already ends with the newline
                return raw_msg

            # Possible scenarios:
            #   'msg\n.' -> 'msg.\n'
            #   'msg.'   -> 'msg.\n'
            #   'msg'    -> 'msg\n'

            if raw_msg.endswith('\\n.'):
                # fix message if final dot is after the newline
                raw_msg = raw_msg[:-3] + '.'

            return raw_msg + '\\n'

        def fix_spacing(raw_msg):
            """ Function fixes spacing around specific symbols """
            # Charachter | Expected spacing format
            # ':'        | 'X: Y'
            # ','        | 'X, Y'
            # ';'        | 'X; Y'

            replacements = {
                # symbol: (spaces_before, spaces_after)
                ',': (0, 1), ':': (0, 1), ';': (0, 1)
            }

            for symbol, cfg in replacements.items():
                # do extention once for some types that require spaces around
                extended_symbol = ' ' * cfg[0] + symbol + ' ' * cfg[1]
                raw_msg = raw_msg.replace(symbol, extended_symbol)

                # do shrinking till its possible
                shrinking_symbols = ((' ' * (cfg[0] + 1) + symbol, ' ' * cfg[0] + symbol),
                                     (symbol + ' ' * (cfg[1] + 1), symbol + ' ' * cfg[1]))
                for sh_symb in shrinking_symbols:
                    # for each symbol run shrinking
                    while True:
                        if sh_symb[0] not in raw_msg:
                            # nothing to shrink
                            break

                        # shrink symbol
                        raw_msg = raw_msg.replace(sh_symb[0], sh_symb[1])

            return raw_msg.strip()

        g_logger.normal('Running automatic fixing for {} source files ..'.format(len(invalid_msg)))

        fixed_messages = 0
        for sdk_file, messages in invalid_msg.items():
            # go through every file
            g_logger.normal('Fixing {} messages in "{}"'.format(len(messages), sdk_file))

            with open(sdk_file, 'r') as fp:
                # read all file content
                content = fp.read()

            for msg in messages:
                # check and fix all messages
                if not (msg.startswith('"') and msg.endswith('"')):
                    # skip log messages with variables
                    continue

                # remove quotes around
                raw_msg = msg[1:-1].strip()

                # fix newlines and spacing
                g_logger.debug('  > Fixing new_lines in "{}"'.format(raw_msg))
                raw_msg = fix_new_lines(raw_msg)
                g_logger.debug('  > Fixing spacing in "{}"'.format(raw_msg))
                raw_msg = fix_spacing(raw_msg)

                # return quotes for messages
                ready_msg = '"{}"'.format(raw_msg)
                g_logger.debug('  > Replacing:\n    {}\n    {}'.format(msg, ready_msg))
                content = content.replace(msg, ready_msg)
                fixed_messages += 1

            with open(sdk_file, 'w') as fp:
                # write fixed file content
                fp.write(content)

        g_logger.success('Automatically fixed {} messages'.format(fixed_messages))


def main():
    checker = SdkLogMsgChecker()
    checker.run()


if __name__ == '__main__':
    main()
