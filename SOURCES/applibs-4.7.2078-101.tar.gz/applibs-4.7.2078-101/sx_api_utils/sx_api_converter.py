#!/usr/bin/env python3
"""
# ADB Converter tool
#
# Provide generation of ADB header files based on existing
# API header files. ADABE file is XML-formatted file with
# all data about APIs data structures.
#
"""
__title__ = 'ADB_CONVERTER_TOOL'
__author__ = 'oleksandrv'
__version__ = '0.8.2b'
__release__ = 'Mar-2021'

import os
import re
import sys
import glob
import json
import time
import getpass
import argparse
import xml.etree.ElementTree as ET

from string import Template
from datetime import datetime

# import SX API Utils library
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.utils import g_logger, g_pbar, LogLevel as llvl, NodeType as nt, FontColor as fc, TimeOutException, timeout


class Pattern:
    ADB_FILE = '''
<!--
     ____________ _________________________________________________
     File:        {}
     Author(s):   {}
     Description: This file stores data for C header file content
                  generation. Each type of data is separated into
                  its own section. General data moved to common.adb.
     Date:        {}
     License:     This program is the confidential and proprietary
                  product of Mellanox Technologies LTD.
                  Any unauthorized use, reproduction or transfer of
                  this program is strictly prohibited.

                  Copyright (c) 1999 by Mellanox Technologies LTD
                  All Rights Reserved.
     ____________ _________________________________________________
-->

<!-- Section contains data for {} header file generation -->
<headerData path="{}" desc="{}">
    <nodes>{}
    </nodes>
</headerData>
'''
    INCLUDE = '''
        <include name="{}" desc="{}" />'''
    DEFINE = '''
        <define name="{}" value="{}" desc="{}" />'''
    TYPEDEF = '''
        <typedef name="{}" type="{}" desc="{}" />'''
    ENUM = '''
        <enum name="{}" typename="{}" desc="{}"{}>{}
        </enum>'''
    ENUM_FIELD = '''
            <field name="{}" value="{}" cont="{}" desc="{}" />'''
    STRUCT = '''
        <struct name="{}" typename="{}" desc="{}">{}
        </struct>'''
    STRUCT_FIELD = '''
            <field name="{}" type="{}" desc="{}" {}/>'''
    UNION = '''
        <union name="{}" typename="{}" desc="{}">{}
        </union>'''
    UNION_FIELD = '''
            <field name="{}" type="{}" desc="{}" {}/>'''


class HeaderParser(object):
    def __init__(self):
        self._h_content = ''
        self._h_lines = []

        self._parsers = {nt.INCLUDE: self._parse_include,
                         nt.DEFINE: self._parse_define,
                         nt.ENUM: self._parse_enum,
                         nt.TYPEDEF: self._parse_typedef,
                         nt.STRUCT: self._parse_struct,
                         nt.UNION: self._parse_union}

    def _read_header(self, source_h):
        with open(source_h, 'r') as f:
            self._h_content = f.read()
            self._h_lines = self._h_content.split('\n')

    def parse(self, source_h):
        self._read_header(source_h)
        failures = []

        cfg = {}
        for ntype, parser in self._parsers.items():
            try:
                cfg[ntype] = parser()
            except TimeOutException:
                g_logger.warning('Failed to parse {} in "{}"'.format(ntype, source_h))
                failures.append(ntype)
                continue

        if len(failures) == len(list(self._parsers.keys())):
            # if all nodes parsing failed call exception
            raise TimeOutException()

        return cfg, failures

    def _index_data(self, text):
        """ Used to find line of text in header """
        for idx, line in enumerate(self._h_lines):
            pos = line.find(text)
            if pos >= 0 and ((pos + len(text)) >= len(line) or not line[pos + len(text)].isalpha()):
                g_logger.debug('Index of "{}" is {}'.format(text, idx))
                return idx

        return 0

    @timeout(30)
    def _parse_include(self):
        # previous filtering
        if '#include' not in self._h_content:
            g_logger.debug('Skipped includes parsing')
            return []

        data = []
        pattern = r'#include [<"](?P<iname>.*)[>"][ ]*(?P<idesc>\/*.*\*\/)?'
        entries = re.findall(pattern, self._h_content)
        g_logger.debug('Found {} INCLUDE groups'.format(len(entries)))

        for match in entries:
            if match[0].endswith('_auto.h'):
                continue
            g_logger.trace(' INC LINE > {}'.format(match))
            data.append({'idx': self._index_data(match[0]),
                         'name': match[0], 'desc': match[1]})

        return data

    @timeout(30)
    def _parse_def_enum(self):
        # previous filtering
        if '#define FOREACH_' not in self._h_content:
            g_logger.debug('Skipped defenums parsing')
            return []

        data = []
        # pattern = r'#define FOREACH_(?P<foreach>[A-Z_]*)?\(F\)[ \\]*[\r\n](?P<fields>(?:[\r\n]|[^;])+\))\n\n(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?[ ]*enum(?P<ename> .*)?[ ]*{(?:[a-zA-Z0-9_.,-=/* \n\t\(\)]*)?}[ ]*(?P<tename> .*)?;'
        # pattern = r'#define FOREACH_(?P<foreach>[A-Z_]*)?\(F\)[ \\]*[\r\n](?P<fields>(?:[\r\n]|[^;])+\))\n\n(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?enum(?P<ename> [a-zA-Z0-9_]*)?[ ]?{(?:[a-zA-Z0-9_.,-=/* \n\t\(\)]*)?}[ ]?(?P<tename> [a-zA-Z0-9_]*)?;'
        # pattern = r'#define FOREACH_(?P<foreach>[A-Z_]*)?\(F\)[ \\]*[\r\n](?P<fields>(?:[\r\n]|[^;])+\))\n\n(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?[\n]*(typedef )?enum(?P<ename> [a-zA-Z0-9_]*)?[ ]?{(?:[a-zA-Z0-9_.,-=/* \n\t\(\)]*)?}[ ]?(?P<tename> [a-zA-Z0-9_]*)?;'
        # pattern = r'#define FOREACH_(?P<foreach>[A-Z_]*)?\(F\)[ \\]*[\r\n](?P<fields>[^;{]+\)\n)(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?[\n]*(typedef )?enum(?P<ename> [a-zA-Z0-9_]*)?[ ]?{(?:[a-zA-Z0-9_.,-=/* \n\t\(\)]*)?}[ ]?(?P<tename> [a-zA-Z0-9_]*)?;'
        pattern = r'#define FOREACH_(?P<foreach>[A-Z_]*)?\(F\)[ \\]*[\r\n](?P<fields>[^;{]+\)(?:[ ]+\\)?\n)[\n]*(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?[\n]*(typedef )?enum(?P<ename> [a-zA-Z0-9_]*)?[ ]?{(?:[a-zA-Z0-9_.,-=/* \n\t\(\)]*)?}[ ]?(?P<tename> [a-zA-Z0-9_]*)?;'
        entries = re.findall(pattern, self._h_content, re.MULTILINE)
        g_logger.debug('Found {} DEFENUM groups'.format(len(entries)))

        for match in entries:
            g_logger.trace(' DEFENM > {}'.format(match))

            fld_pattern = r'^[ ]*F\((?P<name>[A-Z0-9_]*)[ ]*(?:=(?P<value>[a-zA-Z0-9_. |()<]*)|)(?P<desc>\/\*\*\<[a-zA-Z0-9_ .,:]*\*\/|),[ \\\n]*"(?P<cont>[^"]*)"\)[ ]*'
            fields = re.findall(fld_pattern, match[1], re.MULTILINE)
            g_logger.trace(' FOUND {} DEFENUM FIELDS'.format(len(fields)))

            fields_data = []
            for fld in fields:
                fields_data.append({'name': fld[0], 'value': fld[1], 'desc': fld[2], 'cont': fld[3]})

            data.append({'idx': self._index_data(match[5] if match[5].strip() else ('enum %s' % match[4])),
                         'name': match[4], 'typename': match[5], 'desc': match[2], 'foreach': match[0], 'fields': fields_data})

        return data

    @timeout(30)
    def _parse_enum(self):
        # previous filtering
        if 'enum ' not in self._h_content:
            g_logger.debug('Skipped enums parsing')
            return []

        data = []

        if self._h_content.count('enum ') > self._h_content.count('#define FOREACH_'):
            # check if there are usual enums
            # pattern = r'^(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?enum(?P<ename> .*)? {(?P<fields>[a-zA-Z0-9_.,-=/* \n\t]*)?}(?P<tename> .*)?;$'
            pattern = r'^(?P<e_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?[\n]*(typedef )?enum(?P<ename> .*)? {(?P<fields>[a-zA-Z0-9_.,-=/* \n\t<!]*)?}(?P<tename> .*)?;$'
            entries = re.findall(pattern, self._h_content, re.MULTILINE)
            g_logger.debug('Found {} ENUM groups'.format(len(entries)))

            for match in entries:
                g_logger.trace(' ENM > {}'.format(match))

                fld_pattern = r'^[ \t]*(?P<field_name>[A-Z0-9_]+)[ ]*(?:=[ ]*(?P<field_value>[^,\/]+)?[ ]*)?[, ]?[ \t]*(?P<fld_desc>\/*.*\*\/)?\n'
                fields = re.findall(fld_pattern, match[3], re.MULTILINE)
                g_logger.trace(' FOUND {} ENUM FIELDS'.format(len(fields)))

                fields_data = []
                for fld in fields:
                    fields_data.append({'name': fld[0], 'value': fld[1], 'desc': fld[2], 'cont': ''})

                data.append({'idx': self._index_data(match[4] if match[4].strip() else ('enum %s' % match[2])),
                             'name': match[2], 'typename': match[4], 'desc': match[0], 'foreach': '', 'fields': fields_data})

        return data + self._parse_def_enum()

    @timeout(30)
    def _parse_define(self):
        # previous filtering
        if '#define' not in self._h_content:
            g_logger.debug('Skipped defines parsing')
            return []

        data = []
        pattern = r'(?P<d_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n#define (?P<d_name>[a-zA-Z0-9_]*)[ ]+(?P<d_value>[^\n]*)'
        entries = re.findall(pattern, self._h_content)
        g_logger.debug('Found {} DEFINE groups'.format(len(entries)))

        for match in entries:
            g_logger.debug(' DEF > {}'.format(match))
            data.append({'idx': self._index_data(match[1]),
                         'name': match[1], 'value': match[2], 'desc': match[0]})

        return data

    @timeout(30)
    def _parse_typedef(self):
        # previous filtering
        if 'typedef' not in self._h_content:
            g_logger.debug('Skipped typedefs parsing')
            return []

        data = []
        # pattern = r'(?P<t_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\ntypedef (?P<td_name>[a-zA-Z0-9_ ]+) (?P<d_value>[a-zA-Z0-9_]+);'
        pattern = r'(?P<t_desc>/\*(?:[^/\n]|[\n])+\*+/)?\ntypedef (?P<td_name>[a-zA-Z0-9_ ]+) (?P<d_value>[a-zA-Z0-9_]+);'
        entries = re.findall(pattern, self._h_content)
        g_logger.debug('Found {} TYPEDEF groups'.format(len(entries)))

        for match in entries:
            g_logger.trace(' TPDEF > {}'.format(match))
            data.append({'idx': self._index_data(match[2]),
                         'name': match[2], 'type': match[1], 'desc': match[0]})
        g_logger.trace('DONE typedef parsing')

        return data

    @timeout(30)
    def _parse_union(self):
        # previous filtering
        if 'union' not in self._h_content:
            g_logger.debug('Skipped unions parsing')
            return []

        data = []
        # pattern = r'^(?P<u_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?union(?P<uname> .*)?[ ]?{(?P<fields>[a-zA-Z0-9_.,-=:;\/* \n\t\[\]\'\(\)]*)?}[ ]?(?P<tuname>.*)?;$'
        pattern = r'^(?P<u_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?union(?P<uname> .*)?[ ]?{(?P<fields>[a-zA-Z0-9_.,-=:;\/* \n\t\[\]\'()^]*)?}[ ]?(?P<tuname>.*)?;$'
        entries = re.findall(pattern, self._h_content, re.MULTILINE)
        g_logger.debug('Found {} UNION groups'.format(len(entries)))

        for match in entries:
            g_logger.trace(' UNI > {}'.format(match))

            fld_pattern = r'^[ \t]*(?P<field_type>[a-zA-Z0-9_ ]+)[ ]+(?P<ptr>\*)?[ ]?(?P<field_name>[a-zA-Z0-9_]+)[ ]*(?:\[(?P<arr>[0-9]*)\]|)[ ]*;[ \t]*(?P<fld_desc>\/*.*\*\/)?\n'
            fields = re.findall(fld_pattern, match[3], re.MULTILINE)
            g_logger.trace(' FOUND {} STR FIELDS'.format(len(fields)))

            fields_data = []
            for fld in fields:
                arrsz = fld[3] if fld[3] else ('0' if fld[1] else '')
                g_logger.trace(str(fld))
                fields_data.append({'type': fld[0], 'name': fld[2], 'desc': fld[4], 'arraysize': arrsz})

            data.append({'idx': self._index_data(match[2] if match[2].strip() else match[4]),
                         'name': match[2], 'typename': match[4], 'desc': match[0], 'fields': fields_data})

        return data

    @timeout(30)
    def _parse_struct(self):
        # previous filtering
        if 'struct' not in self._h_content:
            g_logger.debug('Skipped structs parsing')
            return []

        data = []
        # pattern = r'^(?P<u_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?struct(?P<sname> .*)?[ ]?{(?P<fields>[a-zA-Z0-9_.,-=:;\/* \n\t\[\]\'\(\)]*)?}[ ]?(?P<tsname>.*)?;$'
        pattern = r'^(?P<u_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n(typedef )?struct(?P<sname> .*)?[ ]?{(?P<fields>[a-zA-Z0-9_.,-=:;\/* \n\t\[\]\'()^]*)?}[ ]?(?P<tsname>.*)?;$'
        entries = re.findall(pattern, self._h_content, re.MULTILINE)
        g_logger.debug('Found {} STRUCT groups'.format(len(entries)))

        for match in entries:
            g_logger.trace(' STRUCT > {}'.format(match))

            fld_pattern = r'^[ \t]*(?P<field_type>[a-zA-Z0-9_ ]+)(?P<field_ptr>[ ]*\*[ ]*|[ ]+)+(?P<field_name>[a-zA-Z0-9_]+)[ ]*(?P<field_arr_bits>\[.*\]|\:.*)?;[ \t]*(?P<fld_desc>/\*(?:[^*]|[\r\n]|(?:\*+(?:[^*/]|[\r\n])))*\*+/)?\n'
            fields = re.findall(fld_pattern, match[3], re.MULTILINE)
            g_logger.trace(' FOUND {} STRUCT FIELDS'.format(len(fields)))

            fields_data = []
            for fld in fields:
                g_logger.trace(str(fld))
                arr_bit = '[0]' if '*' in fld[1] else fld[3]
                fields_data.append({'type': fld[0], 'name': fld[2], 'arr_bit': arr_bit, 'desc': fld[4]})

            data.append({'idx': self._index_data(match[2] if match[2].strip() else match[4]),
                         'name': match[2], 'typename': match[4], 'desc': match[0], 'fields': fields_data})

        return data


class AdbGenerator(object):
    def __init__(self):
        self._cfg = {}

        self._generators = {nt.INCLUDE: self._gen_include,
                            nt.DEFINE: self._gen_define,
                            nt.ENUM: self._gen_enum,
                            nt.TYPEDEF: self._gen_typedef,
                            nt.STRUCT: self._gen_struct,
                            nt.UNION: self._gen_union}

    def _read_cfg(self, cfg):
        self._cfg = cfg

    def _save_adb(self, adb, content):
        with open(adb, 'w+') as f:
            f.write(content)

    def _validate_xml(self, text):
        # &lt; (<), &amp; (&), &gt; (>), &quot; ("), and &apos; (')
        spec_symbols = [['&', '&amp;'],
                        ['<', '&lt;'],
                        ['>', '&gt;'],
                        ['\"', '&quot;'],
                        ['\'', '&apos;']]

        for (symb, alt) in spec_symbols:
            text = text.replace(symb, alt)

        return text

    def _get_raw_comment(self, comment):
        comment = comment.strip()
        prefixes = ['/**<', '/**', '/*', '//']
        postfixes = ['*/']

        for prefix in prefixes:
            if comment.startswith(prefix):
                comment = comment[len(prefix):]
                break

        for postfix in postfixes:
            if comment.endswith(postfix):
                comment = comment[:-len(postfix)].rstrip()
                break

        comment = '\\n\n'.join([line.strip()[1:].strip() if line.strip().startswith('*') else line for line in comment.split('\n') if line])
        return comment.strip()

    def _strip_typename(self, tname, starts=None, ends=None):
        """ Function strips name of the type.

        :param tname: type name
        :param starts: list of prefixes to strip
        :param ends: list of postfixes to strip
        :return: stripped type name
        """
        for prefix in starts or []:
            tname = tname[len(prefix):] if tname.startswith(prefix) else tname

        for postfix in ends or []:
            tname = tname[:-len(postfix)] if tname.endswith(postfix) else tname

        return tname

    def _merge_data(self, orig_d, new_d):
        common = []

        for key in orig_d:
            if key in new_d:
                g_logger.warning('Intersection has been detected by key {}'.format(key))
                g_logger.warning('ORIG: {}'.format(orig_d[key]))
                g_logger.warning('NEW: {}'.format(new_d[key]))

        orig_d.update(new_d)

        return orig_d

    def generate(self, cfg, dest_adb):
        self._read_cfg(cfg)

        data = {}
        for ntype, cfg in self._cfg.items():
            new_data = self._generators[ntype](cfg)
            if new_data:
                data = self._merge_data(data, new_data)

        nodes = ''
        prev_ntype = None
        for key in sorted(data.keys()):
            if prev_ntype and prev_ntype != data[key]['ntype']:
                # add newline between different types
                nodes += '\n'

            nodes += data[key]['data']
            prev_ntype = data[key]['ntype']

        content = self._gen_file(dest_adb, nodes)

        self._save_adb(dest_adb, content)
        g_logger.normal('File {} has been generated'.format(dest_adb))

    def _gen_file(self, adb, nodes):
        """ Generate ADB file skeleton """
        adb_name = adb.split('/')[-1]
        date = '{:%B %Y}'.format(datetime.now())
        raw_name = adb_name.split('.')[0]
        h_name = raw_name + '_auto.h'
        dst_path = '../sx/sdk/auto_headers/' + h_name
        h_desc = raw_name.title().replace('_', ' ') + ' Header'

        content = Pattern.ADB_FILE.format(adb_name, getpass.getuser(), date, h_name, dst_path, h_desc, nodes)

        return content

    @timeout(5)
    def _gen_include(self, cfg):
        data = {}
        for inc in cfg:
            inc_desc = self._validate_xml(self._get_raw_comment(inc['desc']))
            data[inc['idx']] = {'ntype': nt.INCLUDE,
                                'data': Pattern.INCLUDE.format(inc['name'], inc_desc)}

        g_logger.debug('Includes has been generated')
        return data

    @timeout(5)
    def _gen_define(self, cfg):
        data = {}
        for dfn in cfg:
            for postfix in ['/**<', '/**', '/*', '//']:
                if postfix in dfn['value']:
                    dfn_val_desc = dfn['value'].split(postfix)
                    dfn['value'] = dfn_val_desc[0].strip()
                    dfn['desc'] += dfn_val_desc[1].replace('*/', '').strip()
                    break

            dfn_value = self._validate_xml(dfn['value'])
            dfn_desc = self._validate_xml(self._get_raw_comment(dfn['desc']))

            data[dfn['idx']] = {'ntype': nt.DEFINE,
                                'data': Pattern.DEFINE.format(dfn['name'], dfn_value, dfn_desc)}

        g_logger.debug('Defines has been generated')
        return data

    @timeout(5)
    def _gen_enum(self, cfg):
        data = {}
        for enm in cfg:
            enm_desc = self._validate_xml(self._get_raw_comment(enm['desc']))
            if self._strip_typename(enm['typename'], ['sx_'], ['_t', '_e']).upper() != enm['foreach']:
                foreach = enm['foreach']
            else:
                foreach = ''

            fld_extra = (' foreach="%s"' % foreach) if foreach else ''

            enm_fields = ''
            for fld in enm['fields']:
                fld_desc = self._validate_xml(self._get_raw_comment(fld['desc']))
                fld_value = self._validate_xml(fld['value'].strip())
                fld_cont = self._validate_xml(fld['cont'])

                enm_fields += Pattern.ENUM_FIELD.format(fld['name'], fld_value, fld_cont, fld_desc)

            data[enm['idx']] = {'ntype': nt.ENUM,
                                'data': Pattern.ENUM.format(enm['name'].strip(), enm['typename'].strip(), enm_desc, fld_extra, enm_fields)}

        g_logger.debug('Enums has been generated')
        return data

    @timeout(5)
    def _gen_typedef(self, cfg):
        data = {}
        for tpd in cfg:
            tpd_desc = self._validate_xml(self._get_raw_comment(tpd['desc']))

            data[tpd['idx']] = {'ntype': nt.TYPEDEF,
                                'data': Pattern.TYPEDEF.format(tpd['name'], tpd['type'], tpd_desc)}

        g_logger.debug('Typedefs has been generated')
        return data

    @timeout(5)
    def _gen_struct(self, cfg):
        data = {}
        for stc in cfg:
            stc_desc = self._validate_xml(self._get_raw_comment(stc['desc']))

            stc_fields = ''
            if not stc['fields']:
                continue

            for fld in stc['fields']:
                fld_extra = ''
                if fld['arr_bit'].startswith('['):
                    fld_extra = 'arraysize="{}" '.format(fld['arr_bit'].replace('[', '').replace(']', '').strip())
                elif fld['arr_bit'].startswith(':'):
                    fld_extra = 'bits="{}" '.format(fld['arr_bit'].replace(':', '').strip())

                fld_desc = self._validate_xml(self._get_raw_comment(fld['desc']))
                stc_fields += Pattern.STRUCT_FIELD.format(fld['name'].strip(), fld['type'].strip(), fld_desc, fld_extra)

            data[stc['idx']] = {'ntype': nt.STRUCT,
                                'data': Pattern.STRUCT.format(stc['name'].strip(), stc['typename'].strip(), stc_desc, stc_fields)}

        g_logger.debug('Structs has been generated')
        return data

    @timeout(5)
    def _gen_union(self, cfg):
        data = {}
        for uni in cfg:
            uni_desc = self._validate_xml(self._get_raw_comment(uni['desc']))

            uni_fields = ''
            for fld in uni['fields']:
                fld_extra = 'arraysize="%s" ' % fld['arraysize'] if fld['arraysize'] else ''

                fld_desc = self._validate_xml(self._get_raw_comment(fld['desc']))
                uni_fields += Pattern.UNION_FIELD.format(fld['name'].strip(), fld['type'].strip(), fld_desc, fld_extra)

            data[uni['idx']] = {'ntype': nt.UNION,
                                'data': Pattern.UNION.format(uni['name'].strip(), uni['typename'].strip(), uni_desc, uni_fields)}

        g_logger.debug('Unions has been generated')
        return data


class AdbConverter(object):
    def __init__(self, sources_h, dests_adb):
        self._sources_h = sources_h
        self._dests_adb = dests_adb

        self.h_parser = HeaderParser()
        self.adb_gen = AdbGenerator()
        self._statuses = {os.path.basename(src): 'NO RUN' for src in sources_h}

    def check_ext(self, filepath, ext):
        if filepath.endswith('.{}'.format(ext)):
            return True

        return False

    def convert(self):
        for src, dst in zip(self._sources_h, self._dests_adb):
            g_logger.normal('Analyze header "{}"'.format(src))
            try:
                cfg, failed = self.h_parser.parse(src)
            except TimeOutException:
                g_logger.error('Failed to parse "{}". 30s timeout'.format(src))
                self._statuses[os.path.basename(src)] = g_logger.highlight(fc.RED, 'FAILED [parsing]')
                continue

            try:
                self.adb_gen.generate(cfg, dst)
            except TimeOutException:
                g_logger.error('Failed to generate "{}". 5s timeout'.format(src))
                self._statuses[os.path.basename(src)] = g_logger.highlight(fc.RED, 'FAILED [generation]')
                continue

            if failed:
                self._statuses[os.path.basename(src)] = g_logger.highlight(fc.YLW, 'INCOMPLETE [{}]'.format(', '.join(failed)))
            else:
                self._statuses[os.path.basename(src)] = g_logger.highlight(fc.GRN, 'OK')
            g_logger.success('Header "{}" has been converted'.format(dst))

        return self._statuses

    def __str__(self):
        """ Function print tool info at the beginning of execution """
        head = '  {}{{}}[version {} | {}]\n'.format(__title__, __version__, __release__)
        aligned_head = head.format(' ' * (83 - len(head)))

        return ' {0:-^80}\n{1} {0:-^80}\n'.format('', aligned_head)


def main(llevel, test, source):
    excluded_files = ['sx_lib_host_ifc.h', 'sx_strings.h', 'sx_check.h',
                      'sx_ib_lib_if.h', 'sx_internal_dbg_if.h', 'sx_status_convertor.h']
    if test:
        # lookup for multiple header files
        headers_tmpl = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../include/sx/sdk/sx_*.h')
        sources_h = [file for file in glob.glob(headers_tmpl) if ('sx_api_' not in file) and (os.path.basename(file) not in excluded_files)]
        # dests_path = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../include/adb/auto/')
    else:
        sources_h = [source]  # Use single source file

    dests_path = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../include/adb/')
    dests_adb = [dests_path + '/' + os.path.basename(file.replace('.h', '.adb')) for file in sources_h]

    # configure log level
    g_logger.set_level(llevel if llevel else llvl.NORMAL)

    if g_logger.get_level() > llvl.INFO:
        # disable progress bar when verbosity is high
        g_pbar.disable()

    # initialize converter
    converter = AdbConverter(sources_h, dests_adb)
    print(converter)
    print(' [?] Excluded files: {}\n'.format(', '.join(excluded_files)))

    # run convertion
    statuses = converter.convert()

    print(converter)
    print(' {0:=^36} STATUS {0:=^36}'.format(''))
    for src in sorted(statuses.keys()):
        print('  {:.<30}{:.>57}'.format(src + ' ', ' ' + statuses[src][:40]))
    print(' {0:=^80}'.format(''))


def is_valid_file(parser, arg):
    """ Validate file path provided as parameter
    """
    if not os.path.exists(arg):
        parser.error('The file "%s" does not exist!' % arg)
    else:
        return arg


def is_valid_llvl(parser, arg):
    """ Validate log level provided as parameter
    """
    log_levels = {v.lower(): k for k, v in llvl.token.items()}
    if arg.lower() not in log_levels:
        parser.error('The log level "%s" does not exist!' % arg)
    else:
        return log_levels[arg.lower()]


if __name__ == '__main__':
    # parse script options
    argparser = argparse.ArgumentParser(description='SX API Generation tool.')
    argparser.add_argument('-l', '--llevel', required=False, help="Logging level", metavar="LEVEL",
                           type=lambda x: is_valid_llvl(argparser, x))

    megroup = argparser.add_mutually_exclusive_group(required=True)
    megroup.add_argument('-t', '--test', action='store_true', help='Test SX API headers generation')
    megroup.add_argument('-s', '--source', required=False, help="Input header file", metavar="FILE",
                         type=lambda x: is_valid_file(argparser, x))

    args = argparser.parse_args()
    sys.exit(main(**(vars(args))))
