#!/usr/bin/env python3
"""
# SX Filter Maker tool
#
# Provides generation of binary filter file
# that may be used by SX Sniffer or Runner.
# Uses mapping file created by sx_api_mapper
# tool.
#
"""
__title__ = 'SX_FILTER_MAKER'
__author__ = 'oleksandrv'
__version__ = '0.3.4b'
__release__ = 'Sep-2020'

import os
import sys
import json
import argparse


class SxFilterMaker:
    """ SX Filter Maker object.
    Class contains functionality used to generate binary filter file.

    Attributes:
    _mapping_file : str
                    Path to the mapping file with API name-to-opcode mappings.
    _mapping      : dict
                    Mapping with API name as a key and API opcode as a value.
    """

    def __init__(self, mapping_file=None):
        """ SxFilterMaker object constructor """
        self._mapping_file = mapping_file or (os.path.dirname(os.path.abspath(__file__)) + '/filter.mapping')
        self._mapping = {}  # {'api_name': opcode}

    def _load_mapping(self):
        """ Function uploads mapping from the mapping file """
        if os.path.isfile(self._mapping_file):
            # try to restore mapping from existing filter.mapping JSON
            with open(self._mapping_file, 'r') as fp:
                self._mapping = json.load(fp)

            print(' [info] Mapping has been uploaded from "{}".'.format(self._mapping_file))
        else:
            exit(' [error] Unable to obtain mapping information. Please generate mapping via sx_api_maker.')

    def convert(self, usr_filter_cfg, bin_filter):
        """ Function performs convertion of user filter file into
            the binary filter file.

        Arguments:
            usr_filter_cfg {dict} -- Dictionary that points to the way user provided APIs list.
            bin_filter {str} -- Desired binary file path.
        """
        # print header
        print(self)

        # load mapping
        self._load_mapping()

        if usr_filter_cfg['type'] == 'file':
            # alias file path with better name
            filter_file = usr_filter_cfg['value']

            # check we have valid input filter file
            if not (filter_file and os.path.isfile(filter_file)):
                exit(' [error] Filter file is required.')

            # upload filter file
            with open(filter_file, 'r') as fp:
                lines = [line.strip() for line in fp.read().split('\n')]
                usr_apis_list = [row for row in lines if row and not row.startswith('#')]
        else:
            # define default filepath to save APIs
            filter_file = 'default'

            # get APIs list from parameters
            usr_apis_list = [api for api in usr_filter_cfg['value'].split(',')]

        # convert API names to opcodes
        bin_opcodes_list = []
        for api in set(usr_apis_list):
            if self._mapping.get(api):
                bin_opcodes_list.append(self._mapping[api])
            else:
                print(' [warning] Unknown API name provided - "{}".'.format(api))
        print(' [info] API names have been processed.')

        # create binary filter file
        bin_target = bin_filter or (filter_file + '.filter')
        if bin_opcodes_list:
            with open(bin_target, 'w+') as fp:
                # NOTE: Yeah we know that '.filter' is not a binary file.
                #       It is called "binary" to motivate user use this
                #       tool instead of manual opcodes copy-pasting.
                fp.write(' '.join(bin_opcodes_list))
            print(' [info] Binary filter file is ready - {}'.format(bin_target))
        else:
            print(' [info] Binary filter file was not created.')

    def __str__(self):
        """ Function print tool info at the beginning of execution """
        head = '  {}{{}}[version {} | {}]\n'.format(__title__, __version__, __release__)
        aligned_head = head.format(' ' * (83 - len(head)))

        return ' {0:-^80}\n{1} {0:-^80}\n'.format('', aligned_head)

    def help(self):
        """ Function print help instructions to the user """
        text = str(self) + \
            '  Tool creates a binary file with data regarding APIs that have to be filtered.\n' + \
            '  Binary filter file can be used by SX Sniffer and SX Runner (Player/Logger).\n' + \
            '\n' + \
            '   1. Generate a filter binary file to a custom location:\n' + \
            '      {} -f <filter/file.txt> --output <path/output.filter>\n'.format(os.path.basename(__file__)) + \
            '\n' + \
            '   2. Get a help:\n' + \
            '      {} --help\n'.format(os.path.basename(__file__)) + \
            '\n' + \
            ' {:-^80}\n'.format('')
        print(text)

    def gen_def_filter(self):
        """ Function performs generate all get function into the binary filter file.
        """
        # load mapping
        self._load_mapping()
        # convert API names to opcodes
        bin_opcodes_list = []
        for api in self._mapping.keys():
            if "get" in api:
                bin_opcodes_list.append(self._mapping[api])
        special_set_func = ['sx_api_bulk_counter_transaction_set']
        for api in special_set_func:
            bin_opcodes_list.append(self._mapping[api])

        print(' [info] API names have been processed.')

        # create binary filter file
        bin_target = "applibs/sx_api_utils/sx_def_filter"
        if bin_opcodes_list:
            with open(bin_target, 'w+') as fp:
                # NOTE: Yeah we know that '.filter' is not a binary file.
                #       It is called "binary" to motivate user use this
                #       tool instead of manual opcodes copy-pasting.
                fp.write(' '.join(bin_opcodes_list))
            print(' [info] Binary filter file is ready - {}'.format(bin_target))
        else:
            print(' [info] Binary filter file was not created.')


def main(file=None, apis=None, output=None, mapping=None, help=None, gen_def_filter=False):
    """ Main function process user options and runs corresponding flow.

    Keyword Arguments:
        file {str} -- Path to the original filter file (default: {None}).
        apis {str} -- Comma-separated API names that should be filtered (default: {None}).
        output {str} -- Path to the desired filter binary location (default: {None}).
        output {str} -- Path to the custom mapping file (default: {None}).
        help {bool} -- Prints a help to the user (default: {None}).
    """
    # create filter maker object
    filter_maker = SxFilterMaker(mapping)

    if help:
        # user needs a help
        filter_maker.help()
        return

    if gen_def_filter:
        filter_maker.gen_def_filter()
        return

    # prepare user filter config
    usr_filter_cfg = {'type': 'file' if file else 'apis',
                      'value': file or apis}

    # run convertion
    filter_maker.convert(usr_filter_cfg, output)


if __name__ == '__main__':
    # create and initialize arguments parser
    parser = argparse.ArgumentParser(add_help=False)
    cmd_group = parser.add_mutually_exclusive_group(required=False)

    # major part of user arguments
    cmd_group.add_argument('-f', '--file', type=str, help='Path to the user\'s filter file', metavar='FILE')
    cmd_group.add_argument('-a', '--apis', type=str, help='Comma separated list of APIs', metavar='FILE')
    parser.add_argument('-o', '--output', type=str, help='Custom path for binary filter file', metavar='FILE')
    parser.add_argument('-m', '--mapping', type=str, help='Path to the custom mapping file', metavar='FILE')
    parser.add_argument('-gen_def_filter', action='store_true',
                        help="Generate default api exclude file, which include all _get functions")

    # minor part of user arguments
    cmd_group.add_argument('-h', '--help', action='store_true')

    # process arguments
    args = parser.parse_args()
    sys.exit(main(**(vars(args))))
