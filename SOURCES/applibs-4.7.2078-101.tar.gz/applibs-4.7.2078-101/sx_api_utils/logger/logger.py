"""
# SX API Logger
#
# Convert content of PCAP file recorded by SX Sniffer
# into a human-readable text information with various
# options for the filtering, parameters parsing, logs
# dump and many more.
#
"""
__title__ = 'SX_API_LOGGER'
__author__ = 'oleksandrv, ypasichnyk'
__version__ = '1.4.6'
__release__ = 'June-2022'

import os
import sys
import stat
import json
import copy
import struct
from errno import ENOENT
from datetime import datetime, timedelta

# import SX API Utils library
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.utils import g_logger, g_pbar, AdbParser, SxLoggerProcessingError, LogLevel as llvl, NodeType as nt, FontColor as fc


""" Format characters description
I - unsigned int
i - int
H - unsigned short
s - char[], prefix with length
B - unsigned char
"""
PCAP_GLOBAL_HEADER_FORMAT = 'IHHiIII'
PCAP_GLOBAL_HEADER_LEN = 24
PCAP_PACKET_HEADER_FORMAT = 'IIII'
PCAP_PACKET_HEADER_LEN = 16

SX_API_CMD_HEADER_FORMAT = 'IIIIIi'
SX_API_CMD_HEADER_LEN = 24

SX_API_RPL_HEADER_FORMAT = 'IiIII'
SX_API_RPL_HEADER_LEN = 20

SX_API_SYSFS_HEADER_FORMAT = 'I64s256sII'
SX_API_SYSFS_HEADER_LEN = 332

TRAP_HEADER_FORMAT = "IIII64s"
TRAP_HEADER_LENGTH = 100

TRAP_HEADER_PUDE_FORMAT = "IIBI"
TRAP_HEADER_IPAC_FORMAT = "IBIHBI"


# mapping between opcode and api name
# {'opcode': ['api_name', 'api_parameters_type']}
g_api_codes = {}

# mapping between status code and status name
# {'status_code': 'name'}
g_status_codes = {}


port_oper_status_mapping = {
    0: "N/A",
    1: "Up",
    2: "Down",
    3: "N/A",
    4: "Down by Fail"
}

port_logical_state_mapping = {
    0: "N/A",
    1: "Down",
    2: "Init",
    3: "Arm",
    4: "Active"
}

port_profile_ipac_mapping = {
    0: "Idle",
    1: "Busy",
    2: "Cancelled",
    3: "Error"
}


class ProtoHeader():
    """ Header prototype class
    Used to store common header parsing functionality
    """

    def _unpack(self, h_format, data, h_name='header', h_id=0):
        """ Safe unpack function with extended debug info printing

        :param h_format: header format string
        :param data: data to be unpacked
        :param h_name: custom header type name
        :param h_id: header unique id
        :return: tuple with unpacked params
        """
        try:
            unpacked = struct.unpack(h_format, data)
        except Exception as e:
            error_info = '\n' + \
                'Corrupted file. Unable to read %s.\n' % (h_name + ((' #%d' % h_id) if h_id else '')) + \
                '\n' + \
                '  [[ corrupted header debug ]]\n' + \
                '\t > [data] %s (%d bytes)\n' % (' '.join(['{:02x}'.format(ord(x)) for x in data]), len(data)) + \
                '\t > [frmt] %s (%d bytes)\n' % (h_format, struct.calcsize(h_format)) + \
                '\t > [desc] %s\n' % str(e)

            g_logger.error(error_info)
            exit(1)  # catchall for general errors

        return unpacked


class PcapGlobalHeader(ProtoHeader):
    """ PCAP Global header structure
    ----  -------------  ------------------------------------------------------
    SIZE  FIELD          DESCRIPTION
    ----  -------------  ------------------------------------------------------
     32b  magic          constant 'A1B2C3D4'. Check if endianness is correct
     16b  version_major  major number of the file format
     16b  version_minor  minor number of the file format
     32b  thiszone       correction time in seconds from UTC to local time (0)
     32b  sigfigs        accuracy of time stamps in the capture (0)
     32b  snaplen        max length of captured packed (65535)
     32b  linktype       type of data link (1 = ethernet)
    ----  -------------  ------------------------------------------------------
    """

    def __init__(self, data):
        unpacked = self._unpack(PCAP_GLOBAL_HEADER_FORMAT, data, 'global header')
        self.magic = unpacked[0]
        self.swapped = self.magic != 0xa1b2c3d4
        self.version_major = unpacked[1]
        self.version_minor = unpacked[2]
        self.thiszone = unpacked[3]
        self.sigfigs = unpacked[4]
        self.snaplen = unpacked[5]
        self.linktype = unpacked[6]

    def __str__(self):
        """ Function prints PCAP global header data. """

        data = ' [[ GLOBAL HEADER ]]\n' + \
               ' +{0:-^98}+\n'.format('') + \
               '   magic:         %x [%s bytes order]\n' % (self.magic, 'swapped' if self.swapped else 'native') + \
               '   version_major: %d\n' % self.version_major + \
               '   version_minor: %d\n' % self.version_minor + \
               '   thiszone:      %d\n' % self.thiszone + \
               '   sigfigs:       %d\n' % self.sigfigs + \
               '   snaplen:       %d\n' % self.snaplen + \
               '   linktype:      %d [%s]\n' % (self.linktype, 'ethernet' if self.linktype == 1 else 'custom') + \
               ' +{:-^98}+\n'.format('') + \
               '   Details: https://wiki.wireshark.org/Development/LibpcapFileFormat\n' + \
               ' +{:-^98}+\n'.format('')

        return data


class PcapPacketHeader(ProtoHeader):
    """ PCAP Packet header structure
    ----  -------------  ------------------------------------------------------
    SIZE  FIELD          DESCRIPTION
    ----  -------------  ------------------------------------------------------
     32b  ts_sec         timestamp of seconds
     32b  ts_usec        timestamp if microseconds
     32b  caplen         number of octets (bytes) of packet saved in file
     32b  len            actual length of packet
    ----  -------------  ------------------------------------------------------
    """

    def __init__(self, packet_id, hdata):
        unpacked = self._unpack(PCAP_PACKET_HEADER_FORMAT, hdata, 'packet header', h_id=packet_id)
        self.packet_id = packet_id
        self.ts_sec = unpacked[0]
        self.ts_usec = unpacked[1]
        self.caplen = unpacked[2]
        self.len = unpacked[3]
        self.call = None

    def __str__(self):
        """ Function prints PCAP packet header data. """

        tstamp = datetime.fromtimestamp(self.ts_sec)
        data = '\n\n {0:-^32} PACKET HEADER {0:-^31}\n'.format('') + \
               '  packet id: %d\n' % self.packet_id + \
               '  ts_sec: %d\n' % self.ts_sec + \
               '  ts_usec: %d\n' % self.ts_usec + \
               '      [timestamp] {:%Y %b %d %H:%M.%S}.{}\n'.format(tstamp, self.ts_usec) + \
               '  caplen: %d\n' % self.caplen + \
               '  len: %d\n' % self.len + \
               (str(self.call) if self.call else '  [NO SX API CALL]') + '\n' + \
               ' {0:-^78}'.format('')

        return data


class SxApiCallHeader(ProtoHeader):
    """ SX API Call header structure (CMD - 24B, REPLY - 20B)
    ----  -------------  ------------------------------------------------------
    SIZE  FIELD          DESCRIPTION
    ----  -------------  ------------------------------------------------------
     32b  side           direction of sx call (0* 00 00 00): REPLY(0), CMD(1), SYSFS(2), TRAP(3)
     32b  op / retcode   api function code / operation result
     32b  version        api version
     32b  msg_size       size of header + body (params) / size of header only
     32b  list_size      size of list data
     32b  pid / -        process id / not exist
    ----  -------------  ------------------------------------------------------

    Sysfs header layout:
    ---   ------------- -------------------------------------------------------
    32b   side          direction of sysfs(2)
    8b   func_name[64]  sysfs CB function name
    8b   path[256]      sysfs file path
    32b  is_write       write to sysfs file or read from sysfs file
    32b  buff_len       for write access only. the write buffer length
    ----  -------------  ------------------------------------------------------

    Traps header layout:
    32b  side      trap
    32b  trapid
    32b  log_port             Logical port
    8b   event_info[64]    event info
    """

    def __init__(self, header_data):
        unpacked = self._unpack(SX_API_RPL_HEADER_FORMAT, header_data[:20], 'REPLY header')

        self.side = unpacked[0]
        if self.side == 1:
            # CMD HEADER
            unpacked = self._unpack(SX_API_CMD_HEADER_FORMAT, header_data[:24], 'CMD header')
            self.opcode = unpacked[1]
            self.pid = unpacked[5]
            self.version = unpacked[2]
            self.msg_size = unpacked[3]
            self.list_size = unpacked[4]
            self.data = header_data[24:]
        elif self.side == 2:
            # SYSFS HEADER
            unpacked = self._unpack(SX_API_SYSFS_HEADER_FORMAT, header_data[:332], 'SYSFS header')
            self.func_name = unpacked[1]
            self.path = unpacked[2]
            self.is_write = unpacked[3]
            self.buf_len = unpacked[4]
            self.data = header_data[332:]
        elif self.side == 3:
            unpacked = self._unpack(TRAP_HEADER_FORMAT, header_data[:TRAP_HEADER_LENGTH], 'Trap header')
            self.trap_id = unpacked[1]
            self.event_size = unpacked[2]
            self.source_log_port = unpacked[3]
            self.event_info = unpacked[4]
        else:
            # REPLY HEADER
            self.retcode = unpacked[1]
            self.data = header_data[20:]
            self.version = unpacked[2]
            self.msg_size = unpacked[3]
            self.list_size = unpacked[4]

        if self.side not in [2, 3]:
            self.hex = ' '.join('{:02x}'.format(num) for num in unpacked)

    def __str__(self):
        """ Function print SX API header data depending on packet side. """

        data = '\n {0:=^32} sx_api header {0:=^31}\n'.format('') + \
               '  side: %d [%s]\n' % (self.side, 'CMD' if self.side else 'REPLY')
        if self.side:
            # CMD side
            api_name = g_api_codes.get('%x' % self.opcode, ['unknown'])[0].lower()
            data += '  opcode: %d [%s]\n' % (self.opcode, api_name)
        else:
            # REPLY side
            status_str = g_status_codes.get(self.retcode, 'unknown').upper()
            data += '  retcode: %d [%s]\n' % (self.retcode, status_str)

        data += '  version: %d\n' % self.version + \
                '  msg_size: %d\n' % self.msg_size + \
                '  list_size: %d\n' % self.list_size

        if self.side:
            data += '  pid: %d\n' % self.pid

        if self.data:
            row_sz = 24
            hex_rows = [['%02x' % ord(x) for x in self.data[i:i + row_sz]] for i in range(len(self.data[::row_sz]))]
            hex_data = '\n    {}'.format('\n    '.join(' '.join(row) for row in hex_rows))
        else:
            hex_data = ' [NO DATA]'

        data += '  {}\n {:=^78}'.format('data [%dB]:%s' % (len(self.data), hex_data), '')

        return data


class PcapReader():
    """ PCAP Reader object.
    Provides PCAP file reading functionality.

    Attributes
    ----------
    _pcap        : str
                   path to PCAP file
    _packet_id   : int
                   ID of last procees packet
    _packets_num : int
                   total number of packets in PCAP file
    _mdata       : dict
                   PCAP file metadata
    _fd          : int
                   PCAP file descriptor
    gheader      : PcapGlobalHeader
                   global PCAP file header data
    """

    def __init__(self, pcap_file):
        """ PCAP reader constructor

        :param pcap_file: path to PCAP file
        """
        # check if PCAP file exists
        if not os.path.exists(pcap_file):
            g_logger.error('PCAP file {} does not exist'.format(pcap_file))
            raise IOError(ENOENT, os.strerror(ENOENT), pcap_file)

        # save pcap file, declare packet_id and total packets number
        self._pcap = pcap_file
        self._packet_id = 0
        self._packets_num = 0

        # get PCAP file metadata and open file descriptor for reading
        self._mdata = os.stat(self._pcap)
        self._fd = open(self._pcap, 'rb')

        # get global PCAP header
        self.gheader = PcapGlobalHeader(self._fd.read(PCAP_GLOBAL_HEADER_LEN))

        # Trap , Trap Str
        self.sdk_traps_mapping = {
            0x8: ["PUDE"],
            0X10F: ["IPAC"]
        }

    def __del__(self):
        """ PCAP reader destructor """
        if hasattr(self, '_fd'):
            self._fd.close()

    def preanalysis(self):
        """ Function run PCAP file pre-analysis to collect additional data about file """

        # Average Packet Size (APS) and Average Packet Processing Time (APPT)
        # are measured manually using PCAP files with high amount of API calls.
        # APS = PCAP file size / number of PCAP packets
        APS = [266.5857,  # bytes, measured on Sep 02, 2020
               163.4365]  # bytes, measured on Nov 18, 2019
        # approximate packets number
        approx_num = self._mdata[stat.ST_SIZE] / APS[0]

        # APPT = PCAP file analysis time / number of PCAP packets
        APPT = [0.000011326,  # seconds, measured on Sep 02, 2020
                0.000020654]  # seconds, measured on Nov 18, 2019
        # approximate analysis duration
        approx_dur = approx_num * APPT[0]

        # approximate analysis finish time
        approx_end = datetime.now() + timedelta(minutes=approx_dur / 60, seconds=approx_dur % 60)

        approx = '[[ pre-analysis | approximation ]]\n' + \
                 ' +{0:-^83}+\n'.format('') + \
                 '   Started at               {:%H:%M.%S}\n'.format(datetime.now()) + \
                 '   Approx. packets number   {:.0f}\n'.format(approx_num) + \
                 '   Approx. finish at        {:%H:%M.%S}\n'.format(approx_end) + \
                 ' +{:-^83}+'.format('')
        g_logger.normal(approx, end='\n')

        # count PCAP packet in file
        self._packets_num = self.count_packets()

        real = '[[ pre-analysis | result ]]\n' + \
               ' +{0:-^83}+\n'.format('') + \
               '   Real packets number      %d\n' % self._packets_num + \
               '   Finished at              {:%H:%M.%S}\n'.format(datetime.now()) + \
               ' +{:-^83}+\n'.format('')
        g_logger.normal(real, end='\n')

    def count_packets(self):
        """ Function counts total packets number """
        # start task "PCAP packets counting"
        g_pbar.start('PCAP packets counting', unpredictable=True)

        # save configuration
        pos = self._fd.tell()

        count = 0
        while self.next_packet(inc_packet_id=False):
            count += 1

        # restore configuration
        self._fd.seek(pos)

        # finish task "PCAP packets counting"
        g_pbar.finish()

        return count

    def next_packet(self, inc_packet_id=True):
        """ Function process PCAP packet next after last one proceed

        :param inc_packet_id: enable packets counting
        """
        # count if not enabled stealth mode
        if inc_packet_id:
            self._packet_id += 1

        # parse PCAP packet header
        header_data = self._fd.read(PCAP_PACKET_HEADER_LEN)
        packet = PcapPacketHeader(self._packet_id, header_data) if header_data else None
        if packet:
            # parse SX API packet header
            packet.call = SxApiCallHeader(self._fd.read(packet.caplen))

        return packet

    def packet_id_modify(self, value):
        """ Function used to update packet_id counter manually

        :param value: positive or negative value that will be added to packet_id.
        :return: updated packet_id
        """

        if isinstance(value, int):
            self._packet_id += value

        return self._packet_id

    def reset(self):
        """ Function reset PCAP file reader configuration """
        self._fd.seek(PCAP_GLOBAL_HEADER_LEN)
        self._packet_id = 0

    def packets_ts_diff(self, packet1, packet2):
        """ Function calculate time difference between two PCAP packets """
        # calculate call duration
        dur_s = packet2.ts_sec - packet1.ts_sec
        dur_us = packet2.ts_usec - packet1.ts_usec

        # microseconds compensation
        if dur_us < 0:
            dur_us += 1000000
            dur_s -= 1

        return dur_s + dur_us / 1000000.0

    def apilist_print(self, filter_gen_path=None):
        """ Function get list of all unique APIs recorded in PCAP files """
        # initialize variables
        last_cmd = None  # last CMD packet
        api_stub = [0, 0]  # stub used for correct APIs processing

        # initialize data dictionaries
        api_calls = {}  # mapping between API name and times it was used
        sysfs_calls = {}  # mapping between sysfs path and how many times it was accessed
        failed_calls = {}  # mapping between API and list of failures
        traps_calls = {}

        self.preanalysis()  # preanalysis collect initial PCAP file data

        # go through all packets and look for CMD packets with opcode
        g_logger.info('Analysing PCAP packets ..')

        # calculate per packet progress value
        packet_progress = 100.0 / self._packets_num

        # start task "PCAP packets analysis"
        g_pbar.start('PCAP packets analysis')

        while True:
            packet = self.next_packet(inc_packet_id=False)
            if not packet:
                break

            elif packet.call.side == 3:  # Traps processing
                trap_id = packet.call.trap_id
                if trap_id in traps_calls.keys():
                    traps_calls[trap_id] += 1
                else:
                    traps_calls[trap_id] = 1
                continue

            elif packet.call.side == 2:  # SYSFS packet processing
                file_path = packet.call.path
                if file_path in sysfs_calls.keys():
                    sysfs_call = sysfs_calls[file_path]
                    if packet.call.is_write:
                        sysfs_call["W"] += 1
                    else:
                        sysfs_call["R"] += 1
                else:
                    if packet.call.is_write:
                        sysfs_call = {'W': 1, 'R': 0}
                    else:
                        sysfs_call = {'W': 0, 'R': 1}

                    sysfs_calls[file_path] = sysfs_call

            elif packet.call.side == 1:  # CMD packet processing
                # increment API calls and save opcode + timestamps
                api_calls[packet.call.opcode] = [api_calls.get(packet.call.opcode, api_stub)[0] + 1,
                                                 api_calls.get(packet.call.opcode, api_stub)[1]]
                last_cmd = packet

            else:  # REPLY packet processing
                # calculate call duration
                dur = self.packets_ts_diff(last_cmd, packet)

                # increment total duration
                api_calls[last_cmd.call.opcode] = [api_calls.get(last_cmd.call.opcode, api_stub)[0],
                                                   api_calls.get(last_cmd.call.opcode, api_stub)[1] + dur]

                # check if API call failed
                if packet.call.retcode:
                    if failed_calls.get(last_cmd.call.opcode):
                        failed_calls[last_cmd.call.opcode].append(packet.call.retcode)
                    else:
                        failed_calls[last_cmd.call.opcode] = [packet.call.retcode]

            # update progress "PCAP packets analysis"
            g_pbar.progress_inc(packet_progress)

        # notify user
        g_logger.info('PCAP packets analysis has been finished')

        # finish task "PCAP packets analysis"
        g_pbar.finish()

        # print collected data
        separator = '  +-{0:-^64}-+-{0:-^8}-+-{0:-^11}-+'.format('')
        table_fmt = '  | {:<6}  {:<56} | {:<8} | {:>9} s |\n'
        sysfs_fmt = '  | {:<65} | {:<8} | {:>9}|\n'
        traps_fmt = '  | {:<6}  {:<56} | {:>9} |\n'
        sysfs_separator = '  +-{0:-^65}-+-{0:-^8}-+-{0:-^8}-+'.format('')

        table = '  Found {} unique APIs called {} times during {} s:\n'.format(len(api_calls),
                                                                               sum([it[0] for it in api_calls.values()]),
                                                                               sum([it[1] for it in api_calls.values()])) + \
                separator + '\n' + \
                table_fmt.format('OPCODE', '"API NAME"', 'CALLS', 'EXEC.TIME') + \
                separator + '\n'

        for opcode in sorted(api_calls):
            api_name = g_api_codes.get('%x' % opcode, ['unknown'])[0].lower()

            table += table_fmt.format(hex(opcode), '"{}"'.format(api_name),
                                      api_calls[opcode][0], '{:0.5f}'.format(api_calls[opcode][1]))

        g_logger.normal(table + separator, end='\n', label=False)

        if len(sysfs_calls):
            table = '    Found {} sysfs access:\n'.format(len(sysfs_calls)) + \
                    sysfs_separator + '\n' + \
                    sysfs_fmt.format('FILE PATH', 'WRITE', 'READ') + \
                    sysfs_separator + '\n'

            for file_path in sysfs_calls:
                table += sysfs_fmt.format(file_path.decode().replace('\x00', ''), sysfs_calls[file_path]['W'], sysfs_calls[file_path]['R'])

            g_logger.normal(table + sysfs_separator, end='\n', label=False)

        if traps_calls:
            table = '    Found {} SDK Traps :\n'.format(len(traps_calls)) + \
                    separator + '\n' + \
                    traps_fmt.format('TRAP ID', 'TRAP NAME', 'CALLS') + \
                    separator + '\n'
            for trap_id in traps_calls:
                sdk_trap_str = "Unknown"
                if trap_id in self.sdk_traps_mapping.keys():
                    sdk_trap_str = self.sdk_traps_mapping[trap_id][0]
                table += traps_fmt.format(hex(trap_id), '{}'.format(sdk_trap_str), traps_calls[trap_id])

            g_logger.normal(table + sysfs_separator, end='\n', label=False)

        if failed_calls:
            # print failed APIs
            failures = 'Following API calls returned an error(s):\n'

            for opcode in sorted(failed_calls):
                # prepare information per each failed API
                failures += '\n    "{}"\n'.format(g_api_codes.get('%x' % opcode, ['unknown'])[0].lower())
                api_err_count = {}

                for err in failed_calls[opcode]:
                    api_err_count[err] = api_err_count.get(err, 0) + 1

                for err, times in api_err_count.items():
                    failures += '    - {} x {} time(s)\n'.format(g_status_codes.get(err, 'unknown').upper(), times)

            g_logger.normal(failures, end='\n')

        if filter_gen_path:
            # generate filter file using parsed APIs list
            self.__filter_file_gen(filter_gen_path, api_calls.keys())
            g_logger.normal('Generated filter file %s' % filter_gen_path, end='\n', force_cli=True)

    def __filter_file_gen(self, path, opcodes):
        """ Function is used to write API names to the text file """

        # prepare string with API names
        content = '\n'.join([g_api_codes[op][0].lower() for op in ['%x' % op for op in opcodes] if g_api_codes.get(op)])

        # write APIs to the file
        with open(path, 'w+') as fp:
            fp.write(content)

    def __str__(self):
        """ Print PCAP file metadata """
        cdtime = datetime.fromtimestamp(self._mdata[stat.ST_CTIME])
        mdtime = datetime.fromtimestamp(self._mdata[stat.ST_MTIME])

        data = '\n [[ PCAP METADATA ]]\n' + \
               ' +{0:-^98}+\n'.format('') + \
               '   path     %s\n' % os.path.abspath(self._pcap) + \
               '   size     %d bytes\n' % self._mdata[stat.ST_SIZE] + \
               '   created  {:%d-%m-%Y %H:%M.%S}\n'.format(cdtime) + \
               '   modified {:%d-%m-%Y %H:%M.%S}\n'.format(mdtime) + \
               ' +{0:-^98}+\n'.format('')

        return data


class SxLogger():
    """ SX Logger object.
    Provides PCAP file processing functionality.

    Attributes:
    _filter_cfg : dict
                  filter type and path to filter file with APIs
    _params     : str
                  mode to print API parameters
    _filter_db  : set
                  set of APIs to be filtered
    reader      : PcapReader
                  PCAP Reader object
    adb_parser  : utils.AdbParser
                  ADB files parser
    """

    def __init__(self, pcap_file, adb_files, filter_cfg=None, params=None, fix_xml=False):
        """ Constructor of SX Logger

        :param pcap_file: path to PCAP file
        :param adb_files: list of adb_files
        :param filter_cfg: APIs filter configuration
        :param output: output destinations info
        :param params: API parameters print mode
        :param debug: enable debug level verbosity
        :param color: flag used to enable logs colorization
        :param fix_xml: fix special characters in ADB files
        """
        # save user configuration
        self._filter = filter_cfg  # {'range': True, 'from_id': None, 'till_id': 10, 'api': 'include', 'file': '/path/to/filter.txt'}
        self._params = params  # {'mode': 'all', 'skip_zero': True}

        # Trap , Trap Str, Format, display function cb
        self.sdk_traps_mapping = {
            0x8: ["PUDE", TRAP_HEADER_PUDE_FORMAT, self.__pude_trap_show],
            0X10F: ["IPAC", TRAP_HEADER_IPAC_FORMAT, self.__ipac_trap_show]
        }

        # define filter_db - API names
        self._filter_db = set()

        # check if provided filter file exists
        if filter_cfg:
            # check if filter file exists if provided
            if filter_cfg.get('file') and not os.path.isfile(filter_cfg['file']):
                g_logger.error('Filter file {} does not exist'.format(filter_cfg['file']))
                raise IOError(ENOENT, os.strerror(ENOENT), filter_cfg['file'])

            # prepare filtering information
            self.prepare_filter()

        # initialize PCAP file reader
        self.reader = PcapReader(pcap_file)

        # upload information from ADABE files
        self.adb_parser = AdbParser(adb_files, fix_xml=fix_xml)
        self.adb_data_load()

    def adb_data_load(self):
        """ Function upload usefull data from ADB files """
        # start task "ADB analysis"
        g_pbar.start('ADB analysis')

        # upload naming of opcodes and status codes
        self._api_status_codes_get()

        if self._params['mode'] in ['all', 'native', 'cmd', 'reply']:
            # upload API parameters information if parameters parsing enabled
            self._params_load()

        # finish task "ADB analysis"
        g_pbar.finish()

    def _api_status_codes_get(self):
        """ Function upload API names and statuses """
        global g_api_codes
        global g_status_codes

        # api codes upload from 'api_params' section
        # {"opcode": ["api_name", "params_type_name"]}
        for opcode in self.adb_parser.db_access('api_params', None):
            g_api_codes[opcode] = self.adb_parser.db_access('api_params', opcode)

        # update progress "ADB analysis"
        g_pbar.progress_set(10.0)

        # status codes upload using constant type 'sx_status_t'
        # {"status_code": "status_name"}
        for field in self.adb_parser.db_access('types', 'sx_status_t')['fields']:
            if not field['name'].endswith(('_MIN', '_MAX')):
                g_status_codes[self.adb_parser.get_named_value(field['name'])] = field['name']

        # update progress "ADB analysis"
        g_pbar.progress_set(20.0)

    def _params_load(self):
        """ Function upload data and build parsing flow for API's parameters """
        # create a set of unique API parameters types
        api_params = {g_api_codes[op][1] for op in g_api_codes if g_api_codes[op][1] and not self.filtered(op)}

        self.type_parse_flow = {}  # stores parsing flows for parameters data types
        self._enums_texted = {}  # stores names for per each enum type

        # build parsing flows
        g_logger.info('Prepare API parameters metadata ..')

        # zero length check
        if len(api_params):
            # calculate progress step as 80% left divided between each API parameters type
            progress_step = 80.0 / len(api_params)

        for params in api_params:
            g_logger.trace(' Analyzing API parameters [{}]'.format(params))

            # check if API parameters type is known
            is_known = self.adb_parser.is_known_type(params)
            if is_known == 'types':
                params_type = self.adb_parser.db_access('types', params)
            elif is_known == 'base_types':
                params_type = params
            else:
                g_logger.debug('Unknown API parameters "{}"'.format(params))
                continue

            try:
                self.type_parse_flow[params] = self._build_parse_flow(params_type)

            except SxLoggerProcessingError as e:
                # notify user in case of any issues with parameters parsing
                g_logger.warning('Issues during parse flow building for "{}". '.format(params_type)
                                 + 'Use \'--debug\' mode to get more information')
                g_logger.debug('[[[ DETAILS ]]] {}'.format(e))

            # update progress "ADB analysis"
            g_pbar.progress_inc(progress_step)

        g_logger.info('{} API parameters are ready for parsing'.format(len(api_params)))

    def _is_base_type(self, type_name):
        """ Function check if type belongs to base types

        :param type_name: name of type that should be checked
        :return: True if belongs, False otherwise
        """
        return isinstance(type_name, str) and type_name in self.adb_parser.db_access('base_types', None)

    def _build_parse_flow(self, node, prefix='params', u_selector=None, silent=False, style=None):
        """ Function build parsing flow for data node

        :param node: all the node data
        :param prefix: prefix that should be prepended to variable name
        :param u_selector: name of union selector field type
        :param silent: disable error logs, where it is possible
        :param style: custom output style defined by the user
        :return: parsing flow of the node
        """
        def get_array_factor(parent, node, prefix):
            """ Function get real array size value

            :param parent: parent node data
            :param node: node itself
            :param prefix: prefix that should be prepended to variable name
            :return: array size represented by number or another parameter
            """
            factors = []

            for arrsize in node['arraysize']:
                if 'fields' in parent and any([fld['name'] for fld in parent['fields'] if arrsize.startswith(fld['name'])]):
                    # arrsize is specified by structure field
                    factors.append('{}.{}'.format(prefix, arrsize))
                elif isinstance(self.adb_parser.arraysize_eval(arrsize), int):
                    # arrsize is specified by global enum value or define
                    factors.append(self.adb_parser.arraysize_eval(arrsize))
                elif arrsize.isdigit():
                    # arrsize defined by number directly
                    factors.append(int(arrsize))
                else:
                    if not silent:
                        g_logger.error('Unable to recognize array size \'{}\''.format(arrsize))
                    factors.append(1)

            return factors

        def get_max_field(parse_flow):
            """ Function get size of the biggest field in flow

            :param parse_flow: parse flow to be proceed
            :return: size of the biggest field in bytes
            """
            max_field = 1  # byte
            for step in parse_flow:
                if step[0] == 'FIELD':
                    # field alignment is defined by maximum parsing item
                    # except padding byte 'x'
                    unique_sizes = list(set(step[2].replace('x', '')))
                    max_size = max([struct.calcsize(a) for a in unique_sizes])
                elif step[0] == 'ARRAY':
                    # array alignment is defined by the largest field of array item
                    max_size = get_max_field([step[2]])
                elif step[0] == 'UNION':
                    # union alignment is defined by the largest field in any subflow
                    size_variants = [get_max_field(case) for case in step[2].values()]
                    max_size = max(size_variants)
                else:
                    max_size = 0

                if max_size > max_field:
                    max_field = max_size

            return max_field

        def process_field_metadata(field):
            """ Function process field data.

            Arguments:
                field {dict} -- field`s metadata

            Raises:
                SxLoggerProcessingError: a mistake has been detected in the field`s metadata

            Returns:
                [tuple] -- Return subtype node and union selector name
            """
            if not self._is_base_type(field['type']):
                # field is complex type
                type_node = self.adb_parser.db_access('types', field['type'])

                # check if there is an union selector
                if field.get('union_selector'):
                    # user provided some selector attribute
                    if field['union_selector'].startswith('.'):
                        # user provided an absolute path to union selector field
                        selector = 'params' + field['union_selector']
                    else:
                        # user provided a name of the field in the same structure
                        selector = ('%s.%s' % (prefix, field['union_selector']))
                else:
                    # user did not specified union selector to the current node
                    # thus if it will be union, we will parse all known union flows
                    selector = None

            else:
                # field is a base type
                type_node = field['type']
                selector = None

            return type_node, selector

        def get_largest_field(node):
            """ Function gets the largest field in the node

            Arguments:
                node {dict} -- node data

            Returns:
                int -- largest field size
            """
            largest_field = 0  # largest field size used to align whole data unit in a memory

            for field in node['fields']:
                if field['name'].startswith(nt.CODE):
                    # skip code nodes
                    continue

                # get underlay type metadata and union selector name
                type_node, selector = process_field_metadata(field)

                # get parsing flow for the field silently
                fld_parse_flow = self._build_parse_flow(type_node, '[meta]%s.%s' % (prefix, field['name']),
                                                        selector, silent=True)

                # biggest subnode field size
                field_bytes = get_max_field(fld_parse_flow)
                if field_bytes > largest_field:
                    largest_field = field_bytes

            return largest_field

        def enums_texted_get(node):
            """ Function prepares mapping between enum's items value and name """
            texted = {}
            for field in node['fields']:
                if not field['name'].endswith(('_MIN', '_MAX')) and \
                   not field['name'].startswith(nt.CODE):
                    # ignore enum items with MIN or MAX meaning and code nodes
                    texted[self.adb_parser.get_named_value(field['name'])] = field['name']

            return texted

        # parse flow is a list of instructions how to parse every parameter field
        parse_flow = []

        if self._is_base_type(node):
            # node is represented by base type
            node_data = self.adb_parser.db_access('base_types', node)

            # add instruction to the parse flow
            parse_flow.append(['FIELD', prefix, node_data[0], style or node_data[1], {}])

        elif node['node_type'] == nt.ENUM:
            # get the name that is unique for each enum node (typename has a priority)
            unique_enum_name = node['typename'] or node['name']

            # enum is a basic type with available text interpretation
            texted = self._enums_texted.get(unique_enum_name)
            if not texted:
                # prepare texted description and append it to known texted enums
                texted = enums_texted_get(node)
                self._enums_texted[unique_enum_name] = texted

            # define enum size format depending on specific conditions
            node_format = 'i'  # by default enums take 4 bytes

            if node['pack'] == '__attribute__((__packed__))':
                # enum is packed so we change its size to minimum required
                if len(node['fields']) <= 256:
                    node_format = 'B'
                elif len(node['fields']) <= 65535:
                    node_data = 'H'

            # add instruction to the parse flow (output style is ordered by priority)
            parse_flow.append(['FIELD', prefix, node_format, style or node['style'] or '{}', texted])

        elif node['node_type'] == nt.STRUCT:
            # get the largest field in the structure
            largest_field = get_largest_field(node)
            if largest_field:
                # memory pointer should be aligned before the structure
                parse_flow.append(['PAD', largest_field])

            # add parsing flow for each structure field recursively
            for field in node['fields']:
                if field['name'].startswith(nt.CODE):
                    # skip code nodes
                    continue

                # get underlay type metadata and union selector name
                type_node, selector = process_field_metadata(field)

                # prepare parsing flow for field
                field_parse_flow = self._build_parse_flow(type_node, '%s.%s' % (prefix, field['name']),
                                                          selector, silent, field['style'])

                # if field is an array, we add 'ARRAY' node instead of 'FIELD'
                if field.get('arraysize'):
                    if field_parse_flow[0][0] == 'PAD':
                        # if we have padding at the beginning of an array
                        # we should move it before array
                        parse_flow.append(field_parse_flow[0])
                        flow = field_parse_flow[1:]
                    else:
                        flow = field_parse_flow

                    # recursive multidimensional arrays packing
                    for array_factor in get_array_factor(node, field, prefix)[::-1]:
                        flow = [['ARRAY', array_factor, flow]]

                    parse_flow.append(flow[0])
                else:
                    parse_flow += field_parse_flow

            if largest_field:
                # structure should be post-aligned according to the biggest field
                parse_flow.append(['PAD', largest_field])

        elif node['node_type'] == nt.UNION:
            selection = {}  # contains multiple parsing flows used depending on key field value
            u_selector_type = ''  # data type name of union selector field

            # get the largest field in the union
            largest_field = get_largest_field(node)
            if largest_field:
                # memory pointer should be aligned before the union
                parse_flow.append(['PAD', largest_field])

            # union is a selection of multiple sub-flows
            for field in node['fields']:
                if field['name'].startswith(nt.CODE):
                    # skip code nodes
                    continue

                if u_selector and not field.get('selected_by'):
                    # union has union selector, but do not have selected_by value
                    g_logger.error('Union\'s field \'%s.%s\' should have \'selected_by\' attribute.' % (node['typename'], field['name']))
                    raise SxLoggerProcessingError('Union field does not have attribute "selected_by"')

                # getting underlay type data if field is complex
                type_node = field['type'] if self._is_base_type(field['type']) else self.adb_parser.db_access('types', field['type'])

                # prepare parse flor for single union field
                union_item_parse_flow = self._build_parse_flow(type_node, '%s.%s' % (prefix, field['name']),
                                                               silent=silent, style=field['style'])

                # we assume if union has selector, it's field must have "selected_by"
                if u_selector:
                    # process multiple selected_by items
                    for selected_by_item in field['selected_by']:
                        # try to convert 'selected_by' into a number
                        if selected_by_item in self.adb_parser.get_named_value():
                            selected_by, parent_node = self.adb_parser.get_named_value(selected_by_item, parent=True)

                            if u_selector_type and u_selector_type != parent_node and not silent:
                                # union fields point to different key field types
                                g_logger.info('Union\'s \'%s\' field \'%s\' uses ' % (node['typename'], field['name'])
                                              + 'different key type:\n    - "selected_by" points to "%s"\n' % parent_node
                                              + '    - "union_selector" type is "%s"' % u_selector_type,
                                              end='\n')

                            elif not u_selector_type:
                                # initialize union selector type
                                u_selector_type = parent_node

                        else:
                            g_logger.error('Unresolved name %s.%s."%s"' % (node['typename'], field['name'], selected_by_item))
                            raise SxLoggerProcessingError('Cannot resolve "selected_by" attribute value')

                        # append fields parsing flow to selection flow
                        selection[selected_by] = union_item_parse_flow

                else:
                    # there is no union selector, so we assign "selected_by" value automatically
                    selected_by = '[union.%s] ' % field['name']
                    selection[selected_by] = union_item_parse_flow

            # there may be situation, when user specified union flow for part of
            # possible selector values. In such case we create stubs for others,
            # not mentioned, selector values, to omit failure.
            if u_selector_type:
                # fill up union selection with missing key field values
                key_node = self.adb_parser.db_access('types', u_selector_type)
                if key_node['node_type'] == nt.ENUM:
                    for field in key_node['fields']:
                        if field['name'].endswith(('_MIN', '_MAX', '_MIN_E', '_MAX_E')) or \
                                field['name'].startswith(nt.CODE):
                            # ignore enum items with MIN or MAX meaning and code nodes
                            continue

                        value = self.adb_parser.get_named_value(field['name'])
                        if value not in selection:
                            selection[value] = [['NONE']]

            # add union parsing instruction
            parse_flow.append(['UNION', u_selector or 'default', selection])

            if largest_field:
                # union should be post-aligned according to the biggest field
                parse_flow.append(['PAD', largest_field])

        elif node['node_type'] == nt.TYPEDEF:
            # typedef is type name overriding so we get underlay type name
            type_node = node['type'] if self._is_base_type(node['type']) else self.adb_parser.db_access('types', node['type'])
            # build parse flow for underlay node
            node_parse_flow = self._build_parse_flow(type_node, prefix, silent=silent, style=(style or node['style']))

            # add array instruction if underlay type is array else add single parsing flow
            if node.get('arraysize'):
                if node_parse_flow[0][0] == 'PAD':
                    # if we have padding at the beginning of an array
                    # we should move it outside before array
                    parse_flow.append(node_parse_flow[0])
                    flow = node_parse_flow[1:]
                else:
                    flow = node_parse_flow

                # recursive multidimensional arrays packing
                for array_factor in get_array_factor({}, node, prefix)[::-1]:
                    flow = [['ARRAY', array_factor, flow]]

                parse_flow.append(flow[0])
            else:
                parse_flow += node_parse_flow

        return parse_flow

    def parse_api_params(self, opcode, packet):
        """ Function parse SX API parameters from packet data

        :param opcode: API function code used to identify parameters data type
        :param packet: SX API Call packet (CMD or REPLY)
        """
        # define packet side
        side = '   [{}]'.format('CMD' if packet.call.side else 'REPLY')
        # get parse flow for API parameters
        parse_flow = self.type_parse_flow.get(g_api_codes.get(opcode, ('', ''))[1])

        if not len(packet.call.data):
            # api call doesn`t contain parameters
            g_logger.normal(side + ' no params data', end='\n\n', label=False)

        elif parse_flow:
            # parse parameters using parse flow
            g_logger.normal(side, end='\n', label=False)
            self._packet_side = packet.call.side  # side of packet: CMD or REPLY
            self._api_params = []  # list used to store parsed parameters
            self._known_params = {}  # list of parsed params values (except of IP and MAC addresses)

            # run parameters parsing here
            failed = False  # flag used to delay parsing fail
            try:
                last_memptr = self._parse_params(parse_flow, packet.call.data)
                if last_memptr < len(packet.call.data):
                    # there is more data in the buffer than Logger parsed
                    g_logger.warning('Last {} bytes of data buffer were not parsed. '.format(len(packet.call.data) - last_memptr)
                                     + 'Enable \'--debug\' mode to get more information')
                    self._params_hex_dump(packet)

            except (struct.error, SxLoggerProcessingError) as e:
                err = e
                failed = True

            # print parsed parameters
            fields = ''
            for param in self._api_params:
                fields += '   %s = %s%s\n' % (g_logger.highlight(fc.CYA, param['field']), param['value'],
                                              g_logger.highlight(fc.YLW, (' %s' % param['texted']).rstrip()))
            g_logger.normal(fields, end='', label=False)

            # check if parsing has failed and post-process failures
            if failed:
                # increase failures counter for this API
                self._failed_apis[opcode] = self._failed_apis.get(opcode, 0) + 1

                g_logger.error('Failed to parse parameters. Some data may be absent.\n [i] %s' % err)
                self._params_hex_dump(packet)

            g_logger.normal('', end='\n', label=False)

        elif g_logger.get_level() >= llvl.DEBUG:
            # print hex dump of parameters that are not described in ADB
            g_logger.debug(side + ' params hex dump', end='\n', label=False)
            self._params_hex_dump(packet)

        else:
            self.__params_skipped = True

    def _params_hex_dump(self, packet):
        """ Function print packet params in hex format

        :param packet: SX API packet with parameters
        """
        # calculate parameters size and parse them from raw data
        header_sz = SX_API_CMD_HEADER_LEN if packet.call.side else SX_API_RPL_HEADER_LEN
        params_sz = packet.call.msg_size - header_sz + 4
        params = struct.unpack('B' * params_sz, packet.call.data)

        # define content variable and limit of hex output
        content = '   \'***\' %d bytes\n\n' % params_sz
        hex_limit = 1000  # bytes

        if params_sz < hex_limit:
            # params size is below the limit
            row_sz = 32  # number of bytes to dump per row

            # create hex dump header
            head = '   addr |  ' + ('+{:<2}        ' * (len(params[0:row_sz]) // 4)).rstrip() + '\n'
            content += head.format(*[i for i in range(0, len(params[0:row_sz]), 4)])

            # create hex dump table
            for i in range(0, len(params[::row_sz]) * row_sz, row_sz):
                linesz = len(params[i:i + row_sz])
                line = '   {:>4} |' + ''.join(' ' * ((not i % 4) + (not i % 2)) + '{:02x}' for i in range(linesz))
                content += line.format(i, *params[i:i + row_sz]) + '\n'

        else:
            # params are too big
            content += '   [HEX dump is limited by %d bytes]\n' % hex_limit

        g_logger.debug(content, end='\n', label=False)

    def _parse_params(self, parse_flow, data, memptr=0, array_prefix=''):
        """ Function parse data stream according to parse flow

        :param parse_flow: ordered list of instructions for parameters parsing
        :param data: data from PCAP file that contains parameters
        :param memptr: memory pointer used to track last parsed byte position
        :param array_prefix: index of array item
        """

        def get_flow_size(parse_flow):
            """ Function get total size of data that will be parsed in parsing flow

            :param parse flow: ordered list of instructions for parameters parsing
            :return: total parse flow size
            """
            totalsize = 0  # total flow size

            for step in parse_flow:
                if step[0] == 'FIELD':
                    # align field in the memory
                    totalsize += align_memptr(totalsize, struct.calcsize(step[2][0]))
                    # increase total size by size of the field
                    totalsize += struct.calcsize(step[2])

                elif step[0] == 'ARRAY':
                    array_factor = 1  # initial value of an array factor

                    # try to get an array factor value
                    if isinstance(step[1], int):
                        array_factor = step[1]
                    elif str(step[1]).isdigit():
                        array_factor = int(step[1])
                    elif str(step[1]) in self._known_params:
                        array_factor = int(self._known_params[step[1]])
                    else:
                        raise SxLoggerProcessingError('Array size depends on the value of unknown field "%s" %s.\n '
                                                      'Known fields:\n %s' % (step[1], type(step[1]), self._known_params))

                    # increase total size by size of array
                    totalsize += array_factor * get_flow_size(step[2])

                elif step[0] == 'UNION':
                    # calculate all possible union flows size
                    size_variants = [get_flow_size(case) for case in step[2].values()]
                    # add the biggest one as a size of union
                    totalsize += max(size_variants)

            return totalsize

        def is_param_number(param_value):
            """ Function checks if parameter value may be used as
                size of array or union selector
            """
            if isinstance(param_value, int):
                # it is already an integer
                return True
            elif ':' in param_value:
                # value is a MAC address
                return False
            elif param_value.count('.') > 1:
                # value is an IP address
                return False
            elif not param_value.replace('0x', '').isdigit():
                # value is not a decimal or hex number
                return False

            return True

        def prepare_pv(param_value):
            """ Function is used to preprocess parameter value """
            if not is_param_number(param_value):
                # param value should stay as string
                return param_value

            if param_value.startswith('0x'):
                # value is in the HEX format
                return int(param_value[2:], 16)

            return int(param_value)

        def align_memptr(memptr, alignment):
            """ Function calculates node alignment

            :param memptr: memory pointer contain byte position in data structure
            :param alignment: alignment step

            :return number of aligned bytes
            """
            return (alignment - memptr % alignment) % alignment

        # run parsing flow step-by-step
        for step in parse_flow:
            if step[0] == 'NONE':
                # parsing flow stub
                continue

            elif step[0] == 'FIELD':
                # check and perform auto-alignment procedure
                memalign = align_memptr(memptr, struct.calcsize(step[2][0]))
                if memalign:
                    # g_logger.trace('Auto-padding {} +{} byte(s) >> {}'.format(memptr, memalign, memptr + memalign))
                    memptr += memalign

                # define field name, size and parse buffer according to field`s format
                field_name = array_prefix + step[1]
                field_sz = struct.calcsize(step[2])
                params = struct.unpack(step[2], data[memptr: memptr + field_sz])

                # put parsed values into field's output style string and try to get its texted value
                styles = [s for s in step[3].split('|') if s]
                values = [style.format(*params) for style in styles]
                prepared_values = [prepare_pv(v) for v in values]

                texted = ''
                if step[4]:
                    for val in prepared_values:
                        # go through all values and get the first valid value
                        if isinstance(val, int) and step[4].get(val):
                            texted = step[4].get(val, '')
                            break

                # join all variants of field value into one line
                pv_line = ' | '.join(values).strip()

                # save parsed field and shift memory pointer
                if not (prepared_values[0] == 0 and texted == '' and self._params['skip_zero']):
                    self._api_params.append({'field': field_name, 'value': pv_line, 'texted': texted})

                for val in prepared_values:
                    # go through all value formats and get the first valid value
                    if isinstance(val, int):
                        self._known_params[field_name] = val
                        break

                # g_logger.trace('Parsed field "{}" [mem: {}+{}; format: {}] = {}'.format(field_name, memptr, field_sz, step[2], pv_line))
                memptr += field_sz

            elif step[0] == 'PAD':
                memalign = align_memptr(memptr, step[1])
                if memalign:
                    # g_logger.trace('Padding {} +{} byte(s) >> {}'.format(memptr, memalign, memptr + memalign))
                    memptr += memalign

            elif step[0] == 'ARRAY':
                # flow for array parsing
                arr_sz = step[1]  # number of items in the array
                if not isinstance(arr_sz, int):
                    # array size is not a number, so check if it is any known field
                    arr_sz = self._known_params.get(array_prefix + str(step[1]))
                    if arr_sz is None:
                        # currently we cannot parse this array due to unknown size
                        raise SxLoggerProcessingError('Unknown array size "{}" used'.format(array_prefix + str(step[1])))

                rollback_memptr = memptr  # used to revert pointer value if array parsing failed
                for i in range(arr_sz):
                    try:
                        memptr = self._parse_params(step[2], data, memptr, array_prefix + '[%d] ' % i)
                    except struct.error as e:
                        """ There are two cases when array may be empty with non-zero array size:
                            1. In CMD packet when API request N entries from DB.
                            2. In REPLY packet when returns count of stored entries.

                            Here we try to check both scenarios.
                            Note:
                                - If there is no command field (or it has non-typical name)
                                we will fail.
                                - If buffer after array is still bigger than array, then it
                                will be parsed incorrectly and parsing will fail after it.
                        """
                        # look for the command field
                        cmd_fields = [f for f in self._known_params.keys() if 'cmd' in f]
                        if len(cmd_fields) != 1:
                            # we can not find command field
                            g_logger.warning('Unable to define command field')
                            raise e

                        # get value of API command field
                        cmd = self._known_params[cmd_fields[0]]

                        # get codes of GET and COUNT command
                        is_get_code = cmd == self.adb_parser.get_named_value('SX_ACCESS_CMD_GET')
                        is_cnt_code = cmd == self.adb_parser.get_named_value('SX_ACCESS_CMD_COUNT')

                        if not (is_get_code or is_cnt_code):
                            # command field is not GET or COUNT
                            g_logger.debug('Command is not GET or COUNT')
                            raise e

                        # (CMD packet and GET command) or (REPLY packet and COUNT command)
                        if (self._packet_side and is_get_code) or ((not self._packet_side) and is_cnt_code):
                            # array parsing failed due to one of two expected scenarios
                            # so, we revert memory pointer and continue parsing
                            memptr = rollback_memptr
                            # g_logger.trace('Array parsing skipped. API requested entries %s' % ('array' if is_get_code else 'count'))
                            break

            elif step[0] == 'UNION':
                # flow for union parsing
                key_field = array_prefix + step[1]  # key field name
                union_flows = step[2]

                if key_field in self._known_params:
                    # value of the key field
                    key_field_value = int(self._known_params[key_field]) if step[1] != 'default' else step[1]
                    # get parsing flow due to key value
                    union_parse_flow = union_flows.get(key_field_value)

                    if union_parse_flow:
                        # try to predict memory pointer after union parsing
                        prediction_failed = False
                        try:
                            # try to predict pointer position using only static "parse_flow" data
                            exp_ptr = memptr + get_flow_size([step])

                        except SxLoggerProcessingError as e:
                            # we can`t predict memory pointer position statically due to the flow
                            # complexity. So we will try to get it's size dynamically.
                            # g_logger.trace('Dynamic Union Size Prediction [STARTED]', end='\n')
                            try:
                                # try to predict pointer position using parsing flow and packet data
                                orig_params = copy.deepcopy(self._api_params)  # backup original params list
                                subflow_ptrs = []  # all union subflow's pointers after the parsing

                                # go through each possible union flow
                                for key, subflow in union_flows.items():
                                    subflow_ptrs.append(self._parse_params(subflow, data, memptr, array_prefix))

                                exp_ptr = max(subflow_ptrs)
                                # g_logger.trace('Dynamic Union Size Prediction [DONE] +%d bytes' % (exp_ptr - memptr), end='\n')

                            except SxLoggerProcessingError as e:
                                # we are unable to calculate union size for some reason. At that point
                                # we know that in most of cases further parsing will provide incorrect
                                # data. But we will continue parsing with hope that the parsed union's
                                # flow was the biggest one.
                                # g_logger.trace('Dynamic Union Size Prediction [FAILED]', end='\n')
                                g_logger.warning(e)
                                prediction_failed = True

                            finally:
                                # return back original parsed parameters
                                del self._api_params  # remove previous api parameters
                                self._api_params = orig_params  # assign a new copy

                        # perform parsing of actual union flow
                        memptr = self._parse_params(union_parse_flow, data, memptr, array_prefix)

                        if prediction_failed:
                            # if prediction failed, we just assume that new memptr was expected
                            exp_ptr = memptr

                        if memptr > exp_ptr:
                            # memory pointer has been shifted more than union size
                            g_logger.error('Memptr overflow. Real: %d; Expected: %d' % (memptr, exp_ptr))
                            raise SxLoggerProcessingError('Memory management issue during union parsing')

                        # g_logger.trace('Shifting union [key: %s] pointer on %d bytes' % (key_field, exp_ptr - memptr))
                        memptr = exp_ptr
                    else:
                        g_logger.error('Union flow for \'%s\'=\'%s\' is absent' % (key_field, key_field_value))
                        g_logger.debug('Available keys: %s' % union_flows.keys())
                        raise SxLoggerProcessingError('Unexpected union selector value')

                elif step[1] == 'default':
                    # g_logger.trace('Parsing all {} union subflows: {}'.format(len(union_flows), '\b, '.join(sorted(union_flows))))
                    subflow_ptrs = []  # all union subflows pointers after the parsing
                    orig_ptr = memptr  # original memptr value

                    # go through each possible union's flow
                    for key, subflow in sorted(union_flows.items()):
                        subflow_ptrs.append(self._parse_params(subflow, data, memptr, array_prefix + key))

                    memptr = max(subflow_ptrs)
                    # g_logger.trace('Shifting union [key: {}] pointer on {} +{} bytes'.format(key_field, memptr, memptr - orig_ptr))

                else:
                    g_logger.error('Unknown key field \'%s\'' % key_field)
                    return memptr

        return memptr

    def prepare_filter(self):
        """ Function process filter file and stores API names that should be filtered """
        def ord_postfix(number):
            """ Function returns ordinal numbers postfix """
            last_digit = number % 10

            if number < 11 or number > 13:
                if last_digit == 1:
                    return 'st'
                elif last_digit == 2:
                    return 'nd'
                elif last_digit == 3:
                    return 'rd'

            return 'th'

        # check if there is any sort of filtering
        if not (self._filter['range'] or self._filter['api']):
            # Filter was not enabled
            return

        # details of the filtering configuration
        details = 'Filtering enabled.\n'

        if self._filter['range']:
            # prepare range filter message
            from_id = self._filter['from_id']
            till_id = self._filter['till_id']

            before = ('before %d%s call' % (from_id, ord_postfix(from_id))) if from_id else ''
            after = ('after %d%s call' % (till_id, ord_postfix(till_id))) if till_id else ''

            # compile full message
            details += ' [Filter] APIs %s will be ignored.\n' % (before + (' and ' if before and after else '') + after)

        if self._filter['api']:
            # parse filter file and save API names
            with open(self._filter['file'], 'r') as f:
                for line in f.readlines():
                    if not (line.startswith('#') or len(line.split()) != 1):
                        self._filter_db.add(line.split()[0].lower())

            details += ' [Filter] %d APIs will be %sd' % (len(self._filter_db), self._filter['api'])

            if len(self._filter_db) > 20:
                # too much APIs will affect logs readability
                details += '.\n See filter file {}'.format(self._filter['file'])

            elif len(self._filter_db) > 0:
                details += ':\n\t+ {}\n'.format('\n\t+ '.join(self._filter_db))

            else:
                details += '. Your filter file is empty.'

        g_logger.normal(details, end='\n')

    def filtered(self, opcode):
        """ Function check if call should be filtered

        :param opcode: opcode of the API
        :return: True if should be filtered, False if not.
        """
        global g_api_codes

        if self._filter_db and opcode in g_api_codes:
            # get API name
            api_name = g_api_codes[opcode][0].lower()

            # filter API if it is:
            # - in the file and mode is exclude
            # - not in the the file and mode is include
            if (api_name in self._filter_db and self._filter['api'] == 'exclude') or \
               (api_name not in self._filter_db and self._filter['api'] == 'include'):
                return True

        return False

    def run(self):
        """ Function display SX API calls in specific range."""
        def show_title():
            """ Print title before API calls will be printed """
            title_str = '\n' + '  ' + '-' * 149 + '\n' + \
                        self._call_tmpl.format('ID/ SYSFS ACCESS', 'API_FUNCTION (OPCODE)/ SYSFS FILE PATH (WRITE ACCESS)', 'STATUS (RETCODE)', 'DURATION', 'CMD/ SYSFS TS', 'REPLY TS').format('', '') + '\n' + \
                        '  ' + '-' * 149

            g_logger.normal(title_str, end='\n', label=False)

        def show_footer():
            """ Print footer after API calls will be printed """
            g_logger.normal('  \'' + '-' * 140 + '\'', end='\n', label=False)

        # initialize prerequisite variables
        self._failed_apis = {}  # dict with APIs where parameters parsing failed
        self.__params_skipped = False  # notify user that some parameters were not printed

        self._show_cmd = self._params['mode'] in ['all', 'native', 'cmd']  # enable parsing of CMD parameters
        self._show_rpl = self._params['mode'] in ['all', 'reply']  # enable parsing of REPLY parameters
        self._call_tmpl = '  |{0:>17}| {1:<50} | {{0}}{2:<25}{{1}} | {3:>8} s | {4:>12} s | {5:>10} s |'  # API call output template
        self._sysfs_msg_separators = ['  {0}{1:-^148}{0}\n'.format('-', ''), '  {0}{1:-^148}{0}\n'.format('\'', '')]

        if self._params['mode'] in ['all', 'native', 'cmd', 'reply']:
            self._msg_separators = ['  {0}{1:-^155}{0}\n'.format('-', ''), '  {0}{1:-^155}{0}\n'.format('\'', '')]
        else:
            self._msg_separators = ['', '']

        # save the first and the last API calls in local variables
        from_id = self._filter.get('from_id')
        till_id = self._filter.get('till_id')

        # calculate per API call progress
        per_call_progress = 100.0 / (self.reader.count_packets() / 2)

        # reset PCAP reader configuration
        self.reader.reset()

        # print the title
        show_title()

        # start task "API calls parsing"
        g_pbar.start('API calls parsing')

        while True:

            """ SX API calls are always paired as CMD-REPLY
                SYSFS packet can be in any order in the pcap file
                That's why if we get cmd packet, we expect the
                next packet to be sysfs or reply
            """
            cmd_found = False
            rpl_found = False
            mallformed = 0  # malformed packet detection flag

            while (cmd_found == False or rpl_found == False) and mallformed == 0:

                packet = self.reader.next_packet()
                if not packet:
                    break

                if packet.call.side == 1:
                    if cmd_found:
                        mallformed = 1

                    cmd_found = True
                    cmd_packet = packet

                if packet.call.side == 0:
                    if not cmd_found:
                        mallformed = 2

                    rpl_found = True
                    rpl_packet = packet

                if packet.call.side == 2:
                    self.sysfs_access_show(packet)
                    self.reader.packet_id_modify(-1)
                    continue

                if packet.call.side == 3:
                    self.traps_show(packet)
                    self.reader.packet_id_modify(-1)
                    continue

            if (cmd_found == False or rpl_found == False) and mallformed == 0:
                break
            # call_id is equal to a half of proceed packets, relevant for SX-API calls
            call_id = cmd_packet.packet_id / 2 + 1

            if (from_id and (call_id < from_id)) or self.filtered('%x' % cmd_packet.call.opcode):
                # call is before the user-specified range or
                # should be ignored due to the filter file
                continue
            elif till_id and (call_id > till_id):
                # call is after the user-specified range
                break

            if mallformed:
                # mallformed packet processing
                malformed_packet = cmd_packet if mallformed == 1 else rpl_packet
                g_logger.error('Packet #{} ({}) mallformed. [{}]'.format(malformed_packet.packet_id,
                                                                         'CMD' if mallformed == 1 else 'REPLY',
                                                                         malformed_packet.call.hex))
                g_logger.error(malformed_packet, end='\n', label=False)

                continue

            # print call information
            self.api_call_show(call_id, cmd_packet, rpl_packet)

            # update progress "API calls parsing"
            g_pbar.progress_inc(per_call_progress)

        # finish task "API calls parsing"
        g_pbar.finish()

        # print footer
        show_footer()

        if self.__params_skipped:
            # notify user that some parameters were not printed
            g_logger.warning('Some API params are not available yet. Use \'--debug\' to see them in HEX')

        if self._failed_apis:
            # notify user that some Logger is unable to parse some API parameters
            failed_list = []
            for k, v in self._failed_apis.items():
                # convert opcode to an API name
                failed_list.append('{} ({}) x {} time(s)'.format(g_api_codes.get(k, ['unknown'])[0].lower(), k, v))

            g_logger.warning('Params parsing failed in {} API(s). '.format(len(failed_list))
                             + 'Enable \'--debug\' to get the details')
            g_logger.debug('Parsing failed in following API(s):\n    - {}'.format('\n    - '.join(sorted(failed_list))),
                           end='\n')

    def is_ascii(self, bytes_string):
        """Check if the characters in the string are in ASCII"""
        return all(c < 128 for c in bytes_string)

    def sysfs_access_show(self, sysfs_packet):
        """ Function print SYSFS ACCESS call information in user-friendly format

        :param sysfs packet: sysfs packet to display
        """

        func_name = sysfs_packet.call.func_name.decode().replace('\x00', '')
        file_path = sysfs_packet.call.path.decode().replace('\x00', '')

        TS = sysfs_packet.ts_sec + sysfs_packet.ts_usec / 1000000.0

        table_row = self._call_tmpl.format("SYSFS ACCESS", '%s (%x)' % (file_path, sysfs_packet.call.is_write),
                                           '%s (%s)' % ("N/A", "N/A"), "N/A", TS, 0.0)

        # print call information
        st_color = fc.YLW
        msg = self._sysfs_msg_separators[0] + table_row.format(st_color, fc.NRM) + '\n' + \
            self._sysfs_msg_separators[1]
        g_logger.normal(msg, end='', label=False)

        params = ''
        params += '   %s = %s\n' % (g_logger.highlight(fc.CYA, "access type"), "WRITE" if sysfs_packet.call.is_write else "READ")
        params += '   %s = %s\n' % (g_logger.highlight(fc.CYA, "function name"), func_name)
        params += '   %s = %s\n' % (g_logger.highlight(fc.CYA, "buffer length"), sysfs_packet.call.buf_len)
        if sysfs_packet.call.is_write:
            if self.is_ascii(sysfs_packet.call.data):
                params += '   %s = %s\n' % (g_logger.highlight(fc.CYA, "write buffer"), sysfs_packet.call.data.decode())
            else:
                params += '   %s = %s\n' % (g_logger.highlight(fc.CYA, "write buffer"), sysfs_packet.call.data)

        g_logger.normal(params, end='\n', label=False)

    def api_call_show(self, call_id, cmd, reply):
        """ Function print API call information in user-friendly format

        :param call_id: identifier of API call
        :param cmd: command packet
        :param reply: reply packet
        """
        global g_api_codes
        global g_status_codes

        # convert api code to api name
        api_name = g_api_codes.get('%x' % cmd.call.opcode, ['unknown'])[0].lower()

        # calculate call duration
        dur = '{:0.5f}'.format(self.reader.packets_ts_diff(cmd, reply)) if reply else 0.0

        cmd_timestamp = cmd.ts_sec + cmd.ts_usec / 1000000.0
        rpl_timestamp = reply.ts_sec + reply.ts_usec / 1000000.0 if reply else 0.0

        # convert retcode to status string
        retcode = reply.call.retcode if reply else -1

        # configure status name and color
        if reply:
            status = g_status_codes.get(retcode, 'unknown').upper()[-19:]
            st_color = fc.YLW if status == 'UNKNOWN' else (fc.RED if retcode else fc.GRN)
        else:
            # no REPLY packet
            status = 'NO REPLY'
            st_color = fc.RED

        table_row = self._call_tmpl.format(call_id, '%s (%x)' % (api_name, cmd.call.opcode),
                                           '%s (%s)' % (status, retcode), dur, cmd_timestamp, rpl_timestamp)

        # print call information
        msg = self._msg_separators[0] + table_row.format(st_color, fc.NRM) + '\n' + \
            self._msg_separators[1]
        g_logger.normal(msg, end='', label=False)

        # print CMD packet parameters
        if self._show_cmd:
            self.parse_api_params('%x' % cmd.call.opcode, cmd)

        # print REPLY packet parameters if there is a REPLY
        if reply and (self._show_rpl or (self._params['mode'] == 'native' and api_name.endswith('_get'))):
            self.parse_api_params('%x' % cmd.call.opcode, reply)

    def __pude_trap_show(self, trap_id, event_timestamp, event_unpacked):
        fields = None
        sdk_trap_str = self.sdk_traps_mapping[trap_id][0]
        log_port = "0x%x" % (event_unpacked[0])
        oper_state = event_unpacked[1]
        swid = event_unpacked[2]
        log_state = event_unpacked[3]
        oper_state_str = port_oper_status_mapping[oper_state]
        logical_state_str = port_logical_state_mapping[log_state]
        table_row = self._call_tmpl.format("       1", 'SDK Trap %s (%x) port(%s) state(%s)' % (sdk_trap_str, trap_id, log_port, oper_state_str),
                                           '%s(%u) %s(%u)' % (oper_state_str, oper_state, logical_state_str, log_state), "N/A", event_timestamp, 0.0)

        fields = " [PARAMS]\n pude.log_port = {} \n pude.oper_state = {}({}) \n pude.swid = {}\n pude.logical_state = {}({})\n".format(log_port, oper_state_str, oper_state, swid, logical_state_str, log_state)
        return table_row, fields

    def __ipac_trap_show(self, trap_id, event_timestamp, event_unpacked):
        fields = None
        sdk_trap_str = self.sdk_traps_mapping[trap_id][0]
        port_profile_status = event_unpacked[0]
        port_profile_index = event_unpacked[1]
        error_log_port = "0x%x" % (event_unpacked[2])
        error_api = event_unpacked[3]
        device_id = event_unpacked[4]
        db_copy_fail = event_unpacked[5]

        port_profile_status_str = port_profile_ipac_mapping[port_profile_status]
        api_name = ""
        if error_api:
            api_name = g_api_codes.get('%x' % self.error_api, ['unknown'])[0].lower()
        table_row = self._call_tmpl.format("       2", 'SDK Trap %s (%x) port(%s) status(%s)' % (sdk_trap_str, trap_id, error_log_port, port_profile_status_str),
                                           '%s (%u)' % (port_profile_status_str, port_profile_status), "N/A", event_timestamp, 0.0)

        fields = " [PARAMS]\n ipac.status= {}({})\n ipac.port_profile_index = {}\n ipac.error_log_port = {}\n ipac.error_api = {}({})\n ipac.device_id = {}\n ipac.db_copy_fail = {}\n".format(port_profile_status_str, port_profile_status, port_profile_index, error_log_port, api_name, error_api, device_id, db_copy_fail)
        return table_row, fields

    def __traps_hex_dump(self, event_info):
        """ Function print Trap event info in hex format

        """

        # define content variable and limit of hex output
        content = '   \'***\' %d bytes\n\n' % TRAP_HEADER_LENGTH

        row_sz = 32  # number of bytes to dump per row

        # create hex dump header
        head = '   addr |  ' + ('+{:<2}        ' * (len(event_info[0:row_sz]) // 4)).rstrip() + '\n'
        content += head.format(*[i for i in range(0, len(event_info[0:row_sz]), 4)])

        # create hex dump table
        for i in range(0, len(event_info[::row_sz]) * row_sz, row_sz):
            linesz = len(event_info[i:i + row_sz])
            line = '   {:>4} |' + ''.join(' ' * ((not i % 4) + (not i % 2)) + '{:02x}' for i in range(linesz))
            content += line.format(i, *event_info[i:i + row_sz]) + '\n'

        g_logger.debug(content, end='\n', label=False)

    def traps_show(self, packet):
        trap_id = packet.call.trap_id
        event_timestamp = packet.ts_sec + packet.ts_usec / 1000000.0
        source_log_port = packet.call.source_log_port
        event_info = packet.call.event_info
        event_size = packet.call.event_size

        if trap_id in self.sdk_traps_mapping.keys():
            fields = None
            event_unpacked = struct.unpack(self.sdk_traps_mapping[trap_id][1], event_info[:event_size])
            table_row, fields = self.sdk_traps_mapping[trap_id][2](trap_id, event_timestamp, event_unpacked)

            st_color = fc.RED

            msg = self._msg_separators[0] + table_row.format(st_color, fc.NRM) + '\n' + \
                self._msg_separators[1]
            g_logger.normal(msg, end='', label=False)

            # Print Event Info
            if fields:
                g_logger.normal(fields, end='', label=False)
                g_logger.normal('', end='', label=False)
        else:
            g_logger.warning('Unknown Trap ID {} '.format(trap_id) + 'Enable \'--debug\' mode to get more information')
            if g_logger.get_level() >= llvl.DEBUG:
                # print hex dump of parameters that are not described in ADB
                g_logger.warning('Trap params hex dump', end='\n', label=False)
                self.__traps_hex_dump(event_info)


def main():
    pass


if __name__ == '__main__':
    main()
