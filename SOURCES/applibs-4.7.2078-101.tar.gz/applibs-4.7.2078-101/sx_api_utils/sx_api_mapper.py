#!/usr/bin/env python3
"""
# SX API Mapper tool
#
# Provide generation of file with mapping between API
# names and opcodes. Generated file may be used by SX
# Filter Maker (sx_filter_maker) to generate binary
# filter file for SX Sniffer and SX Runner.
#
"""
__title__ = 'SX_API_MAPPER'
__author__ = 'oleksandrv, ypasichnyk'
__version__ = '0.4.2'
__release__ = 'June-2023'

import os
import sys
import json
import argparse

# import SX API Utils library
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.utils import g_logger, g_pbar, AdbParser, LogLevel as llvl, FontColor as fc, TimeOutException, timeout


class SxApiMapper:
    """ SX API Mapper object
    Class contains functionality for mapping file generation.

    Attributes:
    _common_adb : str
                  Path to the common.adb file.
    _mapping_file : str
                    Path to the final output mapping file.
    _mapping      : dict
                    Dictionary with API name as a key and opcode as a value.
    """

    def __init__(self, common_adb=None):
        """ SxApiMapper object constructor """
        self._common_adb = common_adb
        self._mapping_file = os.path.dirname(self._common_adb or './') + '/filter.mapping'
        self._mapping = {}  # {'api_name': opcode}

    def map(self, output=None):
        """ Function process common.adb file and gets mapping between API and its opcode.

        Arguments:
            common_adb {str} -- Path to the common ADB file.
        """
        # print header
        g_logger.normal(str(self), end='\n', label=False)

        if self._common_adb and os.path.isfile(self._common_adb):
            # try to upload mapping from ADB file
            adb_parser = AdbParser([self._common_adb], validate='none')

            # api codes upload from 'api_params' section
            # {"opcode": ["api_name", "params_type_name"]}
            for opcode in adb_parser.db_access('api_params', None):
                self._mapping[adb_parser.db_access('api_params', opcode)[0].lower()] = opcode

            g_logger.normal('Mapping has been uploaded from the "{}"'.format(self._common_adb))

            # prepare mapping file location
            mapping_file = output or self._mapping_file

            # save parsed mapping into the mapping file
            with open(mapping_file, 'w+') as fp:
                json.dump(self._mapping, fp, indent=4, sort_keys=True, separators=(',', ': '))

            g_logger.success('Mapping has been saved into the "{}"'.format(mapping_file))

        else:
            g_logger.error('Please, provide a common.adb file')
            exit(1)  # catchall for general errors

    def __str__(self):
        """ Function print tool info at the beginning of execution """
        head = '  {}{{}}[version {} | {}]\n'.format(__title__, __version__, __release__)
        aligned_head = head.format(' ' * (83 - len(head)))

        return ' {0:-^80}\n{1} {0:-^80}\n'.format('', aligned_head)

    def help(self):
        """ Function print help instructions to the user """
        text = str(self) + \
            '  Tool creates mapping between name and opcode of the API functions and saves it\n' + \
            '  into the mapping file. Mapping file is used by sx_filter_maker for the binary\n' + \
            '  filter file generation. Binary filter file can be used for API filtering in\n' + \
            '  sx_sniffer or sx_runner.\n' + \
            '\n' + \
            '  1. Generate a mapping file:\n' + \
            '     {} -a|--adb <path/to/common.adb> [--debug,--color]\n'.format(os.path.basename(__file__)) + \
            '\n' + \
            '  2. Generate a mapping file to a custom location:\n' + \
            '     {} -a|--adb <path/to/common.adb> --output <path/filter.mapping>\n'.format(os.path.basename(__file__)) + \
            '\n' + \
            '  3. Get a help:\n' + \
            '     {} -h|--help\n'.format(os.path.basename(__file__)) + \
            '\n' + \
            ' {:-^80}\n'.format('')

        g_logger.normal(text, end='\n', label=False)


def main(adb=None, output=None, debug=None, color=None, help=None):
    """ Main function process user options and runs corresponding flow.

    Keyword Arguments:
        adb {str} -- Path to the custom ADB file (default: {None}).
        output {str} -- Path to the desired filter binary location (default: {None}).
        debug {bool} -- Enables debug mode in logger (default: {None}).
        color {bool} -- Enables color mode in log messages (default: {None}).
        help {bool} -- Prints a help to user (default: {None}).
    """
    # create API mapper object
    api_mapper = SxApiMapper(adb)

    if help:
        # user needs a help
        api_mapper.help()
        return

    if debug:
        # enable debug log level
        g_logger.set_level(llvl.DEBUG)

        # disable progress bar when verbosity is high
        g_pbar.disable()

    # configure colorization
    g_logger.set_color(color)

    # perform mapping
    api_mapper.map(output)


if __name__ == '__main__':
    # create and initialize arguments parser
    parser = argparse.ArgumentParser(add_help=False)
    cmd_group = parser.add_mutually_exclusive_group(required=False)

    # major part of user arguments
    cmd_group.add_argument('-a', '--adb', type=str, help='Use specified ADB file', metavar='FILE')
    parser.add_argument('--output', type=str, help='Destination of filter file binary output', metavar='FILE')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--color', action='store_true', help='Colorize output into CLI')
    cmd_group.add_argument('-h', '--help', action='store_true')

    # process arguments
    args = parser.parse_args()
    sys.exit(main(**(vars(args))))
