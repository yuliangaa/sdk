/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_HOST_H__
#define __SX_HOST_H__


#include "sx/sdk/sx_event_id.h"
#include "sx/sdk/auto_headers/sx_host_auto.h"


static __attribute__((__used__)) const char* sx_trap_type_str[] = {
    "Packet",
    "Event",
};

#define SX_TRAP_TYPE_STR(index)                        \
    (SX_CHECK_MAX(index, HOST_IFC_TRAP_TYPE_MAX - 1) ? \
     sx_trap_type_str[index] : "UNKNOWN")


/**
 * sx_receive_info_t structure is used to store received
 * packet data
 */
typedef struct sx_host_ifc_receive_info {
    sx_trap_id_t     trap_id;    /**< trap ID */
    sx_event_info_t  event_info;    /**< event info */
    sx_port_log_id_t source_log_port;    /**< source logical port */
    boolean_t        is_lag; /**< Is the source logical port member of a lag */
    sx_port_log_id_t source_lag_port;    /**< source lag port when applicable */
    uint32_t         original_packet_size; /**<the original size of packet in bytes,
                                            *  if packet wasn't truncated packet_size=original_packet_size*/
    boolean_t                    has_timestamp; /**< does packet have a time stamp? */
    struct timespec              timestamp; /**< Time stamp of the packet. For HW UTC time stamp: only 8 LSB in tv_sec are valid */
    uint32_t                     acl_user_id; /**< for ACL trap id: user ID from ACL action. SX_ACL_USER_ID_INVALID otherwise */
    sx_receive_dest_port_e       dest_port_type; /**< Destination logical port type */
    sx_port_log_id_t             dest_log_port; /**< Destination logical port. Valid if dest_type is NETWORK or LAG */
    sx_port_log_id_t             dest_lag_port; /**< Destination logical LAG port. Valid if dest_type is LAG */
    sx_packet_timestamp_source_e timestamp_source; /**< The source of the timestamps associated with the received packets,
                                                    * Spectrum supports only Linux kernel clock. */
    sx_packet_mirror_info_t mirror_info; /**< Supported devices: Spectrum2. Valid if trap_id is one of the MIRROR_AGENT traps */
    boolean_t               channel_experienced_drop; /**<User channel experienced a drop */
} sx_receive_info_t;

/**
 * sx_packet_info_t structure is used to store received packet data
 * including receive_info
 */
typedef struct sx_packet_info {
    void            * packet_p;
    uint32_t          packet_size;
    sx_receive_info_t receive_info;
} sx_packet_info_t;

#endif /* __SX_HOST_H__ */
