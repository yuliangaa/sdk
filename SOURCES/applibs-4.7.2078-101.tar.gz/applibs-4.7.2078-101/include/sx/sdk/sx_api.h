/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#if 0
/*! \main page Mellanox SwitchX API Guide
 *
 * \section intro_sec Introduction
 *
 * The SwitchX Ethernet SDK is a layered software stack, used for building a complete L2/L3 switching software.
 * The SwitchX SDK comprises of the SwitchX Driver (SxD) and the Application Libraries (AppLibs),
 * where each layer has its own independent application interface (APIs).
 * \image html SwitchXSDKSWcomponents.gif
 * \section sdk_sec SDK Libraries
 * The SDK library is a logic layer that enables porting standard-driven protocol stacks and management systems on top of the SwitchX features set.
 * The SDK libraries are used to invoke the SwitchX Driver APIs (SXD API) in order to invoke hardware configurations.
 *
 * \section sxd_sec SwitchX Driver
 * SwitchX is a hardware oriented layer that reflects register level interfaces.
 * For further information, refer to the Hardware Programmer Reference Manual.
 *
 */
#endif
#ifndef __SX_API_H__
#define __SX_API_H__


#include "sx/sdk/auto_headers/sx_api_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/


#endif /* __SX_API_H__ */
