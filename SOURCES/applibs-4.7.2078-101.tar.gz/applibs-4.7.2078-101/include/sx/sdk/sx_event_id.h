/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#ifndef SX_EVENT_ID_H_
#define SX_EVENT_ID_H_

#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_router.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_tele.h>
#include <sx/sdk/sx_dbg.h>
#include <sx/sxd/sx_bfd_ctrl_cmds.h>
#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_tunnel.h>
#include <sx/sdk/sx_mgmt.h>
#include <sx/sdk/sx_bulk_counter.h>
#include <sx/sdk/sx_macsec.h>
#include <sx/sdk/sx_tele.h>
#include "sx/sdk/auto_headers/sx_event_id_auto.h"

#define SX_OBJECT_TYPE_CHECK_RANGE(OBJECT_TYPE) \
    SX_CHECK_RANGE(SX_OBJECT_TYPE_MIN,          \
                   OBJECT_TYPE,                 \
                   SX_OBJECT_TYPE_MAX)          \

/**
 * sx_event_info_t union is used to store events data
 */
typedef union sx_event_info {
    sx_event_pude_t                            pude;                                  /**< pude event data */
    sx_event_pmpe_t                            pmpe;                                  /**< pmpe event data */
    sx_event_flae_t                            flae;                                  /**< flae event data */
    sx_event_ferr_t                            ferr;                                  /**< ferr event data */
    sx_event_tmpw_t                            tmpw;                                  /**< tmpw event data */
    sx_event_health_notification_t             sdk_health; /**< FW mfde and fshe event data */
    sx_event_need_to_resolve_arp_t             need_to_resolve_arp;
    sx_event_no_need_to_resolve_arp_t          no_need_to_resolve_arp;
    sx_rm_sdk_table_notification_t             rm_sdk_table_notification;
    sx_rm_hw_table_notification_t              rm_hw_table_notification;
    sx_router_neigh_activity_notification_t    router_neigh_activity_notification;
    sx_router_mc_route_activity_notification_t router_mc_route_activity_notification;
    sx_fdb_mc_ip_addr_activity_notification_t  fdb_mc_ip_addr_activity_notification;
    sx_event_queue_threshold_crossed_t         queue_threshold_crossed;
    sx_event_ber_monitor_t                     ber_monitor;
    sx_event_bfd_timeout_t                     bfd_timeout;
    sx_event_ibfmr_t                           ibfmr;                                 /**< ibfmr event data */
    sx_event_port_lag_changes_t                port_lag_changes;
    sx_event_port_added_deleted_t              port_added_or_deleted;
    sx_event_deleted_object_t                  deleted_object;
    sx_event_api_logger_t                      api_logger_info;
    sx_event_mocs_done_t                       mocs_done_info;
    sx_event_port_profile_apply_done_t         port_profile_apply_done_info;
    sx_bulk_cntr_done_notification_t           bulk_cntr_done_info;
    sx_event_tsde_t                            tsde;
    sx_event_pmlpe_t                           pmlpe;
    sx_event_dsdsc_t                           dsdsc;
    sx_event_bctoe_t                           bctoe;
    sx_bulk_cntr_refresh_done_notification_t   bulk_cntr_refresh_done_info; /**< The event data that comes along with the SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT event. */
    sx_event_sb_snapshot_t                     sb_snapshot;
    sx_acl_activity_notification_t             acl_activity_notification;
    sx_event_macsec_utfd_t                     utfd;
    sx_event_stateful_db_partition_threshold_t partition_threshold; /**< Stateful DB partition threshold cross event info. */
    sx_event_meccc_t                           meccc;
    sx_event_pllp_t                            pllp;
    sx_event_tac_action_done_t                 tac_action_done;
    sx_event_port_tx_ready_t                   tx_ready; /**< Port TX ready event data. */
    sx_event_mfri_t                            mfri;
    sx_event_ppir_t                            ppir;
    sx_event_mfcdr_t                           mfcdr;
    sx_event_ibissu_t                          ibissu;
    sx_event_spzr_t                            spzr;
} sx_event_info_t;

#endif /* SX_EVENT_ID_H_ */
