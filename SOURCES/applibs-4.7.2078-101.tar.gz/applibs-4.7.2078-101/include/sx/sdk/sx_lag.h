/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef __SX_LAG_H__
#define __SX_LAG_H__


#include "sx/sdk/auto_headers/sx_lag_auto.h"


/**
 * Max number of LAGs
 */
#define SX_LAG_ID_MIN   (0x00000000)
#define SX_LAG_ID_MAX   (rm_resource_global.lag_num_max - 1)
#define SX_LAG_ID_COUNT (SX_LAG_ID_MAX - SX_LAG_ID_MIN + 1)

/**
 * Max number of ports per LAG
 */
#define SX_LAG_MAX_PORTS_PER_LAG (rm_resource_global.lag_port_members_max)


#define INVALID_LAG_ID rm_resource_global.lag_num_max

#define SX_LAG_ID_CHECK_RANGE(LAG_ID) SX_CHECK_MAX(LAG_ID, SX_LAG_ID_MAX)

#define INVALID_LAG_ID_LOG_PORT(id)            \
    id = 0;                                    \
    SX_PORT_TYPE_ID_SET(id, SX_PORT_TYPE_LAG); \
    SX_PORT_LAG_ID_SET(id, INVALID_LAG_ID)

#define SX_LAG_HASH_TYPE_SPECTRUM_CHECK_RANGE(LAG_HASH_TYPE) \
    SX_CHECK_MAX(LAG_HASH_TYPE, SX_LAG_HASH_TYPE_RANDOM)

/**
 * sx_ladb_port_indices_t structure is used to store LAG port's indices DB
 */
typedef struct {
    boolean_t           valid;         /**< Used to coordinate between the users of the LAG's shared memory */
    cl_plock_t          p_lock;
    uint32_t            max_lag_ports;
    uint32_t            max_lid;
    sx_ladb_port_data_t lag_ports[0];  /**< Place keeper, actual size determined on init */
} sx_ladb_port_indices_t;


#endif /* __SX_LAG_H__ */
