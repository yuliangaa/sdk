/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_CORE_DBG_H__
#define __SX_CORE_DBG_H__

#define VISTA_DBG_LIB_INIT "vista_dbg_lib_init"
#define SX_DBG_LIB_NAME    "/usr/lib/libsxdbg.so"

#include "../sx_api/sx_api_internal.h"

/*
 * fdb_mc_db.c
 * mcdb_context contains 2 dbs :
 * cl_qmap_t mc_group_tbl;		   mc_group_tbl(swid,vid) -> group_map(mc group) -> pgi,mid
 * cl_qmap_t mc_port_tbl;			 port -> mc group list
 */

#include "../ethl2/fdb_mc_db_records.h"
extern sx_mcdb_context_t mcdb_context;

/* fdb_uc_impl.c */
extern cl_qmap_t fdb_by_swid[SX_SWID_ID_COUNT];

/* la_db.c */
#include "../ethl2/la_db.h"
extern sx_ladb_context_t ladb_context;

/* mstp_db.c */
extern cl_qmap_t mstp_swids_qmap;

/* port_db.c */
extern cl_qmap_t port_infos_qmap;
extern cl_qmap_t port_swids_qmap;
extern cl_qmap_t port_devices_qmap;

/* topo_db.c */
#include "../ethl2/topo_db_records.h"
extern topo_root_qmap_t root_qmap;
extern topo_root_pool_t root_pool;

/* vlan_db.c */
#include "../ethl2/vlan_db.h"
extern sx_vdb_context_t vdb_context;

#include "../ethl2/brg.h"
extern sx_brg_context_t brg_context;

#define DBG_LIB_VERSION 0xbeef0001

typedef struct sx_api_dbg_info {
    int version;
} sx_api_dbg_info_t;


#endif /* __SX_CORE_DBG_H__ */
