/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_MSTP_H__
#define __SX_MSTP_H__

#include "sx/sdk/auto_headers/sx_mstp_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define  __USE_MSTP_INST_ID_0__

#ifdef      __USE_MSTP_INST_ID_0__
#define SX_MSTP_INST_ID_CHECK_RANGE(id) (SX_CHECK_MAX(id, SX_MSTP_INST_ID_MAX))
#else   /*      __USE_MSTP_INST_ID_0__  */
#define SX_MSTP_INST_ID_CHECK_RANGE(id) (SX_CHECK_RANGE(SX_MSTP_INST_ID_MIN, id, SX_MSTP_INST_ID_MAX))
#endif  /*      __USE_MSTP_INST_ID_0__  */

#ifdef __USE_MSTP_INST_ID_0__
#define SX_MSTP_INST_ID_MIN (0)
#else   /*      __USE_MSTP_INST_ID_0__  */
#define SX_MSTP_INST_ID_MIN (1)
#endif  /*      __USE_MSTP_INST_ID_0__  */

#define SX_MSTP_INST_ID_MAX     (1024)
#define SX_MSTP_INST_ID_INVALID (0xffff)

#define SX_MSTP_INST_PORT_STATE_MIN_MAX SX_MSTP_INST_PORT_STATE_MIN, SX_MSTP_INST_PORT_STATE_MAX
#define SX_MSTP_MODE_MIN_MAX            SX_MSTP_MODE_MIN, SX_MSTP_MODE_MAX

#define SX_MSTP_INST_PORT_STATE_CHECK_RANGE(state)      \
    (SX_CHECK_RANGE(SX_MSTP_INST_PORT_STATE_MIN, state, \
                    SX_MSTP_INST_PORT_STATE_MAX))

#define SX_MSTP_MODE_CHECK_RANGE(mode) (SX_CHECK_RANGE(SX_MSTP_MODE_MIN, mode, SX_MSTP_MODE_MAX))


#endif /* __SX_MSTP_H__ */
