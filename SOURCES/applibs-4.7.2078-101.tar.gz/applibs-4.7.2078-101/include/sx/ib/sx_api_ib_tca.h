/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef SX_API_IB_TCA_H_
#define SX_API_IB_TCA_H_


#include <sx/sdk/sx_api.h>
#include <sx/ib/sx_ib_tca.h>
#include <sx/sdk/sx_strings.h>

/**
 *  This function sets the router TCA logical and physical port states.
 *  Supported devices: SwitchX, SwitchX2, SwitchIB.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] swid - Switch partition ID.
 * @param[in] sx_ib_tca_port_state_params - TCA port state information: tca logical port state, tca physical port state.
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 */

sx_status_t sx_api_ib_tca_port_state_set(const sx_api_handle_t                handle,
                                         const sx_swid_t                      swid,
                                         const sx_ib_tca_port_state_params_t *sx_ib_tca_port_state_params);

/**
 *  This function gets the tca logical and physical port states.
 *  Supported devices: SwitchX, SwitchX2, SwitchIB.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] swid - Switch partition ID.
 * @param[out] sx_ib_tca_port_state_params - TCA port state information: tca logical port state, tca physical port state.
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 */

sx_status_t sx_api_ib_tca_port_state_get(const sx_api_handle_t          handle,
                                         const sx_swid_t                swid,
                                         sx_ib_tca_port_state_params_t *sx_ib_tca_port_state_params);


#endif /* SX_API_IB_TCA_H_ */
