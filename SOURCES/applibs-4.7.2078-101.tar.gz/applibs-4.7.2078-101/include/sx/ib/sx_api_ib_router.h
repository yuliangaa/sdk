/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef SX_API_IB_ROUTER_H_
#define SX_API_IB_ROUTER_H_


#include <sx/sdk/sx_api.h>
#include <sx/ib/sx_ib_router.h>
#include <sx/sdk/sx_strings.h>

/**
 * This function Initiates the router module in SDK.
 * Including support for IPoIB routing.
 * router_resource_p->min_ipv4_uc_route_entries requires a value larger than 30.
 * router_resource_p->min_ipv4_mc_route_entries requires a value larger than
 * 30. (If MC router is enabled).
 *
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] general_params_p - general router parameters.
 * @param[in] router_resource_p- router resource parameter.
 *
 * @return SX_STATUS_SUCCESS - if operation completes
 *         successfully.
 * @return SX_STATUS_ALREADY_INITIALIZED - When router is
 *         already initialized.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE - When calling with bad
 *         parameters.
 */

sx_status_t sx_api_vpi_router_init_set(const sx_api_handle_t                  handle,
                                       const sx_vpi_router_general_param_t   *general_params_p,
                                       const sx_vpi_router_resources_param_t *router_resource_p);


/**  This function adds/modifies/deletes an IPoIB router interface.
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd - ADD/EDIT/DELETE/DELETE_ALL.
 * @param[in] vrid - Virtual Router ID.
 * @param[in] l2_ibifc - L2 IPoIB Information.
 * @param[in,out] rif - Router Interface ID.
 */

sx_status_t sx_api_ib_router_interface_set(const sx_api_handle_t              handle,
                                           const sx_access_cmd_t              cmd,
                                           const sx_router_id_t               vrid,
                                           const sx_ib_l2_router_interface_t *l2_ibifc,
                                           sx_router_interface_t             *rif);

/**
 *  This function gets an IPoIB router interface information.
 *  For each outputs parameters if it equal NULL than it will be ignored
 *
 *  Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] rif - Router Interface ID.
 * @param[out] vrid - Virtual Router ID.
 * @param[out] l2_ibifc - L2 IPoIB Information.
 */

sx_status_t sx_api_ib_router_interface_get(const sx_api_handle_t        handle,
                                           const sx_router_interface_t  rif,
                                           sx_router_id_t              *vrid,
                                           sx_ib_l2_router_interface_t *l2_ibifc);


/**
 *  This function adds/modifies/deletes/delete_all a neighbor
 *  information. The neighbor information associates an IP
 *  address to a LID QPN address. When calling
 *  with DELETE command, rif parameter is ignored.
 *  When cmd = DELETE_ALL, all neighbors which match the
 *  ip_addr.version and the rif, will be deleted. In case rif is
 *  SX_ROUTER_INTERFACE_DONTCARE, all neighbors corresponding
 *  with the ip_addr.version will be deleted.
 *  If ip_addr.version = SX_IP_VERSION_NONE then only IPv4
 *  neighbors will be deleted.
 *
 *  Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd - ADD/EDIT/DELETE/DELETE_ALL.
 * @param[in] vrid - Virtual Router ID.
 * @param[in] ip_addr - IP address.
 * @param[in] adj_param - Neigh params.
 * @param[in] action - DROP/TRAP/FORWARD
 * @param[in] rif - Router Interface ID.
 */

sx_status_t sx_api_ib_router_neigh_set(const sx_api_handle_t       handle,
                                       const sx_access_cmd_t       cmd,
                                       const sx_router_id_t        vrid,
                                       const sx_ip_addr_t         *ip_addr,
                                       const sx_ib_adjacency_t    *adj_param,
                                       const sx_router_action_t    action,
                                       const sx_router_interface_t rif);


/**
 *  This function gets/tests a neighbor information. At GET
 *  operation, LID/QPN and Router Interface ID will be
 *  returned in case the neighbor exists. At TEST operation,
 *  LID/QPN, Router Interface ID and activity indicator will
 *  be returned.
 *  adj_param, rif and activity: if they will be equal NULL, then they will be ignored.
 *
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd - GET/TEST.
 * @param[in] vrid - Virtual Router ID.
 * @param[in] ip_addr - IP address.
 * @param[out] adj_param - Neigh params.
 * @param[out] rif - Router Interface ID
 * @param[out] activity - Neighbor aged. in case of GET the activity will be equal 0
 */

sx_status_t sx_api_ib_router_neigh_get(const sx_api_handle_t  handle,
                                       const sx_access_cmd_t  cmd,
                                       const sx_router_id_t   vrid,
                                       const sx_ip_addr_t    *ip_addr,
                                       sx_ib_adjacency_t     *adj_param,
                                       sx_router_interface_t *rif,
                                       boolean_t             *activity);


/**  This function sets/edits the router attributes according to the swid value.
 *        In SET case, all the attributes are updated. In case of EDIT, the valid bits are checked and only
 *    these fields are updated.
 *
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd  - Command [SET / EDIT]
 * @param[in] swid   - Switch partition ID.
 * @param[in] sx_ib_router_attr - TCA information: lid, lid_valid, lmc, lmc_valid and gid.
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 */

sx_status_t sx_api_ib_router_attributes_set(const sx_api_handle_t      handle,
                                            const sx_swid_t            swid,
                                            const sx_access_cmd_t      cmd,
                                            const sx_ib_router_attr_t *sx_ib_router_attr);

/**
 *  This function gets the router attributes according to the swid value.
 *  The valid bits are set to '1'.
 *
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in]  handle - SX-API handle.
 * @param[in]  swid   - Switch partition ID.
 * @param[in] sx_ib_router_attr - Router attributes : lid, lmc and gid.
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 */

sx_status_t sx_api_ib_router_attributes_get(const sx_api_handle_t handle,
                                            const sx_swid_t       swid,
                                            sx_ib_router_attr_t  *sx_ib_router_attr);


/**
 *  This function adds/deletes an egress IB MC neighbor to
 *  multicast route:
 *  Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] cmd - ADD /DELETE/DELETE_ALL
 * @param[in] vrid - Virtual Router ID.
 * @param[in] source_addr - source:  ip address + mask + version
 * @param[in] mc_group_addr  - destination: ip address + mask + version
 * @param[in] ingress_rif - Ingress Router Interface. Ingress rif should be 0 when
 *                           rpf is disabled.
 * @param[in] adj_num - mc_ipoib_adj num
 * @param[in] mc_ipoib_adj - Multicast IPoIB Adjacency entry
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is
 *         invalid.
 * @return SX_STATUS_NO_RESOURCES if no routes is available to create.
 * @return SX_STATUS_ERROR general error.
 */

sx_status_t sx_api_ib_router_mc_egress_neigh_set(const sx_api_handle_t       handle,
                                                 const sx_access_cmd_t       cmd,
                                                 const sx_router_id_t        vrid,
                                                 const sx_ip_prefix_t       *source_addr,
                                                 const sx_ip_prefix_t       *mc_group_addr,
                                                 const sx_router_interface_t ingress_rif,
                                                 const uint32_t              adj_num,
                                                 const sx_mc_ipoib_adj_t    *mc_ipoib_adj_arr);

/**
 *  This function gets egress IB neighbors from multicast route.
 *  When adj_num is 0 , will return a counter of the number of
 *  adjacency entries, and mc_ipoib_adj_arr will remain empty.
 *  When mc_ipoib_adj_arr = NULL, will return counter in adj_num.
 *
 * Supported devices: SwitchX, SwitchX2.
 *
 * @param[in] vrid - Virtual Router ID.
 * @param[in] source_addr - source:  ip address + mask + version
 * @param[in] mc_group_addr  - destination: ip address + mask + version
 * @param[in] ingress_rif - Ingress Router Interface. Ingress rif should be 0 when
 *                           rpf is disabled.
 * @param[in,out] adj_num - mc_ipoib_adj num
 * @param[out] mc_ipoib_adj - Multicast IPoIB Adjacency entry
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is
 *         invalid.
 * @return SX_STATUS_NO_RESOURCES if no routes is available to create.
 * @return SX_STATUS_ERROR general error.
 */

sx_status_t sx_api_ib_router_mc_egress_neigh_get(const sx_api_handle_t       handle,
                                                 const sx_router_id_t        vrid,
                                                 const sx_ip_prefix_t       *source_addr,
                                                 const sx_ip_prefix_t       *mc_group_addr,
                                                 const sx_router_interface_t ingress_rif,
                                                 uint32_t                   *adj_num,
                                                 sx_mc_ipoib_adj_t          *mc_ipoib_adj_arr);

#endif /* SX_API_IB_ROUTER_H_ */
