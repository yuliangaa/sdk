/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#define _GNU_SOURCE

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <complib/cl_byteswap_osd.h>
#include <utils/utils.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sx/sxd/sx_bfd_ctrl_cmds.h>
#include "bfd.h"
#include "bfd_db.h"
#include <sched.h>
#include <sys/syscall.h>
#undef __MODULE__
#define __MODULE__ BFD

/************************************************
 *  Global variables
 ***********************************************/
static boolean_t g_bfd_initialized = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static int fd = -1;
static int bfd_switch_ns(const char* path);


/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static inline void __sx_ipv6_sdk_to_network_order(struct in6_addr *addr)
{
    int i = 0;

    for (i = 0; i < 4; i++) {
        addr->s6_addr32[i] = cl_hton32(addr->s6_addr32[i]);
    }
}

sx_status_t bfd_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}

sx_status_t bfd_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return rc;
}

sx_status_t bfd_init(sx_bfd_init_params_t *init_params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(init_params);

    SX_LOG_ENTER();

    if (TRUE == g_bfd_initialized) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* open device */
    fd = open("/dev/sxdevs/bfdcdev", O_RDWR);
    if (fd == -1) {
        SX_LOG_ERR("Failed to open device, errno = [%s]\n",
                   strerror(errno));
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    rc = bfd_db_init(rm_resource_global_default.bfd_session_num_max);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    g_bfd_initialized = TRUE;

out:
    if (rc != SX_STATUS_SUCCESS) {
        if (fd != -1) {
            close(fd);
        }
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t bfd_offload_sessions_stop()
{
    sx_bfd_session_id_t        sx_bfd_session_id = 0;
    uint32_t                   session_id_cnt = 1;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_bfd_session_db_attrib_t session_attr;
    struct bfd_offload_info    bfd_offload;
    enum sx_bfd_cmd            cmd;

    rc = bfd_session_iter_get(SX_ACCESS_CMD_GET_FIRST,
                              0,
                              NULL,
                              &sx_bfd_session_id,
                              &session_id_cnt);
    while (session_id_cnt) {
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("bfd_session_iter_get for session = %d FAILED\n", sx_bfd_session_id);
            goto out;
        }
        memset(&session_attr, 0, sizeof(session_attr));
        rc = bfd_db_session_attrib_get(sx_bfd_session_id,
                                       &session_attr);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("bfd_session_iter_get for session = %d FAILED\n", sx_bfd_session_id);
            goto out;
        }
        if (session_attr.session_data.type == SX_BFD_ASYNC_ACTIVE_TX) {
            cmd = SX_BFD_CMD_STOP_TX_OFFLOAD;
        } else {
            cmd = SX_BFD_CMD_STOP_RX_OFFLOAD;
        }
        memset(&bfd_offload, 0, sizeof(bfd_offload));
        bfd_offload.session_id = sx_bfd_session_id;

        if (ioctl(fd, cmd, (unsigned long)&bfd_offload) < 0) {
            SX_LOG_ERR("ioctl error %s\n", strerror(errno));
            rc = SX_STATUS_ERROR;
            continue;
        }

        rc = bfd_session_iter_get(SX_ACCESS_CMD_GETNEXT,
                                  sx_bfd_session_id,
                                  NULL,
                                  &sx_bfd_session_id,
                                  &session_id_cnt);
    }
out:
    return rc;
}

sx_status_t bfd_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_NTC("BFD : Start Deinit\n");

    if (FALSE == g_bfd_initialized) {
        SX_LOG_NTC("BFD Module is already de-initialized\n");
        goto out;
    }

    rc = bfd_offload_sessions_stop();
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    close(fd);

    rc = bfd_db_deinit();
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_LOG_NTC("BFD : Terminated\n");
    g_bfd_initialized = FALSE;

out:
    return rc;
}

static sx_status_t __bfd_offload_set_rx(struct bfd_offload_info *bfd_offload, sx_api_bfd_offload_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    char        address[INET6_ADDRSTRLEN];

    if (params->session_data.data.rx_data.interval == 0) {
        SX_LOG_ERR("BFD interval 0 is not allowed\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    bfd_offload->interval = params->session_data.data.rx_data.interval;
    bfd_offload->session_opaque_data = params->session_data.data.rx_data.opaque_data;
    if (params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4) {
        bfd_offload->peer_addr.peer_in.sin_addr.s_addr = cl_hton32(
            params->peer.peer_data.ip_and_vrf.ip_addr.addr.ipv4.s_addr);
        bfd_offload->peer_addr.peer_in.sin_family = AF_INET;
    } else if (params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV6) {
        memcpy(&bfd_offload->peer_addr.peer_in6.sin6_addr,
               &params->peer.peer_data.ip_and_vrf.ip_addr.addr.ipv6,
               sizeof(struct in6_addr));
        __sx_ipv6_sdk_to_network_order(&bfd_offload->peer_addr.peer_in6.sin6_addr);
        bfd_offload->peer_addr.peer_in6.sin6_family = AF_INET6;
    } else {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    bfd_offload->vrf_id =
        (params->peer.peer_data.ip_and_vrf.vrf_id < 0) ? 0 : params->peer.peer_data.ip_and_vrf.vrf_id;
    bfd_offload->use_vrf_device = params->peer.peer_data.ip_and_vrf.use_vrf_device;
    memcpy(bfd_offload->linux_vrf_name, params->peer.peer_data.ip_and_vrf.vrf_linux_name,
           sizeof(params->peer.peer_data.ip_and_vrf.vrf_linux_name));
    bfd_offload->bfd_pid = params->bfd_pid;
    bfd_offload->size = params->packet_size;
    memcpy(bfd_offload->bfd_packet, params->bfd_packet, params->packet_size);

    if (params->cmd == SX_ACCESS_CMD_EDIT) {
        SX_LOG_DBG("Set Params for RX Session, VRF id (%u), %s %s \n", bfd_offload->vrf_id,
                   params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ? "ipv4" : "ipv6",
                   params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ?
                   inet_ntop(bfd_offload->peer_addr.peer_in.sin_family,
                             &bfd_offload->peer_addr.peer_in.sin_addr,
                             address,
                             sizeof(address)) :
                   inet_ntop(bfd_offload->peer_addr.peer_in6.sin6_family,
                             &bfd_offload->peer_addr.peer_in6.sin6_addr,
                             address,
                             sizeof(address)));
    } else {
        SX_LOG_NTC("Set Params for RX Session, VRF id (%u), %s %s \n", bfd_offload->vrf_id,
                   params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ? "ipv4" : "ipv6",
                   params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ?
                   inet_ntop(bfd_offload->peer_addr.peer_in.sin_family,
                             &bfd_offload->peer_addr.peer_in.sin_addr,
                             address,
                             sizeof(address)) :
                   inet_ntop(bfd_offload->peer_addr.peer_in6.sin6_family,
                             &bfd_offload->peer_addr.peer_in6.sin6_addr,
                             address,
                             sizeof(address)));
    }


out:
    return rc;
}

static sx_status_t __bfd_offload_set_tx(struct bfd_offload_info *bfd_offload, sx_api_bfd_offload_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    char        local_address[INET6_ADDRSTRLEN];
    char        peer_address[INET6_ADDRSTRLEN];

    if (params->session_data.data.tx_data.interval == 0) {
        SX_LOG_ERR("BFD interval 0 is not allowed\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    bfd_offload->interval = params->session_data.data.tx_data.interval;
    bfd_offload->ttl = params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.ttl;
    bfd_offload->dscp = params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dscp;
    if (params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.version ==
        SX_IP_VERSION_IPV4) {
        bfd_offload->local_addr.local_in.sin_addr.s_addr = cl_hton32(
            params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.addr.ipv4.s_addr);
        bfd_offload->local_addr.local_in.sin_family = AF_INET;
        bfd_offload->local_addr.local_in.sin_port = cl_hton16(
            params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_udp_port);
    } else if (params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.version ==
               SX_IP_VERSION_IPV6) {
        memcpy(&bfd_offload->local_addr.local_in6.sin6_addr,
               &params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.addr.ipv6,
               sizeof(struct in6_addr));
        __sx_ipv6_sdk_to_network_order(&bfd_offload->local_addr.local_in6.sin6_addr);
        bfd_offload->local_addr.local_in6.sin6_family = AF_INET6;
        bfd_offload->local_addr.local_in6.sin6_port = cl_hton16(
            params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_udp_port);
    } else if (params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.version != 0) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4) {
        bfd_offload->peer_addr.peer_in.sin_addr.s_addr = cl_hton32(
            params->peer.peer_data.ip_and_vrf.ip_addr.addr.ipv4.s_addr);
        bfd_offload->peer_addr.peer_in.sin_family = AF_INET;
        bfd_offload->peer_addr.peer_in.sin_port = cl_hton16(
            params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dest_udp_port);
    } else if (params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV6) {
        memcpy(&bfd_offload->peer_addr.peer_in6.sin6_addr,
               &params->peer.peer_data.ip_and_vrf.ip_addr.addr.ipv6,
               sizeof(struct in6_addr));
        __sx_ipv6_sdk_to_network_order(&bfd_offload->peer_addr.peer_in6.sin6_addr);
        bfd_offload->peer_addr.peer_in6.sin6_family = AF_INET6;
        bfd_offload->peer_addr.peer_in6.sin6_port = cl_hton16(
            params->session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dest_udp_port);
    } else {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    bfd_offload->vrf_id =
        (params->peer.peer_data.ip_and_vrf.vrf_id < 0) ? 0 : params->peer.peer_data.ip_and_vrf.vrf_id;
    bfd_offload->bfd_pid = params->bfd_pid;

    bfd_offload->use_vrf_device = params->peer.peer_data.ip_and_vrf.use_vrf_device;
    memcpy(bfd_offload->linux_vrf_name, params->peer.peer_data.ip_and_vrf.vrf_linux_name,
           sizeof(params->peer.peer_data.ip_and_vrf.vrf_linux_name));

    bfd_offload->size = params->packet_size;
    memcpy(bfd_offload->bfd_packet, params->bfd_packet, params->packet_size);

    SX_LOG_NTC("Set Params for TX Session, VRF id (%u), peer: %s %s, local: %s %s \n", bfd_offload->vrf_id,
               params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ? "ipv4" : "ipv6",
               params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ?
               inet_ntop(bfd_offload->peer_addr.peer_in.sin_family,
                         &bfd_offload->peer_addr.peer_in.sin_addr,
                         peer_address,
                         sizeof(peer_address)) :
               inet_ntop(bfd_offload->peer_addr.peer_in6.sin6_family,
                         &bfd_offload->peer_addr.peer_in6.sin6_addr,
                         peer_address,
                         sizeof(peer_address)),
               params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ? "ipv4" : "ipv6",
               params->peer.peer_data.ip_and_vrf.ip_addr.version == SX_IP_VERSION_IPV4 ?
               inet_ntop(bfd_offload->local_addr.local_in.sin_family,
                         &bfd_offload->local_addr.local_in.sin_addr,
                         local_address,
                         sizeof(local_address)) :
               inet_ntop(bfd_offload->local_addr.local_in6.sin6_family,
                         &bfd_offload->local_addr.local_in6.sin6_addr,
                         local_address,
                         sizeof(local_address)));

out:
    return rc;
}

sx_status_t bfd_offload_counter_get(sx_bfd_offload_stats_t *params)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    enum sx_bfd_cmd               cmd;
    struct bfd_offload_get_stats *bfd_offload_get_stats = NULL;

    if ((params->cmd != SX_ACCESS_CMD_READ_CLEAR) && (params->cmd != SX_ACCESS_CMD_READ)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    bfd_offload_get_stats = (struct bfd_offload_get_stats *)calloc(1, sizeof(struct bfd_offload_get_stats));
    if (!bfd_offload_get_stats) {
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    if (params->session_type == SX_BFD_ASYNC_ACTIVE_RX) {
        if (params->cmd == SX_ACCESS_CMD_READ) {
            cmd = SX_BFD_CMD_GET_RX_STATS;
        } else {
            cmd = SX_BFD_CMD_GET_AND_CLEAR_RX_STATS;
        }
    } else if (params->session_type == SX_BFD_ASYNC_ACTIVE_TX) {
        if (params->cmd == SX_ACCESS_CMD_READ) {
            cmd = SX_BFD_CMD_GET_TX_STATS;
        } else {
            cmd = SX_BFD_CMD_GET_AND_CLEAR_TX_STATS;
        }
    } else {
        SX_LOG_ERR("Unsupported session type\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    bfd_offload_get_stats->session_id = params->session_id;
    bfd_offload_get_stats->session_type = params->session_type;

    if (ioctl(fd, cmd, (unsigned long)bfd_offload_get_stats) < 0) {
        SX_LOG_ERR("ioctl error %s\n", strerror(errno));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* save all counters in the bfd session stats struct */
    params->bfd_session_stats.num_control = bfd_offload_get_stats->session_stats.num_control;
    params->bfd_session_stats.num_dropped_control = bfd_offload_get_stats->session_stats.num_dropped_control;
    params->bfd_session_stats.last_time = bfd_offload_get_stats->session_stats.last_time;
    params->bfd_session_stats.interval_min = bfd_offload_get_stats->session_stats.interval_min;
    params->bfd_session_stats.interval_max = bfd_offload_get_stats->session_stats.interval_max;
    params->bfd_session_stats.interval_average = bfd_offload_get_stats->session_stats.interval_average;
    params->bfd_session_stats.remote_heard = bfd_offload_get_stats->session_stats.remote_heard;

out:
    if (bfd_offload_get_stats) {
        free(bfd_offload_get_stats);
    }
    return rc;
}

static int bfd_switch_ns(const char* path)
{
    int fd;
    int rc = -1;

    fd = open(path, O_RDONLY);
    if (fd >= 0) {
        SX_LOG_DBG("Switch to namespace %s PASSED\n", path);
        rc = syscall(__NR_setns, fd, CLONE_NEWNET);
        if (rc) {
            SX_LOG_ERR("Failed to set network namespace [path='%s', fd=%d, err=%d]\n", path, fd, errno);
        }
        if (close(fd)) {
            SX_LOG_ERR("Failed to close network namespace file-descriptor [path='%s', fd=%d, err=%d]\n",
                       path, fd, errno);
        }
    } else {
        SX_LOG_ERR("Failed to open network namespace [path='%s', err=%d]\n", path, errno);
    }

    return rc;
}
sx_status_t bfd_offload_set(sx_api_bfd_offload_set_params_t *params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    enum sx_bfd_cmd            cmd;
    struct bfd_offload_info   *bfd_offload = NULL;
    sx_bfd_session_db_attrib_t attrib;
    char                      *netns = NULL;
    char                      *default_netns = NULL;
    boolean_t                  session_id_created = FALSE;

    if (g_bfd_initialized == FALSE) {
        SX_LOG_ERR("the module BFD not initialized\n");
        goto out;
    }

    bfd_offload = (struct bfd_offload_info *)calloc(1, sizeof(struct bfd_offload_info) + params->packet_size);
    if (!bfd_offload) {
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (params->session_data.type == SX_BFD_ASYNC_ACTIVE_TX) {
            cmd = SX_BFD_CMD_START_TX_OFFLOAD;
            SX_LOG_NTC("Create TX Session\n");
            rc = __bfd_offload_set_tx(bfd_offload, params);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set TX BFD session\n");
                goto out;
            }
        } else {
            cmd = SX_BFD_CMD_START_RX_OFFLOAD;
            SX_LOG_NTC("Create RX Session\n");
            rc = __bfd_offload_set_rx(bfd_offload, params);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set RX BFD session\n");
                goto out;
            }
        }

        memcpy(&attrib.peer, &params->peer, sizeof(sx_bfd_peer_t));
        memcpy(&attrib.session_data, &params->session_data, sizeof(sx_bfd_session_t));
        rc = bfd_db_session_create(&attrib, &params->session_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }

        session_id_created = TRUE;
        SX_LOG_NTC("Session ID for Session is %u\n", params->session_id);
        if ((params->peer.peer_data.ip_and_vrf.vrf_id > 0) && (params->peer.peer_type == SX_BFD_PEER_IP_AND_VRF)) {
            netns = params->peer.peer_data.ip_and_vrf.netns;
            default_netns = params->peer.peer_data.ip_and_vrf.default_netns;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        if (params->session_data.type == SX_BFD_ASYNC_ACTIVE_TX) {
            cmd = SX_BFD_CMD_UPDATE_TX_OFFLOAD;

            SX_LOG_DBG("Update TX Session\n");

            rc = __bfd_offload_set_tx(bfd_offload, params);
            if (rc != SX_STATUS_SUCCESS) {
                goto out;
            }
        } else {
            cmd = SX_BFD_CMD_UPDATE_RX_OFFLOAD;

            SX_LOG_DBG("Update RX Session\n");

            rc = __bfd_offload_set_rx(bfd_offload, params);
            if (rc != SX_STATUS_SUCCESS) {
                goto out;
            }
        }

        memcpy(&attrib.peer, &params->peer, sizeof(sx_bfd_peer_t));
        memcpy(&attrib.session_data, &params->session_data, sizeof(sx_bfd_session_t));
        rc = bfd_db_session_attrib_set(params->session_id, &attrib);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
        SX_LOG_DBG("Session ID for RX Session is %u\n", params->session_id);
        if ((params->peer.peer_data.ip_and_vrf.vrf_id > 0) && (params->peer.peer_type == SX_BFD_PEER_IP_AND_VRF)) {
            netns = params->peer.peer_data.ip_and_vrf.netns;
            default_netns = params->peer.peer_data.ip_and_vrf.default_netns;
        }

        break;

    case SX_ACCESS_CMD_DESTROY:
        if (g_bfd_initialized == FALSE) {
            SX_LOG_NTC("the module BFD is not initialized\n");
            goto out;
        }
        if (params->session_data.type == SX_BFD_ASYNC_ACTIVE_TX) {
            cmd = SX_BFD_CMD_STOP_TX_OFFLOAD;
            SX_LOG_NTC("Delete TX session %u\n", params->session_id);
        } else {
            cmd = SX_BFD_CMD_STOP_RX_OFFLOAD;
            SX_LOG_NTC("Delete RX Session %u\n", params->session_id);
        }

        rc = bfd_db_session_destroy(params->session_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }

        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    bfd_offload->session_id = params->session_id;
    if ((params->cmd != SX_ACCESS_CMD_DESTROY) && netns && strnlen(netns, BFD_NETNS_NAME_LENGTH)) {
        if (bfd_switch_ns(netns) < 0) {
            SX_LOG_ERR("Switch to namespace %s FAILED\n", netns);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
    if (ioctl(fd, cmd, (unsigned long)bfd_offload) < 0) {
        SX_LOG_ERR("ioctl failed, error description: %s\n", strerror(errno));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    if ((rc != SX_STATUS_SUCCESS) && session_id_created) {
        bfd_db_session_destroy(params->session_id);
    }

    if (default_netns) {
        bfd_switch_ns(default_netns);
    }
    if (bfd_offload) {
        free(bfd_offload);
    }
    return rc;
}

sx_status_t bfd_session_iter_get(const sx_access_cmd_t             access_cmd,
                                 const sx_bfd_session_id_t         session_id_key,
                                 const sx_bfd_session_id_filter_t *session_filter_p,
                                 sx_bfd_session_id_t              *session_id_list_p,
                                 uint32_t                         *session_id_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = bfd_db_iter_get(access_cmd,
                         session_id_key,
                         session_filter_p,
                         session_id_list_p,
                         session_id_cnt_p);

    return M_UTILS_SX_LOG_EXIT(rc);
}

void bfd_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    FILE *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;
    dbg_utils_pprinter_module_header_print(stream, "BFD");

    dbg_utils_pprinter_field_print(stream, "Module initialized", &g_bfd_initialized, PARAM_BOOL_E);

    if (FALSE == g_bfd_initialized) {
        /* error stays success */
        goto out;
    }

    bfd_db_dbg_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}
