/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ACL_H_INCL__
#define __ACL_H_INCL__

#include <sx_api/sx_api_internal.h>

#ifdef ACL_C_

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    sx_status_t (*acl_enable_system)(boolean_t enable);
    sx_status_t (*acl_vlan_group_set)(sx_api_acl_vlan_group_set_params_t *params);
    sx_status_t (*acl_vlan_group_get)(sx_acl_vlan_group_t group_id,
                                      sx_swid_id_t        swid,
                                      sx_vlan_id_t       *vlan_list,
                                      uint32_t           *vlan_num);
    sx_status_t (*acl_region_set)(sx_api_acl_region_set_params_t *params);
    sx_status_t (*acl_region_get)(sx_api_acl_region_set_params_t *params);
    sx_status_t (*acl_set)(sx_api_acl_set_params_t *params);
    sx_status_t (*acl_get)(sx_api_acl_set_params_t *params);
    sx_status_t (*acl_iter_get)(sx_api_acl_iter_get_params_t *params);
    sx_status_t (*acl_group_set)(sx_api_acl_group_params_t *params);
    sx_status_t (*acl_group_get)(sx_api_acl_group_params_t *params);
    sx_status_t (*acl_group_iter_get)(sx_api_acl_group_iter_get_params_t *params);
    sx_status_t (*acl_rule_activity_get)(sx_api_acl_rule_activity_get_params_t *params);
    sx_status_t (*acl_rule_activity_dump)(sx_api_acl_rule_activity_dump_params_t *params);
    sx_status_t (*acl_rules_move)(sx_api_acl_block_move_params_t *params);
    sx_status_t (*acl_bind_port)(sx_api_acl_bind_params_t *params);
    sx_status_t (*acl_bind_port_get)(sx_api_acl_bind_get_params_t *params);
    sx_status_t (*acl_unbind_port)(sx_api_acl_bind_params_t *params);
    sx_status_t (*acl_bind_vlan_group)(sx_api_acl_bind_params_t *params, boolean_t rebinding);
    sx_status_t (*acl_bind_vlan_group_get)(sx_api_acl_bind_get_params_t *params);
    sx_status_t (*acl_unbind_vlan_group)(sx_api_acl_bind_params_t *params);
    sx_status_t (*acl_l4_port_range_set)(sx_api_acl_l4_range_params_t *params);
    sx_status_t (*acl_l4_port_range_get)(sx_api_acl_l4_range_params_t *params);
    sx_status_t (*acl_l4_port_range_iter_get)(sx_api_acl_l4_port_range_iter_get_params_t *params);
    sx_status_t (*acl_pbs_set)(sx_api_acl_pbs_set_params_t *params);
    sx_status_t (*acl_pbs_get)(sx_api_acl_pbs_get_params_t *params);
    sx_status_t (*acl_pbs_iter_get)(sx_api_acl_pbs_iter_get_params_t *params);
    sx_status_t (*acl_range_set)(sx_api_acl_range_params_t *params);
    sx_status_t (*acl_range_get)(sx_api_acl_range_params_t *params);
    sx_status_t (*acl_pbilm_set)(sx_api_acl_pbilm_set_params_t *params);
    sx_status_t (*acl_pbilm_get)(sx_api_acl_pbilm_get_params_t *params);
} acl_cb_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t acl_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

acl_cb_t * acl_get_cb(void);
void acl_set_cb(acl_cb_t* cb);

/**
 * Enable/Disable System Privileges.
 * Should be called from sx_core_api.c before each acl
 * call with the value of FALSE.
 *
 * and than after the call is done, return the execution
 * privileges into default level which is TRUE. (System enabled)
 *
 * This will ensure user calls will be called using user privileges
 * while inner calls to ACL module will be run under system.
 */
sx_status_t acl_enable_system(boolean_t enable);
sx_status_t acl_region_set(sx_api_acl_region_set_params_t *params);
sx_status_t acl_set(sx_api_acl_set_params_t *params);
sx_status_t acl_get(sx_api_acl_set_params_t *params);
sx_status_t acl_iter_get(sx_api_acl_iter_get_params_t *params);
sx_status_t acl_region_get(sx_api_acl_region_set_params_t *params);
sx_status_t acl_group_set(sx_api_acl_group_params_t *params);
sx_status_t acl_group_get(sx_api_acl_group_params_t *params);
sx_status_t acl_group_iter_get(sx_api_acl_group_iter_get_params_t *params);
sx_status_t acl_rule_activity_get(sx_api_acl_rule_activity_get_params_t *params);
sx_status_t acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params);
sx_status_t acl_rules_move(sx_api_acl_block_move_params_t *params);
sx_status_t acl_bind_port(sx_api_acl_bind_params_t *params);
sx_status_t acl_bind_port_get(sx_api_acl_bind_get_params_t *params);
sx_status_t acl_unbind_port(sx_api_acl_bind_params_t *params);
sx_status_t acl_bind_vlan_group(sx_api_acl_bind_params_t *params, boolean_t rebinding);
sx_status_t acl_bind_vlan_group_get(sx_api_acl_bind_get_params_t *params);
sx_status_t acl_unbind_vlan_group(sx_api_acl_bind_params_t *params);
sx_status_t acl_l4_port_range_set(sx_api_acl_l4_range_params_t *params);
sx_status_t acl_l4_port_range_iter_get(sx_api_acl_l4_port_range_iter_get_params_t *params);
sx_status_t acl_l4_port_range_get(sx_api_acl_l4_range_params_t *params);
sx_status_t acl_range_set(sx_api_acl_range_params_t *params);
sx_status_t acl_range_get(sx_api_acl_range_params_t *params);
sx_status_t acl_pbs_set(sx_api_acl_pbs_set_params_t *params);
sx_status_t acl_pbs_get(sx_api_acl_pbs_get_params_t *params);
sx_status_t acl_pbs_iter_get(sx_api_acl_pbs_iter_get_params_t *params);
sx_status_t acl_pbilm_set(sx_api_acl_pbilm_set_params_t *params);
sx_status_t acl_pbilm_get(sx_api_acl_pbilm_get_params_t *params);
sx_status_t acl_vlan_group_set(sx_api_acl_vlan_group_set_params_t *params);
sx_status_t acl_vlan_group_get(sx_acl_vlan_group_t group_id,
                               sx_swid_id_t        swid,
                               sx_vlan_id_t       *vlan_list,
                               uint32_t           *vlan_num);


sx_status_t acl_region_update_wildcard_rule_set(sx_acl_region_id_t   region_id,
                                                sx_acl_trap_action_t default_action,
                                                sx_acl_trap_info_t  *default_action_attr,
                                                sx_flow_counter_id_t default_flow_counter);


#endif /* ifndef __ACL_H_INCL__ */
