/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#define  FLEX_ACL_HW_C_
#include "acl.h"
#include "flex_acl_hw.h"
#include "flex_acl_hw_common.h"
#include "flex_acl_hw_db.h"
#include "flex_acl_hw_actions.h"
#include "flex_acl_tcam_manager.h"
#include "flex_acl_binding.h"
#undef   FLEX_ACL_HW_C_
#include "issu/issu.h"
#include "ethl3/router_common.h"
#include "ethl2/topo.h"
#include "ethl2/vlan.h"
#include "ethl2/port.h"
#include "ethl2/la_db.h"
#include <utils/utils.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include <kvd/kvd_linear_manager.h>
#include <sx/sxd/sxd_access_register.h>
#include <policer/policer_manager.h>
#include <counters/counter_manager/counter_manager.h>
#include <span/span.h>
#include "ethl2/port.h"
#include "ethl2/fdb.h"
#include "ethl2/fdb_mc_impl.h"
#include "ethl2/fid_manager.h"
#include "ethl3/hwi/ecmp/router_ecmp.h"
#include "ethl3/hwi/ecmp/router_ecmp_impl.h"
#include "ethl3/hwd/hwd_ecmp/hwd_router_ecmp.h"
#include "bridge_lib/bridge_common.h"
#include <mc_container/hwd/erif_list_manager.h>
#include <mc_container/hwd/hwd_mc_container.h>
#include <sx/sdk/sx_mc_container.h>
#include <tunnel/hwi/tunnel_impl.h>
#include "sx/sdk/sx_status_convertor.h"
#include "ethl3/hwd/hwd_mc_route/hwd_mc_rpf_group.h"
#include "mpls/hwd/hwd_ftn_impl.h"
#include "mpls/hwd/continue_lookup_nhlfe.h"
#include <complib/cl_byteswap.h>

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Local Defines
 ***********************************************/

#define FLEX_ACL_PORT_FILTER_HANDLE(mc_container_id, sxd_action) \
    (((uint64_t)mc_container_id << 16) | (uint64_t)sxd_action)
#define FLEX_ACL_PORT_FILTER_HANDLE_TO_CONTAINER_ID(handle) \
    (handle >> 16)
#define FLEX_ACL_PORT_FILTER_HANDLE_TO_SXD_ACTION(handle) \
    (handle & 0xFFFF)
#define ULONG_BIT_MASK(bit_num) ((1UL << (bit_num)) - 1)

#define FLEX_ACL_HW_INVALID_CBSET (0xFF)

#define ACTION_TYPE_IS_POLICING_COUNTING_OR_FLOW_ESTIMATOR(type) \
    (type == SXD_ACTION_TYPE_POLICING_COUNTING_E ||              \
     type == SXD_ACTION_TYPE_FLOW_ESTIMATOR_E)
#define IS_COUNTER_USED_IN_ACTION_SET(action_set)                                                                \
    (((action_set.action_type == SXD_ACTION_TYPE_POLICING_COUNTING_E) &&                                         \
      (action_set.slot.fields.action_policing_monitoring.c_p == SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E)) \
     || (action_set.action_type == SXD_ACTION_TYPE_FLOW_ESTIMATOR_E))


/* this is only used in this file. so keeping it here in the C file */
typedef enum acl_drop_db_mod_op {
    ACL_DROP_DB_ADD_E = 1,            /* Rule is created. So add to DB */
    ACL_DROP_DB_DEL_E,                /* Rule is deleted. So delete from DB */
    ACL_DROP_DB_GET_E,                /* Get the entry from the db if it exists */
    ACL_DROP_DB_TRAP_ENABLE_E,        /* Existing rule attribute State changes from Trap disabled -> Enabled */
    ACL_DROP_DB_TRAP_DISABLE_E,       /* Existing rule attribute State changes from Trap Enabled -. Disabled */
    ACL_DROP_DB_MIN_E  = ACL_DROP_DB_ADD_E,
    ACL_DROP_DB_LAST_E = ACL_DROP_DB_TRAP_DISABLE_E
} acl_drop_db_mod_op_e;
typedef struct {
    sx_acl_region_id_t   region_id;
    sx_acl_rule_offset_t offset;
    boolean_t            new_monitoring_state;
    uint32_t             new_trap_usr_def_val;
    uint32_t             new_trap_id;
    uint32_t             new_trap_action;
    uint32_t             old_trap_usr_def_val;
    uint32_t             old_trap_id;
    uint32_t             old_trap_action;
} acl_drop_relocate_data_t;

typedef struct {
    sx_acl_region_id_t   region_id;
    sx_acl_rule_offset_t cur_offset;
    sx_acl_rule_offset_t new_offset;
} acl_drop_trap_reloc_db_upd_t;

typedef struct {
    uint32_t                            sxd_actions_count;
    sxd_hash_flex_action_hash_fields_t *sxd_actions;
} crc_hash_action_field_mapping_t;

typedef struct {
    uint32_t                                     sxd_actions_count;
    sxd_custom_bytes_flex_action_field_select_t *sxd_actions;
} action_field_select_mapping_t;


/***********************************************
*  Local variables
***********************************************/
/* Is used by FLEX2 as the handle to the kvd memory allocated to all the regions' default actions. */
extern kvd_linear_manager_handle_t default_action_kvd_handle;
/* Pointer to the relevant register callbacks for FLEX1 or FLEX2. Will be set at initialization*/
extern flex_acl_hw_reg_cb_t *default_register_cbs_p;
/* Stores the flex stage we are working with. Will be set at initialization */
extern acl_stage_e flex_acl_stage;
/* Pointers to bind/unbind functions to be called when there is a goto action */
flex_acl_rebind_group_pfunc_t rebind_group_cb_g;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __acl_hw_action_trap_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                 flex_acl_rule_id_t rule_id,
                                                 hw_action_list_t *hw_action_list_p,
                                                 hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_trap_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                      flex_acl_db_flex_rule_t   *rule,
                                                      flex_acl_relocation_data_t relocation_data,
                                                      boolean_t                  add_ref);
static sx_status_t __acl_hw_action_mirror_sampler_populate(sx_flex_acl_flex_action_t action,
                                                           boolean_t                 is_defer,
                                                           flex_acl_rule_id_t        rule_id,
                                                           hw_action_list_t         *hw_action_list_p,
                                                           hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_mirror_sampler_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                flex_acl_db_flex_rule_t   *rule,
                                                                flex_acl_relocation_data_t relocation_data,
                                                                boolean_t                  add_ref);
static sx_status_t __acl_hw_action_mirror_sampler_release_lock(flex_acl_hw_action_t *hw_action);

static sx_status_t __acl_hw_action_uc_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                    flex_acl_db_flex_rule_t   *rule,
                                                    flex_acl_relocation_data_t relocation_data,
                                                    boolean_t                  add_ref);
static sx_status_t __acl_hw_action_uc_release_lock(flex_acl_hw_action_t *hw_action);
static sx_status_t __acl_hw_action_trap_release_lock(flex_acl_hw_action_t *hw_action);
static sx_status_t __acl_hw_action_vlan_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                 flex_acl_rule_id_t rule_id,
                                                 hw_action_list_t *hw_action_list_p,
                                                 hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_qos_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_mac_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_counter_policer_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                 flex_acl_db_flex_rule_t   *rule,
                                                                 flex_acl_relocation_data_t relocation_data,
                                                                 boolean_t                  ref_add);
static boolean_t __acl_hw_action_reuse_true(sx_flex_acl_flex_action_t *action,
                                            flex_acl_hw_action_t      *hw_action,
                                            int32_t                    relative_position);
static boolean_t __acl_hw_action_reuse_false(sx_flex_acl_flex_action_t *action,
                                             flex_acl_hw_action_t      *hw_action,
                                             int32_t                    relative_position);
static boolean_t __is_mac_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                          flex_acl_hw_action_t      *hw_action,
                                          int32_t                    relative_position);
static boolean_t __is_mpls_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position);
static boolean_t __is_vlan_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position);
static boolean_t __is_hash_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position);
static sx_status_t __acl_hw_action_virtual_forward_populate(sx_flex_acl_flex_action_t action,
                                                            boolean_t                 is_defer,
                                                            flex_acl_rule_id_t        rule_id,
                                                            hw_action_list_t         *hw_action_list_p,
                                                            hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_forward_populate(sx_flex_acl_flex_action_t action,
                                                    boolean_t                 is_defer,
                                                    flex_acl_rule_id_t        rule_id,
                                                    hw_action_list_t         *hw_action_list_p,
                                                    hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_forward_rollback(flex_acl_rule_id_t rule_id, flex_acl_hw_action_t *hw_action);
static sx_status_t __acl_hw_action_meta_data_populate(sx_flex_acl_flex_action_t action,
                                                      boolean_t                 is_defer,
                                                      flex_acl_rule_id_t        rule_id,
                                                      hw_action_list_t         *hw_action_list_p,
                                                      hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_ignore_populate(sx_flex_acl_flex_action_t action,
                                                   boolean_t                 is_defer,
                                                   flex_acl_rule_id_t        rule_id,
                                                   hw_action_list_t         *hw_action_list_p,
                                                   hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_mc_populate(sx_flex_acl_flex_action_t action,
                                               boolean_t                 is_defer,
                                               flex_acl_rule_id_t        rule_id,
                                               hw_action_list_t         *hw_action_list_p,
                                               hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_uc_populate(sx_flex_acl_flex_action_t action,
                                               boolean_t                 is_defer,
                                               flex_acl_rule_id_t        rule_id,
                                               hw_action_list_t         *hw_action_list_p,
                                               hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_mc_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                    flex_acl_db_flex_rule_t   *rule,
                                                    flex_acl_relocation_data_t relocation_data,
                                                    boolean_t                  ref_add);
static sx_status_t __acl_hw_action_forward_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                         flex_acl_db_flex_rule_t   *rule,
                                                         flex_acl_relocation_data_t relocation_data,
                                                         boolean_t                  ref_add);
static sx_status_t __acl_hw_action_forward_release_lock(flex_acl_hw_action_t *hw_action);
static hw_action_position_e __acl_hw_action_counter_policer_position(sx_flex_acl_flex_action_t *action_p,
                                                                     sxd_flex_acl_action_type_t hw_action_type);
static sx_status_t __acl_hw_action_counter_policer_populate(sx_flex_acl_flex_action_t action,
                                                            boolean_t                 is_defer,
                                                            flex_acl_rule_id_t        rule_id,
                                                            hw_action_list_t         *hw_action_list_p,
                                                            hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_counter_policer_release_lock(flex_acl_hw_action_t *hw_action);
static sx_status_t __flex_acl_free_third_parties_action(flex_acl_hw_action_t       *action,
                                                        kvd_linear_manager_index_t *kvd_index_p,
                                                        boolean_t                   is_head);
static sx_status_t __flex_ac_hw_pbs_is_drop(sx_acl_pbs_id_t pbs_id, boolean_t *is_dropped);
static sx_status_t __flex_acl_hw_config_pbs_write_reg(flex_acl_db_pbs_entry_t *pbs_entry, boolean_t is_vport,
                                                      kvd_linear_manager_index_t kvd_index);
static boolean_t __flex_acl_is_pbs_meta_data(sx_flex_acl_flex_action_t *action,
                                             flex_acl_action_modifier_e action_modifier,
                                             uint32_t                  *instance_count);
static boolean_t __flex_acl_is_port_filter_ext(sx_flex_acl_flex_action_t *action,
                                               flex_acl_action_modifier_e action_modifier,
                                               uint32_t                  *instance_count);
static boolean_t __flex_acl_is_port_filter_ext2(sx_flex_acl_flex_action_t *action,
                                                flex_acl_action_modifier_e action_modifier,
                                                uint32_t                  *instance_count);
static boolean_t __flex_acl_is_nat_sip_dip(sx_flex_acl_flex_action_t *action,
                                           flex_acl_action_modifier_e action_modifier,
                                           uint32_t                  *instance_count);
static boolean_t __flex_acl_hash_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                   flex_acl_action_modifier_e action_modifier,
                                                   uint32_t                  *instance_count);
static boolean_t __flex_acl_register_access_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                              flex_acl_action_modifier_e action_modifier,
                                                              uint32_t                  *instance_count);
static boolean_t __flex_acl_field_imm_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                        flex_acl_action_modifier_e action_modifier,
                                                        uint32_t                  *instance_count);
static sx_status_t __flex_acl_hw_egress_mirror_allocate_buffer(sx_port_log_id_t log_port);
static sx_status_t __flex_acl_hw_egress_mirror_free_buffer(sx_port_log_id_t log_port);
sx_status_t __acl_hw_action_port_filter_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                 flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                 hw_action_list_entry_t *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_port_filter_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                      flex_acl_db_flex_rule_t   *rule,
                                                      flex_acl_relocation_data_t relocation_data,
                                                      boolean_t                  add_ref);
static sx_status_t __acl_hw_action_mpls_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                 flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                 hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_sip_dip_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                    flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                    hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_l4_port_populate(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                                    flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                                    hw_action_list_entry_t *first_hw_action_list_entry_p);
static sx_status_t __flex_acl_hw_config_pbilm(flex_acl_db_pbilm_entry_t        *pbilm_entry,
                                              kvd_linear_manager_index_t        nhlfe_index,
                                              kvd_linear_manager_block_length_t nhlfe_size);
static sx_status_t __flex_acl_hw_config_pbilm_write_reg(kvd_linear_manager_index_t        kvd_index,
                                                        kvd_linear_manager_index_t        nhlfe_index,
                                                        kvd_linear_manager_block_length_t nhlfe_size,
                                                        uint8_t                           npop);
static sx_status_t __flex_acl_hw_get_pbilm(sx_acl_pbilm_id_t           pbilm_id,
                                           boolean_t                  *is_empty,
                                           kvd_linear_manager_index_t *adj_index);
static sx_status_t __flex_acl_hw_pbilm_nhfle_change_cb(flex_acl_db_pbilm_entry_t *pbilm_entry, void *param_p);
static boolean_t __acl_hw_action_counter_policer_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                                   flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_counter_policer_by_ref_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                                          flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_hash_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                        flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_alu_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                       flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_alu_field_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                             flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_custom_byte_move_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                             flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_fields_move_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                        flex_acl_hw_action_t *hw_action2_p);
static boolean_t __acl_hw_action_fields_set_imm_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                           flex_acl_hw_action_t *hw_action2_p);
static sx_status_t __acl_hw_action_hash_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_vxlan_populate(sx_flex_acl_flex_action_t action,
                                                  boolean_t                 is_defer,
                                                  flex_acl_rule_id_t        rule_id,
                                                  hw_action_list_t         *hw_action_list_p,
                                                  hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t sb_snapshot_trigger_type_to_sxd_snap_id(const sx_sb_snapshot_trigger_enable_type_e acl_enable_type,
                                                           sxd_snapshot_trigger_id_t                 *sxd_snap_id);
sx_status_t __acl_hw_action_custom_byte_alu_imm_populate(sx_flex_acl_flex_action_t action,
                                                         boolean_t                 is_defer,
                                                         flex_acl_rule_id_t        rule_id,
                                                         hw_action_list_t         *hw_action_list_p,
                                                         hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_custom_byte_alu_reg_populate(sx_flex_acl_flex_action_t action,
                                                         boolean_t                 is_defer,
                                                         flex_acl_rule_id_t        rule_id,
                                                         hw_action_list_t         *hw_action_list_p,
                                                         hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_custom_byte_alu_field_populate(sx_flex_acl_flex_action_t action,
                                                           boolean_t                 is_defer,
                                                           flex_acl_rule_id_t        rule_id,
                                                           hw_action_list_t         *hw_action_list_p,
                                                           hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_custom_byte_move_populate(sx_flex_acl_flex_action_t action,
                                                      boolean_t                 is_defer,
                                                      flex_acl_rule_id_t        rule_id,
                                                      hw_action_list_t         *hw_action_list_p,
                                                      hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_field_immediate_populate(sx_flex_acl_flex_action_t action,
                                                     boolean_t                 is_defer,
                                                     flex_acl_rule_id_t        rule_id,
                                                     hw_action_list_t         *hw_action_list_p,
                                                     hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_field_move_populate(sx_flex_acl_flex_action_t action,
                                                boolean_t                 is_defer,
                                                flex_acl_rule_id_t        rule_id,
                                                hw_action_list_t         *hw_action_list_p,
                                                hw_action_list_entry_t   *first_hw_action_list_entry_p);

sx_status_t __acl_hw_action_flex_modifier_emt_populate(sx_flex_acl_flex_action_t action,
                                                       boolean_t                 is_defer,
                                                       flex_acl_rule_id_t        rule_id,
                                                       hw_action_list_t         *hw_action_list_p,
                                                       hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_buffer_snap_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_stateful_db_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p);
sx_status_t __acl_hw_action_truncation_populate(sx_flex_acl_flex_action_t action,
                                                boolean_t                 is_defer,
                                                flex_acl_rule_id_t        rule_id,
                                                hw_action_list_t         *hw_action_list_p,
                                                hw_action_list_entry_t   *first_hw_action_list_entry_p);
static boolean_t __is_acl_drop_monitor_enabled(flex_acl_rule_id_t rule_id, flex_acl_entry_type_e  *entry_type);
static sx_status_t __acl_drop_trap_usr_def_val_modify(flex_acl_rule_id_t   rule_id,
                                                      acl_drop_db_mod_op_e db_op,
                                                      uint32_t            *ret_usr_def_val_p);
static sx_status_t __acl_drop_trap_action_relocate_handler(void                    *data,
                                                           flex_acl_hw_action_t    *action,
                                                           flex_acl_db_flex_rule_t *related_rule,
                                                           boolean_t               *found,
                                                           boolean_t               *handled);
static sx_status_t __add_acl_drop_trap_action(flex_acl_hw_action_t      *hw_action,
                                              flex_acl_db_flex_rule_t   *rule,
                                              flex_acl_relocation_data_t relocation_data,
                                              boolean_t                  add_ref);
static sx_status_t __empty_cont_del_acl_drop_trap_action_from_db(flex_acl_db_flex_rule_t *rule_p,
                                                                 sxd_action_slot_t       *action_slot_p);
static sx_status_t __acl_drop_relocate_db_update(cl_list_t                    *list,
                                                 flex_acl_db_flex_rule_t      *related_rule,
                                                 acl_drop_trap_reloc_db_upd_t *acl_drop_db_relocate_data);
static sx_status_t __find_acl_drop_trap_action_in_rule(flex_acl_db_flex_rule_t *rule_p,
                                                       boolean_t               *ret_found_p,
                                                       flex_acl_hw_action_t   **ret_hw_action_p);
static sx_status_t __del_acl_drop_action_trap_action_from_db(flex_acl_db_flex_rule_t *rule_p,
                                                             flex_acl_hw_action_t    *hw_action_p);
static sx_status_t __flex_acl_hw_config_extended_pbs_write(const flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                           struct ku_ppbs_reg            *ppbs_p);
static sx_status_t __port_filter_mc_container_fill_action_slot(sxd_action_slot_t         *action_slot_p,
                                                               flex_acl_action_modifier_e action_modifier,
                                                               sx_mc_container_id_t       mc_container_id);
sx_status_t __acl_hw_action_flow_estimator_populate(sx_flex_acl_flex_action_t action,
                                                    boolean_t                 is_defer,
                                                    flex_acl_rule_id_t        rule_id,
                                                    hw_action_list_t         *hw_action_list_p,
                                                    hw_action_list_entry_t   *first_hw_action_list_entry_p);
static sx_status_t __acl_hw_action_flow_estimator_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                flex_acl_db_flex_rule_t   *rule,
                                                                flex_acl_relocation_data_t relocation_data,
                                                                boolean_t                  add_ref);
static sx_status_t __acl_hw_action_flow_estimator_release_lock(flex_acl_hw_action_t *hw_action);

/************************************************
 *  Global variables
 ***********************************************/
static hw_action_position_e __acl_hw_action_position_end(sx_flex_acl_flex_action_t *action_p,
                                                         sxd_flex_acl_action_type_t hw_action_type);
static hw_action_position_e __acl_hw_action_position_in_trans(sx_flex_acl_flex_action_t *action_p,
                                                              sxd_flex_acl_action_type_t hw_action_type);
static hw_action_position_e __acl_hw_action_position_forward(sx_flex_acl_flex_action_t *action_p,
                                                             sxd_flex_acl_action_type_t hw_action_type);
static hw_action_position_e __acl_hw_action_position_off_trans(sx_flex_acl_flex_action_t *action_p,
                                                               sxd_flex_acl_action_type_t hw_action_type);
static hw_action_position_e __acl_hw_action_position_trans_terminate(sx_flex_acl_flex_action_t *action_p,
                                                                     sxd_flex_acl_action_type_t hw_action_type);

sx_status_t __acl_hw_action_counter_policer_by_ref_populate(sx_flex_acl_flex_action_t action,
                                                            boolean_t                 is_defer,
                                                            flex_acl_rule_id_t        rule_id,
                                                            hw_action_list_t         *hw_action_list_p,
                                                            hw_action_list_entry_t   *first_hw_action_list_entry_p);

static flex_acl_hw_action_details_t flex_acl_hw_action_details[SXD_ACTION_TYPE_LAST_E] = {
    [SXD_ACTION_TYPE_TRAP_E] = {2,
                                __acl_hw_action_position_end,
                                __acl_hw_action_reuse_true,
                                __acl_hw_action_trap_populate,
                                __acl_hw_action_trap_bind_populate,
                                __acl_hw_action_trap_release_lock,
                                NULL, NULL},

    [SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E] = {2,
                                               __acl_hw_action_position_end,
                                               __acl_hw_action_reuse_false, /* for wjh acl drop */
                                               __acl_hw_action_trap_populate, /* Reuse */
                                               __acl_hw_action_trap_bind_populate, /* Reuse */
                                               __acl_hw_action_trap_release_lock,
                                               NULL, NULL},

    [SXD_ACTION_TYPE_MIRROR_SAMPLER_E] = {1,
                                          __acl_hw_action_position_in_trans,
                                          __acl_hw_action_reuse_true,
                                          __acl_hw_action_mirror_sampler_populate,
                                          __acl_hw_action_mirror_sampler_bind_populate,
                                          __acl_hw_action_mirror_sampler_release_lock,
                                          NULL, NULL},

    [SXD_ACTION_TYPE_VLAN_E] = {1,
                                __acl_hw_action_position_in_trans,
                                __is_vlan_hw_action_reuse,
                                __acl_hw_action_vlan_populate,
                                NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_QOS_E] = {1,
                               __acl_hw_action_position_in_trans,
                               __acl_hw_action_reuse_true,
                               __acl_hw_action_qos_populate,
                               NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_MAC_E] = {2,
                               __acl_hw_action_position_in_trans,
                               __is_mac_hw_action_reuse,
                               __acl_hw_action_mac_populate,
                               NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_POLICING_COUNTING_E] = {1,
                                             __acl_hw_action_counter_policer_position,
                                             __acl_hw_action_reuse_false,
                                             __acl_hw_action_counter_policer_populate,
                                             __acl_hw_action_counter_policer_bind_populate,
                                             __acl_hw_action_counter_policer_release_lock,
                                             NULL, __acl_hw_action_counter_policer_action_set_comply},
    [SXD_ACTION_TYPE_POLICING_COUNTING_BY_REF_E] = {1,
                                                    __acl_hw_action_position_in_trans,
                                                    __acl_hw_action_reuse_false,
                                                    __acl_hw_action_counter_policer_by_ref_populate,
                                                    NULL,
                                                    NULL,
                                                    NULL, __acl_hw_action_counter_policer_by_ref_action_set_comply},
    [SXD_ACTION_TYPE_PORT_FILTER_E] = {2,
                                       __acl_hw_action_position_in_trans,
                                       __acl_hw_action_reuse_true,
                                       __acl_hw_action_port_filter_populate,
                                       __acl_hw_action_port_filter_bind_populate,
                                       NULL, NULL, NULL},
    [SXD_ACTION_TYPE_PORT_FILTER_EXT_E] = {2,
                                           __acl_hw_action_position_in_trans,
                                           __acl_hw_action_reuse_false,
                                           __acl_hw_action_port_filter_populate,
                                           __acl_hw_action_port_filter_bind_populate,
                                           NULL, NULL, NULL},
    [SXD_ACTION_TYPE_PORT_FILTER_EXT2_E] = {2,
                                            __acl_hw_action_position_in_trans,
                                            __acl_hw_action_reuse_false,
                                            __acl_hw_action_port_filter_populate,
                                            __acl_hw_action_port_filter_bind_populate,
                                            NULL, NULL, NULL},
    [SXD_ACTION_TYPE_FORWARD_E] = {2,
                                   __acl_hw_action_position_forward,
                                   __acl_hw_action_reuse_false,
                                   __acl_hw_action_forward_populate,
                                   __acl_hw_action_forward_bind_populate,
                                   __acl_hw_action_forward_release_lock,
                                   __acl_hw_action_forward_rollback, NULL},
    [SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E] = {1,
                                              __acl_hw_action_position_in_trans,
                                              __acl_hw_action_reuse_true,
                                              __acl_hw_action_virtual_forward_populate,
                                              NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_META_DATA_E] = {2,
                                     __acl_hw_action_position_in_trans,
                                     __acl_hw_action_reuse_false,
                                     __acl_hw_action_meta_data_populate,
                                     NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_IGNORE_E] = {1,
                                  __acl_hw_action_position_in_trans,
                                  __acl_hw_action_reuse_true,
                                  __acl_hw_action_ignore_populate,
                                  NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_MC_E] = {2,
                              __acl_hw_action_position_off_trans,
                              __acl_hw_action_reuse_true,
                              __acl_hw_action_mc_populate,
                              __acl_hw_action_mc_bind_populate,
                              NULL, NULL, NULL},
    [SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E] = {2,
                                              __acl_hw_action_position_off_trans,
                                              __acl_hw_action_reuse_true,
                                              __acl_hw_action_uc_populate,
                                              __acl_hw_action_uc_bind_populate,
                                              __acl_hw_action_uc_release_lock,
                                              NULL, NULL},
    [SXD_ACTION_TYPE_MPLS_E] = {1,
                                __acl_hw_action_position_off_trans,
                                __is_mpls_hw_action_reuse,
                                __acl_hw_action_mpls_populate,
                                NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_SIP_DIP_E] = {2,
                                   __acl_hw_action_position_in_trans,
                                   __acl_hw_action_reuse_false,
                                   __acl_hw_action_sip_dip_populate,
                                   NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_L4_PORT_E] = {1,
                                   __acl_hw_action_position_in_trans,
                                   __acl_hw_action_reuse_false,
                                   __acl_hw_action_l4_port_populate,
                                   NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_HASH_E] = {2,
                                __acl_hw_action_position_in_trans,
                                __is_hash_hw_action_reuse,
                                __acl_hw_action_hash_populate,
                                NULL, NULL, NULL, __acl_hw_action_hash_action_set_comply},
    [SXD_ACTION_TYPE_VXLAN_E] = {1,
                                 __acl_hw_action_position_in_trans,
                                 __acl_hw_action_reuse_false,
                                 __acl_hw_action_vxlan_populate,
                                 NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E] = {1,
                                                __acl_hw_action_position_trans_terminate, /* ALU operation should not allow reordering */
                                                __acl_hw_action_reuse_false,
                                                __acl_hw_action_custom_byte_alu_imm_populate,
                                                NULL, NULL, NULL, __acl_hw_action_alu_action_set_comply},
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E] = {1,
                                                __acl_hw_action_position_trans_terminate, /* ALU operation should not allow reordering */
                                                __acl_hw_action_reuse_false,
                                                __acl_hw_action_custom_byte_alu_reg_populate,
                                                NULL, NULL, NULL, __acl_hw_action_alu_action_set_comply},
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E] = {1,
                                                  __acl_hw_action_position_trans_terminate, /* ALU operation should not allow reordering */
                                                  __acl_hw_action_reuse_false,
                                                  __acl_hw_action_custom_byte_alu_field_populate,
                                                  NULL, NULL, NULL, __acl_hw_action_alu_field_action_set_comply},
    [SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E] = {1,
                                             __acl_hw_action_position_trans_terminate,  /* ALU operation should not allow reordering */
                                             __acl_hw_action_reuse_false,
                                             __acl_hw_action_custom_byte_move_populate,
                                             NULL, NULL, NULL, __acl_hw_action_custom_byte_move_set_comply},
    [SXD_ACTION_TYPE_FIELDS_SET_IMM_E] = {1,
                                          __acl_hw_action_position_in_trans,
                                          __acl_hw_action_reuse_false,
                                          __acl_hw_action_field_immediate_populate,
                                          NULL, NULL, NULL, __acl_hw_action_fields_set_imm_set_comply},
    [SXD_ACTION_TYPE_FIELDS_MOVE_E] = {1,
                                       __acl_hw_action_position_in_trans,
                                       __acl_hw_action_reuse_false,
                                       __acl_hw_action_field_move_populate,
                                       NULL, NULL, NULL, __acl_hw_action_fields_move_set_comply},
    [SXD_ACTION_TYPE_FLEX_MODIFIER_EMT_E] = {1,
                                             __acl_hw_action_position_in_trans,
                                             __acl_hw_action_reuse_false,
                                             __acl_hw_action_flex_modifier_emt_populate,
                                             NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_BUFFER_SNAP_E] = {1,
                                       __acl_hw_action_position_in_trans,
                                       __acl_hw_action_reuse_false,
                                       __acl_hw_action_buffer_snap_populate,
                                       NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_FS_DB_E] = {1,
                                 __acl_hw_action_position_trans_terminate,
                                 __acl_hw_action_reuse_false,
                                 __acl_hw_action_stateful_db_populate,
                                 NULL, NULL, NULL, NULL},
    [SXD_ACTION_TYPE_TRUNCATION_E] = {1,
                                      __acl_hw_action_position_in_trans,
                                      __acl_hw_action_reuse_false,
                                      __acl_hw_action_truncation_populate,
                                      NULL, NULL, NULL, NULL},

    [SXD_ACTION_TYPE_FLOW_ESTIMATOR_E] = {1,
                                          __acl_hw_action_position_in_trans,
                                          __acl_hw_action_reuse_false,
                                          __acl_hw_action_flow_estimator_populate,
                                          __acl_hw_action_flow_estimator_bind_populate,
                                          __acl_hw_action_flow_estimator_release_lock,
                                          NULL, NULL},
};
flex_acl_actions_details_t          sx_flex_acl_actions_details[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = {
    [SX_FLEX_ACL_ACTION_FORWARD] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_TRAP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                  1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                      {NULL, SXD_ACTION_TYPE_TRAP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                  }
    },
    [SX_FLEX_ACL_ACTION_COUNTER] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_POLICING_COUNTING_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_COUNTER_BY_REF] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS),
                                            1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                {NULL, SXD_ACTION_TYPE_POLICING_COUNTING_BY_REF_E,
                                                 FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_MIRROR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                    (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                    1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                        {NULL, SXD_ACTION_TYPE_TRAP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                    }
    },
    [SX_FLEX_ACL_ACTION_EGRESS_MIRROR] = { 0 | (1 << SX_ACL_DIRECTION_EGRESS) |
                                           (1 << SX_ACL_DIRECTION_TPORT_EGRESS),
                                           1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                               {NULL, SXD_ACTION_TYPE_TRAP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                           }
    },
    [SX_FLEX_ACL_ACTION_POLICER] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_POLICING_COUNTING_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_TRUNCATION] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                        1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                            {NULL, SXD_ACTION_TYPE_TRUNCATION_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                        }
    },
    [SX_FLEX_ACL_ACTION_SET_PRIO] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                          {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                      }
    },
    [SX_FLEX_ACL_ACTION_SET_VLAN] = {0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI] = {0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                               1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                   {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                               }
    },
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                (1 << SX_ACL_DIRECTION_EGRESS) |
                                                (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                                (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                                (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                    {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                }
    },
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                               1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                   {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                               }
    },
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                               1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                   {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                               }
    },
    [SX_FLEX_ACL_ACTION_SET_SRC_MAC] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                         1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                             {NULL, SXD_ACTION_TYPE_MAC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                         }
    },
    [SX_FLEX_ACL_ACTION_SET_DST_MAC] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_TPORT_INGRESS),
                                         1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                             {NULL, SXD_ACTION_TYPE_MAC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                         }
    },
    [SX_FLEX_ACL_ACTION_SET_DSCP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                          {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                      }
    },
    [SX_FLEX_ACL_ACTION_SET_BRIDGE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                        1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                            {NULL, SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E,
                                             FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                        }
    },
    [SX_FLEX_ACL_ACTION_PBS] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                 (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                 2, (flex_acl_hw_actions_map_hw_data_t[2]) {
                                     {NULL, SXD_ACTION_TYPE_FORWARD_E, FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                     {__flex_acl_is_pbs_meta_data, SXD_ACTION_TYPE_META_DATA_E,
                                      FLEX_ACL_ACTION_MODEFIER_IGMPV3_PBS_E}
                                 }
    },
    [SX_FLEX_ACL_ACTION_SET_TC] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_EGRESS) |
                                    (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                    (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                    (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                    (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                    1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                        {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                    }
    },
    [SX_FLEX_ACL_ACTION_DEC_TTL] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_MAC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_TTL] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_MAC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_COLOR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                       1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                           {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                       }
    },
    [SX_FLEX_ACL_ACTION_SET_ECN] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_USER_TOKEN] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                            1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                {NULL, SXD_ACTION_TYPE_META_DATA_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_DONT_LEARN] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                        1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                            {NULL, SXD_ACTION_TYPE_IGNORE_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                        }
    },
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER] = { 0 | (1 << SX_ACL_DIRECTION_EGRESS) |
                                                       (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                                       (1 << SX_ACL_DIRECTION_TPORT_EGRESS),
                                                       1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                           {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                            FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                       }
    },
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER] = { 0 | (1 << SX_ACL_DIRECTION_EGRESS) |
                                                      (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                                      (1 << SX_ACL_DIRECTION_TPORT_EGRESS),
                                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                          {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                           FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                      }
    },
    [SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                      (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                                      (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                                      (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                          {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                           FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                      }
    },
    [SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                   (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                                   (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                                   (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                   1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                       {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                        FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                   }
    },
    [SX_FLEX_ACL_ACTION_ELEPHANT_SET] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                               FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_RPF] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                 1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                     {NULL, SXD_ACTION_TYPE_MC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                 }
    },
    [SX_FLEX_ACL_ACTION_MC_ROUTE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                      (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                          {NULL, SXD_ACTION_TYPE_MC_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                      }
    },
    [SX_FLEX_ACL_ACTION_TUNNEL_DECAP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E,
                                               FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_GOTO] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                  0, NULL},
    [SX_FLEX_ACL_ACTION_SET_ROUTER] = { 0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_EGRESS),
                                        1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                            {NULL, SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E,
                                             FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                        }
    },
    [SX_FLEX_ACL_ACTION_MC] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                    {NULL, SXD_ACTION_TYPE_FORWARD_E,
                                     FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                }
    },
    [SX_FLEX_ACL_ACTION_UC_ROUTE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                      (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                      1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                          {NULL, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E,
                                           FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                      }
    },
    [SX_FLEX_ACL_ACTION_AR_UC_ROUTE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                         1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                             {NULL, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E,
                                              FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                         }
    },
    [SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                              (1 << SX_ACL_DIRECTION_EGRESS) |
                                              (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                              (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                              (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                              (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                              (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                              1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                  {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                              }
    },
    [SX_FLEX_ACL_ACTION_SET_PCP_REWRITE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {NULL, SXD_ACTION_TYPE_QOS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = { 0 | (1 << SX_ACL_DIRECTION_EGRESS),
                                         9, (flex_acl_hw_actions_map_hw_data_t[9]) {
                                             {NULL, SXD_ACTION_TYPE_PORT_FILTER_E, FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                             {__flex_acl_is_port_filter_ext, SXD_ACTION_TYPE_PORT_FILTER_EXT_E,
                                              FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE3_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE4_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE5_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE6_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE7_E},
                                             {__flex_acl_is_port_filter_ext2, SXD_ACTION_TYPE_PORT_FILTER_EXT2_E,
                                              FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE8_E}
                                         }
    },
    [SX_FLEX_ACL_ACTION_SET_MPLS_TTL] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_MPLS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_DEC_MPLS_TTL] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_MPLS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_SET_EXP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_MPLS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_EXP_REWRITE] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {NULL, SXD_ACTION_TYPE_MPLS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_PBILM] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                   (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                   (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                   (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                   1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                       {NULL, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E,
                                        FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                   }
    },
    [SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                              (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                              (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                              (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                              1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                  {NULL, SXD_ACTION_TYPE_FORWARD_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                              }
    },
    [SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                 (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                                 (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                 1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                     {NULL, SXD_ACTION_TYPE_FORWARD_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                 }
    },
    [SX_FLEX_ACL_ACTION_TRAP_W_USER_ID] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                            1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                {NULL, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                 FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_SET_SIP_ADDR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_SET_DIP_ADDR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                          (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                          (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                          1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                              {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                          }
    },
    [SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                            2, (flex_acl_hw_actions_map_hw_data_t[2]) {
                                                {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                                {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_IPV6_MSB_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                            2, (flex_acl_hw_actions_map_hw_data_t[2]) {
                                                {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E},
                                                {NULL, SXD_ACTION_TYPE_SIP_DIP_E, FLEX_ACL_ACTION_MODEFIER_IPV6_MSB_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {NULL, SXD_ACTION_TYPE_L4_PORT_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_SET_L4_DST_PORT] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {NULL, SXD_ACTION_TYPE_L4_PORT_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_HASH] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                  (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                  (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                  1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                      {__flex_acl_hash_hw_instance_count, SXD_ACTION_TYPE_HASH_E,
                                       FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                  }
    },
    [SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                   (1 << SX_ACL_DIRECTION_EGRESS) |
                                                   (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                   1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                       {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                   }
    },
    [SX_FLEX_ACL_ACTION_SET_VNI] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_VXLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_ALU_IMM] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E,
                                          FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_ALU_REG] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E,
                                          FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_ALU_FIELD] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                       1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                           {NULL, SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E,
                                            FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                       }
    },
    [SX_FLEX_ACL_ACTION_REGISTER_ACCESS] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {__flex_acl_register_access_hw_instance_count,
                                                  SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_MIRROR_SAMPLER] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                            1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                {NULL,
                                                 SXD_ACTION_TYPE_MIRROR_SAMPLER_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                            }
    },
    [SX_FLEX_ACL_ACTION_FIELD_IMM] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                       (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                       (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                       1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                           {__flex_acl_field_imm_hw_instance_count,
                                            SXD_ACTION_TYPE_FIELDS_SET_IMM_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                       }
    },
    [SX_FLEX_ACL_ACTION_FIELD_COPY] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                        (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                        (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                        1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                            {NULL, SXD_ACTION_TYPE_FIELDS_MOVE_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                        }
    },
    [SX_FLEX_ACL_ACTION_SET_EMT] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                         {NULL, SXD_ACTION_TYPE_FLEX_MODIFIER_EMT_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                     }
    },
    [SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                             (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                             1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                 {NULL, SXD_ACTION_TYPE_BUFFER_SNAP_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                             }
    },
    [SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                     (1 << SX_ACL_DIRECTION_EGRESS) |
                                                     (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                                     (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                                     (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                                     (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                                     (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                     1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                         {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                          FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                     }
    },
    [SX_FLEX_ACL_ACTION_NAT] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                 (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                 5, (flex_acl_hw_actions_map_hw_data_t[5]) {
                                     {__flex_acl_is_nat_sip_dip, SXD_ACTION_TYPE_SIP_DIP_E,
                                      FLEX_ACL_ACTION_MODEFIER_NAT_SIP_LSB_E},
                                     {__flex_acl_is_nat_sip_dip, SXD_ACTION_TYPE_SIP_DIP_E,
                                      FLEX_ACL_ACTION_MODEFIER_NAT_SIP_MSB_E},
                                     {__flex_acl_is_nat_sip_dip, SXD_ACTION_TYPE_SIP_DIP_E,
                                      FLEX_ACL_ACTION_MODEFIER_NAT_DIP_LSB_E},
                                     {__flex_acl_is_nat_sip_dip, SXD_ACTION_TYPE_SIP_DIP_E,
                                      FLEX_ACL_ACTION_MODEFIER_NAT_DIP_MSB_E},
                                     {NULL, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                 }
    },
    [SX_FLEX_ACL_ACTION_STATEFUL_DB] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                         (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                         (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                         1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                             {NULL, SXD_ACTION_TYPE_FS_DB_E,
                                              FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                         }
    },
    [SX_FLEX_ACL_ACTION_DISABLE_FDB_SECURITY] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                                  (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                                  1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                      {NULL, SXD_ACTION_TYPE_IGNORE_E,
                                                       FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                                  }
    },
    [SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE] = {0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                               (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                               (1 << SX_ACL_DIRECTION_CPU_INGRESS),
                                               1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                   {NULL, SXD_ACTION_TYPE_VLAN_E, FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                               }
    },
    [SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR] = { 0 | (1 << SX_ACL_DIRECTION_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_RIF_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_TPORT_EGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_INGRESS) |
                                            (1 << SX_ACL_DIRECTION_CPU_EGRESS),
                                            1, (flex_acl_hw_actions_map_hw_data_t[1]) {
                                                {NULL, SXD_ACTION_TYPE_FLOW_ESTIMATOR_E,
                                                 FLEX_ACL_ACTION_MODEFIER_NONE_E}
                                            }
    },
};
sxd_flex_trap_action_val_t          map_trap_action[] = {
    [SX_ACL_TRAP_ACTION_TYPE_TRAP] = SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E,
    [SX_ACL_TRAP_ACTION_TYPE_DISCARD] = SXD_FLEX_TRAP_ACTION_TYPE_DISCARD_NO_TRAP_E,
    [SX_ACL_TRAP_ACTION_TYPE_SOFT_DISCARD] = SXD_FLEX_TRAP_ACTION_TYPE_SOFT_DISCARD_CLEAR_TRAP_E,
};
sxd_flex_trap_forward_action_val_t  map_forward_action[] = {
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD] = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_FORWARD_DO_NOTHING_CLEAR_SOFT_DROP_E,
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD] = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E,
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD] = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E,
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT] = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DO_NOTHING_E,
};
sxd_flex_vlan_tag_cmd_t             map_vlan_tag_cmd[] = {
    [SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH] = SXD_FLEX_VLAN_TAG_CMD_TYPE_PUSH_OUTER_E,
    [SX_ACL_FLEX_SET_VLAN_CMD_TYPE_POP] = SXD_FLEX_VLAN_TAG_CMD_TYPE_POP_OUTER_E,
};
crc_hash_action_field_mapping_t     map_crc_hash_field[SX_ACL_ACTION_HASH_FIELD_LAST] = {
    [SX_ACL_ACTION_HASH_FIELD_SMAC] = {2, (sxd_hash_flex_action_hash_fields_t[2])
                                       {SXD_HASH_FLEX_ACTION_HASH_FIELD_SMAC_31_0_E,
                                        SXD_HASH_FLEX_ACTION_HASH_FIELD_DMAC_SMAC_47_32_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_DMAC] = {2, (sxd_hash_flex_action_hash_fields_t[2])
                                       {SXD_HASH_FLEX_ACTION_HASH_FIELD_DMAC_31_0_E,
                                        SXD_HASH_FLEX_ACTION_HASH_FIELD_SMAC_DMAC_47_32_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_SIP] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                      {SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_31_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_DIP] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                      {SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_31_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_SIPV6] = {4, (sxd_hash_flex_action_hash_fields_t[4])
                                        {SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_31_0_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_63_32_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_95_64_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_127_96_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_DIPV6] = {4, (sxd_hash_flex_action_hash_fields_t[4])
                                        {SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_31_0_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_63_32_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_95_64_E,
                                         SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_127_96_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_IP_PROTO] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                           {SXD_HASH_FLEX_ACTION_HASH_FIELD_IP_PROTO_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_L4_SOURCE_PORT] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                 {SXD_HASH_FLEX_ACTION_HASH_FIELD_L4_SPORT_DPORT_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_L4_DESTINATION_PORT] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                      {SXD_HASH_FLEX_ACTION_HASH_FIELD_L4_DPORT_SPORT_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_INNER_SIP] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                            {SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_31_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_INNER_DIP] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                            {SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_31_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_INNER_SIPV6] = {4, (sxd_hash_flex_action_hash_fields_t[4])
                                              {SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_31_0_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_63_32_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_95_64_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_127_96_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_INNER_DIPV6] = {4, (sxd_hash_flex_action_hash_fields_t[4])
                                              {SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_31_0_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_63_32_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_95_64_E,
                                               SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_127_96_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_INNER_IP_PROTO] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                 {SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_IP_PROTO_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_0] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_1_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_1] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_1_0_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_2] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_3_2_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_3] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_3_2_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_4] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_5_4_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_5] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_5_4_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_6] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_7_6_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_7] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                                {SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_7_6_E}
    },
    [SX_ACL_ACTION_HASH_FIELD_HASH_VALUE] = {1, (sxd_hash_flex_action_hash_fields_t[1])
                                             {SXD_HASH_FLEX_ACTION_HASH_FIELD_HASH_VALUE_E}
    },
};
action_field_select_mapping_t       map_action_field_select[SX_FLEX_ACL_FIELD_SELECT_LAST] = {
    [SX_FLEX_ACL_FIELD_SELECT_ECMP_HASH] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                            {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_ECMP_HASH_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_LAG_HASH] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                           {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_LAG_HASH_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_RANDOM] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                         {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_RANDOM_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_IP_LENGTH] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                            {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_IP_LENGTH_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_VID] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VID_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_USER_TOKEN] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                             {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_USER_TOKEN_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_TTL] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TTL_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_DMAC] = {3, (sxd_custom_bytes_flex_action_field_select_t[3])
                                       {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_15_0_E,
                                        SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_31_16_E,
                                        SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_47_32_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_SMAC] = {3, (sxd_custom_bytes_flex_action_field_select_t[3])
                                       {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_15_0_E,
                                        SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_31_16_E,
                                        SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_47_32_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_DIP] = {2, (sxd_custom_bytes_flex_action_field_select_t[2])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_15_0_E,
                                       SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_31_16_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_SIP] = {2, (sxd_custom_bytes_flex_action_field_select_t[2])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_15_0_E,
                                       SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_31_16_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_DIPV6] = {8, (sxd_custom_bytes_flex_action_field_select_t[8])
                                        {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_15_0_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_31_16_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_47_32_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_63_48_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_79_64_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_95_80_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_111_96_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_127_112_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_SIPV6] = {8, (sxd_custom_bytes_flex_action_field_select_t[8])
                                        {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_15_0_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_31_16_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_47_32_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_63_48_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_79_64_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_95_80_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_111_96_E,
                                         SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_127_112_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_L4_SOURCE_PORT] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                                 {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_SOURCE_PORT_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_L4_DESTINATION_PORT] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_DESTINATION_PORT_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_VNI] = {2, (sxd_custom_bytes_flex_action_field_select_t[2])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_15_0_E,
                                       SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_31_16_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_FID] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                      {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_FID_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_VRID] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                       {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VRID_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_PORT_USER_MEMORY] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                                   {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_PORT_USER_MEM_E}
    },
    [SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_0_OFFSET] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                                       {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_GP_REGISTER_0_OFFSET}
    },
    [SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_1_OFFSET] = {1, (sxd_custom_bytes_flex_action_field_select_t[1])
                                                       {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_GP_REGISTER_1_OFFSET}
    },
    [SX_FLEX_ACL_FIELD_SELECT_TRAP_USER_ID] = {2, (sxd_custom_bytes_flex_action_field_select_t[2])
                                               {SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_CQE_USER_DEF_VAL_15_0_E,
                                                SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_CQE_USER_DEF_VAL_19_16_E}
    },
};
/* Mapping of the crc hash field to a common key name so they can be compared for hazard prevention */
sx_acl_key_t map_sxd_crc_hash_field[SXD_HASH_FLEX_ACTION_HASH_FIELD_LAST_E] = {
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SMAC_31_0_E] = FLEX_ACL_KEY_SMAC,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DMAC_31_0_E] = FLEX_ACL_KEY_DMAC,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DMAC_SMAC_47_32_E] = FLEX_ACL_KEY_SMAC,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SMAC_DMAC_47_32_E] = FLEX_ACL_KEY_DMAC,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_31_0_E] = FLEX_ACL_KEY_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_63_32_E] = FLEX_ACL_KEY_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_95_64_E] = FLEX_ACL_KEY_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_127_96_E] = FLEX_ACL_KEY_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_31_0_E] = FLEX_ACL_KEY_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_63_32_E] = FLEX_ACL_KEY_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_95_64_E] = FLEX_ACL_KEY_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_127_96_E] = FLEX_ACL_KEY_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_IP_PROTO_E] = FLEX_ACL_KEY_IP_PROTO,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_L4_SPORT_DPORT_E] = FLEX_ACL_KEY_L4_SOURCE_PORT,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_L4_DPORT_SPORT_E] = FLEX_ACL_KEY_L4_DESTINATION_PORT,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_SPI_E] = FLEX_ACL_KEY_INVALID,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_31_0_E] = FLEX_ACL_KEY_INNER_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_63_32_E] = FLEX_ACL_KEY_INNER_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_95_64_E] = FLEX_ACL_KEY_INNER_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_127_96_E] = FLEX_ACL_KEY_INNER_SIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_31_0_E] = FLEX_ACL_KEY_INNER_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_63_32_E] = FLEX_ACL_KEY_INNER_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_95_64_E] = FLEX_ACL_KEY_INNER_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_127_96_E] = FLEX_ACL_KEY_INNER_DIP,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_IP_PROTO_E] = FLEX_ACL_KEY_INNER_IP_PROTO,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_L4_SPORT_DPORT_E] = FLEX_ACL_KEY_INNER_L4_SOURCE_PORT,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_L4_DPORT_SPORT_E] = FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_1_0_E] = FLEX_ACL_KEY_GP_REGISTER_0,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_3_2_E] = FLEX_ACL_KEY_GP_REGISTER_2,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_5_4_E] = FLEX_ACL_KEY_GP_REGISTER_4,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_7_6_E] = FLEX_ACL_KEY_GP_REGISTER_6,
    [SXD_HASH_FLEX_ACTION_HASH_FIELD_HASH_VALUE_E] = FLEX_ACL_KEY_ECMP_HASH,
};
/* Mapping of the action field select to a common key name so they can be compared for hazard prevention */
sx_acl_key_t map_sxd_action_field_select[SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E] = {
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_ECMP_HASH_E] = FLEX_ACL_KEY_ECMP_HASH,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_LAG_HASH_E] = FLEX_ACL_KEY_LAG_HASH,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_RANDOM_E] = FLEX_ACL_KEY_INVALID,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_IP_LENGTH_E] = FLEX_ACL_KEY_IP_PACKET_LENGTH,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VID_E] = FLEX_ACL_KEY_VLAN_ID,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_USER_TOKEN_E] = FLEX_ACL_KEY_USER_TOKEN,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TTL_E] = FLEX_ACL_KEY_TTL,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_15_0_E] = FLEX_ACL_KEY_DMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_31_16_E] = FLEX_ACL_KEY_DMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_47_32_E] = FLEX_ACL_KEY_DMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_15_0_E] = FLEX_ACL_KEY_SMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_31_16_E] = FLEX_ACL_KEY_SMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_47_32_E] = FLEX_ACL_KEY_SMAC,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_15_0_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_31_16_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_47_32_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_63_48_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_79_64_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_95_80_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_111_96_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_127_112_E] = FLEX_ACL_KEY_DIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_15_0_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_31_16_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_47_32_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_63_48_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_79_64_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_95_80_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_111_96_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_127_112_E] = FLEX_ACL_KEY_SIP,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_SOURCE_PORT_E] = FLEX_ACL_KEY_L4_SOURCE_PORT,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_DESTINATION_PORT_E] = FLEX_ACL_KEY_L4_DESTINATION_PORT,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_15_0_E] = FLEX_ACL_KEY_VNI_KEY,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_31_16_E] = FLEX_ACL_KEY_VNI_KEY,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_FID_E] = FLEX_ACL_KEY_FID,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VRID_E] = FLEX_ACL_KEY_VIRTUAL_ROUTER,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_PORT_USER_MEM_E] = FLEX_ACL_KEY_PORT_USER_MEMORY,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_GP_REGISTER_0_OFFSET] = FLEX_ACL_KEY_GP_REGISTER_0,
    [SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_GP_REGISTER_1_OFFSET] = FLEX_ACL_KEY_GP_REGISTER_1,
};

sxd_flex_modifier_emt_action_opcode_t map_sxd_emt_bind_type[SX_FLEX_MODIFIER_BIND_TYPE_LAST_E] = {
    [SX_FLEX_MODIFIER_BIND_TYPE_NOP_E] = SXD_FLEX_MODIFIER_EMT_ACTION_OPCODE_NOP_E,
    [SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E] = SXD_FLEX_MODIFIER_EMT_ACTION_OPCODE_PUSH_E,
    [SX_FLEX_MODIFIER_BIND_TYPE_EDIT_E] = SXD_FLEX_MODIFIER_EMT_ACTION_OPCODE_EDIT_E,
    [SX_FLEX_MODIFIER_BIND_TYPE_DISABLE_E] = SXD_FLEX_MODIFIER_EMT_ACTION_OPCODE_DISABLE_E,
    [SX_FLEX_MODIFIER_BIND_TYPE_POP_E] = SXD_FLEX_MODIFIER_EMT_ACTION_OPCODE_POP_E,
};

sxd_flex_modifier_emt_action_modifier_base_t map_sxd_emt_modifier_base[] = {
    [SX_FLEX_MODIFIER_HEADER_SOP_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_SOP_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_MAC_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_MAC_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_ETHERTYPE_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_ETHERTYPE_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_IP_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_IP_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_MPLS_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_MPLS_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_NVE_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_NVE_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_GRE_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_GRE_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_UDP_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_UDP_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_FLEX_TUNNEL_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_FLEX_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_INNER_MAC_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_INNER_MAC_E,
    [SX_FLEX_MODIFIER_HEADER_ENCAP_INNER_ETHERTYPE_E] = SXD_FLEX_MODIFIER_EMT_ACTION_MODIFIER_BASE_INNER_ETHERTYPE_E
};

static sxd_flex_stateful_db_ticket_op_t map_sxd_stateful_db_ticket_op[] = {
    [SX_STATEFUL_DB_ORDER_NOP_E] = SXD_FLEX_STATEFUL_DB_TICKET_OP_NOP_E,
    [SX_STATEFUL_DB_ORDER_RELEASE_E] = SXD_FLEX_STATEFUL_DB_TICKET_OP_RELEASE_E,
    [SX_STATEFUL_DB_ORDER_FORCE_E] = SXD_FLEX_STATEFUL_DB_TICKET_OP_CHECK_E,
};

static sxd_flex_stateful_db_db_op_t map_sxd_stateful_db_db_op[] = {
    [SX_STATEFUL_DB_OP_NOP_E] = SXD_FLEX_STATEFUL_DB_DB_OP_NOP_E,
    [SX_STATEFUL_DB_OP_READ_E] = SXD_FLEX_STATEFUL_DB_DB_OP_READ_E,
    [SX_STATEFUL_DB_OP_WRITE_E] = SXD_FLEX_STATEFUL_DB_DB_OP_WRITE_E,
    [SX_STATEFUL_DB_OP_REMOVE_INDICATION_E] = SXD_FLEX_STATEFUL_DB_DB_OP_REMOVE_ENTRY_WITH_FAILURE_INDICATION_E,
    [SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E] = SXD_FLEX_STATEFUL_DB_DB_OP_REMOVE_ENTRY_WITHOUT_FAILURE_INDICATION_E,
};

static sxd_flex_stateful_db_sem_op_t map_sxd_stateful_db_sem_op[] = {
    [SX_STATEFUL_DB_SEM_NOP_E] = SXD_FLEX_STATEFUL_DB_SEM_OP_NOP_E,
    [SX_STATEFUL_DB_SEM_LOCK_E] = SXD_FLEX_STATEFUL_DB_SEM_OP_LOCK_E,
    [SX_STATEFUL_DB_SEM_UNLOCK_E] = SXD_FLEX_STATEFUL_DB_SEM_OP_UNLOCK_E,
};

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t flex_acl_hw_set_rebind_group_pfunc(flex_acl_rebind_group_pfunc_t rebind_group_cb)
{
    rebind_group_cb_g = rebind_group_cb;
    return SX_STATUS_SUCCESS;
}

static hw_action_position_e __acl_hw_action_position_end(sx_flex_acl_flex_action_t *action_p,
                                                         sxd_flex_acl_action_type_t hw_action_type)
{
    UNUSED_PARAM(action_p);
    UNUSED_PARAM(hw_action_type);

    return FLEX_ACL_HW_ACTION_POSITION_END_E;
}

static hw_action_position_e __acl_hw_action_position_in_trans(sx_flex_acl_flex_action_t *action_p,
                                                              sxd_flex_acl_action_type_t hw_action_type)
{
    UNUSED_PARAM(action_p);
    UNUSED_PARAM(hw_action_type);

    return FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E;
}

static hw_action_position_e __acl_hw_action_position_off_trans(sx_flex_acl_flex_action_t *action_p,
                                                               sxd_flex_acl_action_type_t hw_action_type)
{
    UNUSED_PARAM(action_p);
    UNUSED_PARAM(hw_action_type);

    return FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E;
}

static hw_action_position_e __acl_hw_action_position_trans_terminate(sx_flex_acl_flex_action_t *action_p,
                                                                     sxd_flex_acl_action_type_t hw_action_type)
{
    UNUSED_PARAM(action_p);
    UNUSED_PARAM(hw_action_type);

    return FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E;
}

static boolean_t __flex_acl_is_pbs_meta_data(sx_flex_acl_flex_action_t *action,
                                             flex_acl_action_modifier_e action_modifier,
                                             uint32_t                  *instance_count)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    UNUSED_PARAM(action_modifier);

    if (instance_count != NULL) {
        *instance_count = 1;
    }

    rc = flex_acl_db_pbs_get_entry(0, action->fields.action_pbs.pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS action PBS id %u is not valid\n", action->fields.action_pbs.pbs_id);
        return FALSE;
    }
    return pbs_entry->entry_type != SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST &&
           pbs_entry->entry_type != SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST;
}

static boolean_t __flex_acl_is_port_filter_ext(sx_flex_acl_flex_action_t *action,
                                               flex_acl_action_modifier_e action_modifier,
                                               uint32_t                  *instance_count)
{
    UNUSED_PARAM(action);
    UNUSED_PARAM(action_modifier);

    if (instance_count != NULL) {
        *instance_count = 1;
    }
    return (ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) ? TRUE : FALSE;
}

static boolean_t __flex_acl_is_port_filter_ext2(sx_flex_acl_flex_action_t *action,
                                                flex_acl_action_modifier_e action_modifier,
                                                uint32_t                  *instance_count)
{
    UNUSED_PARAM(action);
    UNUSED_PARAM(action_modifier);

    if (instance_count != NULL) {
        *instance_count = 1;
    }

    switch (action_modifier) {
    case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE5_E:
    case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE6_E:
    case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE7_E:
    case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE8_E:
        return (ACL_STAGE_IS_FLEX4_OR_ABOVE(flex_acl_stage)) ? TRUE : FALSE;

    default:
        return (ACL_STAGE_IS_FLEX3_OR_ABOVE(flex_acl_stage)) ? TRUE : FALSE;
    }
}

static boolean_t __flex_acl_is_nat_sip_dip(sx_flex_acl_flex_action_t *action,
                                           flex_acl_action_modifier_e action_modifier,
                                           uint32_t                  *instance_count)
{
    boolean_t is_needed = FALSE;

    if (instance_count != NULL) {
        *instance_count = 1;
    }

    switch (action_modifier) {
    case FLEX_ACL_ACTION_MODEFIER_NAT_SIP_LSB_E:
        is_needed = (action->fields.action_nat.sip.version != SX_IP_VERSION_NONE) ? TRUE : FALSE;
        break;

    case FLEX_ACL_ACTION_MODEFIER_NAT_SIP_MSB_E:
        is_needed = (action->fields.action_nat.sip.version == SX_IP_VERSION_IPV6) ? TRUE : FALSE;
        break;

    case FLEX_ACL_ACTION_MODEFIER_NAT_DIP_LSB_E:
        is_needed = (action->fields.action_nat.dip.version != SX_IP_VERSION_NONE) ? TRUE : FALSE;
        break;

    case FLEX_ACL_ACTION_MODEFIER_NAT_DIP_MSB_E:
        is_needed = (action->fields.action_nat.dip.version == SX_IP_VERSION_IPV6) ? TRUE : FALSE;
        break;

    default:
        break;
    }

    return is_needed;
}


/* Calculate the number of hw hash actions needed to implement one user hash action */
static boolean_t __flex_acl_hash_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                   flex_acl_action_modifier_e action_modifier,
                                                   uint32_t                  *instance_count)
{
    UNUSED_PARAM(action_modifier);

    *instance_count = 1;
    /* Only CRC hash action might incur more than one HW command */
    if (action->fields.action_hash.command == SX_ACL_ACTION_HASH_COMMAND_CRC) {
        *instance_count = map_crc_hash_field[action->fields.action_hash.hash_crc.field].sxd_actions_count;
    }

    return TRUE;
}

/* Calculate the number of hw custom bye move hw actions needed to implement one user action */
static boolean_t __flex_acl_register_access_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                              flex_acl_action_modifier_e action_modifier,
                                                              uint32_t                  *instance_count)
{
    UNUSED_PARAM(action_modifier);

    uint32_t i = 0;

    *instance_count = 1;
    /* If registers are consecutive we can merge them into one action. So we check that here */
    if (action->fields.action_register_access.command == SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LOAD) {
        for (i = 1; i < action->fields.action_register_access.list_size; i++) {
            if (action->fields.action_register_access.dst_register_list[i] !=
                action->fields.action_register_access.dst_register_list[i - 1] + 1) {
                (*instance_count)++;
            }
        }
    }
    /* If registers are consecutive we can merge them into one action. So we check that here */
    if (action->fields.action_register_access.command == SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE) {
        for (i = 1; i < action->fields.action_register_access.list_size; i++) {
            if (action->fields.action_register_access.src_register_list[i] !=
                action->fields.action_register_access.src_register_list[i - 1] + 1) {
                (*instance_count)++;
            }
        }
    }
    /* If registers are consecutive we can merge them into one action. So we check that here */
    if (action->fields.action_register_access.command == SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_COPY) {
        for (i = 1; i < action->fields.action_register_access.list_size; i++) {
            if ((action->fields.action_register_access.src_register_list[i] !=
                 action->fields.action_register_access.src_register_list[i - 1] + 1) ||
                (action->fields.action_register_access.dst_register_list[i] !=
                 action->fields.action_register_access.dst_register_list[i - 1] + 1)) {
                (*instance_count)++;
            }
        }
    }

    return TRUE;
}

/* If the same immediate value is used we can reduce the number of action to add */
static boolean_t __flex_acl_field_imm_hw_instance_count(sx_flex_acl_flex_action_t *action,
                                                        flex_acl_action_modifier_e action_modifier,
                                                        uint32_t                  *instance_count)
{
    uint32_t i = 0;

    UNUSED_PARAM(action_modifier);

    *instance_count = action->fields.action_field_imm.list_size;

    for (i = 0; i + 1 < action->fields.action_field_imm.list_size; i++) {
        if (action->fields.action_field_imm.immediate_list[i] ==
            action->fields.action_field_imm.immediate_list[i + 1]) {
            (*instance_count)--;
        }
    }

    return TRUE;
}

sx_status_t __acl_hw_action_vlan_populate(sx_flex_acl_flex_action_t action,
                                          boolean_t                 is_defer,
                                          flex_acl_rule_id_t        rule_id,
                                          hw_action_list_t         *hw_action_list_p,
                                          hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint8_t               ethertype_index = VLAN_ETHER_TYPE_INDEX_0;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_vlan.defer = is_defer;
    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_VLAN:
        hw_action->slot.fields.action_vlan.v_tag_cmd = map_vlan_tag_cmd[action.fields.action_set_vlan.cmd];
        if (action.fields.action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH) {
            hw_action->slot.fields.action_vlan.vid_cmd = SXD_FLEX_VID_CMD_TYPE_SET_OUTER_E;
            hw_action->slot.fields.action_vlan.vid_val = action.fields.action_set_vlan.vlan_id;
            switch (action.fields.action_set_vlan.qinq_tunnel_qos) {
            case SX_ACL_FLEX_QINQ_TUNNEL_QOS_PIPE:
                hw_action->slot.fields.action_vlan.pcp_cmd = SXD_FLEX_VLAN_PRIO_CMD_TYPE_SET_OUTER_E;
                hw_action->slot.fields.action_vlan.pcp_val =
                    action.fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.pcp;
                hw_action->slot.fields.action_vlan.dei_cmd = SXD_FLEX_DEI_CMD_TYPE_SET_OUTER_E;
                hw_action->slot.fields.action_vlan.dei_val =
                    action.fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.dei;
                break;

            case SX_ACL_FLEX_QINQ_TUNNEL_QOS_UNIFORM:
                hw_action->slot.fields.action_vlan.pcp_cmd = SXD_FLEX_VLAN_PRIO_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E;
                hw_action->slot.fields.action_vlan.dei_cmd = SXD_FLEX_DEI_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E;
                break;

            default:
                return SX_STATUS_ERROR;
            }
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID:
        hw_action->slot.fields.action_vlan.vid_cmd = SXD_FLEX_VID_CMD_TYPE_SET_INNER_E;
        hw_action->slot.fields.action_vlan.vid_val = action.fields.action_set_inner_vlan_id.vlan_id;
        break;

    case SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID:
        hw_action->slot.fields.action_vlan.vid_cmd = SXD_FLEX_VID_CMD_TYPE_SET_OUTER_E;
        hw_action->slot.fields.action_vlan.vid_val = action.fields.action_set_outer_vlan_id.vlan_id;
        break;

    case SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI:
        hw_action->slot.fields.action_vlan.pcp_cmd = SXD_FLEX_VLAN_PRIO_CMD_TYPE_SET_INNER_E;
        hw_action->slot.fields.action_vlan.pcp_val = action.fields.action_set_inner_vlan_prio.pcp;
        hw_action->slot.fields.action_vlan.dei_cmd = SXD_FLEX_DEI_CMD_TYPE_SET_INNER_E;
        hw_action->slot.fields.action_vlan.dei_val = action.fields.action_set_inner_vlan_prio.dei;
        break;

    case SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI:
        hw_action->slot.fields.action_vlan.pcp_cmd = SXD_FLEX_VLAN_PRIO_CMD_TYPE_SET_OUTER_E;
        hw_action->slot.fields.action_vlan.pcp_val = action.fields.action_set_outer_vlan_prio.pcp;
        hw_action->slot.fields.action_vlan.dei_cmd = SXD_FLEX_DEI_CMD_TYPE_SET_OUTER_E;
        hw_action->slot.fields.action_vlan.dei_val = action.fields.action_set_outer_vlan_prio.dei;
        break;

    case SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN:
        hw_action->slot.fields.action_vlan.vid_cmd = SXD_FLEX_VID_CMD_TYPE_SWAP_INNER_OUTER_E;
        break;

    case SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE:
        hw_action->slot.fields.action_vlan.ethertype_cmd =
            (sxd_flex_vlan_ethertype_cmd_t)action.fields.action_set_vlan_ethertype.ethertype_cmd;

        switch (action.fields.action_set_vlan_ethertype.ethertype_cmd) {
        case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_OUTER_E:
        case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_INNER_E:
            if (action.fields.action_set_vlan_ethertype.egress_et_set != FALSE) {
                hw_action->slot.fields.action_vlan.ethertype_val = SXD_FLEX_ACL_VLAN_ETHERTYPE_FROM_EGRESS_PORT_INDEX;
            } else {
                if (action.fields.action_set_vlan_ethertype.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
                    ethertype_index = VLAN_ETHER_TYPE_INDEX_1;
                } else {
                    ethertype_index = VLAN_ETHER_TYPE_INDEX_0;
                }

                hw_action->slot.fields.action_vlan.ethertype_val = ethertype_index;
            }

            break;

        case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_OUTER_E:
        case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_INNER_E:
        case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SWAP_INNER_OUTER_E:
        default:
            break;
        }
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __acl_hw_action_reuse_true(sx_flex_acl_flex_action_t *action,
                                            flex_acl_hw_action_t      *hw_action,
                                            int32_t                    relative_position)
{
    UNUSED_PARAM(action);
    UNUSED_PARAM(hw_action);
    UNUSED_PARAM(relative_position);
    return TRUE;
}

static boolean_t __acl_hw_action_reuse_false(sx_flex_acl_flex_action_t *action,
                                             flex_acl_hw_action_t      *hw_action,
                                             int32_t                    relative_position)
{
    UNUSED_PARAM(action);
    UNUSED_PARAM(hw_action);
    UNUSED_PARAM(relative_position);
    return FALSE;
}

static boolean_t __is_hash_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position)
{
    boolean_t action_reuse = FALSE;

    /* The same hash function can be reused only when this is a CRC action for adjacent GP registers.
     * The two actions need also be adjacent in the user's order.
     */
    if ((relative_position == -1) &&
        (hw_action->slot.fields.action_hash.hash_cmd == SXD_HASH_FLEX_ACTION_CMD_CRC_E) &&
        (hw_action->slot.fields.action_hash.type == (sxd_hash_flex_action_type_t)action->fields.action_hash.type) &&
        (action->fields.action_hash.command == SX_ACL_ACTION_HASH_COMMAND_CRC) &&
        (action->fields.action_hash.hash_crc.field >= SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_0) &&
        (action->fields.action_hash.hash_crc.field <= SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_7) &&
        (map_crc_hash_field[action->fields.action_hash.hash_crc.field].sxd_actions[0] ==
         hw_action->slot.fields.action_hash.hash_fields)) {
        switch (action->fields.action_hash.hash_crc.field) {
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_0:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_2:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_4:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_6:
            if ((hw_action->slot.fields.action_hash.hash_mask & 0xFFFF) == 0) {
                action_reuse = TRUE;
            }
            break;

        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_1:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_3:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_5:
        case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_7:
            if ((hw_action->slot.fields.action_hash.hash_mask & 0xFFFF0000) == 0) {
                action_reuse = TRUE;
            }
            break;

        default:
            break;
        }
    }
    return action_reuse;
}

static boolean_t __is_vlan_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position)
{
    UNUSED_PARAM(relative_position);

    switch (action->type) {
    case SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID:
    case SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID:
    case SX_FLEX_ACL_ACTION_SET_VLAN:
    case SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN:
        if ((hw_action->slot.fields.action_vlan.vid_cmd != SXD_FLEX_VID_CMD_TYPE_DO_NOTHING_E) ||
            (hw_action->slot.fields.action_vlan.v_tag_cmd != SXD_FLEX_VLAN_TAG_CMD_TYPE_DO_NOTHING_E)) {
            return FALSE;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI:
    case SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI:
        if (hw_action->slot.fields.action_vlan.pcp_cmd != SXD_FLEX_VLAN_PRIO_CMD_TYPE_DO_NOTHING_E) {
            return FALSE;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE:
        if (hw_action->slot.fields.action_vlan.ethertype_cmd != SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_DO_NOTHING_E) {
            return FALSE;
        }
        break;

    default:
        break;
    }

    return TRUE;
}

sx_status_t __acl_hw_action_trap_populate(sx_flex_acl_flex_action_t action,
                                          boolean_t                 is_defer,
                                          flex_acl_rule_id_t        rule_id,
                                          hw_action_list_t         *hw_action_list_p,
                                          hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    boolean_t             monitor_enabled = FALSE;
    uint32_t              acl_drop_trap_usr_def_val = 0;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_trap.defer = is_defer;
    switch (action.type) {
    case SX_FLEX_ACL_ACTION_TRAP_W_USER_ID:
        hw_action->slot.fields.action_trap.user_def_val = action.fields.action_trap_w_user_id.user_id;
        hw_action->slot.fields.action_trap.trap_action = map_trap_action[action.fields.action_trap_w_user_id.action];
        if (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E) {
            hw_action->slot.fields.action_trap.trap_id = action.fields.action_trap_w_user_id.trap_id;
        }
        break;

    case SX_FLEX_ACL_ACTION_TRAP:
        hw_action->slot.fields.action_trap.trap_action = map_trap_action[action.fields.action_trap.action];
        if (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E) {
            hw_action->slot.fields.action_trap.trap_id = action.fields.action_trap.trap_id;
            hw_action->slot.fields.action_trap.preserve_user_def_val =
                action.fields.action_trap.preserve_user_id;
        }
        break;

    case SX_FLEX_ACL_ACTION_FORWARD:
        hw_action->slot.fields.action_trap.forward_action = map_forward_action[action.fields.action_forward.action];
        hw_action->original_forward_action = map_forward_action[action.fields.action_forward.action];
        /* If forward action is soft/hard discard AND
         * if monitoring is enabled THEN set ACL DROP TRAP
         * */
        if ((action.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD) ||
            (action.fields.action_forward.action == SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD)) {
            monitor_enabled = __is_acl_drop_monitor_enabled(rule_id, &entry_type);
            /* get free index from MAP */
            rc = flex_acl_hw_acl_drop_trap_usr_def_val_add(rule_id, &acl_drop_trap_usr_def_val);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error getting user def map val for Rule[region=%u, offset =%u]  RC = %s\n",
                           rule_id.region_id, rule_id.offset, sx_status_str(rc));
                goto out;
            }
            if (monitor_enabled) {
                hw_action->slot.fields.action_trap.user_def_val = acl_drop_trap_usr_def_val;
                hw_action->slot.fields.action_trap.trap_action = SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E;
                if (entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) {
                    hw_action->slot.fields.action_trap.trap_id = SX_TRAP_ID_ACL_DROP;
                } else {
                    hw_action->slot.fields.action_trap.trap_id = SX_TRAP_ID_SYS_ACL_DROP;
                }
            } else {
                /* The rule is still active/valid. Only monitoring is disabled */
                hw_action->slot.fields.action_trap.user_def_val = SX_ACL_USER_ID_MAX;
                hw_action->slot.fields.action_trap.trap_action = SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E;
                hw_action->slot.fields.action_trap.trap_id = 0;

                /* Disable this rule in the ACL Drop Db */
                rc = flex_acl_hw_acl_drop_trap_usr_def_val_modify(rule_id, monitor_enabled);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error getting user def map val for Rule[region=%u, offset =%u]  RC = %s\n",
                               rule_id.region_id, rule_id.offset, sx_status_str(rc));
                    goto out;
                }
            }
            if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) || (entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E)) {
                /* Save off the orig action to the aux slot. This is needed
                 * mainly for empty MC/ECMP container handling. When container state change
                 * happens(empty -> not empty), we need to distinguish if the ACL drop
                 * Trap is due to Empty container or FWD + Drop*/
                hw_action->aux_slot.fields.action_trap.forward_action =
                    map_forward_action[action.fields.action_forward.action];
                /* set the acl drop handle */
                hw_action->acl_drop_trap_handle = FLEX_ACL_DROP_TRAP_HANDLE(rule_id.region_id,
                                                                            rule_id.offset);
            }
        }
        break;

    case SX_FLEX_ACL_ACTION_EGRESS_MIRROR:
        hw_action->is_egress_mirror = TRUE;

    /* fall through */
    case SX_FLEX_ACL_ACTION_MIRROR:
        hw_action->slot.fields.action_trap.mirror_enable = 1;
        hw_action->span_user_handle = flex_acl_get_span_user_handle();
        hw_action->span_session_id = action.fields.action_mirror.session_id;
        break;

    default:
        SX_LOG_ERR("TRAP HW action populate: Invalid action type:%u \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_mirror_sampler_populate(sx_flex_acl_flex_action_t action,
                                                           boolean_t                 is_defer,
                                                           flex_acl_rule_id_t        rule_id,
                                                           hw_action_list_t         *hw_action_list_p,
                                                           hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_trap.defer = is_defer;
    switch (action.type) {
    case SX_FLEX_ACL_ACTION_MIRROR_SAMPLER:
        hw_action->span_user_handle = flex_acl_get_span_user_handle();
        hw_action->span_session_id = action.fields.action_mirror_sampler.session_id;
        hw_action->mirror_probability_rate = action.fields.action_mirror_sampler.mirror_probability_rate;
        break;

    default:
        SX_LOG_ERR("MIRROR SAMPLER HW action populate: Invalid action type:%u \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_egress_mirror_allocate_buffer(sx_port_log_id_t log_port)
{
    return flex_acl_egress_mirror_handle_buffer(SX_ACCESS_CMD_ADD, log_port);
}


static sx_status_t __flex_acl_hw_egress_mirror_free_buffer(sx_port_log_id_t log_port)
{
    return flex_acl_egress_mirror_handle_buffer(SX_ACCESS_CMD_DELETE, log_port);
}

typedef sx_status_t (*flex_acl_hw_foreach_rule_action_cb_t)(flex_acl_hw_action_t *hw_action,
                                                            boolean_t            *found_p);
static sx_status_t __hw_action_find_empty_action(flex_acl_hw_action_t *hw_action, boolean_t               *found_p)
{
    if (hw_action->slot.type == SXD_ACTION_TYPE_NULL_E) {
        *found_p = TRUE;
    }
    return SX_STATUS_SUCCESS;
}

static sx_status_t __hw_action_find_forward_empty_pbs(flex_acl_hw_action_t *hw_action, boolean_t            *found_p)
{
    if ((hw_action->api_action_type == SX_FLEX_ACL_ACTION_PBS) &&
        (hw_action->aux_slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) &&
        (hw_action->slot.type == SXD_ACTION_TYPE_NULL_E)) {
        *found_p = TRUE;
    }
    return SX_STATUS_SUCCESS;
}
static sx_status_t __hw_action_is_fwd_and_acl_drop(flex_acl_hw_action_t *hw_action, boolean_t *found_p)
{
    /* return True if the API action is fwd, the forwarding action is drop
     * and if the trap id is either SX_TRAP_ID_ACL_DROP or SX_TRAP_ID_SYS ACL_DROP
     * when monitoring is enabled or if the trap action is DO nothing then the user def value
     * is SX_ACL_USER_ID_MAX
     */
    *found_p = FALSE;
    if (hw_action->api_action_type == SX_FLEX_ACL_ACTION_FORWARD) {
        if (hw_action->action_type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
            /* check the aux slot for orig fwd action.
             * we saved this when inserting the trap action */
            if ((hw_action->aux_slot.fields.action_trap.forward_action ==
                 SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E) ||
                (hw_action->aux_slot.fields.action_trap.forward_action ==
                 SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E)) {
                if (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E) {
                    if ((hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
                        (hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP)) {
                        /* acl drop trap is enabled. */
                        *found_p = TRUE;
                    }
                } else if (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E) {
                    /* Monitoring is disabled. */
                    if (hw_action->slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX) {
                        *found_p = TRUE;
                    }
                }
            }
        }
    }
    return SX_STATUS_SUCCESS;
}

static sx_status_t __hw_action_is_other_acl_drop_trap(flex_acl_hw_action_t *hw_action, boolean_t *found_p)
{
    /* return true if the api action is not forward, and not trap-w-user-id and
     * the hw slot action is trap-w-user-def and
     * the trap id is either acl drop trap or the user def val is the max-user-def-val.
     * Applies mainly to empty MC/ECMP/PBS container flow
     */
    *found_p = FALSE;
    if ((hw_action->api_action_type != SX_FLEX_ACL_ACTION_TRAP_W_USER_ID) &&
        (hw_action->api_action_type != SX_FLEX_ACL_ACTION_FORWARD)) {
        if (hw_action->slot.type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
            if ((hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
                (hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP) ||
                (hw_action->slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX)) {
                *found_p = TRUE;
            }
        }
    }
    /* This is to revert discard action not configured by user. This would be set in case of a specific
     * set of actions in the same rule. A forward action with Permit or Forward types
     *  in the same rule as an empty ECMP/MC/PBS container*/
    else if ((hw_action->api_action_type == SX_FLEX_ACL_ACTION_FORWARD) &&
             ((hw_action->original_forward_action ==
               SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_FORWARD_DO_NOTHING_CLEAR_SOFT_DROP_E) ||
              (hw_action->original_forward_action == SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DO_NOTHING_E))) {
        if (hw_action->slot.type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
            if ((hw_action->slot.fields.action_trap.forward_action ==
                 SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E) &&
                (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E)) {
                if ((hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
                    (hw_action->slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP) ||
                    (hw_action->slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX)) {
                    *found_p = TRUE;
                }
            }
        }
    }
    return SX_STATUS_SUCCESS;
}

static sx_status_t flex_acl_hw_foreach_rule_hw_action_until_found(flex_acl_db_flex_rule_t             *rule,
                                                                  sxd_flex_acl_action_type_t           action_type,
                                                                  flex_acl_hw_foreach_rule_action_cb_t func,
                                                                  boolean_t                           *found_p)
{
    uint32_t                         iii;
    flex_acl_hw_db_action_set_t     *action_set = NULL;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    cl_list_iterator_t               iter = NULL;
    const cl_list_t                 *kvd_action_set_list = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    boolean_t                        found = FALSE;

    SX_LOG_ENTER();

    action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    *found_p = FALSE;

    for (iii = 0; !found && (iii < action_set->action_set.actions_count); iii++) {
        if (action_set->action_set.actions[iii].action_type == action_type) {
            rc = func(&action_set->action_set.actions[iii], &found);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Action CB failed for action %s [%s]\n",
                           HW_ACTION_ID_2SHORT(action_set->action_set.actions[iii].action_type),
                           sx_status_str(rc));
                goto out;
            }
        }
    }

    if (action_set->kvd_action_set_count == 0) {
        goto out;
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(action_set, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }

    for (iter = cl_list_head(kvd_action_set_list);
         !found && (iter != cl_list_end(kvd_action_set_list));
         iter = cl_list_next(iter)) {
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        for (iii = 0; !found && (iii < kvd_action_set->actions_count); iii++) {
            if (kvd_action_set->actions[iii].action_type == action_type) {
                rc = func(&kvd_action_set->actions[iii], &found);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Action CB failed for action %s [%s]\n",
                               HW_ACTION_ID_2SHORT(kvd_action_set->actions[iii].action_type),
                               sx_status_str(rc));
                    goto out;
                }
            }
        }
    }

out:
    if (rc == SX_STATUS_SUCCESS) {
        *found_p = found;
    }

    SX_LOG_EXIT();
    return rc;
}

/* This function is used both for SXD_ACTION_TYPE_TRAP_E and SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E */
static sx_status_t __acl_hw_action_trap_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                      flex_acl_db_flex_rule_t   *rule,
                                                      flex_acl_relocation_data_t relocation_data,
                                                      boolean_t                  add_ref)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t           span_session_id_int;
    boolean_t                          found = FALSE;
    uint32_t                           update_count;
    sxd_flex_trap_forward_action_val_t final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_LAST_E;
    uint8_t                            tmp_mirror_enable;
    uint8_t                            tmp_mirror_agent;
    flex_acl_db_acl_region_t          *region_p = NULL;
    flex_acl_rule_id_t                 rule_id;
    flex_acl_entry_type_e              entry_type;
    boolean_t                          acl_drop_trap_enabled = FALSE;

    SX_LOG_ENTER();

    final_forward_action = hw_action->original_forward_action;

    /* If there is an empty action in the rule the TRAP should be changed to DISCARD */
    rc = flex_acl_hw_foreach_rule_hw_action_until_found(rule, SXD_ACTION_TYPE_FORWARD_E,
                                                        __hw_action_find_forward_empty_pbs, &found);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_hw_foreach_rule_hw_action_until_found failed for SXD_ACTION_TYPE_FORWARD_E\n");
        goto out;
    }

    if (found) {
        if (flex_acl_is_using_soft_drop_for_empty_container()) {
            final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E;
        } else {
            final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E;
        }
    }

    rc = flex_acl_hw_foreach_rule_hw_action_until_found(rule, SXD_ACTION_TYPE_MC_E,
                                                        __hw_action_find_empty_action, &found);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_hw_foreach_rule_hw_action_until_found failed for SXD_ACTION_TYPE_MC_E\n");
        goto out;
    }

    if (found) {
        final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E;
    }

    rc = flex_acl_hw_foreach_rule_hw_action_until_found(rule, SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E,
                                                        __hw_action_find_empty_action, &found);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "flex_acl_hw_foreach_rule_hw_action_until_found failed for SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E\n");
        goto out;
    }

    if (found) {
        if (flex_acl_is_using_soft_drop_for_empty_container()) {
            final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E;
        } else {
            final_forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E;
        }
    }

    hw_action->slot.fields.action_trap.forward_action = final_forward_action;

    rc = flex_acl_db_region_get(rule->region_id, &region_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get region id [%u]\n", rule->region_id);
        goto out;
    }

    if ((!ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) && (rule->offset == (region_p->size - 1))) {
        rule_id.offset = SX_ACL_DEFAULT_ACTION_OFFSET;
    } else {
        rule_id.offset = rule->offset;
    }

    rule_id.region_id = rule->region_id;
    acl_drop_trap_enabled = __is_acl_drop_monitor_enabled(rule_id, &entry_type);

    /* For User ACLs we add irrespective of Monitor state as it can be changed at
     * run time. but for System ACL, they must be enabled (done on SDK Init).*/

    if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) ||
        ((entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) && (acl_drop_trap_enabled))) {
        rc = __hw_action_is_fwd_and_acl_drop(hw_action, &found);

        SX_LOG_DBG("%s entry_type = %s , monitoring = %s, found = %s\n", __func__,
                   entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E ? " SYS" : "USR",
                   acl_drop_trap_enabled ? "True" : "False",
                   found ? "True" : "False");
        if (found) {
            /* If user configured FWD + DROP action, Add it to the acl drop trap relocate db.
             * But ensure we do not add any duplicates*/
            if (add_ref) {
                rc = flex_acl_hw_db_acl_drop_relocate_db_add_entry(hw_action->acl_drop_trap_handle,
                                                                   relocation_data.is_head,
                                                                   relocation_data.kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL Drop Trap action failed to add to drop action DB.Region %d Offset %u \n",
                               rule->region_id, rule->offset);
                    goto out;
                }
                SX_LOG_DBG("Added Action to ACL Drop Action db for TRAP, region=%u, off=%u kvd_index=%u\n",
                           FLEX_ACL_DROP_TRAP_HANDLE_TO_REGION(hw_action->acl_drop_trap_handle),
                           FLEX_ACL_DROP_TRAP_HANDLE_TO_OFFSET(hw_action->acl_drop_trap_handle),
                           *(relocation_data.kvd_index_p));
                hw_action->is_ref_count_inc = TRUE;
            }
        } else {
            /* if there was empty container(pbs,mc,uc etc) in the action, the respective bind populate
             * functions added a NULL action block(if a trap block existed).
             * Since we have now merged all the trap actions into 1 block, if there is still
             * no trap being generated and the packet is being dropped,
             * we need to add the ACL drop trap action for those cases here
             */
            if (((final_forward_action == SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E) ||
                 (final_forward_action == SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E)) &&
                (hw_action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E) &&
                (hw_action->acl_drop_trap_handle == 0)) {
                /* save off some mirror state values before adding the acl drop */
                tmp_mirror_enable = hw_action->slot.fields.action_trap.mirror_enable;
                tmp_mirror_agent = hw_action->slot.fields.action_trap.mirror_agent;

                rc = __add_acl_drop_trap_action(hw_action, rule, relocation_data, add_ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error adding ACL DROP Trap action to Rule  RC = %s\n",
                               sx_status_str(rc));
                    goto out;
                }

                /* revert the values */
                hw_action->slot.fields.action_trap.mirror_agent = tmp_mirror_agent;
                hw_action->slot.fields.action_trap.mirror_enable = tmp_mirror_enable;
            }
        }
    }

    if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) &&
        ((hw_action->api_action_type == SX_FLEX_ACL_ACTION_TRAP) ||
         (hw_action->api_action_type == SX_FLEX_ACL_ACTION_TRAP_W_USER_ID))) {
        if (add_ref == TRUE) {
            rc = flex_acl_hw_db_trap_id_add_entry(hw_action->slot.fields.action_trap.trap_id,
                                                  relocation_data.is_head,
                                                  relocation_data.kvd_index_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL Trap action failed to add trap_id [%u] to DB\n",
                           hw_action->slot.fields.action_trap.trap_id);
                goto out;
            }
            hw_action->is_ref_count_inc = TRUE;
        }
    }

    if (!hw_action->slot.fields.action_trap.mirror_enable) {
        goto out;
    }

    SX_LOG_DBG(" Mirror add_ref:%d \n", add_ref);
    if (add_ref) {
        rc = flex_acl_hw_db_mirror_add_entry(hw_action->span_session_id,
                                             relocation_data.is_head,
                                             relocation_data.kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flex_acl_hw_db_span_add_entry failed, span_session_id: %u\n",
                       hw_action->span_session_id);
            goto out;
        }
        SX_LOG_DBG(" Added span session :%d to mirror db\n", hw_action->span_session_id);
    }
    rc = span_session_lock(hw_action->span_user_handle, hw_action->span_session_id, &span_session_id_int);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL span action failed span_session_lock failed, span_session_id: %u\n",
                   hw_action->span_session_id);
        flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
        goto out;
    }
    hw_action->is_locked = TRUE;
    hw_action->slot.fields.action_trap.mirror_agent = span_session_id_int;
    SX_LOG_DBG("FLOWD ACL bind populate : action span is LOCKED,  index:%d \n",
               span_session_id_int);
    if (add_ref) {
        rc = span_session_ref_cnt_inc(hw_action->span_user_handle, hw_action->span_session_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL span action failed span_session_ref_cnt_inc failed id:%d handle:%p\n",
                       hw_action->span_session_id, hw_action->span_user_handle);
            span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
            hw_action->is_locked = FALSE;
            flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
            goto out;
        }
        SX_LOG_DBG("FLOWD ACL bind populate : action span ref INC, id:%d handle:%p \n",
                   hw_action->span_session_id, hw_action->span_user_handle);
        if (hw_action->is_egress_mirror) {
            update_count = 0;
            rc = port_foreach_port(__flex_acl_hw_egress_mirror_allocate_buffer, &update_count);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL counter action failed __flex_acl_hw_egress_mirror_allocate_buffer failed \n");
                port_foreach_port(__flex_acl_hw_egress_mirror_free_buffer, &update_count);
                flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
                span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
                hw_action->is_locked = FALSE;
                span_session_ref_cnt_dec(hw_action->span_user_handle, hw_action->span_session_id);
                goto out;
            }
        }
        hw_action->is_ref_count_inc = TRUE;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __acl_hw_action_mirror_sampler_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                flex_acl_db_flex_rule_t   *rule,
                                                                flex_acl_relocation_data_t relocation_data,
                                                                boolean_t                  add_ref)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t  span_session_id_int;
    flex_acl_db_acl_region_t *region = NULL;
    uint32_t                  update_count;
    boolean_t                 is_egress_mirror_sampler = FALSE;

    UNUSED_PARAM(rule);

    SX_LOG_ENTER();

    SX_LOG_DBG(" Mirror add_ref:%d \n", add_ref);
    if (add_ref) {
        rc = flex_acl_hw_db_mirror_add_entry(hw_action->span_session_id,
                                             relocation_data.is_head,
                                             relocation_data.kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flex_acl_hw_db_span_add_entry failed, span_session_id: %u\n",
                       hw_action->span_session_id);
            goto out;
        }
        SX_LOG_DBG(" Added span session :%d to mirror db\n", hw_action->span_session_id);
    }
    rc = span_session_lock(hw_action->span_user_handle, hw_action->span_session_id, &span_session_id_int);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL span action failed span_session_lock failed, span_session_id: %u\n",
                   hw_action->span_session_id);
        flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
        goto out;
    }

    hw_action->is_locked = TRUE;
    hw_action->slot.fields.action_mirror_sampler.mirror_agent = span_session_id_int;
    hw_action->slot.fields.action_mirror_sampler.mirror_probability_rate = hw_action->mirror_probability_rate;

    SX_LOG_DBG("FLOWD ACL bind populate : action span is LOCKED,  index:%d \n",
               span_session_id_int);
    if (add_ref) {
        rc = span_session_ref_cnt_inc(hw_action->span_user_handle, hw_action->span_session_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL span action failed span_session_ref_cnt_inc failed id:%d handle:%p\n",
                       hw_action->span_session_id, hw_action->span_user_handle);
            span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
            hw_action->is_locked = FALSE;
            flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
            goto out;
        }
        SX_LOG_DBG("FLOWD ACL bind populate : action span ref INC, id:%d handle:%p \n",
                   hw_action->span_session_id, hw_action->span_user_handle);

        /* if egress ACL than need to configure shared buffer for every bound port */
        rc = flex_acl_db_region_get(rule->region_id, &region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed get region id[%d]\n", rule->region_id);
            goto out;
        }

        if (region->direction == SX_ACL_DIRECTION_EGRESS) {
            is_egress_mirror_sampler = TRUE;
        } else if (region->direction == SX_ACL_DIRECTION_MULTI_POINTS_E) {
            if ((region->direction_bitmap & (1 << SX_ACL_DIRECTION_EGRESS)) != 0) {
                is_egress_mirror_sampler = TRUE;
            }
        }

        if (is_egress_mirror_sampler == TRUE) {
            hw_action->is_egress_mirror_sampler = TRUE;
            update_count = 0;
            rc = port_foreach_port(__flex_acl_hw_egress_mirror_allocate_buffer, &update_count);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL MIRROR_SAMPLER action failed __flex_acl_hw_egress_mirror_allocate_buffer failed \n");
                port_foreach_port(__flex_acl_hw_egress_mirror_free_buffer, &update_count);
                flex_acl_hw_db_mirror_remove_entry(hw_action->span_session_id, relocation_data.kvd_index_p);
                span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
                hw_action->is_locked = FALSE;
                span_session_ref_cnt_dec(hw_action->span_user_handle, hw_action->span_session_id);
                goto out;
            }
        }

        hw_action->is_ref_count_inc = TRUE;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_trap_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!hw_action->slot.fields.action_trap.mirror_enable) {
        goto out;
    }

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    rc = span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL CM action failed span_session_unlock failed, span_session_id: %u\n",
                   hw_action->span_session_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    hw_action->is_locked = FALSE;
    SX_LOG_DBG("FLOWD ACL action span UNLOCK id:%d.\n", hw_action->span_session_id);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_mirror_sampler_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    rc = span_session_unlock(hw_action->span_user_handle, hw_action->span_session_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL MIRROR SAMPLER action span_session_unlock failed, span_session_id: %u\n",
                   hw_action->span_session_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    hw_action->is_locked = FALSE;
    SX_LOG_DBG("FLOWD ACL action span UNLOCK id:%d.\n", hw_action->span_session_id);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_qos_populate(sx_flex_acl_flex_action_t action,
                                         boolean_t                 is_defer,
                                         flex_acl_rule_id_t        rule_id,
                                         hw_action_list_t         *hw_action_list_p,
                                         hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();
    hw_action->slot.fields.action_trap.defer = is_defer;
    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_DSCP:
        hw_action->slot.fields.action_qos.dscp_cmd = SXD_FLEX_DSCP_CMD_TYPE_SET_DSCP_6_BITS_E;
        hw_action->slot.fields.action_qos.dscp_val = action.fields.action_set_dscp.dscp_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_PRIO:
        hw_action->slot.fields.action_qos.switch_prio_cmd = SXD_FLEX_SWITCH_PRIO_CMD_TYPE_SET_SWITCH_PRIORITY_E;
        hw_action->slot.fields.action_qos.switch_prio_val = action.fields.action_set_prio.prio_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_TC:
        hw_action->slot.fields.action_qos.traffic_class_cmd = SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_SET_TRAFFIC_CLASS_E;
        hw_action->slot.fields.action_qos.tc = action.fields.action_set_tc.tc_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_COLOR:
        hw_action->slot.fields.action_qos.color_cmd = SXD_FLEX_COLOR_CMD_TYPE_SET_COLOR_E;
        hw_action->slot.fields.action_qos.color_val = action.fields.action_set_color.color_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_ECN:
        hw_action->slot.fields.action_qos.ecn_cmd = SXD_FLEX_ECN_CMD_TYPE_SET_OUTER_ECN_E;
        hw_action->slot.fields.action_qos.ecn_val = action.fields.action_set_ecn.ecn_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE:
        switch (action.fields.action_set_dscp_rewrite.set_rewrite_cmd) {
        case SX_ACL_ACTION_REWRITE_ENABLE:
            hw_action->slot.fields.action_qos.rewrite_dscp_cmd =
                SXD_FLEX_REWRITE_CMD_TYPE_SET_VALUE_REWRITE_ENABLE_BIT_E;
            break;

        case SX_ACL_ACTION_REWRITE_DISABLE:
            hw_action->slot.fields.action_qos.rewrite_dscp_cmd =
                SXD_FLEX_REWRITE_CMD_TYPE_CLEAR_VALUE_REWRITE_ENABLE_BIT_E;
            break;

        default:
            SX_LOG_ERR("SET DSCP Action - invalid set command :%u \n",
                       action.fields.action_set_dscp_rewrite.set_rewrite_cmd);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_PCP_REWRITE:
        switch (action.fields.action_set_pcp_rewrite.set_rewrite_cmd) {
        case SX_ACL_ACTION_REWRITE_ENABLE:
            hw_action->slot.fields.action_qos.rewrite_pcp_cmd =
                SXD_FLEX_REWRITE_CMD_TYPE_SET_VALUE_REWRITE_ENABLE_BIT_E;
            break;

        case SX_ACL_ACTION_REWRITE_DISABLE:
            hw_action->slot.fields.action_qos.rewrite_pcp_cmd =
                SXD_FLEX_REWRITE_CMD_TYPE_CLEAR_VALUE_REWRITE_ENABLE_BIT_E;
            break;

        default:
            SX_LOG_ERR("SET PCP Action - invalid set command :%u \n",
                       action.fields.action_set_pcp_rewrite.set_rewrite_cmd);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t __acl_hw_action_mc_populate(sx_flex_acl_flex_action_t action,
                                        boolean_t                 is_defer,
                                        flex_acl_rule_id_t        rule_id,
                                        hw_action_list_t         *hw_action_list_p,
                                        hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    hwd_rif_id_t          rif_id;
    sx_hw_rpf_group_id_t  hw_rpf_group_id = 0;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->is_defer = is_defer;

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_RPF:
        switch (action.fields.action_rpf.rpf_action) {
        case SX_ACL_RPF_ACTION_TYPE_DISABLED:
            hw_action->aux_slot.fields.action_mc.rpf_action = SXD_MC_FLEX_ACTION_RPF_ACTION_NOP_E;
            break;

        case SX_ACL_RPF_ACTION_TYPE_DROP:
            hw_action->aux_slot.fields.action_mc.rpf_action = SXD_MC_FLEX_ACTION_RPF_ACTION_RPF_DISCARD_ERR_E;
            break;

        case SX_ACL_RPF_ACTION_TYPE_TRAP:
            hw_action->aux_slot.fields.action_mc.rpf_action = SXD_MC_FLEX_ACTION_RPF_ACTION_RPF_TRAP_E;
            break;

        default:
            SX_LOG_ERR("Invalid RPF action :%d \n", action.fields.action_rpf.rpf_action);
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (action.fields.action_rpf.rpf_action == SX_ACL_RPF_ACTION_TYPE_DISABLED) {
            break;
        }
        switch (action.fields.action_rpf.rpf_param.rpf_param_type) {
        case SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF:
            hw_action->aux_slot.fields.action_mc.eir_type = SXD_MC_FLEX_ACTION_EIR_TYPE_IRIF_E;
            rc = sdk_router_cmn_rif_hw_id_get(action.fields.action_rpf.rpf_param.rpf_param_value.rpf_rif, &rif_id);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("RPF RIF param is not valid. rif:%u [%s]\n",
                           action.fields.action_rpf.rpf_param.rpf_param_value.rpf_rif, sx_status_str(rc));
                goto out;
            }
            hw_action->aux_slot.fields.action_mc.expected_irif = (uint16_t)rif_id;
            break;

        case SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP:
            hw_action->aux_slot.fields.action_mc.eir_type = SXD_MC_FLEX_ACTION_EIR_TYPE_IRIF_LIST_E;
            rc = sdk_router_cmn_hw_rpf_group_id_get(action.fields.action_rpf.rpf_param.rpf_param_value.rpf_group,
                                                    &hw_rpf_group_id);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("RPF param is not valid. rpf group :%u [%s]\n",
                           action.fields.action_rpf.rpf_param.rpf_param_value.rpf_group, sx_status_str(rc));
                goto out;
            }

            hw_action->aux_slot.fields.action_mc.expected_irif_list_index = hw_rpf_group_id;
            break;

        default:
            SX_LOG_ERR("Invalid RPF param type :%u \n", action.fields.action_rpf.rpf_param.rpf_param_type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_MC_ROUTE:
        hw_action->mc_container = action.fields.action_mc_route.egress_mc_container;
        break;

    default:
        SX_LOG_ERR("Invalid action type :%d \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t __acl_hw_action_mc_bind_populate(flex_acl_hw_action_t      *hw_action,
                                             flex_acl_db_flex_rule_t   *rule,
                                             flex_acl_relocation_data_t relocation_data,
                                             boolean_t                  add_ref)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    hw_mc_list_pointer_t         erif_list_pointer;
    sx_mc_container_attributes_t attr;
    uint32_t                     next_hop_count;
    boolean_t                    action_found = FALSE;

    SX_LOG_ENTER();

    SX_LOG_DBG(" MC route action add_ref:%d \n", add_ref);
    if (add_ref) {
        rc = flex_acl_hw_db_mc_container_add_entry(hw_action->mc_container,
                                                   relocation_data.is_head,
                                                   relocation_data.kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flex_acl_hw_db_mc_route_add_entry failed, mc_container_id: %u\n",
                       hw_action->mc_container);
            goto out;
        }
        hw_action->is_ref_count_inc = TRUE;
        SX_LOG_DBG(" Added MC container :%d to mc container db\n", hw_action->mc_container);
    }

    rc = sdk_mc_container_impl_get(hw_action->mc_container,
                                   NULL,
                                   &next_hop_count,
                                   NULL,
                                   NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed getting mc container mc list mc:%u [%s]\n",
                   hw_action->mc_container, sx_status_str(rc));
        goto err;
    }
    if (next_hop_count == 0) {
        /* Empty container - The action will be DROP. */
        rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_E, &action_found, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward bind : failed in flex_acl_hw_db_get_action_from_rule mc container:%u\n",
                       hw_action->mc_container);
            goto err;
        }
        if (!action_found) {
            rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E, &action_found, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Action forward bind : failed in flex_acl_hw_db_get_action_from_rule mc container:%u\n",
                           hw_action->mc_container);
                goto err;
            }
        }
        /* If the rule contains TRAP action it will be changed to drop. Another TRAP can not be created
         *  TRAP action will always be the last action according to predefined HW action positioning*/
        if (action_found == TRUE) {
            hw_action->slot.type = SXD_ACTION_TYPE_NULL_E;
            SX_MEM_CLR(hw_action->slot.fields.action_trap);
        } else {
            rc = __add_acl_drop_trap_action(hw_action, rule, relocation_data, add_ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error adding ACL DROP Trap action to Rule  RC = %s\n",
                           sx_status_str(rc));
                goto out;
            }
        }
        goto out;
    }

    hw_action->slot.fields = hw_action->aux_slot.fields;
    hw_action->slot.type = SXD_ACTION_TYPE_MC_E;
    rc = hwd_mc_container_erif_list_get(hw_action->mc_container, &erif_list_pointer, &attr);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed getting mc container mc list mc:%u [%s]\n",
                   hw_action->mc_container, sx_status_str(rc));
        goto err;
    }
    hw_action->slot.fields.action_mc.min_mtu = attr.min_mtu;
    switch (erif_list_pointer.type) {
    case HW_MC_LIST_POINTER_TYPE_RIGR:
        hw_action->slot.fields.action_mc.vrmid = FALSE;
        hw_action->slot.fields.action_mc.rigr_rmid_index = erif_list_pointer.data.rigr_index;
        break;

    case HW_MC_LIST_POINTER_TYPE_RMID:
        hw_action->slot.fields.action_mc.vrmid = TRUE;
        hw_action->slot.fields.action_mc.rigr_rmid_index = erif_list_pointer.data.rmid_index;
        break;

    default:
        SX_LOG_ERR("Invalid erif list type %u \n", erif_list_pointer.type);
        rc = SX_STATUS_ERROR;
        goto err;
    }

    goto out;
err:
    if (add_ref) {
        flex_acl_hw_db_mc_container_remove_entry(hw_action->mc_container, relocation_data.kvd_index_p);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_uc_populate(sx_flex_acl_flex_action_t action,
                                        boolean_t                 is_defer,
                                        flex_acl_rule_id_t        rule_id,
                                        hw_action_list_t         *hw_action_list_p,
                                        hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    boolean_t             is_empty;
    sx_ecmp_attributes_t  ecmp_attributes;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_TUNNEL_DECAP:
        hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E;
        hw_action->tunnel_id = action.fields.action_tunnel_decap.tunnel_id;
        break;

    case SX_FLEX_ACL_ACTION_PBILM:
        hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E;
        hw_action->pbilm_id = action.fields.action_pbilm.pbilm_id;
        break;

    case SX_FLEX_ACL_ACTION_UC_ROUTE:
        switch (action.fields.action_uc_route.uc_route_type) {
        case SX_UC_ROUTE_TYPE_LOCAL:
            hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E;
            hw_action->rif = action.fields.action_uc_route.uc_route_param.local_egress_rif;
            break;

        case SX_UC_ROUTE_TYPE_NEXT_HOP:
            hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E;
            hw_action->ecmp = action.fields.action_uc_route.uc_route_param.ecmp_id;

            rc = sdk_router_ecmp_impl_attributes_get(hw_action->ecmp, &ecmp_attributes);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed to get attributes for ECMP %u.\n", hw_action->ecmp);
                goto out;
            }
            /* Preserve the container type to be used later */
            hw_action->ecmp_container_type = ecmp_attributes.container_type;
            /* Get handle to the ecmp kvdl handle */
            rc = sdk_router_ecmp_impl_active_set_get(hw_action->ecmp,
                                                     &(hw_action->ecmp_block_handle),
                                                     &is_empty);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ECMP %u is not valid.\n", hw_action->ecmp);
                goto out;
            }
            break;

        default:
            SX_LOG_ERR("Invalid UC route action type :%u\n", action.fields.action_uc_route.uc_route_type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_AR_UC_ROUTE:
        hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E;
        hw_action->ecmp = action.fields.action_ar_uc_route.ecmp_id;
        hw_action->ar_profile_id = action.fields.action_ar_uc_route.profile_id;

        /* Get handle to the ecmp kvd handle */
        rc = sdk_router_ecmp_impl_active_set_get(hw_action->ecmp,
                                                 &(hw_action->ecmp_block_handle),
                                                 &is_empty);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ECMP %u is not valid.\n", hw_action->ecmp);
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_NAT:
        hw_action->aux_slot.fields.action_uc_router.type = SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E;
        hw_action->nat_id = action.fields.action_nat.nat_id;
        break;

    default:
        SX_LOG_ERR("Invalid action type :%u\n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __is_mac_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                          flex_acl_hw_action_t      *hw_action,
                                          int32_t                    relative_position)
{
    boolean_t reuse = TRUE;

    UNUSED_PARAM(relative_position);

    if (((action->type == SX_FLEX_ACL_ACTION_SET_DST_MAC) || (action->type == SX_FLEX_ACL_ACTION_SET_SRC_MAC)) &&
        (hw_action->slot.fields.action_mac.mac_cmd != SXD_FLEX_MAC_CMD_TYPE_DO_NOTHING_E)) {
        reuse = FALSE;
    }

    return reuse;
}

static boolean_t __is_mpls_hw_action_reuse(sx_flex_acl_flex_action_t *action,
                                           flex_acl_hw_action_t      *hw_action,
                                           int32_t                    relative_position)
{
    boolean_t reuse = TRUE;

    UNUSED_PARAM(relative_position);

    if (((action->type == SX_FLEX_ACL_ACTION_SET_MPLS_TTL) || (action->type == SX_FLEX_ACL_ACTION_DEC_MPLS_TTL)) &&
        (hw_action->slot.fields.action_mpls.ttl_cmd != SXD_MPLS_FLEX_ACTION_TTL_CMD_TYPE_DO_NOTING_E)) {
        reuse = FALSE;
    }

    return reuse;
}

static hw_action_position_e __acl_hw_action_counter_policer_position(sx_flex_acl_flex_action_t *action_p,
                                                                     sxd_flex_acl_action_type_t hw_action_type)
{
    UNUSED_PARAM(hw_action_type);

    if (action_p->type == SX_FLEX_ACL_ACTION_POLICER) {
        return FLEX_ACL_HW_ACTION_POSITION_END_E;
    }
    return FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E;
}


sx_status_t __acl_hw_action_truncation_populate(sx_flex_acl_flex_action_t action,
                                                boolean_t                 is_defer,
                                                flex_acl_rule_id_t        rule_id,
                                                hw_action_list_t         *hw_action_list_p,
                                                hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);
    UNUSED_PARAM(is_defer);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_truncation.trunc_en = action.fields.action_truncation.trunc_en;
    hw_action->slot.fields.action_truncation.trunc_profile_id =
        action.fields.action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id;

    SX_LOG_EXIT();

    return SX_STATUS_SUCCESS;
}

sx_status_t __acl_hw_action_counter_policer_populate(sx_flex_acl_flex_action_t action,
                                                     boolean_t                 is_defer,
                                                     flex_acl_rule_id_t        rule_id,
                                                     hw_action_list_t         *hw_action_list_p,
                                                     hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_POLICER:
        hw_action->slot.fields.action_policing_monitoring.c_p = SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E;
        hw_action->policer_id = action.fields.action_policer.policer_id;
        break;

    case SX_FLEX_ACL_ACTION_COUNTER:
        hw_action->slot.fields.action_policing_monitoring.c_p = SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E;
        hw_action->counter_id = action.fields.action_counter.counter_id;
        break;

    default:
        SX_LOG_ERR("ACL counter action failed invalid action type: %u\n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_mac_populate(sx_flex_acl_flex_action_t action,
                                         boolean_t                 is_defer,
                                         flex_acl_rule_id_t        rule_id,
                                         hw_action_list_t         *hw_action_list_p,
                                         hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_mac.defer = is_defer;
    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_SRC_MAC:
        hw_action->slot.fields.action_mac.mac_cmd = SXD_FLEX_MAC_CMD_TYPE_SET_SMAC_E;
        memcpy(hw_action->slot.fields.action_mac.mac, &(action.fields.action_set_src_mac.mac), 6);
        break;

    case SX_FLEX_ACL_ACTION_SET_DST_MAC:
        hw_action->slot.fields.action_mac.mac_cmd = SXD_FLEX_MAC_CMD_TYPE_SET_DMAC_E;
        memcpy(hw_action->slot.fields.action_mac.mac, &(action.fields.action_set_dst_mac.mac), 6);
        break;

    case SX_FLEX_ACL_ACTION_DEC_TTL:
        hw_action->slot.fields.action_mac.ttl_cmd = SXD_FLEX_TTL_CMD_DECREMENT_E;
        hw_action->slot.fields.action_mac.ttl_value = action.fields.action_dec_ttl.ttl_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_TTL:
        hw_action->slot.fields.action_mac.ttl_cmd = SXD_FLEX_TTL_CMD_SET_TTL_VALUE_E;
        hw_action->slot.fields.action_mac.ttl_value = action.fields.action_set_ttl.ttl_val;
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_virtual_forward_populate(sx_flex_acl_flex_action_t action,
                                                     boolean_t                 is_defer,
                                                     flex_acl_rule_id_t        rule_id,
                                                     hw_action_list_t         *hw_action_list_p,
                                                     hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_fm_fid_type_t      fid_type = SX_FM_FID_TYPE_INVALID;
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);
    UNUSED_PARAM(is_defer);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_BRIDGE:
        hw_action->slot.fields.action_virtual_forward.fid_cmd =
            SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_SET_FID_TO_PACKET_E;

        rc = sdk_fid_manager_get_fid_type(action.fields.action_set_bridge.bridge_id, &fid_type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get fid (%u) type. rc=[%s]\n",
                       action.fields.action_set_bridge.bridge_id, sx_status_str(rc));
            goto out;
        }

        if ((fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E) && (fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E)) {
            SX_LOG_ERR("Invalid fid [%u] type (%s) is used.\n",
                       action.fields.action_set_bridge.bridge_id, sx_fm_fid_type_str(fid_type));
            rc = SX_STATUS_ERROR;
            goto out;
        }

        rc = sdk_fid_manager_get_hwfid_by_fid(action.fields.action_set_bridge.bridge_id,
                                              &hw_action->slot.fields.action_virtual_forward.fid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL: Failed to get hwFid for fid:[%u]. rc=[%s]\n",
                       action.fields.action_set_bridge.bridge_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_ROUTER:
        hw_action->slot.fields.action_virtual_forward.vr_cmd =
            SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_SET_VR_TO_PACKET_E;
        hw_action->slot.fields.action_virtual_forward.virtual_router = action.fields.action_set_router.vrid;
        break;

    default:
        SX_LOG_ERR("Virtual_forward_populate invalid action type:%u \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t __acl_hw_action_meta_data_populate(sx_flex_acl_flex_action_t action,
                                               boolean_t                 is_defer,
                                               flex_acl_rule_id_t        rule_id,
                                               hw_action_list_t         *hw_action_list_p,
                                               hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);
    UNUSED_PARAM(is_defer);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_metadata.meta_data = hw_action->action_modifier ==
                                                       FLEX_ACL_ACTION_MODEFIER_IGMPV3_PBS_E ?
                                                       ACL_SYSTEM_IGMPV3_PBS_TOKEN : action.fields.
                                                       action_set_user_token.user_token;
    hw_action->slot.fields.action_metadata.mask = hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_IGMPV3_PBS_E ?
                                                  ACL_SYSTEM_TOKEN_MASK : action.fields.action_set_user_token.mask;

    SX_LOG_EXIT();

    return SX_STATUS_SUCCESS;
}

sx_status_t __acl_hw_action_ignore_populate(sx_flex_acl_flex_action_t action,
                                            boolean_t                 is_defer,
                                            flex_acl_rule_id_t        rule_id,
                                            hw_action_list_t         *hw_action_list_p,
                                            hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_DONT_LEARN:
        hw_action->slot.fields.action_ignore.disable_learning =
            SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_DISABLE_LEARNING_E;
        break;

    case SX_FLEX_ACL_ACTION_DISABLE_FDB_SECURITY:
        hw_action->slot.fields.action_ignore.disable_fdb_security =
            SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_FDB_SECURITY_TYPE_DISABLE_SECURITY_E;
        break;

    case SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER:
        hw_action->slot.fields.action_ignore.ignore_vl_filter =
            SXD_IGNORE_FLEX_ACTION_IGNORE_VL_TYPE_IGNORE_VLAN_E;
        break;

    case SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER:
        hw_action->slot.fields.action_ignore.ignore_stp =
            (sxd_ignore_flex_action_ignore_stp_type_t)SXD_IGNORE_FLEX_ACTION_IGNORE_VL_TYPE_IGNORE_VLAN_E;
        break;

    case SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING:
        hw_action->slot.fields.action_ignore.disable_ovl_learning =
            SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_DISABLE_LEARNING_E;
        break;

    case SX_FLEX_ACL_ACTION_ELEPHANT_SET:
        hw_action->slot.fields.action_ignore.set_elephant_flow =
            (sxd_ignore_flex_action_set_elephant_flow_type_t)(action.fields.action_set_elephant_flow_type.action);
        break;

    case SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE:
        hw_action->slot.fields.action_ignore.ar_packet_prof_id =
            (sxd_ar_lookup_profile_id_t)(action.fields.action_ar_packet_profile.ar_packet_profile_type);
        hw_action->slot.fields.action_ignore.ar_packet_prof_cmd = SXD_IGNORE_FLEX_ACTION_IGNORE_AR_PACKET_PROF_SET_E;
        break;

    case SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW:
        span_mt_list_to_flex_action_cond_mirror_bitmap(&(action.fields.action_mirror_disallow.cfg_list),
                                                       &(hw_action->slot.fields.action_ignore.cond_mirror));
        break;

    default:
        SX_LOG_ERR("Invalid action type %d \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

static hw_action_position_e __acl_hw_action_position_forward(sx_flex_acl_flex_action_t *action_p,
                                                             sxd_flex_acl_action_type_t hw_action_type)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    sx_acl_pbs_id_t          pbs_id;
    hw_action_position_e     position = FLEX_ACL_HW_ACTION_POSITION_INVALID_E;
    sx_swid_t                swid = 0;

    UNUSED_PARAM(hw_action_type);

    SX_LOG_ENTER();

    switch (action_p->type) {
    case SX_FLEX_ACL_ACTION_PBS:
        pbs_id = action_p->fields.action_pbs.pbs_id;
        rc = flex_acl_db_pbs_get_entry(swid, pbs_id, &pbs_entry);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to find PBS  ID [%u]\n", pbs_id);
            goto out;
        }

        if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST) ||
            (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
            position = FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E;
        } else {
            position = FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E;
        }
        break;

    case SX_FLEX_ACL_ACTION_MC:
        position = FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E;
        break;

    case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
    case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
        position = FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E;
        break;

    default:
        SX_LOG_ERR("Invalid API action type %d for forward HW action\n", action_p->type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return position;
}

sx_status_t __acl_hw_action_forward_mc_ref(sx_mc_container_id_t           mc_container_id,
                                           flex_acl_hw_action_t          *hw_action,
                                           sx_flex_acl_flex_action_type_t api_action_type,
                                           flex_acl_rule_id_t             rule_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 ref_count;
    sx_acl_pbs_id_t          pbs_id;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    rc = flex_acl_db_pbs_mc_get(mc_container_id, &pbs_id, &ref_count, api_action_type);
    if ((SX_STATUS_ENTRY_NOT_FOUND != rc) && (SX_STATUS_SUCCESS != rc)) {
        SX_LOG_ERR("ACL action forward populate. flex_acl_db_pbs_mc_get failed, mc_container_id: %u.\n",
                   mc_container_id);
        goto out;
    }
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        /* Add PBS */
        rc = flex_acl_mc_container_pbs_add(mc_container_id, &pbs_id, api_action_type);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action forward populate. flex_acl_mc_container_pbs_add failed, mc_container_id: %u.\n",
                       mc_container_id);
            goto out;
        }
        rc = flex_acl_db_pbs_mc_create(mc_container_id, pbs_id, api_action_type);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR(
                "ACL action forward populate. flex_acl_db_pbs_mc_create failed, mc_container_id: %u, pbs_id: %u.\n",
                mc_container_id,
                pbs_id);
            goto out;
        }
        rc = flex_acl_db_pbs_update_ref_count(0, pbs_id, TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to increment PBS [%u]\n", pbs_id);
            goto out;
        }
    }
    rc = flex_acl_db_pbs_mc_ref_inc(mc_container_id, api_action_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Action forward : failed to increment MC PBS [%u]\n", mc_container_id);
        goto out;
    }
    hw_action->pbs_id = pbs_id;
    rc = flex_acl_db_pbs_get_entry(0, hw_action->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Action forward : failed to find PBS  ID [%u]\n", hw_action->pbs_id);
        goto out;
    }
    hw_action->pbs_kvd_handle = pbs_entry->kvd_handle;
    hw_action->mc_container = mc_container_id;

    if (api_action_type == SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP) {
        rc = flex_acl_db_pbs_add_rule_to_list(pbs_entry, rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to add rule to list in PBS [%u]\n",
                       pbs_id);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_forward_ecmp_ref(sx_ecmp_id_t                   ecmp_id,
                                             flex_acl_hw_action_t          *hw_action_p,
                                             sx_flex_acl_flex_action_type_t api_action_type,
                                             flex_acl_rule_id_t             rule_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    uint32_t                   ref_count = 0;
    sx_acl_pbs_id_t            pbs_id = SX_ACL_PBS_ID_INVALID;
    flex_acl_db_pbs_entry_t   *pbs_entry_p = NULL;
    boolean_t                  is_empty = FALSE;
    hwi_ecmp_hw_block_handle_t ecmp_handle = INVALID_ECMP_BLOCK_HANDLE;
    sx_ecmp_attributes_t       ecmp_attributes;

    UNUSED_PARAM(rule_id);
    SX_MEM_CLR(ecmp_attributes);

    /* Get ECMP handle and container type */
    rc = sdk_router_ecmp_impl_active_set_get(ecmp_id,
                                             &ecmp_handle,
                                             &is_empty);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get ECMP properties [ECMP ID = %u; error = %s].\n",
                   ecmp_id, sx_status_str(rc));
        goto out;
    }

    /* Check if ECMP record already exist */
    rc = flex_acl_db_pbs_ecmp_get(ecmp_handle, &pbs_id, &ref_count, api_action_type);
    if ((SX_STATUS_ENTRY_NOT_FOUND != rc) && (SX_STATUS_SUCCESS != rc)) {
        SX_LOG_ERR("Failed to get ECMP map item. [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                   ecmp_handle, sx_status_str(rc));
        goto out;
    }

    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        /* Create new PBS record, add ECMP ID and push into HW */
        rc = flex_acl_ecmp_container_pbs_add(ecmp_id, &pbs_id, api_action_type);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to create PBS DB record [ECMP ID = %u; error = %s].\n",
                       ecmp_id, sx_status_str(rc));
            goto out;
        }

        /* Create new record to ECMP DB */
        rc = flex_acl_db_pbs_ecmp_create(ecmp_handle, pbs_id, api_action_type);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to create ECMP DB record [ECMP handle = %u; PBS ID = %u; error = %s].\n",
                       ecmp_id, pbs_id, sx_status_str(rc));
            goto out;
        }
    }

    /* Increment ref counter to ECMP ID record */
    rc = flex_acl_db_pbs_ecmp_ref_inc(ecmp_handle, api_action_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to increment ECMP map refcount [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                   ecmp_handle, sx_status_str(rc));
        goto out;
    }

    /* Copy PBS ID and get PBS record from DB */
    hw_action_p->pbs_id = pbs_id;
    rc = flex_acl_db_pbs_get_entry(0, hw_action_p->pbs_id, &pbs_entry_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get PBS entry [PBS ID = %u; error = %s].\n",
                   hw_action_p->pbs_id, sx_status_str(rc));
        goto out;
    }

    /* Get ECMP container attributes */
    rc = sdk_router_ecmp_impl_attributes_get(ecmp_id, &ecmp_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed to get attributes from ECMP %u \n", ecmp_id);
        goto out;
    }

    hw_action_p->pbs_kvd_handle = pbs_entry_p->kvd_handle;
    hw_action_p->ecmp = ecmp_id;
    hw_action_p->ecmp_block_handle = ecmp_handle;
    hw_action_p->ecmp_container_type = ecmp_attributes.container_type;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_forward_tun_ref(sx_ip_next_hop_ip_tunnel_t    *tunnel_info_p,
                                            flex_acl_hw_action_t          *hw_action_p,
                                            sx_flex_acl_flex_action_type_t api_action_type,
                                            flex_acl_rule_id_t             rule_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 ref_count = 0;
    flex_acl_db_pbs_entry_t *pbs_entry_p = NULL;
    sx_acl_pbs_id_t          pbs_id = SX_ACL_PBS_ID_INVALID;


    UNUSED_PARAM(api_action_type);
    UNUSED_PARAM(rule_id);

    /* Check if Tunnel PBS record exist */
    rc = flex_acl_db_pbs_nve_get(*tunnel_info_p, &pbs_id, &ref_count);
    if ((SX_STATUS_ENTRY_NOT_FOUND != rc) && (SX_STATUS_SUCCESS != rc)) {
        SX_LOG_ERR("Failed to get NVE DB record [Tunnel ID = %u; error = %s].\n",
                   tunnel_info_p->tunnel_id, sx_status_str(rc));
        goto out;
    }

    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        /* Create new PBS record */
        rc = flex_acl_nve_tunnel_pbs_add(*tunnel_info_p, &pbs_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to create PBS record [Tunnel ID = %u; error = %s].\n",
                       tunnel_info_p->tunnel_id, sx_status_str(rc));
            goto out;
        }

        /* Create new Tunnel record */
        rc = flex_acl_db_pbs_nve_create(*tunnel_info_p, pbs_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR(
                "Failed to create Tunnel DB record [Tunnel ID = %u; PBS ID = %u; error = %s].\n",
                tunnel_info_p->tunnel_id, pbs_id, sx_status_str(rc));
            goto out;
        }

        /* Increment PBS reference counter */
        rc = flex_acl_db_pbs_update_ref_count(0, pbs_id, TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to increment PBS refcount [PBS ID = %u; error = %s].\n",
                       pbs_id, sx_status_str(rc));
            goto out;
        }
    }

    /* Increment tunnel reference counter */
    rc = flex_acl_db_pbs_nve_ref_inc(*tunnel_info_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to increment NVE refcount [Tunnel ID = %u; error = %s].\n",
                   tunnel_info_p->tunnel_id, sx_status_str(rc));
        goto out;
    }

    /* Get KVD handle */
    hw_action_p->pbs_id = pbs_id;
    rc = flex_acl_db_pbs_get_entry(0, hw_action_p->pbs_id, &pbs_entry_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get KVD handle [PBS ID = %u; error = %s].\n",
                   hw_action_p->pbs_id, sx_status_str(rc));
        goto out;
    }

    hw_action_p->pbs_kvd_handle = pbs_entry_p->kvd_handle;
    hw_action_p->ip_tunnel_id = *tunnel_info_p;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_forward_populate(sx_flex_acl_flex_action_t action,
                                             boolean_t                 is_defer,
                                             flex_acl_rule_id_t        rule_id,
                                             hw_action_list_t         *hw_action_list_p,
                                             hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t   *pbs_entry = NULL;
    sx_ip_next_hop_ip_tunnel_t tunnel_info;
    flex_acl_hw_action_t      *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->is_defer = is_defer;

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_PBS:
        hw_action->pbs_id = action.fields.action_pbs.pbs_id;
        SX_LOG_DBG("ACL Populates action PBS pbs_id:%d \n", action.fields.action_pbs.pbs_id);
        rc = flex_acl_db_pbs_get_entry(0, hw_action->pbs_id, &pbs_entry);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to find PBS  ID [%u]\n", hw_action->pbs_id);
            goto out;
        }

        if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST) ||
            (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
            hw_action->slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E;
            hw_action->aux_slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E;
        } else {
            hw_action->slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E;
            hw_action->aux_slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E;
        }
        hw_action->pbs_kvd_handle = pbs_entry->kvd_handle;
        break;

    case SX_FLEX_ACL_ACTION_MC:
        rc = __acl_hw_action_forward_mc_ref(action.fields.action_mc.mc_container_id,
                                            hw_action, action.type, rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to increment MC PBS [%u]\n",
                       action.fields.action_mc.mc_container_id);
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
        /* Check type of tunneling flow */
        if (action.fields.action_nve_tunnel_encap.encap_type ==
            SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP) {
            /* Increment Tunnel reference counter and set hw_action fields */
            tunnel_info.tunnel_id = action.fields.action_nve_tunnel_encap.tunnel_id;
            tunnel_info.underlay_dip = action.fields.action_nve_tunnel_encap.underlay_dip;

            rc = __acl_hw_action_forward_tun_ref(&tunnel_info, hw_action, action.type, rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to configure tunnel entry [Tunnel ID = %u; error = %s].\n",
                           tunnel_info.tunnel_id, sx_status_str(rc));
                goto out;
            }
        } else if (action.fields.action_nve_tunnel_encap.encap_type ==
                   SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP) {
            /* Increment ECMP reference counter and set hw_action fields */
            rc = __acl_hw_action_forward_ecmp_ref(action.fields.action_nve_tunnel_encap.ecmp_id,
                                                  hw_action, action.type, rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to configure ECMP entry [ECMP ID = %u; error = %s].\n",
                           action.fields.action_nve_tunnel_encap.ecmp_id, sx_status_str(rc));
                goto out;
            }
        }
        hw_action->aux_slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E;
        break;

    case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
        rc = __acl_hw_action_forward_mc_ref(action.fields.action_nve_mc_tunnel_encap.mc_container_id,
                                            hw_action, action.type, rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to increment MC PBS [%u]\n",
                       action.fields.action_nve_mc_tunnel_encap.mc_container_id);
            goto out;
        }
        hw_action->aux_slot.fields.action_forward.type = SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E;
        break;

    default:
        SX_LOG_ERR("Invalid API action type %d for forward HW action\n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_forward_rollback(flex_acl_rule_id_t rule_id, flex_acl_hw_action_t *hw_action)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    UNUSED_PARAM(rule_id);

    SX_LOG_ENTER();

    switch (hw_action->slot.fields.action_forward.type) {
    case SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E:
    case SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E:
        rc = flex_acl_db_pbs_get_entry(0, hw_action->pbs_id, &pbs_entry);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward : failed to find PBS  ID [%u]\n", hw_action->pbs_id);
        }
        if (pbs_entry && pbs_entry->is_system) {
            if (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) {
                rc = flex_acl_clean_mc_container_action(hw_action->mc_container,
                                                        SX_FLEX_ACL_ACTION_MC,
                                                        rule_id);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL MC action failed flex_acl_clean_mc_container_action failed, mc_container_id: %u\n",
                               hw_action->mc_container);
                    goto out;
                }
            } else if (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_LAST) {
                switch (pbs_entry->extended_entry_type) {
                case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL:
                    rc = flex_acl_clean_nve_action(hw_action->ip_tunnel_id);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("ACL MC action failed flex_acl_clean_nve_action failed, tunnel ID: %u\n",
                                   hw_action->ip_tunnel_id.tunnel_id);
                        goto out;
                    }
                    break;

                case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_MULTICAST_TUNNEL:
                    rc = flex_acl_clean_mc_container_action(hw_action->mc_container,
                                                            SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP,
                                                            rule_id);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR(
                            "ACL MC action failed flex_acl_clean_mc_container_action failed, mc_container_id: %u\n",
                            hw_action->mc_container);
                        goto out;
                    }
                    break;

                case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP:
                    rc = flex_acl_clean_ecmp_action(hw_action->ecmp_block_handle,
                                                    SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP,
                                                    rule_id);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("Failed to clean ECMP entry [ECMP ID = %u; error = %s].\n",
                                   hw_action->ecmp, sx_status_str(rc));
                        goto out;
                    }
                    break;

                default:
                    break;
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("ACL action forwards. Invalid forward action type :%d \n",
                   hw_action->slot.fields.action_forward.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_mpls_populate(sx_flex_acl_flex_action_t action,
                                          boolean_t                 is_defer,
                                          flex_acl_rule_id_t        rule_id,
                                          hw_action_list_t         *hw_action_list_p,
                                          hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);
    UNUSED_PARAM(is_defer);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_EXP:
        hw_action->slot.fields.action_mpls.exp_cmd = SXD_MPLS_FLEX_ACTION_EXP_CMD_TYPE_SET_EXP_E;
        hw_action->slot.fields.action_mpls.exp = action.fields.action_set_exp.exp_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_EXP_REWRITE:
        switch (action.fields.action_set_exp_rewrite.set_rewrite_cmd) {
        case SX_ACL_ACTION_REWRITE_ENABLE:
            hw_action->slot.fields.action_mpls.exp_rw =
                SXD_MPLS_FLEX_ACTION_EXP_CMD_TYPE_SET_REWRITE_BIT_E;
            break;

        case SX_ACL_ACTION_REWRITE_DISABLE:
            hw_action->slot.fields.action_mpls.exp_rw =
                SXD_MPLS_FLEX_ACTION_EXP_CMD_TYPE_CLEAR_REWRITE_BIT_E;
            break;

        default:
            SX_LOG_ERR("SET EXP Action - invalid set command :%u \n",
                       action.fields.action_set_exp_rewrite.set_rewrite_cmd);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_FLEX_ACL_ACTION_DEC_MPLS_TTL:
        hw_action->slot.fields.action_mpls.ttl_cmd = SXD_MPLS_FLEX_ACTION_TTL_CMD_TYPE_DECREMENT_BY_TTL_E;
        hw_action->slot.fields.action_mpls.ttl = action.fields.action_dec_mpls_ttl.ttl_val;
        break;

    case SX_FLEX_ACL_ACTION_SET_MPLS_TTL:
        hw_action->slot.fields.action_mpls.ttl_cmd = SXD_MPLS_FLEX_ACTION_TTL_CMD_TYPE_SET_TTL_E;
        hw_action->slot.fields.action_mpls.ttl = action.fields.action_set_mpls_ttl.ttl_val;
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __acl_hw_action_sip_dip_populate(sx_flex_acl_flex_action_t action,
                                             boolean_t                 is_defer,
                                             flex_acl_rule_id_t        rule_id,
                                             hw_action_list_t         *hw_action_list_p,
                                             hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_sip_dip.defer = is_defer;

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_SIP_ADDR:
        hw_action->slot.fields.action_sip_dip.ip_31_0 = action.fields.action_set_sip.ip_addr.addr.ipv4.s_addr;
        hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_SOURCE_E;
        hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        break;

    case SX_FLEX_ACL_ACTION_SET_DIP_ADDR:
        hw_action->slot.fields.action_sip_dip.ip_31_0 = action.fields.action_set_dip.ip_addr.addr.ipv4.s_addr;
        hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E;
        hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        break;

    case SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR:
        if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_IPV6_MSB_E) {
            hw_action->slot.fields.action_sip_dip.ip_63_32 =
                action.fields.action_set_sip.ip_addr.addr.ipv6.s6_addr32[0];
            hw_action->slot.fields.action_sip_dip.ip_31_0 =
                action.fields.action_set_sip.ip_addr.addr.ipv6.s6_addr32[1];
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_MSB_E;
        } else {
            hw_action->slot.fields.action_sip_dip.ip_63_32 =
                action.fields.action_set_sip.ip_addr.addr.ipv6.s6_addr32[2];
            hw_action->slot.fields.action_sip_dip.ip_31_0 =
                action.fields.action_set_sip.ip_addr.addr.ipv6.s6_addr32[3];
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        }
        hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_SOURCE_E;
        break;

    case SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR:
        if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_IPV6_MSB_E) {
            hw_action->slot.fields.action_sip_dip.ip_63_32 =
                action.fields.action_set_dip.ip_addr.addr.ipv6.s6_addr32[0];
            hw_action->slot.fields.action_sip_dip.ip_31_0 =
                action.fields.action_set_dip.ip_addr.addr.ipv6.s6_addr32[1];
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_MSB_E;
        } else {
            hw_action->slot.fields.action_sip_dip.ip_63_32 =
                action.fields.action_set_dip.ip_addr.addr.ipv6.s6_addr32[2];
            hw_action->slot.fields.action_sip_dip.ip_31_0 =
                action.fields.action_set_dip.ip_addr.addr.ipv6.s6_addr32[3];
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        }
        hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E;
        break;

    case SX_FLEX_ACL_ACTION_NAT:
        /* The NAT implementation requires that the actions will not be performed immediately, it should be deferred.
         * The commit action will be done by an ACL bound to the irif after the NAT.
         */
        hw_action->slot.fields.action_sip_dip.defer = TRUE;
        if ((hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_SIP_LSB_E) &&
            (action.fields.action_nat.sip.version == SX_IP_VERSION_IPV4)) {
            hw_action->slot.fields.action_sip_dip.ip_31_0 = action.fields.action_nat.sip.addr.ipv4.s_addr;
            hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_SOURCE_E;
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        }
        if ((hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_DIP_LSB_E) &&
            (action.fields.action_nat.dip.version == SX_IP_VERSION_IPV4)) {
            hw_action->slot.fields.action_sip_dip.ip_31_0 = action.fields.action_nat.dip.addr.ipv4.s_addr;
            hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E;
            hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
        }
        if (action.fields.action_nat.sip.version == SX_IP_VERSION_IPV6) {
            if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_SIP_MSB_E) {
                hw_action->slot.fields.action_sip_dip.ip_63_32 =
                    action.fields.action_nat.sip.addr.ipv6.s6_addr32[0];
                hw_action->slot.fields.action_sip_dip.ip_31_0 =
                    action.fields.action_nat.sip.addr.ipv6.s6_addr32[1];
                hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_MSB_E;
                hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_SOURCE_E;
            }
            if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_SIP_LSB_E) {
                hw_action->slot.fields.action_sip_dip.ip_63_32 =
                    action.fields.action_nat.sip.addr.ipv6.s6_addr32[2];
                hw_action->slot.fields.action_sip_dip.ip_31_0 =
                    action.fields.action_nat.sip.addr.ipv6.s6_addr32[3];
                hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
                hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_SOURCE_E;
            }
        }
        if (action.fields.action_nat.dip.version == SX_IP_VERSION_IPV6) {
            if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_DIP_MSB_E) {
                hw_action->slot.fields.action_sip_dip.ip_63_32 =
                    action.fields.action_nat.dip.addr.ipv6.s6_addr32[0];
                hw_action->slot.fields.action_sip_dip.ip_31_0 =
                    action.fields.action_nat.dip.addr.ipv6.s6_addr32[1];
                hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_MSB_E;
                hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E;
            }
            if (hw_action->action_modifier == FLEX_ACL_ACTION_MODEFIER_NAT_DIP_LSB_E) {
                hw_action->slot.fields.action_sip_dip.ip_63_32 =
                    action.fields.action_nat.dip.addr.ipv6.s6_addr32[2];
                hw_action->slot.fields.action_sip_dip.ip_31_0 =
                    action.fields.action_nat.dip.addr.ipv6.s6_addr32[3];
                hw_action->slot.fields.action_sip_dip.bytes = SXD_SIP_DIP_FLEX_ACTION_BYTES_LSB_E;
                hw_action->slot.fields.action_sip_dip.direction = SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E;
            }
        }

        break;

    default:
        SX_LOG_ERR("ACL action sip-dip. Invalid action type :%s \n", ACTION_ID_2STR(action.type));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_l4_port_populate(sx_flex_acl_flex_action_t action,
                                             boolean_t                 is_defer,
                                             flex_acl_rule_id_t        rule_id,
                                             hw_action_list_t         *hw_action_list_p,
                                             hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    hw_action->slot.fields.action_l4_port.defer = is_defer;

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT:
        hw_action->slot.fields.action_l4_port.l4_port = action.fields.action_set_l4_src_port.l4_port;
        hw_action->slot.fields.action_l4_port.direction = SXD_L4_PORT_FLEX_ACTION_DIRECTION_SOURCE_E;
        break;

    case SX_FLEX_ACL_ACTION_SET_L4_DST_PORT:
        hw_action->slot.fields.action_l4_port.l4_port = action.fields.action_set_l4_dst_port.l4_port;
        hw_action->slot.fields.action_l4_port.direction = SXD_L4_PORT_FLEX_ACTION_DIRECTION_DESTINATION_E;
        break;

    default:
        SX_LOG_ERR("ACL action l4 port . Invalid action type :%s \n", ACTION_ID_2STR(action.type));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_hash_populate(sx_flex_acl_flex_action_t action,
                                          boolean_t                 is_defer,
                                          flex_acl_rule_id_t        rule_id,
                                          hw_action_list_t         *hw_action_list_p,
                                          hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint32_t              i = 0, ipv6_idx = 0;
    uint32_t              hash_mask = 0;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_HASH:
        hw_action->slot.fields.action_hash.type = (sxd_hash_flex_action_type_t)(action.fields.action_hash.type);
        hw_action->slot.fields.action_hash.hash_cmd = (sxd_hash_flex_action_cmd_t)(action.fields.action_hash.command);
        if ((action.fields.action_hash.command == SX_ACL_ACTION_HASH_COMMAND_XOR) ||
            (action.fields.action_hash.command == SX_ACL_ACTION_HASH_COMMAND_SET)) {
            hw_action->slot.fields.action_hash.hash_value = action.fields.action_hash.hash_value;
        }
        if (action.fields.action_hash.command == SX_ACL_ACTION_HASH_COMMAND_CRC) {
            /* For CRC action we might need to fill more than one action */
            for (i = 0; i < map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions_count; i++) {
                hw_action->slot.fields.action_hash.type =
                    (sxd_hash_flex_action_type_t)(action.fields.action_hash.type);
                hw_action->slot.fields.action_hash.hash_cmd =
                    (sxd_hash_flex_action_cmd_t)(action.fields.action_hash.command);
                hw_action->slot.fields.action_hash.hash_fields =
                    map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions[i];

                switch (action.fields.action_hash.hash_crc.field) {
                case SX_ACL_ACTION_HASH_FIELD_SMAC:
                    if (hw_action->slot.fields.action_hash.hash_fields ==
                        SXD_HASH_FLEX_ACTION_HASH_FIELD_SMAC_31_0_E) {
                        SX_MEM_CPY_BUF(&hw_action->slot.fields.action_hash.hash_mask,
                                       &action.fields.action_hash.hash_crc.mask.smac.ether_addr_octet[2],
                                       4);
                        /* We need to inverse byte order to comply with HW order */
                        hw_action->slot.fields.action_hash.hash_mask = cl_hton32(
                            hw_action->slot.fields.action_hash.hash_mask);
                    } else {
                        SX_MEM_CPY_BUF(&hw_action->slot.fields.action_hash.hash_mask,
                                       &action.fields.action_hash.hash_crc.mask.smac.ether_addr_octet[0],
                                       2);
                        /* We need to inverse byte order to comply with HW order */
                        hw_action->slot.fields.action_hash.hash_mask = cl_hton32(
                            hw_action->slot.fields.action_hash.hash_mask);
                    }
                    break;

                case SX_ACL_ACTION_HASH_FIELD_DMAC:
                    if (hw_action->slot.fields.action_hash.hash_fields ==
                        SXD_HASH_FLEX_ACTION_HASH_FIELD_DMAC_31_0_E) {
                        SX_MEM_CPY_BUF(&hw_action->slot.fields.action_hash.hash_mask,
                                       &action.fields.action_hash.hash_crc.mask.dmac.ether_addr_octet[2],
                                       4);
                        /* We need to inverse byte order to comply with HW order */
                        hw_action->slot.fields.action_hash.hash_mask = cl_hton32(
                            hw_action->slot.fields.action_hash.hash_mask);
                    } else {
                        SX_MEM_CPY_BUF(&hw_action->slot.fields.action_hash.hash_mask,
                                       &action.fields.action_hash.hash_crc.mask.dmac.ether_addr_octet[0],
                                       2);
                        /* We need to inverse byte order to comply with HW order */
                        hw_action->slot.fields.action_hash.hash_mask = cl_hton32(
                            hw_action->slot.fields.action_hash.hash_mask);
                    }
                    break;

                case SX_ACL_ACTION_HASH_FIELD_SIP:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.sip.s_addr);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_DIP:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.dip.s_addr);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_SIPV6:
                    /* The following calculation determines which 4 byte word from the IPv6 address to copy to the mask.
                     * NOTE: It is assumed the all IPv6 hash fields in the FW are consecutive!
                     */
                    ipv6_idx = SXD_HASH_FLEX_ACTION_HASH_FIELD_SIP_127_96_E -
                               hw_action->slot.fields.action_hash.hash_fields;
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.sipv6.s6_addr32[ipv6_idx]);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_DIPV6:
                    /* The following calculation determines which 4 byte word from the IPv6 address to copy to the mask.
                     * NOTE: It is assumed the all IPv6 hash fields in the FW are consecutive!
                     */
                    ipv6_idx = SXD_HASH_FLEX_ACTION_HASH_FIELD_DIP_127_96_E -
                               hw_action->slot.fields.action_hash.hash_fields;
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.dipv6.s6_addr32[ipv6_idx]);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_IP_PROTO:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.ip_proto);
                    /* Since  this is a single byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hw_action->slot.fields.action_hash.hash_mask <<= 24;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_L4_SOURCE_PORT:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.l4_source_port);
                    /* Since  this is a two byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hw_action->slot.fields.action_hash.hash_mask <<= 16;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_L4_DESTINATION_PORT:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.l4_destination_port);
                    /* Since  this is a two byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hw_action->slot.fields.action_hash.hash_mask <<= 16;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_INNER_SIP:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.inner_sip.s_addr);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_INNER_DIP:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.inner_dip.s_addr);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_INNER_SIPV6:
                    /* The following calculation determines which 4 byte word from the IPv6 address to copy to the mask.
                     * NOTE: It is assumed the all IPv6 hash fields in the FW are consecutive!
                     */
                    ipv6_idx = SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_SIP_127_96_E -
                               hw_action->slot.fields.action_hash.hash_fields;
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.inner_sipv6.s6_addr32[ipv6_idx]);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_INNER_DIPV6:
                    ipv6_idx = SXD_HASH_FLEX_ACTION_HASH_FIELD_INNER_DIP_127_96_E -
                               hw_action->slot.fields.action_hash.hash_fields;
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.inner_dipv6.s6_addr32[ipv6_idx]);
                    break;

                case SX_ACL_ACTION_HASH_FIELD_INNER_IP_PROTO:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.inner_ip_proto);
                    /* Since  this is a single byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hw_action->slot.fields.action_hash.hash_mask <<= 24;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_0:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_2:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_4:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_6:
                    hash_mask = 0;
                    SX_MEM_CPY(hash_mask, action.fields.action_hash.hash_crc.mask.gp_register);
                    /* Since  this is a two byte field the hw takes the byte of the mask from the MSB - hence the mask*/
                    hash_mask &= 0xFFFF;
                    /* The hash mask might already be filled with a value from the adjacent register - hence the or operation */
                    hw_action->slot.fields.action_hash.hash_mask |= hash_mask;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_1:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_3:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_5:
                case SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_7:
                    hash_mask = 0;
                    SX_MEM_CPY(hash_mask, action.fields.action_hash.hash_crc.mask.gp_register);
                    /* Since  this is a two byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hash_mask <<= 16;
                    /* The hash mask might already be filled with a value from the adjacent register - hence the or operation */
                    hw_action->slot.fields.action_hash.hash_mask |= hash_mask;
                    break;

                case SX_ACL_ACTION_HASH_FIELD_HASH_VALUE:
                    SX_MEM_CPY(hw_action->slot.fields.action_hash.hash_mask,
                               action.fields.action_hash.hash_crc.mask.hash_value);
                    /* Since  this is a two byte field the hw takes the byte of the mask from the MSB - hence the shift*/
                    hw_action->slot.fields.action_hash.hash_mask <<= 16;

                    break;

                default:
                    break;
                }

                if (i != map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions_count - 1) {
                    rc = flex_acl_hw_db_hw_action_list_next(hw_action_list_p, &first_hw_action_list_entry_p);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "ACL action hash. SXD action list too short for rule Region[%x]/Offset[%u] should be at least [%u]\n",
                            rule_id.region_id,
                            rule_id.offset,
                            map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions_count);
                        rc = SX_STATUS_ERROR;
                        goto out;
                    }
                    hw_action = &first_hw_action_list_entry_p->hw_action;
                }
            }
            /* Do a sanity check that we haven't allocated too many HW actions */
            rc = flex_acl_hw_db_hw_action_list_next(hw_action_list_p, &first_hw_action_list_entry_p);
            if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
                SX_LOG_ERR(
                    "ACL action hash. SXD action list too long for rule Region[%x]/Offset[%u] it's more than [%u]\n",
                    rule_id.region_id,
                    rule_id.offset,
                    map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions_count);
                rc = SX_STATUS_ERROR;
                goto out;
            }
            rc = SX_STATUS_SUCCESS;
        }
        break;

    default:
        SX_LOG_ERR("ACL action hash. Invalid action type :%s \n", ACTION_ID_2STR(action.type));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_vxlan_populate(sx_flex_acl_flex_action_t action,
                                           boolean_t                 is_defer,
                                           flex_acl_rule_id_t        rule_id,
                                           hw_action_list_t         *hw_action_list_p,
                                           hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_VNI:
        hw_action->slot.fields.action_vni.set_vni = SXD_VNI_FLEX_ACTION_TYPE_SET_E;
        hw_action->slot.fields.action_vni.vni = action.fields.action_vni.vni_value;
        break;

    default:
        SX_LOG_ERR("ACL action vni. Invalid action type :%s \n", ACTION_ID_2STR(action.type));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sb_snapshot_trigger_type_to_sxd_snap_id(const sx_sb_snapshot_trigger_enable_type_e acl_enable_type,
                                                    sxd_snapshot_trigger_id_t                 *sxd_snap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (acl_enable_type) {
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_0_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_0;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_1_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_1;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_2_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_2;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_3_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_3;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_4_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_4;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_5_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_5;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_6_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_6;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_7_E:
        *sxd_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_7;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __acl_hw_action_custom_byte_alu_imm_populate(sx_flex_acl_flex_action_t action,
                                                         boolean_t                 is_defer,
                                                         flex_acl_rule_id_t        rule_id,
                                                         hw_action_list_t         *hw_action_list_p,
                                                         hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t              *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint16_t                           value = 0, mask = 0;
    cm_index_t                         cm_index = 0;
    cm_hw_type_t                       cm_hw_type;
    cm_type_e                          cm_type;
    sx_flex_acl_flex_action_alu_imm_t *action_p = &(action.fields.action_alu_imm);

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    if ((action_p->imm_data_type == SX_ACL_ACTION_ALU_IMM_TYPE_OBJECT_E) &&
        (action_p->imm_obj.obj_type == SX_ACL_ACTION_ALU_IMM_OBJ_FLOW_COUNTER_TYPE_E)) {
        rc = flow_counter_lock(action_p->imm_obj.obj_data.base_counter_id,  &cm_type, &cm_hw_type, &cm_index);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("alu_imm_populate lock failed, counter_id: %u\n",
                       action_p->imm_obj.obj_data.base_counter_id);
            return FALSE;
        }

        /*HW counter index = PRM index/2, asic use HW index*/
        value = (uint16_t)cm_index / rm_resource_global.cntr_lines_flow_both;
        rc = flow_counter_unlock(action_p->imm_obj.obj_data.base_counter_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("alu_imm_populate unlock failed, counter_id: %u\n",
                       action_p->imm_obj.obj_data.base_counter_id);
            return FALSE;
        }
    } else {
        value = action.fields.action_alu_imm.imm_data;
    }
    mask = ULONG_BIT_MASK(action.fields.action_alu_imm.size);
    mask <<= action.fields.action_alu_imm.dst_offset;


    hw_action->slot.fields.action_custom_bytes_alu_imm.opcode =
        (sxd_custom_bytes_alu_imm_action_opcode_t)(action.fields.action_alu_imm.command);
    hw_action->slot.fields.action_custom_bytes_alu_imm.dest_cbset = action.fields.action_alu_imm.dst_register;
    hw_action->slot.fields.action_custom_bytes_alu_imm.imm = value;
    hw_action->slot.fields.action_custom_bytes_alu_imm.mask = mask;


    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_custom_byte_alu_reg_populate(sx_flex_acl_flex_action_t action,
                                                         boolean_t                 is_defer,
                                                         flex_acl_rule_id_t        rule_id,
                                                         hw_action_list_t         *hw_action_list_p,
                                                         hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint16_t              mask = 0;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    mask = ULONG_BIT_MASK(action.fields.action_alu_reg.size);
    mask <<= action.fields.action_alu_reg.dst_offset;

    hw_action->slot.fields.action_custom_bytes_alu_reg.opcode =
        (sxd_custom_bytes_alu_reg_action_opcode_t)(action.fields.action_alu_reg.command);
    hw_action->slot.fields.action_custom_bytes_alu_reg.dest_cbset = action.fields.action_alu_reg.dst_register;
    hw_action->slot.fields.action_custom_bytes_alu_reg.src_cbset = action.fields.action_alu_reg.src_register;
    hw_action->slot.fields.action_custom_bytes_alu_reg.mask = mask;
    hw_action->slot.fields.action_custom_bytes_alu_reg.shr = action.fields.action_alu_reg.src_offset;

    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_custom_byte_alu_field_populate(sx_flex_acl_flex_action_t action,
                                                           boolean_t                 is_defer,
                                                           flex_acl_rule_id_t        rule_id,
                                                           hw_action_list_t         *hw_action_list_p,
                                                           hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint16_t              mask = 0, field_word = 0;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    mask = ULONG_BIT_MASK(action.fields.action_alu_field.size);
    mask <<= action.fields.action_alu_field.dst_offset;
    /* Translate the destination offset to the relevant 16 bit word we want to retrieve from the hw */
    field_word = action.fields.action_alu_field.src_field_offset >> 4;

    hw_action->slot.fields.action_custom_bytes_alu_field.opcode =
        (sxd_custom_bytes_alu_field_action_opcode_t)(action.fields.action_alu_field.command);
    hw_action->slot.fields.action_custom_bytes_alu_field.cbset = action.fields.action_alu_field.dst_register;
    hw_action->slot.fields.action_custom_bytes_alu_field.field_select =
        map_action_field_select[action.fields.action_alu_field.src_field].sxd_actions[field_word];
    hw_action->slot.fields.action_custom_bytes_alu_field.mask = mask;
    hw_action->slot.fields.action_custom_bytes_alu_field.shr = action.fields.action_alu_field.src_field_offset & 0xf;

    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_custom_byte_move_populate(sx_flex_acl_flex_action_t action,
                                                      boolean_t                 is_defer,
                                                      flex_acl_rule_id_t        rule_id,
                                                      hw_action_list_t         *hw_action_list_p,
                                                      hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t                       *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint32_t                                    cbset_index = 0;
    sxd_custom_bytes_flex_action_field_select_t field_select = 0;
    boolean_t                                   continue_cbset = FALSE;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    /* If we have an action that involves a field load/store we find where to start in the hw field */
    if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_COPY) {
        /* If we do not start from the field's start we add to the offset in two bytes resolution */
        field_select =
            map_action_field_select[action.fields.action_register_access.field].sxd_actions[action.fields.
                                                                                            action_register_access
                                                                                            .field_offset >> 4];
    }


    for (cbset_index = 0; cbset_index < action.fields.action_register_access.list_size; cbset_index++,
         field_select++) {
        hw_action->slot.fields.action_custom_bytes_move.size++;
        /* We only need to fill another slot if the previous cannot be continued to be used */
        if (continue_cbset == FALSE) {
            hw_action->slot.fields.action_custom_bytes_move.opcode =
                (sxd_custom_bytes_move_action_opcode_t)(action.fields.action_register_access.command);
            if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE) {
                hw_action->slot.fields.action_custom_bytes_move.dest_cbset =
                    action.fields.action_register_access.dst_register_list[cbset_index];
            }
            if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LOAD) {
                hw_action->slot.fields.action_custom_bytes_move.src_cbset =
                    action.fields.action_register_access.src_register_list[cbset_index];
            }
            if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_COPY) {
                hw_action->slot.fields.action_custom_bytes_move.field_select = field_select;
            }
        }
        /* Check if this is not the last set to enter */
        if (cbset_index + 1 < action.fields.action_register_access.list_size) {
            /* Check if we should continue with the current set or start a new one.
             * We check if the registers in the list are adjacent and if so we continue to use the same slot. */
            continue_cbset = TRUE;
            if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE) {
                if (action.fields.action_register_access.dst_register_list[cbset_index] + 1 !=
                    action.fields.action_register_access.dst_register_list[cbset_index + 1]) {
                    continue_cbset = FALSE;
                }
            }
            if (action.fields.action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LOAD) {
                if (action.fields.action_register_access.src_register_list[cbset_index] + 1 !=
                    action.fields.action_register_access.src_register_list[cbset_index + 1]) {
                    continue_cbset = FALSE;
                }
            }
            /* We need a new slot if we cannot reuse the old one */
            if (continue_cbset == FALSE) {
                rc = flex_acl_hw_db_hw_action_list_next(hw_action_list_p, &first_hw_action_list_entry_p);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "ACL action custom byte move. SXD action list too short for rule Region[%x]/Offset[%u] should be at least [%u]\n",
                        rule_id.region_id,
                        rule_id.offset,
                        map_crc_hash_field[action.fields.action_hash.hash_crc.field].sxd_actions_count);
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
                hw_action = &first_hw_action_list_entry_p->hw_action;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __acl_hw_action_field_immediate_populate(sx_flex_acl_flex_action_t action,
                                                     boolean_t                 is_defer,
                                                     flex_acl_rule_id_t        rule_id,
                                                     hw_action_list_t         *hw_action_list_p,
                                                     hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t                       *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint32_t                                    i = 0;
    sxd_custom_bytes_flex_action_field_select_t field_select = 0;

    SX_LOG_ENTER();

    /* If we do not start from the field's start we add to the offset in two bytes resolution */
    field_select =
        map_action_field_select[action.fields.action_field_imm.dst_field].sxd_actions[action.fields.action_field_imm.
                                                                                      field_offset >> 4];

    for (i = 0; i < action.fields.action_field_imm.list_size; i++, field_select++) {
        hw_action->slot.fields.action_fields_set_imm.defer = is_defer;
        hw_action->slot.fields.action_fields_set_imm.size = 1;
        hw_action->slot.fields.action_fields_set_imm.imm = action.fields.action_field_imm.immediate_list[i];
        hw_action->slot.fields.action_fields_set_imm.dest_field_select = field_select;

        /* We can unite identical immediate values into one actions */
        while ((i + 1 < action.fields.action_field_imm.list_size) &&
               (action.fields.action_field_imm.immediate_list[i] ==
                action.fields.action_field_imm.immediate_list[i + 1])) {
            hw_action->slot.fields.action_fields_set_imm.size++;
            i++;
        }

        if (i + 1 < action.fields.action_field_imm.list_size) {
            rc = flex_acl_hw_db_hw_action_list_next(hw_action_list_p, &first_hw_action_list_entry_p);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "ACL action field immediate set. SXD action list too short for rule Region[%x]/Offset[%u] should be at least [%u]\n",
                    rule_id.region_id,
                    rule_id.offset,
                    map_crc_hash_field[action.fields.action_field_imm.dst_field].sxd_actions_count);
                rc = SX_STATUS_ERROR;
                goto out;
            }
            hw_action = &first_hw_action_list_entry_p->hw_action;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_field_move_populate(sx_flex_acl_flex_action_t action,
                                                boolean_t                 is_defer,
                                                flex_acl_rule_id_t        rule_id,
                                                hw_action_list_t         *hw_action_list_p,
                                                hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t                       *hw_action = &first_hw_action_list_entry_p->hw_action;
    sxd_custom_bytes_flex_action_field_select_t dst_field_select = 0;
    sxd_custom_bytes_flex_action_field_select_t src_field_select = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    /* If we do not start from the field's start we add to the offset in two bytes resolution */
    dst_field_select =
        map_action_field_select[action.fields.action_field_copy.dst_field].sxd_actions[action.fields.action_field_copy.
                                                                                       dst_field_offset >> 4];
    src_field_select =
        map_action_field_select[action.fields.action_field_copy.src_field].sxd_actions[action.fields.action_field_copy.
                                                                                       src_field_offset >> 4];

    hw_action->slot.fields.action_fields_move.defer = is_defer;
    hw_action->slot.fields.action_fields_move.size = action.fields.action_field_copy.size >> 1;
    hw_action->slot.fields.action_fields_move.dest_field_select = dst_field_select;
    hw_action->slot.fields.action_fields_move.src_field_select = src_field_select;

    SX_LOG_EXIT();
    return rc;
}


sx_status_t __acl_hw_action_flex_modifier_emt_populate(sx_flex_acl_flex_action_t action,
                                                       boolean_t                 is_defer,
                                                       flex_acl_rule_id_t        rule_id,
                                                       hw_action_list_t         *hw_action_list_p,
                                                       hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;
    uint32_t              i = 0, bind_index = 0;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    for (i = 0; i < SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E; i++) {
        if (action.fields.action_set_emt.emt_bind_action[i].emt_bind_type != SX_FLEX_MODIFIER_BIND_TYPE_NOP_E) {
            bind_index = action.fields.action_set_emt.emt_bind_action[i].emt_bind_index;

            hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].emt_opcode =
                map_sxd_emt_bind_type[action.fields.action_set_emt.emt_bind_action[i].emt_bind_type];
            if (action.fields.action_set_emt.emt_bind_action[i].emt_bind_type !=
                SX_FLEX_MODIFIER_BIND_TYPE_DISABLE_E) {
                hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].emt_pointer =
                    action.fields.action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_id.emt_id;

                if (action.fields.action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset_type ==
                    SX_FLEX_MODIFIER_OFFSET_TYPE_GP_REGISTER_E) {
                    hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].modify_offset =
                        (sxd_flex_modifier_emt_action_modify_offset_t)(action.fields.action_set_emt.emt_bind_action[i].
                                                                       emt_bind_type_attr.emt_offset);
                    hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].offset_type =
                        SXD_FLEX_MODIFIER_EMT_ACTION_OFFSET_TYPE_GP_REG_E;
                } else {    /* SX_FLEX_MODIFIER_OFFSET_TYPE_ENCAP_HEADER_E */
                    hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].modify_offset =
                        action.fields.action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.
                        offset;
                    hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].modifier_base =
                        map_sxd_emt_modifier_base[action.fields.action_set_emt.emt_bind_action[i].emt_bind_type_attr.
                                                  emt_encap_header_offset.encap_header];
                    hw_action->slot.fields.action_flex_modifier_emt.emt_record[bind_index].offset_type =
                        SXD_FLEX_MODIFIER_EMT_ACTION_OFFSET_TYPE_CONSTANT_E;
                }
            }
        }
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_buffer_snap_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t                *hw_action = &first_hw_action_list_entry_p->hw_action;
    sx_sb_snapshot_trigger_enable_type_e acl_trigger_type = SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E;
    sxd_snapshot_trigger_id_t            sxd_acl_snap_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_0;

    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP:
        acl_trigger_type = action.fields.action_set_buffer_snap.sb_snap_id;
        sb_snapshot_trigger_type_to_sxd_snap_id(acl_trigger_type, &sxd_acl_snap_id);
        hw_action->slot.fields.action_buffer_snap.snap_id = (uint8_t)sxd_acl_snap_id;
        break;

    default:
        SX_LOG_ERR("ACL action snap ID. Invalid action type :%s \n", ACTION_ID_2STR(action.type));
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_stateful_db_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t      *hw_action = &first_hw_action_list_entry_p->hw_action;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_id_t                group_id = 0;

    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    /* Get the ACL group id used by the key id */
    rc = stateful_db_key_id_acl_group_get(action.fields.action_stateful_db.stateful_key_id,
                                          action.fields.action_stateful_db.flow_dir,
                                          &group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: failed to get stateful db key_id [%u] for populate.\n",
                   action.fields.action_stateful_db.stateful_key_id);
        goto out;
    }

    /* Get the bind attribute associated with this group id */
    rc = flex_acl_get_bind_attribs(group_id, &bind_attribs_id, NULL, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: failed to get bind attributes id for stateful db key_id [%u] group id [%u].\n",
                   action.fields.action_stateful_db.stateful_key_id,
                   group_id);
        goto out;
    }

    hw_action->slot.fields.action_flex_stateful_db.key_type = SXD_FLEX_STATEFUL_DB_KEY_TYPE_GROUP_ID_E;
    hw_action->slot.fields.action_flex_stateful_db.key_id = bind_attribs_id;
    hw_action->slot.fields.action_flex_stateful_db.partition_id = action.fields.action_stateful_db.partition_id;
    hw_action->slot.fields.action_flex_stateful_db.db_op =
        map_sxd_stateful_db_db_op[action.fields.action_stateful_db.db_op];
    hw_action->slot.fields.action_flex_stateful_db.sem_op =
        map_sxd_stateful_db_sem_op[action.fields.action_stateful_db.sem_op];
    hw_action->slot.fields.action_flex_stateful_db.ticket_op =
        map_sxd_stateful_db_ticket_op[action.fields.action_stateful_db.order_op];

    /* For remove operation we'll always release the semaphore */
    if ((action.fields.action_stateful_db.db_op == SX_STATEFUL_DB_OP_REMOVE_INDICATION_E) ||
        (action.fields.action_stateful_db.db_op == SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E)) {
        hw_action->slot.fields.action_flex_stateful_db.sem_op = SXD_FLEX_STATEFUL_DB_SEM_OP_UNLOCK_E;
    }
    /* Register are valid only for read and write operations */
    if ((action.fields.action_stateful_db.db_op == SX_STATEFUL_DB_OP_READ_E) ||
        (action.fields.action_stateful_db.db_op == SX_STATEFUL_DB_OP_WRITE_E)) {
        hw_action->slot.fields.action_flex_stateful_db.cbs_index = action.fields.action_stateful_db.gp_reg_set - 1;
    }


out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_ac_hw_pbs_is_drop(sx_acl_pbs_id_t pbs_id, boolean_t *is_dropped)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Action , failed fetching pbs id [%u]\n", pbs_id);
        goto out;
    }

    *is_dropped = ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST
                    || pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST)
                   && pbs_entry->port_num == 0);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_forward_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                  flex_acl_db_flex_rule_t   *rule,
                                                  flex_acl_relocation_data_t relocation_data,
                                                  boolean_t                  add_ref)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    kvd_linear_manager_index_t        kvd_index = 0;
    kvd_linear_manager_block_length_t size = 1;
    boolean_t                         is_dropped;
    boolean_t                         action_found = FALSE;

    UNUSED_PARAM(relocation_data);


    SX_LOG_ENTER();

    switch (hw_action->slot.fields.action_forward.type) {
    case SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E:
    case SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E:
        rc = __flex_ac_hw_pbs_is_drop(hw_action->pbs_id, &is_dropped);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward bind : failed in __flex_ac_hw_pbs_is_drop pbs:%u\n", hw_action->pbs_id);
            goto out;
        }
        SX_LOG_DBG("FORWARD PBS is_dropped:%d add ref:%d \n", is_dropped, add_ref);

        if (is_dropped) {
            /* Create TRAP action */
            rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_E, &action_found, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Action forward bind : failed in flex_acl_hw_db_get_action_from_rule pbs:%u\n",
                           hw_action->pbs_id);
                goto out;
            }
            if (!action_found) {
                rc = flex_acl_hw_db_get_action_from_rule(rule,
                                                         SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                         &action_found,
                                                         NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL Action forward bind : failed in flex_acl_hw_db_get_action_from_rule pbs:%u\n",
                               hw_action->pbs_id);
                    goto out;
                }
            }
            /* If the rule contains TRAP action it will be changed to drop. Another TRAP can not be created
             *  TRAP action will always be the last action according to predefined HW action positioning*/
            if ((action_found == TRUE) ||
                (hw_action->aux_slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E)) {
                hw_action->slot.type = SXD_ACTION_TYPE_NULL_E;
            } else {
                rc = __add_acl_drop_trap_action(hw_action, rule, relocation_data, add_ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error adding ACL DROP Trap action to Rule  RC = %s\n",
                               sx_status_str(rc));
                    goto out;
                }
            }
            goto out;
        }

        hw_action->slot.type = SXD_ACTION_TYPE_FORWARD_E;
        hw_action->slot.fields.action_forward = hw_action->aux_slot.fields.action_forward;
        if (add_ref) {
            rc = flex_acl_hw_db_pbs_add_entry(hw_action->pbs_kvd_handle,
                                              relocation_data.is_head,
                                              relocation_data.kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "ACL counter action failed flex_acl_hw_db_counter_add_entry failed, pbs_kvd_handle: %" PRIu64 "\n",
                    hw_action->pbs_kvd_handle);
                rc = SX_STATUS_ERROR;
                goto out;
            }
        }

        rc = kvd_linear_manager_handle_lock(hw_action->pbs_kvd_handle, &kvd_index, &size);
        if ((SX_STATUS_SUCCESS != rc) || (size < 1)) {
            if (add_ref) {
                flex_acl_hw_db_pbs_remove_entry(hw_action->pbs_kvd_handle, relocation_data.kvd_index_p);
            }
            SX_LOG_ERR("ACL action forward : Failed locking kvd block, pbs_kvd_handle: %" PRIu64 "\n",
                       hw_action->pbs_kvd_handle);
            return rc;
        }
        if (hw_action->slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) {
            hw_action->slot.fields.action_forward.record.pbs_ptr = kvd_index;
        } else if (hw_action->slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E) {
            hw_action->slot.fields.action_forward.record.output.pbs_ptr = kvd_index;
            hw_action->slot.fields.action_forward.record.output.defer =
                SXD_FORWARD_FLEX_ACTION_OUTPUT_DEFER_TYPE_APPLY_E;
            hw_action->slot.fields.action_forward.record.output.in_port = FALSE;
        } else {
            SX_LOG_ERR("Invalid action Forward type %d \n", hw_action->slot.fields.action_forward.type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        hw_action->is_locked = TRUE;

        if (add_ref) {
            rc = kvd_linear_manager_ref_add(hw_action->pbs_kvd_handle);
            if (SX_STATUS_SUCCESS != rc) {
                flex_acl_hw_db_pbs_remove_entry(hw_action->counter_id, relocation_data.kvd_index_p);
                kvd_linear_manager_handle_release(hw_action->pbs_kvd_handle);
                hw_action->is_locked = FALSE;
                SX_LOG_ERR("ACL action : Failed adding reference, pbs_kvd_handle: %" PRIu64 "\n",
                           hw_action->pbs_kvd_handle);
                return rc;
            }
            hw_action->is_ref_count_inc = TRUE;
        }
        break;

    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid forward action type :%d \n",
                   hw_action->slot.fields.action_forward.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_uc_bind_populate(flex_acl_hw_action_t      *hw_action,
                                             flex_acl_db_flex_rule_t   *rule,
                                             flex_acl_relocation_data_t relocation_data,
                                             boolean_t                  add_ref)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    hwd_tunnel_decap_index_t tunnel_hw_index;
    hwd_rif_id_t             rif_hw_id;
    boolean_t                is_trap_action;
    uint32_t                 adj_index, port_grp_index;
    hwd_ecmp_block_size_t    ecmp_block_size;
    hwd_ecmp_block_size_t    hw_ecmp_block_size = 0;
    boolean_t                is_empty = FALSE;

    UNUSED_PARAM(rule);

    SX_LOG_ENTER();

    switch (hw_action->aux_slot.fields.action_uc_router.type) {
    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
        rc = sdk_tunnel_impl_hw_decap_lock(hw_action->tunnel_id, &tunnel_hw_index);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Invalid tunnel id :%u \n", hw_action->tunnel_id);
            goto out;
        }
        hw_action->is_locked = TRUE;
        hw_action->slot.fields = hw_action->aux_slot.fields;
        hw_action->slot.fields.action_uc_router.structs.tunnul_termination.tunnul_ptr = tunnel_hw_index;
        if (add_ref) {
            rc = flex_acl_hw_db_tunnel_decap_add_entry(hw_action->tunnel_id,
                                                       relocation_data.is_head,
                                                       relocation_data.kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                sdk_tunnel_impl_hw_decap_unlock(hw_action->tunnel_id);
                hw_action->is_locked = FALSE;
                SX_LOG_ERR(
                    "ACL uc route tunnel termination action failed flex_acl_hw_db_tunnel_decap_add_entry failed, tunnel ID: %u\n",
                    hw_action->tunnel_id);
                goto out;
            }
            SX_LOG_DBG(" Added tunnel ID :%u to tunnel decap db\n", hw_action->tunnel_id);
            hw_action->is_ref_count_inc = TRUE;
        }
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E:
        hw_action->slot.fields = hw_action->aux_slot.fields;
        rc = sdk_router_cmn_rif_hw_id_get(hw_action->rif, &rif_hw_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("RIF %u is not valid.\n", hw_action->rif);
            goto out;
        }
        hw_action->slot.fields.action_uc_router.structs.ip_local.local_erif = rif_hw_id;
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
        rc = hwd_router_ar_ecmp_block_get(hw_action->ecmp_block_handle,
                                          &adj_index,
                                          &port_grp_index,
                                          &ecmp_block_size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("AR action failed to get ECMP block %u is not valid.\n", hw_action->ecmp);
            goto out;
        }
        hw_action->slot.fields = hw_action->aux_slot.fields;
        hw_action->slot.type = SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E;
        hw_action->slot.fields.action_uc_router.structs.ar_uc_route.arft_pointer = adj_index;
        hw_action->slot.fields.action_uc_router.structs.ar_uc_route.ecmp_size = ecmp_block_size;
        hw_action->slot.fields.action_uc_router.structs.ar_uc_route.arlpgt_pointer = port_grp_index;
        hw_action->slot.fields.action_uc_router.structs.ar_uc_route.ar_lookup_prof_id = hw_action->ar_profile_id;
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
        /* Both the NAT action and the remote UC share the same action type */
        if (hw_action->api_action_type == SX_FLEX_ACL_ACTION_NAT) {
            /* coverity[callee_ptr_arith] */
            rc = hwd_nat_4to6_kvd_index_get(hw_action->nat_id, &adj_index);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("NAT IPv4/IPv6 [%u] failed HW index get for ACL action\n", hw_action->nat_id);
                goto out;
            }

            hw_action->slot.type = SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E;
            hw_action->slot.fields.action_uc_router.structs.ip_remote.adjacency_index = adj_index;
            hw_action->slot.fields.action_uc_router.structs.ip_remote.ecmp_size = 1;
        } else {
            switch (hw_action->ecmp_container_type) {
            case SX_ECMP_CONTAINER_TYPE_IP:
                rc = hwd_router_ecmp_block_get(hw_action->ecmp_block_handle, &adj_index, &ecmp_block_size);
                hw_ecmp_block_size = ecmp_block_size;
                break;

            /* We do not point directly to an ecmp but to ftn/mpls_adj mediator, size of the mpls_adj is always 1.
             * hw_ecmp_block_size represents the size of the ecmp relevant for filling out the action in hw.
             * ecmp_block_size states the actual size of the ecmp behind the mpls_adj which is important to
             * determine if we need to set a drop action if the ecmp_size = 0.
             */
            case SX_ECMP_CONTAINER_TYPE_MPLS:
                rc = hwd_mpls_ftn_get_block_info(hw_action->ecmp_block_handle, NULL, &adj_index, &ecmp_block_size);
                hw_ecmp_block_size = 1;
                break;

            default:
                SX_LOG_ERR("Unknown ecmp container type %u \n", hw_action->ecmp_container_type);
                rc = SX_STATUS_ERROR;
                goto out;
                break;
            }
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ECMP block handle 0x%" PRIx64 " is not valid.\n", hw_action->ecmp_block_handle);
                goto out;
            }

            if (add_ref) {
                rc = flex_acl_hw_db_ecmp_container_add_entry(hw_action->ecmp_block_handle,
                                                             relocation_data.is_head,
                                                             relocation_data.kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "ACL UC ROUTE remote action  flex_acl_hw_db_ecmp_container_add_entry failed, ecmp_block_handle: %" PRIu64 "\n",
                        hw_action->ecmp_block_handle);
                    goto out;
                }
                SX_LOG_DBG(" Added ecmp block id :0x%" PRIx64 " to ecmp container db\n", hw_action->ecmp_block_handle);
                hw_action->is_ref_count_inc = TRUE;
            }

            if (ecmp_block_size == 0) {
                SX_LOG_DBG("Handle empty ECMP container.\n");
                rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_E, &is_trap_action, NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "ACL Action UC ROTE bind : failed in flex_acl_hw_db_get_action_from_rule ecmp container:%u\n",
                        hw_action->ecmp);
                    goto out;
                }
                if (!is_trap_action) {
                    rc = flex_acl_hw_db_get_action_from_rule(rule,
                                                             SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                             &is_trap_action,
                                                             NULL);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "ACL Action UC ROTE bind : failed in flex_acl_hw_db_get_action_from_rule ecmp container:%u\n",
                            hw_action->ecmp);
                        goto out;
                    }
                }
                /* If the rule contains TRAP action it will be changed to drop. Another TRAP can not be created
                 *  TRAP action will always be the last action according to predefined HW action positioning*/
                if (is_trap_action == TRUE) {
                    hw_action->slot.type = SXD_ACTION_TYPE_NULL_E;
                } else {
                    rc = __add_acl_drop_trap_action(hw_action, rule, relocation_data, add_ref);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error adding ACL DROP Trap action to Rule  RC = %s\n",
                                   sx_status_str(rc));
                        goto out;
                    }
                }
                goto out;
            }

            hw_action->slot.fields = hw_action->aux_slot.fields;
            hw_action->slot.type = SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E;
            hw_action->slot.fields.action_uc_router.structs.ip_remote.adjacency_index = adj_index;
            hw_action->slot.fields.action_uc_router.structs.ip_remote.ecmp_size = hw_ecmp_block_size;
        }
        break;

    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
        rc = __flex_acl_hw_get_pbilm(hw_action->pbilm_id, &is_empty, &adj_index);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("PBILM id %u is not valid.\n", hw_action->pbilm_id);
            goto out;
        }
        if (add_ref) {
            rc = flex_acl_hw_db_pbilm_add_entry(hw_action->pbilm_id,
                                                relocation_data.is_head,
                                                relocation_data.kvd_index_p);

            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL UC ROUTE ilm action  flex_acl_hw_db_pbilm_container_add_entry failed, pbilm_id: %u\n",
                           hw_action->pbilm_id);
                goto out;
            }
            SX_LOG_DBG(" Added PBILM id :%u to pbilm container db\n", hw_action->pbilm_id);
            hw_action->is_ref_count_inc = TRUE;
        }

        if (is_empty) {
            SX_LOG_DBG("Handle empty ECMP container for PBILM.\n");
            rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_E, &is_trap_action, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "ACL Action PBILM bind : failed in flex_acl_hw_db_get_action_from_rule pbilm:%u\n",
                    hw_action->pbilm_id);
                goto out;
            }
            if (!is_trap_action) {
                rc = flex_acl_hw_db_get_action_from_rule(rule,
                                                         SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                         &is_trap_action,
                                                         NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "ACL Action UC ROTE bind : failed in flex_acl_hw_db_get_action_from_rule ecmp container:%u\n",
                        hw_action->ecmp);
                    goto out;
                }
            }
            /* If the rule contains TRAP action it will be changed to drop. Another TRAP can not be created
             *  TRAP action will always be the last action according to predefined HW action positioning*/
            if (is_trap_action == TRUE) {
                hw_action->slot.type = SXD_ACTION_TYPE_NULL_E;
            } else {
                rc = __add_acl_drop_trap_action(hw_action, rule, relocation_data, add_ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error adding ACL DROP Trap action to Rule  RC = %s\n",
                               sx_status_str(rc));
                    goto out;
                }
            }
            goto out;
        }

        hw_action->slot.fields = hw_action->aux_slot.fields;
        hw_action->slot.type = SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E;
        hw_action->slot.fields.action_uc_router.structs.mpls_ilm.ilm_ptr = adj_index;

        break;


    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid uc action type :%d \n", hw_action->slot.fields.action_uc_router.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_uc_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    switch (hw_action->slot.fields.action_uc_router.type) {
    case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
        rc = sdk_tunnel_impl_hw_decap_unlock(hw_action->tunnel_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed release lock for decap tunnel id:%u \n", hw_action->tunnel_id);
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid UC route HW action locked id:%u \n", hw_action->slot.fields.action_uc_router.type);
        goto out;
    }

    hw_action->is_locked = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_forward_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_dropped;

    SX_LOG_ENTER();

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    switch (hw_action->slot.fields.action_forward.type) {
    case SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E:
    case SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E:
        rc = __flex_ac_hw_pbs_is_drop(hw_action->pbs_id, &is_dropped);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Action forward bind : failed in __flex_ac_hw_pbs_is_drop pbs id :%u \n",
                       hw_action->pbs_id);
            goto out;
        }
        if (is_dropped) {
            goto out;
        }
        rc = kvd_linear_manager_handle_release(hw_action->pbs_kvd_handle);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL forward action release : Failed releasing the kvd lock, pbs_kvd_handle: %" PRIu64 "\n",
                       hw_action->pbs_kvd_handle);
            goto out;
        }
        hw_action->is_locked = FALSE;
        break;

    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid forward action type :%d \n",
                   hw_action->slot.fields.action_forward.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_hw_write_action_register(sx_dev_id_t          dev_id,
                                              sx_acl_region_id_t   region_id,
                                              sx_acl_rule_offset_t offset,
                                              ku_pefa_reg_t       *pefa_reg_data,
                                              boolean_t            bulk_write)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    UNUSED_PARAM(bulk_write);

    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEFA_E, pefa_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_st);
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL : Failed PEFA write, sxd_status [%d], region [%d], offset [%d]\n",
                                 sxd_st, region_id, offset);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_hw_write_action_register(sx_dev_id_t          dev_id,
                                               sx_acl_region_id_t   region_id,
                                               sx_acl_rule_offset_t offset,
                                               ku_pefa_reg_t       *pefa_reg_data,
                                               boolean_t            bulk_write)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    UNUSED_PARAM(bulk_write);

    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEFA_E, pefa_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_st);
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL : Failed PEFA write, sxd_status [%d], region [%d], offset [%d]\n",
                                 sxd_st, region_id, offset);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_set_action_activity(boolean_t                        is_full_write,
                                            boolean_t                        is_default_action,
                                            boolean_t                        activity_clear,
                                            flex_acl_hw_db_kvd_action_set_t *kvd_action_set,
                                            ku_pefa_reg_t                   *pefa_reg_data)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_region_id_t region_id = FLEX_ACL_INVALID_REGION_ID;

    SX_LOG_ENTER();

    /* Activity in actions is relevant only for flex2
     * Only the relevant activity fields are set by this function.
     */
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) {
        /* For full write we set the default activity. For modification we maintain the current activity */
        if (is_full_write) {
            pefa_reg_data->ca = (activity_clear) ? SXD_PEFA_CA_OP_CLEAR : SXD_PEFA_CA_OP_SET;
        } else {
            pefa_reg_data->ca = SXD_PEFA_CA_OP_MAINTAIN;
        }
        /* The user_val should be set to the region_id only for the first kvd of a rule (used for activity dump) */
        region_id = (kvd_action_set->is_first) ? kvd_action_set->region_id : FLEX_ACL_INVALID_REGION_ID;
        FLEX_CLR_ACL_REGION_BIT(region_id);
        /* as_user_val field may not be used for duplicated ACL actions.
         * for the default actions, the first action set is duplicated by default,
         * we can avoid setting this field
         */
        if ((is_default_action == FALSE) || (kvd_action_set->is_first == FALSE)) {
            pefa_reg_data->as_user_val = region_id;
        }
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_edit_action_register(flex_acl_hw_db_action_set_t *action_set, boolean_t is_commit)
{
    uint32_t                         i = 0;
    uint32_t                         dev_idx = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *hw_region_attributes = NULL;
    flex_acl_db_acl_region_t        *acl_region = NULL;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    sxd_flex_action_set_t            reg_action_set;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_action_set);

    rc = flex_acl_db_region_get(action_set->related_rule->region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to find ACL region: %u\n", action_set->related_rule->region_id);
        goto out;
    }

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get device \n");
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &hw_region_attributes);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (hw_region_attributes->write_reg_cb.rule_hw_cb == NULL) {
        SX_LOG_ERR("ACL : NO HW CB for writing rule, region :%u \n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < action_set->action_set.actions_count; i++) {
        memcpy(&(reg_action_set.action_slots[i]), &(action_set->action_set.actions[i].slot),
               sizeof(struct sxd_action_slot));
    }

    if (action_set->kvd_action_set_count == 0) {
        reg_action_set.next_type = SXD_FLEX_GOTO_RECORD_E;
        reg_action_set.next_goto_record.goto_set_action = action_set->action_set.goto_action;
        reg_action_set.next_goto_record.goto_set_action.group_binding =
            SXD_GROUP_OR_ACL_BINDING_TYPE_GROUP_E;
        reg_action_set.next_goto_record.goto_set_action.commit = is_commit;
    } else {
        reg_action_set.next_type = SXD_FLEX_NEXT_POINTER_RECORD_E;
        reg_action_set.next_goto_record.next_action_set_ptr = action_set->action_set.kvd_index;
    }

    rc = hw_region_attributes->write_reg_cb.rule_hw_cb(ACL_RULE_HW_OP_UPDATE_E,
                                                       devs_list[dev_idx],
                                                       action_set->related_rule->region_id,
                                                       hw_region_attributes->region_info[devs_list[dev_idx]],
                                                       action_set->related_rule->offset,
                                                       action_set->related_rule->valid,
                                                       action_set->related_rule->priority,
                                                       NULL,
                                                       0,
                                                       NULL,
                                                       0,
                                                       &reg_action_set,
                                                       NULL,
                                                       hw_region_attributes->bulk_write);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to configure rule to dev_idx [%u]\n", dev_idx);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return rc;
}

/* This action is intended to directly edit actions only with no relation to the rules that points to them.
 * The typical case is for callback function from external modules (kvd, ecmp, counter) that change the action directly.
 * This function should NOT be called by functions that implement rules API.
 */
sx_status_t __flex_acl_hw_edit_action_kvd(flex_acl_hw_db_kvd_action_set_t *kvd_action_set,
                                          boolean_t                        is_full_write,
                                          boolean_t                        is_default_action)
{
    struct ku_pefa_reg     pefa_reg_data = {.index = 0};
    sx_status_t            rc = SX_STATUS_SUCCESS;
    uint32_t               i = 0;
    sx_sdk_entries_param_t action_entry_param;
    uint32_t               actual_num_of_entries = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(pefa_reg_data);
    SX_MEM_CLR(action_entry_param);

    pefa_reg_data.index = kvd_action_set->kvd_index;

    for (i = 0; i < kvd_action_set->actions_count; i++) {
        memcpy(&(pefa_reg_data.action_set.action_slots[i]), &(kvd_action_set->actions[i].slot),
               sizeof(struct sxd_action_slot));
    }

    if (kvd_action_set->is_last) {
        pefa_reg_data.action_set.next_type = SXD_FLEX_GOTO_RECORD_E;
        pefa_reg_data.action_set.next_goto_record.goto_set_action = kvd_action_set->goto_action;
        pefa_reg_data.action_set.next_goto_record.goto_set_action.group_binding =
            SXD_GROUP_OR_ACL_BINDING_TYPE_GROUP_E;
        pefa_reg_data.action_set.next_goto_record.goto_set_action.commit = 0;
    } else {
        pefa_reg_data.action_set.next_type = SXD_FLEX_NEXT_POINTER_RECORD_E;
        pefa_reg_data.action_set.next_goto_record.next_action_set_ptr = kvd_action_set->kvd_next_index;
    }

    /* Add to the PEFA register the relevant fields related to activity */
    rc = flex_acl_hw_set_action_activity(is_full_write, is_default_action, FALSE, kvd_action_set, &pefa_reg_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed updating action activity fields.\n");
        goto out;
    }

    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    action_entry_param.attr.acl_action_attr.default_action = is_default_action;
    rc = rm_sdk_table_duplication_actual_entries_num_get(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                                                         &action_entry_param, 1, &actual_num_of_entries);
    if (actual_num_of_entries > 1) {
        pefa_reg_data.ddd_en = TRUE;
    }

    /* Since we don't have any relation to the region here, the region ID might not be valid here */
    rc = flex_acl_hw_write_pefa_devices(0, TRUE, kvd_action_set->region_id, UNLIMITED_SDK_TABLE_SIZE, &pefa_reg_data);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL : Failed to configure PEFA for region [%u].\n", kvd_action_set->region_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

typedef struct {
    sx_policer_id_t         policer_id;
    policer_manager_index_t old_index;
    policer_manager_index_t new_index;
} policer_relocate_data_t;
static sx_status_t __policer_relocate_handle(void                    *data,
                                             flex_acl_hw_action_t    *action,
                                             flex_acl_db_flex_rule_t *related_rule,
                                             boolean_t               *found,
                                             boolean_t               *handled)
{
    policer_relocate_data_t *relocate_data = (policer_relocate_data_t*)data;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot  *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found, "found"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *found = FALSE;
    *handled = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    if ((action_slot->type == SXD_ACTION_TYPE_POLICING_COUNTING_E) &&
        (action_slot->fields.action_policing_monitoring.c_p == SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E)) {
        /* change the policer is in the hw action set */
        if (action_slot->fields.action_policing_monitoring.pid == relocate_data->old_index) {
            action_slot->fields.action_policing_monitoring.pid = relocate_data->new_index;
            *found = TRUE;
        }
    }

out:
    SX_LOG_EXIT();

    return rc;
}

typedef struct {
    cm_logical_id_t counter_id;
    cm_hw_type_t    cm_type;
    cm_index_t      old_index;
    cm_index_t      new_index;
} counter_relocate_data_t;
static sx_status_t __counter_relocate_handle(void                    *data,
                                             flex_acl_hw_action_t    *action,
                                             flex_acl_db_flex_rule_t *related_rule,
                                             boolean_t               *found,
                                             boolean_t               *handled)
{
    counter_relocate_data_t *relocate_data = (counter_relocate_data_t*)data;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot  *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found, "found"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *found = FALSE;
    *handled = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    if ((action_slot->type == SXD_ACTION_TYPE_POLICING_COUNTING_E) &&
        (action_slot->fields.action_policing_monitoring.c_p == SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E)) {
        /* change the counter is in the hw action set */
        if (action_slot->fields.action_policing_monitoring.counter_set.index == relocate_data->old_index) {
            action_slot->fields.action_policing_monitoring.counter_set.index = relocate_data->new_index;
            action_slot->fields.action_policing_monitoring.counter_set.type = relocate_data->cm_type;
            *found = TRUE;
        }
    }
    if (action_slot->type == SXD_ACTION_TYPE_FLOW_ESTIMATOR_E) {
        if (action_slot->fields.action_flow_estimator.bulk_counter.index == relocate_data->old_index) {
            action_slot->fields.action_flow_estimator.bulk_counter.index = relocate_data->new_index;
            action_slot->fields.action_flow_estimator.bulk_counter.type = relocate_data->cm_type;
            *found = TRUE;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

typedef struct {
    sx_span_session_id_t     span_session_id;
    sx_span_session_id_int_t old_index;
    sx_span_session_id_int_t new_index;
} span_relocate_data_t;
static sx_status_t __span_relocate_handle(void                    *data,
                                          flex_acl_hw_action_t    *action,
                                          flex_acl_db_flex_rule_t *related_rule,
                                          boolean_t               *found,
                                          boolean_t               *handled)
{
    span_relocate_data_t   *relocate_data = (span_relocate_data_t*)data;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found, "found"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *found = FALSE;
    *handled = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    if ((action_slot->type == SXD_ACTION_TYPE_TRAP_E) && action_slot->fields.action_trap.mirror_enable) {
        if (action_slot->fields.action_trap.mirror_agent == relocate_data->old_index) {
            action_slot->fields.action_trap.mirror_agent = relocate_data->new_index;
            *found = TRUE;
        }
    } else if (action_slot->type == SXD_ACTION_TYPE_MIRROR_SAMPLER_E) {
        if (action_slot->fields.action_mirror_sampler.mirror_agent == relocate_data->old_index) {
            action_slot->fields.action_mirror_sampler.mirror_agent = relocate_data->new_index;
            *found = TRUE;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_write_only_rule_to_devs(flex_acl_db_flex_rule_t  *related_rule_p,
                                                         flex_acl_db_acl_region_t *region_p,
                                                         boolean_t                 is_full_write,
                                                         boolean_t                 is_overwrite)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    dev_idx = 0;
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t    dev_info_arr_size = 0;

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    rc = flex_acl_hw_write_only_rule(related_rule_p,
                                     region_p,
                                     devs_list[dev_idx],
                                     TRUE,
                                     is_full_write,
                                     is_overwrite);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Fatal error: Failed writing rules to new added device[%d].\n", dev_idx);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();

    return rc;
}

static sx_status_t __mc_container_relocate_handle(void                    *data_p,
                                                  flex_acl_hw_action_t    *action,
                                                  flex_acl_db_flex_rule_t *related_rule_p,
                                                  boolean_t               *found_p,
                                                  boolean_t               *handled)
{
    mc_container_pointer_change_event_data_t *container_change_info_p =
        (mc_container_pointer_change_event_data_t*)data_p;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region_p = NULL;
    struct sxd_action_slot   *action_slot_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found_p, "found_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(data_p, "data_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(action, "action"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(related_rule_p, "related_rule_p"))) {
        goto out;
    }

    *found_p = FALSE;
    *handled = FALSE;

    action_slot_p = &action->slot;

    /* If MC container changed from empty to full or from full to empty - different handle */
    if ((container_change_info_p->pointer_changed &&
         (((container_change_info_p->old_pointer.type == HW_MC_LIST_POINTER_TYPE_NONE) &&
           (container_change_info_p->new_pointer.type != HW_MC_LIST_POINTER_TYPE_NONE)) ||
          ((container_change_info_p->old_pointer.type != HW_MC_LIST_POINTER_TYPE_NONE) &&
           (container_change_info_p->new_pointer.type == HW_MC_LIST_POINTER_TYPE_NONE)))) ||
        (container_change_info_p->rewrite_rule)) {
        if (((container_change_info_p->old_pointer.type == HW_MC_LIST_POINTER_TYPE_NONE) &&
             (container_change_info_p->new_pointer.type != HW_MC_LIST_POINTER_TYPE_NONE))) {
            /* Container is not empty any more. If we added ACL DROP Trap action
             * when container was empty, we need to remove it now.
             * Only remove the entry from DBs (ACL Drop Data DB & ACL Drop Relocate DB)here.
             * The trap action will be overwritten with the right MC one later
             */
            SX_LOG_DBG("MC Container is not empty anymore. Delete entry from acl relocate db for action.type %u\n",
                       action_slot_p->type);
            SX_LOG_DBG("old_pointer.type =%s, new_pointer.type =%s rewrite_rule=%s \n",
                       HW_MC_LIST_POINTER_TYPE_STR(container_change_info_p->old_pointer.type),
                       HW_MC_LIST_POINTER_TYPE_STR(container_change_info_p->new_pointer.type),
                       container_change_info_p->rewrite_rule ? "TRUE" : "FALSE");
            rc = __empty_cont_del_acl_drop_trap_action_from_db(related_rule_p, action_slot_p);

            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("error find & del acl drop trap entry from db [%s]\n", sx_status_str(rc));
                goto out;
            }
        }

        /* Rewrite the rule */
        rc = flex_acl_db_region_get(related_rule_p->region_id, &region_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Get ACL region failed, region_id: %u\n", related_rule_p->region_id);
            goto out;
        }
        rc = __flex_acl_hw_write_only_rule_to_devs(related_rule_p,
                                                   region_p,
                                                   FLEX_ACL_HW_ALLOW_WRITE_ONLY_ACTION,
                                                   FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Fatal error: Failed writing rule.\n");
            goto out;
        }
        *found_p = TRUE;
        *handled = TRUE;
        SX_LOG_DBG("Rewrite rule .\n");
        goto out;
    }

    if ((action_slot_p->type != SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) &&
        (action_slot_p->type != SXD_ACTION_TYPE_TRAP_E) &&
        (action_slot_p->type != SXD_ACTION_TYPE_MC_E) &&
        (action_slot_p->type != SXD_ACTION_TYPE_NULL_E)) {
        goto out;
    }
    if (container_change_info_p->attributes_changed) {
        action_slot_p->fields.action_mc.min_mtu = container_change_info_p->new_attributes.min_mtu;
    }
    if (container_change_info_p->pointer_changed) {
        switch (container_change_info_p->new_pointer.type) {
        case HW_MC_LIST_POINTER_TYPE_RIGR:
            action_slot_p->fields.action_mc.vrmid = FALSE;
            action_slot_p->fields.action_mc.rigr_rmid_index = container_change_info_p->new_pointer.data.rigr_index;
            break;

        case HW_MC_LIST_POINTER_TYPE_RMID:
            action_slot_p->fields.action_mc.vrmid = TRUE;
            action_slot_p->fields.action_mc.rigr_rmid_index = container_change_info_p->new_pointer.data.rmid_index;
            break;

        default:
            SX_LOG_ERR("Invalid erif list type %u \n", container_change_info_p->new_pointer.type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *found_p = TRUE;

out:
    SX_LOG_EXIT();

    return rc;
}

typedef struct tunnel_decap_cb {
    sx_tunnel_id_t tunnel_id;
    uint32_t       old_index;
    uint32_t       new_index;
} tunnel_decap_cb_t;
static sx_status_t __tunnel_decap_relocate_handle(void                    *data,
                                                  flex_acl_hw_action_t    *action,
                                                  flex_acl_db_flex_rule_t *related_rule,
                                                  boolean_t               *found,
                                                  boolean_t               *handled)
{
    tunnel_decap_cb_t      *relocate_data = (tunnel_decap_cb_t*)data;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *handled = FALSE;
    *found = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    if ((action_slot->type == SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E) &&
        (action_slot->fields.action_uc_router.type == SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E)) {
        if (action_slot->fields.action_uc_router.structs.tunnul_termination.tunnul_ptr == relocate_data->old_index) {
            action_slot->fields.action_uc_router.structs.tunnul_termination.tunnul_ptr = relocate_data->new_index;
            *found = TRUE;
        }
    }

out:
    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

typedef struct {
    kvd_linear_manager_handle_t handle;
    kvd_linear_manager_index_t  old_index;
    kvd_linear_manager_index_t  new_index;
} pbs_relocate_data_t;
static sx_status_t __pbs_relocate_handle(void                    *data,
                                         flex_acl_hw_action_t    *action,
                                         flex_acl_db_flex_rule_t *related_rule,
                                         boolean_t               *found,
                                         boolean_t               *handled)
{
    pbs_relocate_data_t    *relocate_data = (pbs_relocate_data_t*)data;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found, "found"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *found = FALSE;
    *handled = FALSE;

    action_slot = &action->slot;

    if (action_slot->type == SXD_ACTION_TYPE_FORWARD_E) {
        if (action_slot->fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) {
            if (action_slot->fields.action_forward.record.pbs_ptr == relocate_data->old_index) {
                action_slot->fields.action_forward.record.pbs_ptr = relocate_data->new_index;
                *found = TRUE;
            }
        } else if (action_slot->fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E) {
            if (action_slot->fields.action_forward.record.output.pbs_ptr == relocate_data->old_index) {
                action_slot->fields.action_forward.record.output.pbs_ptr = relocate_data->new_index;
                *found = TRUE;
            }
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_block_relocate(cl_list_t *list, sx_status_t (*handle_cb)(void *data,
                                                                              flex_acl_hw_action_t    *action,
                                                                              flex_acl_db_flex_rule_t *related_rule,
                                                                              boolean_t *found,
                                                                              boolean_t *handled), void *data)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    cl_list_iterator_t                    iter = NULL;
    cl_list_iterator_t                    list_end = NULL;
    cl_list_iterator_t                    list_head = NULL;
    flex_acl_hw_db_kvd_index_ref         *kvd_index_ref = NULL;
    flex_acl_hw_db_register_action_set_t *register_action_set = NULL;
    flex_acl_hw_db_action_set_t          *action_set = NULL;
    flex_acl_hw_db_kvd_action_set_t      *kvd_action_set = NULL;
    uint32_t                              i = 0;
    uint32_t                              k = 0;
    boolean_t                             found_entry = FALSE;
    boolean_t                             handled = FALSE;

    SX_LOG_ENTER();
    list_head = cl_list_head(list);
    list_end = cl_list_end(list);
    for (iter = list_head; iter != list_end;
         iter = cl_list_next(iter)) {
        kvd_index_ref = (flex_acl_hw_db_kvd_index_ref*)cl_list_obj(iter);
        /* Get the action set , get the rule */
        register_action_set = PARENT_STRUCT(kvd_index_ref->kvd_index_ptr,
                                            flex_acl_hw_db_register_action_set_t,
                                            kvd_index);
        action_set = PARENT_STRUCT(register_action_set, flex_acl_hw_db_action_set_t, action_set);
        if (kvd_index_ref->is_head) {
            for (found_entry = FALSE, i = 0; !found_entry && i < register_action_set->actions_count; i++) {
                rc = handle_cb(data,
                               &(register_action_set->actions[i]),
                               action_set->related_rule,
                               &found_entry,
                               &handled);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "flex_acl_block_relocate Failed in CB in rule register, rule_region:%x rule offset:%u \n",
                        action_set->related_rule->region_id,
                        action_set->related_rule->offset);
                    goto out;
                }
            }
            if (found_entry == FALSE) {
                SX_LOG_ERR("flex_acl_block_relocate not found in rule register, rule_region:%x rule offset:%u \n",
                           action_set->related_rule->region_id, action_set->related_rule->offset);
                rc = SX_STATUS_ERROR;
                goto out;
            }
            /* call a function to rewrite the action at PTCE2 */
            if (handled == FALSE) {
                rc = flex_acl_hw_edit_action_register(action_set, FALSE);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "flex_acl_block_relocate failed in edit action in rule register, rule_region:%x rule offset:%u \n",
                        action_set->related_rule->region_id,
                        action_set->related_rule->offset);
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
            }
        } else {
            const cl_list_t   *kvd_action_set_list = NULL;
            cl_list_iterator_t iterk, action_list_end, action_list_head;

            rc = flex_acl_hw_db_get_kvd_action_set_list(action_set, &kvd_action_set_list);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "flex_acl_block_relocate failed flex_acl_hw_db_get_kvd_action_set_list, rule_region:%x rule offset:%u \n",
                    action_set->related_rule->region_id,
                    action_set->related_rule->offset);
                goto out;
            }
            action_list_head = cl_list_head(kvd_action_set_list);
            action_list_end = cl_list_end(kvd_action_set_list);

            for (k = 1, iterk = action_list_head; iterk != action_list_end;
                 iterk = cl_list_next(iterk), k++) {
                kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iterk);
                for (found_entry = FALSE, i = 0; !found_entry && i < kvd_action_set->actions_count; i++) {
                    rc = handle_cb(data,
                                   &(kvd_action_set->actions[i]),
                                   action_set->related_rule,
                                   &found_entry,
                                   &handled);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR(
                            "flex_acl_block_relocate Failed in CB in rule extension, rule_region:%x rule offset:%u \n",
                            action_set->related_rule->region_id,
                            action_set->related_rule->offset);
                        goto out;
                    }
                }
                if (found_entry == TRUE) {
                    /* call a function to rewrite the action to PEFA */
                    if (handled == FALSE) {
                        rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
                        if (SX_STATUS_SUCCESS != rc) {
                            SX_LOG_ERR("flex_acl_block_relocate failed in __flex_acl_hw_edit_action_kvd, rule_region: %x rule offset: %u \n"
                                       " kvd index: %x\n",
                                       action_set->related_rule->region_id,
                                       action_set->related_rule->offset,
                                       kvd_action_set->kvd_index);
                            SX_LOG_ERR("Failed edit action kvd\n");
                            goto out;
                        }
                    }
                    break;
                }
            }
            if (found_entry == FALSE) {
                SX_LOG_ERR("flex_acl_block_relocate failed: KVD index not found, rule region:%x rule offset:%u \n",
                           action_set->related_rule->region_id, action_set->related_rule->offset);
                rc = SX_STATUS_ERROR;
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_policer_block_relocate(sx_policer_id_t                handle,
                                               policer_manager_block_length_t size,
                                               policer_manager_index_t        old_index,
                                               policer_manager_index_t        new_index)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    cl_list_t              *policer_id_list = NULL;
    policer_relocate_data_t policer_relocate_data = {.policer_id = 0};

    SX_LOG_ENTER();

    UNUSED_PARAM(size);

    policer_relocate_data.old_index = old_index;
    policer_relocate_data.new_index = new_index;
    policer_relocate_data.policer_id = handle;

    rc = flex_acl_hw_db_policer_index_ref_list_get(handle, &policer_id_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("Policer relocator : Policer handler %" PRIu64 " no found\n", handle);
        if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
            rc = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("policer relocator : error at callback\n");
        }
        goto out;
    }

    rc = flex_acl_block_relocate(policer_id_list, __policer_relocate_handle, &policer_relocate_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Policer relocator : failed relocate block\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_cm_relocate(cm_logical_id_t lid,
                                    uint32_t        offset,
                                    cm_type_e       type,
                                    cm_hw_type_t    hw_type,
                                    cm_index_t      old_index,
                                    cm_index_t      new_index)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    cl_list_t              *counter_id_list = NULL;
    counter_relocate_data_t counter_relocate_data = {.counter_id = 0};
    sx_flow_counter_id_t    counter_id = LID_OFFSET_TO_FLOW_CNTR_ID(lid, offset);

    UNUSED_PARAM(type);

    SX_LOG_ENTER();

    counter_relocate_data.old_index = old_index;
    counter_relocate_data.new_index = new_index;
    counter_relocate_data.counter_id = counter_id;
    counter_relocate_data.cm_type = hw_type;


    rc = flex_acl_hw_db_counter_index_ref_list_get(counter_id, &counter_id_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("counter relocator : counter handler %u no found\n", counter_id);
        if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
            rc = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("counter relocator : error at callback\n");
        }
        goto out;
    }

    rc = flex_acl_block_relocate(counter_id_list, __counter_relocate_handle, &counter_relocate_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("counter relocator : failed block relocate\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_mc_container_change(adviser_event_e event_type, void *param)
{
    mc_container_pointer_change_event_data_t *container_chnage_info_p;
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    cl_list_t                                *mc_container_id_list = NULL;

    UNUSED_PARAM(event_type);
    SX_LOG_ENTER();

    container_chnage_info_p = (mc_container_pointer_change_event_data_t*)param;

    rc = flex_acl_hw_db_mc_container_index_ref_list_get(container_chnage_info_p->container_id, &mc_container_id_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("MC Container relocator : mc_container handle %u not found\n",
                   container_chnage_info_p->container_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_block_relocate(mc_container_id_list, __mc_container_relocate_handle, container_chnage_info_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Mc container relocator : failed block relocate\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_ecmp_container_change_handle(void                    *data_p,
                                                              flex_acl_hw_action_t    *action,
                                                              flex_acl_db_flex_rule_t *related_rule_p,
                                                              boolean_t               *found_p,
                                                              boolean_t               *handled_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    flex_acl_hw_ecmp_container_change_data_t *ecmp_container_change_data_p =
        (flex_acl_hw_ecmp_container_change_data_t*)data_p;
    flex_acl_db_acl_region_t *region_p = NULL;
    boolean_t                 ecmp_changed = FALSE;
    struct sxd_action_slot   *action_slot_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found_p, "found_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(found_p, "handled_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(data_p, "data_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(action, "action"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(related_rule_p, "related_rule_p"))) {
        goto out;
    }

    *found_p = FALSE;
    *handled_p = FALSE;

    action_slot_p = &action->slot;

    /* If the ECMP size remained at zero size we don't have anything to do */
    if ((ecmp_container_change_data_p->new_ecmp_size == 0) && (ecmp_container_change_data_p->old_ecmp_size == 0)) {
        *found_p = TRUE;
        *handled_p = TRUE;
        SX_LOG_DBG("ACL: ECMP change with both old and new size equal to 0\n");
        goto out;
    }

    /* If ECMP container changed from empty to full or from full to empty - different handle */
    if (((ecmp_container_change_data_p->new_ecmp_size == 0) && (ecmp_container_change_data_p->old_ecmp_size != 0)) ||
        ((ecmp_container_change_data_p->new_ecmp_size != 0) && (ecmp_container_change_data_p->old_ecmp_size == 0))) {
        if ((ecmp_container_change_data_p->new_ecmp_size != 0) && (ecmp_container_change_data_p->old_ecmp_size == 0)) {
            /* Container is not empty any more. If we added ACL DROP Trap action
             * when container was empty, we need to remove it now.
             * Only remove the db entry here. The trap action will be overwritten with the
             * right one later
             */
            SX_LOG_DBG("ECMP Container is not empty anymore. Delete entry from acl relocate db for action.type %u\n",
                       action_slot_p->type);
            SX_LOG_DBG("new_ecmp_size =%u, old_ecmp_size =%u ecmp_block_handle = :0x%" PRIx64 "\n",
                       ecmp_container_change_data_p->new_ecmp_size,
                       ecmp_container_change_data_p->old_ecmp_size,
                       ecmp_container_change_data_p->ecmp_block_handle);

            rc = __empty_cont_del_acl_drop_trap_action_from_db(related_rule_p, action_slot_p);

            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("error find & del acl drop trap entry from acl relocate db [%s]\n", sx_status_str(rc));
                goto out;
            }
        }
        /* Rewrite the rule */
        rc = flex_acl_db_region_get(related_rule_p->region_id, &region_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Get ACL region failed, region_id: %u\n", related_rule_p->region_id);
            goto out;
        }
        rc = __flex_acl_hw_write_only_rule_to_devs(related_rule_p,
                                                   region_p,
                                                   FLEX_ACL_HW_ALLOW_WRITE_ONLY_ACTION,
                                                   FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Fatal error: Failed writing rule.\n");
            goto out;
        }
        *found_p = TRUE;
        *handled_p = TRUE;
        SX_LOG_DBG("Rewrite rule .\n");
        goto out;
    }

    if ((ecmp_container_change_data_p->new_adjacency_index != ecmp_container_change_data_p->old_adjacency_index) ||
        (ecmp_container_change_data_p->new_ecmp_size != ecmp_container_change_data_p->old_ecmp_size)) {
        ecmp_changed = TRUE;
    } else if ((action_slot_p->fields.action_uc_router.type == SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E) &&
               (ecmp_container_change_data_p->new_arlpgt_index != ecmp_container_change_data_p->old_arlpgt_index)) {
        ecmp_changed = TRUE;
    }

    if (action_slot_p->type == SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E) {
        switch (action_slot_p->fields.action_uc_router.type) {
        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
            if (ecmp_changed) {
                /* Something is changed */
                action_slot_p->fields.action_uc_router.structs.ip_remote.adjacency_index =
                    ecmp_container_change_data_p->new_adjacency_index;
                action_slot_p->fields.action_uc_router.structs.ip_remote.ecmp_size =
                    ecmp_container_change_data_p->new_ecmp_size;
            } else {
                /* Nothing is changed. */
                *handled_p = TRUE;
            }
            *found_p = TRUE;
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
            if (ecmp_changed) {
                action_slot_p->fields.action_uc_router.structs.ar_uc_route.arft_pointer =
                    ecmp_container_change_data_p->new_adjacency_index;
                action_slot_p->fields.action_uc_router.structs.ar_uc_route.ecmp_size =
                    ecmp_container_change_data_p->new_ecmp_size;
                action_slot_p->fields.action_uc_router.structs.ar_uc_route.arlpgt_pointer =
                    ecmp_container_change_data_p->new_arlpgt_index;
            } else {
                /* Nothing is changed. */
                *handled_p = TRUE;
            }
            *found_p = TRUE;
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
            if (ecmp_changed) {
                /* Something is changed */
                action_slot_p->fields.action_uc_router.structs.mpls_ilm.ilm_ptr =
                    ecmp_container_change_data_p->new_adjacency_index;
            } else {
                /* Nothing is changed. */
                *handled_p = TRUE;
            }
            *found_p = TRUE;
            break;

        default:
            break;
        }
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_acl_hw_ecmp_container_change(hwi_ecmp_hw_block_handle_t ecmp_block_handle,
                                              sx_ecmp_container_type_e   container_type,
                                              uint32_t                   old_adjacency_index,
                                              uint32_t                   old_arlpgt_index,
                                              hwd_ecmp_block_size_t      old_ecmp_size,
                                              uint32_t                   new_adjacency_index,
                                              uint32_t                   new_arlpgt_index,
                                              hwd_ecmp_block_size_t      new_ecmp_size)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    cl_list_t                               *ecmp_container_id_list = NULL;
    flex_acl_hw_ecmp_container_change_data_t ecmp_container_change_data;

    SX_LOG_ENTER();

    if (flex_acl_is_initialized() == FALSE) {
        goto out;
    }

    ecmp_container_change_data.ecmp_block_handle = ecmp_block_handle;
    ecmp_container_change_data.old_adjacency_index = old_adjacency_index;
    ecmp_container_change_data.old_arlpgt_index = old_arlpgt_index;
    ecmp_container_change_data.old_ecmp_size = old_ecmp_size;
    ecmp_container_change_data.new_adjacency_index = new_adjacency_index;
    ecmp_container_change_data.new_arlpgt_index = new_arlpgt_index;
    ecmp_container_change_data.new_ecmp_size = new_ecmp_size;

    if (container_type != SX_ECMP_CONTAINER_TYPE_MPLS) {
        rc = flex_acl_hw_db_ecmp_container_index_ref_list_get(ecmp_block_handle, &ecmp_container_id_list);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_DBG("ECMP Container relocator : ecmp_container handle %" PRIu64 " not found\n", ecmp_block_handle);
            rc = SX_STATUS_SUCCESS;
        } else {
            rc = flex_acl_block_relocate(ecmp_container_id_list,
                                         __flex_acl_hw_ecmp_container_change_handle,
                                         &ecmp_container_change_data);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL ECMP container relocator : failed block relocate\n");
                goto out;
            }
        }
    } else {
        /* Update the pbilm using this ecmp. Write to the he will be done only if new size > 0. */
        rc = flex_acl_db_pbilm_foreach(__flex_acl_hw_pbilm_nhfle_change_cb, &ecmp_container_change_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex ACL PBILM foreach iterator failed.\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_ftn_change(kvd_linear_manager_handle_t       mpls_adj_block_handle,
                                   kvd_linear_manager_index_t        mpls_adj_old_index,
                                   kvd_linear_manager_index_t        mpls_adj_new_index,
                                   hwi_ecmp_hw_block_handle_t        ecmp_block_handle,
                                   kvd_linear_manager_block_length_t old_ecmp_size,
                                   kvd_linear_manager_block_length_t new_ecmp_size)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    cl_list_t                               *ecmp_container_id_list = NULL;
    flex_acl_hw_ecmp_container_change_data_t ecmp_container_change_data;

    UNUSED_PARAM(mpls_adj_block_handle);

    SX_LOG_ENTER();

    if (flex_acl_is_initialized() == FALSE) {
        goto out;
    }

    /* From the ACL module perspective a change in the ftn/mpls_adj is handled the same
     * as a change in the ecmp container itself.
     * Therefore we utilize the __flex_acl_hw_ecmp_container_change_handle function to do our work.
     * We just need to translate the size to the size of the relevant ftn size.
     * Note: if the ecmp size is already zero changing the location of the mpls_adj
     * doesn't change a thing so we get out.
     */
    if ((old_ecmp_size != 0) || (new_ecmp_size != 0)) {
        ecmp_container_change_data.ecmp_block_handle = ecmp_block_handle;
        ecmp_container_change_data.old_adjacency_index = mpls_adj_old_index;
        ecmp_container_change_data.old_ecmp_size = (old_ecmp_size > 0) ? 1 : 0;
        ecmp_container_change_data.new_adjacency_index = mpls_adj_new_index;
        ecmp_container_change_data.new_ecmp_size = (new_ecmp_size > 0) ? 1 : 0;

        rc = flex_acl_hw_db_ecmp_container_index_ref_list_get(ecmp_block_handle, &ecmp_container_id_list);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_DBG("ACL FTN relocator : ecmp_container handle %" PRIu64 " not found\n", ecmp_block_handle);
            rc = SX_STATUS_SUCCESS;
        } else {
            rc = flex_acl_block_relocate(ecmp_container_id_list,
                                         __flex_acl_hw_ecmp_container_change_handle,
                                         &ecmp_container_change_data);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL FTN relocator : failed block relocate\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* Update the related rules for the PBILM. */
sx_status_t flex_acl_hw_pbilm_update_nhfle_related_rules(sx_acl_pbilm_id_t                         pbilm_id,
                                                         flex_acl_hw_ecmp_container_change_data_t *container_change_data)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    cl_list_t  *pbilm_kvd_id_list = NULL;

    rc = flex_acl_hw_db_pbilm_index_ref_list_get(pbilm_id, &pbilm_kvd_id_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("ECMP Container relocator : PBILM KVD ID %u not found\n", pbilm_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }
    rc = flex_acl_block_relocate(pbilm_kvd_id_list,
                                 __flex_acl_hw_ecmp_container_change_handle,
                                 container_change_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL ECMP NHLFE container relocator : failed block relocate\n");
        goto out;
    }
out:
    return rc;
}

static sx_status_t __flex_acl_hw_pbilm_nhfle_change_cb(flex_acl_db_pbilm_entry_t *pbilm_entry, void *param_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    flex_acl_hw_ecmp_container_change_data_t *container_change_data =
        (flex_acl_hw_ecmp_container_change_data_t*)param_p;

    /* Check if the changed handle is relevant here */
    if (container_change_data->ecmp_block_handle != pbilm_entry->nhlfe_handle) {
        goto out;
    }

    pbilm_entry->nhlfe_size = container_change_data->new_ecmp_size;
    pbilm_entry->nhlfe_index = container_change_data->new_adjacency_index;

    /* Update the PPBMI register with the new index. No write is done if size is zero */
    if (container_change_data->new_ecmp_size > 0) {
        rc = __flex_acl_hw_config_pbilm(pbilm_entry,
                                        container_change_data->new_adjacency_index,
                                        container_change_data->new_ecmp_size);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex ACL continue lookup relocation failed for PBILM id %u.\n", pbilm_entry->pbilm_id);
            goto out;
        }
        SX_LOG_DBG("Flex ACL continue lookup relocation for PBILM id %u.\n", pbilm_entry->pbilm_id);
    }

    /* If the size changed to/from zero there is a need to update the rule itself.
     * We utilize the general ecmp callback to achieve this goal.
     */
    if (((container_change_data->new_ecmp_size == 0) && (container_change_data->old_ecmp_size != 0)) ||
        ((container_change_data->new_ecmp_size != 0) && (container_change_data->old_ecmp_size == 0))) {
        rc = flex_acl_hw_pbilm_update_nhfle_related_rules(pbilm_entry->pbilm_id, container_change_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex ACL continue lookup relocation failed for PBILM id %u.\n", pbilm_entry->pbilm_id);
            goto out;
        }
    }
out:
    return rc;
}

sx_status_t flex_acl_hw_continue_lookup_change(kvd_linear_manager_handle_t handle,
                                               kvd_linear_manager_index_t  old_index,
                                               kvd_linear_manager_index_t  new_index)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    flex_acl_hw_ecmp_container_change_data_t container_change_data;

    UNUSED_PARAM(old_index);

    SX_LOG_ENTER();

    SX_MEM_CLR(container_change_data);

    if (flex_acl_is_initialized() == FALSE) {
        goto out;
    }

    container_change_data.ecmp_block_handle = handle;
    container_change_data.new_adjacency_index = new_index;
    container_change_data.old_adjacency_index = old_index;
    container_change_data.new_ecmp_size = 1;
    container_change_data.old_ecmp_size = 1;

    rc = flex_acl_db_pbilm_foreach(__flex_acl_hw_pbilm_nhfle_change_cb, &container_change_data);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex ACL PBILM foreach iterator failed.\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_span_relocate(sx_span_session_id_t     span_session_id,
                                      sx_span_session_id_int_t old_span_session_id_int,
                                      sx_span_session_id_int_t new_span_session_id_int)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_list_t           *span_id_list = NULL;
    span_relocate_data_t span_relocate_data;

    SX_LOG_ENTER();

    SX_LOG_DBG(" Span relocate new:%d \n", (int)new_span_session_id_int);

    memset(&span_relocate_data, 0, sizeof(span_relocate_data));

    span_relocate_data.old_index = old_span_session_id_int;
    span_relocate_data.new_index = new_span_session_id_int;
    span_relocate_data.span_session_id = span_session_id;

    rc = flex_acl_hw_db_mirror_index_ref_list_get(span_session_id, &span_id_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("Span relocator : span handler %u no found\n", span_session_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }


    rc = flex_acl_block_relocate(span_id_list, __span_relocate_handle, &span_relocate_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("counter relocator : failed block relocate\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_mc_tunnel_decap_change(adviser_event_e event_type, void *param)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    cl_list_t         *tunnel_decap_list = NULL;
    tunnel_decap_cb_t *tunnel_decap_info_p;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    tunnel_decap_info_p = (tunnel_decap_cb_t*)param;

    SX_LOG_DBG(" Tunnel decap relocate new:%d \n", (int)tunnel_decap_info_p->tunnel_id);

    rc = flex_acl_hw_db_tunnel_decap_index_ref_list_get(tunnel_decap_info_p->tunnel_id, &tunnel_decap_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("tunnel decap relocator : tunnel ID handler not found, id:%u\n", tunnel_decap_info_p->tunnel_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_block_relocate(tunnel_decap_list, __tunnel_decap_relocate_handle, param);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("tunnel decap relocator : failed block relocate\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __trap_id_relocate_handle(void                    *data,
                                             flex_acl_hw_action_t    *action,
                                             flex_acl_db_flex_rule_t *related_rule,
                                             boolean_t               *found,
                                             boolean_t               *handled)
{
    sx_trap_id_t            trap_id = *(sx_trap_id_t*)data;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    struct sxd_action_slot *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }

    *handled = FALSE;
    *found = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    if (((action_slot->type == SXD_ACTION_TYPE_TRAP_E) ||
         (action_slot->type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E)) &&
        (action_slot->fields.action_trap.trap_id == trap_id)) {
        *found = TRUE;
    }

out:
    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_hw_trap_id_prio_change(adviser_event_e event_type, void *param)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    cl_list_t   *trap_id_list_p = NULL;
    sx_trap_id_t trap_id;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    if (flex_acl_is_initialized() == FALSE) {
        goto out;
    }

    trap_id = *(sx_trap_id_t*)param;

    /* Is an ACL supported traps */
    if (SX_TRAP_ID_ACL_CHECK_RANGE(trap_id) == FALSE) {
        goto out;
    }

    SX_LOG_DBG("Trap ID [%u] prio has been changed\n", trap_id);

    rc = flex_acl_hw_db_trap_id_index_ref_list_get(trap_id, &trap_id_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_DBG("Trap ID [%u] handler wasn't found\n", trap_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_block_relocate(trap_id_list_p, __trap_id_relocate_handle, param);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to relocate the Trap ID [%u] block. err: %s\n", trap_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

inline static void __flex_acl_hw_pbs_to_mc_key(sx_acl_pbs_id_t pbs_id, sx_fid_t fid, fdb_ext_mc_key_t *key_p)
{
    key_p->fid = fid;
    key_p->key = (0x230000 | pbs_id);
}

sx_status_t flex_acl_hw_kvd_pbs_block_reloc(kvd_linear_manager_handle_t       handle,
                                            kvd_linear_manager_block_length_t size,
                                            kvd_linear_manager_block_length_t offset,
                                            const kvd_linear_manager_index_t *old_index,
                                            const kvd_linear_manager_index_t  new_index)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    cl_list_t               *pbs_list = NULL;
    pbs_relocate_data_t      pbs_relocate_data;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    boolean_t                mid_locked = FALSE;
    fdb_ext_mc_key_t         fdb_ext_mc_key;

    SX_MEM_CLR(fdb_ext_mc_key);

    SX_LOG_ENTER();

    UNUSED_PARAM(size);
    UNUSED_PARAM(offset);

    pbs_relocate_data.handle = handle;
    pbs_relocate_data.old_index = *old_index;
    pbs_relocate_data.new_index = new_index;

    rc = flex_acl_db_pbs_by_kvd_handle(handle, &pbs_entry);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("pbs relocator : pbs kvd handler not found in PBS DB, handle:0x%" PRIx64 " \n", handle);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    __flex_acl_hw_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &fdb_ext_mc_key);

    if (pbs_entry->is_system == FALSE) {
        if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
            (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
            rc = fdb_ext_mc_mac_addr_get_mid(pbs_entry->swid,
                                             fdb_ext_mc_key,
                                             &(pbs_entry->mid));
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_DBG("Failed to get mid for pbs id %u.\n", pbs_entry->pbs_id);
            }
            mid_locked = TRUE;
        }
    }

    rc = __flex_acl_hw_config_pbs_write_reg(pbs_entry, pbs_entry->is_vport, new_index);
    if (SX_STATUS_SUCCESS != rc) {
        if (mid_locked == TRUE) {
            if (SX_STATUS_SUCCESS !=
                fdb_ext_mc_mac_addr_unlock_mid(pbs_entry->swid, fdb_ext_mc_key)) {
                SX_LOG_ERR("Failed to unlock mid %u.\n", pbs_entry->mid);
            }
        }
        SX_LOG_ERR("ACL config PBS : led writing PBS register.\n");
        goto out;
    }

    if (mid_locked == TRUE) {
        rc = fdb_ext_mc_mac_addr_unlock_mid(pbs_entry->swid, fdb_ext_mc_key);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to unlock mid %u.\n", pbs_entry->mid);
            return rc;
        }
        mid_locked = FALSE;
    }

    rc = flex_acl_hw_db_pbs_index_ref_list_get(handle, &pbs_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("pbs relocator : pbs kvd handler %" PRIu64 " not found in rules\n", handle);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_block_relocate(pbs_list, __pbs_relocate_handle, &pbs_relocate_data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("pbs relocator : pbs kvd handler not found, handle:0x%" PRIx64 " old index:%u new index:%u \n",
                   pbs_relocate_data.handle, pbs_relocate_data.old_index, pbs_relocate_data.new_index);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_kvd_pbilm_block_reloc(kvd_linear_manager_handle_t       handle,
                                              kvd_linear_manager_block_length_t size,
                                              kvd_linear_manager_block_length_t offset,
                                              const kvd_linear_manager_index_t *old_index,
                                              const kvd_linear_manager_index_t  new_index)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t               *pbilm_entry = NULL;
    flex_acl_hw_ecmp_container_change_data_t container_change_data;


    UNUSED_PARAM(size);
    UNUSED_PARAM(offset);
    UNUSED_PARAM(old_index);

    SX_MEM_CLR(container_change_data);

    SX_LOG_ENTER();

    rc = flex_acl_db_pbilm_get_entry_by_kvd(handle, &pbilm_entry);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_DBG("pbilm relocator : pbilm kvd handler not found in PBILM DB, handle:0x%" PRIx64 " \n", handle);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    /* There is a point to updating only if the nhlfe itself is not empty */
    if (pbilm_entry->nhlfe_size > 0) {
        rc = __flex_acl_hw_config_pbilm_write_reg(new_index,
                                                  pbilm_entry->nhlfe_index,
                                                  pbilm_entry->nhlfe_size,
                                                  pbilm_entry->params.number_of_pops);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL config pbilm : failed writing pbilm register.\n");
            goto out;
        }
        /* Make sure that the entry moved. If so notify all the related rules. */
        if (new_index != old_index[offset]) {
            container_change_data.ecmp_block_handle = handle;
            container_change_data.new_adjacency_index = new_index;
            container_change_data.old_adjacency_index = old_index[offset];
            container_change_data.old_ecmp_size = 1;
            container_change_data.new_ecmp_size = 1;
            /* Go over all related rules and update the new index */
            rc = flex_acl_hw_pbilm_update_nhfle_related_rules(pbilm_entry->pbilm_id, &container_change_data);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed relocating rules for PBILM id %d.\n", pbilm_entry->pbilm_id);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __acl_hw_action_counter_policer_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                 flex_acl_db_flex_rule_t   *rule,
                                                                 flex_acl_relocation_data_t relocation_data,
                                                                 boolean_t                  add_ref)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    status = SX_STATUS_SUCCESS;
    policer_manager_index_t        index = 0;
    policer_manager_block_length_t size = 0;
    cm_hw_type_t                   cm_type = 0;
    cm_index_t                     cm_index = 0;
    cm_type_e                      type = 0;

    SX_LOG_ENTER();
    UNUSED_PARAM(rule);

    SX_LOG_DBG(" Type:%u add_ref:%d \n", hw_action->slot.fields.action_policing_monitoring.c_p, add_ref);
    switch (hw_action->slot.fields.action_policing_monitoring.c_p) {
    case SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E:
        if (add_ref) {
            rc = flex_acl_hw_db_counter_add_entry(hw_action->counter_id,
                                                  relocation_data.is_head,
                                                  relocation_data.kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL counter action failed flex_acl_hw_db_counter_add_entry failed, counter_id: %u\n",
                           hw_action->counter_id);
                goto out;
            }
        }
        rc = flow_counter_lock(hw_action->counter_id, &type, &cm_type, &cm_index);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flow_counter_lock failed, counter_id: %u\n", hw_action->counter_id);
            if (add_ref) {
                flex_acl_hw_db_counter_remove_entry(hw_action->counter_id, relocation_data.kvd_index_p);
            }
            goto out;
        }
        hw_action->is_locked = TRUE;
        hw_action->slot.fields.action_policing_monitoring.counter_set.type = cm_type;
        hw_action->slot.fields.action_policing_monitoring.counter_set.index = cm_index;
        SX_LOG_DBG("FLOWD ACL bind populate : action counter is LOCKED, cm_type:%d cm_index :%d \n", cm_type,
                   cm_index);

        if (add_ref) {
            rc = flow_counter_ref_inc(hw_action->counter_id);
            SX_LOG_DBG("FLOWD ACL bind populate : action counter ref INC, id:%d \n", hw_action->counter_id);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL counter action failed flow_counter_ref_inc failed, counter_id: %u\n",
                           hw_action->counter_id);
                status = flow_counter_unlock(hw_action->counter_id);
                if (SX_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Failed to unlock old counter, counter_id %u [%s]\n",
                               hw_action->counter_id, sx_status_str(status));
                }
                hw_action->is_locked = FALSE;
                flex_acl_hw_db_counter_remove_entry(hw_action->counter_id, relocation_data.kvd_index_p);
                goto out;
            }
            hw_action->is_ref_count_inc = TRUE;
        }
        if (hw_action->temp_release_lock == TRUE) {
            status = flow_counter_unlock(hw_action->counter_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to unlock old counter, counter_id %u [%s]\n",
                           hw_action->counter_id, sx_status_str(status));
            }
            hw_action->is_locked = FALSE;
        }
        break;

    case SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E:
        if (add_ref) {
            rc = flex_acl_hw_db_policer_add_entry(hw_action->policer_id,
                                                  relocation_data.is_head,
                                                  relocation_data.kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "ACL counter action failed flex_acl_hw_db_policer_add_entry failed, policer_id: %" PRIu64 "\n",
                    hw_action->policer_id);
                goto out;
            }
        }
        rc = policer_manager_handle_lock(hw_action->policer_id,
                                         POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                             hw_action->policer_id),
                                         &index,
                                         &size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL policer action failed  policer_manager_handle_lock failed, policer_id: %" PRIu64 "\n",
                       hw_action->policer_id);
            flex_acl_hw_db_policer_remove_entry(hw_action->policer_id, relocation_data.kvd_index_p);
            goto out;
        }
        hw_action->is_locked = TRUE;
        hw_action->slot.fields.action_policing_monitoring.pid = index;
        SX_LOG_DBG("FLOWD ACL bind populate : action policer is LOCKED, pid:%d \n", index);
        if (add_ref) {
            rc = policer_manager_ref_add(hw_action->policer_id,
                                         POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                             hw_action->policer_id));
            SX_LOG_DBG("FLOWD ACL bind populate : action policer ref ADD, handler:%d \n", (int)hw_action->policer_id);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL policer action failed policer_manager_ref_add failed, policer_id: %" PRIu64 "\n",
                           hw_action->policer_id);
                policer_manager_handle_release(hw_action->policer_id,
                                               POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                                   hw_action->policer_id));
                hw_action->is_locked = FALSE;
                flex_acl_hw_db_policer_remove_entry(hw_action->policer_id, relocation_data.kvd_index_p);
                goto out;
            }
            hw_action->is_ref_count_inc = TRUE;
        }
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __acl_hw_action_counter_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    rc = flow_counter_unlock(hw_action->counter_id);
    if (SX_STATUS_SUCCESS != rc) {
        goto out;
    }
    SX_LOG_DBG("FLOWD ACL action counter UNLOCK.\n");
    hw_action->is_locked = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_counter_policer_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_action->is_locked == FALSE) {
        goto out;
    }

    switch (hw_action->slot.fields.action_policing_monitoring.c_p) {
    case SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E:
        rc = __acl_hw_action_counter_release_lock(hw_action);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL CM action failed flow_counter_unlock failed, counter_id: %u\n", hw_action->counter_id);
            goto out;
        }
        break;

    case SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E:
        rc = policer_manager_handle_release(hw_action->policer_id,
                                            POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                                hw_action->policer_id));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("FLOWD ACL CM action failed policer_manager_handle_release failed, policer_id: %" PRIu64 "\n",
                       hw_action->policer_id);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        SX_LOG_DBG("FLOWD ACL action Policer UNLOCK.\n");
        hw_action->is_locked = FALSE;
        break;

    default:
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* The following API Actions map to SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E
 *  FORWARD(with/without drop), TRAP-W-USER-DEF-VAL
 *  This function will iterate the list of actions, and merge all of the above
 *  into a single SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E action. All others will
 *  be deleted.
 */
static sx_status_t __flex_acl_merge_trap_w_usr_def_actions(hw_action_list_t *hw_action_list_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    cl_list_item_t         *p_item = NULL;
    const cl_list_item_t   *p_end = NULL;
    hw_action_list_entry_t *hw_action_list_entry_p = NULL;
    hw_action_list_entry_t *hw_action_list_entry_trap_w_udf_p = NULL;
    hw_action_list_entry_t *hw_action_entry_forward_p = NULL;
    flex_acl_rule_id_t      rule_id;
    uint64_t                acl_drop_trap_handle = 0;

    SX_LOG_ENTER();
    p_item = cl_qlist_head(&hw_action_list_p->qlist);
    p_end = cl_qlist_end(&hw_action_list_p->qlist);
    while (p_item != p_end) {
        hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);

        if (hw_action_list_entry_p->hw_action.action_type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
            if (hw_action_list_entry_p->hw_action.api_action_type == SX_FLEX_ACL_ACTION_TRAP_W_USER_ID) {
                hw_action_list_entry_trap_w_udf_p = hw_action_list_entry_p;
            } else if (hw_action_list_entry_p->hw_action.api_action_type == SX_FLEX_ACL_ACTION_FORWARD) {
                /* two cases apply
                 * 1. Regular Forward
                 * 2. ACL Drop Trap or System ACL Drop Trap
                 */
                hw_action_entry_forward_p = hw_action_list_entry_p;
            }
        }
        p_item = cl_qlist_next(p_item);
    }
    /* -------------------------------------------------------------|
     * | #  | FWD     | TRAP-W-USER-ID |    What to do              |
     * |------------------------------------------------------------|
     * |    |    0    |       0        |                            |
     * |    |--------------------------|  Nothing to do             |
     * |  A |    0    |       1        |                            |
     * |    |--------------------------|                            |
     * |    |    1    |       0        |                            |
     * |------------------------------------------------------------|
     * |    |    1    |       1        |dst = trap-w-usr-id         |
     * |  B |         |                |merge fwd params            |
     * |    |         |                |Del: FWD action             |
     * |    |         |                |     acl drop db entry      |
     * |------------------------------------------------------------|
     *
     */
    if (!hw_action_list_entry_trap_w_udf_p || !hw_action_entry_forward_p) {
        /* Row A: nothing to merge */
        goto out;
    }

    /* Merge the fwd and trap params - Row B*/

    hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.forward_action =
        hw_action_entry_forward_p->hw_action.slot.fields.action_trap.forward_action;

    hw_action_list_entry_trap_w_udf_p->hw_action.original_forward_action =
        hw_action_entry_forward_p->hw_action.original_forward_action;

    if ((hw_action_entry_forward_p->hw_action.slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
        (hw_action_entry_forward_p->hw_action.slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP) ||
        (hw_action_entry_forward_p->hw_action.slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX)) {
        /* we need to delete the entry from WJH ACL Drop DB if it was added
         * irrespective of WJH ACL DROP monitoring state
         */
        acl_drop_trap_handle = hw_action_entry_forward_p->hw_action.acl_drop_trap_handle;
        rule_id.region_id = FLEX_ACL_DROP_TRAP_HANDLE_TO_REGION(acl_drop_trap_handle);
        rule_id.offset = FLEX_ACL_DROP_TRAP_HANDLE_TO_OFFSET(acl_drop_trap_handle);

        rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Deleting action from ACL drop DB failed [%s]\n", sx_status_str(rc));
            goto out;
        }
    }
    rc = flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_p, &hw_action_entry_forward_p);
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        rc = SX_STATUS_SUCCESS;
    } else if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("removing forward action block failed [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* During action generation
 * SX API actions TRAP, MIRROR and EGRESS_MIRROR are mapped to SXD_ACTION_TYPE_TRAP_E.
 * SX API action FORWARD is mapped to SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E.
 * SX API action TRAP-W-USR-ID is mapped to SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E
 * If both SXD_ACTION_TYPE_TRAP_E & SX_FLEX_ACL_ACTION_TRAP_W_USER_ID exists in rule,
 * the action SXD_ACTION_TYPE_TRAP_E must be merged into SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E.
 * Actions SX_FLEX_ACL_ACTION_TRAP_W_USER_ID and SX_FLEX_ACL_ACTION_TRAP cannot exist together.
 */
static sx_status_t __flex_acl_hw_actions_merge_trap_actions(hw_action_list_t *hw_action_list_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    cl_list_item_t         *p_item = NULL;
    const cl_list_item_t   *p_end = NULL;
    hw_action_list_entry_t *hw_action_list_entry_p = NULL;
    hw_action_list_entry_t *hw_action_list_entry_trap_p = NULL;
    hw_action_list_entry_t *hw_action_list_entry_trap_w_udf_p = NULL;
    flex_acl_rule_id_t      rule_id;
    uint64_t                acl_drop_trap_handle = 0;

    SX_LOG_ENTER();

    /* With the WJH ACL Drop feature, we map FORWARD to SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E.
     * SX_FLEX_ACL_ACTION_TRAP_W_USER_ID also maps to SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E.
     * So it is possible to have more than 1 SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in the list.
     * This can happen when user configures TRAP-W-USR_DEF + FORWARD action
     * To ensure that order of user action list doesn't matter, we insert separate
     * SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E blocks and merge them. This way we
     * will be able to give user trap priority over acl drop trap.
     * Therefore
     *
     * Step 1: merge all TRAP_W_USER_DEF_VAL actions first
     */
    rc = __flex_acl_merge_trap_w_usr_def_actions(hw_action_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error while merging Trap-W-Usr-Def actions [%s]\n", sx_status_str(rc));
        goto out;
    }

    /* Step 2. Merge SXD_ACTION_TYPE_TRAP_E (Trap , Mirror) AND
     *          SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E
     */

    p_item = cl_qlist_head(&hw_action_list_p->qlist);
    p_end = cl_qlist_end(&hw_action_list_p->qlist);
    while (p_item != p_end) {
        hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);

        switch (hw_action_list_entry_p->hw_action.action_type) {
        case SXD_ACTION_TYPE_TRAP_E:
            hw_action_list_entry_trap_p = hw_action_list_entry_p;
            break;

        case SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E:
            hw_action_list_entry_trap_w_udf_p = hw_action_list_entry_p;
            break;

        default:
            /* Ignore all the OTHER action types */
            break;
        }
        p_item = cl_qlist_next(p_item);
    }
    /* ---------------------------------------------------------------|
     * | #  | TRAP-W-USER-ID | TRAP |    What to do                   |
     * |--------------------------------------------------------------|
     * |    |       0        |  0   |                                 |
     * |  A |-----------------------|  Nothing to do                  |
     * |    |       0        |  1   |                                 |
     * |    |-----------------------|                                 |
     * |    |       1        |  0   |                                 |
     * |--------------------------------------------------------------|
     * |  B |       1        |  1   |dst = trap-w-usr-id              |
     * |    |                |      |copy mirror params               |
     * |    |                |      |if ACL DROP & trap->trap_id != 0 |
     * |    |                |      |       copy trap params,         |
     * |    |                |      |del TRAP action                  |
     * |--------------------------------------------------------------|
     */

    if (!hw_action_list_entry_trap_p || !hw_action_list_entry_trap_w_udf_p) {
        /* Row A: nothing to merge */
        goto out;
    }

    /* First Merge the mirror action params*/
    hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.mirror_agent =
        hw_action_list_entry_trap_p->hw_action.slot.fields.action_trap.mirror_agent;

    hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.mirror_enable =
        hw_action_list_entry_trap_p->hw_action.slot.fields.action_trap.mirror_enable;

    hw_action_list_entry_trap_w_udf_p->hw_action.span_session_id =
        hw_action_list_entry_trap_p->hw_action.span_session_id;

    hw_action_list_entry_trap_w_udf_p->hw_action.span_user_handle =
        hw_action_list_entry_trap_p->hw_action.span_user_handle;

    hw_action_list_entry_trap_w_udf_p->hw_action.is_egress_mirror =
        hw_action_list_entry_trap_p->hw_action.is_egress_mirror;

    if (hw_action_list_entry_trap_p->hw_action.slot.fields.action_trap.trap_id != 0) {
        /* user configured regular trap action which is higher priority than ACL DROP*/

        switch (hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.trap_id) {
        case SX_TRAP_ID_ACL_DROP:
            acl_drop_trap_handle = hw_action_list_entry_trap_w_udf_p->hw_action.acl_drop_trap_handle;
            rule_id.region_id = FLEX_ACL_DROP_TRAP_HANDLE_TO_REGION(acl_drop_trap_handle);
            rule_id.offset = FLEX_ACL_DROP_TRAP_HANDLE_TO_OFFSET(acl_drop_trap_handle);

            rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("deleting action from acl drop db failed [%s]\n", sx_status_str(rc));
                goto out;
            }
            hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.user_def_val = 0;

        /* Fall Through */
        case 0:
            /* ACL drop Trap monitoring is disabled. */
            hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.trap_action =
                hw_action_list_entry_trap_p->hw_action.slot.fields.action_trap.trap_action;
            hw_action_list_entry_trap_w_udf_p->hw_action.slot.fields.action_trap.trap_id =
                hw_action_list_entry_trap_p->hw_action.slot.fields.action_trap.trap_id;

            break;

        default:
            break;
        }
    }

    rc = flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_p,
                                                       &hw_action_list_entry_trap_p);
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        rc = SX_STATUS_SUCCESS;
    } else if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("removing trap action block failed [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Function to generate an array of HW actions associated with the list of API actions. */
static sx_status_t __flex_acl_gen_hw_actions(sx_flex_acl_flex_action_t actions[],
                                             uint32_t                  actions_count,
                                             boolean_t                 is_defer,
                                             flex_acl_rule_id_t        rule_id,
                                             hw_action_list_t         *hw_action_list_p)
{
    uint32_t                   i = 0;
    uint32_t                   j = 0;
    sxd_flex_acl_action_type_t new_hw_action_type = SXD_ACTION_TYPE_NULL_E;
    hw_action_position_e       new_hw_action_pos = FLEX_ACL_HW_ACTION_POSITION_INVALID_E;
    sxd_flex_acl_action_type_t member_hw_action_type = SXD_ACTION_TYPE_NULL_E;
    hw_action_position_e       member_hw_action_pos = FLEX_ACL_HW_ACTION_POSITION_INVALID_E;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rc_rb = SX_STATUS_SUCCESS;
    boolean_t                  add_new_action;
    flex_acl_hw_action_t       hw_action_new;
    cl_list_item_t            *p_item = NULL, *p_prev_item = NULL;
    cl_list_item_t            *p_tail = NULL;
    const cl_list_item_t      *p_end = NULL;
    hw_action_list_entry_t    *hw_action_list_entry_p = NULL, *first_hw_action_list_entry_p = NULL;
    uint32_t                   hw_instance = 0, hw_instance_count = 1;
    int32_t                    relative_position = 0;

    SX_LOG_ENTER();

    for (i = 0; i < actions_count; i++) {
        for (j = 0; j < sx_flex_acl_actions_details[actions[i].type].hw_actions_count; j++) {
            hw_instance_count = 1;
            if (sx_flex_acl_actions_details[actions[i].type].hw_actions[j].is_map_action_cb &&
                (sx_flex_acl_actions_details[actions[i].type].hw_actions[j].is_map_action_cb(&actions[i],
                                                                                             sx_flex_acl_actions_details
                                                                                             [actions[i].type].
                                                                                             hw_actions[j].
                                                                                             action_modifier,
                                                                                             &hw_instance_count) ==
                 FALSE)) {
                continue;
            }
            new_hw_action_type = sx_flex_acl_actions_details[actions[i].type].hw_actions[j].hw_action;
            new_hw_action_pos = flex_acl_hw_action_details[new_hw_action_type].position_cb ?
                                flex_acl_hw_action_details[new_hw_action_type].position_cb(&actions[i],
                                                                                           new_hw_action_type) :
                                FLEX_ACL_HW_ACTION_POSITION_INVALID_E;
            if (new_hw_action_pos == FLEX_ACL_HW_ACTION_POSITION_INVALID_E) {
                SX_LOG_ERR("Position definition failed for API action %d, HW action %d\n",
                           actions[i].type, new_hw_action_type);
                rc = SX_STATUS_ERROR;
                goto rollback;
            }

            /* look for existing action at array. Hw should be populated only once even
             * if referred to by more the one API action.
             * If required HW action is found and it is possible to use it avoid creating another HW action block. */
            p_item = cl_qlist_tail(&hw_action_list_p->qlist);
            p_end = cl_qlist_end(&hw_action_list_p->qlist);
            add_new_action = TRUE;
            relative_position = 0;
            while (p_item != p_end) {
                hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);

                member_hw_action_type = hw_action_list_entry_p->hw_action.action_type;
                member_hw_action_pos = hw_action_list_entry_p->hw_action.position;

                if ((new_hw_action_pos == FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E) ||
                    ((new_hw_action_pos == FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E) &&
                     (member_hw_action_pos == FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E))
                    ) {
                    /* Exit the check loop and add the new action */
                    add_new_action = TRUE;
                    break;
                }

                relative_position--;
                /* Try to re-use the HW action */
                if ((member_hw_action_type == new_hw_action_type) &&
                    (flex_acl_hw_action_details[new_hw_action_type].is_hw_action_reuse &&
                     flex_acl_hw_action_details[new_hw_action_type].
                     is_hw_action_reuse(&actions[i], &hw_action_list_entry_p->hw_action, relative_position))) {
                    SX_LOG_DBG("ACL: Reusing HW action type:%d\n", hw_action_list_entry_p->hw_action.action_type);
                    add_new_action = FALSE;
                    /* p_item contains the current */
                    break;
                }

                p_item = cl_qlist_prev(p_item);
            }
            first_hw_action_list_entry_p = hw_action_list_entry_p;
            if (add_new_action) {
                SX_LOG_DBG("ACL: Creating new HW action type:%d\n", new_hw_action_type);
                SX_MEM_CLR(hw_action_new);

                hw_action_new.action_type = new_hw_action_type;
                hw_action_new.slot.type = new_hw_action_type;
                hw_action_new.action_modifier =
                    sx_flex_acl_actions_details[actions[i].type].hw_actions[j].action_modifier;
                hw_action_new.api_action_type =
                    (hw_action_new.action_modifier ==
                     FLEX_ACL_ACTION_MODEFIER_IGMPV3_PBS_E) ?
                    SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST : actions[i].type;
                hw_action_new.position = new_hw_action_pos;

                for (hw_instance = 0; hw_instance < hw_instance_count; hw_instance++) {
                    rc = flex_acl_hw_db_hw_action_list_insert_tail(hw_action_list_p,
                                                                   &hw_action_new,
                                                                   &hw_action_list_entry_p);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("flex_acl_hw_db_hw_action_list_insert_tail failed, [%s]\n", sx_status_str(rc));
                        goto out;
                    }
                    if (hw_instance == 0) {
                        first_hw_action_list_entry_p = hw_action_list_entry_p;
                    }
                }
            }

            if (flex_acl_hw_action_details[new_hw_action_type].pre_bind_populate) {
                rc = flex_acl_hw_action_details[new_hw_action_type].pre_bind_populate(actions[i],
                                                                                      is_defer,
                                                                                      rule_id,
                                                                                      hw_action_list_p,
                                                                                      first_hw_action_list_entry_p);
                if (SX_STATUS_SUCCESS != rc) {
                    rc_rb = flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_p, &hw_action_list_entry_p);
                    if (rc_rb == SX_STATUS_ENTRY_NOT_FOUND) {
                        rc_rb = SX_STATUS_SUCCESS;
                    } else if (rc_rb != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("flex_acl_hw_db_hw_action_list_remove_and_next failed [%s]\n",
                                   sx_status_str(rc_rb));
                        goto out;
                    }
                    goto rollback;
                }
            }
        }
    }

    /* Take care of the actions, which require ordering - action with FLEX_ACL_HW_ACTION_POSITION_END_E
     * move to the end.*/
    p_end = cl_qlist_end(&hw_action_list_p->qlist);
    p_tail = p_item = cl_qlist_tail(&hw_action_list_p->qlist);
    while (p_item != p_end) {
        hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);
        p_prev_item = cl_qlist_prev(p_item);
        if ((hw_action_list_entry_p->hw_action.position == FLEX_ACL_HW_ACTION_POSITION_END_E) &&
            (p_item != p_tail)) {
            rc = flex_acl_hw_db_hw_action_list_move_2tail(hw_action_list_p, hw_action_list_entry_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("flex_acl_hw_db_hw_action_list_move_2tail failed, [%s]\n", sx_status_str(rc));
                goto out; /* Fatal */
            }
        }
        p_item = p_prev_item;
    }

    goto out;

rollback:
    p_item = cl_qlist_head(&hw_action_list_p->qlist);
    p_end = cl_qlist_end(&hw_action_list_p->qlist);
    while (p_item != p_end) {
        hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);
        new_hw_action_type = hw_action_list_entry_p->hw_action.action_type;
        if (flex_acl_hw_action_details[new_hw_action_type].populate_rollback) {
            flex_acl_hw_action_details[new_hw_action_type].populate_rollback
                (rule_id, &hw_action_list_entry_p->hw_action);
        }
        p_item = cl_qlist_next(p_item);
    }
out:
    SX_LOG_EXIT();

    return rc;
}

/* will be pre-populated */
static sx_status_t flex_acl_hw_populate_goto_cmd(flex_acl_db_flex_rule_t *rule_ptr,
                                                 sxd_goto_set_action_t   *goto_set_action,
                                                 boolean_t                rebind)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_flex_acl_flex_action_goto_t goto_api_action;
    boolean_t                      is_found = FALSE;
    flex_acl_bind_attribs_id_t     bind_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    boolean_t                      is_empty_group = FALSE;

    SX_LOG_ENTER();

    rc = flex_acl_db_rule_get_goto_action(rule_ptr, &is_found, &goto_api_action);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get goto action failed, region_id: %u, rc:%s\n", rule_ptr->region_id, sx_status_str(rc));
        goto out;
    }

    if (!is_found) {
        goto_set_action->binding_cmd = SXD_FLEX_BINDING_NONE_E;
        goto out;
    }

    if ((goto_api_action.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
        (goto_api_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
        rc = rebind_group_cb_g.bind_group_cb(rule_ptr, rebind, &bind_id, &is_empty_group);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR_RESOURCE_COND(rc,
                                     "Failed to bind group on goto action, region_id[%x], offset[%u] rc:%s.\n",
                                     rule_ptr->region_id,
                                     rule_ptr->offset, sx_status_str(rc));
            goto out;
        }
    }

    switch (goto_api_action.goto_action_cmd) {
    case SX_ACL_ACTION_GOTO_JUMP:
        if (!is_empty_group) {
            goto_set_action->binding_cmd = SXD_FLEX_BINDING_JUMP_E;
            goto_set_action->next_binding = bind_id;
        } else {
            goto_set_action->binding_cmd = SXD_FLEX_BINDING_TERMINATE_E;
        }
        break;

    case SX_ACL_ACTION_GOTO_CALL:
        if (!is_empty_group) {
            goto_set_action->binding_cmd = SXD_FLEX_BINDING_CALL_E;
            goto_set_action->next_binding = bind_id;
        } else {
            goto_set_action->binding_cmd = SXD_FLEX_BINDING_NONE_E;
        }
        break;

    case SX_ACL_ACTION_GOTO_BREAK:
        goto_set_action->binding_cmd = SXD_FLEX_BINDING_BREAK_E;
        break;

    case SX_ACL_ACTION_GOTO_TERMINATE:
        goto_set_action->binding_cmd = SXD_FLEX_BINDING_TERMINATE_E;
        break;

    default:
        SX_LOG_ERR("Populate goto set unsupported goto type :%u \n", goto_api_action.goto_action_cmd);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}


/* should write updated action set to devices */
sx_status_t flex_acl_hw_goto_action_update(flex_acl_db_flex_rule_t *rule_p, boolean_t rebind)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t        *region_p = NULL;
    boolean_t                        is_bound = FALSE;
    flex_acl_hw_db_action_set_t     *register_action_set = NULL;
    const cl_list_t                 *kvd_action_set_list = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    cl_list_iterator_t               iter, list_head, list_end;

    register_action_set = rule_p->hw_action_handle;
    rc = flex_acl_hw_populate_goto_cmd(rule_p, &register_action_set->action_set.goto_action, rebind);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR_RESOURCE_COND(rc, "Populating goto command failed, region:%#x rc:%s\n",
                                 rule_p->region_id, sx_status_str(rc));
        goto out;
    }
    /* get kvd action  sets to update them with goto action */
    rc = flex_acl_hw_db_get_kvd_action_set_list(register_action_set, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }
    /* iterate on kvd action set and update goto action of each one */
    list_end = cl_list_end(kvd_action_set_list);
    list_head = cl_list_head(kvd_action_set_list);
    for (iter = list_head; iter != list_end; iter = cl_list_next(iter)) {
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        kvd_action_set->goto_action = register_action_set->action_set.goto_action;
    }


    rc = flex_acl_db_is_region_bound_to_dev(rule_p->region_id, &is_bound);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get ACL region failed, region_id: %u\n", rule_p->region_id);
        goto out;
    }
    if (is_bound) {
        rc = flex_acl_db_region_get(rule_p->region_id, &region_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Get ACL region failed, region -d[%x]\n", rule_p->region_id);
            goto out;
        }
        /* write only last action set to register with updated goto action */
        if (register_action_set->kvd_action_set_count == 0) {
            rc = flex_acl_hw_edit_action_register(register_action_set, FALSE);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed update actions of rule at GOTO group update, region id[%x], offset[%u]\n",
                           rule_p->region_id,
                           rule_p->offset);
                goto out;
            }
        } else {
            iter = cl_list_tail(kvd_action_set_list);

            kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);

            rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed update kvd action of rule at GOTO group update, region id[%x], offset[%u]\n",
                           rule_p->region_id,
                           rule_p->offset);
                goto out;
            }
        }
    }
    goto out;
out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __acl_hw_action_counter_policer_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                                   flex_acl_hw_action_t *hw_action2_p)
{
    if (hw_action1_p->action_type == hw_action2_p->action_type) {
        if ((hw_action1_p->slot.fields.action_policing_monitoring.c_p ==
             hw_action2_p->slot.fields.action_policing_monitoring.c_p)
            && (hw_action1_p->slot.fields.action_policing_monitoring.c_p ==
                SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E)) {
            return FALSE;
        }
    }
    return TRUE;
}

static boolean_t __acl_hw_action_hash_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                        flex_acl_hw_action_t *hw_action2_p)
{
    sx_gp_register_e gp_register = SX_GP_REGISTER_0_E;
    sx_acl_key_t     hash_field = FLEX_ACL_KEY_INVALID;
    sx_acl_key_t     other_field = FLEX_ACL_KEY_INVALID;

    /* Don't use the same action in the same action set */
    if (hw_action1_p->action_type == hw_action2_p->action_type) {
        return FALSE;
    }
    /* The hash CRC might read fields from the packet that has been changed by another action */
    if (hw_action2_p->slot.fields.action_hash.hash_cmd != SXD_HASH_FLEX_ACTION_CMD_CRC_E) {
        return TRUE;
    }
    /* Translate the hash field into a common key so it can be compared with other actions that might cause a hazard */
    hash_field = map_sxd_crc_hash_field[hw_action2_p->slot.fields.action_hash.hash_fields];

    if ((hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E) &&
        (hw_action1_p->slot.fields.action_custom_bytes_move.opcode == SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_STORE_E)) {
        other_field = map_sxd_action_field_select[hw_action1_p->slot.fields.action_custom_bytes_move.field_select];
    } else if (hw_action1_p->action_type == SXD_ACTION_TYPE_FIELDS_SET_IMM_E) {
        other_field = map_sxd_action_field_select[hw_action1_p->slot.fields.action_fields_set_imm.dest_field_select];
    } else if (hw_action1_p->action_type == SXD_ACTION_TYPE_FIELDS_MOVE_E) {
        other_field = map_sxd_action_field_select[hw_action1_p->slot.fields.action_fields_move.dest_field_select];
    } else if (hw_action1_p->action_type == SXD_ACTION_TYPE_SIP_DIP_E) {
        other_field =
            (hw_action1_p->slot.fields.action_sip_dip.direction == SXD_SIP_DIP_FLEX_ACTION_DIRECTION_DESTINATION_E) ?
            FLEX_ACL_KEY_DIP : FLEX_ACL_KEY_SIP;
    } else if (hw_action1_p->action_type == SXD_ACTION_TYPE_L4_PORT_E) {
        other_field =
            (hw_action1_p->slot.fields.action_l4_port.direction == SXD_L4_PORT_FLEX_ACTION_DIRECTION_DESTINATION_E) ?
            FLEX_ACL_KEY_L4_DESTINATION_PORT : FLEX_ACL_KEY_L4_SOURCE_PORT;
    } else if (hw_action1_p->action_type == SXD_ACTION_TYPE_MAC_E) {
        if (hw_action1_p->slot.fields.action_mac.mac_cmd == SXD_FLEX_MAC_CMD_TYPE_SET_DMAC_E) {
            other_field = FLEX_ACL_KEY_DMAC;
        } else if (hw_action1_p->slot.fields.action_mac.mac_cmd == SXD_FLEX_MAC_CMD_TYPE_SET_SMAC_E) {
            other_field = FLEX_ACL_KEY_SMAC;
        }
    }
    /* If we're accessing the same field this is a hazard and therefore we deny the combination */
    if ((hash_field != FLEX_ACL_KEY_INVALID) && (other_field != FLEX_ACL_KEY_INVALID) && (other_field == hash_field)) {
        return FALSE;
    }
    /* Due to HW limitations SIP and DIP are handled together and therefore can create a hazard */
    if (((hash_field == FLEX_ACL_KEY_DIP) && (other_field == FLEX_ACL_KEY_SIP)) ||
        ((hash_field == FLEX_ACL_KEY_SIP) && (other_field == FLEX_ACL_KEY_DIP))) {
        return FALSE;
    }
    /* Check if there is common access to GP_REGISTERS */
    if ((hw_action2_p->slot.fields.action_hash.hash_fields >= SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_1_0_E) &&
        (hw_action2_p->slot.fields.action_hash.hash_fields <= SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_7_6_E)) {
        /* Calculate the register the hash is accessing */
        gp_register =
            (hw_action2_p->slot.fields.action_hash.hash_fields -
             SXD_HASH_FLEX_ACTION_HASH_FIELD_GP_REGISTER_1_0_E) * 2;
        gp_register += (hw_action2_p->slot.fields.action_hash.hash_mask & 0xffff) ? 0 : 1;
        /* Now compare the hash register with those of the ALU actions */
        switch (hw_action1_p->action_type) {
        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E:
            if (hw_action1_p->slot.fields.action_custom_bytes_alu_imm.dest_cbset == gp_register) {
                return FALSE;
            }
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E:
            if (hw_action1_p->slot.fields.action_custom_bytes_alu_reg.dest_cbset == gp_register) {
                return FALSE;
            }
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E:
            if (hw_action1_p->slot.fields.action_custom_bytes_alu_field.cbset == gp_register) {
                return FALSE;
            }
            break;

        case SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E:
            if (hw_action1_p->slot.fields.action_custom_bytes_move.opcode !=
                SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_STORE_E) {
                if ((gp_register >= hw_action1_p->slot.fields.action_custom_bytes_move.dest_cbset) &&
                    (gp_register < hw_action1_p->slot.fields.action_custom_bytes_move.dest_cbset +
                     hw_action1_p->slot.fields.action_custom_bytes_move.size)) {
                    return FALSE;
                }
            }
            break;

        default:
            break;
        }
    }
    return TRUE;
}


/* This is a utility function to extract the source and destination cbset / register used in an action.
 * Used to detect action hazards of write/read, write/write.
 */
static void __acl_hw_action_cbset_get(flex_acl_hw_action_t *hw_action_p,
                                      uint8_t              *src_cbset,
                                      uint8_t              *dst_cbset)
{
    *src_cbset = FLEX_ACL_HW_INVALID_CBSET;
    *dst_cbset = FLEX_ACL_HW_INVALID_CBSET;

    switch (hw_action_p->action_type) {
    case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E:
        *dst_cbset = hw_action_p->slot.fields.action_custom_bytes_alu_imm.dest_cbset;
        break;

    case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E:
        *dst_cbset = hw_action_p->slot.fields.action_custom_bytes_alu_reg.dest_cbset;
        *src_cbset = hw_action_p->slot.fields.action_custom_bytes_alu_reg.src_cbset;
        break;

    case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E:
        *dst_cbset = hw_action_p->slot.fields.action_custom_bytes_alu_field.cbset;
        break;

    case SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E:
        switch (hw_action_p->slot.fields.action_custom_bytes_move.opcode) {
        case SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_MOVE_E:
            *dst_cbset = hw_action_p->slot.fields.action_custom_bytes_move.dest_cbset;
            *src_cbset = hw_action_p->slot.fields.action_custom_bytes_move.src_cbset;
            break;

        case SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_STORE_E:
            *src_cbset = hw_action_p->slot.fields.action_custom_bytes_move.src_cbset;
            break;

        case SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_LOAD_E:
            *dst_cbset = hw_action_p->slot.fields.action_custom_bytes_move.dest_cbset;
            break;

        default:
            break;
        }
        break;

    default:
        break;
    }
}

static boolean_t __acl_hw_action_alu_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                       flex_acl_hw_action_t *hw_action2_p)
{
    uint8_t src_cbset1 = FLEX_ACL_HW_INVALID_CBSET;
    uint8_t dst_cbset1 = FLEX_ACL_HW_INVALID_CBSET;
    uint8_t src_cbset2 = FLEX_ACL_HW_INVALID_CBSET;
    uint8_t dst_cbset2 = FLEX_ACL_HW_INVALID_CBSET;

    if (((hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E) ||
         (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E) ||
         (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E) ||
         (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E)) &&
        ((hw_action2_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E) ||
         (hw_action2_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E) ||
         (hw_action2_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E) ||
         (hw_action2_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E))) {
        if (ACL_STAGE_IS_FLEX3_OR_ABOVE(flex_acl_stage)) {
            /* Check that no two actions are causing hazards of write/read, write/write */
            __acl_hw_action_cbset_get(hw_action1_p, &src_cbset1, &dst_cbset1);
            __acl_hw_action_cbset_get(hw_action2_p, &src_cbset2, &dst_cbset2);
            if (((src_cbset2 == dst_cbset1) && (dst_cbset1 != FLEX_ACL_HW_INVALID_CBSET)) ||
                ((dst_cbset2 == dst_cbset1) && (dst_cbset1 != FLEX_ACL_HW_INVALID_CBSET))) {
                return FALSE;
            }
        } else {
            /* Due to HW limitation in SPC2/SPC3 ALU actions cannot be combined into a single actions set */
            return FALSE;
        }
    }
    return TRUE;
}

static boolean_t __acl_hw_action_alu_field_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                             flex_acl_hw_action_t *hw_action2_p)
{
    /* If the previous action set the hash we need to wait to use it if we're reading it*/
    if ((hw_action1_p->action_type == SXD_ACTION_TYPE_HASH_E) &&
        ((hw_action2_p->slot.fields.action_custom_bytes_alu_field.field_select ==
          SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_ECMP_HASH_E) ||
         (hw_action2_p->slot.fields.action_custom_bytes_alu_field.field_select ==
          SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_LAG_HASH_E))) {
        return FALSE;
    }
    /* Call the generic comparison of ALU actions */
    return __acl_hw_action_alu_action_set_comply(hw_action1_p, hw_action2_p);
}

static boolean_t __acl_hw_action_field_select_comply(flex_acl_hw_action_t                       *hw_action1_p,
                                                     sxd_custom_bytes_flex_action_field_select_t hw_action2_field_select)
{
    /* If the previous action set the hash we need to wait to use it if we're reading it*/
    if ((hw_action1_p->action_type == SXD_ACTION_TYPE_HASH_E) &&
        ((hw_action2_field_select == SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_ECMP_HASH_E) ||
         (hw_action2_field_select == SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_LAG_HASH_E))) {
        return FALSE;
    }
    /* If the previous action set the TTL value */
    else if ((hw_action2_field_select == SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TTL_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_MAC_E) &&
             (hw_action1_p->slot.fields.action_mac.ttl_cmd != SXD_FLEX_TTL_CMD_DO_NOTHING_E)) {
        return FALSE;
    }
    /* If the previous action set the VLAN value */
    else if ((hw_action2_field_select == SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VID_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_VLAN_E)) {
        return FALSE;
    }
    /* If the previous action set the SIP / DIP value */
    else if ((hw_action2_field_select >= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DIP_15_0_E) &&
             (hw_action2_field_select <= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SIP_127_112_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_SIP_DIP_E)) {
        return FALSE;
    }
    /* If the previous action set the SPORT / DPORT value */
    else if ((hw_action2_field_select >= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_SOURCE_PORT_E) &&
             (hw_action2_field_select <= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_L4_DESTINATION_PORT_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_L4_PORT_E)) {
        return FALSE;
    }
    /* If the previous action set the SMAC */
    else if ((hw_action2_field_select >= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_15_0_E) &&
             (hw_action2_field_select <= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_SMAC_47_32_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_MAC_E) &&
             (hw_action1_p->slot.fields.action_mac.mac_cmd == SXD_FLEX_MAC_CMD_TYPE_SET_SMAC_E)) {
        return FALSE;
    }
    /* If the previous action set the DMAC */
    else if ((hw_action2_field_select >= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_15_0_E) &&
             (hw_action2_field_select <= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_DMAC_47_32_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_MAC_E) &&
             (hw_action1_p->slot.fields.action_mac.mac_cmd == SXD_FLEX_MAC_CMD_TYPE_SET_DMAC_E)) {
        return FALSE;
    }
    /* If the previous action set the VNI */
    else if ((hw_action2_field_select >= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_15_0_E) &&
             (hw_action2_field_select <= SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_VNI_31_16_E) &&
             (hw_action1_p->action_type == SXD_ACTION_TYPE_VXLAN_E) &&
             (hw_action1_p->slot.fields.action_vni.set_vni == SXD_VNI_FLEX_ACTION_TYPE_SET_E)) {
        return FALSE;
    }

    return TRUE;
}

/* This is a utility function to get the field from an action.
 * Used to detect action hazards of write/read, write/write.
 */
static void __acl_hw_action_field_get(flex_acl_hw_action_t                        *hw_action_p,
                                      sxd_custom_bytes_flex_action_field_select_t *src_field_p,
                                      sxd_custom_bytes_flex_action_field_select_t *dst_field_p)
{
    *src_field_p = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;
    *dst_field_p = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;

    switch (hw_action_p->action_type) {
    case SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E:
        *src_field_p = hw_action_p->slot.fields.action_custom_bytes_alu_field.field_select;
        break;

    case SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E:
        switch (hw_action_p->slot.fields.action_custom_bytes_move.opcode) {
        case SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_STORE_E:
            *dst_field_p = hw_action_p->slot.fields.action_custom_bytes_move.field_select;
            break;

        case SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_LOAD_E:
            *src_field_p = hw_action_p->slot.fields.action_custom_bytes_move.field_select;
            break;

        default:
            break;
        }
        break;

    case SXD_ACTION_TYPE_FIELDS_SET_IMM_E:
        *dst_field_p = hw_action_p->slot.fields.action_fields_set_imm.dest_field_select;
        break;

    case SXD_ACTION_TYPE_FIELDS_MOVE_E:
        *dst_field_p = hw_action_p->slot.fields.action_fields_move.dest_field_select;
        *src_field_p = hw_action_p->slot.fields.action_fields_move.src_field_select;
        break;

    default:
        break;
    }
}

/* This functions checks if two actions (based on TLV_FIELD action) try to access the same packet fields.
 * Used to detect action hazards of write/read, write/write.
 */
static boolean_t __acl_hw_action_field_actions_check(flex_acl_hw_action_t *hw_action1_p,
                                                     flex_acl_hw_action_t *hw_action2_p)
{
    sxd_custom_bytes_flex_action_field_select_t src_field1 = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;
    sxd_custom_bytes_flex_action_field_select_t dst_field1 = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;
    sxd_custom_bytes_flex_action_field_select_t src_field2 = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;
    sxd_custom_bytes_flex_action_field_select_t dst_field2 = SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E;

    __acl_hw_action_field_get(hw_action1_p, &src_field1, &dst_field1);
    __acl_hw_action_field_get(hw_action2_p, &src_field2, &dst_field2);

    /* Check write after write hazard */
    if ((dst_field1 != SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E) &&
        (dst_field2 != SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E)) {
        /* We map a HW actions to a common action to check the entire field is not accessed */
        if (map_sxd_action_field_select[dst_field1] == map_sxd_action_field_select[dst_field2]) {
            return FALSE;
        }
    }
    /* Check read after write hazard */
    if ((dst_field1 != SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E) &&
        (src_field2 != SXD_CUSTOM_BYTES_FLEX_ACTION_FIELD_TYPE_LAST_E)) {
        /* We map a HW actions to a common action to check the entire field is not accessed */
        if (map_sxd_action_field_select[dst_field1] == map_sxd_action_field_select[src_field2]) {
            return FALSE;
        }
    }
    return TRUE;
}

static boolean_t __acl_hw_action_custom_byte_move_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                             flex_acl_hw_action_t *hw_action2_p)
{
    /* Check the field used in the action against other fields that might use the same field */
    if (hw_action2_p->slot.fields.action_custom_bytes_move.opcode != SXD_CUSTOM_BYTES_MOVE_ACTION_OPCODE_MOVE_E) {
        if (__acl_hw_action_field_actions_check(hw_action1_p, hw_action2_p) == FALSE) {
            return FALSE;
        }
        if (__acl_hw_action_field_select_comply(hw_action1_p,
                                                hw_action2_p->slot.fields.action_custom_bytes_move.field_select) ==
            FALSE) {
            return FALSE;
        }
    }
    /* Call the generic comparison of ALU actions */
    return __acl_hw_action_alu_action_set_comply(hw_action1_p, hw_action2_p);
}


static boolean_t __acl_hw_action_fields_set_imm_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                           flex_acl_hw_action_t *hw_action2_p)
{
    if (__acl_hw_action_field_actions_check(hw_action1_p, hw_action2_p) == FALSE) {
        return FALSE;
    }

    if (__acl_hw_action_field_select_comply(hw_action1_p,
                                            hw_action2_p->slot.fields.action_fields_set_imm.dest_field_select) ==
        FALSE) {
        return FALSE;
    }

    return TRUE;
}

static boolean_t __acl_hw_action_fields_move_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                        flex_acl_hw_action_t *hw_action2_p)
{
    if (__acl_hw_action_field_actions_check(hw_action1_p, hw_action2_p) == FALSE) {
        return FALSE;
    }

    if ((__acl_hw_action_field_select_comply(hw_action1_p,
                                             hw_action2_p->slot.fields.action_fields_move.src_field_select) ==
         FALSE) ||
        (__acl_hw_action_field_select_comply(hw_action1_p,
                                             hw_action2_p->slot.fields.action_fields_move.dest_field_select) ==
         FALSE)) {
        return FALSE;
    }

    return TRUE;
}


/**
 * Check that the action set has up to 2 counter actions but no more than 1 policer action and no more than 1 flow estimator action.
 * The following combinations are valid:
 * 1 policer and 1 counter (either flow counter or flow estimator counter)
 * 2 counters (1 can be flow estimator counter)
 * 1 policer or 1 counter (either flow counter or flow estimator counter)
 * Also, Mark counter as "temp_release_lock" when the sets have 2 counters with the same LID and this is the first counter in the set.
 */
static boolean_t __hw_action_fill_action_set_validate_counter_policer_estimator_action(
    flex_acl_hw_action_t  action_set[],
    uint32_t              action_set_idx,
    flex_acl_hw_action_t *hw_action_p)
{
    uint32_t  iii;
    boolean_t rc = TRUE;
    uint32_t  counters_in_set = 0;
    uint32_t  counter_in_set_index = 0;

    /* Check that the new action we want to add to the set is a counter action. If not, return true*/
    if (!(((hw_action_p->action_type == SXD_ACTION_TYPE_POLICING_COUNTING_E) &&
           (hw_action_p->slot.fields.action_policing_monitoring.c_p ==
            SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E)))
        &&
        (hw_action_p->action_type != SXD_ACTION_TYPE_FLOW_ESTIMATOR_E)) {
        goto out;
    }

    /*
     * A set can have up to 2 policer_counter actions, but no more than 1 policing or 1 time flow estimator:
     * 2 counter actions or 1 policer and 1 counter action.
     * The comply function already validates that we don't have more than 1 policer or 1 estimator in the set.
     * We only need to check that we don't have more than 2 policer_counter or estimator actions in the set.
     * */
    if (action_set_idx == 2) {
        if (ACTION_TYPE_IS_POLICING_COUNTING_OR_FLOW_ESTIMATOR(action_set[0].action_type) &&
            ACTION_TYPE_IS_POLICING_COUNTING_OR_FLOW_ESTIMATOR(action_set[1].action_type) &&
            ACTION_TYPE_IS_POLICING_COUNTING_OR_FLOW_ESTIMATOR(hw_action_p->action_type)) {
            rc = FALSE;
            goto out;
        }
    }

    /*Check if one of the existing actions in the set is a counter action or flow estimator action.
     * If one of the existing actions in the set is counter, we should compare the exist counter's LID against the new counter LID.
     */
    for (iii = 0; iii < action_set_idx; iii++) {
        if (IS_COUNTER_USED_IN_ACTION_SET(action_set[iii])) {
            counter_in_set_index = iii;
            counters_in_set++;
        }
    }

    /* Before writing the action set to the HW, SDK should lock each of the counter's LID.
     * If both counter actions have the same LID, the second lock will fail.
     * We have to take the lock in order to get the hardware index of counter. So we cannot skip taking the lock the second time.
     * Instead we will release the lock the first time and take the lock the second time for the second counter and then hold it while we write to the ACL register.
     */
    if (counters_in_set == 1) {
        if (FLOW_CNTR_ID_LID_GET(action_set[counter_in_set_index].counter_id) ==
            FLOW_CNTR_ID_LID_GET(hw_action_p->counter_id)) {
            action_set[counter_in_set_index].temp_release_lock = TRUE;
        }
    }
out:
    return rc;
}

/**
 * Check that same hw action does not appear more than once per set, except those, which have
 * "comply" CB and pass comply check
 *
 * @param action_set
 * @param action_set_idx
 * @param hw_action_p
 * @return
 */
static boolean_t __hw_action_fill_action_set_validate_action(flex_acl_hw_action_t  action_set[],
                                                             uint32_t              action_set_idx,
                                                             flex_acl_hw_action_t *hw_action_p)
{
    uint32_t  iii;
    boolean_t rc = TRUE;

    for (iii = 0; iii < action_set_idx; iii++) {
        if (flex_acl_hw_action_details[hw_action_p->action_type].action_set_comply_cb) {
            if (!flex_acl_hw_action_details[hw_action_p->action_type].action_set_comply_cb(&action_set[iii],
                                                                                           hw_action_p)) {
                return FALSE;
            }
        } else if (action_set[iii].action_type == hw_action_p->action_type) {
            return FALSE;
        }
        if (action_set[iii].action_type == SXD_ACTION_TYPE_FS_DB_E) {
            /* stateful DB action cannot be followed by any other action since
             * the later action will be executed before the stateful DB action.
             * We want to guarantee the order of the execution.
             */
            return FALSE;
        }
    }

    /* We can have up to 2 counter actions in a set. We cannot check it inside the comply function since it comparing only 2 actions.
     * Also, we want to mark the first counter as temp_release_lock in case we have 2 counters with the same LID.*/
    rc =
        __hw_action_fill_action_set_validate_counter_policer_estimator_action(action_set, action_set_idx, hw_action_p);

    return rc;
}

/**
 * Fill action set with actions from the prepared list subject to limitations.
 *
 * @param action_set - Entry: empty action set; Exit: (partially) filled set
 * @param action_set_size_p - Entry: set size; Exit: filled set size
 * @param hw_actions_p - Entry: ptr to HW action list start; Exit: a) used actions replaced by NULL.
 *                       b) ptr forwarded, if there are no skipped actions
 * @param hw_actions_count_p - Entry: size of actions; Exit: size of actions
 * @return
 */
static sx_status_t __hw_action_fill_action_set(flex_acl_hw_action_t action_set[],
                                               uint32_t             action_set_size,
                                               hw_action_list_t    *hw_action_list_p,
                                               uint32_t            *action_set_count_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    uint32_t                action_set_idx = 0;
    uint32_t                skipped = 0;
    uint32_t                action_set_size_new = 0;
    flex_acl_hw_action_t   *hw_action_p;
    hw_action_list_entry_t *hw_action_list_entry_p;

    (*action_set_count_p) = 0;

    rc = flex_acl_hw_db_hw_action_list_head(hw_action_list_p, &hw_action_list_entry_p);
    if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
        /* Empty list only */
        rc = SX_STATUS_SUCCESS;
        goto out;
    } else if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_hw_db_hw_action_list_head failed [%s]\n", sx_status_str(rc));
        goto out;
    }

    while ((action_set_size_new < action_set_size) &&
           !flex_acl_hw_db_hw_action_list_is_empty(hw_action_list_p) &&
           (rc == SX_STATUS_SUCCESS)) {
        /* Ignore NULL  - check if needed? */
        if (hw_action_list_entry_p->hw_action.action_type == SXD_ACTION_TYPE_NULL_E) {
            rc = flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_p, &hw_action_list_entry_p);
            if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
                rc = SX_STATUS_SUCCESS;
                goto out;
            } else if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("flex_acl_hw_db_hw_action_list_remove_and_next failed [%s]\n", sx_status_str(rc));
                goto out;
            }
            continue;
        }

        hw_action_p = &hw_action_list_entry_p->hw_action;

        if ((((hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E)
              || (hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_END_E))
             && !skipped)
            || (hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E)
            || (hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E)) {
            /* Try to take the action */
            if ((flex_acl_hw_action_details[hw_action_p->action_type].size
                 <= (action_set_size - action_set_size_new))
                && (TRUE == __hw_action_fill_action_set_validate_action(
                        action_set,
                        action_set_idx,
                        hw_action_p))) {
                /* Take the action & continue */
                action_set[action_set_idx] = *hw_action_p;
                action_set_size_new += flex_acl_hw_action_details[hw_action_p->action_type].size;
                action_set_idx++;
                (*action_set_count_p)++;

                /* Remove current action in list */
                rc = flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_p, &hw_action_list_entry_p);
                if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
                    rc = SX_STATUS_SUCCESS;
                    goto out;
                } else if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("flex_acl_hw_db_hw_action_list_remove_and_next failed [%s]\n", sx_status_str(rc));
                    goto out;
                }
                continue;
            }
        }

        /* Stop conditions */
        if ((hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E) ||
            (hw_action_p->position == FLEX_ACL_HW_ACTION_POSITION_END_E)) {
            /* Could not take the terminating actions - go out - "no space" */
            goto out;
        } else {
            /* IN_TRANS or OUT_TRANS & cannot take them - skip the action */
            skipped++;
            rc = flex_acl_hw_db_hw_action_list_next(hw_action_list_p, &hw_action_list_entry_p);
            if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
                /* Empty list */
                rc = SX_STATUS_SUCCESS;
                goto out;
            } else if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("flex_acl_hw_db_hw_action_list_next failed [%s]\n", sx_status_str(rc));
                goto out;
            }
        }
    } /* while */

out:
    return rc;
}

sx_status_t flex_acl_hw_gen_hw_action_sets(flex_acl_db_flex_rule_t      *rule_ptr,
                                           boolean_t                     is_defer,
                                           flex_acl_hw_db_action_set_t **new_action_set)
{
    hw_action_list_t                     hw_action_list;
    flex_acl_hw_db_kvd_action_set_t      kvd_action_set = {.actions_count = 0};
    flex_acl_hw_db_register_action_set_t action_set = {.actions_count = 0};
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t                   rule_id;
    boolean_t                            hw_action_list_init_done = FALSE;
    uint32_t                             actions_count = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(hw_action_list);

    rc = flex_acl_hw_db_hw_action_list_init(&hw_action_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("flex_acl_hw_db_hw_action_list_init failed [%s]\n", sx_status_str(rc));
        goto out;
    }
    hw_action_list_init_done = TRUE;

    SX_LOG_DBG("ACL Create Hw action set for rule offset:%d\n", rule_ptr->offset);
    memset(&action_set, 0, sizeof(action_set));
    rule_id.region_id = rule_ptr->region_id;
    rule_id.offset = rule_ptr->offset;
    rc = __flex_acl_gen_hw_actions(rule_ptr->actions,
                                   rule_ptr->action_count,
                                   is_defer,
                                   rule_id,
                                   &hw_action_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed creating hw actions\n");
        goto out;
    }

    rc = __flex_acl_hw_actions_merge_trap_actions(&hw_action_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed handling hw actions\n");
        goto out;
    }

    /* create register action set */
    rc = __hw_action_fill_action_set(action_set.actions, rm_resource_global.acl_max_actions_per_basic_set,
                                     &hw_action_list, &actions_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("__hw_action_fill_action_set failed. [%s]\n", sx_status_str(rc));
        goto out;
    }
    action_set.actions_count = actions_count;

    rc = flex_acl_hw_populate_goto_cmd(rule_ptr, &action_set.goto_action, FALSE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR_RESOURCE_COND(rc, "Populating goto command failed, region:%#x rc:%s\n",
                                 rule_ptr->region_id, sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_hw_db_action_set_create(&action_set, rule_ptr, (void**)new_action_set);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed creating action set.\n");
        goto out;
    }
    SX_LOG_DBG("FLOWD Created action set :%p \n", *new_action_set);

    if (!flex_acl_hw_db_hw_action_list_is_empty(&hw_action_list) &&
        (!flex_acl_is_extended_action())) {
        SX_LOG_ERR("Cannot place all HW actions for rule region %#x offset:%d "
                   "- the extended actions are disabled \n", rule_ptr->region_id, rule_ptr->offset);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* For the following acl stages we always need to create a kvd action even if we have no actual action. The most
     * common cause for this situation is GOTO action that isn't counted in the action list.
     */
    if ((ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) && flex_acl_hw_db_hw_action_list_is_empty(&hw_action_list)) {
        SX_MEM_CLR(kvd_action_set);
        kvd_action_set.goto_action = action_set.goto_action;
        rc = flex_acl_hw_db_tail_add_kvd_action_set(*new_action_set, &kvd_action_set);
        if (SX_STATUS_SUCCESS != rc) {
            flex_acl_hw_db_action_set_destroy(*new_action_set);
            SX_LOG_ERR("ACL action : Failed creating action set.\n");
            goto out;
        }
    }

    /* Create the linked list of action sets */
    while (!flex_acl_hw_db_hw_action_list_is_empty(&hw_action_list)) {
        SX_MEM_CLR(kvd_action_set);
        kvd_action_set.goto_action = action_set.goto_action;

        rc = __hw_action_fill_action_set(kvd_action_set.actions, rm_resource_global.acl_max_actions_per_extended_set,
                                         &hw_action_list, &actions_count);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("__hw_action_fill_action_set failed. [%s]\n", sx_status_str(rc));
            goto out;
        }
        kvd_action_set.actions_count = actions_count;

        rc = flex_acl_hw_db_tail_add_kvd_action_set(*new_action_set, &kvd_action_set);
        if (SX_STATUS_SUCCESS != rc) {
            flex_acl_hw_db_action_set_destroy(*new_action_set);
            SX_LOG_ERR("ACL action : Failed creating action set.\n");
            goto out;
        }
    }

out:
    if (hw_action_list_init_done) {
        flex_acl_hw_db_hw_action_list_deinit(&hw_action_list);
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_free_action_sets(flex_acl_db_flex_rule_t *rule)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    boolean_t                      is_found = FALSE;
    sx_flex_acl_flex_action_goto_t goto_api_action;

    SX_LOG_ENTER();
    SX_LOG_DBG(" rule offset %d\n", rule->offset);

    if ((rule == NULL) || (rule->hw_action_handle == (void*)FLEX_ACL_INVALID_HANDLE) ||
        (rule->hw_action_handle == NULL)) {
        goto out;
    }

    rc = flex_acl_db_rule_get_goto_action(rule, &is_found, &goto_api_action);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed to release goto action, not found in rule offset[%u] but found in hw db\n",
                   rule->offset);
        goto out;
    }
    if (is_found) {
        if ((goto_api_action.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
            (goto_api_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
            rc = rebind_group_cb_g.unbind_group_cb(goto_api_action.acl_group_id, rule);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL action : Failed unbind group on goto action. group_id[%u]\n",
                           goto_api_action.acl_group_id);
                goto out;
            }
        }
    }

    rc = flex_acl_hw_db_action_set_destroy((flex_acl_hw_db_action_set_t*)(rule->hw_action_handle));
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_create_reg_action_set(flex_acl_hw_action_t      *actions,
                                              uint32_t                   actions_count,
                                              sxd_goto_set_action_t      goto_action,
                                              boolean_t                  is_last_set,
                                              kvd_linear_manager_index_t kvd_index,
                                              boolean_t                  is_commit,
                                              flex_acl_relocation_data_t relocation_data,
                                              sxd_flex_action_set_t     *reg_action_set,
                                              boolean_t                  add_ref,
                                              flex_acl_db_flex_rule_t   *rule)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    memset(reg_action_set, 0, sizeof(sxd_flex_action_set_t));
    for (i = 0; i < actions_count; i++) {
        /* Run the bind cbs and provide it with a pointer to the db action set*/
        if (flex_acl_hw_action_details[actions[i].action_type].bind_populate) {
            rc =
                flex_acl_hw_action_details[actions[i].action_type].bind_populate(&(actions[i]), rule, relocation_data,
                                                                                 add_ref);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed bind_populate from action type :%d .\n", actions[i].action_type);
                goto out;
            }
        }
        memcpy(&(reg_action_set->action_slots[i]), &(actions[i].slot), sizeof(struct sxd_action_slot));
    }

    if (is_last_set) {
        reg_action_set->next_type = SXD_FLEX_GOTO_RECORD_E;
        reg_action_set->next_goto_record.goto_set_action = goto_action;
        reg_action_set->next_goto_record.goto_set_action.group_binding = SXD_GROUP_OR_ACL_BINDING_TYPE_GROUP_E;
        reg_action_set->next_goto_record.goto_set_action.commit = is_commit;
    } else {
        reg_action_set->next_type = SXD_FLEX_NEXT_POINTER_RECORD_E;
        reg_action_set->next_goto_record.next_action_set_ptr = kvd_index;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_release_action_locks(flex_acl_hw_action_t *actions, uint32_t actions_count)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < actions_count; i++) {
        /* Run the bind cbs and provide it with a pointer to the db action set*/
        if (flex_acl_hw_action_details[actions[i].action_type].release_lock) {
            rc = flex_acl_hw_action_details[actions[i].action_type].release_lock(&(actions[i]));
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed release lock from action type :%d .\n", actions[i].action_type);
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}
sx_status_t __flex_acl_free_third_parties_action(flex_acl_hw_action_t       *action,
                                                 kvd_linear_manager_index_t *kvd_index_p,
                                                 boolean_t                   is_head)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    update_count;
    boolean_t   del_acl_drop_relocate_db_entry = FALSE;

    SX_LOG_ENTER();

    if (action->is_ref_count_inc == FALSE) {
        SX_LOG_DBG("No need to free Action of type:%u\n", action->slot.type);
        goto out;
    }

    switch (action->slot.type) {
    case SXD_ACTION_TYPE_POLICING_COUNTING_E:
        switch (action->slot.fields.action_policing_monitoring.c_p) {
        case SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E:
            SX_LOG_DBG("FLOWD free third party Policer\n");
            rc = flex_acl_hw_db_policer_remove_entry(action->policer_id, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "ACL Free action failed flex_acl_hw_db_policer_remove_entry failed, policer_id: %" PRIu64 "\n",
                    action->policer_id);
                goto out;
            }
            rc = policer_manager_ref_delete(action->policer_id,
                                            POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                                action->policer_id));
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Free action failed policer_manager_ref_delete failed, policer_id: %" PRIu64 "\n",
                           action->policer_id);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL free third party Policer DELETE handler :%d\n", (int)action->policer_id);
            break;

        case SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E:
            SX_LOG_DBG("FLOWD free third party Counter\n");
            rc = flex_acl_hw_db_counter_remove_entry(action->counter_id, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                flex_acl_hw_db_counter_remove_entry(action->counter_id, kvd_index_p);
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_counter_remove_entry, counter_id: %u\n",
                           action->counter_id);
                goto out;
            }
            rc = flow_counter_ref_dec(action->counter_id);
            if (SX_STATUS_SUCCESS != rc) {
                flex_acl_hw_db_counter_add_entry(action->counter_id, is_head, kvd_index_p);
                SX_LOG_ERR("ACL Free action failed flow_counter_ref_dec, counter_id: %u\n", action->counter_id);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL free third party Counter DEC counter id: %u\n", action->counter_id);
            break;

        default:
            rc = SX_STATUS_ERROR;
            break;
        }
        break;

    case SXD_ACTION_TYPE_FLOW_ESTIMATOR_E:
        SX_LOG_DBG("FLOWD free third party Flow Estimator Profile and Counter\n");
        rc = flex_acl_hw_db_counter_remove_entry(action->counter_id, kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            flex_acl_hw_db_counter_remove_entry(action->counter_id, kvd_index_p);
            SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_counter_remove_entry, counter_id: %u\n",
                       action->counter_id);
            goto out;
        }
        rc = flow_counter_ref_dec(action->counter_id);
        if (SX_STATUS_SUCCESS != rc) {
            flex_acl_hw_db_counter_add_entry(action->counter_id, is_head, kvd_index_p);
            SX_LOG_ERR("ACL Free action failed flow_counter_ref_dec, counter_id: %u\n", action->counter_id);
            goto out;
        }
        SX_LOG_DBG("FLOWD ACL free third party Counter DEC counter id: %u\n", action->counter_id);
        rc =
            flow_estimator_profile_ref_dec((sx_flow_estimator_profile_key_t *)&(action->slot.fields.
                                                                                action_flow_estimator.
                                                                                profile_key));
        if (SX_STATUS_SUCCESS != rc) {
            flow_counter_ref_inc(action->counter_id);
            flex_acl_hw_db_counter_add_entry(action->counter_id, is_head, kvd_index_p);
            SX_LOG_ERR("ACL Free action failed flow_estimator_profile_ref_dec, profile id: %u\n",
                       action->slot.fields.action_flow_estimator.profile_key.profile_id);
            goto out;
        }
        SX_LOG_DBG("FLOWD ACL free third party Counter DEC profile id: %u\n",
                   action->slot.fields.action_flow_estimator.profile_key.profile_id);
        break;

    case SXD_ACTION_TYPE_FORWARD_E:
        if ((action->slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E) ||
            (action->slot.fields.action_forward.type == SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E)) {
            SX_LOG_DBG("FLOWD free third party PBS\n");
            rc = kvd_linear_manager_ref_delete(action->pbs_kvd_handle);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "ACL action free third party SXD_ACTION_TYPE_FORWARD_E : Failed kvd_linear_manager_ref_delete, pbs_kvd_handle: %" PRIu64 "\n",
                    action->pbs_kvd_handle);
                goto out;
            }
            rc = flex_acl_hw_db_pbs_remove_entry(action->pbs_kvd_handle, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                kvd_linear_manager_ref_add(action->pbs_kvd_handle);
                SX_LOG_ERR(
                    "ACL action free third party SXD_ACTION_TYPE_FORWARD_E failed  flex_acl_hw_db_pbs_delete_entry, pbs_kvd_handle: %" PRIu64 "\n",
                    action->pbs_kvd_handle);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL free third party PBS\n");
        }
        break;

    case SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E:
        if ((action->slot.fields.action_trap.forward_action == SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E) ||
            (action->slot.fields.action_trap.forward_action ==
             SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E)) {
            if (action->acl_drop_trap_handle) {
                /* the ACL drop trap handle will be non-zero if we added to relocate db.
                 * This will be added for regular user ACLs and if monitoring is
                 * Enabled for System ACLs.
                 */
                if ((action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E) &&
                    ((action->slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
                     (action->slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP))) {
                    /* monitoring is enabled for user/system acl. remove from reloc db*/
                    del_acl_drop_relocate_db_entry = TRUE;
                } else if ((action->slot.fields.action_trap.trap_action == SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E) &&
                           (action->slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX)) {
                    /* monitoring is disabled. remove from reloc db . Only applies to user acl */
                    del_acl_drop_relocate_db_entry = TRUE;
                }
            }
            if (del_acl_drop_relocate_db_entry) {
                SX_LOG_DBG("Del from reloc db handle =0x%" PRIx64 "\n", action->acl_drop_trap_handle);
                rc = flex_acl_hw_db_acl_drop_relocate_db_del_entry(action->acl_drop_trap_handle, kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "Failed to remove entry from relocate db, region = %u off=%u\n, fwd_action=%u, trap_act=%u, trap_id=%u, RC = %s\n",
                        FLEX_ACL_DROP_TRAP_HANDLE_TO_REGION(action->acl_drop_trap_handle),
                        FLEX_ACL_DROP_TRAP_HANDLE_TO_OFFSET(action->acl_drop_trap_handle),
                        action->slot.fields.action_trap.forward_action,
                        action->slot.fields.action_trap.trap_action,
                        action->slot.fields.action_trap.trap_id,
                        sx_status_str(rc));

                    goto out;
                }
                /* After deleting from Relocate DB, clear the Handle. */
                action->acl_drop_trap_handle = 0;
            }
        }

    /* fall through */
    /* to handle mirror action */
    case SXD_ACTION_TYPE_TRAP_E:
        if (action->slot.fields.action_trap.mirror_enable) {
            SX_LOG_DBG("FLOWD free third party span\n");
            rc = flex_acl_hw_db_mirror_remove_entry(action->span_session_id, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_mirror_remove_entry, span_session_id: %u\n",
                           action->span_session_id);
                goto out;
            }
            rc = span_session_ref_cnt_dec(action->span_user_handle, action->span_session_id);
            if (SX_STATUS_SUCCESS != rc) {
                /* in the case of deinit flow, it is possible to get SX_STATUS_MODULE_UNINITIALIZED
                 * from span module, due to initialization order. */
                if (SX_STATUS_MODULE_UNINITIALIZED == rc) {
                    rc = SX_STATUS_SUCCESS;
                } else {
                    flex_acl_hw_db_mirror_add_entry(action->span_session_id, is_head, kvd_index_p);
                    SX_LOG_ERR("ACL Free action failed span_session_ref_cnt_dec, span_session_id: %u\n",
                               action->span_session_id);
                    goto out;
                }
            }
            SX_LOG_DBG("FLOWD ACL free third party span DEC session id: %u\n",
                       action->span_session_id);
            if (action->is_egress_mirror) {
                update_count = 0;
                rc = port_foreach_port(__flex_acl_hw_egress_mirror_free_buffer, &update_count);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL counter action failed __flex_acl_hw_egress_mirror_free_buffer failed \n");
                    goto out;
                }
            }
        }
        if ((action->api_action_type == SX_FLEX_ACL_ACTION_TRAP) ||
            (action->api_action_type == SX_FLEX_ACL_ACTION_TRAP_W_USER_ID)) {
            rc = flex_acl_hw_db_trap_id_remove_entry(action->slot.fields.action_trap.trap_id, kvd_index_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_trap_id_remove_entry, trap_id: %u\n",
                           action->slot.fields.action_trap.trap_id);
                goto out;
            }
        }

        switch (action->action_type) {
        case SXD_ACTION_TYPE_MC_E:
            SX_LOG_DBG("FLOWD free third party mc container %u \n", action->mc_container);
            rc = flex_acl_hw_db_mc_container_remove_entry(action->mc_container, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_mc_container_remove_entry, mc_container_id: %u\n",
                           action->mc_container);
                goto out;
            }
            break;

        case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
            switch (action->aux_slot.fields.action_uc_router.type) {
            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
                SX_LOG_DBG("FLOWD free third party ECMP container:0x%" PRIx64 "\n",
                           action->ecmp_block_handle);
                rc = flex_acl_hw_db_ecmp_container_remove_entry(action->ecmp_block_handle,
                                                                kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "ACL UC ROUTE remote action flex_acl_hw_db_ecmp_container_remove_entry failed, ecmp_block_handle: %" PRIu64 "\n",
                        action->ecmp_block_handle);
                    goto out;
                }
                break;

            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
                SX_LOG_DBG("FLOWD free third party PBILM\n");
                rc = flex_acl_hw_db_pbilm_remove_entry(action->pbilm_id, kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL UC ROUTE remote action flex_acl_hw_db_pbilm_remove_entry failed, pbilm_id: %u\n",
                               action->pbilm_id);
                    goto out;
                }
                break;

            default:
                SX_LOG_ERR("ACL UC ROUTE unknown type %u.\n", action->slot.fields.action_uc_router.type);
                break;
            }
            break;

        default:
            break;
        }
        break;

    case SXD_ACTION_TYPE_MC_E:
        SX_LOG_DBG("FLOWD free third party mc container %u \n", action->mc_container);
        rc = flex_acl_hw_db_mc_container_remove_entry(action->mc_container, kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_mc_container_remove_entry, mc_container_id: %u\n",
                       action->mc_container);
            goto out;
        }
        break;

    case SXD_ACTION_TYPE_NULL_E:
        switch (action->action_type) {
        case SXD_ACTION_TYPE_MC_E:
            SX_LOG_DBG("FLOWD free third party mc container %u \n", action->mc_container);
            rc = flex_acl_hw_db_mc_container_remove_entry(action->mc_container, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_mc_container_remove_entry, mc_container_id: %u\n",
                           action->mc_container);
                goto out;
            }
            break;

        case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
            switch (action->slot.fields.action_uc_router.type) {
            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
                SX_LOG_DBG("FLOWD free third party ECMP container:0x%" PRIx64 "\n",
                           action->ecmp_block_handle);
                rc = flex_acl_hw_db_ecmp_container_remove_entry(action->ecmp_block_handle,
                                                                kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR(
                        "ACL UC ROUTE remote action flex_acl_hw_db_ecmp_container_remove_entry failed, ecmp_block_handle: %" PRIu64 "\n",
                        action->ecmp_block_handle);
                    goto out;
                }
                break;

            case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
                SX_LOG_DBG("FLOWD free third party PBILM\n");
                rc = flex_acl_hw_db_pbilm_remove_entry(action->pbilm_id, kvd_index_p);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL UC ROUTE remote action flex_acl_hw_db_pbilm_remove_entry failed, pbilm_id: %u\n",
                               action->pbilm_id);
                    goto out;
                }
                break;

            default:
                SX_LOG_ERR("ACL UC ROUTE unknown type %u.\n", action->slot.fields.action_uc_router.type);
                break;
            }
            break;

        default:
            break;
        }
        break;

    case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
        switch (action->slot.fields.action_uc_router.type) {
        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
            SX_LOG_DBG("FLOWD free third party tunnel decap\n");
            rc = flex_acl_hw_db_tunnel_decap_remove_entry(action->tunnel_id, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_tunnel_decap_remove_entry, tunnel ID: %u\n",
                           action->tunnel_id);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL free third party tunnel decap DEC tunnel id: %u\n",
                       action->tunnel_id);
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
            SX_LOG_DBG("FLOWD free third party ECMP container\n");
            rc = flex_acl_hw_db_ecmp_container_remove_entry(action->ecmp_block_handle,
                                                            kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR(
                    "ACL UC ROUTE remote action flex_acl_hw_db_ecmp_container_remove_entry failed, ecmp_block_handle: %" PRIu64 "\n",
                    action->ecmp_block_handle);
                goto out;
            }
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
            SX_LOG_DBG("FLOWD free third party PBILM\n");
            rc = flex_acl_hw_db_pbilm_remove_entry(action->pbilm_id, kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL UC ROUTE remote action flex_acl_hw_db_pbilm_remove_entry failed, pbilm_id: %u\n",
                           action->pbilm_id);
                goto out;
            }
            break;


        default:
            SX_LOG_ERR("Invalid Uc route action type :%u \n", action->slot.fields.action_uc_router.type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SXD_ACTION_TYPE_MIRROR_SAMPLER_E:
        SX_LOG_DBG("FLOWD free third party span\n");
        rc = flex_acl_hw_db_mirror_remove_entry(action->span_session_id, kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Free action failed flex_acl_hw_db_mirror_remove_entry, span_session_id: %u\n",
                       action->span_session_id);
            goto out;
        }
        rc = span_session_ref_cnt_dec(action->span_user_handle, action->span_session_id);
        if (SX_STATUS_SUCCESS != rc) {
            /* in the case of deinit flow, it is possible to get SX_STATUS_MODULE_UNINITIALIZED
             * from span module, due to initialization order. */
            if (SX_STATUS_MODULE_UNINITIALIZED == rc) {
                rc = SX_STATUS_SUCCESS;
            } else {
                flex_acl_hw_db_mirror_add_entry(action->span_session_id, is_head, kvd_index_p);
                SX_LOG_ERR("ACL Free action failed span_session_ref_cnt_dec, span_session_id: %u\n",
                           action->span_session_id);
                goto out;
            }
        }

        /* If region direction is EGRESS free shared buffer allocated for bounded ports */
        if (action->is_egress_mirror_sampler) {
            update_count = 0;
            rc = port_foreach_port(__flex_acl_hw_egress_mirror_free_buffer, &update_count);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL MIRROR_SAMPLER action failed __flex_acl_hw_egress_mirror_free_buffer failed \n");
                goto out;
            }
        }

        break;

    default:
        break;
    }

    action->is_ref_count_inc = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_free_rule_third_party_resources(flex_acl_db_flex_rule_t* rule)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    uint32_t                     i = 0;
    flex_acl_hw_db_action_set_t *action_set = NULL;
    const cl_list_t             *kvd_action_set_list = NULL;
    cl_list_iterator_t           iter = NULL;
    cl_list_iterator_t           list_end = NULL;
    cl_list_iterator_t           list_head = NULL;
    kvd_linear_manager_index_t  *kvd_index_p = NULL;

    SX_LOG_ENTER();

    action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    if (!action_set || (action_set == (void*)FLEX_ACL_INVALID_HANDLE)) {
        SX_LOG_ERR("No action set. \n");
        rc = SX_STATUS_ERROR;
        goto out;
    }
    SX_LOG_DBG("FLOWD Free third parties for rule offset:%u\n", rule->offset);

    kvd_index_p = &(action_set->action_set.kvd_index);
    for (i = 0; i < action_set->action_set.actions_count; i++) {
        rc = __flex_acl_free_third_parties_action(&(action_set->action_set.actions[i]), kvd_index_p, 1);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed freeing third party action\n");
            goto out;
        }
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(action_set, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }
    list_head = cl_list_head(kvd_action_set_list);
    list_end = cl_list_end(kvd_action_set_list);

    for (iter = list_head; iter != list_end; iter = cl_list_next(iter)) {
        flex_acl_hw_db_kvd_action_set_t *kvd_action_set;

        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        SX_LOG_DBG("FLOWD In KVD loop nun of actions :%d \n", kvd_action_set->actions_count);

        for (i = 0; i < kvd_action_set->actions_count; i++) {
            SX_LOG_DBG("FLOWD In KVD block handling action #:%d \n", i);
            rc = __flex_acl_free_third_parties_action(&(kvd_action_set->actions[i]), kvd_index_p, 0);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed freeing third party action\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_kvd_block_reloc(kvd_linear_manager_handle_t       handle,
                                        kvd_linear_manager_block_length_t size,
                                        kvd_linear_manager_block_length_t offset,
                                        const kvd_linear_manager_index_t *old_index,
                                        const kvd_linear_manager_index_t  new_index)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t     *hw_action_set = NULL;
    cl_list_iterator_t               iter = NULL;
    cl_list_iterator_t               list_head = NULL;
    cl_list_iterator_t               list_end = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set_next = NULL;
    const cl_list_t                 *kvd_action_set_list = NULL;
    uint32_t                         i = 0;

    UNUSED_PARAM(size);
    SX_LOG_ENTER();

    rc = flex_acl_hw_db_kvd_action_ref_get(handle, &hw_action_set);
    if (SX_STATUS_SUCCESS != rc) {
        goto out;
    }

    SX_LOG_DBG("KVD relocation : found kvd handle:%d \n", (int)handle);
    rc = flex_acl_hw_db_get_kvd_action_set_list(hw_action_set, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }

    if (offset == 0) {
        SX_LOG_DBG("KVD relocation : first item \n");
        if (hw_action_set->action_set.kvd_index != old_index[0]) {
            SX_LOG_ERR("KVD_ RELOCATION: KVD handler in not consistent with old index.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(cl_list_head(kvd_action_set_list));
        if (kvd_action_set->kvd_index != old_index[0]) {
            SX_LOG_ERR("KVD RELOCATION: old index inconsistency.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        /* Write the action to the new kvd location */
        kvd_action_set->kvd_index = new_index;
        rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            /* rollback */
            kvd_action_set->kvd_index = old_index[0];
            rc = SX_STATUS_SUCCESS;
            goto out;
        }
        hw_action_set->action_set.kvd_index = new_index;
        /* Handle the ptce2 and the first kvd */
        rc = flex_acl_hw_edit_action_register(hw_action_set, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            hw_action_set->action_set.kvd_index = old_index[0];
            kvd_action_set->kvd_index = old_index[0];
            SX_LOG_ERR("KVD RELOCATION: Failed write to register\n");
            goto out;
        }
        rc = flex_acl_db_action_container_kvd_index_reloc(old_index[0], new_index);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("KVD RELOCATION: Failed to update kvd index mapping to action container.\n");
            goto out;
        }
    } else {
        list_end = cl_list_end(kvd_action_set_list);
        list_head = cl_list_head(kvd_action_set_list);
        for (i = 0, iter = list_head;
             i < offset - 1 && iter != list_end;
             iter = cl_list_next(iter), i++) {
        }
        if (iter == cl_list_next(iter)) {
            rc = SX_STATUS_ERROR;
            goto out;
        }
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        /* Write the entry in the new location */
        kvd_action_set_next = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(cl_list_next(iter));
        kvd_action_set_next->kvd_index = new_index;
        rc = __flex_acl_hw_edit_action_kvd(kvd_action_set_next, FALSE, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            kvd_action_set_next->kvd_next_index = old_index[offset];
            goto out;
        }
        /* Handle previous kvd */
        kvd_action_set->kvd_next_index = new_index;
        rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            kvd_action_set->kvd_next_index = old_index[offset];
            kvd_action_set_next->kvd_index = old_index[offset];
            if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_edit_action_kvd(kvd_action_set_next, FALSE, FALSE))) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_write_extended_action_set(flex_acl_db_flex_rule_t     *rule,
                                                  flex_acl_hw_db_action_set_t *hw_action_set,
                                                  kvd_linear_manager_index_t  *kvd_indexes,
                                                  uint32_t                     kvd_block_size,
                                                  boolean_t                    is_commit,
                                                  uint32_t                     dev_id,
                                                  boolean_t                    is_full_write,
                                                  boolean_t                    activity_clear,
                                                  boolean_t                    add_ref)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      unlock_rc = SX_STATUS_SUCCESS;
    struct ku_pefa_reg               pefa_reg_data = {.index = 0};
    uint32_t                         i = 0;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    const cl_list_t                 *kvd_action_set_list = NULL;
    cl_list_iterator_t               iter = NULL;
    cl_list_iterator_t               list_end = NULL;
    kvd_linear_manager_index_t       kvd_index_to_write = kvd_indexes[0];
    flex_acl_relocation_data_t       relocation_data = {.is_head = 0};
    boolean_t                        is_default_action = FALSE;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_kvd_action_set_list(hw_action_set, &kvd_action_set_list);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }

    iter = cl_list_head(kvd_action_set_list);

    if (rule->offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
        is_default_action = TRUE;
        /* Skip the first action set that resides in dedicated pre-allocated KVD and should be set at the end */
        iter = cl_list_next(iter);
    }
    list_end = cl_list_end(kvd_action_set_list);
    for (i = 1; iter != list_end && (rc == SX_STATUS_SUCCESS);
         iter = cl_list_next(iter), i++) {
        boolean_t is_last;
        SX_MEM_CLR(pefa_reg_data);

        if (i > kvd_block_size) {
            SX_LOG_ERR("ACL:Failed to fill kvd action set N[%d], the kvd block size[%u].\n", i, kvd_block_size);
            rc = SX_STATUS_ERROR;
            goto out;
        }

        pefa_reg_data.index = kvd_index_to_write; /* kvd index from previous iteration */
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        kvd_action_set->kvd_index = kvd_index_to_write;
        is_last = (i == kvd_block_size);
        kvd_action_set->is_last = is_last;
        kvd_action_set->is_first = ((i == 1) && (!is_default_action)) ? TRUE : FALSE;
        kvd_action_set->region_id = rule->region_id;
        /* now kvd contain index for next iteration */
        relocation_data.is_head = FALSE;
        relocation_data.kvd_index_p = &(hw_action_set->action_set.kvd_index);
        kvd_index_to_write = is_last ? 0 : kvd_indexes[i];
        kvd_action_set->kvd_next_index = kvd_index_to_write;

        /* Prepare action set for writing to HW, including obtaining third party's HW indexes. */
        rc = flex_acl_hw_create_reg_action_set(kvd_action_set->actions, kvd_action_set->actions_count,
                                               hw_action_set->action_set.goto_action,
                                               is_last, kvd_index_to_write, is_commit, relocation_data,
                                               &(pefa_reg_data.action_set), add_ref, rule);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed creating action set.\n");
            goto out;
        }
        /* Add to the PEFA register the relevant fields related to activity */
        rc = flex_acl_hw_set_action_activity(is_full_write,
                                             FALSE,
                                             activity_clear,
                                             kvd_action_set,
                                             &pefa_reg_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed updating action activity fields.\n");
            goto out;
        }

        /* Write the extended action sets to the hardware */
        rc = flex_acl_hw_write_pefa_devices(dev_id, TRUE, rule->region_id, rule->offset, &pefa_reg_data);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to configure PEFA to dev. err=%s\n", sx_status_str(rc));
        }
        /* Release locks taken for HW writing preparations */
        unlock_rc = flex_acl_hw_release_action_locks(kvd_action_set->actions, kvd_action_set->actions_count);
        if (SX_STATUS_SUCCESS != unlock_rc) {
            SX_LOG_ERR("ACL : Failed to release locks, error: %s\n", sx_status_str(unlock_rc));
            goto out;
        }
    }
    if (!iter) {
        SX_LOG_ERR("ACL action :Failed accessing action set list.\n");
    }
out:
    rc = (rc != SX_STATUS_SUCCESS) ? rc : unlock_rc;
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_write_pefa_devices(sx_dev_id_t          dev_id,
                                           boolean_t            write_all_devs,
                                           sx_acl_region_id_t   region_id,
                                           sx_acl_rule_offset_t offset,
                                           struct ku_pefa_reg  *pefa_reg_data)
{
    uint32_t    dev_idx = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t    dev_info_arr_size = 0;

    SX_LOG_ENTER();

    if (write_all_devs) {
        rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to get devices list \n");
            return rc;
        }
    } else {
        dev_info_arr_size = 1;
        devs_list[0] = dev_id;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    /* Note: The acl action hw callback is used per chip type and not per region.
     * Therefore, we call directly the default register callback instead of the callback
     * from hw_region_attributes.
     */
    rc = default_register_cbs_p->action_hw_cb(devs_list[dev_idx],
                                              region_id,
                                              offset,
                                              pefa_reg_data,
                                              FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure extended action for region [%u] \n", region_id);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return rc;
}

/**
 * Get Device List (All Devices in the system)
 */
sx_status_t flex_acl_hw_get_all_devs_list(sx_dev_id_t *devs_list, uint16_t *devs_count)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    sx_dev_info_t leaf_filter = {
        .dev_id = 0,
        .node_type = SX_DEV_NODE_TYPE_LEAF,
    };
    length_t      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t dev_info_arr[SX_DEV_NUM_MAX];
    length_t      dev_idx = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(dev_info_arr);

    *devs_count = 0;

    err = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &leaf_filter, dev_info_arr, &dev_info_arr_size);
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        devs_list[*devs_count] = dev_info_arr[dev_idx].dev_id;
        *devs_count += 1;
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __flex_acl_hw_config_pbilm_write_reg(kvd_linear_manager_index_t        kvd_index,
                                                        kvd_linear_manager_index_t        nhlfe_index,
                                                        kvd_linear_manager_block_length_t nhlfe_size,
                                                        uint8_t                           npop)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_rc = SXD_STATUS_SUCCESS;
    struct ku_ppbmi_reg ppbmi;
    sxd_reg_meta_t      meta = {.access_cmd = 0};
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t            dev_info_arr_size = 0;
    uint32_t            dev_idx = 0;

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(ppbmi);

    ppbmi.ilm_index = kvd_index;
    ppbmi.nhlfe_index = nhlfe_index;
    ppbmi.ecmp_size = nhlfe_size;
    ppbmi.npop = npop;

    meta.swid = 0;
    meta.access_cmd = SXD_ACCESS_CMD_SET;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    meta.dev_id = devs_list[dev_idx];

    sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PPBMI_E, &ppbmi, &meta, 1, NULL, NULL);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("ACL PBILM failed configure hw : sxd_access_reg_ppbmi failed rc :%d \n", sxd_rc);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_get_pbilm(sx_acl_pbilm_id_t           pbilm_id,
                                           boolean_t                  *is_empty,
                                           kvd_linear_manager_index_t *adj_index)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t        *pbilm_entry = NULL;
    kvd_linear_manager_index_t        kvd_index = 0;
    kvd_linear_manager_block_length_t size = 1;

    SX_LOG_ENTER();

    rc = flex_acl_db_pbilm_get_entry(pbilm_id, &pbilm_entry);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("PBILM id %u is not valid.\n", pbilm_id);
        goto out;
    }

    if (is_empty) {
        *is_empty = (pbilm_entry->nhlfe_size > 0) ? FALSE : TRUE;
    }

    if (adj_index) {
        rc = kvd_linear_manager_handle_lock(pbilm_entry->kvd_handle, &kvd_index, &size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL config pbilm : Failed locking kvd block, kvd_handle: %" PRIu64 "\n",
                       pbilm_entry->kvd_handle);
            goto out;
        }
        SX_LOG_DBG("KVD handle:0x%" PRIx64 " locked index :%d \n", pbilm_entry->kvd_handle, kvd_index);

        rc = kvd_linear_manager_handle_release(pbilm_entry->kvd_handle);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action : Failed releasing the kvd lock, kvd_handle: %" PRIu64 "\n",
                       pbilm_entry->kvd_handle);
            goto out;
        }
        *adj_index = kvd_index;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_config_pbilm(flex_acl_db_pbilm_entry_t        *pbilm_entry,
                                              kvd_linear_manager_index_t        nhlfe_index,
                                              kvd_linear_manager_block_length_t nhlfe_size)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       r_rc = SX_STATUS_SUCCESS;
    kvd_linear_manager_index_t        kvd_index = 0;
    kvd_linear_manager_block_length_t size = 1;

    SX_LOG_ENTER();

    rc = kvd_linear_manager_handle_lock(pbilm_entry->kvd_handle, &kvd_index, &size);
    if ((SX_STATUS_SUCCESS != rc) || (size < 1)) {
        SX_LOG_ERR("ACL config pbilm : Failed locking kvd block, kvd_handle: %" PRIu64 "\n", pbilm_entry->kvd_handle);
        goto out;
    }
    SX_LOG_DBG("KVD handle:0x%" PRIx64 " locked index :%d \n", pbilm_entry->kvd_handle, kvd_index);
    rc = __flex_acl_hw_config_pbilm_write_reg(kvd_index, nhlfe_index, nhlfe_size, pbilm_entry->params.number_of_pops);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL config pbilm : failed writing pbilm register.\n");
        goto release;
    }

release:
    r_rc = kvd_linear_manager_handle_release(pbilm_entry->kvd_handle);
    if (SX_STATUS_SUCCESS != r_rc) {
        rc = r_rc;
        SX_LOG_ERR("ACL action : Failed releasing the kvd lock, kvd_handle: %" PRIu64 "\n", pbilm_entry->kvd_handle);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_add_pbilm(flex_acl_db_pbilm_entry_t *pbilm_entry, boolean_t is_new)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    boolean_t                         kvd_allocated = FALSE;
    boolean_t                         rm_set = FALSE;
    boolean_t                         continue_lookup_created = FALSE;
    boolean_t                         ecmp_ref_inc = FALSE;
    kvd_linear_manager_index_t        nhlfe_index;
    kvd_linear_manager_block_length_t nhlfe_size;
    boolean_t                         is_empty;

    SX_LOG_ENTER();

    /* If this is an old item we assume that the kvd and rm are already set */
    if (is_new) {
        rc = kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_PBILM_E, 1, FALSE, &(pbilm_entry->kvd_handle));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed: Failed allocating kvd block.\n");
            goto out;
        }
        kvd_allocated = TRUE;
        SX_LOG_DBG("flex_acl_hw_add_pbilm, pbilm_entry->kvd_handle = 0x%" PRIx64 "\n", pbilm_entry->kvd_handle);
        SX_LOG_DBG("KVD block was added kvs_handle:0x%" PRIx64 " \n", pbilm_entry->kvd_handle);

        rc = rm_entries_set(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed: Failed on RM entry set.\n");
            goto out;
        }
        rm_set = TRUE;
    }

    switch (pbilm_entry->params.ilm_fwd_action) {
    case SX_MPLS_ILM_CONTINUE_LOOKUP:
    case SX_MPLS_ILM_GOTO_ROUTER:
        /* Create the continue lookup entry */
        rc = hwd_continue_lookup_nhlfe_create_entry(&(pbilm_entry->params),
                                                    &(pbilm_entry->nhlfe_handle),
                                                    &nhlfe_index,
                                                    &nhlfe_size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed creating continue lookup entry.\n");
            goto out;
        }
        continue_lookup_created = TRUE;
        break;

    case SX_MPLS_ILM_GOTO_ECMP:
        rc = sdk_router_ecmp_impl_active_set_get(pbilm_entry->params.fwd_actions_params.ecmp_id,
                                                 &(pbilm_entry->nhlfe_handle),
                                                 &is_empty);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed getting info from ecmp_id %u.\n",
                       pbilm_entry->params.fwd_actions_params.ecmp_id);
            goto out;
        }
        rc = hwd_router_ecmp_block_get(pbilm_entry->nhlfe_handle, &nhlfe_index, &nhlfe_size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed getting ecmp hwd block 0x%" PRIx64 ".\n",
                       pbilm_entry->nhlfe_handle);
            goto out;
        }
        rc = hwd_router_ecmp_ref_inc(pbilm_entry->nhlfe_handle);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_del_pbilm failed adding reference to hwd ecmp, nhlfe_handle: %" PRIu64 "\n",
                       pbilm_entry->nhlfe_handle);
            goto out;
        }
        ecmp_ref_inc = TRUE;
        break;
    }
    /* No point in writing to the HW if the ecmp is empty */
    if (nhlfe_size) {
        rc = __flex_acl_hw_config_pbilm(pbilm_entry, nhlfe_index, nhlfe_size);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_add_pbilm failed: flex_acl_hw_config_pbilm failed.\n");
            goto out;
        }
    }
    pbilm_entry->nhlfe_size = nhlfe_size;
    pbilm_entry->nhlfe_index = nhlfe_index;

out:
    if (SX_STATUS_SUCCESS != rc) {
        if (rm_set) {
            if (SX_CHECK_FAIL(rb_rc =
                                  rm_entries_set(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, SX_ACCESS_CMD_DELETE, 1, NULL))) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
        }
        if (kvd_allocated) {
            if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_block_delete(pbilm_entry->kvd_handle, FALSE))) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
        }
        if (continue_lookup_created) {
            if (SX_CHECK_FAIL(rb_rc = hwd_continue_lookup_nhlfe_remove_entry(&(pbilm_entry->params)))) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
        }
        if (ecmp_ref_inc) {
            if (SX_CHECK_FAIL(rb_rc = hwd_router_ecmp_ref_dec(pbilm_entry->nhlfe_handle))) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
        }
    }

    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_del_pbilm(flex_acl_db_pbilm_entry_t *pbilm_entry, boolean_t remove_kvdl)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("flex_acl_hw_del_pbilm, pbilm_entry->kvd_handle = 0x%" PRIx64 "\n", pbilm_entry->kvd_handle);

    if (remove_kvdl) {
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_del_pbilm failed: Failed on RM entry set.\n");
            goto out;
        }

        rc = kvd_linear_manager_block_delete(pbilm_entry->kvd_handle, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_del_pbilm failed: delete kvd block failed, kvd_handle: %" PRIu64 "\n",
                       pbilm_entry->kvd_handle);
            goto rollback_rm_pbilm_entry_set;
        }
    }
    /* NOTE: the following actions are not reversible and assumed to succeed*/
    switch (pbilm_entry->params.ilm_fwd_action) {
    case SX_MPLS_ILM_CONTINUE_LOOKUP:
    case SX_MPLS_ILM_GOTO_ROUTER:
        rc = hwd_continue_lookup_nhlfe_remove_entry(&(pbilm_entry->params));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_del_pbilm failed removing continue lookup entry.\n");
            goto out;
        }
        break;

    case SX_MPLS_ILM_GOTO_ECMP:
        rc = hwd_router_ecmp_ref_dec(pbilm_entry->nhlfe_handle);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL flex_acl_hw_del_pbilm failed removing reference to hwd ecmp, nhlfe_handle: %" PRIu64 "\n",
                       pbilm_entry->nhlfe_handle);
            goto out;
        }
        break;
    }

    goto out;

rollback_rm_pbilm_entry_set:
    if (SX_CHECK_FAIL(rb_rc = rm_entries_set(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, SX_ACCESS_CMD_ADD, 1, NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_hw_config_pbs_write_reg(flex_acl_db_pbs_entry_t   *pbs_entry,
                                               boolean_t                  is_vport,
                                               kvd_linear_manager_index_t kvd_index)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_rc = SXD_STATUS_SUCCESS;
    struct ku_ppbs_reg   ppbs = {.swid = 0};
    sxd_reg_meta_t       meta = {.access_cmd = 0};
    sx_dev_id_t          devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t             dev_info_arr_size = 0;
    sx_port_ucroute_id_t sys_port = 0;
    uint32_t             dev_idx = 0;

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(ppbs);

    ppbs.pbs_ptr = pbs_entry->pbs_id;
    ppbs.swid = pbs_entry->swid;
    ppbs.pbs_ptr = kvd_index;

    switch (pbs_entry->entry_type) {
    case SX_ACL_PBS_ENTRY_TYPE_UNICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST:
        SX_LOG_DBG("PBS UNICAST port num:%d \n", pbs_entry->port_num);
        ppbs.type = SXD_PPBS_TYPE_UNICAST_RECORD_E;
        ppbs.pbs_record.ppbs_unicast.action = SXD_PPBS_ACTION_NOP_E;

        if (pbs_entry->port_num == 0) {
            SX_LOG_DBG("In case of zero ports action should have write to HW as a DROP action\n");
            break;
        }

        if (IS_LAG_OR_VLAG(pbs_entry->log_port)) {
            SX_LOG_DBG("PBS UNICAST LAG\n");
            ppbs.type = SXD_PPBS_TYPE_UNICAST_LAG_RECORD_E;
            ppbs.pbs_record.unicast_lag.lag_id = SX_PORT_LAG_ID_GET(pbs_entry->log_port);
            if (SX_PORT_TYPE_ID_GET(pbs_entry->log_port) == SX_PORT_TYPE_VLAG) {
                ppbs.pbs_record.unicast_lag.uvid = 1;
                ppbs.pbs_record.unicast_lag.vid = SX_PORT_VLAN_ID_GET(pbs_entry->log_port);
            }
        } else {
            rc = port_ucroute_id_map_get(SX_ACCESS_CMD_GET, pbs_entry->log_port, &sys_port);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("port_ucroute_id_map_get Failed\n");
                goto out;
            }
            ppbs.pbs_record.ppbs_unicast.system_port = sys_port;
            if (is_vport == TRUE) {
                ppbs.pbs_record.ppbs_unicast.set_vid = TRUE;
                ppbs.pbs_record.ppbs_unicast.vid = SX_PORT_VLAN_ID_GET(pbs_entry->log_port);
            }
        }
        break;

    case SX_ACL_PBS_ENTRY_TYPE_MULTICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST:
        SX_LOG_DBG("PBS MULTICAST %sPORT\n", is_vport ? "V" : "");
        ppbs.type = SXD_PPBS_TYPE_MULTICAST_RECORD_E;
        ppbs.pbs_record.ppbs_multicast.pgi = 0x1FFF;
        ppbs.pbs_record.ppbs_multicast.mid = FDB_MC_CALCULATE_MID(pbs_entry->mid);
        SX_LOG_DBG("PBS MULTICAST %sPORT pgi:%d mid:%d\n",
                   is_vport ? "V" : "",
                   ppbs.pbs_record.ppbs_multicast.pgi,
                   ppbs.pbs_record.ppbs_multicast.mid);
        break;

    case SX_ACL_PBS_ENTRY_TYPE_ROUTING:
        ppbs.type = SXD_PPBS_TYPE_UNICAST_RECORD_E;
        ppbs.pbs_record.ppbs_unicast.action = SXD_PPBS_ACTION_FORWARD_TO_IP_ROUTER_E;
        break;

    case SX_ACL_PBS_ENTRY_TYPE_LAST:
        rc = __flex_acl_hw_config_extended_pbs_write(pbs_entry, &ppbs);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS failed configure hw : Failed to configure extended[%u] pbs record: %s \n",
                       pbs_entry->extended_entry_type, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("ACL PBS failed configure hw : Wrong pbs entry type :%u \n", pbs_entry->entry_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    meta.swid = pbs_entry->swid;
    meta.access_cmd = SXD_ACCESS_CMD_SET;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    meta.dev_id = devs_list[dev_idx];

    sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PPBS_E, &ppbs, &meta, 1, NULL, NULL);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("ACL PBS failed configure hw : sxd_access_reg_ppbs failed rc :%d \n", sxd_rc);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_config_extended_pbs_write(const flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                           struct ku_ppbs_reg            *ppbs_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    underlay_mc_ptr = 0;

    SX_LOG_ENTER();

    if (pbs_entry_p->entry_type != SX_ACL_PBS_ENTRY_TYPE_LAST) {
        SX_LOG_ERR("The function can configure only extended pbs records :%u \n", pbs_entry_p->entry_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    switch (pbs_entry_p->extended_entry_type) {
    case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL:
        ppbs_p->type = SXD_PPBS_TYPE_UNICAST_TUNNEL_RECORD_E;
        ppbs_p->pbs_record.unicast_tunnel.gen_enc = 0;
        ppbs_p->pbs_record.unicast_tunnel.tunnel_port_lbf_bitmap = 0xF;
        if (pbs_entry_p->ip_tunnel.underlay_dip.version == SX_IP_VERSION_IPV4) {
            ppbs_p->pbs_record.unicast_tunnel.protocol = (sxd_ppbs_protocol_t)SXD_UDIP_TYPE_IPV4;
            ppbs_p->pbs_record.unicast_tunnel.udip = (uint32_t)(pbs_entry_p->ip_tunnel.underlay_dip.addr.ipv4.s_addr);
        } else {
            ppbs_p->pbs_record.unicast_tunnel.protocol = (sxd_ppbs_protocol_t)SXD_UDIP_TYPE_IPV6;
            ppbs_p->pbs_record.unicast_tunnel.udip = (uint32_t)pbs_entry_p->ipv6_hw_index;
        }

        break;

    case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_MULTICAST_TUNNEL:
        if (pbs_entry_p->tnumt_valid) {
            ppbs_p->type = SXD_PPBS_TYPE_MULTICAST_TUNNEL_RECORD_E;

            underlay_mc_ptr = pbs_entry_p->tnumt;
            ppbs_p->pbs_record.multicast_tunnel.lbf_tunnel_port_bitmap = 0xF;
            ppbs_p->pbs_record.multicast_tunnel.ecmp_size = pbs_entry_p->ecmp_size;
            ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_msb = (underlay_mc_ptr >> 8) & 0x00ffff;
            ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_lsb = (underlay_mc_ptr >> 0) & 0x0000ff;
            ppbs_p->pbs_record.multicast_tunnel.mid = FDB_MC_CALCULATE_MID(pbs_entry_p->mid);

            SX_LOG_DBG("PBS mid:%d tnumt:%04x %02x\n",
                       ppbs_p->pbs_record.multicast_tunnel.mid,
                       ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_msb,
                       ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_lsb);
        } else {
            /* If there is not TNUMT, use the standard MC PPBS */
            ppbs_p->type = SXD_PPBS_TYPE_MULTICAST_RECORD_E;
            ppbs_p->pbs_record.ppbs_multicast.pgi = 0x1FFF;
            ppbs_p->pbs_record.multicast_tunnel.mid = FDB_MC_CALCULATE_MID(pbs_entry_p->mid);

            SX_LOG_DBG("PBS mid:%d\n", ppbs_p->pbs_record.ppbs_multicast.mid);
        }

        break;

    case SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP:
        if (default_register_cbs_p == NULL) {
            SX_LOG_ERR("Cannot prepare PBS EMAD. Default register callbacks are not set.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (default_register_cbs_p->config_uc_tunnel_pbs_write_cb == NULL) {
            SX_LOG_ERR("A callback that configures UC tunnel ECMP PBS records is not initialized. \n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        rc = default_register_cbs_p->config_uc_tunnel_pbs_write_cb(pbs_entry_p, ppbs_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("A callback that configures UC tunnel ECMP PBS records returned an error: %s\n",
                       sx_status_str(rc));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Reached an unsupported extended entry type of PBS records: %u\n",
                   pbs_entry_p->extended_entry_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_config_uc_tunnel_pbs_write(const struct flex_acl_db_pbs_entry *pbs_entry_p,
                                                   struct ku_ppbs_reg                 *ppbs_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    underlay_mc_ptr = 0;

    SX_LOG_ENTER();

    if (pbs_entry_p->extended_entry_type != SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP) {
        SX_LOG_ERR("The function configures only UC tunnel ECMP PBS records, pbs entry type :%u \n",
                   pbs_entry_p->entry_type);
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (pbs_entry_p->tnumt_valid) {
        ppbs_p->type = SXD_PPBS_TYPE_MULTICAST_TUNNEL_RECORD_E;

        underlay_mc_ptr = pbs_entry_p->tnumt;
        ppbs_p->pbs_record.multicast_tunnel.lbf_tunnel_port_bitmap = 0xF;
        ppbs_p->pbs_record.multicast_tunnel.ecmp_size = pbs_entry_p->ecmp_size;
        ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_msb = (underlay_mc_ptr >> 8) & 0x00ffff;
        ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_lsb = (underlay_mc_ptr >> 0) & 0x0000ff;
        ppbs_p->pbs_record.multicast_tunnel.mid = rm_resource_global.reserved_empty_mid;

        SX_LOG_DBG("PBS mid:%d tnumt:%04x %02x ecmp size:%d\n",
                   ppbs_p->pbs_record.multicast_tunnel.mid,
                   ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_msb,
                   ppbs_p->pbs_record.multicast_tunnel.underlay_mc_ptr_lsb,
                   ppbs_p->pbs_record.multicast_tunnel.ecmp_size);
    } else {
        /* If there is not TNUMT, use the standard MC PPBS */
        ppbs_p->type = SXD_PPBS_TYPE_MULTICAST_RECORD_E;
        ppbs_p->pbs_record.ppbs_multicast.pgi = 0x1FFF;
        ppbs_p->pbs_record.ppbs_multicast.mid = rm_resource_global.reserved_empty_mid;

        SX_LOG_DBG("PBS mid:%d\n", ppbs_p->pbs_record.ppbs_multicast.mid);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t flex2_acl_hw_config_uc_tunnel_pbs_write(const struct flex_acl_db_pbs_entry *pbs_entry_p,
                                                    struct ku_ppbs_reg                 *ppbs_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    kvd_linear_manager_index_t kvd_index = 0;

    SX_LOG_ENTER();

    if (pbs_entry_p->extended_entry_type != SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP) {
        SX_LOG_ERR("The function configures only UC tunnel ECMP PBS records, pbs entry type :%u \n",
                   pbs_entry_p->entry_type);
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (pbs_entry_p->tnumt_valid) {
        ppbs_p->type = SXD_PPBS_TYPE_UNICAST_TUNNEL_RECORD_E;
        ppbs_p->pbs_record.unicast_tunnel.gen_enc = 1;
        ppbs_p->pbs_record.unicast_tunnel.protocol = 0;
        ppbs_p->pbs_record.unicast_tunnel.ecmp_size = pbs_entry_p->ecmp_size;
        ppbs_p->pbs_record.unicast_tunnel.udip = pbs_entry_p->tnumt;
        ppbs_p->pbs_record.unicast_tunnel.tunnel_port_lbf_bitmap = pbs_entry_p->tunnel_port_bitmap;
    } else {
        err = sdk_tunnel_impl_zeroed_reserved_tngee_index_get(&kvd_index);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get a KVD index of reserved TNGEE for PBS record : %s \n", sx_status_str(err));
            goto out;
        }

        ppbs_p->type = SXD_PPBS_TYPE_UNICAST_TUNNEL_RECORD_E;
        ppbs_p->pbs_record.unicast_tunnel.gen_enc = 1;
        ppbs_p->pbs_record.unicast_tunnel.protocol = 0;
        ppbs_p->pbs_record.unicast_tunnel.ecmp_size = 1;
        ppbs_p->pbs_record.unicast_tunnel.udip = kvd_index;
    }

    SX_LOG_DBG("PBS gen_enc:%u protocol:%u ecmp size:%u dip:%u \n",
               ppbs_p->pbs_record.unicast_tunnel.gen_enc,
               ppbs_p->pbs_record.unicast_tunnel.protocol,
               ppbs_p->pbs_record.unicast_tunnel.ecmp_size,
               ppbs_p->pbs_record.unicast_tunnel.udip);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t flex_acl_hw_config_pbs(flex_acl_db_pbs_entry_t *pbs_entry, boolean_t is_vport)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       r_rc = SX_STATUS_SUCCESS;
    kvd_linear_manager_index_t        kvd_index = 0;
    kvd_linear_manager_block_length_t size = 1;

    SX_LOG_ENTER();

    rc = kvd_linear_manager_handle_lock(pbs_entry->kvd_handle, &kvd_index, &size);
    if ((SX_STATUS_SUCCESS != rc) || (size < 1)) {
        SX_LOG_ERR("ACL config PBS : Failed locking kvd block, kvd_handle: %" PRIu64 ".\n", pbs_entry->kvd_handle);
        goto out;
    }
    SX_LOG_DBG("KVD handle:0x%" PRIx64 " locked index :%d \n", pbs_entry->kvd_handle, kvd_index);
    rc = __flex_acl_hw_config_pbs_write_reg(pbs_entry, is_vport, kvd_index);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL config PBS : led writing PBS register.\n");
        goto release;
    }

release:
    r_rc = kvd_linear_manager_handle_release(pbs_entry->kvd_handle);
    if (SX_STATUS_SUCCESS != r_rc) {
        rc = r_rc;
        SX_LOG_ERR("ACL action : Failed releasing the kvd lock, kvd_handle: %" PRIu64 "\n", pbs_entry->kvd_handle);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_add_pbs(flex_acl_db_pbs_entry_t *pbs_entry, boolean_t is_vport)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_PBS_E, 1, FALSE, &(pbs_entry->kvd_handle));
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL flex_acl_hw_add_pbs failed: Failed allocating kvd block.\n");
        goto out;
    }
    SX_LOG_DBG("flex_acl_hw_add_pbs, pbs_entry->kvd_handle = 0x%" PRIx64 "\n", pbs_entry->kvd_handle);
    SX_LOG_DBG("KVD block was added kvs_handle:0x%" PRIx64 " \n", pbs_entry->kvd_handle);

    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_PBS_E, SX_ACCESS_CMD_ADD, 1, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL flex_acl_hw_add_pbs failed: Failed on RM entry set.\n");
        goto rollback_kvd_linear_manager_block_add;
    }

    rc = flex_acl_hw_config_pbs(pbs_entry, is_vport);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL flex_acl_hw_add_pbs failed: flex_acl_hw_config_pbs failed.\n");
        goto rollback_rm_pbs_entry_set;
    }

    goto out;

rollback_rm_pbs_entry_set:
    if (SX_CHECK_FAIL(rb_rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_PBS_E, SX_ACCESS_CMD_DELETE, 1, NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_kvd_linear_manager_block_add:
    if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_block_delete(pbs_entry->kvd_handle, FALSE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_del_pbs(flex_acl_db_pbs_entry_t *pbs_entry)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("flex_acl_hw_del_pbs, pbs_entry->kvd_handle = 0x%" PRIx64 "\n", pbs_entry->kvd_handle);

    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_PBS_E, SX_ACCESS_CMD_DELETE, 1, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL flex_acl_hw_del_pbs failed: Failed on RM entry set.\n");
        goto out;
    }

    rc = kvd_linear_manager_block_delete(pbs_entry->kvd_handle, FALSE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL flex_acl_hw_del_pbs failed: delete kvd block failed, kvd_handle: %" PRIu64 ".\n",
                   pbs_entry->kvd_handle);
        goto rollback_rm_pbs_entry_set;
    }

    goto out;

rollback_rm_pbs_entry_set:
    if (SX_CHECK_FAIL(rb_rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_PBS_E, SX_ACCESS_CMD_ADD, 1, NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_pbs_action_inc(flex_acl_hw_action_t *hw_action,
                                                boolean_t             is_head,
                                                uint32_t             *kvd_index_p)
{
    sx_status_t rc;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_pbs_add_entry(hw_action->pbs_kvd_handle, is_head, kvd_index_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL pbs action inc failed after flex_acl_hw_db_pbs_add_entry, pbs_kvd_handle: %" PRIu64 "\n",
                   hw_action->pbs_kvd_handle);
        goto out;
    }
    rc = kvd_linear_manager_ref_add(hw_action->pbs_kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        flex_acl_hw_db_pbs_remove_entry(hw_action->pbs_kvd_handle, kvd_index_p);
        SX_LOG_ERR("ACL pbs action inc failed after flex_acl_hw_db_pbs_remove_entry, pbs_kvd_handle: %" PRIu64 "\n",
                   hw_action->pbs_kvd_handle);
        goto out;
    }
    hw_action->is_ref_count_inc = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_pbs_action_dec(flex_acl_hw_action_t *hw_action,
                                                boolean_t             is_head,
                                                uint32_t             *kvd_index_p)
{
    sx_status_t rc;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_pbs_remove_entry(hw_action->pbs_kvd_handle, kvd_index_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR(
            "ACL bs action inc failed after  flex_acl_hw_db_pbs_remove_entry, pbs_kvd_handle: %" PRIu64 ", error: [%s]\n",
            hw_action->pbs_kvd_handle,
            sx_status_str(rc));
        goto out;
    }
    rc = kvd_linear_manager_ref_delete(hw_action->pbs_kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        flex_acl_hw_db_pbs_add_entry(hw_action->pbs_kvd_handle, is_head, kvd_index_p);
        SX_LOG_ERR(
            "ACL bs action inc failed after kvd_linear_manager_ref_delete, pbs_kvd_handle: %" PRIu64 ", error: [%s]\n",
            hw_action->pbs_kvd_handle,
            sx_status_str(rc));
        goto out;
    }
    hw_action->is_ref_count_inc = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_change_pbs_action_fix_trap(flex_acl_hw_db_action_set_t     *hw_action,
                                                            flex_acl_hw_action_t            *action_p,
                                                            flex_acl_hw_db_kvd_action_set_t *kvd_action_set,
                                                            flex_acl_db_flex_rule_t         *rule)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_relocation_data_t relocation_data = {.is_head = 0};

    if (flex_acl_hw_action_details[action_p->action_type].bind_populate) {
        relocation_data.is_head = FALSE;
        relocation_data.kvd_index_p = &(hw_action->action_set.kvd_index);
        if (flex_acl_hw_action_details[action_p->action_type].bind_populate) {
            rc = flex_acl_hw_action_details[action_p->action_type].bind_populate(action_p,
                                                                                 rule,
                                                                                 relocation_data,
                                                                                 FALSE);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed bind populating TRAP action. [%s]\n", sx_status_str(rc));
                goto out;
            }
        }
    }
    rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed editing KVd extended action.\n");
        goto out;
    }
    if (flex_acl_hw_action_details[action_p->action_type].release_lock) {
        rc =
            flex_acl_hw_action_details[action_p->action_type].release_lock(action_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Change PBS action failed release lock. [%s]\n", sx_status_str(rc));
            goto out;
        }
    }


out:
    return rc;
}

static sx_status_t __flex_acl_hw_change_pbs_action_fix_pbs(flex_acl_hw_db_action_set_t     *hw_action,
                                                           flex_acl_hw_action_t            *action_p,
                                                           kvd_linear_manager_index_t      *kvd_index_p,
                                                           flex_acl_hw_db_kvd_action_set_t *kvd_action_set,
                                                           boolean_t                        to_pbs_action,
                                                           flex_acl_db_flex_rule_t         *rule)
{
    sx_status_t                rc = SX_STATUS_SUCCESS, rb_rc;
    flex_acl_relocation_data_t relocation_data = {.is_head = 0};

    SX_LOG_ENTER();

    if (!to_pbs_action) {
        /* Change to drop action.  dec counters. */
        rc = __flex_acl_hw_pbs_action_dec(action_p, !kvd_action_set, kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Change PBS action failed __flex_acl_hw_pbs_action_dec failed\n");
            goto out;
        }
    }

    relocation_data.is_head = !kvd_action_set;
    relocation_data.kvd_index_p = kvd_index_p;

    if (flex_acl_hw_action_details[action_p->action_type].bind_populate) {
        rc = flex_acl_hw_action_details[action_p->action_type].bind_populate(action_p,
                                                                             rule,
                                                                             relocation_data,
                                                                             TRUE);
        if (SX_STATUS_SUCCESS != rc) {
            if (!to_pbs_action) {
                rb_rc = __flex_acl_hw_pbs_action_inc(action_p, !kvd_action_set, kvd_index_p);
                if (SX_STATUS_SUCCESS != rb_rc) {
                    SX_LOG_ERR("__flex_acl_hw_pbs_action_inc failed in rollback\n");
                }
            }
            SX_LOG_ERR("Change PBS action failed flex_acl_hw_action_details Failed\n");
            goto out;
        }
    }

    if (kvd_action_set) {
        rc = __flex_acl_hw_edit_action_kvd(kvd_action_set, FALSE, FALSE);
    } else {
        rc = flex_acl_hw_edit_action_register(hw_action, FALSE);
    }

    if (SX_STATUS_SUCCESS != rc) {
        rb_rc = to_pbs_action ? __flex_acl_hw_pbs_action_dec(action_p, !kvd_action_set, kvd_index_p) :
                __flex_acl_hw_pbs_action_inc(action_p, !kvd_action_set, kvd_index_p);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR("Change PBS action failed __flex_acl_hw_pbs_action_inc/dec failed at rollback\n");
        }
        goto out;
    }

    if (flex_acl_hw_action_details[action_p->action_type].release_lock) {
        rc = flex_acl_hw_action_details[action_p->action_type].release_lock(action_p);
        if (SX_STATUS_SUCCESS != rc) {
            rb_rc = to_pbs_action ? __flex_acl_hw_pbs_action_dec(action_p, !kvd_action_set, kvd_index_p) :
                    __flex_acl_hw_pbs_action_inc(action_p, !kvd_action_set, kvd_index_p);
            if (SX_STATUS_SUCCESS != rb_rc) {
                SX_LOG_ERR("Change PBS action failed __flex_acl_hw_pbs_action_inc/dec failed at rollback\n");
            }
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_change_pbs_action(flex_acl_rule_id_t      *rule_id_p,
                                          flex_acl_db_pbs_entry_t *pbs_entry,
                                          boolean_t                to_pbs_action)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t         *rule = NULL;
    flex_acl_hw_db_action_set_t     *hw_action;
    uint32_t                         iii = 0;
    const cl_list_t                 *kvd_action_set_list = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    cl_list_iterator_t               iterk, list_head, list_end;
    boolean_t                        is_trap_action_in_rule = FALSE;
    boolean_t                        found_pbs = FALSE;
    boolean_t                        acl_drop_trap_action_in_rule = FALSE;
    flex_acl_hw_action_t            *hw_action_p = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_rule_by_offset(rule_id_p->region_id, rule_id_p->offset, &rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get rule from db for region:%u offset:%u\n",
                   rule_id_p->region_id,
                   rule_id_p->offset);
        goto out;
    }
    hw_action = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;

    if (pbs_entry->entry_type != SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST) {
        rc = flex_acl_hw_db_get_action_from_rule(rule, SXD_ACTION_TYPE_TRAP_E, &is_trap_action_in_rule, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL change pbs action : failed in flex_acl_hw_db_get_action_from_rule.\n");
            goto out;
        }
        if (!is_trap_action_in_rule) {
            rc = flex_acl_hw_db_get_action_from_rule(rule,
                                                     SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                     &is_trap_action_in_rule,
                                                     NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL change pbs action : failed in flex_acl_hw_db_get_action_from_rule.\n");
                goto out;
            }
            if (!is_trap_action_in_rule) {
                rc = __find_acl_drop_trap_action_in_rule(rule, &acl_drop_trap_action_in_rule, &hw_action_p);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in rule  "
                               "RC=%s\n", sx_status_str(rc));
                    goto out;
                }
                if (acl_drop_trap_action_in_rule) {
                    __del_acl_drop_action_trap_action_from_db(rule, hw_action_p);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in list  "
                                   "action in rule. RC=%s\n", sx_status_str(rc));
                        goto out;
                    }
                }
            }
        }
    }

    SX_LOG_DBG("Change PBS action region:%d rule:%d TRAP action :%s exists in rule\n",
               rule_id_p->region_id, rule_id_p->offset, is_trap_action_in_rule ? "" : "NOT");

    /* First look for PBS and fix it */
    for (iii = 0; iii < hw_action->action_set.actions_count; iii++) {
        if ((hw_action->action_set.actions[iii].api_action_type == SX_FLEX_ACL_ACTION_PBS) &&
            (pbs_entry->pbs_id == hw_action->action_set.actions[iii].pbs_id)) {
            rc = __flex_acl_hw_change_pbs_action_fix_pbs(hw_action, &hw_action->action_set.actions[iii],
                                                         &(hw_action->action_set.kvd_index), NULL,
                                                         to_pbs_action, rule);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("__flex_acl_hw_change_pbs_action_fix_pbs failed for non KVD.[%s]\n", sx_status_str(rc));
                goto out;
            }
            found_pbs = TRUE;
        }
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(hw_action, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Change PBS action failed : flex_acl_hw_db_get_kvd_action_set_list failed. [%s]\n", sx_status_str(
                       rc));
        goto out;
    }

    SX_LOG_DBG("Looking for PBS in KVD.\n");
    list_head = cl_list_head(kvd_action_set_list);
    list_end = cl_list_end(kvd_action_set_list);
    for (iterk = list_head; iterk != list_end;
         iterk = cl_list_next(iterk)) {
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iterk);
        for (iii = 0; iii < kvd_action_set->actions_count; iii++) {
            if ((kvd_action_set->actions[iii].api_action_type == SX_FLEX_ACL_ACTION_PBS) &&
                (pbs_entry->pbs_id == kvd_action_set->actions[iii].pbs_id)) {
                rc = __flex_acl_hw_change_pbs_action_fix_pbs(hw_action, &kvd_action_set->actions[iii],
                                                             &(hw_action->action_set.kvd_index), kvd_action_set,
                                                             to_pbs_action, rule);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("__flex_acl_hw_change_pbs_action_fix_pbs failed for KVD.[%s]\n", sx_status_str(rc));
                    goto out;
                }
            }
            found_pbs = TRUE;
        }
    }

    if (!found_pbs) {
        /* PBS action was not found! */
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Change PBS action failed ,PBS was not found for rule. region:%u offset:%u\n",
                   rule_id_p->region_id,
                   rule_id_p->offset);
        goto out;
    }


    /* Now look for TRAP and fix it */
    if (!is_trap_action_in_rule) {
        goto out;
    }

    for (iii = 0; iii < hw_action->action_set.actions_count; iii++) {
        if ((hw_action->action_set.actions[iii].action_type == SXD_ACTION_TYPE_TRAP_E) ||
            (hw_action->action_set.actions[iii].action_type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E)) {
            rc = __flex_acl_hw_change_pbs_action_fix_trap(hw_action, &hw_action->action_set.actions[iii],
                                                          kvd_action_set, rule);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("__flex_acl_hw_change_pbs_action_fix_trap failed for non KVD.[%s]\n", sx_status_str(rc));
                goto out;
            }
        }
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(hw_action, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Change PBS action failed : flex_acl_hw_db_get_kvd_action_set_list failed. [%s]\n", sx_status_str(
                       rc));
        goto out;
    }

    SX_LOG_DBG("Looking for TRAP in KVD.\n");
    list_end = cl_list_end(kvd_action_set_list);
    list_head = cl_list_head(kvd_action_set_list);
    for (iterk = list_head; iterk != list_end;
         iterk = cl_list_next(iterk)) {
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iterk);
        for (iii = 0; iii < kvd_action_set->actions_count; iii++) {
            if ((kvd_action_set->actions[iii].action_type == SXD_ACTION_TYPE_TRAP_E) ||
                (kvd_action_set->actions[iii].action_type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E)) {
                rc = __flex_acl_hw_change_pbs_action_fix_trap(hw_action, &kvd_action_set->actions[iii],
                                                              kvd_action_set, rule);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("__flex_acl_hw_change_pbs_action_fix_trap failed for KVD.[%s]\n", sx_status_str(rc));
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_port_filter_populate(sx_flex_acl_flex_action_t action,
                                                 boolean_t                 is_defer,
                                                 flex_acl_rule_id_t        rule_id,
                                                 hw_action_list_t         *hw_action_list_p,
                                                 hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(hw_action_list_p);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(rule_id);

    SX_LOG_ENTER();

    hw_action->mc_container = action.fields.action_port_filter.mc_container_id;

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __port_filter_fill_action_slot_physical_port(sxd_action_slot_t         *action_slot,
                                                                flex_acl_action_modifier_e action_modifier,
                                                                sx_port_id_t               phy_port)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sx_port_id_t hw_port = SX_PORT_PHY_ID_GET(phy_port);
    uint32_t    *action_port_filter_ext2_egress_port_list = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(action_modifier);

    if (hw_port <= 64) {
        if (action_slot->type != SXD_ACTION_TYPE_PORT_FILTER_E) {
            goto out;
        }
        if (hw_port == 64) {
            action_slot->fields.action_port_filter.egress_port_list_64 |= 1;
            goto out;
        }
        if (hw_port > 31) {
            action_slot->fields.action_port_filter.egress_port_list_32_63 |= (1 << ((int)(hw_port - 32)));
            goto out;
        }
        if ((hw_port <= 31) && (hw_port > 0)) {
            action_slot->fields.action_port_filter.egress_port_list_0_31 |= (1 << ((int)(hw_port)));
            goto out;
        }
    } else if ((hw_port <= 128) && (ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage))) {
        if (action_slot->type != SXD_ACTION_TYPE_PORT_FILTER_EXT_E) {
            goto out;
        }
        if (hw_port <= 96) {
            action_slot->fields.action_port_filter_ext.egress_port_list_65_96 |= (1 << ((int)(hw_port - 65)));
        } else {
            action_slot->fields.action_port_filter_ext.egress_port_list_97_128 |= (1 << ((int)(hw_port - 97)));
        }
        goto out;
    } else if (((hw_port <= 258) && (ACL_STAGE_IS_FLEX3_OR_ABOVE(flex_acl_stage))) ||
               ((hw_port <= 516) && (ACL_STAGE_IS_FLEX4_OR_ABOVE(flex_acl_stage)))) {
        if (action_slot->type != SXD_ACTION_TYPE_PORT_FILTER_EXT2_E) {
            goto out;
        }
        if (PORT_FILTER_EXT2_FLEX_ACTION_HW_PORT_TO_PAGE(hw_port) !=
            action_slot->fields.action_port_filter_ext2.page) {
            goto out;
        }
        if (PORT_FILTER_EXT2_FLEX_ACTION_HW_PORT_TO_LIST(hw_port) == 0) {
            action_port_filter_ext2_egress_port_list =
                &action_slot->fields.action_port_filter_ext2.egress_port_list_0_31;
        } else {
            action_port_filter_ext2_egress_port_list =
                &action_slot->fields.action_port_filter_ext2.egress_port_list_32_63;
        }
        *action_port_filter_ext2_egress_port_list |=
            (1 << ((int)(PORT_FILTER_EXT2_FLEX_ACTION_HW_PORT_TO_OFFSET_IN_LIST(hw_port))));
        goto out;
    }
    SX_LOG_ERR("invalid log port [0x%x] hw port [%d] for flex stage [%d] \n", phy_port, hw_port, flex_acl_stage);
    rc = SX_STATUS_PARAM_ERROR;
    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __port_filter_mc_container_fill_action_slot(sxd_action_slot_t         *action_slot_p,
                                                               flex_acl_action_modifier_e action_modifier,
                                                               sx_mc_container_id_t       mc_container_id)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    sx_port_log_id_t log_port = 0;
    uint32_t         port_idx = 0, lag_port_idx = 0;
    uint32_t         ports_list_count = rm_resource_global.lag_port_members_max;
    sx_port_id_t    *ports_list_p = NULL;
    sx_lag_id_t      lag_id = 0;
    sx_port_type_t   port_type = SX_PORT_TYPE_NETWORK;
    sx_port_id_t    *log_ports_ref_list_p = NULL;
    uint32_t         log_port_count = 0;

    SX_LOG_ENTER();

    ports_list_p = (sx_port_id_t*)cl_malloc(rm_resource_global.lag_port_members_max * sizeof(sx_port_id_t));

    SX_MEM_CLR(action_slot_p->fields.action_port_filter);
    SX_MEM_CLR(action_slot_p->fields.action_port_filter_ext);
    SX_MEM_CLR(action_slot_p->fields.action_port_filter_ext2);

    /* get log_port_ref_list of mc container id from DB*/
    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_id, &log_port_count, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get log_ports_ref count of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    log_ports_ref_list_p = (sx_port_id_t*)cl_malloc(log_port_count * sizeof(sx_port_id_t));
    if (log_ports_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for lag port list\n");
        goto out;
    }

    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_id, &log_port_count, log_ports_ref_list_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get log_ports_ref list of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    if (action_slot_p->type == SXD_ACTION_TYPE_PORT_FILTER_EXT2_E) {
        switch (action_modifier) {
        case FLEX_ACL_ACTION_MODEFIER_NONE_E:
            action_slot_p->fields.action_port_filter_ext2.page = 2;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE3_E:
            action_slot_p->fields.action_port_filter_ext2.page = 3;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE4_E:
            action_slot_p->fields.action_port_filter_ext2.page = 4;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE5_E:
            action_slot_p->fields.action_port_filter_ext2.page = 5;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE6_E:
            action_slot_p->fields.action_port_filter_ext2.page = 6;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE7_E:
            action_slot_p->fields.action_port_filter_ext2.page = 7;
            break;

        case FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE8_E:
            action_slot_p->fields.action_port_filter_ext2.page = 8;
            break;

        default:
            SX_LOG_ERR("Invalid action modifier (%u) for acl ports filter ext2\n", action_modifier);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* Convert LAG to physical ports and fill physical ports */
    for (port_idx = 0; port_idx < log_port_count; port_idx++) {
        log_port = log_ports_ref_list_p[port_idx];
        port_type = SX_PORT_TYPE_ID_GET(log_port);
        if (SX_PORT_TYPE_NETWORK == port_type) {
            rc = __port_filter_fill_action_slot_physical_port(action_slot_p, action_modifier, log_port);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Port[0x%04X] not supported [%s]\n", log_port, sx_status_str(rc));
                goto out;
            }
        } else if (SX_PORT_TYPE_LAG == port_type) {
            ports_list_count = rm_resource_global.lag_port_members_max;
            lag_id = SX_PORT_LAG_ID_GET(log_port);
            rc = sx_la_db_log_port_get(lag_id, SX_PORT_DEV_ID_GET(log_port), ports_list_p, &ports_list_count);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Cannot retrieve ports from lag[0x%04X], rc[%s]\n", lag_id, sx_status_str(rc));
                goto out;
            }
            for (lag_port_idx = 0; lag_port_idx < ports_list_count; lag_port_idx++) {
                rc =
                    __port_filter_fill_action_slot_physical_port(action_slot_p, action_modifier,
                                                                 ports_list_p[lag_port_idx]);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("Port[0x%04X] not supported [%s]\n", log_port, sx_status_str(rc));
                    goto out;
                }
            }
        } else {
            SX_LOG_ERR("Port[0x%04X] type(%s) unsupported\n", log_port, sx_port_type_str(port_type));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    if (log_ports_ref_list_p) {
        cl_free(log_ports_ref_list_p);
    }
    if (ports_list_p) {
        cl_free(ports_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_port_filter_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                      flex_acl_db_flex_rule_t   *rule,
                                                      flex_acl_relocation_data_t relocation_data,
                                                      boolean_t                  add_ref)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(rule);
    UNUSED_PARAM(relocation_data);

    SX_LOG_ENTER();

    if (add_ref) {
        SX_LOG_DBG(" Added port filter mc container id:[%u] to port_filter db\n", hw_action->mc_container);
        hw_action->is_ref_count_inc = TRUE;
    }

    rc = __port_filter_mc_container_fill_action_slot(&hw_action->slot,
                                                     hw_action->action_modifier,
                                                     hw_action->mc_container);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to fill action slot with mc container phys ports id:[%u] Error:[%s]\n",
                   hw_action->mc_container, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_action_details_get(sxd_flex_acl_action_type_t     sxd_flex_acl_action_type,
                                           flex_acl_hw_action_details_t** flex_acl_hw_action_details_pp)
{
    if (sxd_flex_acl_action_type >= SXD_ACTION_TYPE_LAST_E) {
        SX_LOG_ERR("Bad SXD action type %d\n", sxd_flex_acl_action_type);
        *flex_acl_hw_action_details_pp = NULL;
        return SX_STATUS_ERROR;
    }

    *flex_acl_hw_action_details_pp = &flex_acl_hw_action_details[sxd_flex_acl_action_type];
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_hw_init_default_actions()
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    kvd_linear_manager_block_length_t kvd_size = 0;
    kvd_linear_manager_block_length_t return_size = 0;
    kvd_linear_manager_index_t        kvd_index[DEFAULT_ACTIONS_MAX_BLOCK_SIZE];
    sx_dev_id_t                       devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                          dev_info_arr_size = 0;
    uint32_t                          dev_idx = 0;
    struct ku_pgcr_reg                pgcr_reg_data;
    sxd_reg_meta_t                    pgcr_reg_meta;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    sx_sdk_entries_param_t            action_entry_param;

    SX_LOG_ENTER();

    SX_MEM_CLR(action_entry_param);

    /* Check that the handle does not already exist */
    if (default_action_kvd_handle != FLEX_ACL_INVALID_KVD_HANDLE) {
        SX_LOG_ERR("KVD handle already exists for default action\n");
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* NOTE: From the KVD we always allocate the max number of allowed regions rounded up (1024).
     * This is to allow the FW to use the last entry (1023) as the default action for its "hidden"
     * region. This entry should NOT be overwritten by the default or regular actions.
     * We must validate that the actual number of regions does not exceed this value.
     * Currently we allow up to 1000 actual regions leaving 24 as spare for the FW (only one currently used).
     */
    return_size = kvd_size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;


    /* Validate the we would not overflow the kvd_index array */
    if (rm_resource_global.acl_regions_max > DEFAULT_ACTIONS_MAX_ALLOWED) {
        SX_LOG_ERR("Number of regions [%u] is greater than the size of max default block [%u].\n",
                   rm_resource_global.acl_regions_max, DEFAULT_ACTIONS_MAX_ALLOWED);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    SX_MEM_CLR(pgcr_reg_meta);
    SX_MEM_CLR(pgcr_reg_data);

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    /* NOTE: We inform the RM only about the actual region that will be used with defaults (currently 400)
     * and not the entire KVD space (1024). This is to allow a more accurate KVD HW resource accounting since
     * the KVD space (400-1022) will never be used in HW. Note that using the entire 0-1023 range in the RM
     * would have require 16K kvd entries due to DDD. We also account for the FW reserved default action.
     */
    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    action_entry_param.attr.acl_action_attr.default_action = TRUE;
    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                        SX_ACCESS_CMD_ADD,
                        rm_resource_global.acl_regions_max + DEFAULT_ACTIONS_FW_RESERVED,
                        &action_entry_param);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed on RM entry set for RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E.\n");
        goto out;
    }
    /* Get KVD memory for the default action */
    rc =
        kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_ACL_DEFAULT_ACTIONS_E,
                                     kvd_size,
                                     FALSE,
                                     &default_action_kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed allocating kvd block for default action.\n");
        goto kvd_error_rm;
    }
    rc = kvd_linear_manager_handle_lock(default_action_kvd_handle, kvd_index, &return_size);
    if ((SX_STATUS_SUCCESS != rc) || (return_size < kvd_size)) {
        SX_LOG_ERR("ACL action : Failed locking kvd block for default action.\n");
        goto kvd_error_block;
    }

    /* Write the base of the default action location into the pgcr register. */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    pgcr_reg_meta.dev_id = devs_list[dev_idx];

    pgcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pgcr_reg_data.default_action_pointer_base = kvd_index[0];
    sxd_status = sxd_access_reg_pgcr(&pgcr_reg_data, &pgcr_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure default action base to HW rc [%u] \n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto kvd_error_release;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    rc = kvd_linear_manager_handle_release(default_action_kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action.\n");
        goto kvd_error_block;
    }

    goto out;

kvd_error_release:
    kvd_linear_manager_handle_release(default_action_kvd_handle);
kvd_error_block:
    kvd_linear_manager_block_delete(default_action_kvd_handle, FALSE);
kvd_error_rm:
    rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                   SX_ACCESS_CMD_DELETE,
                   rm_resource_global.acl_regions_max + DEFAULT_ACTIONS_FW_RESERVED,
                   &action_entry_param);

    default_action_kvd_handle = FLEX_ACL_INVALID_KVD_HANDLE;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_deinit_default_actions()
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_sdk_entries_param_t action_entry_param;

    SX_LOG_ENTER();

    SX_MEM_CLR(action_entry_param);

    /* Check that the handle does not already exist */
    if (default_action_kvd_handle == FLEX_ACL_INVALID_KVD_HANDLE) {
        SX_LOG_ERR("KVD handle is invalid for default action\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = kvd_linear_manager_block_delete(default_action_kvd_handle, FALSE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed delete KVD block for default action.\n");
        goto out;
    }

    default_action_kvd_handle = FLEX_ACL_INVALID_KVD_HANDLE;

    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    action_entry_param.attr.acl_action_attr.default_action = TRUE;

    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                        SX_ACCESS_CMD_DELETE,
                        rm_resource_global.acl_regions_max + DEFAULT_ACTIONS_FW_RESERVED,
                        &action_entry_param);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed on RM entry set for RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_write_nop_default_action_set(sx_acl_region_id_t         region_id,
                                                     sx_flex_acl_flex_action_t *action_list_p,
                                                     uint32_t                   action_count,
                                                     boolean_t                  is_defer)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       r_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_kvd_action_set_t   kvd_action_set;
    kvd_linear_manager_block_length_t kvd_size = 0;
    kvd_linear_manager_block_length_t return_size = 0;
    kvd_linear_manager_index_t        kvd_index[DEFAULT_ACTIONS_MAX_BLOCK_SIZE];

    SX_LOG_ENTER();

    SX_MEM_CLR(kvd_action_set);
    /* Get region id starting with zero*/
    FLEX_CLR_ACL_REGION_BIT(region_id);

    /* Check that the handle does not already exist */
    if (default_action_kvd_handle == FLEX_ACL_INVALID_KVD_HANDLE) {
        SX_LOG_ERR("Default action KVD handle in not initialized.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (region_id > rm_resource_global.acl_regions_max) {
        SX_LOG_ERR("Default action region ID [%u] is larger than allowed [%u].\n",
                   region_id,
                   rm_resource_global.acl_regions_max);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* validate the we would not overflow the kvd_index array */
    if (rm_resource_global.acl_regions_max > DEFAULT_ACTIONS_MAX_ALLOWED) {
        SX_LOG_ERR("Number of regions [%u] is greater than the size of max default block [%u].\n",
                   rm_resource_global.acl_regions_max, DEFAULT_ACTIONS_MAX_ALLOWED);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    return_size = kvd_size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;

    /* Currently we support only one type of default action. This can change in the future. */
    if ((action_count != 1) || (action_list_p[0].type != SX_FLEX_ACL_ACTION_FORWARD)) {
        SX_LOG_ERR("Only trap action permit is supported as a default action.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    kvd_action_set.actions_count = 1;
    kvd_action_set.is_last = TRUE;
    kvd_action_set.is_first = TRUE;
    kvd_action_set.region_id = region_id;
    kvd_action_set.goto_action.binding_cmd = SXD_FLEX_BINDING_NONE_E;
    kvd_action_set.actions[0].slot.type = SXD_ACTION_TYPE_TRAP_E;
    kvd_action_set.actions[0].slot.fields.action_trap.forward_action =
        map_forward_action[SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT];
    kvd_action_set.actions[0].slot.fields.action_trap.defer = is_defer;

    rc = kvd_linear_manager_handle_lock(default_action_kvd_handle, kvd_index, &return_size);
    if ((SX_CHECK_FAIL(rc)) || (return_size < kvd_size)) {
        SX_LOG_ERR("ACL action : Failed locking kvd block for default action set.\n");
        goto out;
    }

    kvd_action_set.kvd_index = kvd_index[region_id];
    /* Now go and write the default action to the PEFA register */
    rc = __flex_acl_hw_edit_action_kvd(&kvd_action_set, TRUE, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action set.\n");
        goto release_kvd;
    }

release_kvd:
    r_rc = kvd_linear_manager_handle_release(default_action_kvd_handle);
    if (SX_CHECK_FAIL(r_rc)) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action set.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* Retrieve the default action sets from DB and set the first action set into the pre-allocated KVD block */
sx_status_t flex_acl_hw_write_first_default_action_set(flex_acl_db_flex_rule_t     *rule,
                                                       sx_acl_region_id_t           region_id,
                                                       flex_acl_hw_db_action_set_t *hw_action_set_p,
                                                       kvd_linear_manager_index_t  *next_action_kvd_idx_p,
                                                       boolean_t                    is_full_write,
                                                       boolean_t                    activity_clear,
                                                       boolean_t                    is_commit,
                                                       boolean_t                    add_ref)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       r_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_kvd_action_set_t  *kvd_default_action_set_p = NULL;
    kvd_linear_manager_block_length_t kvd_size = 0;
    kvd_linear_manager_block_length_t return_size = 0;
    kvd_linear_manager_index_t        kvd_index[DEFAULT_ACTIONS_MAX_BLOCK_SIZE];
    const cl_list_t                  *kvd_action_set_list_p = NULL;
    struct ku_pefa_reg                pefa_reg_data;
    flex_acl_relocation_data_t        relocation_data = {.is_head = FALSE};

    SX_LOG_ENTER();

    SX_CHECK_NULL_OUT(hw_action_set_p, rc, "hw_action_set");
    /* Get region id starting with zero*/
    FLEX_CLR_ACL_REGION_BIT(region_id);

    /* Check that the handle does not already exist */
    if (default_action_kvd_handle == FLEX_ACL_INVALID_KVD_HANDLE) {
        SX_LOG_ERR("Default action KVD handle in not initialized.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(hw_action_set_p,
                                                &kvd_action_set_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }

    kvd_default_action_set_p = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(cl_list_head(kvd_action_set_list_p));

    if (next_action_kvd_idx_p != NULL) {
        kvd_default_action_set_p->is_last = FALSE;
        kvd_default_action_set_p->kvd_next_index = *next_action_kvd_idx_p;
    } else {
        kvd_default_action_set_p->is_last = TRUE;
        kvd_default_action_set_p->kvd_next_index = 0;

        /* Overwrite the default action type TRAP_W_USER_DEF of a NOP operation - to a smaller PEFA size the with same NOP behaviour.
         * In TRAP_W_USER_DEF we identify the default NOP action by comparing all fields to be disabled and do nothing.*/
        if ((kvd_default_action_set_p->actions_count == 1) &&
            (kvd_default_action_set_p->actions[0].slot.type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) &&
            (kvd_default_action_set_p->actions[0].slot.fields.action_trap.forward_action ==
             map_forward_action[SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT]) &&
            (kvd_default_action_set_p->actions[0].slot.fields.action_trap.mirror_enable == FALSE) &&
            (kvd_default_action_set_p->actions[0].slot.fields.action_trap.trap_action ==
             SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E)) {
            kvd_default_action_set_p->actions[0].slot.type = SXD_ACTION_TYPE_TRAP_E;
            kvd_default_action_set_p->actions[0].slot.fields.action_trap.forward_action =
                map_forward_action[SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT];
        }
    }

    kvd_default_action_set_p->is_first = TRUE;
    kvd_default_action_set_p->region_id = region_id;

    return_size = kvd_size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;
    rc = kvd_linear_manager_handle_lock(default_action_kvd_handle, kvd_index, &return_size);
    if ((SX_CHECK_FAIL(rc)) || (return_size < kvd_size)) {
        SX_LOG_ERR("ACL action : Failed locking kvd block for default action set.\n");
        goto out;
    }
    kvd_default_action_set_p->kvd_index = kvd_index[region_id];

    SX_MEM_CLR(pefa_reg_data);
    relocation_data.kvd_index_p = &(hw_action_set_p->action_set.kvd_index);
    pefa_reg_data.index = kvd_default_action_set_p->kvd_index;
    /* Prepare action set for writing to HW, including obtaining third party's HW indexes. */
    rc = flex_acl_hw_create_reg_action_set(kvd_default_action_set_p->actions,
                                           kvd_default_action_set_p->actions_count,
                                           hw_action_set_p->action_set.goto_action,
                                           kvd_default_action_set_p->is_last,
                                           kvd_default_action_set_p->kvd_index,
                                           is_commit,
                                           relocation_data,
                                           &(pefa_reg_data.action_set), add_ref, rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed creating default hw action set.\n");
        goto out;
    }

    /* Add to the PEFA register the relevant fields related to activity */
    rc = flex_acl_hw_set_action_activity(is_full_write,
                                         TRUE,
                                         activity_clear,
                                         kvd_default_action_set_p,
                                         &pefa_reg_data);

    /* Now go and write the default action set to the PEFA register */
    rc = __flex_acl_hw_edit_action_kvd(kvd_default_action_set_p, TRUE, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action set.\n");
        goto release_kvd;
    }

    /* Release locks taken for HW writing preparations */
    rc = flex_acl_hw_release_action_locks(kvd_default_action_set_p->actions, kvd_default_action_set_p->actions_count);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to release locks of default action set. Region [0x%x]\n", region_id);
        goto release_kvd;
    }

release_kvd:
    r_rc = kvd_linear_manager_handle_release(default_action_kvd_handle);
    if (SX_CHECK_FAIL(r_rc)) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action set.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* generic function to add/del/modify the acl attributes in the ACL Drop Trap
 * Attributes HW db. It will also return the free or already assigned index to
 * set into the user-def-value of the trap block
 */
static sx_status_t __acl_drop_trap_usr_def_val_modify(flex_acl_rule_id_t   rule_id,
                                                      acl_drop_db_mod_op_e db_op,
                                                      uint32_t            *ret_usr_def_val_p)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_acl_pkt_drop_attributes_t acl_drop_trap_attrib;
    flex_acl_db_acl_region_t    *acl_region_p = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(rule_id.region_id,  &acl_region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Error getting Region Attributes for ACL region %u RC = %s\n", rule_id.region_id,
                   sx_status_str(rc));
        goto out;
    }
    SX_MEM_CLR(acl_drop_trap_attrib);

    acl_drop_trap_attrib.acl_id = acl_region_p->bound_acl;
    acl_drop_trap_attrib.acl_region_id = rule_id.region_id; /* e.g. 0x20001 */
    /* For SPC1 register the default rule offset as default actions offset.
     * Using the default actions offset is necessary to allow a unified code for all SPC platforms to reference the default action. */
    if ((!ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) && (rule_id.offset == (acl_region_p->size - 1))) {
        acl_drop_trap_attrib.acl_rule_offset = SX_ACL_DEFAULT_ACTION_OFFSET;
    } else {
        acl_drop_trap_attrib.acl_rule_offset = rule_id.offset;
    }
    acl_drop_trap_attrib.acl_direction = acl_region_p->direction;

    switch (db_op) {
    case ACL_DROP_DB_ADD_E:
        /* Add a new entry to the HW DB */
        if (SX_CHECK_FAIL(rc = utils_check_pointer(ret_usr_def_val_p, "ret_usr_def_val_p"))) {
            goto out;
        }
        acl_drop_trap_attrib.valid = TRUE;
        rc = flex_acl_hw_db_acl_drop_trap_data_db_add(&acl_drop_trap_attrib);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL drop trap DB add failed. ACL Id: %u, Region: %u Offset: %u\n",
                       acl_drop_trap_attrib.acl_id, acl_drop_trap_attrib.acl_region_id,
                       acl_drop_trap_attrib.acl_rule_offset);
            goto out;
        }

        *ret_usr_def_val_p = acl_drop_trap_attrib.trap_usr_def_val;
        SX_LOG_DBG("Added to DB. return value = %u.\n",
                   acl_drop_trap_attrib.trap_usr_def_val);

        break;

    case ACL_DROP_DB_DEL_E:
        /* Delete an existing entry */

        acl_drop_trap_attrib.valid = FALSE;
        rc = flex_acl_hw_db_acl_drop_trap_data_db_del(acl_drop_trap_attrib);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL drop trap DB delete failed. ACL ID:%u, region:%u offset:%u RC = %s\n",
                       acl_drop_trap_attrib.acl_id, acl_drop_trap_attrib.acl_region_id,
                       acl_drop_trap_attrib.acl_rule_offset, sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;
        break;

    case ACL_DROP_DB_TRAP_ENABLE_E:
        /* Monitoring state is now enabled for an existing rule. So simply update
         * the valid state to TRUE in the DB */
        SX_LOG_DBG("Enable OP. usr def val = %u \n", acl_drop_trap_attrib.trap_usr_def_val);
        acl_drop_trap_attrib.valid = TRUE;

        rc = flex_acl_hw_db_acl_drop_trap_data_db_add(&acl_drop_trap_attrib);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL drop trap DB modify failed. ACL ID: %u, region: %u offset: %u\n",
                       acl_drop_trap_attrib.acl_id, acl_drop_trap_attrib.acl_region_id,
                       acl_drop_trap_attrib.acl_rule_offset);
            goto out;
        }

        break;

    case ACL_DROP_DB_TRAP_DISABLE_E:
        /* Monitoring state is now Disabled for an existing rule. So simply update
         * the valid state to FALSE in the DB */
        SX_LOG_DBG("Disable OP. usr def val = %u \n", acl_drop_trap_attrib.trap_usr_def_val);
        acl_drop_trap_attrib.valid = FALSE;

        rc = flex_acl_hw_db_acl_drop_trap_data_db_add(&acl_drop_trap_attrib);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Drop Trap Db Modify Failed. ACl Id: %u, Region: %u Offset: %u\n",
                       acl_drop_trap_attrib.acl_id, acl_drop_trap_attrib.acl_region_id,
                       acl_drop_trap_attrib.acl_rule_offset);
            goto out;
        }

        break;

    case ACL_DROP_DB_GET_E:
        rc = flex_acl_hw_db_acl_drop_trap_data_db_get(&acl_drop_trap_attrib);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("ACL Drop Trap Db Get Failed. ACl Id:%u, Region:%u Offset:%u\n",
                       acl_drop_trap_attrib.acl_id, acl_drop_trap_attrib.acl_region_id,
                       acl_drop_trap_attrib.acl_rule_offset);
            goto out;
        }
        *ret_usr_def_val_p = acl_drop_trap_attrib.trap_usr_def_val;
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Invalid DB Operation :%u\n", db_op);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* This function sets the valid state to TRUE/FALSE in the ACL Drop FMAP. */
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_modify(flex_acl_rule_id_t rule_id, boolean_t monitor_en)
{
    if (monitor_en) {
        return __acl_drop_trap_usr_def_val_modify(rule_id, ACL_DROP_DB_TRAP_ENABLE_E, NULL);
    } else {
        return __acl_drop_trap_usr_def_val_modify(rule_id, ACL_DROP_DB_TRAP_DISABLE_E, NULL);
    }
}

sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_del(flex_acl_rule_id_t rule_id)
{
    return __acl_drop_trap_usr_def_val_modify(rule_id, ACL_DROP_DB_DEL_E, NULL);
}
/* Allocate a new value. If the rule already is in db, simply return the existing value */
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_add(flex_acl_rule_id_t rule_id, uint32_t *ret_usr_def_val_p)
{
    return __acl_drop_trap_usr_def_val_modify(rule_id, ACL_DROP_DB_ADD_E, ret_usr_def_val_p);
}
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_get(flex_acl_rule_id_t rule_id, uint32_t *ret_usr_def_val_p)
{
    return __acl_drop_trap_usr_def_val_modify(rule_id, ACL_DROP_DB_GET_E, ret_usr_def_val_p);
}

static boolean_t __is_acl_drop_monitor_enabled(flex_acl_rule_id_t rule_id, flex_acl_entry_type_e  *entry_type)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 monitor_en = FALSE;
    flex_acl_db_acl_table_t  *acl_table_p = NULL;
    flex_acl_db_acl_region_t *acl_region_p = NULL;

    SX_LOG_ENTER();
    rc = flex_acl_db_region_entry_type_get(rule_id.region_id, entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Failed to get Region Type for Region %u\n", rule_id.region_id);
        goto out;
    }
    flex_acl_db_region_get(rule_id.region_id,  &acl_region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Error getting Region Attributes for ACL region %u RC = %s\n", rule_id.region_id,
                   sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_acl_drop_trap_monitor_state_get(acl_region_p->bound_acl, &monitor_en);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Error getting monitor state for ACL ID %u RC = %s\n", acl_table_p->acl_id, sx_status_str(rc));
        goto out;
    }

    SX_LOG_DBG("monitoring is %s for this Rule ID[%x]/Region[%x]/Offset[%u], Type = %s\n",
               monitor_en ? "TRUE" : "FALSE", acl_region_p->bound_acl, rule_id.region_id, rule_id.offset,
               ((*entry_type ==
                 FLEX_ACL_ENTRY_TYPE_USER_E) ? "USER" : ((*entry_type ==
                                                          FLEX_ACL_ENTRY_TYPE_SYSTEM_E) ? "SYSTEM" : "AGGR")));

out:
    SX_LOG_EXIT();
    return monitor_en;
}

sx_status_t flex_acl_hw_acl_drop_action_relocate(sx_acl_id_t acl_id, boolean_t old_state, boolean_t new_state)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region_p = NULL;
    cl_list_t                *drop_action_list = NULL;
    acl_drop_relocate_data_t  acl_drop_relocate_data;
    uint64_t                  acl_drop_handle = 0;
    flex_acl_rule_id_t        rule_id;
    uint32_t                  i = 0;
    flex_acl_db_acl_table_t  *acl_table_p = NULL;

    SX_LOG_ENTER();
    if (old_state == new_state) {
        SX_LOG_DBG("No state change. both values = %s\n", old_state ? "TRUE" : "FALSE");
        goto out;
    }

    SX_MEM_CLR(acl_drop_relocate_data);
    rc = flex_acl_db_acl_get(acl_id, &acl_table_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get ACL Table failed, acl_id: %u\n", acl_id);
        goto out;
    }
    rc = flex_acl_db_region_get(acl_table_p->bound_region, &region_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get ACL region failed, region_id: %u\n", acl_id);
        goto out;
    }
    if (region_p->entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL Type is %u. Relocation only applies to FLEX_ACL_ENTRY_TYPE_USER_E\n", region_p->entry_type);
        goto out;
    }
    /* Go over all the rules whose actions need to be modified(minus wild card rule
     * and call the relocate function. A region of size X can have N rules where
     * N <= X - reserved_rules_num. N rules can be spread at different offsets within the
     * region. When rules are deleted, no movement within region db is done.
     * Therefore we need iterate over entire region as there can be holes.
     * */
    for (i = 0; i < region_p->size - region_p->reserved_rules_num; i++) {
        if (!(region_p->rules[i].valid)) {
            continue;
        }
        acl_drop_handle = FLEX_ACL_DROP_TRAP_HANDLE(region_p->region_id, region_p->rules[i].offset);
        rc = flex_acl_hw_db_acl_drop_relocate_db_ref_list_get(acl_drop_handle,
                                                              &drop_action_list);
        if (SX_STATUS_SUCCESS != rc) {
            if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
                SX_LOG_DBG("ACL Drop relocate db list not found for region =%x, offset = %u\n",
                           region_p->region_id, region_p->rules[i].offset);
                rc = SX_STATUS_SUCCESS;
                continue;
            } else {
                SX_LOG_ERR("ACL Drop relocate db list get failed for region =%x, offset = %u\n",
                           region_p->region_id, region_p->rules[i].offset);
                goto out;
            }
        }

        rule_id.region_id = region_p->region_id;
        rule_id.offset = region_p->rules[i].offset;
        acl_drop_relocate_data.new_monitoring_state = !new_state;

        rc = flex_acl_block_relocate(drop_action_list,
                                     __acl_drop_trap_action_relocate_handler,
                                     &acl_drop_relocate_data);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Drop relocator failed for region %x , Offset=%u. new state =%s\n",
                       rule_id.region_id, rule_id.offset,
                       acl_drop_relocate_data.new_monitoring_state ? "ENABLED" : "DISABLED");
            goto out;
        }

        rc = flex_acl_hw_acl_drop_trap_usr_def_val_modify(rule_id, !new_state);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Drop Trap HW DB MOdify failed:%s \n", sx_status_str(rc));
            goto out;
        }
    } /* for loop */

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_drop_trap_action_relocate_handler(void                    *data,
                                                           flex_acl_hw_action_t    *action,
                                                           flex_acl_db_flex_rule_t *related_rule,
                                                           boolean_t               *found,
                                                           boolean_t               *handled)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    acl_drop_relocate_data_t *acl_drop_relocate_data = (acl_drop_relocate_data_t*)data;
    uint32_t                  acl_drop_trap_usr_def_val = 0;
    flex_acl_rule_id_t        rule_id;
    struct sxd_action_slot   *action_slot = NULL;

    UNUSED_PARAM(related_rule);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(found, "found"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handled, "handled"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(action, "action"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(related_rule, "related_rule"))) {
        goto out;
    }

    *found = FALSE;
    *handled = FALSE;

    action_slot = &action->slot;

    SX_LOG_ENTER();

    rule_id.region_id = related_rule->region_id;
    rule_id.offset = related_rule->offset;
    rc = flex_acl_hw_acl_drop_trap_usr_def_val_get(rule_id, &acl_drop_trap_usr_def_val);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Drop Trap HW DB Get failed:%s \n", sx_status_str(rc));
        goto out;
    }

    if (acl_drop_relocate_data->new_monitoring_state == FALSE) {
        /* monitoring has been disabled */
        acl_drop_relocate_data->old_trap_id = SX_TRAP_ID_ACL_DROP;
        acl_drop_relocate_data->new_trap_id = 0;
        acl_drop_relocate_data->old_trap_action = SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E;
        acl_drop_relocate_data->new_trap_action = SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E;
        acl_drop_relocate_data->old_trap_usr_def_val = acl_drop_trap_usr_def_val;
        acl_drop_relocate_data->new_trap_usr_def_val = SX_ACL_USER_ID_MAX;
    } else {
        /* monitoring is now enabled */
        acl_drop_relocate_data->old_trap_usr_def_val = SX_ACL_USER_ID_MAX;
        acl_drop_relocate_data->new_trap_usr_def_val = acl_drop_trap_usr_def_val;
        acl_drop_relocate_data->old_trap_action = SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E;
        acl_drop_relocate_data->new_trap_action = SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E;
        acl_drop_relocate_data->old_trap_id = 0;
        acl_drop_relocate_data->new_trap_id = SX_TRAP_ID_ACL_DROP;
    }

    if (action_slot->type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
        if ((action_slot->fields.action_trap.trap_action == acl_drop_relocate_data->old_trap_action) &&
            (action_slot->fields.action_trap.trap_id == acl_drop_relocate_data->old_trap_id) &&
            (action_slot->fields.action_trap.user_def_val == acl_drop_relocate_data->old_trap_usr_def_val)) {
            action_slot->fields.action_trap.trap_action = acl_drop_relocate_data->new_trap_action;
            action_slot->fields.action_trap.trap_id = acl_drop_relocate_data->new_trap_id;
            action_slot->fields.action_trap.user_def_val = acl_drop_relocate_data->new_trap_usr_def_val;
            *found = TRUE;
        } else if ((action_slot->fields.action_trap.trap_action == acl_drop_relocate_data->new_trap_action) &&
                   (action_slot->fields.action_trap.trap_id == acl_drop_relocate_data->new_trap_id) &&
                   (action_slot->fields.action_trap.user_def_val == acl_drop_relocate_data->new_trap_usr_def_val)) {
            *found = TRUE;
            *handled = TRUE;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __add_acl_drop_trap_action(flex_acl_hw_action_t      *hw_action,
                                              flex_acl_db_flex_rule_t   *rule,
                                              flex_acl_relocation_data_t relocation_data,
                                              boolean_t                  add_ref)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_status_t               rb_rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t        rule_id;
    uint32_t                  acl_drop_trap_usr_def_val = 0;
    flex_acl_entry_type_e     entry_type;
    boolean_t                 rollback_on_flr = FALSE;
    boolean_t                 acl_drop_trap_enabled = FALSE;
    flex_acl_db_acl_region_t *region_p = NULL;

    SX_LOG_ENTER();

    memset(&(hw_action->slot.fields.action_trap), 0, sizeof(hw_action->slot.fields.action_trap));

    hw_action->slot.type = SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E;
    if (flex_acl_is_using_soft_drop_for_empty_container()) {
        hw_action->slot.fields.action_trap.forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E;
    } else {
        hw_action->slot.fields.action_trap.forward_action = SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E;
    }
    hw_action->slot.fields.action_trap.defer = hw_action->is_defer;

    rc = flex_acl_db_region_get(rule->region_id, &region_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get region id [%u]\n", rule->region_id);
        goto out;
    }
    /* For SPC1 register the default rule offset as default actions offset.
     * Using the default actions offset is necessary to allow a unified code for all SPC platforms to reference the default action. */
    if ((!ACL_STAGE_IS_FLEX2_OR_ABOVE(flex_acl_stage)) && (rule->offset == (region_p->size - 1))) {
        rule_id.offset = SX_ACL_DEFAULT_ACTION_OFFSET;
    } else {
        rule_id.offset = rule->offset;
    }
    rule_id.region_id = rule->region_id;
    /* first add to drop trap monitoring db. Will update state next */
    rc = flex_acl_hw_acl_drop_trap_usr_def_val_add(rule_id, &acl_drop_trap_usr_def_val);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting user def map val for Rule[region=%u, offset =%u]  RC = %s\n",
                   rule_id.region_id, rule_id.offset, sx_status_str(rc));
        goto out;
    }
    rollback_on_flr = TRUE;
    acl_drop_trap_enabled = __is_acl_drop_monitor_enabled(rule_id, &entry_type);
    if (acl_drop_trap_enabled) {
        hw_action->slot.fields.action_trap.user_def_val = acl_drop_trap_usr_def_val;
        hw_action->slot.fields.action_trap.trap_action = SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E;

        if (entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) {
            hw_action->slot.fields.action_trap.trap_id = SX_TRAP_ID_ACL_DROP;
        } else {
            hw_action->slot.fields.action_trap.trap_id = SX_TRAP_ID_SYS_ACL_DROP;
        }
    } else {
        /* Rule is added when acl drop trap monitoring is  disabled.
         * We need to modify monitoring state to false.
         */
        hw_action->slot.fields.action_trap.user_def_val = SX_ACL_USER_ID_MAX;
        rc = flex_acl_hw_acl_drop_trap_usr_def_val_modify(rule_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error disabling monitor state for Rule[region=%u, offset =%u]  RC = %s\n",
                       rule_id.region_id, rule_id.offset, sx_status_str(rc));
            goto rollback;
        }
    }

    if ((!hw_action->acl_drop_trap_handle) && (add_ref)) {
        if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) ||
            ((entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) && (acl_drop_trap_enabled))) {
            /* add to trap action relocate db so that if monitoring state is changed later,
             *  we will update the trap action accordingly as well then.
             *  For SYS ACL this only applies if Monitoring is enabled because it is set on SDK Init
             *  For User ACLs, monitoring can be changed at run time. so we need to always add.
             */
            hw_action->acl_drop_trap_handle = FLEX_ACL_DROP_TRAP_HANDLE(rule_id.region_id, rule_id.offset);
            SX_LOG_DBG("%s Add to Reloc db handle 0x%" PRIx64 " Entry Type = %s\n",
                       __func__,
                       hw_action->acl_drop_trap_handle,
                       entry_type == FLEX_ACL_ENTRY_TYPE_USER_E ? "USER" : "SYS");
            rc = flex_acl_hw_db_acl_drop_relocate_db_add_entry(hw_action->acl_drop_trap_handle,
                                                               relocation_data.is_head,
                                                               relocation_data.kvd_index_p);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("failed to add to ACL drop Relocate DB.Region %x Offset %u \n",
                           rule->region_id, rule->offset);
                goto rollback;
            }
        }
    }
    if (add_ref) {
        hw_action->is_ref_count_inc = TRUE;
    }
    SX_LOG_DBG("Added ACL Drop Action for region=%u, off=%u\n",
               rule_id.region_id, rule_id.offset);
    goto out;

rollback:
    if (rollback_on_flr) {
        hw_action->acl_drop_trap_handle = 0;
        rb_rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(rule_id);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR("delete db entry on roll back failed for Region %d Offset %u \n",
                       rule->region_id, rule->offset);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_rule_upd_is_acl_drop_trap_overwritten(flex_acl_db_flex_rule_t *old_rule_p,
                                                              flex_acl_db_flex_rule_t *new_rule_p,
                                                              boolean_t               *acl_drop_overwritten)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   old_rule_found, new_rule_found = FALSE;

    SX_LOG_ENTER();

    rc = __find_acl_drop_trap_action_in_rule(old_rule_p, &old_rule_found, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in old rule  "
                       "RC=%s\n", sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;
    }
    rc = __find_acl_drop_trap_action_in_rule(new_rule_p, &new_rule_found, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in new rule  "
                       "RC=%s\n", sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;
    }
    /*If Rule with ACL DROP TRAP is overwritten by another rule
     * that also has ACL DROP TRAP, then the trap action is not overwritten.
     * only if the new rule does not have acl drop trap must we return TRUE.
     */
    if (old_rule_found && !new_rule_found) {
        *acl_drop_overwritten = TRUE;
    } else {
        *acl_drop_overwritten = FALSE;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __find_acl_drop_trap_action_in_rule(flex_acl_db_flex_rule_t *rule_p,
                                                       boolean_t               *ret_found_p,
                                                       flex_acl_hw_action_t   **ret_hw_action_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action_p = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_matching_hw_action_from_rule(rule_p, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                         ret_found_p, &hw_action_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in list  "
                   "action in rule. RC=%s\n", sx_status_str(rc));
        goto out;
    }
    /* Found a TRAP-W-USER-DEF-VAL hw action. Check if it could be acl drop */
    if (*ret_found_p) {
        *ret_found_p = FALSE;

        rc = __hw_action_is_fwd_and_acl_drop(hw_action_p, ret_found_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error trying to find FWD + Drop "
                       "action in rule. RC=%s\n", sx_status_str(rc));
            goto out;
        }
        if (*ret_found_p == FALSE) {
            /* user did not configure FWD + Drop action. Lets check if other ACL
             * drop Trap exists in the actions.
             */
            rc = __hw_action_is_other_acl_drop_trap(hw_action_p, ret_found_p);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error trying to find ACL Drop Trap "
                           "action in rule. RC=%s\n", sx_status_str(rc));
                goto out;
            }
        }
        if (*ret_found_p && ret_hw_action_p) {
            *ret_hw_action_p = hw_action_p;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}
static sx_status_t __del_acl_drop_action_trap_action_from_db(flex_acl_db_flex_rule_t *rule_p,
                                                             flex_acl_hw_action_t    *hw_action_p)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t           rule_id;
    uint64_t                     acl_drop_trap_handle = 0;
    kvd_linear_manager_index_t  *kvd_index_p = NULL;
    flex_acl_hw_db_action_set_t *action_set_p = NULL;
    flex_acl_entry_type_e        entry_type;
    boolean_t                    acl_drop_trap_enabled = FALSE;

    SX_LOG_ENTER();

    rule_id.region_id = rule_p->region_id;
    rule_id.offset = rule_p->offset;
    acl_drop_trap_handle = FLEX_ACL_DROP_TRAP_HANDLE(rule_id.region_id, rule_id.offset);
    acl_drop_trap_enabled = __is_acl_drop_monitor_enabled(rule_id, &entry_type);

    /* delete entry from acl drop trap data db */
    rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(rule_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Deleting action from ACL drop DB failed [%s]\n", sx_status_str(rc));
        goto out;
    }

    action_set_p = (flex_acl_hw_db_action_set_t*)rule_p->hw_action_handle;
    kvd_index_p = &(action_set_p->action_set.kvd_index);

    /* delete entry from acl drop relocate db */
    if (hw_action_p->acl_drop_trap_handle) {
        if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) ||
            ((entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) && (acl_drop_trap_enabled))) {
            SX_LOG_DBG("%s Del from Reloc db handle 0x%" PRIx64 " Entry Type = %s\n", __func__,
                       acl_drop_trap_handle, entry_type == FLEX_ACL_ENTRY_TYPE_USER_E ? "USER" : "SYS");

            rc = flex_acl_hw_db_acl_drop_relocate_db_del_entry(acl_drop_trap_handle, kvd_index_p);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("deleting action from acl drop relocate db for handle 0x%" PRIx64 " failed.RC= [%s]\n",
                           acl_drop_trap_handle, sx_status_str(rc));
                goto out;
            }
            hw_action_p->acl_drop_trap_handle = 0;
        }
    }
    /* clear the acl drop trap info from the action_trap params*/
    if ((hw_action_p->slot.fields.action_trap.trap_id == SX_TRAP_ID_ACL_DROP) ||
        (hw_action_p->slot.fields.action_trap.trap_id == SX_TRAP_ID_SYS_ACL_DROP) ||
        (hw_action_p->slot.fields.action_trap.user_def_val == SX_ACL_USER_ID_MAX)) {
        hw_action_p->slot.fields.action_trap.trap_action = SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E;
        hw_action_p->slot.fields.action_trap.trap_id = 0;
        hw_action_p->slot.fields.action_trap.user_def_val = 0;
    }
out:
    SX_LOG_EXIT();
    return rc;
}
static sx_status_t __empty_cont_del_acl_drop_trap_action_from_db(flex_acl_db_flex_rule_t *rule_p,
                                                                 sxd_action_slot_t       *action_slot_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    boolean_t             found = FALSE;
    boolean_t             del_acl_drop_from_db = FALSE;
    flex_acl_hw_action_t *hw_action_p = NULL;

    SX_LOG_ENTER();

    if (action_slot_p->type == SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E) {
        /*  find the hw_action pointer and mark for deletion*/
        rc = flex_acl_hw_db_get_matching_hw_action_from_rule(rule_p, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                             &found, &hw_action_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in list  "
                       "action in rule. RC=%s\n", sx_status_str(rc));
            goto out;
        }
        if (found) {
            del_acl_drop_from_db = TRUE;
        }
    } else if (action_slot_p->type == SXD_ACTION_TYPE_NULL_E) {
        /* action is NULL. we will have to iterate and check if there is an
         * acl drop trap in the list of actions.
         */
        rc = flex_acl_hw_db_get_action_from_rule(rule_p, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                 &found, &hw_action_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error trying to find SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E "
                       "action in rule. RC=%s\n", sx_status_str(rc));
            goto out;
        }

        if (!found) {
            rc = flex_acl_hw_db_get_action_from_rule(rule_p, SXD_ACTION_TYPE_TRAP_E,
                                                     &found, &hw_action_p);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error trying to find SXD_ACTION_TYPE_TRAP_E "
                           "action in rule. RC=%s\n", sx_status_str(rc));
                goto out;
            }
        }

        if (!found) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("When slot.type is NULL, Trap action must have been added"
                       "to rule. RC=%s\n", sx_status_str(rc));
            goto out;
        }
        found = FALSE;

        /* We must only delete ACL drop for empty container case */

        rc = __hw_action_is_fwd_and_acl_drop(hw_action_p, &found);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error trying to find FWD + Drop "
                       "action in rule. RC=%s\n", sx_status_str(rc));
            goto out;
        }

        if (!found) {
            /* user did not configure FWD + Drop action. Lets check if other ACL
             * drop Trap exists in the actions.
             */
            rc = __hw_action_is_other_acl_drop_trap(hw_action_p, &del_acl_drop_from_db);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error trying to find ACL Drop Trap "
                           "action in rule. RC=%s\n", sx_status_str(rc));
                goto out;
            }
        }
    }

    if (del_acl_drop_from_db) {
        rc = __del_acl_drop_action_trap_action_from_db(rule_p, hw_action_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error trying to del ACL Drop Trap db entries"
                       "RC=%s\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* This function gets the total number of ACLs configured in the system
 * Then iterates over all of them and calls the ACL relocate with the old/new state
 * of the global flag, provided the respective ACL's flag is enabled.
 */
sx_status_t flex_acl_hw_acl_drop_trap_action_iter_relocate(boolean_t old_state, boolean_t new_state)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t          iter_get_cmd = SX_ACCESS_CMD_NONE;
    uint32_t                 i, num_acls = 0;
    sx_acl_id_t             *acl_list_p = NULL;
    sx_acl_id_t              acl_id_key = 0;
    boolean_t                acl_id_acl_drop_trap_en = FALSE;
    flex_acl_db_acl_table_t *acl_table = NULL;

    SX_LOG_ENTER();

    /* we need to iterate over all ACLs in the system and change the trap state
     * So first get a count of all ACLs */
    iter_get_cmd = SX_ACCESS_CMD_GET;
    rc = flex_acl_db_iter_get(iter_get_cmd, acl_id_key, NULL, acl_list_p, &num_acls);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get ACL Count failed. RC = %s\n", sx_status_str(rc));
        goto out;
    }
    SX_LOG_DBG("Iterate over %u ACLs and relocate ACL Drop Trap action if needed\n", num_acls);
    acl_list_p = (sx_acl_id_t*)cl_malloc(sizeof(sx_acl_id_t) * num_acls);
    if (acl_list_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    /* now get a list of all the ACLs */
    iter_get_cmd = SX_ACCESS_CMD_GET_FIRST;
    rc = flex_acl_db_iter_get(iter_get_cmd, acl_id_key, NULL, acl_list_p, &num_acls);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Get ACL Count failed. RC = %s\n", sx_status_str(rc));
        goto out;
    }

    /* Go over all the rules whose actions need to be modified(minus wild card rule
     * and call the relocate function. */
    for (i = 0; i < num_acls; i++) {
        rc = flex_acl_db_acl_get(acl_list_p[i], &acl_table);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG(SX_LOG_ERROR, "Failed to Get ACL Table for acl_id: %u\n", acl_list_p[i]);
            goto out;
        }

        /* Get the acl drop trap state of each acl table*/
        acl_id_acl_drop_trap_en = !acl_table->acl_attributes.disable_acl_drop_monitoring_trap;

        /* Decision table:
         * ------------------------------------------------------
         * |        Global Flag     | Per ACL Flag  |           |
         * ------------------------------------------           |
         * |  Prev st   | New St    |   cur st      |   Action  |
         * ------------------------------------------------------
         * |  ENABLED   | DISABLED  |  DISABLED     |   Skip    |
         * ------------------------------------------------------
         * |  ENABLED   | DISABLED  |  ENABLED      | Relocate  |
         * ------------------------------------------------------
         * |  DISABLED  | ENABLED   |  ENABLED      | Relocate  |
         * ------------------------------------------------------
         * |  DISABLED  | ENABLED   |  DISABLED     |   Skip    |
         * ------------------------------------------------------
         */
        if (acl_id_acl_drop_trap_en) {
            SX_LOG_DBG("Relocate ACL[idx=%u] = %u.\n", i, acl_list_p[i]);
            rc = flex_acl_hw_acl_drop_action_relocate(acl_list_p[i], old_state, new_state);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" Updating ACL Drop Trap State failed for ACL[idx=%u] = %u. RC=%s\n",
                           i, acl_list_p[i], sx_status_str(rc));
                goto out;
            }
        } else {
            SX_LOG_DBG("Skip relocate of ACL[idx=%u] = %u.\n", i, acl_list_p[i]);
        }
    }
out:
    if (acl_list_p != NULL) {
        cl_free(acl_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

/* WJH ACL Drop stores the Rule Offset as a key so that user can know which rule
 * dropped a packet when received in the WJH receive List.
 * Therefore, when a rule move operation is done, we must update all the WJH ACL DROP Trap
 * DBs with the right offset since the user-def-val doesn't change.
 * We need to iterate over existing db entries for a given region and determine the
 * new correct offset for an entry. Note: this function assumes that the overwritten
 * rules entries have already been deleted from the db
 * Using the rule move parameters (block start, size, new block start etc), we can compute the following
 * 1.  Whether this rule has been moved or not
 * 2.  If moved, then what the new offset must be
 * 3.  Since the new offset can result in matching an existing fmap entry,
 *     we need to be careful in the order of iteration
 *       a.  If the rule is moving to greater offset, then we need to count down in the trap db,
 *       b.  If the rule is moving to smaller offset, then we need to count up in the trap db.
 *
 */

sx_status_t flex_acl_hw_rules_move_upd_acl_drop_trap_db(sx_api_acl_block_move_params_t *params)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    cl_list_t                   *acl_drop_reloc_db_list = NULL;
    acl_drop_trap_reloc_db_upd_t acl_drop_reloc_db_data;
    flex_acl_rule_id_t           rule_id;
    flex_acl_db_acl_region_t    *region_p = NULL;
    sx_acl_pkt_drop_attributes_t acl_drop_data_old;
    sx_acl_pkt_drop_attributes_t acl_drop_data_new;
    uint64_t                     acl_drop_trap_hdl = 0;
    int32_t                      i, start, end, incr, block_diff = 0;
    int32_t                      old_block_end, new_block_end = 0;
    sx_flex_acl_rule_offset_t    old_offset, new_offset = 0;
    boolean_t                    acl_drop_trap_enabled = FALSE;
    flex_acl_entry_type_e        entry_type;

    SX_LOG_ENTER();

    SX_MEM_CLR(acl_drop_reloc_db_data);
    SX_MEM_CLR(acl_drop_data_old);
    SX_MEM_CLR(acl_drop_data_new);

    rc = flex_acl_db_region_get(params->region_id, &region_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get region id [%u]\n", params->region_id);
        goto out;
    }

    /* compute the respective block limits      */
    old_block_end = params->block_start + params->block_size; /* offset +1 */
    new_block_end = params->new_block_start + params->block_size; /* offset +1 */
    UNUSED_PARAM(new_block_end);
    if (params->new_block_start < params->block_start) {
        /*count_up*/
        start = params->block_start;
        end = old_block_end;
        incr = 1;
    } else {
        /* count down */
        start = old_block_end - 1;
        end = params->block_start - 1;
        incr = -1;
    }

    rule_id.region_id =
        acl_drop_data_old.acl_region_id =
            acl_drop_data_new.acl_region_id = params->region_id;
    acl_drop_data_old.acl_id =
        acl_drop_data_new.acl_id = region_p->bound_acl;
    acl_drop_data_new.acl_direction = region_p->direction;
    rule_id.offset = 0;
    acl_drop_trap_enabled = __is_acl_drop_monitor_enabled(rule_id, &entry_type);

    /* iterate over the block being moved. Note overwritten rules' entries must
     * already have been deleted.  */
    for (i = start; i != end; i = i + incr) {
        if (region_p->rules[i].valid == FALSE) {
            continue;
        }

        old_offset = (sx_flex_acl_rule_offset_t)i;

        rule_id.offset = old_offset;
        acl_drop_data_old.acl_rule_offset = old_offset;

        rc = flex_acl_hw_db_acl_drop_trap_data_db_get(&acl_drop_data_old);
        if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
            rc = SX_STATUS_SUCCESS;
            continue;
        }
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Failed to get entry from for region: %u offset: %u. RC=%s\n",
                       params->region_id, i, sx_status_str(rc));
            goto out;
        }
        /* calculate the new offset and update the acl drop trap db */
        block_diff = params->new_block_start - params->block_start;
        new_offset = old_offset + block_diff;
        acl_drop_data_new.acl_rule_offset = new_offset;

        /* update the acl drop trap Attribute db. Mainly the rule offset. can be expanded in future */
        SX_LOG_DBG("updating the db entry with old offset = %u with new offset %u\n",
                   old_offset, new_offset);
        rc = flex_acl_hw_db_acl_drop_trap_data_db_edit(&acl_drop_data_old, &acl_drop_data_new);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to edit db entry for old-offset: %u new-offset: %u. RC=%s\n",
                       old_offset, new_offset, sx_status_str(rc));
            goto out;
        }
        /* Next: update the relocate db and the acl drop handle in the hw_action */

        if ((entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) ||
            ((entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) && (acl_drop_trap_enabled))) {
            acl_drop_trap_hdl = FLEX_ACL_DROP_TRAP_HANDLE(rule_id.region_id,
                                                          old_offset);
            rc = flex_acl_hw_db_acl_drop_relocate_db_ref_list_get(acl_drop_trap_hdl,
                                                                  &acl_drop_reloc_db_list);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Drop relocate db get failed. User ACL region %x offset %x\n",
                           rule_id.region_id,
                           rule_id.offset);
                goto out;
            }

            acl_drop_reloc_db_data.region_id = rule_id.region_id;
            acl_drop_reloc_db_data.cur_offset = old_offset;
            acl_drop_reloc_db_data.new_offset = new_offset;

            rc = __acl_drop_relocate_db_update(acl_drop_reloc_db_list,
                                               &region_p->rules[old_offset],
                                               &acl_drop_reloc_db_data);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL Drop relocate db update failed\n");
                goto out;
            }
        } else {
            continue;
        }
    } /* for loop */

out:

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_drop_relocate_db_update(cl_list_t                    *list,
                                                 flex_acl_db_flex_rule_t      *related_rule,
                                                 acl_drop_trap_reloc_db_upd_t *acl_drop_db_relocate_data)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t         *hw_action_p = NULL;
    flex_acl_hw_db_kvd_index_ref *kvd_index_ref = NULL;
    cl_list_iterator_t            iter = NULL;
    cl_list_iterator_t            list_end = NULL;
    cl_list_iterator_t            list_head = NULL;
    uint64_t                      old_acl_drop_trap_hdl = 0;
    uint64_t                      new_acl_drop_trap_hdl = 0;
    boolean_t                     found = FALSE;

    SX_LOG_ENTER();
    old_acl_drop_trap_hdl = FLEX_ACL_DROP_TRAP_HANDLE(acl_drop_db_relocate_data->region_id,
                                                      acl_drop_db_relocate_data->cur_offset);
    new_acl_drop_trap_hdl = FLEX_ACL_DROP_TRAP_HANDLE(acl_drop_db_relocate_data->region_id,
                                                      acl_drop_db_relocate_data->new_offset);

    /* first get the hw action and update the acl drop handle within it */
    rc = flex_acl_hw_db_get_matching_hw_action_from_rule(related_rule, SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E,
                                                         &found, &hw_action_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error trying to find action SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E in list  "
                   "action in rule. RC=%s\n", sx_status_str(rc));
        goto out;
    }
    if (found) {
        hw_action_p->acl_drop_trap_handle = new_acl_drop_trap_hdl;
        list_head = cl_list_head(list);
        list_end = cl_list_end(list);
        iter = list_head;
        while (iter != list_end) {
            kvd_index_ref = (flex_acl_hw_db_kvd_index_ref*)cl_list_obj(iter);
            iter = cl_list_next(iter);
            SX_LOG_DBG("Update acl drop relocate db. kvd_idx_ptr = %p head=%s, index = %u\n",
                       kvd_index_ref->kvd_index_ptr,
                       kvd_index_ref->is_head ? "True" : "False",
                       *kvd_index_ref->kvd_index_ptr);
            SX_LOG_DBG("Update Reloc db. add new handle 0x%" PRIx64 " del old handle 0x%" PRIx64 " \n",
                       new_acl_drop_trap_hdl, old_acl_drop_trap_hdl);
            /* Add new entry to db */

            rc = flex_acl_hw_db_acl_drop_relocate_db_add_entry(new_acl_drop_trap_hdl,
                                                               kvd_index_ref->is_head,
                                                               kvd_index_ref->kvd_index_ptr);

            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("adding action to acl drop relocate db failed [%s]\n", sx_status_str(rc));
                goto out;
            }
            /* delete entry from acl drop relocate db */
            rc = flex_acl_hw_db_acl_drop_relocate_db_del_entry(old_acl_drop_trap_hdl, kvd_index_ref->kvd_index_ptr);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("deleting action from acl drop relocate db failed [%s]\n", sx_status_str(rc));
                goto out;
            }
        }
    } else {
        /* this should not happen. */
        SX_LOG_ERR(" SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E not found in list. RC=%s\n", sx_status_str(rc));
        goto out;
    }


out:

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_field_select_count_get(sx_flex_acl_register_field_select_t field_select,
                                               uint32_t                           *sxd_actions_count)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (field_select >= SX_FLEX_ACL_FIELD_SELECT_LAST) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ACL HW field select is invalid : %u \n", field_select);
        goto out;
    }

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(flex_acl_stage)) {
        /* Some of the fields supported only on SPC4 and above */
        switch (field_select) {
        case SX_FLEX_ACL_FIELD_SELECT_TRAP_USER_ID:
            SX_LOG_ERR("Action register access - field: %u is not supported for this chip type.\n",
                       field_select);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;

        default:
            break;
        }
    }

    *sxd_actions_count = map_action_field_select[field_select].sxd_actions_count;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_hash_crc_count_get(sx_flex_acl_action_hash_crc_field_t field_select,
                                           uint32_t                           *sxd_actions_count)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (field_select >= SX_ACL_ACTION_HASH_FIELD_LAST) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ACL HW hash crc field is invalid : %u \n", field_select);
        goto out;
    }

    *sxd_actions_count = map_crc_hash_field[field_select].sxd_actions_count;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_hw_action_flow_estimator_populate(sx_flex_acl_flex_action_t action,
                                                    boolean_t                 is_defer,
                                                    flex_acl_rule_id_t        rule_id,
                                                    hw_action_list_t         *hw_action_list_p,
                                                    hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();

    switch (action.type) {
    case SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR:
        hw_action->slot.fields.action_flow_estimator.profile_key.profile_id =
            (sxd_flow_estimator_profile_id_e)(action.fields.action_flow_estimator.profile_key.profile_id);
        hw_action->counter_id = action.fields.action_flow_estimator.counter.base_counter_id;
        break;

    default:
        SX_LOG_ERR("FLOW ESTIMATOR HW action populate: Invalid action type:%u \n", action.type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* increase ref_cnt for :
 *   1) flow estimator counter
 *   2) profile */
static sx_status_t __acl_hw_action_flow_estimator_bind_populate(flex_acl_hw_action_t      *hw_action,
                                                                flex_acl_db_flex_rule_t   *rule,
                                                                flex_acl_relocation_data_t relocation_data,
                                                                boolean_t                  add_ref)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sx_status_t  status = SX_STATUS_SUCCESS;
    cm_hw_type_t cm_type = 0;
    cm_index_t   cm_index = 0;
    cm_type_e    type = 0;

    SX_LOG_ENTER();
    UNUSED_PARAM(rule);

    if (add_ref) {
        rc = flex_acl_hw_db_counter_add_entry(hw_action->counter_id,
                                              relocation_data.is_head,
                                              relocation_data.kvd_index_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flex_acl_hw_db_counter_add_entry failed, counter_id: %u\n",
                       hw_action->counter_id);
            goto out;
        }
    }
    rc = flow_counter_lock(hw_action->counter_id, &type, &cm_type, &cm_index);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL counter action failed flow_counter_lock failed, counter_id: %u\n", hw_action->counter_id);
        if (add_ref) {
            goto rollback1;
        }
        goto out;
    }
    hw_action->is_locked = TRUE;
    hw_action->slot.fields.action_flow_estimator.bulk_counter.index = cm_index;
    hw_action->slot.fields.action_flow_estimator.bulk_counter.type = cm_type;

    if (add_ref) {
        rc = flow_counter_ref_inc(hw_action->counter_id);
        SX_LOG_DBG("FLOWD ACL bind populate : action counter ref INC, id:%d \n", hw_action->counter_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL counter action failed flow_counter_ref_inc failed, counter_id: %u\n",
                       hw_action->counter_id);
            goto rollback2;
        }

        rc =
            flow_estimator_profile_ref_inc((sx_flow_estimator_profile_key_t *)&(hw_action->slot.fields.
                                                                                action_flow_estimator
                                                                                .profile_key));
        SX_LOG_DBG("FLOWD ACL bind populate : action profile ref INC, id:%d \n",
                   hw_action->slot.fields.action_flow_estimator.profile_key.profile_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL estimator action failed flow_estimator_profile_ref_inc failed, profile id: %u\n",
                       hw_action->slot.fields.action_flow_estimator.profile_key.profile_id);
            goto rollback3;
        }

        hw_action->is_ref_count_inc = TRUE;
    }
    if (hw_action->temp_release_lock == TRUE) {
        status = flow_counter_unlock(hw_action->counter_id);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to unlock old counter, counter_id %u [%s]\n",
                       hw_action->counter_id, sx_status_str(status));
        }
        hw_action->is_locked = FALSE;
    }
    goto out;

rollback3:
    status = flow_counter_ref_dec(hw_action->counter_id);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to flow_counter_ref_dec, counter_id %u [%s]\n",
                   hw_action->counter_id, sx_status_str(status));
    }

rollback2:
    status = flow_counter_unlock(hw_action->counter_id);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to unlock old counter, counter_id %u [%s]\n",
                   hw_action->counter_id, sx_status_str(status));
    }
    hw_action->is_locked = FALSE;

rollback1:
    flex_acl_hw_db_counter_remove_entry(hw_action->counter_id, relocation_data.kvd_index_p);
    goto out;


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __acl_hw_action_flow_estimator_release_lock(flex_acl_hw_action_t *hw_action)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    rc = __acl_hw_action_counter_release_lock(hw_action);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL CM action failed flow_counter_unlock failed, counter_id: %u\n", hw_action->counter_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __acl_hw_action_counter_policer_by_ref_action_set_comply(flex_acl_hw_action_t *hw_action1_p,
                                                                          flex_acl_hw_action_t *hw_action2_p)
{
    uint8_t src_cbset1 = FLEX_ACL_HW_INVALID_CBSET;
    uint8_t dst_cbset1 = FLEX_ACL_HW_INVALID_CBSET;

    /*write to a GP reg and counter by ref can't be in same action set*/
    if ((hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E) ||
        (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E) ||
        (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E) ||
        (hw_action1_p->action_type == SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E)) {
        __acl_hw_action_cbset_get(hw_action1_p, &src_cbset1, &dst_cbset1);
        if ((dst_cbset1 == hw_action2_p->slot.fields.action_policing_monitoring_by_ref.cbset)
            ) {
            return FALSE;
        }
    }
    return TRUE;
}

sx_status_t __acl_hw_action_counter_policer_by_ref_populate(sx_flex_acl_flex_action_t action,
                                                            boolean_t                 is_defer,
                                                            flex_acl_rule_id_t        rule_id,
                                                            hw_action_list_t         *hw_action_list_p,
                                                            hw_action_list_entry_t   *first_hw_action_list_entry_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_hw_action_t *hw_action = &first_hw_action_list_entry_p->hw_action;

    UNUSED_PARAM(rule_id);
    UNUSED_PARAM(is_defer);
    UNUSED_PARAM(hw_action_list_p);

    SX_LOG_ENTER();
    hw_action->slot.fields.action_policing_monitoring_by_ref.type =
        SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_BY_REF_E;
    hw_action->slot.fields.action_policing_monitoring_by_ref.cbset = action.fields.action_counter_by_ref.gp_reg_lsb;
    SX_LOG_EXIT();
    return rc;
}
