/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#undef  __MODULE__
#define __MODULE__ ACL

#include <complib/sx_log.h>
#include "flex_acl_gen_def.h"
#include "flex_acl_db.h"
#include "flex_acl_binding.h"
#include "flex_acl_hw.h"
#include "flex_acl_keys.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "ethl3/router_common.h"
#include "tunnel/hwi/decap_table_impl.h"
#include "flex_acl_rule_based_binding.h"

/************************************************
 *  Macros
 ***********************************************/
#define REBIND -1


/************************************************
**  Global variables
************************************************/
extern boolean_t   g_flex_acl_initialized;
extern acl_stage_e g_acl_stage;
extern boolean_t   g_flex_acl_manual_unbind;

sx_status_t system_acl_hw_rif_bind_callback(sx_rif_id_t                       rif,
                                            flex_acl_db_group_bind_attribs_t *bind_attribs,
                                            boolean_t                         bind,
                                            boolean_t                        *binding_done);
sx_status_t system_acl_hw_post_port_added_to_lag_callback(sx_port_id_t port_log_id,
                                                          sx_port_id_t lag_port_log_id);
sx_status_t system_acl_hw_port_removed_from_lag_callback(sx_port_id_t port_log_id,
                                                         sx_port_id_t lag_port_log_id);
sx_status_t __flex_acl_allocate_group(sx_acl_id_t       *group_id,
                                      sx_acl_direction_t direction);
sx_status_t __flex_acl_free_group(sx_acl_id_t group_id);
sx_status_t __flex_acl_group_edit(sx_acl_id_t group_id, sx_acl_id_t *acl_ids, uint32_t acl_ids_num);
static sx_status_t __flex_acl_aggregate_port_acl_groups(sx_port_id_t                      port,
                                                        flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                        int                               bind_cmd,
                                                        flex_acl_bind_attribs_id_t       *hw_attribs_id);
static sx_status_t __flex_acl_aggregate_rif_acl_groups(sx_rif_id_t                       rif,
                                                       flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                       int                               bind_cmd,
                                                       flex_acl_bind_attribs_id_t       *hw_attribs_id);
static sx_status_t __flex_acl_aggregate_vlan_group_acl_groups(sx_acl_vlan_group_t               vlan_group,
                                                              flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                              boolean_t                         bind_cmd,
                                                              flex_acl_bind_attribs_id_t       *hw_attribs_id);
static sx_status_t __flex_acl_aggregate_acl_groups(flex_acl_bind_point_id            bind_point_id,
                                                   char                             *bind_point_str,
                                                   flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                   int                               bind_cmd,
                                                   flex_acl_bind_attribs_id_t       *hw_attribs_id,
                                                   boolean_t                         is_vlan_group);
static sx_status_t __flex_acl_aggregate_acl_group_put(sx_acl_direction_t direction,
                                                      sx_acl_id_t       *group_id);
static sx_status_t __flex_acl_bind_port_in_hw(sx_port_id_t               port,
                                              flex_acl_bind_attribs_id_t new_bind_attribs_id);
static sx_status_t __flex_acl_unbind_port_in_hw(sx_port_id_t               port,
                                                flex_acl_bind_attribs_id_t old_bind_attribs_id);
static sx_status_t __flex_acl_unlink_port_attribs(sx_port_id_t               port,
                                                  flex_acl_bind_attribs_id_t old_bind_attribs_id);

/***********************************************
*  Local variables
***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __flex_acl_rebind_lag(sx_port_log_id_t           lag_port,
                                         flex_acl_bind_attribs_id_t new_bind_id,
                                         flex_acl_bind_attribs_id_t old_bind_id);
static sx_status_t __flex_acl_nve_port_rebind(sx_port_log_id_t           log_port,
                                              sx_acl_id_t                acl_group_id,
                                              flex_acl_bind_attribs_id_t new_attribs_id,
                                              flex_acl_bind_attribs_id_t old_attribs_id);
static sx_status_t __flex_acl_validate_port_bind(sx_access_cmd_t    cmd,
                                                 sx_port_id_t       log_port,
                                                 sx_acl_direction_t egress);
static sx_status_t __flex_acl_lag_unbind(sx_port_log_id_t lag_port, sx_acl_direction_t direction);
static sx_status_t __flex_acl_nve_port_unbind(sx_port_log_id_t nve_port, flex_acl_bind_attribs_id_t bind_id);
static sx_status_t __flex_acl_port_swid_validate(const sx_port_log_id_t port_id);
static sx_status_t __flex_acl_clear_rif_direction(sx_rif_id_t        rif,
                                                  sx_acl_direction_t direction,
                                                  boolean_t          clear_system);
static sx_status_t __flex_acl_clear_port_direction(sx_port_id_t log_port, sx_acl_direction_t direction);
static sx_status_t __flex_acl_clear_vlan_group_direction(sx_acl_vlan_group_t vlan_group,
                                                         sx_acl_direction_t  direction);
static const char * acl_rif_ref_name(char* name_buf, size_t name_size, void *data);
/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static ref_name_data_t acl_rif_name_data = {.print_func_p = acl_rif_ref_name, .ref_data_p = NULL, .data_size = 0};

/************************************************
 *  Function implementations
 ***********************************************/

boolean_t flex_acl_is_port_direction(sx_acl_direction_t direction)
{
    if ((direction == SX_ACL_DIRECTION_EGRESS) || (direction == SX_ACL_DIRECTION_INGRESS) ||
        (direction == SX_ACL_DIRECTION_TPORT_EGRESS) || (direction == SX_ACL_DIRECTION_TPORT_INGRESS) ||
        (direction == SX_ACL_DIRECTION_CPU_EGRESS) || (direction == SX_ACL_DIRECTION_CPU_INGRESS)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

boolean_t flex_acl_is_rif_direction(sx_acl_direction_t direction)
{
    if ((direction == SX_ACL_DIRECTION_RIF_EGRESS) || (direction == SX_ACL_DIRECTION_RIF_INGRESS)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

boolean_t flex_acl_is_vlan_direction(sx_acl_direction_t direction)
{
    if (VLAN_PREFIX_DIRECTION(direction)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

/************************************************
 *  Port Binding Functions
 ***********************************************/

/* the function open lag list to log ports and search for first different from port_log_id log port in db
 * because callback called after event
 */
static sx_status_t __flex_acl_get_port_bind_attribs(sx_port_id_t                log_port,
                                                    sx_acl_direction_t          egress,
                                                    flex_acl_bind_attribs_id_t* attribs_id)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(log_port);
    boolean_t      lag = NOT_LAG;

    SX_LOG_ENTER();

    *attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    if (port_type == SX_PORT_TYPE_LAG) {
        lag = IS_LAG;
    }

    rc = flex_acl_db_get_port_bind(log_port, egress, attribs_id, lag);

    if (SX_STATUS_SUCCESS != rc) {
        if (SX_STATUS_ENTRY_NOT_FOUND != rc) {
            SX_LOG_ERR("Error at search log port [%u] direction[%u] in db, err[%s]\n",
                       log_port, egress, sx_status_str(rc));
        }
    }

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_port_swid_validate(const sx_port_log_id_t port_id)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sx_swid_id_t swid_id = 0;

    if (SX_CHECK_FAIL(port_db_check_port_mode_router_port(port_id))) {
        if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, port_id, &swid_id))) {
            SX_LOG_ERR("Can't Retrieve SwID of Port 0x%08X (%s).\n",
                       port_id, sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }

        if (swid_validation_func_ptr) {
            rc = swid_validation_func_ptr(swid_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("SWID(%d) type mismatch\n", swid_id);
                return M_UTILS_SX_LOG_EXIT(rc);
            }
        }
    }

    return rc;
}

/* Validate Port */
sx_status_t flex_acl_validate_port(sx_port_log_id_t log_port)
{
    uint8_t        lag_member = 0;
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(log_port);

    SX_LOG_ENTER();
    /* This API does not support vPort */
    if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG) && (port_type != SX_PORT_TYPE_TUNNEL) &&
        (port_type != SX_PORT_TYPE_CPU)) {
        SX_LOG_ERR("Can't bind Port [0x%08X] (Port type(%s) is unsupported)\n", log_port,
                   sx_port_type_str(port_type));
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    /* Check that the port exists in the port DB */
    rc = port_db_info_get(log_port, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL binding: Logical port[0x%08X] does not exist: [%s]\n", log_port, sx_status_str(rc));
        goto out;
    }

    if (port_type == SX_PORT_TYPE_CPU) {
        /* Only the specific CPU port is supported and only for Spectrum2+ */
        if (!ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage) || (log_port != SX_CPU_PORT_ID)) {
            SX_LOG_ERR("ACL binding: CPU port[0x%08X] is not supported.\n", log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        rc = __flex_acl_port_swid_validate(log_port);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Logical port[0x%08X] swid is not valid: [%s]\n", log_port, sx_status_str(rc));
            goto out;
        }
    }

    if (SX_CHECK_FAIL(rc = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member))) {
        SX_LOG_ERR("port_lag_member_state_get failed, [port_id = 0x%x], error: %s\n", log_port, sx_status_str(rc));
        goto out;
    }

    /* Individual Binding is not permitted if port is lag member */
    if (TRUE == lag_member) {
        SX_LOG_ERR("Logical port[0x%08X] is a LAG member, operation not permitted\n", log_port);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_validate_port_bind(sx_access_cmd_t cmd, sx_port_id_t log_port, sx_acl_direction_t egress)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_lag = FALSE;
    uint32_t    group_count = rm_resource_global.acl_groups_size_max;

    SX_LOG_ENTER();

    /* For bind command user may not bind more than one group */
    if (cmd == SX_ACCESS_CMD_BIND) {
        if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
            is_lag = TRUE;
        }
        rc = flex_acl_db_port_bound_groups_get(log_port, egress, is_lag, NULL, &group_count);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Failed to bind to log Port %#x, err %s\n", log_port, sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;

        if (group_count > 0) {
            SX_LOG_ERR("Log port[%#x] already bound\n", log_port);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rif_bind_validate(sx_access_cmd_t cmd, sx_rif_id_t rif, sx_acl_direction_t egress)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    group_count = rm_resource_global.acl_groups_size_max;

    SX_LOG_ENTER();

    /* For bind command user may not bind more than one group */
    if (cmd == SX_ACCESS_CMD_BIND) {
        rc = flex_acl_db_rif_bound_groups_get(rif, egress, NULL, &group_count);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Failed to bind to RIF %#x, err %s\n", rif, sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;

        if (group_count > 0) {
            SX_LOG_ERR("RIF [%#x] already bound\n", rif);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_nve_port_rebind(sx_port_log_id_t           log_port,
                                              sx_acl_id_t                acl_group_id,
                                              flex_acl_bind_attribs_id_t new_attribs_id,
                                              flex_acl_bind_attribs_id_t old_attribs_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    boolean_t                         rebind = (old_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
    flex_acl_db_group_bind_attribs_t *new_bind_attribs = NULL;
    flex_acl_db_group_bind_attribs_t *old_bind_attribs = NULL;

    SX_LOG_ENTER();

    if ((rebind == FALSE) && (acl_group_id == FLEX_ACL_INVALID_ACL_ID)) {
        SX_LOG_ERR("Error binding to invalid ACL group .\n");
        goto out;
    }
    rc = flex_acl_db_attribs_get(new_attribs_id, &new_bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error getting bind attributes id %u .\n", new_attribs_id);
        goto out;
    }
    if (new_bind_attribs->bound_nve_port != SX_INVALID_PORT) {
        SX_LOG_ERR("error, the NVE port %d is already bound to attributes %d.\n", log_port, new_attribs_id);
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    /* get old and new bind attributes */
    if (rebind) {
        rc = flex_acl_db_attribs_get(old_attribs_id, &old_bind_attribs);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Error getting bind attributes id %u .\n", old_attribs_id);
            goto out;
        }
    }

    /* update ports db that port was bound to attributes */
    rc = flex_acl_db_nve_port_bind(log_port, new_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update DB: bind group [0x%x] to port [0x%x]\n", new_attribs_id,
                   log_port);
        goto out;
    }

    new_bind_attribs->bound_nve_port = log_port;

    if (rebind) {
        old_bind_attribs->bound_nve_port = SX_INVALID_PORT;
    }

    if (rebind == FALSE) {
        rc = decap_table_impl_bind_acl(log_port, acl_group_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to bind acl group  [0x%x] to nve port [0x%x]\n", new_attribs_id,
                       log_port);
            rb_st = flex_acl_db_nve_port_bind(log_port, old_attribs_id);
            if (SX_STATUS_SUCCESS != rb_st) {
                SX_LOG_ERR("ACL : Failed to rollback DB: bind group [0x%x] to port [0x%x]\n", old_attribs_id,
                           log_port);
                goto out;
            }
            new_bind_attribs->bound_nve_port = SX_INVALID_PORT;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_nve_port_unbind(sx_port_log_id_t nve_port, flex_acl_bind_attribs_id_t bind_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    sx_port_type_t                    port_type = SX_PORT_TYPE_ID_GET(nve_port);

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_TUNNEL != port_type) {
        goto out;
    }

    rc = flex_acl_db_attribs_get(bind_id, &bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error getting bind attributes id %u \n", bind_id);
        goto out;
    }

    /* update ports db that port was bound to attributes */
    rc = flex_acl_db_nve_port_unbind(nve_port);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to update DB: unbind group [0x%x] from port [0x%x]\n", bind_attribs->bind_id,
                   nve_port);
        goto out;
    }

    /* update bind attributes db with new bound port and delete port from db of old bind attributes */
    rc = decap_table_impl_unbind_acl(nve_port);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to update decap table: unbind group [0x%x] from port [0x%x]\n", bind_attribs->bind_id,
                   nve_port);
        bind_attribs->bound_nve_port = nve_port;
        rb_st = flex_acl_db_nve_port_bind(nve_port, bind_id);
        if (SX_STATUS_SUCCESS != rb_st) {
            SX_LOG_ERR("ACL: Failed to rollback DB: bind group [0x%x] to port [0x%x]\n", bind_attribs->bind_id,
                       nve_port);
            goto out;
        }
        goto out;
    }

    bind_attribs->bound_nve_port = SX_INVALID_PORT;

out:
    SX_LOG_EXIT();
    return (rc);
}

/* Handle a LAG physical port binding to ACL group.
 * The logical LAG port binding was done before calling this method and it
 * assures we have the correct HW group is already set in DB as bound to the LAG.
 * This method updates the HW binding of the LAG physical member port and updates
 * the appropriate DBs
 */
static sx_status_t __flex_acl_bind_lag_port(sx_port_log_id_t   lag_log_port,
                                            sx_port_log_id_t   log_port,
                                            sx_acl_direction_t direction)
{
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_status_t                rc = SX_STATUS_SUCCESS;

    /* Get LAG HW group */
    rc = flex_acl_db_get_port_bind(lag_log_port, direction, &bind_attribs_id, TRUE);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Error getting port [0x%x] direction [%u] bind attributes id\n", lag_log_port, direction);
        goto out;
    }

    if ((rc == SX_STATUS_ENTRY_NOT_FOUND) || (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    /* Bind the port in HW - Write the register, and update bound points*/
    rc = __flex_acl_bind_port_in_hw(log_port, bind_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in binding aggregate groups for port [0x%x].\n", log_port);
        goto out;
    }

    /* Update ports DB that port was bound to attributes */
    rc = flex_acl_db_port_bind(log_port, direction, bind_attribs_id, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
        /* This Error is FATAL - no rollback */
        goto out;
    }

out:
    return rc;
}

/*
 * Unbind a physical port of a LAG
 */
static sx_status_t __flex_acl_unbind_lag_port(flex_acl_bind_attribs_id_t bind_attribs_id,
                                              sx_port_log_id_t           log_port,
                                              sx_acl_direction_t         direction)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* Unbind the port in HW - Write the register, and update bound points*/
    rc = __flex_acl_unbind_port_in_hw(log_port, bind_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in unbinding LAG port from HW [0x%x].\n", log_port);
        goto out;
    }

    /* Update ports DB that port was bound to attributes */
    rc = flex_acl_db_port_unbind(log_port, direction, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
        /* This Error is FATAL - no rollback */
        goto out;
    }

out:
    return rc;
}

sx_status_t flex_acl_port_bind_internal(sx_port_log_id_t log_port, sx_acl_id_t group_id, boolean_t write_to_reg)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          ports_count = rm_resource_global.lag_port_members_max;
    sx_port_log_id_t                 *log_ports_p = NULL;
    flex_acl_bind_point_id            bind_point = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_acl_group_t          *acl_group = NULL;

    SX_LOG_ENTER();

    bind_point.port_id = log_port;

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: cannot get group [%u]\n", group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("Invalid bind attributes given to bind port %u\n", log_port);
        goto out;
    }

    rc = flex_acl_db_attribs_get(acl_group->bind_attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", acl_group->bind_attribs_id);
        goto out;
    }

    log_ports_p = (sx_port_log_id_t*)cl_malloc(ports_count * sizeof(sx_port_log_id_t));
    if (log_ports_p == NULL) {
        SX_LOG_ERR("ACL : Failed to allocate memory for port list, lag[0x%x]\n", log_port);
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(log_ports_p, 0, ports_count * sizeof(sx_port_log_id_t));
    /* Get list of relevant ports */
    rc = flex_acl_get_lag_ports_list(log_port, FALSE, log_ports_p, &ports_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get port list for bind operation port [0x%x]\n", log_port);
        goto out;
    }

    if (write_to_reg) {
        rc = flex_acl_db_binding_point_group_add(acl_group->direction, bind_point, acl_group->group_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto rollback;
        }

        /* Create the aggregated binding group according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_port_acl_groups(log_port, bind_attribs, TRUE, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in binding aggregate groups for port [0x%x].\n", log_port);
            goto rollback;
        }

        if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_LAG) {
            /* Update ports DB that port was bound to attributes */
            rc = flex_acl_db_port_bind(log_port, acl_group->direction, new_attribs_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
                /* This Error is FATAL - no rollback */
                goto out;
            }
        }
    }

    goto out;

rollback:
    if (write_to_reg) {
        bind_point.port_id = log_port;
        rb_rc = flex_acl_db_binding_point_group_delete(acl_group->direction, bind_point, acl_group->group_id);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at removing group from binding point port [%u]\n", log_port);
        }
    }

out:
    if (log_ports_p != NULL) {
        cl_free(log_ports_p);
    }
    SX_LOG_EXIT();
    return (rc);
}

/* If an ACL table is given for binding, a dedicated group is
 * created for the binding */
static sx_status_t __flex_acl_group_get(sx_acl_id_t acl_id, sx_acl_id_t                *group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* After this section the group ID is allocated for direct acl binding and attributes id
     * are allocated if needed */
    if (!flex_acl_db_is_acl_group(acl_id)) {
        rc = flex_acl_allocate_adhoc_acl_group(acl_id, group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to create a single ACL group for ACL [%u]\n", acl_id);
            goto out;
        }
    } else {
        *group_id = acl_id;
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_group_validate(sx_acl_id_t               group_id,
                                    flex_acl_db_acl_group_t **acl_group_pp,
                                    boolean_t                *write_to_reg_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;
    acl_id_group_entry_t     acl_ids_prepared[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    uint32_t                 prepared_acls_num = rm_resource_global.acl_groups_size_max;

    SX_LOG_ENTER();

    /* Get associated group */
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: cannot get group [%u]\n", group_id);
        goto out;
    }

    if (acl_group->prev_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("ACL: The group id %d has a parent group id %d\n", group_id, acl_group->prev_acl_group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ACL: Invalid bind attributes for group [%u]\n", group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_hw_prepare_acl_list_from_groups(acl_group->group_id, acl_ids_prepared, &prepared_acls_num,
                                                  acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n", acl_group->group_id);
        goto out;
    }

    *write_to_reg_p = (prepared_acls_num > 0) ? TRUE : FALSE;
    *acl_group_pp = acl_group;
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_validate_port_direction(sx_port_id_t log_port, sx_acl_direction_t direction)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(log_port);

    switch (direction) {
    case SX_ACL_DIRECTION_INGRESS:
    case SX_ACL_DIRECTION_EGRESS:
        /* For Spectrum1 we allow port binding for tunnel ports */
        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG) &&
            (port_type != SX_PORT_TYPE_TUNNEL)) {
            rc = SX_STATUS_PARAM_ERROR;
        }
        /* For Spectrum2 we do not allow tunnel port for port direction */
        if (ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
            if (port_type == SX_PORT_TYPE_TUNNEL) {
                rc = SX_STATUS_PARAM_ERROR;
            }
        }
        break;

    case SX_ACL_DIRECTION_TPORT_INGRESS:
    case SX_ACL_DIRECTION_TPORT_EGRESS:
        if (port_type != SX_PORT_TYPE_TUNNEL) {
            rc = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_ACL_DIRECTION_CPU_INGRESS:
    case SX_ACL_DIRECTION_CPU_EGRESS:
        if (port_type != SX_PORT_TYPE_CPU) {
            rc = SX_STATUS_PARAM_ERROR;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Invalid bind direction [%s] for port [0x%08X] binding\n",
                   sx_acl_direction_str(direction), log_port);
    }
    return rc;
}

sx_status_t flex_acl_bind_port_internal(sx_api_acl_bind_params_t * params)
{
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_status_t              rb_st = SX_STATUS_SUCCESS;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    boolean_t                write_to_reg = TRUE;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_ENTER();

    rc = __flex_acl_group_get(params->acl_id, &group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    rc = flex_acl_group_validate(group_id, &acl_group, &write_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    /* Verify that the group direction is indeed for port/tport/cpu and matches group direction */
    rc = __flex_acl_validate_port_direction(params->log_port, acl_group->direction);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL group [%u] has direction [%u] and cannot be bound to port.\n", group_id, acl_group->direction);
        goto rollback_create_adhoc_group;
    }

    /* Validate the group is not already bound */
    rc = __flex_acl_validate_port_bind(params->cmd, params->log_port, acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc == SX_STATUS_RESOURCE_IN_USE) {
            SX_LOG_ERR("Error, port %#x is already bound\n", params->log_port);
        }
        goto rollback_create_adhoc_group;
    }

    rc = flex_acl_db_group_bind_log_port(acl_group, params->log_port);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    rc = flex_acl_db_port_acl_group_bind(params->log_port, acl_group->direction,
                                         (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_LAG),
                                         params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_group_bind;
    }

    /* Bind ports */
    if ((g_acl_stage == ACL_STAGE_FLEX) &&
        (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_TUNNEL)) {
        /* This type of NVE port binding is used only in Spectrum.
         * In Spectrum2 and above NVE port is handled as a regular
         * port in terms of ACL binding.
         */
        rc = __flex_acl_nve_port_rebind(params->log_port,
                                        group_id,
                                        acl_group->bind_attribs_id,
                                        FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to bind ACL group [0x%x] to NVE port [0x%x]\n", acl_group->bind_attribs_id,
                       params->log_port);
            goto rollback_port_group_bind;
        }
    } else {
        rc = flex_acl_port_bind_internal(params->log_port, acl_group->group_id, write_to_reg);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to bind port to group id [0x%x] direction [%u]\n",
                       acl_group->bind_attribs_id, acl_group->direction);
            goto rollback_port_group_bind;
        }
    }

    goto out;

rollback_port_group_bind:
    rb_st = flex_acl_db_port_acl_group_unbind(params->log_port, acl_group->direction,
                                              (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_LAG),
                                              params->acl_id);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback port group DB operation, err [%s]\n", sx_status_str(rb_st));
    }
rollback_group_bind:
    rb_st = flex_acl_db_group_unbind_log_port(acl_group, params->log_port);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback DB operation, err [%s]\n", sx_status_str(rb_st));
    }
rollback_create_adhoc_group:
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rb_st = flex_acl_clean_adhoc_acl_group(params->acl_id, TRUE);
        if (SX_CHECK_FAIL(rb_st)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
        }
    }
out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_port_unbind_internal(sx_acl_id_t                group_id,
                                          sx_port_log_id_t           log_lag_port,
                                          flex_acl_bind_attribs_id_t attribs_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    boolean_t                         is_bound = FALSE;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    sx_acl_direction_t                direction = SX_ACL_DIRECTION_LAST;
    uint32_t                          i = 0;
    uint32_t                          ports_count = rm_resource_global.lag_port_members_max;
    sx_port_log_id_t                 *log_ports_p = NULL;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();

    log_ports_p = (sx_port_log_id_t*)cl_malloc(ports_count * sizeof(sx_port_log_id_t));
    if (log_ports_p == NULL) {
        SX_LOG_ERR("ACL : Failed to allocate memory for port list, lag[0x%x]\n", log_lag_port);
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(log_ports_p, 0, ports_count * sizeof(sx_port_log_id_t));

    /* Get list of relevant ports */
    rc = flex_acl_get_lag_ports_list(log_lag_port, FALSE, log_ports_p, &ports_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get port list for bind operation port [0x%x]\n", log_lag_port);
        goto out;
    }

    /* Validate that all ports are bound to the group bind attributes */
    for (i = 0; i < ports_count; i++) {
        rc = flex_acl_db_attribs_is_log_port_bound(attribs_id, log_ports_p[i], &is_bound);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error, when trying to get if port %u is bound\n", log_ports_p[i]);
            goto out;
        }
        if (!is_bound) {
            SX_LOG_ERR("Error, port %u is not bound to attributes %d\n", log_ports_p[i], attribs_id);
            rc = SX_STATUS_ENTRY_NOT_BOUND;
            goto out;
        }
    }

    rc = flex_acl_db_attribs_get(attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u \n", attribs_id);
        goto out;
    }
    direction = bind_attribs->direction;
    bind_point_id.port_id = log_lag_port;
    rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback;
    }

    /* Create the aggregated binding group according to current bindings,
     * and bind to HW accordingly */
    rc = __flex_acl_aggregate_port_acl_groups(log_lag_port, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unbind group [0x%x] in aggregate groups for port [0x%x].\n", group_id, log_ports_p[i]);
        goto rollback;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* If there were more than one group bound to the port, unbind
         * of one of the group leads to a new HW binding.
         * for example port bound to {g1,g2,g3} - unbind g2 leads to binding {g1.g3} */
        if (SX_PORT_TYPE_ID_GET(log_lag_port) != SX_PORT_TYPE_LAG) {
            /* Update ports DB that port was bound to attributes */
            rc = flex_acl_db_port_bind(log_lag_port, direction, new_attribs_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_lag_port);
                /* This Error is FATAL - no rollback */
                goto out;
            }
        }
    } else {
        /* True unbind */
        if (SX_PORT_TYPE_ID_GET(log_lag_port) != SX_PORT_TYPE_LAG) {
            /* Physical port unbind - DB update only since unbinding was done
             * in the aggregation phase */
            rc = flex_acl_db_port_unbind(log_lag_port, direction, NOT_LAG);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to remove port from DB: bind group [0x%x] to port [0x%x]\n", attribs_id,
                           log_lag_port);

                goto rollback;
            }
        }
    }
    goto out;

rollback:
    bind_point_id.port_id = log_lag_port;
    rb_st = flex_acl_db_binding_point_group_add(direction, bind_point_id, group_id);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to rollback and add group[0x%x] to lag [0x%x]\n", group_id, log_lag_port);
    }

out:
    if (log_ports_p != NULL) {
        cl_free(log_ports_p);
    }
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_unbind_port_internal(sx_api_acl_bind_params_t * params)
{
    flex_acl_db_acl_table_t   *acl_table = NULL;
    flex_acl_db_acl_group_t   *acl_group = NULL;
    flex_acl_bind_attribs_id_t attribs_id_from_port = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_st = SX_STATUS_SUCCESS;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;

    SX_LOG_ENTER();

    /* Check if ACL/group is indeed bound to port */
    group_id = params->acl_id;
    if (!flex_acl_db_is_acl_group(group_id)) {
        /* Get the info about the ACL form the DB */
        rc = flex_acl_db_acl_get(group_id, &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB\n", group_id);
            goto out;
        }
        group_id = acl_table->adhoc_acl_group_id;
        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    if (flex_acl_db_is_port_bound_group(params->log_port, acl_group->direction,
                                        (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_LAG),
                                        params->acl_id) == FALSE) {
        SX_LOG_ERR("ACL: ACL [0x%x] is not bound to port [0x%x]\n", params->acl_id, params->log_port);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* We will first retrieve the HW group of the acl ID that is being unbound */
    rc = flex_acl_get_bind_attribs(params->acl_id, &attribs_id_from_port, NULL, NULL);
    if ((rc != SX_STATUS_SUCCESS) || (attribs_id_from_port == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Error when trying to get bind attributes id for port [%u]\n", params->log_port);
        goto rollback_acl_group_unbind;
    }

    /* Get the HW group actually bound to this port */
    rc = __flex_acl_get_port_bind_attribs(params->log_port, acl_group->direction, &attribs_id_from_port);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for port %u, error[%s]\n", params->log_port,
                   sx_status_str(rc));
        goto rollback_acl_group_unbind;
    }

    if ((rc != SX_STATUS_ENTRY_NOT_FOUND) && (attribs_id_from_port != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) &&
        (acl_group->acl_num > 0)) {
        if ((g_acl_stage == ACL_STAGE_FLEX) &&
            (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_TUNNEL)) {
            /* This part handles Spectrum only NVE port binding.
             * Spectrum2 and above support binding to real NVE port,
             * so it is handled as a regular port
             */
            rc = __flex_acl_nve_port_unbind(params->log_port, attribs_id_from_port);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to unbind port from bind group id [0x%x]\n", attribs_id_from_port);
                goto rollback_acl_group_unbind;
            }
        } else {
            /* After validation is done, UNBIND command means clearing the port bindings,
             * So call clear binding method
             */
            if (params->cmd == SX_ACCESS_CMD_UNBIND) {
                rc = __flex_acl_clear_port_direction(params->log_port, acl_group->direction);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error in port [%u] unbind\n", params->log_port);
                }
                goto out;
            }

            rc = flex_acl_port_unbind_internal(group_id, params->log_port, attribs_id_from_port);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to unbind port[%u] from bind group id [0x%x]\n",
                           params->log_port,
                           attribs_id_from_port);
                goto rollback_lag_unbind;
            }
        }
    }

    /* Unlink group to bound port */
    rc = flex_acl_db_group_unbind_log_port(acl_group, params->log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to mark port [0x%x] unbound to group [%d] in DB\n", params->log_port, group_id);
        goto rollback_port_unbind;
    }

    /* Unlink ACL ID from port */
    rc = flex_acl_db_port_acl_group_unbind(params->log_port, acl_group->direction,
                                           (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_LAG),
                                           params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from port [0x%x] in DB\n", params->acl_id, params->log_port);
        goto rollback_group_unbind;
    }

    /* Remove bind attributes from group and destroy group if was direct ACL binding */
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rc = flex_acl_clean_adhoc_acl_group(params->acl_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at port unbind\n", params->acl_id);
            goto rollback_group_unbind;
        }
    }

    goto out;

rollback_group_unbind:
    rb_st = flex_acl_db_group_bind_log_port(acl_group, params->log_port);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error on rollback mark port [0x%x] bound to group [%d] in DB\n", params->log_port, group_id);
    }
rollback_port_unbind:
    if (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_TUNNEL) {
        rb_st = __flex_acl_nve_port_rebind(params->log_port,
                                           group_id,
                                           attribs_id_from_port,
                                           FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
    }
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
rollback_lag_unbind:
    rb_st =
        __flex_acl_rebind_lag(params->log_port, attribs_id_from_port, FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
rollback_acl_group_unbind:
    rb_st = flex_acl_db_port_acl_group_bind(params->log_port, acl_group->direction,
                                            (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_LAG),
                                            params->acl_id);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_bind_port_get(sx_api_acl_bind_get_params_t * params)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_NETWORK;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    port_type = SX_PORT_TYPE_ID_GET(params->log_port);

    /* Validate Port */
    rc = __flex_acl_port_swid_validate(params->log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PORT : Logical port[0x%08X] swid is not valid: [%s]\n",
                   params->log_port, sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_port_bound_groups_get(params->log_port,
                                           params->acl_direction,
                                           (SX_PORT_TYPE_LAG == port_type) ? IS_LAG : NOT_LAG,
                                           params->acl_id,
                                           &params->acl_ids_num);

out:
    SX_LOG_EXIT();
    /* return to caller */
    return rc;
}

static sx_status_t __flex_acl_clear_port_direction(sx_port_id_t log_port, sx_acl_direction_t direction)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                       groups[rm_resource_global.acl_groups_size_max];
    sx_acl_id_t                       unbind_acl_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                          groups_num = rm_resource_global.acl_groups_size_max;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t        attribs_id_from_port = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          j = 0;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    boolean_t                         is_lag = FALSE;
    sx_acl_id_t                       cur_group = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_table_t          *acl_table = NULL;

    bind_point_id.port_id = log_port;

    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
        is_lag = TRUE;
    }

    rc = flex_acl_db_port_bound_groups_get(log_port, direction, is_lag, groups, &groups_num);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed in getting binding point groups port [%u] direction [%u]\n",
                   log_port,
                   direction);
        goto out;
    }

    /* Get the currently bound HW group */
    attribs_id_from_port = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    rc = __flex_acl_get_port_bind_attribs(log_port, direction, &attribs_id_from_port);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for port %u direction [%u], error[%s]\n", log_port,
                   direction, sx_status_str(rc));
        goto out;
    }

    /* Go over all configured user groups and remove them per this binding point
     * This is imitating a user unbind of all the groups currently bound on the
     * binding point
     */
    for (j = 0; j < groups_num; j++) {
        cur_group = groups[j];
        if (!flex_acl_db_is_acl_group(cur_group)) {
            /* Get the info about the ACL form the DB */
            rc = flex_acl_db_acl_get(cur_group, &acl_table);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB for system group clean\n", cur_group);
                goto out;
            }
            cur_group = acl_table->adhoc_acl_group_id;
        }
        rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, cur_group);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL: Failed in removing binding point groups of port [0x%x] direction [%u]\n", log_port,
                       direction);
            goto out;
        }

        rc = flex_acl_db_get_acl_group(cur_group, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: group get error for group [%d]\n", groups[j]);
            goto out;
        }

        rc = flex_acl_db_group_unbind_log_port(acl_group, bind_point_id.port_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to mark port [0x%x] unbound to group [%d] in DB\n",
                       bind_point_id.port_id,
                       groups[j]);
            goto out;
        }

        rc = flex_acl_db_port_acl_group_unbind(log_port, direction, is_lag, groups[j]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from port [0x%x] in DB\n", groups[j], log_port);
            goto out;
        }
    }

    if (attribs_id_from_port == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_attribs_get(attribs_id_from_port, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id [%u] port [%u] direction [%u]\n", attribs_id_from_port,
                   log_port, direction);
        goto out;
    }

    /* Since all groups are cleared, calling this function will result
     * unbinding of the port from all groups */
    rc = __flex_acl_aggregate_port_acl_groups(log_port, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unbind ingress port by port id[%#x]\n", log_port);
        goto out;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* Most of the work was done in the above function. There is a need only to
         * add the new bind attribute to the port (for non LAG case only).
         */
        if (!is_lag) {
            rc = flex_acl_db_port_bind(log_port, direction, new_attribs_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
                /* This Error is FATAL - no rollback */
                goto out;
            }
        }
    } else {
        /* True unbind - this is the last port bound */
        if (!is_lag) {
            rc = flex_acl_db_port_unbind(log_port, direction, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to remove port from DB: bind group [%u] to port [0x%x]\n",
                           bind_attribs->bind_id,
                           log_port);
                goto out;
            }
        }

        rc = __flex_acl_lag_unbind(log_port, direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("LAG: unbind group [%u] to port [0x%x]\n", bind_attribs->bind_id,
                       log_port);
            goto out;
        }
    }

    for (j = 0; j < groups_num; j++) {
        /* It could be that a dedicated group was created for binding this port.
         * In such cases the dedicated group should be removed if the ACL is not
         * bound anymore.
         */

        if (flex_acl_db_is_acl_group(groups[j])) {
            rc = flex_acl_db_get_acl_id_for_unbind(groups[j], &unbind_acl_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get ACL id for unbind operation, group_id: %u\n", groups[j]);
                goto out;
            }
        } else {
            unbind_acl_id = groups[j];
        }

        if (!flex_acl_db_is_acl_group(unbind_acl_id)) {
            rc = flex_acl_clean_adhoc_acl_group(unbind_acl_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at clear port binding\n",
                           unbind_acl_id);
                goto out;
            }
        }
    }

out:
    return rc;
}

sx_status_t flex_acl_clear_port_binding(sx_port_id_t log_port)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t directions[] = {SX_ACL_DIRECTION_INGRESS, SX_ACL_DIRECTION_EGRESS};
    uint32_t           i = 0;

    SX_LOG_ENTER();

    SX_LOG_DBG("log_port[%#x]\n", log_port);

    /* Unbind ingress and then egress */
    for (i = 0; i < (int)(sizeof(directions) / sizeof(directions[0])); i++) {
        rc = __flex_acl_clear_port_direction(log_port, directions[i]);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/************************************************
 *  LAG Handling Functions
 ***********************************************/

static sx_status_t __flex_acl_lag_unbind(sx_port_log_id_t lag_port, sx_acl_direction_t direction)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(lag_port);

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_LAG != port_type) {
        goto out;
    }

    /* update ports db that port was bound to attributes */
    rc = flex_acl_db_port_unbind(lag_port, direction, IS_LAG);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to update DB: unbind group from port [0x%x]\n", lag_port);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* rebind lag is pure db operation */
static sx_status_t __flex_acl_rebind_lag(sx_port_log_id_t           lag_port,
                                         flex_acl_bind_attribs_id_t new_bind_id,
                                         flex_acl_bind_attribs_id_t old_bind_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    boolean_t                         rebind = (old_bind_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
    sx_port_type_t                    port_type = SX_PORT_TYPE_ID_GET(lag_port);
    flex_acl_db_group_bind_attribs_t *new_bind_attribs = NULL;
    flex_acl_db_group_bind_attribs_t *old_bind_attribs = NULL;

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_LAG != port_type) {
        goto out;
    }

    rc = flex_acl_db_attribs_get(new_bind_id, &new_bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error getting bind attributes id %u \n", new_bind_id);
        goto out;
    }
    if (rebind) {
        rc = flex_acl_db_attribs_get(old_bind_id, &old_bind_attribs);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Error getting bind attributes id %u \n", old_bind_id);
            goto out;
        }
    }

    /* update ports db that port was bound to attributes */
    rc =
        flex_acl_db_port_bind(lag_port, new_bind_attribs->direction, new_bind_attribs->bind_id, IS_LAG);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update DB: bind group [0x%x] to port [0x%x]\n",
                   new_bind_attribs->bind_id,
                   lag_port);
        goto out;
    }

    /* update bind attributes db with new bound port and delete port from db of old bind attributes */
    rc = flex_acl_db_attribs_bind_lag(new_bind_attribs->bind_id, lag_port);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update DB: bind group 0x%x to port 0x%x\n", new_bind_attribs->bind_id,
                   lag_port);
        /* rollback */
        if (rebind) {
            rb_st = flex_acl_db_port_bind(lag_port,
                                          old_bind_attribs->direction,
                                          old_bind_attribs->bind_id,
                                          IS_LAG);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
        } else {
            rb_st = flex_acl_db_port_unbind(lag_port, new_bind_attribs->direction, IS_LAG);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
        }
        goto out;
    }
    SX_LOG_DBG("before rebind = %d\n", rebind);
    if (rebind) {
        rc = flex_acl_db_attribs_unbind_lag(old_bind_attribs->bind_id, lag_port);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to update DB: bind group 0x%x to port 0x%x\n",
                       old_bind_attribs->bind_id,
                       lag_port);

            rb_st = flex_acl_db_port_bind(lag_port,
                                          old_bind_attribs->direction,
                                          old_bind_attribs->bind_id,
                                          IS_LAG);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
            rb_st = flex_acl_db_attribs_unbind_log_port(new_bind_attribs->bind_id, lag_port);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_post_port_added_to_lag_handle_binding(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id)
{
    /* When a port is added to LAG, it should be bound to the LAG's ACLs
     *  If the port is already bound then it should be first removed from binding*/
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("port_log_id %d, port lag id %d\n", port_log_id, lag_port_log_id);

    /* Unbind port from old bind attributes if was bound. The operation also can clear hw from acls, so rollback operation should
     * pay attention to this fact */
    rc = flex_acl_clear_port_binding(port_log_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to clear port [0x%x] bind\n", port_log_id);
        goto out;
    }

    rc = __flex_acl_bind_lag_port(lag_port_log_id, port_log_id, SX_ACL_DIRECTION_INGRESS);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind new LAG [0x%x] port [0x%x] ingress\n", lag_port_log_id, port_log_id);
        goto out;
    }

    rc = __flex_acl_bind_lag_port(lag_port_log_id, port_log_id, SX_ACL_DIRECTION_EGRESS);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind new LAG [0x%x] port [0x%x] bind\n", lag_port_log_id, port_log_id);
        goto out;
    }

    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_port_removed_from_lag_handle_binding(sx_port_id_t lag_port_log_id, sx_port_id_t log_port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(lag_port_log_id);

    SX_LOG_ENTER();

    /* Should check if port in lag is bound to something at all */
    rc = flex_acl_clear_port_binding(log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear port bind attributes for port [%#x]\n", log_port);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/************************************************
 *  RIF Handling Functions
 ***********************************************/
static const char * acl_rif_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_RIF_REF;

    return ref_name;
}

/* Write register, update acl db and update bind attributes db */
sx_status_t flex_acl_rif_unbind_internal(sx_acl_id_t group_id, sx_rif_id_t rif, flex_acl_bind_attribs_id_t attribs_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    boolean_t                         is_bound = FALSE;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_direction_t                direction = SX_ACL_DIRECTION_RIF_INGRESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_attribs_get(attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u \n", attribs_id);
        goto out;
    }

    /* Validate that RIF is bound to the group bind attributes */
    rc = flex_acl_db_attribs_is_rif_bound(attribs_id, rif, &is_bound);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error, when trying to get if RIF %u is bound\n", rif);
        goto out;
    }

    if (!is_bound) {
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    bind_point_id.rif_id = rif;
    direction = bind_attribs->direction;
    rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* Update the aggregated binding group according to current bindings,
     * and bind to HW accordingly */
    rc = __flex_acl_aggregate_rif_acl_groups(rif, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unbind group [0x%x] in aggregate groups for RIF [0x%x].\n", group_id, rif);
        goto rollback;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* If there were more than one group bound to the port, unbind
         * of one of the group leads to a new HW binding.
         * for example port bound to {g1,g2,g3} - unbind g2 leads to binding {g1.g3} */
        rc = flex_acl_db_rif_bind(rif, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating port's HW ACL group in DB RIF [0x%x].\n", rif);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    } else {
        /* RIF true unbind - DB update only since unbinding was done
         * in the aggregation phase */
        rc = flex_acl_db_rif_unbind(rif, direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: unbind group [0x%x] from RIF [0x%x]\n", attribs_id, rif);
            goto out;
        }
    }

    goto out;

rollback:
    rb_st = flex_acl_db_binding_point_group_add(direction, bind_point_id, group_id);
    if ((rb_st != SX_STATUS_SUCCESS) && (rb_st != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed to rollback and add group[0x%x] to RIF [0x%x]\n", group_id, rif);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* This function must be called when a user group is edited in order to update all aggregated
 * ACL groups.
 */
sx_status_t flex_acl_update_bind_points_on_group_edit(sx_acl_id_t                group_id,
                                                      flex_acl_bind_attribs_id_t bind_attribs_id,
                                                      sx_acl_direction_t         direction)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    sx_rif_id_t                       rif = 0;
    sx_port_id_t                      log_port = 0;
    cl_list_iterator_t                iter = NULL;
    cl_list_iterator_t                iter_end = NULL;
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    sx_acl_vlan_group_t               vlan_group = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    rc = flex_acl_db_attribs_get(bind_attribs_id, &attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", bind_attribs_id);
        goto out;
    }

    /* Go all over the relevant rifs/ports/VLAN groups for this bind attributes and check if a system
     * individual acl is also bound to this rif/port/VLAN groups. If so inform him about the change in the group
     */
    iter = cl_list_head(&(acl_group->bound_rifs));
    iter_end = cl_list_end(&(acl_group->bound_rifs));
    while (iter != iter_end) {
        rif = (intptr_t)cl_list_obj(iter);
        /* Trigger aggregated binding group update according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_rif_acl_groups(rif, attribs, REBIND, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" ACL: Failed updating bindings for RIF [0x%x]\n", rif);
            iter = cl_list_next(iter);
            continue;
        }

        /* Update RIFs DB that RIF was bound to attributes */
        rc = flex_acl_db_rif_bind(rif, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating RIF HW ACL group in DB RIF [0x%x].\n", rif);
            /* This Error is FATAL - no rollback */
            goto out;
        }
        iter = cl_list_next(iter);
    }

    iter = cl_list_head(&(acl_group->bound_log_ports));
    iter_end = cl_list_end(&(acl_group->bound_log_ports));
    while (iter != iter_end) {
        log_port = (intptr_t)cl_list_obj(iter);
        /* Trigger aggregated binding group update according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_port_acl_groups(log_port, attribs, REBIND, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" ACL: Failed updating bindings for port [0x%x]\n", log_port);
            iter = cl_list_next(iter);
            continue;
        }
        /* Update Port DB that port was bound to attributes */
        rc = flex_acl_db_port_bind(log_port, direction, new_attribs_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating Port's HW ACL group in DB port [0x%x].\n", log_port);
            /* This Error is FATAL - no rollback */
            goto out;
        }
        iter = cl_list_next(iter);
    }

    /* Handle VLAN group binds */
    iter = cl_list_head(&(acl_group->bound_vlan_groups));
    iter_end = cl_list_end(&(acl_group->bound_vlan_groups));
    while (iter != iter_end) {
        vlan_group = (intptr_t)cl_list_obj(iter);
        /* Trigger aggregated binding group update according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_vlan_group_acl_groups(vlan_group, attribs, REBIND, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" ACL: Failed updating bindings for VLAN group [0x%x]\n", vlan_group);
            iter = cl_list_next(iter);
            continue;
        }
        /* Update DB that VLAN group was bound to attributes */
        rc = flex_acl_db_vlan_group_bind(vlan_group, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
            /* This Error is FATAL - no rollback */
            goto out;
        }
        iter = cl_list_next(iter);
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_rif_bind_internal(sx_rif_id_t rif, sx_acl_id_t group_id, boolean_t write_to_reg)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_bind_point_id            bind_point = {.rif_id = rif};
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_acl_group_t          *acl_group = NULL;

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: cannot get group [%u]\n", group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("Invalid bind attributes given to bind RIF %u\n", rif);
        goto out;
    }

    rc = flex_acl_db_attribs_get(acl_group->bind_attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", acl_group->bind_attribs_id);
        goto out;
    }

    if (write_to_reg) {
        rc = flex_acl_db_binding_point_group_add(acl_group->direction, bind_point, acl_group->group_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto rollback;
        }

        /* Update the aggregated binding group according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_rif_acl_groups(rif, bind_attribs, TRUE, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in binding aggregate groups for RIF [0x%x].\n", rif);
            goto rollback;
        }

        /* Update RIFs DB that RIF was bound to attributes */
        rc = flex_acl_db_rif_bind(rif, acl_group->direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating RIF HW ACL group in DB RIF [0x%x].\n", rif);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    }

    goto out;

rollback:
    if (write_to_reg) {
        rb_rc = flex_acl_db_binding_point_group_delete(acl_group->direction, bind_point, acl_group->group_id);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at removing group from binding point RIF [%u]\n", rif);
        }
    }
out:
    return rc;
}

sx_status_t flex_acl_bind_rif_internal(sx_api_flex_acl_bind_params_t * params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_st = SX_STATUS_SUCCESS;
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_direction_t       direction = SX_ACL_DIRECTION_LAST;
    boolean_t                write_to_reg = TRUE;
    flex_acl_db_acl_group_t *acl_group = NULL;
    sdk_ref_t                ref = 0;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = __flex_acl_group_get(params->acl_id, &group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    rc = flex_acl_group_validate(group_id, &acl_group, &write_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    /* Verify that the group direction is indeed for RIF */
    if (flex_acl_is_rif_direction(acl_group->direction) == FALSE) {
        SX_LOG_ERR("ACL group [%u] has direction [%u] and cannot be bound to RIF.\n", group_id, acl_group->direction);
        rc = SX_STATUS_ERROR;
        goto rollback_create_adhoc_group;
    }

    rc = __flex_acl_rif_bind_validate(params->cmd, params->rif, acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    /* Update logic DB level binding */
    rc = flex_acl_db_group_bind_rif(acl_group, params->rif);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    rc = flex_acl_db_rif_acl_group_bind(params->rif, acl_group->direction,
                                        params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_group_bind;
    }

    rc = flex_acl_rif_bind_internal(params->rif, acl_group->group_id, write_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind RIF to group id [0x%x]\n", acl_group->group_id);
        goto rollback_rif_bind_group;
    }

    /* Increase RIF's REF and store returned REF in DB */
    if (g_flex_acl_manual_unbind) {
        rc = sx_router_cmn_rif_impl_ref_increase(params->rif, &acl_rif_name_data, &ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to increase RIF's REF for [%u] group id\n", acl_group->group_id);
            goto rollback_rif_bind_group;
        }

        rc = flex_acl_db_group_rif_ref_set(SX_ACCESS_CMD_ADD, acl_group, params->rif, ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to set RIF's REF for [%u] group id\n", acl_group->group_id);
            goto rollback_rif_ref_inc;
        }
    }
    goto out;

rollback_rif_ref_inc:
    rb_st = sx_router_cmn_rif_impl_ref_decrease(params->rif, &ref);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to decrease RIF's REF for [%u] group id\n", acl_group->group_id);
    }
rollback_rif_bind_group:
    rb_st = flex_acl_db_rif_acl_group_unbind(params->rif, direction, params->acl_id);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error in rollback, err %s\n", sx_status_str(rb_st));
    }
rollback_group_bind:
    rb_st = flex_acl_db_group_unbind_rif(acl_group, params->rif);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error in rollback, err %s\n", sx_status_str(rb_st));
    }
rollback_create_adhoc_group:
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rb_st = flex_acl_clean_adhoc_acl_group(params->acl_id, TRUE);
        if (SX_CHECK_FAIL(rb_st)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
        }
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_groups_rif_refs_unbind(sx_rif_id_t rif, sx_acl_id_t* bound_groups, uint32_t bound_groups_num)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 j = 0;
    sx_acl_id_t              cur_group = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_table_t *acl_table = NULL;
    flex_acl_db_acl_group_t *acl_group = NULL;
    sdk_ref_t                ref = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(bound_groups, "bound_groups"))) {
        goto out;
    }

    for (j = 0; j < bound_groups_num; j++) {
        cur_group = bound_groups[j];

        if (!flex_acl_db_is_acl_group(cur_group)) {
            /* Get the info about the ACL from the DB in order to retrieve the unbound group id from it*/
            rc = flex_acl_db_acl_get(cur_group, &acl_table);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "ACL: Failed to get ACL [%u] info from DB for retrieving the attached group to RIF in RIF REFS unbind\n",
                    cur_group);
                goto out;
            }
            cur_group = acl_table->adhoc_acl_group_id;
        }
        rc = flex_acl_db_get_acl_group(cur_group, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to get group [%d] info from DB for RIF REFS unbind\n", cur_group);
            goto out;
        }

        rc = flex_acl_db_group_rif_ref_get(acl_group, rif, &ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get RIF's REF for group [%u] from DB for RIF REFS unbind\n",
                       acl_group->group_id);
            goto out;
        }
        rc = sx_router_cmn_rif_impl_ref_decrease(rif, &ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to decrease RIF's REF attached to group [%u] for RIF REFS unbind\n",
                       acl_group->group_id);
            goto out;
        }
        rc = flex_acl_db_group_rif_ref_set(SX_ACCESS_CMD_DELETE, acl_group, rif, ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to set RIF's REF for group [%u] from DB for RIF REFS unbind\n",
                       acl_group->group_id);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_unbind_rif_internal(sx_api_flex_acl_bind_params_t * params, boolean_t full_unbind)
{
    flex_acl_bind_attribs_id_t attribs_id_from_rif = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_group_t   *acl_group = NULL;
    flex_acl_db_acl_table_t   *acl_table = NULL;
    sx_acl_id_t                bound_groups[rm_resource_global.acl_groups_num_max];
    uint32_t                   bound_groups_num = rm_resource_global.acl_groups_num_max;

    SX_LOG_ENTER();

    UNUSED_PARAM(full_unbind);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Check if ACL/group is indeed bound to RIF */
    group_id = params->acl_id;
    if (!flex_acl_db_is_acl_group(group_id)) {
        /* Get the info about the ACL form the DB */
        rc = flex_acl_db_acl_get(group_id, &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB\n", group_id);
            goto out;
        }
        group_id = acl_table->adhoc_acl_group_id;
        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    if (flex_acl_db_is_rif_bound_group(params->rif, acl_group->direction,
                                       params->acl_id) == FALSE) {
        SX_LOG_ERR("ACL: ACL [0x%x] is not bound to RIF [0x%x]\n", params->acl_id, params->rif);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* After validation is done, UNBIND command means clearing the RIFs
     * So call clear binding method
     */
    if (params->cmd == SX_ACCESS_CMD_UNBIND) {
        if (g_flex_acl_manual_unbind) {
            /* Get user groups bound to the RIF before clearing them */
            rc = flex_acl_db_rif_bound_groups_get(params->rif, acl_group->direction, bound_groups, &bound_groups_num);
            if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("ACL: Failed in getting binding point groups RIF [%u] direction [%u]\n",
                           params->rif,
                           acl_group->direction);
                goto out;
            }
        }
        rc = __flex_acl_clear_rif_direction(params->rif, acl_group->direction, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error in RIF [%u] unbind\n", params->rif);
            goto out;
        }
        if (g_flex_acl_manual_unbind) {
            /* Decrease RIF's REF and remove REF from DB for cleared groups. */
            rc = flex_acl_groups_rif_refs_unbind(params->rif, bound_groups, bound_groups_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in unbinding groups RIF REF for RIF [%u]\n", params->rif);
                goto out;
            }
        }
        goto out;
    }

    /* Decrease RIF's REF and remove REF from DB. */
    if (g_flex_acl_manual_unbind) {
        bound_groups_num = 1;
        bound_groups[0] = group_id;

        rc = flex_acl_groups_rif_refs_unbind(params->rif, bound_groups, bound_groups_num);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in decreasing groups RIF REF for RIF [%u]\n", params->rif);
            goto out;
        }
    }

    /* We will first retrieve the HW group of the ACL ID that is being unbound */
    rc = flex_acl_get_bind_attribs(params->acl_id, &attribs_id_from_rif, NULL, NULL);
    if ((rc != SX_STATUS_SUCCESS) || (attribs_id_from_rif == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Error when trying to get bind attributes id for RIF [%u]\n", params->rif);
        goto out;
    }

    /* Get the HW group actually bound to this port */
    rc = flex_acl_db_get_rif_bind(params->rif, acl_group->direction, &attribs_id_from_rif);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for RIF %u, error[%s]\n", params->rif,
                   sx_status_str(rc));
        goto out;
    }

    if ((rc != SX_STATUS_ENTRY_NOT_FOUND) && (attribs_id_from_rif != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) &&
        (acl_group->acl_num > 0)) {
        rc = flex_acl_rif_unbind_internal(group_id, params->rif, attribs_id_from_rif);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to unbind RIF[%u] from bind group id [0x%x] error [%s]\n",
                       params->rif,
                       attribs_id_from_rif,
                       sx_status_str(rc));
            goto out;
        }
    }

    /* Unlink group from RIF */
    rc = flex_acl_db_group_unbind_rif(acl_group, params->rif);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to mark RIF [0x%x] unbound to group [%d] in DB\n", params->rif, group_id);
        goto out;
    }

    /* Unlink ACL ID from RIF */
    rc = flex_acl_db_rif_acl_group_unbind(params->rif, acl_group->direction, params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from RIF [0x%x] in DB\n", params->acl_id, params->rif);
        goto out;
    }

    /* Remove bind attributes from group and destroy group if was direct acl binding */
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rc = flex_acl_clean_adhoc_acl_group(params->acl_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at RIF [%u] unbind\n",
                       params->acl_id,
                       params->rif);
            goto out;
        }
    }

    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_bind_rif_get(sx_api_acl_bind_get_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (flex_acl_is_rif_direction(params->acl_direction) == FALSE) {
        SX_LOG_ERR("The provided direction [%u] is not compatible with RIF\n", params->acl_direction);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_rif_bound_groups_get(params->rif,
                                          params->acl_direction,
                                          params->acl_id,
                                          &params->acl_ids_num);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_clear_rif_direction(sx_rif_id_t rif, sx_acl_direction_t direction,
                                                  boolean_t clear_system)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                       groups[rm_resource_global.acl_groups_num_max];
    sx_acl_id_t                       unbind_acl_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                          groups_num = rm_resource_global.acl_groups_num_max;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t        attribs_id_from_rif = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          j = 0;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    sx_acl_id_t                       cur_group = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_table_t          *acl_table = NULL;
    boolean_t                         is_decap_rif = FALSE;
    boolean_t                         check_global_system_acl_group = TRUE;

    bind_point_id.rif_id = rif;

    /* Get user groups bound to the RIF */
    rc = flex_acl_db_rif_bound_groups_get(rif, direction, groups, &groups_num);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed in getting binding point groups RIF [%u] direction [%u]\n", rif, direction);
        goto out;
    }

    /* Get the currently bound HW group */
    attribs_id_from_rif = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    rc = flex_acl_db_get_rif_bind(rif, direction, &attribs_id_from_rif);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for RIF %u direction [%u], error[%s]\n", rif,
                   direction, sx_status_str(rc));
        goto out;
    }

    /* Go over all configured user groups and remove them per this binding point
     * This is imitating a user unbind of all the groups currently bound on the
     * binding point
     */
    for (j = 0; j < groups_num; j++) {
        cur_group = groups[j];
        if (!flex_acl_db_is_acl_group(cur_group)) {
            /* Get the info about the ACL from the DB */
            rc = flex_acl_db_acl_get(cur_group, &acl_table);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB for system group clean\n", cur_group);
                goto out;
            }
            cur_group = acl_table->adhoc_acl_group_id;
        }

        rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, cur_group);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL: Failed in removing binding point groups of RIF [0x%x] direction [%u]\n", rif,
                       direction);
            goto out;
        }
        rc = flex_acl_db_get_acl_group(cur_group, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: group get error for group [%d]\n", groups[j]);
            goto out;
        }
        rc = flex_acl_db_group_unbind_rif(acl_group, bind_point_id.rif_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to mark RIF [0x%x] unbound to group [%d] in DB\n",
                       bind_point_id.rif_id,
                       groups[j]);
            goto out;
        }
        rc = flex_acl_db_rif_acl_group_unbind(rif, direction, groups[j]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from RIF [0x%x] in DB\n", groups[j], rif);
            goto out;
        }
    }

    if (clear_system == TRUE) {
        /* Check if the binding point is bound to a bind-point specific system ACL and get the group id */
        unbind_acl_id = FLEX_ACL_INVALID_ACL_ID;
        rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &unbind_acl_id);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL: Failed to find system ACL on RIF [%u]\n", rif);
            goto out;
        }

        if (unbind_acl_id != FLEX_ACL_INVALID_ACL_ID) {
            rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, unbind_acl_id);
            if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("ACL: Failed in removing binding point groups of RIF [0x%x] direction [%u]\n", rif,
                           direction);
                goto out;
            }
        }

        /* [DECAP_SYSTEM_ACL] Workaround :
         *  Please read the commit message for this change first.
         *
         *  The code below assumes that only system ACLs that can be bound to RIFs in
         *  the ingress direction are decap system ACLs.
         *
         *  If the RIF is not decap RIF, SDK doesn't bind decap system ACLs to it.
         *
         *  Therefore the code below checks whether the RIF is a subject for this global system group binding.
         */
        if (direction == SX_ACL_DIRECTION_RIF_INGRESS) {
            rc = sdk_rif_impl_decap_check(rif, &is_decap_rif);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to check if the RIF[%u] is a decap RIF, rc = %s\n",
                           rif,
                           sx_status_str(rc));
                goto out;
            }

            check_global_system_acl_group = is_decap_rif;
        }

        /* Check if global system ACL group if present */
        if (check_global_system_acl_group == TRUE) {
            unbind_acl_id = FLEX_ACL_INVALID_ACL_ID;
            rc = flex_acl_db_get_system_acl_group(direction, &unbind_acl_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to get system group, RIF binding [%u]\n", rif);
                goto out;
            }

            if (unbind_acl_id != FLEX_ACL_INVALID_ACL_ID) {
                rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, unbind_acl_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("ACL: Failed in removing binding point groups of RIF [0x%x] direction [%u]\n", rif,
                               direction);
                    goto out;
                }
            }

            if ((unbind_acl_id != FLEX_ACL_INVALID_ACL_ID) &&
                (attribs_id_from_rif == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
                /* Get bind attributes from system */
                rc = flex_acl_get_bind_attribs(unbind_acl_id, &attribs_id_from_rif, NULL, NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error when trying to get bind attributes id for system group id\n");
                    goto out;
                }
            }
        }
    }

    if (attribs_id_from_rif == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_attribs_get(attribs_id_from_rif, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id [%u] RIF [%u] direction [%u]\n", attribs_id_from_rif,
                   rif, direction);
        goto out;
    }

    /* Update the aggregated binding group according to current bindings,
     * and bind to HW accordingly */
    rc = __flex_acl_aggregate_rif_acl_groups(rif, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear bindings in aggregate groups for RIF [0x%x].\n", rif);
        goto out;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* If there were more than one group bound to the port, unbind
         * of one of the group leads to a new HW binding.
         * for example port bound to {g1,g2,g3} - unbind g2 leads to binding {g1.g3} */
        rc = flex_acl_db_rif_bind(rif, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating RIF HW ACL group in DB RIF [0x%x].\n", rif);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    } else {
        /* RIF true unbind - DB update only since unbinding was done
         * in the aggregation phase */
        rc = flex_acl_db_rif_unbind(rif, direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: unbind group [0x%x] from RIF [0x%x]\n", attribs_id_from_rif, rif);
            goto out;
        }
    }

    for (j = 0; j < groups_num; j++) {
        /* It could be that a dedicated group was created for binding this port.
         * In such cases the dedicated group should be removed if the ACL is not
         * bound anymore.
         */

        if (flex_acl_db_is_acl_group(groups[j])) {
            rc = flex_acl_db_get_acl_id_for_unbind(groups[j], &unbind_acl_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed get ACL id for unbind operation, group_id: %u\n", groups[j]);
                goto out;
            }
        } else {
            unbind_acl_id = groups[j];
        }

        if (!flex_acl_db_is_acl_group(unbind_acl_id)) {
            rc = flex_acl_clean_adhoc_acl_group(unbind_acl_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at clear port binding\n",
                           unbind_acl_id);
                goto out;
            }
        }
    }

out:
    return rc;
}

/* This will clear all bindings
 * In RIF termination scenario, it is also desired to clear system ACLs
 * bound to that RIF.
 */
sx_status_t flex_acl_clear_rif_binding(sx_rif_id_t rif, boolean_t clear_system)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t directions[] = {SX_ACL_DIRECTION_RIF_INGRESS, SX_ACL_DIRECTION_RIF_EGRESS};
    uint32_t           i = 0;

    SX_LOG_ENTER();

    SX_LOG_DBG("RIF [%#x]\n", rif);

    /* Unbind ingress and then egress */
    for (i = 0; i < (int)(sizeof(directions) / sizeof(directions[0])); i++) {
        rc = __flex_acl_clear_rif_direction(rif, directions[i], clear_system);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/************************************************
 *  VLAN GROUP Handling Functions
 ***********************************************/
sx_status_t flex_acl_vlan_group_bind_internal(sx_acl_vlan_group_t vlan_group,
                                              sx_acl_id_t         group_id,
                                              boolean_t           write_to_reg)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_bind_point_id            bind_point = {.vlan_group_id = vlan_group};
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_direction_t                direction = SX_ACL_DIRECTION_LAST;
    flex_acl_db_acl_group_t          *acl_group = NULL;

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: cannot get group [%u]\n", group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("Invalid bind attributes given to bind VLAN group %u\n", vlan_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_attribs_get(acl_group->bind_attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", acl_group->bind_attribs_id);
        goto out;
    }

    direction = VLAN_GROUP_DIRECTION(acl_group->direction);

    if (write_to_reg) {
        rc = flex_acl_db_binding_point_group_add(direction, bind_point, acl_group->group_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto rollback;
        }

        /* Update the aggregated binding group according to current bindings,
         * and bind to HW accordingly */
        rc = __flex_acl_aggregate_vlan_group_acl_groups(vlan_group, bind_attribs, TRUE, &new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in binding aggregate groups for VLAN group [0x%x].\n", vlan_group);
            goto rollback;
        }

        /* Update DB that VLAN group was bound to attributes */
        rc = flex_acl_db_vlan_group_bind(vlan_group, acl_group->direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    }

    goto out;

rollback:
    if (write_to_reg) {
        rb_rc = flex_acl_db_binding_point_group_delete(direction, bind_point, acl_group->group_id);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at removing group from binding point VLAN group [%u]\n", vlan_group);
        }
    }
out:
    return rc;
}

sx_status_t flex_acl_bind_vlan_group_internal(sx_api_acl_bind_params_t *params, boolean_t rebinding)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_st = SX_STATUS_SUCCESS;
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_group_t *acl_group = NULL;
    sx_acl_direction_t       direction = SX_ACL_DIRECTION_LAST;
    boolean_t                write_to_reg = TRUE;

    UNUSED_PARAM(rebinding);

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_validate_acl_vlan_group_bind(params->cmd, params->vlan_group, params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to validate bind ACL [0x%x] to VLAN group [%u]in DB\n",
                   params->acl_id,
                   params->vlan_group);
        goto out;
    }

    rc = __flex_acl_group_get(params->acl_id, &group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    rc = flex_acl_group_validate(group_id, &acl_group, &write_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    /* Verify that the group direction is indeed for VLAN */
    if (acl_group->direction != SX_ACL_DIRECTION_INGRESS) {
        SX_LOG_ERR("ACL group [%u] has direction [%u] and cannot be bound to VLAN.\n", group_id, acl_group->direction);
        rc = SX_STATUS_ERROR;
        goto rollback_create_adhoc_group;
    }

    /* Update logic DB level binding */
    rc = flex_acl_db_group_bind_vlan_group(acl_group, params->vlan_group);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_create_adhoc_group;
    }

    rc = flex_acl_db_vlan_group_acl_group_bind(params->vlan_group,
                                               acl_group->direction,
                                               params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_group_bind;
    }

    rc = flex_acl_vlan_group_bind_internal(params->vlan_group, acl_group->group_id, write_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind VLAN group to bind group id [0x%x]\n", acl_group->group_id);
        goto rollback_vlan_group_bind_group;
    }

    goto out;

rollback_vlan_group_bind_group:
    rb_st = flex_acl_db_vlan_group_acl_group_unbind(params->vlan_group, direction, params->acl_id);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error in rollback, err %s\n", sx_status_str(rb_st));
    }
rollback_group_bind:
    rb_st = flex_acl_db_group_unbind_vlan_group(acl_group, params->vlan_group);
    if (rb_st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error in rollback, err %s\n", sx_status_str(rb_st));
    }
rollback_create_adhoc_group:
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rb_st = flex_acl_clean_adhoc_acl_group(params->acl_id, TRUE);
        if (SX_CHECK_FAIL(rb_st)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
        }
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_vlan_group_unbind_internal(sx_acl_id_t                group_id,
                                                sx_acl_vlan_group_t        vlan_group,
                                                flex_acl_bind_attribs_id_t attribs_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_st = SX_STATUS_SUCCESS;
    boolean_t                         is_bound = FALSE;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_direction_t                direction = SX_ACL_DIRECTION_RIF_INGRESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_attribs_get(attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", attribs_id);
        goto out;
    }

    /* Validate that VLAN group is bound to the group bind attributes */
    rc = flex_acl_db_attribs_is_vlan_group_bound(attribs_id, vlan_group, &is_bound);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to get if VLAN group %u is bound\n", vlan_group);
        goto out;
    }

    if (!is_bound) {
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    bind_point_id.vlan_group_id = vlan_group;
    direction = VLAN_GROUP_DIRECTION(bind_attribs->direction);
    rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, group_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* Update the aggregated binding group according to current bindings,
     * and bind to HW accordingly */
    rc = __flex_acl_aggregate_vlan_group_acl_groups(vlan_group, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unbind group [0x%x] in aggregate groups for VLAN group [0x%x].\n", group_id, vlan_group);
        goto rollback;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* If there were more than one group bound to the port, unbind
         * of one of the group leads to a new HW binding.
         * for example port bound to {g1,g2,g3} - unbind g2 leads to binding {g1.g3} */
        rc = flex_acl_db_vlan_group_bind(vlan_group, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating port's HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    } else {
        /* VLAN group true unbind - DB update only since unbinding was done
         * in the aggregation phase */
        rc = flex_acl_db_vlan_group_unbind(vlan_group, direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: unbind group [0x%x] from VLAN group [0x%x]\n", group_id, vlan_group);
            goto out;
        }
    }

    goto out;

rollback:
    rb_st = flex_acl_db_binding_point_group_add(direction, bind_point_id, group_id);
    if ((rb_st != SX_STATUS_SUCCESS) && (rb_st != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed to rollback and add group[0x%x] to VLAN group [0x%x]\n", group_id, vlan_group);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_unbind_vlan_group_internal(sx_api_acl_bind_params_t * params)
{
    flex_acl_bind_attribs_id_t attribs_id_from_vlan = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_db_acl_table_t   *acl_table = NULL;
    flex_acl_db_acl_group_t   *acl_group = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Check if ACL/group is indeed bound to VLAN group */
    group_id = params->acl_id;
    if (!flex_acl_db_is_acl_group(group_id)) {
        /* Get the info about the ACL form the DB */
        rc = flex_acl_db_acl_get(group_id, &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB\n", group_id);
            goto out;
        }
        group_id = acl_table->adhoc_acl_group_id;
        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    if (flex_acl_db_is_vlan_group_bound_group(params->vlan_group, acl_group->direction,
                                              params->acl_id) == FALSE) {
        SX_LOG_ERR("ACL [0x%x] is not bound to VLAN group [0x%x]\n", params->acl_id,
                   params->vlan_group);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    direction = VLAN_GROUP_DIRECTION(params->acl_direction);

    /* After validation is done, UNBIND command means clearing the VLAN group's binding,
     * So call clear binding method
     */
    if (params->cmd == SX_ACCESS_CMD_UNBIND) {
        rc = __flex_acl_clear_vlan_group_direction(params->vlan_group,
                                                   direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error in VLAN group [%u] unbind\n", params->vlan_group);
        }
        goto out;
    }

    /* We will first retrieve the HW group of the ACL ID that is being unbound */
    rc = flex_acl_get_bind_attribs(params->acl_id, &attribs_id_from_vlan, NULL, NULL);
    if ((rc != SX_STATUS_SUCCESS) || (attribs_id_from_vlan == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Error when trying to get bind attributes id for VLAN group [%u]\n", params->vlan_group);
        goto out;
    }

    /* Get the HW group actually bound to this VLAN group */
    rc = flex_acl_db_get_vlan_group_bind(params->vlan_group, direction, &attribs_id_from_vlan);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for VLAN group %u, error[%s]\n", params->vlan_group,
                   sx_status_str(rc));
        goto out;
    }

    if ((rc != SX_STATUS_ENTRY_NOT_FOUND) && (attribs_id_from_vlan != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) &&
        (acl_group->acl_num > 0)) {
        rc = flex_acl_vlan_group_unbind_internal(group_id, params->vlan_group, attribs_id_from_vlan);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to unbind VLAN group [%u] from bind group id [0x%x] error [%s]\n",
                       params->vlan_group,
                       params->acl_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    /* Unlink group from VLAN group */
    rc = flex_acl_db_group_unbind_vlan_group(acl_group, params->vlan_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to mark VLAN group [0x%x] unbound to group [%d] in DB\n", params->vlan_group,
                   group_id);
        goto out;
    }

    /* Unlink ACL ID from VLAN group */
    rc = flex_acl_db_vlan_group_acl_group_unbind(params->vlan_group, direction, params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from VLAN group [0x%x] in DB\n",
                   params->acl_id,
                   params->vlan_group);
        goto out;
    }

    /* Remove bind attributes from group and destroy group if was direct acl binding */
    if (!flex_acl_db_is_acl_group(params->acl_id)) {
        rc = flex_acl_clean_adhoc_acl_group(params->acl_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at VLAN group [%u] unbind\n",
                       params->acl_id,
                       params->vlan_group);
            goto out;
        }
    }

    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_clear_vlan_group_direction(sx_acl_vlan_group_t vlan_group, sx_acl_direction_t direction)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                       groups[rm_resource_global.acl_groups_size_max];
    sx_acl_id_t                       unbind_acl_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                          groups_num = rm_resource_global.acl_groups_size_max;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t        attribs_id_from_vlan = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          j = 0;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    sx_acl_id_t                       cur_group = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_table_t          *acl_table = NULL;

    bind_point_id.vlan_group_id = vlan_group;

    /* Get user groups bound to the VLAN group */
    direction = VLAN_GROUP_DIRECTION(direction);
    rc = flex_acl_db_vlan_group_bound_groups_get(vlan_group, direction, groups, &groups_num);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed in getting binding point groups VLAN_GROUP [%u]\n", vlan_group);
        goto out;
    }

    /* Get the currently bound HW group */
    attribs_id_from_vlan = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    rc = flex_acl_db_get_vlan_group_bind(vlan_group, direction, &attribs_id_from_vlan);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to get bind attributes for VLAN group %u , error[%s]\n", vlan_group,
                   sx_status_str(rc));
        goto out;
    }

    /* Go over all configured user groups and remove them per this binding point
     * This is imitating a user unbind of all the groups currently bound on the
     * binding point
     */
    for (j = 0; j < groups_num; j++) {
        cur_group = groups[j];
        if (!flex_acl_db_is_acl_group(cur_group)) {
            /* Get the info about the ACL form the DB */
            rc = flex_acl_db_acl_get(cur_group, &acl_table);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB for group clean\n", cur_group);
                goto out;
            }
            cur_group = acl_table->adhoc_acl_group_id;
        }

        rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, cur_group);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL: Failed in removing binding point groups of VLAN group [0x%x] direction [%u]\n",
                       vlan_group, USER_GIVEN_DIRECTION(direction));
            goto out;
        }

        rc = flex_acl_db_get_acl_group(cur_group, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: group get error for group [%d]\n", groups[j]);
            goto out;
        }

        rc = flex_acl_db_group_unbind_vlan_group(acl_group, bind_point_id.vlan_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to mark VLAN group [0x%x] unbound to group [%d] in DB\n",
                       bind_point_id.vlan_group_id,
                       groups[j]);
            goto out;
        }

        rc = flex_acl_db_vlan_group_acl_group_unbind(vlan_group, USER_GIVEN_DIRECTION(direction), groups[j]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to unbind ACL ID [0x%x] from VLAN group [0x%x] in DB\n",
                       groups[j], vlan_group);
            goto out;
        }
    }

    if (attribs_id_from_vlan == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_attribs_get(attribs_id_from_vlan, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id [%u] VLAN group [%u] direction [%u]\n",
                   attribs_id_from_vlan, vlan_group, USER_GIVEN_DIRECTION(direction));
        goto out;
    }

    /* Update the aggregated binding group according to current bindings,
     * and bind to HW accordingly */
    rc = __flex_acl_aggregate_vlan_group_acl_groups(vlan_group, bind_attribs, FALSE, &new_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear bindings in aggregate groups for VLAN group [0x%x].\n", vlan_group);
        goto out;
    }

    if (new_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        /* If there were more than one group bound to the port, unbind
         * of one of the group leads to a new HW binding.
         * for example port bound to {g1,g2,g3} - unbind g2 leads to binding {g1.g3} */
        rc = flex_acl_db_vlan_group_bind(vlan_group, direction, new_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in updating HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
            /* This Error is FATAL - no rollback */
            goto out;
        }
    } else {
        /* VLAN group true unbind - DB update only since unbinding was done
         * in the aggregation phase */
        rc = flex_acl_db_vlan_group_unbind(vlan_group, USER_GIVEN_DIRECTION(direction));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: unbind group [0x%x] from VLAN group [0x%x]\n", attribs_id_from_vlan, vlan_group);
            goto out;
        }
    }

    for (j = 0; j < groups_num; j++) {
        /* It could be that a dedicated group was created for binding this port.
         * In such cases the dedicated group should be removed if the ACL is not
         * bound anymore.
         */

        if (flex_acl_db_is_acl_group(groups[j])) {
            rc = flex_acl_db_get_acl_id_for_unbind(groups[j], &unbind_acl_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed get ACL id for unbind operation, group_id: %u\n", groups[j]);
                goto out;
            }
        } else {
            unbind_acl_id = groups[j];
        }

        if (!flex_acl_db_is_acl_group(unbind_acl_id)) {
            rc = flex_acl_clean_adhoc_acl_group(unbind_acl_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to clean dedicated group for ACL [%u], at clear port binding\n",
                           unbind_acl_id);
                goto out;
            }
        }
    }

out:
    return rc;
}

sx_status_t flex_acl_bind_vlan_group_get(sx_api_acl_bind_get_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_vlan_group_bound_groups_get(params->vlan_group,
                                                 params->acl_direction,
                                                 params->acl_id,
                                                 &params->acl_ids_num);

out:
    SX_LOG_EXIT();
    return rc;
}

/************************************************
 *  Rule Rebind Functions
 ***********************************************/
/* This function should be called only if a bind attribute became empty or it was empty and now it has ACLs.
 * In such a case we need to remove goto rules/ports/vlans/rifs that are bound to this bind attribute */
sx_status_t flex_acl_bind_update_rules_and_bind_points(sx_acl_id_t                group_id,
                                                       flex_acl_bind_attribs_id_t bind_attribs_id,
                                                       sx_acl_direction_t         direction,
                                                       boolean_t                  bind)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t               *rule_id_p = NULL;
    flex_acl_db_flex_rule_t          *rule_p = NULL;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    flex_acl_db_group_bind_attribs_t *point_attribs = NULL;
    sx_rif_id_t                       rif = 0;
    sx_acl_vlan_group_t               vlan_group = 0;
    cl_list_iterator_t                iter = NULL;
    cl_list_iterator_t                iter_end = NULL;
    sx_port_id_t                      log_port = 0;
    flex_acl_bind_point_id            bind_point_id = {0};
    flex_acl_bind_attribs_id_t        new_point_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t        attribs_id_from_point = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    boolean_t                         is_lag = FALSE;
    sx_acl_rbb_rule_offset_e          rbb_rule = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    rc = flex_acl_db_attribs_get(bind_attribs_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", bind_attribs_id);
        goto out;
    }
    /* Handle GOTO rules */
    /* For each rule in rule list - rebind it*/
    iter = cl_list_head(&(attribs->bound_goto_rule));
    iter_end = cl_list_end(&(attribs->bound_goto_rule));
    while (iter != iter_end) {
        rule_id_p = (flex_acl_rule_id_t*)cl_list_obj(iter);

        rc = flex_acl_db_get_rule_by_offset(rule_id_p->region_id, rule_id_p->offset, &rule_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at get rule by offset, region id[%x], rule offset[%u]\n",
                       rule_p->region_id,
                       rule_p->offset);
            goto out;
        }
        /* The rule will be rewritten with the correctly if bind attributes exist r not */
        rc = flex_acl_hw_goto_action_update(rule_p, TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at update goto action, region_id[%x] offset [%u] \n", rule_p->region_id, rule_p->offset);
            goto out;
        }
        /* Head has now been modified, goto the next rule */
        iter = cl_list_next(iter);
    }

    if (flex_acl_is_port_direction(direction) == TRUE) {
        /* Handle port binds*/
        iter = cl_list_head(&(acl_group->bound_log_ports));
        iter_end = cl_list_end(&(acl_group->bound_log_ports));
        while (iter != iter_end) {
            log_port = (intptr_t)cl_list_obj(iter);
            is_lag = FALSE;
            if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
                is_lag = TRUE;
            }
            bind_point_id.port_id = log_port;
            if (bind) {
                rc = flex_acl_db_binding_point_group_add(direction, bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed adding bind attributes for port [0x%x]\n", log_port);
                    iter = cl_list_next(iter);
                    continue;
                }
                point_attribs = attribs;
            } else {
                rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed removing bind attributes for port [0x%x]\n", log_port);
                    iter = cl_list_next(iter);
                    continue;
                }

                /* Need to provide current bind attributes */
                rc = __flex_acl_get_port_bind_attribs(log_port, direction, &attribs_id_from_point);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed to get bind attributes for port %u, error[%s]\n", log_port,
                               sx_status_str(rc));
                    goto out;
                }

                if (attribs_id_from_point == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    point_attribs = attribs;
                } else {
                    rc = flex_acl_db_attribs_get(attribs_id_from_point, &point_attribs);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error getting bind attributes id %u\n", attribs_id_from_point);
                        goto out;
                    }
                }
            }
            /* Update the aggregated binding group according to current bindings,
             * and bind to HW accordingly */
            rc = __flex_acl_aggregate_port_acl_groups(log_port, point_attribs, bind, &new_point_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" ACL: Failed updating bindings for port [0x%x]\n", log_port);
                iter = cl_list_next(iter);
                continue;
            }
            /* Update ports DB that port was bound to attributes */
            rc = flex_acl_db_port_bind(bind_point_id.port_id, direction, new_point_attribs_id, is_lag);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
                /* This Error is FATAL - no rollback */
                goto out;
            }
            if (!bind) {
                if (new_point_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    rc = flex_acl_db_port_unbind(bind_point_id.port_id, direction, is_lag);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", log_port);
                        /* This Error is FATAL - no rollback */
                        goto out;
                    }
                }
                rc = flex_acl_db_attribs_unbind_log_port(attribs->bind_id, bind_point_id.port_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed in updating port's HW ACL group in DB port [0x%x].\n", bind_point_id.port_id);
                    /* This Error is FATAL - no rollback for the unbind*/
                    goto out;
                }
                rc = SX_STATUS_SUCCESS;
            }
            iter = cl_list_next(iter);
        }
        /* Handle VLAN group binds */
        iter = cl_list_head(&(acl_group->bound_vlan_groups));
        iter_end = cl_list_end(&(acl_group->bound_vlan_groups));
        while (iter != iter_end) {
            vlan_group = (intptr_t)cl_list_obj(iter);
            bind_point_id.vlan_group_id = vlan_group;
            if (bind) {
                rc = flex_acl_db_binding_point_group_add(VLAN_GROUP_DIRECTION(direction), bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed adding bind attributes for VLAN group [0x%x]\n", vlan_group);
                    iter = cl_list_next(iter);
                    continue;
                }
                point_attribs = attribs;
            } else {
                rc = flex_acl_db_binding_point_group_delete(VLAN_GROUP_DIRECTION(direction), bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed removing bind attributes for VLAN group [0x%x]\n", vlan_group);
                    iter = cl_list_next(iter);
                    continue;
                }

                /* Need to provide current bind attributes */
                rc = flex_acl_db_get_vlan_group_bind(vlan_group, direction, &attribs_id_from_point);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed to get bind attributes for VLAN group [0x%x], error[%s]\n", vlan_group,
                               sx_status_str(rc));
                    goto out;
                }

                if (attribs_id_from_point == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    point_attribs = attribs;
                } else {
                    rc = flex_acl_db_attribs_get(attribs_id_from_point, &point_attribs);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error getting bind attributes id %u\n", attribs_id_from_point);
                        goto out;
                    }
                }
            }
            /* Update the aggregated binding group according to current bindings,
             * and bind to HW accordingly */
            rc = __flex_acl_aggregate_vlan_group_acl_groups(vlan_group, point_attribs, bind, &new_point_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" ACL: Failed updating bindings for VLAN group [0x%x]\n", vlan_group);
                iter = cl_list_next(iter);
                continue;
            }
            /* Update DB that VLAN group was bound to attributes */
            rc = flex_acl_db_vlan_group_bind(vlan_group, direction, new_point_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
                /* This Error is FATAL - no rollback */
                goto out;
            }
            if (!bind) {
                if (new_point_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    rc = flex_acl_db_vlan_group_unbind(vlan_group, direction);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed in unbind HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
                        /* This Error is FATAL - no rollback */
                        goto out;
                    }
                }

                rc = flex_acl_db_attribs_unbind_vlan_group(attribs->bind_id, vlan_group);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed in updating HW ACL group in DB VLAN group [0x%x].\n", vlan_group);
                    /* This Error is FATAL - no rollback for the unbind*/
                    goto out;
                }
                rc = SX_STATUS_SUCCESS;
            }
            iter = cl_list_next(iter);
        }
    } else {
        /* Handle RIF binds */
        iter = cl_list_head(&(acl_group->bound_rifs));
        iter_end = cl_list_end(&(acl_group->bound_rifs));
        while (iter != iter_end) {
            rif = (intptr_t)cl_list_obj(iter);
            bind_point_id.rif_id = rif;
            if (bind) {
                rc = flex_acl_db_binding_point_group_add(direction, bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed adding bind attributes for RIF [0x%x]\n", rif);
                    iter = cl_list_next(iter);
                    continue;
                }
                point_attribs = attribs;
            } else {
                rc = flex_acl_db_binding_point_group_delete(direction, bind_point_id, group_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    /* Programming error */
                    SX_LOG_ERR(" ACL: Failed removing bind attributes for RIF [0x%x]\n", rif);
                    iter = cl_list_next(iter);
                    continue;
                }

                /* Need to provide current bind attributes */
                rc = flex_acl_db_get_rif_bind(rif, direction, &attribs_id_from_point);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed to get bind attributes for RIF [0x%x], error[%s]\n", rif,
                               sx_status_str(rc));
                    goto out;
                }

                if (attribs_id_from_point == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    point_attribs = attribs;
                } else {
                    rc = flex_acl_db_attribs_get(attribs_id_from_point, &point_attribs);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error getting bind attributes id %u\n", attribs_id_from_point);
                        goto out;
                    }
                }
            }
            /* Update the aggregated binding group according to current bindings,
             * and bind to HW accordingly */
            rc = __flex_acl_aggregate_rif_acl_groups(rif, point_attribs, bind, &new_point_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" ACL: Failed updating bindings for RIF [0x%x]\n", rif);
                iter = cl_list_next(iter);
                continue;
            }
            /* Update RIF DB that RIF was bound to attributes */
            rc = flex_acl_db_rif_bind(rif, direction, new_point_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in updating RIF HW ACL group in DB RIF [0x%x].\n", rif);
                /* This Error is FATAL - no rollback */
                goto out;
            }
            if (!bind) {
                if (new_point_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                    rc = flex_acl_db_rif_unbind(rif, direction);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed in unbind RIF HW ACL group in DB RIF [0x%x].\n", rif);
                        /* This Error is FATAL - no rollback */
                        goto out;
                    }
                }

                rc = flex_acl_db_attribs_unbind_rif(attribs->bind_id, bind_point_id.rif_id);
                if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Failed in updating RIF HW ACL group in DB RIF [0x%x].\n", bind_point_id.rif_id);
                    /* This error is FATAL - no rollback for the unbind*/
                    goto out;
                }
                rc = SX_STATUS_SUCCESS;
            }
            iter = cl_list_next(iter);
        }
    }

    /* Handle RBB rules */
    iter = cl_list_head(&(acl_group->bound_rbb_rules));
    iter_end = cl_list_end(&(acl_group->bound_rbb_rules));
    while (iter != iter_end) {
        rbb_rule = (sx_acl_rbb_rule_offset_e)cl_list_obj(iter);

        rc = flex_acl_rule_based_binding_group_update(group_id,
                                                      (bind) ? bind_attribs_id : FLEX_ACL_INVALID_BIND_ATTRIBS_ID,
                                                      direction,
                                                      rbb_rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update RBB for modified ACL group [0x%x]\n", group_id);
            goto out;
        }
        /* Head has now been modified, goto the next rule */
        iter = cl_list_next(iter);
    }


    goto out;

out:
    SX_LOG_EXIT();
    return (rc);
}

/************************************************
 *  System Group Functions
 ***********************************************/
sx_status_t flex_acl_allocate_adhoc_acl_group(sx_acl_id_t acl_id, sx_acl_id_t        *group_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table = NULL;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(group_id, "group_id"))) {
        goto out;
    }

    SX_LOG_ENTER();

    /* Check if this an ACL or a group */
    if (flex_acl_db_is_acl_group(acl_id)) {
        SX_LOG_ERR("ACL: ACL id [%u] is already a group\n", acl_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_acl_get(acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB for dedicated group creation\n", acl_id);
        goto out;
    }

    if (acl_table->direction == SX_ACL_DIRECTION_MULTI_POINTS_E) {
        SX_LOG_ERR("ACL: Cannot create an ad hoc ACL group for ACL table [%u] with the %s direction.\n",
                   acl_id,
                   sx_acl_direction_str(acl_table->direction));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Check if a system group already exists for this ACL */
    if (acl_table->adhoc_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        *group_id = acl_table->adhoc_acl_group_id;
        goto out;
    }

    /* Allocate a system group and a binding attributes for this ACL */
    rc = __flex_acl_allocate_group(group_id, acl_table->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to allocate group for direction [%u]\n", acl_table->direction);
        goto out;
    }
    /* Write the group to HW */
    rc = __flex_acl_group_edit(*group_id, &acl_id, 1);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to update group id %d \n", *group_id);
        goto error;
    }
    /* Set the group for the ACL */
    acl_table->adhoc_acl_group_id = *group_id;
    goto out;

error:
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_free_group(*group_id))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_clean_adhoc_acl_group(sx_acl_id_t acl_id, boolean_t fail_if_bound)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table = NULL;
    flex_acl_db_acl_group_t *acl_group = NULL;
    boolean_t                is_bound = FALSE;

    SX_LOG_ENTER();

    /* If this is a group just return */
    if (flex_acl_db_is_acl_group(acl_id)) {
        goto out;
    }
    /* Get the info about the ACL form the DB */
    rc = flex_acl_db_acl_get(acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get ACL [%u] from DB for system group clean\n", acl_id);
        goto out;
    }
    /* We should have a system group id here */
    if (acl_table->adhoc_acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("ACL: ACL [%u] doesn't have a system group id\n", acl_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_get_acl_group(acl_table->adhoc_acl_group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get ACL group [%u] from DB for system group clean\n",
                   acl_table->adhoc_acl_group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ACL: Invalid bind attributes for system group [%u]\n", acl_table->adhoc_acl_group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Check if the group is bound. If so we leave the group be */
    rc = flex_acl_db_attribs_is_bound(acl_group->bind_attribs_id, &is_bound);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find if bind attributes [%u] is bound\n", acl_group->bind_attribs_id);
        goto out;
    }
    if (is_bound) {
        if (fail_if_bound) {
            SX_LOG_ERR("ACL: Dedicated group for ACL [%u] is unexpectedly bound\n", acl_id);
            rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        }
        goto out;
    }

    /* clean acl from system group */
    /* coverity[callee_ptr_arith] */
    rc = flex_acl_db_update_acl_group(acl_table->adhoc_acl_group_id, &acl_table->acl_id, 0);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to update group [%u]\n", acl_table->adhoc_acl_group_id);
        goto out;
    }

    /* clean acl from steam group */
    rc = flex_acl_db_acl_remove_from_group(acl_table->acl_id, acl_table->adhoc_acl_group_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to remove ACL [%u] from group [%u]\n", acl_table->acl_id, acl_table->adhoc_acl_group_id);
        goto update_group;
    }

    rc = __flex_acl_free_group(acl_table->adhoc_acl_group_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to free group [%u]\n", acl_table->adhoc_acl_group_id);
        goto update_acl;
    }

    acl_table->adhoc_acl_group_id = FLEX_ACL_INVALID_ACL_ID;

    goto out;

update_acl:
    rb_rc = flex_acl_db_acl_add_to_group(acl_table->acl_id, acl_table->adhoc_acl_group_id);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
update_group:
    rb_rc = flex_acl_db_update_acl_group(acl_table->adhoc_acl_group_id, &acl_table->acl_id, 1);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}


/************************************************
 *  General Exported Functions
 ***********************************************/
sx_status_t flex_acl_create_bind_attribs(sx_acl_id_t group_id, flex_acl_bind_attribs_id_t * bind_attribs_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(bind_attribs_id, "bind_attribs_id"))) {
        goto out;
    }
    SX_LOG_ENTER();

    /* if acl id is not group id */
    if (!flex_acl_db_is_acl_group(group_id)) {
        SX_LOG_ERR("ACL: the provided group_id [%d] is not a valid group\n", group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Get associated group */
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ACL: The group ID [%u] already contain bind attributes [%u]\n",
                   group_id,
                   acl_group->bind_attribs_id);
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    /* Allocate the bind attributes */
    rc = flex_acl_db_attribs_allocate(&(acl_group->bind_attribs_id), acl_group->direction, group_id, TRUE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed allocation DB bind attributes for group [%u]\n", group_id);
        goto out;
    }
    *bind_attribs_id = acl_group->bind_attribs_id;

    goto out;

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_remove_bind_attribs(sx_acl_id_t group_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;
    boolean_t                is_bound = FALSE;

    SX_LOG_ENTER();

    /* if acl id is not group id */
    if (!flex_acl_db_is_acl_group(group_id)) {
        SX_LOG_ERR("ACL: the provided group_id [%d] is not a valid group\n", group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Get associated group */
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", group_id);
        goto out;
    }

    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ERROR: The group ID [%u] doesn't contain bind attributes\n", group_id);
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    /* if attributes are bound to anything - it can't be deleted */
    rc = flex_acl_db_attribs_is_bound(acl_group->bind_attribs_id, &is_bound);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to get if bind attributes id [%d] are bound\n",
                   acl_group->bind_attribs_id);
        goto out;
    }

    if (is_bound) {
        SX_LOG_ERR("Bind attribute [%u] is bound and cannot be removed\n", acl_group->bind_attribs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Free bind attributes and  */
    rc = flex_acl_db_attribs_free(acl_group->bind_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to free bind attributes from db, [bind attributes ID = %u]\n", acl_group->bind_attribs_id);
        goto out;
    }
    /* update group */
    acl_group->bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_get_bind_attribs(sx_acl_id_t                 acl_id,
                                      flex_acl_bind_attribs_id_t *bind_attribs_id,
                                      sx_acl_direction_t         *direction,
                                      sx_acl_id_t                *group_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;
    flex_acl_db_acl_table_t *acl_table = NULL;
    sx_acl_id_t              related_group_id = FLEX_ACL_INVALID_ACL_ID;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(bind_attribs_id, "bind_attribs_id"))) {
        goto out;
    }
    SX_LOG_ENTER();

    /* If acl id is not a group id */
    if (!flex_acl_db_is_acl_group(acl_id)) {
        rc = flex_acl_db_acl_get(acl_id, &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: the provided group_id [%d] is not a valid group\n", acl_id);
            goto out;
        }
        if (acl_table->adhoc_acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
            SX_LOG_ERR("ACL: the provided ACL [%u] does not have a group\n", acl_id);
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        related_group_id = acl_table->adhoc_acl_group_id;
    } else {
        related_group_id = acl_id;
    }
    /* Get associated group */
    rc = flex_acl_db_get_acl_group(related_group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: group get error for group [%d]\n", related_group_id);
        goto out;
    }
    *bind_attribs_id = acl_group->bind_attribs_id;
    if (direction != NULL) {
        *direction = acl_group->direction;
    }
    if (group_id != NULL) {
        *group_id = related_group_id;
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

/* Apply bubble sort on groups list so they are ordered
 * according to their priority. Higher priority is first.
 */
void __flex_acl_sort_groups_by_prio(flex_acl_db_acl_group_t **groups, uint32_t groups_num)
{
    flex_acl_db_acl_group_t *tmp_group;
    uint32_t                 i, j, maxi;

    for (j = 0; j < groups_num; j++) {
        maxi = j;
        for (i = j + 1; i < groups_num; i++) {
            if (groups[i]->group_prio > groups[maxi]->group_prio) {
                maxi = i;
            }
        }
        tmp_group = groups[j];
        groups[j] = groups[maxi];
        groups[maxi] = tmp_group;
    }
}

/* Prepare a final list of ACL IDs to be bound to.
 * This includes system ACLs, commit ACLs, linked ACL groups, binding groups with priorities.
 */
sx_status_t __flex_acl_aggregate_groups(sx_acl_id_t          *group_id,
                                        uint32_t              group_num,
                                        sx_acl_direction_t    direction,
                                        acl_id_group_entry_t *acl_ids_prepared,
                                        uint32_t             *prepared_ids_num)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *groups[SPECTRUM_ACL_GROUPS_SIZE_MAX];
    flex_acl_db_acl_group_t *system_group = NULL;
    flex_acl_db_acl_group_t *current_acl_group = NULL;
    sx_acl_id_t              groups_run_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                 i = 0, acl_idx = 0;
    uint32_t                 prepare_i = 0;
    sx_acl_id_t              commit_acl_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                is_parallel = FALSE;
    boolean_t                next_group_exists = FALSE;

    SX_LOG_ENTER();

    /* Get all groups */
    for (i = 0; i < group_num; i++) {
        /* For each group use the group HEAD */
        rc = flex_acl_db_get_groups_head(group_id[i], &groups_run_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id[i]);
            goto out;
        }

        rc = flex_acl_db_get_acl_group(groups_run_id, &groups[i]);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id[i]);
            goto out;
        }

        if (groups[i]->direction != direction) {
            SX_LOG_ERR("ACL : The direction %d of group id %d is different from desired direction %d\n",
                       groups[i]->direction, groups[i]->group_id, direction);
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (groups[i]->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
            if (system_group != NULL) {
                /* Error including two system groups ??? */
                rc = SX_STATUS_ERROR;
                goto out;
            }
            system_group = groups[i];
        }
    }

    rc = flex_acl_db_get_is_parallel(&is_parallel);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get is parallel or serial config\n");
        goto out;
    }

    /* Sort according to priority, 0 is lowest priority */
    __flex_acl_sort_groups_by_prio(groups, group_num);

    for (i = 0; i < group_num; i++) {
        /* Go over groups according to priority, and create a list
         * of ACLs to bind
         */
        current_acl_group = groups[i];
        do {
            next_group_exists = FALSE;
            for (acl_idx = 0; acl_idx < current_acl_group->acl_num; acl_idx++) {
                if (prepare_i >= *prepared_ids_num) {
                    SX_LOG_ERR("Number of acls in hw group [%u] exceeds the given range [%u]\n",
                               prepare_i, *prepared_ids_num);
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
                acl_ids_prepared[prepare_i].acl_id = current_acl_group->acl_ids[acl_idx];
                acl_ids_prepared[prepare_i].is_commit = FALSE;
                acl_ids_prepared[prepare_i].is_multi = FALSE;
                SX_LOG_DBG("ACL ID Added - %d\n", acl_ids_prepared[prepare_i].acl_id);
                prepare_i++;
            }
            /* Add commit acl if execution type is parallel and we actually added acls.*/
            if (is_parallel && (current_acl_group->acl_num > 0)) {
                /* Get commit acl to put it between groups */
                rc = flex_acl_hw_commit_acl_get(&commit_acl_id, direction);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL : Failed to get commit ACL ID [0x%x]\n", commit_acl_id);
                    goto out;
                }

                if (commit_acl_id == FLEX_ACL_INVALID_ACL_ID) {
                    /* For spectrum2 there is no need for a dedicated acl we just mark the last acl as commit. */
                    if (prepare_i > 0) {
                        acl_ids_prepared[prepare_i - 1].is_commit = TRUE;
                    }
                } else {
                    /* For spectrum1 there is a need for a dedicated acl to act as commit. */
                    if (prepare_i >= *prepared_ids_num) {
                        SX_LOG_ERR("Number of ACLs in group exceeds the allowed range\n");
                        rc = SX_STATUS_ERROR;
                        goto out;
                    }
                    acl_ids_prepared[prepare_i].acl_id = commit_acl_id;
                    acl_ids_prepared[prepare_i].is_commit = FALSE;
                    acl_ids_prepared[prepare_i].is_multi = FALSE;
                    prepare_i++;
                    SX_LOG_DBG("Is parallel - c%d \n", acl_ids_prepared[prepare_i - 1].acl_id);
                }
            }

            if (current_acl_group->next_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
                rc = flex_acl_db_get_acl_group(current_acl_group->next_acl_group_id, &current_acl_group);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id[i]);
                    goto out;
                }
                next_group_exists = TRUE;
            }
        } while (next_group_exists);
    }
    *prepared_ids_num = prepare_i;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Find an ACL group specific for a binding point.
 * This function takes care of reusing identical groups.
 * The group holds all the bound groups including system ACLs
 */
static sx_status_t __flex_acl_aggregate_acl_group_get(sx_acl_direction_t    direction,
                                                      acl_id_group_entry_t *acl_ids,
                                                      uint32_t              acl_nums,
                                                      sx_acl_id_t          *group_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    flex_acl_bind_attribs_id_t new_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_api_acl_group_params_t *group_params_p = NULL;
    flex_acl_db_acl_group_t   *cur_group = NULL;
    sx_acl_id_t                hw_acl_group = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                   iii = 0;
    boolean_t                  remove = FALSE;

    if (*group_id != FLEX_ACL_INVALID_ACL_ID) {
        /* As there was a previous group, find it's record */
        rc = flex_acl_db_get_acl_group(*group_id, &cur_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_WRN("ACL: failed to find aggregated group ID 0x%x\n", *group_id);
            cur_group = NULL;
        }
    }

    /* If there is an existing group containing the same ACL IDs
     * then it is best to use it */
    rc = flex_acl_db_hw_group_get(direction, acl_ids, acl_nums, &hw_acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed to lookup a HW group to aggregate\n");
        goto out;
    }
    if (hw_acl_group != FLEX_ACL_INVALID_ACL_ID) {
        /* Found a matching HW group that has the same ACLs */
        *group_id = hw_acl_group;
        goto out;
    }

    /* If there is only a single user for this group, edit the group */
    if ((cur_group != NULL) && (cur_group->bind_point_count == 1)) {
        rc = flex_acl_get_bind_attribs(*group_id, &new_bind_attribs_id, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", *group_id);
            goto out;
        }
        rc = flex_acl_write_bind_attributes(new_bind_attribs_id,
                                            TRUE,
                                            acl_ids,
                                            acl_nums,
                                            TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to edit group in HW, bind attributes: %u\n", new_bind_attribs_id);
            goto out;
        }

        /* Remove from bind_point_groups_map before group editing and insert again after it to keep the fmap works */
        /* Otherwise the fmap will be corrupted due to the key is changed */
        rc = flex_acl_db_hw_group_put(*group_id, &remove);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to put a HW group");
            goto out;
        }

        /* Update group parameters */
        for (iii = 0; iii < acl_nums; iii++) {
            cur_group->acl_ids[iii] = acl_ids[iii].acl_id;
        }
        /* Clear the extra ACLs in the group (if any) */
        for (; iii < cur_group->acl_num; iii++) {
            cur_group->acl_ids[iii] = FLEX_ACL_INVALID_ACL_ID;
        }
        cur_group->acl_num = acl_nums;

        rc = flex_acl_db_hw_groups_set(*group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to set a HW group\n");
            goto out;
        }

        goto out;
    }

    /* If there are no matching groups - create a new dedicated group */
    group_params_p = cl_malloc(sizeof(sx_api_acl_group_params_t) + sizeof(sx_acl_id_t) * acl_nums);
    if (group_params_p == NULL) {
        SX_LOG_ERR("ACL: Failed to allocate memory\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    SX_MEM_CLR_P(group_params_p);

    /* Create a new group for this binding point */
    group_params_p->acl_direction = direction;
    group_params_p->cmd = SX_ACCESS_CMD_CREATE;
    rc = flex_acl_group_set_internal(group_params_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create internal group\n");
        goto out;
    }

    *group_id = group_params_p->group_id;

    rc = flex_acl_db_group_entry_type_set(*group_id, FLEX_ACL_ENTRY_TYPE_AGGREGATE_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed to set type for group_id [%u].\n", *group_id);
        goto error_rollback_group_create;
    }

    group_params_p->cmd = SX_ACCESS_CMD_SET;
    group_params_p->acl_ids_num = acl_nums;
    for (iii = 0; iii < acl_nums; iii++) {
        group_params_p->acl_ids[iii] = acl_ids[iii].acl_id;
    }
    rc = flex_acl_group_set_internal(group_params_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set group for internal purposes, group_id [%u]\n", *group_id);
        goto error_rollback_group_create;
    }
    /* Update new group in DB */
    rc = flex_acl_db_hw_groups_set(*group_id);

    goto out;

error_rollback_group_create:
    group_params_p->cmd = SX_ACCESS_CMD_DESTROY;
    rb_rc = flex_acl_group_set_internal(group_params_p);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in rollback destroy internal group\n");
    }
out:

    CL_FREE_N_NULL(group_params_p);
    return rc;
}

/* Remove an ACL group that was created specifically for binding point.
 */
static sx_status_t __flex_acl_aggregate_acl_group_put(sx_acl_direction_t direction, sx_acl_id_t             *group_id)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_api_acl_group_params_t group_params;
    boolean_t                 remove = FALSE;
    flex_acl_entry_type_e     type = FLEX_ACL_ENTRY_TYPE_LAST_E;

    SX_MEM_CLR(group_params);

    if (*group_id == FLEX_ACL_INVALID_ACL_ID) {
        goto out;
    }

    rc = flex_acl_db_group_entry_type_get(*group_id, &type);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (type != FLEX_ACL_ENTRY_TYPE_AGGREGATE_E) {
        goto out;
    }

    rc = flex_acl_db_hw_group_put(*group_id, &remove);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (remove == FALSE) {
        goto out;
    }

    /* Destroy internal group */
    group_params.acl_direction = direction;
    group_params.group_id = *group_id;
    group_params.cmd = SX_ACCESS_CMD_DESTROY;
    rc = flex_acl_group_set_internal(&group_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy internal group\n");
        goto out;
    }
    *group_id = FLEX_ACL_INVALID_ACL_ID;

out:
    return rc;
}

static sx_status_t __flex_acl_bind_port_in_hw(sx_port_id_t port, flex_acl_bind_attribs_id_t new_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *new_bind_attribs = NULL;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_port_log_id_t                 *log_ports_p = NULL;
    uint32_t                          ports_count = rm_resource_global.lag_port_members_max;
    uint32_t                          i = 0;

    rc = flex_acl_db_attribs_get(new_bind_attribs_id, &new_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", new_bind_attribs_id);
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(port) == SX_PORT_TYPE_LAG) {
        log_ports_p = (sx_port_log_id_t*)cl_malloc(ports_count * sizeof(sx_port_log_id_t));
        if (log_ports_p == NULL) {
            SX_LOG_ERR("ACL : Failed to allocate memory for port list, lag[0x%x]\n", port);
            rc = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
        memset(log_ports_p, 0, ports_count * sizeof(sx_port_log_id_t));
        /* Get list of relevant ports */
        rc = flex_acl_get_lag_ports_list(port, FALSE, log_ports_p, &ports_count);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get port list for bind operation port [0x%x]\n", port);
            goto out;
        }

        rc = __flex_acl_rebind_lag(port, new_bind_attribs_id, FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at rebind lag[%u]\n", port);
            /* This Error is FATAL - no rollback */
            goto out;
        }

        for (i = 0; i < ports_count; i++) {
            rc = __flex_acl_bind_lag_port(port, log_ports_p[i], new_bind_attribs->direction);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error at binding LAG [0x%x] port [%u]\n", port, log_ports_p[i]);
                /* This Error is FATAL - no rollback */
                goto out;
            }
        }
        goto out;
    }

    /* Bind the new group to the hardware */
    rc = flex_acl_db_attribs_bind_log_port(new_bind_attribs_id, port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add attribute bind db for port [0x%x].\n", port);
        goto out;
    }

    rc = flex_acl_hw_reg_write_port(port, new_bind_attribs, TRUE, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to bind port-specific ACL to hardware port [0x%x].\n", port);
        goto rollback_db_write;
    }

    goto out;

rollback_db_write:
    rb_rc = flex_acl_db_attribs_unbind_log_port(new_bind_attribs_id, port);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to remove attribute bind db for port [0x%x].\n", port);
    }
out:
    CL_FREE_N_NULL(log_ports_p);
    return rc;
}

static sx_status_t __flex_acl_unbind_port_in_hw(sx_port_id_t port, flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *old_bind_attribs = NULL;
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_port_log_id_t                 *log_ports_p = NULL;
    uint32_t                          ports_count = rm_resource_global.lag_port_members_max;
    uint32_t                          i = 0;

    rc = flex_acl_db_attribs_get(old_bind_attribs_id, &old_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", old_bind_attribs_id);
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(port) == SX_PORT_TYPE_LAG) {
        log_ports_p = (sx_port_log_id_t*)cl_malloc(ports_count * sizeof(sx_port_log_id_t));
        if (log_ports_p == NULL) {
            SX_LOG_ERR("ACL : Failed to allocate memory for port list, lag[0x%x]\n", port);
            rc = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
        memset(log_ports_p, 0, ports_count * sizeof(sx_port_log_id_t));
        /* Get list of relevant ports */
        rc = flex_acl_get_lag_ports_list(port, FALSE, log_ports_p, &ports_count);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get port list for bind operation port [0x%x]\n", port);
            goto out;
        }

        for (i = 0; i < ports_count; i++) {
            rc = __flex_acl_unbind_lag_port(old_bind_attribs_id, log_ports_p[i], old_bind_attribs->direction);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error at unbinding LAG [0x%x] port [%u]\n", port, log_ports_p[i]);
                /* This Error is FATAL - no rollback */
                goto out;
            }
        }

        /* update ports db that port was bound to attributes */
        rc = flex_acl_db_port_unbind(port, old_bind_attribs->direction, TRUE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to update DB - unbind group [0x%x] from LAG [0x%x]\n",
                       old_bind_attribs->bind_id, port);
            goto out;
        }

        goto out;
    }

    rc = flex_acl_hw_reg_write_port(port, old_bind_attribs, FALSE, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL from hardware port [0x%x].\n", port);
        goto out;
    }

out:
    CL_FREE_N_NULL(log_ports_p);
    return rc;
}

static sx_status_t __flex_acl_bind_rif_in_hw(sx_rif_id_t rif, flex_acl_bind_attribs_id_t new_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *new_bind_attribs = NULL;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_get(new_bind_attribs_id, &new_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", new_bind_attribs_id);
        goto out;
    }

    /* Bind the new group in DB and to the hardware */
    rc = flex_acl_db_attribs_bind_rif(new_bind_attribs_id, rif);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add attribute bind db for RIF [0x%x].\n", rif);
        goto out;
    }

    rc = flex_acl_hw_reg_write_rif_bind(rif, new_bind_attribs, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to bind RIF-specific ACL to hardware RIF [0x%x].\n", rif);
        goto rollback_db_write;
    }

    goto out;

rollback_db_write:
    rb_rc = flex_acl_db_attribs_unbind_rif(new_bind_attribs_id, rif);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to remove attribute bind db for RIF [0x%x].\n", rif);
    }
out:
    return rc;
}

static sx_status_t __flex_acl_unbind_rif_in_hw(sx_rif_id_t rif, flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *old_bind_attribs = NULL;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_get(old_bind_attribs_id, &old_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", old_bind_attribs_id);
        goto out;
    }

    rc = flex_acl_hw_reg_write_rif_bind(rif, old_bind_attribs, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL from hardware RIF [0x%x].\n", rif);
        goto out;
    }

out:
    return rc;
}

static sx_status_t __flex_acl_bind_vlan_group_in_hw(sx_acl_vlan_group_t        vlan_group,
                                                    flex_acl_bind_attribs_id_t new_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *new_bind_attribs = NULL;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_get(new_bind_attribs_id, &new_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", new_bind_attribs_id);
        goto out;
    }

    /* Bind the new group in DB and to the hardware */
    rc = flex_acl_db_attribs_bind_vlan_group(new_bind_attribs_id, vlan_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add attribute bind db for VLAN group [0x%x].\n", vlan_group);
        goto out;
    }

    rc = flex_acl_hw_reg_write_vlan_group_bind(vlan_group, new_bind_attribs, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to bind ACL to hardware VLAN group [0x%x].\n", vlan_group);
        goto rollback_db_write;
    }

    goto out;

rollback_db_write:
    rb_rc = flex_acl_db_attribs_unbind_vlan_group(new_bind_attribs_id, vlan_group);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to remove attribute bind db for VLAN group [0x%x].\n", vlan_group);
    }
out:
    return rc;
}

static sx_status_t __flex_acl_unbind_vlan_group_in_hw(sx_acl_vlan_group_t        vlan_group,
                                                      flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    flex_acl_db_group_bind_attribs_t *old_bind_attribs = NULL;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_get(old_bind_attribs_id, &old_bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error getting bind attributes id %u\n", old_bind_attribs_id);
        goto out;
    }

    rc = flex_acl_hw_reg_write_vlan_group_bind(vlan_group, old_bind_attribs, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind ACL from hardware VLAN group [0x%x].\n", vlan_group);
        goto out;
    }

out:
    return rc;
}

static sx_status_t __flex_acl_bind_point_in_hw(flex_acl_bind_point_id     bind_point_id,
                                               sx_acl_direction_t         direction,
                                               flex_acl_bind_attribs_id_t new_bind_attribs_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;


    if (flex_acl_is_port_direction(direction) == TRUE) {
        /* Port bind */
        rc = __flex_acl_bind_port_in_hw(bind_point_id.port_id, new_bind_attribs_id);
    } else if (flex_acl_is_rif_direction(direction) == TRUE) {
        /* RIF bind */
        rc = __flex_acl_bind_rif_in_hw(bind_point_id.rif_id, new_bind_attribs_id);
    } else if (flex_acl_is_vlan_direction(direction) == TRUE) {
        /* VLAN Group bind */
        rc = __flex_acl_bind_vlan_group_in_hw(bind_point_id.vlan_group_id, new_bind_attribs_id);
    }

    return rc;
}

static sx_status_t __flex_acl_unbind_point_in_hw(flex_acl_bind_point_id     bind_point_id,
                                                 sx_acl_direction_t         direction,
                                                 flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (flex_acl_is_port_direction(direction) == TRUE) {
        /* Port bind */
        rc = __flex_acl_unbind_port_in_hw(bind_point_id.port_id, old_bind_attribs_id);
    } else if (flex_acl_is_rif_direction(direction) == TRUE) {
        /* RIF bind */
        rc = __flex_acl_unbind_rif_in_hw(bind_point_id.rif_id, old_bind_attribs_id);
    } else if (flex_acl_is_vlan_direction(direction) == TRUE) {
        /* VLAN Group bind */
        rc = __flex_acl_unbind_vlan_group_in_hw(bind_point_id.vlan_group_id, old_bind_attribs_id);
    }

    return rc;
}

static sx_status_t __flex_acl_unlink_vlan_group_attribs(sx_acl_vlan_group_t        vlan_group,
                                                        flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_unbind_vlan_group(old_bind_attribs_id, vlan_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unlink attribute bind db for VLAN group [0x%x].\n", vlan_group);
        goto out;
    }

out:
    return rc;
}

static sx_status_t __flex_acl_unlink_rif_attribs(sx_rif_id_t rif, flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_attribs_unbind_rif(old_bind_attribs_id, rif);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unlink attribute bind db for RIF [0x%x].\n", rif);
        goto out;
    }

out:
    return rc;
}

static sx_status_t __flex_acl_unlink_port_attribs(sx_port_id_t port, flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_port_log_id_t *log_ports_p = NULL;
    uint32_t          ports_count = rm_resource_global.lag_port_members_max;
    uint32_t          i = 0;


    if (SX_PORT_TYPE_ID_GET(port) == SX_PORT_TYPE_LAG) {
        log_ports_p = (sx_port_log_id_t*)cl_malloc(ports_count * sizeof(sx_port_log_id_t));
        if (log_ports_p == NULL) {
            SX_LOG_ERR("ACL : Failed to allocate memory for port list, lag[0x%x]\n", port);
            rc = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
        memset(log_ports_p, 0, ports_count * sizeof(sx_port_log_id_t));

        /* Get list of relevant ports */
        rc = flex_acl_get_lag_ports_list(port, FALSE, log_ports_p, &ports_count);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to get port list for bind operation port [0x%x]\n", port);
            goto out;
        }

        for (i = 0; i < ports_count; i++) {
            rc = __flex_acl_unlink_port_attribs(log_ports_p[i], old_bind_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in unbinding LAG port from HW DB port [0x%x].\n", log_ports_p[i]);
                goto out;
            }
        }

        rc = flex_acl_db_attribs_unbind_lag(old_bind_attribs_id, port);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at unbinding LAG [0x%x]\n", port);
            /* This Error is FATAL - no rollback */
            goto out;
        }

        goto out;
    }

    rc = flex_acl_db_attribs_unbind_log_port(old_bind_attribs_id, port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to remove attribute bind db for port [0x%x].\n", port);
        goto out;
    }

out:
    if (log_ports_p != NULL) {
        cl_free(log_ports_p);
    }

    return rc;
}

static sx_status_t __flex_acl_unlink_point_attribs(flex_acl_bind_point_id     bind_point_id,
                                                   sx_acl_direction_t         direction,
                                                   flex_acl_bind_attribs_id_t old_bind_attribs_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (flex_acl_is_port_direction(direction) == TRUE) {
        rc = __flex_acl_unlink_port_attribs(bind_point_id.port_id, old_bind_attribs_id);
    } else if (flex_acl_is_rif_direction(direction) == TRUE) {
        /* RIF unlink */
        rc = __flex_acl_unlink_rif_attribs(bind_point_id.rif_id, old_bind_attribs_id);
    } else if (flex_acl_is_vlan_direction(direction) == TRUE) {
        /* VLAN group unlink */
        rc = __flex_acl_unlink_vlan_group_attribs(bind_point_id.vlan_group_id, old_bind_attribs_id);
    }

    return rc;
}

static sx_status_t __flex_acl_cleanup_old_bind_group(flex_acl_bind_point_id bind_point_id,
                                                     sx_acl_direction_t     direction,
                                                     sx_acl_id_t            old_bind_group_id)
{
    flex_acl_bind_attribs_id_t old_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_status_t                rc = SX_STATUS_SUCCESS;

    /* Mark that the binding group is no longer in use */
    if (old_bind_group_id != FLEX_ACL_INVALID_ACL_ID) {
        rc = flex_acl_get_bind_attribs(old_bind_group_id, &old_bind_attribs_id, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", old_bind_group_id);
            goto out;
        }

        rc = __flex_acl_unlink_point_attribs(bind_point_id, direction, old_bind_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
    }

out:
    return rc;
}

/* Main logic for binding multiple or single ACL groups per binding point (Port/RIF/VLAN group)
 * This function takes the currently bound groups per binding point as input
 * and when it is done the bind point will be bound in HW to the required HW group.
 *
 * Multiple ACL groups can be any permutation of user and system groups that result binding
 * of more than one group to the same binding point.
 * A dedicated aggregate group is either created or reused if possible for such cases when
 * multiple groups are bound to the same binding point.
 */
static sx_status_t __flex_acl_aggregate_acl_groups(flex_acl_bind_point_id            bind_point_id,
                                                   char                             *bind_point_str,
                                                   flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                   int                               bind_cmd,
                                                   flex_acl_bind_attribs_id_t       *hw_attribs_id,
                                                   boolean_t                         is_vlan_group)
{
    uint32_t                   prepared_acls_num = rm_resource_global.acl_groups_size_max;
    acl_id_group_entry_t       acl_ids_prepared[rm_resource_global.acl_groups_size_max];
    flex_acl_bind_attribs_id_t new_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t old_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    uint32_t                   groups_num = rm_resource_global.acl_groups_size_max;
    sx_acl_id_t                groups[rm_resource_global.acl_groups_size_max];
    sx_acl_id_t                global_sys_group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_id_t                old_bind_group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_id_t                bound_group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_id_t                sys_group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_direction_t         direction = bind_attribs->direction;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    uint32_t                   user_groups = 0;

    SX_LOG_ENTER();

    *hw_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    if (is_vlan_group) {
        direction = VLAN_GROUP_DIRECTION(direction);
    }

    /* Get previously used group */
    rc = flex_acl_db_binding_point_bind_group_get(direction, bind_point_id, &old_bind_group_id);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        /* Programming error */
        SX_LOG_ERR(" ACL: Failed getting bind attributes for %s [%u]\n", bind_point_str, bind_point_id.port_id);
        goto out;
    }

    /* Get ACL groups currently bound to port */
    rc = flex_acl_db_binding_point_groups_get(direction, bind_point_id, groups, &groups_num);
    if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("ACL: Failed in getting binding point groups %s [%u]\n", bind_point_str, bind_point_id.port_id);
        goto out;
    }

    if ((bind_cmd == TRUE) && (groups_num == 0)) {
        SX_LOG_ERR("ACL: Unexpected number of groups to bind on %s [%u]\n", bind_point_str, bind_point_id.port_id);
        /* Programming error */
        rc = SX_STATUS_ERROR;
        goto out;
    }
    user_groups = groups_num;

    if (is_vlan_group == FALSE) {
        /* Check if the binding point is bound to a bind-point specific system ACL and get the group id */
        sys_group_id = FLEX_ACL_INVALID_ACL_ID;
        rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &sys_group_id);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("ACL: Failed to find system ACL on %s [%u]\n", bind_point_str, bind_point_id.port_id);
            goto out;
        }

        if (sys_group_id != FLEX_ACL_INVALID_ACL_ID) {
            /* One of the groups is a system group */
            user_groups--;
        }

        /* Add global system ACL group if present */
        global_sys_group_id = FLEX_ACL_INVALID_ACL_ID;
        rc = flex_acl_db_get_system_acl_group(direction, &global_sys_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get system group, binding %s [%u]\n", bind_point_str, bind_point_id.port_id);
            goto out;
        }

        if (global_sys_group_id != FLEX_ACL_INVALID_ACL_ID) {
            /* One of the groups is a system group */
            user_groups--;
        }
    }

    /* At this point all the groups to be bound on the binding point are ready
     * so compile a full list of ACLs according to priority */
    rc = __flex_acl_aggregate_groups(groups,
                                     groups_num,
                                     USER_GIVEN_DIRECTION(direction),
                                     acl_ids_prepared,
                                     &prepared_acls_num);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (bind_cmd != FALSE) {
        if (groups_num == 1) {
            /* In case of a single group bind, whether it is a system group or not,
             * use the group own attributes.
             */
            rc = flex_acl_get_bind_attribs(groups[0], &new_bind_attribs_id, NULL, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to get bind attributes id for user group_id [%u].\n", groups[0]);
                goto out;
            }
            bound_group_id = groups[0];

            if (bind_cmd == REBIND) {
                *hw_attribs_id = new_bind_attribs_id;
                rc = SX_STATUS_SUCCESS;
                goto out;
            }

            rc = __flex_acl_bind_point_in_hw(bind_point_id, direction, new_bind_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to bind user group attributes id on %s [%u].\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            *hw_attribs_id = new_bind_attribs_id;
            rc = flex_acl_db_binding_point_bind_group_set(direction, bind_point_id, bound_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                /* Programming error */
                SX_LOG_ERR(" ACL: Failed setting bind attributes id for %s [%u]\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            goto clean;
        }

        /* Use an internal dedicated HW group.
         * It could be a group already used by other ports.
         * In that case we use the same group.
         */
        bound_group_id = old_bind_group_id;
        rc = __flex_acl_aggregate_acl_group_get(USER_GIVEN_DIRECTION(direction),
                                                acl_ids_prepared,
                                                prepared_acls_num,
                                                &bound_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed creating ACL group for aggregate binding %s [%u]\n",
                       bind_point_str,
                       bind_point_id.port_id);
            goto out;
        }

        rc = flex_acl_get_bind_attribs(bound_group_id, &new_bind_attribs_id, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", bound_group_id);
            goto out;
        }

        *hw_attribs_id = new_bind_attribs_id;

        /* If we are reusing the same aggregate group
         * then no need to bind in HW and no need to free the old group
         */
        if (bound_group_id == old_bind_group_id) {
            old_bind_group_id = FLEX_ACL_INVALID_ACL_ID;
            goto clean;
        }

        if (bind_cmd == REBIND) {
            /* Using a new group, Get the old bind attributes and mark that the old group is not in use */
            rc = flex_acl_get_bind_attribs(old_bind_group_id, &old_attribs_id, NULL, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", bound_group_id);
                goto out;
            }

            /* Mark in DB that bind attributes no longer bound to bind point */
            rc = __flex_acl_unlink_point_attribs(bind_point_id, direction, old_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to unlink ACL to hardware %s [0x%x].\n", bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }
        }

        rc = flex_acl_db_binding_point_bind_group_set(direction, bind_point_id, bound_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            /* Programming error */
            SX_LOG_ERR(" ACL: Failed setting bind attributes id for %s [%u]\n", bind_point_str, bind_point_id.port_id);
            goto out;
        }

        rc = __flex_acl_bind_point_in_hw(bind_point_id, direction, new_bind_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to bind specific group attributes id on %s [%u].\n",
                       bind_point_str,
                       bind_point_id.port_id);
            goto out;
        }

        goto clean;
    } else {
        /* Unbind */
        if (groups_num > 1) {
            bound_group_id = old_bind_group_id;
            rc = __flex_acl_aggregate_acl_group_get(USER_GIVEN_DIRECTION(direction),
                                                    acl_ids_prepared,
                                                    prepared_acls_num,
                                                    &bound_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed getting ACL group for aggregate binding %s [%u]\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            /* Only update the currently used attributes */
            rc = flex_acl_get_bind_attribs(bound_group_id, &new_bind_attribs_id, NULL, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", old_bind_group_id);
                goto out;
            }

            *hw_attribs_id = new_bind_attribs_id;

            /* If we are reusing the same aggregate group
             * then no need to free the group
             */
            if (bound_group_id == old_bind_group_id) {
                old_bind_group_id = FLEX_ACL_INVALID_ACL_ID;
                goto clean;
            }

            rc = flex_acl_db_binding_point_bind_group_set(direction, bind_point_id, bound_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                /* Programming error */
                SX_LOG_ERR(" ACL: Failed setting bind attributes id for %s [%u]\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            rc = __flex_acl_bind_point_in_hw(bind_point_id, direction, new_bind_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to bind specific group attributes id on %s [%u].\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }
        }

        /* A single group uses the ACL group binding attributes.
         * No need to create a new one.
         */
        if (groups_num == 1) {
            /* Use group */
            rc = flex_acl_get_bind_attribs(groups[0], &new_bind_attribs_id, NULL, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to get bind attributes id for group_id [%u].\n", groups[0]);
                goto out;
            }

            /* Set the new bind group */
            rc = flex_acl_db_binding_point_bind_group_set(direction, bind_point_id, groups[0]);
            if (rc != SX_STATUS_SUCCESS) {
                /* Programming error */
                SX_LOG_ERR(" ACL: Failed setting bind attributes id for %s [%u]\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            rc = __flex_acl_bind_point_in_hw(bind_point_id, direction, new_bind_attribs_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: failed to bind user group attributes id on %s [%u].\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }
            *hw_attribs_id = new_bind_attribs_id;
        }

        /* Mark in DB that bind attributes no longer bound to bind point */
        rc = __flex_acl_unlink_point_attribs(bind_point_id, direction, bind_attribs->bind_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to unlink ACL to hardware %s [0x%x].\n", bind_point_str, bind_point_id.port_id);
            goto out;
        }

        if (groups_num == 0) {
            /* Unbind groups from binding point in HW , will skip LAG ports */
            rc = __flex_acl_unbind_point_in_hw(bind_point_id, direction, bind_attribs->bind_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to unbind ACL to hardware %s [0x%x].\n", bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }

            /* Clear bind point bind group indication */
            rc = flex_acl_db_binding_point_bind_group_set(direction, bind_point_id, FLEX_ACL_INVALID_ACL_ID);
            if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                /* Programming error */
                SX_LOG_ERR(" ACL: Failed setting bind attributes id for %s [%u]\n",
                           bind_point_str,
                           bind_point_id.port_id);
                goto out;
            }
        }

        goto clean;
    }

clean:

    if (bind_cmd == TRUE) {
        rc = __flex_acl_cleanup_old_bind_group(bind_point_id, direction, old_bind_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to delete old bind point specific ACL group [%u].\n", old_bind_group_id);
        }
    }

    rc = __flex_acl_aggregate_acl_group_put(direction, &old_bind_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to delete old port specific ACL group [%u].\n", old_bind_group_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_aggregate_port_acl_groups(sx_port_id_t                      port,
                                                        flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                        boolean_t                         bind_cmd,
                                                        flex_acl_bind_attribs_id_t       *hw_attribs_id)
{
    flex_acl_bind_point_id bind_point_id = {.port_id = port};

    return __flex_acl_aggregate_acl_groups(bind_point_id, "Port", bind_attribs, bind_cmd, hw_attribs_id, FALSE);
}

static sx_status_t __flex_acl_aggregate_rif_acl_groups(sx_rif_id_t                       rif,
                                                       flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                       boolean_t                         bind_cmd,
                                                       flex_acl_bind_attribs_id_t       *hw_attribs_id)
{
    flex_acl_bind_point_id bind_point_id = {.rif_id = rif};

    return __flex_acl_aggregate_acl_groups(bind_point_id, "RIF", bind_attribs, bind_cmd, hw_attribs_id, FALSE);
}

static sx_status_t __flex_acl_aggregate_vlan_group_acl_groups(sx_acl_vlan_group_t               vlan_group,
                                                              flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                              boolean_t                         bind_cmd,
                                                              flex_acl_bind_attribs_id_t       *hw_attribs_id)
{
    flex_acl_bind_point_id bind_point_id = {.vlan_group_id = vlan_group};

    return __flex_acl_aggregate_acl_groups(bind_point_id, "VLAN group", bind_attribs, bind_cmd, hw_attribs_id, TRUE);
}


sx_status_t flex_acl_binding_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}
