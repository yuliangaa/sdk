/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_KEYS_H_INCL__
#define __FLEX_ACL_KEYS_H_INCL__

#include "flex_acl_db.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define IS_KEY_BUILD_VALUE(build_mode)                  \
    ((build_mode == FLEX_ACL_KEY_BUILD_VALUE_MASK_E) || \
     (build_mode == FLEX_ACL_KEY_BUILD_VALUE_ONLY_E))
#define IS_KEY_BUILD_MASK(build_mode)                   \
    ((build_mode == FLEX_ACL_KEY_BUILD_VALUE_MASK_E) || \
     (build_mode == FLEX_ACL_KEY_BUILD_MASK_ONLY_E))

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes the following mapping according to the FLEX stage:
 * 1. The FLEX_ACL_KEY to FLEX_ACL_HW_KEY map.
 * 2. Key blocks sizes and location in the key.
 *
 * @return SX_STATUS_SUCCESS       - Initialization successful.
 *         SX_STATUS_UNSUPPORTED   - Flex stage not supported.
 */
sx_status_t flex_acl_key_block_map_init(acl_stage_e acl_stage);

/**
 * This function validates all keys for a specified ACL region.
 *
 *
 * @param[in] key_desc_list_p - pointer to the keys we want to validate.
 * @param[in] key_desc_count  - The number of keys we want to validate.
 * @param[in] acl_region      - pointer to the region info for which to validate the keys.
 * @param[in] build_mode      - Determines if to create value & mask / value only / mask only. *
 * @param[in] is_flex    - Indicate if this is a flex ACL or not.
 *
 * @return SX_STATUS_SUCCESS - keys are valid.
 *         SX_STATUS_PARAM_ERROR - Keys are invalid for the region.
 *         SX_STATUS_INVALID_HANDLE - Internal DB error.
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - Internal DB error.
 */
sx_status_t flex_acl_keys_validate(sx_flex_acl_key_desc_t   *key_desc_list_p,
                                   uint32_t                  key_desc_count,
                                   flex_acl_db_acl_region_t *acl_region,
                                   flex_acl_key_build_mode_e build_mode,
                                   boolean_t                 is_flex);

/**
 * This function creates the key blocks binary representation (value & mask)
 * according to the user keys provided.
 * Note: This function is not used by the ACL rules' logic. It's intended
 * for external application (such as stateful DB) which need to build keys
 * independently from the rule.
 *
 *
 * @param[in] region_id         - The region id for which to generate the key.
 * @param[in] keys              - Pointer to the list of keys to create the key blocks from.
 * @param[in] keys_cnt          - The number of keys in the list.
 * @param[in] build_mode        - Determines if to create value & mask / value only / mask only.
 * @param[out] flex_value_blocks - The generated key value blocks.
 * @param[out] flex_mask_blocks  - The generated key mask blocks.
 *
 * @return SX_STATUS_SUCCESS - keys are valid.
 *         SX_STATUS_PARAM_ERROR - Keys are invalid for the region.
 *         SX_STATUS_INVALID_HANDLE - Internal DB error.
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - Internal DB error.
 */

sx_status_t flex_acl_key_generate(sx_acl_region_id_t        region_id,
                                  sx_flex_acl_key_desc_t   *keys_p,
                                  uint32_t                  keys_cnt,
                                  flex_acl_key_build_mode_e build_mode,
                                  uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                  uint8_t                   flex_mask_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);

/**
 * This function extracts user keys (value only) from the provided key blocks.
 * Note: This function is not used by the ACL rules' logic. It's intended
 * for external application (such as stateful DB) which need to extract keys
 * independently from the rule.
 *
 *
 * @param[in] region_id          - The region id for which to generate the keys.
 * @param[in] flex_value_blocks  - The key value blocks from which to extract the user keys.
 * @param[out] keys_p            - Pointer to the list of user keys that will be filled by the function.
 * @param[in/out] keys_cnt_p     - In: the number of keys in the array pointed by keys_o. Out: the actual number of keys extracted.
 *
 * @return SX_STATUS_SUCCESS - keys are valid.
 *         SX_STATUS_INVALID_HANDLE - Internal DB error.
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - Internal DB error.
 */

sx_status_t flex_acl_key_extract(sx_acl_region_id_t      region_id,
                                 uint8_t                 flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                 sx_flex_acl_key_desc_t *keys_p,
                                 uint32_t               *keys_cnt_p);

sx_status_t flex_acl_get_lag_ports_list(sx_port_log_id_t   log_port,
                                        boolean_t          is_vport,
                                        sx_port_log_id_t * ports_list_p,
                                        uint32_t         * ports_count_p);

sx_status_t flex_acl_compare_keys(flex_acl_db_flex_rule_t *rule1_p,
                                  flex_acl_db_flex_rule_t *rule2_p,
                                  boolean_t               *is_key_changed_p);

sx_status_t flex_acl_keys_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* ifndef __FLEX_ACL_KEYS_H_INCL__ */
