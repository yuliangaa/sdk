/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SYSTEM_ACL_MC_H_
#define SYSTEM_ACL_MC_H_

#include "acl/flex_acl_hw_cb.h"
#include "sx/sdk/sx_status.h"
#include "sx/sdk/sx_dev.h"
#include "sx/sdk/sx_acl.h"
#include "acl/flex_acl_gen_def.h"
#include "sx/sxd/kernel_user.h"
#include "sx/utils/bit_vector.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t system_acl_mc_log_verbosity_level_set(sx_verbosity_level_t verbosity);

sx_status_t system_acl_mc_hw_write_region_ipv4(acl_region_op_e     region_op,
                                               sx_dev_id_t         dev_id,
                                               sx_acl_region_id_t  region_id,
                                               sx_acl_key_type_t   key_handle,
                                               sx_acl_key_block_e *key_blocks,
                                               uint32_t            key_blocks_cnt,
                                               uint8_t            *tcam_region_info,
                                               uint32_t            tcam_region_info_size,
                                               sx_acl_size_t       new_size,
                                               sx_acl_size_t      *allocated_size_p,
                                               boolean_t           stateful_db_region);

sx_status_t system_acl_mc_hw_write_rule_ipv4(acl_rule_hw_op_e        op,
                                             sx_dev_id_t             dev_id,
                                             sx_acl_region_id_t      region_id,
                                             const void             *region_info,
                                             sx_acl_rule_offset_t    offset,
                                             boolean_t               is_valid,
                                             uint32_t                priority,
                                             sx_flex_acl_key_desc_t *keys,
                                             uint32_t                keys_cnt,
                                             sx_acl_key_block_e     *key_blocks,
                                             uint32_t                key_blocks_cnt,
                                             sxd_flex_action_set_t  *reg_action_set,
                                             boolean_t              *activity_value,
                                             boolean_t               bulk_write);

sx_status_t system_acl_mc_hw_move_rule_ipv4(acl_move_rule_hw_op_e op,
                                            sx_dev_id_t           dev_id,
                                            sx_acl_region_id_t    src_region_id,
                                            sx_acl_region_id_t    dst_region_id,
                                            const void           *src_region_info,
                                            const void           *dst_region_info,
                                            sx_acl_rule_offset_t  src_offset,
                                            sx_acl_rule_offset_t  dst_offset,
                                            uint32_t              size,
                                            boolean_t             change_priority);

sx_status_t system_acl_mc_hw_write_region_ipv6(acl_region_op_e     region_op,
                                               sx_dev_id_t         dev_id,
                                               sx_acl_region_id_t  region_id,
                                               sx_acl_key_type_t   key_handle,
                                               sx_acl_key_block_e *key_blocks,
                                               uint32_t            key_blocks_cnt,
                                               uint8_t            *tcam_region_info,
                                               uint32_t            tcam_region_info_size,
                                               sx_acl_size_t       new_size,
                                               sx_acl_size_t      *allocated_size_p,
                                               boolean_t           stateful_db_region);

sx_status_t system_acl_mc_hw_write_rule_ipv6(acl_rule_hw_op_e        op,
                                             sx_dev_id_t             dev_id,
                                             sx_acl_region_id_t      region_id,
                                             const void             *region_info,
                                             sx_acl_rule_offset_t    offset,
                                             boolean_t               is_valid,
                                             uint32_t                priority,
                                             sx_flex_acl_key_desc_t *keys,
                                             uint32_t                keys_cnt,
                                             sx_acl_key_block_e     *key_blocks,
                                             uint32_t                key_blocks_cnt,
                                             sxd_flex_action_set_t  *reg_action_set,
                                             boolean_t              *activity_value,
                                             boolean_t               bulk_write);

sx_status_t system_acl_mc_hw_move_rule_ipv6(acl_move_rule_hw_op_e op,
                                            sx_dev_id_t           dev_id,
                                            sx_acl_region_id_t    src_region_id,
                                            sx_acl_region_id_t    dst_region_id,
                                            const void           *src_region_info,
                                            const void           *dst_region_info,
                                            sx_acl_rule_offset_t  src_offset,
                                            sx_acl_rule_offset_t  dst_offset,
                                            uint32_t              size,
                                            boolean_t             change_priority);

sx_status_t system_acl_mc_acl_write_hw_cb(sx_acl_id_t        acl_id,
                                          sx_acl_direction_t direction,
                                          uint8_t           *region_info,
                                          uint32_t           region_info_size,
                                          sx_dev_id_t        dev_id,
                                          boolean_t          valid);

sx_status_t system_acl_mc_hw_activity_dump_ipv4(boolean_t            is_clear,
                                                sx_dev_id_t          dev_id,
                                                const void          *region_info,
                                                sx_acl_rule_offset_t offset,
                                                uint32_t             num_entries,
                                                bit_vector_t        *activities_p);

sx_status_t system_acl_mc_hw_activity_dump_ipv6(boolean_t            is_clear,
                                                sx_dev_id_t          dev_id,
                                                const void          *region_info,
                                                sx_acl_rule_offset_t offset,
                                                uint32_t             num_entries,
                                                bit_vector_t        *activities_p);

sx_status_t system_acl_mc_router_hw_bind_region_spc(sx_access_cmd_t        cmd,
                                                    system_acl_client_id_e client_id,
                                                    boolean_t              second_group);
/* Dummy function for writing a region - does nothing */
sx_status_t system_acl_hw_write_region_dummy(acl_region_op_e     region_op,
                                             sx_dev_id_t         dev_id,
                                             sx_acl_region_id_t  region_id,
                                             sx_acl_key_type_t   key_handle,
                                             sx_acl_key_block_e *key_blocks,
                                             uint32_t            key_blocks_cnt,
                                             uint8_t            *tcam_region_info,
                                             uint32_t            tcam_region_info_size,
                                             sx_acl_size_t       new_size,
                                             sx_acl_size_t      *allocated_size_p,
                                             boolean_t           stateful_db_region);
/* Dummy function for writing an acl - does nothing */
sx_status_t system_acl_hw_write_acl_dummy(sx_acl_id_t        acl_id,
                                          sx_acl_direction_t direction,
                                          uint8_t           *region_info,
                                          uint32_t           region_info_size,
                                          sx_dev_id_t        dev_id,
                                          boolean_t          valid);
/* Stateful DB callback function intended to write the pointer to the failure actions */
sx_status_t system_acl_hw_write_rule_stateful_db(acl_rule_hw_op_e        op,
                                                 sx_dev_id_t             dev_id,
                                                 sx_acl_region_id_t      region_id,
                                                 const void             *region_info,
                                                 sx_acl_rule_offset_t    offset,
                                                 boolean_t               is_valid,
                                                 uint32_t                priority,
                                                 sx_flex_acl_key_desc_t *keys,
                                                 uint32_t                keys_cnt,
                                                 sx_acl_key_block_e     *key_blocks,
                                                 uint32_t                key_blocks_cnt,
                                                 sxd_flex_action_set_t  *reg_action_set,
                                                 boolean_t              *activity_value,
                                                 boolean_t               bulk_write);

#endif /* SYSTEM_ACL_MC_H_ */
