/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#undef  __MODULE__
#define __MODULE__ ACL

#include <complib/sx_log.h>
#include "flex_acl_gen_def.h"
#include "flex_acl_db.h"
#include "flex_acl_tcam_manager.h"
#include "flex_acl_keys.h"
#include "flex_acl_keys_scp.h"
#include <utils/utils.h>
#include <sx/sdk/sx_flex_acl.h>
#include "flex_acl_hw.h"
#include "ethl2/cos_sb.h"
#include "ethl2/port_db.h"
#include "ethl2/fid_manager.h"
#include "ethl2/la_db.h"
#include "ethl2/port_uc_route.h"
#include "ethl2/vlan.h"
#include "ethl2/fdb.h"
#include "ethl3/router_common.h"
#include "mpe_manager/mpe_manager.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sdk/sx_mc_container.h>
#include <mc_container/hwd/erif_list_manager.h>
#include <mc_container/hwd/hwd_mc_container.h>
#include <mc_container/hwi/mc_container_db.h>
#include <sx/sdk/sx_macsec.h>
#include "host_ifc/trap_id.h"

/************************************************
 *  Macros
 ***********************************************/

#define FLEX_ACL_CB_VALIDATE_ONLY TRUE
#define FLEX_ACL_CB_LOCK_UNLOCK   FALSE

#if (CPU_PORT_PHY_ID != 0)
#error "The local port logic assumes CPU_PORT_PHY_ID equal zero."
#endif

#define BOOLEAN_MASK_CHECK(key_name, valid_ind, out_label)               \
    if ((key->mask.key_name != TRUE) && (key->mask.key_name != FALSE)) { \
        SX_LOG_ERR("ACL : Invalid boolean mask for %s. mask :%x \n",     \
                   flex_acl_db_key_id_to_str(key->key_id),               \
                   key->mask.key_name);                                  \
        valid_ind = FALSE;                                               \
        goto out_label;                                                  \
    }                                                                    \
    valid_ind = TRUE

#define HANDLE_OPAQUE(field_name, field_size)                                  \
    if (IS_KEY_BUILD_VALUE(build_mode)) {                                      \
        memcpy(o_key, &(i_key->key.field_name), field_size);                   \
    }                                                                          \
    if (IS_KEY_BUILD_MASK(build_mode)) {                                       \
        memset(o_mask, i_key->mask.field_name == TRUE ? 0xFF : 0, field_size); \
    }                                                                          \
    *out_len = field_size

#define AVOID_VALIDATION_IF_MASK_FALSE(key_name, out_label) \
    if (key->mask.key_name == FALSE) {                      \
        goto out_label;                                     \
    }

#define MEMCPY_KEY(new_key_id, old_key_type, old_key_field)                                                          \
    if (__is_field_zero((char*)&(rule->mask.fields.old_key_type.old_key_field),                                      \
                        sizeof(rule->key.fields.old_key_type.old_key_field)) == FALSE) {                             \
        flex_rule->key_desc_list_p[k_ind].key_id = new_key_id;                                                       \
        memcpy((uint8_t*)&(flex_rule->key_desc_list_p[k_ind].key), &(rule->key.fields.old_key_type.old_key_field),   \
               sizeof(rule->key.fields.old_key_type.old_key_field));                                                 \
        memcpy((uint8_t*)&(flex_rule->key_desc_list_p[k_ind].mask), &(rule->mask.fields.old_key_type.old_key_field), \
               sizeof(rule->mask.fields.old_key_type.old_key_field));                                                \
        k_ind++;                                                                                                     \
    }

#define SIMPLE_COPY(new_key_id, old_key_type, new_key_field, old_key_field, max_mask)                        \
    if (rule->mask.fields.old_key_type.old_key_field)                                                        \
    {                                                                                                        \
        flex_rule->key_desc_list_p[k_ind].key_id = new_key_id;                                               \
        flex_rule->key_desc_list_p[k_ind].key.new_key_field = rule->key.fields.old_key_type.old_key_field;   \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field = rule->mask.fields.old_key_type.old_key_field; \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field &= max_mask;                                    \
        k_ind++;                                                                                             \
    }

#define SIMPLE_COPY_OPAQUE(new_key_id, old_key_type, new_key_field, old_key_field)                         \
    if (rule->mask.fields.old_key_type.old_key_field)                                                      \
    {                                                                                                      \
        flex_rule->key_desc_list_p[k_ind].key_id = new_key_id;                                             \
        flex_rule->key_desc_list_p[k_ind].key.new_key_field = rule->key.fields.old_key_type.old_key_field; \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field = TRUE;                                       \
        k_ind++;                                                                                           \
    }

#define SIMPLE_COPY_FLAG(new_key_id, old_key_type, new_key_field, old_key_field)                                   \
    if (rule->mask.fields.old_key_type.old_key_field)                                                              \
    {                                                                                                              \
        flex_rule->key_desc_list_p[k_ind].key_id = new_key_id;                                                     \
        flex_rule->key_desc_list_p[k_ind].key.new_key_field = rule->key.fields.old_key_type.old_key_field ? 1 : 0; \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field = TRUE;                                               \
        k_ind++;                                                                                                   \
    }

#define IPV4_COPY(new_key_id, old_key_type, new_key_field, old_key_field)                  \
    if (rule->mask.fields.old_key_type.old_key_field) {                                    \
        flex_rule->key_desc_list_p[k_ind].key_id = new_key_id;                             \
        flex_rule->key_desc_list_p[k_ind].key.new_key_field.version = SX_IP_VERSION_IPV4;  \
        flex_rule->key_desc_list_p[k_ind].key.new_key_field.addr.ipv4.s_addr =             \
            rule->key.fields.old_key_type.old_key_field;                                   \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field.version = SX_IP_VERSION_IPV4; \
        flex_rule->key_desc_list_p[k_ind].mask.new_key_field.addr.ipv4.s_addr =            \
            rule->mask.fields.old_key_type.old_key_field;                                  \
        k_ind++;                                                                           \
    }

/* This struct is used to store that key blocks implementing a basic key (legacy SwitchX Key). */
typedef struct basic_key_blocks_table_entry {
    sx_acl_key_type_t  key_type;                                          /* The basic key this structure holds */
    sx_acl_key_block_e blocks[SPECTRUM2_ACL_KEY_BLOCKS_MAX];              /* The key blocks implementing the key, predefined */
    uint32_t           blocks_count;                                      /* number of blocks, predefined*/
} basic_key_blocks_table_entry_t;


/************************************************
**  Global variables
************************************************/
extern boolean_t                g_flex_acl_initialized;
extern flex_acl_key_map_data_t *flex_acl_key_map[ACL_STAGES_NUM];
extern flex_acl_ops_t          *flex_acl_ops_g;

/***********************************************
*  Local variables
***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/* The following array represent the start offset of each key block in the entire key sent to HW.
 * A bit shift is also provide if the block starts at a non-byte boundary.
 */
static int8_t flex1_key_block_byte_offsets[] = {0, 16, 32, 48, 64, 80};
static int8_t flex1_key_block_bit_shifts[] = {0, 0, 0, 0, 0, 0};

/* The offsets/shifts assume each key block is 8 bytes as it appears in the PRM Keys Layout.
 * However, only the relevant 4.5 bytes will be filled by the function.
 */
static int8_t flex2_key_block_byte_offsets[] = {48, 44, 39, 35, 30, 26, 21, 17, 12, 8, 3, -1};
static int8_t flex2_key_block_bit_shifts[] = {0, 4, 0, 4, 0, 4, 0, 4, 0, 4, 0, 4};

/* The offsets/shifts assume each key block is 8 bytes as it appears in the PRM Keys Layout.
 * However, only the relevant 4.5 bytes will be filled by the function.
 */
static int8_t macsec_key_block_byte_offsets[] = {48, 44, 39, 35, 30, 26, 21, 17, 12, 8, 3, -1};
static int8_t macsec_key_block_bit_shifts[] = {0, 4, 0, 4, 0, 4, 0, 4, 0, 4, 0, 4};

int8_t *flex_key_block_byte_offsets[ACL_STAGES_NUM] = {NULL};
int8_t *flex_key_block_bit_shifts[ACL_STAGES_NUM] = {NULL};

/* The following translates the number of key blocks used to the actual width of the key in hardware. */
static sx_acl_flex_key_width_t flex1_key_widths[] = {SX_ACL_FLEX_KEY_WIDTH_NONE_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_18_E, SX_ACL_FLEX_KEY_WIDTH_18_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_36_E, SX_ACL_FLEX_KEY_WIDTH_36_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E};
static sx_acl_flex_key_width_t flex2_key_widths[] = {SX_ACL_FLEX_KEY_WIDTH_NONE_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_9_E, SX_ACL_FLEX_KEY_WIDTH_9_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_18_E, SX_ACL_FLEX_KEY_WIDTH_18_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_36_E, SX_ACL_FLEX_KEY_WIDTH_36_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_36_E, SX_ACL_FLEX_KEY_WIDTH_36_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                     SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E};
static sx_acl_flex_key_width_t macsec_key_widths[] = {SX_ACL_FLEX_KEY_WIDTH_NONE_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_18_E, SX_ACL_FLEX_KEY_WIDTH_18_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_18_E, SX_ACL_FLEX_KEY_WIDTH_18_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_36_E, SX_ACL_FLEX_KEY_WIDTH_36_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_36_E, SX_ACL_FLEX_KEY_WIDTH_36_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E,
                                                      SX_ACL_FLEX_KEY_WIDTH_54_E, SX_ACL_FLEX_KEY_WIDTH_54_E};

sx_acl_flex_key_width_t *flex_key_widths[ACL_STAGES_NUM] = {NULL};

/************************************************
 *  Local function declarations
 ***********************************************/

typedef boolean_t (*is_key_value_valid_t)(sx_flex_acl_key_desc_t *key, sx_acl_region_id_t region_id,
                                          flex_acl_key_build_mode_e build_mode);
/* Key validation function declarations */
static boolean_t is_dscp_valid(sx_flex_acl_key_desc_t   *key,
                               sx_acl_region_id_t        region_id,
                               flex_acl_key_build_mode_e build_mode);
static boolean_t is_color_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode);
static boolean_t is_ip_valid(sx_flex_acl_key_desc_t   *key,
                             sx_acl_region_id_t        region_id,
                             flex_acl_key_build_mode_e build_mode);
static boolean_t is_ipv6_extension_valid(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode);
static boolean_t is_tcp_control_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode);
static boolean_t is_l4_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_mc_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_3bits_field_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode);
static boolean_t is_vlan_id_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_bit_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode);
static boolean_t is_fid_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode);
static boolean_t is_trap_id_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_2bits_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode);
static boolean_t is_nible_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode);
static boolean_t is_l2_dmac_type_valid(sx_flex_acl_key_desc_t   *key,
                                       sx_acl_region_id_t        region_id,
                                       flex_acl_key_build_mode_e build_mode);
static boolean_t is_l3_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_label_id_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode);
static boolean_t is_mpls_labels_valid_valid(sx_flex_acl_key_desc_t   *key,
                                            sx_acl_region_id_t        region_id,
                                            flex_acl_key_build_mode_e build_mode);
static boolean_t is_rif_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode);
static boolean_t is_virtual_router_valid(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode);
static boolean_t is_tunnel_type_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode);
static boolean_t is_ar_packet_class_type_valid(sx_flex_acl_key_desc_t   *key,
                                               sx_acl_region_id_t        region_id,
                                               flex_acl_key_build_mode_e build_mode);
static boolean_t is_tunnel_nve_type_valid(sx_flex_acl_key_desc_t   *key,
                                          sx_acl_region_id_t        region_id,
                                          flex_acl_key_build_mode_e build_mode);
static boolean_t is_nd_sll_or_tll_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode);
static boolean_t is_l4_type_extended_valid(sx_flex_acl_key_desc_t   *key,
                                           sx_acl_region_id_t        region_id,
                                           flex_acl_key_build_mode_e build_mode);
static boolean_t is_src_port_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode);
static boolean_t is_dst_port_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode);
static boolean_t is_src_phy_port_valid(sx_flex_acl_key_desc_t   *key,
                                       sx_acl_region_id_t        region_id,
                                       flex_acl_key_build_mode_e build_mode);
static boolean_t is_buff_valid(sx_flex_acl_key_desc_t   *key,
                               sx_acl_region_id_t        region_id,
                               flex_acl_key_build_mode_e build_mode);
static boolean_t is_l4_port_range_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode);
static boolean_t is_rx_list_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  sx_port_type_t            port_type,
                                  flex_acl_key_build_mode_e build_mode);
static boolean_t is_rx_list_valid_network(sx_flex_acl_key_desc_t   *key,
                                          sx_acl_region_id_t        region_id,
                                          flex_acl_key_build_mode_e build_mode);
static boolean_t is_rx_list_valid_tunnel(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode);
static boolean_t is_port_list_valid(sx_flex_acl_key_desc_t   *key,
                                    sx_acl_region_id_t        region_id,
                                    flex_acl_key_build_mode_e build_mode);
static boolean_t is_user_token_valid(sx_flex_acl_key_desc_t   *key,
                                     sx_acl_region_id_t        region_id,
                                     flex_acl_key_build_mode_e build_mode);
static boolean_t is_discard_state_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode);
static boolean_t is_qp_valid(sx_flex_acl_key_desc_t   *key,
                             sx_acl_region_id_t        region_id,
                             flex_acl_key_build_mode_e build_mode);
static boolean_t is_gp_register_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode);
static boolean_t is_gp_register_offset_valid(sx_flex_acl_key_desc_t   *key,
                                             sx_acl_region_id_t        region_id,
                                             flex_acl_key_build_mode_e build_mode);

typedef sx_status_t (*field_conv_func_t)(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                                         uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                                         flex_acl_key_build_mode_e build_mode);
/* Key conversion function declarations */
static sx_status_t __l4_port_range_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode);
static sx_status_t __src_port_conv(sx_flex_acl_key_desc_t   *i_key,
                                   sx_acl_hw_key_e           hw_key,
                                   uint8_t                  *o_key,
                                   uint8_t                  *o_mask,
                                   uint32_t                 *out_len,
                                   flex_acl_key_build_mode_e build_mode);
static sx_status_t __boolean_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode);
static sx_status_t __dst_port_conv(sx_flex_acl_key_desc_t   *i_key,
                                   sx_acl_hw_key_e           hw_key,
                                   uint8_t                  *o_key,
                                   uint8_t                  *o_mask,
                                   uint32_t                 *out_len,
                                   flex_acl_key_build_mode_e build_mode);
static sx_status_t __sip_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                              uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                              flex_acl_key_build_mode_e build_mode);
static sx_status_t __dip_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                              uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                              flex_acl_key_build_mode_e build_mode);
static sx_status_t __dipv6_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode);
static sx_status_t __sipv6_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode);
static sx_status_t __l2_dmac_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                       sx_acl_hw_key_e           hw_key,
                                       uint8_t                  *o_key,
                                       uint8_t                  *o_mask,
                                       uint32_t                 *out_len,
                                       flex_acl_key_build_mode_e build_mode);
static sx_status_t __l3_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode);
static sx_status_t __discard_state_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode);
static sx_status_t __l4_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode);
static sx_status_t __color_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode);
static sx_status_t __switch_prio_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode);
static sx_status_t __buff_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                               uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __rif_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                              uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                              flex_acl_key_build_mode_e build_mode);
static sx_status_t __virtual_router_conv(sx_flex_acl_key_desc_t   *i_key,
                                         sx_acl_hw_key_e           hw_key,
                                         uint8_t                  *o_key,
                                         uint8_t                  *o_mask,
                                         uint32_t                 *out_len,
                                         flex_acl_key_build_mode_e build_mode);
static sx_status_t __tunnel_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode);
static sx_status_t __tunnel_nve_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                          sx_acl_hw_key_e           hw_key,
                                          uint8_t                  *o_key,
                                          uint8_t                  *o_mask,
                                          uint32_t                 *out_len,
                                          flex_acl_key_build_mode_e build_mode);
static sx_status_t __ar_packet_class_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                               sx_acl_hw_key_e           hw_key,
                                               uint8_t                  *o_key,
                                               uint8_t                  *o_mask,
                                               uint32_t                 *out_len,
                                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __nd_sll_or_tll_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode);
static sx_status_t __fid_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                              uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                              flex_acl_key_build_mode_e build_mode);
static sx_status_t __trap_id_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode);
static sx_status_t __l4_type_extended_conv(sx_flex_acl_key_desc_t   *i_key,
                                           sx_acl_hw_key_e           hw_key,
                                           uint8_t                  *o_key,
                                           uint8_t                  *o_mask,
                                           uint32_t                 *out_len,
                                           flex_acl_key_build_mode_e build_mode);
static sx_status_t __rx_list_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode);
static sx_status_t __port_list_conv(sx_flex_acl_key_desc_t   *i_key,
                                    sx_acl_hw_key_e           hw_key,
                                    uint8_t                  *o_key,
                                    uint8_t                  *o_mask,
                                    uint32_t                 *out_len,
                                    flex_acl_key_build_mode_e build_mode);
static sx_status_t __ipv6_extension_conv(sx_flex_acl_key_desc_t   *i_key,
                                         sx_acl_hw_key_e           hw_key,
                                         uint8_t                  *o_key,
                                         uint8_t                  *o_mask,
                                         uint32_t                 *out_len,
                                         flex_acl_key_build_mode_e build_mode);
static sx_status_t __inner_ipv6_extension_conv(sx_flex_acl_key_desc_t   *i_key,
                                               sx_acl_hw_key_e           hw_key,
                                               uint8_t                  *o_key,
                                               uint8_t                  *o_mask,
                                               uint32_t                 *out_len,
                                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __ipv6_extension_headers_conv(uint32_t                             extension_headers_cnt,
                                                 sx_flex_acl_ipv6_extension_header_t *extension_headers_list,
                                                 sx_acl_hw_key_e                      hw_key,
                                                 uint8_t                             *o_key);
static sx_status_t __custom_byte_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode);
static sx_status_t __gp_register_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode);
static sx_status_t __smac_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                               uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __dmac_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                               uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __inner_smac_conv(sx_flex_acl_key_desc_t   *i_key,
                                     sx_acl_hw_key_e           hw_key,
                                     uint8_t                  *o_key,
                                     uint8_t                  *o_mask,
                                     uint32_t                 *out_len,
                                     flex_acl_key_build_mode_e build_mode);
static sx_status_t __inner_dmac_conv(sx_flex_acl_key_desc_t   *i_key,
                                     sx_acl_hw_key_e           hw_key,
                                     uint8_t                  *o_key,
                                     uint8_t                  *o_mask,
                                     uint32_t                 *out_len,
                                     flex_acl_key_build_mode_e build_mode);
static sx_status_t __smpe_conv(sx_flex_acl_key_desc_t *i_key, sx_acl_hw_key_e hw_key,
                               uint8_t *o_key, uint8_t *o_mask, uint32_t *out_len,
                               flex_acl_key_build_mode_e build_mode);
static sx_status_t __gp_register_offset_conv(sx_flex_acl_key_desc_t   *i_key,
                                             sx_acl_hw_key_e           hw_key,
                                             uint8_t                  *o_key,
                                             uint8_t                  *o_mask,
                                             uint32_t                 *out_len,
                                             flex_acl_key_build_mode_e build_mode);
static void __left_shift_array(uint8_t *arr, uint32_t pos, uint32_t len);
static void __right_shift_array(uint8_t *arr, uint32_t pos, uint32_t len);
static sx_status_t __macsec_flow_sec_y_conv(sx_flex_acl_key_desc_t   *i_key,
                                            sx_acl_hw_key_e           hw_key,
                                            uint8_t                  *o_key,
                                            uint8_t                  *o_mask,
                                            uint32_t                 *out_len,
                                            flex_acl_key_build_mode_e build_mode);
static sx_status_t __sci_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode);

/* Key extraction conversion function declarations */
typedef sx_status_t (*field_conv_extract_func_t)(sx_flex_acl_key_desc_t *key_p,
                                                 sx_acl_hw_key_e         hw_key,
                                                 uint8_t                *hw_key_buff_p,
                                                 boolean_t               last_hw_key);
static sx_status_t __src_port_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                           sx_acl_hw_key_e         hw_key,
                                           uint8_t                *hw_key_buff_p,
                                           boolean_t               last_hw_key);
static sx_status_t __dst_port_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                           sx_acl_hw_key_e         hw_key,
                                           uint8_t                *hw_key_buff_p,
                                           boolean_t               last_hw_key);
static sx_status_t __mac_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key);
static sx_status_t __ipv4_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                       sx_acl_hw_key_e         hw_key,
                                       uint8_t                *hw_key_buff_p,
                                       boolean_t               last_hw_key);
static sx_status_t __ipv6_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                       sx_acl_hw_key_e         hw_key,
                                       uint8_t                *hw_key_buff_p,
                                       boolean_t               last_hw_key);
static sx_status_t __l4_port_range_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key);
static sx_status_t __virtual_router_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                 sx_acl_hw_key_e         hw_key,
                                                 uint8_t                *hw_key_buff_p,
                                                 boolean_t               last_hw_key);
static sx_status_t __gp_register_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key);
static sx_status_t __gp_register_offset_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                     sx_acl_hw_key_e         hw_key,
                                                     uint8_t                *hw_key_buff_p,
                                                     boolean_t               last_hw_key);
static sx_status_t __custom_byte_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key);
static sx_status_t __fid_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key);
static sx_status_t __l2_dmac_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                               sx_acl_hw_key_e         hw_key,
                                               uint8_t                *hw_key_buff_p,
                                               boolean_t               last_hw_key);
static sx_status_t __l3_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key);
static sx_status_t __discard_state_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key);
static sx_status_t __l4_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key);
static sx_status_t __l4_type_extended_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                   sx_acl_hw_key_e         hw_key,
                                                   uint8_t                *hw_key_buff_p,
                                                   boolean_t               last_hw_key);
static sx_status_t __rif_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key);
static sx_status_t __tunnel_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key);
static sx_status_t __tunnel_nve_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                  sx_acl_hw_key_e         hw_key,
                                                  uint8_t                *hw_key_buff_p,
                                                  boolean_t               last_hw_key);
static sx_status_t __nd_sll_or_tll_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key);
static sx_status_t __ipv6_extension_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                 sx_acl_hw_key_e         hw_key,
                                                 uint8_t                *hw_key_buff_p,
                                                 boolean_t               last_hw_key);
static sx_status_t __boolean_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key);
static sx_status_t __key_extract_not_supported(sx_flex_acl_key_desc_t *key_p,
                                               sx_acl_hw_key_e         hw_key,
                                               uint8_t                *hw_key_buff_p,
                                               boolean_t               last_hw_key);

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Key validation function array
 ***********************************************/
static is_key_value_valid_t keys_validation[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_SIP] = is_ip_valid,
    [FLEX_ACL_KEY_DIP] = is_ip_valid,
    [FLEX_ACL_KEY_COLOR] = is_color_valid,
    [FLEX_ACL_KEY_DSCP] = is_dscp_valid,
    [FLEX_ACL_KEY_RW_DSCP] = is_bit_valid,
    [FLEX_ACL_KEY_L2_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_ECN] = is_2bits_valid,
    [FLEX_ACL_KEY_IP_FRAGMENTED] = is_bit_valid,
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = is_bit_valid,
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = is_bit_valid,
    [FLEX_ACL_KEY_IP_OK] = is_bit_valid,
    [FLEX_ACL_KEY_IS_ARP] = is_bit_valid,
    [FLEX_ACL_KEY_URPF_FAIL] = is_bit_valid,
    [FLEX_ACL_KEY_IP_OPT] = is_bit_valid,
    [FLEX_ACL_KEY_IS_IP_V4] = is_bit_valid,
    [FLEX_ACL_KEY_L3_TYPE] = is_l3_type_valid,
    [FLEX_ACL_KEY_TTL_OK] = is_bit_valid,
    [FLEX_ACL_KEY_L4_OK] = is_bit_valid,
    [FLEX_ACL_KEY_MC_TYPE] = is_mc_type_valid,
    [FLEX_ACL_KEY_L4_TYPE] = is_l4_type_valid,
    [FLEX_ACL_KEY_TCP_CONTROL] = is_tcp_control_valid,
    [FLEX_ACL_KEY_TCP_ECN] = is_3bits_field_valid,
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = is_l2_dmac_type_valid,
    [FLEX_ACL_KEY_SRC_PORT] = is_src_port_valid,
    [FLEX_ACL_KEY_DST_PORT] = is_dst_port_valid,
    [FLEX_ACL_KEY_SRC_PHY_PORT] = is_src_phy_port_valid,
    [FLEX_ACL_KEY_RW_PCP] = is_bit_valid,
    [FLEX_ACL_KEY_DEI] = is_bit_valid,
    [FLEX_ACL_KEY_PCP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_INNER_DEI] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_PCP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_TUNNEL_DEI] = is_bit_valid,
    [FLEX_ACL_KEY_TUNNEL_PCP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_TUNNEL_INNER_DEI] = is_bit_valid,
    [FLEX_ACL_KEY_TUNNEL_INNER_PCP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_VLAN_TAGGED] = is_bit_valid,
    [FLEX_ACL_KEY_VLAN_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_VLAN_ID] = is_vlan_id_valid,
    [FLEX_ACL_KEY_INNER_VLAN_ID] = is_vlan_id_valid,
    [FLEX_ACL_KEY_TUNNEL_VLAN_ID] = is_vlan_id_valid,
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID] = is_vlan_id_valid,
    [FLEX_ACL_KEY_SWITCH_PRIO] = is_nible_valid,
    [FLEX_ACL_KEY_DMAC_IS_UC] = is_bit_valid,
    [FLEX_ACL_KEY_BUFF] = is_buff_valid,
    [FLEX_ACL_KEY_L4_PORT_RANGE] = is_l4_port_range_valid,
    [FLEX_ACL_KEY_SIPV6] = is_ip_valid,
    [FLEX_ACL_KEY_DIPV6] = is_ip_valid,
    [FLEX_ACL_KEY_INNER_SIPV6] = is_ip_valid,
    [FLEX_ACL_KEY_INNER_DIPV6] = is_ip_valid,
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = is_ip_valid,
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = is_ip_valid,
    [FLEX_ACL_KEY_IRIF] = is_rif_valid,
    [FLEX_ACL_KEY_ERIF] = is_rif_valid,
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = is_virtual_router_valid,
    [FLEX_ACL_KEY_TUNNEL_TYPE] = is_tunnel_type_valid,
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = is_tunnel_nve_type_valid,
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = is_l4_type_extended_valid,
    [FLEX_ACL_KEY_RX_LIST] = is_rx_list_valid_network,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] = is_ipv6_extension_valid,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] = is_ipv6_extension_valid,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_DIP] = is_ip_valid,
    [FLEX_ACL_KEY_INNER_SIP] = is_ip_valid,
    [FLEX_ACL_KEY_INNER_TTL_OK] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_L4_OK] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_OK] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_OPT] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_L3_TYPE] = is_l3_type_valid,
    [FLEX_ACL_KEY_USER_TOKEN] = is_user_token_valid,
    [FLEX_ACL_KEY_DISCARD_STATE] = is_discard_state_valid,
    [FLEX_ACL_KEY_IS_TRAPPED] = is_bit_valid,
    [FLEX_ACL_KEY_IS_MPLS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IS_MPLS] = is_bit_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = is_label_id_valid,
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = is_mpls_labels_valid_valid,
    [FLEX_ACL_KEY_MPLS_ECN] = is_2bits_valid,
    [FLEX_ACL_KEY_INNER_MPLS_ECN] = is_2bits_valid,
    [FLEX_ACL_KEY_RW_EXP] = is_bit_valid,
    [FLEX_ACL_KEY_EXP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_INNER_EXP] = is_3bits_field_valid,
    [FLEX_ACL_KEY_BOS] = is_bit_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST] = is_port_list_valid,
    [FLEX_ACL_KEY_IS_ROUTED] = is_bit_valid,
    [FLEX_ACL_KEY_ROCE_DEST_QP] = is_qp_valid,
    [FLEX_ACL_KEY_DWORD_0_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_DWORD_1_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_DWORD_2_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_DWORD_3_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_DWORD_4_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_DWORD_5_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_FID] = is_fid_valid,
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = is_bit_valid,
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = is_nd_sll_or_tll_valid,
    [FLEX_ACL_KEY_IP_MORE_FRAGMENTS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_BOS] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1] = is_label_id_valid,
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2] = is_label_id_valid,
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3] = is_label_id_valid,
    [FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID] = is_mpls_labels_valid_valid,
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = is_l4_type_extended_valid,
    [FLEX_ACL_KEY_INNER_TCP_CONTROL] = is_tcp_control_valid,
    [FLEX_ACL_KEY_INNER_TCP_ECN] = is_3bits_field_valid,
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = is_bit_valid,
    [FLEX_ACL_KEY_IS_TCP_OPTION] = is_bit_valid,
    [FLEX_ACL_KEY_TRAP_ID] = is_trap_id_valid,
    [FLEX_ACL_KEY_FDB_MISS] = is_bit_valid,
    [FLEX_ACL_KEY_LLC_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = is_fid_valid,
    [FLEX_ACL_KEY_IS_BUM] = is_bit_valid,
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_0] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_1] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_2] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_3] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_4] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_5] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_6] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_7] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_8] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_9] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_10] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_11] = is_gp_register_valid,
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_10_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_11_VALID] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = is_bit_valid,
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = is_gp_register_offset_valid,
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = is_gp_register_offset_valid,
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = is_ar_packet_class_type_valid,
    [FLEX_ACL_KEY_IS_ARN] = is_bit_valid,
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = is_rx_list_valid_tunnel,
    [FLEX_ACL_KEY_MAC_COMPARE] = is_bit_valid,
    [FLEX_ACL_KEY_IP_COMPARE] = is_bit_valid,
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = is_bit_valid,
    [FLEX_ACL_KEY_DEFAULT_ROUTE_HIT] = is_bit_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_1_128] = is_port_list_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_129_258] = is_port_list_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_0] = is_port_list_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_1] = is_port_list_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_2] = is_port_list_valid,
    [FLEX_ACL_KEY_RX_PORT_LIST_3] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_1_128] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_129_258] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_0] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_1] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_2] = is_port_list_valid,
    [FLEX_ACL_KEY_TX_PORT_LIST_3] = is_port_list_valid,
};

/************************************************
 *  Key conversion function array
 ***********************************************/
static field_conv_func_t special_field_conv[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_SRC_PORT] = __src_port_conv,
    [FLEX_ACL_KEY_DST_PORT] = __dst_port_conv,
    [FLEX_ACL_KEY_SRC_PHY_PORT] = __src_port_conv,
    [FLEX_ACL_KEY_RW_PCP] = __boolean_conv,
    [FLEX_ACL_KEY_VLAN_TAGGED] = __boolean_conv,
    [FLEX_ACL_KEY_VLAN_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_FID] = __fid_conv,
    [FLEX_ACL_KEY_RW_DSCP] = __boolean_conv,
    [FLEX_ACL_KEY_IP_FRAGMENTED] = __boolean_conv,
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = __boolean_conv,
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = __boolean_conv,
    [FLEX_ACL_KEY_IP_OK] = __boolean_conv,
    [FLEX_ACL_KEY_IS_ARP] = __boolean_conv,
    [FLEX_ACL_KEY_URPF_FAIL] = __boolean_conv,
    [FLEX_ACL_KEY_IP_OPT] = __boolean_conv,
    [FLEX_ACL_KEY_IS_IP_V4] = __boolean_conv,
    [FLEX_ACL_KEY_TTL_OK] = __boolean_conv,
    [FLEX_ACL_KEY_L4_OK] = __boolean_conv,
    [FLEX_ACL_KEY_SIP] = __sip_conv,
    [FLEX_ACL_KEY_DIP] = __dip_conv,
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = __l2_dmac_type_conv,
    [FLEX_ACL_KEY_L3_TYPE] = __l3_type_conv,
    [FLEX_ACL_KEY_L4_TYPE] = __l4_type_conv,
    [FLEX_ACL_KEY_COLOR] = __color_conv,
    [FLEX_ACL_KEY_SWITCH_PRIO] = __switch_prio_conv,
    [FLEX_ACL_KEY_BUFF] = __buff_conv,
    [FLEX_ACL_KEY_L4_PORT_RANGE] = __l4_port_range_conv,
    [FLEX_ACL_KEY_DIPV6] = __dipv6_conv,
    [FLEX_ACL_KEY_SIPV6] = __sipv6_conv,
    [FLEX_ACL_KEY_INNER_DIPV6] = __dipv6_conv,
    [FLEX_ACL_KEY_INNER_SIPV6] = __sipv6_conv,
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = __dipv6_conv,
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = __dipv6_conv,
    [FLEX_ACL_KEY_IRIF] = __rif_conv,
    [FLEX_ACL_KEY_ERIF] = __rif_conv,
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = __virtual_router_conv,
    [FLEX_ACL_KEY_TUNNEL_TYPE] = __tunnel_type_conv,
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = __tunnel_nve_type_conv,
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = __nd_sll_or_tll_conv,
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = __l4_type_extended_conv,
    [FLEX_ACL_KEY_RX_LIST] = __rx_list_conv,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] = __ipv6_extension_conv,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] = __inner_ipv6_extension_conv,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_DIP] = __dip_conv,
    [FLEX_ACL_KEY_INNER_SIP] = __sip_conv,
    [FLEX_ACL_KEY_INNER_TTL_OK] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_L4_OK] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IP_OK] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IP_OPT] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_L3_TYPE] = __l3_type_conv,
    [FLEX_ACL_KEY_DISCARD_STATE] = __discard_state_conv,
    [FLEX_ACL_KEY_IS_TRAPPED] = __boolean_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST] = __port_list_conv,
    [FLEX_ACL_KEY_IS_ROUTED] = __boolean_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_20] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_21] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_22] = __custom_byte_conv,
    [FLEX_ACL_KEY_CUSTOM_BYTE_23] = __custom_byte_conv,
    [FLEX_ACL_KEY_BOS] = __boolean_conv,
    [FLEX_ACL_KEY_IS_MPLS] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IS_MPLS] = __boolean_conv,
    [FLEX_ACL_KEY_RW_EXP] = __boolean_conv,
    [FLEX_ACL_KEY_DMAC] = __dmac_conv,
    [FLEX_ACL_KEY_SMAC] = __smac_conv,
    [FLEX_ACL_KEY_INNER_DMAC] = __inner_dmac_conv,
    [FLEX_ACL_KEY_INNER_SMAC] = __inner_smac_conv,
    [FLEX_ACL_KEY_DWORD_0_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_DWORD_1_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_DWORD_2_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_DWORD_3_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_DWORD_4_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_DWORD_5_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_BOS] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = __l4_type_extended_conv,
    [FLEX_ACL_KEY_IS_TCP_OPTION] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = __boolean_conv,
    [FLEX_ACL_KEY_TRAP_ID] = __trap_id_conv,
    [FLEX_ACL_KEY_FDB_MISS] = __boolean_conv,
    [FLEX_ACL_KEY_LLC_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = __smpe_conv,
    [FLEX_ACL_KEY_IS_BUM] = __boolean_conv,
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_0] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_1] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_2] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_3] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_4] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_5] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_6] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_7] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_8] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_9] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_10] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_11] = __gp_register_conv,
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_10_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_11_VALID] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = __boolean_conv,
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = __gp_register_offset_conv,
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = __gp_register_offset_conv,
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = __ar_packet_class_type_conv,
    [FLEX_ACL_KEY_IS_ARN] = __boolean_conv,
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = __rx_list_conv,
    [FLEX_ACL_KEY_MAC_COMPARE] = __boolean_conv,
    [FLEX_ACL_KEY_IP_COMPARE] = __boolean_conv,
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = __boolean_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_1_128] = __port_list_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_129_258] = __port_list_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_0] = __port_list_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_1] = __port_list_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_2] = __port_list_conv,
    [FLEX_ACL_KEY_RX_PORT_LIST_3] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_1_128] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_129_258] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_0] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_1] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_2] = __port_list_conv,
    [FLEX_ACL_KEY_TX_PORT_LIST_3] = __port_list_conv,
    [FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID] = __macsec_flow_sec_y_conv,
    [FLEX_ACL_KEY_MACSEC_DMAC] = __dmac_conv,
    [FLEX_ACL_KEY_MACSEC_SCI] = __sci_conv,
};


/************************************************
 *  Key conversion function array
 ***********************************************/
static field_conv_extract_func_t special_field_extract_conv[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_SRC_PORT] = __src_port_conv_extract,
    [FLEX_ACL_KEY_DST_PORT] = __dst_port_conv_extract,
    [FLEX_ACL_KEY_SRC_PHY_PORT] = __src_port_conv_extract,
    [FLEX_ACL_KEY_DMAC] = __mac_conv_extract,
    [FLEX_ACL_KEY_SMAC] = __mac_conv_extract,
    [FLEX_ACL_KEY_INNER_DMAC] = __mac_conv_extract,
    [FLEX_ACL_KEY_INNER_SMAC] = __mac_conv_extract,
    [FLEX_ACL_KEY_DIP] = __ipv4_conv_extract,
    [FLEX_ACL_KEY_SIP] = __ipv4_conv_extract,
    [FLEX_ACL_KEY_INNER_DIP] = __ipv4_conv_extract,
    [FLEX_ACL_KEY_INNER_SIP] = __ipv4_conv_extract,
    [FLEX_ACL_KEY_DIPV6] = __ipv6_conv_extract,
    [FLEX_ACL_KEY_SIPV6] = __ipv6_conv_extract,
    [FLEX_ACL_KEY_INNER_DIPV6] = __ipv6_conv_extract,
    [FLEX_ACL_KEY_INNER_SIPV6] = __ipv6_conv_extract,
    [FLEX_ACL_KEY_L4_PORT_RANGE] = __l4_port_range_conv_extract,
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = __virtual_router_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_0] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_1] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_2] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_3] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_4] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_5] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_6] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_7] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_8] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_9] = __gp_register_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = __gp_register_offset_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = __gp_register_offset_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] = __custom_byte_conv_extract,
    [FLEX_ACL_KEY_FID] = __fid_conv_extract,
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = __l2_dmac_type_conv_extract,
    [FLEX_ACL_KEY_L3_TYPE] = __l3_type_conv_extract,
    [FLEX_ACL_KEY_INNER_L3_TYPE] = __l3_type_conv_extract,
    [FLEX_ACL_KEY_L4_TYPE] = __l4_type_conv_extract,
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = __l4_type_extended_conv_extract,
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = __l4_type_extended_conv_extract,
    [FLEX_ACL_KEY_DISCARD_STATE] = __discard_state_conv_extract,
    [FLEX_ACL_KEY_IRIF] = __rif_conv_extract,
    [FLEX_ACL_KEY_ERIF] = __rif_conv_extract,
    [FLEX_ACL_KEY_TUNNEL_TYPE] = __tunnel_type_conv_extract,
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = __tunnel_nve_type_conv_extract,
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = __nd_sll_or_tll_conv_extract,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] = __ipv6_extension_conv_extract,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] = __ipv6_extension_conv_extract,
    [FLEX_ACL_KEY_RX_LIST] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = __key_extract_not_supported,
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RW_PCP] = __boolean_conv_extract,
    [FLEX_ACL_KEY_VLAN_TAGGED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_VLAN_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_RW_DSCP] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_FRAGMENTED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_ARP] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_OPT] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_IP_V4] = __boolean_conv_extract,
    [FLEX_ACL_KEY_TTL_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_L4_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_TTL_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_L4_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IP_OK] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IP_OPT] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_TRAPPED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_ROUTED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_BOS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_MPLS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IS_MPLS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_RW_EXP] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_0_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_1_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_2_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_3_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_4_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_DWORD_5_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_BOS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_TCP_OPTION] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FDB_MISS] = __boolean_conv_extract,
    [FLEX_ACL_KEY_LLC_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IS_BUM] = __boolean_conv_extract,
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = __boolean_conv_extract,
    [FLEX_ACL_KEY_MAC_COMPARE] = __boolean_conv_extract,
    [FLEX_ACL_KEY_IP_COMPARE] = __boolean_conv_extract,
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = __boolean_conv_extract,
    [FLEX_ACL_KEY_RX_PORT_LIST_1_128] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST_129_258] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST_0] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST_1] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST_2] = __key_extract_not_supported,
    [FLEX_ACL_KEY_RX_PORT_LIST_3] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_1_128] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_129_258] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_0] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_1] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_2] = __key_extract_not_supported,
    [FLEX_ACL_KEY_TX_PORT_LIST_3] = __key_extract_not_supported,
};

/************************************************
 *  Function implementations
 ***********************************************/

/***********************************************
*  Key validation functions
***********************************************/
static boolean_t is_qp_valid(sx_flex_acl_key_desc_t   *key,
                             sx_acl_region_id_t        region_id,
                             flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    /* qp is 24 bits long. */
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.dest_qp > 0xFFFFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("dest_qp key value :%d is not valid.\n", key->key.dest_qp);
            goto out;
        }
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (key->mask.dest_qp > 0xFFFFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("dest_qp mask value :%d is not valid.\n", key->mask.dest_qp);
        }
    }

out:
    return is_valid;
}

static boolean_t is_dscp_valid(sx_flex_acl_key_desc_t   *key,
                               sx_acl_region_id_t        region_id,
                               flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    /* DSCP is 6 bits long. */
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.dscp > 0x3F) {
            is_valid = FALSE;
            SX_LOG_ERR("dscp key value :%d is not valid.\n", key->key.dscp);
            goto out;
        }
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (key->mask.dscp > 0x3F) {
            is_valid = FALSE;
            SX_LOG_ERR("dscp mask value :%d is not valid.\n", key->mask.dscp);
        }
    }

out:
    return is_valid;
}

static boolean_t is_color_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(color, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.color >= SX_ACL_FLEX_COLOR_LAST) {
            is_valid = FALSE;
            SX_LOG_ERR("color key value :%d is not valid.\n", key->key.color);
        }
    }

out:
    return is_valid;
}

static boolean_t is_ip_version_valid(sx_ip_addr_t              key_ip,
                                     sx_ip_addr_t              mask_ip,
                                     sx_ip_version_t           ip_version,
                                     boolean_t                 is_sip,
                                     flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key_ip.version != ip_version) {
            is_valid = FALSE;
            SX_LOG_ERR("Key %s %s does not have proper IP version .\n",
                       ip_version == SX_IP_VERSION_IPV4 ? "IPV4" : "IPV6",
                       is_sip ? "SIP" : "DIP");
        }
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (mask_ip.version != ip_version) {
            is_valid = FALSE;
            SX_LOG_ERR("Mask %s %s does not have proper IP version .\n",
                       ip_version == SX_IP_VERSION_IPV4 ? "IPV4" : "IPV6",
                       is_sip ? "SIP" : "DIP");
        }
    }

    return is_valid;
}

static boolean_t is_ip_valid(sx_flex_acl_key_desc_t   *key,
                             sx_acl_region_id_t        region_id,
                             flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    switch ((flex_acl_system_key_e)key->key_id) {
    case FLEX_ACL_SYSTEM_KEY_DIPV6_LSB:
        is_valid = is_ip_version_valid(key->key.dipv6_lsb, key->mask.dipv6_lsb, SX_IP_VERSION_IPV6, FALSE, build_mode);
        goto out;

    case FLEX_ACL_SYSTEM_KEY_DIPV6_MSB:
        is_valid = is_ip_version_valid(key->key.dipv6_msb, key->mask.dipv6_msb, SX_IP_VERSION_IPV6, FALSE, build_mode);
        goto out;

    default:
        break;
    }

    switch (key->key_id) {
    case FLEX_ACL_KEY_SIP:
        is_valid = is_ip_version_valid(key->key.sip, key->mask.sip, SX_IP_VERSION_IPV4, TRUE, build_mode);
        break;

    case FLEX_ACL_KEY_INNER_SIP:
        is_valid = is_ip_version_valid(key->key.inner_sip, key->mask.inner_sip, SX_IP_VERSION_IPV4, FALSE, build_mode);
        break;

    case FLEX_ACL_KEY_DIP:
        is_valid = is_ip_version_valid(key->key.dip, key->mask.dip, SX_IP_VERSION_IPV4, FALSE, build_mode);
        break;

    case FLEX_ACL_KEY_INNER_DIP:
        is_valid = is_ip_version_valid(key->key.inner_dip, key->mask.inner_dip, SX_IP_VERSION_IPV4, FALSE, build_mode);
        break;

    case FLEX_ACL_KEY_DIPV6:
        is_valid = is_ip_version_valid(key->key.dipv6, key->mask.dipv6, SX_IP_VERSION_IPV6, FALSE, build_mode);
        break;

    case FLEX_ACL_KEY_SIPV6:
        is_valid = is_ip_version_valid(key->key.sipv6, key->mask.sipv6, SX_IP_VERSION_IPV6, TRUE, build_mode);
        break;

    case FLEX_ACL_KEY_INNER_SIPV6:
        is_valid = is_ip_version_valid(key->key.inner_sipv6,
                                       key->mask.inner_sipv6,
                                       SX_IP_VERSION_IPV6,
                                       TRUE,
                                       build_mode);
        break;

    case FLEX_ACL_KEY_INNER_DIPV6:
        is_valid = is_ip_version_valid(key->key.inner_dipv6,
                                       key->mask.inner_dipv6,
                                       SX_IP_VERSION_IPV6,
                                       FALSE,
                                       build_mode);
        break;

    default:
        SX_LOG_ERR("Key %s is not ipv4 and not ipv6 sip or dip\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;

        break;
    }

out:
    return is_valid;
}

static boolean_t is_ipv6_extension_valid(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode)
{
    boolean_t                            is_valid = TRUE;
    uint32_t                             i;
    uint32_t                             extension_headers_cnt;
    uint32_t                             extension_headers_last = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST;
    sx_flex_acl_ipv6_extension_header_t *extension_headers_list = NULL;
    acl_stage_e                          acl_stage = ACL_STAGE_UNKNOWN;

    UNUSED_PARAM(region_id);

    if (flex_acl_ops_g->acl_stage_get_p(&acl_stage) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get acl stage.\n");
        is_valid = FALSE;
        goto out;
    }

    switch (key->key_id) {
    case FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS:
        if (IS_KEY_BUILD_MASK(build_mode)) {
            BOOLEAN_MASK_CHECK(ipv6_extension_headers, is_valid, out);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            extension_headers_cnt = key->key.ipv6_extension_headers.extension_headers_cnt;
            if (acl_stage == ACL_STAGE_FLEX) {
                extension_headers_last = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_SHIM6;
            }
            extension_headers_list = key->key.ipv6_extension_headers.extension_headers_list;
        }
        break;

    case FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS:
        if (acl_stage == ACL_STAGE_FLEX) {
            SX_LOG_ERR("Key %s is not supported for Spectrum\n", flex_acl_db_key_id_to_str(key->key_id));
        }
        if (IS_KEY_BUILD_MASK(build_mode)) {
            BOOLEAN_MASK_CHECK(inner_ipv6_extension_headers, is_valid, out);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            extension_headers_cnt = key->key.inner_ipv6_extension_headers.extension_headers_cnt;
            extension_headers_list = key->key.inner_ipv6_extension_headers.extension_headers_list;
        }
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (extension_headers_cnt > extension_headers_last) {
            SX_LOG_ERR("Invalid number of header extensions %d. Max number of extension : %d\n",
                       extension_headers_cnt, SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST);
            is_valid = FALSE;
            goto out;
        }
        for (i = 0; i < extension_headers_cnt; i++) {
            if (extension_headers_list[i] >= extension_headers_last) {
                SX_LOG_ERR("Invalid header extensions %u\n",
                           extension_headers_list[i]);
                is_valid = FALSE;
                goto out;
            }
        }
    }

out:
    return is_valid;
}

static boolean_t is_tcp_control_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint8_t   tcp_control_key;
    uint8_t   tcp_control_mask;

    UNUSED_PARAM(region_id);

    switch (key->key_id) {
    case FLEX_ACL_KEY_TCP_CONTROL:
        tcp_control_mask = key->mask.tcp_control;
        tcp_control_key = key->key.tcp_control;
        break;

    case FLEX_ACL_KEY_INNER_TCP_CONTROL:
        tcp_control_mask = key->mask.inner_tcp_control;
        tcp_control_key = key->key.inner_tcp_control;
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }

    /* tcp control is 6 bits long. */
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (tcp_control_mask > 0x3f) {
            is_valid = FALSE;
            SX_LOG_ERR("tcp_control mask value :%x is not valid.\n", tcp_control_mask);
            goto out;
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (tcp_control_key > 0x3f) {
            is_valid = FALSE;
            SX_LOG_ERR("tcp_control key value :%x is not valid.\n", tcp_control_key);
        }
    }

out:
    return is_valid;
}

static boolean_t is_l4_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(l4_type, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.l4_type > SX_ACL_L4_TYPE_MAX) {
            is_valid = FALSE;
            SX_LOG_ERR("l4 type valid key value is not valid. value:%#x\n", key->key.l4_type);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_mc_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (key->mask.mc_type_vector > SX_ACL_MC_TYPE_MAX) {
            is_valid = FALSE;
            SX_LOG_ERR("mc bc_or_flood type valid mask value is not valid. value:%#x\n", key->mask.mc_type_vector);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.mc_type_vector > SX_ACL_MC_TYPE_MAX) {
            is_valid = FALSE;
            SX_LOG_ERR("mc bc_or_flood type valid key value is not valid. value:%#x\n", key->key.mc_type_vector);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_3bits_field_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint8_t   mask_val, key_val;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        mask_val = *((uint8_t*)&(key->mask));
        if (mask_val > 7) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s mask value is to big. value:%x max value :%x\n",
                       flex_acl_db_key_id_to_str(key->key_id),
                       mask_val,
                       7);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        key_val = *((uint8_t*)&(key->key));
        if (key_val > 7) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s key value is to big. value:%x max value :%x\n", flex_acl_db_key_id_to_str(key->key_id),
                       key_val, 7);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_vlan_id_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t    is_valid = TRUE;
    sx_vlan_id_t vlan_id_key;
    sx_vlan_id_t vlan_id_mask;


    UNUSED_PARAM(region_id);

    switch (key->key_id) {
    case FLEX_ACL_KEY_VLAN_ID:
        vlan_id_mask = key->mask.vlan_id;
        vlan_id_key = key->key.vlan_id;
        break;

    case FLEX_ACL_KEY_INNER_VLAN_ID:
        vlan_id_mask = key->mask.inner_vlan_id;
        vlan_id_key = key->key.inner_vlan_id;
        break;

    case FLEX_ACL_KEY_TUNNEL_VLAN_ID:
        vlan_id_mask = key->mask.tunnel_vlan_id;
        vlan_id_key = key->key.tunnel_vlan_id;
        break;

    case FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID:
        vlan_id_mask = key->mask.tunnel_inner_vlan_id;
        vlan_id_key = key->key.tunnel_inner_vlan_id;
        break;

    default:
        SX_LOG_ERR("Key %s is invalid for vlan id\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (vlan_id_mask > 0xFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("vlan id type mask value :%#x is not valid.\n", vlan_id_mask);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (vlan_id_key > 0xFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("vlan id type key value :%#x is not valid.\n", vlan_id_key);
        }
    }

out:
    return is_valid;
}

static boolean_t is_bit_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint8_t   mask_val, key_val;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        mask_val = *((uint8_t*)&(key->mask));
        if ((mask_val != 1) && (mask_val != 0)) {
            is_valid = FALSE;
            SX_LOG_ERR("ACL : mask is not valid for %s. mask:%x \n", flex_acl_db_key_id_to_str(key->key_id),
                       mask_val);
            goto out;
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        key_val = *((uint8_t*)&(key->key));
        if (key_val > 1) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s bit key value is to big value:%x.\n", flex_acl_db_key_id_to_str(key->key_id), key_val);
        }
    }

out:
    return is_valid;
}

static boolean_t is_fid_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode)
{
    sx_status_t      rc;
    boolean_t        is_valid = TRUE;
    sx_fid_t         fid;
    sx_fm_fid_type_t fid_type = SX_FM_FID_TYPE_INVALID;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key_id == FLEX_ACL_KEY_BUM_BRIDGE_ID) {
            fid = key->key.bum_bridge_id;
        } else {
            fid = key->key.fid;
        }

        rc = sdk_fid_manager_get_fid_type(fid, &fid_type);
        if (rc != SX_STATUS_SUCCESS) {
            is_valid = FALSE;
            goto out;
        }
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (key->key_id == FLEX_ACL_KEY_BUM_BRIDGE_ID) {
            BOOLEAN_MASK_CHECK(bum_bridge_id, is_valid, out);
        } else {
            BOOLEAN_MASK_CHECK(fid, is_valid, out);
        }
    }

out:
    return is_valid;
}

static boolean_t is_gp_register_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    boolean_t         is_valid = TRUE;
    sx_register_key_t reg_key;
    boolean_t         is_allocated = FALSE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(build_mode);
    SX_MEM_CLR(reg_key);

    reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    reg_key.key.gp_reg.reg_id = key->key_id - FLEX_ACL_KEY_GP_REGISTER_START;

    rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
    if ((rc != SX_STATUS_SUCCESS) || (is_allocated == FALSE)) {
        SX_LOG_ERR("ACL: GP register [%u] is not allocated. Validation for region [%u]\n",
                   reg_key.key.gp_reg.reg_id,
                   region_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t is_gp_register_offset_valid(sx_flex_acl_key_desc_t   *key,
                                             sx_acl_region_id_t        region_id,
                                             flex_acl_key_build_mode_e build_mode)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    boolean_t         is_valid = TRUE;
    sx_register_key_t reg_key;
    boolean_t         is_allocated = FALSE;

    UNUSED_PARAM(region_id);
    SX_MEM_CLR(reg_key);

    reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    reg_key.key.gp_reg.reg_id = key->key_id - FLEX_ACL_KEY_GP_REGISTER_OFFSET_START;

    rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
    if ((rc != SX_STATUS_SUCCESS) || (is_allocated == FALSE)) {
        SX_LOG_ERR("ACL: GP register [%u] offset is not allocated. Validation for region [%u]\n",
                   reg_key.key.gp_reg.reg_id,
                   region_id);
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (((key->key.gp_register_offset & 0x1) != 0) || (key->key.gp_register_offset > (UINT8_MAX * 2))) {
            SX_LOG_ERR(
                "ACL: GP register offset [%u] should be even number and not exceed [%u]. Validation for region [%u]\n",
                (UINT8_MAX * 2),
                key->key.gp_register_offset,
                region_id);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}


static boolean_t is_trap_id_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint16_t  key_val = 0;


    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        key_val = key->key.trap_id;
        if ((key_val < SX_TRAP_ID_MIN) || (key_val > SX_TRAP_ID_MAX)) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s key value is out of range. value:%#x \n",
                       flex_acl_db_key_id_to_str(key->key_id),
                       key_val);
            goto out;
        }

        /* Validate trap ID is supported as an ACL key. */
        if (trap_id_is_acl_key_supported(key_val) == FALSE) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s key value isn't valid. trap_id:%#x \n",
                       flex_acl_db_key_id_to_str(key->key_id),
                       key_val);
            goto out;
        }
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(trap_id, is_valid, out);
    }

out:
    return is_valid;
}

static boolean_t is_2bits_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint8_t   mask_val, key_val;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        mask_val = *((uint8_t*)&(key->mask));
        if (mask_val > 3) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s mask value is to big. value:%#x \n", flex_acl_db_key_id_to_str(key->key_id), mask_val);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        key_val = *((uint8_t*)&(key->key));
        if (key_val > 3) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s key value is to big. value:%#x \n", flex_acl_db_key_id_to_str(key->key_id), key_val);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_nible_valid(sx_flex_acl_key_desc_t   *key,
                                sx_acl_region_id_t        region_id,
                                flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;
    uint8_t   mask_val, key_val;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        mask_val = *((uint8_t*)&(key->mask));
        if (mask_val > 0xf) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s mask value is to big. value:%#x \n", flex_acl_db_key_id_to_str(key->key_id), mask_val);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        key_val = *((uint8_t*)&(key->key));
        if (key_val > 0xf) {
            is_valid = FALSE;
            SX_LOG_ERR("Key :%s key value is to big. value:%#x \n", flex_acl_db_key_id_to_str(key->key_id), key_val);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_l2_dmac_type_valid(sx_flex_acl_key_desc_t   *key,
                                       sx_acl_region_id_t        region_id,
                                       flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(l2_dmac_type, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.l2_dmac_type > SX_ACL_L2_DMAC_TYPE_MAX) {
            SX_LOG_ERR("L2_DMAC_TYPE value is not valid. value:%x\n", key->key.l2_dmac_type);
            is_valid = FALSE;
        }
    }

out:
    return is_valid;
}

static boolean_t is_l3_type_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(l3_type, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.l3_type > SX_ACL_L3_TYPE_MAX) {
            SX_LOG_ERR("L3_TYPE value is not valid. value:%x\n", key->key.l3_type);
            is_valid = FALSE;
        }
    }

out:
    return is_valid;
}

static boolean_t is_label_id_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    sx_mpls_label_t* label_key = NULL;
    sx_mpls_label_t* label_mask = NULL;

    switch (key->key_id) {
    case FLEX_ACL_KEY_MPLS_LABEL_ID_1:
        label_key = &(key->key.mpls_label_id_1);
        label_mask = &(key->mask.mpls_label_id_1);
        break;

    case FLEX_ACL_KEY_MPLS_LABEL_ID_2:
        label_key = &(key->key.mpls_label_id_2);
        label_mask = &(key->mask.mpls_label_id_2);
        break;

    case FLEX_ACL_KEY_MPLS_LABEL_ID_3:
        label_key = &(key->key.mpls_label_id_3);
        label_mask = &(key->mask.mpls_label_id_3);
        break;

    case FLEX_ACL_KEY_MPLS_LABEL_ID_4:
        label_key = &(key->key.mpls_label_id_4);
        label_mask = &(key->mask.mpls_label_id_4);
        break;

    case FLEX_ACL_KEY_MPLS_LABEL_ID_5:
        label_key = &(key->key.mpls_label_id_5);
        label_mask = &(key->mask.mpls_label_id_5);
        break;

    case FLEX_ACL_KEY_MPLS_LABEL_ID_6:
        label_key = &(key->key.mpls_label_id_6);
        label_mask = &(key->mask.mpls_label_id_6);
        break;

    case FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1:
        label_key = &(key->key.inner_mpls_label_id_1);
        label_mask = &(key->mask.inner_mpls_label_id_1);
        break;

    case FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2:
        label_key = &(key->key.inner_mpls_label_id_2);
        label_mask = &(key->mask.inner_mpls_label_id_2);
        break;

    case FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3:
        label_key = &(key->key.inner_mpls_label_id_3);
        label_mask = &(key->mask.inner_mpls_label_id_3);
        break;

    default:
        SX_LOG_ERR("Key %s is invalid for mpls\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (*label_key > 0xFFFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("label id %u is not valid for key type %s.\n",
                       *label_key,
                       flex_acl_db_key_id_to_str(key->key_id));
        }
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (*label_mask > 0xFFFFF) {
            is_valid = FALSE;
            SX_LOG_ERR("label mask 0x%x is not valid for key type %s.\n", *label_mask,
                       flex_acl_db_key_id_to_str(key->key_id));
        }
    }
out:
    return is_valid;
}

static boolean_t is_mpls_labels_valid_valid(sx_flex_acl_key_desc_t   *key,
                                            sx_acl_region_id_t        region_id,
                                            flex_acl_key_build_mode_e build_mode)
{
    boolean_t                               is_valid = TRUE;
    sx_flex_acl_mpls_labels_valid_bitmask_t mpls_labels_valid_key;
    sx_flex_acl_mpls_labels_valid_bitmask_t mpls_labels_valid_mask;

    UNUSED_PARAM(region_id);

    switch (key->key_id) {
    case FLEX_ACL_KEY_MPLS_LABELS_VALID:
        mpls_labels_valid_key = key->key.mpls_labels_valid;
        mpls_labels_valid_mask = key->mask.mpls_labels_valid;
        break;

    case FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID:
        mpls_labels_valid_key = key->key.inner_mpls_labels_valid;
        mpls_labels_valid_mask = key->mask.inner_mpls_labels_valid;
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (mpls_labels_valid_key > 0x3F) {
            is_valid = FALSE;
            SX_LOG_ERR("mpls labels valid key is not valid.\n");
        }
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (mpls_labels_valid_mask > 0x3F) {
            is_valid = FALSE;
            SX_LOG_ERR("mpls labels valid mask is not valid.\n");
        }
    }

out:
    return is_valid;
}

static boolean_t is_rif_valid(sx_flex_acl_key_desc_t   *key,
                              sx_acl_region_id_t        region_id,
                              flex_acl_key_build_mode_e build_mode)
{
    boolean_t             is_valid = TRUE;
    hwd_rif_id_t          rif_id;
    sx_router_interface_t rif;
    sx_status_t           rc;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (key->key_id == FLEX_ACL_KEY_ERIF) {
            BOOLEAN_MASK_CHECK(erif, is_valid, out);
            AVOID_VALIDATION_IF_MASK_FALSE(erif, out);
        } else {
            BOOLEAN_MASK_CHECK(irif, is_valid, out);
            AVOID_VALIDATION_IF_MASK_FALSE(irif, out);
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rif = (key->key_id == FLEX_ACL_KEY_ERIF) ? key->key.erif : key->key.irif;
        rc = sdk_router_cmn_rif_hw_id_get(rif, &rif_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("%s %d is not valid.\n", key->key_id == FLEX_ACL_KEY_ERIF ? "ERIF" : "IRIF", rif);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_virtual_router_valid(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(virtual_router, is_valid, out);
        AVOID_VALIDATION_IF_MASK_FALSE(virtual_router, out);
    }

out:
    return is_valid;
}


static boolean_t is_tunnel_type_valid(sx_flex_acl_key_desc_t   *key,
                                      sx_acl_region_id_t        region_id,
                                      flex_acl_key_build_mode_e build_mode)
{
    boolean_t   is_valid = TRUE;
    acl_stage_e acl_stage = ACL_STAGE_UNKNOWN;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(tunnel_type, is_valid, out);
    }

    if (flex_acl_ops_g->acl_stage_get_p(&acl_stage) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get acl stage.\n");
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.tunnel_type > SX_TUNNEL_TYPE_MAX) {
            SX_LOG_ERR("Invalid tunnel type :%u \n", key->key.tunnel_type);
            is_valid = FALSE;
            goto out;
        }
        if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_L2_FLEX_MIN, key->key.tunnel_type, SX_TUNNEL_TYPE_L2_FLEX_MAX)) {
            SX_LOG_ERR("ACL: Flex tunnel type is not supported as a tunnel type key\n");
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_ar_packet_class_type_valid(sx_flex_acl_key_desc_t   *key,
                                               sx_acl_region_id_t        region_id,
                                               flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(ar_packet_class, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if ((key->key.ar_packet_class > SX_AR_CLASSIFIER_ACTION_MAX_E) ||
            (key->key.ar_packet_class < SX_AR_CLASSIFIER_ACTION_STATIC_E)) {
            SX_LOG_ERR("Invalid AR packet class type :%u \n", key->key.ar_packet_class);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_tunnel_nve_type_valid(sx_flex_acl_key_desc_t   *key,
                                          sx_acl_region_id_t        region_id,
                                          flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(tunnel_nve_type, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if ((key->key.tunnel_nve_type > SX_TUNNEL_TYPE_NVE_MAX) ||
            (key->key.tunnel_nve_type < SX_TUNNEL_TYPE_NVE_MIN)) {
            SX_LOG_ERR("Invalid tunnel nve type :%u \n", key->key.tunnel_nve_type);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t is_nd_sll_or_tll_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(nd_sll_or_tll_valid, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.nd_sll_or_tll_valid >= SX_ACL_ND_LAST) {
            SX_LOG_ERR("Invalid nd_sll_or_tll, type: %u \n", key->key.nd_sll_or_tll_valid);
            is_valid = FALSE;
            goto out;
        }
    }
out:
    return is_valid;
}

static boolean_t is_l4_type_extended_valid(sx_flex_acl_key_desc_t   *key,
                                           sx_acl_region_id_t        region_id,
                                           flex_acl_key_build_mode_e build_mode)
{
    boolean_t                      is_valid = TRUE;
    sx_flex_acl_l4_type_extended_t l4_type_extended_key;

    UNUSED_PARAM(region_id);

    switch (key->key_id) {
    case FLEX_ACL_KEY_L4_TYPE_EXTENDED:
        l4_type_extended_key = key->key.l4_type_extended;
        if (IS_KEY_BUILD_MASK(build_mode)) {
            BOOLEAN_MASK_CHECK(l4_type_extended, is_valid, out);
        }
        break;

    case FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED:
        l4_type_extended_key = key->key.inner_l4_type_extended;
        if ((l4_type_extended_key == SX_ACL_L4_TYPE_EXTENDED_BTH) ||
            (l4_type_extended_key == SX_ACL_L4_TYPE_EXTENDED_BTHOUDP)) {
            SX_LOG_ERR("ACL: BTH is not supported for inner L4 type\n");
            is_valid = FALSE;
            goto out;
        }

        if (IS_KEY_BUILD_MASK(build_mode)) {
            BOOLEAN_MASK_CHECK(inner_l4_type_extended, is_valid, out);
        }
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(key->key_id));
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (l4_type_extended_key >= SX_ACL_L4_TYPE_EXTENDED_LAST) {
            SX_LOG_ERR("Invalid l4_ty_extended, type :%u \n", l4_type_extended_key);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_port_valid(sx_port_log_id_t          port_log_id,
                                 boolean_t                 allow_lag,
                                 flex_acl_key_build_mode_e build_mode)
{
    boolean_t            is_valid = TRUE;
    sx_port_ucroute_id_t sys_port;
    sx_status_t          rc;
    sx_port_info_t       port_info;

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (IS_VPORT_OR_VLAG(port_log_id)) {
            SX_LOG_ERR("ACL : Port matching on vPort is not allowed.\n");
            is_valid = FALSE;
            goto out;
        }

        if (((SX_PORT_TYPE_ID_GET(port_log_id) == SX_PORT_TYPE_LAG)) && (allow_lag == FALSE)) {
            SX_LOG_ERR("ACL : Port matching on LAG is not allowed.\n");
            is_valid = FALSE;
            goto out;
        }

        if (SX_PORT_TYPE_LAG != SX_PORT_TYPE_ID_GET(port_log_id)) {
            rc = port_ucroute_id_map_get(
                SX_ACCESS_CMD_GET,
                port_log_id,
                &sys_port);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Can't retrieve data from port DB [%s]\n",
                           sx_status_str(rc));
                is_valid = FALSE;
            }
        }
        rc = port_db_info_get(port_log_id, &port_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("port_db_info_get rc = %d port = 0x%X\n", rc, port_log_id);
            is_valid = FALSE;
            goto out;
        }
    }
out:
    return is_valid;
}


static boolean_t is_src_port_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(src_port, is_valid, out);
        AVOID_VALIDATION_IF_MASK_FALSE(src_port, out);
    }

    is_valid = __is_port_valid(key->key.src_port, TRUE, build_mode);
    if (is_valid == FALSE) {
        SX_LOG_ERR("ACL : Source port validation failed for port [0x%x].\n", key->key.src_port);
        goto out;
    }
out:
    return is_valid;
}

static boolean_t is_dst_port_valid(sx_flex_acl_key_desc_t   *key,
                                   sx_acl_region_id_t        region_id,
                                   flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(dst_port, is_valid, out);
        AVOID_VALIDATION_IF_MASK_FALSE(dst_port, out);
    }

    is_valid = __is_port_valid(key->key.dst_port, FALSE, build_mode);
    if (is_valid == FALSE) {
        SX_LOG_ERR("ACL : Destination port validation failed for port [0x%x].\n", key->key.dst_port);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t is_src_phy_port_valid(sx_flex_acl_key_desc_t   *key,
                                       sx_acl_region_id_t        region_id,
                                       flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(src_phy_port, is_valid, out);
        AVOID_VALIDATION_IF_MASK_FALSE(src_phy_port, out);
    }

    is_valid = __is_port_valid(key->key.src_phy_port, FALSE, build_mode);
    if (is_valid == FALSE) {
        SX_LOG_ERR("ACL : Source physical port validation failed for port [0x%x].\n", key->key.src_phy_port);
        goto out;
    }
out:
    return is_valid;
}


static boolean_t is_buff_valid(sx_flex_acl_key_desc_t   *key,
                               sx_acl_region_id_t        region_id,
                               flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(buff, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.buff > SX_COS_ING_PG_MAX_E) {
            SX_LOG_ERR("BUFF key value is not valid. value:%x\n", key->key.buff);
            is_valid = FALSE;
        }
    }

out:
    return is_valid;
}

static boolean_t is_l4_port_range_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode)
{
    boolean_t            is_valid = TRUE;
    sx_status_t          rc;
    uint32_t             i;
    sx_acl_range_entry_t range_entry;

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(l4_port_range, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.l4_port_range.port_range_cnt > RM_API_ACL_PORT_RANGES_MAX) {
            is_valid = FALSE;
            SX_LOG_ERR("Number of port ranges exceeds the maximum. Max is :%d \n", RM_API_ACL_PORT_RANGES_MAX);
            goto out;
        }

        for (i = 0; i < key->key.l4_port_range.port_range_cnt; i++) {
            rc = flex_acl_db_range_get(key->key.l4_port_range.port_range_list[i], &range_entry);
            if (SX_STATUS_SUCCESS != rc) {
                is_valid = FALSE;
                SX_LOG_ERR("Port range index %d does not exist.\n", key->key.l4_port_range.port_range_list[i]);
                goto out;
            }
        }
    }

out:
    return is_valid;
}

static boolean_t is_rx_list_valid(sx_flex_acl_key_desc_t   *key,
                                  sx_acl_region_id_t        region_id,
                                  sx_port_type_t            port_type,
                                  flex_acl_key_build_mode_e build_mode)
{
    boolean_t                is_valid = TRUE;
    sx_status_t              rc;
    sx_acl_port_list_entry_t port_list[RM_API_ACL_PORT_LIST_MAX];
    uint32_t                 port_list_count = 0;
    sx_port_type_t           list_port_type = FLEX_ACL_INVALID_PORT_TYPE;

    UNUSED_PARAM(region_id);

    SX_LOG_ENTER();

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(rx_list, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rc = flex_acl_db_rx_list_get(key->key.rx_list, port_list, &port_list_count, &list_port_type);
        if (SX_STATUS_SUCCESS != rc) {
            is_valid = FALSE;
            SX_LOG_ERR("ACL key rx list id:[%u], does not exist.\n", key->key.rx_list);
            goto out;
        }

        if (list_port_type == FLEX_ACL_INVALID_PORT_TYPE) {
            /* This is a bit out of the ordinary behaviour - if the list doesn't has a type yet (it was created with zero ports)
             * we set the type to the first rule that has tried to set it to something.
             */
            rc = flex_acl_db_rx_list_set_port_type(key->key.rx_list, port_type);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Key rx list id:[%u], failed to set port type %s.\n", key->key.rx_list,
                           sx_port_type_str(port_type));
                is_valid = FALSE;
                goto out;
            }
        } else if (list_port_type != port_type) {
            SX_LOG_ERR("ACL key rx list id:[%u], key type %s doesn't match list type %s.\n",
                       key->key.rx_list,
                       sx_port_type_str(port_type),
                       sx_port_type_str(list_port_type));
            is_valid = FALSE;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return is_valid;
}

static boolean_t is_rx_list_valid_network(sx_flex_acl_key_desc_t   *key,
                                          sx_acl_region_id_t        region_id,
                                          flex_acl_key_build_mode_e build_mode)
{
    return is_rx_list_valid(key, region_id, SX_PORT_TYPE_NETWORK, build_mode);
}

static boolean_t is_rx_list_valid_tunnel(sx_flex_acl_key_desc_t   *key,
                                         sx_acl_region_id_t        region_id,
                                         flex_acl_key_build_mode_e build_mode)
{
    return is_rx_list_valid(key, region_id, SX_PORT_TYPE_TUNNEL, build_mode);
}

static boolean_t is_port_list_valid(sx_flex_acl_key_desc_t   *key,
                                    sx_acl_region_id_t        region_id,
                                    flex_acl_key_build_mode_e build_mode)
{
    boolean_t                    is_valid = TRUE;
    uint32_t                     next_hop_cnt;
    sx_mc_container_attributes_t attr;
    mc_container_owner_type_t    type;
    sx_status_t                  rc;
    sx_mc_container_id_t         mc_container_id;
    sx_acl_port_list_match_t     match_type;
    boolean_t                    mask_boolean = FALSE;

    UNUSED_PARAM(region_id);

    SX_LOG_ENTER();

    /* Deprecated ACL keys */
    switch (key->key_id) {
    case FLEX_ACL_KEY_RX_PORT_LIST_1_128:
        SX_LOG_DEPRECATED_PARAM_ERR("FLEX_ACL_KEY_RX_PORT_LIST_1_128", "FLEX_ACL_KEY_RX_PORT_LIST_0");
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_129_258:
        SX_LOG_DEPRECATED_PARAM_ERR("FLEX_ACL_KEY_RX_PORT_LIST_129_258", "FLEX_ACL_KEY_RX_PORT_LIST_1");
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_1_128:
        SX_LOG_DEPRECATED_PARAM_ERR("FLEX_ACL_KEY_TX_PORT_LIST_1_128", "FLEX_ACL_KEY_TX_PORT_LIST_0");
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_129_258:
        SX_LOG_DEPRECATED_PARAM_ERR("FLEX_ACL_KEY_TX_PORT_LIST_129_258", "FLEX_ACL_KEY_TX_PORT_LIST_1");
        break;

    default:
        break;
    }

    rc = flex_acl_key_port_list_get_info(key, &mc_container_id, &match_type, &mask_boolean);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed port list info get for key type [%u]\n", key->key_id);
        is_valid = FALSE;
        goto out;
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if ((mask_boolean != FALSE) && (mask_boolean != TRUE)) {
            SX_LOG_ERR("ACL : Invalid boolean mask for port list key\n");
            is_valid = FALSE;
            goto out;
        }
        if (mask_boolean == FALSE) {
            goto out;
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if ((match_type != SX_ACL_PORT_LIST_MATCH_NEGATIVE) &&
            (match_type != SX_ACL_PORT_LIST_MATCH_POSITIVE)) {
            SX_LOG_ERR("PORT_LIST : Invalid match type:%u.\n", match_type);
            is_valid = FALSE;
            goto out;
        }

        rc = sdk_mc_container_impl_get(mc_container_id, NULL, &next_hop_cnt, &attr, &type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("PORT_LIST : Invalid MC id:%u  err %s.\n", mc_container_id, sx_status_str(rc));
            is_valid = FALSE;
            goto out;
        }

        if (attr.type != SX_MC_CONTAINER_TYPE_PORT) {
            SX_LOG_ERR("PORT_LIST : Unsupported MC Type:%u.\n", attr.type);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return is_valid;
}

static boolean_t is_user_token_valid(sx_flex_acl_key_desc_t   *key,
                                     sx_acl_region_id_t        region_id,
                                     flex_acl_key_build_mode_e build_mode)
{
    boolean_t                 is_valid = TRUE;
    flex_acl_db_acl_region_t *acl_region_p;
    sx_status_t               rc;

    SX_LOG_ENTER();

    /* Check system ACL */
    rc = flex_acl_db_region_get(region_id, &acl_region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", region_id);
        is_valid = FALSE;
        goto out;
    }
    if (acl_region_p->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            if (key->key.user_token & ACL_SYSTEM_TOKEN_MASK) {
                SX_LOG_ERR("User token key is invalid, Upper nibble can not be used.\n");
                is_valid = FALSE;
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return is_valid;
}

static boolean_t is_discard_state_valid(sx_flex_acl_key_desc_t   *key,
                                        sx_acl_region_id_t        region_id,
                                        flex_acl_key_build_mode_e build_mode)
{
    boolean_t is_valid = TRUE;

    SX_LOG_ENTER();

    UNUSED_PARAM(region_id);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        BOOLEAN_MASK_CHECK(discard_state, is_valid, out);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (key->key.discard_state >= SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST) {
            SX_LOG_ERR("Discard state is invalid\n");
            is_valid = FALSE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return is_valid;
}


void __copy_bits(uint8_t *dst, uint8_t src, int offset, int len)
{
    uint8_t dst_mask, src_mask;

    src_mask = (0xff << offset) & (0xff >> (8 - len - offset));
    dst_mask = src_mask ^ 0xff;

    *dst = (*dst & dst_mask) | (src & src_mask);
}

void __left_shift_array(uint8_t *arr, uint32_t pos, uint32_t len)
{
    uint32_t bits_shift = pos % 8;
    uint32_t bytes_shift = pos / 8;
    uint32_t i;

    for (i = 0; i < len - 1; i++) {
        arr[i] = arr[i] << bits_shift;
        arr[i] |= arr[i + 1] >> (8 - bits_shift);
    }
    arr[i] = arr[i] << bits_shift;

    for (i = 0; bytes_shift && i < len; i++) {
        arr[i] = i < len - bytes_shift ? arr[i + bytes_shift] : 0;
    }
}

void __right_shift_array(uint8_t *arr, uint32_t pos, uint32_t len)
{
    uint32_t bits_shift = pos % 8;
    uint32_t bytes_shift = pos / 8;
    int      i;

    for (i = len - 1; i > 0; i--) {
        arr[i] = arr[i] >> bits_shift;
        arr[i] |= arr[i - 1] << (8 - bits_shift);
    }
    arr[i] = arr[i] >> bits_shift;

    for (i = (int)(len - 1); bytes_shift && i >= 0; i--) {
        arr[i] = (i >= (int)bytes_shift) ? arr[i - bytes_shift] : 0;
    }
}

static boolean_t __is_host_big_end(void)
{
    union {
        uint32_t i;
        uint8_t  a[4];
    } u;

    u.i = 1;

    return u.a[3];
}

static void __reverse_array(uint8_t *arr, uint16_t size)
{
    uint16_t i;
    uint8_t  tmp;

    for (i = 0; i < size / 2; i++) {
        tmp = arr[i];
        arr[i] = arr[size - 1 - i];
        arr[size - 1 - i] = tmp;
    }
}

void flex_acl_handle_endianess(uint8_t *key, uint16_t size)
{
    if (__is_host_big_end() || (size == 1)) {
        return; /* Nothing to do */
    }
    __reverse_array(key, size);
}


/* Function to copy a specific key to a specific key block
 * The key and the block buffer are regarded as arrays of uint8_t in order to avoid Endianness issues.
 * The input parameter block_bit_offset is converted into a word offset and a bit offset within the word.
 * Keys len + block shift must be <= 64 bits. If a key overrun the 32bit word boundary, the rest of the bits
 * will be placed in the previous word in order to be compliant with the big endian HW implementation.
 *
 * @param[out] block - pointer to the start of the block.
 * @param[in]  block_bit_offset - location of key in the key block according to the PRM (using little endian counting).
 * @param[in]  block_shift - the left shift to perform on the key location if entire key block is not byte aligned.
 * @param[in]  key - pointer to the key.
 * @param[in]  key_bit_offset - the bit offset in the key from which to start copying bits to the block.
 * @param[in]  len - the number of bits to copy from the key to the key block.
 * @param[in]  key_size - the key size in bytes.
 * @param[in]  is_endianess - is endian conversion needed for this key.
 */
void flex_acl_copy_key_to_block(uint8_t  *block,
                                int       block_bit_offset,
                                uint8_t   block_shift,
                                uint8_t  *key,
                                uint32_t  key_bit_offset,
                                uint32_t  len,
                                uint16_t  key_size,
                                boolean_t is_endianess)
{
    int      bits_left_to_copy = 0;
    int      key_ind = 0;
    int      i = 0;
    uint8_t  help_key[FLEX_ACL_MAX_KEY_SIZE];
    uint8_t  block_ind = 0;
    uint8_t *block_word = NULL;
    uint8_t  key_word[8] = { 0 };
    uint8_t  block_word_offset = 0;
    uint8_t  block_word_bit_offset = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(help_key);

    block_word_offset = block_bit_offset / 32;
    block_word_bit_offset = block_bit_offset % 32 + block_shift;

    /* The block word is 4 bytes but since the key word is 8 bytes (to allow word overflow)
     * we need to decrease the pointer by 4 to the start of the key_word.
     */
    block_word = block + block_word_offset * 4 - 4;
    memcpy(help_key, key, key_size);
    if (is_endianess) {
        flex_acl_handle_endianess(help_key, key_size);
    }
    __right_shift_array(help_key, key_bit_offset, key_size);
    for (i = 7, key_ind = key_size - 1; key_ind >= 0 && i >= 0;
         key_ind--, i--) {
        key_word[i] = help_key[key_ind];
    }
    __left_shift_array(key_word, block_word_bit_offset % 8, 8);

    block_ind = 7 - (block_word_bit_offset / 8);
    key_ind = 7;
    /* handle first byte which might be partial */
    __copy_bits(&block_word[block_ind--], key_word[key_ind--],
                block_word_bit_offset % 8,
                MIN(len, (uint8_t)(8 - block_word_bit_offset % 8)));
    for (bits_left_to_copy = len - (8 - block_word_bit_offset % 8);
         bits_left_to_copy >= 8; bits_left_to_copy -= 8) {
        block_word[block_ind--] = key_word[key_ind--];
    }
    /* copy last byte which might be partial */
    if (bits_left_to_copy > 0) {
        __copy_bits(&block_word[block_ind], key_word[key_ind], 0,
                    bits_left_to_copy);
    }
    SX_LOG_EXIT();
}

void flex_acl_copy_block_to_key(uint8_t  *block,
                                int       block_bit_offset,
                                uint8_t   block_shift,
                                uint8_t  *key,
                                uint32_t  key_bit_offset,
                                uint32_t  len,
                                uint16_t  key_size,
                                boolean_t is_endianess)
{
    int      bits_left_to_copy = 0;
    int      key_ind = 0;
    int      i = 0;
    uint8_t  help_key[FLEX_ACL_MAX_KEY_SIZE];
    uint8_t  block_ind = 0;
    uint8_t *block_word = NULL;
    uint8_t  key_word[8] = { 0 };
    uint8_t  block_word_offset = 0;
    uint8_t  block_word_bit_offset = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(help_key);

    block_word_offset = block_bit_offset / 32;
    block_word_bit_offset = block_bit_offset % 32 + block_shift;

    /* The block word is 4 bytes but since the key word is 8 bytes (to allow word overflow)
     * we need to decrease the pointer by 4 to the start of the key_word.
     */
    block_word = block + block_word_offset * 4 - 4;

    block_ind = 7 - (block_word_bit_offset / 8);
    key_ind = 7;
    /* handle first byte which might be partial */
    __copy_bits(&key_word[key_ind--], block_word[block_ind--],
                block_word_bit_offset % 8,
                MIN(len, (uint8_t)(8 - block_word_bit_offset % 8)));
    for (bits_left_to_copy = len - (8 - block_word_bit_offset % 8);
         bits_left_to_copy >= 8; bits_left_to_copy -= 8) {
        key_word[key_ind--] = block_word[block_ind--];
    }
    /* copy last byte which might be partial */
    if (bits_left_to_copy > 0) {
        __copy_bits(&key_word[key_ind], block_word[block_ind], 0,
                    bits_left_to_copy);
    }
    __right_shift_array(key_word, block_word_bit_offset % 8, 8);

    for (i = 7, key_ind = key_size - 1; key_ind >= 0 && i >= 0;
         key_ind--, i--) {
        help_key[key_ind] = key_word[i];
    }
    __left_shift_array(help_key, key_bit_offset, key_size);

    if (is_endianess) {
        flex_acl_handle_endianess(help_key, key_size);
    }

    /* We do not want to overwrite bits that already exist and therefore OR the new bits */
    for (i = 0; i < key_size; i++) {
        key[i] |= help_key[i];
    }

    SX_LOG_EXIT();
}


/**
 *  This function is used to populate the keys blocks information.
 *  A List of keys and masks is provided. the value of the keys is populated
 *  into the proper place at the proper key block,
 *
 * @param[in] keys - An array of the keys that should be populated to the 9bytes blocks.
 * @param[in] keys_count -The number of keys in the above array.
 * @param[in] key_blocks - An array of 9bytes blocks that are used to populate the keys.
 * @param[in] keys_count - The number of keys in the above array.
 * @param[out] - key - Buffer of 96 bytes blocks for populating with keys values.
 * @param[out] - mask - Buffer of 96 bytes blocks for populating with mask values.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_SUCCESS if operation fails.
 *
 */

sx_status_t flex_acl_key_layout_constructor(acl_stage_e               acl_stage,
                                            sx_flex_acl_key_desc_t   *keys,
                                            uint32_t                  keys_count,
                                            sx_acl_key_block_e       *key_blocks,
                                            uint32_t                  key_blocks_count,
                                            uint8_t                  *key,
                                            uint8_t                  *mask,
                                            flex_acl_key_build_mode_e build_mode)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_key_block_item_t *items = NULL;
    boolean_t                  found_block = FALSE, is_end = FALSE;
    uint32_t                   items_count = 0, i, b_ind = 0, j, k, key_size = 0;
    uint8_t                    conv_buff[FLEX_ACL_MAX_KEY_SIZE],
                               conv_mask_buff[FLEX_ACL_MAX_KEY_SIZE];

    SX_LOG_ENTER();

    if ((FALSE == g_flex_acl_initialized) || (flex_acl_key_map[acl_stage] == NULL)) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    SX_MEM_CLR(conv_buff);
    SX_MEM_CLR(conv_mask_buff);
    SX_MEM_CLR_ARRAY(mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES, uint8_t);
    SX_MEM_CLR_ARRAY(key, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES, uint8_t);

    for (i = 0; i < keys_count; i++) {
        for (j = 0; j < flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys_cnt; j++) {
            for (b_ind = 0, found_block = 0;
                 b_ind < key_blocks_count && !found_block; b_ind++) {
                items =
                    key_block_data_dictionary[key_blocks[b_ind]].key_block_items;
                items_count =
                    key_block_data_dictionary[key_blocks[b_ind]].key_block_items_count;
                for (k = 0; k < items_count; k++) {
                    if (flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j] == items[k].key_id) {
                        found_block = 1;
                        /* Populate current 9b block at the buffer */
                        if (special_field_conv[keys[i].key_id]) {
                            key_size = 0;
                            rc = special_field_conv[keys[i].key_id](
                                &keys[i], flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j], conv_buff,
                                conv_mask_buff, &key_size, build_mode);
                            if ((SX_STATUS_SUCCESS != rc) || (key_size == 0)) {
                                SX_LOG_ERR("ACL key conversion failed for (%s) key size (%u).\n",
                                           sx_acl_key_str(keys[i].key_id), key_size);
                                rc = SX_STATUS_ERROR;
                                goto out;
                            }
                        } else {
                            key_size = flex_acl_keys_data[flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j]].size;
                        }
                        is_end =
                            flex_acl_keys_data[flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j]].is_endianism;
                        if (IS_KEY_BUILD_VALUE(build_mode)) {
                            flex_acl_copy_key_to_block(key + flex_key_block_byte_offsets[acl_stage][b_ind],
                                                       items[k].block_offset,
                                                       flex_key_block_bit_shifts[acl_stage][b_ind],
                                                       special_field_conv[keys[i].key_id] ? conv_buff : (uint8_t*)&keys[
                                                           i].key,
                                                       items[k].basic_key_offset,
                                                       items[k].len,
                                                       key_size,
                                                       is_end);
                        }
                        if (IS_KEY_BUILD_MASK(build_mode)) {
                            flex_acl_copy_key_to_block(mask + flex_key_block_byte_offsets[acl_stage][b_ind],
                                                       items[k].block_offset,
                                                       flex_key_block_bit_shifts[acl_stage][b_ind],
                                                       special_field_conv[keys[i].key_id] ? conv_mask_buff : (uint8_t*)&keys[
                                                           i].mask,
                                                       items[k].basic_key_offset,
                                                       items[k].len,
                                                       key_size,
                                                       is_end);
                        }
                    }
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_keys_extractor(acl_stage_e             acl_stage,
                                    sx_flex_acl_key_desc_t *keys,
                                    uint32_t                keys_count,
                                    sx_acl_key_block_e     *key_blocks,
                                    uint32_t                key_blocks_count,
                                    uint8_t                *key)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_key_block_item_t *items = NULL;
    boolean_t                  found_block = FALSE, is_end = FALSE;
    uint32_t                   items_count = 0, i, b_ind = 0, j, k, key_size = 0;
    uint8_t                    hw_key_buff[FLEX_ACL_MAX_KEY_SIZE];
    sx_acl_hw_key_e            hw_key = 0;
    boolean_t                  last_hw_key = FALSE;

    SX_LOG_ENTER();

    if ((FALSE == g_flex_acl_initialized) || (flex_acl_key_map[acl_stage] == NULL)) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    for (i = 0; i < keys_count; i++) {
        SX_MEM_CLR(keys[i].key);    /* Needed since some operations assume key is zeroed */
        for (j = 0; j < flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys_cnt; j++) {
            SX_MEM_CLR(hw_key_buff);
            hw_key = flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j];
            for (b_ind = 0, found_block = 0;
                 b_ind < key_blocks_count && !found_block; b_ind++) {
                items =
                    key_block_data_dictionary[key_blocks[b_ind]].key_block_items;
                items_count =
                    key_block_data_dictionary[key_blocks[b_ind]].key_block_items_count;
                for (k = 0; k < items_count; k++) {
                    if (hw_key == items[k].key_id) {
                        found_block = 1;
                        key_size = flex_acl_keys_data[flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j]].size;
                        is_end =
                            flex_acl_keys_data[flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys[j]].is_endianism;

                        flex_acl_copy_block_to_key(key + flex_key_block_byte_offsets[acl_stage][b_ind],
                                                   items[k].block_offset,
                                                   flex_key_block_bit_shifts[acl_stage][b_ind],
                                                   hw_key_buff,
                                                   items[k].basic_key_offset,
                                                   items[k].len,
                                                   key_size,
                                                   is_end);
                    }
                }
            }
            if (special_field_extract_conv[keys[i].key_id] != NULL) {
                last_hw_key = ((j + 1) >= flex_acl_key_map[acl_stage][keys[i].key_id].hw_keys_cnt) ? TRUE : FALSE;
                rc = special_field_extract_conv[keys[i].key_id](&keys[i], hw_key, hw_key_buff, last_hw_key);
                if (SX_CHECK_FAIL(rc) || (key_size == 0)) {
                    SX_LOG_ERR("ACL key extraction failed for (%s) key size (%u).\n",
                               sx_acl_key_str(keys[i].key_id), key_size);
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
            } else {
                memcpy(&keys[i].key, &hw_key_buff, key_size);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_key_block_map_init(acl_stage_e acl_stage)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Set the correct key map according to stage */
    switch (acl_stage) {
    case ACL_STAGE_FLEX:
        flex_key_block_byte_offsets[acl_stage] = flex1_key_block_byte_offsets;
        flex_key_block_bit_shifts[acl_stage] = flex1_key_block_bit_shifts;
        flex_key_widths[acl_stage] = flex1_key_widths;
        break;

    case ACL_STAGE_FLEX2:
    case ACL_STAGE_FLEX3:
    case ACL_STAGE_FLEX4:
        flex_key_block_byte_offsets[acl_stage] = flex2_key_block_byte_offsets;
        flex_key_block_bit_shifts[acl_stage] = flex2_key_block_bit_shifts;
        flex_key_widths[acl_stage] = flex2_key_widths;
        break;

    case ACL_STAGE_MACSEC:
        flex_key_block_byte_offsets[acl_stage] = macsec_key_block_byte_offsets;
        flex_key_block_bit_shifts[acl_stage] = macsec_key_block_bit_shifts;
        flex_key_widths[acl_stage] = macsec_key_widths;
        break;

    default:
        SX_LOG_ERR("Unknown Flex acl stage [%u] for key map init.\n", acl_stage);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = flex_acl_scp_init(acl_stage);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed scp init.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_keys_custom_byte_id_is_valid(sx_acl_key_t key)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    acl_custom_bytes_set_id_e custom_bytes_set_id;
    uint32_t                  count;

    if (!is_flex_acl_key_custom_byte_key(key)) {
        /* Not a custom bytes key. */
        SX_LOG_ERR("Invalid custom byte key id:%u(%#x) \n", key, key);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_key_id_to_custom_byte_set(key, &custom_bytes_set_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_acl_key_id_to_custom_byte_set failed [%s]. key id:%u(%#x) \n",
                   sx_status_str(rc), key, key);
        goto out;
    }

    rc = flex_acl_db_custom_bytes_set_ref_get(custom_bytes_set_id, &count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Custom byte key:%u(%#x) not allocated \n", key, key);
        goto out;
    }

out:
    return rc;
}

/***********************************************
*  Key conversion functions
***********************************************/

static sx_status_t __l4_port_range_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode)
{
    uint16_t bitmap = 0, i;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        for (i = 0; i < i_key->key.l4_port_range.port_range_cnt; i++) {
            bitmap |= 1 << i_key->key.l4_port_range.port_range_list[i];
        }
        memcpy(o_key, (uint8_t*)&bitmap, 2);
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (i_key->mask.l4_port_range == TRUE) {
            memcpy(o_mask, (uint8_t*)&bitmap, 2);
        } else {
            memset(o_mask, 0, 2);
        }
    }
    *out_len = 2;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __src_port_conv(sx_flex_acl_key_desc_t   *i_key,
                                   sx_acl_hw_key_e           hw_key,
                                   uint8_t                  *o_key,
                                   uint8_t                  *o_mask,
                                   uint32_t                 *out_len,
                                   flex_acl_key_build_mode_e build_mode)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t src_sys_port = 0;
    uint32_t             conv_physical_src_port = 0;
    uint16_t             rx_local_port = 0;

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_SRC_PORT_E:           /* Flex1 */
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.src_port == FALSE) {
                memset(o_mask, 0, 4);
                memset(o_key, 0, 4);
                *out_len = 4;
                goto out;
            }
            memset(o_mask, 0xff, 4);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(i_key->key.src_port)) {
                src_sys_port = SX_PORT_LAG_ID_GET(i_key->key.src_port);
                SX_LOG_DBG(" LAG src_sys_port:%d \n", src_sys_port);
            } else {
                rc = port_ucroute_id_map_get(
                    SX_ACCESS_CMD_GET,
                    i_key->key.src_port,
                    &src_sys_port);
                SX_LOG_DBG("non LAG src_sys_port:%d \n", src_sys_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Can't retrieve data from port DB [%s]\n",
                               sx_status_str(rc));
                    goto out;
                }
            }
            conv_physical_src_port = (uint32_t)src_sys_port;
            if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(i_key->key.src_port)) {
                conv_physical_src_port |= 1 << 16;
            }
            memcpy(o_key, &conv_physical_src_port, 4);
        }

        *out_len = 4;
        break;

    case FLEX_ACL_HW_KEY_RX_SYS_PORT_E:   /* Flex2 */
    case FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E:
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.src_port == FALSE) {
                memset(o_mask, 0, 2);
                memset(o_key, 0, 2);
                *out_len = 2;
                goto out;
            }
            memset(o_mask, 0xff, 2);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(i_key->key.src_port)) {
                rx_local_port = SX_PORT_LAG_ID_GET(i_key->key.src_port);
                rx_local_port |= 1 << 15;
            } else {
                rx_local_port = SX_PORT_PHY_ID_GET(i_key->key.src_port);
                if (rx_local_port == CPU_PORT_PHY_ID) { /* CPU_PORT_PHY_ID == 0 */
                    rx_local_port = rm_resource_global.port_ext_num_max;   /* maximum number of ports */
                } else {
                    rx_local_port--;        /* Regular port */
                }
            }
            memcpy(o_key, &rx_local_port, 2);
        }
        *out_len = 2;
        break;

    default:
        SX_LOG_ERR("Invalid source port HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }
out:
    return SX_STATUS_SUCCESS;
}

#define CONVERT_FLAG(enum_value, field)       \
case enum_value:                              \
    if (IS_KEY_BUILD_VALUE(build_mode)) {     \
        *o_key = (uint8_t)i_key->key.field;   \
    }                                         \
    if (IS_KEY_BUILD_MASK(build_mode)) {      \
        *o_mask = (uint8_t)i_key->mask.field; \
    }                                         \
    break;

static sx_status_t __boolean_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    switch (i_key->key_id) {
        CONVERT_FLAG(FLEX_ACL_KEY_RW_PCP, rw_pcp)
        CONVERT_FLAG(FLEX_ACL_KEY_VLAN_TAGGED, vlan_tagged)
        CONVERT_FLAG(FLEX_ACL_KEY_VLAN_VALID, vlan_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_L2_VALID, l2_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_RW_DSCP, rw_dscp)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_FRAGMENTED, ip_fragmented)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_DONT_FRAGMENT, ip_dont_fragment)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST, ip_fragment_not_first)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_OK, ip_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IP_OK, inner_ip_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IP_OPT, inner_ip_opt)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_VLAN_VALID, inner_vlan_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_VLAN_TAG_VALID, vlan_tag_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_VLAN_TAG_VALID, inner_vlan_tag_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID, tunnel_vlan_tag_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID, tunnel_inner_vlan_tag_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_ARP, is_arp)
        CONVERT_FLAG(FLEX_ACL_KEY_URPF_FAIL, urpf_fail)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_OPT, ip_opt)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_IP_V4, is_ip_v4)
        CONVERT_FLAG(FLEX_ACL_KEY_TTL_OK, ttl_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_TTL_OK, inner_ttl_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_L4_OK, l4_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_L4_OK, inner_l4_ok)
        CONVERT_FLAG(FLEX_ACL_KEY_DMAC_IS_UC, dmac_is_uc)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_TRAPPED, is_trapped)
        CONVERT_FLAG(FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS, ipv6_extension_header_exists)
        CONVERT_FLAG(FLEX_ACL_KEY_RW_EXP, rw_exp)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_MPLS, is_mpls)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IS_MPLS, inner_is_mpls)
        CONVERT_FLAG(FLEX_ACL_KEY_BOS, bos)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_ROUTED, is_routed)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_0_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_1_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_2_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_3_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_4_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_DWORD_5_VALID, dword_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID, mpls_control_word_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IS_IP_V4, inner_is_ip_v4)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_BOS, inner_bos)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IP_FRAGMENTED, inner_ip_fragmented)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT, inner_ip_dont_fragment)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST, inner_ip_fragment_not_first)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID, inner_mpls_control_word_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_IS_TCP_OPTION, inner_is_tcp_option)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_TCP_OPTION, is_tcp_option)
        CONVERT_FLAG(FLEX_ACL_KEY_FDB_MISS, fdb_miss)
        CONVERT_FLAG(FLEX_ACL_KEY_LLC_VALID, llc_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_DMAC_VALID, inner_dmac_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_IS_BUM, is_bum_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_ALU_CARRY_FLAG, alu_carry_flag)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_0_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_1_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_2_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_3_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_4_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_5_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_6_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_7_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_8_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_9_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_10_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_GP_REGISTER_11_VALID, gp_register_extraction_valid)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_0_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_1_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_2_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_3_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_4_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_5_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_6_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_FPP_7_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_0_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_1_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_2_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_3_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_4_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_5_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_6_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_INNER_FPP_7_TOUCHED, fpp_touched)
        CONVERT_FLAG(FLEX_ACL_KEY_PACKET_IS_ELEPHANT, packet_is_elephant)
        CONVERT_FLAG(FLEX_ACL_KEY_MAC_COMPARE, mac_compare)
        CONVERT_FLAG(FLEX_ACL_KEY_IP_COMPARE, ip_compare)
        CONVERT_FLAG(FLEX_ACL_KEY_L4_PORT_COMPARE, l4_port_compare)
    default:
        SX_LOG_ERR("key:%s is not handled.\n", flex_acl_db_key_id_to_str(i_key->key_id));
        rc = SX_STATUS_ERROR;
        break;
    }

    *out_len = 1;

    return rc;
}

static sx_status_t __dst_port_conv(sx_flex_acl_key_desc_t   *i_key,
                                   sx_acl_hw_key_e           hw_key,
                                   uint8_t                  *o_key,
                                   uint8_t                  *o_mask,
                                   uint32_t                 *out_len,
                                   flex_acl_key_build_mode_e build_mode)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t dst_sys_port = 0;
    sx_port_phy_id_t     local_port = 0;

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_DST_PORT_E:       /* Flex1 */
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.dst_port == FALSE) {
                memset(o_mask, 0, 2);
                memset(o_key, 0, 2);
                *out_len = 2;
                goto out;
            }
            memset(o_mask, 0xff, 2);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            rc = port_ucroute_id_map_get(
                SX_ACCESS_CMD_GET,
                i_key->key.dst_port,
                &dst_sys_port);
            SX_LOG_DBG("non LAG dst_sys_port:%d \n", dst_sys_port);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Can't retrieve data from port DB [%s]\n",
                           sx_status_str(rc));
                goto out;
            }
            memcpy(o_key, &dst_sys_port, 2);
        }
        *out_len = 2;
        break;

    case FLEX_ACL_HW_KEY_TX_SYS_PORT_E:   /* Flex2 */
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.dst_port == FALSE) {
                memset(o_mask, 0, 2);
                memset(o_key, 0, 2);
                *out_len = 2;
                goto out;
            }
            memset(o_mask, 0xff, 2);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            local_port = SX_PORT_PHY_ID_GET(i_key->key.dst_port);
            if (local_port == CPU_PORT_PHY_ID) { /* CPU_PORT_PHY_ID == 0 */
                *(uint16_t*)o_key = rm_resource_global.port_ext_num_max;   /* maximum number of ports */
            } else {
                *(uint16_t*)o_key = local_port - 1;        /* Regular port */
            }
        }
        *out_len = 2;
        break;

    default:
        SX_LOG_ERR("Invalid destination port HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }
out:
    return rc;
}

static void __ipv4_conv(sx_ip_addr_t              key_ip,
                        sx_ip_addr_t              mask_ip,
                        uint8_t                  *o_key,
                        uint8_t                  *o_mask,
                        uint32_t                 *out_len,
                        flex_acl_key_build_mode_e build_mode)
{
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        memcpy(o_key, &(key_ip.addr.ipv4.s_addr), 4);
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        memcpy(o_mask, &(mask_ip.addr.ipv4.s_addr), 4);
    }

    *out_len = 4;
}

static sx_status_t __sip_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    __ipv4_conv(i_key->key.sip, i_key->mask.sip, o_key, o_mask, out_len, build_mode);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __dip_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    __ipv4_conv(i_key->key.dip, i_key->mask.dip, o_key, o_mask, out_len, build_mode);

    return SX_STATUS_SUCCESS;
}


static sx_status_t __ipv6_hw_key_offset_get(const sx_acl_hw_key_e hw_key, uint32_t             *offset_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_SIP_E:
    case FLEX_ACL_HW_KEY_DIP_E:
    case FLEX_ACL_HW_KEY_INNER_SIP_E:
    case FLEX_ACL_HW_KEY_INNER_DIP_E:
    case FLEX_ACL_HW_KEY_DIPV6_PART1_E:
    case FLEX_ACL_HW_KEY_SIPV6_PART1_E:
    case FLEX_ACL_HW_KEY_INNER_DIPV6_PART1_E:
    case FLEX_ACL_HW_KEY_INNER_SIPV6_PART1_E:
        *offset_p = 3;
        break;

    case FLEX_ACL_HW_KEY_DIPV6_PART2_E:
    case FLEX_ACL_HW_KEY_SIPV6_PART2_E:
    case FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E:
    case FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E:
        *offset_p = 2;
        break;

    case FLEX_ACL_HW_KEY_DIPV6_PART3_E:
    case FLEX_ACL_HW_KEY_SIPV6_PART3_E:
    case FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E:
    case FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E:
        *offset_p = 1;
        break;

    case FLEX_ACL_HW_KEY_DIPV6_PART4_E:
    case FLEX_ACL_HW_KEY_SIPV6_PART4_E:
    case FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E:
    case FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E:
        *offset_p = 0;
        break;

    default:
        SX_LOG_ERR("Invalid IPV6 HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __ipv6_conv(sx_ip_addr_t              key_ip,
                               sx_ip_addr_t              mask_ip,
                               sx_acl_hw_key_e           hw_key,
                               uint8_t                  *o_key,
                               uint8_t                  *o_mask,
                               uint32_t                 *out_len,
                               flex_acl_key_build_mode_e build_mode)
{
    uint32_t    offset = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;


    rc = __ipv6_hw_key_offset_get(hw_key, &offset);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        memcpy(o_key, &(key_ip.addr.ipv6.s6_addr32[offset]), 4);
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        memcpy(o_mask, &(mask_ip.addr.ipv6.s6_addr32[offset]), 4);
    }

    *out_len = 4;

out:
    return rc;
}

static sx_status_t __dipv6_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode)
{
    return __ipv6_conv(i_key->key.dipv6, i_key->mask.dip, hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __sipv6_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode)
{
    return __ipv6_conv(i_key->key.sipv6, i_key->mask.sip, hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __l2_dmac_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                       sx_acl_hw_key_e           hw_key,
                                       uint8_t                  *o_key,
                                       uint8_t                  *o_mask,
                                       uint32_t                 *out_len,
                                       flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.l2_dmac_type == TRUE ? 0xFF : 0;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.l2_dmac_type) {
        case SX_ACL_L2_DMAC_TYPE_MULTICAST:
            *o_key = (uint8_t)SXD_FLEX_ACL_L2_DMAC_TYPE_MULTICAST;
            break;

        case SX_ACL_L2_DMAC_TYPE_BROADCAST:
            *o_key = (uint8_t)SXD_FLEX_ACL_L2_DMAC_TYPE_BROADCAST;
            break;

        case SX_ACL_L2_DMAC_TYPE_UNICAST:
            *o_key = (uint8_t)SXD_FLEX_ACL_L2_DMAC_TYPE_UNICAST;
            break;

        default:
            SX_LOG_ERR("l2_dmac_type is invalid :%d \n", i_key->key.l2_dmac_type);
            return SX_STATUS_ERROR;
        }
    }

    *out_len = 1;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __l3_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.l3_type == TRUE ? 0xFF : 0;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.l3_type) {
        case SX_ACL_L3_TYPE_IPV4:
            *o_key = (uint8_t)SXD_FLEX_ACL_L3_TYPE_IPV4;
            break;

        case SX_ACL_L3_TYPE_IPV6:
            *o_key = (uint8_t)SXD_FLEX_ACL_L3_TYPE_IPV6;
            break;

        case SX_ACL_L3_TYPE_ARP:
            *o_key = (uint8_t)SXD_FLEX_ACL_L3_TYPE_ARP;
            break;

        case SX_ACL_L3_TYPE_OTHER:
            *o_key = (uint8_t)SXD_FLEX_ACL_L3_TYPE_OTHER;
            break;

        default:
            SX_LOG_ERR("l3_type is invalid :%d \n", i_key->key.l3_type);
            return SX_STATUS_ERROR;
        }
    }

    *out_len = 1;


    return SX_STATUS_SUCCESS;
}

static sx_status_t __discard_state_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.discard_state == TRUE ? 0xFF : 0;
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.discard_state) {
        case SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD:
            *o_key = (uint8_t)SXD_FLEX_ACL_DISCARD_STATE_FORWARD;
            break;

        case SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD:
            *o_key = (uint8_t)SXD_FLEX_ACL_DISCARD_STATE_DISCARD;
            break;

        case SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD:
            *o_key = (uint8_t)SXD_FLEX_ACL_DISCARD_STATE_SOFT_DISCARD_ERROR;
            break;

        default:
            SX_LOG_ERR("discard state is invalid :%d \n", i_key->key.discard_state);
            return SX_STATUS_ERROR;
        }
    }

    *out_len = 1;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __l4_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode)
{
    uint8_t l4_type_bits = 0;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.l4_type == TRUE ? 0xFF : 0;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (i_key->key.l4_type & SX_ACL_L4_TYPE_TCP) {
            l4_type_bits |= SXD_FLEX_ACL_L4_TYPE_TCP;
        }
        if (i_key->key.l4_type & SX_ACL_L4_TYPE_UDP) {
            l4_type_bits |= SXD_FLEX_ACL_L4_TYPE_UDP;
        }
        if (i_key->key.l4_type & SX_ACL_L4_TYPE_OTHER) {
            l4_type_bits |= SXD_FLEX_ACL_L4_TYPE_OTHER;
        }
        *o_key = l4_type_bits;
    }
    *out_len = 1;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __color_conv(sx_flex_acl_key_desc_t   *i_key,
                                sx_acl_hw_key_e           hw_key,
                                uint8_t                  *o_key,
                                uint8_t                  *o_mask,
                                uint32_t                 *out_len,
                                flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    HANDLE_OPAQUE(color, sizeof(i_key->key.color));

    return SX_STATUS_SUCCESS;
}

static sx_status_t __switch_prio_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    HANDLE_OPAQUE(switch_prio, sizeof(i_key->key.switch_prio));

    return SX_STATUS_SUCCESS;
}

static sx_status_t __buff_conv(sx_flex_acl_key_desc_t   *i_key,
                               sx_acl_hw_key_e           hw_key,
                               uint8_t                  *o_key,
                               uint8_t                  *o_mask,
                               uint32_t                 *out_len,
                               flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    HANDLE_OPAQUE(buff, sizeof(i_key->key.buff));

    return SX_STATUS_SUCCESS;
}

static sx_status_t __rif_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    uint16_t              rif_hw_key;
    hwd_rif_id_t          rif_id;
    sx_router_interface_t rif;
    sx_status_t           rc = SX_STATUS_SUCCESS;

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (((i_key->key_id == FLEX_ACL_KEY_ERIF) && (i_key->mask.erif == TRUE)) ||
            ((i_key->key_id == FLEX_ACL_KEY_IRIF) && (i_key->mask.irif == TRUE))) {
            memset(o_mask, 0xFF, 4);
        } else {
            memset(o_mask, 0x0, 4);
            memset(o_key, 0x0, 4);
            *out_len = 2;
            goto out;
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rif = (i_key->key_id == FLEX_ACL_KEY_ERIF) ? i_key->key.erif : i_key->key.irif;
        rc = sdk_router_cmn_rif_hw_id_get(rif, &rif_id);
        rif_hw_key = (uint16_t)rif_id;
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("%s %d is not valid.\n", i_key->key_id == FLEX_ACL_KEY_ERIF ? "ERIF" : "IRIF", rif);
            goto out;
        }

        switch (hw_key) {
        case FLEX_ACL_HW_KEY_IRIF_E:
        case FLEX_ACL_HW_KEY_ERIF_E:
            memcpy(o_key, &rif_hw_key, 2);
            *out_len = 2;
            break;

        case FLEX_ACL_HW_KEY_IRIF_3_0_E:
            *o_key = rif_hw_key & 0xf;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_IRIF_7_4_E:
            *o_key = (rif_hw_key >> 4) & 0xf;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_IRIF_11_8_E:
            *o_key = (rif_hw_key >> 8) & 0xf;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_IRIF_12_E:
            *o_key = (rif_hw_key >> 12) & 0x1;
            *out_len = 1;
            break;

        default:
            SX_LOG_ERR("Invalid irif HW key id:%d \n", hw_key);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    return rc;
}

static sx_status_t __virtual_router_conv(sx_flex_acl_key_desc_t   *i_key,
                                         sx_acl_hw_key_e           hw_key,
                                         uint8_t                  *o_key,
                                         uint8_t                  *o_mask,
                                         uint32_t                 *out_len,
                                         flex_acl_key_build_mode_e build_mode)
{
    uint16_t    hw_virtual_router = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (IS_KEY_BUILD_MASK(build_mode)) {
        memset(o_mask, i_key->mask.virtual_router == TRUE ? 0xFF : 0, 2);
        if (i_key->mask.virtual_router == FALSE) {
            memset(o_key, 0, 2);
            *out_len = (hw_key == FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E) ? 2 : 1;
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (hw_key) {
        case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E:
            hw_virtual_router = (uint16_t)i_key->key.virtual_router;
            *out_len = 2;
            break;

        case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E:
            hw_virtual_router = ((uint16_t)i_key->key.virtual_router) & 0xF;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E:
            hw_virtual_router = (((uint16_t)i_key->key.virtual_router) >> 4) & 0xF;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E:
            hw_virtual_router = (((uint16_t)i_key->key.virtual_router) >> 8) & 0x7;
            *out_len = 1;
            break;

        case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E:
            hw_virtual_router = (((uint16_t)i_key->key.virtual_router) >> 11) & 0x1;
            *out_len = 1;
            break;

        default:
            SX_LOG_ERR("Invalid virtual router HW key id:%d \n", hw_key);
            rc = SX_STATUS_ERROR;
            goto out;
        }

        memcpy(o_key, &hw_virtual_router, 2);
    }

out:
    return rc;
}

static sx_status_t __tunnel_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.tunnel_type == TRUE ? 0xFF : 0;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.tunnel_type) {
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
            *o_key = SXD_TUNNEL_TYPE_IPINIP;
            break;

        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
            *o_key = SXD_TUNNEL_TYPE_GRE;
            break;

        case SX_TUNNEL_TYPE_NVE_VXLAN:
        case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        case SX_TUNNEL_TYPE_NVE_GENEVE:
            *o_key = SXD_TUNNEL_TYPE_VXLAN;
            break;

        case SX_TUNNEL_TYPE_NVE_NVGRE:
        case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
            *o_key = SXD_TUNNEL_TYPE_NVGRE;
            break;

        case SX_TUNNEL_TYPE_L2_FLEX:
        case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
            *o_key = SXD_TUNNEL_TYPE_FLEX;
            break;

        default:
            SX_LOG_ERR("Invalid Tunnel type :%u \n", i_key->key.tunnel_type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *out_len = 1;

out:
    return rc;
}

static sx_status_t __tunnel_nve_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                          sx_acl_hw_key_e           hw_key,
                                          uint8_t                  *o_key,
                                          uint8_t                  *o_mask,
                                          uint32_t                 *out_len,
                                          flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.tunnel_nve_type == TRUE ? 0xFF : 0;

        if (!*o_mask) {
            *o_key = 0;
            *out_len = 1;
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.tunnel_nve_type) {
        case SX_TUNNEL_TYPE_NVE_VXLAN:
        case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
            *o_key = SXD_NVE_TUNNEL_TYPE_VXLAN;
            break;

        case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
            *o_key = SXD_NVE_TUNNEL_TYPE_VXLAN_GPE;
            break;

        case SX_TUNNEL_TYPE_NVE_GENEVE:
            *o_key = SXD_NVE_TUNNEL_TYPE_GENEVE;
            break;

        case SX_TUNNEL_TYPE_NVE_NVGRE:
        case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
            *o_key = SXD_NVE_TUNNEL_TYPE_NVGRE;
            break;

        default:
            SX_LOG_ERR("Invalid Tunnel type :%u \n", i_key->key.tunnel_type);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *out_len = 1;

out:
    return rc;
}

static sx_status_t __ar_packet_class_type_conv(sx_flex_acl_key_desc_t   *i_key,
                                               sx_acl_hw_key_e           hw_key,
                                               uint8_t                  *o_key,
                                               uint8_t                  *o_mask,
                                               uint32_t                 *out_len,
                                               flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.ar_packet_class == TRUE ? 0xFF : 0;

        if (!*o_mask) {
            *o_key = 0;
            *out_len = 1;
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.ar_packet_class) {
        case SX_AR_CLASSIFIER_ACTION_STATIC_E:
            *o_key = SX_AR_HW_PROFILE_HBF_E;
            break;

        case SX_AR_CLASSIFIER_ACTION_PROFILE0_E:
            *o_key = SX_AR_HW_PROFILE_0_E;
            break;

        case SX_AR_CLASSIFIER_ACTION_PROFILE1_E:
            *o_key = SX_AR_HW_PROFILE_1_E;
            break;

        default:
            SX_LOG_ERR("Invalid AR packet classification type :%s \n",
                       sx_ar_classifier_action_type_str(i_key->key.ar_packet_class));
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *out_len = 1;

out:
    return rc;
}

static sx_status_t __nd_sll_or_tll_conv(sx_flex_acl_key_desc_t   *i_key,
                                        sx_acl_hw_key_e           hw_key,
                                        uint8_t                  *o_key,
                                        uint8_t                  *o_mask,
                                        uint32_t                 *out_len,
                                        flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.nd_sll_or_tll_valid == TRUE ? 0xFF : 0;

        if (!*o_mask) {
            *o_key = 0;
            *out_len = 1;
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (i_key->key.nd_sll_or_tll_valid) {
        case SX_ACL_NO_ND_SLL_OR_TTL:
            *o_key = SXD_FLEX_ACL_NO_ND_SLL_OR_TTL;
            break;

        case SX_ACL_ND_SLL:
            *o_key = SXD_FLEX_ACL_ND_SLL;
            break;

        case SX_ACL_ND_TLL:
            *o_key = SXD_FLEX_ACL_ND_TLL;
            break;

        default:
            SX_LOG_ERR("Invalid nd_sll_or_tll type :%u \n", i_key->key.nd_sll_or_tll_valid);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *out_len = 1;

out:
    return rc;
}

static sx_status_t __smpe_conv(sx_flex_acl_key_desc_t   *i_key,
                               sx_acl_hw_key_e           hw_key,
                               uint8_t                  *o_key,
                               uint8_t                  *o_mask,
                               uint32_t                 *out_len,
                               flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint16_t    smpe_index = FM_INVALID_MPE_INDEX;
    mpe_key_t   mpe_key;

    UNUSED_PARAM(hw_key);
    SX_MEM_CLR(mpe_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        memset(o_mask, i_key->mask.bum_bridge_id == TRUE ? 0xFF : 0, sizeof(uint16_t));
        if (i_key->mask.bum_bridge_id == FALSE) {
            memset(o_key, 0, sizeof(uint16_t));
            *out_len = sizeof(uint16_t);
            goto out;
        }
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        mpe_key.key.fid = i_key->key.bum_bridge_id;
        mpe_key.type = MPE_KEY_FID_E;
        rc = mpe_manager_get_index(mpe_key, &smpe_index);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get MPE index by FID %d\n", i_key->key.bum_bridge_id);
            goto out;
        }
        memcpy(o_key, &smpe_index,  sizeof(uint16_t));
    }

    *out_len = sizeof(uint16_t);
out:
    return rc;
}

static sx_status_t __fid_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    uint16_t    fid_key;
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        memset(o_mask, i_key->mask.fid == TRUE ? 0xFF : 0, 2);
        if (i_key->mask.fid == FALSE) {
            memset(o_key, 0, 2);
            *out_len = 2;
            goto out;
        }
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rc = sdk_fid_manager_get_hwfid_by_fid(i_key->key.fid, &fid_key);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL: Failed to get HW FID for FID:[%u]. rc=[%s]\n", i_key->key.fid, sx_status_str(rc));
            goto out;
        }
        memcpy(o_key, &fid_key, 2);
    }

    *out_len = 2;

out:
    return rc;
}

static sx_status_t __trap_id_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode)
{
    uint16_t    hw_syndrome;
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);

    *out_len = 2;

    if (IS_KEY_BUILD_MASK(build_mode)) {
        memset(o_mask, i_key->mask.trap_id == TRUE ? 0xFF : 0, *out_len);
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        if (IS_KEY_BUILD_MASK(build_mode) && (i_key->mask.trap_id == FALSE)) {
            SX_MEM_CLR_BUF(o_key, *out_len);
        } else {
            rc = trap_id_hw_syndrome_get(i_key->key.trap_id, &hw_syndrome);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL: Failed get HW syndrome for SW trap ID[%u]\n", i_key->key.trap_id);
                goto out;
            }
            SX_MEM_CPY_BUF(o_key, &hw_syndrome, *out_len);
        }
    }

out:
    return rc;
}

static sx_status_t __l4_type_extended_conv(sx_flex_acl_key_desc_t   *i_key,
                                           sx_acl_hw_key_e           hw_key,
                                           uint8_t                  *o_key,
                                           uint8_t                  *o_mask,
                                           uint32_t                 *out_len,
                                           flex_acl_key_build_mode_e build_mode)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_flex_acl_l4_type_extended_t l4_type_extended_key;

    UNUSED_PARAM(hw_key);

    switch (i_key->key_id) {
    case FLEX_ACL_KEY_L4_TYPE_EXTENDED:
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = i_key->mask.l4_type_extended == TRUE ? 0xFF : 0;
        }
        l4_type_extended_key = i_key->key.l4_type_extended;
        break;

    case FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED:
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = i_key->mask.inner_l4_type_extended == TRUE ? 0xFF : 0;
        }
        l4_type_extended_key = i_key->key.inner_l4_type_extended;
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(i_key->key_id));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        switch (l4_type_extended_key) {
        case SX_ACL_L4_TYPE_EXTENDED_TCP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_TCP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_UDP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_UDP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_BTH:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_BTH;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_BTHOUDP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_BTHOUDP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_ICMP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_ICMP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_IGMP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_IGMP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_ESP:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_ESP;
            break;

        case SX_ACL_L4_TYPE_EXTENDED_RAW:
        case SX_ACL_L4_TYPE_EXTENDED_OTHERS:
            *o_key = SXD_FLEX_ACL_L4_TYPE_EXTENDED_RAW;
            break;

        default:
            SX_LOG_ERR("Invalid l4 type type :%u \n", l4_type_extended_key);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    *out_len = 1;

out:
    return rc;
}

static sx_status_t __rx_list_conv(sx_flex_acl_key_desc_t   *i_key,
                                  sx_acl_hw_key_e           hw_key,
                                  uint8_t                  *o_key,
                                  uint8_t                  *o_mask,
                                  uint32_t                 *out_len,
                                  flex_acl_key_build_mode_e build_mode)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 phy_port = 0;
    uint32_t                 port_idx = 0;
    sx_acl_port_list_id_t    rx_list_id;
    sx_acl_port_list_entry_t port_list[RM_API_ACL_PORT_LIST_MAX];
    uint32_t                 port_list_count = 0;
    uint8_t                  conv_local_src_port_arr[FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS];
    uint8_t                  conv_local_src_mask_arr[FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS];

    UNUSED_PARAM(hw_key);

    SX_LOG_ENTER();

    memset(o_mask, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);
    memset(o_key, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);
    memset(port_list, 0, sizeof(sx_acl_port_list_entry_t) * RM_API_ACL_PORT_LIST_MAX);
    memset(conv_local_src_port_arr, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);
    memset(conv_local_src_mask_arr, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);

    switch (i_key->key_id) {
    case FLEX_ACL_KEY_RX_LIST:
        *out_len = (rm_resource_global.port_ext_num_max / FLEX_ACL_BITS_IN_BYTE) + 1;
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.rx_list == FALSE) {
                return SX_STATUS_SUCCESS;
            }
        }
        /*CPU port */
        conv_local_src_mask_arr[0] |= 1;
        rx_list_id = i_key->key.rx_list;
        break;

    case FLEX_ACL_KEY_RX_TUNNEL_LIST:
        *out_len = 1;
        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.rx_tunnel_list == FALSE) {
                return SX_STATUS_SUCCESS;
            }
        }
        rx_list_id = i_key->key.rx_tunnel_list;
        break;

    default:
        SX_LOG_ERR("Key %s is invalid\n", flex_acl_db_key_id_to_str(i_key->key_id));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_rx_list_get(rx_list_id, port_list, &port_list_count, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to get RX list id:[%u] from DB. rc=[%s]\n", rx_list_id, sx_status_str(rc));
        goto out;
    }

    for (port_idx = 0; port_idx < port_list_count; port_idx++) {
        phy_port = SX_PORT_PHY_ID_GET(port_list[port_idx].log_port);

        if (port_list[port_idx].port_match == SX_ACL_PORT_LIST_MATCH_POSITIVE) {
            SXD_BITMAP_SET(conv_local_src_port_arr,
                           FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS,
                           FLEX_ACL_BITS_IN_BYTE,
                           phy_port);
        }

        SXD_BITMAP_SET(conv_local_src_mask_arr,
                       FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS,
                       FLEX_ACL_BITS_IN_BYTE,
                       phy_port);
    }
    memcpy(o_key, &conv_local_src_port_arr, *out_len);
    memcpy(o_mask, &conv_local_src_mask_arr, *out_len);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __port_list_conv_bit_set(uint32_t phy_port, uint8_t *mask_arr, sx_acl_port_list_match_t match_type)
{
    if (match_type == SX_ACL_PORT_LIST_MATCH_POSITIVE) {
        SXD_BITMAP_CLR(mask_arr,
                       FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS,
                       FLEX_ACL_BITS_IN_BYTE,
                       phy_port);
    } else {
        SXD_BITMAP_SET(mask_arr,
                       FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS,
                       FLEX_ACL_BITS_IN_BYTE,
                       phy_port);
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __port_list_conv(sx_flex_acl_key_desc_t   *i_key,
                                    sx_acl_hw_key_e           hw_key,
                                    uint8_t                  *o_key,
                                    uint8_t                  *o_mask,
                                    uint32_t                 *out_len,
                                    flex_acl_key_build_mode_e build_mode)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_port_type_t           port_type = SX_PORT_TYPE_NETWORK;
    uint32_t                 phy_port = 0;
    uint32_t                 port_idx = 0;
    uint32_t                 lag_port_idx = 0;
    uint8_t                  conv_local_src_port_arr[FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS];
    uint8_t                  conv_local_src_mask_arr[FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS];
    sx_mc_next_hop_t        *next_hops = NULL;
    uint32_t                 next_hop_cnt = 0;
    sx_mc_container_id_t     mc_container_id = 0;
    sx_acl_port_list_match_t match_type = SX_ACL_PORT_LIST_MATCH_POSITIVE;
    uint32_t                 lag_port_count = rm_resource_global.lag_port_members_max;
    sx_port_id_t            *lag_port_list_p = NULL;
    sx_port_log_id_t         log_port = 0;
    boolean_t                mask_boolean = FALSE;

    UNUSED_PARAM(hw_key);

    SX_LOG_ENTER();

    memset(o_mask, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);
    memset(o_key, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);
    *out_len = (rm_resource_global.port_ext_num_max / FLEX_ACL_BITS_IN_BYTE) + 1;

    rc = flex_acl_key_port_list_get_info(i_key, &mc_container_id, &match_type, &mask_boolean);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed port list info get for key type [%u]\n", i_key->key_id);
        goto out;
    }

    if (IS_KEY_BUILD_MASK(build_mode)) {
        if (mask_boolean == FALSE) {
            return SX_STATUS_SUCCESS;
        }
    }

    rc = sdk_mc_container_impl_get(mc_container_id, NULL, &next_hop_cnt, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PORT_LIST : Invalid MC id:%u  err %s.\n", mc_container_id, sx_status_str(rc));
        goto out;
    }

    if (next_hop_cnt > 0) {
        next_hops = cl_calloc(next_hop_cnt, sizeof(sx_mc_next_hop_t));
        if (next_hops == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("No memory for MC container %u next hops\n", mc_container_id);
            goto out;
        }

        rc = sdk_mc_container_impl_get(mc_container_id, next_hops, &next_hop_cnt, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve MC container, container id :%u rc=[%s]\n",
                       mc_container_id, sx_status_str(rc));
            goto out;
        }
    }

    lag_port_list_p = (sx_port_log_id_t*)cl_calloc(lag_port_count, sizeof(sx_port_log_id_t));
    if (lag_port_list_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for lag port list\n");
        goto out;
    }

    /* Set mask bits for the ports we do NOT want to match.
     * Negative: start with all zeroes, then set bits for each port in the list.
     * Positive: start with all ones, then clear bits for each port in the list.
     */
    memset(conv_local_src_mask_arr,
           (match_type == SX_ACL_PORT_LIST_MATCH_POSITIVE) ? 0xff : 0x00,
           sizeof(conv_local_src_mask_arr));

    /* The value bits are always all set to ZERO. */
    memset(conv_local_src_port_arr, 0, sizeof(conv_local_src_port_arr));

    /* Set mask bit for CPU port */
    phy_port = 0;
    SXD_BITMAP_SET(conv_local_src_mask_arr,
                   FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS,
                   FLEX_ACL_BITS_IN_BYTE,
                   phy_port);

    for (port_idx = 0; port_idx < next_hop_cnt; port_idx++) {
        log_port = next_hops[port_idx].data.log_port;
        port_type = SX_PORT_TYPE_ID_GET(log_port);
        if (port_type == SX_PORT_TYPE_NETWORK) {
            phy_port = SX_PORT_PHY_ID_GET(log_port);
            __port_list_conv_bit_set(phy_port, conv_local_src_mask_arr, match_type);
        } else { /* SX_PORT_TYPE_LAG */
            lag_port_count = rm_resource_global.lag_port_members_max;
            memset(lag_port_list_p, 0, lag_port_count * sizeof(sx_port_log_id_t));
            rc = flex_acl_get_lag_ports_list(log_port, FALSE, lag_port_list_p, &lag_port_count);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get port list for LAG [0x%x], rc=[%s]\n",
                           (uint32_t)log_port, sx_status_str(rc));
                goto out;
            }
            for (lag_port_idx = 0; lag_port_idx < lag_port_count; lag_port_idx++) {
                phy_port = SX_PORT_PHY_ID_GET(lag_port_list_p[lag_port_idx]);
                __port_list_conv_bit_set(phy_port, conv_local_src_mask_arr, match_type);
            }
        }
    }

    memcpy(o_key, &conv_local_src_port_arr, *out_len);
    memcpy(o_mask, &conv_local_src_mask_arr, *out_len);

out:
    if (next_hops != NULL) {
        CL_FREE_N_NULL(next_hops);
    }
    if (lag_port_list_p != NULL) {
        CL_FREE_N_NULL(lag_port_list_p);
    }

    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __ipv6_extension_headers_conv(uint32_t                             extension_headers_cnt,
                                                 sx_flex_acl_ipv6_extension_header_t *extension_headers_list,
                                                 sx_acl_hw_key_e                      hw_key,
                                                 uint8_t                             *o_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    *o_key = 0;

    for (i = 0; i < extension_headers_cnt; i++) {
        if ((hw_key == FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E) ||
            (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E)) {
            if (extension_headers_list[i] == SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH) {
                *o_key = 1;
            }
            continue;
        }
        if ((hw_key == FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E) ||
            (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E)) {
            if (extension_headers_list[i] == SX_FLEX_ACL_IPV6_EXTENSION_HEADER_SHIM6) {
                *o_key = 1;
            }
            continue;
        }
        if ((hw_key == FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E) ||
            (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E)) {
            if (extension_headers_list[i] == SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HOST_IDENTIFY_PROTOCOL) {
                *o_key = 1;
            }
            continue;
        }
        if ((hw_key == FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E) ||
            (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E)) {
            if (extension_headers_list[i] == SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH_ROUTER_ALERT) {
                *o_key = 1;
            }
            continue;
        }

        if ((hw_key != FLEX_ACL_HW_KEY_IPV6_EXTENSION_E) &&
            (hw_key != FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E)) {
            SX_LOG_ERR("Failed conversion of IPV6 extension wrong HW key:%u\n", hw_key);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        switch (extension_headers_list[i]) {
        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY:
            *o_key |= 1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY;
            break;

        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE:
        case SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH:
            break;

        default:
            SX_LOG_ERR("Invalid ipv6 extension type:%u  \n",
                       extension_headers_list[i]);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __ipv6_extension_conv(sx_flex_acl_key_desc_t   *i_key,
                                         sx_acl_hw_key_e           hw_key,
                                         uint8_t                  *o_key,
                                         uint8_t                  *o_mask,
                                         uint32_t                 *out_len,
                                         flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rc = __ipv6_extension_headers_conv(i_key->key.ipv6_extension_headers.extension_headers_cnt,
                                           i_key->key.ipv6_extension_headers.extension_headers_list,
                                           hw_key,
                                           o_key);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.ipv6_extension_headers ? *o_key : 0;
    }
    *out_len = 1;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __inner_ipv6_extension_conv(sx_flex_acl_key_desc_t   *i_key,
                                               sx_acl_hw_key_e           hw_key,
                                               uint8_t                  *o_key,
                                               uint8_t                  *o_mask,
                                               uint32_t                 *out_len,
                                               flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        rc = __ipv6_extension_headers_conv(i_key->key.inner_ipv6_extension_headers.extension_headers_cnt,
                                           i_key->key.inner_ipv6_extension_headers.extension_headers_list,
                                           hw_key,
                                           o_key);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = i_key->mask.inner_ipv6_extension_headers ? *o_key : 0;
    }
    *out_len = 1;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __custom_byte_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E:
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            *o_key = i_key->key.custom_byte;
        }
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = i_key->mask.custom_byte;
        }
        break;

    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E:
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            *o_key = 1;
        }
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = i_key->mask.custom_byte ? 1 : 0;
        }
        break;

    default:
        SX_LOG_ERR("Invalid hw key :%u \n", hw_key);
        goto out;
    }
    *out_len = 1;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __gp_register_conv(sx_flex_acl_key_desc_t   *i_key,
                                      sx_acl_hw_key_e           hw_key,
                                      uint8_t                  *o_key,
                                      uint8_t                  *o_mask,
                                      uint32_t                 *out_len,
                                      flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E:
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            *o_key = i_key->key.gp_register & 0xff;
        }
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = i_key->mask.gp_register & 0xff;
        }
        break;

    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E:
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            *o_key = (i_key->key.gp_register >> 8) & 0xff;
        }
        if (IS_KEY_BUILD_MASK(build_mode)) {
            *o_mask = (i_key->mask.gp_register >> 8) & 0xff;
        }
        break;

    default:
        SX_LOG_ERR("Invalid hw key for gp register:%u \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    *out_len = 1;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __mac_hw_key_offset_get(const sx_acl_hw_key_e hw_key,
                                           uint32_t             *offset_p,
                                           uint32_t             *len_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (hw_key) {
    /* Flex1 */
    case FLEX_ACL_HW_KEY_DMAC_E:
    case FLEX_ACL_HW_KEY_SMAC_E:
    case FLEX_ACL_HW_KEY_INNER_SMAC_E:
    case FLEX_ACL_HW_KEY_INNER_DMAC_E:
        *offset_p = 0;
        *len_p = ETHER_ADDR_LEN;
        break;

    /* Flex2 */
    case FLEX_ACL_HW_KEY_DMAC_31_0_E:
    case FLEX_ACL_HW_KEY_SMAC_31_0_E:
    case FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E:
    case FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E:
        *offset_p = 2;
        *len_p = 4;
        break;

    case FLEX_ACL_HW_KEY_DMAC_47_32_E:
    case FLEX_ACL_HW_KEY_SMAC_47_32_E:
    case FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E:
    case FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E:
        *offset_p = 0;
        *len_p = 2;
        break;

    default:
        SX_LOG_ERR("Invalid MAC HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }
out:
    return rc;
}

static sx_status_t __mac_conv(const sx_mac_addr_t      *i_key,
                              const sx_mac_addr_t      *i_mask,
                              const sx_acl_hw_key_e     hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    offset = 0;

    rc = __mac_hw_key_offset_get(hw_key, &offset, out_len);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (IS_KEY_BUILD_VALUE(build_mode)) {
        memcpy(o_key, &(i_key->ether_addr_octet[offset]), *out_len);
    }
    if (IS_KEY_BUILD_MASK(build_mode)) {
        memcpy(o_mask, &(i_mask->ether_addr_octet[offset]), *out_len);
    }

out:
    return rc;
}

static sx_status_t __smac_conv(sx_flex_acl_key_desc_t   *i_key,
                               sx_acl_hw_key_e           hw_key,
                               uint8_t                  *o_key,
                               uint8_t                  *o_mask,
                               uint32_t                 *out_len,
                               flex_acl_key_build_mode_e build_mode)
{
    return __mac_conv(&(i_key->key.smac), &(i_key->mask.smac), hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __dmac_conv(sx_flex_acl_key_desc_t   *i_key,
                               sx_acl_hw_key_e           hw_key,
                               uint8_t                  *o_key,
                               uint8_t                  *o_mask,
                               uint32_t                 *out_len,
                               flex_acl_key_build_mode_e build_mode)
{
    return __mac_conv(&(i_key->key.dmac), &(i_key->mask.dmac), hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __inner_smac_conv(sx_flex_acl_key_desc_t   *i_key,
                                     sx_acl_hw_key_e           hw_key,
                                     uint8_t                  *o_key,
                                     uint8_t                  *o_mask,
                                     uint32_t                 *out_len,
                                     flex_acl_key_build_mode_e build_mode)
{
    return __mac_conv(&(i_key->key.inner_smac), &(i_key->mask.inner_smac), hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __inner_dmac_conv(sx_flex_acl_key_desc_t   *i_key,
                                     sx_acl_hw_key_e           hw_key,
                                     uint8_t                  *o_key,
                                     uint8_t                  *o_mask,
                                     uint32_t                 *out_len,
                                     flex_acl_key_build_mode_e build_mode)
{
    return __mac_conv(&(i_key->key.inner_dmac), &(i_key->mask.inner_dmac), hw_key, o_key, o_mask, out_len, build_mode);
}

static sx_status_t __gp_register_offset_conv(sx_flex_acl_key_desc_t   *i_key,
                                             sx_acl_hw_key_e           hw_key,
                                             uint8_t                  *o_key,
                                             uint8_t                  *o_mask,
                                             uint32_t                 *out_len,
                                             flex_acl_key_build_mode_e build_mode)
{
    UNUSED_PARAM(hw_key);

    if (IS_KEY_BUILD_MASK(build_mode)) {
        *o_mask = (uint8_t)(i_key->mask.gp_register_offset >> 1);
    }
    if (IS_KEY_BUILD_VALUE(build_mode)) {
        *o_key = (uint8_t)(i_key->key.gp_register_offset >> 1);
    }

    *out_len = sizeof(uint8_t);

    return SX_STATUS_SUCCESS;
}

/***********************************************
*  Key extraction conversion functions
***********************************************/

static sx_status_t __src_port_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                           sx_acl_hw_key_e         hw_key,
                                           uint8_t                *hw_key_buff_p,
                                           boolean_t               last_hw_key)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t src_sys_port = 0;
    sx_port_log_id_t     src_port = 0;
    uint32_t             conv_physical_src_port = 0;
    uint16_t             rx_local_port = 0;

    UNUSED_PARAM(last_hw_key);

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_SRC_PORT_E:           /* Flex1 */
        memcpy(&conv_physical_src_port, hw_key_buff_p, 4);

        /* Check if this is a LAG port */
        if (conv_physical_src_port & (1 << 16)) {
            SX_PORT_TYPE_ID_SET(src_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(src_port, (conv_physical_src_port & 0xFFFF));
        } else {
            src_sys_port = conv_physical_src_port & 0xFFFF;
            rc = port_log_id_map_get(SX_ACCESS_CMD_GET, src_sys_port, &src_port);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Can't find logical port for sys port extract [0x%04X]\n", src_sys_port);
                goto out;
            }
            SX_PORT_TYPE_ID_SET(src_port, SX_PORT_TYPE_NETWORK);
        }
        break;

    case FLEX_ACL_HW_KEY_RX_SYS_PORT_E:   /* Flex2 */
    case FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E:
        memcpy(&rx_local_port, hw_key_buff_p, 2);

        if ((rx_local_port & (1 << 15)) && (hw_key != FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E)) {
            SX_PORT_TYPE_ID_SET(src_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(src_port, (rx_local_port & 0x7FFF));
        } else {
            rx_local_port &= 0x7FFF;
            if (rx_local_port == rm_resource_global.port_ext_num_max) {
                rx_local_port = CPU_PORT_PHY_ID;
            } else {
                rx_local_port++;
            }
            SX_PORT_LCL_ID_SET(src_port, rx_local_port);
            SX_PORT_TYPE_ID_SET(src_port, SX_PORT_TYPE_NETWORK);
        }
        break;

    default:
        SX_LOG_ERR("Invalid source port HW key id:%d for extract \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    key_p->key.src_port = src_port;
out:
    return rc;
}

static sx_status_t __dst_port_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                           sx_acl_hw_key_e         hw_key,
                                           uint8_t                *hw_key_buff_p,
                                           boolean_t               last_hw_key)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t dst_sys_port = 0;
    sx_port_log_id_t     dst_port = 0;

    UNUSED_PARAM(last_hw_key);

    memcpy(&dst_sys_port, hw_key_buff_p, 2);

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_DST_PORT_E:       /* Flex1 */

        rc = port_log_id_map_get(SX_ACCESS_CMD_GET, dst_sys_port, &dst_port);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Can't find logical port for sys port extract [0x%04X]\n", dst_sys_port);
            goto out;
        }
        SX_PORT_TYPE_ID_SET(dst_port, SX_PORT_TYPE_NETWORK);

        break;

    case FLEX_ACL_HW_KEY_TX_SYS_PORT_E:   /* Flex2 */

        if (dst_sys_port == rm_resource_global.port_ext_num_max) {
            dst_sys_port = CPU_PORT_PHY_ID;
        } else {
            dst_sys_port++;
        }
        SX_PORT_LCL_ID_SET(dst_port, dst_sys_port);
        SX_PORT_TYPE_ID_SET(dst_port, SX_PORT_TYPE_NETWORK);
        break;

    default:
        SX_LOG_ERR("Invalid destination port HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    key_p->key.dst_port = dst_port;
out:
    return rc;
}

static sx_status_t __mac_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    offset = 0, size = 0;
    uint8_t    *mac_p = NULL;

    UNUSED_PARAM(last_hw_key);

    rc = __mac_hw_key_offset_get(hw_key, &offset, &size);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    switch (key_p->key_id) {
    case FLEX_ACL_KEY_DMAC:
        mac_p = key_p->key.dmac.ether_addr_octet;
        break;

    case FLEX_ACL_KEY_SMAC:
        mac_p = key_p->key.smac.ether_addr_octet;
        break;

    case FLEX_ACL_KEY_INNER_DMAC:
        mac_p = key_p->key.inner_dmac.ether_addr_octet;
        break;

    case FLEX_ACL_KEY_INNER_SMAC:
        mac_p = key_p->key.inner_smac.ether_addr_octet;
        break;

    default:
        SX_LOG_ERR("Invalid MAC HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    memcpy(&mac_p[offset], hw_key_buff_p, size);

out:
    return rc;
}

static sx_status_t __ipv4_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                       sx_acl_hw_key_e         hw_key,
                                       uint8_t                *hw_key_buff_p,
                                       boolean_t               last_hw_key)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    sx_ip_addr_t *ip_addr_p = NULL;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (key_p->key_id) {
    case FLEX_ACL_KEY_DIP:
        ip_addr_p = &key_p->key.dip;
        break;

    case FLEX_ACL_KEY_SIP:
        ip_addr_p = &key_p->key.sip;
        break;

    case FLEX_ACL_KEY_INNER_DIP:
        ip_addr_p = &key_p->key.inner_dip;
        break;

    case FLEX_ACL_KEY_INNER_SIP:
        ip_addr_p = &key_p->key.inner_sip;
        break;

    default:
        SX_LOG_ERR("Invalid IPv4 key id:%s extract\n", flex_acl_db_key_id_to_str(key_p->key_id));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    memcpy(&(ip_addr_p->addr.ipv4.s_addr), hw_key_buff_p, 4);
    ip_addr_p->version = SX_IP_VERSION_IPV4;

out:
    return rc;
}


static sx_status_t __ipv6_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                       sx_acl_hw_key_e         hw_key,
                                       uint8_t                *hw_key_buff_p,
                                       boolean_t               last_hw_key)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    uint32_t      offset = 0;
    sx_ip_addr_t *ip_addr_p = NULL;

    UNUSED_PARAM(last_hw_key);

    rc = __ipv6_hw_key_offset_get(hw_key, &offset);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    switch (key_p->key_id) {
    case FLEX_ACL_KEY_DIPV6:
        ip_addr_p = &key_p->key.dipv6;
        break;

    case FLEX_ACL_KEY_SIPV6:
        ip_addr_p = &key_p->key.sipv6;
        break;

    case FLEX_ACL_KEY_INNER_DIPV6:
        ip_addr_p = &key_p->key.inner_dipv6;
        break;

    case FLEX_ACL_KEY_INNER_SIPV6:
        ip_addr_p = &key_p->key.inner_sipv6;
        break;

    default:
        SX_LOG_ERR("Invalid IPv6 key id:%s extract\n", flex_acl_db_key_id_to_str(key_p->key_id));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    memcpy(&(ip_addr_p->addr.ipv6.s6_addr32[offset]), hw_key_buff_p, 4);
    ip_addr_p->version = SX_IP_VERSION_IPV6;

out:
    return rc;
}

static sx_status_t __l4_port_range_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);
    uint16_t bitmap = 0, i;
    uint32_t port_range_cnt = 0;

    memcpy((uint8_t*)&bitmap, hw_key_buff_p, 2);


    /* Go over all the bits we get from the hw and check which ones are set */
    for (i = 0; i < (sizeof(bitmap) * FLEX_ACL_BITS_IN_BYTE); i++) {
        if (bitmap & (1 << i)) {
            key_p->key.l4_port_range.port_range_list[port_range_cnt++] = i;
        }
    }
    key_p->key.l4_port_range.port_range_cnt = port_range_cnt;

    return rc;
}

static sx_status_t __virtual_router_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                 sx_acl_hw_key_e         hw_key,
                                                 uint8_t                *hw_key_buff_p,
                                                 boolean_t               last_hw_key)
{
    uint16_t    hw_virtual_router = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(last_hw_key);

    memcpy(&hw_virtual_router, hw_key_buff_p, 2);

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E:
        key_p->key.virtual_router = hw_virtual_router;
        break;

    case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E:
        key_p->key.virtual_router |= hw_virtual_router & 0xF;
        break;

    case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E:
        key_p->key.virtual_router |= (hw_virtual_router & 0xF) << 4;
        break;

    case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E:
        key_p->key.virtual_router |= (hw_virtual_router & 0x7) << 8;
        break;

    case FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E:
        key_p->key.virtual_router |= (hw_virtual_router & 0x1) << 11;
        break;

    default:
        SX_LOG_ERR("Invalid virtual router HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __gp_register_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint16_t    value = hw_key_buff_p[0];

    UNUSED_PARAM(last_hw_key);

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E:
        key_p->key.gp_register |= value;
        break;

    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E:
    case FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E:
        key_p->key.gp_register |= value << 8;
        break;

    default:
        SX_LOG_ERR("Invalid hw key for gp register:%u extract\n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __gp_register_offset_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                     sx_acl_hw_key_e         hw_key,
                                                     uint8_t                *hw_key_buff_p,
                                                     boolean_t               last_hw_key)
{
    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    uint16_t value = hw_key_buff_p[0];

    key_p->key.gp_register_offset = value << 1;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __custom_byte_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key)
{
    UNUSED_PARAM(last_hw_key);

    if ((hw_key >= FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E) && (hw_key <= FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E)) {
        key_p->key.custom_byte = hw_key_buff_p[0];
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __fid_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key)
{
    sxd_fid_t   fid_key;
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    memcpy(&fid_key, hw_key_buff_p, 2);

    rc = sdk_fid_manager_get_fid_by_hwfid(fid_key, &key_p->key.fid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed to get FID for HW FID:[%u]. rc=[%s]\n", fid_key, sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

static sx_status_t __l2_dmac_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                               sx_acl_hw_key_e         hw_key,
                                               uint8_t                *hw_key_buff_p,
                                               boolean_t               last_hw_key)
{
    sxd_flex_acl_l2_dmac_type_t sxd_l2_dmac_type = (sxd_flex_acl_l2_dmac_type_t)hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (sxd_l2_dmac_type) {
    case SXD_FLEX_ACL_L2_DMAC_TYPE_MULTICAST:
        key_p->key.l2_dmac_type = SX_ACL_L2_DMAC_TYPE_MULTICAST;
        break;

    case SXD_FLEX_ACL_L2_DMAC_TYPE_BROADCAST:
        key_p->key.l2_dmac_type = SX_ACL_L2_DMAC_TYPE_BROADCAST;
        break;

    case SXD_FLEX_ACL_L2_DMAC_TYPE_UNICAST:
        key_p->key.l2_dmac_type = SX_ACL_L2_DMAC_TYPE_UNICAST;
        break;

    default:
        SX_LOG_ERR("ACL: SXD l2_dmac_type [%u] extract is invalid\n", sxd_l2_dmac_type);
        return SX_STATUS_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __l3_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key)
{
    sxd_flex_acl_l3_type_t sxd_l3_type = hw_key_buff_p[0];
    sx_flex_acl_l3_type_t  l3_type = 0;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (sxd_l3_type) {
    case SXD_FLEX_ACL_L3_TYPE_IPV4:
        l3_type = SX_ACL_L3_TYPE_IPV4;
        break;

    case SXD_FLEX_ACL_L3_TYPE_IPV6:
        l3_type = SX_ACL_L3_TYPE_IPV6;
        break;

    case SXD_FLEX_ACL_L3_TYPE_ARP:
        l3_type = SX_ACL_L3_TYPE_ARP;
        break;

    case SXD_FLEX_ACL_L3_TYPE_OTHER:
        l3_type = SX_ACL_L3_TYPE_OTHER;
        break;

    default:
        SX_LOG_ERR("AC: SXD l3_type [%u] is invalid\n", sxd_l3_type);
        return SX_STATUS_ERROR;
    }

    if (key_p->key_id == FLEX_ACL_KEY_INNER_L3_TYPE) {
        key_p->key.inner_l3_type = l3_type;
    } else {
        key_p->key.l3_type = l3_type;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __discard_state_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key)
{
    sxd_flex_acl_discard_state_t discard_state = hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (discard_state) {
    case SXD_FLEX_ACL_DISCARD_STATE_FORWARD:
        key_p->key.discard_state = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;
        break;

    case SXD_FLEX_ACL_DISCARD_STATE_DISCARD:
        key_p->key.discard_state = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD;
        break;

    case SXD_FLEX_ACL_DISCARD_STATE_SOFT_DISCARD_ERROR:
        key_p->key.discard_state = SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD;
        break;

    default:
        SX_LOG_ERR("ACL: SXD discard state [%u] is invalid \n", discard_state);
        return SX_STATUS_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __l4_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key)
{
    uint8_t l4_type_bits = hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    if (l4_type_bits & SXD_FLEX_ACL_L4_TYPE_TCP) {
        key_p->key.l4_type |= SX_ACL_L4_TYPE_TCP;
    }

    if (l4_type_bits & SXD_FLEX_ACL_L4_TYPE_UDP) {
        key_p->key.l4_type |= SX_ACL_L4_TYPE_UDP;
    }

    if (l4_type_bits & SXD_FLEX_ACL_L4_TYPE_OTHER) {
        key_p->key.l4_type |= SX_ACL_L4_TYPE_OTHER;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __l4_type_extended_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                   sx_acl_hw_key_e         hw_key,
                                                   uint8_t                *hw_key_buff_p,
                                                   boolean_t               last_hw_key)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sxd_flex_acl_l4_type_extended_t sxd_l4_type_extended = hw_key_buff_p[0];
    sx_flex_acl_l4_type_extended_t  l4_type_extended = 0;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (sxd_l4_type_extended) {
    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_TCP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_TCP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_UDP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_UDP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_BTH:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_BTH;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_BTHOUDP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_BTHOUDP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_ICMP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_ICMP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_IGMP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_IGMP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_ESP:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_ESP;
        break;

    case SXD_FLEX_ACL_L4_TYPE_EXTENDED_RAW:
        l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_RAW;
        break;

    default:
        SX_LOG_ERR("Invalid SXD l4 type extended extract :%u \n", sxd_l4_type_extended);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    if (key_p->key_id == FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED) {
        key_p->key.inner_l4_type_extended = l4_type_extended;
    } else {
        key_p->key.l4_type_extended = l4_type_extended;
    }

out:
    return rc;
}

static sx_status_t __rif_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                      sx_acl_hw_key_e         hw_key,
                                      uint8_t                *hw_key_buff_p,
                                      boolean_t               last_hw_key)
{
    hwd_rif_id_t          hwd_rif_id = 0;
    sx_router_interface_t rif = 0;
    sx_status_t           rc = SX_STATUS_SUCCESS;
    boolean_t             is_irif = TRUE;

    /* We accumulate in the user key all the bits from the hw keys. After all the hw keys are used
     * we'll convert the user key (which now contains the full hw key) to the actual user key.
     */
    switch (hw_key) {
    case FLEX_ACL_HW_KEY_IRIF_E:
        memcpy(&key_p->key.irif, hw_key_buff_p, 2);
        hwd_rif_id = key_p->key.irif;
        break;

    case FLEX_ACL_HW_KEY_ERIF_E:
        memcpy(&key_p->key.erif, hw_key_buff_p, 2);
        hwd_rif_id = key_p->key.erif;
        is_irif = FALSE;
        break;

    case FLEX_ACL_HW_KEY_IRIF_3_0_E:
        hwd_rif_id = (uint16_t)hw_key_buff_p[0];
        key_p->key.irif |= hwd_rif_id & 0xF;
        hwd_rif_id = key_p->key.irif;
        break;

    case FLEX_ACL_HW_KEY_IRIF_7_4_E:
        hwd_rif_id = (uint16_t)hw_key_buff_p[0];
        key_p->key.irif |= (hwd_rif_id & 0xF) << 4;
        ;
        hwd_rif_id = key_p->key.irif;
        break;

    case FLEX_ACL_HW_KEY_IRIF_11_8_E:
        hwd_rif_id = (uint16_t)hw_key_buff_p[0];
        key_p->key.irif |= (hwd_rif_id & 0xF) << 8;
        hwd_rif_id = key_p->key.irif;
        break;

    case FLEX_ACL_HW_KEY_IRIF_12_E:
        hwd_rif_id = (uint16_t)hw_key_buff_p[0];
        key_p->key.irif |= (hwd_rif_id & 0x1) << 12;
        hwd_rif_id = key_p->key.irif;
        break;

    default:
        SX_LOG_ERR("Invalid rif HW key id:%d for extract\n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Since we are done with all the hw keys we now convert from the HW rif to user rif */
    if (last_hw_key) {
        rc = sdk_router_cmn_rif_id_get(hwd_rif_id, &rif);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL: Failed to get RIF for HW rif:[%u] extract. rc=[%s]\n", hwd_rif_id, sx_status_str(rc));
            goto out;
        }
    }
    if (is_irif) {
        key_p->key.irif = rif;
    } else {
        key_p->key.erif = rif;
    }

out:
    return rc;
}

static sx_status_t __tunnel_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                              sx_acl_hw_key_e         hw_key,
                                              uint8_t                *hw_key_buff_p,
                                              boolean_t               last_hw_key)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sxd_tunnel_type_t sxd_tunnel_type = hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    /* NOTE: Since there are many user values mapped to one HW value,
     * We chose a random user value to represent a HW value.
     */
    switch (sxd_tunnel_type) {
    case SXD_TUNNEL_TYPE_IPINIP:
        key_p->key.tunnel_type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4;
        break;

    case SXD_TUNNEL_TYPE_GRE:
        key_p->key.tunnel_type = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE;
        break;

    case SXD_TUNNEL_TYPE_VXLAN:
        key_p->key.tunnel_type = SX_TUNNEL_TYPE_NVE_VXLAN;
        break;

    case SXD_TUNNEL_TYPE_NVGRE:
        key_p->key.tunnel_type = SX_TUNNEL_TYPE_NVE_NVGRE;
        break;

    case SXD_TUNNEL_TYPE_FLEX:
        key_p->key.tunnel_type = SX_TUNNEL_TYPE_L2_FLEX;
        break;

    default:
        SX_LOG_ERR("Invalid Tunnel type :%u \n", sxd_tunnel_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __tunnel_nve_type_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                  sx_acl_hw_key_e         hw_key,
                                                  uint8_t                *hw_key_buff_p,
                                                  boolean_t               last_hw_key)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sxd_nve_tunnel_type_t sxd_nve_tunnel_type = hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    /* NOTE: Since there are many user values mapped to one HW value,
     * We chose a random user value to represent a HW value.
     */
    switch (sxd_nve_tunnel_type) {
    case SXD_NVE_TUNNEL_TYPE_VXLAN:
        key_p->key.tunnel_nve_type = SX_TUNNEL_TYPE_NVE_VXLAN;
        break;

    case SXD_NVE_TUNNEL_TYPE_VXLAN_GPE:
        key_p->key.tunnel_nve_type = SX_TUNNEL_TYPE_NVE_VXLAN_GPE;
        break;

    case SXD_NVE_TUNNEL_TYPE_GENEVE:
        key_p->key.tunnel_nve_type = SX_TUNNEL_TYPE_NVE_GENEVE;
        break;

    case SXD_NVE_TUNNEL_TYPE_NVGRE:
        key_p->key.tunnel_nve_type = SX_TUNNEL_TYPE_NVE_NVGRE;
        break;

    default:
        SX_LOG_ERR("Invalid NVE Tunnel type :%u \n", sxd_nve_tunnel_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __nd_sll_or_tll_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                sx_acl_hw_key_e         hw_key,
                                                uint8_t                *hw_key_buff_p,
                                                boolean_t               last_hw_key)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sxd_flex_acl_nd_sll_or_tll_valid sxd_type = hw_key_buff_p[0];

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    /* NOTE: Since there are many user values mapped to one HW value,
     * We chose a random user value to represent a HW value.
     */
    switch (sxd_type) {
    case SXD_FLEX_ACL_NO_ND_SLL_OR_TTL:
        key_p->key.nd_sll_or_tll_valid = SX_ACL_NO_ND_SLL_OR_TTL;
        break;

    case SXD_FLEX_ACL_ND_SLL:
        key_p->key.nd_sll_or_tll_valid = SX_ACL_ND_SLL;
        break;

    case SXD_FLEX_ACL_ND_TLL:
        key_p->key.nd_sll_or_tll_valid = SX_ACL_ND_TLL;
        break;

    default:
        SX_LOG_ERR("ACL extract: Invalid nd_sll_or_tll HW type :%u \n", sxd_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __ipv6_extension_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                                 sx_acl_hw_key_e         hw_key,
                                                 uint8_t                *hw_key_buff_p,
                                                 boolean_t               last_hw_key)
{
    sx_flex_acl_extension_headrs_list_t *ipv6_extension_headers_p = NULL;
    sx_flex_acl_extension_headrs_list_t  ipv6_extension_headers_temp;
    uint32_t                             i = 0;

    UNUSED_PARAM(last_hw_key);

    SX_MEM_CLR(ipv6_extension_headers_temp);

    if (key_p->key_id == FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS) {
        ipv6_extension_headers_p = &key_p->key.ipv6_extension_headers;
    } else {
        ipv6_extension_headers_p = &key_p->key.inner_ipv6_extension_headers;
    }

    if (ipv6_extension_headers_p->extension_headers_cnt >= SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST) {
        SX_LOG_ERR("ACL extract: IPv6 extension count exceeded\n");
        return SX_STATUS_ERROR;
    }

    if ((hw_key == FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E) ||
        (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E)) {
        ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
            SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH;
        ipv6_extension_headers_temp.extension_headers_cnt++;
    }

    if ((hw_key == FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E) ||
        (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E)) {
        ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
            SX_FLEX_ACL_IPV6_EXTENSION_HEADER_SHIM6;
        ipv6_extension_headers_temp.extension_headers_cnt++;
    }

    if ((hw_key == FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E) ||
        (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E)) {
        ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
            SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HOST_IDENTIFY_PROTOCOL;
        ipv6_extension_headers_temp.extension_headers_cnt++;
    }

    if ((hw_key == FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E) ||
        (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E)) {
        ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
            SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH_ROUTER_ALERT;
        ipv6_extension_headers_temp.extension_headers_cnt++;
    }

    if ((hw_key == FLEX_ACL_HW_KEY_IPV6_EXTENSION_E) ||
        (hw_key == FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E)) {
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
        if (hw_key_buff_p[0] & (1 << SXD_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY)) {
            ipv6_extension_headers_temp.extension_headers_list[ipv6_extension_headers_temp.extension_headers_cnt] =
                SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY;
            ipv6_extension_headers_temp.extension_headers_cnt++;
        }
    }

    if (ipv6_extension_headers_p->extension_headers_cnt + ipv6_extension_headers_temp.extension_headers_cnt >
        SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST) {
        SX_LOG_ERR("ACL extract: IPv6 extension count exceeded\n");
        return SX_STATUS_ERROR;
    }

    for (i = 0; i < ipv6_extension_headers_temp.extension_headers_cnt; i++) {
        ipv6_extension_headers_p->extension_headers_list[ipv6_extension_headers_p->extension_headers_cnt++] =
            ipv6_extension_headers_temp.extension_headers_list[i];
    }

    return SX_STATUS_SUCCESS;
}


#define CONVERT_FLAG_EXTRACT(enum_value, field) \
case enum_value:                                \
    if (hw_key_buff_p[0] == 1) {                \
        key_p->key.field = TRUE;                \
    } else {                                    \
        key_p->key.field = FALSE;               \
    }                                           \
    break;

static sx_status_t __boolean_conv_extract(sx_flex_acl_key_desc_t *key_p,
                                          sx_acl_hw_key_e         hw_key,
                                          uint8_t                *hw_key_buff_p,
                                          boolean_t               last_hw_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(last_hw_key);

    switch (key_p->key_id) {
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_RW_PCP, rw_pcp)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_VLAN_TAGGED, vlan_tagged)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_VLAN_VALID, vlan_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_L2_VALID, l2_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_RW_DSCP, rw_dscp)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IP_FRAGMENTED, ip_fragmented)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IP_DONT_FRAGMENT, ip_dont_fragment)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST, ip_fragment_not_first)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IP_OK, ip_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IP_OK, inner_ip_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IP_OPT, inner_ip_opt)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_VLAN_VALID, inner_vlan_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_VLAN_TAG_VALID, vlan_tag_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_VLAN_TAG_VALID, inner_vlan_tag_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID, tunnel_vlan_tag_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID, tunnel_inner_vlan_tag_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_ARP, is_arp)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IP_OPT, ip_opt)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_IP_V4, is_ip_v4)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_TTL_OK, ttl_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_TTL_OK, inner_ttl_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_L4_OK, l4_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_L4_OK, inner_l4_ok)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DMAC_IS_UC, dmac_is_uc)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_TRAPPED, is_trapped)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS, ipv6_extension_header_exists)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_RW_EXP, rw_exp)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_MPLS, is_mpls)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IS_MPLS, inner_is_mpls)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_BOS, bos)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_ROUTED, is_routed)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_0_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_1_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_2_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_3_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_4_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_DWORD_5_VALID, dword_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID, mpls_control_word_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IS_IP_V4, inner_is_ip_v4)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_BOS, inner_bos)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IP_FRAGMENTED, inner_ip_fragmented)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT, inner_ip_dont_fragment)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST, inner_ip_fragment_not_first)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID, inner_mpls_control_word_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_IS_TCP_OPTION, inner_is_tcp_option)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_TCP_OPTION, is_tcp_option)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FDB_MISS, fdb_miss)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_LLC_VALID, llc_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_DMAC_VALID, inner_dmac_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_IS_BUM, is_bum_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_ALU_CARRY_FLAG, alu_carry_flag)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_0_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_1_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_2_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_3_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_4_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_5_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_6_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_7_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_8_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_GP_REGISTER_9_VALID, gp_register_extraction_valid)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_0_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_1_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_2_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_3_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_4_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_5_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_6_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_FPP_7_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_0_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_1_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_2_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_3_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_4_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_5_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_6_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_INNER_FPP_7_TOUCHED, fpp_touched)
        CONVERT_FLAG_EXTRACT(FLEX_ACL_KEY_PACKET_IS_ELEPHANT, packet_is_elephant)
    default:
        SX_LOG_ERR("ACL key :%s is not handled for extract.\n", flex_acl_db_key_id_to_str(key_p->key_id));
        rc = SX_STATUS_ERROR;
        break;
    }

    return rc;
}

static sx_status_t __key_extract_not_supported(sx_flex_acl_key_desc_t *key_p,
                                               sx_acl_hw_key_e         hw_key,
                                               uint8_t                *hw_key_buff_p,
                                               boolean_t               last_hw_key)
{
    UNUSED_PARAM(key_p);
    UNUSED_PARAM(hw_key);
    UNUSED_PARAM(hw_key_buff_p);
    UNUSED_PARAM(last_hw_key);

    SX_LOG_ERR("ACL key: %s is not handled for extract.\n", flex_acl_db_key_id_to_str(key_p->key_id));
    return SX_STATUS_UNSUPPORTED;
}

/***********************************************
*  General key functions
***********************************************/

sx_status_t flex_acl_keys_custom_bytes_set_lock_unlock(sx_acl_key_t key, sx_access_cmd_t cmd, boolean_t validate_only)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    uint32_t                  count;
    acl_custom_bytes_set_id_e custom_byte_set_id;

    if (!is_flex_acl_key_custom_byte_key(key)) {
        /* Not a custom bytes key. */
        goto out;
    }

    /* Custom byte key */
    rc = flex_acl_key_id_to_custom_byte_set(key, &custom_byte_set_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Invalid custom bytes key:%u \n", key);
        goto out;
    }

    if (validate_only) {
        rc = flex_acl_db_custom_bytes_set_ref_get(custom_byte_set_id, &count);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Invalid custom bytes key:%u \n", key);
            goto out;
        }
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = flex_acl_db_custom_bytes_set_ref_inc(custom_byte_set_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Invalid custom bytes key:%u \n", key);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        rc = flex_acl_db_custom_bytes_set_ref_dec(custom_byte_set_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Invalid custom bytes key:%u \n", key);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("custom byte handle inc, Invalid cmd :%u \n", cmd);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

/**
 *  This function is used to create/delete ACL key.
 *  Creation - Use command CREATE and provide list array of key fields.
 *  Delete - Use command DELETE and provide key handler.
 *
 * @params[in] params - struct with relevant parameters
 * @params[in] is_symmetric - indicate if to create a key that is symmetric i.e.
 *                            we can replace ip and l4 port with their other direction.
 *                            (SIP <-> DIP, SPORT <-> DPORT).
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is
 *  invalid
 * @return SX_STATUS_CMD_UNSUPPORTED if unsupported command is
 *  requested.
 */
sx_status_t flex_acl_key_ext_set(sx_api_flex_acl_key_set_params_t *params, boolean_t is_symmetric)
{
    sx_acl_key_block_e blocks[FLEX_ACL_MAX_KEY_BLOCKS];
    sx_acl_hw_key_e    hw_keys[FLEX_ACL_HW_KEY_LAST_E] = {0};
    uint32_t           blocks_count = 0, hw_keys_count;
    uint32_t           hw_key_handle = 0, i;
    sx_acl_key_t      *keys = NULL;
    uint8_t            keys_count;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    acl_stage_e        acl_stage;

    SX_LOG_ENTER();

    SX_MEM_CLR(blocks);

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for flex_acl_key_set.\n");
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        if ((params->keys_count < 1)
            || (params->keys_count > RM_API_ACL_MAX_FIELDS_IN_KEY)) {
            SX_LOG_ERR("Invalid number of key fields.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        /* Key id validation */
        for (i = 0; i < params->keys_count; i++) {
            rc = flex_acl_keys_custom_bytes_set_lock_unlock(params->keys[i], params->cmd, FLEX_ACL_CB_VALIDATE_ONLY);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed keys validation key:%u .\n", params->keys[i]);
                goto out;
            }
        }

        rc = flex_acl_get_hw_keys(acl_stage, params->keys, params->keys_count, hw_keys, &hw_keys_count);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed getting hw keys. Selected keys are not supported.\n");
            goto out;
        }

        if (flex_acl_scp_calc(acl_stage, hw_keys, hw_keys_count, blocks, &blocks_count,
                              is_symmetric, TRUE) != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed calculating key blocks - too many keys selected.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (flex_acl_hw_set_key_blocks(blocks, blocks_count, &hw_key_handle)
            != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed adding key to DB.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (flex_acl_db_add_flex_key_entry(params->keys, params->keys_count,
                                           hw_key_handle, &(params->key_handle)) != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed adding key to DB.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        /* Key ids ref count handling */
        for (i = 0; i < params->keys_count; i++) {
            rc = flex_acl_keys_custom_bytes_set_lock_unlock(params->keys[i], params->cmd, FLEX_ACL_CB_LOCK_UNLOCK);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed keys refcount key:%u .\n", params->keys[i]);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        if (flex_acl_db_region_key_use_validate(params->key_handle) != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("The key in use.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        rc = flex_acl_db_get_flex_key_entry(params->key_handle, &keys, &keys_count, &hw_key_handle);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting key %u.\n", params->key_handle);
            goto out;
        }

        /* Key ids ref count handling */
        for (i = 0; i < keys_count; i++) {
            rc = flex_acl_keys_custom_bytes_set_lock_unlock(keys[i], params->cmd, FLEX_ACL_CB_LOCK_UNLOCK);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed keys refcount key:%u .\n", params->keys[i]);
                goto out;
            }
        }

        if (flex_acl_hw_remove_flex_key_entry(params->key_handle)
            != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed deleting key from hw DB.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        if (flex_acl_db_remove_flex_key_entry(params->key_handle)
            != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed deleting key from DB.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

inline sx_status_t flex_acl_key_set(sx_api_flex_acl_key_set_params_t *params)
{
    return flex_acl_key_ext_set(params, FALSE);
}

sx_status_t flex_acl_symmetric_key_handle_create(sx_acl_key_type_t key_handle, sx_acl_key_type_t *new_key_handle_p)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    uint32_t            hw_key_handle = 0;
    sx_acl_key_t       *keys_p = NULL;
    uint8_t             keys_count = 0;
    sx_acl_key_t        new_keys[RM_API_ACL_MAX_FIELDS_IN_KEY] = {0};
    sx_acl_key_block_e *key_blocks_p = NULL;
    uint32_t            key_blocks_count = 0;
    sx_acl_key_block_e  new_key_blocks[FLEX_ACL_MAX_KEY_BLOCKS];
    uint32_t            i = 0;
    acl_stage_e         acl_stage;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(new_key_handle_p, "new_key_handle_p"))) {
        goto out;
    }

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve ACL stage\n");
        goto out;
    }

    /* Get the keys and key blocks from the original handle */
    rc = flex_acl_db_get_flex_key_entry(key_handle, &keys_p, &keys_count, &hw_key_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed to get flex key handle [0x%x] for symmetric key creation\n", key_handle);
        goto out;
    }
    rc = flex_acl_hw_get_key_blocks(hw_key_handle, &key_blocks_p, &key_blocks_count);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed to get hw key handle [0x%x] for symmetric key creation\n", hw_key_handle);
        goto out;
    }

    /* Replace the user keys and HW key blocks with their symmetric counterparts */
    for (i = 0; i < keys_count; i++) {
        /* Replace the IP & L4 port keys */
        switch (keys_p[i]) {
        case FLEX_ACL_KEY_DIP:
            new_keys[i] = FLEX_ACL_KEY_SIP;
            break;

        case FLEX_ACL_KEY_SIP:
            new_keys[i] = FLEX_ACL_KEY_DIP;
            break;

        case FLEX_ACL_KEY_DIPV6:
            new_keys[i] = FLEX_ACL_KEY_SIPV6;
            break;

        case FLEX_ACL_KEY_SIPV6:
            new_keys[i] = FLEX_ACL_KEY_DIPV6;
            break;

        case FLEX_ACL_KEY_INNER_DIP:
            new_keys[i] = FLEX_ACL_KEY_INNER_SIP;
            break;

        case FLEX_ACL_KEY_INNER_SIP:
            new_keys[i] = FLEX_ACL_KEY_INNER_DIP;
            break;

        case FLEX_ACL_KEY_INNER_DIPV6:
            new_keys[i] = FLEX_ACL_KEY_INNER_SIPV6;
            break;

        case FLEX_ACL_KEY_INNER_SIPV6:
            new_keys[i] = FLEX_ACL_KEY_INNER_DIPV6;
            break;

        case FLEX_ACL_KEY_L4_SOURCE_PORT:
            new_keys[i] = FLEX_ACL_KEY_L4_DESTINATION_PORT;
            break;

        case FLEX_ACL_KEY_L4_DESTINATION_PORT:
            new_keys[i] = FLEX_ACL_KEY_L4_SOURCE_PORT;
            break;

        default:
            new_keys[i] = keys_p[i];
            break;
        }
    }

    for (i = 0; i < key_blocks_count; i++) {
        switch (key_blocks_p[i]) {
        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_SYMM_E:
            if (ACL_STAGE_IS_FLEX4_OR_ABOVE(acl_stage)) {
                new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_SYMM_E;
            } else {
                new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_SYMM_E;
            }
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_SYMM_E:
        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_SYMM_E:
        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM_E:
            if (ACL_STAGE_IS_FLEX4_OR_ABOVE(acl_stage)) {
                new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_SYMM_E;
            } else {
                new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_SYMM_E;
            }
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_SYMM_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_SYMM_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_SWAP_E;
            break;

        case FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_SWAP_E:
            new_key_blocks[i] = FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_E;
            break;

        default:
            new_key_blocks[i] = key_blocks_p[i];
            break;
        }
    }


    /* Set the new key blocks */
    rc = flex_acl_hw_set_key_blocks(new_key_blocks, key_blocks_count, &hw_key_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed adding symmetric HW key to DB.\n");

        goto out;
    }

    /* Set the new keys */
    rc = flex_acl_db_add_flex_key_entry(new_keys, keys_count, hw_key_handle, new_key_handle_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed adding symmetric key to DB.\n");
        goto out;
    }

    /* Key ids ref count handling */
    for (i = 0; i < keys_count; i++) {
        rc = flex_acl_keys_custom_bytes_set_lock_unlock(new_keys[i], SX_ACCESS_CMD_CREATE, FLEX_ACL_CB_LOCK_UNLOCK);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed keys refcount key:%u .\n", new_keys[i]);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_get(sx_api_flex_acl_key_get_params_t *param)
{
    uint32_t      hw_key_handle = 0;
    sx_acl_key_t *keys = NULL;
    sx_status_t   rc = SX_STATUS_SUCCESS;
    uint32_t      i = 0;


    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_get_flex_key_entry(param->key_handle, &keys, &(param->keys_count), &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get flex key entry\n");
        goto out;
    }

    for (i = 0; i < param->keys_count; i++) {
        param->keys[i] = keys[i];
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_attribs_get(sx_api_acl_flex_key_attr_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_key_sizes_get(params->key_handle, NULL, &params->key_attr.key_width);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex key sizes for handle [0x%x]\n", params->key_handle);
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_sizes_get(sx_acl_key_type_t        key_handle,
                                   uint32_t                *blocks_count_p,
                                   sx_acl_flex_key_width_t *key_width_p)
{
    uint32_t                hw_key_handle = 0;
    sx_acl_key_block_e      blocks[FLEX_ACL_MAX_KEY_BLOCKS];
    uint32_t                blocks_count = 0;
    uint8_t                 keys_count = 0;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_acl_key_t           *keys = NULL;
    sx_acl_flex_key_width_t key_width = SX_ACL_FLEX_KEY_WIDTH_NONE_E;
    acl_stage_e             acl_stage;

    SX_LOG_ENTER();

    SX_MEM_CLR(blocks);

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_get_acl_stage_from_key_handle(key_handle, &acl_stage);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex key entry[0x%x]\n", key_handle);
        goto out;
    }

    rc = flex_acl_db_get_flex_key_entry(key_handle, &keys, &keys_count, &hw_key_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex key entry [0x%x]\n", key_handle);
        goto out;
    }

    rc = flex_acl_hw_get_key_blocks(hw_key_handle, (sx_acl_key_block_e**)&blocks, &blocks_count);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get hw attributes of flex key entry [0x%x]\n", key_handle);
        goto out;
    }

    if ((blocks_count > 0) && (blocks_count <= FLEX_ACL_MAX_KEY_BLOCKS)) {
        key_width = flex_key_widths[acl_stage][blocks_count];
    } else {
        SX_LOG_ERR("Illegal block count %d for key handle [0x%x]\n", blocks_count, key_handle);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (blocks_count_p != NULL) {
        *blocks_count_p = blocks_count;
    }
    if (key_width_p != NULL) {
        *key_width_p = key_width;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __flex_acl_is_key_valid_for_bind(acl_stage_e              acl_stage,
                                                  sx_acl_key_t             key,
                                                  flex_acl_db_acl_table_t *acl_table)
{
    boolean_t is_valid = TRUE;
    uint32_t  i;
    uint32_t  invalid_acl_dir_bitmap = 0;

    if (acl_table->direction != SX_ACL_DIRECTION_MULTI_POINTS_E) {
        for (i = 0; i < flex_acl_key_map[acl_stage][key].hw_keys_cnt && is_valid; i++) {
            if ((flex_acl_keys_data[flex_acl_key_map[acl_stage][key].hw_keys[i]].flags &
                 (1 << acl_table->direction)) == 0) {
                is_valid = FALSE;
            }
        }
    } else {
        for (i = 0; i < flex_acl_key_map[acl_stage][key].hw_keys_cnt && is_valid; i++) {
            invalid_acl_dir_bitmap = ~(flex_acl_keys_data[flex_acl_key_map[acl_stage][key].hw_keys[i]].flags);
            if ((invalid_acl_dir_bitmap & acl_table->acl_attributes.multi_direction.acl_direction_bitmap) !=
                0) {
                is_valid = FALSE;
            }
        }
    }

    return is_valid;
}

/* This is a utility function to determine if two keys can be combined in one rule */
static boolean_t __flex_acl_keys_combination_valid(const sx_acl_key_t key_id1, const sx_acl_key_t key_id2)
{
    boolean_t    is_valid = TRUE;
    sx_acl_key_t other_key = FLEX_ACL_KEY_INVALID;

    switch (key_id1) {
    case FLEX_ACL_KEY_GRE_KEY:
        other_key = FLEX_ACL_KEY_VNI_KEY;
        break;

    case FLEX_ACL_KEY_VNI_KEY:
        other_key = FLEX_ACL_KEY_GRE_KEY;
        break;

    case FLEX_ACL_KEY_DIPV6:
        other_key = FLEX_ACL_KEY_DIP;
        break;

    case FLEX_ACL_KEY_DIP:
        other_key = FLEX_ACL_KEY_DIPV6;
        break;

    case FLEX_ACL_KEY_SIPV6:
        other_key = FLEX_ACL_KEY_SIP;
        break;

    case FLEX_ACL_KEY_SIP:
        other_key = FLEX_ACL_KEY_SIPV6;
        break;

    case FLEX_ACL_KEY_INNER_DIPV6:
        other_key = FLEX_ACL_KEY_INNER_DIP;
        break;

    case FLEX_ACL_KEY_INNER_DIP:
        other_key = FLEX_ACL_KEY_INNER_DIPV6;
        break;

    case FLEX_ACL_KEY_INNER_SIPV6:
        other_key = FLEX_ACL_KEY_INNER_SIP;
        break;

    case FLEX_ACL_KEY_INNER_SIP:
        other_key = FLEX_ACL_KEY_INNER_SIPV6;
        break;

    default:
        break;
    }
    is_valid = (key_id2 == other_key) ? FALSE : TRUE;


    return is_valid;
}

static boolean_t __keys_combinations_valid(sx_flex_acl_key_desc_t *key_p,
                                           sx_flex_acl_key_desc_t *key_desc_list_p,
                                           uint32_t                key_desc_count)
{
    boolean_t is_valid = TRUE;
    uint32_t  i = 0;

    for (i = 0; i < key_desc_count; i++) {
        if (__flex_acl_keys_combination_valid(key_desc_list_p[i].key_id, key_p->key_id) != TRUE) {
            SX_LOG_ERR("Key id %u (%s) and Key id %u (%s) can not coexists in the same rule\n",
                       key_desc_list_p[i].key_id, flex_acl_db_key_id_to_str(key_desc_list_p[i].key_id),
                       key_p->key_id, flex_acl_db_key_id_to_str(key_p->key_id));
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

sx_status_t flex_acl_keys_validate(sx_flex_acl_key_desc_t   *key_desc_list_p,
                                   uint32_t                  key_desc_count,
                                   flex_acl_db_acl_region_t *acl_region,
                                   flex_acl_key_build_mode_e build_mode,
                                   boolean_t                 is_flex)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint8_t                  keys_count;
    uint32_t                 hw_key_handle = 0;
    sx_acl_key_t            *keys = NULL;
    flex_acl_db_acl_table_t *acl_table = NULL;
    uint32_t                 j, k;
    acl_stage_e              acl_stage;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_stage_from_key_handle(acl_region->key_handle, &acl_stage);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed get acl_stage from DB for key_handle: %u\n", acl_region->key_handle);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if ((rc = flex_acl_db_get_flex_key_entry(acl_region->key_handle, &keys, &keys_count, &hw_key_handle))
        != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Key handler at region is invalid \n");
        goto out;
    }

    if (is_flex) {
        rc = flex_acl_db_acl_get(acl_region->bound_acl, &acl_table);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed get db acl.\n");
            goto out;
        }
    }

    /* rules key fields validation */
    for (j = 0; j < key_desc_count; j++) {
        for (k = 0; k < keys_count && keys[k] != key_desc_list_p[j].key_id; k++) {
        }
        if (k == keys_count) {
            SX_LOG_ERR("ACL : Key id %u (%s) is not part of the region %#x key handle %d.\n",
                       key_desc_list_p[j].key_id,
                       flex_acl_db_key_id_to_str(key_desc_list_p[j].key_id),
                       acl_region->region_id, acl_region->key_handle
                       );
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        /* Bind key validation */
        if (is_flex && (acl_table->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E) &&
            (__flex_acl_is_key_valid_for_bind(acl_stage, key_desc_list_p[j].key_id, acl_table) == FALSE)) {
            SX_LOG_ERR("ACL : Key id %u (%s) is not valid for binding type :%s (0x%x).\n",
                       key_desc_list_p[j].key_id,
                       flex_acl_db_key_id_to_str(key_desc_list_p[j].key_id),
                       sx_acl_direction_str(acl_table->direction),
                       acl_table->acl_attributes.multi_direction.acl_direction_bitmap);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Key value validation. */
        if (keys_validation[key_desc_list_p[j].key_id] &&
            (keys_validation[key_desc_list_p[j].key_id](&key_desc_list_p[j],
                                                        acl_region->region_id,
                                                        build_mode) == FALSE)) {
            SX_LOG_ERR("ACL : Key id %u (%s) value id is not valid.\n",
                       key_desc_list_p[j].key_id,
                       flex_acl_db_key_id_to_str(key_desc_list_p[j].key_id));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (__keys_combinations_valid(&key_desc_list_p[j],
                                      key_desc_list_p,
                                      key_desc_count) == FALSE) {
            SX_LOG_ERR("Keys combination is not valid region id :%u.\n", acl_region->region_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

#define COMPARE_KEY(key_name, key_field)                                                                 \
case key_name:                                                                                           \
    if (memcmp(&(rule1_p->key_desc_list[i].key.key_field), &(rule2_p->key_desc_list[i].key.key_field),   \
               sizeof(rule1_p->key_desc_list[i].key.key_field)) ||                                       \
        memcmp(&(rule1_p->key_desc_list[i].mask.key_field), &(rule2_p->key_desc_list[i].mask.key_field), \
               sizeof(rule1_p->key_desc_list[i].mask.key_field))) {                                      \
        *is_key_changed_p = TRUE;                                                                        \
    }                                                                                                    \
    break;                                                                                               \

sx_status_t flex_acl_compare_keys(flex_acl_db_flex_rule_t *rule1_p,
                                  flex_acl_db_flex_rule_t *rule2_p,
                                  boolean_t               *is_key_changed_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i;

    *is_key_changed_p = FALSE;
    if (rule1_p->key_desc_count != rule2_p->key_desc_count) {
        *is_key_changed_p = TRUE;
        goto out;
    }
    for (i = 0; i < rule1_p->key_desc_count && *is_key_changed_p == FALSE; i++) {
        if (rule1_p->key_desc_list[i].key_id != rule2_p->key_desc_list[i].key_id) {
            *is_key_changed_p = TRUE;
            break;
        }
        /* handling custom bytes */
        if (is_flex_acl_key_custom_byte_key(rule1_p->key_desc_list[i].key_id)) {
            if (memcmp(&(rule1_p->key_desc_list[i].key.custom_byte), &(rule2_p->key_desc_list[i].key.custom_byte),
                       sizeof(rule1_p->key_desc_list[i].key.custom_byte)) ||
                memcmp(&(rule1_p->key_desc_list[i].mask.custom_byte), &(rule2_p->key_desc_list[i].mask.custom_byte),
                       sizeof(rule1_p->key_desc_list[i].mask.custom_byte))) {
                *is_key_changed_p = TRUE;
            }
            continue;
        }

        /* handling system keys */
        if (((int)rule1_p->key_desc_list[i].key_id >= (int)FLEX_ACL_KEY_SYSTEM_START) &&
            ((int)rule1_p->key_desc_list[i].key_id <= (int)FLEX_ACL_KEY_SYSTEM_LAST)) {
            switch ((flex_acl_system_key_e)rule1_p->key_desc_list[i].key_id) {
                COMPARE_KEY(FLEX_ACL_SYSTEM_KEY_DIPV6_LSB, dipv6_lsb)
                COMPARE_KEY(FLEX_ACL_SYSTEM_KEY_DIPV6_MSB, dipv6_msb)
                /* No Default clause is specified intentionally. When new key is not added to the switch
                 *  build fails */
            }
            continue;
        }
        switch (rule1_p->key_desc_list[i].key_id) {
            COMPARE_KEY(FLEX_ACL_KEY_DMAC, dmac)
            COMPARE_KEY(FLEX_ACL_KEY_SMAC, smac)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERTYPE, ethertype)
            COMPARE_KEY(FLEX_ACL_KEY_DEI, dei)
            COMPARE_KEY(FLEX_ACL_KEY_PCP, pcp)
            COMPARE_KEY(FLEX_ACL_KEY_VLAN_ID, vlan_id)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_VLAN_ID, inner_vlan_id)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DMAC, inner_dmac)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_SMAC, inner_smac)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DEI, inner_dei)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_PCP, inner_pcp)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_DEI, tunnel_dei)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_PCP, tunnel_pcp)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_INNER_DEI, tunnel_inner_dei)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_INNER_PCP, tunnel_inner_pcp)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_ETHERTYPE, inner_ethertype)
            COMPARE_KEY(FLEX_ACL_KEY_L2_VALID, l2_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DIP, dip)
            COMPARE_KEY(FLEX_ACL_KEY_SIP, sip)
            COMPARE_KEY(FLEX_ACL_KEY_DSCP, dscp)
            COMPARE_KEY(FLEX_ACL_KEY_ECN, ecn)
            COMPARE_KEY(FLEX_ACL_KEY_IP_PACKET_LENGTH, ip_packet_length)
            COMPARE_KEY(FLEX_ACL_KEY_IP_PROTO, ip_proto)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_PROTO, inner_ip_proto)
            COMPARE_KEY(FLEX_ACL_KEY_TTL, ttl)
            COMPARE_KEY(FLEX_ACL_KEY_DIPV6, dipv6)
            COMPARE_KEY(FLEX_ACL_KEY_SIPV6, sipv6)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_SIP, inner_sip)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DIP, inner_dip)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_SIPV6, inner_sipv6)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DIPV6, inner_dipv6)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DSCP, inner_dscp)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_ECN, inner_ecn)
            COMPARE_KEY(FLEX_ACL_KEY_L4_DESTINATION_PORT, l4_destination_port)
            COMPARE_KEY(FLEX_ACL_KEY_L4_SOURCE_PORT, l4_source_port)
            COMPARE_KEY(FLEX_ACL_KEY_TCP_CONTROL, tcp_control)
            COMPARE_KEY(FLEX_ACL_KEY_TCP_ECN, tcp_ecn)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT, inner_l4_destination_port)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_L4_SOURCE_PORT, inner_l4_source_port)
            COMPARE_KEY(FLEX_ACL_KEY_GRE_KEY, gre_key)
            COMPARE_KEY(FLEX_ACL_KEY_VNI_KEY, vni_key)
            COMPARE_KEY(FLEX_ACL_KEY_GRE_PROTOCOL, gre_protocol)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_VLAN_ID, tunnel_vlan_id)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID, tunnel_inner_vlan_id)
            COMPARE_KEY(FLEX_ACL_KEY_RW_PCP, rw_pcp)
            COMPARE_KEY(FLEX_ACL_KEY_L2_DMAC_TYPE, l2_dmac_type)
            COMPARE_KEY(FLEX_ACL_KEY_DMAC_IS_UC, dmac_is_uc)
            COMPARE_KEY(FLEX_ACL_KEY_VLAN_TAGGED, vlan_tagged)
            COMPARE_KEY(FLEX_ACL_KEY_VLAN_VALID, vlan_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DST_PORT, dst_port)
            COMPARE_KEY(FLEX_ACL_KEY_SRC_PORT, src_port)
            COMPARE_KEY(FLEX_ACL_KEY_SRC_PHY_PORT, src_phy_port)
            COMPARE_KEY(FLEX_ACL_KEY_RW_DSCP, rw_dscp)
            COMPARE_KEY(FLEX_ACL_KEY_IP_FRAGMENTED, ip_fragmented)
            COMPARE_KEY(FLEX_ACL_KEY_IP_DONT_FRAGMENT, ip_dont_fragment)
            COMPARE_KEY(FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST, ip_fragment_not_first)
            COMPARE_KEY(FLEX_ACL_KEY_IP_OK, ip_ok)
            COMPARE_KEY(FLEX_ACL_KEY_IS_ARP, is_arp)
            COMPARE_KEY(FLEX_ACL_KEY_URPF_FAIL, urpf_fail)
            COMPARE_KEY(FLEX_ACL_KEY_IP_OPT, ip_opt)
            COMPARE_KEY(FLEX_ACL_KEY_IS_IP_V4, is_ip_v4)
            COMPARE_KEY(FLEX_ACL_KEY_L3_TYPE, l3_type)
            COMPARE_KEY(FLEX_ACL_KEY_TTL_OK, ttl_ok)
            COMPARE_KEY(FLEX_ACL_KEY_L4_OK, l4_ok)
            COMPARE_KEY(FLEX_ACL_KEY_L4_TYPE, l4_type)
            COMPARE_KEY(FLEX_ACL_KEY_SWITCH_PRIO, switch_prio)
            COMPARE_KEY(FLEX_ACL_KEY_COLOR, color)
            COMPARE_KEY(FLEX_ACL_KEY_BUFF, buff)
            COMPARE_KEY(FLEX_ACL_KEY_L4_PORT_RANGE, l4_port_range)
            COMPARE_KEY(FLEX_ACL_KEY_DISCARD_STATE, discard_state)
            COMPARE_KEY(FLEX_ACL_KEY_IS_TRAPPED, is_trapped)
            COMPARE_KEY(FLEX_ACL_KEY_RX_LIST, rx_list)
            COMPARE_KEY(FLEX_ACL_KEY_IRIF, irif)
            COMPARE_KEY(FLEX_ACL_KEY_ERIF, erif)
            COMPARE_KEY(FLEX_ACL_KEY_VIRTUAL_ROUTER, virtual_router)
            COMPARE_KEY(FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS, ipv6_extension_headers)
            COMPARE_KEY(FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS, ipv6_extension_header_exists)
            COMPARE_KEY(FLEX_ACL_KEY_USER_TOKEN, user_token)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_VLAN_VALID, inner_vlan_valid)
            COMPARE_KEY(FLEX_ACL_KEY_VLAN_TAG_VALID, vlan_tag_valid)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_VLAN_TAG_VALID, inner_vlan_tag_valid)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID, tunnel_vlan_tag_valid)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID, tunnel_inner_vlan_tag_valid)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_OK, inner_ip_ok)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_OPT, inner_ip_opt)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_L3_TYPE, inner_l3_type)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_L4_OK, inner_l4_ok)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_TTL, inner_ttl)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_TTL_OK, inner_ttl_ok)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_TYPE, tunnel_type)
            COMPARE_KEY(FLEX_ACL_KEY_GRE_KEY_EXISTS, gre_key_exists)
            COMPARE_KEY(FLEX_ACL_KEY_TUNNEL_NVE_TYPE, tunnel_nve_type)
            COMPARE_KEY(FLEX_ACL_KEY_L4_TYPE_EXTENDED, l4_type_extended)
            COMPARE_KEY(FLEX_ACL_KEY_IS_MPLS, is_mpls)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IS_MPLS, inner_is_mpls)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_1, mpls_label_id_1)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_2, mpls_label_id_2)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_3, mpls_label_id_3)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_4, mpls_label_id_4)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_5, mpls_label_id_5)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABEL_ID_6, mpls_label_id_6)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_LABELS_VALID, mpls_labels_valid)
            COMPARE_KEY(FLEX_ACL_KEY_EXP, exp)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_EXP, inner_exp)
            COMPARE_KEY(FLEX_ACL_KEY_BOS, bos)
            COMPARE_KEY(FLEX_ACL_KEY_RW_EXP, rw_exp)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_TTL, mpls_ttl)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_ECN, mpls_ecn)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_ECN, inner_mpls_ecn)
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST, rx_port_list)
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST, tx_port_list)
            COMPARE_KEY(FLEX_ACL_KEY_IS_ROUTED, is_routed)
            COMPARE_KEY(FLEX_ACL_KEY_ROCE_DEST_QP, dest_qp)
            COMPARE_KEY(FLEX_ACL_KEY_ROCE_PKEY, pkey)
            COMPARE_KEY(FLEX_ACL_KEY_ROCE_BTH_OPCODE, bth_opcode)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5, ethernet_payload_dword)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_0_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_1_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_2_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_3_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_4_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_DWORD_5_VALID, dword_valid)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID, mpls_control_word_valid)
            COMPARE_KEY(FLEX_ACL_KEY_MPLS_CONTROL_WORD, mpls_control_word)
            COMPARE_KEY(FLEX_ACL_KEY_FID, fid)
            COMPARE_KEY(FLEX_ACL_KEY_MC_TYPE, mc_type_vector)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IS_IP_V4, inner_is_ip_v4)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH, inner_ip_packet_length)
            COMPARE_KEY(FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID, nd_sll_or_tll_valid)
            COMPARE_KEY(FLEX_ACL_KEY_IP_MORE_FRAGMENTS, ip_more_fragments)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT, inner_ip_dont_fragment)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS, inner_ip_more_fragments)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_FRAGMENTED, inner_ip_fragmented)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST, inner_ip_fragment_not_first)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS, inner_ipv6_extension_headers)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS, inner_ipv6_extension_headers_exists)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_BOS, inner_bos)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_TTL, inner_mpls_ttl)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID, inner_mpls_labels_valid)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1, inner_mpls_label_id_1)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2, inner_mpls_label_id_2)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3, inner_mpls_label_id_3)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID, inner_mpls_control_word_valid)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD, inner_mpls_control_word)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED, inner_l4_type_extended)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_TCP_CONTROL, inner_tcp_control)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_TCP_ECN, inner_tcp_ecn)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IS_TCP_OPTION, inner_is_tcp_option)
            COMPARE_KEY(FLEX_ACL_KEY_IS_TCP_OPTION, is_tcp_option)
            COMPARE_KEY(FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB, free_running_clock_msb)
            COMPARE_KEY(FLEX_ACL_KEY_TRAP_ID, trap_id)
            COMPARE_KEY(FLEX_ACL_KEY_FDB_MISS, fdb_miss)
            COMPARE_KEY(FLEX_ACL_KEY_LLC_VALID, llc_valid)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_DMAC_VALID, inner_dmac_valid)
            COMPARE_KEY(FLEX_ACL_KEY_LAG_HASH, lag_hash)
            COMPARE_KEY(FLEX_ACL_KEY_ECMP_HASH, ecmp_hash)
            COMPARE_KEY(FLEX_ACL_KEY_BUM_BRIDGE_ID, bum_bridge_id)
            COMPARE_KEY(FLEX_ACL_KEY_IS_BUM, is_bum_valid)
            COMPARE_KEY(FLEX_ACL_KEY_ALU_CARRY_FLAG, alu_carry_flag)
            COMPARE_KEY(FLEX_ACL_KEY_PORT_USER_MEMORY, port_user_memory)
            COMPARE_KEY(FLEX_ACL_KEY_PACKET_IS_ELEPHANT, packet_is_elephant)
            COMPARE_KEY(FLEX_ACL_KEY_AR_PACKET_CLASS, ar_packet_class)
            COMPARE_KEY(FLEX_ACL_KEY_IS_ARN, is_arn)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_0, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_1, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_2, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_3, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_4, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_5, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_6, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_7, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_8, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_9, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_10, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_11, gp_register)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_0_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_1_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_2_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_3_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_4_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_5_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_6_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_7_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_8_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_9_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_10_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_11_VALID, gp_register_extraction_valid)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_0_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_1_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_2_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_3_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_4_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_5_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_6_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_FPP_7_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_0_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_1_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_2_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_3_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_4_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_5_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_6_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_INNER_FPP_7_TOUCHED, fpp_touched)
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_0_OFFSET, gp_register_offset);
            COMPARE_KEY(FLEX_ACL_KEY_GP_REGISTER_1_OFFSET, gp_register_offset);
            COMPARE_KEY(FLEX_ACL_KEY_RX_TUNNEL_LIST, rx_tunnel_list);
            COMPARE_KEY(FLEX_ACL_KEY_MAC_COMPARE, mac_compare);
            COMPARE_KEY(FLEX_ACL_KEY_IP_COMPARE, ip_compare);
            COMPARE_KEY(FLEX_ACL_KEY_L4_PORT_COMPARE, l4_port_compare);
            COMPARE_KEY(FLEX_ACL_KEY_DEFAULT_ROUTE_HIT, default_route_hit);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_1_128, rx_port_list_1_128);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_129_258, rx_port_list_129_258);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_0, rx_port_list_0);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_1, rx_port_list_1);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_2, rx_port_list_2);
            COMPARE_KEY(FLEX_ACL_KEY_RX_PORT_LIST_3, rx_port_list_3);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_1_128, tx_port_list_1_128);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_129_258, tx_port_list_129_258);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_0, tx_port_list_0);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_1, tx_port_list_1);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_2, tx_port_list_2);
            COMPARE_KEY(FLEX_ACL_KEY_TX_PORT_LIST_3, tx_port_list_3);
            COMPARE_KEY(FLEX_ACL_KEY_IPSEC_SPI, ipsec_spi);
            COMPARE_KEY(FLEX_ACL_KEY_INNER_IPSEC_SPI, inner_ipsec_spi);


            /* MACSEC ACL keys */
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_DMAC, macsec_dmac);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_ETHERTYPE, macsec_ethertype);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_VLAN_ID, macsec_vlan_id);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_VNI_ID, macsec_vni_key);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID_VALID, macsec_flow_secy_id_valid);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID, macsec_flow_secy_id);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_SCI_VALID, macsec_sci_valid);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_SCI, macsec_sci);
            COMPARE_KEY(FLEX_ACL_KEY_MACSEC_AN, macsec_an);

        case FLEX_ACL_KEY_INVALID:
        case FLEX_ACL_KEY_CUSTOM_BYTE_0:
        case FLEX_ACL_KEY_CUSTOM_BYTE_1:
        case FLEX_ACL_KEY_CUSTOM_BYTE_2:
        case FLEX_ACL_KEY_CUSTOM_BYTE_3:
        case FLEX_ACL_KEY_CUSTOM_BYTE_4:
        case FLEX_ACL_KEY_CUSTOM_BYTE_5:
        case FLEX_ACL_KEY_CUSTOM_BYTE_6:
        case FLEX_ACL_KEY_CUSTOM_BYTE_7:
        case FLEX_ACL_KEY_CUSTOM_BYTE_8:
        case FLEX_ACL_KEY_CUSTOM_BYTE_9:
        case FLEX_ACL_KEY_CUSTOM_BYTE_10:
        case FLEX_ACL_KEY_CUSTOM_BYTE_11:
        case FLEX_ACL_KEY_CUSTOM_BYTE_12:
        case FLEX_ACL_KEY_CUSTOM_BYTE_13:
        case FLEX_ACL_KEY_CUSTOM_BYTE_14:
        case FLEX_ACL_KEY_CUSTOM_BYTE_15:
        case FLEX_ACL_KEY_CUSTOM_BYTE_16:
        case FLEX_ACL_KEY_CUSTOM_BYTE_17:
        case FLEX_ACL_KEY_CUSTOM_BYTE_18:
        case FLEX_ACL_KEY_CUSTOM_BYTE_19:
        case FLEX_ACL_KEY_CUSTOM_BYTE_20:
        case FLEX_ACL_KEY_CUSTOM_BYTE_21:
        case FLEX_ACL_KEY_CUSTOM_BYTE_22:
        case FLEX_ACL_KEY_CUSTOM_BYTE_23:
        case FLEX_ACL_KEY_LAST:
            SX_LOG_ERR("Invalid key id :%d \n", rule1_p->key_desc_list[i].key_id);
            rc = SX_STATUS_ERROR;
            goto out;
            /* No Default clause is specified intentionally.When new key is not added to the switch
             *  build fails */
        }
    }

out:
    return rc;
}

/* This is a utility function to get the directions a key can be bound to */
sx_status_t flex_acl_key_directions_get(const sx_acl_key_t key_id, sx_acl_multi_direction_t *directions_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    uint8_t     flags = 0;
    boolean_t   is_first = TRUE;
    acl_stage_e acl_stage = ACL_STAGE_UNKNOWN;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(directions_p, "directions_p"))) {
        goto out;
    }

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for flex_acl_key_directions_get.\n");
        goto out;
    }

    /* Get the directions that are supported by all the hw keys */
    for (i = 0; i < flex_acl_key_map[acl_stage][key_id].hw_keys_cnt; i++) {
        if (is_first) {
            flags = flex_acl_keys_data[flex_acl_key_map[acl_stage][key_id].hw_keys[i]].flags;
            is_first = FALSE;
        } else {
            flags &= flex_acl_keys_data[flex_acl_key_map[acl_stage][key_id].hw_keys[i]].flags;
        }
    }

    directions_p->acl_direction_bitmap = flags;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_create_basic_key(acl_stage_e        acl_stage,
                                      sx_acl_key_t       keys[],
                                      uint32_t           keys_count,
                                      sx_acl_key_type_t *key_type)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_key_block_e blocks[FLEX_ACL_MAX_KEY_BLOCKS];
    uint32_t           blocks_count = 0, hw_keys_count;
    sx_acl_hw_key_e    hw_keys[FLEX_ACL_HW_KEY_LAST_E];
    uint32_t           hw_key_handle = 0;

    SX_LOG_ENTER();
    memset(blocks, 0, sizeof(blocks));
    memset(hw_keys, 0, sizeof(hw_keys));

    rc = flex_acl_get_hw_keys(acl_stage, keys, keys_count, hw_keys, &hw_keys_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed getting hw keys. Selected keys are not supported.\n");
        goto out;
    }

    rc = flex_acl_scp_calc(acl_stage, hw_keys, hw_keys_count, blocks, &blocks_count, FALSE, TRUE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed calculating key blocks.\n");
        goto out;
    }

    rc = flex_acl_hw_set_key_blocks(blocks, blocks_count, &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed adding key to DB.\n");
        goto out;
    }

    rc = flex_acl_db_flex_key_entry_init_predefined(keys, keys_count, hw_key_handle, key_type);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Fail in %s in creating predefined key. \n", __FUNCTION__);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_remove_basic_key(sx_acl_key_type_t key_handle)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_hw_remove_flex_key_entry(key_handle);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deleting key from hw DB, key_handle: %u\n", key_handle);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_remove_flex_key_entry(key_handle);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deleting key from DB, key_handle: %u\n", key_handle);
        rc = SX_STATUS_ERROR;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_generate(sx_acl_region_id_t        region_id,
                                  sx_flex_acl_key_desc_t   *keys_p,
                                  uint32_t                  keys_cnt,
                                  flex_acl_key_build_mode_e build_mode,
                                  uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                  uint8_t                   flex_mask_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES])
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(keys_p, "keys_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(flex_value_blocks, "flex_value_blocks"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(flex_mask_blocks, "flex_mask_blocks"))) {
        goto out;
    }


    if (build_mode >= FLEX_ACL_KEY_BUILD_LAST_E) {
        SX_LOG_ERR("ACL : Invalid build mode [%u] for key generation \n", build_mode);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR_ARRAY(flex_value_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES, uint8_t);
    SX_MEM_CLR_ARRAY(flex_mask_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES, uint8_t);

    if (keys_cnt == 0) {
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to find ACL region for key generation: %u\n", region_id);
        goto out;
    }

    rc = flex_acl_keys_validate(keys_p, keys_cnt, acl_region_p, build_mode, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to validate keys for region [%u] key generation\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_key_generate(acl_region_p, keys_p, keys_cnt, build_mode, flex_value_blocks, flex_mask_blocks);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed HW key generation for region [%u]\n", region_id);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_extract(sx_acl_region_id_t      region_id,
                                 uint8_t                 flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                 sx_flex_acl_key_desc_t *keys_p,
                                 uint32_t               *keys_cnt_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(keys_p, "keys_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(keys_cnt_p, "keys_cnt_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(flex_value_blocks, "flex_value_blocks"))) {
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to find ACL region for key extraction: %u\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_key_extract(acl_region_p, flex_value_blocks, keys_p, keys_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed key extraction for region: %u\n", region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_port_list_get_info(const sx_flex_acl_key_desc_t *key_p,
                                            sx_mc_container_id_t         *mc_container_id_p,
                                            sx_acl_port_list_match_t     *match_type_p,
                                            boolean_t                    *mask_boolean_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_mc_container_id_t     mc_container_id = 0;
    sx_acl_port_list_match_t match_type = SX_ACL_PORT_LIST_MATCH_POSITIVE;
    boolean_t                mask_boolean = FALSE;

    switch (key_p->key_id) {
    case FLEX_ACL_KEY_RX_PORT_LIST:
        mask_boolean = key_p->mask.rx_port_list;
        mc_container_id = key_p->key.rx_port_list.mc_container_id;
        match_type = key_p->key.rx_port_list.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST:
        mask_boolean = key_p->mask.tx_port_list;
        mc_container_id = key_p->key.tx_port_list.mc_container_id;
        match_type = key_p->key.tx_port_list.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_1_128:
        mask_boolean = key_p->mask.rx_port_list_1_128;
        mc_container_id = key_p->key.rx_port_list_1_128.mc_container_id;
        match_type = key_p->key.rx_port_list_1_128.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_129_258:
        mask_boolean = key_p->mask.rx_port_list_129_258;
        mc_container_id = key_p->key.rx_port_list_129_258.mc_container_id;
        match_type = key_p->key.rx_port_list_129_258.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_0:
        mask_boolean = key_p->mask.rx_port_list_0;
        mc_container_id = key_p->key.rx_port_list_0.mc_container_id;
        match_type = key_p->key.rx_port_list_0.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_1:
        mask_boolean = key_p->mask.rx_port_list_1;
        mc_container_id = key_p->key.rx_port_list_1.mc_container_id;
        match_type = key_p->key.rx_port_list_1.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_2:
        mask_boolean = key_p->mask.rx_port_list_2;
        mc_container_id = key_p->key.rx_port_list_2.mc_container_id;
        match_type = key_p->key.rx_port_list_2.match_type;
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST_3:
        mask_boolean = key_p->mask.rx_port_list_3;
        mc_container_id = key_p->key.rx_port_list_3.mc_container_id;
        match_type = key_p->key.rx_port_list_3.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_1_128:
        mask_boolean = key_p->mask.tx_port_list_1_128;
        mc_container_id = key_p->key.tx_port_list_1_128.mc_container_id;
        match_type = key_p->key.tx_port_list_1_128.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_129_258:
        mask_boolean = key_p->mask.tx_port_list_129_258;
        mc_container_id = key_p->key.tx_port_list_129_258.mc_container_id;
        match_type = key_p->key.tx_port_list_129_258.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_0:
        mask_boolean = key_p->mask.tx_port_list_0;
        mc_container_id = key_p->key.tx_port_list_0.mc_container_id;
        match_type = key_p->key.tx_port_list_0.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_1:
        mask_boolean = key_p->mask.tx_port_list_1;
        mc_container_id = key_p->key.tx_port_list_1.mc_container_id;
        match_type = key_p->key.tx_port_list_1.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_2:
        mask_boolean = key_p->mask.tx_port_list_2;
        mc_container_id = key_p->key.tx_port_list_2.mc_container_id;
        match_type = key_p->key.tx_port_list_2.match_type;
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST_3:
        mask_boolean = key_p->mask.tx_port_list_3;
        mc_container_id = key_p->key.tx_port_list_3.mc_container_id;
        match_type = key_p->key.tx_port_list_3.match_type;
        break;

    default:
        SX_LOG_ERR("ACL : Invalid key type [%u] for port list conversion.\n", key_p->key_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (mc_container_id_p != NULL) {
        *mc_container_id_p = mc_container_id;
    }
    if (match_type_p != NULL) {
        *match_type_p = match_type;
    }
    if (mask_boolean_p != NULL) {
        *mask_boolean_p = mask_boolean;
    }

out:
    return rc;
}

/* This is a utility function to retrieve the amount of KVD resource taken by a specific key */
sx_status_t flex_acl_get_key_kvd_size(uint32_t key_handle, uint32_t *kvd_size_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_acl_flex_key_width_t key_width = SX_ACL_FLEX_KEY_WIDTH_NONE_E;
    rm_sdk_table_type_e     resource = 0;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(kvd_size_p, "kvd_size_p"))) {
        goto out;
    }

    rc = flex_acl_key_sizes_get(key_handle, NULL, &key_width);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: failed to get key sizes for key handle [0x%x]\n", key_handle);
        goto out;
    }

    /* Translate the key width to relevant ATCAM blocks */
    switch (key_width) {
    case SX_ACL_FLEX_KEY_WIDTH_9_E:
        resource = RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E;
        break;

    case SX_ACL_FLEX_KEY_WIDTH_18_E:
        resource = RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E;
        break;

    case SX_ACL_FLEX_KEY_WIDTH_36_E:
        resource = RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E;
        break;

    case SX_ACL_FLEX_KEY_WIDTH_54_E:
        resource = RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E;
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ACL: Unexpected key width [%u] when getting key KVD size\n", key_width);
        break;
    }
    /* Retrieve the KVD cost of this resource type */
    *kvd_size_p = rm_resource_global.rm_sdk_tables_db[resource].entry_cost;

out:
    return rc;
}


sx_status_t flex_acl_get_lag_ports_list(sx_port_log_id_t   log_port,
                                        boolean_t          is_vport,
                                        sx_port_log_id_t * ports_list_p,
                                        uint32_t         * ports_count_p)
{
    sx_lag_id_t    lid = 0;
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(log_port);

    SX_LOG_ENTER();

    if ((port_type == SX_PORT_TYPE_NETWORK) ||
        (port_type == SX_PORT_TYPE_TUNNEL) ||
        (port_type == SX_PORT_TYPE_CPU) ||
        (TRUE == is_vport)) {
        *ports_count_p = 1;
        ports_list_p[0] = log_port;
    } else if (SX_PORT_TYPE_LAG == port_type) {
        /* SX_PORT_TYPE_LAG */
        lid = SX_PORT_LAG_ID_GET(log_port);
        sx_status = sx_la_db_log_port_get(lid, SX_PORT_DEV_ID_GET(log_port), ports_list_p, ports_count_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Cannot retrieve ports from lag[0x%04X], rc[%s]\n", lid, sx_status_str(sx_status));
            return sx_status;
        }
    } else {
        SX_LOG_ERR("The port[0x%04X], are from unsupported type(%s)\n", log_port, sx_port_type_str(port_type));
        return SX_STATUS_PARAM_ERROR;
    }


    SX_LOG_DBG("Lag_port[%#x], port_count[%d],ports_list_p[0]=[%u]\n", log_port, *ports_count_p,
               ports_list_p[0]);
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_keys_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}


static sx_status_t __macsec_flow_sec_y_conv(sx_flex_acl_key_desc_t   *i_key,
                                            sx_acl_hw_key_e           hw_key,
                                            uint8_t                  *o_key,
                                            uint8_t                  *o_mask,
                                            uint32_t                 *out_len,
                                            flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint16_t    hw_macsec_flow_secy_id = 0;

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_MACSEC_SECY_E:   /* MACSEC */

        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.macsec_flow_secy_id == 0) {
                memset(o_mask, 0, sizeof(i_key->mask.macsec_flow_secy_id));
                memset(o_key, 0, sizeof(i_key->key.macsec_flow_secy_id));
                *out_len = sizeof(i_key->mask.macsec_flow_secy_id);
                goto out;
            }
            memset(o_mask, 0xff, sizeof(i_key->mask.macsec_flow_secy_id));
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            SX_MACSEC_GET_ID_FROM_OBJ_ID(i_key->key.macsec_flow_secy_id, hw_macsec_flow_secy_id);
            memcpy(o_key, &hw_macsec_flow_secy_id, sizeof(hw_macsec_flow_secy_id));
        }

        *out_len = sizeof(i_key->mask.macsec_flow_secy_id);
        break;

    default:
        SX_LOG_ERR("Invalid macsec secy id HW key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __sci_conv(sx_flex_acl_key_desc_t   *i_key,
                              sx_acl_hw_key_e           hw_key,
                              uint8_t                  *o_key,
                              uint8_t                  *o_mask,
                              uint32_t                 *out_len,
                              flex_acl_key_build_mode_e build_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (hw_key) {
    case FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_0_31_E:

        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.macsec_sci == 0) {
                memset(o_mask, 0, 4);
                memset(o_key, 0, 4);
                *out_len = 4;
                goto out;
            }
            memset(o_mask, 0xff, 4);
        }
        if (IS_KEY_BUILD_VALUE(build_mode)) {
            memcpy(o_key, &i_key->key.macsec_sci, 4);
        }

        *out_len = 4;

        break;

    case FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E:

        if (IS_KEY_BUILD_MASK(build_mode)) {
            if (i_key->mask.macsec_sci == 0) {
                memset(o_mask, 0, 4);
                memset(o_key, 0, 4);
                *out_len = 4;
                goto out;
            }
            memset(o_mask, 0xff, 4);
        }

        if (IS_KEY_BUILD_VALUE(build_mode)) {
            memcpy(o_key, ((uint8_t*)&i_key->key.macsec_sci) + 4, 4);
        }

        *out_len = 4;

        break;

    default:
        SX_LOG_ERR("Invalid MACSEC SCI key id:%d \n", hw_key);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}
