/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __FLEX2_ACL_H_INCL__
#define __FLEX2_ACL_H_INCL__

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t flex2_acl_init_ops(void);
sx_status_t flex3_acl_init_ops(void);
sx_status_t flex4_acl_init_ops(void);
sx_status_t flex2_acl_init(sx_api_sx_sdk_init_t *init_params);
void flex2_acl_deinit(void);
sx_status_t flex2_acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params);
sx_status_t flex2_acl_range_set(sx_api_acl_range_params_t *params);
sx_status_t flex2_acl_range_get(sx_api_acl_range_params_t *params);
sx_status_t flex2_acl_l4_port_range_set(sx_api_acl_l4_range_params_t *params_p);
sx_status_t flex2_acl_bind_port(sx_api_acl_bind_params_t *params);
sx_status_t flex2_acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* ifndef __FLEX2_ACL_H_INCL__ */
