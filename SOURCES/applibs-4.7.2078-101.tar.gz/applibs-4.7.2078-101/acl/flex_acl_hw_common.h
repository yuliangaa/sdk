/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef FLEX_ACL_HW_COMMON_H_
#define FLEX_ACL_HW_COMMON_H_

#include <policer/policer_manager.h>
#include <counters/counter_manager/counter_manager.h>
#include <span/span.h>
#include <kvd/kvd_linear_manager.h>
#include <acl/flex_acl_db.h>
#include <ethl3/hwi/ecmp/router_ecmp.h>

#ifdef FLEX_ACL_HW_COMMON_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif


/************************************************
 *  Global variables
 ***********************************************/
extern char * hw_action_short[];
/************************************************
 *  Macros
 ***********************************************/
#define HW_ACTION_ID_2SHORT(hw_action_id)       \
    ((hw_action_id) < SXD_ACTION_TYPE_LAST_E && \
     hw_action_short[(hw_action_id)]) ? hw_action_short[(hw_action_id)] : "***"

/* The maximum KVD block size used for default actions.
 * NOTE: Due to FW workaround a single default action is needed to be
 * reserved for FW use. Currently it's entry 1023.
 * We leave an extra space just to be safe so the usable space is 0-999.
 * In any case the maximum regions we support is currently 1000.
 */
#define DEFAULT_ACTIONS_MAX_BLOCK_SIZE (1024)
#define DEFAULT_ACTIONS_MAX_ALLOWED    (DEFAULT_ACTIONS_MAX_BLOCK_SIZE - 24)
#define DEFAULT_ACTIONS_FW_RESERVED    (1)


#define FLEX_ACL_INVALID_KVD_HANDLE (0xFFFFFFFFFFFFFFFF)

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum {
    FLEX_ACL_ACTION_MODEFIER_NONE_E,
    FLEX_ACL_ACTION_MODEFIER_IGMPV3_PBS_E,
    FLEX_ACL_ACTION_MODEFIER_IPV6_MSB_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE3_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE4_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE5_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE6_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE7_E,
    FLEX_ACL_ACTION_MODEFIER_PORTS_EXT2_PAGE8_E,
    FLEX_ACL_ACTION_MODEFIER_NAT_SIP_LSB_E,
    FLEX_ACL_ACTION_MODEFIER_NAT_SIP_MSB_E,
    FLEX_ACL_ACTION_MODEFIER_NAT_DIP_LSB_E,
    FLEX_ACL_ACTION_MODEFIER_NAT_DIP_MSB_E,
} flex_acl_action_modifier_e;

typedef enum hw_action_position {
    FLEX_ACL_HW_ACTION_POSITION_INVALID_E,          /** Position: invalid */
    FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E,         /** Position: in transaction */
    FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E,  /** Transaction terminator */
    FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E,        /** Position: off transaction */
    FLEX_ACL_HW_ACTION_POSITION_END_E,              /** Position: at the end of action list */
    FLEX_ACL_HW_ACTION_POSITION_LAST_E,
} hw_action_position_e;

typedef struct {
    sx_flex_acl_flex_action_type_t     api_action_type;
    sxd_flex_acl_action_type_t         action_type;
    boolean_t                          is_defer;
    sx_policer_id_t                    policer_id;
    cm_logical_id_t                    counter_id;
    cm_type_e                          cm_type;
    sx_acl_pbs_id_t                    pbs_id;
    span_client_handle_t               span_user_handle;
    sx_span_session_id_t               span_session_id;
    uint32_t                           mirror_probability_rate;
    kvd_linear_manager_handle_t        pbs_kvd_handle;
    sx_tunnel_id_t                     tunnel_id;
    sx_mc_container_id_t               mc_container;
    sx_router_interface_t              rif;
    sx_ecmp_id_t                       ecmp;
    hwi_ecmp_hw_block_handle_t         ecmp_block_handle;
    sx_ecmp_container_type_e           ecmp_container_type;
    boolean_t                          is_ref_count_inc;
    boolean_t                          is_locked;
    boolean_t                          is_egress_mirror;
    boolean_t                          is_egress_mirror_sampler;
    sxd_flex_trap_forward_action_val_t original_forward_action;  /* in case of empty PBS etc. */
    sxd_action_slot_t                  slot;
    sxd_action_slot_t                  aux_slot;
    flex_acl_action_modifier_e         action_modifier;
    sx_acl_pbilm_id_t                  pbilm_id;
    hw_action_position_e               position;
    sx_ip_next_hop_ip_tunnel_t         ip_tunnel_id;
    uint64_t                           acl_drop_trap_handle;
    boolean_t                          temp_release_lock; /*This is to temporarily release the lock of other objects (like counter) while building the actions in an action set.
                                                           *  Note a subsequent counter action would most probably result in grabbing the lock again prior to writing the entire action set to hardware*/
    sx_ar_classifier_action_type_e ar_profile_id;
    sx_nat_id_t                    nat_id;
} flex_acl_hw_action_t;

/* Temporary HW actions list */
typedef struct {
    cl_pool_item_t       pool_item;
    cl_list_item_t       list_item;
    flex_acl_hw_action_t hw_action;
} hw_action_list_entry_t;

typedef struct {
    cl_qlist_t qlist;
} hw_action_list_t;

typedef struct {
    boolean_t is_head;
    uint32_t *kvd_index_p;
} flex_acl_relocation_data_t;

typedef sx_status_t (*populate_hw_action_t)(sx_flex_acl_flex_action_t action, boolean_t is_defer,
                                            flex_acl_rule_id_t rule_id, hw_action_list_t *hw_action_list_p,
                                            hw_action_list_entry_t *first_hw_action_list_entry_p);

typedef hw_action_position_e (*hw_action_position_cb_t)(sx_flex_acl_flex_action_t *action_p,
                                                        sxd_flex_acl_action_type_t hw_action_type);

typedef sx_status_t (*rollback_hw_action_t)(flex_acl_rule_id_t rule_id, flex_acl_hw_action_t *hw_action);

typedef sx_status_t (*bind_populate_hw_action_t)(flex_acl_hw_action_t *hw_action, flex_acl_db_flex_rule_t *rule,
                                                 flex_acl_relocation_data_t relocation_data, boolean_t add_ref);

typedef sx_status_t (*bind_release_lock_t)(flex_acl_hw_action_t *hw_action);

typedef boolean_t (*is_hw_action_reuse_t)(sx_flex_acl_flex_action_t *action,
                                          flex_acl_hw_action_t      *hw_action,
                                          int32_t                    relative_position);

typedef boolean_t (*is_map_action_t)(sx_flex_acl_flex_action_t *action, flex_acl_action_modifier_e action_modifier,
                                     uint32_t *instance_count);

typedef boolean_t (*is_hw_action_set_comply_t)(flex_acl_hw_action_t *hw_action1_p,
                                               flex_acl_hw_action_t *hw_action2_p);

typedef struct {
    is_map_action_t            is_map_action_cb;
    sxd_flex_acl_action_type_t hw_action;
    flex_acl_action_modifier_e action_modifier;
} flex_acl_hw_actions_map_hw_data_t;

typedef struct {
    uint8_t                            flags;
    uint8_t                            hw_actions_count;
    flex_acl_hw_actions_map_hw_data_t *hw_actions;
} flex_acl_actions_details_t;

typedef struct {
    uint8_t                   size;
    hw_action_position_cb_t   position_cb;
    is_hw_action_reuse_t      is_hw_action_reuse;
    populate_hw_action_t      pre_bind_populate;
    bind_populate_hw_action_t bind_populate;
    bind_release_lock_t       release_lock;
    rollback_hw_action_t      populate_rollback;
    is_hw_action_set_comply_t action_set_comply_cb;
} flex_acl_hw_action_details_t;

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* ifndef FLEX_ACL_HW_COMMON_H_ */
