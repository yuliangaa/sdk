/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/* system_acl.h
 */
#ifndef SYSTEM_ACL_H_
#define SYSTEM_ACL_H_

#include <sx/sdk/sx_flex_acl.h>
#include <acl/flex_acl_hw_cb.h>
#include <acl/flex_acl_gen_def.h>
#include <complib/cl_list.h>

#define SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE            16
#define SYSTEM_ACL_REGION_IGMP_V3_IPV4_MIN_SIZE      8
#define SYSTEM_ACL_REGION_IGMP_V3_IPV6_MIN_SIZE      8
#define SYSTEM_ACL_REGION_IGMP_V3_PRUNE_MIN_SIZE     8
#define SYSTEM_ACL_REGION_IGMP_V3_METADATA_SIZE      5
#define SYSTEM_ACL_REGION_IGMP_V3_METADATA_ERIF_SIZE 2
#define SYSTEM_ACL_REGION_IGMP_V3_RESTORE_VLAN_SIZE  4096

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/** The type describing system clients */
typedef enum system_acl_client_id {
    SYSTEM_ACL_CLIENT_ID_INVALID_E               = 0,
    SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E        = 1,
    SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E        = 2,
    SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E           = 3,
    SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E      = 4,
    SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E           = 5,
    SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E      = 6,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_E      = 7,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV4_E          = 8,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV6_E          = 9,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_ERIF_E = 10,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV4_E    = 11,
    SYSTEM_ACL_CLIENT_ID_PORT_ISOLATION_E        = 12,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_RESTORE_VLAN_E  = 13,
    SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV6_E    = 14,
    SYSTEM_ACL_CLIENT_ID_L2_TPORT_ISOLATION_E    = 15,
    SYSTEM_ACL_CLIENT_ID_NAT_4_TO_6_E            = 16,
    SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E           = 17,
    SYSTEM_ACL_CLIENT_ID_LAST_E,
} system_acl_client_id_e;

typedef enum system_acl_binding_point_type {
    SYSTEM_ACL_BINDING_POINT_TYPE_MC_E                   = 0,
    SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_INGRESS_E = 1,
    SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_EGRESS_E  = 2,
    SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E     = 3,
    SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E      = 4,
    SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E                 = 5,
    SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E                 = 6,
    SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E          = 7,
    SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E           = 8,
    SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E      = 9,
    SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E       = 10,
    SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E        = 11,
    SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E         = 12,
    SYSTEM_ACL_BINDING_POINT_LAST_E,
} system_acl_binding_point_type_e;

typedef enum system_acl_wc_rule_type {
    SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E = 0,      /** Standard Flex ACL wildcard rule */
    SYSTEM_ACL_WC_RULE_TYPE_NONE_E    = 1,      /** No wildcard rule */
    SYSTEM_ACL_WC_RULE_TYPE_LAST_E,
} system_acl_wc_rule_type_e;

typedef enum system_acl_priority {
    SYSTEM_ACL_PRIORITY_BEFORE_USER = 0,        /* The system ACL should be inserted before the user's ACLs */
    SYSTEM_ACL_PRIORITY_AFTER_USER  = 1,        /* The system ACL should be inserted after the user's ACLs */
    SYSTEM_ACL_PRIORITY_LAST_E,
} system_acl_priority_e;

/* HW call backs structure, stores registers call backs, that can be defined by user */
typedef struct system_acl_hw_cb {
    flex_acl_hw_rule_write_hw_cb      rule_hw_cb;
    flex_acl_hw_region_write_hw_cb    region_hw_cb;
    flex_acl_hw_move_rule_write_hw_cb move_rule_hw_cb;
    flex_acl_hw_acl_write_hw_cb       acl_hw_cb;
    flex_acl_hw_activity_read_hw_cb   activity_read_hw_cb;
    flex_acl_hw_dump_activity_cb      activity_dump_hw_cb;
} system_acl_hw_cb_t;

typedef struct system_acl_instance_info {
    boolean_t          is_initialized;                                  /** initialization flag */
    sx_acl_region_id_t region_id;                                       /** ID of allocated region */
    sx_acl_id_t        acl_group_id;                                    /** ID of allocated default group */
    sx_acl_id_t        acl_id;                                          /** ID of allocated ACL */
} system_acl_instance_info_t;

/* entry per client, each client should fill parameters in static client table. Parameters to fill commented as "predefined" */
/* for each client will be created : key, region, ACL and ACL group.*/
typedef struct system_acl_client_table_entry {
    system_acl_client_id_e          client_id;                          /** predefined */
    sx_acl_key_t                    keys[RM_API_ACL_MAX_FIELDS_IN_KEY]; /** desired keys, predefined */
    uint32_t                        num_of_keys;                        /** number of desired keys, predefined*/
    system_acl_binding_point_type_e binding_point_type;                 /** predefined */
    system_acl_priority_e           system_acl_priority;                /** order between the user and system ACLs. Individual binding only, predefined */
    sx_acl_size_t                   region_min_size;                    /** size of region at creation, predefined */
    uint32_t                        instances_allowed;                  /** Instances allowed, predefined */
    uint32_t                        num_of_instances;                   /** Currently initialized instances */
    system_acl_instance_info_t     *instance_info;                      /** Pointer to an array of per instance information */
    sx_acl_key_type_t               key_handle;                         /** key handle for allocated region(s) */
    system_acl_wc_rule_type_e       wc_rule_type;                       /** WC rule type */
    boolean_t                       is_rules_rm_needed;                 /** Is RM update needed */
} system_acl_client_table_entry_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/* initialize system acl client by static parameters defined in system_acl.c */
sx_status_t system_acl_client_init(system_acl_client_id_e client_id,
                                   uint32_t               instance,
                                   sx_acl_region_id_t    *region_id_p);
sx_status_t system_acl_client_deinit(system_acl_client_id_e client_id, uint32_t instance);
/* get reference to client structure in static clients table */
sx_status_t system_acl_client_get(sx_acl_region_id_t region_id, system_acl_client_table_entry_t **client_table_entry);
sx_status_t system_acl_client_get_by_id(system_acl_client_id_e            client_id,
                                        system_acl_client_table_entry_t **client_table_entry);
sx_status_t system_acl_instance_get_by_id(system_acl_client_id_e       client_id,
                                          uint32_t                     instance_num,
                                          system_acl_instance_info_t **instance_info_p);
sx_status_t system_acl_region_get_hw_size(sx_acl_region_id_t region_id, uint32_t *hw_size);
sx_status_t system_acl_vlan_add(system_acl_client_id_e client_id,
                                sx_swid_id_t           swid,
                                sx_vlan_id_t          *vlan_list,
                                uint32_t               vlan_num);
sx_status_t system_acl_vlan_remove(system_acl_client_id_e client_id,
                                   sx_swid_id_t           swid,
                                   sx_vlan_id_t          *vlan_list,
                                   uint32_t               vlan_num);

sx_acl_direction_t system_acl_get_direction(system_acl_binding_point_type_e binding_point_type);
system_acl_client_id_e system_acl_tunnel_client_id_get(sx_ip_version_t ip_version);

sx_status_t system_acl_rif_bind(system_acl_client_id_e client_id, uint32_t instance, sx_rif_id_t rif);
sx_status_t system_acl_rif_unbind(system_acl_client_id_e client_id, uint32_t instance, sx_rif_id_t rif);
sx_status_t system_acl_port_bind(system_acl_client_id_e client_id, uint32_t instance, sx_port_id_t port);
sx_status_t system_acl_port_unbind(system_acl_client_id_e client_id, uint32_t instance, sx_port_id_t port);

sx_status_t system_acl_issu_mc_router_bind_trigger_spc2(sx_access_cmd_t cmd, system_acl_client_id_e client_id);
/* for inner use */
void system_acl_dump(dbg_dump_params_t *dbg_dump_params_p);


#endif /* SYSTEM_ACL_H_ */
