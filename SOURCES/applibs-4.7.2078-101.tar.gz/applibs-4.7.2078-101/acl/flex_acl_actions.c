/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#undef  __MODULE__
#define __MODULE__ ACL

#include <complib/sx_log.h>
#include "flex_acl_gen_def.h"
#include "flex_acl_db.h"
#include "flex_acl_hw.h"
#include "flex_acl_actions.h"
#include "ethl2/vlan.h"
#include "ethl2/fid_manager.h"
#include "ethl3/hwd/hwd_rif/hwd_rif.h"
#include "ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h"
#include "ethl3/hwi/ecmp/router_ecmp_impl.h"
#include "ethl3/hwi/nat_4to6/nat_4to6_impl.h"
#include "ethl3/router_common.h"
#include "ethl3/hwi/mc_route/mc_rpf_group_db.h"
#include <flow_counter/flow_counter.h>
#include <sx/sdk/sx_mc_container.h>
#include <tunnel/hwi/tunnel_impl.h>
#include <policer/policer.h>
#include <mc_container/hwd/hwd_mc_container.h>
#include "flex_modifier/flex_modifier.h"
#include "truncation_profile/truncation_profile.h"
/************************************************
 *  Macros
 ***********************************************/

#define GP_REGISTER_BITS_SIZE (sizeof(sx_gp_register_t) * 8)
#define FIELDS_SELECT_SIZE    (16)  /* Field select field size in bits */
#define GP_REGISTER_SET_SIZE  (4)   /* Used for stateful DB action */
#define EMT_ENCAP_OFFSET_MAX  (60)

/************************************************
**  Global variables
************************************************/
extern flex_acl_db_goto_validation_params_t flex_acl_goto_validation_params;
extern flex_acl_ops_t                      *flex_acl_ops_g;
extern acl_stage_e                          g_acl_stage;

/***********************************************
*  Local variables
***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

typedef boolean_t (*is_action_value_valid_t)(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id);
/* Actions validation function declarations */
static boolean_t __is_set_vlan_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id);
static boolean_t __is_set_inner_vlan_id_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id);
static boolean_t __is_set_outer_vlan_id_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id);
static boolean_t __is_pbs_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id);
static boolean_t __is_trap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id);
static boolean_t __is_forward_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_counter_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_counter_by_ref_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id);
static boolean_t __is_mirror_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                          sx_flex_acl_flex_action_fields_t *action,
                                          sx_acl_region_id_t                region_id);
static boolean_t __is_mirror_sampler_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id);
static boolean_t __is_set_bridge_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id);
static boolean_t __is_set_color_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id);
static boolean_t __is_set_ecn_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_rpf_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id);
static boolean_t __is_mc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id);
static boolean_t __is_uc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id);
static boolean_t __is_tunnel_decap_valid(sx_flex_acl_flex_action_type_t    action_type,
                                         sx_flex_acl_flex_action_fields_t *action,
                                         sx_acl_region_id_t                region_id);
static boolean_t __is_nve_tunnel_encap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                    sx_flex_acl_flex_action_fields_t *action,
                                                    sx_acl_region_id_t                region_id);
static boolean_t __is_nve_mc_tunnel_encap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                       sx_flex_acl_flex_action_fields_t *action,
                                                       sx_acl_region_id_t                region_id);
static boolean_t __is_set_dscp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                    sx_flex_acl_flex_action_fields_t *action,
                                                    sx_acl_region_id_t                region_id);
static boolean_t __is_set_pcp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id);
static boolean_t __is_policer_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_set_exp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id);
static boolean_t __is_pbilm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                         sx_flex_acl_flex_action_fields_t *action,
                                         sx_acl_region_id_t                region_id);
static boolean_t __is_goto_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id);
static boolean_t __is_set_router_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id);
static boolean_t __is_set_user_token_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id);
static boolean_t __is_mc_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                      sx_flex_acl_flex_action_fields_t *action,
                                      sx_acl_region_id_t                region_id);
static boolean_t __is_set_ip_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                          sx_flex_acl_flex_action_fields_t *action,
                                          sx_acl_region_id_t                region_id);
static boolean_t __is_set_l4_port_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                               sx_flex_acl_flex_action_fields_t *action,
                                               sx_acl_region_id_t                region_id);
static boolean_t __is_hash_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id);
static boolean_t __is_alu_imm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_alu_reg_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_alu_field_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id);
static boolean_t __is_register_access_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id);
static boolean_t __is_set_elephant_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                sx_flex_acl_flex_action_fields_t *action,
                                                sx_acl_region_id_t                region_id);
static boolean_t __is_field_imm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id);
static boolean_t __is_field_copy_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id);
static boolean_t __is_set_emt_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id);
static boolean_t __is_set_buffer_snap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id);
static boolean_t __is_ar_packet_prof_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id);
static boolean_t __is_ar_uc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                               sx_flex_acl_flex_action_fields_t *action,
                                               sx_acl_region_id_t                region_id);
static boolean_t __is_mirror_trigger_disallow_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                           sx_flex_acl_flex_action_fields_t *action,
                                                           sx_acl_region_id_t                region_id);
static boolean_t __is_nat_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id);
static boolean_t __is_stateful_db_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id);
static boolean_t __is_disable_fdb_security_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                 sx_flex_acl_flex_action_fields_t *action,
                                                 sx_acl_region_id_t                region_id);
static boolean_t __is_set_vlan_ethertype_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                      sx_flex_acl_flex_action_fields_t *action,
                                                      sx_acl_region_id_t                region_id);
static boolean_t __is_truncation_profile_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                      sx_flex_acl_flex_action_fields_t *action,
                                                      sx_acl_region_id_t                region_id);
static boolean_t __is_flow_estimator_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id);

/* General local functions */
static sx_status_t __is_group_chain_contain_goto_call(sx_acl_id_t group_id, boolean_t *contain);
static sx_status_t __is_acl_group_goto_call_target(sx_acl_id_t group_id, boolean_t  *is_target);
static sx_status_t __is_acl_group_goto_target(sx_acl_id_t group_id, boolean_t  *is_target);

/************************************************
 *  Local variables
 ***********************************************/
/************************************************
 *  Action validation function array
 ***********************************************/
static is_action_value_valid_t action_validation[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = {
    [SX_FLEX_ACL_ACTION_TRAP] = __is_trap_action_valid,
    [SX_FLEX_ACL_ACTION_FORWARD] = __is_forward_action_valid,
    [SX_FLEX_ACL_ACTION_COUNTER] = __is_counter_action_valid,
    [SX_FLEX_ACL_ACTION_COUNTER_BY_REF] = __is_counter_by_ref_action_valid,
    [SX_FLEX_ACL_ACTION_MIRROR] = __is_mirror_action_valid,
    [SX_FLEX_ACL_ACTION_SET_VLAN] = __is_set_vlan_action_valid,
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID] = __is_set_inner_vlan_id_valid,
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID] = __is_set_outer_vlan_id_valid,
    [SX_FLEX_ACL_ACTION_SET_BRIDGE] = __is_set_bridge_action_valid,
    [SX_FLEX_ACL_ACTION_PBS] = __is_pbs_action_valid,
    [SX_FLEX_ACL_ACTION_SET_COLOR] = __is_set_color_action_valid,
    [SX_FLEX_ACL_ACTION_SET_ECN] = __is_set_ecn_action_valid,
    [SX_FLEX_ACL_ACTION_RPF] = __is_rpf_action_valid,
    [SX_FLEX_ACL_ACTION_MC_ROUTE] = __is_mc_route_action_valid,
    [SX_FLEX_ACL_ACTION_TUNNEL_DECAP] = __is_tunnel_decap_valid,
    [SX_FLEX_ACL_ACTION_POLICER] = __is_policer_action_valid,
    [SX_FLEX_ACL_ACTION_TRUNCATION] = __is_truncation_profile_action_valid,
    [SX_FLEX_ACL_ACTION_GOTO] = __is_goto_action_valid,
    [SX_FLEX_ACL_ACTION_SET_ROUTER] = __is_set_router_action_valid,
    [SX_FLEX_ACL_ACTION_SET_USER_TOKEN] = __is_set_user_token_action_valid,
    [SX_FLEX_ACL_ACTION_UC_ROUTE] = __is_uc_route_action_valid,
    [SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE] = __is_set_dscp_rewrite_action_valid,
    [SX_FLEX_ACL_ACTION_SET_PCP_REWRITE] = __is_set_pcp_rewrite_action_valid,
    [SX_FLEX_ACL_ACTION_MC] = __is_mc_action_valid,
    [SX_FLEX_ACL_ACTION_SET_EXP_REWRITE] = __is_set_exp_rewrite_action_valid,
    [SX_FLEX_ACL_ACTION_PBILM] = __is_pbilm_action_valid,
    [SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP] = __is_nve_tunnel_encap_action_valid,
    [SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP] = __is_nve_mc_tunnel_encap_action_valid,
    [SX_FLEX_ACL_ACTION_TRAP_W_USER_ID] = __is_trap_action_valid,
    [SX_FLEX_ACL_ACTION_SET_SIP_ADDR] = __is_set_ip_action_valid,
    [SX_FLEX_ACL_ACTION_SET_DIP_ADDR] = __is_set_ip_action_valid,
    [SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR] = __is_set_ip_action_valid,
    [SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR] = __is_set_ip_action_valid,
    [SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT] = __is_set_l4_port_action_valid,
    [SX_FLEX_ACL_ACTION_SET_L4_DST_PORT] = __is_set_l4_port_action_valid,
    [SX_FLEX_ACL_ACTION_HASH] = __is_hash_action_valid,
    [SX_FLEX_ACL_ACTION_ALU_IMM] = __is_alu_imm_action_valid,
    [SX_FLEX_ACL_ACTION_ALU_REG] = __is_alu_reg_action_valid,
    [SX_FLEX_ACL_ACTION_ALU_FIELD] = __is_alu_field_action_valid,
    [SX_FLEX_ACL_ACTION_REGISTER_ACCESS] = __is_register_access_action_valid,
    [SX_FLEX_ACL_ACTION_ELEPHANT_SET] = __is_set_elephant_action_valid,
    [SX_FLEX_ACL_ACTION_MIRROR_SAMPLER] = __is_mirror_sampler_action_valid,
    [SX_FLEX_ACL_ACTION_FIELD_IMM] = __is_field_imm_action_valid,
    [SX_FLEX_ACL_ACTION_FIELD_COPY] = __is_field_copy_action_valid,
    [SX_FLEX_ACL_ACTION_SET_EMT] = __is_set_emt_action_valid,
    [SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP] = __is_set_buffer_snap_action_valid,
    [SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE] = __is_ar_packet_prof_action_valid,
    [SX_FLEX_ACL_ACTION_AR_UC_ROUTE] = __is_ar_uc_route_action_valid,
    [SX_FLEX_ACL_ACTION_MIRROR_TRIGGER_DISALLOW] = __is_mirror_trigger_disallow_action_valid,
    [SX_FLEX_ACL_ACTION_NAT] = __is_nat_action_valid,
    [SX_FLEX_ACL_ACTION_STATEFUL_DB] = __is_stateful_db_valid,
    [SX_FLEX_ACL_ACTION_DISABLE_FDB_SECURITY] = __is_disable_fdb_security_valid,
    [SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE] = __is_set_vlan_ethertype_action_valid,
    [SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR] = __is_flow_estimator_action_valid,
};

/************************************************
 *  Function implementations
 ***********************************************/
static boolean_t __is_set_vlan_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if ((action->action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH) &&
        !VLAN_ID_CHECK_RANGE(action->action_set_vlan.vlan_id)) {
        SX_LOG_ERR("set vlan action vid %u is not valid \n", action->action_set_vlan.vlan_id);
        is_valid = FALSE;
        goto out;
    }

    if (action->action_set_vlan.cmd >= SX_ACL_FLEX_SET_VLAN_CMD_TYPE_LAST) {
        SX_LOG_ERR("Vlan action %u is not valid\n", action->action_set_vlan.cmd);
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_set_vlan.cmd == SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH) &&
        (action->action_set_vlan.qinq_tunnel_qos >= SX_ACL_FLEX_QINQ_TUNNEL_QOS_LAST)) {
        SX_LOG_ERR("Vlan qinq_tunnel_qos %u is not valid\n", action->action_set_vlan.qinq_tunnel_qos);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_inner_vlan_id_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (!VLAN_ID_CHECK_RANGE(action->action_set_inner_vlan_id.vlan_id)) {
        SX_LOG_ERR("set inner vlan action vid %u is not valid \n", action->action_set_inner_vlan_id.vlan_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_outer_vlan_id_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (!VLAN_ID_CHECK_RANGE(action->action_set_outer_vlan_id.vlan_id)) {
        SX_LOG_ERR("set outer vlan action vid %u is not valid \n", action->action_set_outer_vlan_id.vlan_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_pbs_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id)
{
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    boolean_t                is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = flex_acl_db_pbs_get_entry(0, action->action_pbs.pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS action PBS id %u is not valid\n", action->action_pbs.pbs_id);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_trap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    boolean_t                        is_valid = TRUE;
    flex_acl_db_acl_region_t        *acl_region_p;
    system_acl_client_table_entry_t *client_table_entry_p;
    boolean_t                        no_trap_id_validation = FALSE;
    sx_flex_acl_trap_action_t        trap_action;
    sx_trap_id_t                     trap_id;

    if (action_type == SX_FLEX_ACL_ACTION_TRAP) {
        trap_action = action->action_trap.action;
        trap_id = action->action_trap.trap_id;

        if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage) &&
            (action->action_trap.preserve_user_id != FALSE)) {
            /* preserve_user_id is supported for SPC4 and above */
            SX_LOG_ERR("Flex ACL trap action preserve_user_id is not supported for this chip type.\n");
            is_valid = FALSE;
            goto out;
        }
    } else if (action_type == SX_FLEX_ACL_ACTION_TRAP_W_USER_ID) {
        trap_action = action->action_trap_w_user_id.action;
        trap_id = action->action_trap_w_user_id.trap_id;
    } else {
        SX_LOG_ERR("Unsupported action type %s(%u)\n", ACTION_ID_2STR(action_type), action_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (trap_action >= SX_ACL_TRAP_ACTION_TYPE_LAST) {
        SX_LOG_ERR("TRAP action %u is not valid\n", trap_action);
        is_valid = FALSE;
        goto out;
    }

    if (trap_action == SX_ACL_TRAP_ACTION_TYPE_TRAP) {
        /* Check system ACL */
        rc = flex_acl_db_region_get(region_id, &acl_region_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", region_id);
            goto out;
        }
        if (acl_region_p->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
            rc = system_acl_client_get(acl_region_p->region_id, &client_table_entry_p);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("system_acl_client_get failed for region id [%u]\n", acl_region_p->region_id);
                goto out;
            }
            if (client_table_entry_p->binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_MC_E) {
                no_trap_id_validation = TRUE;
            }
        }

        if (!no_trap_id_validation && !SX_TRAP_ID_ACL_CHECK_RANGE(trap_id)) {
            SX_LOG_ERR("ACL : Trap ID [%u] not in range [%u-%u]\n",
                       trap_id, SX_TRAP_ID_ACL_MIN, SX_TRAP_ID_ACL_MAX);
            is_valid = FALSE;
        }
    }
out:
    return is_valid;
}

static boolean_t __is_forward_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_forward.action >= SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST) {
        SX_LOG_ERR("FORWARD action %u is not valid\n", action->action_forward.action);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_counter_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t   is_valid = TRUE;
    sx_status_t rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = flow_counter_is_exists(action->action_counter.counter_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flow Counter id:[%u] does not exist, rc:[%s]\n", action->action_counter.counter_id,
                   sx_status_str(rc));
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_counter_by_ref_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);
    UNUSED_PARAM(action);
    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        /* Supported for SPC4 and above */
        SX_LOG_ERR("Counter by ref is not supported for this chip type.\n");
        is_valid = FALSE;
        goto out;
    }

    if (action->action_counter_by_ref.gp_reg_lsb >= SX_GP_REGISTER_LAST_E) {
        SX_LOG_ERR("action_counter_by_ref.gp_reg_lsb is invalid\n");
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}


static boolean_t __is_mirror_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                          sx_flex_acl_flex_action_fields_t *action,
                                          sx_acl_region_id_t                region_id)
{
    boolean_t                is_valid = TRUE;
    sx_span_session_params_t span_session_params;
    sx_status_t              rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = span_session_get(action->action_mirror.session_id, &span_session_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : session id %d does not exist\n",
                   action->action_mirror.session_id);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_mirror_sampler_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id)
{
    boolean_t                is_valid = TRUE;
    sx_span_session_params_t span_session_params;
    sx_status_t              rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = span_session_get(action->action_mirror_sampler.session_id, &span_session_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : session id %d does not exist\n",
                   action->action_mirror_sampler.session_id);
        is_valid = FALSE;
        goto out;
    }

    if (action->action_mirror_sampler.mirror_probability_rate > MIRROR_SAMPLER_PROBABILITY_RATE_MAX) {
        SX_LOG_ERR("ACL : mirror probability rate %d exceed max %d \n",
                   action->action_mirror_sampler.mirror_probability_rate, MIRROR_SAMPLER_PROBABILITY_RATE_MAX);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}


static boolean_t __is_set_bridge_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id)
{
    boolean_t        is_valid = TRUE;
    sx_status_t      rc;
    sx_fm_fid_type_t fid_type = SX_FM_FID_TYPE_INVALID;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = sdk_fid_manager_get_fid_type(action->action_set_bridge.bridge_id, &fid_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to translate vid (%u)\n", action->action_set_bridge.bridge_id);
        is_valid = FALSE;
        goto out;
    }
    if (fid_type == SX_FM_FID_TYPE_RIF_E) {
        SX_LOG_ERR("Invalid fid %d is used.FID type is SX_FM_FID_TYPE_RIF_E\n", action->action_set_bridge.bridge_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_color_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_set_color.color_val >= SX_ACL_FLEX_COLOR_LAST) {
        SX_LOG_ERR("SET COLOR action %u is not valid\n", action->action_set_color.color_val);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_set_ecn_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_set_ecn.ecn_val > 3) {
        SX_LOG_ERR("SET ECN action %u is not valid\n", action->action_set_ecn.ecn_val);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_rpf_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id)
{
    boolean_t    is_valid = TRUE;
    hwd_rif_id_t rif_id;
    sx_status_t  rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_rpf.rpf_action >= SX_ACL_RPF_ACTION_TYPE_LAST) {
        SX_LOG_ERR("RPF action %u is not valid\n", action->action_rpf.rpf_action);
        is_valid = FALSE;
        goto out;
    }

    if (action->action_rpf.rpf_action == SX_ACL_RPF_ACTION_TYPE_DISABLED) {
        goto out;
    }

    switch (action->action_rpf.rpf_param.rpf_param_type) {
    case SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF:
        rc = sdk_router_cmn_rif_hw_id_get(action->action_rpf.rpf_param.rpf_param_value.rpf_rif, &rif_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("RPF RIF param is not valid. rif:%u [%s]\n",
                       action->action_rpf.rpf_param.rpf_param_value.rpf_rif, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP:
        rc = sdk_mc_rpf_group_db_check(action->action_rpf.rpf_param.rpf_param_value.rpf_group);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("RPF param is not valid. rpf group :%u [%s]\n",
                       action->action_rpf.rpf_param.rpf_param_value.rpf_group, sx_status_str(rc));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("RPF action type is invalid. Type:%u.\n", action->action_rpf.rpf_param.rpf_param_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_mc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id)
{
    boolean_t                    is_valid = TRUE;
    sx_status_t                  rc;
    hw_mc_list_pointer_t         erif_list_pointer;
    sx_mc_container_attributes_t attr;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = hwd_mc_container_erif_list_get(action->action_mc_route.egress_mc_container, &erif_list_pointer, &attr);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed getting mc container mc list mc:%u [%s]\n",
                   action->action_mc_route.egress_mc_container, sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_uc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                            sx_flex_acl_flex_action_fields_t *action,
                                            sx_acl_region_id_t                region_id)
{
    boolean_t     is_valid = TRUE;
    hwd_rif_id_t  rif_id;
    sx_status_t   rc;
    sx_next_hop_t next_hop_list[1];
    uint32_t      next_hop_cnt = 0;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    switch (action->action_uc_route.uc_route_type) {
    case SX_UC_ROUTE_TYPE_LOCAL:
        rc = sdk_router_cmn_rif_hw_id_get(action->action_uc_route.uc_route_param.local_egress_rif, &rif_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("UC route local action invalid local Egress RIF %u.\n",
                       action->action_uc_route.uc_route_param.local_egress_rif);
            is_valid = FALSE;
            goto out;
        }
        break;

    case SX_UC_ROUTE_TYPE_NEXT_HOP:
        rc = sdk_router_ecmp_impl_get(action->action_uc_route.uc_route_param.ecmp_id, next_hop_list, &next_hop_cnt);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("UC route remote action ecmp container id %u.\n",
                       action->action_uc_route.uc_route_param.ecmp_id);
            is_valid = FALSE;
            goto out;
        }
        break;

    default:
        is_valid = FALSE;
        SX_LOG_ERR("Invalid UC route action type: %u \n", action->action_uc_route.uc_route_type);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_ar_uc_route_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                               sx_flex_acl_flex_action_fields_t *action,
                                               sx_acl_region_id_t                region_id)
{
    boolean_t            is_valid = TRUE;
    sx_status_t          rc;
    sx_next_hop_t        next_hop_list[1];
    uint32_t             next_hop_cnt = 0;
    sx_ecmp_attributes_t ecmp_attr;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);
    SX_MEM_CLR(ecmp_attr);

    if (action->action_ar_uc_route.profile_id > SX_AR_CLASSIFIER_ACTION_MAX_E) {
        SX_LOG_ERR("AR UC route remote action profile id %u isn't valid\n",
                   action->action_ar_uc_route.profile_id);
        is_valid = FALSE;
        goto out;
    }

    rc = sdk_router_ecmp_impl_get(action->action_ar_uc_route.ecmp_id, next_hop_list, &next_hop_cnt);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("AR UC route action ecmp container id %u doesn't exist\n",
                   action->action_ar_uc_route.ecmp_id);
        is_valid = FALSE;
        goto out;
    }

    rc = sdk_router_ecmp_impl_attributes_get(action->action_ar_uc_route.ecmp_id, &ecmp_attr);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("AR UC validation failed to get ecmp container id %u attributes\n",
                   action->action_ar_uc_route.ecmp_id);
        is_valid = FALSE;
        goto out;
    }

    if (ecmp_attr.ecmp_type != SX_ECMP_TYPE_ADAPTIVE_E) {
        SX_LOG_ERR("AR UC route unsupported ECMP container type [ECMP ID = %u; type = %s].\n",
                   action->action_ar_uc_route.ecmp_id,
                   SX_ECMP_CONTAINER_STR(ecmp_attr.container_type));
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_tunnel_decap_valid(sx_flex_acl_flex_action_type_t    action_type,
                                         sx_flex_acl_flex_action_fields_t *action,
                                         sx_acl_region_id_t                region_id)
{
    boolean_t             is_valid = TRUE;
    sx_status_t           rc;
    sx_tunnel_attribute_t tunnel_attr;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = sdk_tunnel_impl_get(action->action_tunnel_decap.tunnel_id, &tunnel_attr);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Invalid tunnel id :%u \n", action->action_tunnel_decap.tunnel_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_nve_tunnel_encap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                    sx_flex_acl_flex_action_fields_t *action_p,
                                                    sx_acl_region_id_t                region_id)
{
    boolean_t             is_valid = TRUE;
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    sx_ecmp_attributes_t  ecmp_attr;


    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);
    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ecmp_attr);

    if (action_p->action_nve_tunnel_encap.encap_type == SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP) {
        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(action_p->action_nve_tunnel_encap.tunnel_id)) {
            SX_LOG_ERR("Flex tunnels can only be used in ECMP containers for ACL tunnel encapsulation action\n");
            is_valid = FALSE;
            goto out;
        }

        rc = sdk_tunnel_impl_get(action_p->action_nve_tunnel_encap.tunnel_id, &tunnel_attr);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Invalid tunnel id :%u \n", action_p->action_tunnel_decap.tunnel_id);
            is_valid = FALSE;
            goto out;
        }

        rc = sdk_tunnel_impl_capability_check(action_p->action_nve_tunnel_encap.tunnel_id,  SX_TUNNEL_CAP_ACL_ENCAP_E);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Wrong type or direction for tunnel:%u \n", action_p->action_nve_tunnel_encap.tunnel_id);
            is_valid = FALSE;
            goto out;
        }

        if (!IS_IP_ADDR_UNICAST(action_p->action_nve_tunnel_encap.underlay_dip)) {
            SX_LOG_ERR("Underlay IP address %x is not in UC address range \n",
                       action_p->action_nve_tunnel_encap.underlay_dip.addr.ipv4.s_addr);
            is_valid = FALSE;
            goto out;
        }
    } else if (action_p->action_nve_tunnel_encap.encap_type == SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP) {
        rc = sdk_router_ecmp_impl_attributes_get(action_p->action_nve_tunnel_encap.ecmp_id, &ecmp_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get ECMP attributes [ECMP ID = %u; error = %s].\n",
                       action_p->action_nve_tunnel_encap.ecmp_id,
                       sx_status_str(rc));
            is_valid = FALSE;
            goto out;
        }

        if ((ecmp_attr.container_type != SX_ECMP_CONTAINER_TYPE_NVE_MC) &&
            (ecmp_attr.container_type != SX_ECMP_CONTAINER_TYPE_NVE_FLOOD)) {
            SX_LOG_ERR("Unsupported ECMP container type [ECMP ID = %u; type = %s].\n",
                       action_p->action_nve_tunnel_encap.ecmp_id,
                       SX_ECMP_CONTAINER_STR(ecmp_attr.container_type));
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_nve_mc_tunnel_encap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                       sx_flex_acl_flex_action_fields_t *action,
                                                       sx_acl_region_id_t                region_id)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    uint32_t                     next_hop_cnt = 0;
    uint32_t                     nh_idx = 0;
    boolean_t                    is_valid = TRUE;
    boolean_t                    has_tunnel_nh = FALSE;
    boolean_t                    has_ecmp_nh = FALSE;
    sx_mc_container_id_t         mc_container_id = 0;
    mc_container_owner_type_t    type;
    sx_mc_container_attributes_t attr;
    sx_mc_next_hop_t            *next_hops = NULL;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    SX_MEM_CLR(type);
    SX_MEM_CLR(attr);

    mc_container_id = action->action_nve_mc_tunnel_encap.mc_container_id;

    rc = sdk_mc_container_impl_get(mc_container_id, NULL, &next_hop_cnt, &attr, &type);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("MC Action : Invalid MC id:%u  err %s.\n",
                   mc_container_id, sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }
    if ((attr.type != SX_MC_CONTAINER_TYPE_BRIDGE_MC) &&
        (attr.type != SX_MC_CONTAINER_TYPE_VLAN_UNAWARE)) {
        SX_LOG_ERR(
            "MC Action : Invalid MC type %u . Only SX_MC_CONTAINER_TYPE_BRIDGE_MC and SX_MC_CONTAINER_TYPE_VLAN_UNAWARE types are valid \n",
            attr.type);
        is_valid = FALSE;
        goto out;
    }

    if (next_hop_cnt > 0) {
        next_hops = cl_calloc(next_hop_cnt, sizeof(sx_mc_next_hop_t));
        if (next_hops == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("No memory for MC container %u next hops\n", mc_container_id);
            goto out;
        }

        rc = sdk_mc_container_impl_get(mc_container_id, next_hops, &next_hop_cnt, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve MC container, container id :%u rc=[%s]\n",
                       mc_container_id, sx_status_str(rc));
            goto out;
        }

        for (nh_idx = 0; nh_idx < next_hop_cnt; nh_idx++) {
            switch (next_hops[nh_idx].type) {
            case SX_MC_NEXT_HOP_TYPE_LOG_PORT:
                continue;

            case SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP:
                if (has_ecmp_nh == TRUE) {
                    SX_LOG_ERR("MC Action : MCC cannot contain both TUNNEL_ENCAP_IP and ECMP next hops\n");
                    is_valid = FALSE;
                    goto out;
                }
                has_tunnel_nh = TRUE;
                continue;

            case SX_MC_NEXT_HOP_TYPE_ECMP:
                if (has_tunnel_nh == TRUE) {
                    SX_LOG_ERR("MC Action : MCC cannot contain both ECMP and TUNNEL_ENCAP_IP next hops\n");
                    is_valid = FALSE;
                    goto out;
                }

                /* assuming that has_ecmp_nh is initialized with FALSE */
                if (has_ecmp_nh == TRUE) {
                    SX_LOG_ERR("MC Action : MCC cannot contain more than one ECMP next hop\n");
                    is_valid = FALSE;
                    goto out;
                }

                has_ecmp_nh = TRUE;
                continue;

            default:
                SX_LOG_ERR(
                    "MC Action : Invalid NextHop type %u. Only LOG_PORT, ECMP and TUNNEL_ENCAP_IP type are valid\n",
                    next_hops[nh_idx].type);
                is_valid = FALSE;
                goto out;
            }
        }
    }

out:
    if (next_hops != NULL) {
        cl_free(next_hops);
    }
    return is_valid;
}

static boolean_t __is_set_dscp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                    sx_flex_acl_flex_action_fields_t *action,
                                                    sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_set_dscp_rewrite.set_rewrite_cmd >= SX_ACL_ACTION_REWRITE_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action DSCP RE WRITE - invalid Rewrite command : %u \n",
                   action->action_set_dscp_rewrite.set_rewrite_cmd);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_pcp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_set_pcp_rewrite.set_rewrite_cmd >= SX_ACL_ACTION_REWRITE_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action PCP RE WRITE - invalid Rewrite command : %u \n",
                   action->action_set_pcp_rewrite.set_rewrite_cmd);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_policer_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t               is_valid = TRUE;
    sx_status_t             rc;
    sx_policer_attributes_t policer_attr;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = sx_policer_get(action->action_policer.policer_id, &policer_attr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Policer id:[%u] does not exist rc:[%s]\n",
                   (unsigned int)action->action_policer.policer_id,
                   sx_status_str(rc));
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_truncation_profile_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                      sx_flex_acl_flex_action_fields_t *action,
                                                      sx_acl_region_id_t                region_id)
{
    boolean_t                   is_valid = TRUE;
    sx_status_t                 rc;
    sx_truncation_profile_cfg_t trunc_profile_cfg;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        /* Supported for SPC4 and above */
        SX_LOG_ERR("Flex ACL Truncation-Profile is not supported for this chip type.\n");
        is_valid = FALSE;
        goto out;
    }

    if (action->action_truncation.trunc_profile_id.trunc_profile_type != SX_TRUNCATION_PROFILE_TYPE_ACL_E) {
        SX_LOG_ERR("Truncation-Profile invalid type[%d].\n",
                   (unsigned int)action->action_truncation.trunc_profile_id.trunc_profile_type);
        is_valid = FALSE;
        goto out;
    }

    rc = truncation_profile_get(&action->action_truncation.trunc_profile_id, &trunc_profile_cfg);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Truncation-Profile id:[%u] does not exist rc:[%s]\n",
                   (unsigned int)action->action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id,
                   sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_exp_rewrite_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (action->action_set_exp_rewrite.set_rewrite_cmd >= SX_ACL_ACTION_REWRITE_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action EXP RE WRITE - invalid Rewrite command : %u \n",
                   action->action_set_exp_rewrite.set_rewrite_cmd);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_pbilm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                         sx_flex_acl_flex_action_fields_t *action,
                                         sx_acl_region_id_t                region_id)
{
    flex_acl_db_pbilm_entry_t *pbilm_entry = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    boolean_t                  is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = flex_acl_db_pbilm_get_entry(action->action_pbilm.pbilm_id, &pbilm_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBILM action PBILM id %u is not valid\n", action->action_pbilm.pbilm_id);
        is_valid = FALSE;
    }

    return is_valid;
}

static boolean_t __is_set_ip_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                          sx_flex_acl_flex_action_fields_t *action,
                                          sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG_ERR("Flex ACL set ip address action is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    switch (action_type) {
    case SX_FLEX_ACL_ACTION_SET_SIP_ADDR:
        if (action->action_set_sip.ip_addr.version != SX_IP_VERSION_IPV4) {
            is_valid = FALSE;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_DIP_ADDR:
        if (action->action_set_dip.ip_addr.version != SX_IP_VERSION_IPV4) {
            is_valid = FALSE;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR:
        if (action->action_set_sipv6.ip_addr.version != SX_IP_VERSION_IPV6) {
            is_valid = FALSE;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR:
        if (action->action_set_dipv6.ip_addr.version != SX_IP_VERSION_IPV6) {
            is_valid = FALSE;
        }
        break;

    default:
        SX_LOG_ERR("Flex acl action  %s is not valid for set ip\n", ACTION_ID_2STR(action_type));
        is_valid = FALSE;
        goto out;
    }
    if (is_valid == FALSE) {
        SX_LOG_ERR("Flex ACL set ip address action has an invalid IP version for region [%u]\n", region_id);
    }

out:
    return is_valid;
}

static boolean_t __is_set_l4_port_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                               sx_flex_acl_flex_action_fields_t *action,
                                               sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(action);
    UNUSED_PARAM(region_id);

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG_ERR("Flex ACL set l4 port action is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_hash_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_hash.command >= SX_ACL_ACTION_HASH_COMMAND_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action HASH - invalid hash command : %u \n",
                   action->action_hash.command);
        goto out;
    }

    if (action->action_hash.type >= SX_ACL_ACTION_HASH_TYPE_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action HASH - invalid hash type : %u \n",
                   action->action_hash.type);
        goto out;
    }

    if (action->action_hash.command == SX_ACL_ACTION_HASH_COMMAND_CRC) {
        if (action->action_hash.hash_crc.field >= SX_ACL_ACTION_HASH_FIELD_LAST) {
            is_valid = FALSE;
            SX_LOG_ERR("Action HASH - invalid hash crc field: %u \n",
                       action->action_hash.hash_crc.field);
            goto out;
        }
        /* Spectrum1 does not support some of the fields */
        if ((g_acl_stage == ACL_STAGE_FLEX) &&
            ((action->action_hash.hash_crc.field >= SX_ACL_ACTION_HASH_FIELD_GP_REGISTER_0) ||
             (action->action_hash.hash_crc.field == SX_ACL_ACTION_HASH_FIELD_SIP) ||
             (action->action_hash.hash_crc.field == SX_ACL_ACTION_HASH_FIELD_SIPV6) ||
             (action->action_hash.hash_crc.field == SX_ACL_ACTION_HASH_FIELD_INNER_SIP) ||
             (action->action_hash.hash_crc.field == SX_ACL_ACTION_HASH_FIELD_INNER_SIPV6))) {
            is_valid = FALSE;
            SX_LOG_ERR("Action HASH - invalid hash crc field: %u for Spectrum-1\n",
                       action->action_hash.hash_crc.field);
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_alu_imm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_alu_imm.command >= SX_ACL_ACTION_ALU_IMM_COMMAND_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU immediate - invalid command : %u \n",
                   action->action_alu_imm.command);
        goto out;
    }

    if (action->action_alu_imm.imm_data_type >= SX_ACL_ACTION_ALU_IMM_TYPE_LAST_E) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU immediate - invalid data type : %u \n",
                   action->action_alu_imm.imm_data_type);
        goto out;
    }

    if (action->action_alu_imm.dst_register >= rm_resource_global.gp_register_num_max) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU immediate - invalid register : %u \n",
                   action->action_alu_imm.dst_register);
        goto out;
    }

    if (action->action_alu_imm.size == 0) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU immediate - size cannot be zero \n");
        goto out;
    }

    if (action->action_alu_imm.size + action->action_alu_imm.dst_offset > GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU immediate - dst_offset + size should not exceed register size of %zu\n",
                   GP_REGISTER_BITS_SIZE);
        goto out;
    }

    if (action->action_alu_imm.imm_data_type == SX_ACL_ACTION_ALU_IMM_TYPE_OBJECT_E) {
        if (action->action_alu_imm.imm_obj.obj_type >= SX_ACL_ACTION_ALU_IMM_OBJ_TYPE_LAST_E) {
            is_valid = FALSE;
            SX_LOG_ERR("Action ALU immediate - invalid obj type : %u \n",
                       action->action_alu_imm.imm_obj.obj_type);
            goto out;
        }

        if ((action->action_alu_imm.command != SX_ACL_ACTION_ALU_IMM_COMMAND_SET) &&
            (action->action_alu_imm.command != SX_ACL_ACTION_ALU_IMM_COMMAND_ADD)) {
            is_valid = FALSE;
            SX_LOG_ERR("Action ALU immediate - only add/set are supported for SX_ACL_ACTION_ALU_IMM_TYPE_OBJECT_E\n");
            goto out;
        }

        if (action->action_alu_imm.imm_obj.obj_type == SX_ACL_ACTION_ALU_IMM_OBJ_FLOW_COUNTER_TYPE_E) {
            if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
                SX_LOG_ERR("counter by ref is supported on Spectrum4 and above\n");
                is_valid = FALSE;
                goto out;
            }

            if (!flow_counter_is_counter_by_ref_type_base(action->action_alu_imm.imm_obj.obj_data.base_counter_id)) {
                SX_LOG_ERR("counter_id %u is not a counter by ref base id\n",
                           action->action_alu_imm.imm_obj.obj_data.base_counter_id);
                is_valid = FALSE;
                goto out;
            }
        }
    }

out:
    return is_valid;
}

static boolean_t __is_alu_reg_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_alu_reg.command >= SX_ACL_ACTION_ALU_REG_COMMAND_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - invalid command : %u \n",
                   action->action_alu_reg.command);
        goto out;
    }

    if (action->action_alu_reg.dst_register >= rm_resource_global.gp_register_num_max) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - invalid destination register : %u \n",
                   action->action_alu_reg.dst_register);
        goto out;
    }

    if (action->action_alu_reg.src_register >= rm_resource_global.gp_register_num_max) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - invalid source register : %u \n",
                   action->action_alu_reg.src_register);
        goto out;
    }

    if (action->action_alu_reg.size == 0) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - size cannot be zero \n");
        goto out;
    }

    if (action->action_alu_reg.size + action->action_alu_reg.dst_offset > GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - dst_offset + size should not exceed register size of %zu\n",
                   GP_REGISTER_BITS_SIZE);
        goto out;
    }

    if (action->action_alu_reg.size + action->action_alu_reg.src_offset > GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU register - src_offset + size should not exceed register size of %zu\n",
                   GP_REGISTER_BITS_SIZE);
        goto out;
    }


out:
    return is_valid;
}

static boolean_t __is_alu_field_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid = TRUE;
    uint32_t    sxd_field_select_count = 0;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_alu_field.command >= SX_ACL_ACTION_ALU_FIELD_COMMAND_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - invalid command : %u \n",
                   action->action_alu_field.command);
        goto out;
    }

    if (action->action_alu_field.dst_register >= rm_resource_global.gp_register_num_max) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - invalid destination register : %u \n",
                   action->action_alu_field.dst_register);
        goto out;
    }

    rc = flex_acl_hw_field_select_count_get(action->action_alu_field.src_field, &sxd_field_select_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Action ALU field - incorrect field : %u \n", action->action_alu_field.src_field);
        is_valid = FALSE;
        goto out;
    }

    if (action->action_alu_field.size == 0) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - size cannot be zero \n");
        goto out;
    }

    if (action->action_alu_field.size + action->action_alu_field.dst_offset > GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - dst_offset + size should not exceed register size of %zu\n",
                   GP_REGISTER_BITS_SIZE);
        goto out;
    }

    if (action->action_alu_field.src_field_offset + action->action_alu_field.size > sxd_field_select_count *
        GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - src field [%u] offset + size [%u] is larger than the field size [%zu]\n",
                   action->action_alu_field.src_field,
                   action->action_alu_field.src_field_offset + action->action_alu_field.size,
                   sxd_field_select_count * GP_REGISTER_BITS_SIZE);
        goto out;
    }
    /* We can work with the field in 16 bit chucks and the field cannot traverse two chunks */
    if ((action->action_alu_field.src_field_offset % GP_REGISTER_BITS_SIZE) + action->action_alu_field.size >
        GP_REGISTER_BITS_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action ALU field - src field offset + size should stay in register size limit of %zu\n",
                   GP_REGISTER_BITS_SIZE);
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_register_access_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid = TRUE;
    uint32_t    i = 0;
    uint32_t    sxd_field_select_count = 0;
    boolean_t   is_parallel = FALSE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_register_access.command >= SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LAST) {
        is_valid = FALSE;
        SX_LOG_ERR("Action register access - invalid command : %u \n",
                   action->action_register_access.command);
        goto out;
    }

    if ((action->action_register_access.list_size > FLEX_ACTION_REGISTER_ACCESS_LIST_SIZE) ||
        (action->action_register_access.list_size == 0)) {
        is_valid = FALSE;
        SX_LOG_ERR("Action register access - register list size %u is not supported. Must not exceed %u or be zero.\n",
                   action->action_register_access.list_size, FLEX_ACTION_REGISTER_ACCESS_LIST_SIZE);
        goto out;
    }
    /* Check the register numbers are OK */
    for (i = 0; i < action->action_register_access.list_size; i++) {
        if (action->action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_LOAD) {
            if (action->action_register_access.src_register_list[i] >= rm_resource_global.gp_register_num_max) {
                is_valid = FALSE;
                SX_LOG_ERR("Action register access - invalid source register : %u \n",
                           action->action_register_access.src_register_list[i]);
                goto out;
            }
        }
        if (action->action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE) {
            if (action->action_register_access.dst_register_list[i] >= rm_resource_global.gp_register_num_max) {
                is_valid = FALSE;
                SX_LOG_ERR("Action register access - invalid destination register : %u \n",
                           action->action_register_access.dst_register_list[i]);
                goto out;
            }
        }
    }
    /* Validate the field we use is valid */
    if (action->action_register_access.command != SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_COPY) {
        rc = flex_acl_hw_field_select_count_get(action->action_register_access.field, &sxd_field_select_count);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Action register access - incorrect field : %u \n", action->action_register_access.field);
            is_valid = FALSE;
            goto out;
        }

        rc = flex_acl_db_get_is_parallel(&is_parallel);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Action register access - failed getting parallel mode\n");
            is_valid = FALSE;
            goto out;
        }
        /* Some of the fields are not valid for the store action or if we're working in parallel mode*/
        if (is_parallel || (action->action_register_access.command == SX_ACL_ACTION_REGISTER_ACCESS_COMMAND_STORE)) {
            switch (action->action_register_access.field) {
            case SX_FLEX_ACL_FIELD_SELECT_ECMP_HASH:
            case SX_FLEX_ACL_FIELD_SELECT_LAG_HASH:
            case SX_FLEX_ACL_FIELD_SELECT_RANDOM:
            case SX_FLEX_ACL_FIELD_SELECT_IP_LENGTH:
            case SX_FLEX_ACL_FIELD_SELECT_VID:
            case SX_FLEX_ACL_FIELD_SELECT_USER_TOKEN:
            case SX_FLEX_ACL_FIELD_SELECT_PORT_USER_MEMORY:
            case SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_0_OFFSET:
            case SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_1_OFFSET:
                SX_LOG_ERR("Action register access - field: %u is not supported for store or parallel operation\n",
                           action->action_register_access.field);
                is_valid = FALSE;
                goto out;
                break;

            default:
                is_valid = TRUE;
                break;
            }
        }
        /* We only support offsets which are a multiply of a register size. */
        if (action->action_register_access.field_offset % GP_REGISTER_BITS_SIZE != 0) {
            SX_LOG_ERR("Action register access - field offset should be a multiply of: %zu\n", GP_REGISTER_BITS_SIZE);
            is_valid = FALSE;
            goto out;
        }
        /* Check that the size of the field matches that of the registers we want to load/store. */
        if (((uint32_t)action->action_register_access.list_size * GP_REGISTER_BITS_SIZE +
             (uint32_t)action->action_register_access.field_offset) >
            (sxd_field_select_count * GP_REGISTER_BITS_SIZE)) {
            SX_LOG_ERR("Action register access - field %u it too small for this operation\n",
                       action->action_register_access.field);
            is_valid = FALSE;
            goto out;
        }
    }


out:
    return is_valid;
}

static boolean_t __is_field_action_valid(sx_flex_acl_register_field_select_t field,
                                         uint8_t                             field_offset,
                                         uint8_t                             field_count,
                                         boolean_t                           is_destination)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    boolean_t         is_valid = TRUE;
    uint32_t          sxd_field_select_count = 0;
    boolean_t         is_parallel = FALSE;
    boolean_t         is_allocated = FALSE;
    sx_register_key_t reg_key;

    /* Get the maximum size of this field */
    rc = flex_acl_hw_field_select_count_get(field, &sxd_field_select_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Action field - incorrect field : %u \n", field);
        is_valid = FALSE;
        goto out;
    }

    /* Check that the offset is aligned to a two byte word */
    if (field_offset % FIELDS_SELECT_SIZE != 0) {
        SX_LOG_ERR("Action field - field offset is %u, should be a multiply of %u\n",
                   field_offset,
                   FIELDS_SELECT_SIZE);
        is_valid = FALSE;
        goto out;
    }

    /* Check that the size of the field matches the size we want to use. */
    if (((uint32_t)field_count * FIELDS_SELECT_SIZE + (uint32_t)field_offset) >
        (sxd_field_select_count * FIELDS_SELECT_SIZE)) {
        SX_LOG_ERR("Action field - field %u it too small for this operation\n",
                   field);
        is_valid = FALSE;
        goto out;
    }

    rc = flex_acl_db_get_is_parallel(&is_parallel);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Action field immediate - failed getting parallel mode\n");
        is_valid = FALSE;
        goto out;
    }

    /* Some of the fields are not valid for the store action or if we're working in parallel mode*/
    switch (field) {
    case SX_FLEX_ACL_FIELD_SELECT_ECMP_HASH:
    case SX_FLEX_ACL_FIELD_SELECT_LAG_HASH:
    case SX_FLEX_ACL_FIELD_SELECT_RANDOM:
    case SX_FLEX_ACL_FIELD_SELECT_IP_LENGTH:
    case SX_FLEX_ACL_FIELD_SELECT_VID:
        if (is_destination) {
            is_valid = FALSE;
        }

    /* no break */
    /* fall through */
    case SX_FLEX_ACL_FIELD_SELECT_USER_TOKEN:
    case SX_FLEX_ACL_FIELD_SELECT_PORT_USER_MEMORY:
    case SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_0_OFFSET:
    case SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_1_OFFSET:
    case SX_FLEX_ACL_FIELD_SELECT_TRAP_USER_ID:
        if ((is_valid == FALSE) || is_parallel) {
            if (is_parallel) {
                SX_LOG_ERR("Action field: %u is not supported for parallel operation\n", field);
            }
            if (is_valid == FALSE) {
                SX_LOG_ERR("Action field: %u is not supported for destination operation\n", field);
            }

            is_valid = FALSE;
            goto out;
        }
        break;

    default:
        is_valid = TRUE;
        break;
    }


    if ((field == SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_0_OFFSET) ||
        (field == SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_1_OFFSET)) {
        SX_MEM_CLR(reg_key);
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
        reg_key.key.gp_reg.reg_id = field - SX_FLEX_ACL_FIELD_SELECT_GP_REGISTER_0_OFFSET;

        rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
        if ((rc != SX_STATUS_SUCCESS) || (is_allocated == FALSE)) {
            SX_LOG_ERR("Action field - GP register [%u] is not allocated.\n",
                       reg_key.key.gp_reg.reg_id);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_field_imm_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                             sx_flex_acl_flex_action_fields_t *action,
                                             sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (action->action_field_imm.list_size > FLEX_ACTION_FIELD_IMM_LIST_SIZE) {
        is_valid = FALSE;
        SX_LOG_ERR("Action field immediate - list size %u is not supported. Must not exceed %u.\n",
                   action->action_field_imm.list_size, FLEX_ACTION_FIELD_IMM_LIST_SIZE);
        goto out;
    }

    /* Go to the common verification function */
    is_valid = __is_field_action_valid(action->action_field_imm.dst_field,
                                       action->action_field_imm.field_offset,
                                       action->action_field_imm.list_size,
                                       TRUE);
    if (is_valid == FALSE) {
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_field_copy_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    /* Check that the size is an even number */
    if ((action->action_field_copy.size & 0x1) != 0) {
        is_valid = FALSE;
        SX_LOG_ERR("Action field copy - size is in bytes and a multiple of 2. Configured value %u.\n",
                   action->action_field_copy.size);
        goto out;
    }

    /* Go to the common verification function */
    is_valid = __is_field_action_valid(action->action_field_copy.dst_field,
                                       action->action_field_copy.dst_field_offset,
                                       action->action_field_copy.size / 2,
                                       TRUE);
    if (is_valid == FALSE) {
        goto out;
    }

    /* Go to the common verification function */
    is_valid = __is_field_action_valid(action->action_field_copy.src_field,
                                       action->action_field_copy.src_field_offset,
                                       action->action_field_copy.size / 2,
                                       FALSE);
    if (is_valid == FALSE) {
        goto out;
    }

out:
    return is_valid;
}

static sx_status_t __flex_acl_infinite_loop_validate(sx_acl_id_t target_group_id,
                                                     sx_acl_id_t src_acl_id,
                                                     sx_acl_id_t group_id_to_edit)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                    curr_group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_group_t       *acl_group = NULL;
    uint32_t                       rule_i = 0, acl_i = 0;
    flex_acl_db_acl_table_t       *acl_table = NULL;
    sx_flex_acl_flex_action_goto_t goto_action;
    boolean_t                      is_found = FALSE;
    sx_acl_id_t                   *group_id_cont = NULL;
    cl_list_iterator_t             iter, list_head, list_end;
    sx_acl_id_t                    group_head_id;
    sx_acl_id_t                    first_goto_target;
    boolean_t                      is_set = FALSE;
    sx_acl_id_t                    head_group_id_to_edit;
    flex_acl_db_acl_region_t      *acl_region = NULL;

    SX_LOG_ENTER();

    /* get bound to region acl */
    rc = flex_acl_db_acl_get(src_acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed get acl id[%x], rc = %s\n", src_acl_id, sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_get_groups_head(target_group_id, &first_goto_target);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get head of acl group[%x]\n", target_group_id);
        goto out;
    }
    if (first_goto_target != target_group_id) {
        SX_LOG_ERR("the target group_id are not head of groups\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* set up vector of forbidden groups */
    rc = flex_acl_db_id_bitmap_clear(&flex_acl_goto_validation_params.forbidden_groups_map);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to set up validation map for target group_id[%x]\n", target_group_id);
        goto out;
    }
    /* if call from edit acl group flow - should add edited group to forbidden list */
    if (group_id_to_edit != FLEX_ACL_INVALID_ACL_ID) {
        rc = flex_acl_db_get_groups_head(group_id_to_edit, &head_group_id_to_edit);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get head of acl group[%x]\n", group_id_to_edit);
            goto out;
        }
        /* set up self loop group id to be forbidden */
        rc =
            flex_acl_db_id_bitmap_set(&flex_acl_goto_validation_params.forbidden_groups_map, GET_ACL_GROUP_IDX(
                                          head_group_id_to_edit));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to reset stack for target group_id[%x]\n", target_group_id);
            goto out;
        }
    }
    list_head = cl_list_head(&acl_table->bound_group_list);
    list_end = cl_list_end(&acl_table->bound_group_list);
    for (iter = list_head;
         iter != list_end;
         iter = cl_list_next(iter)) {
        group_id_cont = cl_list_obj(iter);
        rc = flex_acl_db_get_groups_head(*group_id_cont, &group_head_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get head of acl group[%x]\n", *group_id_cont);
            goto out;
        }
        rc =
            flex_acl_db_id_bitmap_set(&flex_acl_goto_validation_params.forbidden_groups_map, GET_ACL_GROUP_IDX(
                                          group_head_id));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to set bitmap for target group_id[%x]\n", target_group_id);
            goto out;
        }
    }

    /* check self loop, when goto action points to contain goto action group */
    rc =
        flex_acl_db_id_bitmap_get(&flex_acl_goto_validation_params.forbidden_groups_map, GET_ACL_GROUP_IDX(
                                      target_group_id), &is_set);
    if (rc != SX_STATUS_SUCCESS) {
        /* print group id and acl id */
        SX_LOG_ERR("failed to get id list for group id[%x], rc = %s\n", goto_action.acl_group_id, sx_status_str(rc));
        goto out;
    }
    if (is_set) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Exist loop in goto JUMP/CALL chain. The target group id[%x] points to itself \n", target_group_id);
        goto out;
    }

    /* clear stack */
    rc = flex_acl_db_id_stack_reset(&flex_acl_goto_validation_params.groups_to_visit_stack);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to reset stack for target group_id[%x]\n", target_group_id);
        goto out;
    }
    /* clear visited groups */
    rc = flex_acl_db_id_bitmap_clear(&flex_acl_goto_validation_params.groups_to_visit_map);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to clear validation map for target group_id[%x]\n", target_group_id);
        goto out;
    }

    while (target_group_id != FLEX_ACL_INVALID_ACL_ID) {
        curr_group_id = target_group_id;
        /* iterate on groups in chain */
        while (curr_group_id != FLEX_ACL_INVALID_ACL_ID) {
            rc = flex_acl_db_get_acl_group(curr_group_id, &acl_group);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed get acl target_group_id[%x]\n", curr_group_id);
                goto out;
            }
            /* iterate on acls in groups. current group id can be only head */
            for (acl_i = 0; acl_i < acl_group->acl_num; acl_i++) {
                rc = flex_acl_db_acl_get(acl_group->acl_ids[acl_i], &acl_table);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("failed get acl id[%x], rc = %s\n", acl_group->acl_ids[acl_i], sx_status_str(rc));
                    goto out;
                }
                rc = flex_acl_db_region_get(acl_table->bound_region, &acl_region);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("failed get acl region id[%x], rc = %s\n", acl_table->bound_region, sx_status_str(rc));
                    goto out;
                }

                /* iterate on acl rules */
                for (rule_i = 0; rule_i < acl_region->size; rule_i++) {
                    rc = flex_acl_db_rule_get_goto_action(&acl_region->rules[rule_i], &is_found, &goto_action);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("failed get goto action from rule offset[%u], region id[%x], rc = %s\n",
                                   rule_i,
                                   acl_table->bound_region,
                                   sx_status_str(rc));
                        goto out;
                    }
                    if (is_found &&
                        ((goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
                         (goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL))) {
                        rc = flex_acl_db_id_bitmap_get(&flex_acl_goto_validation_params.forbidden_groups_map,
                                                       GET_ACL_GROUP_IDX(goto_action.acl_group_id),
                                                       &is_set);
                        if (rc != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR("failed to set id list for group id[%x], rc = %s\n",
                                       goto_action.acl_group_id,
                                       sx_status_str(rc));
                            goto out;
                        }
                        if (is_set) {
                            rc = SX_STATUS_PARAM_ERROR;
                            SX_LOG_ERR(
                                "Exist loop in goto JUMP/CALL chain. The target group id[%x] points to one of containing source acl id[%x] groups \n",
                                goto_action.acl_group_id,
                                src_acl_id);
                            goto out;
                        }
                        /* check that group not visited  */
                        rc = flex_acl_db_id_bitmap_get(&flex_acl_goto_validation_params.groups_to_visit_map,
                                                       GET_ACL_GROUP_IDX(goto_action.acl_group_id),
                                                       &is_set);
                        if (rc != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR("failed to set id list for group id[%x], rc = %s\n",
                                       goto_action.acl_group_id,
                                       sx_status_str(rc));
                            goto out;
                        }
                        if (!is_set) {
                            rc = flex_acl_db_id_bitmap_set(&flex_acl_goto_validation_params.groups_to_visit_map,
                                                           GET_ACL_GROUP_IDX(goto_action.acl_group_id));
                            if (rc != SX_STATUS_SUCCESS) {
                                SX_LOG_ERR("failed to set id list for group id[%x], rc = %s\n",
                                           goto_action.acl_group_id,
                                           sx_status_str(rc));
                                goto out;
                            }
                            rc = flex_acl_db_id_stack_push(&flex_acl_goto_validation_params.groups_to_visit_stack,
                                                           goto_action.acl_group_id);
                            if (rc != SX_STATUS_SUCCESS) {
                                SX_LOG_ERR("failed to set id list for group id[%x], rc = %s\n",
                                           goto_action.acl_group_id,
                                           sx_status_str(rc));
                                goto out;
                            }
                        }
                    }
                }
            }
            curr_group_id = acl_group->next_acl_group_id;
        } /* while (target_group_id != FLEX_ACL_INVALID_ACL_ID) */
          /* get not visited group */
        rc = flex_acl_db_id_stack_pop(&flex_acl_goto_validation_params.groups_to_visit_stack, &target_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed at infinite loop validation, err[%s]\n", sx_status_str(rc));
            goto out;
        }
    } /* while (target_group_id != FLEX_ACL_INVALID_ACL_ID){ */


out:
    SX_LOG_EXIT();
    return rc;
}

/* validate that group direction and region direction are the same */
static sx_status_t __is_same_direction(sx_acl_id_t target_group_id, sx_acl_id_t src_acl_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table_p = NULL;
    flex_acl_db_acl_group_t *acl_group_p = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(target_group_id, &acl_group_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", target_group_id);
        goto out;
    }

    rc = flex_acl_db_acl_get(src_acl_id, &acl_table_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get acl table error, acl id[%d]\n", src_acl_id);
        goto out;
    }

    if (acl_table_p->direction != SX_ACL_DIRECTION_MULTI_POINTS_E) {
        if (acl_group_p->direction != acl_table_p->direction) {
            SX_LOG_ERR("Goto Target Group[%x] direction[%u] different from contain goto acl[%x] direction[%u]!\n",
                       target_group_id, acl_group_p->direction, src_acl_id, acl_table_p->direction);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        if ((acl_table_p->acl_attributes.multi_direction.acl_direction_bitmap & (1 << acl_group_p->direction)) == 0) {
            SX_LOG_ERR(
                "Goto Target Group[%x] direction[%u] different from contain goto acl[%x] direction bitmap [%x] !\n",
                target_group_id,
                acl_group_p->direction,
                src_acl_id,
                acl_table_p->acl_attributes.multi_direction.acl_direction_bitmap);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __is_region_target_group_member(sx_acl_region_id_t region_id, boolean_t *is_target_member)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_target = FALSE;
    flex_acl_db_acl_region_t *region_p = NULL;
    flex_acl_db_acl_table_t  *acl_table = NULL;
    cl_list_iterator_t        iter, list_head, list_end;
    sx_acl_id_t              *group_id_cont = NULL;
    sx_acl_id_t               group_head_id = FLEX_ACL_INVALID_ACL_ID;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(region_id, &region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", region_id);
        goto out;
    }
    rc = flex_acl_db_acl_get(region_p->bound_acl, &acl_table);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get acl table error, acl id[%d]\n", region_p->bound_acl);
        goto out;
    }
    list_head = cl_list_head(&(acl_table->bound_group_list));
    list_end = cl_list_end(&(acl_table->bound_group_list));
    for (iter = list_head;
         iter != list_end;
         iter = cl_list_next(iter)) {
        group_id_cont = cl_list_obj(iter);
        rc = flex_acl_db_get_groups_head(*group_id_cont, &group_head_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get head of acl group[%x]\n", *group_id_cont);
            goto out;
        }
        rc = __is_acl_group_goto_call_target(group_head_id, &is_target);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get if acl group is goto target, group_id[%x]\n", group_head_id);
            goto out;
        } else if (is_target) {
            *is_target_member = TRUE;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __is_goto_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_valid = TRUE;
    sx_acl_id_t               group_head_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                 is_contain = FALSE;
    boolean_t                 is_member = FALSE;
    flex_acl_db_acl_region_t *region_p = NULL;

    UNUSED_PARAM(action_type);

    rc = flex_acl_db_region_get(region_id, &region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", region_id);
        goto out;
    }


    switch (action->action_goto.goto_action_cmd) {
    case SX_ACL_ACTION_GOTO_JUMP:
        if (region_p->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
            /* validate goto target group and contain rule region are in same direction */
            rc = __is_same_direction(action->action_goto.acl_group_id, region_p->bound_acl);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed at direction validation for goto target group[%x]\n",
                           action->action_goto.acl_group_id);
                is_valid = FALSE;
                goto out;
            }
        }

        /* check that target group is group head */
        rc = flex_acl_db_get_groups_head(action->action_goto.acl_group_id, &group_head_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get head of groups chain for group[%x]\n", action->action_goto.acl_group_id);
            is_valid = FALSE;
            goto out;
        }
        if (group_head_id != action->action_goto.acl_group_id) {
            SX_LOG_ERR("Target goto group[%x] are not head[%x] of group chain\n",
                       action->action_goto.acl_group_id,
                       group_head_id);
            is_valid = FALSE;
            goto out;
        }

        rc = __flex_acl_infinite_loop_validate(action->action_goto.acl_group_id,
                                               region_p->bound_acl,
                                               FLEX_ACL_INVALID_ACL_ID);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed validation of infinite loop existence, group_id[%x]\n",
                       action->action_goto.acl_group_id);
            is_valid = FALSE;
            goto out;
        }

        break;

    case SX_ACL_ACTION_GOTO_CALL:
        if (region_p->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
            /* validate goto target group and contain rule region are in same direction */
            rc = __is_same_direction(action->action_goto.acl_group_id, region_p->bound_acl);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed at direction validation for goto target group[%x]\n",
                           action->action_goto.acl_group_id);
                is_valid = FALSE;
                goto out;
            }
        }

        /* check that target group is group head */
        rc = flex_acl_db_get_groups_head(action->action_goto.acl_group_id, &group_head_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get head of groups chain for group[%x]\n", action->action_goto.acl_group_id);
            is_valid = FALSE;
            goto out;
        } else if (group_head_id != action->action_goto.acl_group_id) {
            SX_LOG_ERR("Target goto group[%x] are not head[%x] of group chain\n",
                       action->action_goto.acl_group_id,
                       group_head_id);
            is_valid = FALSE;
            goto out;
        }

        /* check that target group does not have any region rule with goto action */
        rc = __is_group_chain_contain_goto_call(group_head_id, &is_contain);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get if group chain contain jump call, groups head[%x]\n", group_head_id);
            is_valid = FALSE;
            goto out;
        } else if (is_contain) {
            SX_LOG_ERR("Target group chain of GOTO group[%x] contain jump call\n", action->action_goto.acl_group_id);
            is_valid = FALSE;
            goto out;
        }

        /* check that region not belong to any other target group */
        rc = __is_region_target_group_member(region_id, &is_member);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get if region id[%x] are target group member\n", region_id);
            is_valid = FALSE;
            goto out;
        } else if (is_member) {
            SX_LOG_ERR("the region id[%x] are target group member\n", region_id);
            is_valid = FALSE;
            goto out;
        }

        /* check that go to action not creates infinite loop at execution */
        rc = __flex_acl_infinite_loop_validate(action->action_goto.acl_group_id,
                                               region_p->bound_acl,
                                               FLEX_ACL_INVALID_ACL_ID);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed validation of infinite loop existence, group_id[%x]\n",
                       action->action_goto.acl_group_id);
            is_valid = FALSE;
            goto out;
        }
        break;


    case SX_ACL_ACTION_GOTO_BREAK:
        break;

    case SX_ACL_ACTION_GOTO_TERMINATE:
        break;

    default:
        is_valid = FALSE;
        SX_LOG_ERR("Goto command :[%u] is invalid\n", action->action_goto.goto_action_cmd);
        break;
    }
out:
    return is_valid;
}

static boolean_t __is_set_router_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                              sx_flex_acl_flex_action_fields_t *action,
                                              sx_acl_region_id_t                region_id)
{
    boolean_t              is_valid = TRUE;
    sx_router_attributes_t router_attr;
    sx_status_t            rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = sdk_router_vrid_impl_get(action->action_set_router.vrid, &router_attr);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get VRID %u from router dev. err %s.\n",
                   action->action_set_router.vrid, sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_user_token_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id)
{
    boolean_t                 is_valid = TRUE;
    flex_acl_db_acl_region_t *acl_region_p;
    sx_status_t               rc;

    UNUSED_PARAM(action_type);

    SX_LOG_ENTER();

    /* Check system ACL */
    rc = flex_acl_db_region_get(region_id, &acl_region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", region_id);
        is_valid = FALSE;
        goto out;
    }
    if (acl_region_p->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        if (action->action_set_user_token.mask & ACL_SYSTEM_TOKEN_MASK) {
            SX_LOG_ERR("User token mask is invalid, Max Mask value :%x\n", ACL_USER_TOKEN_MASK);
            is_valid = FALSE;
            goto out;
        }
        if (action->action_set_user_token.user_token & ACL_SYSTEM_TOKEN_MASK) {
            SX_LOG_ERR("User token value is invalid, Max value :%x\n", ACL_USER_TOKEN_MASK);
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_mc_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                      sx_flex_acl_flex_action_fields_t *action,
                                      sx_acl_region_id_t                region_id)
{
    boolean_t                    is_valid = TRUE;
    uint32_t                     next_hop_cnt;
    sx_mc_container_attributes_t attr;
    mc_container_owner_type_t    type;
    sx_status_t                  rc;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    rc = sdk_mc_container_impl_get(action->action_mc.mc_container_id, NULL, &next_hop_cnt, &attr, &type);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("MC Action : Invalid MC id:%u  err %s.\n", action->action_mc.mc_container_id, sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }
    if (attr.type != SX_MC_CONTAINER_TYPE_BRIDGE_MC) {
        SX_LOG_ERR("MC Action : Invalid MC type %u . Only SX_MC_CONTAINER_TYPE_BRIDGE_MC type is valid \n", attr.type);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_elephant_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                sx_flex_acl_flex_action_fields_t *action,
                                                sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG_ERR("Flex ACL set elephant flow action is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_set_elephant_flow_type.action != SX_ACL_ACTION_SET_ELEPHANT_FLOW_E) &&
        (action->action_set_elephant_flow_type.action != SX_ACL_ACTION_SET_NON_ELEPHANT_FLOW_E)) {
        SX_LOG_ERR("set elephant flow action, elephant flow %u is not valid \n",
                   action->action_set_elephant_flow_type.action);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_ar_packet_prof_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG_ERR("Flex ACL AR packet profile id action is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    if (action->action_ar_packet_profile.ar_packet_profile_type > SX_AR_CLASSIFIER_ACTION_MAX_E) {
        SX_LOG_ERR("AR packet profile id action %u is not valid \n",
                   action->action_ar_packet_profile.ar_packet_profile_type);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_emt_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                           sx_flex_acl_flex_action_fields_t *action,
                                           sx_acl_region_id_t                region_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid = TRUE;
    uint32_t    i = 0;
    boolean_t   emt_index_exists[SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E] = {FALSE};

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG_ERR("Flex ACL set EMT action is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    for (i = 0; i < SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E; i++) {
        /* If the bind type is nop we just ignore all other configurations */
        if (action->action_set_emt.emt_bind_action[i].emt_bind_type != SX_FLEX_MODIFIER_BIND_TYPE_NOP_E) {
            /* Check that the action index is ok */
            if (action->action_set_emt.emt_bind_action[i].emt_bind_index >= SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E) {
                SX_LOG_ERR("Flex ACL set EMT bind index [%u] is not valid\n",
                           action->action_set_emt.emt_bind_action[i].emt_bind_index);
                is_valid = FALSE;
                goto out;
            }
            /* Check if the same action index was already used */
            if (emt_index_exists[action->action_set_emt.emt_bind_action[i].emt_bind_index]) {
                SX_LOG_ERR("Flex ACL set EMT: same index [%u] cannot be used twice\n",
                           action->action_set_emt.emt_bind_action[i].emt_bind_index);
                is_valid = FALSE;
                goto out;
            }
            /* Check that the bind type is ok */
            if (action->action_set_emt.emt_bind_action[i].emt_bind_type >= SX_FLEX_MODIFIER_BIND_TYPE_LAST_E) {
                SX_LOG_ERR("Flex ACL set EMT bind type [%u] is not valid\n",
                           action->action_set_emt.emt_bind_action[i].emt_bind_type);
                is_valid = FALSE;
                goto out;
            }
            if ((action->action_set_emt.emt_bind_action[i].emt_bind_type == SX_FLEX_MODIFIER_BIND_TYPE_POP_E) &&
                !ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
                SX_LOG_ERR("Flex ACL set EMT bind type POP is not valid for this chip type\n");
                is_valid = FALSE;
                goto out;
            }
            /* Validate that the EMT exists and valid for this operation */
            rc = flex_modifier_validate_emt_bind(
                action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_id.emt_id,
                action->action_set_emt.emt_bind_action[i].emt_bind_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Flex ACL set EMT [%u] is not valid for bind type [%u]\n",
                           action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_id.emt_id,
                           action->action_set_emt.emt_bind_action[i].emt_bind_type);
                is_valid = FALSE;
                goto out;
            }
            /* Check the offset fields are valid */
            if (action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset_type ==
                SX_FLEX_MODIFIER_OFFSET_TYPE_GP_REGISTER_E) {
                /* Check that the offset is correct */
                if ((action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset !=
                     SX_FLEX_MODIFIER_GP_REGISTER_0_OFFSET_E) &&
                    (action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset !=
                     SX_FLEX_MODIFIER_GP_REGISTER_1_OFFSET_E)) {
                    SX_LOG_ERR("Flex ACL set EMT [%u] offset [%u] is not valid for bind\n",
                               action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_id.emt_id,
                               action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset);
                    is_valid = FALSE;
                    goto out;
                }
            } else if ((action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset_type ==
                        SX_FLEX_MODIFIER_OFFSET_TYPE_ENCAP_HEADER_E) &&
                       ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
                if (action->action_set_emt.emt_bind_action[i].emt_bind_type == SX_FLEX_MODIFIER_BIND_TYPE_POP_E) {
                    SX_LOG_ERR("Flex ACL set EMT pop action is not valid for encapsulating header\n");
                    is_valid = FALSE;
                    goto out;
                }
                if (action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.encap_header
                    >= SX_FLEX_MODIFIER_HEADER_ENCAP_LAST_E) {
                    SX_LOG_ERR("Flex ACL set EMT encap header type [%u] is not valid\n",
                               action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.encap_header);
                    is_valid = FALSE;
                    goto out;
                }
                if ((action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.offset >
                     EMT_ENCAP_OFFSET_MAX) ||
                    ((action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.offset &
                      0x3) != 0)) {
                    SX_LOG_ERR(
                        "Flex ACL set EMT encap header offset [%u] is not valid. Should be up to 60 and multiple of 4.\n",
                        action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_encap_header_offset.offset);
                    is_valid = FALSE;
                    goto out;
                }
            } else {
                SX_LOG_ERR("Flex ACL set EMT - Offset type [%u] is not valid.\n",
                           action->action_set_emt.emt_bind_action[i].emt_bind_type_attr.emt_offset_type);
                is_valid = FALSE;
                goto out;
            }

            /* Indicate that this index is already in use */
            emt_index_exists[action->action_set_emt.emt_bind_action[i].emt_bind_index] = TRUE;
        }
    }

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        /* Spectrum2 & Spectrum3 do not support two push operations */
        if ((action->action_set_emt.emt_bind_action[0].emt_bind_type == SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E) &&
            (action->action_set_emt.emt_bind_action[1].emt_bind_type == SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E)) {
            SX_LOG_ERR("Flex ACL set EMT - both indexes cannot be push operation.\n");
            is_valid = FALSE;
            goto out;
        }
    }

out:
    return is_valid;
}

static boolean_t __is_set_buffer_snap_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                   sx_flex_acl_flex_action_fields_t *action,
                                                   sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(action);
    UNUSED_PARAM(region_id);

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        SX_LOG_ERR("Flex ACL set buffer snapshot is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_0_E, action->action_set_buffer_snap.sb_snap_id,
                        SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_7_E)) {
        SX_LOG_ERR("Invalid trigger type of snap ID [%u]\n", action->action_set_buffer_snap.sb_snap_id);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_mirror_trigger_disallow_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                           sx_flex_acl_flex_action_fields_t *action,
                                                           sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        SX_LOG_ERR("Flex ACL mirror trigger disallow is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    if (!SX_CHECK_MAX(action->action_mirror_disallow.cfg_list.mirror_trigger_disallow_cnt,
                      SX_SPAN_MIRROR_BIND_TYPE_MAX_E + 1)) {
        SX_LOG_ERR("Invalid mirror trigger disallow setting count [%u]\n",
                   action->action_mirror_disallow.cfg_list.mirror_trigger_disallow_cnt);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_flow_estimator_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                  sx_flex_acl_flex_action_fields_t *action,
                                                  sx_acl_region_id_t                region_id)
{
    boolean_t   is_valid = TRUE;
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (!ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        SX_LOG_ERR("Flex ACL flow estimator is not supported by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    rc = flow_counter_is_exists(action->action_flow_estimator.counter.base_counter_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flow Counter ID: [%u] does not exist, rc:[%s]\n",
                   action->action_flow_estimator.counter.base_counter_id,
                   sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

    rc = flow_estimator_profile_is_exists(&(action->action_flow_estimator.profile_key));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flow Estimator Profile ID: [%u] does not exist, rc:[%s]\n",
                   action->action_flow_estimator.profile_key.profile_id,
                   sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

    /* check whether the array of flow estimator counters match the profile */
    rc = flow_estimator_counter_is_matching_profile(action->action_flow_estimator.counter.base_counter_id,
                                                    &(action->action_flow_estimator.profile_key),
                                                    &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flow Counter ID [%u] does not match Flow Estimator Profile ID [%u], rc:[%s]\n",
                   action->action_flow_estimator.counter.base_counter_id,
                   action->action_flow_estimator.profile_key.profile_id,
                   sx_status_str(rc));
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_nat_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                       sx_flex_acl_flex_action_fields_t *action,
                                       sx_acl_region_id_t                region_id)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    boolean_t            is_valid = TRUE;
    sx_router_nat_type_e nat_type = 0;
    boolean_t            is_parallel = FALSE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    if (!ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage)) {
        SX_LOG_ERR("Flex ACL NAT IPv4/IPv6 is not allowed by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    rc = flex_acl_db_get_is_parallel(&is_parallel);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("NAT IPv4/IPv6 - failed getting parallel mode\n");
        is_valid = FALSE;
        goto out;
    }

    if (is_parallel) {
        SX_LOG_ERR("NAT IPv4/IPv6 ACL actions is not supported in parallel mode\n");
        is_valid = FALSE;
        goto out;
    }

    if (sdk_nat_4to6_type_get(action->action_nat.nat_id, &nat_type) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("NAT IPv4/IPv6 [%u] is not valid for Flex ACL action\n", action->action_nat.nat_id);
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_nat.dip.version != SX_IP_VERSION_NONE) &&
        (action->action_nat.dip.version != SX_IP_VERSION_IPV4) &&
        (action->action_nat.dip.version != SX_IP_VERSION_IPV6)) {
        SX_LOG_ERR("NAT IPv4/IPv6 [%u], DIP version [%s] is not valid for Flex ACL action\n",
                   action->action_nat.nat_id,
                   sx_ip_version_str(action->action_nat.dip.version));
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_nat.sip.version != SX_IP_VERSION_NONE) &&
        (action->action_nat.sip.version != SX_IP_VERSION_IPV4) &&
        (action->action_nat.sip.version != SX_IP_VERSION_IPV6)) {
        SX_LOG_ERR("NAT IPv4/IPv6 [%u], SIP version [%s] is not valid for Flex ACL action\n",
                   action->action_nat.nat_id,
                   sx_ip_version_str(action->action_nat.sip.version));
        is_valid = FALSE;
        goto out;
    }

    if (nat_type == SX_ROUTER_NAT_TYPE_6TO4_E) {
        if ((action->action_nat.sip.version == SX_IP_VERSION_IPV6) ||
            (action->action_nat.dip.version == SX_IP_VERSION_IPV6)) {
            SX_LOG_ERR("NAT IPv4 [%u], cannot support IPv6 Flex ACL action\n",
                       action->action_nat.nat_id);
            is_valid = FALSE;
            goto out;
        }
    }

    if (nat_type == SX_ROUTER_NAT_TYPE_4TO6_E) {
        if ((action->action_nat.sip.version == SX_IP_VERSION_IPV4) ||
            (action->action_nat.dip.version == SX_IP_VERSION_IPV4)) {
            SX_LOG_ERR("NAT IPv6 [%u], cannot support IPv4 Flex ACL action\n",
                       action->action_nat.nat_id);
            is_valid = FALSE;
            goto out;
        }
    }


out:
    return is_valid;
}

static boolean_t __is_stateful_db_valid(sx_flex_acl_flex_action_type_t    action_type,
                                        sx_flex_acl_flex_action_fields_t *action,
                                        sx_acl_region_id_t                region_id)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    boolean_t                   is_valid = TRUE;
    sx_register_key_t           reg_key;
    uint32_t                    i = 0;
    boolean_t                   is_allocated = FALSE;
    sx_stateful_db_attributes_t stateful_attr;
    static sx_gp_register_e     register_sets[][GP_REGISTER_SET_SIZE] = {
        [SX_STATEFUL_DB_GP_REGISTER_SET_0_E] =
        {SX_GP_REGISTER_0_E, SX_GP_REGISTER_1_E, SX_GP_REGISTER_2_E, SX_GP_REGISTER_3_E},
        [SX_STATEFUL_DB_GP_REGISTER_SET_1_E] =
        {SX_GP_REGISTER_4_E, SX_GP_REGISTER_5_E, SX_GP_REGISTER_6_E, SX_GP_REGISTER_7_E},
        [SX_STATEFUL_DB_GP_REGISTER_SET_2_E] =
        {SX_GP_REGISTER_8_E, SX_GP_REGISTER_9_E, SX_GP_REGISTER_10_E, SX_GP_REGISTER_11_E},
    };

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);

    SX_MEM_CLR(reg_key);
    SX_MEM_CLR(stateful_attr);

    if (ACL_STAGE_IS_FLEX3_OR_ABOVE(g_acl_stage) == FALSE) {
        SX_LOG_ERR("Flex ACL stateful DB action is not allowed by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

    rc = stateful_db_key_get(SX_ACCESS_CMD_GET, action->action_stateful_db.stateful_key_id, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex ACL stateful DB action key ID [%u] is invalid\n", action->action_stateful_db.stateful_key_id);
        is_valid = FALSE;
        goto out;
    }

    rc = stateful_db_partition_get(SX_ACCESS_CMD_GET, action->action_stateful_db.partition_id, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex ACL stateful DB action partition [%u] is invalid\n", action->action_stateful_db.partition_id);
        is_valid = FALSE;
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_STATEFUL_DB_OP_MIN_E, action->action_stateful_db.db_op, SX_STATEFUL_DB_OP_MAX_E)) {
        SX_LOG_ERR("Flex ACL stateful DB action op [%u] is invalid\n", action->action_stateful_db.db_op);
        is_valid = FALSE;
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_STATEFUL_DB_SEM_MIN_E, action->action_stateful_db.sem_op, SX_STATEFUL_DB_SEM_MAX_E)) {
        SX_LOG_ERR("Flex ACL stateful DB action semaphore [%u] is invalid\n", action->action_stateful_db.sem_op);
        is_valid = FALSE;
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_STATEFUL_DB_ORDER_MIN_E, action->action_stateful_db.order_op, SX_STATEFUL_DB_ORDER_MAX_E)) {
        SX_LOG_ERR("Flex ACL stateful DB action order [%u] is invalid\n", action->action_stateful_db.order_op);
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_stateful_db.db_op == SX_STATEFUL_DB_OP_WRITE_E) &&
        (action->action_stateful_db.sem_op == SX_STATEFUL_DB_SEM_LOCK_E)) {
        SX_LOG_ERR("Flex ACL stateful DB action cannot combine write operation with semaphore lock\n");
        is_valid = FALSE;
        goto out;
    }

    if ((action->action_stateful_db.order_op == SX_STATEFUL_DB_ORDER_FORCE_E) ||
        (action->action_stateful_db.order_op == SX_STATEFUL_DB_ORDER_RELEASE_E)) {
        rc = stateful_db_attr_get(SX_ACCESS_CMD_GET, &stateful_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex ACL stateful DB action failed to get stateful attributes\n");
            is_valid = FALSE;
            goto out;
        }
        if (stateful_attr.force_ordering_enable != TRUE) {
            SX_LOG_ERR("Flex ACL stateful DB force ordering is not globally enabled\n");
            is_valid = FALSE;
            goto out;
        }
    }

    /* Check that each register in the register set is allocated */
    if (action->action_stateful_db.gp_reg_set != SX_STATEFUL_DB_GP_REGISTER_SET_NOP_E) {
        reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
        for (i = 0; i < GP_REGISTER_SET_SIZE; i++) {
            reg_key.key.gp_reg.reg_id = register_sets[action->action_stateful_db.gp_reg_set][i];
            rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
            if ((SX_CHECK_FAIL(rc)) || (is_allocated == FALSE)) {
                SX_LOG_ERR("Flex ACL stateful DB action - GP register [%u] is not allocated.\n",
                           reg_key.key.gp_reg.reg_id);
                is_valid = FALSE;
                goto out;
            }
        }
    }


out:
    return is_valid;
}

static boolean_t __is_disable_fdb_security_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                 sx_flex_acl_flex_action_fields_t *action,
                                                 sx_acl_region_id_t                region_id)
{
    boolean_t is_valid = TRUE;

    UNUSED_PARAM(action_type);
    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action);

    if (!ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        SX_LOG_ERR("Flex ACL disable FDB security action is not allowed by this chip type\n");
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __is_set_vlan_ethertype_action_valid(sx_flex_acl_flex_action_type_t    action_type,
                                                      sx_flex_acl_flex_action_fields_t *action,
                                                      sx_acl_region_id_t                region_id)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    boolean_t       is_valid = TRUE;
    sx_ether_type_t ethertype = 0;

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(action_type);

    switch (action->action_set_vlan_ethertype.ethertype_cmd) {
    case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_OUTER_E:
    case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SET_INNER_E:
        if (action->action_set_vlan_ethertype.egress_et_set != FALSE) {
            if (g_acl_stage == ACL_STAGE_FLEX) {
                SX_LOG_ERR(
                    "Flex ACL: Setting the Ethertype according to an egress port is not supported by this chip type\n");
                is_valid = FALSE;
                goto out;
            }

            action->action_set_vlan_ethertype.egress_et_set = !!action->action_set_vlan_ethertype.egress_et_set;
        } else {
            if (action->action_set_vlan_ethertype.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
                rc = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                               sx_status_str(rc));
                    is_valid = FALSE;
                    goto out;
                }
            }
        }

        break;

    case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_OUTER_E:
    case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_COPY_INNER_E:
    case SX_FLEX_ACL_VLAN_ETHERTYPE_CMD_SWAP_INNER_OUTER_E:
        break;

    default:
        SX_LOG_ERR("Flex ACL VLAN Ethertype command [%u] is invalid\n",
                   action->action_set_vlan_ethertype.ethertype_cmd);
        is_valid = FALSE;
        goto out;
    }

out:
    return is_valid;
}

static boolean_t __flex_acl_actions_combination_is_valid(uint8_t actions_present[], sx_flex_acl_flex_rule_t *rule_p)
{
    boolean_t                is_valid = TRUE;
    uint32_t                 i;
    sx_status_t              rc;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    if ((actions_present[SX_FLEX_ACL_ACTION_RPF] > 0) && (actions_present[SX_FLEX_ACL_ACTION_MC_ROUTE] == 0)) {
        SX_LOG_ERR("RPF action can not be provided without MC_ROUTE action.\n");
        is_valid = FALSE;
        goto out;
    }
    if (actions_present[SX_FLEX_ACL_ACTION_GOTO] > 1) {
        SX_LOG_ERR("Error, can set only one goto action per rule\n");
        is_valid = FALSE;
        goto out;
    }

    if ((actions_present[SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP] +
         actions_present[SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP]) > 1) {
        SX_LOG_ERR("Error, can set only one encap action per rule\n");
        is_valid = FALSE;
        goto out;
    }

    if ((actions_present[SX_FLEX_ACL_ACTION_PBS] > 0) &&
        ((actions_present[SX_FLEX_ACL_ACTION_UC_ROUTE] > 0) ||
         (actions_present[SX_FLEX_ACL_ACTION_AR_UC_ROUTE] > 0) ||
         (actions_present[SX_FLEX_ACL_ACTION_PBILM] > 0) ||
         (actions_present[SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP] > 0) ||
         (actions_present[SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP] > 0))) {
        boolean_t is_pbr_remote = FALSE;
        boolean_t is_nve_encap = FALSE;
        boolean_t is_nve_mc_encap = FALSE;

        for (i = 0; i < rule_p->action_count; i++) {
            switch (rule_p->action_list_p[i].type) {
            case SX_FLEX_ACL_ACTION_PBS:
                rc = flex_acl_db_pbs_get_entry(0, rule_p->action_list_p[i].fields.action_pbs.pbs_id, &pbs_entry);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("PBS action PBS id %u is not valid\n",
                               rule_p->action_list_p[i].fields.action_pbs.pbs_id);
                    is_valid = FALSE;
                    goto out;
                }
                break;

            case SX_FLEX_ACL_ACTION_UC_ROUTE:
                is_pbr_remote =
                    (rule_p->action_list_p[i].fields.action_uc_route.uc_route_type == SX_UC_ROUTE_TYPE_NEXT_HOP);
                break;

            case SX_FLEX_ACL_ACTION_AR_UC_ROUTE:
                is_pbr_remote = TRUE;
                break;

            case SX_FLEX_ACL_ACTION_PBILM:
                is_pbr_remote = TRUE;
                break;

            case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
                is_nve_encap = TRUE;
                break;

            case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
                is_nve_mc_encap = TRUE;
                break;

            default:
                break;
            }
        }

        if (is_pbr_remote && (pbs_entry && (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST))) {
            SX_LOG_ERR(
                "PBS UC action can not be specified with UC ROUTE remote/PBILM/AR UC ROUTE action in the same rule.\n");
            is_valid = FALSE;
            goto out;
        }

        if ((is_nve_encap || is_nve_mc_encap) &&
            ((pbs_entry && (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST)) ||
             (pbs_entry && (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST)))) {
            SX_LOG_ERR("PBS UC/MC action can not be specified with NVE Encap action in the same rule.\n");
            is_valid = FALSE;
            goto out;
        }
    }
    if (actions_present[SX_FLEX_ACL_ACTION_PBS] > 1) {
        boolean_t pbs_exists = FALSE;

        for (i = 0; i < rule_p->action_count; i++) {
            if (rule_p->action_list_p[i].type != SX_FLEX_ACL_ACTION_PBS) {
                continue;
            }
            rc = flex_acl_db_pbs_get_entry(0, rule_p->action_list_p[i].fields.action_pbs.pbs_id, &pbs_entry);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("PBS action PBS id %u is not valid\n", rule_p->action_list_p[i].fields.action_pbs.pbs_id);
                is_valid = FALSE;
                goto out;
            }
            if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST) ||
                (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
                (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_ROUTING)) {
                if (pbs_exists) {
                    SX_LOG_ERR("Rule can not contain more than one PBS action of types"
                               "UNICAST/MULTICAST/ROUTING.\n");
                    is_valid = FALSE;
                    goto out;
                }
                pbs_exists = TRUE;
                continue;
            }
            if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST) ||
                (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
                if (pbs_exists) {
                    SX_LOG_ERR("PBS action of types UNICAST/MULTICAST/ROUTING "
                               "cannot precede PBS of OUTPUT types.\n");
                    is_valid = FALSE;
                    goto out;
                }
            }
        }
    }
    if ((actions_present[SX_FLEX_ACL_ACTION_TRAP] > 0) && (actions_present[SX_FLEX_ACL_ACTION_TRAP_W_USER_ID] > 0)) {
        SX_LOG_ERR("Action TRAP and TRAP_W_USER_ID cannot be used together in same rule.\n");
        is_valid = FALSE;
        goto out;
    }
    if (actions_present[SX_FLEX_ACL_ACTION_TRAP] > 1) {
        SX_LOG_ERR("Multiple SX_FLEX_ACL_ACTION_TRAP actions are not allowed in the same rule.\n");
        is_valid = FALSE;
        goto out;
    }
    if (actions_present[SX_FLEX_ACL_ACTION_TRAP_W_USER_ID] > 1) {
        SX_LOG_ERR("Multiple SX_FLEX_ACL_ACTION_TRAP_W_USER_ID actions are not allowed in the same rule.\n");
        is_valid = FALSE;
        goto out;
    }
    if (actions_present[SX_FLEX_ACL_ACTION_FORWARD] > 1) {
        SX_LOG_ERR("Multiple SX_FLEX_ACL_ACTION_FORWARD actions are not allowed in the same rule.\n");
        is_valid = FALSE;
        goto out;
    }
    if ((actions_present[SX_FLEX_ACL_ACTION_MIRROR] > 1) || (actions_present[SX_FLEX_ACL_ACTION_EGRESS_MIRROR] > 1)) {
        SX_LOG_ERR(
            "Multiple SX_FLEX_ACL_ACTION_MIRROR or SX_FLEX_ACL_ACTION_EGRESS_MIRROR actions are not allowed in the same rule.\n");
        is_valid = FALSE;
        goto out;
    }


out:
    return is_valid;
}

static sx_status_t __is_goto_call_in_acl(sx_acl_id_t acl_id, boolean_t *call_exist)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t      *region_p = NULL;
    flex_acl_db_acl_table_t       *acl_table = NULL;
    boolean_t                      goto_exist = FALSE;
    sx_flex_acl_flex_action_goto_t goto_action;
    uint32_t                       i = 0;

    SX_LOG_ENTER();

    *call_exist = FALSE;

    rc = flex_acl_db_acl_get(acl_id, &acl_table);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get acl table error, acl id[%d]\n", acl_id);
        goto out;
    }

    rc = flex_acl_db_region_get(acl_table->bound_region, &region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", acl_table->bound_region);
        goto out;
    }
    for (i = 0; i < region_p->size; i++) {
        rc = flex_acl_db_rule_get_goto_action(&region_p->rules[i], &goto_exist, &goto_action);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed get rule goto action for region id[%x]\n", acl_table->bound_region);
        }
        if (goto_exist && (goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
            *call_exist = TRUE;
            break;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_db_attribs_is_goto_call_target(flex_acl_bind_attribs_id_t attribs_id,
                                                             boolean_t                 *is_target)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    cl_list_iterator_t                iter = NULL;
    cl_list_iterator_t                list_end = NULL;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    flex_acl_rule_id_t               *rule_id = NULL;
    flex_acl_db_acl_region_t         *region_p = NULL;
    boolean_t                         goto_exist = FALSE;
    sx_flex_acl_flex_action_goto_t    goto_action;


    SX_LOG_ENTER();

    *is_target = FALSE;

    rc = flex_acl_db_attribs_get(attribs_id, &attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get bind attribs id [%d]\n", attribs_id);
        goto out;
    }
    list_end = cl_list_end(&(attribs->bound_goto_rule));
    iter = cl_list_head(&(attribs->bound_goto_rule));
    while (iter != list_end) {
        rule_id = cl_list_obj(iter);
        rc = flex_acl_db_region_get(rule_id->region_id, &region_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", rule_id->region_id);
            goto out;
        }
        rc = flex_acl_db_rule_get_goto_action(&region_p->rules[rule_id->offset], &goto_exist, &goto_action);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed get rule goto action for region id[%x]\n", rule_id->region_id);
        }
        if (goto_exist && (goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
            *is_target = TRUE;
            break;
        }
        iter = cl_list_next(iter);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __is_group_chain_contain_goto_call(sx_acl_id_t group_id, boolean_t *contain)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t * acl_group = NULL;
    sx_acl_id_t               current_group_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                  i = 0;
    boolean_t                 jump_exist = FALSE;

    SX_LOG_ENTER();

    current_group_id = group_id;
    while (current_group_id != FLEX_ACL_INVALID_ACL_ID) {
        rc = flex_acl_db_get_acl_group(current_group_id, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get acl group[%x]\n", current_group_id);
            goto out;
        }
        for (i = 0; i < acl_group->acl_num; i++) {
            rc = __is_goto_call_in_acl(acl_group->acl_ids[i], &jump_exist);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed to get if acl contain jump call[%x]\n", acl_group->acl_ids[i]);
                goto out;
            } else if (jump_exist) {
                *contain = TRUE;
                goto out;
            }
        }
        current_group_id = acl_group->next_acl_group_id;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __is_acl_group_goto_call_target(sx_acl_id_t group_id, boolean_t  *is_target)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_ENTER();

    *is_target = FALSE;

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get acl group[%x]\n", group_id);
        goto out;
    }
    if (acl_group->bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        rc = __flex_acl_db_attribs_is_goto_call_target(acl_group->bind_attribs_id, is_target);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get if acl group[%x] are target of call action\n", group_id);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __is_acl_group_goto_target(sx_acl_id_t group_id, boolean_t  *is_target)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int32_t     ref_count = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_group_rules_ref_cnt_get(group_id, &ref_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed get rules ref count for group id [%#x]\n", group_id);
    }
    if (ref_count != 0) {
        *is_target = TRUE;
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_actions_validate(sx_flex_acl_flex_rule_t  *rule,
                                      flex_acl_db_acl_region_t *acl_region,
                                      boolean_t                 is_flex)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 j;
    uint8_t                  actions_present[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = {0};
    flex_acl_db_acl_table_t *acl_table = NULL;
    uint32_t                 invalid_dir_bitmap = 0;

    SX_LOG_ENTER();

    if (is_flex) {
        rc = flex_acl_db_acl_get(acl_region->bound_acl, &acl_table);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed get db acl.\n");
            goto out;
        }
    }

    /* Validate actions  */
    for (j = 0; j < rule->action_count; j++) {
        /* validate action type */
        if (rule->action_list_p[j].type > SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST) {
            SX_LOG_ERR("ACL : Action type is invalid. \n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* validate action type isn't MACSEC */
        if ((rule->action_list_p[j].type == SX_FLEX_ACL_MACSEC_ACTION_FORWARD) ||
            (rule->action_list_p[j].type == SX_FLEX_ACL_MACSEC_ACTION_TRAP) ||
            (rule->action_list_p[j].type == SX_FLEX_ACL_MACSEC_ACTION_COUNTER)) {
            SX_LOG_ERR("ACL : MACSEC Action type %d (%s) at action index %d can't be used for FLEX ACL. \n",
                       rule->action_list_p[j].type, ACTION_ID_2STR(rule->action_list_p[j].type), j);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Validate that action can be used in binding type */

        if (is_flex && (acl_table->entry_type != FLEX_ACL_ENTRY_TYPE_SYSTEM_E)) {
            if (acl_table->direction != SX_ACL_DIRECTION_MULTI_POINTS_E) {
                if ((sx_flex_acl_actions_details[rule->action_list_p[j].type].flags &
                     (1 << acl_table->direction)) == 0) {
                    SX_LOG_ERR("ACL : Action id %u (%s) is not valid for binding type :%s.\n",
                               rule->action_list_p[j].type,
                               ACTION_ID_2STR(rule->action_list_p[j].type),
                               sx_acl_direction_str(acl_table->direction));
                    rc = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            } else {
                invalid_dir_bitmap = ~(sx_flex_acl_actions_details[rule->action_list_p[j].type].flags);
                if ((invalid_dir_bitmap & acl_table->acl_attributes.multi_direction.acl_direction_bitmap) !=
                    0) {
                    SX_LOG_ERR("ACL : Action id %u (%s) is not valid for binding bitmap: 0x%x.\n",
                               rule->action_list_p[j].type,
                               ACTION_ID_2STR(rule->action_list_p[j].type),
                               acl_table->acl_attributes.multi_direction.acl_direction_bitmap);
                    rc = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
        }
        /* validate action value */
        if (action_validation[rule->action_list_p[j].type] &&
            (action_validation[rule->action_list_p[j].type](rule->action_list_p[j].type,
                                                            &(rule->action_list_p[j].fields),
                                                            acl_region->region_id) == FALSE)) {
            SX_LOG_ERR("ACL : Action type %u value id is not valid.\n",
                       rule->action_list_p[j].type);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        actions_present[rule->action_list_p[j].type]++;
    }
    if (__flex_acl_actions_combination_is_valid(actions_present, rule) == FALSE) {
        SX_LOG_ERR("ACL : Actions combination is invalid. Region:%#x\n",
                   acl_region->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t validate_goto_action_on_group_update(flex_acl_db_acl_group_t *acl_group,
                                                 uint32_t                 acl_ids_num,
                                                 sx_acl_id_t             *acl_ids)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                    group_head_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                      is_target = FALSE;
    boolean_t                      call_exist = FALSE;
    uint32_t                       acl_i = 0, rule_i;
    flex_acl_db_acl_table_t       *acl_table = NULL;
    boolean_t                      goto_exist = FALSE;
    sx_flex_acl_flex_action_goto_t goto_action;
    flex_acl_db_acl_region_t      *region_p = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_groups_head(acl_group->group_id, &group_head_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed get group head\n");
        goto out;
    }
    /* check goto action */
    rc = __is_acl_group_goto_call_target(group_head_id, &is_target);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get if acl group[%x] is goto target\n", group_head_id);
        goto out;
    } else if (is_target) {
        for (acl_i = 0; acl_i < acl_ids_num; acl_i++) {
            rc = __is_goto_call_in_acl(acl_ids[acl_i], &call_exist);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get if acl[%x] contain goto jump action\n", acl_ids[acl_i]);
                goto out;
            } else if (call_exist) {
                SX_LOG_ERR(
                    "Error: the goto call action exist in acl[%x] that should be added to goto target group[%x]\n",
                    acl_ids[acl_i],
                    group_head_id);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }

    /* infinite loop validation */
    for (acl_i = 0; acl_i < acl_ids_num; acl_i++) {
        rc = flex_acl_db_acl_get(acl_ids[acl_i], &acl_table);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("get acl table error, acl id[%d]\n", acl_ids[acl_i]);
            goto out;
        }

        rc = flex_acl_db_region_get(acl_table->bound_region, &region_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("flex_acl_db_region_get failed for region id [%u]\n", acl_table->bound_region);
            goto out;
        }
        for (rule_i = 0; rule_i < region_p->size; rule_i++) {
            rc = flex_acl_db_rule_get_goto_action(&region_p->rules[rule_i], &goto_exist, &goto_action);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed get rule goto action for region id[%x]\n", acl_table->bound_region);
                goto out;
            }
            if (goto_exist && ((goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL) ||
                               (goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP))) {
                rc = __flex_acl_infinite_loop_validate(goto_action.acl_group_id, acl_ids[acl_i], acl_group->group_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("failed validation of infinite loop existence, group_id[%x]\n",
                               goto_action.acl_group_id);
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t validate_goto_action_on_groups_bind(sx_acl_id_t group_head_id, sx_acl_id_t child_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_target = FALSE;
    boolean_t   is_contain = FALSE;

    SX_LOG_ENTER();

    /* check that child group are not goto target group */
    rc = __is_acl_group_goto_target(child_group_id, &is_target);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to check if acl group[%x] are GOTO JUMP target\n", child_group_id);
        goto out;
    } else if (is_target) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* check if head group are goto target and child group contain goto also*/
    rc = __is_acl_group_goto_call_target(group_head_id, &is_target);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to check if acl group[%x] are GOTO JUMP target\n", group_head_id);
        goto out;
    } else if (is_target) {
        rc = __is_group_chain_contain_goto_call(child_group_id, &is_contain);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to check if acl group[%x] contain jump call\n", child_group_id);
            goto out;
        } else if (is_contain) {
            SX_LOG_ERR(
                "ACL: The child group[%x] contain goto action and the group head[%x] is goto action target\n",
                child_group_id,
                group_head_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_actions_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}
