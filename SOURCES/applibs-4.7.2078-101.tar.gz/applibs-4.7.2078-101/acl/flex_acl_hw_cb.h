/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_HW_CB_H__
#define __FLEX_ACL_HW_CB_H__

#include "flex_acl_gen_def.h"
#include "sx/sdk/sx_flex_acl.h"
#include <sx_api/sx_api_internal.h>
#include <span/span.h>


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
/* forward declaration of flex_acl_db_pbs_entry for callbacks */
struct flex_acl_db_pbs_entry;

typedef enum acl_move_rule_hw_op {
    ACL_RULE_MOVE_HW_OP_COPY_E = 0,
    ACL_RULE_MOVE_HW_OP_MOVE_E = 1,
    ACL_RULE_MOVE_HW_OP_LAST_E,
} acl_move_rule_hw_op_e;

typedef enum acl_region_hw_op {
    ACL_REGION_HW_OP_ALLOCATE_E      = 0,
    ACL_REGION_HW_OP_RESIZE_E        = 1,
    ACL_REGION_HW_OP_DEALLOCATE_E    = 2,
    ACL_REGION_HW_OP_TEST_ALLOCATE_E = 3,
    ACL_REGION_HW_OP_LAST_E
} acl_region_op_e;

typedef enum acl_rule_hw_op {
    ACL_RULE_HW_OP_WRITE_E           = 0,
    ACL_RULE_HW_OP_READ_E            = 1,
    ACL_RULE_HW_OP_CLEAR_ON_READ_E   = 2,
    ACL_RULE_HW_OP_UPDATE_E          = 3,
    ACL_RULE_HW_OP_CLEAR_ACTIVITY_E  = 4,
    ACL_RULE_HW_OP_WRITE_CLEAR_E     = 5,
    ACL_RULE_HW_OP_OVERWRITE_E       = 6,
    ACL_RULE_HW_OP_OVERWRITE_CLEAR_E = 7,
    ACL_RULE_HW_OP_PRIO_SET_E        = 8,
    ACL_RULE_HW_OP_PRIO_SET_CLEAR_E  = 9,
    ACL_RULE_HW_OP_LAST_E,
} acl_rule_hw_op_e;

typedef sx_status_t (*flex_acl_hw_region_write_hw_cb)(acl_region_op_e     region_op,
                                                      sx_dev_id_t         dev_id,
                                                      sx_acl_region_id_t  region_id,
                                                      sx_acl_key_type_t   key_handle,
                                                      sx_acl_key_block_e *key_blocks,
                                                      uint32_t            key_blocks_cnt,
                                                      uint8_t            *tcam_region_info,
                                                      uint32_t            tcam_region_info_size,
                                                      sx_acl_size_t       new_size,
                                                      sx_acl_size_t      *allocated_size_p,
                                                      boolean_t           stateful_db_region);

typedef sx_status_t (*flex_acl_hw_rule_write_hw_cb)(acl_rule_hw_op_e        op,
                                                    sx_dev_id_t             dev_id,
                                                    sx_acl_region_id_t      region_id,
                                                    const void             *region_info,
                                                    sx_acl_rule_offset_t    offset,
                                                    boolean_t               is_valid,
                                                    uint32_t                priority,
                                                    sx_flex_acl_key_desc_t *keys,
                                                    uint32_t                keys_cnt,
                                                    sx_acl_key_block_e     *key_blocks,
                                                    uint32_t                key_blocks_cnt,
                                                    sxd_flex_action_set_t  *reg_action_set,
                                                    boolean_t              *activity_value,
                                                    boolean_t               bulk_write);

typedef sx_status_t (*flex_acl_hw_move_rule_write_hw_cb)(acl_move_rule_hw_op_e op,
                                                         sx_dev_id_t           dev_id,
                                                         sx_acl_region_id_t    src_region_id,
                                                         sx_acl_region_id_t    dst_region_id,
                                                         const void           *src_region_info,
                                                         const void           *dst_region_info,
                                                         sx_acl_rule_offset_t  src_offset,
                                                         sx_acl_rule_offset_t  dst_offset,
                                                         uint32_t              size,
                                                         boolean_t             change_priority);

typedef sx_status_t (*flex_acl_hw_acl_write_hw_cb)(sx_acl_id_t        acl_id,
                                                   sx_acl_direction_t direction,
                                                   uint8_t           *region_info,
                                                   uint32_t           region_info_size,
                                                   sx_dev_id_t        dev_id,
                                                   boolean_t          valid);

typedef flex_acl_hw_rule_write_hw_cb flex_acl_hw_activity_read_hw_cb;

typedef sx_status_t (*flex_acl_hw_dump_activity_cb)(boolean_t            is_clear,
                                                    sx_dev_id_t          dev_id,
                                                    const void          *region_info,
                                                    sx_acl_rule_offset_t offset,
                                                    uint32_t             num_entries,
                                                    bit_vector_t        *activities_p);

typedef sx_status_t (*flex_acl_hw_action_write_hw_cb)(sx_dev_id_t          dev_id,
                                                      sx_acl_region_id_t   region_id,
                                                      sx_acl_rule_offset_t offset,
                                                      ku_pefa_reg_t       *pefa_reg_data,
                                                      boolean_t            bulk_write);

typedef sx_status_t (*flex_acl_hw_prio_change_hw_cb)(sx_acl_region_id_t region_id,
                                                     const uint32_t     min_prio,
                                                     const uint32_t     max_prio,
                                                     const int32_t      prio_change);

typedef sx_status_t (*flex_acl_hw_config_uc_tunnel_pbs_write_cb)(const struct flex_acl_db_pbs_entry *pbs_entry_p,
                                                                 struct ku_ppbs_reg                 *ppbs_p);
typedef sx_status_t (*flex_acl_hw_activity_bulk_dump_cb)(sx_dev_id_t              dev_id,
                                                         sx_acl_region_id_t       region_id,
                                                         boolean_t                clear,
                                                         boolean_t                force_end,
                                                         sxd_pefaad_index_dump_t *record_p,
                                                         uint32_t                *record_num_p);
typedef sx_status_t (*flex_acl_hw_write_global_mask_cb)(sx_dev_id_t        dev_id,
                                                        sx_acl_region_id_t region_id,
                                                        uint8_t            global_mask[
                                                            SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);

typedef sx_status_t (*flex_acl_hw_lookup_region_write_hw_cb)(sx_dev_id_t              dev_id,
                                                             const sx_acl_region_id_t region_id,
                                                             const sx_acl_region_id_t lookup_region_id);

/************************************************
 *  Function declarations
 ***********************************************/
#endif /* ifndef __FLEX_ACL_HW_CB_H__ */
