/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#undef  __MODULE__
#define __MODULE__ ACL

/******************************************************************************************
* NOTE: This file (along with flex_acl_gen_def.h & flex_acl_gen_init.c) can be compiled  *
* independently from the rest of the SDK. This allows external application to use        *
* these files to calculate the key blocks without needing to compile the whole SDK!      *
* Any changes to these files (especially the include directive) need to be examined      *
* carefully not to break the code independence. The sx_examples/flex_acl_key_scp_example *
* contains an example to the independent compilation of these files.                     *
******************************************************************************************/
#include "flex_acl_gen_def.h"
#include "flex_acl_keys_scp.h"
#include <sx/sdk/sx_flex_acl.h>


/************************************************
 *  Macros
 ***********************************************/
/* If candidate KB count is greater than this TEST amount, then see if there is any valid solution given by greedy approximation*/
#define GREEDY_TEST_KEY_BLOCK_COUNT (18)
/* If greedy algorithm returns an approx key block count that is < tolerance +
 * max number of key blocks possible for chip then we can try the optimal solution since
 * there might be a valid cover
 */
#define GREEDY_APPROX_ERR_TOLERANCE (2)

/* A key block can be used: only for non-symmetric keys (0x1),
 * only for symmetric keys (0x2), or for both (0x3).
 * Given a key type we can use the bitmask to determine if the key
 * block is compatible with the key symmetric type.
 */

#define NON_SYMMETRIC_KEY_BLOCK_MASK (0x1)
#define SYMMETRIC_KEY_BLOCK_MASK     (0x2)

/************************************************
**  Global variables
************************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/* This variable holds the maximum number of key blocks this acl stage can handle */
uint32_t flex_acl_max_key_blocks[ACL_STAGES_NUM] = {0};

/* This variable will point to the correct mapping of FLEX_ACL_KEY to FLEX_ACL_HW_KWY according to FLEX stage. */
flex_acl_key_map_data_t *flex_acl_key_map[ACL_STAGES_NUM] = {NULL};

flex_acl_key_map_data_t flex1_acl_key_map[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DIP_E}
    },
    [FLEX_ACL_KEY_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SIP_E}
    },
    [FLEX_ACL_KEY_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_DIPV6_PART1_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART2_E, FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_SIPV6_PART1_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART2_E, FLEX_ACL_HW_KEY_SIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DSCP_E}
    },
    [FLEX_ACL_KEY_RW_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_DSCP_E}
    },
    [FLEX_ACL_KEY_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECN_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OK_E}
    },
    [FLEX_ACL_KEY_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_IS_ARP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARP_E}
    },
    [FLEX_ACL_KEY_URPF_FAIL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_URPF_FAIL_E}
    },
    [FLEX_ACL_KEY_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OPT_E}
    },
    [FLEX_ACL_KEY_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_IP_V4_E}
    },
    [FLEX_ACL_KEY_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_E}
    },
    [FLEX_ACL_KEY_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_OK_E}
    },
    [FLEX_ACL_KEY_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_OK_E}
    },
    [FLEX_ACL_KEY_L4_PORT_RANGE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E}
    },
    [FLEX_ACL_KEY_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_L4_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_E}
    },
    [FLEX_ACL_KEY_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_DMAC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DMAC_E}
    },
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E}
    },
    [FLEX_ACL_KEY_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_RW_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_PCP_E}
    },
    [FLEX_ACL_KEY_SMAC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMAC_E}
    },
    [FLEX_ACL_KEY_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEI_E}
    },
    [FLEX_ACL_KEY_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PCP_E}
    },
    [FLEX_ACL_KEY_VLAN_TAGGED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_TAGGED_E}
    },
    [FLEX_ACL_KEY_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_COLOR] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_COLOR_E}
    },
    [FLEX_ACL_KEY_DST_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DST_PORT_E}
    },
    [FLEX_ACL_KEY_SWITCH_PRIO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SWITCH_PRIO_E}
    },
    [FLEX_ACL_KEY_SRC_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SRC_PORT_E}
    },
    [FLEX_ACL_KEY_DMAC_IS_UC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DMAC_IS_UC_E}
    },
    [FLEX_ACL_KEY_BUFF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BUFF_E}
    },
    [FLEX_ACL_KEY_IRIF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IRIF_E}
    },
    [FLEX_ACL_KEY_ERIF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ERIF_E}
    },
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E}
    },
    [FLEX_ACL_KEY_TUNNEL_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E}
    },
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_VNI_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VNI_E}
    },
    [FLEX_ACL_KEY_GRE_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_KEY_E}
    },
    [FLEX_ACL_KEY_GRE_PROTOCOL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_USER_TOKEN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_USER_TOKEN_E}
    },
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_RX_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_LIST_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_LIST_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TX_LIST_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E, FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DIP_E}
    },
    [FLEX_ACL_KEY_INNER_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SIP_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OK_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_INNER_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_OK_E}
    },
    [FLEX_ACL_KEY_INNER_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_INNER_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DMAC_E}
    },
    [FLEX_ACL_KEY_INNER_SMAC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SMAC_E}
    },
    [FLEX_ACL_KEY_INNER_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DSCP_E}
    },
    [FLEX_ACL_KEY_INNER_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_INNER_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_DISCARD_STATE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DISCARD_STATE_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIPV6_PART1_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART2_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_IS_TRAPPED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TRAPPED_E}
    },
    [FLEX_ACL_KEY_INNER_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_DIPV6_PART1_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_INNER_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_SIPV6_PART1_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_LABEL_ID_2_9_0_E,
                                                               FLEX_ACL_HW_KEY_LABEL_ID_2_19_10_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_3_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BOS_E}
    },
    [FLEX_ACL_KEY_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_EXP_E}
    },
    [FLEX_ACL_KEY_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_RW_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_EXP_E}
    },
    [FLEX_ACL_KEY_IS_ROUTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ROUTED_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_ROCE_DEST_QP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEST_QP_E}
    },
    [FLEX_ACL_KEY_ROCE_PKEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PKEY_E}
    },
    [FLEX_ACL_KEY_ROCE_BTH_OPCODE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BTH_OPCODE_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E}
    },
    [FLEX_ACL_KEY_DWORD_0_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_0_E}
    },
    [FLEX_ACL_KEY_DWORD_1_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_1_E}
    },
    [FLEX_ACL_KEY_DWORD_2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_2_E}
    },
    [FLEX_ACL_KEY_DWORD_3_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_3_E}
    },
    [FLEX_ACL_KEY_DWORD_4_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_4_E}
    },
    [FLEX_ACL_KEY_DWORD_5_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_5_E}
    },
    [FLEX_ACL_KEY_LAG_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LAG_HASH_E}
    },
    [FLEX_ACL_KEY_ECMP_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECMP_HASH_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_E}
    },
    [FLEX_ACL_KEY_IS_BUM] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_VALID_E}
    },
    [FLEX_ACL_KEY_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SPI_E}
    },
};
flex_acl_key_map_data_t flex2_acl_key_map[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DIP_E}
    },
    [FLEX_ACL_KEY_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SIP_E}
    },
    [FLEX_ACL_KEY_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_DIP_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART2_E, FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_SIP_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART2_E, FLEX_ACL_HW_KEY_SIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DSCP_E}
    },
    [FLEX_ACL_KEY_RW_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_DSCP_E}
    },
    [FLEX_ACL_KEY_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECN_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OK_E}
    },
    [FLEX_ACL_KEY_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_IS_ARP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARP_E}
    },
    [FLEX_ACL_KEY_URPF_FAIL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_URPF_FAIL_E}
    },
    [FLEX_ACL_KEY_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OPT_E}
    },
    [FLEX_ACL_KEY_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_IP_V4_E}
    },
    [FLEX_ACL_KEY_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_E}
    },
    [FLEX_ACL_KEY_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_OK_E}
    },
    [FLEX_ACL_KEY_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_OK_E}
    },
    [FLEX_ACL_KEY_L4_PORT_RANGE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E}
    },
    [FLEX_ACL_KEY_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_L4_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_E}
    },
    [FLEX_ACL_KEY_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_DMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DMAC_31_0_E, FLEX_ACL_HW_KEY_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E}
    },
    [FLEX_ACL_KEY_L2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E}
    },
    [FLEX_ACL_KEY_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_RW_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_PCP_E}
    },
    [FLEX_ACL_KEY_SMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_SMAC_31_0_E, FLEX_ACL_HW_KEY_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEI_E}
    },
    [FLEX_ACL_KEY_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PCP_E}
    },
    [FLEX_ACL_KEY_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_VLAN_TAGGED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_TAGGED_E}
    },
    [FLEX_ACL_KEY_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_COLOR] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_COLOR_E}
    },
    [FLEX_ACL_KEY_DST_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_SWITCH_PRIO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SWITCH_PRIO_E}
    },
    [FLEX_ACL_KEY_SRC_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_DMAC_IS_UC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DMAC_IS_UC_E}
    },
    [FLEX_ACL_KEY_BUFF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BUFF_E}
    },
    [FLEX_ACL_KEY_IRIF] = {3, (sx_acl_hw_key_e[3]) {FLEX_ACL_HW_KEY_IRIF_3_0_E,
                                                    FLEX_ACL_HW_KEY_IRIF_7_4_E,
                                                    FLEX_ACL_HW_KEY_IRIF_11_8_E}
    },
    [FLEX_ACL_KEY_ERIF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ERIF_E}
    },
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = {3, (sx_acl_hw_key_e[3]) {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E}
    },
    [FLEX_ACL_KEY_TUNNEL_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E}
    },
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_VNI_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VNI_E}
    },
    [FLEX_ACL_KEY_GRE_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_KEY_E}
    },
    [FLEX_ACL_KEY_GRE_PROTOCOL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_USER_TOKEN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_USER_TOKEN_E}
    },
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_RX_LIST] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_RX_CPU_E,
                                                       FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                       FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                       FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                       FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_RX_CPU_E,
                                                            FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                            FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                            FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                            FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DIP_E}
    },
    [FLEX_ACL_KEY_INNER_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SIP_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OPT_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_INNER_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_OK_E}
    },
    [FLEX_ACL_KEY_INNER_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_INNER_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_SMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DSCP_E}
    },
    [FLEX_ACL_KEY_INNER_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_INNER_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_DISCARD_STATE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DISCARD_STATE_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIP_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART2_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_IS_TRAPPED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TRAPPED_E}
    },
    [FLEX_ACL_KEY_INNER_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_DIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_INNER_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_SIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_3_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BOS_E}
    },
    [FLEX_ACL_KEY_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_EXP_E}
    },
    [FLEX_ACL_KEY_INNER_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_EXP_E}
    },
    [FLEX_ACL_KEY_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_RW_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_EXP_E}
    },
    [FLEX_ACL_KEY_IS_ROUTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ROUTED_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_ROCE_DEST_QP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEST_QP_E}
    },
    [FLEX_ACL_KEY_ROCE_PKEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PKEY_E}
    },
    [FLEX_ACL_KEY_ROCE_BTH_OPCODE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BTH_OPCODE_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E}
    },
    [FLEX_ACL_KEY_DWORD_0_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_0_E}
    },
    [FLEX_ACL_KEY_DWORD_1_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_1_E}
    },
    [FLEX_ACL_KEY_DWORD_2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_2_E}
    },
    [FLEX_ACL_KEY_DWORD_3_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_3_E}
    },
    [FLEX_ACL_KEY_DWORD_4_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_4_E}
    },
    [FLEX_ACL_KEY_DWORD_5_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_FID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FID_E}
    },
    [FLEX_ACL_KEY_MC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_IPV4_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E}
    },
    [FLEX_ACL_KEY_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_INNER_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_BOS_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E}
    },
    [FLEX_ACL_KEY_TRAP_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TRAP_ID_E}
    },
    [FLEX_ACL_KEY_FDB_MISS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FDB_MISS_E}
    },
    [FLEX_ACL_KEY_LLC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LLC_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E}
    },
    [FLEX_ACL_KEY_LAG_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LAG_HASH_E}
    },
    [FLEX_ACL_KEY_ECMP_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECMP_HASH_E}
    },
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_E}
    },
    [FLEX_ACL_KEY_IS_BUM] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_VALID_E}
    },
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E}
    },
    [FLEX_ACL_KEY_PORT_USER_MEMORY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PORT_USER_MEM_E}
    },
    [FLEX_ACL_KEY_PACKET_IS_ELEPHANT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ELEPHANT_E}
    },
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E}
    },
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E}
    },
    [FLEX_ACL_KEY_MAC_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E}
    },
    [FLEX_ACL_KEY_IP_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E}
    },
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E}
    },
    [FLEX_ACL_KEY_DEFAULT_ROUTE_HIT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E}
    },
    [FLEX_ACL_KEY_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SPI_E}
    },
    [FLEX_ACL_KEY_INNER_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SPI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_PCP_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_IS_ARN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARN_E}
    },
};

flex_acl_key_map_data_t flex3_acl_key_map[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DIP_E}
    },
    [FLEX_ACL_KEY_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SIP_E}
    },
    [FLEX_ACL_KEY_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_DIP_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART2_E, FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_SIP_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART2_E, FLEX_ACL_HW_KEY_SIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DSCP_E}
    },
    [FLEX_ACL_KEY_RW_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_DSCP_E}
    },
    [FLEX_ACL_KEY_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECN_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OK_E}
    },
    [FLEX_ACL_KEY_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_IS_ARP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARP_E}
    },
    [FLEX_ACL_KEY_URPF_FAIL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_URPF_FAIL_E}
    },
    [FLEX_ACL_KEY_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OPT_E}
    },
    [FLEX_ACL_KEY_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_IP_V4_E}
    },
    [FLEX_ACL_KEY_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_E}
    },
    [FLEX_ACL_KEY_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_OK_E}
    },
    [FLEX_ACL_KEY_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_OK_E}
    },
    [FLEX_ACL_KEY_L4_PORT_RANGE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E}
    },
    [FLEX_ACL_KEY_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_L4_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_E}
    },
    [FLEX_ACL_KEY_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_DMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DMAC_31_0_E, FLEX_ACL_HW_KEY_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E}
    },
    [FLEX_ACL_KEY_L2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E}
    },
    [FLEX_ACL_KEY_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_RW_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_PCP_E}
    },
    [FLEX_ACL_KEY_SMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_SMAC_31_0_E, FLEX_ACL_HW_KEY_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEI_E}
    },
    [FLEX_ACL_KEY_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PCP_E}
    },
    [FLEX_ACL_KEY_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_VLAN_TAGGED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_TAGGED_E}
    },
    [FLEX_ACL_KEY_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_COLOR] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_COLOR_E}
    },
    [FLEX_ACL_KEY_DST_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_SWITCH_PRIO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SWITCH_PRIO_E}
    },
    [FLEX_ACL_KEY_SRC_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_DMAC_IS_UC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DMAC_IS_UC_E}
    },
    [FLEX_ACL_KEY_BUFF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BUFF_E}
    },
    [FLEX_ACL_KEY_IRIF] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_IRIF_3_0_E,
                                                    FLEX_ACL_HW_KEY_IRIF_7_4_E,
                                                    FLEX_ACL_HW_KEY_IRIF_11_8_E,
                                                    FLEX_ACL_HW_KEY_IRIF_12_E}
    },
    [FLEX_ACL_KEY_ERIF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ERIF_E}
    },
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E}
    },
    [FLEX_ACL_KEY_TUNNEL_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E}
    },
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_VNI_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VNI_E}
    },
    [FLEX_ACL_KEY_GRE_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_KEY_E}
    },
    [FLEX_ACL_KEY_GRE_PROTOCOL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_USER_TOKEN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_USER_TOKEN_E}
    },
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_RX_LIST] = {10, (sx_acl_hw_key_e[10]) {FLEX_ACL_HW_KEY_RX_CPU_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E,
                                                         FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST] = {10, (sx_acl_hw_key_e[10]) {FLEX_ACL_HW_KEY_RX_CPU_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST] = {9, (sx_acl_hw_key_e[9]) {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E,
                                                            FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DIP_E}
    },
    [FLEX_ACL_KEY_INNER_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SIP_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OPT_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_INNER_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_OK_E}
    },
    [FLEX_ACL_KEY_INNER_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_INNER_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_SMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DSCP_E}
    },
    [FLEX_ACL_KEY_INNER_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_INNER_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_DISCARD_STATE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DISCARD_STATE_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIP_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART2_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_IS_TRAPPED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TRAPPED_E}
    },
    [FLEX_ACL_KEY_INNER_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_DIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_INNER_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_SIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_3_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BOS_E}
    },
    [FLEX_ACL_KEY_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_EXP_E}
    },
    [FLEX_ACL_KEY_INNER_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_EXP_E}
    },
    [FLEX_ACL_KEY_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_RW_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_EXP_E}
    },
    [FLEX_ACL_KEY_IS_ROUTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ROUTED_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_20] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_21] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_22] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_23] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E}
    },
    [FLEX_ACL_KEY_ROCE_DEST_QP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEST_QP_E}
    },
    [FLEX_ACL_KEY_ROCE_PKEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PKEY_E}
    },
    [FLEX_ACL_KEY_ROCE_BTH_OPCODE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BTH_OPCODE_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E}
    },
    [FLEX_ACL_KEY_DWORD_0_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_0_E}
    },
    [FLEX_ACL_KEY_DWORD_1_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_1_E}
    },
    [FLEX_ACL_KEY_DWORD_2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_2_E}
    },
    [FLEX_ACL_KEY_DWORD_3_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_3_E}
    },
    [FLEX_ACL_KEY_DWORD_4_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_4_E}
    },
    [FLEX_ACL_KEY_DWORD_5_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_FID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FID_E}
    },
    [FLEX_ACL_KEY_MC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_IPV4_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E}
    },
    [FLEX_ACL_KEY_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_INNER_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_BOS_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E}
    },
    [FLEX_ACL_KEY_TRAP_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TRAP_ID_E}
    },
    [FLEX_ACL_KEY_FDB_MISS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FDB_MISS_E}
    },
    [FLEX_ACL_KEY_LLC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LLC_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E}
    },
    [FLEX_ACL_KEY_LAG_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LAG_HASH_E}
    },
    [FLEX_ACL_KEY_ECMP_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECMP_HASH_E}
    },
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_E}
    },
    [FLEX_ACL_KEY_IS_BUM] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_VALID_E}
    },
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E}
    },
    [FLEX_ACL_KEY_PORT_USER_MEMORY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PORT_USER_MEM_E}
    },
    [FLEX_ACL_KEY_PACKET_IS_ELEPHANT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ELEPHANT_E}
    },
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_10_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_11_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E}
    },
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E}
    },
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E}
    },
    [FLEX_ACL_KEY_MAC_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E}
    },
    [FLEX_ACL_KEY_IP_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E}
    },
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E}
    },
    [FLEX_ACL_KEY_DEFAULT_ROUTE_HIT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E}
    },
    [FLEX_ACL_KEY_SRC_PHY_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E}
    },
    /* Deprecated ACL Key */
    [FLEX_ACL_KEY_RX_PORT_LIST_1_128] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                                  FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                                  FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                                  FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E}
    },
    /* Deprecated ACL Key */
    [FLEX_ACL_KEY_RX_PORT_LIST_129_258] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E,
                                                                    FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E,
                                                                    FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E,
                                                                    FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E,
                                                                    FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E}
    },
    /* Deprecated ACL Key */
    [FLEX_ACL_KEY_TX_PORT_LIST_1_128] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E,
                                                                  FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E,
                                                                  FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E,
                                                                  FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E}
    },
    /* Deprecated ACL Key */
    [FLEX_ACL_KEY_TX_PORT_LIST_129_258] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E,
                                                                    FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E,
                                                                    FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E,
                                                                    FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E,
                                                                    FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST_0] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST_1] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST_0] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST_1] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E}
    },
    [FLEX_ACL_KEY_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SPI_E}
    },
    [FLEX_ACL_KEY_INNER_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SPI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_PCP_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_IS_ARN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARN_E}
    },
};

flex_acl_key_map_data_t flex4_acl_key_map[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DIP_E}
    },
    [FLEX_ACL_KEY_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SIP_E}
    },
    [FLEX_ACL_KEY_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_DIP_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART2_E, FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_SIP_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART2_E, FLEX_ACL_HW_KEY_SIPV6_PART3_E,
                                                     FLEX_ACL_HW_KEY_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DSCP_E}
    },
    [FLEX_ACL_KEY_RW_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_DSCP_E}
    },
    [FLEX_ACL_KEY_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECN_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OK_E}
    },
    [FLEX_ACL_KEY_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_IS_ARP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARP_E}
    },
    [FLEX_ACL_KEY_URPF_FAIL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_URPF_FAIL_E}
    },
    [FLEX_ACL_KEY_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_OPT_E}
    },
    [FLEX_ACL_KEY_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_IP_V4_E}
    },
    [FLEX_ACL_KEY_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_E}
    },
    [FLEX_ACL_KEY_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TTL_OK_E}
    },
    [FLEX_ACL_KEY_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_OK_E}
    },
    [FLEX_ACL_KEY_L4_PORT_RANGE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E}
    },
    [FLEX_ACL_KEY_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_L4_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_E}
    },
    [FLEX_ACL_KEY_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_DMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DMAC_31_0_E, FLEX_ACL_HW_KEY_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E}
    },
    [FLEX_ACL_KEY_L2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E}
    },
    [FLEX_ACL_KEY_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_RW_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_PCP_E}
    },
    [FLEX_ACL_KEY_SMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_SMAC_31_0_E, FLEX_ACL_HW_KEY_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEI_E}
    },
    [FLEX_ACL_KEY_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PCP_E}
    },
    [FLEX_ACL_KEY_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_VLAN_TAGGED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_TAGGED_E}
    },
    [FLEX_ACL_KEY_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_COLOR] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_COLOR_E}
    },
    [FLEX_ACL_KEY_DST_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_SWITCH_PRIO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SWITCH_PRIO_E}
    },
    [FLEX_ACL_KEY_SRC_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_SYS_PORT_E}
    },
    [FLEX_ACL_KEY_DMAC_IS_UC] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DMAC_IS_UC_E}
    },
    [FLEX_ACL_KEY_BUFF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BUFF_E}
    },
    [FLEX_ACL_KEY_IRIF] = {3, (sx_acl_hw_key_e[3]) {FLEX_ACL_HW_KEY_IRIF_3_0_E,
                                                    FLEX_ACL_HW_KEY_IRIF_7_4_E,
                                                    FLEX_ACL_HW_KEY_IRIF_11_8_E}
    },
    [FLEX_ACL_KEY_ERIF] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ERIF_E}
    },
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = {3, (sx_acl_hw_key_e[3]) {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E,
                                                              FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E}
    },
    [FLEX_ACL_KEY_TUNNEL_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E}
    },
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_VNI_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VNI_E}
    },
    [FLEX_ACL_KEY_GRE_KEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_KEY_E}
    },
    [FLEX_ACL_KEY_GRE_PROTOCOL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_USER_TOKEN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_USER_TOKEN_E}
    },
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_DIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DIP_E}
    },
    [FLEX_ACL_KEY_INNER_SIP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SIP_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_OPT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_OPT_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_L3_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E}
    },
    [FLEX_ACL_KEY_INNER_L4_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_OK_E}
    },
    [FLEX_ACL_KEY_INNER_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_TTL_OK] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TTL_OK_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PROTO] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E}
    },
    [FLEX_ACL_KEY_INNER_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_SMAC] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E, FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E}
    },
    [FLEX_ACL_KEY_INNER_DSCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DSCP_E}
    },
    [FLEX_ACL_KEY_INNER_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E}
    },
    [FLEX_ACL_KEY_INNER_L4_SOURCE_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E}
    },
    [FLEX_ACL_KEY_DISCARD_STATE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DISCARD_STATE_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_LSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIP_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART2_E}
    },
    [FLEX_ACL_SYSTEM_KEY_DIPV6_MSB] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DIPV6_PART3_E,
                                                                FLEX_ACL_HW_KEY_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_IS_TRAPPED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TRAPPED_E}
    },
    [FLEX_ACL_KEY_INNER_DIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_DIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_INNER_SIPV6] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_INNER_SIP_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E,
                                                           FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_3_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_4_E}
    },
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LABEL_ID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BOS_E}
    },
    [FLEX_ACL_KEY_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_EXP_E}
    },
    [FLEX_ACL_KEY_INNER_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_EXP_E}
    },
    [FLEX_ACL_KEY_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E}
    },
    [FLEX_ACL_KEY_RW_EXP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RW_EXP_E}
    },
    [FLEX_ACL_KEY_IS_ROUTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ROUTED_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_20] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_21] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_22] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E}
    },
    [FLEX_ACL_KEY_CUSTOM_BYTE_23] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E}
    },
    [FLEX_ACL_KEY_ROCE_DEST_QP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEST_QP_E}
    },
    [FLEX_ACL_KEY_ROCE_PKEY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PKEY_E}
    },
    [FLEX_ACL_KEY_ROCE_BTH_OPCODE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_BTH_OPCODE_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E}
    },
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E}
    },
    [FLEX_ACL_KEY_DWORD_0_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_0_E}
    },
    [FLEX_ACL_KEY_DWORD_1_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_1_E}
    },
    [FLEX_ACL_KEY_DWORD_2_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_2_E}
    },
    [FLEX_ACL_KEY_DWORD_3_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_3_E}
    },
    [FLEX_ACL_KEY_DWORD_4_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_4_E}
    },
    [FLEX_ACL_KEY_DWORD_5_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DWORD_VALID_5_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_FID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FID_E}
    },
    [FLEX_ACL_KEY_MC_TYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E}
    },
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_IPV4_E}
    },
    [FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E}
    },
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E}
    },
    [FLEX_ACL_KEY_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E}
    },
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] =
    {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E,
                              FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E}
    },
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E}
    },
    [FLEX_ACL_KEY_INNER_IS_MPLS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E}
    },
    [FLEX_ACL_KEY_INNER_BOS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_BOS_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_TTL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] =
    {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E}
    },
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_CONTROL] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E}
    },
    [FLEX_ACL_KEY_INNER_TCP_ECN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_TCP_ECN_E}
    },
    [FLEX_ACL_KEY_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E}
    },
    [FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E}
    },
    [FLEX_ACL_KEY_TRAP_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TRAP_ID_E}
    },
    [FLEX_ACL_KEY_FDB_MISS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FDB_MISS_E}
    },
    [FLEX_ACL_KEY_LLC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LLC_VALID_E}
    },
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E}
    },
    [FLEX_ACL_KEY_LAG_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_LAG_HASH_E}
    },
    [FLEX_ACL_KEY_ECMP_HASH] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ECMP_HASH_E}
    },
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_E}
    },
    [FLEX_ACL_KEY_IS_BUM] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SMPE_VALID_E}
    },
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E}
    },
    [FLEX_ACL_KEY_PORT_USER_MEMORY] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_PORT_USER_MEM_E}
    },
    [FLEX_ACL_KEY_PACKET_IS_ELEPHANT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ELEPHANT_E}
    },
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_10] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_11] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_10_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_11_VALID] =
    {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E, FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E}
    },
    [FLEX_ACL_KEY_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_0_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E}
    },
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_0_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E}
    },
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E}
    },
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E}
    },
    [FLEX_ACL_KEY_MAC_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E}
    },
    [FLEX_ACL_KEY_IP_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E}
    },
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E}
    },
    [FLEX_ACL_KEY_DEFAULT_ROUTE_HIT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E}
    },
    [FLEX_ACL_KEY_SRC_PHY_PORT] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST_0] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_RX_PORT_LIST_1] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E}
    },

    [FLEX_ACL_KEY_RX_PORT_LIST_2] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_RX_LIST_HW_287_256_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_319_288_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_351_320_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_383_352_E}
    },

    [FLEX_ACL_KEY_RX_PORT_LIST_3] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_RX_LIST_HW_415_384_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_447_416_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_479_448_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_511_480_E,
                                                              FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST_0] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST_1] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E}
    },
    [FLEX_ACL_KEY_TX_PORT_LIST_2] = {4, (sx_acl_hw_key_e[4]) {FLEX_ACL_HW_KEY_TX_LIST_HW_287_256_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_319_288_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_351_320_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_383_352_E}
    },

    [FLEX_ACL_KEY_TX_PORT_LIST_3] = {5, (sx_acl_hw_key_e[5]) {FLEX_ACL_HW_KEY_TX_LIST_HW_415_384_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_447_416_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_479_448_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_511_480_E,
                                                              FLEX_ACL_HW_KEY_TX_LIST_HW_515_512_E}
    },

    [FLEX_ACL_KEY_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_SPI_E}
    },
    [FLEX_ACL_KEY_INNER_IPSEC_SPI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_INNER_SPI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_PCP_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_DEI] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E}
    },
    [FLEX_ACL_KEY_TUNNEL_INNER_PCP] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E}
    },
    [FLEX_ACL_KEY_IS_ARN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_IS_ARN_E}
    },
};

flex_acl_key_map_data_t macsec_acl_key_map[FLEX_ACL_KEY_LAST] = {
    [FLEX_ACL_KEY_MACSEC_DMAC] = {2, (sx_acl_hw_key_e[2]) {FLEX_ACL_HW_KEY_DMAC_31_0_E, FLEX_ACL_HW_KEY_DMAC_47_32_E}
    },
    [FLEX_ACL_KEY_MACSEC_ETHERTYPE] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_ETHERTYPE_E}
    },
    [FLEX_ACL_KEY_VLAN_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_VALID_E}
    },
    [FLEX_ACL_KEY_MACSEC_VLAN_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_VLAN_ID_E}
    },
    [FLEX_ACL_KEY_MACSEC_VNI_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MACSEC_VNI_GRE_KEY_8_31_E}
    },
    [FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MACSEC_SECY_VALID_E}
    },
    [FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MACSEC_SECY_E}
    },
    [FLEX_ACL_KEY_MACSEC_SCI_VALID] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E}
    },
    [FLEX_ACL_KEY_MACSEC_SCI] = {2, (sx_acl_hw_key_e[2]) {
                                     FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_0_31_E,
                                     FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E
                                 }
    },
    [FLEX_ACL_KEY_MACSEC_AN] = {1, (sx_acl_hw_key_e[1]) {FLEX_ACL_HW_KEY_MACSEC_SECTAG_AN_E}
    },
};

/* Set to True if the Key is covered by the Key block, done once during init for the ACL stage*/
static boolean_t key_block_relation[FLEX_ACL_KEY_BLOCK_LAST_E][FLEX_ACL_HW_KEY_LAST_E] = {
    {0}, {0}
};

typedef struct {
    uint32_t           key_block_count;
    sx_acl_key_block_e key_block;
} flex_acl_static_key_block_data_t;

/* Stores the list of Keys which are covered by at most one Key Block  */
flex_acl_static_key_block_data_t flex_acl_static_key_block_data[FLEX_ACL_HW_KEY_LAST_E] = {
    {0}
};

typedef struct {
    sx_acl_key_block_e key_block;
    sx_acl_hw_key_e    key_list[FLEX_ACL_HW_KEY_LAST_E];
    uint32_t           key_count;
} key_block_list_item_t;

/************************************************
 *  Function implementations
 ***********************************************/

static sx_status_t __flex_acl_scp_init_matrix(flex_acl_key_block_data_t *blocks,
                                              uint32_t                   key_blocks_count,
                                              acl_stage_e                acl_stage)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    b_ind = 0;
    uint32_t    i = 0;

    /*  The block below cleans "key_block_relation" array
     *  MACSEC stage initialized after FLEX ACL
     *  To prevent clearing key_block_relation that initialized for FLEX stage (next code block)
     *  we will skip clearing for MACSEC stage */
    if (acl_stage != ACL_STAGE_MACSEC) {
        for (b_ind = 0; b_ind < FLEX_ACL_KEY_BLOCK_LAST_E; b_ind++) {
            for (i = 0; i < FLEX_ACL_HW_KEY_LAST_E; i++) {
                key_block_relation[b_ind][i] = 0;
            }
        }
        memset(&flex_acl_static_key_block_data, 0, sizeof(flex_acl_static_key_block_data));
    }


    for (b_ind = 0; b_ind < key_blocks_count; b_ind++) {
        if ((blocks[b_ind].is_enabled == FALSE) ||
            ((acl_stage & blocks[b_ind].hw_key_stages) == 0)) {
            continue;
        }

        for (i = 0; i < blocks[b_ind].key_block_items_count; i++) {
            key_block_relation[b_ind][blocks[b_ind].key_block_items[i].key_id] = 1;
            /* We are only interested in Keys which have a 1-1 mapping with a Key Block,
             * if the Key is covered by more than one Key Block (i.e.key_block_count > 1)
             * then the last Key block is stored but the algorithm ignores them.
             */
            flex_acl_static_key_block_data[blocks[b_ind].key_block_items[i].key_id].key_block =
                (sx_acl_key_block_e)b_ind;
            flex_acl_static_key_block_data[blocks[b_ind].key_block_items[i].key_id].key_block_count++;
        }
    }

    return rc;
}

sx_status_t flex_acl_scp_init(acl_stage_e acl_stage)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    key_blocks_count;


    /* Set the correct key map according to stage */
    switch (acl_stage) {
    case ACL_STAGE_FLEX:
        flex_acl_max_key_blocks[acl_stage] = ACL_STAGE_FLEX_MAX_KEY_BLOCKS;
        flex_acl_key_map[acl_stage] = flex1_acl_key_map;
        key_blocks_count = FLEX_ACL_KEY_BLOCK_LAST_E;
        break;

    case ACL_STAGE_FLEX2:
        flex_acl_max_key_blocks[acl_stage] = ACL_STAGE_FLEX2_MAX_KEY_BLOCKS;
        flex_acl_key_map[acl_stage] = flex2_acl_key_map;
        key_blocks_count = FLEX_ACL_KEY_BLOCK_LAST_E;
        break;

    case ACL_STAGE_FLEX3:
        flex_acl_max_key_blocks[acl_stage] = ACL_STAGE_FLEX2_MAX_KEY_BLOCKS;
        flex_acl_key_map[acl_stage] = flex3_acl_key_map;
        key_blocks_count = FLEX_ACL_KEY_BLOCK_LAST_E;
        break;

    case ACL_STAGE_FLEX4:
        flex_acl_max_key_blocks[acl_stage] = ACL_STAGE_FLEX2_MAX_KEY_BLOCKS;
        flex_acl_key_map[acl_stage] = flex4_acl_key_map;
        key_blocks_count = FLEX_ACL_KEY_BLOCK_LAST_E;
        break;

    case ACL_STAGE_MACSEC:
        flex_acl_max_key_blocks[acl_stage] = ACL_STAGE_MACSEC_MAX_KEY_BLOCKS;
        flex_acl_key_map[acl_stage] = macsec_acl_key_map;
        key_blocks_count = FLEX_ACL_KEY_BLOCK_LAST_E;
        break;

    default:
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
        break;
    }

    if ((rc = __flex_acl_scp_init_matrix(key_block_data_dictionary,
                                         key_blocks_count, acl_stage)) != SX_STATUS_SUCCESS) {
        return rc;
    }

out:
    return SX_STATUS_SUCCESS;
}

/* Helper function for qsort*/
static int __key_cmp(const void *p1, const void *p2)
{
    uint32_t ui1, ui2;

    ui1 = *(uint32_t*)p1;
    ui2 = *(uint32_t*)p2;

    if (ui1 == ui2) {
        return 0;
    } else if (ui1 < ui2) {
        return -1;
    } else {
        return 1;
    }
}

/* Removes duplicates from an array */
static void __remove_duplicates(sx_acl_key_block_e kb_arr[], uint32_t *num_kbs)
{
    uint32_t           n = *num_kbs;
    uint32_t           i = 0;
    sx_acl_key_block_e temp_arr[n];
    uint32_t           j = 0;

    if ((n == 0) || (n == 1)) {
        return;
    }
    qsort(kb_arr, n, sizeof(sx_acl_key_block_e), __key_cmp);

    /* If current element is not equal to next element */
    /* then store that current element */
    for (i = 0; i < n - 1; i++) {
        if (kb_arr[i] != kb_arr[i + 1]) {
            temp_arr[j++] = kb_arr[i];
        }
    }

    /* Store the last element as whether it is unique or */
    /* repeated, it hasn't stored previously */
    temp_arr[j++] = kb_arr[n - 1];

    /* Modify original array */
    for (i = 0; i < j; i++) {
        kb_arr[i] = temp_arr[i];
    }

    *num_kbs = j;
}

/* Function provides a set of blocks that contain at least one of the needed keys. */
static sx_status_t __get_relevant_blocks(sx_acl_hw_key_e    *keys,
                                         uint32_t            keys_count,
                                         sx_acl_key_block_e *key_blocks,
                                         uint32_t           *key_blocks_count,
                                         sx_acl_key_block_e *static_key_blocks,
                                         uint32_t           *static_key_blocks_count,
                                         sx_acl_hw_key_e    *relevant_keys,
                                         uint32_t           *relevant_keys_count,
                                         boolean_t           is_symmetric,
                                         boolean_t           do_static)
{
    uint32_t           b = 0, k = 0, symmetric_bitmask = 0;
    sx_acl_hw_key_e    temp_keys[FLEX_ACL_HW_KEY_LAST_E + 1] = {0};
    uint32_t           temp_key_count = 0;
    boolean_t          found = FALSE;
    sx_acl_key_block_e kb = FLEX_ACL_KEY_BLOCK_LAST_E;

    symmetric_bitmask = (is_symmetric) ? SYMMETRIC_KEY_BLOCK_MASK : NON_SYMMETRIC_KEY_BLOCK_MASK;
    *static_key_blocks_count = 0;
    *relevant_keys_count = 0;
    *key_blocks_count = 0;

    if (do_static) {
        /* First allocate any static keys, i.e. keys which can only be covered by one Key Block */
        for (k = 0; k < keys_count; k++) {
            kb = FLEX_ACL_KEY_BLOCK_LAST_E;
            if (flex_acl_static_key_block_data[keys[k]].key_block_count == 1) {
                if ((symmetric_bitmask & key_block_data_dictionary[b].symmetric_bitmask) == 1) {
                    kb = flex_acl_static_key_block_data[keys[k]].key_block;
                }
            }
            if (kb != FLEX_ACL_KEY_BLOCK_LAST_E) {
                static_key_blocks[(*static_key_blocks_count)++] = kb;
            } else {
                /* Store Keys which are not covered by static Key blocks*/
                temp_keys[temp_key_count++] = keys[k];
            }
        }

        if (*static_key_blocks_count != 0) {
            /* Remove duplicates in static list*/
            __remove_duplicates(static_key_blocks, static_key_blocks_count);
            /* See if any keys can be removed because they are covered by the static list*/
            for (k = 0; k < temp_key_count; k++) {
                found = FALSE;
                for (b = 0; b < *static_key_blocks_count; b++) {
                    if ((symmetric_bitmask & key_block_data_dictionary[b].symmetric_bitmask) == 0) {
                        continue;
                    }
                    if (key_block_relation[static_key_blocks[b]][temp_keys[k]]) {
                        found = TRUE;
                        break;
                    }
                }
                /* If Key is not covered by static block, then add to relevant keys list*/
                if (found == FALSE) {
                    relevant_keys[(*relevant_keys_count)++] = temp_keys[k];
                }
            }
        } else {
            /* If no static keys, then all keys are relevant*/
            for (k = 0; k < temp_key_count; k++) {
                relevant_keys[(*relevant_keys_count)++] = temp_keys[k];
            }
        }
    } else {
        /* If do_static is disabled then all keys are relevant */
        for (k = 0; k < keys_count; k++) {
            relevant_keys[(*relevant_keys_count)++] = keys[k];
        }
    }

    *key_blocks_count = 0;

    for (b = 0; b < FLEX_ACL_KEY_BLOCK_LAST_E; b++) {
        /* Check that the symmetric type of the key is compatible with what the key block can provide */
        if ((symmetric_bitmask & key_block_data_dictionary[b].symmetric_bitmask) == 0) {
            continue;
        }
        for (k = 0; k < *relevant_keys_count; k++) {
            if (key_block_relation[b][relevant_keys[k]]) {
                key_blocks[(*key_blocks_count)++] = b;
                break;
            }
        }
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __get_next_comb(uint32_t arr[], uint32_t k, uint32_t n)
{
    uint32_t i = 0;
    int      cur = k - 1;

    if (++arr[cur] < n) {
        return SX_STATUS_SUCCESS;
    }

    /* search for new place to increase. */
    for (cur = cur - 1; cur >= 0; cur--) {
        if (++arr[cur] < n - 1) {
            for (i = cur + 1; i < k; i++) {
                arr[i] = arr[i - 1] + 1;
            }
            if (arr[k - 1] < n) {
                return SX_STATUS_SUCCESS;
            }
        }
    }

    return SX_STATUS_ERROR;
}

/* function checks if a combination of blocks contains all needed keys */
static boolean_t __is_comb_enough(sx_acl_hw_key_e    *keys,
                                  uint32_t            keys_count,
                                  uint32_t            index_arr[],
                                  uint32_t            k,
                                  sx_acl_key_block_e *relevant_blocks)
{
    uint32_t  i = 0, j = 0;
    boolean_t key_found = FALSE;

    for (i = 0; i < keys_count; i++) {
        for (j = 0, key_found = 0; j < k && !key_found; j++) {
            if (key_block_relation[relevant_blocks[index_arr[j]]][keys[i]]) {
                key_found = 1;
            }
        }
        if (!key_found) {
            return 0;
        }
    }

    return 1;
}


static sx_status_t __get_scp(acl_stage_e         acl_stage,
                             sx_acl_hw_key_e    *keys,
                             int                 keys_count,
                             sx_acl_key_block_e *relevant_blocks,
                             uint32_t            n,
                             uint32_t            k,
                             sx_acl_key_block_e *key_blocks)
{
    uint32_t i = 0, index_arr[flex_acl_max_key_blocks[acl_stage]];

    memset(index_arr, 0, sizeof(index_arr));
    /* An array of indexes is used. The array contains indexes in relevant_blocks array. This array
     *   is manipulated to contain all sets of k items out set of n items. the items are indexes in relevant_blocks
     *   array. */
    for (i = 0; i < k; i++) {
        index_arr[i] = i;
    }

    do {
        if (__is_comb_enough(keys, keys_count, index_arr, k, relevant_blocks)) {
            for (i = 0; i < k; i++) {
                key_blocks[i] = relevant_blocks[index_arr[i]];
            }
            return SX_STATUS_SUCCESS;
        }
    } while (__get_next_comb(index_arr, k, n) == SX_STATUS_SUCCESS);

    return SX_STATUS_ERROR;
}

/* The function performs a binary search for the smallest list of blocks that contain all the needed keys. */

static void __scp_calc(acl_stage_e         acl_stage,
                       sx_acl_hw_key_e    *keys,
                       int                 keys_count,
                       sx_acl_key_block_e *relevant_blocks,
                       uint32_t            relevant_blocks_count,
                       uint32_t            start,
                       uint32_t            end,
                       sx_acl_key_block_e *key_blocks,
                       uint32_t           *key_blocks_count)
{
    uint32_t mid = 0;

    if (start > end) {
        return;
    }

    mid = (start + end) / 2;
    if (__get_scp(acl_stage, keys, keys_count, relevant_blocks, relevant_blocks_count, mid,
                  key_blocks) == SX_STATUS_SUCCESS) {
        *key_blocks_count = mid;
        __scp_calc(acl_stage, keys, keys_count, relevant_blocks, relevant_blocks_count,
                   start, mid - 1, key_blocks, key_blocks_count);
    } else {
        __scp_calc(acl_stage, keys, keys_count, relevant_blocks, relevant_blocks_count,
                   mid + 1, end, key_blocks, key_blocks_count);
    }
}

/* Get the bounds, i.e. the number of Key blocks the SCP algorithm should try to get a solution*/
static sx_status_t __get_scp_bounds(acl_stage_e      acl_stage,
                                    sx_acl_hw_key_e *relevant_keys,
                                    uint32_t         relevant_keys_count,
                                    boolean_t        is_symmetric,
                                    uint32_t         relevant_blocks_count,
                                    uint32_t         static_key_blocks_count,
                                    uint32_t        *min_block_count,
                                    uint32_t        *max_block_count)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sx_acl_key_block_e greedy_approx_blocks[FLEX_ACL_KEY_BLOCK_LAST_E] = {0};
    uint32_t           greedy_approx_block_count = 0;

    /* Default to 1 to max count that needs to be checked*/
    *min_block_count = 1;
    *max_block_count = flex_acl_max_key_blocks[acl_stage] - static_key_blocks_count;

    /* If the number of candidate Key blocks is high, see if we can narrow down the search*/
    if (relevant_blocks_count > GREEDY_TEST_KEY_BLOCK_COUNT) {
        /* Greedy will give a solution that is at most ln(N) more than the valid solution*/
        flex_acl_scp_calc_greedy(acl_stage,
                                 relevant_keys,
                                 relevant_keys_count,
                                 greedy_approx_blocks,
                                 &greedy_approx_block_count,
                                 is_symmetric);

        /* If greedy says no valid solution, then no need to try return error*/
        if ((greedy_approx_block_count + static_key_blocks_count) >
            (flex_acl_max_key_blocks[acl_stage] + GREEDY_APPROX_ERR_TOLERANCE)) {
            status = SX_STATUS_ERROR;
            goto out;
        }
        /* We are close to the error but to allow for possible Greedy error, try the max possible case*/
        else if ((greedy_approx_block_count + static_key_blocks_count) > flex_acl_max_key_blocks[acl_stage]) {
            /* Greedy Approx can have error of +~1, see if there is a solution at Max KB number*/
            *min_block_count = flex_acl_max_key_blocks[acl_stage] - static_key_blocks_count;
            *max_block_count = flex_acl_max_key_blocks[acl_stage] - static_key_blocks_count;
        } else if (greedy_approx_block_count == 1) {
            /* There is a valid solution at 1 Key Block, do the SCP with 1*/
            *min_block_count = greedy_approx_block_count;
            *max_block_count = greedy_approx_block_count;
        } else {
            /* Use the greedy approx as an estimate to search for optimal we will do search for 1 smaller KB size in addition to the greedy approx
             * Most of the cases will fall in this bucket
             */
            *min_block_count = greedy_approx_block_count - 1;
            *max_block_count = greedy_approx_block_count;
        }
    }

out:
    return status;
}

/*
 * This is main API and entry point to the algorithm. It takes as input a set of Keys and
 * generates the smallest set of Key Blocks which cover the given keys. Since the brute force
 * set cover method is NP-Complete, we use some heuristics to reduce the overall run time. It
 * proceeds as below:
 * 1) Find all the Key Blocks which contain at least one of the given Keys
 * 2) Find all static Key blocks and Keys, i.e. Key Blocks and Keys which have a 1-1 mapping
 * 3) Check if the number of remaining Key blocks (after static removal) is more than a threshold, if yes proceed to 3a, else 4
 * 3a) Compute greedy approximation which runs in O(log N) time approximately. Greedy approximation can have
 * at most ln(N) error (where N is the number of Key Blocks). Set start and end points of brute-force SCP algorithm based
 * on greedy result
 * 4) Compute brute force search of optimal set cover.
 */

sx_status_t flex_acl_scp_calc(acl_stage_e         acl_stage,
                              sx_acl_hw_key_e    *keys,
                              uint32_t            keys_count,
                              sx_acl_key_block_e *key_blocks,
                              uint32_t           *key_blocks_count,
                              boolean_t           is_symmetric,
                              boolean_t           do_static)
{
    *key_blocks_count = flex_acl_max_key_blocks[acl_stage] + 1;
    sx_acl_key_block_e relevant_blocks[FLEX_ACL_KEY_BLOCK_LAST_E] = {0};
    uint32_t           relevant_blocks_count = 0;
    sx_acl_key_block_e static_key_blocks[FLEX_ACL_KEY_BLOCK_LAST_E] = {0};
    uint32_t           static_key_blocks_count = 0;
    sx_acl_hw_key_e    relevant_keys[FLEX_ACL_HW_KEY_LAST_E] = {0};
    uint32_t           relevant_keys_count = 0;
    uint32_t           min_block_count = 0, max_block_count = 0;
    sx_status_t        status = SX_STATUS_SUCCESS;
    uint32_t           i = 0;

    /* Prepare a list of only blocks that contain one of the needed keys.
     *  IN: keys/keys_count
     * OUT: relevant_blocks/ count - List of blocks which contain one of the given keys (not including static as discussed below)
     * OUT: static_key_blocks/static_key_blocks_count - List of Key blocks which have to be chosen since only these KBs can cover a given Key
     * OUT: relevant_keys/relevant_keys_count - List of Keys which are left over after static removal and we need to cover with relevant_blocks
     */
    if (__get_relevant_blocks(keys, keys_count, relevant_blocks,
                              &relevant_blocks_count, static_key_blocks, &static_key_blocks_count, relevant_keys,
                              &relevant_keys_count, is_symmetric, do_static) != SX_STATUS_SUCCESS) {
        return SX_STATUS_ERROR;
    }

    if ((static_key_blocks_count > flex_acl_max_key_blocks[acl_stage]) ||
        ((static_key_blocks_count == flex_acl_max_key_blocks[acl_stage]) && (relevant_keys_count > 0))) {
        /* No valid solution possible in these cases*/
        return SX_STATUS_ERROR;
    }

    /* See if we need to do scp, or if all are static*/
    if (relevant_keys_count > 0) {
        /* Get min and max Key block counts to try to find a solution for SCP algorithm*/
        status = __get_scp_bounds(acl_stage,
                                  relevant_keys,
                                  relevant_keys_count,
                                  is_symmetric,
                                  relevant_blocks_count,
                                  static_key_blocks_count,
                                  &min_block_count,
                                  &max_block_count);
        if (status != SX_STATUS_SUCCESS) {
            /* No valid solution possible */
            return SX_STATUS_ERROR;
        }

        /* There is potentially a valid solution, try SCP on leftover KBs and keys*/
        __scp_calc(acl_stage,
                   relevant_keys,
                   relevant_keys_count,
                   relevant_blocks,
                   relevant_blocks_count,
                   min_block_count,
                   max_block_count,
                   key_blocks,
                   key_blocks_count);
    } else {
        /* All keys are static, YAY ! */
        *key_blocks_count = 0;
    }

    if (*key_blocks_count + static_key_blocks_count > flex_acl_max_key_blocks[acl_stage]) {
        return SX_STATUS_ERROR;
    }

    for (i = 0; i < static_key_blocks_count; i++) {
        key_blocks[i + *key_blocks_count] = static_key_blocks[i];
    }
    *key_blocks_count += static_key_blocks_count;


    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_get_hw_keys(acl_stage_e     acl_stage,
                                 sx_acl_key_t    keys[],
                                 uint32_t        keys_count,
                                 sx_acl_hw_key_e hw_keys[],
                                 uint32_t       *hw_key_cnt)
{
    uint32_t    i, j, k_ind = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    for (i = 0; i < keys_count; i++) {
        if (keys[i] >= FLEX_ACL_KEY_LAST) {
            rc = SX_STATUS_ERROR;
            goto out;
        }
        if (flex_acl_key_map[acl_stage][keys[i]].hw_keys_cnt == 0) {
            rc = SX_STATUS_ERROR;
            goto out;
        }
        if (k_ind == RM_API_ACL_MAX_FIELDS_IN_KEY) {
            rc = SX_STATUS_ERROR;
            goto out;
        }
        for (j = 0; j < flex_acl_key_map[acl_stage][keys[i]].hw_keys_cnt; j++) {
            hw_keys[k_ind++] = flex_acl_key_map[acl_stage][keys[i]].hw_keys[j];
        }
    }

    *hw_key_cnt = k_ind;

out:
    return rc;
}


/*
 *  Greedy-Set-Cover(X, S) {
 *  U = X // U stores the uncovered items
 *  C = empty // C stores the sets of the cover
 *  while (U is nonempty) {
 *  select s[i] in S that covers the most elements of U
 *  add i to C
 *  remove the elements of s[i] from U
 *  }
 *  return C
 *  }
 *
 */

/*  keys_list is U/X */
/* g_key_db->relevant_key_block_list is S */
/* g_key_db->selected_key_block_list is C */
/* key_block_list_item->key_list has list of keys for that KB */


/* This creates the relevant_key_block_list by iterating over the list of keys, finding a Key block which has at least one valid key and
 * Unlike in the original algorithm, it doesn't break at this point, but continues to iterate through all the Keys and add them to the list of
 * Keys covered by the found Key block */
static sx_status_t __get_relevant_blocks_greedy(sx_acl_hw_key_e      *keys,
                                                uint32_t              keys_count,
                                                boolean_t             is_symmetric,
                                                key_block_list_item_t relevant_key_block_list[],
                                                uint32_t             *key_block_count)
{
    uint32_t  b = 0, k = 0, symmetric_bitmask;
    boolean_t found = FALSE;
    int       key_count = 0;

    *key_block_count = 0;

    symmetric_bitmask = (is_symmetric) ? SYMMETRIC_KEY_BLOCK_MASK : NON_SYMMETRIC_KEY_BLOCK_MASK;

    for (b = 0; b < FLEX_ACL_KEY_BLOCK_LAST_E; b++) {
        found = FALSE;
        key_count = 0;
        /* Check that the symmetric type of the key is compatible with what the key block can provide */
        if ((symmetric_bitmask & key_block_data_dictionary[b].symmetric_bitmask) == 0) {
            continue;
        }

        for (k = 0; k < keys_count; k++) {
            if (key_block_relation[b][keys[k]]) {
                if (found == FALSE) {
                    found = TRUE;
                    relevant_key_block_list[*key_block_count].key_block = b;
                    (*key_block_count)++;
                }
                relevant_key_block_list[*key_block_count - 1].key_list[key_count++] = keys[k];
                relevant_key_block_list[*key_block_count - 1].key_count = key_count;
            }
        }
    }

    return SX_STATUS_SUCCESS;
}
/* Find the max intersection between two sorted arrays*/
static uint32_t __max_inter(sx_acl_hw_key_e arr1[], sx_acl_hw_key_e arr2[], uint32_t m, uint32_t n)
{
    uint32_t i = 0, j = 0;
    uint32_t max_count = 0;

    while (i < m && j < n) {
        if (arr1[i] < arr2[j]) {
            i++;
        } else if (arr2[j] < arr1[i]) {
            j++;
        } else { /* if arr1[i] == arr2[j] */
            max_count++;
            i++;
            j++;
        }
    }

    return max_count;
}
/* Remove the intersection i.e. common elements between arr1 and arr2 from arr1 */
static void __remove_inter(sx_acl_hw_key_e  arr1[],
                           sx_acl_hw_key_e  arr2[],
                           uint32_t         m,
                           uint32_t         n,
                           sx_acl_hw_key_e* ret_arr,
                           uint32_t        *ret_count)
{
    uint32_t i = 0, j = 0, k = 0;

    *ret_count = 0;

    if (arr1[i] == FLEX_ACL_HW_KEY_INVALID_E) {
        return;
    }

    while (i < m && j < n) {
        if (arr1[i] < arr2[j]) {
            ret_arr[k++] = arr1[i];
            i++;
        } else if (arr2[j] < arr1[i]) {
            j++;
        } else { /* if arr1[i] == arr2[j] */
            i++;
            j++;
        }
    }

    while (i < m && arr1[i] != FLEX_ACL_HW_KEY_INVALID_E) {
        ret_arr[k++] = arr1[i++];
    }
    *ret_count = k;
}

/* The algorithm takes as input relevant_key_block_list and the list of Keys to be covered
 * Each item in the relevant_key_block_list has {Key block Id, List of keys in kb, count} .
 * It creates a key_blocks list using these two inputs
 * The goal of the algorithm is
 *    Do:
 *        Iterate through relevant_key_block_list
 *        For each element in the list:
 *             find the intersection (common elements) in the Key block key list and the input list of keys
 *             If intersection is the max so far, replace it and store the index of the max
 *        Remove max idx element from the relevant_key_block_list and add to selected_key_block_list
 *        Remove all the keys covered by the Max element from the list of keys
 *    Until all Keys are covered
 *
 */
static void __greedy_scp(sx_acl_hw_key_e      *keys,
                         int                   keys_count,
                         uint32_t              relevant_key_blocks_count,
                         key_block_list_item_t relevant_key_block_list[],
                         sx_acl_key_block_e   *key_blocks,
                         uint32_t             *key_blocks_count)
{
    /* Iterate through relevant_key_block_list and find key block that has max coverage*/
    uint32_t        max_key_count = 0;        /* Store the max num of keys in each iteration*/
    uint32_t        max_inter_count = 0;        /*Temp variable to hold max intersection for a key block */
    uint32_t        key_list_count = keys_count;
    uint32_t        temp_count = 0;
    sx_acl_hw_key_e keys_list[FLEX_ACL_HW_KEY_LAST_E] = {FLEX_ACL_HW_KEY_INVALID_E};
    sx_acl_hw_key_e temp_keys_list[FLEX_ACL_HW_KEY_LAST_E] = {FLEX_ACL_HW_KEY_INVALID_E};
    uint32_t        rel_kb_iter = 0; /* relevant key block list iterator*/
    uint32_t        sel_kb_iter = 0; /* Selected key block list iterator*/
    uint32_t        max_kb_idx = 0; /* Idx of Key block with max matching keys*/


    memcpy(keys_list, keys, sizeof(sx_acl_hw_key_e) * keys_count);

    do {
        rel_kb_iter = 0;
        while (rel_kb_iter != relevant_key_blocks_count) {
            /* If Key count is 0, this element has been removed form the list*/
            if (relevant_key_block_list[rel_kb_iter].key_count == 0) {
                rel_kb_iter++;
                continue;
            }
            /* Find the Key block which has the largest number of keys we need to cover*/
            max_inter_count = __max_inter(keys_list,
                                          relevant_key_block_list[rel_kb_iter].key_list,
                                          key_list_count,
                                          relevant_key_block_list[rel_kb_iter].key_count);
            if (max_inter_count > max_key_count) {
                max_kb_idx = rel_kb_iter;
                max_key_count = max_inter_count;
            }
            /* No need to keep looking at this KB in the next iterations, it has no Keys to cover*/
            if (max_inter_count == 0) {
                relevant_key_block_list[rel_kb_iter].key_count = 0;
            }
            rel_kb_iter++;
        } /* End of loop over all Key Blocks*/
        /* No more keys to be found, exit*/
        if (max_key_count == 0) {
            break;
        }

        /* Add top choice to selected key block list*/
        key_blocks[sel_kb_iter++] = relevant_key_block_list[max_kb_idx].key_block;

        /* Remove chosen keys from key_list */
        __remove_inter(keys_list,
                       relevant_key_block_list[max_kb_idx].key_list,
                       key_list_count,
                       relevant_key_block_list[max_kb_idx].key_count,
                       temp_keys_list,
                       &temp_count);

        /* Disable selected block from being chosen again*/
        relevant_key_block_list[max_kb_idx].key_count = 0;
        memcpy(keys_list, temp_keys_list, sizeof(sx_acl_hw_key_e) * temp_count);
        key_list_count = temp_count;
        max_key_count = 0;
        max_inter_count = 0;
        /* temp_count will have the count of remaining keys to cover */
    } while(temp_count != 0);


    /* selected_key_block_list should now have the list of selected blocks*/
    *key_blocks_count = sel_kb_iter;
}

#ifdef __VALIDATE_GREEDY_
static boolean_t __is_coverage_valid(sx_acl_hw_key_e    *keys,
                                     uint32_t            keys_count,
                                     sx_acl_key_block_e *selected_blocks,
                                     uint32_t            block_count)
{
    boolean_t key_found = FALSE;

    for (uint32_t k = 0; k < keys_count; k++) {
        key_found = FALSE;
        for (uint32_t b = 0; b < block_count; b++) {
            if (key_block_relation[selected_blocks[b]][keys[k]]) {
                key_found = TRUE;
                break;
            }
        }
        if (key_found == FALSE) {
            return 0;
        }
    }

    return 1;
}
#endif /*VALIDATE GREEDY */

sx_status_t flex_acl_scp_calc_greedy(acl_stage_e         acl_stage,
                                     sx_acl_hw_key_e    *keys,
                                     uint32_t            keys_count,
                                     sx_acl_key_block_e *key_blocks,
                                     uint32_t           *key_blocks_count,
                                     boolean_t           is_symmetric)
{
    uint32_t relevant_key_blocks_count = 0;
    /* Relevant Key Block List */
    key_block_list_item_t relevant_key_block_list[FLEX_ACL_KEY_BLOCK_LAST_E] = {
        {0}
    };

    /* Sort keys by enum value*/
    qsort(keys, keys_count, sizeof(sx_acl_hw_key_e), __key_cmp);

    /* Prepare a list of only blocks that contain one of the needed keys.
     * IN -  Keys/Keys count
     * OUT - relevant_key_block_list/ relevant_key_blocks_count - Key Blocks which cover the given Keys
     */
    if (__get_relevant_blocks_greedy(keys, keys_count, is_symmetric, relevant_key_block_list,
                                     &relevant_key_blocks_count) != SX_STATUS_SUCCESS) {
        return SX_STATUS_ERROR;
    }
    __greedy_scp(keys, keys_count, relevant_key_blocks_count, relevant_key_block_list, key_blocks, key_blocks_count);

    #ifdef __VALIDATE_GREEDY_
    /* Enable to verify that the chosen Key blocks are a valid cover of the given Keys*/
    assert(__is_coverage_valid(keys, keys_count, key_blocks, *key_blocks_count) == TRUE);
    #endif

    return (*key_blocks_count <= flex_acl_max_key_blocks[acl_stage]) ?
           SX_STATUS_SUCCESS : SX_STATUS_ERROR;
}
