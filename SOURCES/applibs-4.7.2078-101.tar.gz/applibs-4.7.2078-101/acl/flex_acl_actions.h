/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_ACTIONS_H_INCL__
#define __FLEX_ACL_ACTIONS_H_INCL__


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function validates all actions of a rule for a specified ACL region.
 *
 * Note: To get num of handles associated with this next hop, pass handles_list_cnt_p = 0;
 *
 * @param[in] rule       - pointer to the rule we want to validate.
 * @param[in] acl_region - pointer to the region info for which to validate the actions.
 * @param[in] is_flex    - Indicate if this is a flex ACL or not.
 *
 * @return SX_STATUS_SUCCESS - actions are valid.
 *         SX_STATUS_PARAM_ERROR - actions are invalid for the region.
 */
sx_status_t flex_acl_actions_validate(sx_flex_acl_flex_rule_t  *rule,
                                      flex_acl_db_acl_region_t *acl_region,
                                      boolean_t                 is_flex);

sx_status_t validate_goto_action_on_group_update(flex_acl_db_acl_group_t *acl_group,
                                                 uint32_t                 acl_ids_num,
                                                 sx_acl_id_t             *acl_ids);

sx_status_t validate_goto_action_on_groups_bind(sx_acl_id_t group_head_id, sx_acl_id_t child_group_id);

sx_status_t flex_acl_actions_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* ifndef __FLEX_ACL_ACTIONS_H_INCL__ */
