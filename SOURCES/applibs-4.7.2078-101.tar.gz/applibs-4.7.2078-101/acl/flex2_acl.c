/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ ACL


#include "flex_acl.h"
#include "flex_acl_db.h"
#include "flex_acl_hw.h"
#include "flex2_acl.h"
#include "atcam/atcam_api/sx_atcam_api.h"
#include <sx/sdk/sx_status_convertor.h>
#include "issu/issu.h"
#include "register/hwi/register_impl.h"
#include "acl/system_acl_mc.h"

/***********************************************
*  Local variables
***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_acl_initialized = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __flex2_acl_stage_get(acl_stage_e *acl_stage_p);
static sx_status_t __flex3_acl_stage_get(acl_stage_e *acl_stage_p);
static sx_status_t __flex4_acl_stage_get(acl_stage_e *acl_stage_p);
static boolean_t __flex2_acl_wc_rule_needed();
static boolean_t __flex2_acl_default_action_needed();
static sx_status_t __flex2_acl_range_validation(sx_acl_range_entry_t *range_entry_p);
static sx_status_t __flex2_acl_range_add(sx_acl_port_range_id_t *range_id_p, sx_acl_range_entry_t *range_entry_p);
static sx_status_t __flex2_acl_range_edit(sx_acl_port_range_id_t range_id, sx_acl_range_entry_t *range_entry_p);
static sx_status_t __flex2_acl_range_delete(sx_acl_port_range_id_t range_id);
static sx_status_t __flex2_acl_range_hw_set(sx_acl_port_range_id_t id, sx_acl_range_entry_t *range_entry_p);
static sx_status_t __flex2_system_acl_set_mc_register_callbacks(system_acl_client_id_e client_id,
                                                                system_acl_hw_cb_t    *system_acl_hw_cb_p,
                                                                boolean_t             *change_needed);

static acl_cb_t flex2_acl_cbs = {
    .acl_enable_system = flex_acl_enable_system,
    .acl_vlan_group_set = flex_acl_vlan_group_set,
    .acl_vlan_group_get = flex_acl_vlan_group_get,
    .acl_region_set = flex_acl_redirect_region_set,
    .acl_region_get = flex_acl_redirect_region_get,
    .acl_set = flex_acl_redirect_acl_set,
    .acl_get = flex_acl_redirect_acl_get,
    .acl_iter_get = flex_acl_iter_get,
    .acl_group_set = flex_acl_group_set,
    .acl_group_get = flex_acl_group_get,
    .acl_group_iter_get = flex_acl_group_iter_get,
    .acl_rule_activity_get = flex_acl_rule_activity_get,
    .acl_rule_activity_dump = flex2_acl_rule_activity_dump,
    .acl_rules_move = flex_acl_rules_move,
    .acl_bind_port = flex2_acl_bind_port,
    .acl_bind_port_get = flex_acl_bind_port_get,
    .acl_unbind_port = flex_acl_unbind_port,
    .acl_bind_vlan_group = flex_acl_bind_vlan_group,
    .acl_bind_vlan_group_get = flex_acl_bind_vlan_group_get,
    .acl_unbind_vlan_group = flex_acl_unbind_vlan_group,
    .acl_l4_port_range_set = flex2_acl_l4_port_range_set,
    .acl_l4_port_range_get = flex_acl_l4_port_range_get,
    .acl_l4_port_range_iter_get = flex_acl_l4_port_range_iter_get,
    .acl_pbs_set = flex_acl_pbs_set,
    .acl_pbs_get = flex_acl_pbs_get,
    .acl_pbs_iter_get = flex_acl_pbs_iter_get,
    .acl_range_set = flex2_acl_range_set,
    .acl_range_get = flex2_acl_range_get,
    .acl_pbilm_set = flex_acl_pbilm_set,
    .acl_pbilm_get = flex_acl_pbilm_get,
};

static flex_acl_ops_t flex2_acl_ops = {
    .acl_stage_get_p = __flex2_acl_stage_get,
    .acl_wc_rule_needed_p = __flex2_acl_wc_rule_needed,
    .acl_default_action_needed_p = __flex2_acl_default_action_needed,
    .system_acl_set_mc_register_callbacks_p = __flex2_system_acl_set_mc_register_callbacks,
};

static flex_acl_ops_t flex3_acl_ops = {
    .acl_stage_get_p = __flex3_acl_stage_get,
    .acl_wc_rule_needed_p = __flex2_acl_wc_rule_needed,
    .acl_default_action_needed_p = __flex2_acl_default_action_needed,
    .system_acl_set_mc_register_callbacks_p = __flex2_system_acl_set_mc_register_callbacks,
};

static flex_acl_ops_t flex4_acl_ops = {
    .acl_stage_get_p = __flex4_acl_stage_get,
    .acl_wc_rule_needed_p = __flex2_acl_wc_rule_needed,
    .acl_default_action_needed_p = __flex2_acl_default_action_needed,
    .system_acl_set_mc_register_callbacks_p = __flex2_system_acl_set_mc_register_callbacks,
};

/************************************************
**  Global variables
************************************************/
extern flex_acl_ops_t *flex_acl_ops_g;

/************************************************
 *  Local function implementations
 ***********************************************/
static sx_status_t __flex2_acl_stage_get(acl_stage_e *acl_stage_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (NULL == acl_stage_p) {
        SX_LOG_ERR("NULL pointer given as input parameter.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *acl_stage_p = ACL_STAGE_FLEX2;

out:
    return rc;
}

static sx_status_t __flex3_acl_stage_get(acl_stage_e *acl_stage_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (NULL == acl_stage_p) {
        SX_LOG_ERR("NULL pointer given as input parameter.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *acl_stage_p = ACL_STAGE_FLEX3;

out:
    return rc;
}

static sx_status_t __flex4_acl_stage_get(acl_stage_e *acl_stage_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (NULL == acl_stage_p) {
        SX_LOG_ERR("NULL pointer given as input parameter.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *acl_stage_p = ACL_STAGE_FLEX4;

out:
    return rc;
}

static boolean_t __flex2_acl_wc_rule_needed()
{
    return FALSE;
}

static boolean_t __flex2_acl_default_action_needed()
{
    return TRUE;
}

static sx_status_t __flex2_acl_range_validation(sx_acl_range_entry_t *range_entry_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_allocated = FALSE;
    acl_stage_e               acl_stage = ACL_STAGE_UNKNOWN;
    sx_acl_range_match_type_e last_match_type = SX_ACL_RANGE_MATCH_TYPE_RANGE_E;

    SX_LOG_ENTER();

    if (utils_check_pointer(range_entry_p, "range_entry_p")) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Validate ip_version field */
    if (range_entry_p->ip_version > SX_IP_VERSION_MAX) {
        SX_LOG_ERR("ACL : Unsupported IP  version [%u]\n", range_entry_p->ip_version);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate direction field */
    if (range_entry_p->direction > SX_ACL_PORT_DIRECTION_MAX) {
        SX_LOG_ERR("ACL : Unsupported port direction [%u]\n", range_entry_p->direction);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate l4_protocol field */
    if (range_entry_p->l4_protocol > SX_ACL_L4_TYPE_TCP_UDP) {
        SX_LOG_ERR("ACL : Unsupported L4 protocol type [%u]\n", range_entry_p->l4_protocol);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate outer_inner field */
    if (range_entry_p->outer_inner > SX_ACL_PORT_RANGE_IP_HEADER_INNER) {
        SX_LOG_ERR("ACL : Unsupported header type [%u]\n", range_entry_p->outer_inner);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate range_type field */
    if (range_entry_p->range_type > SX_ACL_RANGE_TYPE_MAX_E) {
        SX_LOG_ERR("ACL : Unsupported range type [%u] \n", range_entry_p->range_type);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate range_type field: ignore_l4 flag should not be set if range type is L4 Port range */
    if ((range_entry_p->range_type == SX_ACL_RANGE_TYPE_L4_PORT_E) &&
        (range_entry_p->l4_protocol == SX_ACL_L4_TYPE_INVALID)) {
        SX_LOG_ERR("ACL : 'ignore_l4' is not supported if range type is L4 port \n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate range_type field: tcp, udp flags should be 0 if range type IP Length */
    if ((range_entry_p->range_type == SX_ACL_RANGE_TYPE_IP_LENGTH_E) &&
        (range_entry_p->l4_protocol != SX_ACL_L4_TYPE_INVALID)) {
        SX_LOG_ERR("ACL : IP Length range type doesn't support l4_protocol field\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate range_type field: check types allowed only for outer headers */
    if (((range_entry_p->range_type == SX_ACL_RANGE_TYPE_TTL_E) ||
         (range_entry_p->range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) ||
         (range_entry_p->range_type == SX_ACL_RANGE_TYPE_UTC_29_14_E) ||
         (range_entry_p->range_type == SX_ACL_RANGE_TYPE_REGISTER_E) ||
         (range_entry_p->range_type == SX_ACL_RANGE_TYPE_PORT_USER_MEM_E) ||
         (range_entry_p->range_type == SX_ACL_RANGE_TYPE_PRBS_E)) &&
        (range_entry_p->outer_inner != SX_ACL_PORT_RANGE_IP_HEADER_OUTER)) {
        SX_LOG_ERR("ACL : Current range type [%u] is supported only for outer header\n", range_entry_p->outer_inner);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate range field: TTL range type supports only 8-bit length values */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_TTL_E) {
        if ((range_entry_p->range_limits.min > TTL_MAX_MASK) ||
            (range_entry_p->range_limits.max > TTL_MAX_MASK)) {
            SX_LOG_ERR("ACL : Range limits for TTL range should be in range from 0 to 255.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* Validate range field: PORT_USER_MEM range type supports only 8-bit length values */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_PORT_USER_MEM_E) {
        if ((range_entry_p->range_limits.min > PORT_USER_MEM_MAX_MASK) ||
            (range_entry_p->range_limits.max > PORT_USER_MEM_MAX_MASK)) {
            SX_LOG_ERR("ACL : Range limits for PORT_USER_MEM range should be in range from 0 to 255.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* Validate range_attr field: check Custom Bytes ACL key */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) {
        if (!is_flex_acl_key_custom_byte_key(range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id))
        {
            SX_LOG_ERR("ACL : ACL keys for Custom Byte range should be in range from %u to %u.\n",
                       FLEX_ACL_KEY_CUSTOM_BYTES_START,
                       FLEX_ACL_KEY_CUSTOM_BYTES_START +
                       (rm_resource_global.acl_custom_bytes_set_max *
                        rm_resource_global.acl_custom_bytes_set_size_max));
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    /* Validate range_attr field: check GP Register allocation */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_REGISTER_E) {
        rc = sdk_register_impl_is_allocated(range_entry_p->range_attr.register_range_attr.reg_key, &is_allocated);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to get allocation information.\n");
            goto out;
        }

        if (is_allocated != TRUE) {
            SX_LOG_ERR("ACL : Range validation - input GP register (%d) is not allocated.\n",
                       range_entry_p->range_attr.register_range_attr.reg_key.key.gp_reg.reg_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* Validate match_type field */
    if (flex_acl_ops_g->acl_stage_get_p(&acl_stage) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get flex acl stage.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (ACL_STAGE_IS_FLEX3_OR_ABOVE(acl_stage)) {
        last_match_type = SX_ACL_RANGE_MATCH_TYPE_EXACT_E;
    } else {
        last_match_type = SX_ACL_RANGE_MATCH_TYPE_RANGE_E;
    }

    if (range_entry_p->match_type > last_match_type) {
        SX_LOG_ERR("ACL : Unsupported range match_type [%u] \n", range_entry_p->match_type);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validate range_limits field */
    if (range_entry_p->range_limits.min > range_entry_p->range_limits.max) {
        SX_LOG_ERR("ACL : Max limit [%u] could not be less than Min limit [%u]\n",
                   range_entry_p->range_limits.max, range_entry_p->range_limits.min);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex2_acl_range_add(sx_acl_port_range_id_t *range_id_p, sx_acl_range_entry_t *range_entry_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_status_t            rb_rc = SX_STATUS_SUCCESS;
    sx_acl_port_range_id_t id = 0;

    SX_LOG_ENTER();

    /* Validate the range */
    rc = __flex2_acl_range_validation(range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to add new range\n");
        goto out;
    }

    /* Validate available port range register */
    rc = flex_acl_db_port_range_get_available_idx(&id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to add new range (no available port range)\n");
        goto out;
    }

    /* Return the index upwards  */
    *range_id_p = id;

    /* Write ranges to DB*/
    rc = flex_acl_db_range_update(id, range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update range [%u] in db\n", id);
        goto out;
    }

    /* Try to configure HW */
    rc = __flex2_acl_range_hw_set(id, range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        rb_rc = flex_acl_db_range_delete(id);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }

        SX_LOG_ERR("ACL : Failed to write range id [%u] to HW\n", id);
        goto out;
    }

    /* Lock Custom Bytes set */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) {
        rc = flex_acl_keys_custom_bytes_set_lock_unlock(
            range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id,
            SX_ACCESS_CMD_CREATE,
            FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock custom bytes set, key_id [%u] .\n",
                       range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

static sx_status_t __flex2_acl_range_edit(sx_acl_port_range_id_t range_id, sx_acl_range_entry_t *range_entry_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_status_t          rb_rc = SX_STATUS_SUCCESS;
    sx_acl_range_entry_t rollback_entry;

    SX_LOG_ENTER();
    SX_MEM_CLR(rollback_entry);

    /* Validate the range */
    rc = __flex2_acl_range_validation(range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to edit range (max range must be >= min range)\n");
        goto out;
    }

    /* DB pre edit validations*/
    rc = flex_acl_db_range_pre_edit(range_id, range_entry_p);
    if (SX_STATUS_ENTRY_ALREADY_EXISTS == rc) {
        /* no need to update DB or HW */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Pre edit range failed\n");
        goto out;
    }

    /* Get the range from DB */
    rc = flex_acl_db_range_get(range_id, &rollback_entry);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get range id [%u] in db\n", range_id);
        goto out;
    }

    /* Write ranges to DB*/
    rc = flex_acl_db_range_update(range_id, range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update range [%u] in db\n", range_id);
        goto out;
    }

    /* Try to configure HW */
    rc = __flex2_acl_range_hw_set(range_id, range_entry_p);
    if (SX_STATUS_SUCCESS != rc) {
        rb_rc = flex_acl_db_range_update(range_id, &rollback_entry);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
        SX_LOG_ERR("ACL : Failed to write range id [%u] to HW\n", range_id);
        goto out;
    }

    /* Unlock Custom Bytes set */
    if ((rollback_entry.range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) &&
        (range_entry_p->range_type != SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E)) {
        rc = flex_acl_keys_custom_bytes_set_lock_unlock(
            rollback_entry.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id,
            SX_ACCESS_CMD_DELETE,
            FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock custom bytes set, key_id [%u] .\n",
                       rollback_entry.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id);
            goto out;
        }
    }

    /* Lock Custom Bytes set */
    if ((rollback_entry.range_type != SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) &&
        (range_entry_p->range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E)) {
        rc = flex_acl_keys_custom_bytes_set_lock_unlock(
            range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id,
            SX_ACCESS_CMD_CREATE,
            FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock custom bytes set, key_id [%u] .\n",
                       range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex2_acl_range_delete(sx_acl_port_range_id_t range_id)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_acl_range_entry_t range_entry;

    SX_LOG_ENTER();
    SX_MEM_CLR(range_entry);

    /* Get the range from DB */
    rc = flex_acl_db_range_get(range_id, &range_entry);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get port range id [%u] in db\n", range_id);
        goto out;
    }

    /* Delete range from DB, no HW intervention */
    rc = flex_acl_db_range_delete(range_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to delete range [%u]. rc=[%u]\n", range_id, rc);
        goto out;
    }

    /* Unlock Custom Bytes set */
    if (range_entry.range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) {
        rc = flex_acl_keys_custom_bytes_set_lock_unlock(
            range_entry.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id,
            SX_ACCESS_CMD_DELETE,
            FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock custom bytes set, key_id [%u] .\n",
                       range_entry.range_attr.custom_bytes_range_attr.custom_bytes_set_key_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex2_acl_range_hw_set(sx_acl_port_range_id_t id, sx_acl_range_entry_t     *range_entry_p)
{
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t    dev_info_arr_size = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Prepare a list of relevant devices */
    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list\n");
        goto out;
    }

    /* Write data to the HW */
    rc = flex_acl_hw_set_range(range_entry_p, id, devs_list, dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set range [%u]\n", id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex2_system_acl_set_mc_register_callbacks(system_acl_client_id_e client_id,
                                                                system_acl_hw_cb_t    *system_acl_hw_cb_p,
                                                                boolean_t             *change_needed)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(client_id);

    if (utils_check_pointer(system_acl_hw_cb_p, "system_acl_hw_cb_p")) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(change_needed, "change_needed")) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* For stateful DB we need to replace the region/acl/rule hw write callbacks.
     * This region will only be used for writing failure actions.
     */
    if (client_id == SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E) {
        system_acl_hw_cb_p->region_hw_cb = system_acl_hw_write_region_dummy;
        system_acl_hw_cb_p->acl_hw_cb = system_acl_hw_write_acl_dummy;
        system_acl_hw_cb_p->rule_hw_cb = system_acl_hw_write_rule_stateful_db;
        *change_needed = TRUE;
    } else {
        /* Indicate there is no need to change the default callbacks for flex2 MC. */
        *change_needed = FALSE;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t flex2_acl_init_ops(void)
{
    return flex_acl_set_ops(&flex2_acl_ops);
}

sx_status_t flex3_acl_init_ops(void)
{
    return flex_acl_set_ops(&flex3_acl_ops);
}

sx_status_t flex4_acl_init_ops(void)
{
    return flex_acl_set_ops(&flex4_acl_ops);
}

sx_status_t flex2_acl_init(sx_api_sx_sdk_init_t *init_params)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    atcam_attributes_t atcam_api_params;
    sx_boot_mode_e     issu_boot_mode;


    SX_LOG_ENTER();
    SX_MEM_CLR(atcam_api_params);

    /* Do a sanity check that the size of the region allowed is no larger than the max priority.
     * This is done to correctly support legacy mode in which offset is also the priority.
     */
    if (rm_resource_global.acl_region_size_max >= FLEX_ACL_RULE_PRIORITY_MAX) {
        SX_LOG_ERR("Failed to init Flex ACL since max region size [%u] is larger/equal to max priority [%u]\n",
                   rm_resource_global.acl_region_size_max, FLEX_ACL_RULE_PRIORITY_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto error;
    }

    /* Init Flex ACL & set Flex2 ACL callbacks*/
    rc = flex_acl_init_with_callbacks(init_params, &flex2_acl_cbs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init Flex ACL\n");
        goto error;
    }

    atcam_api_params.shadow_region_create_cb = flex_acl_create_shadow_acl_region;
    atcam_api_params.shadow_region_remove_cb = flex_acl_remove_shadow_acl_region;

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    /* The ATCAM module will reserve space to all regions.
     * In ISSU mode the ACL module should address only the relevant regions.
     */
    atcam_api_params.num_of_atcam_regions = rm_resource_global.acl_regions_max;

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        atcam_api_params.num_of_atcam_erps = 256;
    } else {
        atcam_api_params.num_of_atcam_erps = 512;
    }

    rc = sx_atcam_api_init(&atcam_api_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init atcam\n");
        goto error;
    }
    g_acl_initialized = TRUE;
    goto out;

error:
    g_acl_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return rc;
}

void flex2_acl_deinit(void)
{
    SX_LOG_ENTER();

    flex_acl_deinit();
    sx_atcam_api_deinit(TRUE);
    g_acl_initialized = FALSE;

    SX_LOG_EXIT();
}

sx_status_t flex2_acl_range_set(sx_api_acl_range_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_acl_initialized) {
        SX_LOG_ERR("ACL Modules was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_ADD:
        rc = __flex2_acl_range_add(&(params->range_id), &(params->range_entry));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to add new range. rc=[%u]\n", rc);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        rc = __flex2_acl_range_edit(params->range_id, &(params->range_entry));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to edit range [%u]. rc=[%u]\n", params->range_id, rc);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        rc = __flex2_acl_range_delete(params->range_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to delete range [%u]. rc=[%u]\n", params->range_id, rc);
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("ACL: [%s] unsupported.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_range_get(sx_api_acl_range_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_acl_initialized) {
        SX_LOG_ERR("ACL Modules was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Get port range from db */
    rc = flex_acl_db_range_get(params->range_id, &(params->range_entry));
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get range from db [%u]. rc=[%u]\n", params->range_id, rc);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_l4_port_range_set(sx_api_acl_l4_range_params_t *params_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_api_acl_range_params_t flex2_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(flex2_params);

    /* Backward compatible flow: map Flex ACL L4 range params to Flex2 ACL range params */
    flex2_params.cmd = params_p->cmd;
    if (params_p->cmd != SX_ACCESS_CMD_ADD) {
        /* Copy range ID in case of EDIT or DELETE command */
        flex2_params.range_id = params_p->range_id;
    }

    flex2_params.range_entry.range_limits.min = params_p->l4_port_range.port_range_min;
    flex2_params.range_entry.range_limits.max = params_p->l4_port_range.port_range_max;
    flex2_params.range_entry.direction = params_p->l4_port_range.port_range_direction;
    flex2_params.range_entry.outer_inner = params_p->l4_port_range.port_range_ip_header;
    flex2_params.range_entry.ip_version = SX_IP_VERSION_IPV4_IPV6;
    if (params_p->l4_port_range.port_range_ip_length == FALSE) {
        flex2_params.range_entry.range_type = SX_ACL_RANGE_TYPE_L4_PORT_E;
        flex2_params.range_entry.l4_protocol = SX_ACL_L4_TYPE_TCP_UDP;
    } else {
        flex2_params.range_entry.range_type = SX_ACL_RANGE_TYPE_IP_LENGTH_E;
    }

    rc = flex2_acl_range_set(&flex2_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set range. rc=[%u]\n", rc);
        goto out;
    }

    if (params_p->cmd == SX_ACCESS_CMD_ADD) {
        /* Return new range ID */
        params_p->range_id = flex2_params.range_id;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params)
{
    sx_status_t                           status = SX_STATUS_SUCCESS;
    sx_utils_status_t                     utils_status = SX_UTILS_STATUS_SUCCESS;
    flex_acl_db_acl_region_t             *acl_region = NULL;
    sx_acl_rule_offset_t                  offset = 0;
    sx_api_acl_rule_activity_get_params_t activity_params = {0};
    uint32_t                              num_entries = 0;
    uint32_t                              region_size = 0, i = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(params, "params")) {
        status = SX_STATUS_ERROR;
        goto out;
    }

    offset = params->rule_offset;
    num_entries = params->num_entries;

    if (FALSE == g_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = flex_acl_db_region_get(params->region_id, &acl_region);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("ACL : Failed to get Region ID 0x%x [%u]\n", params->region_id, params->region_id);
        goto out;
    }

    if (acl_region->bound_acl == FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_DBG("ACL : ACL region [%u] not bound to an ACL table %d\n", params->region_id, acl_region->bound_acl);
        goto out;
    }

    region_size = (acl_region->size - acl_region->reserved_rules_num);

    /* Size validation */
    if ((offset + num_entries) > region_size) {
        SX_LOG_ERR("ACL : requested num entries [%u] exceeds ACL region size [%u]\n", offset, region_size);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* set params for activity get */
    activity_params.cmd = params->cmd;
    activity_params.region_id = params->region_id;
    activity_params.rule_offset = offset;

    switch (params->cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        for (i = 0; i < num_entries; ++i) {
            if (acl_region->rules[activity_params.rule_offset].valid != TRUE) {
                ++activity_params.rule_offset;
                continue;
            }

            status = flex_acl_rule_activity_get_internal(&activity_params);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to get activity on offset 0x%x -- err = %s \n",
                           activity_params.rule_offset, sx_status_str(status));
                goto out;
            }

            if (activity_params.activity) {
                utils_status = bit_vector_set(params->activities, activity_params.rule_offset);
                if (SX_UTILS_CHECK_FAIL(utils_status)) {
                    status = sx_utils_status_to_sx_status(utils_status);
                    SX_LOG_ERR("Failed to assign array of bits to bit_vector, err = [%s]\n",
                               sx_status_str(status));
                    goto out;
                }
            }
            ++activity_params.rule_offset;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("ACL: activity dump is not supported with CMD: [%s].\n", sx_access_cmd_str(params->cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:

    SX_LOG_EXIT();
    return status;
}

sx_status_t flex2_acl_bind_port(sx_api_acl_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* Check that group id is user group */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }

    /* Validate Port */
    rc = flex_acl_validate_port(params->log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to validate port[%#x]\n", params->log_port);
        goto out;
    }

    rc = flex_acl_bind_port_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at port bind, port 0x[%x] to group 0x[%x]\n", params->log_port, params->acl_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}
