/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <sx/sdk/sx_event.h>
#include <sx/sdk/sx_port_id.h>
#include <sx/sdk/sx_policer.h>
#include <utils/utils.h>
#include <sx/sxd/sxd_access_register.h>
#include "bridge_lib/bridge_common.h"
#include "ethl2/brg.h"
#include "ethl2/topo.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "utils/sx_adviser.h"
#include "utils/port_type_validate.h"
#include "ethl2/lag_sink.h"
#include "ethl2/la_db.h"
#include "ethl2/fdb.h"
#include "ethl2/vlan.h"
#include "ethl2/fdb_mc_impl.h"
#include "policer/policer_db.h"
#include "policer_lib/policer_common.h"
#include "acl.h"
#include "flex_acl.h"
#include "flex2_acl.h"
#include "flow_counter/flow_counter.h"
#include "ethl2/fdb_mc_db_records.h"
#include <include/resource_manager/resource_manager.h>
#include "resource_manager/resource_manager_sdk_table.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t acl_enable_system(boolean_t enable)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_enable_system(enable);
}

sx_status_t acl_region_set(sx_api_acl_region_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_region_set(params);
}

sx_status_t acl_set(sx_api_acl_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_set(params);
}

sx_status_t acl_get(sx_api_acl_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_get(params);
}

sx_status_t acl_iter_get(sx_api_acl_iter_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_iter_get(params);
}

sx_status_t acl_region_get(sx_api_acl_region_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_region_get(params);
}

sx_status_t acl_group_set(sx_api_acl_group_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }
    return acl_cb_p->acl_group_set(params);
}

sx_status_t acl_group_get(sx_api_acl_group_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_group_get(params);
}

sx_status_t acl_group_iter_get(sx_api_acl_group_iter_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_group_iter_get(params);
}

sx_status_t acl_rule_activity_get(sx_api_acl_rule_activity_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_rule_activity_get(params);
}

sx_status_t acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_rule_activity_dump(params);
}

sx_status_t acl_rules_move(sx_api_acl_block_move_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_rules_move(params);
}

sx_status_t acl_bind_port(sx_api_acl_bind_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_bind_port(params);
}

sx_status_t acl_bind_port_get(sx_api_acl_bind_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_bind_port_get(params);
}

sx_status_t acl_unbind_port(sx_api_acl_bind_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_unbind_port(params);
}

sx_status_t acl_bind_vlan_group(sx_api_acl_bind_params_t *params, boolean_t rebinding)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_bind_vlan_group(params, rebinding);
}

sx_status_t acl_bind_vlan_group_get(sx_api_acl_bind_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_bind_vlan_group_get(params);
}

sx_status_t acl_unbind_vlan_group(sx_api_acl_bind_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_unbind_vlan_group(params);
}

sx_status_t acl_l4_port_range_set(sx_api_acl_l4_range_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_l4_port_range_set(params);
}

sx_status_t acl_l4_port_range_get(sx_api_acl_l4_range_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_l4_port_range_get(params);
}

sx_status_t acl_range_set(sx_api_acl_range_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_range_set(params);
}

sx_status_t acl_range_get(sx_api_acl_range_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_range_get(params);
}

sx_status_t acl_pbs_iter_get(sx_api_acl_pbs_iter_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_pbs_iter_get(params);
}


sx_status_t acl_l4_port_range_iter_get(sx_api_acl_l4_port_range_iter_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_l4_port_range_iter_get(params);
}

sx_status_t acl_pbs_set(sx_api_acl_pbs_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_pbs_set(params);
}

sx_status_t acl_pbs_get(sx_api_acl_pbs_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_pbs_get(params);
}

sx_status_t acl_pbilm_set(sx_api_acl_pbilm_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_pbilm_set(params);
}

sx_status_t acl_pbilm_get(sx_api_acl_pbilm_get_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_pbilm_get(params);
}

sx_status_t acl_vlan_group_set(sx_api_acl_vlan_group_set_params_t *params)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_vlan_group_set(params);
}

sx_status_t acl_vlan_group_get(sx_acl_vlan_group_t group_id,
                               sx_swid_id_t        swid,
                               sx_vlan_id_t       *vlan_list,
                               uint32_t           *vlan_num)
{
    acl_cb_t* acl_cb_p = acl_get_cb();

    if (NULL == acl_cb_p) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    return acl_cb_p->acl_vlan_group_get(group_id, swid, vlan_list, vlan_num);
}

static sx_status_t __acl_is_flex_acl(boolean_t *is_flex)
{
    *is_flex = TRUE;

    return SX_STATUS_SUCCESS;
}


sx_status_t acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_flex;

    err = __acl_is_flex_acl(&is_flex);
    if (SX_STATUS_SUCCESS != err) {
        return err;
    }

    if (is_flex == TRUE) {
        err = flex_acl_log_verbosity_level_set(verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            return err;
        }

        return flex2_acl_log_verbosity_level_set(verbosity_level);
    }

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t acl_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_flex;

    err = __acl_is_flex_acl(&is_flex);
    if (SX_STATUS_SUCCESS != err) {
        return err;
    }

    if (is_flex == TRUE) {
        return flex_acl_log_verbosity_level_get(verbosity_level);
    }

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return err;
}
