/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#define  FLEX_ACL_HW_C_
#include "acl.h"
#include "flex_acl_hw.h"
#include "flex_acl_hw_common.h"
#include "flex_acl_hw_db.h"
#include "flex_acl_hw_actions.h"
#include "flex_acl_tcam_manager.h"
#undef   FLEX_ACL_HW_C_
#include "flex_acl_keys.h"
#include "issu/issu.h"
#include "ethl3/router_common.h"
#include "ethl2/vlan.h"
#include "ethl2/port.h"
#include <utils/utils.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include <kvd/kvd_linear_manager.h>
#include <sx/sxd/sxd_access_register.h>
#include "ethl2/port.h"
#include "sx/utils/gc.h"
#include "sx/sdk/sx_status_convertor.h"
#include "atcam/atcam_api/sx_atcam_api.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/atcam_regions_manager/atcam_regions_manager.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Local Defines
 ***********************************************/

#define FLEX_ACL_LATE_BINDING_PORT_KEY(direction, log_port) \
    ((uint64_t)(direction % 2) << 63 | log_port)
#define FLEX_ACL_LATE_BINDING_RIF_KEY(direction, rif) \
    ((uint64_t)(direction % 2) << 63 | rif)
#define FLEX_ACL_LATE_BINDING_VLAN_KEY(vlan) \
    (vlan)

#define FLEX_ACL_HW_BULK_DUMP_ACTIVITY_CHECK_RANGE(record_number) ((record_number > 0) && (record_number <= 256))

/***********************************************
*  Local variables
***********************************************/

static sx_status_t flex_acl_hw_write_rule_register(acl_rule_hw_op_e        op,
                                                   sx_dev_id_t             dev_id,
                                                   sx_acl_region_id_t      region_id,
                                                   const void             *region_info,
                                                   sx_acl_rule_offset_t    offset,
                                                   boolean_t               is_valid,
                                                   uint32_t                priority,
                                                   sx_flex_acl_key_desc_t *keys,
                                                   uint32_t                keys_cnt,
                                                   sx_acl_key_block_e     *key_blocks,
                                                   uint32_t                key_blocks_cnt,
                                                   sxd_flex_action_set_t  *reg_action_set,
                                                   boolean_t              *activity_value,
                                                   boolean_t               bulk_write);
static sx_status_t flex2_acl_hw_write_rule_register(acl_rule_hw_op_e        op,
                                                    sx_dev_id_t             dev_id,
                                                    sx_acl_region_id_t      region_id,
                                                    const void             *region_info,
                                                    sx_acl_rule_offset_t    offset,
                                                    boolean_t               is_valid,
                                                    uint32_t                priority,
                                                    sx_flex_acl_key_desc_t *keys,
                                                    uint32_t                keys_cnt,
                                                    sx_acl_key_block_e     *key_blocks,
                                                    uint32_t                key_blocks_cnt,
                                                    sxd_flex_action_set_t  *reg_action_set,
                                                    boolean_t              *activity_value,
                                                    boolean_t               bulk_write);
static sx_status_t flex2_acl_hw_write_region_register(acl_region_op_e     region_op,
                                                      sx_dev_id_t         dev_id,
                                                      sx_acl_region_id_t  region_id,
                                                      sx_acl_key_type_t   key_handle,
                                                      sx_acl_key_block_e *key_blocks,
                                                      uint32_t            key_blocks_cnt,
                                                      uint8_t            *tcam_region_info,
                                                      uint32_t            tcam_region_info_size,
                                                      sx_acl_size_t       new_size,
                                                      sx_acl_size_t      *allocated_size_p,
                                                      boolean_t           stateful_db_region);
static sx_status_t flex_acl_hw_move_rule_register(acl_move_rule_hw_op_e op,
                                                  sx_dev_id_t           dev_id,
                                                  sx_acl_region_id_t    src_region_id,
                                                  sx_acl_region_id_t    dst_region_id,
                                                  const void           *src_region_info,
                                                  const void           *dst_region_info,
                                                  sx_acl_rule_offset_t  src_offset,
                                                  sx_acl_rule_offset_t  dst_offset,
                                                  uint32_t              size,
                                                  boolean_t             change_priority);
static sx_status_t flex2_acl_hw_move_rule_register(acl_move_rule_hw_op_e op,
                                                   sx_dev_id_t           dev_id,
                                                   sx_acl_region_id_t    src_region_id,
                                                   sx_acl_region_id_t    dst_region_id,
                                                   const void           *src_region_info,
                                                   const void           *dst_region_info,
                                                   sx_acl_rule_offset_t  src_offset,
                                                   sx_acl_rule_offset_t  dst_offset,
                                                   uint32_t              size,
                                                   boolean_t             change_priority);
static sx_status_t flex_acl_hw_write_region_register(acl_region_op_e     region_op,
                                                     sx_dev_id_t         dev_id,
                                                     sx_acl_region_id_t  region_id,
                                                     sx_acl_key_type_t   key_handle,
                                                     sx_acl_key_block_e *key_blocks,
                                                     uint32_t            key_blocks_cnt,
                                                     uint8_t            *tcam_region_info,
                                                     uint32_t            tcam_region_info_size,
                                                     sx_acl_size_t       new_size,
                                                     sx_acl_size_t      *allocated_size_p,
                                                     boolean_t           stateful_db_region);
static sx_status_t flex_acl_hw_write_acl_register(sx_acl_id_t        acl_id,
                                                  sx_acl_direction_t direction,
                                                  uint8_t           *region_info,
                                                  uint32_t           region_info_size,
                                                  sx_dev_id_t        dev_id,
                                                  boolean_t          valid);
static sx_status_t flex2_acl_hw_activity_read_register(acl_rule_hw_op_e        op,
                                                       sx_dev_id_t             dev_id,
                                                       sx_acl_region_id_t      region_id,
                                                       const void             *region_info,
                                                       sx_acl_rule_offset_t    offset,
                                                       boolean_t               is_valid,
                                                       uint32_t                priority,
                                                       sx_flex_acl_key_desc_t *keys,
                                                       uint32_t                keys_cnt,
                                                       sx_acl_key_block_e     *key_blocks,
                                                       uint32_t                key_blocks_cnt,
                                                       sxd_flex_action_set_t  *reg_action_set,
                                                       boolean_t              *activity_value,
                                                       boolean_t               bulk_write);
static sx_status_t flex2_acl_hw_activity_bulk_dump_register(sx_dev_id_t              dev_id,
                                                            sx_acl_region_id_t       region_id,
                                                            boolean_t                clear,
                                                            boolean_t                force_end,
                                                            sxd_pefaad_index_dump_t *record_p,
                                                            uint32_t                *record_num_p);
static sx_status_t flex_acl_hw_activity_dump(boolean_t            is_clear,
                                             sx_dev_id_t          dev_id,
                                             const void          *region_info,
                                             sx_acl_rule_offset_t offset,
                                             uint32_t             num_entries,
                                             bit_vector_t        *activities_p);
static sx_status_t flex_acl_hw_prio_change_register(sx_acl_region_id_t region_id,
                                                    const uint32_t     min_prio,
                                                    const uint32_t     max_prio,
                                                    const int32_t      prio_change);
static sx_status_t flex2_acl_hw_prio_change_register(sx_acl_region_id_t region_id,
                                                     const uint32_t     min_prio,
                                                     const uint32_t     max_prio,
                                                     const int32_t      prio_change);
static sx_status_t flex2_acl_hw_write_global_mask_register(sx_dev_id_t        dev_id,
                                                           sx_acl_region_id_t region_id,
                                                           uint8_t            global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);
static sx_status_t flex2_acl_hw_write_lookup_region_register(sx_dev_id_t              dev_id,
                                                             const sx_acl_region_id_t region_id,
                                                             const sx_acl_region_id_t lookup_region_id);

/* Is used by FLEX1 to store the ACL IDs used for commit ACLs. */
static sx_acl_id_t commit_acl[SX_ACL_DIRECTION_LAST] =
{FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID,
 FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID, FLEX_ACL_INVALID_ACL_ID,
 FLEX_ACL_INVALID_ACL_ID};

/* Default call backs that will be used to write to FLEX1 registers. */
static flex_acl_hw_reg_cb_t flex1_default_register_cbs = {.rule_hw_cb = flex_acl_hw_write_rule_register,
                                                          .region_hw_cb = flex_acl_hw_write_region_register,
                                                          .move_rule_hw_cb = flex_acl_hw_move_rule_register,
                                                          .acl_register_cb = flex_acl_hw_write_acl_register,
                                                          .activity_register_cb = flex_acl_hw_write_rule_register,
                                                          .activity_dump_hw_cb = flex_acl_hw_activity_dump,
                                                          .action_hw_cb = flex_acl_hw_write_action_register,
                                                          .prio_change_hw_cb = flex_acl_hw_prio_change_register,
                                                          .activity_bulk_dump_hw_cb = NULL,
                                                          .config_uc_tunnel_pbs_write_cb =
                                                              flex_acl_hw_config_uc_tunnel_pbs_write,
                                                          .global_mask_hw_cb = NULL,
                                                          .lookup_region_hw_cb = NULL};

/* Default call backs that will be used to write to FLEX2 registers. */
static flex_acl_hw_reg_cb_t flex2_default_register_cbs = {.rule_hw_cb = flex2_acl_hw_write_rule_register,
                                                          .region_hw_cb = flex2_acl_hw_write_region_register,
                                                          .move_rule_hw_cb = flex2_acl_hw_move_rule_register,
                                                          .acl_register_cb = flex_acl_hw_write_acl_register,
                                                          .activity_register_cb = flex2_acl_hw_activity_read_register,
                                                          .activity_dump_hw_cb = flex_acl_hw_activity_dump,
                                                          .action_hw_cb = flex2_acl_hw_write_action_register,
                                                          .prio_change_hw_cb = flex2_acl_hw_prio_change_register,
                                                          .activity_bulk_dump_hw_cb =
                                                              flex2_acl_hw_activity_bulk_dump_register,
                                                          .config_uc_tunnel_pbs_write_cb =
                                                              flex2_acl_hw_config_uc_tunnel_pbs_write,
                                                          .global_mask_hw_cb =
                                                              flex2_acl_hw_write_global_mask_register,
                                                          .lookup_region_hw_cb =
                                                              flex2_acl_hw_write_lookup_region_register};

/* Is used by FLEX2 as the handle to the kvd memory allocated to all the regions' default actions. */
kvd_linear_manager_handle_t default_action_kvd_handle = FLEX_ACL_INVALID_KVD_HANDLE;
/* Pointer to the relevant register callbacks for FLEX1 or FLEX2. Will be set at initialization*/
flex_acl_hw_reg_cb_t *default_register_cbs_p = NULL;
/* Stores the flex stage we are working with. Will be set at initialization */
acl_stage_e          flex_acl_stage = ACL_STAGE_UNKNOWN;
sx_tcam_opt_params_t tcam_opt_params_g;
/************************************************
 *  Local function declarations
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_status_t __flex_acl_hw_get_is_commit(sx_acl_id_t              acl_id,
                                               flex_acl_db_flex_rule_t *rule_p,
                                               boolean_t               *is_commit);
static sx_status_t __flex_acl_hw_handle_late_binding(boolean_t                     *late_binding_p,
                                                     uint64_t                       key,
                                                     flex_acl_hw_db_binding_data_t *data_p);
static sx_status_t __flex_acl_hw_reg_write_ppbt(flex_acl_hw_db_binding_data_t *binding_data_p);
static sx_status_t __flex_acl_hw_reg_write_prbt(flex_acl_hw_db_binding_data_t *binding_data_p);
static sx_status_t __flex_acl_hw_reg_write_pvgt(flex_acl_hw_db_binding_data_t *binding_data_p);
/************************************************
 *  Global variables
 ***********************************************/
acl_hw_custom_bytes_set_data_t custom_bytes_set_hw_data[] = {
    [ACL_CUSTOM_BYTES_SET_0] = {SXD_ACL_CUSTOM_BYTE_SET0},
    [ACL_CUSTOM_BYTES_SET_1] = {SXD_ACL_CUSTOM_BYTE_SET1},
    [ACL_CUSTOM_BYTES_SET_2] = {SXD_ACL_CUSTOM_BYTE_SET2},
    [ACL_CUSTOM_BYTES_SET_3] = {SXD_ACL_CUSTOM_BYTE_SET3},
    [ACL_CUSTOM_BYTES_SET_4] = {SXD_ACL_CUSTOM_BYTE_SET4},
    [ACL_CUSTOM_BYTES_SET_5] = {SXD_ACL_CUSTOM_BYTE_SET5},
    [ACL_CUSTOM_BYTES_SET_6] = {SXD_ACL_CUSTOM_BYTE_SET6},
    [ACL_CUSTOM_BYTES_SET_7] = {SXD_ACL_CUSTOM_BYTE_SET7},
    [ACL_CUSTOM_BYTES_SET_8] = {SXD_ACL_CUSTOM_BYTE_SET8},
    [ACL_CUSTOM_BYTES_SET_9] = {SXD_ACL_CUSTOM_BYTE_SET9},
    [ACL_CUSTOM_BYTES_SET_10] = {SXD_ACL_CUSTOM_BYTE_SET10},
    [ACL_CUSTOM_BYTES_SET_11] = {SXD_ACL_CUSTOM_BYTE_SET11},
};
acl_hw_extraction_point_data_t extraction_points_hw_data[] = {
    [ACL_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_START_OF_PACKET},
    [ACL_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE] = {SXD_ACL_EXTRACTION_POINT_ETHER_TYPE},
    [ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_IPV4_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_IPV4_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_ARP},
    [ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_IPV6_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_IPV6_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_MPLS_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_MPLS_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_GRE_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_GRE_PAYLOLAD},
    [ACL_EXTRACTION_POINT_TYPE_UDP_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_UDP_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_INNER_MAC_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE] = {SXD_ACL_EXTRACTION_POINT_INNER_ETHER_TYPE},
    [ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_INNER_IPV4_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_INNER_IPV4_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER] = {SXD_ACL_EXTRACTION_POINT_INNER_IPV6_HEADER},
    [ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_INNER_IPV6_PAYLOAD},
    [ACL_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD] = {SXD_ACL_EXTRACTION_POINT_INNER_UDP_PAYLOAD},
};
static sxd_pprr_ip_length_t    range_map[] = {
    [SX_ACL_RANGE_TYPE_L4_PORT_E] = SXD_PPRR_IP_LENGTH_L4_PORT_E,
    [SX_ACL_RANGE_TYPE_IP_LENGTH_E] = SXD_PPRR_IP_LENGTH_IP_LENGTH_E,
    [SX_ACL_RANGE_TYPE_TTL_E] = SXD_PPRR_IP_LENGTH_TTL_E,
    [SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E] = SXD_PPRR_IP_LENGTH_CUSTOM_BYTE_SET_E,
    [SX_ACL_RANGE_TYPE_UTC_29_14_E] = SXD_PPRR_IP_LENGTH_UTC_29_14_E,
    [SX_ACL_RANGE_TYPE_REGISTER_E] = SXD_PPRR_IP_LENGTH_CUSTOM_BYTE_SET_E,
    [SX_ACL_RANGE_TYPE_PORT_USER_MEM_E] = SXD_PPRR_IP_LENGTH_ING_LOCAL_PORT_USER_MEM_E,
    [SX_ACL_RANGE_TYPE_PRBS_E] = SXD_PPRR_IP_LENGTH_PRBS__E,
};

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t flex_acl_hw_write_rule_register(acl_rule_hw_op_e        op,
                                            sx_dev_id_t             dev_id,
                                            sx_acl_region_id_t      region_id,
                                            const void             *region_info,
                                            sx_acl_rule_offset_t    offset,
                                            boolean_t               is_valid,
                                            uint32_t                priority,
                                            sx_flex_acl_key_desc_t *keys,
                                            uint32_t                keys_cnt,
                                            sx_acl_key_block_e     *key_blocks,
                                            uint32_t                key_blocks_cnt,
                                            sxd_flex_action_set_t  *reg_action_set,
                                            boolean_t              *activity_value,
                                            boolean_t               bulk_write)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    struct ku_ptce2_reg ptce2_reg_data;
    sxd_reg_meta_t      reg_meta;

    SX_LOG_ENTER();

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(priority);
    UNUSED_PARAM(bulk_write);
    SX_MEM_CLR(ptce2_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = dev_id;

    ptce2_reg_data.valid = is_valid;
    ptce2_reg_data.offset = offset;
    memcpy(ptce2_reg_data.tcam_region_info, region_info, sizeof(ptce2_reg_data.tcam_region_info));

    switch (op) {
    case ACL_RULE_HW_OP_WRITE_E:
    case ACL_RULE_HW_OP_WRITE_CLEAR_E:
    case ACL_RULE_HW_OP_OVERWRITE_E:
    case ACL_RULE_HW_OP_OVERWRITE_CLEAR_E:
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        ptce2_reg_data.op =
            (op == ACL_RULE_HW_OP_WRITE_E || op ==
             ACL_RULE_HW_OP_OVERWRITE_E) ? SXD_PTCE_OP_WRITE : SXD_PTCE_OP_WRITE_CLEAR;
        rc = flex_acl_key_layout_constructor(flex_acl_stage,
                                             keys,
                                             keys_cnt,
                                             key_blocks,
                                             key_blocks_cnt,
                                             ptce2_reg_data.flex_key_blocks,
                                             ptce2_reg_data.flex_mask_blocks,
                                             FLEX_ACL_KEY_BUILD_VALUE_MASK_E);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL PTCE2 register write : Failed flex_acl_key_layout_constructor.\n");
            goto out;
        }
        if (reg_action_set) {
            memcpy(&ptce2_reg_data.action_set, reg_action_set, sizeof(sxd_flex_action_set_t));
        }
        break;

    case ACL_RULE_HW_OP_UPDATE_E:
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        ptce2_reg_data.op = SXD_PTCE_OP_UPDATE;
        if (reg_action_set == NULL) {
            SX_LOG_ERR("ACL: Failed WRITE_RULE_UPDATE  action set in NULL\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        memcpy(&ptce2_reg_data.action_set, reg_action_set, sizeof(sxd_flex_action_set_t));
        break;

    case ACL_RULE_HW_OP_CLEAR_ON_READ_E:
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        ptce2_reg_data.op = SXD_PTCE_OP_CLEAR_ON_READ;
        break;

    case ACL_RULE_HW_OP_READ_E:
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        ptce2_reg_data.op = SXD_PTCE_OP_READ;
        break;

    default:
        SX_LOG_ERR("PTCE2 register CB, invalid operation:%d \n", op);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PTCE2_E, &ptce2_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to configure PTCE2 to dev_idx [%u]\n", dev_id);
        rc = sxd_status_to_sx_status(sxd_st);
        goto out;
    }

    if (reg_meta.access_cmd == SXD_ACCESS_CMD_GET) {
        *activity_value = ptce2_reg_data.activity;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_hw_write_rule_register(acl_rule_hw_op_e        op,
                                             sx_dev_id_t             dev_id,
                                             sx_acl_region_id_t      region_id,
                                             const void             *region_info,
                                             sx_acl_rule_offset_t    offset,
                                             boolean_t               is_valid,
                                             uint32_t                priority,
                                             sx_flex_acl_key_desc_t *keys,
                                             uint32_t                keys_cnt,
                                             sx_acl_key_block_e     *key_blocks,
                                             uint32_t                key_blocks_cnt,
                                             sxd_flex_action_set_t  *reg_action_set,
                                             boolean_t              *activity_value,
                                             boolean_t               bulk_write)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    atcam_api_rule_info_t atcam_rules_info;
    static uint32_t       _transaction_id = 0;

    FLEX_CLR_ACL_REGION_BIT(region_id);

    _transaction_id++;
    SX_LOG_ENTER();

    UNUSED_PARAM(region_info);
    UNUSED_PARAM(activity_value);
    UNUSED_PARAM(bulk_write);

    SX_MEM_CLR(atcam_rules_info);

    atcam_rules_info.rule_offset = offset;
    atcam_rules_info.priority = priority;
    atcam_rules_info.keyblocks_count = key_blocks_cnt;

    switch (op) {
    case ACL_RULE_HW_OP_WRITE_E:
    case ACL_RULE_HW_OP_WRITE_CLEAR_E:
        if (is_valid) {
            rc = flex_acl_key_layout_constructor(flex_acl_stage,
                                                 keys,
                                                 keys_cnt,
                                                 key_blocks,
                                                 key_blocks_cnt,
                                                 atcam_rules_info.flex_key_blocks,
                                                 atcam_rules_info.flex_mask_blocks,
                                                 FLEX_ACL_KEY_BUILD_VALUE_MASK_E);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL rule register write : Failed flex_acl_key_layout_constructor.\n");
                goto out;
            }

            atcam_rules_info.action_set = reg_action_set->next_goto_record.next_action_set_ptr;
            rc = sx_atcam_insert_rules(region_id,
                                       &atcam_rules_info,
                                       1 /*rules_count -at this point we handle only one...*/,
                                       dev_id,
                                       _transaction_id,
                                       TRUE /* is_sync*/);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed to insert new rule, region = %d, offset = %d.\n", region_id, offset);
                goto out;
            }
        } else {
            rc = sx_atcam_delete_rules(region_id, &atcam_rules_info, 1, dev_id, _transaction_id, TRUE /* is_sync */);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed to delete rule, region = %d, offset = %d.\n", region_id, offset);
                goto out;
            }
        }
        break;

    case ACL_RULE_HW_OP_OVERWRITE_E:
    case ACL_RULE_HW_OP_OVERWRITE_CLEAR_E:
        if (is_valid) {
            rc = flex_acl_key_layout_constructor(flex_acl_stage,
                                                 keys,
                                                 keys_cnt,
                                                 key_blocks,
                                                 key_blocks_cnt,
                                                 atcam_rules_info.flex_key_blocks,
                                                 atcam_rules_info.flex_mask_blocks,
                                                 FLEX_ACL_KEY_BUILD_VALUE_MASK_E);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL rule register write : Failed flex_acl_key_layout_constructor.\n");
                goto out;
            }

            atcam_rules_info.action_set = reg_action_set->next_goto_record.next_action_set_ptr;
            rc = sx_atcam_overwrite_rules(region_id,
                                          &atcam_rules_info,
                                          1 /*rules_count -at this point we handle only one...*/,
                                          dev_id,
                                          _transaction_id,
                                          TRUE /* is_sync*/);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed to insert new rule, region = %d, offset = %d.\n", region_id, offset);
                goto out;
            }
        } else {
            /* Should not happen - coding error */
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Coding error, region = %d, offset = %d.\n", region_id, offset);
        }
        break;

    /* at this point prio update is like rule overwrite */
    case ACL_RULE_HW_OP_PRIO_SET_E:
    case ACL_RULE_HW_OP_PRIO_SET_CLEAR_E:
        if (is_valid) {
            rc = sx_atcam_update_priority(region_id,
                                          offset,
                                          priority,
                                          reg_action_set->next_goto_record.next_action_set_ptr,
                                          dev_id,
                                          _transaction_id,
                                          TRUE /*is_sync*/);

            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Failed to set  rule priority, region = %d, offset = %d.\n", region_id, offset);
                goto out;
            }
        } else {
            /* Should not happen - coding error */
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Coding error, region = %d, offset = %d.\n", region_id, offset);
        }
        break;

    case ACL_RULE_HW_OP_UPDATE_E:
        if (reg_action_set == NULL) {
            SX_LOG_ERR("ACL: Failed WRITE_RULE_UPDATE action set in NULL\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        rc = sx_atcam_update_action(region_id,
                                    offset,
                                    reg_action_set->next_goto_record.next_action_set_ptr,
                                    dev_id,
                                    _transaction_id,
                                    TRUE /* is_sync*/);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to update action to rule, region = %d, offset = %d.\n", region_id, offset);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("PTCE2 register CB, invalid operation:%d \n", op);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_rule_prio_update(sx_acl_region_id_t          region_id,
                                         sx_flex_acl_rule_priority_t min_priority,
                                         sx_flex_acl_rule_priority_t max_priority,
                                         int32_t                     priority_change)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t        *acl_region = NULL;
    flex_acl_hw_db_region_attribs_t *hw_region_attributes = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to find ACL region: %u\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &hw_region_attributes);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Failed getting region hw attributes.\n");
        goto out;
    }
    if (hw_region_attributes->write_reg_cb.prio_change_hw_cb == NULL) {
        SX_LOG_ERR("ACL: No CB for prio change. Region:%u \n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }


    rc = hw_region_attributes->write_reg_cb.prio_change_hw_cb(region_id,
                                                              min_priority,
                                                              max_priority,
                                                              priority_change);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to update rule db prio \n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_move_rule_register(acl_move_rule_hw_op_e op,
                                           sx_dev_id_t           dev_id,
                                           sx_acl_region_id_t    src_region_id,
                                           sx_acl_region_id_t    dst_region_id,
                                           const void           *src_region_info,
                                           const void           *dst_region_info,
                                           sx_acl_rule_offset_t  src_offset,
                                           sx_acl_rule_offset_t  dst_offset,
                                           uint32_t              size,
                                           boolean_t             change_priority)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_prcr_reg prcr_reg_data;
    sxd_reg_meta_t     prcr_reg_meta;
    sx_status_t        rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(src_region_id);
    UNUSED_PARAM(dst_region_id);

    SX_MEM_CLR(prcr_reg_data);
    SX_MEM_CLR(prcr_reg_meta);

    if (!change_priority) {
        SX_LOG_ERR("Moving rule without changing its priority is not supported in Flex1\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    switch (op) {
    case ACL_RULE_MOVE_HW_OP_COPY_E:
        prcr_reg_data.op = SXD_PRCR_OP_RULES_COPY;
        break;

    case ACL_RULE_MOVE_HW_OP_MOVE_E:
        prcr_reg_data.op = SXD_PRCR_OP_RULES_MOVE;
        break;

    default:
        SX_LOG_ERR("Write PRCR register operation:%d is not supported/\n", op);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    prcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    prcr_reg_meta.dev_id = dev_id;
    prcr_reg_data.size = size;
    prcr_reg_data.offset = src_offset;
    prcr_reg_data.dest_offset = dst_offset;
    memcpy(prcr_reg_data.tcam_region_info, src_region_info, sizeof(prcr_reg_data.tcam_region_info));
    memcpy(prcr_reg_data.dest_tcam_region_info, dst_region_info, sizeof(prcr_reg_data.tcam_region_info));

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PRCR_E, &prcr_reg_data, &prcr_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure PRCR to dev_idx [%u]\n", dev_id);
        rc = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_hw_move_rule_register(acl_move_rule_hw_op_e op,
                                            sx_dev_id_t           dev_id,
                                            sx_acl_region_id_t    src_region_id,
                                            sx_acl_region_id_t    dst_region_id,
                                            const void           *src_region_info,
                                            const void           *dst_region_info,
                                            sx_acl_rule_offset_t  src_offset,
                                            sx_acl_rule_offset_t  dst_offset,
                                            uint32_t              size,
                                            boolean_t             change_priority)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 i = 0;
    flex_acl_db_flex_rule_t *rule = NULL;
    sx_acl_rule_offset_t     src_offset_idx = 0, dst_offset_idx = 0;
    int32_t                  rule_step = 0;
    sx_acl_rule_offset_t     overlap_start = 0xFFFFFFFF, overlap_end = 0;
    boolean_t                overwrite_dst = FALSE;
    static uint32_t          _transaction_id = 0;

    SX_LOG_ENTER();

    _transaction_id++;

    UNUSED_PARAM(src_region_info);
    UNUSED_PARAM(dst_region_info);

    FLEX_CLR_ACL_REGION_BIT(src_region_id);
    FLEX_CLR_ACL_REGION_BIT(dst_region_id);

    if (op != ACL_RULE_MOVE_HW_OP_MOVE_E) {
        SX_LOG_ERR("Flex2 : Operation:%d is not supported for move rule.\n", op);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (src_region_id != dst_region_id) {
        SX_LOG_ERR("Flex2 : Move rules between two regions is not supported region1:[%u] region2:[%u]\n",
                   src_region_id,
                   dst_region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* If the source offset if smaller than the destination, we'll move the rules one by one from the highest offset to the lower offsets.
     * If the source offset if higher than the destination we'll move the rules one by one from the lower offsets to the higher offsets.
     * This is not to overwrite rules that we'll remain valid after the move.
     */
    if (src_offset < dst_offset) {
        src_offset_idx = src_offset + size - 1;
        dst_offset_idx = dst_offset + size - 1;
        rule_step = -1;
        /* the source and destination are overlapping in some entries. calculate the overlapping area. */
        if (src_offset + size > dst_offset) {
            overlap_start = dst_offset;
            overlap_end = src_offset + size - 1;
        }
    } else {
        src_offset_idx = src_offset;
        dst_offset_idx = dst_offset;
        rule_step = 1;
        /* the source and destination are overlapping in some entries. calculate the overlapping area. */
        if (dst_offset + size > src_offset) {
            overlap_start = src_offset;
            overlap_end = dst_offset + size - 1;
        }
    }

    /* Get a point to all the rules in the region. NOTE: it is strongly assumed here (and other places in the code) that the return
     * value is a pointer to region's rule array we can traverse at will.
     */
    rc = flex_acl_db_get_rule_by_offset(src_region_id, 0, &rule);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex2 : Failed to get rule by offset for region:[%u] offset:[%u]\n", src_region_id, src_offset);
        goto out;
    }

    /* Go all the rules that needs to be moved and check if they are valid. If so call the atcam move function. */
    for (i = 0; i < size; i++) {
        if (rule[src_offset_idx].valid || rule[dst_offset_idx].valid) {
            /* We need to delete the destination only if it's not in the overlapping area.
             * If it's in the overlapping area. It's already been removed by previous loop iteration.
             */
            overwrite_dst =
                ((rule[dst_offset_idx].valid) && ((dst_offset_idx < overlap_start) || (dst_offset_idx > overlap_end)));

            rc = sx_atcam_move_rule(src_region_id,
                                    src_offset_idx,
                                    dst_offset_idx,
                                    FLEX_ACL_OFFSET_TO_PRIO(src_offset_idx),
                                    FLEX_ACL_OFFSET_TO_PRIO(dst_offset_idx),
                                    rule[src_offset_idx].valid,
                                    overwrite_dst,
                                    change_priority,
                                    dev_id,
                                    _transaction_id,
                                    TRUE /* is_sync*/);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Flex2 : Failed move atcam rule by offset for region:[%u] offset:[%u]\n",
                           src_region_id,
                           src_offset);
                goto out;
            }
        }
        src_offset_idx += rule_step;
        dst_offset_idx += rule_step;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t flex2_acl_hw_write_region_register(acl_region_op_e     region_op,
                                                      sx_dev_id_t         dev_id,
                                                      sx_acl_region_id_t  region_id,
                                                      sx_acl_key_type_t   key_handle,
                                                      sx_acl_key_block_e *key_blocks,
                                                      uint32_t            key_blocks_cnt,
                                                      uint8_t            *tcam_region_info,
                                                      uint32_t            tcam_region_info_size,
                                                      sx_acl_size_t       new_size,
                                                      sx_acl_size_t      *allocated_size_p,
                                                      boolean_t           stateful_db_region)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    atcam_region_params_t region_params;
    uint32_t              i = 0;

    UNUSED_PARAM(key_handle);
    UNUSED_PARAM(dev_id);
    SX_MEM_CLR(region_params);

    FLEX_CLR_ACL_REGION_BIT(region_id);

    if ((region_op == ACL_REGION_HW_OP_ALLOCATE_E) &&
        (tcam_region_info_size != SXD_TCAM_REGION_INFO_SIZE_BYTES)) {
        SX_LOG_ERR("ACL : Provided tcam region info buffer is not in the right size (%u != %u)\n",
                   tcam_region_info_size, SXD_TCAM_REGION_INFO_SIZE_BYTES);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    region_params.region_size = new_size;
    region_params.region_ctcam_size = 0; /*This will be determined by atcam module */
    region_params.bf_bypass = FALSE;
    region_params.atcam_ignore_prune = FALSE;
    region_params.erp_data.is_ctcam_enabled = FALSE;
    region_params.key_blocks_cnt = key_blocks_cnt;

    for (i = 0; i < region_params.key_blocks_cnt; i++) {
        region_params.key_blocks[i] = key_blocks[i];
    }

    switch (region_op) {
    case ACL_REGION_HW_OP_ALLOCATE_E:
        status = atcam_regions_manager_region_create(region_id, stateful_db_region, &region_params, tcam_region_info);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to create region, region_id: %u, utils_err = [%s]\n",
                       region_id, SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        break;

    case ACL_REGION_HW_OP_RESIZE_E:
        status = atcam_regions_manager_region_resize(region_id, tcam_region_info, new_size);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to resize region, region_id: %u, utils_err = [%s]\n",
                       region_id, SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        break;

    case ACL_REGION_HW_OP_DEALLOCATE_E:
        status = atcam_regions_manager_region_destroy(region_id);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to destroy region, region_id: %u, utils_err = [%s]\n",
                       region_id, SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        break;

    case ACL_REGION_HW_OP_TEST_ALLOCATE_E:
    default:
        SX_LOG_ERR("ACL : Unhandled region_op [%u]\n", region_op);
        status = SX_STATUS_PARAM_ERROR;
        break;
    }

    /* Update the allocated size */
    if (allocated_size_p != NULL) {
        /* For atcam there is no actual hw size for the region. */
        *allocated_size_p = new_size;
        if (region_op == ACL_REGION_HW_OP_DEALLOCATE_E) {
            *allocated_size_p = 0;
        }
    }

out:
    return status;
}

static sx_status_t flex_acl_hw_prio_change_register(sx_acl_region_id_t region_id,
                                                    const uint32_t     min_prio,
                                                    const uint32_t     max_prio,
                                                    const int32_t      prio_change)
{
    UNUSED_PARAM(region_id);
    UNUSED_PARAM(prio_change);
    UNUSED_PARAM(max_prio);
    UNUSED_PARAM(min_prio);

    return SX_STATUS_CMD_UNSUPPORTED;
}

static sx_status_t flex2_acl_hw_prio_change_register(sx_acl_region_id_t region_id,
                                                     const uint32_t     min_prio,
                                                     const uint32_t     max_prio,
                                                     const int32_t      prio_change)
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    static uint32_t _transaction_id = 0;

    _transaction_id++;

    SX_LOG_ENTER();

    FLEX_CLR_ACL_REGION_BIT(region_id);

    status = sx_atcam_update_rules_prio(region_id,
                                        min_prio,
                                        max_prio,
                                        prio_change,
                                        1 /*dev_id*/,
                                        _transaction_id,
                                        TRUE /*is_sync*/);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Failed to update priority to rule, region = %d.\n", region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}
sx_status_t flex_acl_hw_write_region_register(acl_region_op_e     region_op,
                                              sx_dev_id_t         dev_id,
                                              sx_acl_region_id_t  region_id,
                                              sx_acl_key_type_t   key_handle,
                                              sx_acl_key_block_e *key_blocks,
                                              uint32_t            key_blocks_cnt,
                                              uint8_t            *tcam_region_info,
                                              uint32_t            tcam_region_info_size,
                                              sx_acl_size_t       new_size,
                                              sx_acl_size_t      *allocated_size_p,
                                              boolean_t           stateful_db_region)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_err = SX_UTILS_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_ptar_reg ptar_reg_data;
    sxd_reg_meta_t     ptar_reg_meta;
    uint32_t           i = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(key_handle);
    UNUSED_PARAM(stateful_db_region);

    SX_MEM_CLR(ptar_reg_meta);
    SX_MEM_CLR(ptar_reg_data);

    if ((region_op == ACL_REGION_HW_OP_ALLOCATE_E) &&
        (tcam_region_info_size != sizeof(ptar_reg_data.tcam_region_info))) {
        SX_LOG_ERR("ACL : Provided tcam region info buffer is not in the right size (%u != %u)\n",
                   tcam_region_info_size, (uint32_t)sizeof(ptar_reg_data.tcam_region_info));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (region_op == ACL_REGION_HW_OP_DEALLOCATE_E) {
        /* Fence needs to be performed before PTAR deallocate flows. For now
         * we do a synchronous fence, in the future the deallocate should go through
         * the garbage collector and become asynchronous.
         */
        utils_err = gc_object_fence(GC_FENCE_TYPE_FAST);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            rc = sx_utils_status_to_sx_status(utils_err);
            SX_LOG_ERR("Failed to perform fast fence, utils_err = [%s]\n",
                       SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }
        SX_LOG_DBG("Performed fast fence before deallocating region %u\n",
                   region_id);
    }

    ptar_reg_meta.dev_id = dev_id;
    ptar_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    ptar_reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

    ptar_reg_data.key_type = SXD_PTAR_KEY_FLEX_KEY_E;
    ptar_reg_data.action_type = SXD_PTAR_FLEX_ACTION_E;
    switch (region_op) {
    case ACL_REGION_HW_OP_ALLOCATE_E:
        ptar_reg_data.op = SXD_PTAR_OP_ALLOCATE_E;
        break;

    case ACL_REGION_HW_OP_RESIZE_E:
        ptar_reg_data.op = SXD_PTAR_OP_RESIZE_E;
        break;

    case ACL_REGION_HW_OP_DEALLOCATE_E:
        ptar_reg_data.op = SXD_PTAR_OP_DEALLOCATE_E;
        break;

    default:
        SX_LOG_ERR("Error PTAR write register, invalid op :%d \n", region_op);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* TCAM optimization full implementation */
    switch (tcam_opt_params_g.tcam_opt_mode) {
    case SX_TCAM_OPT_MODE_DISABLED:
        ptar_reg_data.op_type = SXD_PTAR_TCAM_NO_OPTIMIZATION_E;
        ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_0_PCT;
        break;

    case SX_TCAM_OPT_MODE_STATIC:
        ptar_reg_data.op_type = SXD_PTAR_TCAM_HARD_OPTIMIZATION_E;
        switch (tcam_opt_params_g.tcam_opt_mode_param) {
        case SX_TCAM_OPT_MODE_PARAM_FWS_64B:
            ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_80_PCT;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_128B:
            ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_40_PCT;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_256B:
            ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_20_PCT;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_512B:
            ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_10_PCT;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_1024B:
            ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_0_PCT;
            break;

        default:
            SX_LOG_ERR("Unsupported TCAM opt mode param value (%d) for TCAM opt mode: (%s[%d]) \n",
                       tcam_opt_params_g.tcam_opt_mode_param,
                       sx_tcam_opt_mode_str(tcam_opt_params_g.tcam_opt_mode),
                       tcam_opt_params_g.tcam_opt_mode);
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        break;

    case SX_TCAM_OPT_MODE_DYNAMIC:
        ptar_reg_data.op_type = SXD_PTAR_TCAM_SOFT_OPTIMIZATION_E;
        ptar_reg_data.packet_rate = SXD_PTAR_PACKET_RATE_0_PCT;
        break;

    default:
        SX_LOG_ERR("Unsupported TCAM opt mode: (%s[%d]) \n",
                   sx_tcam_opt_mode_str(tcam_opt_params_g.tcam_opt_mode),
                   tcam_opt_params_g.tcam_opt_mode);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    ptar_reg_data.region_id = region_id;
    ptar_reg_data.region_size = new_size;

    if (ptar_reg_data.op != SXD_PTAR_OP_RESIZE_E) {
        for (i = 0; i < key_blocks_cnt; i++) {
            ptar_reg_data.flexible_key_id[i] = key_block_data_dictionary[key_blocks[i]].key_block_code;
        }
    }

    if (region_op == ACL_REGION_HW_OP_ALLOCATE_E) {
        memset(ptar_reg_data.tcam_region_info, 0, sizeof(ptar_reg_data.tcam_region_info));
    } else {
        memcpy(ptar_reg_data.tcam_region_info, tcam_region_info, sizeof(ptar_reg_data.tcam_region_info));
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PTAR_E, &ptar_reg_data, &ptar_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        rc = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR_RESOURCE_COND(rc,
                                 "ACL : Failed to configure PTAR to dev_idx [%u] ERR code [%u] \n",
                                 dev_id,
                                 sxd_status);
        goto out;
    }

    /* Update the allocated size */
    if (allocated_size_p != NULL) {
        *allocated_size_p = ptar_reg_data.region_size;
        if (region_op == ACL_REGION_HW_OP_DEALLOCATE_E) {
            *allocated_size_p = 0;
        }
    }

    /* Copy region info back to caller for DB */
    if (region_op == ACL_REGION_HW_OP_ALLOCATE_E) {
        memcpy(tcam_region_info, ptar_reg_data.tcam_region_info, tcam_region_info_size);
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex2_acl_hw_activity_read_register(acl_rule_hw_op_e        op,
                                                sx_dev_id_t             dev_id,
                                                sx_acl_region_id_t      region_id,
                                                const void             *region_info,
                                                sx_acl_rule_offset_t    offset,
                                                boolean_t               is_valid,
                                                uint32_t                priority,
                                                sx_flex_acl_key_desc_t *keys,
                                                uint32_t                keys_cnt,
                                                sx_acl_key_block_e     *key_blocks,
                                                uint32_t                key_blocks_cnt,
                                                sxd_flex_action_set_t  *reg_action_set,
                                                boolean_t              *activity_value,
                                                boolean_t               bulk_write)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS, rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t     *rule = NULL;
    flex_acl_hw_db_action_set_t *hw_action_set = NULL;
    uint32_t                     kvd_block_size = 0, size = 0;
    kvd_linear_manager_index_t   kvd_indexes[DEFAULT_ACTIONS_MAX_BLOCK_SIZE];
    struct ku_pefa_reg           pefa_reg_data = {.index = 0};
    sxd_reg_meta_t               reg_meta;
    sxd_status_t                 sxd_st = SXD_STATUS_SUCCESS;
    sx_acl_region_id_t           hw_region_id;

    SX_LOG_ENTER();

    UNUSED_PARAM(region_info);
    UNUSED_PARAM(is_valid);
    UNUSED_PARAM(priority);
    UNUSED_PARAM(keys);
    UNUSED_PARAM(keys_cnt);
    UNUSED_PARAM(key_blocks);
    UNUSED_PARAM(key_blocks_cnt);
    UNUSED_PARAM(reg_action_set);
    UNUSED_PARAM(bulk_write);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(activity_value, "activity_value"))) {
        goto out;
    }

    SX_MEM_CLR(pefa_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    switch (op) {
    case ACL_RULE_HW_OP_READ_E:
        pefa_reg_data.ca = SXD_PEFA_CA_OP_SET;
        break;

    case ACL_RULE_HW_OP_CLEAR_ON_READ_E:
        pefa_reg_data.ca = SXD_PEFA_CA_OP_CLEAR;
        break;

    default:
        SX_LOG_ERR("Invalid activity op [%u].\n", op);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get rule for activity from db for region:%u offset:%u\n", region_id, offset);
        goto out;
    }

    /* get actions from db */
    hw_action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    if (NULL == hw_action_set) {
        SX_LOG_ERR("ACL action : Invalid action set handle for activity read.\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (hw_action_set->kvd_action_set_count == 0) {
        SX_LOG_ERR("Invalid action set size for region:%u offset:%u.\n", region_id, offset);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
        kvd_block_size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;
        size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;
        rc = kvd_linear_manager_handle_lock(default_action_kvd_handle, kvd_indexes, &size);
        if ((SX_STATUS_SUCCESS != rc) || (size < kvd_block_size)) {
            SX_LOG_ERR("ACL action : Failed locking kvd block for default action set.\n");
            goto out;
        }
        /* Get region id starting with zero*/
        hw_region_id = region_id;
        FLEX_CLR_ACL_REGION_BIT(hw_region_id);
        pefa_reg_data.index = kvd_indexes[hw_region_id];
        pefa_reg_data.ddd_en = TRUE;
    } else {
        kvd_block_size = hw_action_set->kvd_action_set_count;
        size = rm_resource_global.acl_max_actions_per_rule;

        rc = kvd_linear_manager_handle_lock(hw_action_set->kvd_handle, kvd_indexes, &size);
        if (SX_CHECK_FAIL(rc) || (size < kvd_block_size)) {
            SX_LOG_ERR("ACL action : Failed locking kvd block for activity read, kvd_handle: %" PRIx64 "\n",
                       hw_action_set->kvd_handle);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        pefa_reg_data.index = kvd_indexes[0];
    }
    /* Read the value of the activity bit from the first action block*/

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEFA_E, &pefa_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to read PEFA from dev_idx [%u] index [%u].\n", dev_id, kvd_indexes[0]);
        rc = sxd_status_to_sx_status(sxd_st);
        goto kvd_release;
    }

    if (offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
        rc = kvd_linear_manager_handle_release(default_action_kvd_handle);
    } else {
        rc = kvd_linear_manager_handle_release(hw_action_set->kvd_handle);
    }
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed unlocking kvd block for activity read, kvd_handle: %" PRIu64 "\n",
                   hw_action_set->kvd_handle);
        goto out;
    }
    /* return the value of the activity */
    *activity_value = pefa_reg_data.a;

    goto out;

kvd_release:
    rb_rc = kvd_linear_manager_handle_release(hw_action_set->kvd_handle);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("ACL action : Failed rollback unlocking kvd block for activity read, kvd_handle: %" PRIu64 "\n",
                   hw_action_set->kvd_handle);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_hw_activity_bulk_dump_register(sx_dev_id_t              dev_id,
                                                     sx_acl_region_id_t       region_id,
                                                     boolean_t                clear,
                                                     boolean_t                force_end,
                                                     sxd_pefaad_index_dump_t *record_p,
                                                     uint32_t                *record_num_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_st = SXD_STATUS_SUCCESS;
    struct ku_pefaad_reg pefaad_reg_data;
    sxd_reg_meta_t       reg_meta;
    uint16_t             as_user_val = 0;
    uint8_t              filter_by_region = 0;

    SX_MEM_CLR(pefaad_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    if (clear) {
        pefaad_reg_data.op = 2;
    } else if (force_end) {
        pefaad_reg_data.op = 1;
    } else {
        pefaad_reg_data.op = 0;
    }

    if (!clear) {
        if (region_id != FLEX_ACL_INVALID_REGION_ID) {
            as_user_val = region_id;
            filter_by_region = 1;
        }
        pefaad_reg_data.filter_fields = (filter_by_region << 1) | 1;
    }

    if (record_num_p) {
        pefaad_reg_data.num_rec = *record_num_p;
    } else {
        pefaad_reg_data.num_rec = 256;
    }

    if (pefaad_reg_data.filter_fields & 0x1) {
        pefaad_reg_data.entry_a = 1;
    }

    if (pefaad_reg_data.filter_fields & 0x2) {
        pefaad_reg_data.as_user_val = as_user_val;
    }

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEFAAD_E, &pefaad_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to read PEFAAD from dev_idx [%u] .\n", dev_id);
        rc = sxd_status_to_sx_status(sxd_st);
        goto out;
    }

    if (record_num_p) {
        if (pefaad_reg_data.num_rec > (*record_num_p)) {
            SX_LOG_ERR("PEFAAD return unexpected record number %d than requested number %d.\n",
                       pefaad_reg_data.num_rec,
                       *record_num_p);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        *record_num_p = pefaad_reg_data.num_rec;
    }

    if ((record_p) && (record_num_p)) {
        memcpy(record_p, pefaad_reg_data.index_dump, sizeof(sxd_pefaad_index_dump_t) * pefaad_reg_data.num_rec);
    }

out:
    return rc;
}

sx_status_t flex2_acl_hw_write_global_mask_register(sx_dev_id_t        dev_id,
                                                    sx_acl_region_id_t region_id,
                                                    uint8_t            global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES])
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_region_id_t atcam_region_id = region_id;

    SX_LOG_ENTER();

    UNUSED_PARAM(dev_id);

    FLEX_CLR_ACL_REGION_BIT(atcam_region_id);

    /* Updated the ATCAM global mask DB with the provided mask */
    rc = atcam_global_mask_override_set(atcam_region_id, global_mask);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL write global mask register : Failed ATCAM mask override [%u]. err = %s\n",
                   atcam_region_id,
                   sx_status_str(rc));
        goto out;
    }

    /* Use the ATCAM module to write directly the global mask to HW*/
    rc = atcam_regions_manager_region_mask_update(atcam_region_id, global_mask);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL write global mask register : Failed ATCAM mask update [%u]. err = %s\n",
                   atcam_region_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex2_acl_hw_write_lookup_region_register(sx_dev_id_t              dev_id,
                                                      const sx_acl_region_id_t region_id,
                                                      const sx_acl_region_id_t lookup_region_id)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_region_id_t atcam_region_id = region_id;
    sx_acl_region_id_t atcam_lookup_region_id = lookup_region_id;

    SX_LOG_ENTER();

    UNUSED_PARAM(dev_id);

    FLEX_CLR_ACL_REGION_BIT(atcam_region_id);
    FLEX_CLR_ACL_REGION_BIT(atcam_lookup_region_id);

    /* Use the ATCAM module to write directly the global mask */
    rc = atcam_regions_manager_set_lookup_region_id(atcam_region_id, atcam_lookup_region_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL write lookup register : Failed ATCAM lookup region update [%u]. err = %s\n",
                   atcam_region_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_copy_rule_ptr(flex_acl_db_flex_rule_t *rule)
{
    /* hw action is not relevant yet */
    if ((rule == NULL) || !rule->is_exist ||
        (rule->hw_action_handle == (void*)FLEX_ACL_INVALID_HANDLE) || (rule->hw_action_handle == NULL)) {
        return SX_STATUS_SUCCESS;
    }
    ((flex_acl_hw_db_action_set_t*)(rule->hw_action_handle))->related_rule = rule;

    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_hw_set_key_blocks(sx_acl_key_block_e *key_blocks, uint32_t count, uint32_t* handle)
{
    return flex_acl_hw_db_set_key_blocks(key_blocks, count, handle);
}

sx_status_t flex_acl_hw_get_key_blocks(uint32_t handle, sx_acl_key_block_e **key_blocks, uint32_t *count)
{
    return flex_acl_hw_db_get_key_blocks(handle, key_blocks, count);
}

sx_status_t flex_acl_hw_remove_flex_key_entry(sx_acl_key_type_t key_handle)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    sx_acl_key_t *user_keys = NULL;
    uint8_t       user_key_count = 0;
    uint32_t      hw_key_handle = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_flex_key_entry(key_handle, &user_keys, &user_key_count, &hw_key_handle);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed get key entry from DB, key_handle: %u\n", key_handle);
        goto out;
    }

    rc = flex_acl_hw_db_remove_key_blocks(hw_key_handle);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deleting key from DB, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_free_third_parties(sx_acl_region_id_t region_id, sx_flex_acl_rule_offset_t offset)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t *rule = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ERROR : Invalid rule, region_id: %u\n", region_id);
        goto out;
    }

    if (rule->valid == FLEX_ACL_RULE_INVALID) {
        SX_LOG_DBG("Rule was not valid, nothing to free.\n");
        goto out;
    }
    rc = flex_acl_hw_free_rule_third_party_resources(rule);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ERROR : Failed to free rule third party references\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_free_rule_kvd(flex_acl_db_flex_rule_t *rule)
{
    flex_acl_hw_db_action_set_t *action_set = NULL;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_sdk_entries_param_t       action_entry_param;
    uint32_t                     kvd_action_set_count;

    SX_LOG_ENTER();

    SX_MEM_CLR(action_entry_param);

    action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    if (!action_set || (action_set == (void*)FLEX_ACL_INVALID_HANDLE)) {
        SX_LOG_ERR("No action set\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (rule->offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
        kvd_action_set_count = action_set->kvd_action_set_count - 1; /* The first actions set resides in pre-allocated KVD block */
    } else {
        kvd_action_set_count = action_set->kvd_action_set_count;
    }

    if (kvd_action_set_count == 0) {
        goto out;
    }

    rc = kvd_linear_manager_ref_delete(action_set->kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("KVD ref delete failed handle:0x%" PRIx64 " .\n", action_set->kvd_handle);
        goto out;
    }
    SX_LOG_DBG("FLOWD KVD ref delete handle:0x%" PRIx64 " \n", action_set->kvd_handle);

    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    action_entry_param.attr.acl_action_attr.default_action = FALSE;
    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                        SX_ACCESS_CMD_DELETE,
                        kvd_action_set_count,
                        &action_entry_param);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed on RM entry set for RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E.\n");
        goto out;
    }
    rc = kvd_linear_manager_block_delete(action_set->kvd_handle, FALSE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("KVD block delete failed handle:0x%" PRIx64 ".\n", action_set->kvd_handle);
        goto out;
    }
    SX_LOG_DBG("FLOWED KVD block delete handle:0x%" PRIx64 " \n", action_set->kvd_handle);

    rc = flex_acl_hw_db_kvd_remove_entry(action_set->kvd_handle, action_set);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("KVD handler removal failed handle:0x%" PRIx64 " .\n", action_set->kvd_handle);
        goto out;
    }
    SX_LOG_DBG("FLOWD KVD DB remove entry handle:0x%" PRIx64 " \n", action_set->kvd_handle);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_free_kvd(sx_acl_region_id_t region_id, sx_flex_acl_rule_offset_t offset)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t *rule = NULL;

    SX_LOG_ENTER();

    SX_LOG_DBG("Free KVD rule offset:%u\n", offset);

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule);
    if ((SX_STATUS_SUCCESS != rc) || !rule->valid) {
        SX_LOG_DBG("Free KVD rule offset:%u Nothing to free\n", offset);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_hw_free_rule_kvd(rule);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ERROR : failed to free rules kvd references\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rm_entries_set(uint32_t new_cnt, uint32_t old_cnt, flex_acl_db_acl_region_t *region)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    uint32_t                         rm_cnt = 0;
    sx_access_cmd_t                  rm_cmd = SX_ACCESS_CMD_NONE;
    system_acl_client_table_entry_t *client_p = NULL;
    rm_sdk_table_type_e              resource;

    SX_LOG_ENTER();

    if (region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        rc = system_acl_client_get(region->region_id, &client_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL :Failed to get system client entry, region_id[%#x]\n", region->region_id);
            goto out;
        }
        if (!client_p->is_rules_rm_needed) {
            goto out;
        }
    }

    if (new_cnt > old_cnt) {
        /* We need to tell RM that we are going to allocate some entries */
        rm_cmd = SX_ACCESS_CMD_ADD;
        rm_cnt = new_cnt - old_cnt;
    } else if (new_cnt < old_cnt) {
        /* We need to tell RM that we are going to free some entries */
        rm_cmd = SX_ACCESS_CMD_DELETE;
        rm_cnt = old_cnt - new_cnt;
    }

    /* RM update should be in touch with adding / deleting rules in sw */
    if (!rm_cnt) {
        goto out;
    }


    rc = flex_acl_get_rm_resource(region->key_handle, &resource);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : RM Failed to get resource type\n");
        goto out;
    }

    SX_LOG_DBG("rm_entries_set: rm_cmd = %s, rm_cnt = %u\n", rm_cmd == SX_ACCESS_CMD_ADD ? "add" : "delete", rm_cnt);
    rc = rm_entries_set(resource, rm_cmd, rm_cnt, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : RM Failed rules set action\n");
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_rules_move_update_db(sx_api_acl_block_move_params_t *params,
                                             flex_acl_db_flex_rule_t        *rules_to_free,
                                             uint32_t                        rules_count,
                                             boolean_t                       change_priority)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_bound = FALSE;
    sx_flex_acl_rule_offset_t offset = 0;
    uint32_t                  i = 0;
    uint32_t                  old_valid_rules_num = 0;
    flex_acl_db_acl_region_t *region = NULL;
    flex_acl_rule_id_t        rule_id;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(params->region_id, &region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get region id [%u]\n", params->region_id);
        goto out;
    }
    old_valid_rules_num = region->valid_rules_num;
    rule_id.region_id = params->region_id;

    rc = flex_acl_db_is_region_bound_to_dev(params->region_id, &is_bound);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed check if region bound to devices\n");
        goto out;
    }
    /* the rules should be deleted from db without writing to register */
    for (i = 0; i < rules_count; i++) {
        if (rules_to_free[i].valid == FALSE) {
            continue;
        }
        if (is_bound) {
            rc = flex_acl_hw_free_rule_third_party_resources(&rules_to_free[i]);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL: Failed to free third party.\n");
            }
            rc = flex_acl_hw_free_rule_kvd(&rules_to_free[i]);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL: Failed to free kvd.\n");
            }

            /* delete the entry from acl drop trap Attribute db
             * acl drop relocate db already deleted because free third party's was called earlier  */
            rule_id.offset = rules_to_free[i].offset;
            rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
                    rc = SX_STATUS_SUCCESS;
                } else {
                    SX_LOG_ERR("deleting action from acl drop db failed.RC=[%s]\n", sx_status_str(rc));
                    goto out;
                }
            }
        }
        offset = rules_to_free[i].offset;

        rc = flex_acl_db_invalidate_rules(params->region_id, &offset, 1);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL: Failed to free kvd.\n");
        }
    }

    rc = flex_acl_rm_entries_set(region->valid_rules_num, old_valid_rules_num, region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", params->region_id);
        /*should move rules back and set */
    }

    /* update the WJH ACL DROP Trap Attribute DBs */
    rc = flex_acl_hw_rules_move_upd_acl_drop_trap_db(params);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to update acl drop trap db for region [%u]\n", params->region_id);
        goto out;
    }

    rc = flex_acl_db_rules_move(params, flex_acl_hw_copy_rule_ptr, change_priority);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to move rules at db [%u]\n", params->region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* the function writes configured rule to ptce2 from db as it is, without allocation resources of kvd,
 *  policer and s.o.
 */
sx_status_t flex_acl_hw_write_only_rule(flex_acl_db_flex_rule_t  *rule,
                                        flex_acl_db_acl_region_t *region,
                                        uint32_t                  dev_id,
                                        boolean_t                 fill_kvd,
                                        boolean_t                 is_full_write,
                                        boolean_t                 is_overwrite)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       unlock_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t      *hw_action_set = NULL;
    sxd_flex_action_set_t             reg_action_set;
    sx_acl_key_t                     *keys = NULL;
    uint8_t                           keys_count = 0;
    sx_acl_key_block_e               *key_blocks = NULL;
    uint32_t                          blocks_count = 0;
    uint32_t                          hw_key_handle = 0;
    flex_acl_hw_db_region_attribs_t  *hw_region_attributes = NULL;
    flex_acl_db_acl_table_t          *acl_table = NULL;
    boolean_t                         is_commit = FALSE;
    kvd_linear_manager_index_t       *kvd_indexes = NULL;
    uint32_t                          kvd_block_size = 0;
    kvd_linear_manager_block_length_t size = 0;
    kvd_linear_manager_index_t        kvd_index_to_write = 0;
    flex_acl_relocation_data_t        relocation_data = {.is_head = 0};
    boolean_t                         is_last_action_set = FALSE;
    boolean_t                         kvd_locked = FALSE;
    boolean_t                         actions_locked = FALSE;
    acl_rule_hw_op_e                  hw_op = ACL_RULE_HW_OP_WRITE_E;
    boolean_t                         is_default_actions = FALSE;

    SX_LOG_ENTER();

    if (!rule->valid) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    is_default_actions = (rule->offset == SX_ACL_DEFAULT_ACTION_OFFSET) ? TRUE : FALSE;

    rc = flex_acl_db_acl_get(region->bound_acl, &acl_table);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Failed fetching ACL from region, acl_id: %u.\n", region->bound_acl);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_hw_is_commit_acl(acl_table->acl_id, &is_commit);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL calling flex_acl_hw_is_commit_acl, acl_id: %u\n", acl_table->acl_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(reg_action_set);

    rc = flex_acl_hw_db_get_region_attributes(region->hw_region_attribs_handle, &hw_region_attributes);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get region hw attributes[%u]\n", dev_id);
        goto out;
    }
    if (hw_region_attributes->write_reg_cb.rule_hw_cb == NULL) {
        SX_LOG_ERR("ACL : NO HW CB for writing rule, region :%u \n", region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* get key blocks from db */
    rc = flex_acl_db_get_flex_key_entry(region->key_handle, &keys, &keys_count, &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_db_get_flex_key_entry, key_handle: %u\n", region->key_handle);
        goto out;
    }
    rc = flex_acl_hw_db_get_key_blocks(hw_key_handle, &key_blocks, &blocks_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_hw_db_get_key_blocks, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }

    /* get actions from db */
    hw_action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    if (NULL == hw_action_set) {
        SX_LOG_ERR("ACL action : Invalid action set handle.\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    SX_LOG_DBG("ACTION SET count [%d]\n", hw_action_set->kvd_action_set_count);
    kvd_block_size = hw_action_set->kvd_action_set_count;

    if (is_default_actions) {
        kvd_block_size--;       /* The first default action set has pre-allocated KVD entry */
    }

    if (kvd_block_size) {
        /* Get kvd indexes to write */
        SX_LOG_DBG("FLOWD hw_write_only_rule: lock kvd.\n");
        kvd_indexes = (kvd_linear_manager_index_t*)cl_malloc(sizeof(kvd_linear_manager_index_t) * kvd_block_size);
        if (kvd_indexes == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            goto out;
        }

        size = kvd_block_size;

        rc = kvd_linear_manager_handle_lock(hw_action_set->kvd_handle, kvd_indexes, &size);
        if ((SX_STATUS_SUCCESS != rc) || (size < kvd_block_size)) {
            SX_LOG_ERR("ACL action : Failed locking kvd block, kvd_handle: %" PRIu64 "\n", hw_action_set->kvd_handle);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        kvd_locked = TRUE;
        SX_LOG_DBG("FLOWD hw write rule add KVD lock \n");

        kvd_index_to_write = hw_action_set->action_set.kvd_index = kvd_indexes[0];
        is_last_action_set = FALSE;
    } else {
        kvd_index_to_write = hw_action_set->action_set.kvd_index = 0;
        is_last_action_set = TRUE;
    }

    if (is_default_actions == TRUE) {
        rc = flex_acl_hw_write_first_default_action_set(rule,
                                                        region->region_id,
                                                        hw_action_set,
                                                        &kvd_indexes[0],
                                                        is_full_write,
                                                        region->initial_activity_cleared,
                                                        is_commit,
                                                        FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed write the default action set for region [%d]\n",
                       region->region_id);
            goto out;
        }
    } else {
        /* Write rule register, we have the index of the next */
        relocation_data.is_head = TRUE;
        relocation_data.kvd_index_p = &(hw_action_set->action_set.kvd_index);
        /* Prepare action set for writing to HW, including obtaining third party's HW indexes. */
        rc = flex_acl_hw_create_reg_action_set(hw_action_set->action_set.actions,
                                               hw_action_set->action_set.actions_count,
                                               hw_action_set->action_set.goto_action,
                                               is_last_action_set,
                                               kvd_index_to_write,
                                               is_commit,
                                               relocation_data,
                                               &reg_action_set,
                                               FALSE,
                                               rule);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action : Failed creating action set.\n");
            goto out;
        }
    }
    actions_locked = TRUE;

    if (kvd_block_size && fill_kvd) {
        /* write extended action set to kvd */
        rc = flex_acl_hw_write_extended_action_set(rule, hw_action_set, kvd_indexes,
                                                   kvd_block_size, is_commit, dev_id,
                                                   is_full_write, region->initial_activity_cleared, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action : Failed write extended actions, for kvd handle[0x%" PRIx64 "]\n",
                       hw_action_set->kvd_handle);
            goto out;
        }
    }

    if (is_full_write) {
        if (is_overwrite) {
            hw_op = (region->initial_activity_cleared) ? ACL_RULE_HW_OP_OVERWRITE_CLEAR_E : ACL_RULE_HW_OP_OVERWRITE_E;
        } else {
            hw_op = (region->initial_activity_cleared) ? ACL_RULE_HW_OP_WRITE_CLEAR_E : ACL_RULE_HW_OP_WRITE_E;
        }
    } else {
        hw_op = ACL_RULE_HW_OP_UPDATE_E;
    }

    /* [SPC2+] No HW rule for default actions */
    if (is_default_actions == FALSE) {
        /* write only register */
        rc = hw_region_attributes->write_reg_cb.rule_hw_cb(
            hw_op,
            dev_id,
            region->region_id,
            hw_region_attributes->region_info[dev_id],
            rule->offset,
            rule->valid,
            rule->priority,
            rule->key_desc_list,
            rule->key_desc_count,
            key_blocks,
            blocks_count,
            &reg_action_set,
            NULL,
            hw_region_attributes->bulk_write);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to configure PTCE2 to dev_idx [%u]\n", dev_id);
        }
    }

    /* Release locks taken for HW writing preparations */
out:
    if (actions_locked) {
        unlock_rc =
            flex_acl_hw_release_action_locks(hw_action_set->action_set.actions,
                                             hw_action_set->action_set.actions_count);
        if (SX_STATUS_SUCCESS != unlock_rc) {
            SX_LOG_ERR("ACL : Failed to release actions locks.\n");
            rc = (rc != SX_STATUS_SUCCESS) ? rc : unlock_rc;
        }
    }

    if (kvd_locked) {
        unlock_rc = kvd_linear_manager_handle_release(hw_action_set->kvd_handle);
        if (SX_STATUS_SUCCESS != unlock_rc) {
            SX_LOG_ERR("ACL action : Failed releasing the kvd lock, kvd_handle: %" PRIu64 "\n",
                       hw_action_set->kvd_handle);
            rc = (rc != SX_STATUS_SUCCESS) ? rc : unlock_rc;
        }
        SX_LOG_DBG("FLOWD:write_only_rule KVD handle:0x%" PRIx64 " release\n", hw_action_set->kvd_handle);
    }
    if (kvd_indexes != NULL) {
        cl_free(kvd_indexes);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_write_rollback_move_rules(flex_acl_db_flex_rule_t  *rules,
                                                  uint32_t                  rules_num,
                                                  flex_acl_db_acl_region_t *acl_region,
                                                  uint32_t                  dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < rules_num; i++) {
        /* move rules backward in db */
        rc =
            flex_acl_hw_write_only_rule(&rules[i], acl_region, dev_id, FALSE, FLEX_ACL_HW_FULL_WRITE, FALSE);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL Fatal error: Failed writing rollback of move rules.\n");
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_get_is_commit(sx_acl_id_t              acl_id,
                                               flex_acl_db_flex_rule_t *rule_p,
                                               boolean_t               *is_commit)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_parallel = FALSE;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_is_parallel(&is_parallel);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get is parallel or serial config\n");
        goto out;
    }
    if (!is_parallel) {
        if (ACL_STAGE_IS_FLEX3_OR_ABOVE(flex_acl_stage) == TRUE) {
            /* For NAT operation we shouldn't do the commit operation as it's performed after the loopback */
            for (i = 0; i < rule_p->action_count; i++) {
                if (rule_p->actions[i].type == SX_FLEX_ACL_ACTION_NAT) {
                    *is_commit = FALSE;
                    goto out;
                }
            }
        }
        *is_commit = TRUE;
        goto out;
    }

    rc = flex_acl_hw_is_commit_acl(acl_id, is_commit);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL calling flex_acl_hw_is_commit_acl, acl_id: %u\n", acl_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_write_rule_devices(flex_acl_db_acl_region_t *acl_region,
                                           flex_acl_db_flex_rule_t  *rule,
                                           sx_acl_key_block_e       *key_blocks,
                                           uint32_t                  key_blocks_cnt,
                                           sxd_flex_action_set_t    *reg_action_set,
                                           acl_rule_hw_op_e          hw_op)
{
    uint32_t                         dev_idx = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    flex_acl_hw_db_region_attribs_t *hw_region_attributes = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        return rc;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &hw_region_attributes);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }
    if (hw_region_attributes->write_reg_cb.rule_hw_cb == NULL) {
        SX_LOG_ERR("ACL: No CB for write rule. Region:%u \n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Adjust default activity state */
    if (hw_op == ACL_RULE_HW_OP_WRITE_E) {
        hw_op = (acl_region->initial_activity_cleared) ? ACL_RULE_HW_OP_WRITE_CLEAR_E : ACL_RULE_HW_OP_WRITE_E;
    }
    if (hw_op == ACL_RULE_HW_OP_OVERWRITE_E) {
        hw_op = (acl_region->initial_activity_cleared) ? ACL_RULE_HW_OP_OVERWRITE_CLEAR_E : ACL_RULE_HW_OP_OVERWRITE_E;
    }
    if (hw_op == ACL_RULE_HW_OP_PRIO_SET_CLEAR_E) {
        hw_op = (acl_region->initial_activity_cleared) ? ACL_RULE_HW_OP_PRIO_SET_E : ACL_RULE_HW_OP_PRIO_SET_CLEAR_E;
    }


    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    rc = hw_region_attributes->write_reg_cb.rule_hw_cb(
        hw_op,
        devs_list[dev_idx],
        acl_region->region_id,
        hw_region_attributes->region_info[devs_list[dev_idx]],
        rule->offset,
        rule->valid,
        rule->priority,
        rule->key_desc_list,
        rule->key_desc_count,
        key_blocks,
        key_blocks_cnt,
        reg_action_set,
        NULL,
        hw_region_attributes->bulk_write);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to configure PTCE2 to dev_idx [%u]\n", dev_idx);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Write Rules register with keys and first action, Write additional action sets to KVD */
sx_status_t flex_acl_hw_write_rule(flex_acl_db_flex_rule_t  *rule,
                                   flex_acl_db_acl_region_t *acl_region,
                                   acl_rule_hw_op_e          hw_op)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS, rc1;
    flex_acl_hw_db_action_set_t      *hw_action_set = NULL;
    kvd_linear_manager_handle_t       kvd_handle = 0;
    kvd_linear_manager_index_t       *kvd_indexes = NULL;
    uint32_t                          kvd_block_size = 0;
    kvd_linear_manager_block_length_t size = 0;
    kvd_linear_manager_index_t        kvd_index_to_write = 0;
    sx_acl_key_t                     *keys = NULL;
    uint8_t                           keys_count = 0;
    sx_acl_key_block_e               *key_blocks = NULL;
    uint32_t                          blocks_count = 0;
    uint32_t                          hw_key_handle = 0;
    boolean_t                         is_commit = FALSE;
    flex_acl_relocation_data_t        relocation_data = {.is_head = 0};
    sxd_flex_action_set_t             reg_action_set;
    sx_sdk_entries_param_t            action_entry_param;
    boolean_t                         is_default_actions = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(action_entry_param);

    if (NULL == rule) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (NULL == acl_region) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    rc = __flex_acl_hw_get_is_commit(acl_region->bound_acl, rule, &is_commit);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL calling __flex_acl_hw_get_is_commit, acl_id: %u\n", acl_region->bound_acl);
        goto out;
    }

    SX_LOG_DBG("FLOWD HW write rule offset:%u valid:%u\n", rule->offset, rule->valid);

    /* Delete rule */
    if (rule->valid == FALSE) {
        rc = flex_acl_hw_write_rule_devices(acl_region, rule, NULL, 0, NULL, ACL_RULE_HW_OP_WRITE_E);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to configure device for rule delete. Region [0x%x], Offset [%u]\n",
                       acl_region->region_id,
                       rule->offset);
            goto out;
        }
        rc = flex_acl_hw_free_third_parties(acl_region->region_id, rule->offset);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL: Failed to free third party, region_id: %u, offset: %u\n",
                       acl_region->region_id, rule->offset);
            goto out;
        }
        rc = flex_acl_hw_free_kvd(acl_region->region_id, rule->offset);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL: Failed to free kvd, region_id: %u, offset: %u\n",
                       acl_region->region_id, rule->offset);
            goto out;
        }

        flex_acl_db_flex_rule_t *actual_rule = NULL;
        rc = flex_acl_db_get_rule_by_offset(acl_region->region_id, rule->offset, &actual_rule);
        if ((SX_STATUS_SUCCESS != rc) || !actual_rule->valid) {
            rc = SX_STATUS_SUCCESS;
            goto out;
        }

        if (actual_rule->action_container_id != FLEX_ACL_INVALID_ACTION_CONTAINER_ID) {
            rc = flex_acl_db_action_container_delete(actual_rule->action_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to delete action container.\n");
                goto out;
            }
            actual_rule->action_container_id = FLEX_ACL_INVALID_ACTION_CONTAINER_ID;
        }

        goto out;
    }

    hw_action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;
    if (NULL == hw_action_set) {
        SX_LOG_ERR("ACL action : Invalid action set handle.\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    is_default_actions = (rule->offset == SX_ACL_DEFAULT_ACTION_OFFSET) ? TRUE : FALSE;

    rc = flex_acl_db_get_flex_key_entry(acl_region->key_handle, &keys, &keys_count, &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_db_get_flex_key_entry, key_handle: %u\n", acl_region->key_handle);
        return rc;
    }
    rc = flex_acl_hw_db_get_key_blocks(hw_key_handle, &key_blocks, &blocks_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_hw_db_get_key_blocks, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }

    kvd_block_size = hw_action_set->kvd_action_set_count;
    SX_LOG_DBG("FLOWD Number of KVD lines :%u \n", kvd_block_size);
    if (!kvd_block_size) {
        relocation_data.is_head = TRUE;
        relocation_data.kvd_index_p = &(hw_action_set->action_set.kvd_index);
        /* Prepare action set for writing to HW, including obtaining third party's HW indexes. */
        rc = flex_acl_hw_create_reg_action_set(hw_action_set->action_set.actions,
                                               hw_action_set->action_set.actions_count,
                                               hw_action_set->action_set.goto_action,
                                               TRUE,
                                               0,
                                               is_commit,
                                               relocation_data,
                                               &reg_action_set,
                                               TRUE,
                                               rule);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action : Failed creating action set.\n");
            goto out;
        }
        /* Write Register */
        SX_LOG_DBG("FLOWD Write PTCE2 Register No KVD\n");
        rc =
            flex_acl_hw_write_rule_devices(acl_region, rule, key_blocks, blocks_count, &reg_action_set, hw_op);
        /* Release locks taken for HW writing preparations */
        rc1 = flex_acl_hw_release_action_locks(hw_action_set->action_set.actions,
                                               hw_action_set->action_set.actions_count);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to configure PTCE2 to device. Region [0x%x], Offset [%u]\n",
                       acl_region->region_id,
                       rule->offset);
            goto out;
        }
        if (SX_STATUS_SUCCESS != rc1) {
            SX_LOG_ERR("ACL : Failed to release locks.\n");
            rc = rc1;
            goto out;
        }

        goto out;
    }

    if (is_default_actions) {
        kvd_block_size--;       /* The first default action set has pre-allocated KVD entry */

        if (kvd_block_size == 0) {
            rc = flex_acl_hw_write_first_default_action_set(rule,
                                                            acl_region->region_id,
                                                            hw_action_set,
                                                            NULL,
                                                            TRUE,
                                                            acl_region->initial_activity_cleared,
                                                            is_commit,
                                                            TRUE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL action : Failed write the default action set for region [%d]\n",
                           acl_region->region_id);
            }
            goto out;
        }
    }

    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                        SX_ACCESS_CMD_ADD,
                        kvd_block_size,
                        &action_entry_param);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed on RM entry set for RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E.\n");
        goto out;
    }
    rc = kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_ACL_RULES_E, kvd_block_size, FALSE, &kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        rm_entries_set(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                       SX_ACCESS_CMD_DELETE,
                       kvd_block_size,
                       &action_entry_param);
        SX_LOG_ERR("ACL action : Failed allocating kvd block.\n");
        goto out;
    }
    SX_LOG_DBG("FLOWD hw write rule add KVD block:0x%" PRIx64 " \n", kvd_handle);

    hw_action_set->kvd_handle = kvd_handle;

    /* Add the KVD handler to DBs */
    rc = flex_acl_hw_db_kvd_add_entry(kvd_handle, hw_action_set);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed allocating kvd adding kvd handle entry, kvd_handle: %" PRIu64 "\n",
                   kvd_handle);
        goto kvd_error_block;
    }
    SX_LOG_DBG("FLOWD hw write rule add KVD DB entry.\n");

    kvd_indexes = (kvd_linear_manager_index_t*)cl_malloc(sizeof(kvd_linear_manager_index_t) * kvd_block_size);
    if (kvd_indexes == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        goto kvd_error_block;
    }

    size = kvd_block_size;
    rc = kvd_linear_manager_handle_lock(kvd_handle, kvd_indexes, &size);
    if ((SX_STATUS_SUCCESS != rc) || (size < kvd_block_size)) {
        SX_LOG_ERR("ACL action : Failed locking kvd block, kvd_handle: %" PRIu64 "\n", kvd_handle);
        rc = SX_STATUS_ERROR;
        goto kvd_error_block;
    }

    SX_LOG_DBG("FLOWD hw write rule add KVD lock \n");
    /* Update KVD index at register action set */

    kvd_index_to_write = hw_action_set->action_set.kvd_index = kvd_indexes[0];
    if (is_default_actions == FALSE) {
        /* Write rule register, we have the index of the next */
        relocation_data.is_head = TRUE;
        relocation_data.kvd_index_p = &(hw_action_set->action_set.kvd_index);
        /* Prepare action set for writing to HW, including obtaining third party's HW indexes. */
        rc = flex_acl_hw_create_reg_action_set(hw_action_set->action_set.actions,
                                               hw_action_set->action_set.actions_count,
                                               hw_action_set->action_set.goto_action,
                                               FALSE,
                                               kvd_index_to_write,
                                               is_commit,
                                               relocation_data,
                                               &reg_action_set,
                                               TRUE,
                                               rule);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL action : Failed creating action set for ptce2 with action extension.\n");
            goto kvd_error_release;
        }
    }

    /* write action sets to kvd */
    rc = flex_acl_hw_write_extended_action_set(rule, hw_action_set, kvd_indexes,
                                               kvd_block_size, is_commit, 0,
                                               TRUE, acl_region->initial_activity_cleared, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed write extended actions, for kvd handle[0x%" PRIx64 "]\n",
                   hw_action_set->kvd_handle);
        goto out;
    }

    if (is_default_actions == TRUE) {
        rc = flex_acl_hw_write_first_default_action_set(rule,
                                                        acl_region->region_id,
                                                        hw_action_set,
                                                        &kvd_indexes[0],
                                                        TRUE,
                                                        acl_region->initial_activity_cleared,
                                                        is_commit,
                                                        TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed write the default action set for region [%d]\n",
                       acl_region->region_id);
            goto out;
        }
    } else {
        rc = flex_acl_hw_write_rule_devices(acl_region, rule, key_blocks, blocks_count, &reg_action_set, hw_op);
        /* Release locks taken for HW writing preparations */
        rc1 = flex_acl_hw_release_action_locks(hw_action_set->action_set.actions,
                                               hw_action_set->action_set.actions_count);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to configure key to device. Region [0x%x], Offset [%u]\n",
                       acl_region->region_id,
                       rule->offset);
            goto kvd_error_release;
        }
        if (SX_STATUS_SUCCESS != rc1) {
            SX_LOG_ERR("ACL : Failed to release locks. Region [0x%x], Offset [%u]\n",
                       acl_region->region_id,
                       rule->offset);
            rc = rc1;
            goto kvd_error_release;
        }
    }

    rc = kvd_linear_manager_handle_release(kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed releasing the kvd lock, kvd_handle: %" PRIu64 "\n", kvd_handle);
        goto kvd_error_block;
    }
    SX_LOG_DBG("FLOWD hw write rule KVD handle:0x%" PRIx64 " release\n", kvd_handle);

    rc = kvd_linear_manager_ref_add(kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed adding reference, kvd_handle: %" PRIu64 "\n", kvd_handle);
        goto kvd_error_block;
    }
    SX_LOG_DBG("FLOWD hw write rule KVD ref add handle:0x%" PRIx64 " \n", kvd_handle);

    goto out;

kvd_error_release:
    kvd_linear_manager_handle_release(kvd_handle);
kvd_error_block:
    kvd_linear_manager_block_delete(kvd_handle, FALSE);
    rm_entries_set(action_entry_param.resource, SX_ACCESS_CMD_DELETE, kvd_block_size,
                   &action_entry_param);
out:
    if (kvd_indexes) {
        cl_free(kvd_indexes);
    }
    SX_LOG_EXIT();
    return rc;
}

/* the function should set up acl group on hw. The flow checks than num of acls aren't equal to zero,
 * because pagt write with acl num = 0 are invalidates the group.
 * NOTE: Usually, RM is needed for the number of ACLs in groups. This should be done by calling the
 * flex_acl_write_bind_attributes which in turn calls this function.
 */
sx_status_t flex_acl_hw_reg_write_group(flex_acl_bind_attribs_id_t new_bind_attribs_id,
                                        acl_id_group_entry_t      *acl_ids_prepared,
                                        uint32_t                   prepared_ids_num)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                          i = 0;
    uint32_t                          j = 0;
    struct ku_pagt_v2_reg             pagt_v2_reg_data;
    sxd_reg_meta_t                    pagt_v2_reg_meta;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          dev_idx = 0;
    sx_dev_id_t                       devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                          dev_info_arr_size = 0;

#ifdef UNITTESTS
    struct ku_pagt_reg pagt_reg_data;
    sxd_reg_meta_t     pagt_reg_meta;
#endif  /* UNITTESTS */

    SX_LOG_ENTER();

    if (prepared_ids_num == 0) {
        SX_LOG_ERR("ACL : Attempt to write illegal PAGT configuration, the group size are 0\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (rm_resource_global.acl_groups_size_max < prepared_ids_num) {
        SX_LOG_ERR("Too many acl ids for bind attr %#x list.\n", new_bind_attribs_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    SX_MEM_CLR(pagt_v2_reg_meta);
    SX_MEM_CLR(pagt_v2_reg_data);

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    rc = flex_acl_db_attribs_get(new_bind_attribs_id, &bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", new_bind_attribs_id);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    pagt_v2_reg_meta.dev_id = devs_list[dev_idx];
    pagt_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;


    for (i = 0; i < prepared_ids_num; i++) {
        /* We actually want to write the entries from the last to the first
         * so the head of the list will be written last and allow on to
         * perform an in-place replacement of the list.
         */
        j = prepared_ids_num - i - 1;

        pagt_v2_reg_data.acl_group_element = acl_ids_prepared[j].acl_group_element;
        pagt_v2_reg_data.acl_id = acl_ids_prepared[j].acl_id;
        pagt_v2_reg_data.commit = (acl_ids_prepared[j].is_commit) ? 1 : 0;
        pagt_v2_reg_data.multi = (acl_ids_prepared[j].is_multi) ? 1 : 0;
        pagt_v2_reg_data.id_v = 1;
        pagt_v2_reg_data.n_v = (i == 0) ? 0 : 1;
        pagt_v2_reg_data.next_acl_group_element = (i == 0) ? 0 : acl_ids_prepared[j + 1].acl_group_element;

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_V2_E,
                                                         &pagt_v2_reg_data,
                                                         &pagt_v2_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to configure ACL group [%u], element [%u] to HW rc [%u] \n",
                       bind_attribs->bind_id,
                       pagt_v2_reg_data.acl_group_element,
                       sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
#ifdef UNITTESTS
    /*
     * NOTE: This code is intended to be used for unit test only.
     * Since a great number of UTs used PAGT it was impractical to convert
     * all of them to the PAGT_V2 method. Therefore the UT actually writes to
     * both PAGT & PAGT_V2 for ACL groups operations.
     */

    SX_MEM_CLR(pagt_reg_meta);
    SX_MEM_CLR(pagt_reg_data);

    pagt_reg_meta.dev_id = devs_list[dev_idx];
    pagt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pagt_reg_data.acl_group_id = bind_attribs->bind_id;
    pagt_reg_data.size = prepared_ids_num;

    for (i = 0; i < pagt_reg_data.size; i++) {
        pagt_reg_data.acl_ids[i].acl_id = acl_ids_prepared[i].acl_id;
        pagt_reg_data.acl_ids[i].commit = (acl_ids_prepared[i].is_commit) ? 1 : 0;
        pagt_reg_data.acl_ids[i].multi = (acl_ids_prepared[i].is_multi) ? 1 : 0;
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_E, &pagt_reg_data, &pagt_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure ACL group [%u] to HW rc [%u] \n", bind_attribs->bind_id, sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }
#endif  /* UNITTESTS */

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    /* Put all written ACL IDs to the bind attributes DB */
    for (i = 0; i < prepared_ids_num; i++) {
        bind_attribs->acl_id_list[i] = acl_ids_prepared[i];
    }
    bind_attribs->acl_id_num = prepared_ids_num;

out:
    SX_LOG_EXIT();
    return rc;
}
/* This function invalidates an ACL group.
 * NOTE: Usually, RM is needed for the number of ACLs in groups. This should be done by calling the
 * flex_acl_write_bind_attributes which in turn calls this function.
 */
sx_status_t flex_acl_hw_reg_invalidate_group(flex_acl_bind_attribs_id_t bind_attribs_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t                 utils_err = SX_UTILS_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pagt_v2_reg             pagt_v2_reg_data;
    sxd_reg_meta_t                    pagt_v2_reg_meta;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          dev_idx = 0;
    sx_dev_id_t                       devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                          dev_info_arr_size = 0;
    uint32_t                          i = 0;

#ifdef UNITTESTS
    struct ku_pagt_reg pagt_reg_data;
    sxd_reg_meta_t     pagt_reg_meta;
#endif  /* UNITTESTS */

    SX_LOG_ENTER();

    SX_MEM_CLR(pagt_v2_reg_meta);
    SX_MEM_CLR(pagt_v2_reg_data);

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to get devices list\n");
        goto out;
    }

    rc = flex_acl_db_attribs_get(bind_attribs_id, &bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", bind_attribs_id);
        goto out;
    }

    /* Fence needs to be performed before PAGT delete flows. For now
     * we do a synchronous fence, in the future the delete should go through
     * the garbage collector and become asynchronous.
     */
    utils_err = gc_object_fence(GC_FENCE_TYPE_FAST);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        rc = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to perform fast fence, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    SX_LOG_DBG("Performed fast fence before invalidating ACL group %u\n",
               bind_attribs->bind_id);

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    pagt_v2_reg_meta.dev_id = devs_list[dev_idx];
    pagt_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    for (i = 0; i < bind_attribs->acl_id_num; i++) {
        /* Invalidate the group starting from the head of the list */
        pagt_v2_reg_data.acl_group_element = bind_attribs->acl_id_list[i].acl_group_element;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_V2_E,
                                                         &pagt_v2_reg_data,
                                                         &pagt_v2_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to configure ACL group [%u], element [%u] to HW rc [%u] \n",
                       bind_attribs->bind_id,
                       pagt_v2_reg_data.acl_group_element,
                       sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
#ifdef UNITTESTS
    /*
     * NOTE: This code is intended to be used for unit test only.
     * Since a great number of UTs used PAGT it was impractical to convert
     * all of them to the PAGT_V2 method. Therefore the UT actually writes to
     * both PAGT & PAGT_V2 for ACL groups operations.
     */

    SX_MEM_CLR(pagt_reg_meta);
    SX_MEM_CLR(pagt_reg_data);

    pagt_reg_meta.dev_id = devs_list[dev_idx];
    pagt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pagt_reg_data.acl_group_id = bind_attribs->bind_id;
    pagt_reg_data.size = 0;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_E, &pagt_reg_data, &pagt_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure ACL group [%u] to HW rc [%u] \n", bind_attribs->bind_id, sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }
#endif  /* UNITTESTS */

    SX_FDB_FOR_EACH_LEAF_DEV_END;
    /* Clean bind attributes DB of ACL IDs */
    bind_attribs->acl_id_num = 0;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_hw_handle_late_binding(boolean_t                     *late_binding_p,
                                              uint64_t                       key,
                                              flex_acl_hw_db_binding_data_t *data_p)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_boot_mode_e issu_boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    if (late_binding_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("late_binding_p is NULL.\n");
        goto out;
    }
    if (data_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("data_p is NULL.\n");
        goto out;
    }

    *late_binding_p = FALSE;

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get. sx_status = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }
    *late_binding_p = TRUE;

    rc = flex_acl_hw_db_handle_late_binding(key, data_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to do late binding, key: %" PRIu64 ", sx_status = %s\n",
                   key, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_hw_reg_write_ppbt(flex_acl_hw_db_binding_data_t *binding_data_p)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_ppbt_reg ppbt_reg_data = {.op = 0};
    sxd_reg_meta_t     ppbt_reg_meta = {.access_cmd = 0};
    sx_status_t        rc = SX_STATUS_SUCCESS;

    if (binding_data_p->binding_type != FLEX_ACL_HW_BINDING_PORT_E) {
        SX_LOG_ERR("Binding type %u is unsupported for PPBT.\n", binding_data_p->binding_type);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    SX_MEM_CLR(ppbt_reg_meta);
    SX_MEM_CLR(ppbt_reg_data);

    ppbt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    ppbt_reg_meta.dev_id = SX_PORT_DEV_ID_GET(binding_data_p->data.port.log_port);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ppbt_reg_data.local_port, ppbt_reg_data.lp_msb,
                                        SX_PORT_PHY_ID_GET(binding_data_p->data.port.log_port));
    ppbt_reg_data.op = (binding_data_p->bind) ? SXD_PPBT_OP_BIND_E : SXD_PPBT_OP_UNBIND_E;
    ppbt_reg_data.e = binding_data_p->data.port.direction % 2; /* ingress or egress direction only */
    ppbt_reg_data.g = TRUE;
    ppbt_reg_data.acl_id_group_id = binding_data_p->data.port.bind_id;
    ppbt_reg_data.tport =
        (SX_PORT_TYPE_ID_GET(binding_data_p->data.port.log_port) == SX_PORT_TYPE_TUNNEL) ? TRUE : FALSE;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PPBT_E, &ppbt_reg_data, &ppbt_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind port SXD err [%u]\n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_hw_reg_write_prbt(flex_acl_hw_db_binding_data_t *binding_data_p)
{
    uint32_t           dev_idx = 0, i = 0;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_prbt_reg prbt_reg_data = {.group_binding = 0};
    sxd_reg_meta_t     meta = {.access_cmd = 0};
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t           dev_info_arr_size = 0;

    SX_LOG_ENTER();
    if (binding_data_p->binding_type != FLEX_ACL_HW_BINDING_RIF_E) {
        SX_LOG_ERR("Binding type %u unsupported for PRBT.\n", binding_data_p->binding_type);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to get devices list\n");
        goto out;
    }

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    rc = sdk_router_cmn_rif_hw_id_get(binding_data_p->data.rif.rif_id, &prbt_reg_data.rif);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR,
               "sdk_router_cmn_rif_hw_id_get failed, rif_id: %u, err %s\n",
               binding_data_p->data.rif.rif_id,
               sx_status_str(rc));
        goto out;
    }
    prbt_reg_data.op = KU_PRBT_REG_OP_TYPE_BIND_ACL;
    if (binding_data_p->bind == FALSE) {
        prbt_reg_data.op = KU_PRBT_REG_OP_TYPE_UNBIND_ACL;
    }
    prbt_reg_data.egress_indication = binding_data_p->data.rif.direction % 2; /* direction ingress or egress only */
    prbt_reg_data.group_binding = SXD_GROUP_OR_ACL_BINDING_TYPE_GROUP_E;
    prbt_reg_data.acl_id_grp_id = binding_data_p->data.rif.bind_id;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    meta.dev_id = devs_list[dev_idx];

    /* Bind to Vlan group */
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PRBT_E, &prbt_reg_data, &meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind rif SXD err [%u]\n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto error;
    }
    /* Reference updates of ACL groups are being done outside the function */
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    goto out;

error:
/* rollback all devices that was set */
    prbt_reg_data.op = !prbt_reg_data.op;
    for (i = 0; i < dev_idx; i++) {
        meta.dev_id = devs_list[i];
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PRBT_E, &prbt_reg_data, &meta, 1, NULL, NULL);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_issu_bind_acl_trigger()
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    cl_qmap_t                      *binding_map_p = NULL;
    cl_map_item_t                  *map_item_p = NULL;
    const cl_map_item_t            *map_end_p = NULL;
    flex_acl_hw_db_binding_entry_t *binding_entry_p = NULL;
    uint32_t                        type;

    for (type = FLEX_ACL_HW_BINDING_MIN_E; type <= FLEX_ACL_HW_BINDING_MAX_E; type++) {
        rc = flex_acl_hw_db_get_late_binding_map(type, &binding_map_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get binding map for type %u. sx_status = %s\n",
                       type, sx_status_str(rc));
            goto out;
        }
        map_item_p = cl_qmap_head(binding_map_p);
        map_end_p = cl_qmap_end(binding_map_p);
        while (map_item_p != map_end_p) {
            binding_entry_p = PARENT_STRUCT(map_item_p, flex_acl_hw_db_binding_entry_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);


            switch (type) {
            case FLEX_ACL_HW_BINDING_PORT_E:
                rc = __flex_acl_hw_reg_write_ppbt(&binding_entry_p->binding_data);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to write ppbt.\n");
                    goto out;
                }
                break;

            case FLEX_ACL_HW_BINDING_VLAN_E:
                rc = __flex_acl_hw_reg_write_pvgt(&binding_entry_p->binding_data);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to write pvgt.\n");
                    goto out;
                }
                break;

            case FLEX_ACL_HW_BINDING_RIF_E:
                rc = __flex_acl_hw_reg_write_prbt(&binding_entry_p->binding_data);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to write prbt.\n");
                    goto out;
                }
                break;

            /* coverity[dead_error_begin] */
            default:
                SX_LOG_ERR("Register is not handled for type %u.\n", type);
                break;
            }
            flex_acl_hw_db_remove_late_binding_entry(binding_entry_p);
        }
        cl_qmap_remove_all(binding_map_p);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_port(sx_port_log_id_t                  log_port,
                                       flex_acl_db_group_bind_attribs_t *bind_attribs,
                                       boolean_t                         bind,
                                       boolean_t                         write_to_reg)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_binding_data_t binding_data;
    boolean_t                     late_binding = FALSE;
    uint64_t                      key;

    SX_LOG_ENTER();

    if (write_to_reg == FALSE) {
        goto out;
    }

    SX_MEM_CLR(binding_data);
    binding_data.binding_type = FLEX_ACL_HW_BINDING_PORT_E;
    binding_data.bind = bind;
    binding_data.data.port.direction = PORT_BIND_DIRECTION(bind_attribs->direction);
    binding_data.data.port.bind_id = bind_attribs->bind_id;
    binding_data.data.port.log_port = log_port;
    key = FLEX_ACL_LATE_BINDING_PORT_KEY(bind_attribs->direction, log_port);
    rc = __flex_acl_hw_handle_late_binding(&late_binding, key, &binding_data);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to do late binding.\n");
        goto out;
    }
    if (late_binding == TRUE) {
        SX_LOG_DBG("Do late binding, not write to register now.\n");
        goto out;
    }

    rc = __flex_acl_hw_reg_write_ppbt(&binding_data);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to write ppbt.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_vlan_group_bind(sx_acl_vlan_group_t               vlan_group,
                                                  flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                  uint8_t                           bind)
{
    uint32_t           dev_idx = 0, i = 0;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pvbt_reg pvbt_reg_data = {.op = 0};
    sxd_reg_meta_t     meta = {.access_cmd = 0};
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t           dev_info_arr_size = 0;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pvbt_reg_data);

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL: Failed to get devices list\n");
        goto out;
    }

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    pvbt_reg_data.swid = 0;
    pvbt_reg_data.op = SXD_PVBT_OP_BIND_E;
    if (bind == FALSE) {
        pvbt_reg_data.op = SXD_PVBT_OP_UNBIND_E;
    }
    pvbt_reg_data.vlan_group = vlan_group;
    pvbt_reg_data.g = TRUE;
    pvbt_reg_data.acl_id_group_id = bind_attribs->bind_id;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    meta.dev_id = devs_list[dev_idx];

    /* Bind to Vlan group */
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVBT_E, &pvbt_reg_data, &meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind vlan SXD err [%u]\n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto error;
    }
    /* Reference updates of ACL groups are being done outside the function */
    SX_FDB_FOR_EACH_LEAF_DEV_END;
    goto out;

error:
/* rollback all devices that was set */
    pvbt_reg_data.op = !pvbt_reg_data.op;
    for (i = 0; i < dev_idx; i++) {
        meta.dev_id = devs_list[i];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVBT_E, &pvbt_reg_data, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("fatal error at rollback in sxd_access_reg_pvbt\n");
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_rif_bind(sx_rif_id_t                       rif,
                                           flex_acl_db_group_bind_attribs_t *bind_attribs,
                                           boolean_t                         bind)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_binding_data_t binding_data;
    boolean_t                     late_binding = FALSE;
    uint64_t                      key;

    SX_LOG_ENTER();

    SX_MEM_CLR(binding_data);
    binding_data.binding_type = FLEX_ACL_HW_BINDING_RIF_E;
    binding_data.bind = bind;
    binding_data.data.rif.direction = bind_attribs->direction;
    binding_data.data.rif.bind_id = bind_attribs->bind_id;
    binding_data.data.rif.rif_id = rif;
    key = FLEX_ACL_LATE_BINDING_RIF_KEY(bind_attribs->direction, rif);
    rc = __flex_acl_hw_handle_late_binding(&late_binding, key, &binding_data);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to do late binding, key: %" PRIu64 "\n", key);
        goto out;
    }
    if (late_binding == TRUE) {
        SX_LOG_DBG("Do late binding, not write to register now.\n");
        goto out;
    }

    rc = __flex_acl_hw_reg_write_prbt(&binding_data);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to write prbt.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* Decide if acl should be unbind at group update. if current acl exist in at least one of groups - can't be unbound
 * 1. Get groups list from acl
 * 2. Get head of each group in the list
 * 3. The acl should stay unattached when:
 *      If at least one of heads are bound
 *      If acl holds system group */
sx_status_t flex_acl_hw_should_unbind_acl_at_group_update(sx_acl_id_t acl_id, boolean_t *unbind)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t               *group_id_get = NULL;
    sx_acl_id_t                group_head_id = FLEX_ACL_INVALID_ACL_ID;
    const cl_list_t           *groups_list = NULL;
    cl_list_iterator_t         list_iter = NULL;
    cl_list_iterator_t         list_end = NULL;
    flex_acl_bind_attribs_id_t bind_attribs_id_other = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    boolean_t                  is_commit = FALSE;

    SX_LOG_ENTER();
    *unbind = TRUE;

    /* check that acl isn't commit acl */
    rc = flex_acl_hw_is_commit_acl(acl_id, &is_commit);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed check of commit acl id %u\n", acl_id);
        goto out;
    }

    if (is_commit) {
        *unbind = FALSE;
        goto out;
    }

    rc = flex_acl_db_acl_get_group_list(acl_id, &groups_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get group list from acl table error, acl_id: %u\n", acl_id);
        goto out;
    }

    /* check that each group in the list aren't bound */
    list_end = cl_list_end(groups_list);
    list_iter = cl_list_head(groups_list);
    while (list_iter != list_end) {
        group_id_get = cl_list_obj(list_iter);

        rc = flex_acl_db_get_groups_head(*group_id_get, &group_head_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("get acl table error, group_id: %u\n", *group_id_get);
            goto out;
        }

        rc = flex_acl_db_acl_group_get_bind_attribs_id(group_head_id, &bind_attribs_id_other);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("get acl table error, group_id: %u\n", group_head_id);
            goto out;
        }
        if (bind_attribs_id_other != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            *unbind = FALSE;
            goto out;
        }
        list_iter = cl_list_next(list_iter);
    }
out:
    SX_LOG_EXIT();
    return (rc);
}

/* Decide if acl should be unbind.
 * 1. Get groups list from acl
 * 2. Get head of each group in the list
 * 3. The acl should stay unattached when:
 *      If acl holds system group
 *      If head is bound and bind attributes are different from bind attributes to unbind - no need to unbind */
sx_status_t flex_acl_hw_should_unbind_acl(sx_acl_id_t acl_id, sx_acl_id_t group_id, boolean_t *unbind)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t               *group_id_get = NULL;
    sx_acl_id_t                group_head_id = FLEX_ACL_INVALID_ACL_ID;
    const cl_list_t           *groups_list = NULL;
    cl_list_iterator_t         list_iter = NULL;
    cl_list_iterator_t         list_end = NULL;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t bind_attribs_id_other = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    boolean_t                  is_commit = FALSE;

    SX_LOG_ENTER();

    *unbind = TRUE;

    /* check that acl isn't commit acl */
    rc = flex_acl_hw_is_commit_acl(acl_id, &is_commit);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed check of commit acl id %u\n", acl_id);
        goto out;
    }

    if (is_commit) {
        *unbind = FALSE;
        goto out;
    }

    rc = flex_acl_db_acl_get_group_list(acl_id, &groups_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get group list from acl table error, acl_id: %u\n", acl_id);
        goto out;
    }
    rc = flex_acl_db_get_groups_head(group_id, &group_head_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get group head error, group_id: %u\n", group_id);
        goto out;
    }
    rc = flex_acl_db_acl_group_get_bind_attribs_id(group_head_id, &bind_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get bind attributes id error, group_id: %u\n", group_head_id);
        goto out;
    }

    /* check that each group in the list aren't bound */
    list_end = cl_list_end(groups_list);
    list_iter = cl_list_head(groups_list);
    while (list_iter != list_end) {
        group_id_get = cl_list_obj(list_iter);

        rc = flex_acl_db_get_groups_head(*group_id_get, &group_head_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("get acl table error, group_id: %u\n", *group_id_get);
            goto out;
        }

        rc = flex_acl_db_acl_group_get_bind_attribs_id(group_head_id, &bind_attribs_id_other);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("get acl table error, group_id: %u\n", group_head_id);
            goto out;
        }
        if (bind_attribs_id_other != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            *unbind = FALSE;
            goto out;
        }
        list_iter = cl_list_next(list_iter);
    }
out:
    SX_LOG_EXIT();
    return (rc);
}

/* The function run over linked groups and accumulate ACLs within groups and put commit acl id between logical
 * groups. The output of function is acl list that will be write to register
 * Note that prepared_ids_num in/out parameter, on in max num of acls in current array, on out returns actual number.*/
sx_status_t flex_acl_hw_prepare_acl_list_from_groups(sx_acl_id_t           group_id,
                                                     acl_id_group_entry_t *acl_ids_prepared,
                                                     uint32_t             *prepared_ids_num,
                                                     sx_acl_direction_t    direction)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *group = NULL;
    sx_acl_id_t              groups_run_id = FLEX_ACL_INVALID_ACL_ID;
    uint32_t                 i = 0;
    uint32_t                 prepare_i = 0;
    sx_acl_id_t              commit_acl_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                is_parallel = FALSE;
    flex_acl_entry_type_e    entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;
    flex_acl_db_acl_table_t *acl_table = NULL;

    SX_LOG_ENTER();

    /* Check if this is a system group */
    rc = flex_acl_db_group_entry_type_get(group_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group type [%#x]\n", group_id);
        goto out;
    }

    rc = flex_acl_db_get_is_parallel(&is_parallel);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get is parallel or serial config\n");
        goto out;
    }

    rc = flex_acl_db_get_groups_head(group_id, &groups_run_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id);
        goto out;
    }

    SX_LOG_DBG("Adding acls :\n");
    do {
        rc = flex_acl_db_get_acl_group(groups_run_id, &group);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", groups_run_id);
            goto out;
        }
        /* Validate direction */
        if (group->direction != direction) {
            SX_LOG_ERR("ACL : The direction %d of group id %d are different from desired direction %d\n",
                       group->direction, groups_run_id, direction);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        /* copy the acls to prepared list */
        for (i = 0; i < group->acl_num; i++) {
            if (prepare_i >= *prepared_ids_num) {
                SX_LOG_ERR("The num of ACLs in hw group exceeds the rm range\n");
                rc = SX_STATUS_ERROR;
                goto out;
            }
            /* Get the ACL info to see if it's a commit ACL.
             * ACLs are set as commit in special cases only (and explicitly).
             */
            rc = flex_acl_db_acl_get(group->acl_ids[i], &acl_table);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed getting ACL for HW prepare acl list, acl id[%d]\n", group->acl_ids[i]);
                goto out;
            }
            acl_ids_prepared[prepare_i].acl_id = group->acl_ids[i];
            acl_ids_prepared[prepare_i].is_commit = acl_table->is_commit;
            acl_ids_prepared[prepare_i].is_multi = FALSE;
            prepare_i++;
            SX_LOG_DBG(" ACL id prepared - %d\n", acl_ids_prepared[prepare_i - 1].acl_id);
        }
        /* add commit acl if execution type is parallel and we actually added acls.*/
        if (is_parallel && (group->acl_num > 0) && (entry_type != FLEX_ACL_ENTRY_TYPE_AGGREGATE_E)) {
            /* Get commit acl to put it between groups */
            rc = flex_acl_hw_commit_acl_get(&commit_acl_id, direction);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL : Failed to get commit acl id [0x%x]\n", commit_acl_id);
                goto out;
            }
            /* NOTE: This can change the commit only to TRUE. It cannot change the commit state set above. */
            if (commit_acl_id == FLEX_ACL_INVALID_ACL_ID) {
                /* For spectrum2 there is no need for a dedicated acl we just mark the last acl as commit. */
                if (prepare_i > 0) {
                    acl_ids_prepared[prepare_i - 1].is_commit = TRUE;
                }
            } else {
                /* For spectrum1 there is a need for a dedicated acl to act as commit. */
                if (prepare_i >= *prepared_ids_num) {
                    SX_LOG_ERR("The num of ACLs in group exceeds the rm range\n");
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
                acl_ids_prepared[prepare_i].acl_id = commit_acl_id;
                acl_ids_prepared[prepare_i].is_commit = FALSE;
                acl_ids_prepared[prepare_i].is_multi = FALSE;
                prepare_i++;
                SX_LOG_DBG("Is parallel - c%d \n", acl_ids_prepared[prepare_i - 1].acl_id);
            }
        }

        groups_run_id = group->next_acl_group_id;
    } while (groups_run_id != FLEX_ACL_INVALID_ACL_ID);

    *prepared_ids_num = prepare_i;

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_hw_update_acl_list_with_shadows(acl_id_group_entry_t *acl_ids,
                                                     uint32_t              acl_ids_num,
                                                     acl_id_group_entry_t *acl_ids_prepared,
                                                     uint32_t             *prepared_ids_num)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table = NULL;
    uint32_t                 i = 0;
    uint32_t                 acls_with_shadow_count = 0;

    SX_LOG_ENTER();

    /* The acls in the list might have a shadow acl which we need to insert into the list
     *  in order to implement a multi ACL feature.
     */
    for (i = 0; i < acl_ids_num; i++) {
        rc = flex_acl_db_acl_get(acl_ids[i].acl_id, &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting ACL for bind attributes write, acl id[%d]\n", acl_ids[i].acl_id);
            goto out;
        }
        /* If the ACL in the list we got is already a shadow ACL we ignore it in order not to add it twice */
        if (acl_table->shadow_of_acl_id != FLEX_ACL_INVALID_ACL_ID) {
            continue;
        }
        if (acls_with_shadow_count >= *prepared_ids_num) {
            SX_LOG_ERR("The number of ACLs in hw group exceeds the rm range\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        acl_ids_prepared[acls_with_shadow_count] = acl_ids[i];
        acl_ids_prepared[acls_with_shadow_count++].is_multi = FALSE;
        /* If this acl has a shadow ACL we need to insert it into the list */
        if (acl_table->shadowed_by_acl_id != FLEX_ACL_INVALID_ACL_ID) {
            if (acls_with_shadow_count >= *prepared_ids_num) {
                SX_LOG_ERR("The number of ACLs in hw group exceeds the rm range\n");
                rc = SX_STATUS_ERROR;
                goto out;
            }
            /* Update the last ACL that it's now a multi ACL */
            acl_ids_prepared[acls_with_shadow_count - 1].is_multi = TRUE;
            /* Add the shadow acl */
            acl_ids_prepared[acls_with_shadow_count].acl_id = acl_table->shadowed_by_acl_id;
            acl_ids_prepared[acls_with_shadow_count].is_commit = acl_ids[i].is_commit;
            acl_ids_prepared[acls_with_shadow_count++].is_multi = FALSE;
        }
    }

    *prepared_ids_num = acls_with_shadow_count;
out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t flex_acl_hw_region_hw_size_set(sx_acl_region_id_t region_id, sx_dev_id_t dev_id, sx_acl_size_t hw_size)
{
    flex_acl_db_acl_region_t        *acl_region = NULL;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *region_attribs = NULL;

    SX_LOG_ENTER();

    if (dev_id >= SX_DEV_NUM_MAX) {
        SX_LOG_ERR("dev_idx id exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region error, region_id: %u\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &region_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region attributes error, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }

    region_attribs->hw_size[dev_id] = hw_size;
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_region_update_bind(sx_acl_region_id_t region_id,
                                           sx_dev_id_t        dev_id,
                                           uint8_t          * tcam_region_info_arr,
                                           uint32_t           tcam_region_info_size)
{
    flex_acl_db_acl_region_t        *acl_region = NULL;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *region_attribs = NULL;

    SX_LOG_ENTER();

    if (dev_id >= SX_DEV_NUM_MAX) {
        SX_LOG_ERR("dev_idx id exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region error, region_id: %u\n", region_id);
        goto out;
    }
    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &region_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region attributes error, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }

    if (tcam_region_info_size != sizeof(region_attribs->region_info[dev_id])) {
        SX_LOG_ERR("ACL : Provided tcam region info buffer is not in the right size (%u != %u)\n",
                   tcam_region_info_size, (uint32_t)sizeof(region_attribs->region_info[dev_id]));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memcpy(region_attribs->region_info[dev_id],
           tcam_region_info_arr,
           tcam_region_info_size);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_region_update_unbind(sx_acl_region_id_t region_id, sx_dev_id_t dev_id)
{
    flex_acl_db_acl_region_t        *acl_region = NULL;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *region_attribs = NULL;

    SX_LOG_ENTER();

    if (dev_id >= SX_DEV_NUM_MAX) {
        SX_LOG_ERR("dev_idx id exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region error, region_id: %u\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &region_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region attributes error, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }

    memset(region_attribs->region_info[dev_id],
           0,
           sizeof(region_attribs->region_info[dev_id]));
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_region_attribs_set(sx_acl_region_id_t region_id, flex_acl_hw_db_region_attribs_t *attribs)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    system_acl_client_table_entry_t *client_table_entry = NULL;
    uint32_t                         handle = 0;

    SX_LOG_ENTER();

    if (NULL == default_register_cbs_p) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Cannot set region attributes. Default register callbacks not set.\n");
        goto out;
    }

    /* set default callback functions */
    attribs->write_reg_cb = *default_register_cbs_p;

    /* User ACLs should always attempt to free unused memory when necessary.
     * System ACLs are responsible for freeing unused memory themselves, for
     * now.
     */
    rc = system_acl_client_get(region_id, &client_table_entry);
    if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
        attribs->free_unused_memory = TRUE;
    } else if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get system ACL client for region ID %u, rc = [%s]\n",
                   region_id, sx_status_str(rc));
        goto out;
    } else {
        attribs->free_unused_memory = FALSE;
    }
    attribs->bulk_write = FALSE;

    /* Allocate and set handle for attributes */
    rc = flex_acl_hw_db_set_region_attributes(attribs, &handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes \n");
        goto out;
    }

    /* update db about allocated handle */
    rc = flex_acl_db_region_hw_handle_set(region_id, handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set hw attributes handle %u to region %u\n", handle, region_id);
        goto error;
    }
    goto out;
error:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_hw_db_remove_region_attributes(handle))) {
        SX_LOG_ERR("Fatal error  at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}


/* The rollback attributes should be allocated in caller function */
sx_status_t flex_acl_hw_region_attribs_remove(sx_acl_region_id_t               region_id,
                                              flex_acl_hw_db_region_attribs_t *rollback_attribs)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    uint32_t                         handle = 0;
    flex_acl_hw_db_region_attribs_t *attribs_get = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_hw_handle_get(region_id, &handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set hw attributes handle %u to region %u\n", handle, region_id);
        goto out;
    }

    if (rollback_attribs != NULL) {
        rc = flex_acl_hw_db_get_region_attributes(handle, &attribs_get);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed to get region attributes, handle: %u\n", handle);
            goto out;
        }
        memcpy(rollback_attribs, attribs_get, sizeof(*attribs_get));
    }

    rc = flex_acl_db_region_hw_handle_set(region_id, FLEX_ACL_INVALID_HANDLE);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set hw attributes handle %u to region %u\n", FLEX_ACL_INVALID_HANDLE, region_id);
        goto out;
    }

    rc = flex_acl_hw_db_remove_region_attributes(handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to remove region attributes, handle: %u\n", handle);
        goto error;
    }
    goto out;

error:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_db_region_hw_handle_set(region_id, handle))) {
        SX_LOG_ERR("Fatal error at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_acl_hw_reg_write_acls(flex_acl_db_acl_table_t *acl_table, boolean_t valid)
{
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX] = {0};
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint16_t    dev_info_arr_size = 0;

    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get device \n");
        goto out;
    }

    rc = flex_acl_hw_reg_write_acls_to_dev(acl_table, devs_list, dev_info_arr_size, valid);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("write acl table to register error\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_hw_write_acl_register(sx_acl_id_t        acl_id,
                                                  sx_acl_direction_t direction,
                                                  uint8_t           *region_info,
                                                  uint32_t           region_info_size,
                                                  sx_dev_id_t        dev_id,
                                                  boolean_t          valid)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_utils_status_t  utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    struct ku_pacl_reg pacl_reg_data = {.egress = 0};
    sxd_reg_meta_t     pacl_reg_meta = {.access_cmd = 0};

    UNUSED_PARAM(direction);
    SX_LOG_ENTER();

    if (region_info_size != sizeof(pacl_reg_data.tcam_region_info[dev_id])) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(pacl_reg_meta);
    SX_MEM_CLR(pacl_reg_data);

    if (!valid) {
        /* Fence needs to be performed before PACL delete flows. For now
         * we do a synchronous fence, in the future the delete should go through
         * the garbage collector and become asynchronous.
         */
        utils_err = gc_object_fence(GC_FENCE_TYPE_FAST);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            rc = sx_utils_status_to_sx_status(utils_err);
            SX_LOG_ERR("Failed to perform fast fence, utils_err = [%s]\n",
                       SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }
        SX_LOG_DBG("Performed fast fence before invalidating ACL %u\n",
                   acl_id);
    }

    pacl_reg_meta.dev_id = dev_id;
    pacl_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pacl_reg_data.acl_id = acl_id;
    pacl_reg_data.valid = valid;
    pacl_reg_data.acl_type = SXD_PACL_ACL_TYPE_ALL;

    memcpy(pacl_reg_data.tcam_region_info[0], region_info, sizeof(pacl_reg_data.tcam_region_info[dev_id]));

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PACL_E, &pacl_reg_data, &pacl_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to configure PACL to dev_idx [%u] acl_id [%u]\n", dev_id, acl_id);
        rc = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_hw_activity_dump(boolean_t            is_clear,
                                             sx_dev_id_t          dev_id,
                                             const void          *region_info,
                                             sx_acl_rule_offset_t offset,
                                             uint32_t             num_entries,
                                             bit_vector_t        *activities_p)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_status = SXD_STATUS_SUCCESS;
    sx_utils_status_t    utils_status = SX_UTILS_STATUS_SUCCESS;
    sxd_reg_meta_t       reg_meta;
    uint8_t              activities_index = 0;
    uint32_t             activities[SXD_PTCEAD_ACTIVITIES_VECTOR_SIZE];
    int                  index = 0;
    struct ku_ptcead_reg ptcead_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(ptcead_data);
    SX_MEM_CLR(activities);

    ptcead_data.operation = (is_clear) ? SXD_EMAD_PTCEAD_OPERATION_READ_CLEAR_E : SXD_EMAD_PTCEAD_OPERATION_READ_E;
    ptcead_data.offset = offset;
    ptcead_data.num_entries = num_entries;
    memcpy(&ptcead_data.tcam_region_info, region_info, sizeof(ptcead_data.tcam_region_info));

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_status = sxd_access_reg_ptcead(&ptcead_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        status = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("Failed to read activities from PTCEAD, err = [%s]\n",
                   sx_status_str(status));
        goto out;
    }

    /* change order of array elements to get valid offsets */
    for (index = (SXD_PTCEAD_ACTIVITIES_VECTOR_SIZE - 1); index >= 0; index--) {
        activities[activities_index] = ptcead_data.activities[index];
        activities_index++;
    }

    /* copy from array only needed size in words */
    utils_status = bit_vector_assign_array(activities_p, activities, ((num_entries - 1) / 32) + 1);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        status = sx_utils_status_to_sx_status(utils_status);
        SX_LOG_ERR("Failed to assign array of bits to bit_vector, err = [%s]\n",
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t flex_acl_hw_reg_write_acls_to_dev(flex_acl_db_acl_table_t *acl_table,
                                              sx_dev_id_t             *devs_list,
                                              uint16_t                 dev_info_arr_size,
                                              boolean_t                valid)
{
    uint32_t                         i = 0;
    uint32_t                         j = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t        *acl_region = NULL;
    flex_acl_hw_db_region_attribs_t *region_attribs = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(acl_table->bound_region, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region Id [%u]\n", acl_table->bound_region);
        goto out;
    }
    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &region_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("HW ACL: Failed to get region attributes, region id = %u\n", acl_region->region_id);
        goto out;
    }

    if (region_attribs->write_reg_cb.acl_register_cb != NULL) {
        for (i = 0; i < dev_info_arr_size; i++) {
            rc = region_attribs->write_reg_cb.acl_register_cb(acl_table->acl_id, acl_table->direction % 2,
                                                              region_attribs->region_info[devs_list[i]],
                                                              sizeof(region_attribs->region_info[devs_list[i]]),
                                                              devs_list[i],
                                                              valid);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to write acl to register, acl Id [%u]\n", acl_table->acl_id);
                goto error;
            }
        }
    } else {
        SX_LOG_ERR("ACL : Failed to write acl to register,cb function is NULL\n");
        rc = SX_STATUS_ERROR;
    }

    goto out;

error:
    for (j = 0; j < i; j++) {
        if (region_attribs->write_reg_cb.acl_register_cb != NULL) {
            rc = region_attribs->write_reg_cb.acl_register_cb(acl_table->acl_id, acl_table->direction,
                                                              region_attribs->region_info[devs_list[j]],
                                                              sizeof(region_attribs->region_info[devs_list[j]]),
                                                              devs_list[j],
                                                              !valid);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL HW :Failed to rollback for dev_idx %d\n", devs_list[j]);
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_region(flex_acl_db_acl_region_t * acl_region,
                                         sx_dev_id_t                dev_id,
                                         acl_region_op_e            op,
                                         uint8_t                  * tcam_region_info,
                                         uint32_t                   tcam_region_info_size,
                                         sx_acl_size_t              new_size,
                                         sx_acl_size_t            * allocated_size)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_acl_key_t                    *user_keys = NULL;
    uint8_t                          user_keys_count = 0;
    uint32_t                         hw_key_handle = 0;
    sx_acl_key_block_e              *key_blocks = NULL;
    uint32_t                         key_count = 0;
    flex_acl_hw_db_region_attribs_t *attribs;

    SX_LOG_ENTER();

    if (NULL == acl_region) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (ACL_REGION_HW_OP_ALLOCATE_E == op) {
        if (NULL == tcam_region_info) {
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }
    rc = flex_acl_db_get_flex_key_entry(acl_region->key_handle, &user_keys, &user_keys_count,
                                        &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get flex_key_entry error, key_handle: %u\n", acl_region->key_handle);
        goto out;
    }

    rc = flex_acl_hw_db_get_key_blocks(hw_key_handle, &key_blocks, &key_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get hw flex key blocks error, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region attributes error, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }
    if (attribs->write_reg_cb.region_hw_cb == NULL) {
        SX_LOG_ERR("ACL : NO CB to write region. Region :%u \n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = attribs->write_reg_cb.region_hw_cb(op,
                                            dev_id,
                                            acl_region->region_id,
                                            acl_region->key_handle,
                                            key_blocks,
                                            key_count,
                                            tcam_region_info,
                                            tcam_region_info_size,
                                            new_size,
                                            allocated_size,
                                            acl_region->stateful_db_region);
    if (SX_STATUS_SUCCESS != rc) {
        if (SX_STATUS_NO_RESOURCES == rc) {
            if (attribs->free_unused_memory) {
                rc = flex_acl_tcam_manager_free_unused_entries(FLEX_ACL_TCAM_MANAGER_INVALID_HANDLE);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("Failed to free unused entries, rc = [%s]\n",
                               sx_status_str(rc));
                    goto out;
                }

                rc = attribs->write_reg_cb.region_hw_cb(op,
                                                        dev_id,
                                                        acl_region->region_id,
                                                        acl_region->key_handle,
                                                        key_blocks,
                                                        key_count,
                                                        tcam_region_info,
                                                        tcam_region_info_size,
                                                        new_size,
                                                        allocated_size,
                                                        acl_region->stateful_db_region);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR_RESOURCE_COND(rc,
                                             "Write region register cb failed after freeing unused memory, region_id[%x] rc = %d\n",
                                             acl_region->region_id,
                                             rc);
                    goto out;
                }
            } else {
                SX_LOG_INF("Write region register cb failed, region_id[%x] rc = %d\n",
                           acl_region->region_id,
                           rc);
                goto out;
            }
        } else {
            SX_LOG_ERR("Write region register cb failed, region_id[%x] rc = %d\n",
                       acl_region->region_id,
                       rc);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_hw_reg_write_pvgt(flex_acl_hw_db_binding_data_t *binding_data_p)
{
    uint32_t           dev_idx = 0, i = 0;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t           dev_info_arr_size = 0;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pvgt_reg pvgt = {.swid = 0};
    sxd_reg_meta_t     meta = {.access_cmd = 0};
    sx_status_t        rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (binding_data_p->binding_type != FLEX_ACL_HW_BINDING_VLAN_E) {
        SX_LOG_ERR("Binding type %u unsupported for pvgt.\n", binding_data_p->binding_type);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pvgt);

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    /* Prepare a list of relevant devices */
    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get all devices list\n");
        goto out;
    }
    pvgt.vlan_group = 0;
    pvgt.swid = 0;
    pvgt.op = SXD_PVGT_OP_REMOVE_VLAN_E;
    if (binding_data_p->bind) {
        pvgt.op = SXD_PVGT_OP_ADD_VLAN_E;
        pvgt.vlan_group = binding_data_p->data.vlan.vlan_group_id;
    }

    /* Update new mappings for all devices */
    pvgt.vid = binding_data_p->data.vlan.vlan_id;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    meta.dev_id = devs_list[dev_idx];

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVGT_E, &pvgt, &meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set vlan group entry SXD err [%s]\n",
                   SXD_STATUS_MSG(sxd_status));
        /* rollback current vid for all devices */
        rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
        goto error;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    goto out;
error:
    for (i = 0; i < dev_idx; i++) {
        meta.dev_id = devs_list[i];
        pvgt.op = ~pvgt.op;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVGT_E, &pvgt, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Fatal error at rollback\n");
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_vlan_group_add(sx_api_acl_vlan_group_set_params_t *params)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_binding_data_t binding_data;
    boolean_t                     late_binding = FALSE;
    uint64_t                      key;
    uint32_t                      vid_idx = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(binding_data);
    binding_data.binding_type = FLEX_ACL_HW_BINDING_VLAN_E;
    if (params->cmd == SX_ACCESS_CMD_ADD) {
        binding_data.bind = TRUE;
    }
    binding_data.data.vlan.vlan_group_id = params->vlan_group_id;

    for (vid_idx = 0; vid_idx < params->vlan_num; vid_idx++) {
        binding_data.data.vlan.vlan_id = params->vlan_list[vid_idx];
        key = FLEX_ACL_LATE_BINDING_VLAN_KEY(vid_idx);
        rc = __flex_acl_hw_handle_late_binding(&late_binding, key, &binding_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to do late binding.\n");
            goto out;
        }
        if (late_binding == TRUE) {
            SX_LOG_DBG("Do late binding, not write to register now.\n");
            continue;
        }
        rc = __flex_acl_hw_reg_write_pvgt(&binding_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to write pvgt.\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Create/Destroy/Edit Region */
sx_status_t flex_acl_hw_region_update(flex_acl_db_acl_region_t * acl_region, acl_region_op_e op,
                                      sx_acl_size_t new_size)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    sx_acl_size_t                    allocated_size = 0;
    flex_acl_hw_db_region_attribs_t *attribs = NULL;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    uint32_t                         dev_idx = 0;

    SX_LOG_DBG(" region id %d\n", acl_region->region_id);
    SX_LOG_ENTER();

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("get region attributes error, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        goto out;
    }

    if (op == ACL_REGION_HW_OP_ALLOCATE_E) {
        /* update bound devices in db */
        rc = flex_acl_db_region_bind_set(acl_region->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to Update regions db with new bound device, region_id: %u\n",
                       acl_region->region_id);
            goto out;
        }
    } else if (op == ACL_REGION_HW_OP_DEALLOCATE_E) {
        rc = flex_acl_db_region_unbind_set(acl_region->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to Update regions db with new unbound device, region_id: %u.\n",
                       acl_region->region_id);
            goto out;
        }
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    /* Configure the FW and get the real resource block usage */
    rc = flex_acl_hw_reg_write_region(acl_region,
                                      devs_list[dev_idx],
                                      op,
                                      attribs->region_info[devs_list[dev_idx]],
                                      SXD_TCAM_REGION_INFO_SIZE_BYTES,
                                      new_size,
                                      &allocated_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL : the register update failed for region id [%d] ,dev_idx id [%d].\n",
                                 acl_region->region_id,
                                 dev_idx);
        goto error;
    }
    attribs->hw_size[devs_list[dev_idx]] = allocated_size;

    SX_FDB_FOR_EACH_LEAF_DEV_END;


    /* store the allocated size to db */
    goto out;

error:
    if (op == ACL_REGION_HW_OP_ALLOCATE_E) {
        if (SX_CHECK_FAIL(rb_rc = flex_acl_db_region_unbind_set(acl_region->region_id))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    } else if (op == ACL_REGION_HW_OP_DEALLOCATE_E) {
        if (SX_CHECK_FAIL(rb_rc = flex_acl_db_region_bind_set(acl_region->region_id))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* Use this function when updates bound group.
 * The function run over linked groups and accumulate ACLs within groups and put commit acl between logical
 * groups. The acl array in group(group_id) will be changed to ACL IDs that delivered in params.
 * The output of function is acl list that can be wrote to register
 */
sx_status_t flex_acl_hw_prepare_acl_list_from_groups_update(sx_acl_id_t           group_id,
                                                            sx_acl_id_t          *acl_ids,
                                                            uint32_t              acl_ids_num,
                                                            acl_id_group_entry_t *acl_ids_prepared,
                                                            uint32_t             *prepared_ids_num,
                                                            sx_acl_direction_t    direction)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *group = NULL;
    uint32_t                 temp_acl_num = 0;
    sx_acl_id_t             *temp_acl_ids = NULL;

    SX_LOG_ENTER();

    /* We change acl array within desired group id with ACL IDs received as param*/
    rc = flex_acl_db_get_acl_group(group_id, &group);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id);
        goto out;
    }

    temp_acl_num = group->acl_num;
    temp_acl_ids = group->acl_ids;

    group->acl_num = acl_ids_num;
    group->acl_ids = acl_ids;

    rc = flex_acl_hw_prepare_acl_list_from_groups(group_id, acl_ids_prepared, prepared_ids_num, direction);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to prepare ACL list from group id [0x%x]\n", group_id);
    }

    group->acl_num = temp_acl_num;
    group->acl_ids = temp_acl_ids;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_is_commit_acl(sx_acl_id_t acl_id, boolean_t *is_commit)
{
    uint32_t    i = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *is_commit = FALSE;

    if (flex_acl_stage != ACL_STAGE_FLEX) {
        goto out;
    }

    for (i = 0; i <= SX_ACL_DIRECTION_MAX_SPECTRUM; i++) {
        if ((acl_id == commit_acl[i]) && (acl_id != FLEX_ACL_INVALID_ACL_ID)) {
            *is_commit = TRUE;
            break;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_commit_acl_set(sx_acl_id_t acl_id, sx_acl_direction_t direction)
{
    if (direction > SX_ACL_DIRECTION_MAX) {
        SX_LOG_ERR("acl direction exceeds direction range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    commit_acl[direction] = acl_id;

    return SX_STATUS_SUCCESS;
}


sx_status_t flex_acl_hw_commit_acl_get(sx_acl_id_t *acl_id, sx_acl_direction_t direction)
{
    if (direction > SX_ACL_DIRECTION_MAX) {
        SX_LOG_ERR("acl direction exceeds direction range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    *acl_id = commit_acl[direction];

    return SX_STATUS_SUCCESS;
}


sx_status_t flex_acl_hw_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    flex_acl_hw_db_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_status_t flex_acl_hw_rule_move(sx_api_acl_block_move_params_t *params,
                                  uint32_t                        dev_idx,
                                  flex_acl_db_acl_region_t       *region,
                                  boolean_t                       change_priority)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *reg_attribs = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_region_attributes(region->hw_region_attribs_handle, &reg_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get region hw attributes[%u]\n", dev_idx);
        goto out;
    }
    if (reg_attribs->write_reg_cb.move_rule_hw_cb == NULL) {
        SX_LOG_ERR("ACL: No CB to move rule. Region:%u \n", region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = reg_attribs->write_reg_cb.move_rule_hw_cb(ACL_RULE_MOVE_HW_OP_MOVE_E,
                                                   dev_idx,
                                                   region->region_id,
                                                   region->region_id,
                                                   reg_attribs->region_info[dev_idx],
                                                   reg_attribs->region_info[dev_idx],
                                                   params->block_start,
                                                   params->new_block_start,
                                                   params->block_size,
                                                   change_priority);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to configure PRCR to dev_idx [%u]\n", dev_idx);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_set_range_to_devs(sx_acl_port_range_entry_t* port_range,
                                          sx_acl_port_range_id_t     id,
                                          sx_dev_id_t               *devs_list,
                                          uint16_t                   dev_info_arr_size)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     meta = {.access_cmd = 0};
    struct ku_pprr_reg pprr = {.ipv4 = 0};
    uint16_t           dev_idx = 0;

    SX_LOG_ENTER();

    if ((NULL == port_range) || (NULL == devs_list)) {
        SX_LOG_ERR("ACL :Null pointer \n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pprr);

    meta.access_cmd = SXD_ACCESS_CMD_SET;

    pprr.register_index = id;
    pprr.port_range_max = port_range->port_range_max;
    pprr.port_range_min = port_range->port_range_min;

    pprr.ipv4 = 1;
    pprr.ipv6 = 1;
    if (!port_range->port_range_ip_length) {
        pprr.tcp = 1;
        pprr.udp = 1;
        switch (port_range->port_range_direction) {
        case SX_ACL_PORT_DIRECTION_SOURCE:
            pprr.src = 1;
            break;

        case SX_ACL_PORT_DIRECTION_DESTINATION:
            pprr.dst = 1;
            break;

        case SX_ACL_PORT_DIRECTION_BOTH:
            pprr.src = 1;
            pprr.dst = 1;
            break;

        default:
            SX_LOG_ERR("Invalid direction :%d \n", port_range->port_range_direction);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    switch (port_range->port_range_ip_header) {
    case SX_ACL_PORT_RANGE_IP_HEADER_OUTER:
        pprr.outer_inner = 0;
        break;

    case SX_ACL_PORT_RANGE_IP_HEADER_INNER:
        pprr.outer_inner = 1;
        break;

    case SX_ACL_PORT_RANGE_IP_HEADER_BOTH:
        pprr.outer_inner = 2;
        break;

    default:
        SX_LOG_ERR("Invalid ip header (inner/outer) :%d \n", port_range->port_range_ip_header);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    pprr.ip_length = port_range->port_range_ip_length;

    /* Update new mappings for all devices */
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PPRR_E, &pprr, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to set port range [%u] on device [%u] SXD rc [%u] \n", id, meta.dev_id,
                       sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_set_range(sx_acl_range_entry_t  *range_entry_p,
                                  sx_acl_port_range_id_t id,
                                  sx_dev_id_t           *devs_list,
                                  uint16_t               dev_info_arr_size)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sxd_status_t              sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t            meta;
    struct ku_pprr_reg        pprr;
    uint16_t                  dev_idx = 0;
    acl_custom_bytes_set_id_e cbset_id = ACL_CUSTOM_BYTES_SET_0;

    SX_LOG_ENTER();

    if ((NULL == range_entry_p) || (NULL == devs_list)) {
        SX_LOG_ERR("ACL :Null pointer \n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pprr);

    meta.access_cmd = SXD_ACCESS_CMD_SET;

    switch (range_entry_p->ip_version) {
    case SX_IP_VERSION_NONE:
        pprr.ignore_l3 = 1;
        break;

    case SX_IP_VERSION_IPV4:
        pprr.ipv4 = 1;
        break;

    case SX_IP_VERSION_IPV6:
        pprr.ipv6 = 1;
        break;

    case SX_IP_VERSION_IPV4_IPV6:
        pprr.ipv4 = 1;
        pprr.ipv6 = 1;
        break;

    default:
        SX_LOG_ERR("Invalid IP version : [%d]\n", range_entry_p->ip_version);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* src, dst flags are only used if range type is L4 Port */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_L4_PORT_E) {
        switch (range_entry_p->direction) {
        case SX_ACL_PORT_DIRECTION_SOURCE:
            pprr.src = 1;
            break;

        case SX_ACL_PORT_DIRECTION_DESTINATION:
            pprr.dst = 1;
            break;

        case SX_ACL_PORT_DIRECTION_BOTH:
            pprr.src = 1;
            pprr.dst = 1;
            break;

        default:
            SX_LOG_ERR("Invalid port direction : [%d]\n", range_entry_p->direction);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    switch (range_entry_p->l4_protocol) {
    case SX_ACL_L4_TYPE_INVALID:
        pprr.ignore_l4 = 1;
        break;

    case SX_ACL_L4_TYPE_TCP:
        pprr.tcp = 1;
        break;

    case SX_ACL_L4_TYPE_UDP:
        pprr.udp = 1;
        break;

    case SX_ACL_L4_TYPE_TCP_UDP:
        pprr.tcp = 1;
        pprr.udp = 1;
        break;

    default:
        SX_LOG_ERR("Invalid L4 protocol : [%d]\n", range_entry_p->l4_protocol);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    pprr.outer_inner = (sxd_pprr_outer_inner_t)range_entry_p->outer_inner;
    pprr.ip_length = range_map[range_entry_p->range_type];
    pprr.comp_type = (sxd_pprr_comp_type_t)range_entry_p->match_type;
    pprr.register_index = id;
    pprr.port_range_min = range_entry_p->range_limits.min;
    pprr.port_range_max = range_entry_p->range_limits.max;

    /* Convert Custom Byte key to appropriate Custom Byte set ID */
    if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E) {
        rc = flex_acl_key_id_to_custom_byte_set(
            range_entry_p->range_attr.custom_bytes_range_attr.custom_bytes_set_key_id,
            &cbset_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to convert ACL key to Custom Byte set ID, rc [%u] \n", rc);
            goto out;
        }

        pprr.cbset = cbset_id;
    } else if (range_entry_p->range_type == SX_ACL_RANGE_TYPE_REGISTER_E) {
        pprr.cbset = range_entry_p->range_attr.register_range_attr.reg_key.key.gp_reg.reg_id;
    }

    /* Update new mappings for all devices */
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PPRR_E, &pprr, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to set port range [%u] on device [%u] SXD rc [%u]\n",
                       id, meta.dev_id, sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_policy_engine_general_conf_device(sx_dev_id_t dev_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    kvd_linear_manager_block_length_t kvd_size = 0;
    kvd_linear_manager_block_length_t return_size = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;
    kvd_linear_manager_index_t        kvd_index[DEFAULT_ACTIONS_MAX_BLOCK_SIZE];
    struct ku_pgcr_reg                pgcr_reg_data;
    sxd_reg_meta_t                    pgcr_reg_meta;

    SX_LOG_ENTER();

    /* Check that the handle does not already exist */
    if (default_action_kvd_handle == FLEX_ACL_INVALID_KVD_HANDLE) {
        SX_LOG_ERR("KVD handle Invalid\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(pgcr_reg_meta);
    SX_MEM_CLR(pgcr_reg_data);

    rc = kvd_linear_manager_handle_lock(default_action_kvd_handle, kvd_index, &return_size);
    if ((SX_STATUS_SUCCESS != rc) || (return_size < kvd_size)) {
        SX_LOG_ERR("ACL action : Failed locking kvd block for default action.\n");
        goto out;
    }

    pgcr_reg_meta.dev_id = dev_id;
    pgcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pgcr_reg_data.default_action_pointer_base = kvd_index[0];
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PGCR_E, &pgcr_reg_data, &pgcr_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure default action base to HW rc [%u] \n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto kvd_error_release;
    }

    rc = kvd_linear_manager_handle_release(default_action_kvd_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed release kvd block for default action.\n");
        goto out;
    }
    goto out;

kvd_error_release:
    kvd_linear_manager_handle_release(default_action_kvd_handle);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_set_register_cb(sx_acl_region_id_t region_id, flex_acl_hw_reg_cb_t *hw_cbs)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *attribs_p;
    uint32_t                         handle = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_hw_handle_get(region_id, &handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes, region_id: %u\n", region_id);
        goto out;
    }

    /* get regions hw attributes */
    rc = flex_acl_hw_db_get_region_attributes(handle, &attribs_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes, handle: %u\n", handle);
        goto out;
    }

    /* We do not support the following callback as per region basis.
     * NOTE: The action callback should be valid even before region exists (for ISSU reasons).
     */
    if (hw_cbs->action_hw_cb) {
        SX_LOG_ERR("ACL: Changing the default hw callback for action write is not supported\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    if (hw_cbs->prio_change_hw_cb) {
        SX_LOG_ERR("ACL: Changing the default hw callback for priority change is not supported\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    /* update db  with allocated handle */
    if (hw_cbs->move_rule_hw_cb) {
        attribs_p->write_reg_cb.move_rule_hw_cb = hw_cbs->move_rule_hw_cb;
    }
    if (hw_cbs->region_hw_cb) {
        attribs_p->write_reg_cb.region_hw_cb = hw_cbs->region_hw_cb;
    }
    if (hw_cbs->rule_hw_cb) {
        attribs_p->write_reg_cb.rule_hw_cb = hw_cbs->rule_hw_cb;
    }
    if (hw_cbs->acl_register_cb) {
        attribs_p->write_reg_cb.acl_register_cb = hw_cbs->acl_register_cb;
    }
    if (hw_cbs->activity_register_cb) {
        attribs_p->write_reg_cb.activity_register_cb = hw_cbs->activity_register_cb;
    }
    if (hw_cbs->activity_dump_hw_cb) {
        attribs_p->write_reg_cb.activity_dump_hw_cb = hw_cbs->activity_dump_hw_cb;
    }

    /* For now, it is the responsibility of the system ACL client to free unused
     * memory.
     */
    attribs_p->free_unused_memory = FALSE;
    attribs_p->bulk_write = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_read_activity(flex_acl_db_acl_region_t *acl_region,
                                      sx_acl_rule_offset_t      offset,
                                      boolean_t                 is_clear,
                                      boolean_t                *value)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *hw_region_attribs = NULL;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    uint32_t                         dev_idx = 0;
    boolean_t                        activity = 0;

    SX_LOG_ENTER();
    *value = 0;

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get all devices \n");
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &hw_region_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        rc = SX_STATUS_INVALID_HANDLE;
    }
    if (hw_region_attribs->write_reg_cb.activity_register_cb == NULL) {
        SX_LOG_ERR("ACL: No CB for write rule. region :%u \n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    rc = hw_region_attribs->write_reg_cb.activity_register_cb(
        is_clear ? ACL_RULE_HW_OP_CLEAR_ON_READ_E : ACL_RULE_HW_OP_READ_E,
        devs_list[dev_idx],
        acl_region->region_id,
        hw_region_attribs->region_info[devs_list[dev_idx]],
        offset,
        FLEX_ACL_RULE_VALID,
        0,
        NULL,
        0,
        NULL,
        0,
        NULL,
        &activity,
        hw_region_attribs->bulk_write);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to read activity from dev_idx [%u]\n", dev_idx);
        goto out;
    }

    *value += activity;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_set_default_register_cbs(acl_stage_e acl_stage, boolean_t is_ut)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    static flex_acl_hw_reg_cb_t flex2_ut_register_cbs = {.rule_hw_cb = flex_acl_hw_write_rule_register,
                                                         .region_hw_cb = flex_acl_hw_write_region_register,
                                                         .move_rule_hw_cb = flex_acl_hw_move_rule_register,
                                                         .acl_register_cb = flex_acl_hw_write_acl_register,
                                                         .activity_register_cb = flex2_acl_hw_activity_read_register,
                                                         .activity_dump_hw_cb = flex_acl_hw_activity_dump,
                                                         .action_hw_cb = flex_acl_hw_write_action_register,
                                                         .prio_change_hw_cb = flex2_acl_hw_prio_change_register,
                                                         .config_uc_tunnel_pbs_write_cb =
                                                             flex2_acl_hw_config_uc_tunnel_pbs_write,
                                                         .activity_bulk_dump_hw_cb =
                                                             flex2_acl_hw_activity_bulk_dump_register,
                                                         .global_mask_hw_cb = NULL,
                                                         .lookup_region_hw_cb = NULL};

    SX_LOG_ENTER();

    /* Set the correct default register callbacks according to the flex version */
    switch (acl_stage) {
    case ACL_STAGE_FLEX:
        default_register_cbs_p = &flex1_default_register_cbs;
        break;

    case ACL_STAGE_FLEX2:
    case ACL_STAGE_FLEX3:
    case ACL_STAGE_FLEX4:
        default_register_cbs_p = &flex2_default_register_cbs;
        break;

    default:
        SX_LOG_ERR("Unsupported flex stage [%u] for hw init.\n", acl_stage);
        rc = SX_STATUS_PARAM_ERROR;
        break;
    }

    flex_acl_stage = acl_stage;

    if (is_ut) {
        default_register_cbs_p = &flex2_ut_register_cbs;
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_dump_activity(flex_acl_db_acl_region_t *acl_region,
                                      sx_access_cmd_t           cmd,
                                      sx_acl_rule_offset_t      offset,
                                      uint32_t                  num_entries,
                                      bit_vector_t             *activities_p)
{
    sx_status_t                      status = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *hw_region_attribs = NULL;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    uint32_t                         dev_idx = 0;

    SX_LOG_ENTER();

    status = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("ACL : Failed to get all devices \n");
        goto out;
    }

    status = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &hw_region_attribs);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u\n",
                   acl_region->hw_region_attribs_handle);
        status = SX_STATUS_INVALID_HANDLE;
    }
    if (hw_region_attribs->write_reg_cb.activity_dump_hw_cb == NULL) {
        SX_LOG_ERR("ACL: No CB for activity dump rule, region :%u \n", acl_region->region_id);
        status = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    status = hw_region_attribs->write_reg_cb.activity_dump_hw_cb(SX_ACCESS_CMD_READ_CLEAR == cmd,
                                                                 devs_list[dev_idx],
                                                                 hw_region_attribs->region_info[devs_list[dev_idx]],
                                                                 offset,
                                                                 num_entries,
                                                                 activities_p);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("ACL : Failed to dump activities from dev_idx [%u]\n", dev_idx);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t flex_acl_hw_init(flex_acl_attributes_t *attribs_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Set the correct default register callbacks*/
    rc = flex_acl_hw_set_default_register_cbs(attribs_p->acl_stage, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set default register callback for flex acl hw stage [%u].\n",
                   attribs_p->acl_stage);
        goto out;
    }

    rc = flex_acl_hw_db_init(attribs_p->num_of_acl_regions);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init acl hw db. Num regions:%d. Error: %s \n",
                   attribs_p->num_of_acl_regions, sx_status_str(rc));
        goto out;
    }

    tcam_opt_params_g = attribs_p->tcam_opt_params;
    flex_acl_hw_set_rebind_group_pfunc(attribs_p->rebind_group_cb);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_deinit(void)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_deinit();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed deinit hw db resources, error:  %s \n", sx_status_str(rc));
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_handle_custom_bytes_register(acl_custom_bytes_set_id_e    custom_byte_set_id,
                                                     flex_acl_extraction_point_t *extraction_points_p,
                                                     uint32_t                     extraction_points_count,
                                                     boolean_t                    is_enable)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_rc = SXD_STATUS_SUCCESS;
    struct ku_pecb_reg pecb;
    sxd_reg_meta_t     meta = {.access_cmd = 0};
    uint32_t           i;
    uint8_t            extraction_point_ind;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    if (custom_byte_set_id >= rm_resource_global.acl_custom_bytes_set_max) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid custom bytes set id:%u\n", custom_byte_set_id);
        goto out;
    }

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list, error: %s.\n", sx_status_str(rc));
        goto out;
    }

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pecb);

    pecb.cbset = custom_bytes_set_hw_data[custom_byte_set_id].custom_bytes_set_code;
    if (is_enable) {
        for (i = 0; i < extraction_points_count; i++) {
            if (extraction_points_p[i].extraction_point >= ACL_EXTRACTION_POINT_TYPE_LAST) {
                rc = SX_STATUS_ERROR;
                SX_LOG_ERR("Invalid extraction point id:%u\n", extraction_points_p[i].extraction_point);
                goto out;
            }
            extraction_point_ind =
                extraction_points_hw_data[extraction_points_p[i].extraction_point].extraction_point_type_code;
            pecb.extraction_points[extraction_point_ind].enable = 1;
            pecb.extraction_points[extraction_point_ind].offset = extraction_points_p[i].offset;
        }
    }
    meta.access_cmd = SXD_ACCESS_CMD_SET;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PECB_E, &pecb, &meta, 1, NULL, NULL);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("ACL custom bytes failed configure hw : sxd_access_reg_pecb failed rc :%d \n", sxd_rc);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_mc_bind(sx_access_cmd_t            cmd,
                                          sx_ip_version_t            ip_version,
                                          flex_acl_bind_attribs_id_t bind_attribs_id)
{
    sx_status_t                       sx_status = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pemrbt_reg              pemrbt_reg_data;
    sxd_reg_meta_t                    reg_meta;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    sx_boot_mode_e                    boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    sx_status = issu_boot_mode_get(&boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ISSU boot mode %s\n", sx_status_str(sx_status));
        goto out;
    }

    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }

    SX_MEM_CLR(pemrbt_reg_data);
    SX_MEM_CLR(reg_meta);

    switch (ip_version) {
    case SX_IP_VERSION_IPV4:
        pemrbt_reg_data.protocol = 0;
        break;

    case SX_IP_VERSION_IPV6:
        pemrbt_reg_data.protocol = 1;
        break;

    default:
        SX_LOG_ERR("Invalid IP version : [%d]\n", ip_version);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Currently there is no need for unbind */
    if ((bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) || (cmd == SX_ACCESS_CMD_UNBIND)) {
        goto out;
    }

    sx_status = flex_acl_db_attribs_get(bind_attribs_id, &bind_attribs);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", bind_attribs_id);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        pemrbt_reg_data.op = 0;     /*SXD_PEMRBT_OP_BIND_E;*/
        break;

    case SX_ACCESS_CMD_ADD:
        pemrbt_reg_data.op = 2;     /* SXD_PEMRBT_OP_ADD_E;*/
        break;

    default:
        SX_LOG_ERR("ACL : CMD is not supported %s\n", sx_access_cmd_str(cmd));
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    pemrbt_reg_data.group_id = bind_attribs->bind_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = DEFAULT_DEV_ID;
    reg_meta.swid = 0;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEMRBT_E, &pemrbt_reg_data, &reg_meta, 1, NULL, NULL);
    sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set PEMRBT (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t flex_acl_get_hw_opt(sx_acl_region_id_t region_id, uint32_t *num_of_copies)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* Get by region id for per-region optimization*/
    UNUSED_PARAM(region_id);

    switch (tcam_opt_params_g.tcam_opt_mode) {
    case SX_TCAM_OPT_MODE_DISABLED:
    case SX_TCAM_OPT_MODE_DYNAMIC:
        *num_of_copies = 1;
        break;

    case SX_TCAM_OPT_MODE_STATIC:
        switch (tcam_opt_params_g.tcam_opt_mode_param) {
        case SX_TCAM_OPT_MODE_PARAM_FWS_64B:
            *num_of_copies = 16;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_128B:
            *num_of_copies = 8;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_256B:
            *num_of_copies = 4;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_512B:
            *num_of_copies = 2;
            break;

        case SX_TCAM_OPT_MODE_PARAM_FWS_1024B:
            *num_of_copies = 1;
            break;

        default:
            SX_LOG_ERR("Unsupported TCAM opt mode param value (%d) for TCAM opt mode: (%s[%d]) \n",
                       tcam_opt_params_g.tcam_opt_mode_param,
                       sx_tcam_opt_mode_str(tcam_opt_params_g.tcam_opt_mode),
                       tcam_opt_params_g.tcam_opt_mode);
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        break;
    }
out:
    return rc;
}

sx_status_t flex_acl_hw_bulk_dump_activity(sx_acl_region_id_t          region_id,
                                           boolean_t                   clear,
                                           boolean_t                   force_end,
                                           kvd_linear_manager_index_t *index_arr,
                                           uint32_t                   *index_num_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_dev_id_t             dev_id = 1;
    sxd_pefaad_index_dump_t record[SX_ACL_ACTIVITY_NOTIFY_CNT_MAX];
    uint32_t                i = 0;

    SX_MEM_CLR_ARRAY(record, SX_ACL_ACTIVITY_NOTIFY_CNT_MAX, sxd_pefaad_index_dump_t);

    if ((index_num_p) && (!FLEX_ACL_HW_BULK_DUMP_ACTIVITY_CHECK_RANGE(*index_num_p))) {
        SX_LOG_ERR("Request index number %d is invalid.\n", *index_num_p);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (default_register_cbs_p->activity_bulk_dump_hw_cb == NULL) {
        SX_LOG_ERR("A callback that bulk dump ACL activity is not initialized. \n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = default_register_cbs_p->activity_bulk_dump_hw_cb(dev_id, region_id, clear, force_end, record, index_num_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("A callback that configures UC tunnel ECMP PBS records returned an error: %s\n",
                   sx_status_str(rc));
        goto out;
    }

    if ((index_arr) && (index_num_p)) {
        for (i = 0; i < *index_num_p; i++) {
            index_arr[i] = record[i].index_dump;
        }
    }

out:
    return rc;
}


sx_status_t flex_acl_hw_key_generate(flex_acl_db_acl_region_t *acl_region_p,
                                     sx_flex_acl_key_desc_t   *keys_p,
                                     uint32_t                  keys_cnt,
                                     flex_acl_key_build_mode_e build_mode,
                                     uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                     uint8_t                   flex_mask_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES])
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sx_acl_key_block_e *key_blocks_p = NULL;
    uint32_t            blocks_count = 0;
    uint32_t            hw_key_handle = 0;

    SX_LOG_ENTER();

    /* get key blocks from db */
    rc = flex_acl_db_get_flex_key_entry(acl_region_p->key_handle, NULL, NULL, &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_db_get_flex_key_entry, key_handle: %u\n", acl_region_p->key_handle);
        goto out;
    }
    rc = flex_acl_hw_db_get_key_blocks(hw_key_handle, &key_blocks_p, &blocks_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_hw_db_get_key_blocks, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }

    /* Create the key as requested */
    rc = flex_acl_key_layout_constructor(flex_acl_stage,
                                         keys_p,
                                         keys_cnt,
                                         key_blocks_p,
                                         blocks_count,
                                         flex_value_blocks,
                                         flex_mask_blocks,
                                         build_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL HW key generate : Failed flex_acl_key_layout_constructor for region [%u].\n",
                   acl_region_p->region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_key_extract(flex_acl_db_acl_region_t *acl_region_p,
                                    uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                    sx_flex_acl_key_desc_t   *keys_p,
                                    uint32_t                 *keys_cnt_p)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sx_acl_key_block_e *key_blocks_p = NULL;
    uint32_t            blocks_count = 0;
    uint32_t            hw_key_handle = 0;
    sx_acl_key_t       *user_keys_p = NULL;
    uint8_t             user_key_count = 0;
    uint32_t            i = 0;


    SX_LOG_ENTER();

    /* get user keys and key blocks from db */
    rc = flex_acl_db_get_flex_key_entry(acl_region_p->key_handle, &user_keys_p, &user_key_count, &hw_key_handle);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL key extract : Failed flex_acl_db_get_flex_key_entry, key_handle: %u\n",
                   acl_region_p->key_handle);
        goto out;
    }
    /* Check that we have enough room for the keys */
    if (((uint32_t)user_key_count) > (*keys_cnt_p)) {
        SX_LOG_ERR("ACL key extract : key amount provided [%u] is not sufficient, [%u] needed \n",
                   *keys_cnt_p,
                   (uint32_t)user_key_count);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_hw_db_get_key_blocks(hw_key_handle, &key_blocks_p, &blocks_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed flex_acl_hw_db_get_key_blocks, hw_key_handle: %u\n", hw_key_handle);
        goto out;
    }
    /* Copy the region's user keys to the output format */
    for (i = 0; i < user_key_count; i++) {
        keys_p[i].key_id = user_keys_p[i];
    }
    *keys_cnt_p = user_key_count;

    /* Create the key as requested */
    rc = flex_acl_keys_extractor(flex_acl_stage,
                                 keys_p,
                                 *keys_cnt_p,
                                 key_blocks_p,
                                 blocks_count,
                                 flex_value_blocks);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL HW key extract : Failed flex_acl_keys_extractor for region [%u].\n",
                   acl_region_p->region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_global_mask_set(flex_acl_db_acl_region_t *acl_region_p,
                                        uint8_t                   global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES])
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *hw_region_attribs_p = NULL;
    sx_dev_id_t                      dev_id = 1;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_region_attributes(acl_region_p->hw_region_attribs_handle, &hw_region_attribs_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u, err = %s\n",
                   acl_region_p->hw_region_attribs_handle, sx_status_str(rc));
        goto out;
    }

    if (hw_region_attribs_p->write_reg_cb.global_mask_hw_cb != NULL) {
        rc = hw_region_attribs_p->write_reg_cb.global_mask_hw_cb(dev_id,
                                                                 acl_region_p->region_id,
                                                                 global_mask);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to write global mask for region [%u]\n", acl_region_p->region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_lookup_region_id_set(flex_acl_db_acl_region_t *acl_region_p,
                                             const sx_acl_region_id_t  lookup_region_id)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *hw_region_attribs_p = NULL;
    sx_dev_id_t                      dev_id = 1;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_region_attributes(acl_region_p->hw_region_attribs_handle, &hw_region_attribs_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL Failed getting region hw attributes, hw_region_attribs_handle: %u, err = %s\n",
                   acl_region_p->hw_region_attribs_handle, sx_status_str(rc));
        goto out;
    }

    if (hw_region_attribs_p->write_reg_cb.lookup_region_hw_cb != NULL) {
        rc = hw_region_attribs_p->write_reg_cb.lookup_region_hw_cb(dev_id,
                                                                   acl_region_p->region_id,
                                                                   lookup_region_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to write lookup region [0x%x] - [0x%x]  \n",
                       acl_region_p->region_id,
                       lookup_region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/*
 * This ISSU function should be called only once when upgrading an SDK
 * using the old PAGT ACL groups to the newer PAGT_V2 method. The new
 * method assumes the ACL group elements (1790) were split to even/odd according
 * to the ISSU bank and therefore we can use all the other half of entries.
 * Unfortunately, the old method using PAGT did not adhere to the odd/even rule
 * and entries in the 400-1789 range were randomly placed in the odd & even entries.
 * This function fixes the problem by moving entries not in the correct bank to empty
 * entries in the correct bank. It is assumed that only half of the group entries are
 * in use so we should always have place for this move.
 * NOTE: It's critical to run this function before actually using ACL group entries
 * in the new life.
 * We align the entries of the previous run of the SDK, so if the current run uses
 * bank 0 we move all the entries from previous life to use only bank 1 entries.
 * This way the new life can use all the entries in bank 0 expecting all of them to be free.
 * In addition, due to bug 3899404 we must clear the current bank from previous groups
 * (written by PAGT) that might be left in the bank we intend to write to. The clearing
 * must be done before the alignment so we'll make sure we have enough entries for the alignment.
 *
 */
sx_status_t flex_acl_hw_issu_bind_attributes_align(sx_issu_bank_e align_issu_bank, sx_issu_bank_e clear_issu_bank)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pagt_v2_reg pagt_v2_reg_data[rm_resource_global.acl_groups_size_max];
    sxd_reg_meta_t        pagt_v2_reg_meta;
    struct ku_pagtq_reg   pagtq_reg_data;
    sxd_reg_meta_t        pagtq_reg_meta;
    sxd_reg_meta_t        iicr_reg_meta;
    struct ku_iicr_reg    iicr_reg_data;
    uint32_t              is_bit_set = 0;
    uint32_t              start = align_issu_bank;
    uint32_t              step = 2;
    uint32_t              group_head_idx = 0;
    uint32_t              free_idx = align_issu_bank;
    uint32_t              i = 0;
    uint32_t              group_size = 0;
    boolean_t             update_needed = FALSE;
    uint32_t              dev_idx = 0;
    sx_dev_id_t           devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t              dev_info_arr_size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(pagt_v2_reg_data);
    SX_MEM_CLR(pagt_v2_reg_meta);
    SX_MEM_CLR(pagtq_reg_data);
    SX_MEM_CLR(pagtq_reg_meta);
    SX_MEM_CLR(iicr_reg_meta);
    SX_MEM_CLR(iicr_reg_data);

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get devices list \n");
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    /* We clear this bank from leftovers that might be left during the previous
     * use of this bank. The FW will clear the linked lists for us.
     */
    iicr_reg_meta.dev_id = devs_list[dev_idx];
    iicr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    iicr_reg_data.clear_acl_group_ids_mask = 0x0001;
    iicr_reg_data.clear_acl_group_ids_value = clear_issu_bank;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IICR_E,
                                                     &iicr_reg_data,
                                                     &iicr_reg_meta,
                                                     1,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to execute IICR to clean ACL group ISSU bank [%u]\n", clear_issu_bank);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    pagt_v2_reg_meta.dev_id = devs_list[dev_idx];
    pagt_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pagtq_reg_meta.dev_id = devs_list[dev_idx];
    pagtq_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    /* Get the current location of the ACL group elements that are used */
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGTQ_E,
                                                     &pagtq_reg_data,
                                                     &pagtq_reg_meta,
                                                     1,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to read ACL groups status\n");
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    /* Go over all the groups one by one and store the elements in each group locally.
     * We'll later examine each entry if it's in the correct bank and move it if it's not.
     */
    for (group_head_idx = start; group_head_idx < FLEX_ACL_LEGACY_BIND_ATTRIB_COUNT; group_head_idx += step) {
        is_bit_set = SXD_BITMAP_REVERSE_GET(pagtq_reg_data.acl_group_element_busy_bitmap,
                                            SXD_PAGTQ_ACL_GROUP_ELEMENT_BUSY_BITMAP_NUM,
                                            32,
                                            group_head_idx);
        /* Check if this group head / bind attribute is used */
        if (is_bit_set == 0) {
            continue;
        }

        SX_MEM_CLR(pagt_v2_reg_data);
        /* Read the entire list for this group */
        pagt_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        pagt_v2_reg_data[0].acl_group_element = group_head_idx;
        group_size = 0;

        for (i = 0; i < rm_resource_global.acl_groups_size_max; i++) {
            /* Read the group entries and store it for later */
            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_V2_E,
                                                             &pagt_v2_reg_data[i],
                                                             &pagt_v2_reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to read ACL PAGT element [%u] for ISSU bank alignment\n",
                           pagt_v2_reg_data[i].acl_group_element);
                rc = sxd_status_to_sx_status(sxd_status);
                goto out;
            }
            /* Just making sure that the entry is valid before we try to do something with it */
            if (pagt_v2_reg_data[i].id_v == 0) {
                SX_LOG_ERR("ACL: ISSU group [%u] element [%u] is not valid when aligning\n",
                           group_head_idx,
                           pagt_v2_reg_data[i].acl_group_element);
                group_size = 0;
                break;
            }
            group_size++;
            /* Check if we've reached the end of the lined list (no next) */
            if (pagt_v2_reg_data[i].n_v == 0) {
                break;
            }
            /* The last element in the list should always end with no next.
             * If that's not the case, we have some inconsistency in the FW.
             */
            if (i == rm_resource_global.acl_groups_size_max - 1) {
                SX_LOG_ERR("ACL: ISSU group [%u] doesn't not end with null pointer when aligning\n", group_head_idx);
                group_size = 0;
                break;
            }
            /* Get the next element to read from the linked list */
            pagt_v2_reg_data[i + 1].acl_group_element = pagt_v2_reg_data[i].next_acl_group_element;
        }
        /* If the group size consists only of the header we don't need to move it */
        if (group_size <= 1) {
            continue;
        }

        /* We now start moving elements in the groups that are not in the correct place */
        pagt_v2_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        i = group_size;
        do {
            i--;
            update_needed = FALSE;
            /* IF the next element in the list has changed its index we need to update our next pointer */
            if ((pagt_v2_reg_data[i].n_v == 1) &&
                (pagt_v2_reg_data[i].next_acl_group_element != pagt_v2_reg_data[i + 1].acl_group_element)) {
                pagt_v2_reg_data[i].next_acl_group_element = pagt_v2_reg_data[i + 1].acl_group_element;
                update_needed = TRUE;
            }
            /* If the element is not in the correct bank we need to write it in a free element using the correct bank */
            if ((pagt_v2_reg_data[i].acl_group_element & 1) != align_issu_bank) {
                /* Try to find a free index to move this entry to */
                while (free_idx < rm_resource_global.acl_acls_in_groups_max) {
                    is_bit_set = SXD_BITMAP_REVERSE_GET(pagtq_reg_data.acl_group_element_busy_bitmap,
                                                        SXD_PAGTQ_ACL_GROUP_ELEMENT_BUSY_BITMAP_NUM,
                                                        32,
                                                        free_idx);
                    /* If the element is free we store can use it as the new home for the old element */
                    if (is_bit_set == 0) {
                        pagt_v2_reg_data[i].acl_group_element = free_idx;
                        /* Make sure to start the search from the next element */
                        free_idx += step;
                        break;
                    }
                    /* Increase the next free index to start searching for */
                    free_idx += step;
                }
                if (free_idx >= rm_resource_global.acl_acls_in_groups_max) {
                    SX_LOG_ERR("ACL: No more free group elements for ISSU bank alignment\n");
                    rc = SX_STATUS_NO_RESOURCES;
                    goto out;
                }
                update_needed = TRUE;
            }
            if (update_needed == TRUE) {
                sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_V2_E,
                                                                 &pagt_v2_reg_data[i],
                                                                 &pagt_v2_reg_meta,
                                                                 1,
                                                                 NULL,
                                                                 NULL);
                if (sxd_status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL: Failed to read ACL PAGT element [%u] for ISSU bank alignment\n",
                               pagt_v2_reg_data[i].acl_group_element);
                    rc = sxd_status_to_sx_status(sxd_status);
                    goto out;
                }
            }
        } while (i > 0);
    }  /* End of the iteration over all the groups */

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}
