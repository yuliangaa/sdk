/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef FLEX_ACL_DB_H_
#define FLEX_ACL_DB_H_

/*
 *                  - Mellanox Confidential and Proprietary -
 *
 *  Copyright (C) January 2010 , Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein , no portion of the information ,
 *  including but not limited to object code and source code , may be reproduced ,
 *  modified , distributed , republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "LICENSE.txt".
 */

#include <sx_api/sx_api_internal.h>
#include <sx/sxd/sxd_emad_acl.h>


#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_map.h>
#include "sx/sdk/sx_acl.h"
#include "sx/sdk/sx_flex_acl.h"
#include <kvd/kvd_linear_manager.h>
#include "acl/flex_acl.h"
#include "resource_manager/spectrum.h"
#include "resource_manager/spectrum2.h"
#include "sx/utils/sdk_refcount.h"
#include "flex_acl_pool_map.h"
#include "ethl3/hwi/ecmp/router_ecmp.h"
#include <sx/utils/id_allocator.h>


#ifdef FLEX_ACL_DB_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define FLEX_ACL_INVALID_REGION_ID       0x2FFFF
#define FLEX_ACL_INVALID_ACL_ID          0xFFFFFFFF
#define FLEX_ACL_RULE_INVALID            0
#define FLEX_ACL_RULE_VALID              1
#define FLEX_ACL_DB_DEV_BOUND            1
#define FLEX_ACL_DB_DEV_UNBOUND          0
#define FLEX_ACL_INVALID_BIND_ATTRIBS_ID 0xFFFF
#define FLEX_ACL_INVALID_HANDLE          0xFFFFFFFF

#define FLEX_ACL_LOGIC_GROUP_BIT_MASK  0x10000
#define FLEX_ACL_REGION_BIT_MASK       0x20000
#define MACSEC_ACL_REGION_BIT_MASK     0x40000          /* macsec acl region bitmask to distinguish between flex and macsec flows */
#define MACSEC_ACL_KEY_HANDLE_BIT_MASK 0x40000000       /* macsec acl key handle bitmask to distinguish between flex and macsec flows */
#define MACSEC_ACL_BIT_MASK            0x4000000        /* macsec acl table bitmask to distinguish between flex and macsec flows */

/* Flex ACL bitmask macros */
#define FLEX_ACL_REGION_BIT_CHECK(region_id) ((region_id & FLEX_ACL_REGION_BIT_MASK) != FLEX_ACL_REGION_BIT_MASK)
#define FLEX_CLR_ACL_REGION_BIT(region_id)   (region_id &= ~(FLEX_ACL_REGION_BIT_MASK))
#define GET_ACL_GROUP_IDX(group_id)          (group_id & (~FLEX_ACL_LOGIC_GROUP_BIT_MASK))
#define CREATE_GROUP_ID(group_id)            (group_id | FLEX_ACL_LOGIC_GROUP_BIT_MASK)
#define FLEX_ACL_ALL_1_INT                   0xFFFFFFFF
#define FLEX_ACL_INVALID_ACTION_CONTAINER_ID 0xFFFFFFFF
#define FLEX_ACL_INVALID_PORT_TYPE           0xFFFFFFFF

/* MACSEC ACL bitmask macros */
#define MACSEC_ACL_REGION_BIT_CHECK(region_id) ((region_id & MACSEC_ACL_REGION_BIT_MASK) == MACSEC_ACL_REGION_BIT_MASK)
#define MACSEC_CLR_ACL_REGION_BIT(region_id)   (region_id &= ~(MACSEC_ACL_REGION_BIT_MASK))
#define MACSEC_ACL_KEY_HANDLE_BIT_CHECK(key_handle)   \
    ((key_handle & MACSEC_ACL_KEY_HANDLE_BIT_MASK) == \
     MACSEC_ACL_KEY_HANDLE_BIT_MASK)
#define MACSEC_CLR_ACL_KEY_HANDLE_BIT(key_handle) (key_handle &= ~(MACSEC_ACL_KEY_HANDLE_BIT_MASK))
#define MACSEC_SET_KEY_HANDLE(key_idx,                                                \
                              num_of_keys)        ((MACSEC_ACL_KEY_HANDLE_BIT_MASK) | \
                                                   (num_of_keys << KEY_HANDLE_MASK_OFFSET) | key_idx)
#define MACSEC_GET_KEY_INDEX(key_handle)          (key_handle & 0xFFFF)
#define MACSEC_ACL_BIT_CHECK(acl_id)              ((acl_id & MACSEC_ACL_BIT_MASK) == MACSEC_ACL_BIT_MASK)
#define MACSEC_CLR_ACL_BIT(acl_id)                (acl_id &= ~(MACSEC_ACL_BIT_MASK))


/* A utility macro to convert a rule's offset to a priority (for phoenix only). */
#define FLEX_ACL_OFFSET_TO_PRIO(rule_offset) (FLEX_ACL_RULE_PRIORITY_MAX - rule_offset)

#define ACTION_ID_2STR(action_id) sx_flex_acl_flex_action_type_str(action_id)

#define FLEX_ACL_MIN_NUM_OF_RULES_THAT_USE_PBS 10

#define FLEX_ACL_MIN_NUM_OF_RULES_THAT_USE_PBILM 10

#define ACL_MAX_EXTRACTION_POINTS_IN_GROUP 10
/* The old number of HW ACL groups that was supported a.k.a bind attributes */
#define FLEX_ACL_LEGACY_BIND_ATTRIB_COUNT 400

/* VLAN group direction is by legacy the same as port
 * So for differentiating between port and VLAN use an MSB bit
 * that creates the differentiation.
 * The supplied MACROs are used for setting and resetting direction
 * when appropriate.
 */
#define VLAN_GROUP_DIRECTION_PREFIX 0x80
#define USER_GIVEN_DIRECTION(direction)  (direction & 0x7F)
#define VLAN_GROUP_DIRECTION(direction)  (direction | VLAN_GROUP_DIRECTION_PREFIX)
#define VLAN_PREFIX_DIRECTION(direction) (direction & VLAN_GROUP_DIRECTION_PREFIX)

/* NVE port direction is required for NVE port
 * binding, however the direction used in the lower layers
 * is a regular port direction
 */
#define PORT_BIND_DIRECTION(direction) (direction & 0x1)
#define NVE_PORT_DIRECTION(direction)  (direction | ACL_DIRECTION_TPORT_INGRESS_BASE)

#define FLEX_ACL_BITS_IN_BYTE                       8
#define FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS         ((RM_API_ACL_PORT_LIST_MAX / FLEX_ACL_BITS_IN_BYTE) + 1)
#define FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS
#define FLEX_ACL_MAX_KEY_SIZE                       (FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS + 1)
#define FLEX_ACL_MAX_KEY_BLOCKS                     (rm_resource_global.acl_key_blocks_max)
#define FLEX_ACL_MAX_ACL_GROUP_SIZE                 (rm_resource_global.acl_groups_size_max)

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    sx_acl_id_t rollback_ids[SPECTRUM_ACL_GROUPS_SIZE_MAX];
    uint32_t    acls_num;
} flex_acl_group_creation_data_t;

typedef struct {
    boolean_t lag_sinc_advised;
    boolean_t adviser_regisered_dev_ready;
    boolean_t adviser_registered_pre_port_del;
    boolean_t adviser_registered_port_del;
    boolean_t adviser_registered_port_add;
    boolean_t cm_user_inited;
    boolean_t policer_manager_user_inited;
    boolean_t span_user_inited;
    boolean_t kvd_pbs_inited;
    boolean_t kvd_rules_inited;
    boolean_t kvd_default_actions_inited;
    boolean_t rm_groups_inited;
    boolean_t rm_acls_in_groups_inited;
    boolean_t rm_rules_inited;
    boolean_t basic_keys_inited;
    boolean_t db_inited;
    boolean_t hw_init_done;
    boolean_t redirection_db_inited;
    boolean_t pbs_inited;
    boolean_t rif_destroy_adviser_set_done;
    boolean_t rif_create_adviser_set_done;
    boolean_t rm_extended_actions_inited;
    boolean_t tunnel_decap_change_adviser_set_done;
    boolean_t mc_container_erif_pointer_change_adviser_set_done;
    boolean_t vport_bridge_delete_pre_adviser_set_done;
    boolean_t mc_container_port_mc_pointer_change_adviser_set_done;
    boolean_t ecmp_update_pointer_change_adviser_set_done;
    boolean_t ipv6_reloc_changed_set_done;
    boolean_t mc_container_nve_mc_pointer_change_adviser_set_done;
    boolean_t default_vlan_group_created; /* not the best place for that */
    boolean_t mc_container_next_hops_change_adviser_set_done;
    boolean_t fdb_mc_mid_change_adviser_set_done;
    boolean_t ftn_adviser_set_done;
    boolean_t continue_lookup_adviser_set_done;
    boolean_t trap_id_prio_change_adviser_set_done;
    boolean_t pbilm_inited;
    boolean_t kvd_pbilm_inited;
    boolean_t rm_regions_inited;
    boolean_t sys_acl_drop_trap_enabled;
    boolean_t use_soft_drop_for_empty_container;
    boolean_t rule_based_biniding_inited;
} flex_acl_init_flags_t;


/* structure that stores set of found 9B keys within a given by user set of basic acl keys. The structure also holds
 * the hw_key_handle to hw representation of key*/
typedef struct {
    uint32_t      key_idx;
    boolean_t     allocated;
    uint32_t      key_blocks_count;
    uint32_t      hw_key_handle;
    uint32_t      user_key_count;
    sx_acl_key_t *user_keys;
} flex_acl_db_flex_key_entry_t;


/* table that stores ACL key entries and manage free pool. Number of entries is bounded by entry_count*/
typedef struct {
    flex_acl_db_flex_key_entry_t *key_entries;
    uint32_t                      entry_count;
    id_allocator_t                id_allocator;
} flex_acl_db_flex_key_table_t;

typedef struct {
    sdk_ref_t                ref;
    sdk_ref_t                extra_ref;
    sx_ecmp_container_type_e ecmp_container_type;
} flex_acl_db_ref_handlers_t;

/* The structure holds rule as SW entity, where hw entities stored in rule as handlers */
typedef struct {
    sx_acl_rule_offset_t         offset;                 /**< Rules offset in the region */
    uint8_t                      valid;                  /**< Rules validity flag */
    sx_flex_acl_key_desc_t      *key_desc_list;          /**< Array of structures describing a set of basic 9b keys in the rule */
    uint32_t                     key_desc_count;         /**< Number of elements in array of basic keys descriptors */
    void                       * hw_key_desc_handle;     /**< Handle to hw representation of key descriptor */
    sx_flex_acl_flex_action_t   *actions;                /**< Actions that arranged in sets according to size */
    uint32_t                     action_count;           /**< actual amount of actions in rule */
    void                       * hw_action_handle;       /**< Handle to hw representation of actions */
    sx_acl_action_container_id_t action_container_id;
    sx_acl_region_id_t           region_id;
    boolean_t                    is_exist;               /**< Rule existence flag. */
    flex_acl_db_ref_handlers_t  *key_refs;
    flex_acl_db_ref_handlers_t  *action_refs;
    sdk_ref_t                    goto_rule_ref;
    sx_flex_acl_rule_priority_t  priority;               /**< Rule priority */
} flex_acl_db_flex_rule_t;

/* The structure represents acl region and it holds hw region attributes handle.
 */
typedef struct {
    sx_acl_region_id_t        region_id;                 /**< Self ID of the region */
    sx_acl_direction_t        direction;
    uint8_t                   allocated;                 /**< Allocation flag, when region in use the flag is TRUE */
    sx_acl_size_t             size;                      /**< Size of the region provided at region allocation */
    uint32_t                  reserved_rules_num;        /**< Number of reserved rules in region */
    sx_acl_key_type_t         key_handle;                /**< Handle to key structure */
    flex_acl_db_flex_rule_t  *rules;                      /**< Rules within the region. Allocated at set, filled at update*/
    uint32_t                  rules_num;
    uint32_t                  valid_rules_num;           /**< bound valid rules (for RM) */
    flex_acl_db_flex_rule_t   default_rule;              /*[SPC2+] Holds the default actions only (No keys) */
    sx_acl_id_t               bound_acl;
    boolean_t                 bound_to_devs;             /**< The flag if region bound to devices */
    uint32_t                  hw_region_attribs_handle;   /**< Handle to hw representation of region. See  */
    flex_acl_entry_type_e     entry_type;
    uint32_t                  egress_mirror_actions_count;
    flex_rule_priority_mode_e rules_priority_mode;       /**< Saves how region computes rules priority */
    boolean_t                 initial_activity_cleared;    /**< Indicate if to clear activity for a new rule */
    sx_acl_region_id_t        shadowed_by_region_id;      /**< The region_id of the region that shadows this region */
    sx_acl_region_id_t        shadow_of_region_id;        /**< The region_id of the region that this region shadows */
    uint32_t                  direction_bitmap;           /**< BitMap of ACL directions allowed for binding.
                                                           *    Applicable if the direction is the SX_ACL_DIRECTION_MULTI_POINTS_E direction */
    boolean_t stateful_db_region;                         /**< Indicate if this region is intended to be used by stateful db */
} flex_acl_db_acl_region_t;

typedef struct {
    flex_acl_db_acl_region_t *regions;              /**< Array of regions */
    uint32_t                  num_of_regions;       /**< Actual number of allocated items in array */
    id_allocator_t            id_allocator;
} flex_acl_db_acl_regions_db_t;

typedef struct {
    sx_acl_id_t           acl_id;
    uint8_t               allocated;
    sx_acl_direction_t    direction;
    flex_acl_entry_type_e entry_type;
    sx_acl_region_id_t    bound_region;
    cl_list_t             bound_group_list;
    sx_acl_id_t           adhoc_acl_group_id;     /**< where acl bounded directly to port,the group id created for binding*/
    sx_acl_id_t           shadowed_by_acl_id;     /* The acl id of the ACL that shadows this acl */
    sx_acl_id_t           shadow_of_acl_id;       /* The acl id of the ACL that this acl is shadowing */
    sx_acl_attributes_t   acl_attributes;
    boolean_t             is_commit;              /* For SPC2+ indicate this ACL should commit its actions. For internal use */
} flex_acl_db_acl_table_t;

/* Will be used as part of an array of acl ids to be written to a group */
typedef struct {
    sx_acl_id_t                acl_id;
    boolean_t                  is_commit;
    boolean_t                  is_multi;
    flex_acl_bind_attribs_id_t acl_group_element;  /* The PAGT_V2 index this entry resides in */
} acl_id_group_entry_t;

/* The structure that describes bind attributes. At binding logical group, bind attributes will be allocated through bind_id*/
typedef struct {
    flex_acl_bind_attribs_id_t bind_id;
    sx_acl_id_t                bound_logic_group_id;
    uint8_t                    allocated;
    sx_acl_direction_t         direction;
    boolean_t                  is_group_head;
    sx_port_log_id_t           bound_nve_port;
    cl_list_t                  bound_log_port;
    cl_list_t                  bound_lag;
    cl_list_t                  bound_vlan_group;
    cl_list_t                  bound_rif;
    cl_list_t                  bound_goto_rule;
    cl_list_t                  bound_rbb_rule;
    flex_acl_entry_type_e      entry_type;
    acl_id_group_entry_t      *acl_id_list;  /*SX_ACL_MAX_ACL_GROUP_SIZE*/
    uint32_t                   acl_id_num;
} flex_acl_db_group_bind_attribs_t;

typedef struct {
    cl_fmap_item_t        fmap_item;                /* bind_point_groups_map */
    sx_acl_id_t           group_id;
    uint8_t               allocated;
    sx_acl_direction_t    direction;
    sx_acl_id_t           bind_attribs_id;
    sx_acl_id_t           prev_acl_group_id;
    sx_acl_id_t           next_acl_group_id;
    uint32_t              acl_num;
    sx_acl_id_t          *acl_ids;                      /*SX_ACL_MAX_ACL_GROUP_SIZE*/
    flex_acl_entry_type_e entry_type;
    sdk_refcount_t        rules_ref_count;
    cl_map_t              rifs_refs;                /* map of RIF's REF counts associated to ACL group when bound/added to RIF,
                                                     * key: RIF ID, data: RIF's REF*/
    cl_list_t                bound_log_ports;       /* list of bound log ports */
    cl_list_t                bound_rifs;            /* list of bound RIFs */
    cl_list_t                bound_vlan_groups;     /* list of bound vlan groups */
    cl_list_t                bound_rbb_rules;       /* list of bound rule based binding */
    sx_acl_group_priority_t  group_prio;
    uint32_t                 bind_point_count;        /* Counts the number of bind_points using this group */
    sx_acl_description_str_t group_desc;    /* [Optional] Group Description */
} flex_acl_db_acl_group_t;

typedef struct {
    sx_rif_id_t                rif_id;
    cl_list_t                  bound_groups;
    flex_acl_bind_attribs_id_t bound_attribs_id;
} flex_acl_db_rif_info_t;

typedef struct {
    cl_list_t rifs_db[2];   /* stores the list of rif elements*/
} flex_acl_db_rif_db_t;

typedef struct {
    flex_acl_db_group_bind_attribs_t *attribs;
    uint32_t                          num_of_attribs;
    cl_list_t                         free_pool;
} flex_acl_db_bind_attris_db_t;

typedef struct {
    flex_acl_db_acl_group_t *groups;
    uint32_t                 num_of_groups;
    cl_list_t                free_pool;
    cl_fmap_t                bind_point_groups_map; /** This map holds the aggregated groups
                                                     *   Key: list of aggregated ACL IDs {1,2,3,4 },
                                                     *   Value : group itself */
} flex_acl_db_acl_groups_db_t;

typedef struct flex_acl_db_vlan_group_vid_map_db_entry {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    uint32_t       vid;
} flex_acl_db_vlan_group_vid_map_db_entry_t;

typedef struct flex_acl_db_vlan_group_swid_map_db_entry {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    sx_swid_id_t   swid;
    cl_qpool_t     vid_pool;
    cl_qmap_t      vid_map;
} flex_acl_db_vlan_group_swid_map_db_entry_t;

typedef struct {
    sx_acl_vlan_group_t        group_id;
    uint8_t                    allocated;
    cl_qpool_t                 swid_pool;
    cl_qmap_t                  swid_map;    /* Each swid_map contain vid map */
    cl_list_t                  bound_groups; /* List of groups bound to this group */
    flex_acl_bind_attribs_id_t bound_attribs_id; /* Current HW group bound to the VLAN group */
    flex_acl_entry_type_e      entry_type;
} flex_acl_db_vlan_group_element_t;

/**
 * Keeps VLAN information: whether VLAN is defined and in which VLAN groups
 */
typedef struct vlan_attribs {
    uint8_t             is_exist;
    sx_acl_vlan_group_t group_id;
} flex_acl_vlan_attribs_t;

/* system vlan group DB items */
typedef struct flex_acl_db_system_vid_pool_map_entry {
    sx_swid_id_t           swid;
    uint32_t               vid;
    system_acl_client_id_e client_id;
} flex_acl_db_system_vid_pool_map_entry_t;

typedef struct {
    sx_acl_vlan_group_t default_group_id;
    flex_acl_pool_map_t vid_pool_map;
    boolean_t           is_initialized;
    uint32_t            db_init_ref_count;       /** How many clients made init of this DB */
} flex_acl_db_system_vlan_group_t;

typedef struct {
    flex_acl_db_acl_table_t *tables;
    uint32_t                 num_of_tables;
    id_allocator_t           id_allocator;
} flex_acl_db_acl_tables_db_t;

typedef struct {
    sx_port_id_t               port_id;
    cl_list_t                  bound_groups;
    flex_acl_bind_attribs_id_t bound_attribs_id;
} flex_acl_db_port_info_t;

typedef struct {
    cl_list_t               ports_db[2];
    cl_list_t               lag_db[2];
    flex_acl_db_port_info_t nve_port_info;
} flex_acl_db_acl_ports_db_t;

typedef struct {
    sx_acl_range_entry_t range_entry;
    boolean_t            allocated;
    uint32_t             rules_ref_cnt;
    sdk_ref_t            reg_reference;
} flex_acl_db_acl_range_t;

/* Common DB for custom byte set and gp register */
typedef struct {
    acl_custom_bytes_set_id_e custom_byte_set;
    uint8_t                   custom_byte_set_ref;
} flex_acl_db_acl_ranges_custom_bytes_db_t;

typedef struct {
    flex_acl_db_acl_range_t                  *ranges_db;
    flex_acl_db_acl_ranges_custom_bytes_db_t *custom_bytes_db;
} flex_acl_db_acl_ranges_db_t;

typedef struct {
    cl_qpool_t     pbs_pool;
    uint32_t       pbs_pool_size;  /* PBS pool maximum size */
    cl_qmap_t      pbs_map;    /* map storing ALL active PBS {swid,pbs_id}*/
    uint32_t       pbs_count;  /* actual PBS entries  */
    id_allocator_t id_allocator;
    /* cl_qmap_t  kvd_handles_map;  / * Kvd handle is a key and object is an pbs handler * / */
} flex_acl_db_pbs_db_t;

typedef struct {
    flex_acl_rule_id_t rule_id;
    uint32_t           refcnt;   /* In case same PBS is used several times in the rule */
} flex_acl_pbs_rule_id_t;

typedef struct flex_acl_db_pbs_entry {
    cl_pool_item_t                   pool_item;
    cl_map_item_t                    map_item;
    cl_map_item_t                    kvd_map_item;
    sx_acl_pbs_id_t                  pbs_id;
    kvd_linear_manager_handle_t      kvd_handle;
    sx_swid_t                        swid;
    sx_acl_pbs_entry_type_t          entry_type;
    uint32_t                         port_num;      /* Relevant for unicast type */
    sx_port_id_t                     log_port;      /* Valid for unicast type */
    sx_pgi_t                         pgi;           /* Valid for mcast type */
    sx_mc_id_t                       mid;           /* Valid for mcast type*/
    uint32_t                         ecmp_size;     /* Valid for mcast tunnel type*/
    uint32_t                         tnumt;         /* Valid for mcast tunnel type or UC tunnel with ECMP*/
    boolean_t                        tnumt_valid;   /* Valid for mcast tunnel type*/
    boolean_t                        is_vport;
    sx_fid_t                         fid;           /* Relevant for vport & SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_MULTICAST_TUNNEL */
    uint32_t                         rules_ref_cnt;
    cl_list_t                        rules_list;
    boolean_t                        is_system;
    sx_mc_container_id_t             container_id;
    sx_ecmp_id_t                     ecmp_id;       /* Relevant for EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP */
    sx_ip_next_hop_ip_tunnel_t       ip_tunnel;
    sx_acl_pbs_entry_type_extended_t extended_entry_type; /* Extended types not included in SX-API*/
    uint32_t                         tunnel_port_bitmap; /* Valid for UC tunnel with ECMP*/
    uint32_t                         ipv6_hw_index; /* Valid for unicast IPv6 tunnel type */
} flex_acl_db_pbs_entry_t;

typedef struct {
    cl_pool_item_t     pool_item;
    cl_list_item_t     list_item;
    flex_acl_rule_id_t rule_id;
} flex_acl_db_rule_id_item_t;

typedef struct {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    cl_qpool_t               rules_ref_list_pool;
    cl_qlist_t               rules_ref_list;     /*flex_acl_db_rule_id_item_t*/
    sx_acl_port_list_entry_t port_list[RM_API_ACL_PORT_LIST_MAX];
    uint32_t                 port_count;
    sx_acl_port_list_id_t    rx_list_id;
    sx_port_type_t           port_type;
} flex_acl_db_rx_list_map_item_t;

typedef struct {
    cl_qpool_t     rx_lists_pool;
    uint32_t       rx_list_pool_size;
    cl_qmap_t      rx_lists_map;               /*flex_acl_db_rx_list_map_item_t*/
    id_allocator_t id_allocator;
} flex_acl_db_rx_lists_db_t;

typedef struct {
    cl_pool_item_t     pool_item;
    cl_map_item_t      map_item;
    flex_acl_rule_id_t rule_id;
    uint32_t           ref_count;
} flex_acl_db_rule_map_item_t;

typedef enum  {
    MCC_TO_RULE_PORT_LIST_KEY      = 0,
    MCC_TO_RULE_PORT_FILTER_ACTION = 1,
} mcc_to_rule_type_e;

typedef struct {
    cl_pool_item_t       pool_item;
    cl_map_item_t        map_item;
    sx_mc_container_id_t mc_container_id;
    mcc_to_rule_type_e   type;
    cl_qpool_t           rule_id_map_pool;
    cl_qmap_t            rule_id_map;   /* flex_acl_db_rule_map_item_t */
} flex_acl_db_mcc_to_rule_item_t;

typedef struct {
    cl_qpool_t container_rule_pool;
    cl_qmap_t  container_rule_map;      /* flex_acl_db_mcc_to_rule_item_t */
} flex_acl_db_mcc_to_rule_db_t;

typedef struct {
    cl_qpool_t pbs_mc_pool;
    uint32_t   pbs_mc_pool_size;
    cl_qmap_t  pbs_mc_map;
} flex_acl_db_pbs_mc_db_t;

typedef struct {
    cl_pool_item_t                 pool_item;
    cl_map_item_t                  map_item;
    sx_mc_container_id_t           mc_id;
    sx_flex_acl_flex_action_type_t api_action_type;
    sx_acl_pbs_id_t                pbs_id;
    uint32_t                       ref_count;
} flex_acl_db_pbs_mc_map_item_t;

typedef struct {
    cl_qpool_t pbs_ecmp_pool;
    cl_qmap_t  pbs_ecmp_map;
} flex_acl_db_pbs_ecmp_db_t;

typedef struct {
    cl_pool_item_t             pool_item;
    cl_map_item_t              map_item;
    hwi_ecmp_hw_block_handle_t ecmp_handle;
    sx_acl_pbs_id_t            pbs_id;
    uint32_t                   ref_count;
} flex_acl_db_pbs_ecmp_map_item_t;

typedef struct {
    cl_qpool_t log_port_to_mc_container_pool;
    cl_qpool_t mc_containers_ref_list_pool;
    cl_qmap_t  log_port_to_mc_container_map;
} flex_acl_db_log_port_to_mc_container_db_t;

typedef struct {
    cl_pool_item_t       pool_item;
    cl_list_item_t       list_item;
    sx_mc_container_id_t mc_container_id;
} flex_acl_db_mc_container_id_item_t;

typedef struct {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    sx_port_id_t   log_port;
    cl_qlist_t     mc_containers_ref_list;           /*flex_acl_db_mc_container_id_item_t*/
} flex_acl_db_log_port_to_mc_container_item_t;

typedef struct {
    cl_qpool_t mc_container_to_log_port_pool;
    cl_qpool_t log_port_ref_list_pool;
    cl_qmap_t  mc_container_to_log_port_map;
} flex_acl_db_mc_container_to_log_port_db_t;

typedef struct {
    cl_pool_item_t pool_item;
    cl_list_item_t list_item;
    sx_port_id_t   log_port;
} flex_acl_db_log_port_id_item_t;

typedef struct {
    cl_pool_item_t       pool_item;
    cl_map_item_t        map_item;
    sx_mc_container_id_t mc_container_id;
    cl_qlist_t           log_port_ref_list;     /*flex_acl_db_log_port_id_item_t*/
    uint32_t             rules_ref_count;
} flex_acl_db_mc_container_to_log_port_item_t;

typedef struct {
    cl_qpool_t        pbilm_pool;
    cl_qmap_t         pbilm_map;        /* pbilm_id is the key */
    cl_qmap_t         kvd_handles_map;  /* Kvd handle (PPBMI allocation) is the key */
    sx_acl_pbilm_id_t last_pbilm_id;    /* Index that will be used to allocate pbilm id */
    uint32_t          pbilm_count;      /* Simple counter to monitor the number of items created */
} flex_acl_db_pbilm_db_t;

typedef struct {
    cl_pool_item_t                    pool_item;
    cl_map_item_t                     map_item;       /* Used for mapping from the pbilm_id */
    cl_map_item_t                     kvd_map_item;   /* Used for mapping from the kvd_handle */
    sx_acl_pbilm_id_t                 pbilm_id;
    kvd_linear_manager_handle_t       kvd_handle;     /* KVD handle of the PPBMI allocation */
    kvd_linear_manager_handle_t       nhlfe_handle;   /* KVD handle of the MPNHLFE allocation */
    kvd_linear_manager_index_t        nhlfe_index;    /* Last index of the nhlfe */
    kvd_linear_manager_block_length_t nhlfe_size;     /* The size of the nhlfe pointed by this entry */
    sx_mpls_in_segment_params_t       params;
    uint32_t                          rules_ref_cnt;
    sdk_ref_t                         ecmp_ref;
} flex_acl_db_pbilm_entry_t;

typedef struct {
    cl_qpool_t pbs_nve_pool;
    uint32_t   pbs_nve_pool_size;
    cl_fmap_t  pbs_nve_map;
} flex_acl_db_pbs_nve_db_t;

typedef struct {
    cl_pool_item_t             pool_item;
    cl_fmap_item_t             fmap_item;
    sx_ip_next_hop_ip_tunnel_t ip_tunnel_id;
    sx_acl_pbs_id_t            pbs_id;
    uint32_t                   ref_count;
} flex_acl_db_pbs_nve_map_item_t;


/* The following structures are used to map a binding point (direction+rif/port) to acl groups that
 * are attached to this point.
 */
typedef struct {
    cl_qpool_t bind_point_pool;
    cl_qmap_t  bind_point_map;
} flex_acl_db_bind_point_db_t;

typedef struct {
    cl_pool_item_t         pool_item;
    cl_map_item_t          map_item;
    sx_acl_direction_t     direction;
    flex_acl_bind_point_id bind_point_id;
    sx_acl_id_t            group_id;
} flex_acl_db_sys_bind_point_item_t;

typedef struct {
    cl_pool_item_t         pool_item;
    cl_map_item_t          map_item;
    sx_acl_direction_t     direction;
    flex_acl_bind_point_id bind_point_id;
    cl_list_t              bound_groups;            /* List of bound groups */
    sx_acl_id_t            bind_group;              /* Valid in case of port-specific HW group */
} flex_acl_db_bind_point_item_t;

typedef struct {
    cl_qpool_t system_acl_group_pool;
    cl_qmap_t  system_acl_group_map;
} flex_acl_db_system_acl_group_db_t;

typedef struct {
    cl_pool_item_t         pool_item;
    cl_map_item_t          map_item;
    sx_acl_id_t            group_id;
    system_acl_client_id_e client_id;
    uint32_t               instance;
} flex_acl_db_system_acl_group_item_t;

typedef sx_status_t (*flex_acl_rif_db_pfn_t)(flex_acl_db_rif_info_t *, void *param_p);
typedef sx_status_t (*flex_acl_port_db_pfn_t)(flex_acl_db_port_info_t *, void *param_p);
typedef sx_status_t (*flex_acl_pbs_db_pfn_t)(flex_acl_db_pbs_entry_t *, void *param_p);
typedef sx_status_t (*flex_acl_db_hw_t)(flex_acl_db_flex_rule_t *rule);
typedef sx_status_t (*flex_acl_free_action_sets_t)(flex_acl_db_flex_rule_t *rule);
typedef sx_status_t (*flex_acl_region_db_pfn_t)(flex_acl_db_acl_region_t *region, void *param_p);
typedef sx_status_t (*flex_acl_bind_attributes_db_pfn_t)(flex_acl_db_group_bind_attribs_t *bind_attribute,
                                                         void                             *param_p);
typedef sx_status_t (*flex_acl_bind_acl_db_pfn_t)(flex_acl_db_acl_table_t *acl_table, void *param_p);
typedef sx_status_t (*flex_acl_bind_group_db_pfn_t)(flex_acl_db_acl_group_t *acl_group, void *param_p);
typedef sx_status_t (*flex_acl_vlan_grp_db_pfn_t)(flex_acl_db_vlan_group_element_t *grp_info, void *param_p);
typedef sx_status_t (*flex_acl_hw_del_pbs_pfn_t)(flex_acl_db_pbs_entry_t *pbs_entry);
typedef sx_status_t (*flex_acl_port_list_db_pfn_t)(flex_acl_db_rx_list_map_item_t *port_list_p, void *param_p);
typedef sx_status_t (*flex_acl_db_mcc_rule_pfn_t)(flex_acl_rule_id_t *rule_id_p, void *param_p);
typedef sx_status_t (*bind_group_func_p)(flex_acl_db_flex_rule_t *rule_p, boolean_t rebind,
                                         flex_acl_bind_attribs_id_t *bind_id, boolean_t *is_empty_group);
typedef sx_status_t (*unbind_group_func_p)(sx_acl_id_t group_id, flex_acl_db_flex_rule_t *rule_p);
typedef sx_status_t (*flex_acl_pbilm_db_pfn_t)(flex_acl_db_pbilm_entry_t *, void *param_p);
typedef sx_status_t (*flex_acl_hw_del_pbilm_pfn_t)(flex_acl_db_pbilm_entry_t *pbilm_entry, boolean_t remove_kvdl);

typedef struct bind_group_cb {
    bind_group_func_p   bind_group_cb;
    unbind_group_func_p unbind_group_cb;
} flex_acl_rebind_group_pfunc_t;

typedef struct {
    uint32_t                      num_of_devices;
    uint8_t                       num_of_swid_ids;
    uint32_t                      num_of_vlan_groups;
    uint32_t                      num_of_acl_ingress_groups; /* backward compatible */
    uint32_t                      num_of_acl_egress_groups; /* backward compatible */
    uint32_t                      num_of_acl;
    uint32_t                      num_of_acl_regions;
    uint32_t                      min_acl_rules;
    uint32_t                      max_acl_rules;
    uint32_t                      num_of_rif;
    uint32_t                      num_of_bind_attribs;
    uint32_t                      max_group_size;
    uint32_t                      num_of_logic_groups;
    uint32_t                      num_of_key_tables;
    sx_flex_acl_search_type_t     acl_search_type;
    flex_acl_free_action_sets_t   free_action_set_cb;
    flex_acl_hw_del_pbs_pfn_t     free_pbs_cb;
    flex_acl_hw_del_pbilm_pfn_t   free_pbilm_cb;
    sx_tcam_opt_params_t          tcam_opt_params;
    flex_acl_rebind_group_pfunc_t rebind_group_cb;
    acl_stage_e                   acl_stage;
} flex_acl_attributes_t;

typedef struct {
    cl_qpool_t     action_container_pool;
    id_allocator_t id_allocator;
    cl_qmap_t      kvd_index_map;           /* kvd index map to container item */
    cl_qmap_t      container_id_map;        /* container id map to container item */
} flex_acl_db_action_container_db_t;

typedef struct {
    cl_pool_item_t               pool_item;
    cl_map_item_t                kvd_index_map_item;
    cl_map_item_t                container_id_map_item;
    sx_acl_action_container_id_t container_id;
    void                        *hw_action_handle;
} flex_acl_db_action_container_item_t;

typedef struct {
    boolean_t                          in_progress;
    sx_access_cmd_t                    cmd;
    sx_flex_acl_activity_notify_attr_t activity_notify_attr;
} flex_acl_db_activity_notify_param_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
const char * flex_acl_db_key_id_to_str(sx_acl_key_t key_id);

/* HW implementation layer */

sx_status_t flex_acl_db_init(flex_acl_attributes_t *db_attributes);
void flex_acl_db_deinit();

/* Allocate mem for user keys and adds it to db. return handle to user*/
sx_status_t flex_acl_db_add_flex_key_entry(sx_acl_key_t      *user_keys,
                                           uint32_t           user_key_count,
                                           uint32_t           hw_key_handle,
                                           sx_acl_key_type_t* key_handle);

sx_status_t flex_acl_db_flex_key_entry_init_predefined(sx_acl_key_t      *user_keys,
                                                       uint32_t           user_key_count,
                                                       uint32_t           hw_key_handle,
                                                       sx_acl_key_type_t *key_type);

/* Return references to user keys and key blocks structures stored at DB */
sx_status_t flex_acl_db_get_flex_key_entry(sx_acl_key_type_t key_handle,
                                           sx_acl_key_t    **user_keys,
                                           uint8_t         * user_key_count,
                                           uint32_t        * hw_key_handle);
/* clean key entry and return it to free pool*/
sx_status_t flex_acl_db_remove_flex_key_entry(sx_acl_key_type_t key_handle);

/* FOR SET RULES copy the rules to region according to offset of each rule */
sx_status_t flex_acl_db_update_rules(sx_acl_region_id_t region_id,
                                     flex_acl_db_flex_rule_t *rules,
                                     uint32_t rules_num, flex_acl_db_hw_t copy_rule_ptr_cb);
sx_status_t flex_acl_db_get_rule_by_offset(sx_acl_region_id_t        region_id,
                                           sx_flex_acl_rule_offset_t offset,
                                           flex_acl_db_flex_rule_t **rule);

/* FOR RESIZE allocate place , copy old rules to new location and delete old location.*/
sx_status_t flex_acl_db_allocate_and_copy_rules(flex_acl_db_flex_rule_t **old_rules_ptr_p,
                                                uint32_t                  new_rules_num,
                                                uint32_t                  old_rules_num,
                                                uint32_t                  reserved_rules_num,
                                                flex_acl_db_hw_t          copy_rule_ptr_cb);
/* FOR SET RULES PRE PROCESSING
 *  allocate place, build db rules structure from user rules. Allocate place for inner references */
sx_status_t flex_acl_db_allocate_and_fill_rules(sx_flex_acl_flex_rule_t   *rules,
                                                sx_flex_acl_rule_offset_t* offsets_list_p,
                                                uint32_t                   rules_num,
                                                flex_acl_db_flex_rule_t  **db_rules_ptr_p);
/* FOR DELETE rules with inner references */
sx_status_t flex_acl_db_free_rules(flex_acl_db_flex_rule_t *db_rules_ptr, uint32_t count);
sx_status_t flex_acl_db_validate_and_prepare_rules_move(sx_api_acl_block_move_params_t *params,
                                                        uint32_t                        reserved_rules_num,
                                                        flex_acl_db_flex_rule_t       **rules_to_free,
                                                        uint32_t                       *rules_count);
sx_status_t flex_acl_db_rules_move(sx_api_acl_block_move_params_t *params,
                                   flex_acl_db_hw_t                copy_rule_ptr_cb,
                                   boolean_t                       change_priority);

/* Gets acl id that is bound to specified rif*/
sx_status_t flex_acl_db_rif_bind(sx_rif_id_t                rif,
                                 sx_acl_direction_t         egress,
                                 flex_acl_bind_attribs_id_t new_attribs_id);
sx_status_t flex_acl_db_rif_unbind(sx_rif_id_t rif, sx_acl_direction_t egress);
sx_status_t flex_acl_db_validate_rif_bind(sx_rif_id_t rif, sx_acl_direction_t egress, boolean_t rebinding);
sx_status_t flex_acl_db_get_rif_bind(sx_rif_id_t                 rif,
                                     sx_acl_direction_t          egress,
                                     flex_acl_bind_attribs_id_t* attribs_id);
sx_status_t flex_acl_db_rif_acl_group_bind(sx_rif_id_t        rif,
                                           sx_acl_direction_t egress,
                                           sx_acl_id_t        acl_group_id);
sx_status_t flex_acl_db_rif_acl_group_unbind(sx_rif_id_t        rif,
                                             sx_acl_direction_t egress,
                                             sx_acl_id_t        acl_group_id);
sx_status_t flex_acl_db_rif_bound_groups_get(sx_rif_id_t        rif,
                                             sx_acl_direction_t egress,
                                             sx_acl_id_t       *acl_group_id,
                                             uint32_t          *group_num);
boolean_t flex_acl_db_is_rif_bound_group(sx_rif_id_t        rif,
                                         sx_acl_direction_t egress,
                                         sx_acl_id_t        acl_group_id);
sx_status_t flex_acl_db_rif_bind_foreach(flex_acl_rif_db_pfn_t func, void *data);

/* REGIONS HANDLING */
sx_status_t flex_acl_db_region_allocate(sx_acl_region_id_t *region_id);
sx_status_t flex_acl_db_region_destroy(sx_acl_region_id_t region_id,  uint32_t *region_size);
sx_status_t flex_acl_db_region_get(sx_acl_region_id_t region_id, flex_acl_db_acl_region_t **acl_region);
sx_status_t flex_acl_db_region_entry_type_set(sx_acl_region_id_t region_id, flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_db_region_entry_type_get(sx_acl_region_id_t region_id, flex_acl_entry_type_e *entry_type);

sx_status_t flex_acl_db_region_params_set(sx_acl_region_id_t region_id,
                                          sx_acl_size_t      region_size,
                                          sx_acl_key_type_t  key_handle,
                                          uint32_t           reserved_rules_num,
                                          boolean_t          initial_activity_clear,
                                          boolean_t          stateful_db_region);
sx_status_t flex_acl_db_region_params_get(sx_acl_region_id_t region_id,
                                          sx_acl_size_t     *region_size,
                                          sx_acl_key_type_t *key_handle);
sx_status_t flex_acl_db_set_region_acl_table(sx_acl_region_id_t region_id, sx_acl_id_t acl_id);

sx_status_t flex_acl_db_region_size_validate(sx_acl_region_id_t region_id,
                                             sx_acl_size_t      acl_new_size,
                                             sx_acl_size_t      reserved_acl_rules_num,
                                             boolean_t         *size_hit);
sx_status_t flex_acl_db_region_size_set(sx_acl_region_id_t region_id, sx_acl_size_t region_size);
sx_status_t flex_acl_db_region_resize_set(sx_acl_region_id_t region_id,
                                          sx_acl_size_t      region_new_size,
                                          sx_acl_size_t      reserved_rules_num,
                                          flex_acl_db_hw_t   copy_rule_ptr_cb);

sx_status_t flex_acl_db_region_hw_handle_set(sx_acl_region_id_t region_id, uint32_t hw_handle);
sx_status_t flex_acl_db_region_hw_handle_get(sx_acl_region_id_t region_id, uint32_t *hw_handle);

sx_status_t flex_acl_db_region_valid_rules_set(sx_acl_region_id_t region_id, uint32_t valid_rules_count);
sx_status_t flex_acl_db_region_valid_rules_sum_get(uint32_t *rm_valid_rules);
sx_status_t flex_acl_db_region_reserved_get(sx_acl_region_id_t *region_id);
sx_status_t flex_acl_db_region_reserved_set(sx_acl_region_id_t region_id);
sx_status_t flex_acl_db_region_key_use_validate(sx_acl_key_type_t key_handle);
/* if region_in = invalid_region_id will return first region id, if region_in invalid or las- >will return invalid_region_id*/
sx_acl_region_id_t flex_acl_db_get_next_region(sx_acl_region_id_t region_id_in);
sx_status_t flex_acl_db_get_valid_rules_offset_list(sx_acl_region_id_t     region_id,
                                                    sx_acl_rule_offset_t **offset_list,
                                                    uint32_t              *list_size);
void flex_acl_db_free_offset_list(sx_acl_rule_offset_t *offset_list);

sx_status_t flex_acl_db_region_bind_set(sx_acl_region_id_t region_id);
sx_status_t flex_acl_db_region_unbind_set(sx_acl_region_id_t region_id);
sx_status_t flex_acl_db_is_region_bound_to_dev(sx_acl_region_id_t region_id, boolean_t *is_bound);
sx_status_t flex_acl_db_region_foreach(flex_acl_region_db_pfn_t func, void *param_p);

sx_status_t flex_acl_db_get_acl_rule_from_region(sx_acl_region_id_t        region_id,
                                                 sx_acl_rule_offset_t      rule_offset,
                                                 flex_acl_db_flex_rule_t **rule);

sx_status_t flex_acl_db_invalidate_rules(sx_acl_region_id_t         region_id,
                                         sx_flex_acl_rule_offset_t *offset_list,
                                         uint32_t                   count);
sx_status_t flex_acl_db_delete_rules(sx_acl_region_id_t         region_id,
                                     sx_flex_acl_rule_offset_t *offset_list,
                                     uint32_t                   count);
sx_status_t flex_acl_db_verify_rules_exist(sx_acl_region_id_t       region_id,
                                           flex_acl_db_flex_rule_t *rules,
                                           uint32_t                 rules_num);
sx_status_t flex_acl_db_region_set_shadow_region(const sx_acl_region_id_t region_id,
                                                 const sx_acl_region_id_t shadow_region_id);

/* ACL handling */
sx_status_t flex_acl_db_acl_allocate(sx_acl_id_t *acl_id, sx_acl_direction_t acl_direction);
sx_status_t flex_acl_db_acl_destroy(sx_acl_id_t acl_id);
sx_status_t flex_acl_db_acl_get(sx_acl_id_t acl_id, flex_acl_db_acl_table_t **acl_table);
sx_status_t flex_acl_db_iter_get(const sx_access_cmd_t access_cmd,
                                 const sx_acl_id_t     key,
                                 sx_acl_filter_t      *filter,
                                 sx_acl_id_t          *list,
                                 uint32_t             *cnt);

sx_status_t flex_acl_group_db_iter_get(const sx_access_cmd_t access_cmd,
                                       const sx_acl_id_t     key,
                                       sx_acl_filter_t      *filter,
                                       sx_acl_id_t          *list,
                                       uint32_t             *cnt);
sx_status_t flex_acl_db_acl_get_from_region_id(sx_acl_region_id_t region_id, flex_acl_db_acl_table_t **acl_table);
sx_status_t flex_acl_db_set_acl_attributes(sx_api_flex_acl_set_params_t *params);
sx_status_t flex_acl_db_get_acl_attributes(sx_api_flex_acl_set_params_t *params);
sx_status_t flex_acl_db_acl_add_to_group(sx_acl_id_t acl_id, sx_acl_id_t group_id);
sx_status_t flex_acl_db_acl_remove_from_group(sx_acl_id_t acl_id, sx_acl_id_t group_id);
sx_status_t flex_acl_db_acl_get_group_list(sx_acl_id_t acl_id, const cl_list_t **groups_list);
sx_status_t flex_acl_db_acl_bind_foreach(flex_acl_bind_acl_db_pfn_t func, void *param_p);
sx_status_t flex_acl_db_acl_entry_type_set(sx_acl_id_t acl_id, flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_db_acl_entry_type_get(sx_acl_id_t acl_id, flex_acl_entry_type_e *entry_type);
sx_status_t flex_acl_db_acl_set_shadow_acl(const sx_acl_id_t acl_id, const sx_acl_id_t shadow_acl_id);
uint32_t flex_acl_db_get_shadow_acl_count();

/* Vlan Group operations*/
uint32_t flex_acl_db_get_max_swid();
boolean_t flex_acl_db_swid_in_range(sx_swid_id_t swid);
sx_status_t flex_acl_db_vlan_group_allocate(sx_acl_vlan_group_t *group_id);
uint8_t flex_acl_db_vlan_group_is_exist(sx_acl_vlan_group_t group_id);
sx_status_t flex_acl_db_vlan_group_destroy(sx_acl_vlan_group_t group_id);
sx_status_t flex_acl_db_vlan_group_validate_destroy(sx_acl_vlan_group_t group_id);
sx_status_t flex_acl_db_vlan_group_get(sx_acl_vlan_group_t group_id,   sx_swid_id_t swid,
                                       sx_vlan_id_t        *vlan_list, uint32_t     *vlan_num);
sx_status_t flex_acl_db_vlan_group_add(sx_acl_vlan_group_t group_id, sx_swid_id_t swid,
                                       sx_vlan_id_t *vlan_list, uint32_t vlan_num);
sx_status_t flex_acl_db_vlan_group_validate_add(sx_acl_vlan_group_t group_id,
                                                sx_swid_id_t        swid,
                                                sx_vlan_id_t       *vlan_list,
                                                uint32_t            vlan_num);
sx_status_t flex_acl_db_vlan_group_remove_from(uint16_t      group_id,
                                               sx_swid_id_t  swid,
                                               sx_vlan_id_t *vlan_list,
                                               uint32_t      vlan_num);
sx_status_t flex_acl_db_vlan_group_validate_remove(sx_acl_vlan_group_t group_id,
                                                   sx_swid_id_t        swid,
                                                   sx_vlan_id_t       *vlan_list,
                                                   uint32_t            vlan_num);
sx_status_t flex_acl_db_vlan_group_bind_attributes(sx_acl_vlan_group_t        vlan_group,
                                                   sx_acl_direction_t         egress,
                                                   flex_acl_bind_attribs_id_t new_attribs_id,
                                                   boolean_t                  rebinding);
sx_status_t flex_acl_db_vlan_group_get_bind_attributes(sx_acl_vlan_group_t         vlan_group,
                                                       sx_acl_direction_t          egress,
                                                       flex_acl_bind_attribs_id_t *attribs_id);
sx_status_t flex_acl_db_group_bind_vlan_group(flex_acl_db_acl_group_t *group,
                                              sx_acl_vlan_group_t      vlan_group);
sx_status_t flex_acl_db_group_unbind_vlan_group(flex_acl_db_acl_group_t *group,
                                                sx_acl_vlan_group_t      vlan_group);
sx_status_t flex_acl_db_vlan_group_acl_group_bind(sx_acl_vlan_group_t vlan_group,
                                                  sx_acl_direction_t  egress,
                                                  sx_acl_id_t         acl_group_id);
sx_status_t flex_acl_db_vlan_group_acl_group_unbind(sx_acl_vlan_group_t vlan_group,
                                                    sx_acl_direction_t  egress,
                                                    sx_acl_id_t         acl_group_id);
sx_status_t flex_acl_db_vlan_group_bound_groups_get(sx_acl_vlan_group_t vlan_group,
                                                    sx_acl_direction_t  egress,
                                                    sx_acl_id_t        *acl_group_id,
                                                    uint32_t           *group_num);
boolean_t flex_acl_db_is_vlan_group_bound_group(sx_acl_vlan_group_t vlan_group,
                                                sx_acl_direction_t  egress,
                                                sx_acl_id_t         acl_group_id);
sx_status_t flex_acl_db_get_vlan_group_bind(sx_acl_vlan_group_t         rif,
                                            sx_acl_direction_t          egress,
                                            flex_acl_bind_attribs_id_t *attribs_id);
sx_status_t flex_acl_db_vlan_group_bind(sx_acl_vlan_group_t        vlan_group,
                                        sx_acl_direction_t         egress,
                                        flex_acl_bind_attribs_id_t new_attribs_id);
sx_status_t flex_acl_db_vlan_group_unbind(sx_acl_vlan_group_t vlan_group,
                                          sx_acl_direction_t  egress);
sx_status_t flex_acl_db_validate_acl_vlan_group_bind(sx_access_cmd_t     cmd,
                                                     sx_acl_vlan_group_t vlan_group,
                                                     sx_acl_id_t         acl_id);
sx_status_t flex_acl_db_vlan_group_foreach(flex_acl_vlan_grp_db_pfn_t func, void *param_p);
sx_status_t flex_acl_db_vlan_group_entry_type_set(sx_acl_vlan_group_t group_id,  flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_db_vlan_group_entry_type_get(sx_acl_vlan_group_t group_id,  flex_acl_entry_type_e *entry_type);
sx_status_t flex_acl_db_get_vlan_attribs(sx_swid_id_t             swid,
                                         sx_vlan_id_t            *vlan_list,
                                         uint32_t                 vlan_num,
                                         flex_acl_vlan_attribs_t *vlan_attribs_arr);
typedef sx_status_t (*for_each_vlan_in_group_p_fn)(sx_acl_vlan_group_t group_id,
                                                   sx_swid_id_t        swid,
                                                   sx_vlan_id_t        vlan);
sx_status_t flex_acl_db_vlan_group_foreaach_vlan(sx_acl_vlan_group_t         group_id,
                                                 for_each_vlan_in_group_p_fn p_fn);
/* New API for bind attributes . The reserved attributes allocated at db init */
sx_status_t flex_acl_db_attribs_allocate(flex_acl_bind_attribs_id_t *attribs_id,
                                         sx_acl_direction_t          acl_direction,
                                         sx_acl_id_t                 group_id,
                                         boolean_t                   is_group_head);
sx_status_t flex_acl_db_attribs_free(flex_acl_bind_attribs_id_t attribs_id);
uint32_t flex_acl_db_attribs_free_count();
sx_status_t flex_acl_db_attribs_get(flex_acl_bind_attribs_id_t         attribs_id,
                                    flex_acl_db_group_bind_attribs_t **attribs);
sx_status_t flex_acl_db_attribs_get_count(uint32_t* attribs_used, uint32_t* total_attribs);
sx_status_t flex_acl_db_group_bind_log_port(flex_acl_db_acl_group_t *group, sx_port_log_id_t log_port);
sx_status_t flex_acl_db_group_unbind_log_port(flex_acl_db_acl_group_t *group, sx_port_log_id_t log_port);
sx_status_t flex_acl_db_group_bind_rif(flex_acl_db_acl_group_t *group, sx_rif_id_t rif);
sx_status_t flex_acl_db_group_unbind_rif(flex_acl_db_acl_group_t *group, sx_rif_id_t rif);
sx_status_t flex_acl_db_group_bind_vlan_group(flex_acl_db_acl_group_t *group, sx_acl_vlan_group_t vlan_group);
sx_status_t flex_acl_db_group_unbind_vlan_group(flex_acl_db_acl_group_t *group, sx_acl_vlan_group_t vlan_group);
sx_status_t flex_acl_db_attribs_bind_log_port(flex_acl_bind_attribs_id_t attribs_id, sx_port_log_id_t log_port);
sx_status_t flex_acl_db_attribs_unbind_log_port(flex_acl_bind_attribs_id_t attribs_id, sx_port_id_t log_port);
sx_status_t flex_acl_db_attribs_is_log_port_bound(flex_acl_bind_attribs_id_t attribs_id,
                                                  sx_port_id_t               log_port,
                                                  boolean_t                 *is_bound);
sx_status_t flex_acl_db_attribs_bind_lag(flex_acl_bind_attribs_id_t attribs_id, sx_port_log_id_t lag_port);
sx_status_t flex_acl_db_attribs_unbind_lag(flex_acl_bind_attribs_id_t attribs_id, sx_port_id_t lag_port);
sx_status_t flex_acl_db_attribs_is_lag_bound(flex_acl_bind_attribs_id_t attribs_id,
                                             sx_port_id_t               lag_port,
                                             boolean_t                 *is_bound);
sx_status_t flex_acl_db_attribs_bind_rif(flex_acl_bind_attribs_id_t attribs_id, sx_rif_id_t log_port);
sx_status_t flex_acl_db_attribs_unbind_rif(flex_acl_bind_attribs_id_t attribs_id, sx_rif_id_t log_port);
sx_status_t flex_acl_db_attribs_is_rif_bound(flex_acl_bind_attribs_id_t attribs_id,
                                             sx_rif_id_t                log_port,
                                             boolean_t                 *is_bound);
sx_status_t flex_acl_db_attribs_bind_vlan_group(flex_acl_bind_attribs_id_t attribs_id,
                                                sx_acl_vlan_group_t        vlan_group);
sx_status_t flex_acl_db_attribs_unbind_vlan_group(flex_acl_bind_attribs_id_t attribs_id,
                                                  sx_acl_vlan_group_t        vlan_group);
sx_status_t flex_acl_db_attribs_is_vlan_group_bound(flex_acl_bind_attribs_id_t attribs_id,
                                                    sx_acl_vlan_group_t        vlan_group,
                                                    boolean_t                 *is_bound);
sx_status_t flex_acl_db_attribs_bind_rule(flex_acl_bind_attribs_id_t attribs_id,
                                          sx_acl_region_id_t         region_id,
                                          sx_flex_acl_rule_offset_t  offset);
sx_status_t flex_acl_db_attribs_unbind_rule(flex_acl_bind_attribs_id_t attribs_id,
                                            sx_acl_region_id_t         region_id,
                                            sx_flex_acl_rule_offset_t  offset);
sx_status_t flex_acl_db_attribs_is_rule_bound(flex_acl_bind_attribs_id_t attribs_id,
                                              sx_acl_region_id_t         region_id,
                                              sx_flex_acl_rule_offset_t  offset,
                                              boolean_t                 *is_bound);
sx_status_t flex_acl_db_attribs_is_goto_target(flex_acl_bind_attribs_id_t attribs_id,
                                               boolean_t                 *is_target);

sx_status_t flex_acl_db_attribs_is_bound(flex_acl_bind_attribs_id_t attribs_id, boolean_t *is_bound);
sx_status_t flex_acl_db_attribs_foreach(flex_acl_bind_attributes_db_pfn_t func, void *param_p);


/* ACL group operations */
sx_status_t flex_acl_db_allocate_acl_group(sx_acl_id_t *group_id, sx_acl_direction_t acl_direction);
sx_status_t flex_acl_db_destroy_acl_group(sx_acl_id_t group_id);
sx_status_t flex_acl_db_get_acl_group(sx_acl_id_t group_id, flex_acl_db_acl_group_t **acl_group);
sx_status_t flex_acl_db_update_acl_group(sx_acl_id_t group_id, sx_acl_id_t *acl_ids, uint32_t acl_ids_num);
sx_status_t flex_acl_db_get_max_acl_groups(uint32_t * rm_acl_groups, uint32_t * allocated_groups);

boolean_t flex_acl_db_is_acl_group(sx_acl_id_t acl_id);
boolean_t flex_acl_db_is_acl_group_bound(sx_acl_id_t group_id);
sx_status_t flex_acl_db_acl_group_get_bind_attribs_id(sx_acl_id_t group_id, flex_acl_bind_attribs_id_t *attribs_id);
sx_status_t flex_acl_db_get_groups_head(sx_acl_id_t group_id, sx_acl_id_t *group_head_id);
sx_status_t flex_acl_db_get_group_by_attribs_id(flex_acl_bind_attribs_id_t attribs_id, sx_acl_id_t *acl_id);
sx_status_t flex_acl_db_get_acl_id_for_unbind(sx_acl_id_t group_id, sx_acl_id_t *acl_id);
sx_status_t flex_acl_db_group_bind_foreach(flex_acl_bind_group_db_pfn_t func, void* param_p);
/* bind - link operations between groups */
sx_status_t flex_acl_db_acl_group_bind_acl_group(sx_acl_id_t parent_group_id, sx_acl_id_t child_group_id);
sx_status_t flex_acl_db_acl_group_unbind_acl_group(sx_acl_id_t parent_group_id, sx_acl_id_t child_group_id);
sx_status_t flex_acl_db_acl_group_bind_group_get(sx_acl_id_t parent_group_id, sx_acl_id_t *child_group_id);
sx_status_t flex_acl_db_group_entry_type_set(sx_acl_id_t group_id, flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_db_group_entry_type_get(sx_acl_id_t acl_id, flex_acl_entry_type_e *entry_type);
sx_status_t flex_acl_db_group_rules_ref_cnt_update(sx_acl_id_t group_id, boolean_t increment, sdk_ref_t *reference);
sx_status_t flex_acl_db_group_rules_ref_cnt_get(sx_acl_id_t group_id, int32_t *ref_count);

/* Port operations */
sx_status_t flex_acl_db_port_bind(sx_port_id_t               log_port,
                                  sx_acl_direction_t         egress,
                                  flex_acl_bind_attribs_id_t new_attribs_id,
                                  boolean_t                  is_lag);

sx_status_t flex_acl_db_validate_port_bind(sx_port_id_t       log_port,
                                           sx_acl_direction_t egress,
                                           boolean_t          rebinding,
                                           boolean_t          is_lag);
sx_status_t flex_acl_db_get_port_bind(sx_port_id_t                log_port,
                                      sx_acl_direction_t          egress,
                                      flex_acl_bind_attribs_id_t* attribs_id,
                                      boolean_t                   is_lag);

sx_status_t flex_acl_db_port_unbind(sx_port_id_t log_port, sx_acl_direction_t egress, boolean_t is_lag);
sx_status_t flex_acl_db_port_acl_group_bind(sx_port_id_t       log_port,
                                            sx_acl_direction_t egress,
                                            boolean_t          is_lag,
                                            sx_acl_id_t        acl_group_id);
sx_status_t flex_acl_db_port_acl_group_unbind(sx_port_id_t       log_port,
                                              sx_acl_direction_t egress,
                                              boolean_t          is_lag,
                                              sx_acl_id_t        acl_group_id);
sx_status_t flex_acl_db_port_bound_groups_get(sx_port_id_t       log_port,
                                              sx_acl_direction_t egress,
                                              boolean_t          is_lag,
                                              sx_acl_id_t       *acl_group_id,
                                              uint32_t          *group_num);
boolean_t flex_acl_db_is_port_bound_group(sx_port_id_t       log_port,
                                          sx_acl_direction_t egress,
                                          boolean_t          is_lag,
                                          sx_acl_id_t        acl_group_id);

sx_status_t flex_acl_db_validate_nve_port_bind(sx_port_id_t       log_port,
                                               sx_acl_direction_t egress);
sx_status_t flex_acl_db_nve_port_bind(sx_port_id_t               log_port,
                                      flex_acl_bind_attribs_id_t new_attribs_id);
sx_status_t flex_acl_db_nve_port_unbind(sx_port_id_t log_port);
sx_status_t flex_acl_db_get_nve_port_bind(sx_port_id_t                log_port,
                                          flex_acl_bind_attribs_id_t *attribs_id);

/* Range operations */
sx_status_t flex_acl_db_port_range_get_available_idx(sx_acl_port_range_id_t* id);
sx_status_t flex_acl_db_port_range_get(sx_acl_port_range_id_t id, sx_acl_port_range_entry_t *port_range_p);
sx_status_t flex_acl_db_port_range_iter_get(const sx_access_cmd_t        access_cmd,
                                            const sx_acl_port_range_id_t key,
                                            sx_acl_port_range_filter_t  *filter,
                                            sx_acl_port_range_id_t      *list,
                                            uint32_t                    *cnt);

sx_status_t flex_acl_db_port_range_pre_edit(const sx_acl_port_range_id_t     id,
                                            const sx_acl_port_range_entry_t* port_range_p);
sx_status_t flex_acl_db_port_range_update(const sx_acl_port_range_id_t     id,
                                          const sx_acl_port_range_entry_t *port_range_p);
sx_status_t flex_acl_db_port_range_delete(sx_acl_port_range_id_t id);
sx_status_t flex_acl_db_port_range_update_ref_count(sx_acl_port_range_id_t idx, boolean_t increase, uint32_t value);
sx_status_t flex_acl_db_verify_port_ranges_exist(boolean_t *port_range_apply_arr);

sx_status_t flex_acl_db_range_get(sx_acl_port_range_id_t idx, sx_acl_range_entry_t *range_entry_p);
sx_status_t flex_acl_db_range_pre_edit(sx_acl_port_range_id_t idx, const sx_acl_range_entry_t* range_entry_p);
sx_status_t flex_acl_db_range_update(sx_acl_port_range_id_t idx, const sx_acl_range_entry_t *range_entry_p);
sx_status_t flex_acl_db_range_delete(sx_acl_port_range_id_t idx);

/* PBS handling */
sx_status_t flex_acl_db_pbs_set_entry(flex_acl_db_pbs_entry_t *pbs_entry, sx_acl_pbs_id_t *pbs_id);
sx_status_t flex_acl_db_pbs_get_entry(sx_swid_t swid, sx_acl_pbs_id_t pbs_id, flex_acl_db_pbs_entry_t **pbs_entry);
sx_status_t flex_acl_db_pbs_delete_entry(sx_swid_t swid, sx_acl_pbs_id_t pbs_id);
void flex_acl_db_pbs_get_count(sx_swid_t swid, uint32_t *pbs_cnt);
sx_status_t flex_acl_db_pbs_update_ref_count(sx_swid_t swid, sx_acl_pbs_id_t pbs_id, uint8_t increment);
sx_status_t flex_acl_db_pbs_foreach(flex_acl_pbs_db_pfn_t func, void *data);
sx_status_t flex_acl_db_pbs_add_rule_to_list(flex_acl_db_pbs_entry_t *pbs_entry, flex_acl_rule_id_t rule);
sx_status_t flex_acl_db_pbs_del_rule_from_list(flex_acl_db_pbs_entry_t *pbs_entry, flex_acl_rule_id_t rule);
sx_status_t flex_acl_db_pbs_by_kvd_handle(kvd_linear_manager_handle_t kvd_handle, flex_acl_db_pbs_entry_t **entry);
sx_status_t flex_acl_db_pbs_by_log_port(sx_port_log_id_t log_port, flex_acl_db_pbs_entry_t **entry);
sx_status_t flex_acl_db_get_is_parallel(boolean_t *is_parallel);

sx_status_t flex_acl_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t flex_acl_db_privilege_set(flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_db_privilege_get(flex_acl_entry_type_e * entry_type);

/* RX List handling*/
sx_status_t flex_acl_db_rx_list_create(sx_acl_port_list_entry_t* port_list_p,
                                       uint32_t                  port_list_count,
                                       sx_acl_port_list_id_t   * rx_list_id_p);
sx_status_t flex_acl_db_rx_list_get(sx_acl_port_list_id_t     rx_list_id,
                                    sx_acl_port_list_entry_t* port_list_p,
                                    uint32_t                * port_list_count_p,
                                    sx_port_type_t          * port_type_p);
sx_status_t flex_acl_db_rx_list_set(sx_acl_port_list_entry_t* port_list_p,
                                    uint32_t                  port_list_count,
                                    sx_acl_port_list_id_t     rx_list_id);
sx_status_t flex_acl_db_rx_list_set_port_type(sx_acl_port_list_id_t rx_list_id, sx_port_type_t port_type);
sx_status_t flex_acl_db_update_rules_ref_rx_list(sx_acl_port_list_id_t rx_list_id,
                                                 flex_acl_rule_id_t   *rule_id_p,
                                                 sx_access_cmd_t       cmd);
sx_status_t flex_acl_db_rx_list_rules_ref_list_get(sx_acl_port_list_id_t rx_list_id,
                                                   cl_qlist_t         ** rules_ref_set_list_p);
sx_status_t flex_acl_db_rx_list_destroy(sx_acl_port_list_id_t rx_list_id);
sx_status_t flex_acl_db_port_list_foreach(flex_acl_port_list_db_pfn_t func, void *param_p);
sx_status_t flex_acl_db_is_port_in_port_list(sx_port_id_t port_id);

/* PBS MC handling */
sx_status_t flex_acl_db_pbs_mc_create(sx_mc_container_id_t mc_id, sx_acl_pbs_id_t pbs_id,
                                      sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_mc_get(sx_mc_container_id_t           mc_id,
                                   sx_acl_pbs_id_t               *pbs_id_p,
                                   uint32_t                      *ref_count_p,
                                   sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_mc_ref_inc(sx_mc_container_id_t           mc_id,
                                       sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_mc_ref_dec(sx_mc_container_id_t           mc_id,
                                       sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_mc_destroy(sx_mc_container_id_t           mc_id,
                                       sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_iter_get(const sx_access_cmd_t access_cmd,
                                     const sx_swid_t       swid,
                                     const sx_acl_pbs_id_t key,
                                     sx_acl_pbs_filter_t  *filter_p,
                                     sx_acl_pbs_id_t      *list_p,
                                     uint32_t             *cnt_p);

/* PBS ECMP handling */
sx_status_t flex_acl_db_pbs_ecmp_create(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                        sx_acl_pbs_id_t                pbs_id,
                                        sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_ecmp_get(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                     sx_acl_pbs_id_t               *pbs_id_p,
                                     uint32_t                      *ref_count_p,
                                     sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_ecmp_ref_inc(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                         sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_ecmp_ref_dec(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                         sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_db_pbs_ecmp_destroy(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                         sx_flex_acl_flex_action_type_t api_action_type);


/* Port filter mc container and log ports handling */
sx_status_t flex_acl_db_log_port_to_mc_container_add(sx_port_id_t log_port_id);
sx_status_t flex_acl_db_log_port_to_mc_container_destroy(sx_port_id_t log_port_id);
sx_status_t flex_acl_db_log_port_to_mc_containers_ref_list_update(sx_port_id_t         log_port_id,
                                                                  sx_mc_container_id_t mc_container_id,
                                                                  sx_access_cmd_t      cmd);
sx_status_t flex_acl_db_log_port_to_mc_containers_ref_list_get(sx_port_id_t          log_port_id,
                                                               uint32_t             *mc_containers_ref_count,
                                                               sx_mc_container_id_t *mc_container_ref_list_p);
sx_status_t flex_acl_db_mc_container_to_log_port_add(sx_mc_container_id_t mc_container_id);
sx_status_t flex_acl_db_mc_container_to_log_port_destroy(sx_mc_container_id_t mc_container_id);
sx_status_t flex_acl_db_mc_container_to_log_ports_ref_list_update(sx_mc_container_id_t mc_container_id,
                                                                  sx_port_id_t         log_port_id,
                                                                  sx_access_cmd_t      cmd);
sx_status_t flex_acl_db_mc_container_to_log_ports_ref_list_get(sx_mc_container_id_t mc_container_id,
                                                               uint32_t            *log_ports_ref_count,
                                                               sx_port_id_t        *log_ports_ref_list_p);
sx_status_t flex_acl_db_mc_container_rule_ref_get(sx_mc_container_id_t mc_container_id, uint32_t* rule_ref_count);
sx_status_t flex_acl_db_mc_container_rule_ref_inc(sx_mc_container_id_t mc_container_id);
sx_status_t flex_acl_db_mc_container_rule_ref_dec(sx_mc_container_id_t mc_container_id);
sx_status_t flex_acl_db_mc_container_to_rule_refs_add(mcc_to_rule_type_e   type,
                                                      sx_mc_container_id_t mc_container_id,
                                                      flex_acl_rule_id_t  *rule_id_p);
sx_status_t flex_acl_db_mc_container_to_rule_refs_delete(mcc_to_rule_type_e   type,
                                                         sx_mc_container_id_t mc_container_id,
                                                         flex_acl_rule_id_t  *rule_id_p);
sx_status_t flex_acl_db_mc_container_to_rule_refs_foreach(mcc_to_rule_type_e type,
                                                          sx_mc_container_id_t mc_container_id,
                                                          flex_acl_db_mcc_rule_pfn_t func, void *data);

/* PBILM handling */
sx_status_t flex_acl_db_pbilm_set_entry(flex_acl_db_pbilm_entry_t *pbilm_entry_src, sx_acl_pbilm_id_t* pbilm_id);
sx_status_t flex_acl_db_pbilm_delete_entry(sx_acl_pbilm_id_t pbilm_id);
sx_status_t flex_acl_db_pbilm_get_entry(sx_acl_pbilm_id_t pbilm_id, flex_acl_db_pbilm_entry_t **pbilm_entry);
sx_status_t flex_acl_db_pbilm_get_entry_by_kvd(kvd_linear_manager_handle_t kvd_handle,
                                               flex_acl_db_pbilm_entry_t **pbilm_entry);
sx_status_t flex_acl_db_pbilm_foreach(flex_acl_pbilm_db_pfn_t func, void *data);
sx_status_t flex_acl_db_pbilm_ref_inc(sx_acl_pbilm_id_t pbilm_id);
sx_status_t flex_acl_db_pbilm_ref_dec(sx_acl_pbilm_id_t pbilm_id);

/* PBS NVE Tunnel handling */
sx_status_t flex_acl_db_pbs_nve_create(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id, sx_acl_pbs_id_t pbs_id);
sx_status_t flex_acl_db_pbs_nve_get(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id,
                                    sx_acl_pbs_id_t           *pbs_id_p,
                                    uint32_t                  *ref_count_p);
sx_status_t flex_acl_db_pbs_nve_ref_inc(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id);
sx_status_t flex_acl_db_pbs_nve_ref_dec(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id);
sx_status_t flex_acl_db_pbs_nve_destroy(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id);

/* System ACL Group ID mapping to System ACL client ID and instance */
sx_status_t flex_acl_db_system_acl_group_client_add(sx_acl_id_t            group_id,
                                                    system_acl_client_id_e client_id,
                                                    uint32_t               instance);
sx_status_t flex_acl_db_system_acl_group_client_delete(sx_acl_id_t group_id);
sx_status_t flex_acl_db_system_acl_group_client_get(sx_acl_id_t             group_id,
                                                    system_acl_client_id_e *client_id,
                                                    uint32_t               *instance);
sx_status_t flex_acl_db_rules_priority_set(sx_acl_region_id_t          region_id,
                                           sx_flex_acl_rule_priority_t max_priority,
                                           sx_flex_acl_rule_priority_t min_priority,
                                           int32_t                     priority_change);

void flex_acl_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

/* redirection db */
typedef struct {
    sx_acl_region_id_t   region_id;
    sx_acl_action_type_t action_type;
} flex_acl_region_action_type_entry_t;

typedef struct {
    boolean_t inited;
    cl_list_t action_type_list;
    cl_list_t trap_group_list;
} flex_acl_redirection_db_t;

void flex_acl_deinit_redirection_db();
sx_status_t flex_acl_db_init_redirection_db(uint32_t list_min_items);
sx_status_t flex_acl_redirect_db_add_region(sx_acl_region_id_t region_id, sx_acl_action_type_t action_type);
void flex_acl_redirection_get_region_record(sx_acl_region_id_t region_id, sx_acl_action_type_t *action_type);
sx_status_t flex_acl_redirect_db_remove_region_entry(sx_acl_region_id_t region_id);
sx_status_t flex_acl_redirect_db_add_trap_group(uint16_t trap_id, uint8_t trap_group);
void flex_acl_redirection_get_trap_group(uint16_t trap_id, uint8_t *trap_group);
sx_status_t flex_acl_redirect_db_remove_trap_group(uint16_t trap_id);

sx_status_t flex_acl_db_get_system_acl_group(sx_acl_direction_t direction, sx_acl_id_t *group_id);
sx_status_t flex_acl_db_set_system_acl_group(sx_acl_id_t group_id, sx_acl_direction_t direction);

sx_status_t flex_acl_db_rule_get_goto_action(flex_acl_db_flex_rule_t *rule, boolean_t *is_found,
                                             sx_flex_acl_flex_action_goto_t *goto_action);

sx_status_t flex_acl_db_bind_attribs_rule_ref_update(flex_acl_bind_attribs_id_t attribs_id,
                                                     flex_acl_rule_id_t        *rule_id_p);                            /* adds  rule identifier to bind attributes */
sx_status_t flex_acl_db_bind_attribs_rule_ref_list_get(flex_acl_bind_attribs_id_t attribs_id, cl_list_t* rules_list); /* return  list of referenced rules */


/* Bit map of ids, stores bit array in length num_of_items/8 bytes */
typedef struct flex_acl_db_id_bitmap {
    uint8_t *id_bitmap;
    uint32_t num_of_bytes;
} flex_acl_db_id_bitmap_t;

sx_status_t flex_acl_db_id_bitmap_init(flex_acl_db_id_bitmap_t *id_map, uint32_t num_of_items);
void flex_acl_db_id_bitmap_deinit(flex_acl_db_id_bitmap_t *id_map);
sx_status_t flex_acl_db_id_bitmap_clear(flex_acl_db_id_bitmap_t *id_map);
sx_status_t flex_acl_db_id_bitmap_set(flex_acl_db_id_bitmap_t *id_map, uint32_t id);
sx_status_t flex_acl_db_id_bitmap_get(flex_acl_db_id_bitmap_t *id_map, uint32_t id, boolean_t *is_set);

/* stack of ids(stores uint32_t) for internal purposes */
typedef struct flex_acl_db_id_stack {
    uint32_t *stack_p;
    uint32_t  size;
    uint32_t  head;
} flex_acl_db_id_stack_t;

sx_status_t flex_acl_db_id_stack_init(flex_acl_db_id_stack_t *stack, uint32_t size);
void flex_acl_db_id_stack_deinit(flex_acl_db_id_stack_t *stack);
sx_status_t flex_acl_db_id_stack_reset(flex_acl_db_id_stack_t *stack);
sx_status_t flex_acl_db_id_stack_push(flex_acl_db_id_stack_t *stack, uint32_t id);
sx_status_t flex_acl_db_id_stack_pop(flex_acl_db_id_stack_t *stack, uint32_t *id);

/* internal structure to track goto action validation */
typedef struct flex_acl_db_goto_validation_params {
    flex_acl_db_id_stack_t  groups_to_visit_stack;
    flex_acl_db_id_bitmap_t groups_to_visit_map;
    flex_acl_db_id_bitmap_t forbidden_groups_map;
} flex_acl_db_goto_validation_params_t;

sx_status_t flex_acl_db_goto_validation_init(flex_acl_db_goto_validation_params_t *validation_params,
                                             uint32_t                              num_of_groups);
void flex_acl_goto_validation_denit(flex_acl_db_goto_validation_params_t *validation_params);

sx_status_t flex_acl_db_egress_mirror_actions_count_inc(sx_acl_region_id_t region_id);
sx_status_t flex_acl_db_egress_mirror_actions_count_dec(sx_acl_region_id_t region_id);
sx_status_t flex_acl_db_egress_mirror_actions_count_get(sx_acl_region_id_t region_id, uint32_t *count);

sx_status_t flex_acl_db_get_default_vlan_group_id(sx_acl_vlan_group_t *group_id);
sx_status_t flex_acl_db_system_acl_vlan_group_init(sx_acl_vlan_group_t group_id, uint32_t num_of_vid_ids);
sx_status_t flex_acl_db_system_acl_vlan_group_deinit(sx_acl_vlan_group_t *vlan_group_id);
sx_status_t flex_acl_db_system_acl_vlan_ref_count_update(boolean_t increment);
sx_status_t flex_acl_db_system_acl_vlan_ref_count_get(uint32_t *refcount);

sx_status_t flex_acl_db_system_vlan_group_add_entry(sx_swid_id_t swid, system_acl_client_id_e client_id, uint32_t vid);
sx_status_t flex_acl_db_system_vlan_group_remove_entry(sx_swid_id_t           swid,
                                                       system_acl_client_id_e client_id,
                                                       uint32_t               vid);
sx_status_t system_vlan_entries_list_get(sx_swid_id_t swid, uint32_t vid, cl_list_t **list_of_vlan_entries);
sx_status_t flex_acl_db_system_vlan_is_vlan_set(sx_swid_id_t swid, uint32_t vid, boolean_t *is_set);
sx_status_t flex_acl_db_for_each_vlan_entry(pool_map_apply_on_each_p_fn func_p, void* context);
sx_status_t flex_acl_db_custom_bytes_create_extraction_points(
    sx_acl_custom_bytes_set_attributes_t *custom_bytes_set_attributes_p,
    flex_acl_extraction_point_t          *extraction_points_p,
    uint32_t                             *extraction_points_count_p);

sx_status_t flex_acl_db_custom_bytes_set_create(sx_acl_custom_bytes_extraction_group_type_t extraction_group_type,
                                                uint32_t                                    extraction_points_count,
                                                flex_acl_extraction_point_t                *flex_acl_db_extraction_points_p,
                                                acl_custom_bytes_set_id_e                  *custom_byte_set_id);

sx_status_t flex_acl_db_custom_bytes_set_edit(acl_custom_bytes_set_id_e                   custom_bytes_set_id,
                                              sx_acl_custom_bytes_extraction_group_type_t extraction_group_type,
                                              uint32_t                                    extraction_points_count,
                                              flex_acl_extraction_point_t                *extraction_points_p);

sx_status_t flex_acl_db_custom_bytes_set_delete(acl_custom_bytes_set_id_e custom_byte_set_id);

sx_status_t flex_acl_db_custom_bytes_set_get(acl_custom_bytes_set_id_e             custom_byte_set_id,
                                             sx_acl_custom_bytes_set_attributes_t *custom_bytes_set_attributes_p);

sx_status_t flex_acl_db_custom_bytes_set_ref_inc(acl_custom_bytes_set_id_e custom_byte_set_id);
sx_status_t flex_acl_db_custom_bytes_set_ref_dec(acl_custom_bytes_set_id_e custom_byte_set_id);
sx_status_t flex_acl_db_custom_bytes_set_ref_get(acl_custom_bytes_set_id_e custom_byte_set_id, uint32_t *count);
sx_status_t flex_acl_db_custom_bytes_set_is_used(boolean_t *is_in_used_p);

sx_status_t flex_acl_db_update_acl_bound_group_list(sx_acl_id_t acl_id, sx_acl_id_t group_id, sx_access_cmd_t cmd);
sx_status_t flex_acl_db_group_in_acl_bound_group_list(sx_acl_id_t acl_id, sx_acl_id_t group_id,
                                                      boolean_t *is_in_group);

sx_status_t flex_acl_db_system_acl_binding_point_add(sx_acl_direction_t     direction,
                                                     flex_acl_bind_point_id bind_point_id,
                                                     sx_acl_id_t            group_id,
                                                     boolean_t              rebind);
sx_status_t flex_acl_db_system_acl_binding_point_delete(sx_acl_direction_t     direction,
                                                        flex_acl_bind_point_id bind_point_id);
sx_status_t flex_acl_db_system_acl_binding_point_get(sx_acl_direction_t     direction,
                                                     flex_acl_bind_point_id bind_point_id,
                                                     sx_acl_id_t           *group_id);

sx_status_t flex_acl_db_binding_point_group_add(sx_acl_direction_t     direction,
                                                flex_acl_bind_point_id bind_point_id,
                                                sx_acl_id_t            group_id);

sx_status_t flex_acl_db_binding_point_group_delete(sx_acl_direction_t     direction,
                                                   flex_acl_bind_point_id bind_point_id,
                                                   sx_acl_id_t            group_id);

sx_status_t flex_acl_db_binding_point_groups_get(sx_acl_direction_t     direction,
                                                 flex_acl_bind_point_id bind_point_id,
                                                 sx_acl_id_t           *group_ids,
                                                 uint32_t              *group_num);

sx_status_t flex_acl_db_binding_point_bind_group_set(sx_acl_direction_t     direction,
                                                     flex_acl_bind_point_id bind_point_id,
                                                     sx_acl_id_t            bind_group);

sx_status_t flex_acl_db_binding_point_bind_group_get(sx_acl_direction_t     direction,
                                                     flex_acl_bind_point_id bind_point_id,
                                                     sx_acl_id_t           *bind_group);

sx_status_t flex_acl_db_initial_activity_set(sx_acl_region_id_t region_id, boolean_t activity_cleared);

const char* flex_acl_get_dump_action(sx_flex_acl_flex_action_type_t action);
sx_status_t flex_acl_db_get_iteration_start_and_step(uint32_t *start_p, uint32_t *step_p);
sx_status_t flex_acl_db_acl_drop_trap_monitor_state_get(sx_acl_id_t acl_id, boolean_t *monitor_state);
sx_status_t flex_acl_db_acl_attributes_set(sx_acl_id_t acl_id, sx_acl_attributes_t *acl_attributes_p);
sx_status_t flex_acl_db_acl_attributes_get(sx_acl_id_t acl_id, sx_acl_attributes_t *acl_attributes_p);
sx_status_t flex_acl_db_acl_grp_attributes_set(sx_acl_id_t group_id, sx_acl_group_attributes_t *acl_grp_attributes_p);
sx_status_t flex_acl_db_acl_grp_attributes_get(sx_acl_id_t group_id, sx_acl_group_attributes_t *acl_grp_attributes_p);
sx_status_t flex_acl_db_acl_global_attr_set(sx_acl_global_attributes_t *acl_global_attr_p);
sx_status_t flex_acl_db_acl_global_attr_get(sx_acl_global_attributes_t *acl_global_attr_p);

sx_status_t flex_acl_db_hw_groups_set(sx_acl_id_t group_id);
sx_status_t flex_acl_db_hw_group_get(sx_acl_direction_t    direction,
                                     acl_id_group_entry_t *acl_ids,
                                     uint32_t              acl_nums,
                                     sx_acl_id_t          *group_id);
sx_status_t flex_acl_db_hw_group_put(sx_acl_id_t group_id,
                                     boolean_t  *remove);
sx_status_t flex_acl_db_group_rif_ref_set(sx_access_cmd_t          cmd,
                                          flex_acl_db_acl_group_t *group,
                                          sx_rif_id_t              rif,
                                          sdk_ref_t                ref);
sx_status_t flex_acl_db_group_rif_ref_get(flex_acl_db_acl_group_t *group, sx_rif_id_t rif, sdk_ref_t *ref);

sx_status_t flex_acl_db_action_container_add(void *hw_action_handle, sx_acl_action_container_id_t *container_id_p);
sx_status_t flex_acl_db_action_container_delete(sx_acl_action_container_id_t container_id);
sx_status_t flex_acl_db_action_container_kvd_index_reloc(const kvd_linear_manager_index_t old_index,
                                                         const kvd_linear_manager_index_t new_index);
sx_status_t flex_acl_db_action_container_get_by_kvd_index(kvd_linear_manager_index_t    kvd_index,
                                                          sx_acl_action_container_id_t *container_id_p);

sx_status_t flex_acl_db_activity_notify_set(const sx_access_cmd_t              cmd,
                                            const sx_access_cmd_t              notification_cmd,
                                            sx_flex_acl_activity_notify_attr_t activity_notify_attr);
sx_status_t flex_acl_db_activity_notify_get(boolean_t                          *in_progress_p,
                                            sx_access_cmd_t                    *cmd_p,
                                            sx_flex_acl_activity_notify_attr_t *activity_notify_attr_p);
void span_mt_list_to_flex_action_cond_mirror_bitmap(sx_span_mirror_trigger_disallow_list_t       *span_mt_list,
                                                    sxd_ignore_flex_action_cond_mirroring_type_t *flex_mt_bitmap);
sx_status_t flex_acl_db_get_acl_stage_from_key_handle(sx_acl_key_type_t key_handle,
                                                      acl_stage_e      *acl_stage_p);

sx_status_t flex_acl_db_group_bind_rbb_rule(sx_acl_rbb_rule_offset_e rbb_rule, flex_acl_db_acl_group_t *group_p);
sx_status_t flex_acl_db_group_unbind_rbb_rule(sx_acl_rbb_rule_offset_e rbb_rule, flex_acl_db_acl_group_t *group_p);
sx_status_t flex_acl_db_attribs_bind_rbb_rule(flex_acl_bind_attribs_id_t attribs_id,
                                              sx_acl_rbb_rule_offset_e   rbb_rule);
sx_status_t flex_acl_db_attribs_unbind_rbb_rule(flex_acl_bind_attribs_id_t attribs_id,
                                                sx_acl_rbb_rule_offset_e   rbb_rule);
sx_status_t flex_acl_db_attribs_is_rbb_rule_bound(flex_acl_bind_attribs_id_t attribs_id,
                                                  sx_acl_rbb_rule_offset_e   rbb_rule,
                                                  boolean_t                 *is_bound_p);

#endif /* FLEX_ACL_DB_H_ */
