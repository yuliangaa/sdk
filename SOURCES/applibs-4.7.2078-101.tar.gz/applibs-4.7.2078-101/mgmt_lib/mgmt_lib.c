/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_mem.h>
#include <sx/sdk/sx_strings.h>
#include <sx/sdk/sx_port_id.h>
#include <sx/sxd/sxd_dpt.h>
#include "sx_api/sx_api_internal.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "sx_core/sx_core_api.h"
#include "ethl2/fdb_common.h"
#include "ethl2/port.h"
#include "utils/sx_mem.h"
#include "ethl2/port_db.h"
#include "mgmt_lib.h"
#include "sx_mgmt_lib/mgmt_lib_common.h"
#include <errno.h>
#include <dlfcn.h>

#undef __MODULE__
#define __MODULE__ MGMT_LIB

/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t rm_resource_global;
extern uint8_t        port_post_init_done_s;
extern boolean_t      event_timer_handler_exit_signal_issued;
/************************************************
 *  Local variables
 ***********************************************/
#ifndef SPECTRUM_SWID
#define SPECTRUM_SWID 0
#endif

#ifndef SX_GENERATE_STRING
#define SX_GENERATE_STRING(ENUM, STR) STR,
#endif

#ifndef SX_GENERATE_ENUM
#define SX_GENERATE_ENUM(ENUM, STR) ENUM,
#endif

#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

#define MGMT_LIB_IS_MODULE_SENSOR_ID(sensor_id) SX_CHECK_RANGE(64, sensor_id, 255)

#define SLOT_DEVICE_SENSOR_INDEX_OFFSET         256
#define MGMT_LIB_EVENT_TIMER_TICK_IN_MSEC       100
#define MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_1 1   /* MGMT_LIB_EVENT_TIMER_TICK_IN_MSEC*/
#define MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_2 (2 * MGMT_LIB_EVENT_TIMER_TICK_IN_MSEC)
#define MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_3 (10 * MGMT_LIB_EVENT_TIMER_TICK_IN_MSEC)
#define BILLION                                 1000000000L
#define SX_MGMT_LIB_PMAOS_DOWN_DELAY_IN_MSEC    700

typedef enum sxd_card_type {
    SXD_CARD_TYPE_MSN_4_400G_E,
    SXD_CARD_TYPE_MSN_8_200G_E,
    SXD_CARD_TYPE_MSN_16_100G_E,
    SXD_CARD_TYPE_MIN = SXD_CARD_TYPE_MSN_4_400G_E,
    SXD_CARD_TYPE_MAX = SXD_CARD_TYPE_MSN_16_100G_E
} sxd_card_type_t;


typedef enum sxd_mddc_control_oper {
    SXD_MDDC_CONTROL_OPER_SOFT_RESET_E = 1,
    SXD_MDDC_CONTROL_OPER_MIN          = SXD_MDDC_CONTROL_OPER_SOFT_RESET_E,
    SXD_MDDC_CONTROL_OPER_MAX          = SXD_MDDC_CONTROL_OPER_SOFT_RESET_E
} sxd_mddc_control_oper_t;

typedef enum sxd_pmtdb_status {
    SXD_PMTDB_STATUS_SUCCESS_E,
    SXD_PMTDB_STATUS_EXCEED_MODULE_WIDTH_E,
    SXD_PMTDB_STATUS_MODULE_NOT_INSTANTIATED_E,
    SXD_PMTDB_STATUS_PORTS_COMBINATION_NOT_ALLOWED,
    SXD_PMTDB_STATUS_MIN = SXD_PMTDB_STATUS_SUCCESS_E,
    SXD_PMTDB_STATUS_MAX = SXD_PMTDB_STATUS_PORTS_COMBINATION_NOT_ALLOWED
} sxd_pmtdb_status_t;

typedef enum sxd_mtmp_e {
    SXD_MTMP_E_DO_NOT_GENERATE_EVENT_E = 0x0,
    SXD_MTMP_E_GENERATE_EVENT_E        = 0x1,
    SXD_MTMP_E_GENERATE_SINGLE_EVENT_E = 0x2
} sxd_mtmp_e_t;


typedef enum sx_mgmt_ev_handling_mode {
    FAST_E,
    MEDIUM_E,
    SLOW_E
} sx_mgmt_ev_handling_mode_e;

typedef struct port_module_event {
    int                        timeout_in_ticks;
    sx_mgmt_ev_handling_mode_e handling_mode;
    struct timespec            timestamp;
    sx_dev_id_t                dev_id;
    int                        module_id;
    sx_slot_id_t               slot_id;
    sx_port_module_state_t     last_oper_state;
    boolean_t                  event_disabled;
} port_module_event_t;

#define CHECK_MGMT_LIB_INIT_DONE                                                               \
    if (!__is_mgmt_lib_initialized_g) {                                                        \
        SX_LOG_ERR("Management lib module is not initialized, err[%s]\n", sx_status_str(err)); \
        err = SX_STATUS_MODULE_UNINITIALIZED;                                                  \
        goto out;                                                                              \
    }

/************************************************
 *  Global variables
 ***********************************************/
static void                * __mgmt_lib_handle = NULL;
static mgmt_lib_ctxt_t       __mgmt_ctx_g;
static boolean_t             __is_mgmt_lib_initialized_g = FALSE;
static port_module_event_t **port_module_ev_list = NULL;
static sx_add_intern_job_cb  __add_internal_job_cb_s = NULL;
static sxd_handle            __g_mgmt_lib_device_handle;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __mgmt_lib_update_ctxt_system_info();
static sx_mgmt_slot_card_type_e __conv_sxd_to_sx_mgmt_slot_card_type(uint8_t card_type);
static sx_status_t __mgmt_lib_mapping_status_changed_ports_get(
    sx_mgmt_slot_ini_operation_result_t *ini_operation_result_p);
static sx_status_t __mgmt_lib_fetch_port_map_attributes(sx_port_phy_id_t local_port, sx_port_attributes_t *port_attr);
static sx_status_t __mgmt_lib_is_module_id_valid(sx_slot_id_t slot_id, sx_port_mod_id_t module_id,
                                                 boolean_t *is_valid);
static sx_status_t __mgmt_lib_fetch_hw_ini_status(sx_slot_id_t           slot_id,
                                                  sxd_mbct_ini_status_t *ini_status_p,
                                                  sxd_mbct_status_t     *ini_oper_status_p,
                                                  sxd_mbct_fsm_state_t  *hw_ini_fsm_state_p);
/* This function checks the module_status_bits in MCION register to know if module is present. */
static sx_status_t __mgmt_lib_is_module_present(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                boolean_t                      *is_module_present_p);

/* This function checks if any of the ports associated with the module is admin enabled,
 * The generate_error_log flag dictates if error log needs to be generated or not.
 */
static sx_status_t __mgmt_lib_is_module_logport_admin_enabled(sx_device_id_t                  dev_id,
                                                              const sx_mgmt_module_id_info_t *module_id_info_p,
                                                              boolean_t                      *is_admin_enabled_p,
                                                              boolean_t                       generate_error_log);
/* This function reads PMAOS register and returns module operational state and error type if any*/
static sx_status_t __mgmt_lib_phy_module_status_get(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                    sx_mgmt_phy_module_state_t     *module_status_p);

/* This function gets the number of modules in a given slot. */
static sx_status_t __mgmt_lib_get_slot_modules_count(sx_slot_id_t slot_id, uint32_t *module_count_p);

/* This function gets the cable type of a given module. */
static sx_status_t __mgmt_lib_get_module_cable_type(sx_mgmt_module_id_info_t *module_id_info_p,
                                                    sxd_pddr_cable_type_t    *cable_p);

/* This function checks if a given module type is backplane or not */
static sx_status_t __is_module_type_backplane(sx_mgmt_phy_module_type_e module_type,
                                              boolean_t                *is_back_plane_p);
static sx_status_t __mgmt_lib_is_module_backplane_type(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                       boolean_t                      *is_backplane_p,
                                                       boolean_t                      *is_twisted_pair_p);

/* This function sends internal event to enable phy module events in SDK main thread context */
static sx_status_t __mgmt_lib_module_status_event_send(const sx_dev_id_t              dev_id,
                                                       const sx_slot_id_t             slot_id,
                                                       const sx_port_mod_id_t         module_id,
                                                       const sx_event_generate_mode_t event_mode,
                                                       sx_port_oper_state_t           last_oper_state);
/* This function is used to retrieves the system timestamp */
static sx_status_t __mgmt_lib_event_set_timestamp(struct timespec *timestamp);
/* Retrieve last operational status of a modules */
static sx_status_t __mgmt_lib_get_module_last_oper_state(sx_slot_id_t            slot_id,
                                                         uint32_t                module_id,
                                                         sx_port_module_state_t *last_module_state_p);

static unsigned long long __mgmt_lib_event_get_time_msec_delta(struct timespec *timestamp);

static sx_port_module_state_t __sx_mgmt_module_status(sxd_pmaos_oper_status_t pmaos_oper_status);
static sx_status_t __mgmt_lib_dump_slot_info(dbg_dump_params_t *dbg_dump_params_p, uint32_t slot_count);
static sx_status_t __mgmt_lib_dump_slot_description_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                         sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                         uint32_t             slot_count);
static sx_status_t __mgmt_lib_dump_slot_device_description_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                                sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                                uint32_t             slot_count);
static sx_status_t __mgmt_lib_dump_slot_device_firmware_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                             sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                             uint32_t             slot_count);
static sx_status_t __mgmt_lib_dump_slot_device_sensor_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                           sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                           uint32_t             slot_count);
/*****************************************************************************************************
 * Local functions
 * For all static helper functions, parameters are not validated. So the calling function must ensure
 * all params are valid/not null.
 ******************************************************************************************************/

static sx_mgmt_slot_card_type_e __conv_sxd_to_sx_mgmt_slot_card_type(uint8_t card_type)
{
    switch (card_type) {
    case SXD_CARD_TYPE_MSN_4_400G_E:
        return SX_MGMT_SLOT_CARD_TYPE_MSN_4_400G_E;

    case SXD_CARD_TYPE_MSN_8_200G_E:
        return SX_MGMT_SLOT_CARD_TYPE_MSN_8_200G_E;

    case SXD_CARD_TYPE_MSN_16_100G_E:
        return SX_MGMT_SLOT_CARD_TYPE_MSN_16_100G_E;

    default:
        return SX_MGMT_SLOT_CARD_TYPE_INVALID_E;
    }
}

static sx_mgmt_slot_ini_status_e __conv_sxd_to_sx_mgmt_slot_ini_status(sxd_mbct_ini_status_t status)
{
    switch (status) {
    case SXD_MBCT_INI_STATUS_EMPTY_NOT_VALID_E:
        return SX_MGMT_SLOT_INI_STATUS_NOT_VALID_E;

    case SXD_MBCT_INI_STATUS_VALID_E:
        return SX_MGMT_SLOT_INI_STATUS_VALID_E;

    case SXD_MBCT_INI_STATUS_READY_TO_USE_E:
        return SX_MGMT_SLOT_INI_STATUS_READY_TO_USE_E;

    case SXD_MBCT_INI_STATUS_IN_USE_E:
        return SX_MGMT_SLOT_INI_STATUS_IN_USE_E;

    default:
        return SX_MGMT_SLOT_INI_STATUS_NOT_VALID_E;
    }
}

static sx_mgmt_slot_ini_oper_status_e __conv_sxd_to_sx_mgmt_slot_ini_oper_status(sxd_mbct_status_t status)
{
    switch (status) {
    case SXD_MBCT_STATUS_NA_E:
        return SX_MGMT_SLOT_INI_OPER_NONE_STATUS_IDLE_E;

    case SXD_MBCT_STATUS_BUSY_E:
        return SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_BUSY_E;

    case SXD_MBCT_STATUS_PARTIAL_E:
        return SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_READY_NEXT_XFER_E;

    case SXD_MBCT_STATUS_LAST_DATA_E:
        return SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_LAST_XFER_READY_APPLY_E;

    case SXD_MBCT_STATUS_ERASE_IS_COMPLETE_E:
        return SX_MGMT_SLOT_INI_OPER_ERASE_STATUS_COMPLETE_E;

    case SXD_MBCT_STATUS_ERROR_ATTEMPTED_ERASE_INI_IN_USE_E:
        return SX_MGMT_SLOT_INI_OPER_ERASE_STATUS_FAILURE_IN_USE_E;

    case SXD_MBCT_STATUS_TRANSFER_FAILURE_E:
        return SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_FAILURE_E;

    case SXD_MBCT_STATUS_ERASE_FAILURE_E:
        return SX_MGMT_SLOT_INI_OPER_ERASE_STATUS_FAILURE_E;

    case SXD_MBCT_STATUS_INI_ERROR_E:
        return SX_MGMT_SLOT_INI_OPER_TRANSFER_STATUS_INI_ERROR_E;

    case SXD_MBCT_STATUS_ACTIVATION_OF_INI_FAILED_E:
        return SX_MGMT_SLOT_INI_OPER_ACTIVATION_STATUS_ERROR_E;

    case SXD_MBCT_STATUS_DEACTIVATION_OF_INI_FAILED_E:
        return SX_MGMT_SLOT_INI_OPER_DEACTIVATION_STATUS_ERROR_E;

    case SXD_MBCT_STATUS_ERROR_ILLEGAL_OPERATION_E:
        return SX_MGMT_SLOT_INI_OPER_ILLEGAL_ERROR_E;

    default:
        return SX_MGMT_SLOT_INI_OPER_NONE_STATUS_IDLE_E;
    }
}

static sx_mgmt_phy_module_type_e __conv_sxd_to_sx_mgmt_phy_module_type(sxd_pmtm_module_type_t module_type)
{
    switch (module_type) {
    case SXD_PMTM_MODULE_TYPE_BACKPLANE_WITH_4_LANES_E:
        return SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_4X_E;

    case SXD_PMTM_MODULE_TYPE_QSFP_E:
        return SX_MGMT_PHY_MODULE_TYPE_QSFP_E;

    case SXD_PMTM_MODULE_TYPE_SFP_E:
        return SX_MGMT_PHY_MODULE_TYPE_SFP_E;

    case SXD_PMTM_MODULE_TYPE_BACKPLANE_WITH_SINGLE_LANE_E:
        return SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_1X_E;

    case SXD_PMTM_MODULE_TYPE_BACKPLANE_WITH_TWO_LANES_E:
        return SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_2X_E;

    case SXD_PMTM_MODULE_TYPE_CHIP2CHIP4X_E:
        return SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_4X_E;

    case SXD_PMTM_MODULE_TYPE_CHIP2CHIP2X_E:
        return SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_2X_E;

    case SXD_PMTM_MODULE_TYPE_CHIP2CHIP1X_E:
        return SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_1X_E;

    case SXD_PMTM_MODULE_TYPE_QSFP_DD_E:
        return SX_MGMT_PHY_MODULE_TYPE_QSFP_DD_E;

    case SXD_PMTM_MODULE_TYPE_OSFP_E:
        return SX_MGMT_PHY_MODULE_TYPE_OSFP_E;

    case SXD_PMTM_MODULE_TYPE_SFP_DD_E:
        return SX_MGMT_PHY_MODULE_TYPE_SFP_DD_E;

    case SXD_PMTM_MODULE_TYPE_DSFP_E:
        return SX_MGMT_PHY_MODULE_TYPE_DSFP_E;

    case SXD_PMTM_MODULE_TYPE_CHIP2CHIP8X_E:
        return SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_8X_E;

    case SXD_PMTM_MODULE_TYPE_TWISTED_PAIR_E:
        return SX_MGMT_PHY_MODULE_TYPE_TWISTED_PAIR_E;

    case SXD_PMTM_MODULE_TYPE_BACKPLANE_WITH_8_LANES_E:
        return SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_8X_E;

    default:
        return SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_4X_E;
    }
}
static sx_mgmt_phy_module_cable_type_e __conv_sxd_to_sx_mgmt_phy_module_cable_type(sxd_pddr_cable_type_t cable_type)
{
    switch (cable_type) {
    case SXD_PDDR_CABLE_TYPE_UNIDENTIFIED_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_UNIDENTIFIED_E;

    case SXD_PDDR_CABLE_TYPE_ACTIVE_CABLE_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_ACTIVE_E;

    case SXD_PDDR_CABLE_TYPE_OPTICAL_MODULE_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_OPTICAL_MODULE_E;

    case SXD_PDDR_CABLE_TYPE_PASSIVE_COPPER_CABLE_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_PASSIVE_COPPER_E;

    case SXD_PDDR_CABLE_TYPE_CABLE_UNPLUGGED_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_UNPLUGGED_E;

    case SXD_PDDR_CABLE_TYPE_TWISTED_PAIR_E:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_TWISTED_PAIR_E;

    default:
        return SX_MGMT_PHY_MODULE_CABLE_TYPE_UNIDENTIFIED_E;
    }
}
static sx_port_module_state_t __sx_mgmt_module_status(sxd_pmaos_oper_status_t pmaos_oper_status)
{
    switch (pmaos_oper_status) {
    case SXD_PMAOS_OPER_STATUS_INITIALIZING_E:
        return SX_PORT_MODULE_STATUS_INITIALIZING;

    case SXD_PMAOS_OPER_STATUS_PLUGGED_ENABLED_E:
        return SX_PORT_MODULE_STATUS_PLUGGED;

    case SXD_PMAOS_OPER_STATUS_UNPLUGGED_E:
        return SX_PORT_MODULE_STATUS_UNPLUGGED;

    case SXD_PMAOS_OPER_STATUS_MODULE_PLUGGED_WITH_ERROR_E:
        return SX_PORT_MODULE_STATUS_PLUGGED_WITH_ERROR;

    case SXD_PMAOS_OPER_STATUS_PLUGGED_DISABLED_E:
        return SX_PORT_MODULE_STATUS_PLUGGED_DISABLED;

    case SXD_PMAOS_OPER_STATUS_UNKNOWN_E:
        return SX_PORT_MODULE_STATUS_UNKNOWN;
    }

    return SX_PORT_MODULE_STATUS_PLUGGED_DISABLED;
}

static sx_status_t __is_module_type_backplane(sx_mgmt_phy_module_type_e module_type,
                                              boolean_t                *is_back_plane_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    switch (module_type) {
    case SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_4X_E:
    case SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_1X_E:
    case SX_MGMT_PHY_MODULE_TYPE_BACK_PLANE_2X_E:
    case SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_4X_E:
    case SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_2X_E:
    case SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_1X_E:
    case SX_MGMT_PHY_MODULE_TYPE_CHIP_TO_CHIP_8X_E:
        *is_back_plane_p = TRUE;
        break;

    default:
        *is_back_plane_p = FALSE;
        break;
    }

out:
    return err;
}

static sx_status_t __mgmt_lib_module_status_event_send(const sx_dev_id_t              dev_id,
                                                       const sx_slot_id_t             slot_id,
                                                       const sx_port_mod_id_t         module_id,
                                                       const sx_event_generate_mode_t event_mode,
                                                       sx_port_oper_state_t           last_oper_state)
{
    sx_mgmt_phy_module_state_event_set_params_t params;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    params.cmd = SX_ACCESS_CMD_SET;


    params.dev_id = dev_id;
    params.slot_id = slot_id;
    params.module_id = module_id;
    params.status_change_event_gen_mode = event_mode;
    params.last_oper_state = last_oper_state;

    err = __add_internal_job_cb_s(SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_STATUS_EVENT_SET_INT_E, (uint8_t*)&params,
                                  sizeof(sx_mgmt_phy_module_state_event_set_params_t), SX_CORE_MED_PRIO_BUF_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send internal job, [opcode = %u, buf_idx = %u], error: %s.\n",
                   SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_STATUS_EVENT_SET_INT_E,
                   SX_CORE_MED_PRIO_BUF_E,
                   sx_status_str(err));
    }

    SX_LOG_EXIT();
    return err;
}

static unsigned long long __mgmt_lib_event_get_time_msec_delta(struct timespec *timestamp)
{
    int                rc;
    struct timespec    curr_time, end, start, temp;
    unsigned long long delta;


    rc = clock_gettime(CLOCK_REALTIME, &curr_time);
    if (rc == -1) {
        SX_LOG(SX_LOG_ERROR, "clock_gettime failed.\n");
        return 0;
    }

    end = curr_time;
    start = *timestamp;

    if ((end.tv_nsec - start.tv_nsec) < 0) {
        temp.tv_sec = curr_time.tv_sec - start.tv_sec - 1;
        temp.tv_nsec = 1000000000 + end.tv_nsec - start.tv_nsec;
    } else {
        temp.tv_sec = end.tv_sec - start.tv_sec;
        temp.tv_nsec = end.tv_nsec - start.tv_nsec;
    }

    delta = ((unsigned long long)(temp.tv_sec + temp.tv_nsec / BILLION)) * 1000;

    return delta;
}

static sx_status_t __mgmt_lib_event_set_timestamp(struct timespec *timestamp)
{
    int rc;

    rc = clock_gettime(CLOCK_REALTIME, timestamp);
    if (rc == -1) {
        SX_LOG(SX_LOG_ERROR, "clock_gettime failed.\n");
        return SX_STATUS_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __mgmt_lib_get_module_last_oper_state(sx_slot_id_t            slot_id,
                                                         uint32_t                module_id,
                                                         sx_port_module_state_t *last_module_state_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    boolean_t                is_valid = FALSE;
    sx_mgmt_module_id_info_t module_id_info;


    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    rc = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "slot[%d], module[%d] validation failed.\n", slot_id, module_id);
        goto out;
    }

    if (is_valid == FALSE) {
        SX_LOG(SX_LOG_ERROR, "slot[%d] module[%d] validation failed, retrieve last module state.\n", slot_id,
               module_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (last_module_state_p == NULL) {
        SX_LOG_ERR("last_oper_state_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *last_module_state_p = port_module_ev_list[slot_id][module_id].last_oper_state;

out:
    return rc;
}

static sx_status_t __mgmt_lib_is_module_present(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                boolean_t                      *is_module_present_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_mcion_reg mcion_reg_data;
    sxd_reg_meta_t      reg_meta;
    uint16_t            module_present_status = 0;
    boolean_t           is_valid = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    err = mgmt_lib_is_module_id_info_valid(module_id_info_p, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(mcion_reg_data);
    SX_MEM_CLR(reg_meta);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to check module presence, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    mcion_reg_data.slot_index = module_id_info_p->slot_id;
    mcion_reg_data.module = module_id_info_p->module_id;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MCION_E, &mcion_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Slot [%u] Module [%u], MCION GET failed. (%s)\n", module_id_info_p->slot_id,
                   module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    module_present_status = mcion_reg_data.module_status_bits & (1 << SXD_MCION_MODULE_PRESENT_BIT);
    if (module_present_status != 0) {
        *is_module_present_p = TRUE;
    } else {
        *is_module_present_p = FALSE;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_is_module_logport_admin_enabled(sx_device_id_t                  dev_id,
                                                              const sx_mgmt_module_id_info_t *module_id_info_p,
                                                              boolean_t                      *is_admin_enabled_p,
                                                              boolean_t                       generate_error_log)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    uint32_t          port_list_size = 0;
    sxd_port_phy_id_t phy_port_list_p[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    sx_port_log_id_t  log_port = 0;
    sx_port_info_t    port_info;
    uint32_t          i = 0;

    *is_admin_enabled_p = FALSE;
    SX_MEM_CLR_ARRAY(phy_port_list_p, RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX, sxd_port_phy_id_t);

    /*Get all the logical port belonging to module */
    rc = sxd_status_to_sx_status(
        sxd_dpt_port_module_map_port_get(dev_id,
                                         module_id_info_p->slot_id,
                                         module_id_info_p->module_id,
                                         phy_port_list_p,
                                         &port_list_size));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "sxd_dpt_port_module_map_port_get error "
               "slot_id [%u] module_id [%x] rc :%d \n", module_id_info_p->slot_id, module_id_info_p->module_id, rc);
        goto out;
    }

    /* check admin status of ports and return as soon as any port is found to be
     * admin enabled
     */
    for (i = 0; i < port_list_size; i++) {
        log_port = 0;
        SX_PORT_DEV_ID_SET(log_port, dev_id);
        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(log_port, phy_port_list_p[i]);
        SX_MEM_CLR(port_info);
        if (SX_CHECK_FAIL(rc = port_db_info_get(log_port, &port_info))) {
            SX_LOG_ERR("Unable to get logport [0x%08X] info (%s).\n", log_port, sx_status_str(rc));
            goto out;
        }

        if ((port_info.admin_state == SX_PORT_ADMIN_STATUS_UP) ||
            (port_info.admin_state == SX_PORT_ADMIN_STATUS_UP_ONCE)) {
            if (generate_error_log) {
                SX_LOG_ERR("Slot [%u] Module [%u] has logport [0x%08X] in enabled state\n",
                           module_id_info_p->slot_id,
                           module_id_info_p->module_id,
                           log_port);
            }
            *is_admin_enabled_p = TRUE;
            goto out;
        }
    }
out:
    return rc;
}

static sx_status_t __mgmt_lib_is_module_id_valid(sx_slot_id_t     slot_id,
                                                 sx_port_mod_id_t module_id,
                                                 boolean_t       *is_valid_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_mgpir_reg mgpir_reg_data;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    /* 1U system module ID check can be done without querying the MGPIR*/
    if (slot_id == 0) {
        if (module_id < rm_resource_global.port_system_port_modules_max) {
            *is_valid_p = TRUE;
        } else {
            *is_valid_p = FALSE;
        }
        /* No more processing required */
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mgpir_reg_data);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to check module validity, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    mgpir_reg_data.hw_info.slot_index = slot_id;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPIR_E, &mgpir_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MGPIR Failed to get the system information, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    if (module_id < mgpir_reg_data.hw_info.num_of_modules) {
        *is_valid_p = TRUE;
    } else {
        *is_valid_p = FALSE;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_fetch_hw_ini_status(sx_slot_id_t           slot_id,
                                                  sxd_mbct_ini_status_t *ini_status_p,
                                                  sxd_mbct_status_t     *ini_oper_status_p,
                                                  sxd_mbct_fsm_state_t  *hw_ini_fsm_state_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mbct_reg mbct_reg_data;
    boolean_t          is_valid = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }
    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to fetch ini status from hardware, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    SX_MEM_CLR(mbct_reg_data);
    mbct_reg_data.slot_index = slot_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    mbct_reg_data.op = SXD_MBCT_OP_QUERY_STATUS_E;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MBCT Failed to get INI status, error (%s).\n",
                   sx_status_str(err));
        goto out;
    }


    *ini_oper_status_p = mbct_reg_data.status;
    *ini_status_p = mbct_reg_data.ini_status;
    *hw_ini_fsm_state_p = mbct_reg_data.fsm_state;
out:
    return err;
}

static sx_status_t __mgmt_lib_fetch_port_map_attributes(sx_port_phy_id_t local_port, sx_port_attributes_t *port_attr)
{
    struct ku_pmlp_reg pmlp_reg_data;
    sxd_reg_meta_t     pmlp_reg_meta;
    sx_status_t        err = SX_STATUS_SUCCESS;
    uint8_t            lane_index = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR_TYPE(&pmlp_reg_meta, sxd_reg_meta_t);
    pmlp_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    SX_MEM_CLR_TYPE(&pmlp_reg_data, struct ku_pmlp_reg);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to fetch port map attributes, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    pmlp_reg_meta.swid = SPECTRUM_SWID;
    pmlp_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmlp_reg_data.local_port, pmlp_reg_data.lp_msb, local_port);

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMLP_E, &pmlp_reg_data,
                                                                      &pmlp_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMLP GET failed (%s)\n", sx_status_str(err));
        goto out;
    }

    port_attr->port_mapping.lane_bmap = 0;
    for (lane_index = 0; lane_index < pmlp_reg_data.width; lane_index++) {
        port_attr->port_mapping.lane_bmap |= 0x01 << pmlp_reg_data.lane[lane_index];
    }

    port_attr->port_mapping.width = pmlp_reg_data.width;
    SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(port_attr->port_mapping.local_port,
                                      pmlp_reg_data.local_port,
                                      pmlp_reg_data.lp_msb);
    if (port_attr->port_mapping.width) {
        port_attr->port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE;
        /* Module and slot is same for all the lanes, so only lane0 is considered.*/
        port_attr->port_mapping.module_port = pmlp_reg_data.module[0];
        port_attr->port_mapping.slot = pmlp_reg_data.slot[0];
    } else {
        /* when mapping is disabled, width is 0, slot and module need not be considered.*/
        port_attr->port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE;
    }

    /* In case of multiple devices, choose the first device for
     * logical port creation.
     */
    SX_PORT_DEV_ID_SET(port_attr->log_port, dev_info_arr[0].dev_id);
    SX_PORT_TYPE_ID_SET(port_attr->log_port, SX_PORT_TYPE_NETWORK);
    SX_PORT_PHY_ID_SET(port_attr->log_port, local_port);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_mapping_status_changed_ports_get(
    sx_mgmt_slot_ini_operation_result_t *ini_operation_result_p)
{
    struct ku_pmsc_reg pmsc_reg_data;
    sxd_reg_meta_t     reg_meta;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sx_status_t        err_pmsc = SX_STATUS_SUCCESS;
    uint8_t            status_change_read_done = 0;
    uint32_t           idx = 0, local_port_count = 0;
    uint32_t           bit_offset = 0, bit_idx = 0;
    uint32_t           local_port = 0, port_attr_list_size = 0;
    uint32_t           port_mapping_retrieved[SXD_PMSC_PORT_MAPPING_UPDATED_NUM];

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmsc_reg_data);
    SX_MEM_CLR_ARRAY(port_mapping_retrieved, SXD_PMSC_PORT_MAPPING_UPDATED_NUM, uint32_t);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to fetch port mapping status changes, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    /* Get PMSC, see all bits changed and retrieve using PMLP */
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMSC_E, &pmsc_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMSC retrieval failed, status (%s)\n", sx_status_str(err));
        goto out;
    }

    status_change_read_done = 1;
    port_attr_list_size = ini_operation_result_p->port_info.port_attr_list_size;

    /* PMSC register has depth of 8 */
    for (idx = 0; idx < SXD_PMSC_PORT_MAPPING_UPDATED_NUM; idx++) {
        /* if the word is 0, then no need to check for bits */
        if (pmsc_reg_data.port_mapping_updated[idx] == 0) {
            continue;
        }
        /* bit offset to determine the local port */
        bit_offset = (idx * 32);
        /* check each bit and see if it is set or not until all bits are zero or bit index 32*/
        for (bit_idx = 0; bit_idx < 32 && pmsc_reg_data.port_mapping_updated[idx] != 0; bit_idx++) {
            if (pmsc_reg_data.port_mapping_updated[idx] & (1 << bit_idx)) {
                /* local port that has mapping change seen */
                local_port_count++;
                /* check if we have space in input array to store the mapping. */
                if (local_port_count <= port_attr_list_size) {
                    /* local port is offset + 1 as per PRM */
                    local_port = bit_offset + bit_idx + 1;
                    err =
                        __mgmt_lib_fetch_port_map_attributes(local_port,
                                                             &(ini_operation_result_p->port_info.port_attr_list_p[
                                                                   local_port_count - 1]));
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Failed to retrieve port mapping attributes after INI operation, status (%s)\n",
                                   sx_status_str(err));
                        goto out;
                    }
                    /* Mapping is read, so update the PMSC content so that it can be cleared. */
                    port_mapping_retrieved[idx] |= (1 << bit_idx);
                }
                /* clear the read bit for next iteration.*/
                pmsc_reg_data.port_mapping_updated[idx] &= ~(1 << bit_idx);
            }
        }
    }

    ini_operation_result_p->port_info.port_count = local_port_count;

out:
    if (status_change_read_done) {
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        SX_MEM_CPY_ARRAY(pmsc_reg_data.port_mapping_updated,
                         port_mapping_retrieved,
                         SXD_PMSC_PORT_MAPPING_UPDATED_NUM,
                         uint32_t);
        err_pmsc = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMSC_E, &pmsc_reg_data,
                                                                               &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err_pmsc)) {
            SX_LOG_ERR("PMSC set failed, status (%s)\n", sx_status_str(err_pmsc));
            break;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

        /* if there is error before pmsc set then return that error or return the final error code */
        if (err == SX_STATUS_SUCCESS) {
            err = err_pmsc;
        }
    }

    SX_LOG_EXIT();
    return err;
}

/* This function creates the cache with slot count in the system
 * Once, the cache is made valid, it stays valid all the time
 * as the slot count in system never changes.
 */
static sx_status_t __mgmt_lib_update_ctxt_system_info()
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t          reg_meta;
    struct ku_mgpir_reg     mgpir_reg_data;
    mgmt_lib_system_info_t *sys_info_p = NULL;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mgpir_reg_data);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        /* IB switches have no devices in ready state. */
        SX_LOG_ERR("Failed to update mgmt lib system context, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sys_info_p = &__mgmt_ctx_g.sys_info;

    /* when querying main board, slot index has to be 0 */
    mgpir_reg_data.hw_info.slot_index = 0;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPIR_E, &mgpir_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MGPIR Failed to get the system information, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    sys_info_p->is_valid = TRUE;
    SX_MEM_CPY(sys_info_p->hw_info, mgpir_reg_data.hw_info);

out:
    SX_LOG_EXIT();
    return err;
}


/**
 *  Translate set of PMD types which we get from user into
 *  bitmap value, which will be set to FW.
 *
 * @param[in] type_p - set of PMD interface types
 * @param[out] type_bitmask_p - bitmap value which will be set
 *       to FW
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
static sx_status_t __convert_phy_type_struct_to_phy_type_bitmap(sx_port_phy_module_type_bitmask_t *type_p,
                                                                uint16_t                          *type_bitmask_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_P(type_bitmask_p);


    if (TRUE == type_p->module_smf_up_500m) {
        *type_bitmask_p |= (1 << 0);
    }

    if (TRUE == type_p->module_smf_up_2km) {
        *type_bitmask_p |= (1 << 1);
    }

    if (TRUE == type_p->module_smf_above_2km) {
        *type_bitmask_p |= (1 << 2);
    }

    if (TRUE == type_p->module_mmf_up_100m) {
        *type_bitmask_p |= (1 << 3);
    }

    if (TRUE == type_p->module_mmf_above_100m) {
        *type_bitmask_p |= (1 << 4);
    }

    if (TRUE == type_p->module_aoc_acc_up_30m) {
        *type_bitmask_p |= (1 << 5);
    }

    if (TRUE == type_p->module_aoc_acc_above_30m) {
        *type_bitmask_p |= (1 << 6);
    }

    if (TRUE == type_p->module_base_cr) {
        *type_bitmask_p |= (1 << 7);
    }

    if (TRUE == type_p->module_base_tp) {
        *type_bitmask_p |= (1 << 8);
    }

    SX_LOG_EXIT();
    return rc;
}

/**
 *  Translate PDM types bitmap value which we get from FW into
 *  relevant set of PMD types which will be exposed to user.
 *
 * @param[in] type_bitmask - bitmap of PMD interface types
 * @param[out] type_p - set of PDM types
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
static sx_status_t __convert_phy_type_bitmap_to_phy_type_struct(uint16_t                           type_bitmask,
                                                                sx_port_phy_module_type_bitmask_t *type_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_P(type_p);

    /* Check that specified bit in input rate_bitmap is not 0 */
    if ((type_bitmask & (1 << 0)) != 0) {
        type_p->module_smf_up_500m = TRUE;
    }

    if ((type_bitmask & (1 << 1)) != 0) {
        type_p->module_smf_up_2km = TRUE;
    }

    if ((type_bitmask & (1 << 2)) != 0) {
        type_p->module_smf_above_2km = TRUE;
    }

    if ((type_bitmask & (1 << 3)) != 0) {
        type_p->module_mmf_up_100m = TRUE;
    }

    if ((type_bitmask & (1 << 4)) != 0) {
        type_p->module_mmf_above_100m = TRUE;
    }

    if ((type_bitmask & (1 << 5)) != 0) {
        type_p->module_aoc_acc_up_30m = TRUE;
    }

    if ((type_bitmask & (1 << 6)) != 0) {
        type_p->module_aoc_acc_above_30m = TRUE;
    }

    if ((type_bitmask & (1 << 7)) != 0) {
        type_p->module_base_cr = TRUE;
    }

    if ((type_bitmask & (1 << 8)) != 0) {
        type_p->module_base_tp = TRUE;
    }

    SX_LOG_EXIT();
    return rc;
}

/**
 *  Set PMD type into the FW.
 *
 * @param[in] slot_id - slot id to configure
 * @param[in] module_id - module number to configure
 * @param[in] module_type - bitmap of required PMD types to
 *       enable
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
static sx_status_t __port_admin_phy_type_set(sx_slot_id_t slot_id, sx_port_mod_id_t module_id, uint16_t module_type)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_pmtps_reg pmtps_reg_data;
    sxd_reg_meta_t      pmtps_reg_meta;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(pmtps_reg_data);
    SX_MEM_CLR(pmtps_reg_meta);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set port admin phy type, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    pmtps_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    pmtps_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pmtps_reg_meta.swid = SPECTRUM_SWID;

    pmtps_reg_data.slot_index = slot_id;
    pmtps_reg_data.module = module_id;
    pmtps_reg_data.module_type_admin = module_type;

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMTPS_E, &pmtps_reg_data,
                                                                      &pmtps_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send SET-PMTPS EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/**
 *  Get operational (connected) PMD type from the FW.
 *
 * @param[in] slot_id - slot number to configure
 * @param[in] module_id - module number to configure
 * @param[out] module_type_p - operational (connected) PMD type
 *       of interface
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
static sx_status_t __port_oper_phy_type_get(sx_slot_id_t               slot_id,
                                            sx_port_mod_id_t           module_id,
                                            sx_port_phy_module_type_e *module_type_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_pmtps_reg pmtps_reg_data;
    sxd_reg_meta_t      pmtps_reg_meta;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(pmtps_reg_data);
    SX_MEM_CLR(pmtps_reg_meta);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get port oper phy type, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    pmtps_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    pmtps_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pmtps_reg_meta.swid = SPECTRUM_SWID;
    pmtps_reg_data.slot_index = slot_id;
    pmtps_reg_data.module = module_id;

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMTPS_E, &pmtps_reg_data,
                                                                      &pmtps_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send GET-PMTPS EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

    *module_type_p = pmtps_reg_data.module_type_connected;

out:
    SX_LOG_EXIT();
    return err;
}

/**
 *  Get configured by admin and supported by module set of PMD
 *  types from the FW.
 *
 * @param[in] slot_id - slot number to configure
 * @param[in] module_id - module number to configure
 * @param[out] admin_type_p - configured by admin PMD types of
 *       interface
 * @param[out] capab_type_p - supported by module PMD types of
 *       interface
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
static sx_status_t __port_capab_phy_type_get(sx_slot_id_t     slot_id,
                                             sx_port_mod_id_t module_id,
                                             uint16_t        *admin_type_p,
                                             uint32_t        *capab_type_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_pmtps_reg pmtps_reg_data;
    sxd_reg_meta_t      pmtps_reg_meta;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(pmtps_reg_data);
    SX_MEM_CLR(pmtps_reg_meta);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get port capab phy type, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    pmtps_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    pmtps_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pmtps_reg_meta.swid = SPECTRUM_SWID;
    pmtps_reg_data.module = module_id;
    pmtps_reg_data.slot_index = slot_id;

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMTPS_E, &pmtps_reg_data,
                                                                      &pmtps_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send GET-PMTPS EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

    *admin_type_p = pmtps_reg_data.module_type_admin;
    *capab_type_p = pmtps_reg_data.eth_module_c2m;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_phy_module_status_get(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                    sx_mgmt_phy_module_state_t     *module_status_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_pmaos_reg pmaos_reg_data;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    /* No param validation are performed as this is a helper function.
     * Ensure no null pointers are passed and also that module, slot are valid */

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmaos_reg_data);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n", sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR(" __mgmt_lib_phy_module_status_get failed as device list is empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    /* Read PMAOS. For GET Oper we dont need to go over all devices unlike in a SET oper */
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pmaos_reg_data.module = module_id_info_p->module_id;
    pmaos_reg_data.slot_index = module_id_info_p->slot_id;
    pmaos_reg_data.oper_status = 0;
    pmaos_reg_data.admin_status = 0;
    pmaos_reg_data.ase = 0;
    pmaos_reg_data.ee = 0;
    pmaos_reg_data.e = 0;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMAOS SLOT [%u] Module [%u] get failed to read the current status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (pmaos_reg_data.admin_status == SXD_PMAOS_ADMIN_STATUS_DISABLED_BY_CONFIGURATION_E) {
        /* As per PRM module oper_status is reserved when admin_status is disabled */
        module_status_p->oper_state = SX_PORT_MODULE_STATUS_RESERVED_E;
        module_status_p->error_type = SX_PORT_MODULE_ERROR_TYPE_RESERVED_E;
    } else {
        module_status_p->oper_state = __sx_mgmt_module_status(pmaos_reg_data.oper_status);
        if (pmaos_reg_data.oper_status != SXD_PMAOS_OPER_STATUS_MODULE_PLUGGED_WITH_ERROR_E) {
            /* as per PRM, error_type is valid only when oper_status == b0011(error) */
            module_status_p->error_type = SX_PORT_MODULE_ERROR_TYPE_RESERVED_E;
        } else {
            module_status_p->error_type = (sx_port_module_error_type_t)(pmaos_reg_data.error_type);
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_get_slot_modules_count(sx_slot_id_t slot_id, uint32_t *module_count_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_mgpir_reg mgpir_reg_data;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get module count, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mgpir_reg_data);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    mgpir_reg_data.hw_info.slot_index = slot_id;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPIR_E, &mgpir_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MGPIR Failed to get the system information, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    *module_count_p = mgpir_reg_data.hw_info.num_of_modules;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_get_module_cable_type(sx_mgmt_module_id_info_t *module_id_info_p,
                                                    sxd_pddr_cable_type_t    *cable_p)
{
    sx_status_t                                         err = SX_STATUS_SUCCESS;
    struct                                  ku_pddr_reg pddr_reg_data;
    sxd_reg_meta_t                                      pddr_reg_meta;
    uint32_t                                            port_list_size = 0;
    sxd_port_phy_id_t                                   phy_port_list_p[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    sx_port_log_id_t                                    log_port = 0;
    sx_port_mapping_t                                   port_mapping;
    uint32_t                                            idx = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    /* WA - Bug#3178040 PDDR access is too slow for modular systems.
     * This results in watch dog being triggered in NOS. Disable PDDR access
     * for time being in modular systems.
     */
    if (module_id_info_p->slot_id != 0) {
        *cable_p = SXD_PDDR_CABLE_TYPE_UNIDENTIFIED_E;
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to check module validity, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    /* Get all the logical port belonging to module */
    port_list_size = 0;
    err = sxd_status_to_sx_status(
        sxd_dpt_port_module_map_port_get(dev_info_arr[dev_idx].dev_id, module_id_info_p->slot_id,
                                         module_id_info_p->module_id,
                                         phy_port_list_p, &port_list_size));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sxd_dpt_port_module_map_port_get error "
                   "slot_id [%x], module_id [%x] err :%s \n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
    }

    if (port_list_size == 0) {
        *cable_p = SXD_PDDR_CABLE_TYPE_CABLE_UNPLUGGED_E;
        goto out;
    }

    SX_MEM_CLR(pddr_reg_data);
    SX_MEM_CLR(pddr_reg_meta);

    pddr_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pddr_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    pddr_reg_meta.swid = SPECTRUM_SWID;

    /* For pddr access search for the first mapped port with valid width */
    for (idx = 0; idx < port_list_size; ++idx) {
        log_port = 0;
        memset(&port_mapping, 0, sizeof(sx_port_mapping_t));
        SX_PORT_PHY_ID_SET(log_port, phy_port_list_p[idx]);
        SX_PORT_DEV_ID_SET(log_port, 1);

        err = port_map_get(SX_ACCESS_CMD_GET, 1, &log_port, &port_mapping);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("port_map_get failed (%s)\n", sx_status_str(err));
        }

        if (port_mapping.width != 0) {
            break;
        }
    }
    /* if mapped port with valid width not found protect pddr access */
    if (idx == port_list_size) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("PDDR reg access is not allowed (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pddr_reg_data.local_port, pddr_reg_data.lp_msb, phy_port_list_p[idx]);
    pddr_reg_data.pnat = SXD_PDDR_PNAT_LOCAL_PORT_NUMBER_E;

    /* select module info page and retrieve it.*/
    pddr_reg_data.page_select = SXD_PDDR_PAGE_SELECT_MODULE_INFO_PAGE_E;

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PDDR_E,
                                                                      &pddr_reg_data,
                                                                      &pddr_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PDDR get failed (%s)\n", sx_status_str(err));
        goto out;
    }

    *cable_p = pddr_reg_data.page_data.pddr_module_info.cable_type;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_is_module_backplane_type(const sx_mgmt_module_id_info_t *module_id_info_p,
                                                       boolean_t                      *is_backplane_p,
                                                       boolean_t                      *is_twisted_pair_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_info_t module_info;

    SX_LOG_ENTER();

    SX_MEM_CLR(module_info);

    err = mgmt_lib_phy_module_info_get(module_id_info_p, &module_info, 1);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get module information, slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (is_twisted_pair_p != NULL) {
        *is_twisted_pair_p = FALSE;
        if (module_info.module_type == SX_MGMT_PHY_MODULE_TYPE_TWISTED_PAIR_E) {
            *is_twisted_pair_p = TRUE;
        }
    }

    err = __is_module_type_backplane(module_info.module_type, is_backplane_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify if module is backplane, slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t mgmt_lib_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         sxd_err = 0;
    char        dev_name[MAX_NAME_LEN];
    char       *dev_name_p = dev_name;
    uint32_t    dev_num = 1;        /* there should be only 1 char device */

    if (__is_mgmt_lib_initialized_g) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Mgmt Lib module is already initialized\n");
        goto out;
    }

    SX_MEM_CLR(__mgmt_ctx_g);
    __mgmt_lib_handle = NULL;
    __is_mgmt_lib_initialized_g = TRUE;

    sxd_err = sxd_get_dev_list(&dev_name_p, &dev_num);
    if (sxd_err != 0) {
        SX_LOG_ERR("mgmt_lib: sxd_get_dev_list error: %s\n", strerror(errno));
        err = sxd_status_to_sx_status(SXD_STATUS_DEVICE_GET_ERROR);
        goto out;
    }

    sxd_err = sxd_open_device(dev_name, &__g_mgmt_lib_device_handle);
    if (err != 0) {
        SX_LOG_ERR("mgmt_lib: sxd_open_device error: %s\n", strerror(errno));
        err = sxd_status_to_sx_status(SXD_STATUS_DEVICE_OPEN_ERROR);
        goto out;
    }

out:
    return err;
}
sx_status_t mgmt_lib_handle_set(void* lib_handle)
{
    __mgmt_lib_handle = lib_handle;
    return SX_STATUS_SUCCESS;
}
sx_status_t mgmt_lib_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    CHECK_MGMT_LIB_INIT_DONE;

    SX_MEM_CLR(__mgmt_ctx_g);
    __is_mgmt_lib_initialized_g = FALSE;
    if (__mgmt_lib_handle != NULL) {
        dlclose(__mgmt_lib_handle);
        __mgmt_lib_handle = NULL;
    }

    err = sxd_close_device(__g_mgmt_lib_device_handle);
    if (err) {
        SX_LOG_ERR("sxd_close_device error: %s\n", strerror(errno));
        return sxd_status_to_sx_status(SXD_STATUS_DEVICE_CLOSE_ERROR);
    }

out:
    return err;
}


sx_status_t mgmt_lib_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t mgmt_lib_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}


sx_status_t mgmt_lib_is_module_id_info_valid(const sx_mgmt_module_id_info_t *module_id_info_p, boolean_t *is_valid_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(is_valid_p, "is_valid_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(module_id_info_p->slot_id, is_valid_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   module_id_info_p->slot_id, sx_status_str(err));
        goto out;
    }

    /* If slot is not valid then no need to check further */
    if (*is_valid_p == FALSE) {
        goto out;
    }

    err = __mgmt_lib_is_module_id_valid(module_id_info_p->slot_id, module_id_info_p->module_id, is_valid_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify module id[%u], status (%s)\n",
                   module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_is_slot_valid(sx_slot_id_t slot_id, boolean_t *is_valid_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    mgmt_lib_system_info_t *sys_info_p = NULL;
    sx_swid_type_t          swid_type = KU_SWID_TYPE_DISABLED;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(is_valid_p, "is_valid_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    err = port_db_swid_type_get(SPECTRUM_SWID, &swid_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Management lib slot info retrieval failed, unable to get swid type, err[%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* IB has only one slot */
    if (swid_type == KU_SWID_TYPE_INFINIBAND) {
        if (slot_id == 0) {
            *is_valid_p = TRUE;
        } else {
            *is_valid_p = FALSE;
        }
        goto out;
    }

    sys_info_p = &__mgmt_ctx_g.sys_info;

    /* Fetch system information if it is not valid */
    if (!sys_info_p->is_valid) {
        err = __mgmt_lib_update_ctxt_system_info();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Management lib slot info retrieval failed, unable to fetch slot count, err[%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* 1U system has only slot id 0 as valid */
    if (sys_info_p->hw_info.num_of_slots == 0) {
        if (slot_id != 0) {
            *is_valid_p = FALSE;
        } else {
            *is_valid_p = TRUE;
        }
    } else {
        /* Slot identifier for modular systems go from 1 to N */
        if ((slot_id > 0) && (slot_id <= sys_info_p->hw_info.num_of_slots)) {
            *is_valid_p = TRUE;
        } else {
            *is_valid_p = FALSE;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t mgmt_lib_system_info_get(sx_mgmt_slot_system_info_t *system_info_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    mgmt_lib_system_info_t *sys_info_p = NULL;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(system_info_p, "system_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sys_info_p = &__mgmt_ctx_g.sys_info;

    /* Fetch system information if it is not valid */
    if (!sys_info_p->is_valid) {
        err = __mgmt_lib_update_ctxt_system_info();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MGPIR Failed to get the system information, status (%s)\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /*
     * Currently there is no FW design about device_index and slot_index in MECCC, we don't know the valid ranges for device_index and slot_index.
     * FW always returns the ECC statistics for device_index 0 and slot_index 0, so here we assign both of them to 0.
     * If FW supports multiple device_index/slot_index in the future, then we need to iterate on all possible combinations of device_index/slot_index,
     * and accumulate them in the final result.
     */
    err = host_ifc_get_ecc_stats(0, 0, &system_info_p->ecc_stats);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get the ECC statistics, status (%s)\n", sx_status_str(err));
        goto out;
    }

    system_info_p->slot_count = sys_info_p->hw_info.num_of_slots;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_slot_control_set(sx_slot_id_t slot_id, sx_mgmt_slot_control_info_t *slot_control_info_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mddc_reg mddc_reg_data;
    boolean_t          is_valid = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(slot_control_info_p, "slot_control_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set slot control, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mddc_reg_data);

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN
    reg_meta.swid = SPECTRUM_SWID;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    mddc_reg_data.level = 0;
    mddc_reg_data.slot_index = slot_id;

    if (slot_control_info_p->operation == SX_MGMT_SLOT_CONTROL_OPERATION_ACTIVATE_E) {
        mddc_reg_data.device_enable = 1;
    } else {
        mddc_reg_data.device_enable = 1;
        mddc_reg_data.rst = SXD_MDDC_CONTROL_OPER_SOFT_RESET_E;
    }

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MDDC_E, &mddc_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MDDC Failed to set the slot control state, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }
    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_slot_info_get(sx_slot_id_t        *slot_id_list_p,
                                   sx_mgmt_slot_info_t *slot_info_list_p,
                                   uint32_t             slot_list_size,
                                   uint32_t            *system_slot_count_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t              reg_meta;
    struct ku_mddq_reg          mddq_reg_data;
    mgmt_lib_system_info_t     *sys_info_p = NULL;
    uint32_t                    idx = 0, card_dev_idx = 0;
    sx_mgmt_slot_device_info_t *slot_device_info_p = NULL;
    boolean_t                   is_valid = FALSE;
    uint32_t                    slot_count = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(system_slot_count_p, "system_slot_count_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (slot_list_size != 0) {
        if (utils_check_pointer(slot_id_list_p, "slot_id_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        if (utils_check_pointer(slot_info_list_p, "slot_info_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    sys_info_p = &__mgmt_ctx_g.sys_info;
    /* Fetch system information if it is not valid */
    if (!sys_info_p->is_valid) {
        err = __mgmt_lib_update_ctxt_system_info();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Management lib slot info retrieval failed, unable to fetch slot count, err[%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* when slot_id_list_p or slot_info_list_p are NULL, we just need to return slot count */
    if ((slot_id_list_p == NULL) || (slot_info_list_p == NULL)) {
        *system_slot_count_p = sys_info_p->hw_info.num_of_slots;
        SX_LOG_DBG("Slot count retrieved, no space for slot information");
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mddq_reg_data);
    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get slot information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    for (idx = 0; idx < slot_list_size; idx++) {
        /* Check if slot is valid */
        err = mgmt_lib_is_slot_valid(slot_id_list_p[idx], &is_valid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        if (!is_valid) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        /* Populate the slot index and query slot type first.*/
        mddq_reg_data.slot_index = slot_id_list_p[idx];
        mddq_reg_data.query_type = SXD_MDDQ_QUERY_TYPE_SLOT_INFO_E;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MDDQ_E, &mddq_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MDDQ Failed to get the slot id [%u] info, status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        /* Populate slot information */
        slot_info_list_p[idx].slot_id = slot_id_list_p[idx];
        slot_info_list_p[idx].slot_description.slot_card_type = __conv_sxd_to_sx_mgmt_slot_card_type(
            mddq_reg_data.data.mddq_slot_info.card_type);
        slot_info_list_p[idx].slot_description.slot_card_ini_info.slot_card_hw_revision =
            mddq_reg_data.data.mddq_slot_info.hw_revision;
        slot_info_list_p[idx].slot_description.slot_card_ini_info.slot_card_minor_ini_version =
            mddq_reg_data.data.mddq_slot_info.ini_file_version;

        slot_info_list_p[idx].slot_description.slot_state_info.slot_id = slot_id_list_p[idx];
        slot_info_list_p[idx].slot_description.slot_state_info.is_slot_card_provisioned =
            mddq_reg_data.data.mddq_slot_info.provisioned;
        slot_info_list_p[idx].slot_description.slot_state_info.is_slot_card_valid =
            mddq_reg_data.data.mddq_slot_info.sr_valid;
        slot_info_list_p[idx].slot_description.slot_state_info.is_slot_card_ready =
            mddq_reg_data.data.mddq_slot_info.lc_ready;
        slot_info_list_p[idx].slot_description.slot_state_info.is_slot_card_active =
            mddq_reg_data.data.mddq_slot_info.active;

        if (mddq_reg_data.data.mddq_slot_info.provisioned == 0) {
            /* If slot is not provisioned then, collect information about next slot. */
            SX_LOG_DBG("MDDQ slot id [%u] is not provisioned, status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            continue;
        }

        /* Query MDDQ for slot card name*/
        SX_MEM_CLR(mddq_reg_data);
        mddq_reg_data.slot_index = slot_id_list_p[idx];
        mddq_reg_data.query_type = SXD_MDDQ_QUERY_TYPE_SLOT_NAME_E;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MDDQ_E, &mddq_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MDDQ Failed to get the slot id [%u] name info, status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        /* Copy the slot card name. */
        SX_MEM_CPY_BUF(slot_info_list_p[idx].slot_description.slot_card_name,
                       (char*)mddq_reg_data.data.mddq_slot_name.slot_ascii_name,
                       sizeof(slot_info_list_p[idx].slot_description.slot_card_name));

        slot_count++;

        /* If slot is not ready then no need to query device */
        if (slot_info_list_p[idx].slot_description.slot_state_info.is_slot_card_ready != 1) {
            slot_info_list_p[idx].dev_description.slot_device_count = 0;
            continue;
        }

        /* Query MDDQ for device information*/
        SX_MEM_CLR(mddq_reg_data);
        mddq_reg_data.slot_index = slot_id_list_p[idx];
        mddq_reg_data.query_type = SXD_MDDQ_QUERY_TYPE_DEVICE_INFO_E;
        for (card_dev_idx = 0; card_dev_idx < SX_MGMT_MAX_DEVICE_PER_CARD; card_dev_idx++) {
            /* start with 0 and following message will get sequence from response */
            mddq_reg_data.request_message_sequence = mddq_reg_data.response_message_sequence;
            err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MDDQ_E, &mddq_reg_data,
                                                                              &reg_meta, 1, NULL, NULL));

            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("MDDQ Failed to get the device[%u] info, status (%s)\n",
                           card_dev_idx, sx_status_str(err));
                goto out;
            }

            /* when data_valid is zero, there are no devices in the slot card.*/
            if (mddq_reg_data.data_valid == 0) {
                SX_LOG_DBG("MDDQ No devices in slot[%u], continue to check next slot.\n", slot_id_list_p[idx]);
                break;
            }

            slot_info_list_p[idx].dev_description.slot_device_count++;
            slot_device_info_p = &slot_info_list_p[idx].dev_description.slot_device_info[card_dev_idx];
            slot_device_info_p->device_index = mddq_reg_data.data.mddq_device_info.device_index;
            slot_device_info_p->is_flash_used = mddq_reg_data.data.mddq_device_info.uses_flash;
            slot_device_info_p->is_flash_owner = mddq_reg_data.data.mddq_device_info.flash_owner;
            slot_device_info_p->flash_id = mddq_reg_data.data.mddq_device_info.flash_id;
            slot_device_info_p->device_gb_type = mddq_reg_data.data.mddq_device_info.device_type;
            slot_device_info_p->device_fw_info.fw_major = mddq_reg_data.data.mddq_device_info.fw_major;
            slot_device_info_p->device_fw_info.fw_minor = mddq_reg_data.data.mddq_device_info.fw_minor;
            slot_device_info_p->device_fw_info.fw_sub_minor = mddq_reg_data.data.mddq_device_info.fw_sub_minor;
            slot_device_info_p->device_temp_info.sensor_id = mddq_reg_data.data.mddq_device_info.device_index +
                                                             SLOT_DEVICE_SENSOR_INDEX_OFFSET;
            slot_device_info_p->device_temp_info.thermal_sd = mddq_reg_data.data.mddq_device_info.thermal_sd;

            if (mddq_reg_data.response_message_sequence == 0) {
                SX_LOG_DBG("MDDQ Found [%u] devices, no more devices in slot[%u], continue to check next slot.\n",
                           (card_dev_idx + 1), slot_id_list_p[idx]);
                break;
            }
        }
    }
    /* give back to API, number of slot info retrieved */
    *system_slot_count_p = slot_count;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_slot_state_info_get(sx_slot_id_t              *slot_id_list_p,
                                         sx_mgmt_slot_state_info_t *slot_state_info_list_p,
                                         uint32_t                   slot_list_size,
                                         uint32_t                  *system_slot_count_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t          reg_meta;
    struct ku_mddq_reg      mddq_reg_data;
    mgmt_lib_system_info_t *sys_info_p = NULL;
    boolean_t               is_valid = FALSE;
    uint32_t                idx = 0;
    uint32_t                slot_count = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(system_slot_count_p, "system_slot_count_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (slot_list_size != 0) {
        if (utils_check_pointer(slot_id_list_p, "slot_id_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        if (utils_check_pointer(slot_state_info_list_p, "slot_state_info_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    sys_info_p = &__mgmt_ctx_g.sys_info;
    /* Fetch system information if it is not valid */
    if (!sys_info_p->is_valid) {
        err = __mgmt_lib_update_ctxt_system_info();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Management lib slot info retrieval failed unable to fetch slot count, err[%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* Return slot count when the slot id list or slot info list is NULL */
    if ((slot_id_list_p == NULL) || (slot_state_info_list_p == NULL)) {
        *system_slot_count_p = sys_info_p->hw_info.num_of_slots;
        SX_LOG_DBG("Slot count retrieved, no space for slot information");
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mddq_reg_data);
    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get slot state information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    mddq_reg_data.query_type = SXD_MDDQ_QUERY_TYPE_SLOT_INFO_E;

    for (idx = 0; idx < slot_list_size; idx++) {
        /* Check if slot is valid */
        err = mgmt_lib_is_slot_valid(slot_id_list_p[idx], &is_valid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        if (!is_valid) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        /* Populate the slot index */
        mddq_reg_data.slot_index = slot_id_list_p[idx];
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MDDQ_E, &mddq_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MDDQ Failed to get the slot [%u]info, status (%s)\n",
                       slot_id_list_p[idx], sx_status_str(err));
            goto out;
        }
        slot_state_info_list_p[idx].slot_id = slot_id_list_p[idx];
        slot_state_info_list_p[idx].is_slot_card_provisioned = mddq_reg_data.data.mddq_slot_info.provisioned;
        slot_state_info_list_p[idx].is_slot_card_ready = mddq_reg_data.data.mddq_slot_info.lc_ready;
        slot_state_info_list_p[idx].is_slot_card_active = mddq_reg_data.data.mddq_slot_info.active;
        slot_state_info_list_p[idx].is_slot_card_valid = mddq_reg_data.data.mddq_slot_info.sr_valid;
        slot_count++;
    }
    /* give back to API, number of slot info retrieved */
    *system_slot_count_p = slot_count;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_ini_data_set(sx_slot_id_t                        slot_id,
                                  sx_mgmt_slot_ini_data_t            *data_p,
                                  sx_mgmt_slot_ini_transfer_result_t *ini_transfer_result_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t        reg_meta;
    struct ku_mbct_reg    mbct_reg_data;
    boolean_t             is_valid = FALSE;
    sxd_mbct_status_t     ini_oper_status = SXD_MBCT_STATUS_NA_E;
    sxd_mbct_ini_status_t ini_status = SXD_MBCT_INI_STATUS_EMPTY_NOT_VALID_E;
    sxd_mbct_fsm_state_t  hw_ini_fsm_state = SXD_MBCT_FSM_STATE_IDLE_E;


    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ini_transfer_result_p, "ini_transfer_result_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set ini data, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.swid = SPECTRUM_SWID;

    if (data_p->ini_data_size > 0) {
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN SX_MEM_CLR(mbct_reg_data);
        reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;
        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        mbct_reg_data.slot_index = slot_id;
        mbct_reg_data.op = SXD_MBCT_OP_DATA_TRANSFER_E;
        mbct_reg_data.data_size = data_p->ini_data_size;
        SX_MEM_CPY_BUF(mbct_reg_data.data, data_p->ini_data, data_p->ini_data_size);
        mbct_reg_data.last = data_p->is_last_chunk;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MBCT Failed to set INI data, status[%u], error (%s).\n",
                       mbct_reg_data.status, sx_status_str(err));
            goto out;
        }

        ini_status = mbct_reg_data.ini_status;
        ini_oper_status = mbct_reg_data.status;
        hw_ini_fsm_state = mbct_reg_data.fsm_state;
        if (hw_ini_fsm_state == SXD_MBCT_FSM_STATE_ERROR_E) {
            SX_LOG_ERR("MBCT Failed to set INI data, HW fsm error, status[%u], error (%s).\n",
                       mbct_reg_data.status, sx_status_str(err));
            goto fsm_clear_error;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END
    } else {
        err = __mgmt_lib_fetch_hw_ini_status(slot_id, &ini_status, &ini_oper_status, &hw_ini_fsm_state);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MBCT Failed to get INI status, error (%s).\n",
                       sx_status_str(err));
            goto out;
        }
    }

fsm_clear_error:
    ini_transfer_result_p->ini_oper_status = __conv_sxd_to_sx_mgmt_slot_ini_oper_status(ini_oper_status);
    ini_transfer_result_p->ini_status = __conv_sxd_to_sx_mgmt_slot_ini_status(ini_status);
    if (hw_ini_fsm_state == SXD_MBCT_FSM_STATE_ERROR_E) {
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

        reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;
        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        mbct_reg_data.slot_index = slot_id;
        mbct_reg_data.op = SXD_MBCT_OP_CLEAR_ERRORS_E;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MBCT Failed to clear INI errors, when HW FSM moved to error state, error (%s).\n",
                       sx_status_str(err));
            goto out;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

        if (data_p->ini_data_size > 0) {
            /* Data transfer failed, FSM went into error state,return error */
            err = SX_STATUS_ERROR;
            goto out;
        }
    }
out:
    return err;
}

sx_status_t mgmt_lib_ini_operation_set(sx_slot_id_t                         slot_id,
                                       sx_mgmt_slot_ini_operation_e         oper,
                                       sx_mgmt_slot_ini_operation_result_t *ini_operation_result_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t            reg_meta;
    struct ku_mbct_reg        mbct_reg_data = {0};
    boolean_t                 is_valid = FALSE;
    sx_mgmt_slot_state_info_t slot_state_info;
    struct ku_pmsc_reg        pmsc_reg_data;
    uint32_t                  slot_list_size = 0;
    uint32_t                  idx = 0;
    uint32_t                  system_slot_count = 0;
    sxd_mbct_status_t         ini_oper_status = SXD_MBCT_STATUS_NA_E;
    sxd_mbct_ini_status_t     ini_status = SXD_MBCT_INI_STATUS_EMPTY_NOT_VALID_E;
    sxd_mbct_fsm_state_t      hw_ini_fsm_state = SXD_MBCT_FSM_STATE_IDLE_E;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(ini_operation_result_p, "ini_operation_result_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid slot id[%u], status (%s)\n", slot_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to execute slot ini operation, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmsc_reg_data);
    reg_meta.swid = SPECTRUM_SWID;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    /* Clear all the PMSC bits in firmware before new INI operation is performed.
     * PMSC register has depth of 8.
     */
    for (idx = 0; idx < SXD_PMSC_PORT_MAPPING_UPDATED_NUM; idx++) {
        pmsc_reg_data.port_mapping_updated[idx] = 0xFFFFFFFF;
    }

    /* Get PMSC, see all bits changed and retrieve using PMLP */
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMSC_E, &pmsc_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMSC retrieval failed, status (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(mbct_reg_data);
    mbct_reg_data.slot_index = slot_id;
    mbct_reg_data.fsm_state = SXD_MBCT_FSM_STATE_IDLE_E;

    /* For Reset - Query the status and make sure the INI is not in use.
     * If INI is in use then deactivate the INI and then erase.
     * For Apply - Query the status and make sure the INI is valid.
     */
    err = __mgmt_lib_fetch_hw_ini_status(slot_id, &ini_status, &ini_oper_status, &hw_ini_fsm_state);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MBCT Failed to get INI status, error (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    /* Any INI operation we do, get the status back in eMAD response */
    reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

    if (oper == SX_MGMT_SLOT_INI_OPERATION_RESET_E) {
        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

        /* Check if PSPA unmap is done. */
        if (ini_status == SXD_MBCT_INI_STATUS_IN_USE_E) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("MBCT Failed to set INI operation[%u] INI, status is in use(%s)\n",
                       mbct_reg_data.op, sx_status_str(err));
            goto out;
        }
        /* Erase the INI file */
        mbct_reg_data.op = SXD_MBCT_OP_ERASE_INI_IMAGE_E;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MBCT Failed to set INI operation[%u], status (%s)\n",
                       mbct_reg_data.op, sx_status_str(err));
            goto out;
        }
    } else {
        /* INI state can be "VALID" when the slot is not provisioned in the beginning and a new valid
         * INI was transferred. INI can be in "IN_USE" state in case of upgrade process when another INI
         * was transferred prior to upgrade and was activated by NOS.
         */
        if ((ini_status == SXD_MBCT_INI_STATUS_VALID_E) || (ini_status == SXD_MBCT_INI_STATUS_IN_USE_E)) {
            reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
            mbct_reg_data.op = SXD_MBCT_OP_ACTIVATE_E;
            mbct_reg_data.oee = 1;
            err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                              &reg_meta, 1, NULL, NULL));
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("MBCT Failed to set INI operation[%u], status (%s)\n",
                           mbct_reg_data.op, sx_status_str(err));
                goto out;
            }
        } else {
            SX_LOG_ERR("MBCT Failed to set INI operation[%u], current ini is not valid, status (%s)\n",
                       mbct_reg_data.op, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

    /* Copy the results here */
        ini_status = mbct_reg_data.ini_status;

    ini_oper_status = mbct_reg_data.status;
    hw_ini_fsm_state = mbct_reg_data.fsm_state;

    ini_operation_result_p->ini_oper_status = __conv_sxd_to_sx_mgmt_slot_ini_oper_status(ini_oper_status);
    ini_operation_result_p->ini_status = __conv_sxd_to_sx_mgmt_slot_ini_status(ini_status);

    if ((oper == SX_MGMT_SLOT_INI_OPERATION_APPLY_E) &&
        (ini_oper_status == SXD_MBCT_STATUS_BUSY_E)) {
        /* INI Apply operation is async now, so return from here if FW is busy due to APPLY*/
        SX_LOG_DBG(
            "MBCT set INI operation is async, no change in mapping or provision unless busy status changes, status (%s)\n",
            sx_status_str(err));
        goto out;
    } else if (hw_ini_fsm_state == SXD_MBCT_FSM_STATE_ERROR_E) {
        /* INI operation failed, FSM went into error state,return error */
        reg_meta.mode = SXD_ACCESS_MODE_DEFAULT;
        mbct_reg_data.op = SXD_MBCT_OP_CLEAR_ERRORS_E;

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MBCT_E, &mbct_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MBCT Failed to clear INI errors, when HW FSM moved to error state, error (%s).\n",
                       sx_status_str(err));
            goto out;
        }
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END
        /* INI operation failed, FSM went into error state,return error */
        SX_LOG_ERR("MBCT Failed to set INI operation[%u], current ini is not valid, status (%s)\n",
                   mbct_reg_data.op, sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(slot_state_info);
    slot_list_size = 1;
    err = mgmt_lib_slot_state_info_get(&slot_id, &slot_state_info, slot_list_size, &system_slot_count);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("MDDQ status retrieval failed for slot[%u] after INI operation, status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    if ((slot_state_info.is_slot_card_provisioned && (oper == SX_MGMT_SLOT_INI_OPERATION_RESET_E)) ||
        ((slot_state_info.is_slot_card_provisioned == 0) && (oper == SX_MGMT_SLOT_INI_OPERATION_APPLY_E))) {
        SX_LOG_ERR("INI operation failed card provision status is not as expected, status (%s)\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    ini_operation_result_p->slot_state_info = slot_state_info;

    err = __mgmt_lib_mapping_status_changed_ports_get(ini_operation_result_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Error processing the port mapping status changes, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_split_info_get(sx_mgmt_module_id_info_t          *module_id_info_p,
                                               sx_mgmt_phy_module_split_params_t *module_split_params_p,
                                               sx_mgmt_phy_module_split_info_t   *module_split_info_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_pmtdb_reg pmtdb_reg_data;
    boolean_t           is_valid = FALSE;
    uint8_t             idx = 0;
    uint16_t           *local_port_p = NULL;
    sx_port_mapping_t  *port_mapping_p = NULL;
    uint8_t             lane_bmap = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(module_split_params_p, "module_split_params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(module_split_info_p, "module_split_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (module_split_params_p->split_num > RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX) {
        SX_LOG_ERR("Invalid split count [%u] for slot id[%u] module_id[%u], status (%s)\n",
                   module_split_params_p->split_num, module_id_info_p->slot_id,
                   module_id_info_p->module_id, sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((module_split_params_p->port_width == 0) ||
        (module_split_params_p->port_width > RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX)) {
        SX_LOG_ERR("Invalid width for each port [%u] for slot id[%u] module_id[%u], status (%s)\n",
                   module_split_params_p->port_width, module_id_info_p->slot_id,
                   module_id_info_p->module_id, sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = mgmt_lib_is_module_id_info_valid(module_id_info_p, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmtdb_reg_data);

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get split information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    pmtdb_reg_data.slot_index = module_id_info_p->slot_id;
    pmtdb_reg_data.module = module_id_info_p->module_id;
    pmtdb_reg_data.num_ports = module_split_params_p->split_num;
    pmtdb_reg_data.ports_width = module_split_params_p->port_width;

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMTDB_E, &pmtdb_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMTDB Failed to get the split information for slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    /* PMTDB eMAD can succeed but query can fail when -
     * 1. split number passed exceed the current module width
     * 2. when module is not correctly instantiated.
     */
    if (pmtdb_reg_data.status != SXD_PMTDB_STATUS_SUCCESS_E) {
        if ((pmtdb_reg_data.status == SXD_PMTDB_STATUS_EXCEED_MODULE_WIDTH_E) ||
            (pmtdb_reg_data.status == SXD_PMTDB_STATUS_PORTS_COMBINATION_NOT_ALLOWED)) {
            module_split_info_p->list_len = 0;
            goto out;
        } else if (pmtdb_reg_data.status == SXD_PMTDB_STATUS_MODULE_NOT_INSTANTIATED_E) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("PMTDB Query split information for slot id[%u] module_id[%u] failure[%u], status (%s)\n",
                       module_id_info_p->slot_id, module_id_info_p->module_id, pmtdb_reg_data.status,
                       sx_status_str(err));
            goto out;
        }
    }

    /* PMTDB returns local port that would be used after the port split.
     * Lanes used by each of the local port is determined as below
     * If split_num is 1, then port #1 uses lanes (0: port_width-1)
     * If split_num is 2, then port #1 uses lanes as above and  port #2 uses lanes (port_width: 2*port_width-1)
     * If split_num is 4, then port #1 and port #2 uses the lanes as above and port #3 uses lanes
     * (2*port_width: 3*port_width-1) and port #4 uses lanes (3*port_width: 4*port_width -1).
     * Similar logic applies when the number of split is 8.
     */
    local_port_p = &pmtdb_reg_data.port_num1;
    lane_bmap = (1 << module_split_params_p->port_width) - 1;
    for (idx = 0; idx < module_split_params_p->split_num; idx++) {
        /* In case of multiple devices, choose the first device for
         * logical port creation.
         */
        /* Store logical port number. */
        SX_PORT_DEV_ID_SET(module_split_info_p->port_attribs_list[idx].log_port, dev_info_arr[0].dev_id);
        SX_PORT_TYPE_ID_SET(module_split_info_p->port_attribs_list[idx].log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(module_split_info_p->port_attribs_list[idx].log_port, *(local_port_p));

        /* Store port mode and label information. */
        module_split_info_p->port_attribs_list[idx].port_mode = SX_PORT_MODE_EXTERNAL;
        module_split_info_p->port_attribs_list[idx].usr_label_info.port_label = 0;

        /* Store port mapping. */
        port_mapping_p = &module_split_info_p->port_attribs_list[idx].port_mapping;
        port_mapping_p->local_port = *local_port_p;
        port_mapping_p->module_port = module_id_info_p->module_id;
        port_mapping_p->slot = module_id_info_p->slot_id;
        port_mapping_p->width = module_split_params_p->port_width;
        port_mapping_p->lane_bmap = lane_bmap << (idx * module_split_params_p->port_width);
        local_port_p++;
        module_split_info_p->list_len++;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_info_get(const sx_mgmt_module_id_info_t *module_id_info_list_p,
                                         sx_mgmt_phy_module_info_t      *module_info_list_p,
                                         uint32_t                        list_size)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_pmtm_reg pmtm_reg_data;
    boolean_t          is_valid = FALSE;
    uint32_t           idx = 0;
    boolean_t          is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    if (utils_check_pointer(module_id_info_list_p, "module_id_info_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(module_info_list_p, "module_info_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (list_size == 0) {
        SX_LOG_ERR("Failed mgmt_lib_phy_module_info_get, incorrect list size status (%s)\n",
                   sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get phy module information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;


    for (idx = 0; idx < list_size; idx++) {
        err = mgmt_lib_is_module_id_info_valid(&module_id_info_list_p[idx], &is_valid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                       module_id_info_list_p[idx].slot_id, module_id_info_list_p[idx].module_id, sx_status_str(err));
            goto out;
        }

        if (!is_valid) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                       module_id_info_list_p[idx].slot_id, module_id_info_list_p[idx].module_id, sx_status_str(err));
            goto out;
        }

        SX_MEM_CLR(pmtm_reg_data);
        pmtm_reg_data.slot_index = module_id_info_list_p[idx].slot_id;
        pmtm_reg_data.module = module_id_info_list_p[idx].module_id;

        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMTM_E, &pmtm_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("PMTM Failed to get the module information for slot id[%u] module_id[%u], status (%s)\n",
                       module_id_info_list_p[idx].slot_id, module_id_info_list_p[idx].module_id, sx_status_str(err));
            goto out;
        }
        module_info_list_p[idx].slot_id = pmtm_reg_data.slot_index;
        module_info_list_p[idx].module_id = pmtm_reg_data.module;
        module_info_list_p[idx].module_width = pmtm_reg_data.module_width;
        module_info_list_p[idx].module_type = __conv_sxd_to_sx_mgmt_phy_module_type(pmtm_reg_data.module_type);

        err = __mgmt_lib_phy_module_status_get(&(module_id_info_list_p[idx]), &(module_info_list_p[idx].module_state));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__mgmt_lib_phy_module_status_get() failed at idx=%u for slot= %u,mod= %u, error: %s\n",
                       idx, module_info_list_p[idx].slot_id, module_info_list_p[idx].module_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_log_port_info_get(sx_port_log_id_t    *log_port_list_p,
                                       sx_mgmt_port_info_t *log_port_info_list_p,
                                       uint32_t             list_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;
    sx_slot_id_t       slot_id = 0;
    sxd_port_mod_id_t  module_id = 0;
    sxd_port_phy_id_t  lport;
    sxd_reg_meta_t     reg_meta;
    struct ku_pllp_reg pllp_reg_data;


    SX_LOG_ENTER();

    if (utils_check_pointer(log_port_list_p, "log_port_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(log_port_info_list_p, "log_port_info_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (list_size == 0) {
        SX_LOG_ERR("Failed mgmt_lib_log_port_info_get, incorrect list size status (%s)\n",
                   sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    CHECK_MGMT_LIB_INIT_DONE;

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get logical port information get, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    for (idx = 0; idx < list_size; idx++) {
        lport = SX_PORT_PHY_ID_GET(log_port_list_p[idx]);
        err = sxd_status_to_sx_status(sxd_dpt_port_module_map_module_get(dev_info_arr[dev_idx].dev_id,
                                                                         lport, &slot_id, &module_id));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "sxd_dpt_port_module_map_module_get failed"
                   "local port:%u , rc :%d \n", lport, err);
            goto out;
        }

        SX_MEM_CLR(pllp_reg_data);
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pllp_reg_data.local_port,
                                            pllp_reg_data.lp_msb,
                                            lport);
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PLLP_E, &pllp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("PLLP Failed to get split information, local port[%u] status (%s)\n",
                       lport, sx_status_str(err));
            goto out;
        }

        log_port_info_list_p[idx].log_port = log_port_list_p[idx];
        log_port_info_list_p[idx].module_id_info.slot_id = slot_id;
        log_port_info_list_p[idx].module_id_info.module_id = module_id;
        log_port_info_list_p[idx].panel_info.split_num = pllp_reg_data.split_num;
        log_port_info_list_p[idx].panel_info.label_port = pllp_reg_data.label_port;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/*
 * This function support the following commands :
 * SX_ACCESS_CMD_SET/UNSET - to enable / disable events
 * SX_ACCESS_CMD_CLEAR - to clear max temperature
 * temp_sensor_ctrl_info_list_p can be NULL if cmd = SX_ACCESS_CMD_CLEAR
 * */
sx_status_t mgmt_lib_temp_sensor_set(sx_access_cmd_t                  cmd,
                                     sx_slot_id_t                     slot_id,
                                     uint32_t                         list_size,
                                     sx_sensor_id_t                  *sensor_id_list_p,
                                     sx_mgmt_temp_sensor_ctrl_info_t *temp_sensor_ctrl_info_list_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;
    uint8_t     event_mode;
    boolean_t   is_valid = FALSE;
    boolean_t   is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mtmp_reg mtmp_reg_data;

    SX_LOG_ENTER();

    if (utils_check_pointer(sensor_id_list_p, "sensor_id_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CLEAR) &&
        utils_check_pointer(temp_sensor_ctrl_info_list_p, "temp_sensor_ctrl_info_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (list_size == 0) {
        SX_LOG_ERR("Failed mgmt_lib_temp_sensor_set, incorrect list size status (%s)\n",
                   sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* validation for allowed commands done on upper layer */
    if (cmd == SX_ACCESS_CMD_SET) {
        event_mode = SXD_MTMP_E_GENERATE_EVENT_E;
    } else if ((cmd == SX_ACCESS_CMD_UNSET) ||
               (cmd == SX_ACCESS_CMD_CLEAR)) {
        event_mode = SXD_MTMP_E_DO_NOT_GENERATE_EVENT_E;
    } else {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported command %s , status (%s)\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    CHECK_MGMT_LIB_INIT_DONE;

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        for (idx = 0; idx < list_size; idx++) {
            if (MGMT_LIB_IS_MODULE_SENSOR_ID(sensor_id_list_p[idx])) {
                err = SX_STATUS_CMD_UNPERMITTED;
                SX_LOG_ERR("This operation is not permitted if SDK is initiated "
                           "with independent or standalone module support, and sensor ID (%d) index (%d) is"
                           "module sensor ID.\n", sensor_id_list_p[idx], idx);
                goto out;
            }
        }
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set temp sensor information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN SX_MEM_CLR(reg_meta);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    for (idx = 0; idx < list_size; idx++) {
        SX_MEM_CLR(mtmp_reg_data);
        mtmp_reg_data.slot_index = slot_id;
        mtmp_reg_data.sensor_index = sensor_id_list_p[idx];
        mtmp_reg_data.mte = 1;  /* always set max_temp to enable */

        /* Clear command intended to clear max temp only */
        if (cmd == SX_ACCESS_CMD_CLEAR) {
            mtmp_reg_data.mtr = 1;
        } else {
            if (temp_sensor_ctrl_info_list_p[idx].temp_sensor_ops_mask &
                SX_MGMT_TEMP_SNSR_OP_TEMP_WARNING_EV_E) {
                mtmp_reg_data.weme = 1;
                mtmp_reg_data.tee = event_mode;
            }

            if (temp_sensor_ctrl_info_list_p[idx].temp_sensor_ops_mask &
                SX_MGMT_TEMP_SNSR_OP_TEMP_SHUTDOWN_EV_E) {
                mtmp_reg_data.sdme = 1; /* Shut Down Events Modify Enable */
                mtmp_reg_data.sdee = event_mode;
            }
        }

        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MTMP_E, &mtmp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MTMP Failed to set temp control information, slot:[%u] sensor_id:[%u] status (%s)\n",
                       slot_id, sensor_id_list_p[idx], sx_status_str(err));
            goto out;
        }
    }

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t mgmt_lib_temp_sensor_get(sx_access_cmd_t             cmd,
                                     sx_slot_id_t                slot_id,
                                     uint32_t                    list_size,
                                     sx_sensor_id_t             *sensor_id_list_p,
                                     sx_mgmt_temp_sensor_info_t *temp_sensor_info_list_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;
    boolean_t   is_valid = FALSE;
    boolean_t   is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mtmp_reg mtmp_reg_data;

    SX_LOG_ENTER();

    if (utils_check_pointer(sensor_id_list_p, "sensor_id_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(temp_sensor_info_list_p, "temp_sensor_info_list_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (list_size == 0) {
        SX_LOG_ERR("Failed mgmt_lib_temp_sensor_get, incorrect list size status (%s)\n",
                   sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    CHECK_MGMT_LIB_INIT_DONE;

    /* Check if slot is valid */
    err = mgmt_lib_is_slot_valid(slot_id, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to verify slot id[%u], status (%s)\n",
                   slot_id, sx_status_str(err));
        goto out;
    }

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        for (idx = 0; idx < list_size; idx++) {
            if (MGMT_LIB_IS_MODULE_SENSOR_ID(sensor_id_list_p[idx])) {
                err = SX_STATUS_CMD_UNPERMITTED;
                SX_LOG_ERR("This operation is not permitted if SDK is initiated "
                           "with independent or standalone module support, and sensor ID (%d) index (%d) is"
                           "module sensor ID.\n", sensor_id_list_p[idx], idx);
                goto out;
            }
        }
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get temp sensor information, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    for (idx = 0; idx < list_size; idx++) {
        SX_MEM_CLR(mtmp_reg_data);
        mtmp_reg_data.slot_index = slot_id;
        mtmp_reg_data.sensor_index = sensor_id_list_p[idx];

        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MTMP_E, &mtmp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MTMP Failed to get temp control information, slot:[%u] sensor_id:[%u] status (%s)\n",
                       slot_id, sensor_id_list_p[idx], sx_status_str(err));
            goto out;
        }

        temp_sensor_info_list_p[idx].sensor_id = mtmp_reg_data.sensor_index;  /**< Sensor ID */
        /*
         * Temperature reading from the sensor. Reading is in 0.125 Celsius degrees units.
         * For negative values 2's complement is used (for example: -3.25
         * Celsius will read as 0xFFE6)
         */
        temp_sensor_info_list_p[idx].curr_temp = MTMP_CONV_TO_CELSIUS(mtmp_reg_data.temperature);
        temp_sensor_info_list_p[idx].max_temp = MTMP_CONV_TO_CELSIUS(mtmp_reg_data.max_temperature);
        temp_sensor_info_list_p[idx].temp_warning_enabled = mtmp_reg_data.tee;
        temp_sensor_info_list_p[idx].temp_shutdown_enabled = mtmp_reg_data.sdee;
        temp_sensor_info_list_p[idx].temp_threshold_high =
            MTMP_CONV_TO_CELSIUS(mtmp_reg_data.temperature_threshold_hi);
        temp_sensor_info_list_p[idx].temp_threshold_low = MTMP_CONV_TO_CELSIUS(mtmp_reg_data.temperature_threshold_lo);
        SX_MEM_CLR_BUF(temp_sensor_info_list_p[idx].sensor_name,
                       sizeof(temp_sensor_info_list_p[idx].sensor_name));
        SX_MEM_CPY_BUF(temp_sensor_info_list_p[idx].sensor_name,
                       &mtmp_reg_data.sensor_name_hi, sizeof(mtmp_reg_data.sensor_name_hi));
        SX_MEM_CPY_BUF(temp_sensor_info_list_p[idx].sensor_name + sizeof(mtmp_reg_data.sensor_name_hi),
                       &mtmp_reg_data.sensor_name_lo, sizeof(mtmp_reg_data.sensor_name_lo));
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        err = mgmt_lib_temp_sensor_set(SX_ACCESS_CMD_CLEAR, slot_id, list_size,
                                       sensor_id_list_p, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("MTMP Failed to set temp control information, slot:[%u] sensor_id:[%u] status (%s)\n",
                       slot_id, sensor_id_list_p[idx], sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_admin_type_set(const sx_slot_id_t                 slot_id,
                                               const sx_port_mod_id_t             module_id,
                                               sx_port_phy_module_type_bitmask_t *types_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint16_t                 module_type = 0;
    sx_mgmt_module_id_info_t module_id_info;
    boolean_t                is_module_valid;
    boolean_t                is_independent_module_enabled = FALSE;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    if (utils_check_pointer(types_p, "types_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = port_is_ext_speed_supported();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("API is not supported, error: (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    err = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_module_valid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n",
                   slot_id, module_id, sx_status_str(err));
        goto out;
    }

    if (is_module_valid == FALSE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n",
                   slot_id, module_id, sx_status_str(err));
        goto out;
    }

    err = __convert_phy_type_struct_to_phy_type_bitmap(types_p, &module_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to convert bitmap to port rate value, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = __port_admin_phy_type_set(slot_id, module_id, module_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set admin port rate value, error: (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_oper_get(const sx_slot_id_t         slot_id,
                                         const sx_port_mod_id_t     module_id,
                                         sx_port_phy_module_type_e *oper_type_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_mgmt_module_id_info_t module_id_info;
    boolean_t                is_module_valid;
    boolean_t                is_independent_module_enabled = FALSE;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    if (utils_check_pointer(oper_type_p, "oper_type_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = port_is_ext_speed_supported();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("API is not supported, error: (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    err = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_module_valid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n",
                   slot_id, module_id, sx_status_str(err));
        goto out;
    }

    if (is_module_valid == FALSE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n",
                   slot_id, module_id, sx_status_str(err));
        goto out;
    }

    err = __port_oper_phy_type_get(slot_id, module_id, oper_type_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get operational module type value, error: (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_capab_get(const sx_slot_id_t                 slot_id,
                                          const sx_port_mod_id_t             module_id,
                                          sx_port_rate_bitmask_t            *capab_port_rate_p,
                                          sx_port_phy_module_type_bitmask_t *admin_types_p,
                                          sx_port_phy_module_type_bitmask_t *capab_types_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint16_t                 admin_phy_type = 0;
    uint32_t                 capab_phy_type = 0;
    sx_mgmt_module_id_info_t module_id_info;
    boolean_t                is_module_valid;
    boolean_t                is_independent_module_enabled = FALSE;

    SX_LOG_ENTER();
    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    if (utils_check_pointer(capab_port_rate_p, "capab_port_rate_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(admin_types_p, "admin_types_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(capab_types_p, "capab_types_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = port_is_ext_speed_supported();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("API is not supported, error: (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    err = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_module_valid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n", slot_id, module_id, sx_status_str(err));
        goto out;
    }

    if (is_module_valid == FALSE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Slot ID '%u' Module ID '%u' is not valid, error: (%s)\n", slot_id, module_id, sx_status_str(err));
        goto out;
    }

    err = __port_capab_phy_type_get(slot_id, module_id, &admin_phy_type, &capab_phy_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get admin port rate value, error: (%s)\n", sx_status_str(err));
        goto out;
    }

    err = __convert_phy_type_bitmap_to_phy_type_struct(admin_phy_type, admin_types_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to convert capab bitmap to phy type struct, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = port_convert_port_rate_bitmap_to_port_struct_rate(capab_phy_type, capab_port_rate_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to convert capab bitmap to port struct rate, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = port_convert_port_rate_bitmap_to_port_module_type(capab_phy_type, capab_types_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to convert capab bitmap to port module capab type, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_reset(const sx_mgmt_module_id_info_t *module_id_info_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_pmaos_reg pmaos_reg_data;
    boolean_t           is_valid = FALSE;
    boolean_t           is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = mgmt_lib_is_module_id_info_valid(module_id_info_p, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to reset module, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmaos_reg_data);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    /* check if module is enabled */
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pmaos_reg_data.slot_index = module_id_info_p->slot_id;
    pmaos_reg_data.module = module_id_info_p->module_id;
    pmaos_reg_data.oper_status = 0;
    pmaos_reg_data.admin_status = 0;
    pmaos_reg_data.ase = 0;
    pmaos_reg_data.ee = 0;
    pmaos_reg_data.e = 0;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMAOS Slot [%u] Module [%u] get failed to know the current status (%s)\n",
                   module_id_info_p->slot_id,
                   module_id_info_p->module_id,
                   sx_status_str(err));
        goto out;
    }

    /* check module is present before attempting to change status.*/
    if (pmaos_reg_data.oper_status == SXD_PMAOS_OPER_STATUS_UNPLUGGED_E) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Module reset failed, slot [%u] module [%d] is unplugged. (%s)\n",
                   module_id_info_p->slot_id,
                   module_id_info_p->module_id,
                   sx_status_str(err));
        goto out;
    }

    if (pmaos_reg_data.admin_status == SXD_PMAOS_ADMIN_STATUS_DISABLED_BY_CONFIGURATION_E) {
        SX_LOG_ERR("Reset can only be done on Admin enabled modules, enable respective ports to enable module\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

    /* reset the module */
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    pmaos_reg_data.slot_index = module_id_info_p->slot_id;
    pmaos_reg_data.module = module_id_info_p->module_id;
    pmaos_reg_data.rst = 1;
    pmaos_reg_data.oper_status = 0;
    pmaos_reg_data.ase = SXD_PMAOS_ADMIN_STATE_DISABLE;
    pmaos_reg_data.ee = SXD_PMAOS_EVENT_ENABLE;
    pmaos_reg_data.e = (sxd_pmaos_e_t)SX_EVENT_GENERATE_MODE_GENRATE_SINGLE;
    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("PMAOS Slot [%u] Module [%u] set failed for module reset (%s)\n", module_id_info_p->slot_id,
                   module_id_info_p->module_id,
                   sx_status_str(err));
        goto out;
    }

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_pwr_attr_get(const sx_access_cmd_t           cmd,
                                             const sx_mgmt_module_id_info_t *module_id_info_p,
                                             sx_mgmt_phy_mod_pwr_attr_t     *pwr_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_pmmp_reg  pmmp_reg_data;
    struct ku_mcion_reg mcion_reg_data;
    sxd_reg_meta_t      reg_meta;
    uint16_t            mod_low_pwr_admin_state = 0;
    uint16_t            mod_low_pwr_oper_state = 0;
    boolean_t           is_module_present = FALSE;
    boolean_t           is_valid = FALSE;
    uint16_t            module_present_status = 0;
    boolean_t           is_backplane = FALSE;
    boolean_t           is_twisted_pair = FALSE;
    boolean_t           is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();
    UNUSED_PARAM(cmd);

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }


    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(pwr_attr_p, "pwr_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to get power attribute, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    err = mgmt_lib_is_module_id_info_valid(module_id_info_p, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    err = __mgmt_lib_is_module_backplane_type(module_id_info_p, &is_backplane, &is_twisted_pair);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check  if module is backplane slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    /* MCION does not support twisted or back plane cables. (for Alligator) */
    if ((is_backplane == TRUE) || (is_twisted_pair == TRUE)) {
        SX_LOG_DBG("Module slot id[%u] module_id[%u] is of type backplane\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id);
        pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_INVALID_E;
        pwr_attr_p->pwr_mode_attr.oper_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_INVALID_E;
        goto out;
    }

    if (pwr_attr_p->power_attr_type & SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E) {
        /* get the admin power mode*/
        SX_MEM_CLR(pmmp_reg_data);
        SX_MEM_CLR(mcion_reg_data);
        SX_MEM_CLR(reg_meta);

        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.swid = SPECTRUM_SWID;
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        mcion_reg_data.slot_index = module_id_info_p->slot_id;
        mcion_reg_data.module = module_id_info_p->module_id;

        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MCION_E, &mcion_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Slot [%u] Module [%u] Attr get, MCION GET failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        module_present_status = mcion_reg_data.module_status_bits & (1 << SXD_MCION_MODULE_PRESENT_BIT);
        if (module_present_status != 0) {
            is_module_present = TRUE;
        } else {
            is_module_present = FALSE;
        }

        if (is_module_present == FALSE) {
            SX_LOG_DBG("Slot [%u] Module [%d] is unplugged.\n", module_id_info_p->slot_id,
                       module_id_info_p->module_id);
            pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_INVALID_E;
            pwr_attr_p->pwr_mode_attr.oper_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_INVALID_E;
            goto out;
        }

        mod_low_pwr_oper_state = mcion_reg_data.module_status_bits & (1 << SXD_MCION_LOW_POWER_STATUS_BIT);
        if (mod_low_pwr_oper_state != 0) {
            pwr_attr_p->pwr_mode_attr.oper_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_LOW_E;
        } else {
            pwr_attr_p->pwr_mode_attr.oper_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_HIGH_E;
        }


        pmmp_reg_data.slot_index = module_id_info_p->slot_id;
        pmmp_reg_data.module = module_id_info_p->module_id;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMMP_E, &pmmp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Slot [%u] Module [%u] Attr get, PMMP GET failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        mod_low_pwr_admin_state = pmmp_reg_data.eeprom_override & (1 << SXD_PMMP_MODULE_LOW_POWER_BIT);
        if (mod_low_pwr_admin_state != 0) {
            pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_LOW_E;
        } else {
            pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e = SX_MGMT_PHY_MOD_PWR_MODE_AUTO_E;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_phy_module_pwr_attr_set(const sx_access_cmd_t             cmd,
                                             const sx_mgmt_module_id_info_t   *module_id_info_p,
                                             const sx_mgmt_phy_mod_pwr_attr_t *pwr_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_status_t         roll_back_err = SX_STATUS_SUCCESS;
    struct ku_pmaos_reg pmaos_reg_data;
    struct ku_pmmp_reg  pmmp_reg_data;
    sxd_reg_meta_t      reg_meta;
    uint16_t            is_low_pwr_mode = 0;
    boolean_t           is_port_admin_enabled = FALSE;
    boolean_t           module_disabled = FALSE;
    boolean_t           roll_back = FALSE;
    boolean_t           is_module_present = FALSE;
    boolean_t           is_valid = FALSE;
    boolean_t           is_backplane = FALSE;
    boolean_t           is_independent_module_enabled = FALSE;

    SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();
    UNUSED_PARAM(cmd);

    CHECK_MGMT_LIB_INIT_DONE;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR(
            "This operation is not permitted if SDK is initiated with independent or standalone module support.\n");
        goto out;
    }

    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (pwr_attr_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("pwr_attr_p is NULL, err: %s.\n", sx_status_str(err));
        goto out;
    }

    err = mgmt_lib_is_module_id_info_valid(module_id_info_p, &is_valid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    if (!is_valid) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid slot id[%u] module_id[%u] information, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    err = SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        goto out;
    }

    if (SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set power attribute, device list empty, status (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    err = __mgmt_lib_is_module_backplane_type(module_id_info_p, &is_backplane, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check  if module is backplane slot id[%u] module_id[%u], status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }
    if (is_backplane == TRUE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Module slot id[%u] module_id[%u] is of type backplane, status (%s)\n",
                   module_id_info_p->slot_id, module_id_info_p->module_id, sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmaos_reg_data);
    SX_MEM_CLR(pmmp_reg_data);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    if (pwr_attr_p->power_attr_type & SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E) {
        /* check module is present before attempting to change status.*/
        err = __mgmt_lib_is_module_present(module_id_info_p, &is_module_present);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("slot [%u] module [%d] present status retrieval failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        if (is_module_present == FALSE) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("slot [%u] module [%d] is unplugged. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        /* check if all ports associated with module are down */
        err =
            __mgmt_lib_is_module_logport_admin_enabled(reg_meta.dev_id, module_id_info_p, &is_port_admin_enabled,
                                                       TRUE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Slot[%u] Module [%u] logport status check failed (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        if (is_port_admin_enabled == TRUE) {
            err = SX_STATUS_ERROR;
            goto out;
        }

        /* do PMMP get and check if the current value is same as configured value */
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        pmmp_reg_data.slot_index = module_id_info_p->slot_id;
        pmmp_reg_data.module = module_id_info_p->module_id;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMMP_E, &pmmp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("PMMP Slot [%u] Module [%u] get failed. (%s) \n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        is_low_pwr_mode = pmmp_reg_data.eeprom_override & (1 << SXD_PMMP_MODULE_LOW_POWER_BIT);
        if (((pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e == SX_MGMT_PHY_MOD_PWR_MODE_LOW_E) &&
             (is_low_pwr_mode != 0)) ||
            ((pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e == SX_MGMT_PHY_MOD_PWR_MODE_AUTO_E) &&
             (is_low_pwr_mode == 0))) {
            SX_LOG_DBG("Current power mode and desired power mode are same.\n");
            goto out;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN

        /* disable the module */
        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        pmaos_reg_data.slot_index = module_id_info_p->slot_id;
        pmaos_reg_data.module = module_id_info_p->module_id;
        pmaos_reg_data.oper_status = 0;
        pmaos_reg_data.admin_status = SXD_PMAOS_ADMIN_STATUS_DISABLED_BY_CONFIGURATION_E;
        pmaos_reg_data.ase = SXD_PMAOS_ADMIN_STATE_ENABLE;
        pmaos_reg_data.ee = SXD_PMAOS_EVENT_ENABLE;
        pmaos_reg_data.e = (sxd_pmaos_e_t)SX_EVENT_GENERATE_MODE_GENRATE_SINGLE;
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("PMAOS Slot [%u] Module [%u] set failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END

            module_disabled = TRUE;
        /* Add sleep since PMAOS return ACK before actually set module disable. */
        usleep(SX_MGMT_LIB_PMAOS_DOWN_DELAY_IN_MSEC * 1000);

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN
        reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
        /* change only the power mode from previous get*/
        pmmp_reg_data.eeprom_override_mask = 0xFFFF;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        if (pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e == SX_MGMT_PHY_MOD_PWR_MODE_LOW_E) {
            pmmp_reg_data.eeprom_override |= (1 << SXD_PMMP_MODULE_LOW_POWER_BIT);
        } else { /* power mode is set to AUTO */
            pmmp_reg_data.eeprom_override &= ~(1 << SXD_PMMP_MODULE_LOW_POWER_BIT);
        }
        /* write enable for PMMP register has negative polarity in the over-ride mask(0) */
        pmmp_reg_data.eeprom_override_mask &= ~(1 << SXD_PMMP_MODULE_LOW_POWER_BIT);
        err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMMP_E, &pmmp_reg_data,
                                                                          &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(err)) {
            roll_back = TRUE;
            SX_LOG_ERR("PMMP Slot [%u] Module [%u] get failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(err));
            goto out;
        }
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END
    }

out:
    if (module_disabled) {
        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN
        /* enable the module */
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        pmaos_reg_data.slot_index = module_id_info_p->slot_id;
        pmaos_reg_data.module = module_id_info_p->module_id;
        pmaos_reg_data.oper_status = 0;
        pmaos_reg_data.admin_status = SXD_PMAOS_ADMIN_STATUS_ENABLED_E;
        pmaos_reg_data.ase = SXD_PMAOS_ADMIN_STATE_ENABLE;
        pmaos_reg_data.ee = SXD_PMAOS_EVENT_ENABLE;
        pmaos_reg_data.e = (sxd_pmaos_e_t)SX_EVENT_GENERATE_MODE_GENRATE_SINGLE;
        roll_back_err =
            sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                        &reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(roll_back_err)) {
            SX_LOG_ERR("PMAOS Slot[%u] Module [%u] set failed. (%s)\n",
                       module_id_info_p->slot_id,
                       module_id_info_p->module_id,
                       sx_status_str(roll_back_err));
        }

        if (roll_back == FALSE) {
            err = roll_back_err;
        }

        SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_drv_rearm_module_event(u_int8_t                          dev_id,
                                                     u_int8_t                          slot_id,
                                                     u_int8_t                          module_id,
                                                     sxd_pmaos_e_t                     gen_mode,
                                                     struct ku_rearm_module_event_ret *ret)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    int                          dev_ret = 0;
    struct ku_rearm_module_event rearm;
    sxd_ctrl_pack_t              ctrl_pack = { .ctrl_cmd = CTRL_CMD_REARM_MODULE_EVENT,
                                               .cmd_body = NULL};

    memset(&rearm, 0, sizeof(rearm));

    rearm.dev_id = dev_id;
    rearm.slot = slot_id;
    rearm.module = module_id;
    rearm.gen_mode = (uint8_t)gen_mode;
    ctrl_pack.cmd_body = (void*)&rearm;
    dev_ret = sxd_ioctl(__g_mgmt_lib_device_handle, &ctrl_pack);
    if (dev_ret != 0) {
        SX_LOG(SX_LOG_ERROR, "sxd_ioctl (CTRL_CMD_REARM_MODULE_EVENT) "
               "error:  %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto bail;
    }

    *ret = rearm.ret;

bail:
    return err;
}

sx_status_t mgmt_lib_module_state_event_set(const sx_access_cmd_t          cmd,
                                            const sx_dev_id_t              dev_id,
                                            const sx_slot_id_t             slot_id,
                                            const sx_port_mod_id_t         module_id,
                                            const sx_event_generate_mode_t oper_state_change_event_gen_mode,
                                            sx_port_module_state_t         last_oper_state)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    struct ku_pmaos_reg              pmaos_reg_data;
    struct ku_pmaos_reg              pmaos_reg_data_saved;
    sxd_reg_meta_t                   pmaos_reg_meta;
    sx_event_info_t                  event_info;
    uint32_t                         port_list_size = 0;
    sxd_port_phy_id_t                phy_port_list_p[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    uint32_t                         i = 0;
    boolean_t                        is_valid = FALSE;
    sx_mgmt_module_id_info_t         module_id_info;
    struct ku_rearm_module_event_ret module_ret;

    SX_LOG_ENTER();

    if (FALSE == port_post_init_done_s) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failure - %s\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    SX_MEM_CLR(module_id_info);
    SX_MEM_CLR(module_ret);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    rc = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "slot[%d], module[%d] validation failed.\n", slot_id, module_id);
        goto out;
    }

    if (is_valid == FALSE) {
        SX_LOG(SX_LOG_ERROR,
               "slot[%d] module[%d] validation failed, not enabling future module events.\n",
               slot_id,
               module_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(pmaos_reg_data);
    SX_MEM_CLR(pmaos_reg_data_saved);
    SX_MEM_CLR(pmaos_reg_meta);

    /* O/W: */
    switch (cmd) {
    case SX_ACCESS_CMD_SET:

        /* for ETH ports we should arm the PMPE with UP_ONCE. We put it in kernel mode to sync with other parallel PMAOS settings from kernel sysfs interfaces */
        rc = __mgmt_lib_drv_rearm_module_event(dev_id,
                                               slot_id,
                                               module_id,
                                               (sxd_pmaos_e_t)oper_state_change_event_gen_mode,
                                               &module_ret);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Can't send rearm module %d event: %s\n", module_id, sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }

        /* send PMPE if status was changed */
        if ((module_ret.oper_status != SXD_PMAOS_OPER_STATUS_INITIALIZING_E) &&
            (__sx_mgmt_module_status(module_ret.oper_status) != last_oper_state)) {
            rc = sxd_status_to_sx_status(
                sxd_dpt_port_module_map_port_get(
                    dev_id,
                    slot_id,
                    module_id,
                    phy_port_list_p,
                    &port_list_size));
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "sxd_dpt_port_module_map_port_get error "
                       "slot id [%u] module_id [%x] rc :%d \n", slot_id, module_id, rc);
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            SX_MEM_CLR(event_info);
            for (i = 0; i < port_list_size; i++) {
                event_info.pmpe.log_port_list[i] = 0;
                SX_PORT_DEV_ID_SET(event_info.pmpe.log_port_list[i], dev_id);
                SX_PORT_TYPE_ID_SET(event_info.pmpe.log_port_list[i], SX_PORT_TYPE_NETWORK);
                SX_PORT_PHY_ID_SET(event_info.pmpe.log_port_list[i], phy_port_list_p[i]);
            }
            event_info.pmpe.list_size = port_list_size;
            if (module_ret.oper_status == SXD_PMAOS_OPER_STATUS_MODULE_PLUGGED_WITH_ERROR_E) {
                event_info.pmpe.error_type = (sx_port_module_error_type_t)(module_ret.error_type);
            } else {
                event_info.pmpe.error_type = SX_PORT_MODULE_ERROR_TYPE_RESERVED_E;
            }
            event_info.pmpe.module_state = (sx_port_module_state_t)(module_ret.oper_status);
            event_info.pmpe.device_id = dev_id;
            event_info.pmpe.module_id = module_id;
            event_info.pmpe.slot_id = slot_id;
            rc = host_ifc_send_event(SX_TRAP_ID_PMPE, &(event_info), sizeof(event_info),
                                     SX_EV_SEND_MODE_WITH_EMAD_HDR_E);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Module state event set: Could not send event SX_TRAP_ID_PMPE for "
                           "slot_id [%u] module_id [%x] with state %d, rc :%d \n",
                           slot_id, module_id, event_info.pmpe.module_state, rc);
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            SX_LOG_INF("SW event SX_TRAP_ID_PMPE with state %d was sent OK.\n",
                       event_info.pmpe.module_state);
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        return M_UTILS_SX_LOG_EXIT(rc);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t mgmt_lib_phy_module_state_sync(sx_device_id_t dev_id, sx_slot_id_t slot_id, sx_port_mod_id_t module_id)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    struct ku_pmaos_reg    pmaos_reg_data;
    sxd_reg_meta_t         pmaos_reg_meta;
    sx_port_module_state_t last_module_state;
    uint8_t                admin_status;
    sx_event_info_t        event_info;
    uint32_t               port_list_size = 0;
    sxd_port_phy_id_t      phy_port_list_p[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    uint32_t               i = 0;

    SX_LOG_ENTER();

    if (FALSE == port_post_init_done_s) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failure - %s\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    SX_MEM_CLR(pmaos_reg_data);
    SX_MEM_CLR(pmaos_reg_meta);

    /* check the state before rearm and "UP_ONCE" */
    pmaos_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pmaos_reg_meta.swid = 0;
    pmaos_reg_meta.dev_id = dev_id;
    pmaos_reg_data.slot_index = slot_id;
    pmaos_reg_data.module = module_id;
    pmaos_reg_data.oper_status = 0;
    pmaos_reg_data.admin_status = 0;
    pmaos_reg_data.ase = 0;
    pmaos_reg_data.ee = 0;
    pmaos_reg_data.e = 0;
    rc =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                    &pmaos_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't send GET-PMAOS EMAD (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    admin_status = pmaos_reg_data.admin_status;

    /* send PMPE if status was changed */
    rc = __mgmt_lib_get_module_last_oper_state(slot_id, module_id, &last_module_state);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get last module state (%s).\n",
                   sx_status_str(rc));
        goto out;
    }
    if (__sx_mgmt_module_status(pmaos_reg_data.oper_status) != last_module_state) {
        rc = sxd_status_to_sx_status(
            sxd_dpt_port_module_map_port_get(
                dev_id,
                slot_id,
                module_id,
                phy_port_list_p,
                &port_list_size));
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG(SX_LOG_ERROR, "sxd_dpt_port_module_map_port_get error "
                   "slot_id [%u] module_id [%x] rc :%d \n", slot_id, module_id, rc);
            goto out;
        }

        for (i = 0; i < port_list_size; i++) {
            event_info.pmpe.log_port_list[i] = 0;
            SX_PORT_DEV_ID_SET(event_info.pmpe.log_port_list[i], dev_id);
            SX_PORT_TYPE_ID_SET(event_info.pmpe.log_port_list[i], SX_PORT_TYPE_NETWORK);
            SX_PORT_PHY_ID_SET(event_info.pmpe.log_port_list[i], phy_port_list_p[i]);
        }
        event_info.pmpe.list_size = port_list_size;
        event_info.pmpe.module_state = (sx_port_module_state_t)(pmaos_reg_data.oper_status);
        event_info.pmpe.device_id = dev_id;
        event_info.pmpe.module_id = module_id;
        event_info.pmpe.slot_id = slot_id;
        rc = host_ifc_send_event(SX_TRAP_ID_PMPE, &(event_info), sizeof(event_info),
                                 SX_EV_SEND_MODE_WITH_EMAD_HDR_E);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Module state sync: Could not send event SX_TRAP_ID_PMPE for "
                       "slot_id [%u] module_id [%x] with state %d, rc :%d \n",
                       slot_id, module_id, event_info.pmpe.module_state, rc);
            goto out;
        }
        SX_LOG_INF("SW event SX_TRAP_ID_PMPE with state %d was sent OK.\n",
                   event_info.pmpe.module_state);
    }

    /* Enable module event generation and arm the PMPE with UP_ONCE */
    pmaos_reg_meta.swid = 0;
    pmaos_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pmaos_reg_meta.dev_id = dev_id;
    pmaos_reg_data.slot_index = slot_id;
    pmaos_reg_data.module = module_id;
    pmaos_reg_data.admin_status = admin_status;
    pmaos_reg_data.ase = 0x1;
    pmaos_reg_data.ee = 0x1;
    pmaos_reg_data.e = (sxd_pmaos_e_t)SX_EVENT_GENERATE_MODE_GENRATE_SINGLE;

    rc =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                    &pmaos_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't send SET-PMAOS EMAD (%s)\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t mgmt_lib_phy_module_admin_set(sx_device_id_t                   dev_id,
                                          sx_mgmt_module_id_info_t        *module_id_info_p,
                                          sx_mgmt_phy_module_admin_info_t *admin_info_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta;
    struct ku_pmaos_reg pmaos_reg_data;

    SX_LOG_ENTER();

    CHECK_MGMT_LIB_INIT_DONE;

    if (utils_check_pointer(module_id_info_p, "module_id_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(admin_info_p, "admin_info_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pmaos_reg_data);

    reg_meta.swid = SPECTRUM_SWID;
    reg_meta.dev_id = dev_id;

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pmaos_reg_data.slot_index = module_id_info_p->slot_id;
    pmaos_reg_data.module = module_id_info_p->module_id;
    pmaos_reg_data.admin_status = (sxd_pmaos_admin_status_t)(admin_info_p->admin_state);
    pmaos_reg_data.ase = admin_info_p->admin_state_change;
    pmaos_reg_data.ee = admin_info_p->event_state_change;
    pmaos_reg_data.e = (sxd_pmaos_e_t)(admin_info_p->event_gen_mode);

    err = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PMAOS_E, &pmaos_reg_data,
                                                                      &reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send GET-PMAOS EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mgmt_lib_set_internal_job_func(sx_add_intern_job_cb cb)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (cb == NULL) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __add_internal_job_cb_s = cb;
out:
    SX_LOG_EXIT();
    return err;
}

void mgmt_lib_module_event_map_deinit()
{
    uint32_t slot_count = 0;
    uint32_t slot_index = 0;

    /* Slot(Id) can go from 0 to 0x0F */
    slot_count = RM_API_SLOT_MAX_NUM + 1;

    if (NULL != port_module_ev_list) {
        /* free port modules events list*/
        for (slot_index = 0; slot_index < slot_count; slot_index++) {
            if (port_module_ev_list[slot_index] != NULL) {
                cl_free(port_module_ev_list[slot_index]);
                port_module_ev_list[slot_index] = NULL;
            }
        }
        cl_free(port_module_ev_list);
        port_module_ev_list = NULL;
    }
}

sx_status_t mgmt_lib_module_event_map_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    slot_count = 0;
    uint32_t    slot_index = 0;
    uint32_t    slot_modules_max = 0;

    /* Slot(Id) can go from 0 to 0x0F */
    slot_count = RM_API_SLOT_MAX_NUM + 1;

    /* Allocate slotid(0) for 1U system and for main board in modular system. */
    port_module_ev_list = (port_module_event_t**)cl_calloc((slot_count), sizeof(port_module_event_t*));
    if (!port_module_ev_list) {
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    for (slot_index = 0; slot_index < slot_count; slot_index++) {
        /* Allocate memory for all modules possible, as SDK doesn't track card insertion.*/
        slot_modules_max = rm_resource_global.port_system_port_modules_max;
        port_module_ev_list[slot_index] =
            (port_module_event_t*)cl_calloc(slot_modules_max, sizeof(port_module_event_t));
        if (!port_module_ev_list[slot_index]) {
            rc = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
    }

out:
    if (SX_CHECK_FAIL(rc)) {
        mgmt_lib_module_event_map_deinit();
    }
    return rc;
}

sx_status_t mgmt_lib_is_module_event_disabled(sx_slot_id_t slot_id, uint32_t module_id, boolean_t *event_disabled_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    boolean_t                is_valid = FALSE, is_independent_module_enabled = FALSE;
    sx_mgmt_module_id_info_t module_id_info;

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        *event_disabled_p = TRUE;
        goto out;
    }

    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    rc = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "slot[%d], module[%d] validation failed.\n", slot_id, module_id);
        goto out;
    }

    if (is_valid == FALSE) {
        SX_LOG(SX_LOG_ERROR,
               "slot[%d] module[%d] validation failed, retrieve module event disable.\n",
               slot_id,
               module_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (event_disabled_p == NULL) {
        SX_LOG_ERR("event_disabled_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *event_disabled_p = port_module_ev_list[slot_id][module_id].event_disabled;

out:
    return rc;
}


sx_status_t mgmt_lib_set_module_event_config(sx_slot_id_t slot_id, uint32_t module_id, boolean_t event_disabled)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    boolean_t                is_valid = FALSE;
    sx_mgmt_module_id_info_t module_id_info;


    SX_MEM_CLR(module_id_info);
    module_id_info.slot_id = slot_id;
    module_id_info.module_id = module_id;
    rc = mgmt_lib_is_module_id_info_valid(&module_id_info, &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "slot[%d], module[%d] validation failed.\n", slot_id, module_id);
        goto out;
    }

    if (is_valid == FALSE) {
        SX_LOG(SX_LOG_ERROR,
               "slot[%d] module[%d] validation failed, save disabled module events.\n",
               slot_id,
               module_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    port_module_ev_list[slot_id][module_id].event_disabled = event_disabled;

out:
    return rc;
}


sx_status_t mgmt_lib_module_event_rearm_after_timeout(sx_slot_id_t           slot_id,
                                                      uint32_t               module_id,
                                                      sx_port_module_state_t oper_state,
                                                      sx_dev_id_t            dev_id)
{
    unsigned long long delta;
    sx_status_t        rc = SX_STATUS_SUCCESS;

    port_module_ev_list[slot_id][module_id].module_id = module_id;
    port_module_ev_list[slot_id][module_id].dev_id = dev_id;
    port_module_ev_list[slot_id][module_id].last_oper_state = oper_state;

    delta = __mgmt_lib_event_get_time_msec_delta(&port_module_ev_list[slot_id][module_id].timestamp);
    if (0 == port_module_ev_list[slot_id][module_id].timeout_in_ticks) {
        port_module_ev_list[slot_id][module_id].timeout_in_ticks = MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_1;
        port_module_ev_list[slot_id][module_id].handling_mode = FAST_E;
        SX_LOG(SX_LOG_DEBUG, "Port slot %d, module %d: set timeout 1st time: %d ticks , handling mode: %d\n",
               slot_id,
               module_id,
               port_module_ev_list[slot_id][module_id].timeout_in_ticks,
               port_module_ev_list[slot_id][module_id].handling_mode);
    } else if (delta > (MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_3 * MGMT_LIB_EVENT_TIMER_TICK_IN_MSEC)) {
        port_module_ev_list[slot_id][module_id].timeout_in_ticks = MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_1;
        port_module_ev_list[slot_id][module_id].handling_mode = FAST_E;
        SX_LOG(SX_LOG_DEBUG, "Port slot %d, module %d: set timeout after long time: %d ticks , handling mode: %d\n",
               slot_id,
               module_id,
               port_module_ev_list[slot_id][module_id].timeout_in_ticks,
               port_module_ev_list[slot_id][module_id].handling_mode);
    } else if (port_module_ev_list[slot_id][module_id].handling_mode == FAST_E) {
        port_module_ev_list[slot_id][module_id].timeout_in_ticks = MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_2;
        port_module_ev_list[slot_id][module_id].handling_mode = MEDIUM_E;
        SX_LOG(SX_LOG_DEBUG, "Port slot %d module %d mode FAST: set timeout : %d ticks , handling mode: %d\n",
               slot_id,
               module_id,
               port_module_ev_list[slot_id][module_id].timeout_in_ticks,
               port_module_ev_list[slot_id][module_id].handling_mode);
    } else { /* MEDIUM_E , SLOW_E */
        port_module_ev_list[slot_id][module_id].timeout_in_ticks = MGMT_LIB_EVENT_TIMEOUT_IN_TICKS_TIMER_3;
        port_module_ev_list[slot_id][module_id].handling_mode = SLOW_E;
        SX_LOG(SX_LOG_DEBUG, "Port slot %d module %d mode MEDIUM,SLOW: set timeout : %d ticks , handling mode: %d\n",
               slot_id,
               module_id,
               port_module_ev_list[slot_id][module_id].timeout_in_ticks,
               port_module_ev_list[slot_id][module_id].handling_mode);
    }

    return rc;
}

sx_status_t mgmt_lib_module_event_status_poll(int32_t *active_events_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    local_module = 0;
    uint8_t     slot_id = 0;
    uint32_t    slot_modules_max = 0;
    uint32_t    slot_count = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(active_events_cnt_p, "active_events_cnt_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Slot(Id) can go from 0 to 0x0F */
    slot_count = RM_API_SLOT_MAX_NUM + 1;

    for (slot_id = 0; slot_id < slot_count; slot_id++) {
        slot_modules_max = rm_resource_global.port_system_port_modules_max;
        for (local_module = 0; local_module < slot_modules_max; local_module++) {
            if (0 == port_module_ev_list[slot_id][local_module].timeout_in_ticks) {
                continue;
            }

            /* check if time to die */
            if (event_timer_handler_exit_signal_issued == TRUE) {
                SX_LOG_DBG("Thread __host_ifc_resume_timer_thread is gracefully ending.\n");
                return SX_STATUS_SUCCESS;
            }

            (*active_events_cnt_p)++;

            port_module_ev_list[slot_id][local_module].timeout_in_ticks--;

            /*
             *  if after decrement port_module_ev_p->ev_timeout.
             *  It became 0 then this is timeout
             */
            if (0 == port_module_ev_list[slot_id][local_module].timeout_in_ticks) {
                SX_LOG(SX_LOG_DEBUG, "Port slot %d, module %d Arm new event by PMAOS after timeout.\n",
                       slot_id,
                       port_module_ev_list[slot_id][local_module].module_id);

                /* Set timestamp of last handling event */
                __mgmt_lib_event_set_timestamp(&port_module_ev_list[slot_id][local_module].timestamp);

                /* Arm PMPE event */
                SX_LOG(SX_LOG_DEBUG, "__mgmt_lib_module_status_event_send ( slot_id: 0x%x module_id: 0x%x )\n",
                       slot_id,
                       port_module_ev_list[slot_id][local_module].module_id);
                err = __mgmt_lib_module_status_event_send(port_module_ev_list[slot_id][local_module].dev_id,
                                                          slot_id,
                                                          port_module_ev_list[slot_id][local_module].module_id,
                                                          SX_EVENT_GENERATE_MODE_GENRATE_SINGLE,
                                                          (sx_port_oper_state_t)(port_module_ev_list[slot_id][
                                                                                     local_module].last_oper_state));
                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG(SX_LOG_ERROR, "Port slot %d module %d mgmt_lib_module_event_status_poll failed. err=%d\n",
                           slot_id, local_module, err);
                }
            }
        }           /* for (local_module = 1; local_module < rm_resource_global.port_system_port_modules_max; local_module++) */
    } /* (slot_id = 0; slot_id < ( slot_count+1); slot_id++) */

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mgmt_lib_dump_slot_ini_fsm_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                     sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                     uint32_t             slot_count)
{
    FILE                          *stream = NULL;
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_slot_id_t                   slot_id;
    sx_mgmt_slot_info_t           *slot_id_info_p = NULL;
    uint16_t                       slot_idx = 0;
    sxd_mbct_status_t              ini_oper_status = SXD_MBCT_STATUS_NA_E;
    sxd_mbct_ini_status_t          ini_status = SXD_MBCT_INI_STATUS_EMPTY_NOT_VALID_E;
    sxd_mbct_fsm_state_t           hw_ini_fsm_state = SXD_MBCT_FSM_STATE_IDLE_E;
    sx_mgmt_slot_ini_oper_status_e sx_ini_oper_status;
    sx_mgmt_slot_ini_status_e      sx_ini_status;
    dbg_utils_table_columns_t      slot_ini_fsm_info_clmns[] = {
        { "Slot",                                5,      PARAM_UINT8_E,      &slot_id},
        { "INI Status",                          34,      PARAM_STRING_E,     NULL},
        { "INI Oper Status",                     65,      PARAM_STRING_E,     NULL},
        { "INI FSM state",                       15,      PARAM_UINT32_E,     &hw_ini_fsm_state},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;
    dbg_utils_pprinter_general_header_print(stream, "Slot INI FW State Machine Information");
    dbg_utils_pprinter_table_headline_print(stream, slot_ini_fsm_info_clmns);

    slot_id_info_p = slot_id_info_list_p;
    for (slot_idx = 0; slot_idx < slot_count; slot_idx++) {
        slot_id = slot_id_info_p->slot_id;
        sx_status = __mgmt_lib_fetch_hw_ini_status(slot_id, &ini_status, &ini_oper_status, &hw_ini_fsm_state);
        if (SX_CHECK_FAIL(sx_status)) {
            continue;
        }
        sx_ini_oper_status = __conv_sxd_to_sx_mgmt_slot_ini_oper_status(ini_oper_status);
        sx_ini_status = __conv_sxd_to_sx_mgmt_slot_ini_status(ini_status);
        slot_ini_fsm_info_clmns[1].data = sx_mgmt_slot_ini_status_str(sx_ini_status);
        slot_ini_fsm_info_clmns[2].data = sx_mgmt_slot_ini_oper_status_str(sx_ini_oper_status);
        dbg_utils_pprinter_table_data_line_print(stream, slot_ini_fsm_info_clmns);
        slot_id_info_p++;
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __mgmt_lib_dump_slot_device_sensor_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                           sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                           uint32_t             slot_count)
{
    FILE                      *stream = NULL;
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_slot_id_t               slot_id;
    sx_mgmt_slot_info_t       *slot_id_info_p = NULL;
    uint16_t                   slot_idx = 0, dev_idx = 0;
    uint16_t                   dev_index = 0, sensor_idx = 0, sensor_curr_temp = 0;
    uint16_t                   sensor_max_temp = 0, sensor_temp_th_high = 0, sensor_temp_th_low = 0;
    boolean_t                  sensor_temp_warn_enabled = FALSE, sensor_temp_sd_enabled = FALSE;
    uint32_t                   max_sensor_name_str_len = 17;
    char                       sensor_name_str[max_sensor_name_str_len];
    sx_mgmt_temp_sensor_info_t temp_sensor_info;
    dbg_utils_table_columns_t  slot_dev_sensor_desc_clmns[] = {
        { "Slot",                                5,      PARAM_UINT8_E,      &slot_id},
        { "Device Idx",                          10,     PARAM_UINT16_E,     &dev_index},
        { "Sensor Id",                           9,      PARAM_UINT16_E,     &sensor_idx},
        { "Sensor Name",                         17,     PARAM_STRING_E,     sensor_name_str},
        { "Current temp",                        12,     PARAM_UINT16_E,     &sensor_curr_temp},
        { "Max temp",                            8,      PARAM_UINT16_E,     &sensor_max_temp},
        { "Warn enabled",                        12,     PARAM_BOOL_E,       &sensor_temp_warn_enabled},
        { "Shutdown enabled",                    16,     PARAM_BOOL_E,       &sensor_temp_sd_enabled},
        { "th high",                             7,     PARAM_UINT16_E,      &sensor_temp_th_high},
        { "th low",                              6,     PARAM_UINT16_E,      &sensor_temp_th_low},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();


    SX_MEM_CLR_BUF(sensor_name_str, sizeof(sensor_name_str));
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Slot Temperature Sensor Information");
    dbg_utils_pprinter_table_headline_print(stream, slot_dev_sensor_desc_clmns);
    slot_id_info_p = slot_id_info_list_p;
    for (slot_idx = 0; slot_idx < slot_count; slot_idx++) {
        for (dev_idx = 0; dev_idx < slot_id_info_p->dev_description.slot_device_count; dev_idx++) {
            slot_id = slot_id_info_p->slot_id;
            dev_index = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_index;
            sensor_idx = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_temp_info.sensor_id;
            SX_MEM_CLR(temp_sensor_info);
            sx_status = mgmt_lib_temp_sensor_get(SX_ACCESS_CMD_GET, slot_id, 1, &sensor_idx, &temp_sensor_info);
            if (SX_CHECK_FAIL(sx_status)) {
                continue;
            }
            strncpy(sensor_name_str, temp_sensor_info.sensor_name, sizeof(sensor_name_str));
            sensor_curr_temp = temp_sensor_info.curr_temp;
            sensor_max_temp = temp_sensor_info.max_temp;
            sensor_temp_warn_enabled = temp_sensor_info.temp_warning_enabled;
            sensor_temp_sd_enabled = temp_sensor_info.temp_shutdown_enabled;
            sensor_temp_th_high = temp_sensor_info.temp_threshold_high;
            sensor_temp_th_low = temp_sensor_info.temp_threshold_low;
            dbg_utils_pprinter_table_data_line_print(stream, slot_dev_sensor_desc_clmns);
        }
        slot_id_info_p++;
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __mgmt_lib_dump_slot_description_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                         sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                         uint32_t             slot_count)
{
    FILE                     *stream = NULL;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    uint16_t                  hw_version = 0, minor_version = 0;
    boolean_t                 is_provisioned = FALSE, is_valid = FALSE, is_ready = FALSE, is_active = FALSE;
    char                      card_name_str[SX_MGMT_MAX_SLOT_CARD_NAME];
    sx_slot_id_t              slot_id;
    sx_mgmt_slot_info_t      *slot_id_info_p = NULL;
    uint16_t                  slot_idx = 0;
    dbg_utils_table_columns_t slot_desc_dump_clmns[] = {
        { "Slot",               5,      PARAM_UINT8_E,      &slot_id},
        { "Card Type",          40,     PARAM_STRING_E,     NULL},
        { "Card Name",          20,     PARAM_STRING_E,     card_name_str},
        { "Hw version",         10,     PARAM_UINT16_E,    &hw_version},
        { "Minor version",      13,     PARAM_UINT16_E,    &minor_version},
        { "Provisioned",        11,     PARAM_BOOL_E,      &is_provisioned},
        { "Valid",              6,      PARAM_BOOL_E,      &is_valid},
        { "Ready",              6,      PARAM_BOOL_E,      &is_ready},
        { "Active",             7,      PARAM_BOOL_E,      &is_active},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    SX_MEM_CLR_BUF(card_name_str, sizeof(card_name_str));

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Slot Description");
    dbg_utils_pprinter_table_headline_print(stream, slot_desc_dump_clmns);
    slot_id_info_p = slot_id_info_list_p;
    for (slot_idx = 0; slot_idx < slot_count; slot_idx++) {
        slot_id = slot_id_info_p->slot_id;
        /* coverity[buffer_size_warning] */
        strncpy(card_name_str, slot_id_info_p->slot_description.slot_card_name,
                sizeof(card_name_str));
        hw_version = slot_id_info_p->slot_description.slot_card_ini_info.slot_card_hw_revision;
        minor_version = slot_id_info_p->slot_description.slot_card_ini_info.slot_card_minor_ini_version;
        is_provisioned = slot_id_info_p->slot_description.slot_state_info.is_slot_card_provisioned;
        is_valid = slot_id_info_p->slot_description.slot_state_info.is_slot_card_valid;
        is_ready = slot_id_info_p->slot_description.slot_state_info.is_slot_card_ready;
        is_active = slot_id_info_p->slot_description.slot_state_info.is_slot_card_active;
        slot_desc_dump_clmns[1].data = sx_mgmt_slot_card_type_str(slot_id_info_p->slot_description.slot_card_type);
        dbg_utils_pprinter_table_data_line_print(stream, slot_desc_dump_clmns);
        slot_id_info_p++;
    }

    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __mgmt_lib_dump_slot_device_description_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                                sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                                uint32_t             slot_count)
{
    FILE                     *stream = NULL;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    sx_slot_id_t              slot_id;
    sx_mgmt_slot_info_t      *slot_id_info_p = NULL;
    uint16_t                  slot_idx = 0, dev_idx = 0;
    uint16_t                  dev_index = 0, sensor_idx = 0;
    boolean_t                 is_thermal_sd = FALSE, is_flash_used = FALSE, is_flash_owner = FALSE;
    uint8_t                   flash_id;
    dbg_utils_table_columns_t slot_dev_desc_dump_clmns[] = {
        { "Slot",               5,      PARAM_UINT8_E,      &slot_id},
        { "Device Idx",         10,     PARAM_UINT16_E,     &dev_index},
        { "Flash Used",         10,     PARAM_BOOL_E,       &is_flash_used},
        { "Flash Owner",        11,     PARAM_BOOL_E,       &is_flash_owner},
        { "Flash Id",           8,      PARAM_UINT8_E,      &flash_id},
        { "GB Type",            40,     PARAM_STRING_E,     NULL},
        { "Sensor Id",          9,      PARAM_UINT16_E,     &sensor_idx},
        { "Thermal shutdown",   16,     PARAM_BOOL_E,      &is_thermal_sd},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Slot Device Description");
    dbg_utils_pprinter_table_headline_print(stream, slot_dev_desc_dump_clmns);
    slot_id_info_p = slot_id_info_list_p;
    for (slot_idx = 0; slot_idx < slot_count; slot_idx++) {
        for (dev_idx = 0; dev_idx < slot_id_info_p->dev_description.slot_device_count; dev_idx++) {
            slot_id = slot_id_info_p->slot_id;
            dev_index = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_index;
            is_flash_used = slot_id_info_p->dev_description.slot_device_info[dev_idx].is_flash_used;
            is_flash_owner = slot_id_info_p->dev_description.slot_device_info[dev_idx].is_flash_owner;
            flash_id = slot_id_info_p->dev_description.slot_device_info[dev_idx].flash_id;
            slot_dev_desc_dump_clmns[5].data =
                sx_mgmt_slot_device_gb_type_str(
                    slot_id_info_p->dev_description.slot_device_info[dev_idx].device_gb_type);
            sensor_idx = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_temp_info.sensor_id;
            is_thermal_sd = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_temp_info.thermal_sd;
            dbg_utils_pprinter_table_data_line_print(stream, slot_dev_desc_dump_clmns);
        }
        slot_id_info_p++;
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __mgmt_lib_dump_slot_device_firmware_info(dbg_dump_params_t   *dbg_dump_params_p,
                                                             sx_mgmt_slot_info_t *slot_id_info_list_p,
                                                             uint32_t             slot_count)
{
    FILE                     *stream = NULL;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    sx_slot_id_t              slot_id;
    sx_mgmt_slot_info_t      *slot_id_info_p = NULL;
    uint16_t                  slot_idx = 0, dev_idx = 0;
    uint16_t                  dev_index = 0;
    uint32_t                  max_gb_fw_ver_str_len = 20;
    uint16_t                  dev_fw_major_ver = 0, dev_fw_minor_ver = 0, dev_fw_sub_minor_ver = 0;
    char                      gb_fw_ver_str[max_gb_fw_ver_str_len];
    dbg_utils_table_columns_t slot_dev_desc_fw_info_dump_clmns[] = {
        { "Slot",                   5,  PARAM_UINT8_E,      &slot_id},
        { "Device Idx",             10, PARAM_UINT16_E,     &dev_index},
        { "GB Type",                40, PARAM_STRING_E,     NULL},
        { "FW version",             20, PARAM_STRING_E,     gb_fw_ver_str},
        {NULL, 0, 0, NULL}
    };

    SX_MEM_CLR_BUF(gb_fw_ver_str, sizeof(gb_fw_ver_str));

    stream = dbg_dump_params_p->stream;
    dbg_utils_pprinter_general_header_print(stream, "Slot Device Firmware version Information");
    dbg_utils_pprinter_table_headline_print(stream, slot_dev_desc_fw_info_dump_clmns);
    slot_id_info_p = slot_id_info_list_p;
    for (slot_idx = 0; slot_idx < slot_count; slot_idx++) {
        for (dev_idx = 0; dev_idx < slot_id_info_p->dev_description.slot_device_count; dev_idx++) {
            slot_id = slot_id_info_p->slot_id;
            dev_index = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_index;
            slot_dev_desc_fw_info_dump_clmns[2].data =
                sx_mgmt_slot_device_gb_type_str(
                    slot_id_info_p->dev_description.slot_device_info[dev_idx].device_gb_type);
            dev_fw_major_ver = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_fw_info.fw_major;
            dev_fw_minor_ver = slot_id_info_p->dev_description.slot_device_info[dev_idx].device_fw_info.fw_minor;
            dev_fw_sub_minor_ver =
                slot_id_info_p->dev_description.slot_device_info[dev_idx].device_fw_info.fw_sub_minor;
            snprintf(gb_fw_ver_str, sizeof(gb_fw_ver_str),
                     "%u.%u.%u", dev_fw_major_ver, dev_fw_minor_ver, dev_fw_sub_minor_ver);
            dbg_utils_pprinter_table_data_line_print(stream, slot_dev_desc_fw_info_dump_clmns);
        }
        slot_id_info_p++;
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __mgmt_lib_dump_slot_info(dbg_dump_params_t *dbg_dump_params_p, uint32_t slot_count)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    uint8_t              slot_id = 0;
    sx_slot_id_t        *slot_id_list_p = NULL;
    sx_mgmt_slot_info_t *slot_id_info_list_p = NULL;

    SX_LOG_ENTER();

    slot_id_list_p = (sx_slot_id_t*)cl_calloc(slot_count, sizeof(sx_slot_id_t));
    if (slot_id_list_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Unable to allocate memory for slot id list\n");
        goto out;
    }

    for (slot_id = 1; slot_id <= slot_count; slot_id++) {
        slot_id_list_p[slot_id - 1] = slot_id;
    }
    slot_id_info_list_p = (sx_mgmt_slot_info_t*)cl_calloc(slot_count, sizeof(sx_mgmt_slot_info_t));
    if (slot_id_info_list_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Unable to allocate memory for slot information list\n");
        goto out;
    }
    sx_status = mgmt_lib_slot_info_get(slot_id_list_p, slot_id_info_list_p, slot_count, &slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Unable to allocate memory for slot information list, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = __mgmt_lib_dump_slot_description_info(dbg_dump_params_p, slot_id_info_list_p, slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to dump slot description, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = __mgmt_lib_dump_slot_device_description_info(dbg_dump_params_p, slot_id_info_list_p, slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to dump slot device description information, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = __mgmt_lib_dump_slot_device_firmware_info(dbg_dump_params_p, slot_id_info_list_p, slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to dump slot device firmware information, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = __mgmt_lib_dump_slot_device_sensor_info(dbg_dump_params_p, slot_id_info_list_p, slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to dump slot device sensor information, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = __mgmt_lib_dump_slot_ini_fsm_info(dbg_dump_params_p, slot_id_info_list_p, slot_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to dump slot ini fsm information, err(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
out:
    if (slot_id_info_list_p) {
        CL_FREE_N_NULL(slot_id_info_list_p);
    }

    if (slot_id_list_p) {
        CL_FREE_N_NULL(slot_id_list_p);
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __mgmt_lib_dump_module_info(dbg_dump_params_t *dbg_dump_params_p, uint32_t slot_count)
{
    FILE                           *stream = NULL;
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    uint16_t                        slot_idx = 0;
    uint32_t                        module_count = 0;
    uint32_t                        mod_idx = 0;
    uint8_t                         module_width = 0;
    sxd_pddr_cable_type_t           cable;
    sx_mgmt_phy_module_cable_type_e sx_cable_type;
    sx_mgmt_phy_mod_pwr_attr_t      pwr_attr;
    sx_mgmt_module_id_info_t        module_id_info;
    sx_mgmt_phy_module_info_t       module_info;
    boolean_t                       is_backplane = FALSE;
    sx_mgmt_slot_info_t            *slot_id_info_list_p = NULL;
    sx_slot_id_t                   *slot_id_list_p = NULL;
    uint8_t                         slot_id = 0;
    uint8_t                         slot_list_idx = 0;
    boolean_t                       is_independent_module_enabled = FALSE;
    dbg_utils_table_columns_t       port_dump_module_info_clmns[] = {
        { "Slot ID",                 7,  PARAM_UINT8_E,         &slot_idx},
        { "Module ID",               9,  PARAM_UINT16_E,        &mod_idx},
        { "Module Type",             20, PARAM_STRING_E,        NULL},
        { "Module width",            12, PARAM_UINT8_E,         &module_width},
        { "Oper state",              10, PARAM_STRING_E,        NULL},
        { "Error type",              10, PARAM_STRING_E,        NULL},
        { "Admin Power Mode",        17, PARAM_STRING_E,        NULL},
        { "Oper Power Mode",         16, PARAM_STRING_E,        NULL},
        { "Cable Type",              36, PARAM_STRING_E,        NULL},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        SX_LOG_NTC(
            "Dump module info operation is not supported if SDK is initiated with independent or standalone module mode.\n");
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_secondary_header_print(stream, "Module Information");
    dbg_utils_pprinter_table_headline_print(stream, port_dump_module_info_clmns);

    if (slot_count != 0) {
        slot_id_list_p = (sx_slot_id_t*)cl_calloc(slot_count, sizeof(sx_slot_id_t));
        if (slot_id_list_p == NULL) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Unable to allocate memory for slot id list\n");
            goto out;
        }

        for (slot_id = 1; slot_id <= slot_count; slot_id++) {
            slot_id_list_p[slot_id - 1] = slot_id;
        }

        slot_id_info_list_p = (sx_mgmt_slot_info_t*)cl_calloc(slot_count, sizeof(sx_mgmt_slot_info_t));
        if (slot_id_info_list_p == NULL) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Unable to allocate memory for slot information list\n");
            goto out;
        }

        rc = mgmt_lib_slot_info_get(slot_id_list_p, slot_id_info_list_p, slot_count, &slot_count);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Unable to allocate memory for slot information list, err(%s)\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    if (slot_count == 0) {
        slot_idx = 0;
    } else {
        slot_idx = 1;
    }

    for (; slot_idx <= slot_count; slot_idx++) {
        /* consider only active slots for module information retrieval */
        if (slot_idx != 0) {
            for (slot_list_idx = 0; slot_list_idx < slot_count; slot_list_idx++) {
                if (slot_id_info_list_p[slot_list_idx].slot_id == slot_idx) {
                    break;
                }
            }
            if (slot_id_info_list_p[slot_list_idx].slot_description.slot_state_info.is_slot_card_active != 1) {
                continue;
            }
        }

        /* Get the modules count */
        rc = __mgmt_lib_get_slot_modules_count(slot_idx, &module_count);
        if (SX_CHECK_FAIL(rc)) {
            continue;
        }
        /* Dump each module information */
        for (mod_idx = 0; mod_idx < module_count; mod_idx++) {
            SX_MEM_CLR(pwr_attr);
            SX_MEM_CLR(module_id_info);
            SX_MEM_CLR(module_info);
            module_id_info.slot_id = slot_idx;
            module_id_info.module_id = mod_idx;
            rc = mgmt_lib_phy_module_info_get(&module_id_info, &module_info, 1);
            if (rc != SX_STATUS_SUCCESS) {
                continue;
            }
            module_width = module_info.module_width;
            if (module_info.module_state.oper_state == SX_PORT_MODULE_STATUS_PLUGGED) {
                rc = __is_module_type_backplane(module_info.module_type, &is_backplane);
                if (rc != SX_STATUS_SUCCESS) {
                    continue;
                }
                if (is_backplane == FALSE) {
                    /* Get Module power info for non backplane modules */
                    pwr_attr.power_attr_type = SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E;
                    rc = mgmt_lib_phy_module_pwr_attr_get(SX_ACCESS_CMD_GET, &module_id_info, &pwr_attr);
                    if (rc != SX_STATUS_SUCCESS) {
                        continue;
                    }
                }
                /* Get Cable string here */
                rc = __mgmt_lib_get_module_cable_type(&module_id_info, &cable);
                if (rc != SX_STATUS_SUCCESS) {
                    continue;
                }
                sx_cable_type = __conv_sxd_to_sx_mgmt_phy_module_cable_type(cable);
            } else {
                /* Set cable type to unknown, pwr attr is invalid when module in not plugged */
                sx_cable_type = SX_MGMT_PHY_MODULE_CABLE_TYPE_UNIDENTIFIED_E;
            }
            port_dump_module_info_clmns[2].data = sx_mgmt_phy_module_type_str(module_info.module_type);
            port_dump_module_info_clmns[4].data = sx_port_module_state_str(module_info.module_state.oper_state);
            port_dump_module_info_clmns[5].data = sx_port_module_error_type_str(module_info.module_state.error_type);
            port_dump_module_info_clmns[6].data =
                sx_mgmt_phy_mod_pwr_mode_str(pwr_attr.pwr_mode_attr.admin_pwr_mode_e);
            port_dump_module_info_clmns[7].data = sx_mgmt_phy_mod_pwr_mode_str(pwr_attr.pwr_mode_attr.oper_pwr_mode_e);
            port_dump_module_info_clmns[8].data = sx_mgmt_phy_module_cable_type_str(sx_cable_type);
            dbg_utils_pprinter_table_data_line_print(stream, port_dump_module_info_clmns);
        }
    }

out:
    if (slot_id_info_list_p) {
        CL_FREE_N_NULL(slot_id_info_list_p);
    }

    if (slot_id_list_p) {
        CL_FREE_N_NULL(slot_id_list_p);
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t mgmt_lib_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    FILE                      *stream = NULL;
    uint32_t                   slot_count = 0;
    uint32_t                   max_system_type_str_len = 20;
    char                       system_type_str[max_system_type_str_len];
    sx_mgmt_slot_system_info_t system_info;
    sx_swid_type_t             swid_type = KU_SWID_TYPE_DISABLED;

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_secondary_header_print(stream, "Management Library Module");
    dbg_utils_pprinter_field_print(stream, "Module initialized", &(__is_mgmt_lib_initialized_g), PARAM_BOOL_E);
    if (__is_mgmt_lib_initialized_g == FALSE) {
        goto out;
    }

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    SX_MEM_CLR(system_info);
    SX_MEM_CLR_BUF(system_type_str, sizeof(system_type_str));

    sx_status = port_db_swid_type_get(SPECTRUM_SWID, &swid_type);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Unable to get swid type, err[%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /* Get SWID type and determine slot count. */
    if (swid_type == KU_SWID_TYPE_ETHERNET) {
        sx_status = mgmt_lib_system_info_get(&system_info);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Unable to get system information, err[%s]\n",
                       sx_status_str(sx_status));
            goto out;
        }
        slot_count = system_info.slot_count;
    } else {
        slot_count = 0;
    }

    dbg_utils_pprinter_general_header_print(stream, "System Information");

    if (slot_count == 0) {
        snprintf(system_type_str, sizeof(system_type_str), "%s", "Single Unit");
        dbg_utils_pprinter_field_print(stream, "System Type", system_type_str, PARAM_STRING_E);
    } else {
        snprintf(system_type_str, sizeof(system_type_str), "%s", "Modular");
        dbg_utils_pprinter_field_print(stream, "System Type", system_type_str, PARAM_STRING_E);
        slot_count = system_info.slot_count;
        dbg_utils_pprinter_general_header_print(stream, "Slot Information");
        dbg_utils_pprinter_field_print(stream, "Slot Count", &slot_count,
                                       PARAM_UINT32_E);
        /* Modular system slot information */
        sx_status = __mgmt_lib_dump_slot_info(dbg_dump_params_p, slot_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("__mgmt_lib_dump_slot_info failed. Error: %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }

    if (swid_type == KU_SWID_TYPE_ETHERNET) {
        sx_status = __mgmt_lib_dump_module_info(dbg_dump_params_p, slot_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("__mgmt_lib_dump_module_info failed. Error: %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}
