/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_dbg.h>

#include "ib_router.h"
#include "router_attr_db.h"
#include "sx_api/sx_api_internal.h"
#include "ethl3/sx/router.h"
#include "ethl3/sx/router_db.h"
#include "ethl3/sx/router_mc.h"
#include "ethl3/common/router_utils.h"
#include "ethl2/fdb_common.h"
#include "ethl2/port_db.h"
#include "ethl2/topo.h"
#include "host_ifc/host_ifc.h"
#include "tcal3/ib_tca.h"
#include "ib_router_mc.h"
#include <sx/sdk/sx_status_convertor.h>
#include <include/resource_manager/resource_manager.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include "utils/sx_ip_utils.h"
#include "sx_reg_bulk/sx_reg_bulk.h"

/************************************************
 *  Global variables
 ***********************************************/

extern uint32_t total_router_interfaces;
extern uint8_t  router_module_enabled;
extern uint32_t is_vpi;

/************************************************
 *  Local variables
 ***********************************************/

/* Define all necessary local variables */
#define SX_TCA_SET_LEAF_DEV_VARS                \
    length_t dev_info_arr_size = SX_DEV_ID_MAX; \
    sx_dev_info_t dev_info_arr[SX_DEV_ID_MAX];  \
    length_t      dev_idx = 0

/* Get list of LEAF devices */
#define SX_TCA_GET_LIST_OF_LEAF_DEV \
    topo_device_tbl_bulk_get(       \
        SX_ACCESS_CMD_GET,          \
        &leaf_filter,               \
        dev_info_arr,               \
        &dev_info_arr_size)

#define IB_SWID_ENABLED     2
#define IB_ROUTER_SUPPORTED IB_SWID_ENABLED

#define IB_SWID_DISABLED 1

#define IB_UC_HOST_ADJ_SIZE      2
#define IB_UC_GRH_HOST_ADJ_SIZE  4
#define IB_GRH_HOP_LIMIT_DEFAULT 1

/**
 * neigh_table_entry_t structure is used to store neighbor table entry data.
 */
typedef struct ib_neigh_table_entry {
    neigh_table_entry_common_t common;
    sx_ib_adjacency_t         *adj_param;
} ib_neigh_table_entry_t;

ib_neigh_data_t *ib_neigh_data[NUM_OF_NEIGH_DATA_TYPES_E] = {0};

uint32_t ib_neigh_entered = 0;

router_db_neigh_params_t ib_neigh_init_params;

static uint32_t *curr_pkey_interfaces_s;

static boolean_t sdk_initiated_s = FALSE;

/*TRUE if fw adjacency IB table has been allocated*/
static boolean_t ib_mc_enabled_s = FALSE;

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

sx_status_t __router_attr_device_ready_callback(adviser_event_e event_type,
                                                void           *param);

sx_status_t __router_ib_device_ready_callback(adviser_event_e event_type,
                                              void           *param);

static void __router_interface_ib_ritr_build(const sxd_access_cmd_t      cmd,
                                             const sxd_dev_id_t          dev_id,
                                             const sx_router_interface_t rif,
                                             struct ku_ritr_reg         *ritr_reg_data,
                                             sx_ip_version_t             uc_state,
                                             sx_ip_version_t             mc_state);

static sx_status_t __router_db_ib_neigh_find(const sx_router_id_t     vrid,
                                             const sx_ip_addr_t      *ip_addr,
                                             ib_neigh_table_entry_t **neigh);

static sx_status_t __router_db_ib_neigh_entry_add(ib_neigh_table_entry_t *neigh);

static sx_status_t __router_db_ib_neigh_add(const sx_router_id_t        vrid,
                                            const sx_ip_addr_t         *ip_addr,
                                            const sx_ib_adjacency_t    *adj_param,
                                            const sx_router_action_t    action,
                                            const sx_router_interface_t rif);

static sx_status_t __router_db_ib_neigh_modify(const sx_router_id_t        vrid,
                                               const sx_ip_addr_t         *ip_addr,
                                               const sx_ib_adjacency_t    *adj_param,
                                               const sx_router_action_t    action,
                                               const sx_router_interface_t rif);

static sx_status_t __router_db_ib_neigh_delete(const sx_router_id_t   vrid,
                                               const sx_ip_addr_t    *ip_addr,
                                               sx_router_interface_t *rif);


static sx_status_t __router_db_ib_neigh_delete_all(const sx_router_id_t        vrid,
                                                   const sx_router_interface_t rif,
                                                   const sx_ip_version_t       version);

static sx_status_t __router_db_ib_neigh_set(const sx_access_cmd_t    cmd,
                                            const sx_router_id_t     vrid,
                                            const sx_ip_addr_t      *ip_addr,
                                            const sx_ib_adjacency_t *adj_param,
                                            const sx_router_action_t action,
                                            sx_router_interface_t   *rif);

static sx_status_t __router_db_ib_neigh_get(const sx_router_id_t   vrid,
                                            const sx_ip_addr_t    *ip_addr,
                                            sx_ib_adjacency_t     *adj_param,
                                            sx_router_interface_t *rif);

static sx_status_t __router_db_ib_neigh_test(const sx_router_id_t   vrid,
                                             const sx_ip_addr_t    *ip_addr,
                                             sx_ib_adjacency_t     *adj_param,
                                             sx_router_interface_t *rif,
                                             boolean_t             *activity);

void __ib_router_db_neigh_deinit(const cl_pool_item_t * const pp_pool_item,
                                 void                        *context);

cl_status_t __ib_router_db_neigh_init(void *const             p_object,
                                      void                   *context,
                                      cl_pool_item_t ** const pp_pool_item);

static sx_status_t __find_common_neigh(const sx_router_id_t vrid,
                                       const sx_ip_addr_t  *ip_addr,
                                       neigh_table_info_t **neigh_info_arr);

static sx_status_t __router_db_ib_neigh_info_find(const sx_router_id_t vrid,
                                                  const sx_ip_addr_t  *ip_addr,
                                                  neigh_table_info_t **neigh_info_arr);

static sx_status_t __verify_no_ipoib_parameters(const sx_vpi_router_general_param_t   *general_param_p,
                                                const sx_vpi_router_resources_param_t *resources_param_p);

static sx_status_t __ib_router_neigh_exists_on_vrid(const sx_router_id_t     vrid,
                                                    const neigh_data_types_e neigh_type);

static sx_status_t __router_common_device_deinit(const sx_dev_id_t dev_id);

static sx_status_t __router_db_ib_neigh_entry_sync_to_dev(sxd_dev_id_t dev_id);

static sx_status_t __router_db_ib_neigh_alloc(sx_ip_version_t          version,
                                              ib_neigh_table_entry_t **neigh);

static sx_status_t __router_db_ib_neigh_free(ib_neigh_table_entry_t *neigh);

sx_status_t __router_db_ib_neigh_remove_cb(sx_router_id_t vrid,
                                           sx_ip_addr_t * addr);

static
sx_status_t __ib_router_reserved_neigh_offset_replace(uint32_t           src_index,
                                                      uint32_t           dst_index,
                                                      neigh_data_types_e neigh_type);

static void __router_db_mark_adj_block(uint32_t                    adj_index,
                                       neigh_table_entry_common_t* neigh_object,
                                       adjacency_entry_type_e      neigh_type);

static void __router_db_invalidate_adjacency(neigh_table_entry_common_t* common_neigh);

static char * __ib_router_print_l2_attributes(const void    *attributes_p,
                                              const uint32_t length,
                                              char          *string);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t deinit_vpi_rm_resources()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    rm_resource_global.ib_router_lids_max = rm_resource_global_default.ib_router_lids_max;
    rm_resource_global.ib_router_mc_lids_num_max = rm_resource_global_default.ib_router_mc_lids_num_max;
    rm_resource_global.ib_router_uc_lid_num_max = rm_resource_global_default.ib_router_uc_lid_num_max;

    err = deinit_rm_resources();

    return err;
}

static sx_status_t validate_resources_param(const sx_vpi_router_general_param_t   *general_param_p,
                                            const sx_vpi_router_resources_param_t *resources_param_p,
                                            sx_router_init_params_t               *router_params,
                                            router_db_neigh_params_t              *eth_neigh_params,
                                            router_db_neigh_params_t              *ib_neigh_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    profile_max, actual_max;

    router_params->mc_rpf_enable = general_param_p->rpf_enable;
    router_params->mc_single_egress_rif_enable = general_param_p->mc_single_egress_rif_enable;

    if (!RM_ROUTER_RIF_CHECK_MAX(resources_param_p->max_pkey_router_interfaces)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "max_pkey_router_interfaces [%d] exceeds range [%d] .\n",
               resources_param_p->max_pkey_router_interfaces,
               rm_resource_global.router_rifs_max);
        goto out;
    }
    router_params->max_pkey_router_interfaces_num = resources_param_p->max_pkey_router_interfaces;

    if (!RM_ROUTER_RIF_CHECK_MAX(resources_param_p->max_router_interfaces)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, " max_router_interfaces [%d] exceeds range [%d].\n",
               resources_param_p->max_router_interfaces,
               rm_resource_global.router_rifs_max);
        goto out;
    }
    rm_resource_global.router_rifs_max = resources_param_p->max_router_interfaces;
    router_params->max_router_interfaces_num = resources_param_p->max_router_interfaces;

    if (!RM_ROUTER_VRID_NUM_CHECK_MAX(resources_param_p->max_virtual_routers_num)) {
        SX_LOG(SX_LOG_ERROR, "max_virtual_routers_num [%d] exceeds range [%d].\n",
               resources_param_p->max_virtual_routers_num,
               rm_resource_global.router_vrid_max);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    rm_resource_global.router_vrid_max = resources_param_p->max_virtual_routers_num;
    router_params->virtual_routers_num = resources_param_p->max_virtual_routers_num;

    router_params->uc_version = SX_IP_VERSION_NONE;

    if (general_param_p->ipv4_enable) {
        router_params->uc_version |= SX_IP_VERSION_IPV4;
        if ((resources_param_p->min_ipv4_uc_route_entries > resources_param_p->max_ipv4_uc_route_entries)
            && (resources_param_p->max_ipv4_uc_route_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv4_uc_route_entries [%u] higher than "
                   "max_ipv6_uc_route_entries [%u].\n",
                   resources_param_p->min_ipv4_uc_route_entries,
                   resources_param_p->max_ipv4_uc_route_entries);
            goto out;
        }

        if (!RM_ROUTER_UC_IPV4_CHECK_MAX(resources_param_p->max_ipv4_uc_route_entries
                                         + resources_param_p->max_virtual_routers_num)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv4_uc_route_entries [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv4_uc_route_entries,
                   rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max -
                   resources_param_p->max_virtual_routers_num);
            goto out;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_min =
            resources_param_p->min_ipv4_uc_route_entries + resources_param_p->max_virtual_routers_num;
        /*for backward compatibility*/
        if (resources_param_p->max_ipv4_uc_route_entries != 0) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max =
                resources_param_p->max_ipv4_uc_route_entries + resources_param_p->max_virtual_routers_num;
        } else {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max;
        }
        rm_resource_global.router_ipv4_uc_max =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max -
            resources_param_p->max_virtual_routers_num;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv6_enable) {
        router_params->uc_version |= SX_IP_VERSION_IPV6;
        if ((resources_param_p->min_ipv6_uc_route_entries > resources_param_p->max_ipv6_uc_route_entries)
            && (resources_param_p->max_ipv6_uc_route_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv6_uc_route_entries [%u] higher than "
                   "max_ipv6_uc_route_entries [%u].\n",
                   resources_param_p->min_ipv6_uc_route_entries,
                   resources_param_p->max_ipv6_uc_route_entries);
            goto out;
        }
        if (!RM_ROUTER_UC_IPV6_CHECK_MAX(resources_param_p->max_ipv6_uc_route_entries
                                         + resources_param_p->max_virtual_routers_num)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv6_uc_route_entries [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv6_uc_route_entries,
                   rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max -
                   resources_param_p->max_virtual_routers_num);
            goto out;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_min =
            resources_param_p->min_ipv6_uc_route_entries + resources_param_p->max_virtual_routers_num;
        /*for backward compatibility*/
        if (resources_param_p->max_ipv6_uc_route_entries != 0) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max =
                resources_param_p->max_ipv6_uc_route_entries + resources_param_p->max_virtual_routers_num;
        } else {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max;
        }
        rm_resource_global.router_ipv6_uc_max =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max -
            resources_param_p->max_virtual_routers_num;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv4_mc_enable) {
        if ((resources_param_p->min_ipv4_mc_route_entries > resources_param_p->max_ipv4_mc_route_entries)
            && (resources_param_p->max_ipv4_mc_route_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv4_mc_route_entries [%u] higher than "
                   "max_ipv4_mc_route_entries [%u].\n",
                   resources_param_p->min_ipv4_mc_route_entries,
                   resources_param_p->max_ipv4_mc_route_entries);
            goto out;
        }
        if (!RM_ROUTER_MC_IPV4_CHECK_MAX(resources_param_p->max_ipv4_mc_route_entries
                                         + resources_param_p->max_virtual_routers_num)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv4_mc_route_entries [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv4_mc_route_entries,
                   rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max -
                   resources_param_p->max_virtual_routers_num);
            goto out;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_min =
            resources_param_p->min_ipv4_mc_route_entries + resources_param_p->max_virtual_routers_num;
        profile_max = router_mc_get_max_routes(SX_IP_VERSION_IPV4, router_params->max_router_interfaces_num);
        /*for backward compatibility*/
        if (resources_param_p->max_ipv4_mc_route_entries != 0) {
            if ((general_param_p->mc_single_egress_rif_enable == FALSE) &&
                (resources_param_p->max_ipv4_mc_route_entries > profile_max -
                 router_params->max_router_interfaces_num)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                SX_LOG_ERR("Specified max_ipv4_mc_rt %d > profile max_mc_rt for %u rifs: %d \n",
                           resources_param_p->max_ipv4_mc_route_entries, router_params->max_router_interfaces_num,
                           profile_max - router_params->max_router_interfaces_num);
                goto out;
            }
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max =
                resources_param_p->max_ipv4_mc_route_entries + resources_param_p->max_virtual_routers_num;
        } else {
            actual_max = rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max;
            if (!router_params->mc_single_egress_rif_enable &&
                (actual_max > profile_max)) {
                actual_max = profile_max;
            }

            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max = actual_max;
        }
        rm_resource_global.router_ipv4_mc_max =
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max -
            resources_param_p->max_virtual_routers_num;

        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].is_initialized = TRUE;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_min =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_min;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_max =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_max;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv6_mc_enable) {
        if ((resources_param_p->min_ipv6_mc_route_entries > resources_param_p->max_ipv6_mc_route_entries)
            && (resources_param_p->max_ipv6_mc_route_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv6_mc_route_entries [%u] higher than "
                   "max_ipv6_mc_route_entries [%u].\n",
                   resources_param_p->min_ipv6_mc_route_entries,
                   resources_param_p->max_ipv6_mc_route_entries);
            goto out;
        }
        if (!RM_ROUTER_MC_IPV6_CHECK_MAX(resources_param_p->max_ipv6_mc_route_entries
                                         + resources_param_p->max_virtual_routers_num)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv6_mc_route_entries [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv6_mc_route_entries,
                   rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max -
                   resources_param_p->max_virtual_routers_num);
            goto out;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_min =
            resources_param_p->min_ipv6_mc_route_entries + resources_param_p->max_virtual_routers_num;
        profile_max = router_mc_get_max_routes(SX_IP_VERSION_IPV6, router_params->max_router_interfaces_num);
        if (resources_param_p->max_ipv6_mc_route_entries != 0) {
            if ((general_param_p->mc_single_egress_rif_enable == FALSE) &&
                (resources_param_p->max_ipv6_mc_route_entries > profile_max -
                 router_params->max_router_interfaces_num)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                SX_LOG_ERR("Specified max_ipv6_mc_rt %d > profile max_mc_rt for %u rifs: %d \n",
                           resources_param_p->max_ipv6_mc_route_entries, router_params->max_router_interfaces_num,
                           profile_max - router_params->max_router_interfaces_num);
                goto out;
            }
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max =
                resources_param_p->max_ipv6_mc_route_entries + resources_param_p->max_virtual_routers_num;
        } else {
            actual_max = rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max;
            if (!router_params->mc_single_egress_rif_enable &&
                (actual_max > profile_max)) {
                actual_max = profile_max;
            }

            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max = actual_max;
            /*in case mc ipv4 is initialized (is_initialized = TRUE) l3 mc rep already has value , we want to reserve it */
        }

        rm_resource_global.router_ipv6_mc_max =
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max -
            resources_param_p->max_virtual_routers_num;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].is_initialized = TRUE;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_min =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_min;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_max =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].table_size_max;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv4_enable) {
        if ((resources_param_p->min_ipv4_eth_neighbor_entries > resources_param_p->max_ipv4_eth_neighbor_entries)
            && (resources_param_p->max_ipv4_eth_neighbor_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv4_eth_neighbor_entries [%u] higher than "
                   "max_ipv4_eth_neighbor_entries [%u].\n",
                   resources_param_p->min_ipv4_eth_neighbor_entries,
                   resources_param_p->max_ipv4_eth_neighbor_entries);
            goto out;
        }
        if ((resources_param_p->min_ipv4_ib_neighbor_entries > resources_param_p->max_ipv4_ib_neighbor_entries)
            && (resources_param_p->max_ipv4_ib_neighbor_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv4_ib_neighbor_entries [%u] higher than "
                   "max_ipv4_ib_neighbor_entries [%u].\n",
                   resources_param_p->min_ipv4_ib_neighbor_entries,
                   resources_param_p->max_ipv4_ib_neighbor_entries);
            goto out;
        }
        if (!RM_ROUTER_IPV4_NEIGHS_CHECK_MAX(resources_param_p->max_ipv4_eth_neighbor_entries)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv4_neighbor_entries eth [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv4_eth_neighbor_entries,
                   rm_resource_global_default.router_neigh_max);
            goto out;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_min =
            resources_param_p->min_ipv4_eth_neighbor_entries + resources_param_p->min_ipv4_ib_neighbor_entries;
        eth_neigh_params->ipv4_min_neigh_num = resources_param_p->min_ipv4_eth_neighbor_entries;
        ib_neigh_params->ipv4_min_neigh_num = resources_param_p->min_ipv4_ib_neighbor_entries;
        if ((resources_param_p->max_ipv4_eth_neighbor_entries != 0) &&
            (resources_param_p->max_ipv4_ib_neighbor_entries != 0)) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max =
                resources_param_p->max_ipv4_eth_neighbor_entries + resources_param_p->max_ipv4_ib_neighbor_entries;
        } else if ((is_vpi == IB_SWID_DISABLED) &&
                   (resources_param_p->max_ipv4_eth_neighbor_entries != 0)) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max =
                resources_param_p->max_ipv4_eth_neighbor_entries;
        } else {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max;
        }

        if (resources_param_p->max_ipv4_eth_neighbor_entries != 0) {
            eth_neigh_params->ipv4_max_neigh_num = resources_param_p->max_ipv4_eth_neighbor_entries;
        } else {
            eth_neigh_params->ipv4_max_neigh_num =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max;
        }
        if (resources_param_p->max_ipv4_ib_neighbor_entries != 0) {
            ib_neigh_params->ipv4_max_neigh_num = resources_param_p->max_ipv4_ib_neighbor_entries;
        } else {
            ib_neigh_params->ipv4_max_neigh_num =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].table_size_max;
        }

        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV4_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv6_enable) {
        if ((resources_param_p->min_ipv6_eth_neighbor_entries > resources_param_p->max_ipv6_eth_neighbor_entries)
            && (resources_param_p->max_ipv6_eth_neighbor_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv6_eth_neighbor_entries [%u] higher than "
                   "max_ipv6_eth_neighbor_entries [%u].\n",
                   resources_param_p->min_ipv6_eth_neighbor_entries,
                   resources_param_p->max_ipv6_eth_neighbor_entries);
            goto out;
        }
        if ((resources_param_p->min_ipv6_ib_neighbor_entries > resources_param_p->max_ipv6_ib_neighbor_entries)
            && (resources_param_p->max_ipv6_ib_neighbor_entries != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "min_ipv6_ib_neighbor_entries [%u] higher than "
                   "max_ipv6_ib_neighbor_entries [%u].\n",
                   resources_param_p->min_ipv6_ib_neighbor_entries,
                   resources_param_p->max_ipv6_ib_neighbor_entries);
            goto out;
        }
        if (!RM_ROUTER_IPV6_NEIGHS_CHECK_MAX(resources_param_p->max_ipv6_eth_neighbor_entries +
                                             resources_param_p->max_ipv6_ib_neighbor_entries)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "max_ipv6_neighbor_entries eth+ib [%d] exceeds range [%d].\n",
                   resources_param_p->max_ipv6_eth_neighbor_entries + resources_param_p->max_ipv6_ib_neighbor_entries,
                   rm_resource_global_default.router_neigh_max);
            goto out;
        }

        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_min =
            resources_param_p->min_ipv6_eth_neighbor_entries + resources_param_p->min_ipv6_ib_neighbor_entries;
        eth_neigh_params->ipv6_min_neigh_num = resources_param_p->min_ipv6_eth_neighbor_entries;
        ib_neigh_params->ipv6_min_neigh_num = resources_param_p->min_ipv6_ib_neighbor_entries;
        if ((resources_param_p->max_ipv6_eth_neighbor_entries != 0) &&
            (resources_param_p->max_ipv6_ib_neighbor_entries != 0)) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max =
                resources_param_p->max_ipv6_eth_neighbor_entries + resources_param_p->max_ipv6_ib_neighbor_entries;
        } else if ((is_vpi == IB_SWID_DISABLED) &&
                   (resources_param_p->max_ipv6_eth_neighbor_entries != 0)) {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max =
                resources_param_p->max_ipv6_eth_neighbor_entries;
        } else {
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max;
        }

        if (resources_param_p->max_ipv6_eth_neighbor_entries != 0) {
            eth_neigh_params->ipv6_max_neigh_num = resources_param_p->max_ipv6_eth_neighbor_entries;
        } else {
            eth_neigh_params->ipv6_max_neigh_num =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max;
        }
        if (resources_param_p->max_ipv6_ib_neighbor_entries != 0) {
            ib_neigh_params->ipv6_max_neigh_num = resources_param_p->max_ipv6_ib_neighbor_entries;
        } else {
            ib_neigh_params->ipv6_max_neigh_num =
                rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].table_size_max;
        }
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ARP_IPV6_E].is_initialized = TRUE;
    }

    if (general_param_p->ipv4_enable || general_param_p->ipv6_enable) {
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_min =
            resources_param_p->min_ipv4_eth_neighbor_entries +
            resources_param_p->min_ipv6_eth_neighbor_entries +
            resources_param_p->min_ipv4_ib_neighbor_entries +
            resources_param_p->min_ipv6_ib_neighbor_entries;

        if (rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_min >
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_max) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG(SX_LOG_ERROR, "Sum of neighbor minimums [%d] exceeds adjacency table range [%d].\n",
                   rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_min,
                   rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_max);
            goto out;
        }

        /* Note - user cannot control adjacency table min/max, and no other table competes for this resource
         * So we always set maximum table size to HW maximum
         */
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_max =
            rm_resource_global_default.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_max;

        rm_resource_global.router_adj_max =
            rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_max;
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].is_initialized = TRUE;

        router_db_adjacency_size_set(rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ADJACENCY_E].table_size_min);
    }

    router_params->grh_hop_limit = general_param_p->grh_hop_limit;
    if (router_params->grh_hop_limit == 0) {
        router_params->grh_hop_limit = IB_GRH_HOP_LIMIT_DEFAULT;
    }

out:
    return err;
}

sx_utils_status_t __ib_adjacency_relocate(bin_database_t database,
                                          bin_block_t  * old_block,
                                          bin_block_t  * new_block,
                                          boolean_t      enable_ecmp_move)
{
    uint32_t                 old_index, new_index;
    sx_utils_status_t        utils_err;
    sx_status_t              err = 0;
    adjacency_table_entry_t *old_adj = NULL, *new_adj = NULL;
    ib_neigh_table_entry_t  *neigh = NULL;
    uint8_t                  is_grh = 0;

    SX_LOG_ENTER();

    CL_ASSERT(database == router_db_adjacency_allocator_get());

    utils_err = bin_get_slot_index(database, old_block, &old_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot relocate. cannot get old block index\n");
        goto out;
    }
    old_adj = router_db_adjacency_entry_get(old_index);
    CL_ASSERT(old_adj->used);
    CL_ASSERT(old_adj->block_size == old_block->size);

    if (old_adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E) {
        utils_err = ib_router_mc_adjacency_moved(old_block, new_block);
        goto out;
    }
    if ((old_adj->type != (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E) &&
        (old_adj->type != (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E)) {
        /* Handle ethernet move */
        utils_err = router_db_block_moved(database, old_block, new_block, enable_ecmp_move);
        goto out;
    }

    /*IB_NEIGH consumes two spaces in the Tcam table*/
    /*IB GRH_NEIGH consumes four spaces in the Tcam table*/
    CL_ASSERT(old_adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E ||
              old_adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E);
    CL_ASSERT(old_block->size == IB_UC_HOST_ADJ_SIZE ||
              old_block->size == IB_UC_GRH_HOST_ADJ_SIZE);

    if (old_adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E) {
        is_grh = 1;
    }

    utils_err = bin_get_slot_index(database, new_block, &new_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot relocate. cannot get new block index\n");
        goto out;
    }
    new_adj = router_db_adjacency_entry_get(new_index);
    CL_ASSERT(!new_adj->used);
    if (new_adj->used) {
        SX_LOG(SX_LOG_ERROR, "Cannot relocate. New index %u is already taken\n", new_index);
        utils_err = SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    CL_ASSERT(old_index != new_index);

    /* Note: At this point, the hardware has only the old RATR. */
    neigh = PARENT_STRUCT(old_adj->content.neigh_object, ib_neigh_table_entry_t, common);
    if (bin_block_compare(old_block, &neigh->common.adjacency_block) != 0) {
        goto out;
    }

    /* Write the new RATR -- Only if the old one was already written */
    neigh->common.adjacency_block = *new_block;
    if ((neigh->common.oper_action == SX_ROUTER_ACTION_FORWARD) ||
        (neigh->common.oper_action == SX_ROUTER_ACTION_MIRROR)) {
        err = __router_db_ib_neigh_entry_add(neigh);
        if (err != SX_STATUS_SUCCESS) {
            neigh->common.adjacency_block = *old_block;
            utils_err = SX_STATUS_TO_SX_UTILS_STATUS(err);
            SX_LOG(SX_LOG_ERROR, "Failed to move RATR entry to new index %u\n", new_index);
            goto out;
        }
    }

    /* Update the RUHT */
    err = __router_db_host_add(neigh->common.vrid,
                               neigh->common.ip_addr,
                               neigh->common.action,
                               neigh->common.rif,
                               neigh->common.trap_attr,
                               ADJACENCY_TABLE_IB,
                               new_block,
                               neigh->common.offset,
                               SXD_ROUTER_TCAM_UPDATE);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update host [%x] at the routing DB.\n",
               neigh->common.ip_addr.addr.ipv4.s_addr);
        goto out;
    }

    /* Update RUFTs of single-path and TCAM-based ECMP */
    utils_err = router_db_routes_db_relocate_single_entry(&neigh->common.routes_db);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update adjacency of routes in routes_db.\n");
        goto out;
    }

    /* Delete the old RATR -- Only if it was written in FW*/
    if ((neigh->common.oper_action == SX_ROUTER_ACTION_FORWARD) ||
        (neigh->common.oper_action == SX_ROUTER_ACTION_MIRROR)) {
        err = __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, old_block);
        if (err != SX_STATUS_SUCCESS) {
            utils_err = SX_STATUS_TO_SX_UTILS_STATUS(err);
            SX_LOG(SX_LOG_ERROR, "Failed to delete old RATR entry at index %u\n", new_index);
            goto out;
        }
    }

    __router_db_mark_adj_block(new_index, old_adj->content.neigh_object, old_adj->type);

    old_adj->used = FALSE;

    old_index++;
    old_adj = router_db_adjacency_entry_get(old_index);
    CL_ASSERT(old_adj->used);
    old_adj->used = FALSE;

    if (is_grh) {
        old_index++;
        old_adj = router_db_adjacency_entry_get(old_index);
        CL_ASSERT(old_adj->used);
        old_adj->used = FALSE;

        old_index++;
        old_adj = router_db_adjacency_entry_get(old_index);
        CL_ASSERT(old_adj->used);
        old_adj->used = FALSE;
    }

out:
    return utils_err;
}

uint32_t __ib_adjacency_relocation_cost(bin_database_t database, bin_block_t* old_block)
{
    uint32_t                 cost = 0;
    uint32_t                 adj_index;
    sx_utils_status_t        utils_err;
    ib_neigh_table_entry_t  *neigh = NULL;
    adjacency_table_entry_t* adj_entry = NULL;

    SX_LOG_ENTER();

    CL_ASSERT(database == router_db_adjacency_allocator_get());

    /* Find the neighbor object */
    utils_err = bin_get_slot_index(database, old_block, &adj_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    adj_entry = router_db_adjacency_entry_get(adj_index);
    CL_ASSERT(adj_entry->used);

    if (adj_entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E) {
        cost = ib_router_mc_adjacency_move_cost(old_block);
        goto out;
    }

    if ((adj_entry->type != (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E) &&
        (adj_entry->type != (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E)) {
        /* Handle non-IB neighbor */
        cost = router_db_relocation_cost(database, old_block);
        goto out;
    }

    CL_ASSERT(old_block->size == IB_UC_HOST_ADJ_SIZE || old_block->size == IB_UC_GRH_HOST_ADJ_SIZE);  /*PKEY_NEIGHBOR consumes two spaces in the Tcam table*/

    neigh = PARENT_STRUCT(adj_entry->content.neigh_object, ib_neigh_table_entry_t, common);
    if (bin_block_compare(old_block, &neigh->common.adjacency_block) != 0) {
        goto out;
    }

    /* One neighbor means we need to move one RATR and update one RUHT */
    cost += old_block->size;
    CL_ASSERT(adj_entry->block_size == old_block->size);

    /* And also update all RUFTs of single-path and TCAM-based ECMP that use it */
    cost += router_db_routes_db_relocation_cost(&neigh->common.routes_db);

out:
    SX_LOG_EXIT();
    return cost;
}


sx_status_t ib_router_init_param(const sx_vpi_router_general_param_t   *general_param_p,
                                 const sx_vpi_router_resources_param_t *resources_param_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rollback_err = SX_STATUS_SUCCESS;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_router_init_params_t init_param;

    ib_neigh_entered = 0;
    router_db_neigh_params_t ib_neigh_params;
    router_db_neigh_params_t eth_neigh_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(init_param);
    SX_MEM_CLR(eth_neigh_params);
    SX_MEM_CLR(ib_neigh_params);

    if (sdk_initiated_s) {
        err = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (router_module_enabled) {
        SX_LOG(SX_LOG_ERROR, "Router is already initialized.\n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    err =
        validate_resources_param(general_param_p, resources_param_p, &init_param, &eth_neigh_params, &ib_neigh_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Router params exceeds range.\n");
        goto err_resource_out;
    }


    if (general_param_p->ipv4_mc_enable) {
        if (general_param_p->ipv4_enable) {
            init_param.mc_version |= SX_IP_VERSION_IPV4;
            init_param.mc_enable = TRUE;
        } else {
            SX_LOG(SX_LOG_ERROR, "Must enable IPv4 in order to use IPv4 MC.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto err_resource_out;
        }
    }

    if (general_param_p->ipv6_mc_enable) {
        if (general_param_p->ipv6_enable) {
            init_param.mc_version |= SX_IP_VERSION_IPV6;
            init_param.mc_enable = TRUE;
        } else {
            SX_LOG(SX_LOG_ERROR, "Must enable IPv6 in order to use IPv6 MC.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto err_resource_out;
        }
    }

    if (is_vpi == IB_SWID_DISABLED) {
        err = __verify_no_ipoib_parameters(general_param_p, resources_param_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "There is no IB swid in the system,"
                   " IPoIB router cannot be initialized.\n");
            goto err_resource_out;
        }
    }

    err = router_init(&init_param);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to initialize the router \n");
        goto err_resource_out;
    }

    if (init_param.mc_enable) {
        if (is_vpi == IB_SWID_ENABLED) {
            err = ib_router_mc_init(&ib_neigh_params, resources_param_p);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to initialize IB MC router.\n");
                goto err_router_init_out;
            }
            ib_mc_enabled_s = TRUE;
        }

        err = router_mc_init();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to initialize MC router.\n");
            goto err_ib_router_mc_init_out;
        }
    }

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));

        err = SX_STATUS_ERROR;
        goto err_mc_init_out;
    }

    if (dev_info_arr_size == 0) {
        err = router_allocate_rm_tables_zero_device();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed in allocation of RM router tables.\n");
            goto err_mc_init_out;
        }
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    /*init TCAM tables*/
    err = router_init_device(dev_info_arr[dev_idx].dev_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to initialize device [%u].\n", dev_info_arr[dev_idx].dev_id);
        goto err_mc_init_out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    err = router_db_init(__ib_adjacency_relocation_cost, __ib_adjacency_relocate, &eth_neigh_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init router db, err: %s.\n", sx_status_str(err));
        goto err_init_device_out;
    }

    if (init_param.mc_enable) {
        err = router_mc_init_db_hw();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to initialize MC router database and HW.\n");
            goto err_db_init_out;
        }
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 router_device_ready_callback);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to register advisor with adviser_register_event"
               " error: [%s].\n", sx_status_str(err));
        goto err_mc_init_db_hw_out;
    }
    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 router_init_cntr_cb);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to Unregister advisor with adviser_register_event"
               " error: [%s].\n", sx_status_str(err));
        goto err_mc_init_db_hw_out;
    }

    if (is_vpi == IB_SWID_ENABLED) {
        err = sx_ib_init_router(&init_param, &ib_neigh_params);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ib L3 initialization failed \n");
            goto err_advise_set_out;
        }

        SX_LOG_INF("IB LIB is loaded\n");
        err = ib_tca_port_state_init();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ib tca port initialization failed \n");
            goto err_ib_init_out;
        }
    }

    if (is_vpi == IB_SWID_ENABLED) {
        router_module_enabled = IB_ROUTER_SUPPORTED;
    } else {
        router_module_enabled = IB_SWID_DISABLED;
    }

    goto out;

err_ib_init_out:
    if (is_vpi == IB_SWID_ENABLED) {
        rollback_err = sx_ib_deinit_router();
        if (rollback_err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed in sx_ib_deinit_router.\n");
        }
    }
err_advise_set_out:
    rollback_err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                          router_device_ready_callback);
    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to Unregister advisor with adviser_register_event"
               " error: [%s].\n", sx_status_str(rollback_err));
    }
    rollback_err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                          router_init_cntr_cb);
    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to register advisor with adviser_register_event"
               " error: [%s].\n", sx_status_str(rollback_err));
    }
err_mc_init_db_hw_out:
    if (init_param.mc_enable) {
        rollback_err = router_mc_deinit();
        if (rollback_err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed in router_mc_deinit.\n");
        }
    }
err_db_init_out:
    rollback_err = router_db_deinit();
    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed in router_db_deinit.\n");
    }
err_init_device_out:
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    rollback_err = router_deinit_device(dev_info_arr[dev_idx].dev_id);

    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed in router_deinit_device.\n");
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
err_mc_init_out:
    if (init_param.mc_enable) {
        rollback_err = router_mc_free_resources();
        if (rollback_err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed in router_mc_free_resources.\n");
        }
    }
err_ib_router_mc_init_out:
    if (init_param.mc_enable && (is_vpi == IB_SWID_ENABLED)) {
        rollback_err = ib_router_mc_deinit();
        if (rollback_err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed in ib_router_mc_deinit.\n");
        }
    }
err_router_init_out:
    rollback_err = router_free_resources();
    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed in router_free_resources.\n");
    }
err_resource_out:
    rollback_err = deinit_vpi_rm_resources();
    if (rollback_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed in deinit_vpi_rm_resources.\n");
    }
    ib_mc_enabled_s = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_info_find(const sx_router_id_t vrid,
                                                  const sx_ip_addr_t  *ip_addr,
                                                  neigh_table_info_t **neigh_info_arr)
{
    cl_fmap_item_t             *map_item = NULL;
    const cl_fmap_item_t       *map_end = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;
    neigh_table_entry_common_t *common_neigh = NULL;
    neigh_table_info_t         *neigh_info = NULL;

    SX_LOG_ENTER();

    map_item = cl_fmap_get(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]),
                           ip_addr);
    map_end = cl_fmap_end(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]));
    /* if neigh_info_arr is NULL then only status FOUND/NOT FOUND is needed */
    if (neigh_info_arr == NULL) {
        if (map_item == map_end) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
        }
        goto out;
    }

    /*
     *  This func should be called with neigh_info_arr != NULL only if
     *  ib neigh is existed.
     */
    if (map_item == map_end) {
        SX_LOG(SX_LOG_ERROR, "ib_neigh_info_find failed to find neigh [%x].\n",
               ip_addr->addr.ipv4.s_addr);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }


    /* neigh is found in the neigh DB */
    common_neigh = PARENT_STRUCT(map_item, neigh_table_entry_common_t, map_item);

    if (neigh_info_arr != NULL) {
        err = router_db_neigh_info_get(&neigh_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not get new neigh_info entry.\n");
            goto out;
        }

        neigh_info->action = common_neigh->action;
        neigh_info->oper_action = common_neigh->oper_action;
        neigh_info->ip_addr = common_neigh->ip_addr;
        neigh_info->adjacency_block = &common_neigh->adjacency_block;
        neigh_info->table = ADJACENCY_TABLE_IB;
        neigh_info->rif = common_neigh->rif;
        neigh_info->routes_use = &common_neigh->routes_use;
        neigh_info->state = &common_neigh->state;
        neigh_info->routes_db = &common_neigh->routes_db;
        neigh_info->remove_neigh_cb = common_neigh->remove_neigh_cb;
        *neigh_info_arr = neigh_info;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_common_deinit()
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_router_id_t vrid = 0;

    SX_LOG_ENTER();

    if (!router_module_enabled) {
        goto out;
    }

    if (ib_mc_enabled_s) {
        err = ib_router_mc_deinit();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ib L3 MC router deinit failed. \n");
            goto out;
        }
    }

    for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
        err = __router_db_ib_neigh_delete_all(vrid,
                                              rm_resource_global.router_rifs_max + 1,
                                              router_init_params_s.uc_version);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to remove all ib router [%u] "
                   "neighbors entries at the routing DB.\n", vrid);
            goto out;
        }
    }

    err = ib_tca_port_state_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ib TCA deinitialization failed. \n");
        goto out;
    }

    err = sx_ib_deinit_router();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ib L3 router deinit DB failed. \n");
        goto out;
    }

    err = router_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("router deinitialization failed. \n");
        goto out;
    }

    ib_mc_enabled_s = FALSE;

    err = deinit_vpi_rm_resources();

    /* Free the current PKEY interfaces array */
    if (curr_pkey_interfaces_s != NULL) {
        CL_FREE_N_NULL(curr_pkey_interfaces_s);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_common_device_deinit(const sx_dev_id_t dev_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ib_neigh_entered = 0;

    err = router_deinit_device(dev_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Router deinit Failed.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __find_common_neigh(const sx_router_id_t vrid,
                                       const sx_ip_addr_t  *ip_addr,
                                       neigh_table_info_t **neigh_info_arr)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = __router_db_ib_neigh_info_find(vrid, ip_addr, NULL);
    if (err == SX_STATUS_SUCCESS) {
        err = __router_db_ib_neigh_info_find(vrid, ip_addr, neigh_info_arr);
    } else {
        err = __router_db_neigh_info_find(vrid, ip_addr, neigh_info_arr);
    }

    return err;
}

sx_status_t __ib_router_reserved_neigh_offset_init(neigh_data_types_e neigh_type)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    uint32_t              psort_index = 0;
    router_table_types_e  table_type = IPV4_UC_RT_E;
    cl_pool_item_t       *pool_item = NULL;
    cl_map_item_t        *map_item = NULL;
    neigh_offset_entry_t *neigh_offset_entry = NULL;
    uint32_t              i = 0;
    cl_status_t           cl_st = CL_SUCCESS;

    SX_LOG_ENTER();

    switch (neigh_type) {
    case IPV4_NEIGH_E:
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count =
            ib_neigh_init_params.ipv4_min_neigh_num;
        table_type = IPV4_HOSTS_TABLE_E;
        break;

    case IPV6_NEIGH_E:
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count =
            ib_neigh_init_params.ipv6_min_neigh_num;
        table_type = IPV6_HOSTS_TABLE_E;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported neigh_type [%u].\n", neigh_type);
        status = SX_STATUS_ERROR;
        goto out;
    }

    /* Neighbors reserved offset map */
    cl_qmap_init(&ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map);

    /* Neighbor reserved offset pool. Size is unlimited. */
    cl_st = CL_QPOOL_INIT(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool),
                          rm_resource_global.router_neigh_max,
                          0,
                          rm_resource_global.router_neigh_max,
                          sizeof(neigh_offset_entry_t),
                          NULL, NULL, NULL);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize IB neighbor pool.\n");
        status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    for (i = 0; i < ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count; i++) {
        status = router_db_neigh_offset_psort_get(table_type, &psort_index);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed to Get a free psort entry for reserved rule.\n");
            goto err_out;
        }
        pool_item = cl_qpool_get(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool));
        if (pool_item == NULL) {
            SX_LOG(SX_LOG_ERROR, "Could not allocate neigh_info from the pool.\n");
            status = SX_STATUS_NO_RESOURCES;
            goto err_out;
        }
        neigh_offset_entry = PARENT_STRUCT(pool_item, neigh_offset_entry_t, pool_item);

        neigh_offset_entry->offset = psort_index;
        cl_qmap_insert(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                       neigh_offset_entry->offset, &(neigh_offset_entry->map_item));
    }

    goto out;

err_out:
    map_item = cl_qmap_head(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map));
    while (map_item != cl_qmap_end(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map))) {
        neigh_offset_entry = PARENT_STRUCT(map_item, neigh_offset_entry_t, map_item);
        router_db_neigh_offset_psort_put(table_type, neigh_offset_entry->offset);
        map_item = cl_qmap_get_next(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                                    neigh_offset_entry->offset);
        cl_qmap_remove(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                       neigh_offset_entry->offset);
        cl_qpool_put(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool), &(neigh_offset_entry->pool_item));
    }
    CL_QPOOL_DESTROY(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool));
out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t __ib_router_reserved_neigh_offset_deinit(neigh_data_types_e neigh_type)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    router_table_types_e  table_type;
    cl_map_item_t        *map_item;
    neigh_offset_entry_t *neigh_offset_entry = NULL;

    SX_LOG_ENTER();

    switch (neigh_type) {
    case IPV4_NEIGH_E:
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count =
            ib_neigh_init_params.ipv4_min_neigh_num;
        table_type = IPV4_HOSTS_TABLE_E;
        break;

    case IPV6_NEIGH_E:
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count =
            ib_neigh_init_params.ipv6_min_neigh_num;
        table_type = IPV6_HOSTS_TABLE_E;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported neigh_type [%u].\n", neigh_type);
        status = SX_STATUS_ERROR;
        goto out;
    }

    map_item = cl_qmap_head(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map));
    while (map_item != cl_qmap_end(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map))) {
        neigh_offset_entry = PARENT_STRUCT(map_item, neigh_offset_entry_t, map_item);
        router_db_neigh_offset_psort_put(table_type, neigh_offset_entry->offset);
        map_item = cl_qmap_get_next(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                                    neigh_offset_entry->offset);
        cl_qmap_remove(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                       neigh_offset_entry->offset);
        cl_qpool_put(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool), &(neigh_offset_entry->pool_item));
    }
    CL_QPOOL_DESTROY(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool));

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t ib_router_db_init_by_type(neigh_data_types_e neigh_type)
{
    sx_router_id_t vrid = 0;
    uint32_t       ib_neigh_db_size = 0;
    sx_status_t    err = SX_STATUS_SUCCESS;
    cl_status_t    cl_st = CL_SUCCESS;
    const uint32_t neigh_map_size = rm_resource_global.router_vrid_max - ROUTER_VRID_MIN + 1;

    SX_LOG_ENTER();

    ib_neigh_db_size = sizeof(ib_neigh_data_t);
    /* Allocate neigh_data memory*/
    err = utils_clr_memory_get((void**)(&ib_neigh_data[neigh_type]), 1, ib_neigh_db_size,
                               UTILS_MEM_TYPE_ID_ROUTER_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for the ib neigh table DB.\n");
        goto out;
    }
    /* Allocate the neighbor map array for the current neighbor type */
    /* ib_neigh_data_t *ib_neigh_data[NUM_OF_NEIGH_DATA_TYPES_E]= {0}; */
    ib_neigh_data[neigh_type]->neigh_map =
        (cl_fmap_t*)cl_malloc(sizeof(cl_fmap_t) * neigh_map_size);
    if (!ib_neigh_data[neigh_type]->neigh_map) {
        SX_LOG_ERR("Failed to allocate memory for the IB neighbor map array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    memset(ib_neigh_data[neigh_type]->neigh_map, 0,
           sizeof(cl_fmap_t) * neigh_map_size);

    /* The neigh pool size isn't limited */
    cl_st = CL_QPOOL_INIT(&(ib_neigh_data[neigh_type]->neigh_pool),
                          rm_resource_global.router_neigh_max, 0, rm_resource_global.router_neigh_max,
                          sizeof(ib_neigh_table_entry_t),
                          __ib_router_db_neigh_init, __ib_router_db_neigh_deinit, NULL);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize IB neighbor pool.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    /* Neighbors map */
    for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
        cl_fmap_init(&(ib_neigh_data[neigh_type]->neigh_map[vrid]), __ip_addr_compare);
    }

    err = __ib_router_reserved_neigh_offset_init(neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "__ib_router_reserved_neigh_offset_init failed for %d[neigh_type].\n", neigh_type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_ib_init_router(sx_router_init_params_t *router_init_params, router_db_neigh_params_t *neigh_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Allocate the current PKEY interfaces array */
    /* static uint32_t curr_pkey_interfaces_s[SX_VRID_COUNT]={0}; */
    const uint32_t curr_interfaces_size = rm_resource_global.router_vrid_max - ROUTER_VRID_MIN + 1;

    curr_pkey_interfaces_s = (uint32_t*)cl_malloc(sizeof(uint32_t) * curr_interfaces_size);
    if (!curr_pkey_interfaces_s) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate memory for the current PKEY interfaces array, err: %s.\n", sx_status_str(err));
        goto out;
    }
    memset(curr_pkey_interfaces_s, 0, sizeof(uint32_t) * curr_interfaces_size);

    SX_MEM_CPY_P(&router_init_params_s, router_init_params);
    SX_MEM_CPY_P(&ib_neigh_init_params, neigh_params);


    /*Initiate IPoIB IPv4 DB*/
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV4) {
        err = ib_router_db_init_by_type(IPV4_NEIGH_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "Failed to initiate IPv4 IPoIB router DB table.\n");
            goto out;
        }
    }
    /*Initiate IPoIB IPv6 DB*/
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV6) {
        err = ib_router_db_init_by_type(IPV6_NEIGH_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "Failed to initiate IPv6 IPoIB router DB table.\n");
            goto out;
        }
    }

    __set_find_neigh_func((void*)__find_common_neigh);
    router_set_device_deinit_func((void*)__router_common_device_deinit);
    router_set_verify_neigh_exist_func((void*)__ib_router_neigh_exists_on_vrid);
    router_set_deinit_func((void*)__router_common_deinit);
    router_db_set_reserved_neigh_offset_replace_func((void*)__ib_router_reserved_neigh_offset_replace);

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_attr_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
        utils_memory_put(ib_neigh_data, UTILS_MEM_TYPE_ID_ROUTER_E);
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_ib_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                               __router_ib_device_ready_callback);
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
        return err;
    }

    router_module_enabled = 2;
out:
    SX_LOG_EXIT();
    return err;
}


void __ib_router_db_neigh_deinit(const cl_pool_item_t *const pp_pool_item, void *context)
{
    cl_status_t             err = CL_SUCCESS;
    ib_neigh_table_entry_t *neigh = NULL;

    UNUSED_PARAM(context);

    SX_LOG_ENTER();

    neigh = PARENT_STRUCT(pp_pool_item, ib_neigh_table_entry_t, common.pool_item);

    err = utils_memory_put((void*)(neigh->adj_param), UTILS_MEM_TYPE_ID_ROUTER_E);
    if (err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to deallocate memory for the adjacency information.\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
}

cl_status_t __ib_router_db_neigh_init(void *const p_object, void *context, cl_pool_item_t ** const pp_pool_item)
{
    uint32_t                ib_adjacency_size = 0;
    cl_status_t             err = CL_SUCCESS;
    ib_neigh_table_entry_t *ib_neigh = (ib_neigh_table_entry_t*)p_object;

    UNUSED_PARAM(context);
    SX_LOG_ENTER();
    bin_block_init(&ib_neigh->common.adjacency_block);
    ib_neigh->common.offset = SX_NEIGH_OFFSET_INVALID;

    ib_adjacency_size = sizeof(sx_ib_adjacency_t);
    err = utils_clr_memory_get((void**)(&ib_neigh->adj_param), 1, ib_adjacency_size,
                               UTILS_MEM_TYPE_ID_ROUTER_E);
    if (err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the adjacency information.\n");
        goto out;
    }

    *pp_pool_item = &(ib_neigh->common.pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_ib_deinit_router()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_ib_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_attr_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
    }

    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV4) {
        __ib_router_reserved_neigh_offset_deinit(IPV4_NEIGH_E);
        /* Free the IPV4 neighbor map array */
        CL_FREE_N_NULL(ib_neigh_data[IPV4_NEIGH_E]->neigh_map);

        CL_QPOOL_DESTROY(&(ib_neigh_data[IPV4_NEIGH_E]->neigh_pool));
        err = utils_memory_put((void*)(ib_neigh_data[IPV4_NEIGH_E]), UTILS_MEM_TYPE_ID_ROUTER_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deallocate memory for the ib neigh table DB %s.\n", sx_status_str(err));
        }
        ib_neigh_data[IPV4_NEIGH_E] = NULL;
    }
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV6) {
        __ib_router_reserved_neigh_offset_deinit(IPV6_NEIGH_E);
        /* Free the IPV6 neighbor map array */
        CL_FREE_N_NULL(ib_neigh_data[IPV6_NEIGH_E]->neigh_map);

        CL_QPOOL_DESTROY(&(ib_neigh_data[IPV6_NEIGH_E]->neigh_pool));
        err = utils_memory_put((void*)(ib_neigh_data[IPV6_NEIGH_E]), UTILS_MEM_TYPE_ID_ROUTER_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deallocate memory for the ib neigh table DB %s.\n", sx_status_str(err));
        }
        ib_neigh_data[IPV6_NEIGH_E] = NULL;
    }


    return SX_STATUS_SUCCESS;
}

sx_status_t __ib_router_neigh_exists_on_rif_by_type(const sx_router_id_t        vrid,
                                                    const sx_router_interface_t rif,
                                                    const neigh_data_types_e    neigh_type)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_ENTRY_NOT_FOUND;

    SX_LOG_ENTER();

    if (ib_neigh_data[neigh_type]) {
        map_item = cl_fmap_head(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));
        map_end = cl_fmap_end(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));

        while (map_item != map_end) {
            neigh = PARENT_STRUCT(map_item, ib_neigh_table_entry_t, common.map_item);
            map_item = cl_fmap_next(map_item);

            if ((RM_ROUTER_RIF_CHECK_MAX(rif) == TRUE) &&
                (neigh->common.oper_action == SX_ROUTER_ACTION_FORWARD) &&
                (neigh->common.rif == rif)) {
                err = SX_STATUS_SUCCESS;
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_neigh_exists_on_rif(const sx_router_id_t vrid, const sx_router_interface_t rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Check that at all neighbors are deleted */
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV4) {
        err = __ib_router_neigh_exists_on_rif_by_type(vrid, rif, IPV4_NEIGH_E);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
        } else {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG(SX_LOG_ERROR, "Found IPv4 neighbors which use this vrid: %d / rif: %d [%s].\n",
                   vrid, rif, sx_status_str(err));
            goto out;
        }
    }
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV6) {
        err = __ib_router_neigh_exists_on_rif_by_type(vrid, rif, IPV6_NEIGH_E);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
        } else {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG(SX_LOG_ERROR, "Found IPv6 neighbors which use this vrid: %d / rif: %d [%s].\n",
                   vrid, rif, sx_status_str(err));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_neigh_exists_on_vrid(const sx_router_id_t vrid, const neigh_data_types_e neigh_type)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_ENTRY_NOT_FOUND;

    SX_LOG_ENTER();

    if (router_module_enabled) {
        if (ib_neigh_data[neigh_type]) {
            map_item = cl_fmap_head(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));
            map_end = cl_fmap_end(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));

            while (map_item != map_end) {
                neigh = PARENT_STRUCT(map_item, ib_neigh_table_entry_t, common.map_item);
                map_item = cl_fmap_next(map_item);
                if (neigh->common.state != SX_NEIGH_STATE_ALLOC_BY_SDK_E) {
                    err = SX_STATUS_SUCCESS;
                    goto out;
                }
            }
        }
    }

    err = router_db_neigh_exists_on_vrid(vrid, neigh_type);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_interface_verify_delete(sx_router_id_t vrid, sx_router_interface_t rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Check that all neigh is deleted */
    err = __ib_router_neigh_exists_on_rif(vrid, rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Found neighbors which use this vrid: %d / rif: %d [%s].\n",
               vrid, rif, sx_status_str(err));
        goto out;
    }

    if (ib_mc_enabled_s) {
        if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
            err = ib_router_mc_verify_neigh_exist_on_rif(vrid, IPV4_NEIGH_E, rif);
            if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                err = SX_STATUS_SUCCESS;
            } else {
                err = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG(SX_LOG_ERROR, "Found IPv4 MC neighbors which use this vrid: %d / rif: %d [%s].\n",
                       vrid, rif, sx_status_str(err));
                goto out;
            }
        }
        if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
            err = ib_router_mc_verify_neigh_exist_on_rif(vrid, IPV6_NEIGH_E, rif);
            if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                err = SX_STATUS_SUCCESS;
            } else {
                err = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG(SX_LOG_ERROR, "Found IPv6 MC neighbors which use this vrid: %d / rif: %d [%s].\n",
                       vrid, rif, sx_status_str(err));
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_interface_set(const sx_access_cmd_t              cmd,
                                    const sx_router_id_t               vrid,
                                    const sx_ib_l2_router_interface_t *l2_ibifc,
                                    sx_router_interface_t             *rif)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_status_t                  err_mem = SX_STATUS_SUCCESS;
    sx_l2_ib_router_interface_t *l2_ib_rif;
    interface_util_funcs_t       interface_util_funcs;
    sx_ib_l2_router_interface_t  l2_ibifc_rback;
    uint32_t                     i = 0;
    sx_swid_type_t               swid_type;

    SX_LOG_ENTER();

    if (router_module_enabled != IB_ROUTER_SUPPORTED) {
        SX_LOG(SX_LOG_ERROR, "IPoIB Router is not initialized. \n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (total_router_interfaces == router_init_params_s.max_router_interfaces_num) {
            SX_LOG(SX_LOG_ERROR, "Maximum number of router interfaces %d exist.\n",
                   total_router_interfaces);
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        if (curr_pkey_interfaces_s[vrid] == router_init_params_s.max_pkey_router_interfaces_num) {
            SX_LOG(SX_LOG_ERROR, "Maximum number of router pkey interfaces %d for vrid %d exist.\n",
                   curr_pkey_interfaces_s[vrid], vrid);
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        if ((SX_SWID_CHECK_RANGE(l2_ibifc->swid) != TRUE) || (l2_ibifc->swid == SX_SWID_ID_STACKING)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        err = port_db_swid_type_get(l2_ibifc->swid, &swid_type);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get SWID(%d) type - %s.\n", l2_ibifc->swid, sx_status_str(err));
            goto out;
        }

        if (swid_type != SX_SWID_TYPE_INFINIBAND) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("SWID(%d) type is %s not IB \n",
                       l2_ibifc->swid, (swid_type == 0) ? "DISABLED" : "ETHERNET");
            goto out;
        }

        if (SX_PORT_MTU_CHECK_RANGE(l2_ibifc->mtu) != TRUE) {
            SX_LOG(SX_LOG_ERROR, "Router Interface MTU [%u] exceeds range.\n", l2_ibifc->mtu);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (l2_ibifc->scope > 0x0f) { /*scope is 4 bit*/
            SX_LOG(SX_LOG_ERROR, "Router Interface scope [%u] exceeds range.\n", l2_ibifc->scope);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        for (i = ROUTER_RIFS_MIN; i <= rm_resource_global.router_rifs_max; ++i) {
            if ((router_interfaces[i].used == FALSE) ||
                (((sx_l2_ib_router_interface_t*)(router_interfaces[i].l2_att))->type != SX_L2_INTERFACE_TYPE_PKEY)) {
                continue;
            }

            if (((sx_l2_ib_router_interface_t*)(router_interfaces[i].l2_att))->l2_attr.pkey == l2_ibifc->pkey) {
                SX_LOG_ERR("ib_router_interface_set: rif with pkey %d already exists.\n", l2_ibifc->pkey);
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }

            if (((sx_l2_ib_router_interface_t*)(router_interfaces[i].l2_att))->l2_attr.qkey != l2_ibifc->qkey) {
                SX_LOG_ERR("ib_router_interface_set: rif with different qkey already exists [current qkey - %d].\n",
                           ((sx_l2_ib_router_interface_t*)(router_interfaces[i].l2_att))->l2_attr.qkey);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        M_UTILS_CLR_MEM_GET(&l2_ib_rif,
                            1,
                            sizeof(sx_l2_ib_router_interface_t),
                            UTILS_MEM_TYPE_ID_ROUTER_E,
                            "L2 Router Attributes",
                            err);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Cannot allocate space for router L2 attributes.\n");
            goto out;
        }

        l2_ib_rif->type = SX_L2_INTERFACE_TYPE_PKEY;
        l2_ib_rif->l2_attr = *l2_ibifc;
        SX_MEM_CLR(interface_util_funcs);
        interface_util_funcs.interface_build_ritr = __router_interface_ib_ritr_build;
        interface_util_funcs.interface_delete = router_interface_common_delete;
        err = router_interface_add(vrid,
                                   l2_ib_rif,
                                   rif,
                                   &interface_util_funcs,
                                   l2_ibifc->swid,
                                   __ib_router_print_l2_attributes);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Cannot create Pkey router interface [%u-%u] at router [%u].\n",
                   l2_ibifc->swid, l2_ibifc->pkey, vrid);
            M_UTILS_MEM_PUT(l2_ib_rif, UTILS_MEM_TYPE_ID_ROUTER_E, "Deallocation L2 router attributes", err_mem);
            goto out;
        }

        curr_pkey_interfaces_s[vrid]++;
        total_router_interfaces++;
        break;

    case SX_ACCESS_CMD_EDIT:
        if (RM_ROUTER_RIF_CHECK_MAX(*rif) != TRUE) {
            SX_LOG(SX_LOG_ERROR, "Router Interface [%u] exceeds range.\n", *rif);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (router_interfaces[*rif].used == FALSE) {
            SX_LOG_ERR("Router Interface (%d) err: %s.\n", *rif, sx_status_str(err));
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        if (((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->type != SX_L2_INTERFACE_TYPE_PKEY) {
            SX_LOG(SX_LOG_ERROR, "Router Interface type [%u] is not supported.\n",
                   ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->type);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (SX_PORT_MTU_CHECK_RANGE(l2_ibifc->mtu) != TRUE) {
            SX_LOG(SX_LOG_ERROR, "Router Interface MTU [%u] exceeds range.\n", l2_ibifc->mtu);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (l2_ibifc->scope > 0x0f) { /*scope is 4 bit*/
            SX_LOG(SX_LOG_ERROR, "Router Interface scope [%u] exceeds range.\n", l2_ibifc->scope);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (l2_ibifc->qkey != ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->l2_attr.qkey) {
            SX_LOG(SX_LOG_ERROR, "Cannot Modify qkey for router interface.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        l2_ibifc_rback = ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->l2_attr;
        ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->type = SX_L2_INTERFACE_TYPE_PKEY;
        ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->l2_attr = *l2_ibifc;
        err = router_interface_modify(vrid, *rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__ib_router_interface_modify for vrid %d, interface %d failed, err: %s.\n",
                       vrid, *rif, sx_status_str(err));
            ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->l2_attr = l2_ibifc_rback;
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DELETE:
        if (RM_ROUTER_RIF_CHECK_MAX(*rif) != TRUE) {
            SX_LOG(SX_LOG_ERROR, "Router Interface [%u] exceeds range.\n", *rif);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (router_interfaces[*rif].used == FALSE) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Router Interface (%d) err: %s.\n", *rif, sx_status_str(err));
            goto out;
        }

        if (((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->type != SX_L2_INTERFACE_TYPE_PKEY) {
            SX_LOG(SX_LOG_ERROR, "Router Interface type [%u] is not supported.\n",
                   ((sx_l2_ib_router_interface_t*)(router_interfaces[*rif].l2_att))->type);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = __ib_router_interface_verify_delete(vrid, *rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Rif %d is in use, err: %s.\n", *rif, sx_status_str(err));
            goto out;
        }

        err = router_interface_common_delete(vrid, *rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__ib_router_interface_delete for vrid %d, interface id %d, failed, err: %s.\n",
                       vrid, *rif, sx_status_str(err));
            goto out;
        }

        M_UTILS_MEM_PUT(router_interfaces[*rif].l2_att, UTILS_MEM_TYPE_ID_ROUTER_E,
                        "Deallocation L2 router attributes", err);
        curr_pkey_interfaces_s[vrid]--;
        total_router_interfaces--;

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        for (i = ROUTER_RIFS_MIN; i <= rm_resource_global.router_rifs_max; ++i) {
            if ((router_interfaces[i].used == FALSE) ||
                (router_interfaces[i].vrid != vrid) ||
                (((sx_l2_ib_router_interface_t*)(router_interfaces[i].l2_att))->type != SX_L2_INTERFACE_TYPE_PKEY)) {
                continue;
            }
            err = __ib_router_interface_verify_delete(vrid, i);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Rif %d is in use, err: %s.\n", i, sx_status_str(err));
                goto out;
            }

            err = router_interface_common_delete(vrid, i);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to delete Router Interfaces [%u].\n", i);
                goto out;
            }

            M_UTILS_MEM_PUT(router_interfaces[i].l2_att, UTILS_MEM_TYPE_ID_ROUTER_E,
                            "Deallocation L2 router attributes", err);
            curr_pkey_interfaces_s[vrid]--;
            total_router_interfaces--;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s.\n", cmd, sx_status_str(err));
        break;
    }
out:
    SX_LOG_EXIT();

    return err;
}


sx_status_t ib_router_interface_get(sx_router_interface_t        rif,
                                    sx_router_id_t              *vrid,
                                    sx_ib_l2_router_interface_t *l2_ibifc)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (router_module_enabled != IB_ROUTER_SUPPORTED) {
        SX_LOG(SX_LOG_ERROR, "IPoIB Router is not initialized. \n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (RM_ROUTER_RIF_CHECK_MAX(rif) != TRUE) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("rif (%d) err: %s.\n", rif, sx_status_str(err));
        goto out;
    }

    if ((router_interfaces[rif].used == FALSE) ||
        (((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->type != SX_L2_INTERFACE_TYPE_PKEY)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("rif (%d) err: %s.\n", rif, sx_status_str(err));
        goto out;
    }

    *vrid = router_interfaces[rif].vrid;
    *l2_ibifc = ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_neigh_set(const sx_access_cmd_t       cmd,
                                const sx_router_id_t        vrid,
                                const sx_ip_addr_t         *ip_addr,
                                const sx_ib_adjacency_t    *adj_param,
                                const sx_router_action_t    action,
                                const sx_router_interface_t rif)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_router_interface_t neigh_rif = rif;
    supported_rif_types_t supported_rif_types;

    SX_LOG_ENTER();

    if (router_module_enabled != IB_ROUTER_SUPPORTED) {
        SX_LOG(SX_LOG_ERROR, "IPoIB Router is not initialized. \n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    memset(&supported_rif_types, 0, sizeof(supported_rif_types));
    supported_rif_types.type[SX_L2_INTERFACE_TYPE_PKEY] = 1;
    err = router_neigh_set_param_check(cmd, vrid, ip_addr, rif, &supported_rif_types, action, SX_TRAP_PRIORITY_LOW);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("router_db_neigh_set params check for vrid %d failed, err: %s.\n",
                   vrid, sx_status_str(err));
        goto out;
    }

    err = __router_db_ib_neigh_set(cmd, vrid, ip_addr, adj_param, action, &neigh_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("router_db_ib_neigh_set for vrid %d failed, err: %s.\n",
                   vrid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_neigh_get(const sx_access_cmd_t  cmd,
                                const sx_router_id_t   vrid,
                                const sx_ip_addr_t    *ip_addr,
                                sx_ib_adjacency_t     *adj_param,
                                sx_router_interface_t *rif,
                                boolean_t             *activity)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    supported_rif_types_t supported_rif_types;

    SX_LOG_ENTER();

    if (router_module_enabled != IB_ROUTER_SUPPORTED) {
        SX_LOG(SX_LOG_ERROR, "IPoIB Router is not initialized. \n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    memset(&supported_rif_types, 0, sizeof(supported_rif_types));
    supported_rif_types.type[SX_L2_INTERFACE_TYPE_PKEY] = 1;
    err = router_neigh_set_param_check(cmd, vrid, ip_addr, *rif, &supported_rif_types, 0, 0);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("vrid (%d) err: %s.\n",
                   vrid, sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = __router_db_ib_neigh_get(vrid, ip_addr, adj_param, rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("router_db_neigh_get for vrid %d failed, err: %s.\n",
                       vrid, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_TEST:
        err = __router_db_ib_neigh_test(vrid, ip_addr, adj_param, rif, activity);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("router_db_neigh_test for vrid %d failed, err: %s.\n",
                       vrid, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static void __router_interface_ib_ritr_build(const sxd_access_cmd_t      cmd,
                                             const sxd_dev_id_t          dev_id,
                                             const sx_router_interface_t rif,
                                             struct ku_ritr_reg         *ritr_reg_data,
                                             sx_ip_version_t             uc_state,
                                             sx_ip_version_t             mc_state)
{
    /* It cannot be Spectrum chip so we should keep the 'op' field reserved */
    UNUSED_PARAM(dev_id);
    ritr_reg_data->valid = (cmd != SXD_ACCESS_CMD_DELETE);
    ritr_reg_data->op = 0; /* reserved */

    ritr_reg_data->enable =
        (uc_state != SX_IP_VERSION_NONE || mc_state != SX_IP_VERSION_NONE);
    ritr_reg_data->ipv4_enable =
        ((uc_state == SX_IP_VERSION_IPV4) ||
         (uc_state == SX_IP_VERSION_IPV4_IPV6));
    ritr_reg_data->ipv6_enable =
        ((uc_state == SX_IP_VERSION_IPV6) ||
         (uc_state == SX_IP_VERSION_IPV4_IPV6));
    ritr_reg_data->ipv4_mc =
        ((mc_state == SX_IP_VERSION_IPV4) ||
         (mc_state == SX_IP_VERSION_IPV4_IPV6));
    ritr_reg_data->ipv6_mc =
        ((mc_state == SX_IP_VERSION_IPV6) ||
         (mc_state == SX_IP_VERSION_IPV4_IPV6));
    ritr_reg_data->type = PKEY_INTERFACE;
    ritr_reg_data->router = router_interfaces[rif].vrid;
    ritr_reg_data->router_interface = rif;

    ritr_reg_data->rif_properties.pkey_interface.swid =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.swid;
    ritr_reg_data->rif_properties.pkey_interface.pkey =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.pkey;
    ritr_reg_data->rif_properties.pkey_interface.qkey =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.qkey;
    ritr_reg_data->rif_properties.pkey_interface.qpn =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.qpn;
    ritr_reg_data->rif_properties.pkey_interface.scope =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.scope;
    ritr_reg_data->mtu =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.mtu;
    ritr_reg_data->ttl_threshold =
        ((sx_l2_ib_router_interface_t*)(router_interfaces[rif].l2_att))->l2_attr.multicast_ttl_threshold;
    if (router_interfaces[rif].cntr != NULL) {
        ritr_reg_data->ingress_counter_set =
            router_interfaces[rif].cntr->ingress_counter_set;
        ritr_reg_data->egress_counter_set =
            router_interfaces[rif].cntr->egress_counter_set;
    }
}

static sx_status_t __router_db_ib_neigh_find(const sx_router_id_t     vrid,
                                             const sx_ip_addr_t      *ip_addr,
                                             ib_neigh_table_entry_t **neigh)
{
    cl_fmap_item_t       *map_item = NULL;
    const cl_fmap_item_t *map_end = NULL;
    sx_status_t           err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    map_item = cl_fmap_get(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]),
                           ip_addr);
    map_end = cl_fmap_end(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]));

    if (map_item != map_end) {
        *neigh = PARENT_STRUCT(map_item, ib_neigh_table_entry_t, common.map_item);
    } else {
        *neigh = NULL;
    }

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __router_db_ib_neigh_entry_add(ib_neigh_table_entry_t *neigh)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_ratr_reg  ratr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    uint32_t            index;
    rm_sdk_table_type_e resource;

    SX_LOG_ENTER();

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    bin_get_slot_index(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block, &index);

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;
    reg_meta[dev_idx].mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

    SX_MEM_CLR(ratr_reg_data[dev_idx]);

    ratr_reg_data[dev_idx].operation = SXD_ROUTER_ARP_OPERATION_WRITE;
    ratr_reg_data[dev_idx].valid = SXD_ROUTE_ADJECENCY_WRITE;
    ratr_reg_data[dev_idx].type = PKEY_UNI_WITHOUT_GRH;
    ratr_reg_data[dev_idx].table = ADJACENCY_TABLE_IB;
    ratr_reg_data[dev_idx].egress_rif = neigh->common.rif;
    ratr_reg_data[dev_idx].adjacency_index = index;

    if (neigh->adj_param->is_grh) {
        ratr_reg_data[dev_idx].type = PKEY_UNI_WITH_GRH;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.dlid = neigh->adj_param->dlid;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.dqpn = neigh->adj_param->dqpn;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.my_lid = (uint8_t)neigh->adj_param->my_lid;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.sl = neigh->adj_param->sl;
        SX_MEM_CPY_TYPE(ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet,
                        neigh->adj_param->dgid.addr_octet,
                        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet);
    } else {
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_without_grh_parameters.dlid = neigh->adj_param->dlid;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_without_grh_parameters.dqpn = neigh->adj_param->dqpn;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_without_grh_parameters.my_lid =
            (uint8_t)neigh->adj_param->my_lid;
        ratr_reg_data[dev_idx].adj_parameters.pkey_uni_without_grh_parameters.sl = neigh->adj_param->sl;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
    resource = RM_SDK_TABLE_TYPE_ADJACENCY_E;
    err = rm_entries_set(resource, SX_ACCESS_CMD_ADD, 1, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set entries in RM for %s\n",
               SX_RESOURCE_MSG(resource));
        goto out;
    }
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RATR_E,
                                                     ratr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed RATR allocate set: id [%u], err [%s].\n",
               index, SXD_STATUS_MSG(sxd_status));
        rm_entries_set(resource, SX_ACCESS_CMD_DELETE, 1, NULL);
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_entry_sync_to_dev_by_type(sxd_dev_id_t dev_id, neigh_data_types_e neigh_type)
{
    sxd_reg_meta_t          reg_meta;
    struct ku_ratr_reg      ratr_reg_data;
    sxd_status_t            sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t             err = SX_STATUS_SUCCESS;
    ib_neigh_table_entry_t *neigh = NULL;
    sx_router_id_t          vrid;
    struct ku_ruht_reg      ruht_reg_data;
    uint32_t                index;
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(ratr_reg_data);

    for (vrid = 0; vrid < router_init_params_s.virtual_routers_num; vrid++) {
        map_item = cl_fmap_head(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));
        map_end = cl_fmap_end(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));

        while (map_item != map_end) {
            neigh = PARENT_STRUCT(map_item, ib_neigh_table_entry_t, common.map_item);
            map_item = cl_fmap_next(map_item);

            if ((RM_ROUTER_RIF_CHECK_MAX(neigh->common.rif) != TRUE) ||
                (neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_SDK_E)) {
                continue;
            }

            if ((neigh->common.action == SX_ROUTER_ACTION_FORWARD) ||
                (neigh->common.action == SX_ROUTER_ACTION_MIRROR)) {
                bin_get_slot_index(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block, &index);

                reg_meta.dev_id = dev_id;
                reg_meta.access_cmd = SXD_ACCESS_CMD_ADD;
                reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

                ratr_reg_data.operation = SXD_ROUTER_ARP_OPERATION_WRITE;
                ratr_reg_data.valid = SXD_ROUTE_ADJECENCY_WRITE;
                ratr_reg_data.type = PKEY_UNI_WITHOUT_GRH;
                ratr_reg_data.table = ADJACENCY_TABLE_IB;
                ratr_reg_data.adjacency_index = index;
                ratr_reg_data.egress_rif = neigh->common.rif;
                if (neigh->adj_param->is_grh) {
                    ratr_reg_data.type = PKEY_UNI_WITH_GRH;
                    ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.dlid = neigh->adj_param->dlid;
                    ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.dqpn = neigh->adj_param->dqpn;
                    ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.my_lid =
                        (uint8_t)neigh->adj_param->my_lid;
                    ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.sl = neigh->adj_param->sl;
                    SX_MEM_CPY_TYPE(ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet,
                                    neigh->adj_param->dgid.addr_octet,
                                    ratr_reg_data.adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet);
                } else {
                    ratr_reg_data.adj_parameters.pkey_uni_without_grh_parameters.dlid = neigh->adj_param->dlid;
                    ratr_reg_data.adj_parameters.pkey_uni_without_grh_parameters.dqpn = neigh->adj_param->dqpn;
                    ratr_reg_data.adj_parameters.pkey_uni_without_grh_parameters.my_lid = neigh->adj_param->my_lid;
                    ratr_reg_data.adj_parameters.pkey_uni_without_grh_parameters.sl = neigh->adj_param->sl;
                }

                sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RATR_E,
                                                                 &ratr_reg_data,
                                                                 &reg_meta,
                                                                 1,
                                                                 NULL,
                                                                 NULL);
                if (sxd_status != SXD_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Failed RATR allocate set: index [%u], err [%s].\n",
                           index, SXD_STATUS_MSG(sxd_status));
                    err = sxd_status_to_sx_status(sxd_status);
                    goto out;
                }
            }

            /* add ruht  */
            SX_MEM_CLR(reg_meta);
            SX_MEM_CLR(ruht_reg_data);

            reg_meta.dev_id = dev_id;
            reg_meta.access_cmd = SXD_ACCESS_CMD_ADD;

            ruht_reg_data.offset = neigh->common.offset;
            ruht_reg_data.offset_enable = TRUE;
            ruht_reg_data.valid = TRUE;
            ruht_reg_data.route_type =
                (neigh->common.ip_addr.version == SX_IP_VERSION_IPV4) ?
                SXD_ROUTER_ROUTE_TYPE_IPV4 : SXD_ROUTER_ROUTE_TYPE_IPV6;
            ruht_reg_data.operation = SXD_ROUTER_TCAM_WRITE;
            ruht_reg_data.router = vrid;

            sdk_router_utils_assign_ip(ruht_reg_data.destination_ip, &neigh->common.ip_addr);

            ruht_reg_data.ecmp_hash = 0;
            ruht_reg_data.ecmp_hash_mask = 0;

            switch (neigh->common.action) {
            case SX_ROUTER_ACTION_DROP:
                ruht_reg_data.route_action = SXD_ROUTER_ROUTE_ACTION_SOFT_DROP;
                break;

            case SX_ROUTER_ACTION_FORWARD:
                ruht_reg_data.route_action = SXD_ROUTER_ROUTE_ACTION_PERMIT;
                ruht_reg_data.table = ADJACENCY_TABLE_IB;
                ruht_reg_data.adjacency_index = index;

                err = __router_db_get_qos_mode(neigh->common.rif, &ruht_reg_data.qos);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "__router_db_get_qos_mode failed with err %d [%s].\n",
                           err, sx_status_str(err));
                    goto out;
                }

                break;

            case SX_ROUTER_ACTION_TRAP:
                ruht_reg_data.route_action = SXD_ROUTER_ROUTE_ACTION_SOFT_DROP_TRAP;
                /*we use PRIO_LOW priority as default*/
                ruht_reg_data.trap_group = SX_TRAP_PRIORITY_LOW;
                ruht_reg_data.trap_id = SX_TRAP_ID_L3_NEIGH_IP_BASE +
                                        ruht_reg_data.trap_group;
                break;

            default:
                SX_LOG(SX_LOG_ERROR, "Unsupported router action [%u].\n", neigh->common.action);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RUHT_E,
                                                             &ruht_reg_data,
                                                             &reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed RUHT set: [%s].\n",
                       SXD_STATUS_MSG(sxd_status));
                if (sxd_status == SXD_STATUS_FW_NO_RESOURCES) {
                    err = SX_STATUS_NO_RESOURCES;
                    goto out;
                } else {
                    err = sxd_status_to_sx_status(sxd_status);
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __router_db_ib_neigh_entry_sync_to_dev(sxd_dev_id_t dev_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV4) {
        err = __router_db_ib_neigh_entry_sync_to_dev_by_type(dev_id, IPV4_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Unable to add all IPv4 IB neighbor entries to device: %d\n", dev_id);
            goto out;
        }
    }
    if (router_init_params_s.uc_version & SX_IP_VERSION_IPV6) {
        err = __router_db_ib_neigh_entry_sync_to_dev_by_type(dev_id, IPV6_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Unable to add all IPv6 IB neighbor entries to device: %d\n", dev_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_alloc(sx_ip_version_t version, ib_neigh_table_entry_t **neigh)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    ib_neigh_table_entry_t *new_neigh = NULL;
    cl_pool_item_t         *pool_item = NULL;

    SX_LOG_ENTER();

    /* The neigh isn't found in DB , so create it */
    pool_item = cl_qpool_get(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(version)]->neigh_pool));
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_DEBUG, "Failed cl_qpool_get. Neigh IB alloc failed.\n");
        *neigh = NULL;
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    new_neigh = PARENT_STRUCT(pool_item, ib_neigh_table_entry_t, common.pool_item);
    new_neigh->common.routes_use = 0;
    cl_qmap_init(&(new_neigh->common.routes_db));
    new_neigh->common.state = SX_NEIGH_STATE_ALLOC_BY_SDK_E;
    bin_block_init(&new_neigh->common.adjacency_block);
    new_neigh->common.offset = SX_NEIGH_OFFSET_INVALID;
    new_neigh->common.remove_neigh_cb = __router_db_ib_neigh_remove_cb;

    *neigh = new_neigh;

out:
    SX_LOG_EXIT();
    return err;
}

#if 0
void __router_db_ib_neigh_route_dump(ib_neigh_table_entry_t *neigh)
{
    cl_map_item_t           *map_item = NULL;
    const cl_map_item_t     *map_end = NULL;
    neigh_routes_db_entry_t *neigh_routes_db_entry = NULL;
    routing_table_entry_t   *route_entry = NULL;
    uint32_t                 i = 0;
    char                     ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                     ip_prefix_mask_str[FORMAT_BUFFER_SIZE] = {0};
    char                     ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    map_item = cl_qmap_head(&(neigh->routes_db));
    map_end = cl_qmap_end(&(neigh->routes_db));

    SX_LOG(SX_LOG_ERROR, "IB Neigh : %s , Alloc by: %s , routes attached %d, rif: %d : \n",
           format_ip_addr(neigh->ip_addr, ip_addr_str),
           neigh->state == SX_NEIGH_STATE_ALLOC_BY_SDK_E ? "SDK" : "USER",
           cl_qmap_count(&(neigh->routes_db)),
           neigh->rif);
    while (map_item != map_end) {
        neigh_routes_db_entry = PARENT_STRUCT(map_item, neigh_routes_db_entry_t, map_item);
        route_entry = neigh_routes_db_entry->route_entry;
        map_item = cl_qmap_next(map_item);
        SX_LOG(SX_LOG_ERROR, "%d : route %s:%s, action %s, ecmp [ data %p, index %d, neigh_id: %d ] \n",
               i,
               format_prefix(route_entry->uc.network_addr, ip_prefix_str),
               format_prefix_mask(route_entry->uc.network_addr, ip_prefix_mask_str),
               sx_router_action_str(route_entry->uc.action),
               route_entry->uc.ecmp_data,
               route_entry->uc.ecmp_index,
               route_entry->uc.next_hop_index);
        i++;
    }
}
#endif

static sx_status_t __router_db_ib_neigh_free(ib_neigh_table_entry_t *neigh)
{
    uint32_t    attached_routes_num;
    sx_status_t err = SX_STATUS_SUCCESS;
    char        ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    /* check to validate that neigh deleted only if no route point to it */
    attached_routes_num = cl_qmap_count(&(neigh->common.routes_db));
    if (attached_routes_num > 0) {
        SX_LOG(SX_LOG_DEBUG, "__router_db_neigh_free for neigh %s failed !!! "
               "Some routes still use this entry.\n",
               format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    cl_qpool_put(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(neigh->common.ip_addr.version)]->neigh_pool),
                 &(neigh->common.pool_item));

out:
    SX_LOG_EXIT();
    return err;
}

static
sx_status_t __ib_router_neigh_offset_get(const router_table_types_e table_type, uint32_t * psort_index)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    cl_map_item_t        *map_item;
    const cl_map_item_t  *map_end;
    neigh_offset_entry_t *neigh_offset_entry = NULL;
    neigh_data_types_e    neigh_type;
    uint32_t              max_entries_num;

    SX_LOG_ENTER();

    switch (table_type) {
    case IPV4_HOSTS_TABLE_E:
        neigh_type = IPV4_NEIGH_E;
        max_entries_num = ib_neigh_init_params.ipv4_max_neigh_num;
        break;

    case IPV6_HOSTS_TABLE_E:
        neigh_type = IPV6_NEIGH_E;
        max_entries_num = ib_neigh_init_params.ipv6_max_neigh_num;
        break;

    default:
        SX_LOG_ERR("table_type unsupported: %d\n", table_type);
        goto out;
    }

    map_item = cl_qmap_head(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map));
    map_end = cl_qmap_end(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map));
    if (map_item == map_end) {
        if (ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count >= max_entries_num) {
            SX_LOG(SX_LOG_ERROR, "Max num of IB neighbors is - [%d].\n", max_entries_num);
            status = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        status = router_db_neigh_offset_psort_get(table_type, psort_index);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "__router_db_neigh_offset_psort_get failed. ERROR = %s.\n",
                   sx_status_str(status));
            goto out;
        }
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count++;
        goto out;
    }

    neigh_offset_entry = PARENT_STRUCT(map_item, neigh_offset_entry_t, map_item);
    *psort_index = neigh_offset_entry->offset;

    cl_qmap_remove(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map), neigh_offset_entry->offset);
    cl_qpool_put(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool), &(neigh_offset_entry->pool_item));

out:
    SX_LOG_EXIT();
    return status;
}

static
sx_status_t __ib_router_db_neigh_offset_put(router_table_types_e table_type, uint32_t offset)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    uint32_t              neigh_min_count = 0;
    cl_pool_item_t       *pool_item = NULL;
    neigh_offset_entry_t *neigh_offset_entry = NULL;
    neigh_data_types_e    neigh_type;

    SX_LOG_ENTER();

    switch (table_type) {
    case IPV4_HOSTS_TABLE_E:
        neigh_type = IPV4_NEIGH_E;
        neigh_min_count = ib_neigh_init_params.ipv4_min_neigh_num;
        break;

    case IPV6_HOSTS_TABLE_E:
        neigh_type = IPV6_NEIGH_E;
        neigh_min_count = ib_neigh_init_params.ipv6_min_neigh_num;
        break;

    default:
        SX_LOG_ERR("table type unsupported: %d\n", table_type);
        goto out;
    }

    if (ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count >= neigh_min_count) {
        status = router_db_neigh_offset_psort_put(table_type, offset);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "__router_db_neigh_offset_psort_put failed. ERROR = %s.\n",
                   sx_status_str(status));
            goto out;
        }
        ib_neigh_data[neigh_type]->ib_neigh_allocated_offset_count--;
        goto out;
    }

    pool_item = cl_qpool_get(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_pool));

    neigh_offset_entry = PARENT_STRUCT(pool_item, neigh_offset_entry_t, pool_item);
    neigh_offset_entry->offset = offset;
    cl_qmap_insert(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                   neigh_offset_entry->offset, &(neigh_offset_entry->map_item));

out:
    SX_LOG_EXIT();
    return status;
}

static void __router_db_mark_adj_block(uint32_t                    adj_index,
                                       neigh_table_entry_common_t* neigh_object,
                                       adjacency_entry_type_e      neigh_type)
{
    uint32_t                 end_idx = adj_index + neigh_object->adjacency_block.size;
    adjacency_table_entry_t* entry = NULL;

    /* Mark this entry in the array */
    entry = router_db_adjacency_entry_get(adj_index);

    CL_ASSERT(!entry->used);
    entry->used = TRUE;
    entry->type = neigh_type;
    entry->block_size = neigh_object->adjacency_block.size;
    entry->content.neigh_object = neigh_object;
    adj_index++;

    /* Mark this entry as a reserved entry*/
    while (adj_index < end_idx) {
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(!entry->used);
        entry->used = TRUE;
        entry->type = (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E;
        adj_index++;
    }
}

static sx_status_t __router_db_ib_neigh_add(const sx_router_id_t        vrid,
                                            const sx_ip_addr_t         *ip_addr,
                                            const sx_ib_adjacency_t    *adj_param,
                                            const sx_router_action_t    action,
                                            const sx_router_interface_t rif)
{
    ib_neigh_table_entry_t  *neigh = NULL;
    sx_trap_attributes_t     trap_attr;
    sx_status_t              err = SX_STATUS_SUCCESS;
    boolean_t                is_neigh_newly_allocated = FALSE;
    eth_neigh_table_entry_t *eth_neigh = NULL;
    router_table_types_e     table_type;
    char                     ip_addr_str[FORMAT_BUFFER_SIZE] = {0};
    uint32_t                 psort_offset;
    uint32_t                 adj_index;
    sx_utils_status_t        utils_err;
    adjacency_entry_type_e   neigh_type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E;

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if (neigh == NULL) {
        router_db_neigh_find(vrid, ip_addr, &eth_neigh);
        if ((eth_neigh != NULL) && (eth_neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_USER_E)) {
            SX_LOG(SX_LOG_ERROR, "Neighbor [%s] already allocated by USER in ETH side.\n",
                   format_ip_addr(ip_addr, ip_addr_str));
            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }

        /* The neigh isn't found in DB , so create it */
        err = __router_db_ib_neigh_alloc(ip_addr->version, &neigh);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not alloc IB neighbor entry for IP [%s]. \n",
                   format_ip_addr(ip_addr, ip_addr_str));
            goto out;
        }

        is_neigh_newly_allocated = TRUE;
        neigh->common.ip_addr = *ip_addr;

        /* replace the neigh in UC routes */
        if ((eth_neigh != NULL) && (cl_qmap_count(&(eth_neigh->common.routes_db)) > 0)) {
            err = __router_db_routes_update_neigh(&(eth_neigh->common.routes_db),
                                                  &neigh->common.routes_use,  &neigh->common.state,
                                                  &neigh->common.routes_db, neigh->common.remove_neigh_cb);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "__router_db_routes_update_neigh failed with err: %s when"
                       "created IB neighbor entry for IP [%s]. \n",
                       sx_status_str(err), format_ip_addr(ip_addr, ip_addr_str));
                goto out;
            }
        }
    } else {
        SX_LOG(SX_LOG_DEBUG, "Neighbor [%s] already exists at the neigh DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        /*
         *  If still added by user return ALREADY_EXISTS .
         *  The user should use EDIT command to change already existed Neighs                                                                               .
         */
        if (neigh->common.state != SX_NEIGH_STATE_ALLOC_BY_SDK_E) {
            SX_LOG(SX_LOG_ERROR, "Neighbor [%s] already added by user to neigh DB.\n",
                   format_ip_addr(ip_addr, ip_addr_str));
            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
    }

    SX_MEM_CPY_P(neigh->adj_param, adj_param);
    neigh->common.action = action;
    neigh->common.oper_action = action;
    neigh->common.rif = rif;
    neigh->common.vrid = vrid;

    /* Allocate a double entry for IB adjacency */
    neigh->common.adjacency_block.size = IB_UC_HOST_ADJ_SIZE;
    if (neigh->adj_param->is_grh) {
        neigh->common.adjacency_block.size = IB_UC_GRH_HOST_ADJ_SIZE;
        neigh_type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E;
    }
    CL_ASSERT(!bin_is_block_valid(&neigh->common.adjacency_block));

    /*  Allocate Adjacency only when action == FWD */
    if (action == SX_ROUTER_ACTION_FORWARD) {
        err = router_db_allocate_adjacency(&neigh->common.adjacency_block);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_NOTICE, "Failed bin_allocate. IB Neigh add failed.\n");
            if (is_neigh_newly_allocated) {
                __router_db_ib_neigh_free(neigh);
            }
            bin_block_init(&neigh->common.adjacency_block);
            goto out;
        }

        utils_err =
            bin_get_slot_index(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block, &adj_index);
        if (utils_err != SX_UTILS_STATUS_SUCCESS) {
            err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
            SX_LOG(SX_LOG_ERROR, "Cannot determine block index. IB Neigh add failed.\n");
            err = router_db_deallocate_adjacency(&neigh->common.adjacency_block);
            if (is_neigh_newly_allocated) {
                __router_db_ib_neigh_free(neigh);
            }
            goto out;
        }

        /* RATR */
        err = __router_db_ib_neigh_entry_add(neigh);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not  add IB neighbor entry, IP [%s], at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            bin_free(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block);
            if (is_neigh_newly_allocated) {
                __router_db_ib_neigh_free(neigh);
            }
            bin_block_init(&neigh->common.adjacency_block);
            goto out;
        }
    }

    /*Get PSort index for hosts table*/
    table_type = (ip_addr->version == SX_IP_VERSION_IPV4) ?
                 IPV4_HOSTS_TABLE_E : IPV6_HOSTS_TABLE_E;

    err = __ib_router_neigh_offset_get(table_type, &psort_offset);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find free neigh offset.\n");
        err = SX_STATUS_NO_RESOURCES;
        if (action == SX_ROUTER_ACTION_FORWARD) {
            __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
        }
        bin_free(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block);
        if (is_neigh_newly_allocated) {
            __router_db_ib_neigh_free(neigh);
        }
        bin_block_init(&neigh->common.adjacency_block);
        goto out;
    }

    trap_attr.prio = SX_TRAP_PRIORITY_LOW;
    neigh->common.offset = psort_offset;
    err = __router_db_host_add(
        vrid,
        neigh->common.ip_addr, neigh->common.action,
        neigh->common.rif,
        trap_attr,
        ADJACENCY_TABLE_IB,
        &neigh->common.adjacency_block,
        neigh->common.offset,
        SXD_ROUTER_TCAM_WRITE);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not add host [%s] at the routing DB.\n",
               format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
        if (action == SX_ROUTER_ACTION_FORWARD) {
            __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
        }

        bin_free(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block);
        __ib_router_db_neigh_offset_put(table_type, neigh->common.offset);
        if (is_neigh_newly_allocated) {
            __router_db_ib_neigh_free(neigh);
        }
        bin_block_init(&neigh->common.adjacency_block);

        goto out;
    }

    /* Update all routes which use this neigh */
    err = __router_db_neigh_update_routes(&neigh->common.routes_db,
                                          neigh->common.action,
                                          neigh->common.oper_action,
                                          ADJACENCY_TABLE_IB,
                                          &neigh->common.adjacency_block,
                                          neigh->common.rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update routes of IB neigh [%s].\n",
               format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
        __router_db_host_delete(neigh->common.offset, neigh->common.ip_addr);
        if (action == SX_ROUTER_ACTION_FORWARD) {
            __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
        }

        bin_free(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block);
        __ib_router_db_neigh_offset_put(table_type, neigh->common.offset);
        if (is_neigh_newly_allocated) {
            __router_db_ib_neigh_free(neigh);
        }
        bin_block_init(&neigh->common.adjacency_block);
        goto out;
    }

    /* add the neigh to DB only if newly allocated */
    if (is_neigh_newly_allocated == TRUE) {
        cl_fmap_insert(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]),
                       &(neigh->common.ip_addr), &(neigh->common.map_item));
    }
    /* set the neigh state to alloc-by-user only after success of
     *  all FW configurations : adj + host entry */
    neigh->common.state = SX_NEIGH_STATE_ALLOC_BY_USER_E;

    router_db_neigh_index_map_add(&neigh->common);

    if (action == SX_ROUTER_ACTION_FORWARD) {
        /* Mark this entry in the array */
        __router_db_mark_adj_block(adj_index, &neigh->common, neigh_type);
    }

out:
    if (err == SX_STATUS_SUCCESS) {
        ++ib_neigh_entered;
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_modify(const sx_router_id_t        vrid,
                                               const sx_ip_addr_t         *ip_addr,
                                               const sx_ib_adjacency_t    *adj_param,
                                               const sx_router_action_t    action,
                                               const sx_router_interface_t rif)
{
    ib_neigh_table_entry_t *neigh = NULL;
    sx_trap_attributes_t    trap_attr;
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_utils_status_t       utils_err;
    uint32_t                adj_index;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};
    adjacency_entry_type_e  neigh_type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E;

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if (neigh == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find IB neighbor [%s] at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_SDK_E) {
        SX_LOG(SX_LOG_ERROR, "Could not edit IB neighbor [%s] in state alloc-by-sdk.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /*Set default prio*/
    trap_attr.prio = SX_TRAP_PRIORITY_LOW;

    /*New action is DROP/TRAP, update Host table according*/
    if (action != SX_ROUTER_ACTION_FORWARD) {
        err = __router_db_host_add(vrid, neigh->common.ip_addr, action, rif, trap_attr, ADJACENCY_TABLE_IB,
                                   &neigh->common.adjacency_block, neigh->common.offset, SXD_ROUTER_TCAM_UPDATE);
    }
    /*Action was Forward and is staying Forward, move host table to TRAP temporarily*/
    else if ((action == SX_ROUTER_ACTION_FORWARD) && (neigh->common.action == SX_ROUTER_ACTION_FORWARD)) {
        err = __router_db_host_add(vrid,
                                   neigh->common.ip_addr,
                                   SX_ROUTER_ACTION_TRAP,
                                   neigh->common.rif,
                                   trap_attr,
                                   ADJACENCY_TABLE_IB,
                                   &neigh->common.adjacency_block,
                                   neigh->common.offset,
                                   SXD_ROUTER_TCAM_UPDATE);
    }
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not  add host [%s] at the routing DB.\n",
               format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
        goto out;
    }
    /* Remove old ARP */
    if (neigh->common.action == SX_ROUTER_ACTION_FORWARD) {
        err = __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not delete neighbor entry, IP [%s], at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }

        /* If previous action was FWD need to release adjacency record */
        /* Mark this entry in the adjacency array */
        __router_db_invalidate_adjacency(&neigh->common);
    }

    SX_MEM_CPY_P(neigh->adj_param, adj_param);
    neigh->common.action = action;
    neigh->common.oper_action = action;
    neigh->common.rif = rif;

    /* If new action is Forward, Add the updated ARP and change host table to Forward*/
    if (action == SX_ROUTER_ACTION_FORWARD) {
        neigh->common.adjacency_block.size = IB_UC_HOST_ADJ_SIZE;
        if (neigh->adj_param->is_grh) {
            neigh->common.adjacency_block.size = IB_UC_GRH_HOST_ADJ_SIZE;
            neigh_type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E;
        }
        err = router_db_allocate_adjacency(&neigh->common.adjacency_block);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_NOTICE, "Failed bin_allocate. IB Neigh modify failed.\n");
            bin_block_init(&neigh->common.adjacency_block);
            goto out;
        }

        utils_err =
            bin_get_slot_index(router_db_adjacency_allocator_get(), &neigh->common.adjacency_block, &adj_index);
        if (utils_err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Cannot determine block index. IB Neigh modify failed.\n");
            err = router_db_deallocate_adjacency(&neigh->common.adjacency_block);
            if (err) {
                SX_LOG(SX_LOG_ERROR, "Failed in deallocating adjacency entry in IB neigh modify err = %d\n", err);
            }
            err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
            goto out;
        }

        __router_db_mark_adj_block(adj_index, &neigh->common, neigh_type);

        err = __router_db_ib_neigh_entry_add(neigh);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not add neighbor entry, IP [%s], at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }

        err = __router_db_host_add(vrid,
                                   neigh->common.ip_addr,
                                   neigh->common.action,
                                   neigh->common.rif,
                                   neigh->common.trap_attr,
                                   ADJACENCY_TABLE_IB,
                                   &neigh->common.adjacency_block,
                                   neigh->common.offset,
                                   SXD_ROUTER_TCAM_UPDATE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not  add host [%s] at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }
    }

    /* Update all routes which use this neigh */
    err = __router_db_neigh_update_routes(&neigh->common.routes_db,
                                          neigh->common.action,
                                          neigh->common.oper_action,
                                          ADJACENCY_TABLE_IB,
                                          &neigh->common.adjacency_block,
                                          neigh->common.rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update routes of IB neigh [%s].\n",
               format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t __router_db_ib_neigh_remove_cb(sx_router_id_t vrid, sx_ip_addr_t* ip_addr)
{
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if (neigh == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find IB neighbor [%s] at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (neigh->common.state != SX_NEIGH_STATE_ALLOC_BY_SDK_E) {
        SX_LOG(SX_LOG_ERROR, "Error : Try to remove [%s] IB neigh IN ALLOC_BY_USER state .\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    cl_fmap_remove_item(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]),
                        &(neigh->common.map_item));
    __router_db_ib_neigh_free(neigh);

out:
    SX_LOG_EXIT();

    return err;
}

static void __router_db_invalidate_adjacency(neigh_table_entry_common_t* common_neigh)
{
    uint32_t                 adj_index = 0;
    adjacency_table_entry_t* entry = NULL;
    uint8_t                  is_grh = 0;

    /* Mark this entry in the adjacency array */
    bin_get_slot_index(router_db_adjacency_allocator_get(), &common_neigh->adjacency_block, &adj_index);
    entry = router_db_adjacency_entry_get(adj_index);
    CL_ASSERT(entry->used);
    CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E ||
              entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E);
    CL_ASSERT(entry->content.neigh_object == common_neigh);
    if (entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E) {
        is_grh = 1;
    }
    entry->used = FALSE;

    adj_index++;
    entry = router_db_adjacency_entry_get(adj_index);
    CL_ASSERT(entry->used);
    CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E);
    entry->used = FALSE;

    /* GRH entry has a size of 4 */
    if (is_grh) {
        adj_index++;
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(entry->used);
        CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E);
        entry->used = FALSE;

        adj_index++;
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(entry->used);
        CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E);
        entry->used = FALSE;
    }

    /* Free the adjacency block */
    bin_free(router_db_adjacency_allocator_get(), &common_neigh->adjacency_block);
    bin_block_init(&common_neigh->adjacency_block);
}

static void __router_db_invalidate_neigh(neigh_table_entry_common_t* common_neigh)
{
    router_table_types_e table_type;

    if (common_neigh->action == SX_ROUTER_ACTION_FORWARD) {
        __router_db_invalidate_adjacency(common_neigh);
    }
    router_db_neigh_index_map_remove(common_neigh);
    table_type = (common_neigh->ip_addr.version == SX_IP_VERSION_IPV4) ?
                 IPV4_HOSTS_TABLE_E : IPV6_HOSTS_TABLE_E;
    __ib_router_db_neigh_offset_put(table_type, common_neigh->offset);
}

static sx_status_t __router_db_ib_neigh_delete(const sx_router_id_t   vrid,
                                               const sx_ip_addr_t    *ip_addr,
                                               sx_router_interface_t *rif)
{
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                attached_routes_num = 0;
    sx_event_info_t         event_info;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if ((neigh == NULL) || (neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_SDK_E)) {
        SX_LOG(SX_LOG_ERROR, "Could not find IB neighbor [%s] at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (rif) {
        *rif = neigh->common.rif;
    }

    attached_routes_num = cl_qmap_count(&neigh->common.routes_db);
    if (attached_routes_num == 0) {
        err = __router_db_host_delete(neigh->common.offset, neigh->common.ip_addr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not  delete host [%s] at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }
        if (neigh->common.action == SX_ROUTER_ACTION_FORWARD) {
            if (neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_SDK_E) {
                /* send event no need to resolve */
                event_info.no_need_to_resolve_arp.vrid = neigh->common.vrid;
                event_info.no_need_to_resolve_arp.ip_addr = neigh->common.ip_addr;
                event_info.no_need_to_resolve_arp.rif = rm_resource_global.router_rifs_dontcare;
                err = host_ifc_send_event(SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP,
                                          &(event_info.no_need_to_resolve_arp),
                                          sizeof(event_info.no_need_to_resolve_arp),
                                          SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Could not send event NEED_TO_RESOLVE for  IP [%s]	\n",
                           format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
                    goto out;
                }
            }

            err = __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not  delete neighbor entry, IP [%s], at the routing DB.\n",
                       format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
                goto out;
            }
        }

        __router_db_invalidate_neigh(&neigh->common);

        cl_fmap_remove_item(&(ib_neigh_data[VERSION_TO_NEIGH_TYPE(ip_addr->version)]->neigh_map[vrid]),
                            &(neigh->common.map_item));
        __router_db_ib_neigh_free(neigh);
    } else {
        /* existed routes which use current neigh entry */

        /* Update all routes which use this neigh */
        err = __router_db_neigh_update_routes(&neigh->common.routes_db,
                                              neigh->common.action,
                                              SX_ROUTER_ACTION_TRAP,
                                              ADJACENCY_TABLE_IB,
                                              &neigh->common.adjacency_block,
                                              neigh->common.rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not update routes of neigh [%s].\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }

        /* update host rule to action TRAP */
        err = __router_db_host_delete(neigh->common.offset, neigh->common.ip_addr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not change neigh [%s] action to TRAP .\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }
        if (neigh->common.action == SX_ROUTER_ACTION_FORWARD) {
            err = __router_db_neigh_entry_delete(ADJACENCY_TABLE_IB, &neigh->common.adjacency_block);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not  delete neighbor entry, IP [%s], at the routing DB.\n",
                       format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
                goto out;
            }

            /* send event need to resolve */
            event_info.no_need_to_resolve_arp.vrid = neigh->common.vrid;
            event_info.no_need_to_resolve_arp.ip_addr = neigh->common.ip_addr;
            event_info.no_need_to_resolve_arp.rif = rm_resource_global.router_rifs_dontcare;
            err = host_ifc_send_event(SX_TRAP_ID_NEED_TO_RESOLVE_ARP,
                                      &(event_info.no_need_to_resolve_arp),
                                      sizeof(event_info.no_need_to_resolve_arp),
                                      SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not send event NEED_TO_RESOLVE for  IP [%s]	\n",
                       format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
                goto out;
            }
        }

        __router_db_invalidate_neigh(&neigh->common);

        neigh->common.oper_action = SX_ROUTER_ACTION_TRAP;
        neigh->common.state = SX_NEIGH_STATE_ALLOC_BY_SDK_E;
    }

out:
    if (err == SX_STATUS_SUCCESS) {
        --ib_neigh_entered;
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_delete_all_by_type(const sx_router_id_t        vrid,
                                                           const sx_router_interface_t rif,
                                                           const neigh_data_types_e    neigh_type)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    map_item = cl_fmap_head(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));
    map_end = cl_fmap_end(&(ib_neigh_data[neigh_type]->neigh_map[vrid]));

    while (map_item != map_end) {
        neigh = PARENT_STRUCT(map_item, ib_neigh_table_entry_t, common.map_item);
        map_item = cl_fmap_next(map_item);

        if (((RM_ROUTER_RIF_CHECK_MAX(rif) == TRUE) && (neigh->common.rif != rif)) ||
            (neigh->common.state == SX_NEIGH_STATE_ALLOC_BY_SDK_E)) {
            continue;
        }

        err = __router_db_ib_neigh_delete(vrid, &(neigh->common.ip_addr), 0);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not delete neighbor [%s] at the routing DB.\n",
                   format_ip_addr(&neigh->common.ip_addr, ip_addr_str));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_delete_all(const sx_router_id_t        vrid,
                                                   const sx_router_interface_t rif,
                                                   const sx_ip_version_t       version)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (version & SX_IP_VERSION_IPV4 || (version == SX_IP_VERSION_NONE)) {
        err = __router_db_ib_neigh_delete_all_by_type(vrid, rif, IPV4_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not delete all IPv4 neighbors from rif [%d].\n", rif);
            goto out;
        }
    }
    if (version & SX_IP_VERSION_IPV6) {
        err = __router_db_ib_neigh_delete_all_by_type(vrid, rif, IPV6_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not delete all IPv6 neighbors from rif [%d].\n", rif);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_set(const sx_access_cmd_t    cmd,
                                            const sx_router_id_t     vrid,
                                            const sx_ip_addr_t      *ip_addr,
                                            const sx_ib_adjacency_t *adj_param,
                                            const sx_router_action_t action,
                                            sx_router_interface_t   *rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = __router_db_ib_neigh_add(vrid, ip_addr, adj_param, action, *rif);
        break;

    case SX_ACCESS_CMD_EDIT:
        err = __router_db_ib_neigh_modify(vrid, ip_addr, adj_param, action, *rif);
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __router_db_ib_neigh_delete(vrid, ip_addr, rif);
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = __router_db_ib_neigh_delete_all(vrid, *rif, ip_addr->version);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_db_ib_neigh_get(const sx_router_id_t   vrid,
                                            const sx_ip_addr_t    *ip_addr,
                                            sx_ib_adjacency_t     *adj_param,
                                            sx_router_interface_t *rif)
{
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if (neigh == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find neighbor [%s] at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
    } else {
        SX_MEM_CPY_P(adj_param, neigh->adj_param);
        *rif = neigh->common.rif;
    }

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __router_db_ib_neigh_test(const sx_router_id_t   vrid,
                                             const sx_ip_addr_t    *ip_addr,
                                             sx_ib_adjacency_t     *adj_param,
                                             sx_router_interface_t *rif,
                                             boolean_t             *activity)
{
    ib_neigh_table_entry_t *neigh = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    char                    ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    __router_db_ib_neigh_find(vrid, ip_addr, &neigh);
    if (neigh == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find neighbor [%s] at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CPY_P(adj_param, neigh->adj_param);
    *rif = neigh->common.rif;

    if (neigh->common.routes_use > 0) {
        *activity = TRUE;
        goto out;
    }

    err =
        __router_db_host_activity_get(SX_ACCESS_CMD_READ_CLEAR, neigh->common.offset, neigh->common.ip_addr, activity);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not get neighbor [%s] activity at the routing DB.\n",
               format_ip_addr(ip_addr, ip_addr_str));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static
sx_status_t __ib_router_reserved_neigh_offset_replace(uint32_t           src_index,
                                                      uint32_t           dst_index,
                                                      neigh_data_types_e neigh_type)
{
    cl_map_item_t        *map_item;
    const cl_map_item_t  *map_end;
    neigh_offset_entry_t *neigh_offset_entry = NULL;

    map_item = cl_qmap_remove(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map), src_index);
    map_end = cl_qmap_end(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map));
    if (map_item == map_end) {
        SX_LOG(SX_LOG_DEBUG, "in entry %d not found in IB reserved offset.\n", src_index);
        /*Search in ETH reserved offset*/
        return router_db_reserved_neigh_offset_replace(src_index, dst_index, neigh_type);
    }

    neigh_offset_entry = PARENT_STRUCT(map_item, neigh_offset_entry_t, map_item);
    neigh_offset_entry->offset = dst_index;

    cl_qmap_insert(&(ib_neigh_data[neigh_type]->ib_neigh_reserved_offset_map),
                   neigh_offset_entry->offset, &(neigh_offset_entry->map_item));

    return SX_STATUS_SUCCESS;
}

static sx_status_t __verify_no_ipoib_parameters(const sx_vpi_router_general_param_t   *general_param_p,
                                                const sx_vpi_router_resources_param_t *resources_param_p)
{
    if (general_param_p->ipoib_allrouters_enable ||
        general_param_p->ipoib_broadcast_enable ||
        (resources_param_p->max_pkey_router_interfaces > 0) ||
        (resources_param_p->min_ipv4_ib_neighbor_entries > 0) ||
        (resources_param_p->max_ipv4_ib_neighbor_entries > 0) ||
        (resources_param_p->min_ipv6_ib_neighbor_entries > 0) ||
        (resources_param_p->max_ipv6_ib_neighbor_entries > 0)) {
        return SX_STATUS_PARAM_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t ib_router_attributes_set(const sx_swid_t       swid,
                                     const sx_access_cmd_t cmd,
                                     sx_ib_router_attr_t  *sx_ib_router_attr)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_status = SXD_STATUS_SUCCESS;
    sx_swid_type_t swid_type;

    SX_TCA_SET_LEAF_DEV_VARS;

    struct ku_rtca_reg rtca_reg_data;
    sxd_reg_meta_t     rtca_reg_meta;

    SX_LOG_ENTER();


    SX_MEM_CLR(rtca_reg_meta);
    SX_MEM_CLR(rtca_reg_data);

    sx_status = port_db_swid_type_get(swid, &swid_type);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get SWID(%d) type - %s.\n", swid, sx_status_str(sx_status));
        return M_UTILS_SX_LOG_EXIT(sx_status);
    }
    if (swid_type != SX_SWID_TYPE_INFINIBAND) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("SWID(%d) type is %s not IB \n", swid, (swid_type == 0) ? "DISABLED" : "ETHERNET");
        return sx_status;
    }
    /* Store attributes in Router attributes DB */
    sx_status = router_attr_db_set(cmd, sx_ib_router_attr, swid);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update Router attributes DB with SWID: %d.\n", swid);
        return M_UTILS_SX_LOG_EXIT(sx_status);
    }

    /* Get list of LEAF devices*/
    sx_status = SX_TCA_GET_LIST_OF_LEAF_DEV;

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(
            "IB ROUTER ATTRIBUTES SET:"
            " Get LEAF devices list failure (%s)\n",
            sx_status_str(sx_status));
        return sx_status;
    }

    if (dev_info_arr_size == 0) {
    } else {
        rtca_reg_meta.swid = 0;
        rtca_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        rtca_reg_data.swid = swid;
        sx_status = router_attr_db_get(swid, sx_ib_router_attr);
        rtca_reg_data.lid = sx_ib_router_attr->lid;
        rtca_reg_data.lmc = sx_ib_router_attr->lmc;
        SX_MEM_CPY_TYPE(rtca_reg_data.gid.addr_octet,
                        sx_ib_router_attr->gid.addr_octet,
                        rtca_reg_data.gid.addr_octet);
        /* For each LEAF device */
        for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
            rtca_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RTCA_E,
                                                             &rtca_reg_data,
                                                             &rtca_reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (SXD_CHECK_FAIL(sxd_status)) {
                SX_LOG_ERR(
                    "IB ROUTER ATTRIBUTES SET:"
                    "Set RTCA register failure (%u) "
                    "swid(%u)\n",
                    swid, sxd_status);
                sx_status = SX_STATUS_SXD_RETURNED_NON_ZERO;
                break;
            }
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t ib_router_attributes_get(const sx_swid_t swid, sx_ib_router_attr_t *sx_ib_router_attr)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_swid_type_t swid_type;

    sx_status = port_db_swid_type_get(swid, &swid_type);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get SWID(%d) type - %s.\n", swid, sx_status_str(sx_status));
        return M_UTILS_SX_LOG_EXIT(sx_status);
    }
    if (swid_type != SX_SWID_TYPE_INFINIBAND) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("SWID(%d) type is %s not IB \n", swid, (swid_type == 0) ? "DISABLED" : "ETHERNET");
        return sx_status;
    }

    sx_status = router_attr_db_get(swid, sx_ib_router_attr);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get Router attributes of SWID %d.\n", swid);
        return M_UTILS_SX_LOG_EXIT(sx_status);
    }

    return sx_status;
}

sx_status_t ib_router_attr_device_in(const sx_dev_id_t dev_id)
{
    sx_ib_router_attr_t sx_ib_router_attr;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_swid_type_t      swid_type;
    sx_swid_t           swid_temp;
    int                 i;
    struct ku_rtca_reg  rtca_reg_data;
    sxd_reg_meta_t      rtca_reg_meta;

    SX_MEM_CLR(rtca_reg_meta);
    SX_MEM_CLR(rtca_reg_data);

    for (i = 0; i < SXD_SWID_ID_COUNT; i++) {
        swid_temp = i;
        sx_status = port_db_swid_type_get(swid_temp, &swid_type);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get SWID(%d) type - %s.\n", swid_temp, sx_status_str(sx_status));
            return M_UTILS_SX_LOG_EXIT(sx_status);
        }
        if (swid_type == SX_SWID_TYPE_INFINIBAND) {
            sx_status = router_attr_db_get(swid_temp, &sx_ib_router_attr);
            if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
                /* This value was not configured, ignore this configuration */
                continue;
            }

            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Router attributes of SWID %d is empty.\n", swid_temp);
                return M_UTILS_SX_LOG_EXIT(sx_status);
            }

            rtca_reg_meta.swid = 0;
            rtca_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
            rtca_reg_data.swid = swid_temp;
            rtca_reg_data.lid = sx_ib_router_attr.lid;
            rtca_reg_data.lmc = sx_ib_router_attr.lmc;
            rtca_reg_meta.dev_id = dev_id;
            SX_MEM_CPY_TYPE(rtca_reg_data.gid.addr_octet,
                            sx_ib_router_attr.gid.addr_octet,
                            rtca_reg_data.gid.addr_octet);
            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RTCA_E,
                                                             &rtca_reg_data,
                                                             &rtca_reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (SXD_CHECK_FAIL(sxd_status)) {
                SX_LOG_ERR(
                    "IB ROUTER ATTRIBUTES SET:"
                    "Set RTCA register failure (%u) "
                    "swid(%u)\n",
                    swid_temp, sxd_status);
                sx_status = SX_STATUS_SXD_RETURNED_NON_ZERO;
                break;
            }
        }
    }

    return sx_status;
}

sx_status_t __router_attr_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t *dev_info_p = NULL;
    sx_status_t    sx_status;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "Device add callback: %s called.\n", __func__);

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG(SX_LOG_ERROR, "Wrong event type, expected event type is"
               " ADVISER_EVENT_POST_DEVICE_READY, received event type: [%s].\n",
               ADVISER_EVENT_STR(event_type));

        sx_status = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    dev_info_p = (sx_dev_info_t*)(param);
    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        return SX_STATUS_SUCCESS;
    }

    if (router_module_enabled == 0) {
        SX_LOG(SX_LOG_ERROR, "Called before router_init_params. Failed to initialize device [%u]"
               "router resources.\n", dev_info_p->dev_id);
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* When Device is added - update router attributes of all relevant swids */
    sx_status = ib_router_attr_device_in(dev_info_p->dev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "ib_router_attr_device_in failed on device [%u] \n",
               dev_info_p->dev_id);
        goto out;
    }

    SX_LOG_EXIT();

out:
    return sx_status;
}

sx_status_t __router_ib_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t *dev_info_p = NULL;
    sx_status_t    sx_status;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_ERROR, "Device add callback: %s called.\n", __func__);

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG(SX_LOG_ERROR, "Wrong event type, expected event type is"
               " ADVISER_EVENT_POST_DEVICE_READY, received event type: [%s].\n",
               ADVISER_EVENT_STR(event_type));

        sx_status = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    dev_info_p = (sx_dev_info_t*)(param);
    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        return SX_STATUS_SUCCESS;
    }

    if (router_module_enabled == 0) {
        SX_LOG(SX_LOG_ERROR, "Called before router_init_params. Failed to initialize device [%u]"
               "router resources.\n", dev_info_p->dev_id);
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* sync ib neigh to dev */
    sx_status = __router_db_ib_neigh_entry_sync_to_dev(dev_info_p->dev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to sync ib neigh  to device [%u] \n",
               dev_info_p->dev_id);
        goto out;
    }

    SX_LOG_EXIT();

out:
    return sx_status;
}

static char * __ib_router_print_l2_attributes(const void *attributes_p, const uint32_t length, char *string)
{
    snprintf(string,
             length,
             "SWID %u PKEY 0x%x QKEY %u QPN %u MTU %u MC TTL %u Scope %u",
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.swid,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.pkey,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.qkey,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.qpn,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.mtu,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.multicast_ttl_threshold,
             ((sx_l2_ib_router_interface_t*)(attributes_p))->l2_attr.scope);
    return string;
}
