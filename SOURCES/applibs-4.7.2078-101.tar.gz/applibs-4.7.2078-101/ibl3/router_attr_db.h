/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __ROUTER_ATTR_DB_H_INCL__
#define __ROUTER_ATTR_DB_H_INCL__

#include "ib_router.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/

/**
 * router_attr_db_item_t struct is the definition of one item of the router attributes DB
 */

typedef struct router_attr_db_item {
    uint8_t  valid;
    sx_lid_t lid;
    sx_lmc_t lmc;
    sx_gid_t gid;
} router_attr_db_item_t;

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  This function init the router attributes DB
 * @return SX_STATUS_SUCCESS
 */
sx_status_t router_attr_db_init(void);


/**
 *  This function Sets/Edits the fields in the router attributes DB
 * @param[in] cmd  - Command [SET / EDIT]
 * @param[in] sx_ib_router_attr - TCA information: lid,lid_valid, lmc, lmc_valid and gid.
 * @param[in] swid - Switch partition ID.
 * @return SX_STATUS_SUCCESS
 * @return SX_STATUS_CMD_UNSUPPORTED
 */
sx_status_t router_attr_db_set(const sx_access_cmd_t      cmd,
                               const sx_ib_router_attr_t* sx_ib_router_attr,
                               const sx_swid_t            swid);

/**
 *  This function reads the fields in the router attributes DB
 * @param[in] swid - Switch partition ID.
 * @param[out] sx_ib_router_attr - TCA information: lid, lmc  and gid.
 * @return SX_STATUS_SUCCESS
 * @return SX_STATUS_ENTRY_NOT_FOUND
 */

sx_status_t router_attr_db_get(const sx_swid_t      swid,
                               sx_ib_router_attr_t* sx_ib_router_attr);

#endif /* __ROUTER_ATTR_DB_H_INCL__ */
