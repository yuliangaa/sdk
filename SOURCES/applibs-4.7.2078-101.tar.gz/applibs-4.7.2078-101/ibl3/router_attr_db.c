/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include "router_attr_db.h"

#undef  __MODULE__
#define __MODULE__ ROUTER_ATTR_DB

/************************************************
 *  Global variables
 ***********************************************/

#define __SX_LOG_EXIT(SX_STATUS) __sx_log_exit(SX_STATUS, __func__)

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static router_attr_db_item_t __router_attr_db_item_arr[SX_SWID_ID_COUNT];

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __sx_log_exit(sx_status_t rc, const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s - left\n");
    return rc;
}


/************************************************
 *  API functions
 ***********************************************/

sx_status_t router_attr_db_init(void)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         i = 0;

    SX_LOG_ENTER();

    for (; i < SX_SWID_ID_COUNT; i++) {
        __router_attr_db_item_arr[i].valid = FALSE;
    }

    return __SX_LOG_EXIT(rc);
}

sx_status_t router_attr_db_set(const sx_access_cmd_t      cmd,
                               const sx_ib_router_attr_t* sx_ib_router_attr,
                               const sx_swid_t            swid)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        __router_attr_db_item_arr[swid].lid = sx_ib_router_attr->lid;
        __router_attr_db_item_arr[swid].lmc = sx_ib_router_attr->lmc;
        memcpy(__router_attr_db_item_arr[swid].gid.addr_octet, sx_ib_router_attr->gid.addr_octet,
               SX_IB_ADDR_LEN_BYTES);
        __router_attr_db_item_arr[swid].valid = TRUE;
        break;

    case SX_ACCESS_CMD_EDIT:
        if (__router_attr_db_item_arr[swid].valid == TRUE) {
            if (sx_ib_router_attr->lid_valid) {
                __router_attr_db_item_arr[swid].lid = sx_ib_router_attr->lid;
            }
            if (sx_ib_router_attr->lmc_valid) {
                __router_attr_db_item_arr[swid].lmc = sx_ib_router_attr->lmc;
            }
        } else {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            return __SX_LOG_EXIT(rc);
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        return __SX_LOG_EXIT(rc);
        break;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t router_attr_db_get(const sx_swid_t swid, sx_ib_router_attr_t*    sx_ib_router_attr)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (__router_attr_db_item_arr[swid].valid == FALSE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("DB entry of Swid %d is not valid\n", swid);
        return __SX_LOG_EXIT(rc);
    }

    sx_ib_router_attr->lid = __router_attr_db_item_arr[swid].lid;
    sx_ib_router_attr->lmc = __router_attr_db_item_arr[swid].lmc;
    memcpy(sx_ib_router_attr->gid.addr_octet, __router_attr_db_item_arr[swid].gid.addr_octet, SX_IB_ADDR_LEN_BYTES);

    return SX_STATUS_SUCCESS;
}
