/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef IB_ROUTER_H_
#define IB_ROUTER_H_


#include <sx/ib/sx_api_ib_router.h>
#include <sx/ib/sx_ib_router.h>
#include <sx/utils/bin_allocator.h>
#include "ethl3/sx/router.h"
#include "ethl3/sx/router_db.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

#define ADJACENCY_TABLE_IB     (ADJACENCY_TABLE_DEFAULT)
#define IB_ROUTER_MC_LIDS_MIN  0xc000
#define IB_ROUTER_PKEYS_ID_MIN 0x8000
#define IB_ROUTER_PKEYS_ID_MAX 0xffff

#define IB_ROUTER_QPN_MAX    0xffffff
#define IB_ROUTER_UC_LID_MIN 0x0001
#define IB_ROUTER_LMC_MAX    7

/************************************************
 *  Macros
 ***********************************************/

#define IB_ROUTER_UC_LID_MAX                                                      \
    MIN((IB_ROUTER_UC_LID_MIN + rm_resource_global.ib_router_uc_lid_num_max - 1), \
        (IB_ROUTER_MC_LIDS_MIN - 1))

#define IB_ROUTER_MC_LID_MAX \
    (IB_ROUTER_MC_LIDS_MIN + rm_resource_global.ib_router_mc_lids_num_max - 1)

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sx_l2_ib_router_interface {
    sx_router_interface_type_t  type;       /* This field must be the first! */
    sx_ib_l2_router_interface_t l2_attr;
} sx_l2_ib_router_interface_t;

typedef struct ib_neigh_data {
    cl_qpool_t neigh_pool;
    cl_fmap_t *neigh_map;
    cl_qpool_t ib_neigh_reserved_offset_pool;
    cl_qmap_t  ib_neigh_reserved_offset_map;
    uint32_t   ib_neigh_allocated_offset_count;
} ib_neigh_data_t;

typedef enum {
    ADJACENCY_ENTRY_ETH_E = ADJACENCY_ENTRY_ETH_MAX_E,
    ADJACENCY_ENTRY_IB_PKEY_NEIGHBOR_E,
    ADJACENCY_ENTRY_IB_PKEY_GRH_NEIGHBOR_E,
    ADJACENCY_ENTRY_IB_MULTICAST_E,
    ADJACENCY_ENTRY_RESERVED_E,
} ib_adjacency_entry_type_e;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function Initiates the IPoIB router module in SDK.
 */
sx_status_t ib_router_init_param(const sx_vpi_router_general_param_t   *general_param_p,
                                 const sx_vpi_router_resources_param_t *resources_param_p);

/**
 * This function initiates the ib router neighbors database.
 */
sx_status_t sx_ib_init_router(sx_router_init_params_t  *router_init_params,
                              router_db_neigh_params_t *neigh_params);

/**
 * This function deinitialize the ib router neighbors database.
 */
sx_status_t sx_ib_deinit_router();

/**
 *  This function adds/modifies/deletes  a router interface.
 */
sx_status_t ib_router_interface_set(const sx_access_cmd_t              cmd,
                                    const sx_router_id_t               vrid,
                                    const sx_ib_l2_router_interface_t *l2_ibifc,
                                    sx_router_interface_t             *rif);

/**
 *  This function gets a router interface information.
 */
sx_status_t ib_router_interface_get(const sx_router_interface_t  rif,
                                    sx_router_id_t              *vrid,
                                    sx_ib_l2_router_interface_t *l2_ibifc);

/**
 *  This function adds/modifies/deletes a neighbor information.
 *  The neighbor information associates an IP address to a LID QPN address.
 *  At DELETE_ALL operation the neighbors associated with the
 *  router interface parameter will be deleted in case it is valid,
 *  otherwise all neighbors will be deleted.
 */
sx_status_t ib_router_neigh_set(const sx_access_cmd_t       cmd,
                                const sx_router_id_t        vrid,
                                const sx_ip_addr_t         *ip_addr,
                                const sx_ib_adjacency_t    *adj_param,
                                const sx_router_action_t    action,
                                const sx_router_interface_t rif);

/**
 *  This function gets/tests a neighbor information. At GET
 *  operation, LID/QPN and Router Interface ID will be
 *  returned in case the neighbor exists. At TEST operation,
 *  LID/QPN, Router Interface ID and activity indicator will
 *  be returned.
 */
sx_status_t ib_router_neigh_get(const sx_access_cmd_t  cmd,
                                const sx_router_id_t   vrid,
                                const sx_ip_addr_t    *ip_addr,
                                sx_ib_adjacency_t     *adj_param,
                                sx_router_interface_t *rif,
                                boolean_t             *activity);

/**
 *  This function sets/edits the router attributes according to the swid value.
 *  In SET case, all the attributes are updated. In case of EDIT, the valid bits are checked and only
 *  these fields are updated.
 */
sx_status_t ib_router_attributes_set(const sx_swid_t       swid,
                                     const sx_access_cmd_t cmd,
                                     sx_ib_router_attr_t  *sx_ib_router_attr);

/**
 *  This function gets the router attributes according to the swid value.
 *  The valid bits are set to '1'.
 */
sx_status_t ib_router_attributes_get(const sx_swid_t      swid,
                                     sx_ib_router_attr_t *sx_ib_router_attr);

/**
 *  This function updates the router attributes when a new device event occurs.
 */
sx_status_t ib_router_attr_device_in(const sx_dev_id_t dev_id);


#endif /* IB_ROUTER_H_ */
