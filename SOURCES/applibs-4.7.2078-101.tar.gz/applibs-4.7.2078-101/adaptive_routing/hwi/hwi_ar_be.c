/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ ADAPTIVE_ROUTING
#include "sx/sxd/kernel_user.h"
#include "complib/sx_log.h"
#include "hwi_ar_be.h"
#include "hwi_ar_db.h"
#include "hwi_ar_impl.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/port_type_validate.h"
#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include <ethl3/hwi/rif/rif_be.h>

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/
extern hwd_ar_ops_t g_hwd_ar_ops;


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __sdk_ar_be_profile_validity_check(const sx_access_cmd_t       cmd,
                                                      const sx_ar_profile_key_t  *profile_key_p,
                                                      const sx_ar_profile_attr_t *profile_attr_p);
static sx_status_t __sdk_ar_be_arn_profile_validity_check(const sx_access_cmd_t        cmd,
                                                          const sx_ar_profile_key_t   *profile_key_p,
                                                          const sx_arn_profile_attr_t *profile_attr_p);

static sx_status_t __sdk_ar_be_classification_default_validity_check(
    const sx_ar_classifier_action_t *classifier_action_p);
static sx_status_t __sdk_ar_be_congestion_threshold_validity_check(
    const sx_ar_congestion_threshold_attr_t *congestion_thresh);
static sx_status_t __sdk_ar_be_classification_validity_check(const sx_access_cmd_t          cmd,
                                                             const sx_ar_classifier_id_e    classifier_id,
                                                             const sx_ar_classifier_attr_t *attr_p);
static sx_status_t __sdk_ar_be_link_utilization_validity_check(const sx_ar_link_utilization_attr_t *link_util_attr);
static sx_status_t __sdk_ar_be_arn_default_params_validity_check(const sx_arn_default_params_t *default_params_p);
static sx_status_t __sdk_ar_be_arn_general_params_validity_check(const sx_arn_general_params_t *general_params_p);

/************************************************
 *  Function implementations
 ***********************************************/


sx_status_t sdk_ar_be_init_set(const sx_ar_init_params_t *init_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (TRUE == is_module_inited) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("AR module is already initialized.\n");
        goto out;
    }

    err = sdk_ar_init(init_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init Adaptive Routing library - error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_deinit_set()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = sdk_ar_deinit(FALSE);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit AR library - error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_profile_set(const sx_access_cmd_t        cmd,
                                      const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    is_module_inited = sdk_arn_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_arn_profile_validity_check(cmd, profile_key_p, profile_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ARN profile is invalid %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_arn_profile_set(cmd, profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure ARN profile: command - %s error: %s.\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_profile_get(const sx_ar_profile_key_t *profile_key_p, sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    is_module_inited = sdk_arn_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    err = __sdk_ar_be_arn_profile_validity_check(SX_ACCESS_CMD_GET, profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ARN profile is invalid %s.\n", sx_status_str(err));
        goto out;
    }

    err = sdk_ar_impl_arn_profile_get(profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ARN profile configuration. error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_profile_set(const sx_access_cmd_t       cmd,
                                  const sx_ar_profile_key_t  *profile_key_p,
                                  const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_profile_validity_check(cmd, profile_key_p, profile_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR profile is invalid %s.\n", sx_status_str(err));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_profile_set(cmd, profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure AR profile: command - %s error: %s.\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_profile_get(const sx_ar_profile_key_t *profile_key_p, sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = __sdk_ar_be_profile_validity_check(SX_ACCESS_CMD_GET, profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("AR profile is invalid %s.\n", sx_status_str(err));
        goto out;
    }

    err = sdk_ar_impl_profile_get(profile_key_p, profile_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR profile configuration. error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_profile_validity_check(const sx_access_cmd_t       cmd,
                                                      const sx_ar_profile_key_t  *profile_key_p,
                                                      const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(profile_key_p, "profile_key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(profile_attr_p, "profile_attr_p"))) {
        goto out;
    }

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("AR profile handle %u is invalid.\n", profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if ((profile_attr_p->mode < SX_AR_PROFILE_MODE_MIN_E) ||
            (profile_attr_p->mode > SX_AR_PROFILE_MODE_MAX_E)) {
            SX_LOG_ERR("AR profile mode %u is invalid.\n", profile_attr_p->mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((profile_attr_p->profile_threshold.busy_threshold > AR_GRADE_MAX) ||
            (profile_attr_p->profile_threshold.free_threshold > AR_GRADE_MAX)) {
            SX_LOG_ERR("AR profile thresholds free=%u, busy=%u are invalid.\n",
                       profile_attr_p->profile_threshold.free_threshold,
                       profile_attr_p->profile_threshold.busy_threshold);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (profile_attr_p->mode == SX_AR_PROFILE_MODE_TIME_BOUND_E) {
            if ((profile_attr_p->bind_time < AR_BIND_TIME_MIN) ||
                (profile_attr_p->bind_time > AR_BIND_TIME_MAX)) {
                SX_LOG_ERR("AR bind time: %u is invalid. Valid values are: (%u-%u)\n",
                           profile_attr_p->bind_time, AR_BIND_TIME_MIN, AR_BIND_TIME_MAX);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if ((profile_attr_p->mode != SX_AR_PROFILE_MODE_FREE_E) && (profile_attr_p->only_elephant_en == TRUE)) {
            SX_LOG_ERR("AR with only_elephant enabled can only be activated in free profile mode.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_ar_be_arn_profile_validity_check(const sx_access_cmd_t        cmd,
                                                          const sx_ar_profile_key_t   *profile_key_p,
                                                          const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;


    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(profile_key_p, "profile_key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(profile_attr_p, "profile_attr_p"))) {
        goto out;
    }

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("ARN profile  %s is invalid.\n", sx_ar_profile_handle_str(profile_key_p->profile));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_CHECK_RANGE(ARN_PROFILE_HOLD_TIME_MIN, profile_attr_p->arn_hold_time,
                           ARN_PROFILE_HOLD_TIME_MAX) == FALSE) {
            SX_LOG_ERR("ARN hold time %u for profile %s is out of valid range [%u ..%u] .\n",
                       profile_attr_p->arn_hold_time,
                       sx_ar_profile_handle_str(profile_key_p->profile),
                       ARN_PROFILE_HOLD_TIME_MIN,
                       ARN_PROFILE_HOLD_TIME_MAX);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }


        if (SX_CHECK_RANGE(ARN_PROFILE_AGING_TIME_MIN, profile_attr_p->arn_aging_time,
                           ARN_PROFILE_AGING_TIME_MAX) == FALSE) {
            SX_LOG_ERR("ARN aging time %u for profile %s is out of valid range [%u ..%u] .\n",
                       profile_attr_p->arn_aging_time,
                       sx_ar_profile_handle_str(profile_key_p->profile),
                       ARN_PROFILE_AGING_TIME_MIN,
                       ARN_PROFILE_AGING_TIME_MAX);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (SX_CHECK_MAX(profile_attr_p->arn_penalty, ARN_PROFILE_PANELTY_MAX) == FALSE) {
            SX_LOG_ERR("ARN penalty %u for profile %s is out of valid range [%u ..%u] .\n",
                       profile_attr_p->arn_penalty,
                       sx_ar_profile_handle_str(profile_key_p->profile),
                       ARN_PROFILE_PANELTY_MIN,
                       ARN_PROFILE_PANELTY_MAX);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_default_classification_get(sx_ar_classifier_action_t *classifier_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = sdk_ar_impl_default_classification_get(classifier_action_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR default classification: error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_default_classification_set(const sx_access_cmd_t            cmd,
                                                 const sx_ar_classifier_action_t *classifier_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_classification_default_validity_check(classifier_action_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR classification is invalid %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_default_classification_set(cmd, classifier_action_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure AR default classification: error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_classification_default_validity_check(
    const sx_ar_classifier_action_t *classifier_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if ((classifier_action_p->ar_flow_classification != SX_AR_CLASSIFIER_ACTION_STATIC_E) &&
        (classifier_action_p->ar_flow_classification != SX_AR_CLASSIFIER_ACTION_PROFILE0_E) &&
        (classifier_action_p->ar_flow_classification != SX_AR_CLASSIFIER_ACTION_PROFILE1_E)) {
        SX_LOG_ERR("AR action type %u is invalid.\n", classifier_action_p->ar_flow_classification);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_congestion_threshold_set(const sx_access_cmd_t                    cmd,
                                               const sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_congestion_threshold_validity_check(congestion_thresh);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR congestion threshold is invalid %s.\n", sx_status_str(err));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_congestion_threshold_set(cmd, congestion_thresh);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure AR congestion threshold: command - %s error: %s.\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = sdk_ar_impl_congestion_threshold_get(congestion_thresh);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR congestion threshold. error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_congestion_threshold_validity_check(
    const sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(congestion_thresh, "congestion_thresh"))) {
        goto out;
    }

    if ((congestion_thresh->port_threshold.congestion_thresh_hi >
         rm_resource_global.shared_buff_def_egr_desc_pool_size) ||
        (congestion_thresh->port_threshold.congestion_thresh_hi <
         congestion_thresh->port_threshold.congestion_thresh_med) ||
        (congestion_thresh->port_threshold.congestion_thresh_med <
         congestion_thresh->port_threshold.congestion_thresh_lo)) {
        SX_LOG_ERR(
            "AR port congestion threshold definition is invalid. (Hi:%u,   Med:%u,  Low:%u, Expected range:0-%u)\n",
            congestion_thresh->port_threshold.congestion_thresh_hi,
            congestion_thresh->port_threshold.congestion_thresh_med,
            congestion_thresh->port_threshold.congestion_thresh_lo,
            rm_resource_global.shared_buff_def_egr_desc_pool_size);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_classification_set(const sx_access_cmd_t            cmd,
                                         const sx_ar_classifier_id_e      classifier_id,
                                         const sx_ar_classifier_attr_t   *attr_p,
                                         const sx_ar_classifier_action_t *action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_classification_default_validity_check(action_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR classification validity check failed %s.\n", sx_status_str(err));
            goto out;
        }

    /* fallthrough */
    case SX_ACCESS_CMD_UNSET:
        err = __sdk_ar_be_classification_validity_check(cmd, classifier_id, attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR classification non default validity check failed %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_classification_set(cmd, classifier_id, attr_p, action_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure AR classifier: error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_classification_get(const sx_ar_classifier_id_e classifier_id,
                                         sx_ar_classifier_attr_t    *attr_p,
                                         sx_ar_classifier_action_t  *action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = sdk_ar_impl_classification_get(classifier_id, attr_p, action_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR classifier: %s error: %s.\n",
                   sx_ar_classifier_id_str(classifier_id), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_classification_validity_check(const sx_access_cmd_t          cmd,
                                                             const sx_ar_classifier_id_e    classifier_id,
                                                             const sx_ar_classifier_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if ((classifier_id < SX_AR_CLASSIFIER_INDEX_MIN_E) ||
        (classifier_id > SX_AR_CLASSIFIER_INDEX_MAX_E)) {
        SX_LOG_ERR("AR classifier index %u is invalid. Valid range is (%s-%s)\n",
                   classifier_id, sx_ar_classifier_id_str(SX_AR_CLASSIFIER_INDEX_MIN_E),
                   sx_ar_classifier_id_str(SX_AR_CLASSIFIER_INDEX_MAX_E));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (attr_p->key.log_ports_cnt > MAX_PHYPORT_NUM) {
            SX_LOG_ERR("AR classifier attribute log ports count %u is invalid. Max value is %u\n",
                       attr_p->key.log_ports_cnt, MAX_PHYPORT_NUM);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.switch_priorities_cnt > RM_API_COS_PORT_PRIO_MAX + 1) {
            SX_LOG_ERR("AR classifier attribute priorities count %u is invalid. Max value is %u\n",
                       attr_p->key.switch_priorities_cnt, RM_API_COS_PORT_PRIO_MAX + 1);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < attr_p->key.switch_priorities_cnt; i++) {
            if (attr_p->key.switch_priorities[i] > RM_API_COS_PORT_PRIO_MAX + 1) {
                SX_LOG_ERR("AR classifier attribute switch priorities %u is invalid. Max value is %u\n",
                           attr_p->key.switch_priorities[i], RM_API_COS_PORT_PRIO_MAX + 1);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if (attr_p->key.bth_opcodes.bth_opcode_7_5_cnt > AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE) {
            SX_LOG_ERR("AR classifier attribute bth_opcodes 7_5 count %u is invalid. Max value is %u\n",
                       attr_p->key.bth_opcodes.bth_opcode_7_5_cnt, AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < attr_p->key.bth_opcodes.bth_opcode_7_5_cnt; i++) {
            if (attr_p->key.bth_opcodes.bth_opcode_7_5[i] > AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE) {
                SX_LOG_ERR("AR classifier attribute bth_opcode_7_5 %u is invalid. Max value is %u\n",
                           attr_p->key.bth_opcodes.bth_opcode_7_5[i], AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if (attr_p->key.bth_opcodes.bth_opcode_4_0_cnt > AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE) {
            SX_LOG_ERR("AR classifier attribute bth_opcodes 4_0 count %u is invalid. Max value is %u\n",
                       attr_p->key.bth_opcodes.bth_opcode_4_0_cnt, AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < attr_p->key.bth_opcodes.bth_opcode_4_0_cnt; i++) {
            if (attr_p->key.bth_opcodes.bth_opcode_4_0[i] > AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE) {
                SX_LOG_ERR("AR classifier attribute bth_opcode_4_0 %u is invalid. Max value is %u\n",
                           attr_p->key.bth_opcodes.bth_opcode_4_0[i], AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if (attr_p->key.inner_bth_opcodes.bth_opcode_7_5_cnt > AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE) {
            SX_LOG_ERR("AR classifier attribute inner_bth_opcodes 7_5 count %u is invalid. Max value is %u\n",
                       attr_p->key.inner_bth_opcodes.bth_opcode_7_5_cnt, AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < attr_p->key.inner_bth_opcodes.bth_opcode_7_5_cnt; i++) {
            if (attr_p->key.inner_bth_opcodes.bth_opcode_7_5[i] > AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE) {
                SX_LOG_ERR("AR classifier attribute inner_bth_opcodes_7_5 %u is invalid. Max value is %u\n",
                           attr_p->key.inner_bth_opcodes.bth_opcode_7_5[i], AR_CLASSIFIER_BTH_OPCODE_HIGH_SIZE);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if (attr_p->key.inner_bth_opcodes.bth_opcode_4_0_cnt > AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE) {
            SX_LOG_ERR("AR classifier attribute inner_bth_opcodes 4_0 count %u is invalid. Max value is %u\n",
                       attr_p->key.inner_bth_opcodes.bth_opcode_4_0_cnt, AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < attr_p->key.inner_bth_opcodes.bth_opcode_4_0_cnt; i++) {
            if (attr_p->key.inner_bth_opcodes.bth_opcode_4_0[i] > AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE) {
                SX_LOG_ERR("AR classifier attribute inner_bth_opcode_4_0 %u is invalid. Max value is %u\n",
                           attr_p->key.inner_bth_opcodes.bth_opcode_4_0[i], AR_CLASSIFIER_BTH_OPCODE_LOW_SIZE);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        if (attr_p->key.l3 > AR_CLASSIFIER_L3_MAX) {
            SX_LOG_ERR("AR classifier attribute l3 %u is invalid.\n",
                       attr_p->key.l3);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.inner_l3 > AR_CLASSIFIER_L3_MAX) {
            SX_LOG_ERR("AR classifier attribute inner l3 %u is invalid.\n",
                       attr_p->key.inner_l3);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.l4 > AR_CLASSIFIER_L4_MAX) {
            SX_LOG_ERR("AR classifier attribute l4 %u is invalid.\n",
                       attr_p->key.l4);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.inner_l4 > AR_CLASSIFIER_L4_MAX) {
            SX_LOG_ERR("AR classifier attribute inner l4 %u is invalid.\n",
                       attr_p->key.inner_l4);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.bth_ar > SX_AR_IN_BTH_HEADER_ON_E) {
            SX_LOG_ERR("AR classifier attribute bth_ar %u is invalid. Max value is %u\n",
                       attr_p->key.bth_ar, SX_AR_IN_BTH_HEADER_ON_E);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.inner_bth_ar > SX_AR_IN_BTH_HEADER_ON_E) {
            SX_LOG_ERR("AR classifier attribute inner bth_ar %u is invalid. Max value is %u\n",
                       attr_p->key.inner_bth_ar, SX_AR_IN_BTH_HEADER_ON_E);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.port_ranges_cnt > AR_PORT_RANGES_MAX) {
            SX_LOG_ERR("AR classifier attribute port_ranges_cnt %u is invalid. Max value is %u\n",
                       attr_p->key.port_ranges_cnt, AR_PORT_RANGES_MAX);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (attr_p->key.port_ranges_mode > SX_AR_CLASSIFIER_L4_PORT_RANGE_MODE_MAX_E) {
            SX_LOG_ERR("AR classifier attribute port_ranges_mode %u is invalid. Max value is %u\n",
                       attr_p->key.port_ranges_mode, SX_AR_CLASSIFIER_L4_PORT_RANGE_MODE_MAX_E);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (g_hwd_ar_ops.hwd_ar_classification_attr_validate_pfn != NULL) {
            err = g_hwd_ar_ops.hwd_ar_classification_attr_validate_pfn(attr_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Classifier attributes validation failed, error: %s\n", sx_status_str(err));
                goto out;
            }
        }

        for (i = 0; i < attr_p->key.port_ranges_cnt; i++) {
            if (attr_p->key.port_ranges[i].port > SX_AR_CLASSIFIER_L4_PORT_SRC_E) {
                SX_LOG_ERR("AR classifier attribute port %u in port_ranges location %u is invalid. Max value is %u\n",
                           attr_p->key.port_ranges[i].port, i, SX_AR_CLASSIFIER_L4_PORT_SRC_E);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            if (attr_p->key.port_ranges[i].protocol > SX_AR_CLASSIFIER_L4_PROTO_TCP_UDP_E) {
                SX_LOG_ERR(
                    "AR classifier attribute protocol %u in port_ranges location %u is invalid. Max value is %u\n",
                    attr_p->key.port_ranges[i].protocol,
                    i,
                    SX_AR_CLASSIFIER_L4_PROTO_TCP_UDP_E);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            if (attr_p->key.port_ranges[i].port_low > attr_p->key.port_ranges[i].port_high) {
                SX_LOG_ERR(
                    "AR classifier attribute port_ranges %u is invalid. port low: %u can't be higher than port high: %u\n",
                    i,
                    attr_p->key.port_ranges[i].port_low,
                    attr_p->key.port_ranges[i].port_high);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    err = sdk_ar_impl_shaper_rate_get(shaper_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR shaper rate. error: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_shaper_rate_set(const sx_access_cmd_t cmd, const sx_ar_shaper_attr_t    *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if ((INVALID_SHAPER_RATE_CONF == shaper_attr_p->shaper_rate_from) ||
        (INVALID_SHAPER_RATE_CONF == shaper_attr_p->shaper_rate_to)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported AR shaper rate: [%u] error: [%s].\n"
                   , INVALID_SHAPER_RATE_CONF, sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_ar_impl_shaper_rate_set(cmd, shaper_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to configure AR shaper rate: error: %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_link_utilization_threshold_set(const sx_access_cmd_t                cmd,
                                                     const sx_port_log_id_t               log_port,
                                                     const sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_link_utilization_validity_check(link_util_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AR link utilization attributes is invalid %s.\n", sx_status_str(err));
            goto out;
        }

    /*Fallthrough*/
    case SX_ACCESS_CMD_UNSET:
        VALIDATE_PORT(sdk_ar_be_link_utilization_threshold_set, log_port);
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_link_utilization_threshold_set(cmd, log_port, link_util_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure AR link utilization threshold: command - %s log port [0x%08X]"
                   " error: %s.\n",
                   sx_access_cmd_str(cmd), log_port, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_link_utilization_threshold_get(const sx_port_log_id_t         log_port,
                                                     sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    VALIDATE_PORT(sdk_ar_be_link_utilization_threshold_get, log_port);

    err = sdk_ar_impl_link_utilization_threshold_get(log_port, link_util_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get AR link utilization threshold for log port [0x%08X]. "
                   "error: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_link_utilization_validity_check(const sx_ar_link_utilization_attr_t *link_util_attr)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (link_util_attr == NULL) {
        SX_LOG_ERR("Link utilization attribute parameter is NULL");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((link_util_attr->link_utilization_threshold > LINK_UTILIZATION_MAX) ||
        ((link_util_attr->link_utilization_threshold % LINK_UTILIZATION_GRANULARITY) != 0)) {
        SX_LOG_ERR(
            "AR port link utilization threshold definition is invalid [%u]. Max size: [%u], Granularity: [%u]\n",
            link_util_attr->link_utilization_threshold,
            LINK_UTILIZATION_MAX,
            LINK_UTILIZATION_GRANULARITY);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_be_counters_get(const sx_access_cmd_t cmd, sx_ar_global_counters_t *ar_counters_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_module_inited = FALSE;

    SX_LOG_ENTER();

    is_module_inited = sdk_ar_impl_is_module_initialized();
    if (FALSE == is_module_inited) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        err = sdk_ar_impl_counters_get(cmd, ar_counters_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve AR counters (%s).\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_counters_get(const sx_access_cmd_t cmd, sx_arn_counters_t *arn_counters_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        err = sdk_ar_impl_arn_counters_get(cmd, arn_counters_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve ARN counters (%s).\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_port_counters_get(const sx_access_cmd_t   cmd,
                                            const sx_port_log_id_t  log_port,
                                            sx_arn_port_counters_t *arn_port_counters_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    VALIDATE_PORT(sdk_ar_be_arn_port_counters_get, log_port);

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        err = sdk_ar_impl_arn_port_counters_get(cmd, log_port, arn_port_counters_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to retrieve ARN port counters (%s).\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_flow_status_get(const sx_access_cmd_t      cmd,
                                          sx_arn_flow_status_key_t  *flow_status_key_p,
                                          sx_arn_flow_status_data_t *flow_status_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_READ) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        goto out;
    }


    err = sdk_ar_impl_arn_flow_status_get(flow_status_key_p, flow_status_data_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve ARN flow status (%s).\n", sx_status_str(err));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_be_arn_defaults_set(const sx_access_cmd_t cmd, const sx_arn_default_params_t *default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_arn_default_params_validity_check(default_params_p);
        SX_CHECK_RC_OUT_ERR(err, "Failed to validate ARN defaults.");
    /*fallthrough*/

    case SX_ACCESS_CMD_UNSET:
        err = sdk_ar_impl_arn_defaults_set(cmd, default_params_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to %s ARN defaults. Error: (%s).\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
            goto out;
        }
        err = sdk_ar_impl_arn_params_hwd_set();
        SX_CHECK_RC_OUT_ERR(err, "ARN parameters set failed writing to FW.");
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_arn_default_params_validity_check(const sx_arn_default_params_t *default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_CHECK_NULL_OUT(default_params_p, err, "ARN defaults params is NULL");

    if (!SX_CHECK_RANGE(ARN_GEN_SHAPER_TIMER_MIN,
                        default_params_p->gen_shaper_min_time,
                        ARN_GEN_SHAPER_TIMER_MAX)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ARN generation shaper min time [%u] exceeds range [%u - %u]. Error: (%s).\n",
                   default_params_p->gen_shaper_min_time,
                   ARN_GEN_SHAPER_TIMER_MIN,
                   ARN_GEN_SHAPER_TIMER_MAX,
                   sx_status_str(err));
        goto out;
    }

    if (default_params_p->sip_prefix_match_type > SX_ARN_SIP_PREFIX_MATCH_ANY_E) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ARN source IP prefix match type [%u] doesn't exists. Error: (%s).\n",
                   default_params_p->sip_prefix_match_type, sx_status_str(err));
        goto out;
    }

    if (default_params_p->truncate_size > ARN_TRUNCATE_SIZE_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ARN truncation size [%u] is too big. Max size: %u. Error: (%s).\n",
                   default_params_p->truncate_size, ARN_TRUNCATE_SIZE_MAX, sx_status_str(err));
        goto out;
    }

    if ((default_params_p->truncate_size % ARN_TRUNCATE_SIZE_GRANULARITY) != 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ARN truncation size [%u] granularity should be [%u]. Error: (%s).\n",
                   default_params_p->truncate_size, ARN_TRUNCATE_SIZE_GRANULARITY, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_defaults_get(const sx_access_cmd_t cmd, sx_arn_default_params_t *default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    SX_CHECK_NULL_OUT(default_params_p, err, "ARN defaults params is NULL");

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_arn_defaults_get(default_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN default params.");

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_arn_router_key_validity_check(const sx_arn_router_key_t *router_key_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    boolean_t              is_vrid_used = FALSE;
    boolean_t              sw_pending_del = FALSE;
    gc_state_t             gc_state = GC_STATE_FREE;
    sx_router_attributes_t router_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(router_attr);

    SX_CHECK_NULL_OUT(router_key_p, err, "ARN router key pointer is NULL");

    err = sdk_router_vrid_impl_params_get(router_key_p->vrid, &is_vrid_used, &router_attr,
                                          &gc_state, &sw_pending_del);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get VRID attributes. err %s.\n", sx_status_str(err));
        goto out;
    }

    if (is_vrid_used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed, given VRID [%u] is not in use. err: %s.\n", router_key_p->vrid, sx_status_str(err));
        goto out;
    }

    if (gc_state != GC_STATE_EXISTS) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Failed, VRID [%u] is during a delete process (%s state).\n", router_key_p->vrid,
                   GC_STATE_STR(gc_state));
        goto out;
    }

    if (sw_pending_del == TRUE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "VRID [%u] is in pending delete state. sx_status:%s.\n", router_key_p->vrid,
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_arn_router_attr_validity_check(const sx_router_id_t              vrid,
                                                              const sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_router_id_t              erif_vrid = 0, irif_vrid = 0;
    sx_router_interface_param_t erif_ifc, irif_ifc;
    sx_interface_attributes_t   erif_ifc_attr, irif_ifc_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(erif_ifc);
    SX_MEM_CLR(erif_ifc_attr);
    SX_MEM_CLR(irif_ifc);
    SX_MEM_CLR(irif_ifc_attr);

    SX_CHECK_NULL_OUT(router_attr_p, err, "ARN router attributes pointer is NULL");

    err = sdk_router_interface_get(router_attr_p->erif, &erif_vrid, &erif_ifc, &erif_ifc_attr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ARN generation egress RIF info. Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_router_interface_get(router_attr_p->irif, &irif_vrid, &irif_ifc, &irif_ifc_attr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ARN generation ingress RIF info. Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    if ((erif_ifc.type != SX_L2_INTERFACE_TYPE_LOOPBACK) || (irif_ifc.type != SX_L2_INTERFACE_TYPE_LOOPBACK)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ARN generation egress and ingress RIFs' type should be SX_L2_INTERFACE_TYPE_LOOPBACK. "
                   "Error: (%s).\n", sx_status_str(err));
        goto out;
    }

    if ((vrid != erif_vrid) || (vrid != irif_vrid)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ARN generation egress rif vrid [%u] or ingress rif vrid [%u] "
                   "are not equal to ARN generation vrid[%u]. Error: (%s).\n",
                   vrid, erif_vrid, irif_vrid, sx_status_str(err));
        goto out;
    }

    if ((erif_ifc_attr.mtu != rm_resource_global.port_mtu_max) ||
        (irif_ifc_attr.mtu != rm_resource_global.port_mtu_max)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ARN generation egress and ingress RIF's MTU should be set to %u. Error: (%s).\n",
                   SX_PORT_MTU_MAX, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_router_gen_set(const sx_access_cmd_t             cmd,
                                         const sx_arn_router_key_t        *router_key_p,
                                         const sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    err = __sdk_ar_be_arn_router_key_validity_check(router_key_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed during router key validity check. Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (sdk_arn_impl_is_arn_generation_enabled(router_key_p->vrid)) {
            err = SX_STATUS_ALREADY_INITIALIZED;
            SX_LOG_ERR("ARN generation is already initialized on VRID [%u].\n", router_key_p->vrid);
            goto out;
        }

        err = __sdk_ar_be_arn_router_attr_validity_check(router_key_p->vrid, router_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed during router attributes validity check. Error: (%s).\n",
                       sx_status_str(err));
            goto out;
        }

    /*fallthrough*/
    case SX_ACCESS_CMD_UNSET:
        err = sdk_ar_impl_arn_router_gen_set(cmd, router_key_p, router_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to %s ARN router generation. Error: (%s).\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_router_gen_get(const sx_arn_router_key_t  *router_key_p,
                                         sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    err = __sdk_ar_be_arn_router_key_validity_check(router_key_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed during router key validity check. Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_ar_impl_arn_router_gen_get(router_key_p, router_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ARN router generation attributes. Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_be_arn_set(const sx_access_cmd_t cmd, const sx_arn_general_params_t *general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    SX_CHECK_NULL_OUT(general_params_p, err, "ARN general params is NULL");

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __sdk_ar_be_arn_general_params_validity_check(general_params_p);
        SX_CHECK_RC_OUT_ERR(err, "Failed to validate ARN general params.");
    /*fallthrough*/

    case SX_ACCESS_CMD_UNSET:
        err = sdk_ar_impl_arn_set(cmd, general_params_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to %s ARN general params. Error: (%s).\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_arn_get(const sx_access_cmd_t cmd, sx_arn_general_params_t *general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("AR module is not initialized.\n");
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ARN module is not initialized.\n");
        goto out;
    }

    SX_CHECK_NULL_OUT(general_params_p, err, "ARN general params is NULL");

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_impl_arn_get(general_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params.");

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_be_arn_general_params_validity_check(const sx_arn_general_params_t *general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == sdk_arn_impl_is_module_initialized()) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("ARN module is already initialized.\n");
        goto out;
    }

    if (!SX_CHECK_RANGE(ARN_GRADE_THRESHOLD_MIN,
                        general_params_p->grade_threshold,
                        ARN_GRADE_THRESHOLD_MAX)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ARN grade threshold [%u] exceeds range [%u - %u]. Error: (%s).\n",
                   general_params_p->grade_threshold,
                   ARN_GRADE_THRESHOLD_MIN,
                   ARN_GRADE_THRESHOLD_MAX,
                   sx_status_str(err));
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_COS_TQ_PROFILE_ID_MIN_E,
                        general_params_p->profile_id,
                        SX_COS_TQ_PROFILE_ID_MAX_E)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ARN profile id [%u] exceeds range [%u - %u]. Error: (%s).\n",
                   general_params_p->profile_id,
                   SX_COS_TQ_PROFILE_ID_MIN_E,
                   SX_COS_TQ_PROFILE_ID_MAX_E,
                   sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    sdk_ar_impl_log_verbosity_level_set(verbosity_level);
    sdk_ar_db_log_verbosity_level_set(verbosity_level);
    SX_LOG_EXIT();

    return rc;
}

sx_status_t sdk_ar_be_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (verbosity_level_p == NULL) {
        SX_LOG_ERR("verbosity level pointer is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

out:
    SX_LOG_EXIT();
    return rc;
}
