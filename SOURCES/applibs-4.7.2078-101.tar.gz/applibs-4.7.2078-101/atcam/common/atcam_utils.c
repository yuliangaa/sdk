/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "atcam_utils.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/* Two arrays indicating for each number of blocks the location of the blocks' start in the key and the relevant blocks' sizes. */
static uint8_t atcam_utils_blocks_start[ATCAM_MAX_NUM_OF_HW_KEY_BLOCKS +
                                        1] = {0, 51, 47, 42, 38, 33, 29, 24, 20, 15, 11,  6,  2};
static uint8_t atcam_utils_blocks_size[ATCAM_MAX_NUM_OF_HW_KEY_BLOCKS +
                                       1] = {0,  5,  9, 14, 18, 23, 27, 32, 36, 41, 45, 50, 54};
#if (ATCAM_MAX_KEY_SIZE != 56)
#error "The atcam utils logic assumes atcam key size is 56."
#endif

/************************************************
 *  Local functions declarations
 ***********************************************/

/**
 * Intersects 2 bytes array. The result is an array with logical AND between respective 2 bytes.
 *
 * @param[in]  arr1           - First byte array
 * @param[in]  arr2           - Second byte array
 * @param[out] res            - The result of the intersection.
 */
inline static void __atcam_utils_intersect_bytes(const uint8_t *arr1,
                                                 const uint8_t *arr2,
                                                 uint8_t       *res);

/**
 * Unites 2 bytes array. The result is an array with logical OR between respective 2 bytes.
 *
 * @param[in]  arr1           - First byte array
 * @param[in]  arr2           - Second byte array
 * @param[out] res            - The result of the union.
 */
static void __atcam_utils_unite_bytes(const uint8_t *arr1, const uint8_t *arr2, uint8_t       *res);

/**
 * performs a XOR operation between 2 bytes array.
 * The result is an array with logical Exclusive OR between respective 2 bytes.
 *
 * @param[in]  arr1           - First byte array
 * @param[in]  arr2           - Second byte array
 * @param[out] res            - The result of the XOR operation.
 */
static void __atcam_utils_xor_bytes(const uint8_t *arr1, const uint8_t *arr2, uint8_t       *res);

/**
 * Compares 2 bytes array. Bytes array are considered equal if all their bytes are the same.
 *
 * @param[in]  arr1           - First byte array
 * @param[in]  arr2           - Second byte array
 */
static boolean_t __atcam_utils_compare_bytes_arr(const uint8_t *arr1,
                                                 const uint8_t *arr2);


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t get_region_rule_resource(sx_atcam_key_blocks_size_t key_blocks_size,
                                     boolean_t                  is_atcam,
                                     rm_sdk_table_type_e       *resource)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* According to the block size get the correct resource to update ATCAM or ctcam*/
    switch (key_blocks_size) {
    case SX_ATCAM_ONE_KEY_BLOCK:
        *resource = (is_atcam) ? RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E : RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E;
        break;

    case SX_ATCAM_TWO_KEY_BLOCKS:
        *resource = (is_atcam) ? RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E : RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E;
        break;

    case SX_ATCAM_FOUR_KEY_BLOCKS:
        *resource =
            (is_atcam) ? RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E : RM_SDK_TABLE_TYPE_C_TCAM_FOUR_KEYS_BLOCK_E;
        break;

    case SX_ATCAM_SIX_KEY_BLOCKS:
        *resource = (is_atcam) ? RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E : RM_SDK_TABLE_TYPE_C_TCAM_SIX_KEYS_BLOCK_E;
        break;

    default:
        SX_LOG_ERR("Unsupported key block size [%u] when updating rm\n", key_blocks_size);
        status = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t atcam_utils_intersection_mask(const sx_atcam_key_mask_t *const mask1,
                                          const sx_atcam_key_mask_t *const mask2,
                                          sx_atcam_key_mask_t             *res)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!mask1 || !mask2 || !res) {
        SX_LOG_ERR("One of the parameters to function was NULL\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __atcam_utils_intersect_bytes(mask1->flex_mask_blocks,
                                  mask2->flex_mask_blocks,
                                  res->flex_mask_blocks);
out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_utils_are_keys_compatible(const sx_atcam_key_t *const key1,
                                            const sx_atcam_key_t *const key2,
                                            boolean_t                  *are_compatible)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_mask_t  intersection_mask;
    sx_atcam_key_value_t value1, value2;

    SX_LOG_ENTER();
    SX_MEM_CLR(intersection_mask);
    SX_MEM_CLR(value1);
    SX_MEM_CLR(value2);

    if (!key1 || !key2 || !are_compatible) {
        SX_LOG_ERR("atcam_utils_are_rules_compatible: Null params were given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __atcam_utils_intersect_bytes(key1->flex_mask_blocks,
                                  key2->flex_mask_blocks,
                                  intersection_mask.flex_mask_blocks);
    __atcam_utils_intersect_bytes(key1->flex_value_blocks,
                                  intersection_mask.flex_mask_blocks,
                                  value1.flex_value_blocks);
    __atcam_utils_intersect_bytes(key2->flex_value_blocks,
                                  intersection_mask.flex_mask_blocks,
                                  value2.flex_value_blocks);

    *are_compatible = __atcam_utils_compare_bytes_arr(value1.flex_value_blocks,
                                                      value2.flex_value_blocks);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_intersect_rule_n_mask(const sx_atcam_mask_byte_t *mask,
                                              sx_atcam_key_byte_t        *rule_key_val)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!rule_key_val || !mask) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    __atcam_utils_intersect_bytes(mask, rule_key_val, rule_key_val);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_intersect_masks(const sx_atcam_key_mask_t *mask1,
                                        const sx_atcam_key_mask_t *mask2,
                                        sx_atcam_key_mask_t       *res)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!mask1 || !mask2 || !res) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    __atcam_utils_intersect_bytes(mask1->flex_mask_blocks, mask2->flex_mask_blocks, res->flex_mask_blocks);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_intersect_val_n_mask(const sx_atcam_key_value_t *const value,
                                             const sx_atcam_key_mask_t  *const mask,
                                             sx_atcam_key_value_t             *res)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!value || !mask || !res) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    __atcam_utils_intersect_bytes(value->flex_value_blocks, mask->flex_mask_blocks, res->flex_value_blocks);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_unite_masks(const sx_atcam_key_mask_t *mask1, sx_atcam_key_mask_t *mask2)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!mask1 || !mask2) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    __atcam_utils_unite_bytes(mask1->flex_mask_blocks, mask2->flex_mask_blocks, mask2->flex_mask_blocks);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_xor_masks(const sx_atcam_key_mask_t *const mask1,
                                  const sx_atcam_key_mask_t *const mask2,
                                  sx_atcam_key_mask_t             *res)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!mask1 || !mask2 || !res) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    __atcam_utils_xor_bytes(mask1->flex_mask_blocks, mask2->flex_mask_blocks, res->flex_mask_blocks);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_blocks_location_get(const uint32_t blocks_count,
                                            uint8_t       *blocks_start,
                                            uint8_t       *blocks_size)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (!blocks_start || !blocks_size) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((blocks_count == 0) || (blocks_count > ATCAM_MAX_NUM_OF_HW_KEY_BLOCKS)) {
        SX_LOG_ERR("Illegal number of key blocks [%u].\n", blocks_count);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *blocks_start = atcam_utils_blocks_start[blocks_count];
    *blocks_size = atcam_utils_blocks_size[blocks_count];

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_utils_need_to_update_bf(const uint16_t num_of_erps, boolean_t *update_bf)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (update_bf == NULL) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *update_bf = TRUE;

    if ((num_of_erps != 0) && (num_of_erps < MIN_ERPS_FOR_BF)) {
        *update_bf = FALSE;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_utils_need_to_update_all_erps_bf(const uint16_t  old_num_of_erps,
                                                   const uint16_t  new_num_of_erps,
                                                   const boolean_t is_add,
                                                   boolean_t      *update_all_p,
                                                   boolean_t      *bf_bypass_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   update_all = FALSE;
    boolean_t   bf_bypass = FALSE;

    if (is_add) {
        if (new_num_of_erps < MIN_ERPS_FOR_BF) {
            update_all = FALSE;
            bf_bypass = TRUE;
        } else if (old_num_of_erps < MIN_ERPS_FOR_BF) {
            update_all = TRUE;
            bf_bypass = FALSE;
        }
    } else {
        if (old_num_of_erps < MIN_ERPS_FOR_BF) {
            update_all = FALSE;
            bf_bypass = TRUE;
        } else if (new_num_of_erps < MIN_ERPS_FOR_BF) {
            update_all = TRUE;
            bf_bypass = TRUE;
        }
    }

    if (update_all_p != NULL) {
        *update_all_p = update_all;
    }

    if (bf_bypass_p != NULL) {
        *bf_bypass_p = bf_bypass;
    }

    SX_LOG_EXIT();
    return sx_status;
}

/*****************************************************************
 *                     Local Functions implementations
 ******************************************************************/

#define BITWISE_OP(arr1, op, arr2, res)                                \
    ((uint64_t*)res)[0] = ((uint64_t*)arr1)[0] op((uint64_t*)arr2)[0]; \
    ((uint64_t*)res)[1] = ((uint64_t*)arr1)[1] op((uint64_t*)arr2)[1]; \
    ((uint64_t*)res)[2] = ((uint64_t*)arr1)[2] op((uint64_t*)arr2)[2]; \
    ((uint64_t*)res)[3] = ((uint64_t*)arr1)[3] op((uint64_t*)arr2)[3]; \
    ((uint64_t*)res)[4] = ((uint64_t*)arr1)[4] op((uint64_t*)arr2)[4]; \
    ((uint64_t*)res)[5] = ((uint64_t*)arr1)[5] op((uint64_t*)arr2)[5]; \
    ((uint64_t*)res)[6] = ((uint64_t*)arr1)[6] op((uint64_t*)arr2)[6];


static void __atcam_utils_intersect_bytes(const uint8_t *arr1, const uint8_t *arr2, uint8_t *res)
{
    BITWISE_OP(arr1, &, arr2, res)
}

static void __atcam_utils_unite_bytes(const uint8_t *arr1, const uint8_t *arr2, uint8_t *res)
{
    BITWISE_OP(arr1, |, arr2, res)
}

static void __atcam_utils_xor_bytes(const uint8_t *arr1, const uint8_t *arr2, uint8_t *res)
{
    BITWISE_OP(arr1, ^, arr2, res)
}

static boolean_t __atcam_utils_compare_bytes_arr(const uint8_t *arr1, const uint8_t  *arr2)
{
    return memcmp(arr1, arr2, ATCAM_MAX_KEY_SIZE) == 0 ? TRUE : FALSE;
}
