/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_TYPES_H__
#define __ATCAM_TYPES_H__

#include <stdint.h>
#include "sx/sxd/kernel_user.h"
#include "sx/sdk/sx_status.h"
#include "sx/sdk/sx_types.h"
#include "complib/sx_log.h"

#define DEFAULT_DEV_ID 1
#define BYTE_SIZE      8

#define SX_ATCAM_NUM_OF_ERPS       256
#define SX_ATCAM_ERPS_PER_REGION   16
#define SX_ATCAM_HW_REGION_MAX     1000
#define SX_ATCAM_INVALID_REGION_ID 0x2FFFF


#define ATCAM_MAX_NUM_OF_HW_KEY_BLOCKS 12
#define ATCAM_MAX_KEY_SIZE             56
#define ATCAM_NUM_OF_BANKS             4
#define ATCAM_BF_SIZE_OF_BANK          (1 << 16)
#define ATCAM_INVALID_ERP_ID           SX_ATCAM_ERPS_PER_REGION
#define ATCAM_INVALID_ERP_OFFSET       SX_ATCAM_ERPS_PER_REGION
#define ATCAM_INVALID_ERP_INDEX        0xFFFFFFFF
#define ATCAM_INVALID_RULE_OFFSET      0xFFFFFFFF
#define ERPS_POOL_MAX_SIZE             512
#define ATCAM_BF_NUM_OF_BANKS          ATCAM_NUM_OF_BANKS
#define ATCAM_KEY_BLOCK_BIT_SIZE       36             /* 4.5B key blocks */
#define ATCAM_LARGE_KEY_START_OFFSET   2
#define ATCAM_LARGE_KEY_PREFIX_BYTES   27
#define ATCAM_LARGE_KEY_BYTES          54
#define ATCAM_LARGE_KEY_MIN_BLOCK_CNT  8           /* The minimum number of blocks needed to necessitate a large key */
#define ATCAM_SINGLE_ENTRY_BLOCK_CNT   2           /* The maximum number of block that occupy a single KVD entry     */
#define MIN_ERPS_FOR_BF                3           /* We will not calculate the BF if we have less than 3 erps */
#define BULK_BF_ENTREIS_MAX            256         /* Maximum number of BF entries to be updated in BF register */
#define ATCAM_CLR_REGION_BIT(region_id) (region_id &= 0xFFFF) /* Clear the additional bit imposed on the region_id by the acl */


#define INITIAL_CTCAM_REGION_SIZE 16
#define CTCAM_CHANGE_INTERVAL     16


/**
 * Defines the id of a region in terms of atcam module. In general, there should be a
 * one-to-one relation between acl region id, and atcam id, but this can also vary.
 */
typedef uint32_t sx_atcam_region_id_t;

/**
 * The ID of an eRP within region context. To uniquely identify an eRP, always supply the
 * region id where this eRP resides.
 */
typedef uint8_t sx_atcam_erp_id_t;


/**
 * Defines the internal atcam id for a rule. Each rule has a unique, non-changing, running value.
 */
typedef uint64_t sx_atcam_rule_id_t;

/**
 * One byte of key within atcam modules
 */
typedef uint8_t sx_atcam_key_byte_t;
/**
 * One byte of mask within atcam modules
 */
typedef uint8_t sx_atcam_mask_byte_t;

typedef uint32_t sx_atcam_region_size_t;
typedef uint32_t sx_atcam_region_ctcam_size_t;
typedef uint32_t sx_atcam_erp_index_t;
typedef uint8_t sx_atcam_erp_offset_t;
typedef uint8_t sx_atcam_bank_number_t;

/**
 * Defines the type for large key entry ID
 */
typedef uint32_t sx_atcam_large_entry_key_id_t;

/**
 * The number of key-block count supported in atcam
 */
typedef enum sx_atcam_key_blocks_size {
    SX_ATCAM_ONE_KEY_BLOCK   = 1,
    SX_ATCAM_TWO_KEY_BLOCKS  = 2,
    SX_ATCAM_FOUR_KEY_BLOCKS = 4,
    SX_ATCAM_SIX_KEY_BLOCKS  = 6,
} sx_atcam_key_blocks_size_t;

/**
 * Algo-Tcam key should ALWAYS structured in the following way, where key and mask blocks
 * are first translated by acl-key block resolver (according to PRM).
 */
typedef struct sx_atcam_key {
    sx_atcam_key_byte_t  flex_value_blocks[ATCAM_MAX_KEY_SIZE];
    sx_atcam_mask_byte_t flex_mask_blocks[ATCAM_MAX_KEY_SIZE];
} sx_atcam_key_t;


/**
 * The value part of atcam-key. Use this when mask is mutual amongst many different keys (like eRPs etc.)
 */
typedef struct sx_atcam_key_value {
    sx_atcam_key_byte_t flex_value_blocks[ATCAM_MAX_KEY_SIZE];
} sx_atcam_key_value_t;


/**
 * the mask part of atcam-key. Used to describe eRP for instance.
 */
typedef struct sx_atcam_key_mask {
    sx_atcam_mask_byte_t flex_mask_blocks[ATCAM_MAX_KEY_SIZE];
} sx_atcam_key_mask_t;

typedef struct sx_atcam_key_delta {
    uint16_t delta_start;
    uint8_t  delta_value;
    uint8_t  delta_mask;
} sx_atcam_key_delta_t;

/* Callbacks to the flex acl module to create and destroy shadow regions for erp optimizations */
typedef sx_status_t (*atcam_shadow_region_create_cb)(sx_acl_region_id_t  region_id,
                                                     sx_acl_region_id_t *shadow_region_id,
                                                     sx_acl_id_t        *shadow_acl_id);
typedef sx_status_t (*atcam_shadow_region_remove_cb)(sx_acl_region_id_t region_id,
                                                     sx_acl_region_id_t shadow_region_id);

#endif /* __ATCAM_TYPES_H__ */
