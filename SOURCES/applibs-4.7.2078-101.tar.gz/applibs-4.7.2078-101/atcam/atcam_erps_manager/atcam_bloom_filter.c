/*
 * SPDX-FileCopyrightText: Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "complib/sx_log.h"
#include "complib/cl_mem.h"
#include "complib/cl_byteswap.h"
#include "sx/utils/bloom_filter.h"
#include "sx/sdk/sx_status_convertor.h"
#include "sx/utils/crc16.h"

#include "atcam_bloom_filter.h"
#include "utils/sx_mem.h"
#include "atcam/atcam_sxd_wrapper/atcam_bloom_filter_sxd_wrapper.h"
#include "atcam/atcam_regions_manager/atcam_regions_db.h"

/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/

#define ATCAM_BF_NUMBER_OF_BANKS 4

/**
 * This struct should mimic the HW implementation of bloom_filter (under Spectrum2).
 * Currently, HW bloom_filter is implemented using ATCAM_BF_NUMBER_OF_BANKS.
 */
typedef struct atcam_bloom_filter {
    bloom_filter_t *bf_banks[ATCAM_BF_NUMBER_OF_BANKS];
} atcam_bloom_filter_t;

/* 4 key blocks are packed together == 4.5*4 */
#define ATCAM_BF_4_KEY_BLOCK_HW_NUM_OF_BYTES 18

typedef struct __attribute__((__packed__)) atcam_bf_key_info_flex2 {
    uint8_t  chunk_pad[3];
    uint16_t erp_region_id;
    uint8_t  keys_block[ATCAM_BF_4_KEY_BLOCK_HW_NUM_OF_BYTES];
} atcam_bf_key_info_flex2_t;

typedef struct __attribute__((__packed__)) atcam_bf_key_info_flex3 {
    uint16_t erp_region_id;
    uint8_t  keys_block[ATCAM_BF_4_KEY_BLOCK_HW_NUM_OF_BYTES];
} atcam_bf_key_info_flex3_t;

/* The number of bits to shift right to match the PRM specification */
#define FLEX3_KEY_INFO_SHIFT (2)

/* The bf key is built from 3 chunks each composed of 4 key blocks. */
#define ATCAM_BF_KEY_BLOCK_IN_CHUNK 4
#define ATCAM_BF_CHUNKS_NUM         3

#define ATCAM_BF_BLOCKS_TO_CHUNKS(blocks) (((blocks - 1) >> 2) + 1)

#define FLEX2_BLOOM_FILTER_POLY         (0x8529) /* 1+x^3+x^5+x^8+x^10+x^15+x^16 */
#define FLEX3_BLOOM_FILTER_COLUMN_POLY  (0x002D) /* 1+x^2+x^3+x^5+x^6 */
#define FLEX3_BLOOM_FILTER_COLUMN_WIDTH (6)
#define FLEX3_BLOOM_FILTER_ROW_POLY     (0x001B) /* 1+x^1+x^3+x^4+x^10 */
#define FLEX3_BLOOM_FILTER_ROW_WIDTH    (10)

/**
 * The key of the bloom_filter.
 * This should be exactly as HW uses it - see PRM for reference.
 */
typedef struct __attribute__((__packed__)) atcam_bloom_filter_key {
    union {
        atcam_bf_key_info_flex2_t data_flex2[ATCAM_BF_CHUNKS_NUM];
        atcam_bf_key_info_flex3_t data_flex3[ATCAM_BF_CHUNKS_NUM];
    };
} atcam_bloom_filter_key_t;

typedef struct {
    sx_status_t (*atcam_bloom_filter_build_key_pfn)(const sx_atcam_region_id_t  region_id,
                                                    const sx_atcam_erp_id_t     erp_id,
                                                    const sx_atcam_key_value_t *key,
                                                    atcam_bloom_filter_key_t   *bf_key,
                                                    uint8_t                   **bf_start,
                                                    uint32_t                   *bf_size);
} atcam_bloom_filter_ops_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static atcam_bloom_filter_t atcam_bf;
/* The following is the offset in the key where each of the bf chunks should be copied from.*/
static uint8_t key_chunk_locations[ATCAM_BF_CHUNKS_NUM] = {2, 20, 38};

static crc16_table_t bf_crc16_table;
static crc16_table_t bf_crc_row_table;
static crc16_table_t bf_crc_column_table;

static atcam_bloom_filter_ops_t atcam_bloom_filter_ops;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __atcam_bloom_filter_check_args(const uint8_t           bf_bank,
                                                   const sx_atcam_erp_id_t erp_id);


/**
 * Builds the bf_key, for the region_id, erp_id and rule key.
 */
static sx_status_t __atcam_bloom_filter_build_key(const sx_atcam_region_id_t  region_id,
                                                  const sx_atcam_erp_id_t     erp_id,
                                                  const sx_atcam_key_value_t *key,
                                                  atcam_bloom_filter_key_t   *bf_key,
                                                  uint8_t                   **bf_start,
                                                  uint32_t                   *bf_size);
static sx_status_t __atcam_bloom_filter_build_key_flex2(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size);
static sx_status_t __atcam_bloom_filter_build_key_flex3(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size);
static sx_status_t __atcam_bloom_filter_build_key_flex4(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size);


/* The hash functions used in each type of flex */
static uint16_t __flex2_bf_hash_func(const uint8_t* data, uint32_t size);
static uint16_t __flex3_bf_hash_func(const uint8_t* data, uint32_t size);

/************************************************
 *  Function implementations
 ***********************************************/

static uint16_t __flex2_bf_hash_func(const uint8_t* data, uint32_t size)
{
    return crc_16_msb(&bf_crc16_table, data, size, FLEX2_BLOOM_FILTER_POLY);
}

static uint16_t __flex3_bf_hash_func(const uint8_t* data, uint32_t size)
{
    uint16_t crc_row = 0, crc_column = 0;

    crc_row = crc_msb(&bf_crc_row_table, data, size, FLEX3_BLOOM_FILTER_ROW_POLY, FLEX3_BLOOM_FILTER_ROW_WIDTH);
    crc_column = crc_msb(&bf_crc_column_table,
                         data,
                         size,
                         FLEX3_BLOOM_FILTER_COLUMN_POLY,
                         FLEX3_BLOOM_FILTER_COLUMN_WIDTH);
    /* 6 bit column is MSB, 10 bit row_is LSB */
    return (crc_column << FLEX3_BLOOM_FILTER_ROW_WIDTH) | crc_row;
}


sx_status_t atcam_bloom_filter_assign_ops_flex2(atcam_bloom_filter_params_t *bloom_filter_params_p)
{
    bloom_filter_params_p->atcam_bf_hash_func = __flex2_bf_hash_func;
    bloom_filter_params_p->size = ATCAM_BF_SIZE_OF_BANK;

    atcam_bloom_filter_ops.atcam_bloom_filter_build_key_pfn = __atcam_bloom_filter_build_key_flex2;
    return SX_STATUS_SUCCESS;
}

sx_status_t atcam_bloom_filter_assign_ops_flex3(atcam_bloom_filter_params_t *bloom_filter_params_p)
{
    bloom_filter_params_p->atcam_bf_hash_func = __flex3_bf_hash_func;
    bloom_filter_params_p->size = ATCAM_BF_SIZE_OF_BANK;

    atcam_bloom_filter_ops.atcam_bloom_filter_build_key_pfn = __atcam_bloom_filter_build_key_flex3;
    return SX_STATUS_SUCCESS;
}

sx_status_t atcam_bloom_filter_assign_ops_flex4(atcam_bloom_filter_params_t *bloom_filter_params_p)
{
    bloom_filter_params_p->atcam_bf_hash_func = __flex3_bf_hash_func;
    bloom_filter_params_p->size = ATCAM_BF_SIZE_OF_BANK;

    atcam_bloom_filter_ops.atcam_bloom_filter_build_key_pfn = __atcam_bloom_filter_build_key_flex4;
    return SX_STATUS_SUCCESS;
}

sx_status_t atcam_bloom_filter_init(const atcam_bloom_filter_params_t* params)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    uint16_t          i, j;

    SX_LOG_ENTER();

    for (i = 0; i < ATCAM_BF_NUMBER_OF_BANKS; ++i) {
        /*
         * each bf is allocated with the same hash_function. Obviously, this can change
         * with different implementations of bf.
         */
        sx_utils_status = bloom_filter_init(params->atcam_bf_hash_func, params->size, &atcam_bf.bf_banks[i]);
        sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "atcam_bf_init: error while allocating bloom_filter bank %d\n", i);
            goto rollback_mem_error;
        }
    }

    goto out;

rollback_mem_error:

    for (j = 0; j <= i; ++j) {
        sx_utils_status = bloom_filter_deinit(&atcam_bf.bf_banks[j]);
        sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR,
                   "atcam_bf_init: error while deallocating bloom_filter bank %d at rollback_mem_error label\n",
                   j);
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_bloom_filter_deinit()
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    uint16_t          i;

    SX_LOG_ENTER();

    for (i = 0; i < ATCAM_BF_NUMBER_OF_BANKS; ++i) {
        sx_utils_status = bloom_filter_deinit(&atcam_bf.bf_banks[i]);
        sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "atcam_bf_deinit: error while deallocating bloom_filter bank %d\n", i);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_bloom_filter_insert_rule(const sx_dev_id_t           dev_id,
                                           const uint8_t               bf_bank,
                                           const sx_atcam_region_id_t  region_id,
                                           const sx_atcam_erp_id_t     erp_id,
                                           const sx_atcam_key_value_t *key,
                                           uint32_t                   *res_index)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t        sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    boolean_t                is_first = FALSE;
    atcam_bloom_filter_key_t bf_key;
    uint8_t                 *bf_start = NULL;
    uint32_t                 bf_size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(bf_key);

    if (res_index == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed. res_index can't be NULL\n");
        goto out;
    }
    sx_status = __atcam_bloom_filter_check_args(bf_bank, erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed:\n");
        goto out;
    }

    sx_status = __atcam_bloom_filter_build_key(region_id, erp_id, key,
                                               &bf_key, &bf_start, &bf_size);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed: when building bf key\n");
        goto out;
    }

    sx_utils_status = bloom_filter_increase(atcam_bf.bf_banks[bf_bank],
                                            bf_start,
                                            bf_size,
                                            res_index, &is_first);
    sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed: when accessing bf at bank %d\n", bf_bank);
        goto out;
    }

    if (is_first) {
        sx_status = atcam_sxd_wrapper_bloom_filter_update_hw(dev_id, bf_bank, res_index, 1, FALSE);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed: when updating HW\n");
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_bloom_filter_delete_rule(const sx_dev_id_t           dev_id,
                                           const uint8_t               bf_bank,
                                           const sx_atcam_region_id_t  region_id,
                                           const sx_atcam_erp_id_t     erp_id,
                                           const sx_atcam_key_value_t *key,
                                           uint32_t                   *res_index)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t        sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    boolean_t                is_last;
    atcam_bloom_filter_key_t bf_key;
    uint8_t                 *bf_start = NULL;
    uint32_t                 bf_size = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(bf_key);

    if (res_index == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_delete_rule failed. res_index can't be NULL\n");
        goto out;
    }

    sx_status = __atcam_bloom_filter_check_args(bf_bank, erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_delete_rule failed:\n");
        goto out;
    }

    sx_status = __atcam_bloom_filter_build_key(region_id, erp_id, key,
                                               &(bf_key), &bf_start, &bf_size);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_delete_rule failed: when building bf key\n");
        goto out;
    }

    sx_utils_status = bloom_filter_decrease(atcam_bf.bf_banks[bf_bank],
                                            bf_start,
                                            bf_size,
                                            res_index, &is_last);
    sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_delete_rule failed: when accessing bf at bank %d\n", bf_bank);
        goto out;
    }

    if (is_last) {
        sx_status = atcam_sxd_wrapper_bloom_filter_update_hw(dev_id, bf_bank, res_index, 1, TRUE);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "atcam_bf_delete_rule failed: when updating HW\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_bloom_filter_update_erp_in_bulk(const atcam_erps_db_erp_t *erp, boolean_t is_increase)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t            sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t               *it = NULL;
    const cl_map_item_t         *end = NULL;
    atcam_rules_db_rule_entry_t *erp_rule_entry = NULL;
    uint32_t                     res_index_arr[BULK_BF_ENTREIS_MAX];
    uint32_t                     num_of_rules = 0;
    boolean_t                    need_to_update_hw = FALSE;


    SX_LOG_ENTER();

    if (erp == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed. erp can't be NULL\n");
        goto out;
    }

    it = cl_qmap_head(&(erp->rules));
    end = cl_qmap_end(&erp->rules);
    while (it != end) {
        erp_rule_entry = PARENT_STRUCT(it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        if (erp_rule_entry->data.is_atcam) {
            sx_utils_status = bloom_filter_update_data(atcam_bf.bf_banks[erp->bf_bank],
                                                       erp_rule_entry->data.bf_res_index,
                                                       is_increase,
                                                       &need_to_update_hw);
            sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG(SX_LOG_ERROR,
                       "atcam_bloom_filter_update_erp_in_bulk failed: when accessing bf at bank %d\n",
                       erp->bf_bank);
                goto out;
            }
            if (need_to_update_hw) {
                res_index_arr[num_of_rules] = erp_rule_entry->data.bf_res_index;
                num_of_rules++;
            }
        }
        it = cl_qmap_next(it);
        if ((it == end) || (num_of_rules == BULK_BF_ENTREIS_MAX)) {
            if (num_of_rules != 0) {
                sx_status = atcam_sxd_wrapper_bloom_filter_update_hw(DEFAULT_DEV_ID,
                                                                     erp->bf_bank,
                                                                     res_index_arr,
                                                                     num_of_rules,
                                                                     !is_increase);
                if (SX_STATUS_SUCCESS != sx_status) {
                    SX_LOG(SX_LOG_ERROR, "atcam_bf_insert_rule failed: when accessing bf HW\n");
                    goto out;
                }
                num_of_rules = 0;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_bloom_filter_calculate_res_index(const uint8_t               bf_bank,
                                                   const sx_atcam_region_id_t  region_id,
                                                   const sx_atcam_erp_id_t     erp_id,
                                                   const sx_atcam_key_value_t *key,
                                                   uint32_t                   *res_index)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t        sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    atcam_bloom_filter_key_t bf_key;
    uint8_t                 *bf_start = NULL;
    uint32_t                 bf_size = 0;


    SX_LOG_ENTER();
    SX_MEM_CLR(bf_key);


    if (res_index == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_calculate_res_index failed. res_index can't be NULL\n");
        goto out;
    }

    sx_status = __atcam_bloom_filter_check_args(bf_bank, erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_calculate_res_index failed:\n");
        goto out;
    }

    sx_status = __atcam_bloom_filter_build_key(region_id, erp_id, key,
                                               &(bf_key), &bf_start, &bf_size);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_delete_rule failed: when building bf key\n");
        goto out;
    }
    sx_utils_status = bloom_filter_calculate_res_index(atcam_bf.bf_banks[bf_bank],
                                                       bf_start,
                                                       bf_size,
                                                       res_index);
    sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_calculate_res_index failed: when accessing bf at bank %d\n", bf_bank);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

/*
 * For DEBUG purposes only
 */
sx_status_t atcam_bloom_filter_get_by_key(const uint8_t               bf_bank,
                                          const sx_atcam_region_id_t  region_id,
                                          const sx_atcam_erp_id_t     erp_id,
                                          const sx_atcam_key_value_t *key,
                                          uint32_t                   *res_index,
                                          uint32_t                   *res_value)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t        sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    atcam_bloom_filter_key_t bf_key;
    uint8_t                 *bf_start = NULL;
    uint32_t                 bf_size = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(bf_key);

    sx_status = __atcam_bloom_filter_check_args(bf_bank, erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_get_by_key failed:\n");
        goto out;
    }

    if ((res_index == NULL) || (res_value == NULL)) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_get_by_key failed: bad params\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    sx_status = __atcam_bloom_filter_build_key(region_id, erp_id, key,
                                               &bf_key, &bf_start, &bf_size);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_get_by_key failed: when building bf key\n");
        goto out;
    }

    sx_utils_status = bloom_filter_get(atcam_bf.bf_banks[bf_bank],
                                       bf_start,
                                       bf_size,
                                       res_index, res_value);
    sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bf_get_by_key failed: when accessing bf at bank %d\n", bf_bank);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_bloom_filter_issu_set()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     bf_bank = 0;
    uint32_t    count = 0, i = 0;
    uint32_t    res_index_arr[BULK_BF_ENTREIS_MAX] = {0};

    SX_LOG_ENTER();

    /* The previous ISSU iteration might have left BF bits
     * set to 1 in the hw that are no longer correct. Therefore, we go
     * over all the BF bits that we know should be set to 0 and we make
     * sure they are set to 0 in hw*/
    for (bf_bank = 0; bf_bank < ATCAM_BF_NUMBER_OF_BANKS; bf_bank++) {
        /* We will only go over the bf_bank that were initialized */
        if (!atcam_bf.bf_banks[bf_bank] || !atcam_bf.bf_banks[bf_bank]->is_initialized) {
            continue;
        }
        for (i = 0; i < atcam_bf.bf_banks[bf_bank]->size; i++) {
            if (atcam_bf.bf_banks[bf_bank]->data[i] == 0) {
                res_index_arr[count] = i;
                count++;
            }
            if (((i + 1) == atcam_bf.bf_banks[bf_bank]->size) || (count == BULK_BF_ENTREIS_MAX)) {
                if (count != 0) {
                    sx_status = atcam_sxd_wrapper_bloom_filter_update_hw(DEFAULT_DEV_ID,
                                                                         bf_bank,
                                                                         res_index_arr,
                                                                         count,
                                                                         TRUE);
                    if (SX_STATUS_SUCCESS != sx_status) {
                        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_issu_set failed: when accessing bf HW\n");
                        goto out;
                    }
                    count = 0;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

/************************************************
 *  Local Functions implementations
 ***********************************************/

static sx_status_t __atcam_bloom_filter_check_args(const uint8_t bf_bank, const sx_atcam_erp_id_t erp_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (bf_bank >= ATCAM_BF_NUMBER_OF_BANKS) {
        SX_LOG(SX_LOG_ERROR, "bf_bank out of range.\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!atcam_bf.bf_banks[bf_bank] || !atcam_bf.bf_banks[bf_bank]->is_initialized) {
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG(SX_LOG_ERROR, "Atcam bf bank %d wasn't properly initialized\n", bf_bank);
        goto out;
    }

    if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG(SX_LOG_ERROR, "erd_id out of range.\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __atcam_bloom_filter_build_key_flex2(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i_chunk = 0;
    uint16_t    erp_region_id = 0;
    uint32_t    key_blocks_cnt = 0;

    sx_status = atcam_regions_db_key_blocks_cnt_get(region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Unable to get region key blocks count for region %d\n", region_id);
        goto out;
    }

    /* NOTE: it is assumed here that bf_key is zeroed by the caller of this function. */
    /* NOTE: Blocks 0..3 are inserted to chunk 2, 4..7 to chunk 1, 8..1 to chunk 0 */
    i_chunk = ATCAM_BF_CHUNKS_NUM - ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt);
    *bf_start = (uint8_t*)(&bf_key->data_flex2[i_chunk]);
    *bf_size = ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt) * sizeof(atcam_bf_key_info_flex2_t);
    /* Go over the chunks of key blocks */
    for (; i_chunk < ATCAM_BF_CHUNKS_NUM; i_chunk++) {
        /* copy the key blocks from the original key */
        memcpy(bf_key->data_flex2[i_chunk].keys_block,
               &(key->flex_value_blocks[key_chunk_locations[i_chunk]]),
               ATCAM_BF_4_KEY_BLOCK_HW_NUM_OF_BYTES);
        /* add the erp & region id to the bf key */
        erp_region_id = (uint16_t)((erp_id & 0xF) | ((region_id & 0x3ff) << 4));
        bf_key->data_flex2[i_chunk].erp_region_id = cl_hton16(erp_region_id);
    }

out:
    return sx_status;
}

static void __right_shift_array(uint8_t *arr, uint32_t shift, uint32_t len)
{
    uint32_t bits_shift = shift % 8;
    uint32_t bytes_shift = shift / 8 + ((bits_shift > 0) ? 1 : 0);
    uint8_t  byte_mask = 0xff >> bits_shift;
    int      i = 0;

    for (i = len - 1; i >= 0; i--) {
        arr[bytes_shift + i] &= byte_mask;
        arr[bytes_shift + i] |= arr[i] << (8 - bits_shift);
        arr[bytes_shift + i - 1] = arr[i] >> bits_shift;
    }
    /* Clear the remaining bytes */
    for (i = 0; i < (int)(shift / 8); i++) {
        arr[i] = 0;
    }
}

static sx_status_t __atcam_bloom_filter_build_key_flex3_flex4(const sx_atcam_region_id_t  region_id,
                                                              const sx_atcam_erp_id_t     erp_id,
                                                              const sx_atcam_key_value_t *key,
                                                              atcam_bloom_filter_key_t   *bf_key,
                                                              uint8_t                   **bf_start,
                                                              uint32_t                   *bf_size,
                                                              boolean_t                   is_flex4)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i_chunk = 0;
    uint16_t    erp_region_id = 0;
    uint32_t    key_blocks_cnt = 0;

    sx_status = atcam_regions_db_key_blocks_cnt_get(region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Unable to get region key blocks count for region %d\n", region_id);
        goto out;
    }

    /* NOTE: it is assumed here that bf_key is zeroed by the caller of this function. */
    /* NOTE: Blocks 0..3 are inserted to chunk 2, 4..7 to chunk 1, 8..1 to chunk 0 */
    i_chunk = ATCAM_BF_CHUNKS_NUM - ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt);
    *bf_start = (uint8_t*)(&bf_key->data_flex3[i_chunk]);
    *bf_size = ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt) * sizeof(atcam_bf_key_info_flex3_t);

    erp_region_id = (uint16_t)((erp_id & 0xF) | ((region_id & 0x3ff) << 4));
    /* Go over the chunks of key blocks */
    for (; i_chunk < ATCAM_BF_CHUNKS_NUM; i_chunk++) {
        /* copy the key blocks from the original key */
        memcpy(bf_key->data_flex3[i_chunk].keys_block,
               &(key->flex_value_blocks[key_chunk_locations[i_chunk]]),
               ATCAM_BF_4_KEY_BLOCK_HW_NUM_OF_BYTES);
        /* add the erp & region id to the bf key */
        bf_key->data_flex3[i_chunk].erp_region_id = cl_hton16(erp_region_id);
        /* For Flex 4 we need the erp & region id only in the last block */
        if ((is_flex4 == TRUE) && (i_chunk < (ATCAM_BF_CHUNKS_NUM - 1))) {
            bf_key->data_flex3[i_chunk].erp_region_id = 0;
        }
    }

    /* For Spectrum 4 we need to shift right by 2 bits for the top two chunks */
    if (ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt) > 1) {
        __right_shift_array((uint8_t*)(&bf_key->data_flex3[1]), FLEX3_KEY_INFO_SHIFT,
                            sizeof(atcam_bf_key_info_flex3_t));
    }
    if (ATCAM_BF_BLOCKS_TO_CHUNKS(key_blocks_cnt) > 2) {
        __right_shift_array((uint8_t*)(&bf_key->data_flex3[0]), FLEX3_KEY_INFO_SHIFT * 2,
                            sizeof(atcam_bf_key_info_flex3_t));
    }

out:
    return sx_status;
}

static sx_status_t __atcam_bloom_filter_build_key_flex3(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size)
{
    return __atcam_bloom_filter_build_key_flex3_flex4(region_id, erp_id, key, bf_key, bf_start, bf_size, FALSE);
}

static sx_status_t __atcam_bloom_filter_build_key_flex4(const sx_atcam_region_id_t  region_id,
                                                        const sx_atcam_erp_id_t     erp_id,
                                                        const sx_atcam_key_value_t *key,
                                                        atcam_bloom_filter_key_t   *bf_key,
                                                        uint8_t                   **bf_start,
                                                        uint32_t                   *bf_size)
{
    return __atcam_bloom_filter_build_key_flex3_flex4(region_id, erp_id, key, bf_key, bf_start, bf_size, TRUE);
}

static sx_status_t __atcam_bloom_filter_build_key(const sx_atcam_region_id_t  region_id,
                                                  const sx_atcam_erp_id_t     erp_id,
                                                  const sx_atcam_key_value_t *key,
                                                  atcam_bloom_filter_key_t   *bf_key,
                                                  uint8_t                   **bf_start,
                                                  uint32_t                   *bf_size)
{
    return atcam_bloom_filter_ops.atcam_bloom_filter_build_key_pfn(region_id, erp_id, key, bf_key, bf_start, bf_size);
}
