/*
 * Copyright (C) 2018-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "atcam_erps_prune_calc.h"
#include "atcam_erps_memory_manager.h"
#include "atcam_erps_opts.h"
#include "complib/sx_log.h"

#include "atcam/atcam_sxd_wrapper/atcam_rules_manager_sxd_wrapper.h"


/**
 * Notation used in this file:
 *
 * A' -> A*  - This is the flow to update the prune vector of the rule that was inserted to atcam.
 * A' -> C*  - This is the flow to update the prune ctcam bit of the rule that was inserted to ctcam.
 * A* -> A' - This is the flow of updating the prune vector of other rules, as a result of inserting some rule to atcam.
 */


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local definitions
 ***********************************************/

/* These are utility definitions used in __create_priority_rule_key to create a unique
 * priority for rules with the same priority
 */
#define UNIQUE_PRIORITY_SHIFT (44)
#define UNIQUE_PRIORITY_MAX   (1ULL << (64 - UNIQUE_PRIORITY_SHIFT))
#define UNIQUE_VALUE_MASK     ((1ULL << UNIQUE_PRIORITY_SHIFT) - 1)

#if (FLEX_ACL_RULE_PRIORITY_MAX >= UNIQUE_PRIORITY_MAX)
#error "The logic assumes that the max priority does not exceed 1M (20bits)."
#endif

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/****************************** helper functions************************************/
static uint64_t __create_priority_rule_key(const uint64_t priority);

/****************************** ATCAM insertion ************************************/

/**
 * Updates the prune vector of the current rule being inserted: 'rule'.
 * This function does NOT update any other rules in the process.
 * Note that DB entries will be updated throughout the process as well.
 */
static sx_status_t __atcam_insertion_current_rule_erps_calc(atcam_rules_db_rule_t *rule,
                                                            const boolean_t        edit_flow);

/**
 * Updates a specific bit for a rule being inserted 'rule'.
 * Assume rule 'R' is inserted to erp <i>, then this function is called for every j != i, which
 * described a valid erp of the rule's region. That is, we update every j-th bit in the prune vector
 * of 'R'.
 * The scope of the function is the map <main: rule->erp_id, sec: other erp in region>
 */
static sx_status_t __atcam_insertion_current_rule_erp_to_erp_calc(atcam_erps_db_prune_db_t *prune_map,
                                                                  atcam_rules_db_rule_t    *rule,
                                                                  const boolean_t           edit_flow);

/**
 * Update the prune-ctcam bit of the current rule being inserted to atcam.
 */
static sx_status_t __atcam_insertion_current_rule_erp_to_ctcam_calc(atcam_rules_db_rule_t *rule);

/**
 * Updates the prune vector of other rules in atcam as a result of insertion of rule 'rule'
 * to atcam. That is, assume rule 'R' was inserted to erp <i>, then this function (possibly) updates
 * the i-th bit of other rules in erp's j, where j != i.
 */
static sx_status_t __atcam_insertion_other_rules_erp_to_erp_calc(sx_atcam_erp_id_t      other_erp_id,
                                                                 atcam_rules_db_rule_t *rule,
                                                                 const boolean_t        edit_flow);


/****************************** ATCAM deletion *************************************/

/**
 * Updates the prune DB entries as a result of deletion of rule 'rule' from atcam.
 * Note: Even though there's nothing to update on the rule itself, there's still some db updates
 * to be made, so that the DB will be consistent for future usage.
 */
static sx_status_t __atcam_deletion_current_rule_erps_calc(atcam_rules_db_rule_t *rule);

/*
 * Performs the changes from the function above in the scope of 2 erps.
 */
static sx_status_t __atcam_deletion_current_rule_erp_to_erp_calc(atcam_erps_db_prune_db_t *prune_map,
                                                                 atcam_rules_db_rule_t    *rule);

/**
 * Updates the prune vector of other rules in atcam as a result of deletion of rule 'rule'
 * from atcam. That is, assume rule 'R' was deleted from erp <i>, then this function (possibly) updates
 * the i-th bit of other rules in erp's j, where j != i.
 */
static sx_status_t __atcam_deletion_other_rules_erp_to_erp_calc(const sx_atcam_erp_id_t other_erp_id,
                                                                atcam_rules_db_rule_t  *rule,
                                                                const boolean_t         edit_flow);

/********************************* CTCAM Add/delete/prio-update ********************************/

/**
 * Updates the prune-ctcam bit of all rules in erps, as a result of rule 'rule' being updated to ctcam.
 * Note - this function is used both for insertion and deletion. (And update at next stages)
 */
static sx_status_t __atcam_erps_prune_calc_ctcam_update(const atcam_rules_db_rule_t *rule,
                                                        const boolean_t              is_deletion);

/*
 * Same as the above function, only the scope now is for a single erp.
 */
static sx_status_t __update_prune_of_erp_rules(const boolean_t              is_deletion,
                                               const sx_atcam_erp_id_t      erp_id,
                                               const atcam_rules_db_rule_t *rule);

/**
 * Helper function used to update HW for ctcam handle.
 */
static void __update_prune_to_ctcam(const boolean_t              main_flow,
                                    const boolean_t              is_deletion,
                                    const atcam_rules_db_rule_t *ctcam_rule,
                                    atcam_rules_db_rule_t       *erp_rule);
static sx_status_t __update_prune_of_erp_rules_changed_priority(const sx_atcam_erp_id_t           erp_id,
                                                                const atcam_rules_db_rule_t      *rule,
                                                                const sx_flex_acl_rule_priority_t old_priority);


/**
 * Helper function used to update HW for ctcam handle when priority is changed.
 */
static void __update_prune_to_ctcam_changed_priority(const atcam_rules_db_rule_t      *ctcam_rule,
                                                     atcam_rules_db_rule_t            *erp_rule,
                                                     const sx_flex_acl_rule_priority_t old_priority);


/********************************* New erp updates *********************************/

/**
 * Updates the DB used in order to calculate future prune vectors, for this newly created erp.
 */
static sx_status_t __atcam_erp_add_current_erp_update_db(const sx_atcam_region_id_t region_id,
                                                         const sx_atcam_erp_id_t    new_erp_id);

/**
 * Updates the DB used in order to calculate future prune vectors, for other erp that already existed in
 * this region.
 * Note that DB-wise, the erp should have been allocated prior to the calling of this function. What updated
 * here are purely prune-DB entries.
 */
static sx_status_t __atcam_erp_add_other_erp_update_db(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    new_erp_id,
                                                       const sx_atcam_erp_id_t    other_erp_id);

/**
 * Helper function called from the 2 functions above - distinguishing the 'added_erp_context', that is,
 *  the erp that has been created, or previously existing erps.
 */
static sx_status_t __atcam_erp_add_update_db(const sx_atcam_region_id_t region_id,
                                             const sx_atcam_erp_id_t    erp_id,
                                             atcam_erps_db_prune_db_t  *prune_map,
                                             const boolean_t            added_erp_context);


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t atcam_erps_prune_calc_atcam_insertion(atcam_rules_db_rule_t *rule)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};
    uint8_t           num_of_erps = 0;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRPs of region %d\n", rule->region_id);
        goto out;
    }

    if (num_of_erps) {
        /*
         * Iterate over all valid erps - the id of the rule gets a different treatment.
         * also note that there's currently no distinction between before and after prune calculations.
         */
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erps_ids[i] == ATCAM_INVALID_ERP_ID) {
                continue;
            }

            if (erps_ids[i] == rule->erp_id) {
                /***********************/
                /*       A'->A*        */
                /***********************/
                /* Prune current calculation (main eRP) - i.e. - this rule (MUST WAIT) */
                sx_status = __atcam_insertion_current_rule_erps_calc(rule, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to calculate prune vector of rule 0x%" PRIx64 ", offset %d, for region %d\n",
                               rule->rule_id,
                               rule->offset,
                               rule->region_id);
                    goto out;
                }

                /***********************/
                /*       A'->C*        */
                /***********************/
                /* Calculate prune ctcam bit. A* -> C - This should be done in a separate thread */
                /* This is done ONLY if eRP is used */
                sx_status = __atcam_insertion_current_rule_erp_to_ctcam_calc(rule);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed  to calculate prune ctcam bit of rule 0x%" PRIx64 ", offset %d, of region %d\n",
                               rule->rule_id,
                               rule->offset,
                               rule->region_id);
                    goto out;
                }
            } else {
                /***********************/
                /*       A*->A'        */
                /***********************/
                sx_status = __atcam_insertion_other_rules_erp_to_erp_calc(erps_ids[i], rule, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to calculate prune vector of other rules when handling rule 0x%" PRIx64 ", offset %d, for region %d\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id);
                    goto out;
                }
            }
        }

        /*
         * We should update this here for 2 reasons:
         *  1. Only now we know the prune vector of the newly inserted rule.
         *  2. RP flow might hide here, in which case we should not update the DB. This will take care of that.
         */
        sx_status = atcam_erps_opts_erp_update_score(rule->region_id, rule->erp_id, rule->prune_vector, TRUE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update prune score of erp %d in region %d, when inserting rule %d.\n",
                       rule->erp_id,
                       rule->region_id,
                       rule->offset);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_atcam_deletion(atcam_rules_db_rule_t *rule)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0, num_of_erps = 0;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRPs of region %d\n", rule->region_id);
        goto out;
    }

    if (num_of_erps) {
        /*
         * See note @atcam_erps_prune_calc_atcam_insertion
         */
        sx_status = atcam_erps_opts_erp_update_score(rule->region_id, rule->erp_id, rule->prune_vector, FALSE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update prune score of erp %d in region %d, when inserting rule %d.\n",
                       rule->erp_id,
                       rule->region_id,
                       rule->offset);
            goto out;
        }


        /*
         * Iterate over all valid erps - the id of the rule gets a different treatment.
         * also note that there's currently no distinction between before and after prune calculations.
         */
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erps_ids[i] == ATCAM_INVALID_ERP_ID) {
                continue;
            }

            if (erps_ids[i] == rule->erp_id) {
                /***********************/
                /*       A'->A*         */
                /***********************/
                /* Prune current calculation (main eRP) - i.e. - this rule (MUST WAIT) */
                sx_status = __atcam_deletion_current_rule_erps_calc(rule);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to calculate prune vector of rule 0x%" PRIx64 ", offset %d, for region %d\n",
                               rule->rule_id,
                               rule->offset,
                               rule->region_id);
                    goto out;
                }

                /***********************/
                /*       A'->C*        */
                /***********************/
                /* Nothing to do in this case */
            } else {
                /***********************/
                /*       A*->A'        */
                /***********************/
                sx_status = __atcam_deletion_other_rules_erp_to_erp_calc(erps_ids[i], rule, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to calculate prune vector of other rules when deleting rule 0x%" PRIx64 ", offset %d, from region %d\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id);
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_ctcam_insertion(const atcam_rules_db_rule_t *rule)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    sx_status = __atcam_erps_prune_calc_ctcam_update(rule, FALSE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update prune to ctcam when inserting rule 0x%" PRIx64 ", offset %d, to region %d\n",
                   rule->rule_id,
                   rule->offset,
                   rule->region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_ctcam_deletion(const atcam_rules_db_rule_t *rule)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    sx_status = __atcam_erps_prune_calc_ctcam_update(rule, TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update prune to ctcam when deleting rule 0x%" PRIx64 ", offset %d, from region %d\n",
                   rule->rule_id,
                   rule->offset,
                   rule->region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_new_erp(const sx_atcam_region_id_t        region_id,
                                          const sx_atcam_erp_id_t           new_erp_id,
                                          const atcam_erps_db_erp_params_t *erp_params)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     i = 0;

    SX_LOG_ENTER();

    /* ON GM flow nothing will happen - which is ok */
    for (; i < erp_params->region_erps_num; ++i) {
        /*******************/
        /*    Main flow    */
        /*******************/
        if (new_erp_id == erp_params->region_erps[i]) {
            sx_status = __atcam_erp_add_current_erp_update_db(region_id, new_erp_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update prune db of current erp %d added to region %d\n", new_erp_id, region_id);
                goto out;
            }
        }
        /*******************/
        /* Secondary flow  */
        /*******************/
        else {
            sx_status = __atcam_erp_add_other_erp_update_db(region_id, new_erp_id, erp_params->region_erps[i]);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update prune db of other erp %d when adding erp %d to region %d\n",
                           erp_params->region_erps[i],
                           new_erp_id,
                           region_id);
                goto out;
            }
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_atcam_priority_update(atcam_rules_db_rule_t            *rule,
                                                        const sx_flex_acl_rule_priority_t old_priority)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0, num_of_erps = 0;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};
    boolean_t         is_priority_raised = (old_priority < rule->priority);

    rule->prune_vector = 0xFFFF; /* This is important - our algorithm can only tell if we don't have to prune - so to successfully capture every priority edit possibility, this is necessary */
    rule->prune_ctcam_cnt = 0; /* This will be recalculated */

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRPs of region %d\n", rule->region_id);
        goto out;
    }

    if (num_of_erps) {
        /*
         * Iterate over all valid erps - the id of the rule gets a different treatment.
         * also note that there's currently no distinction between before and after prune calculations.
         */
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erps_ids[i] == ATCAM_INVALID_ERP_ID) {
                continue;
            }

            if (erps_ids[i] == rule->erp_id) {
                /***********************/
                /*       A'->A*        */
                /***********************/
                /* Prune current calculation (main eRP) - i.e. - this rule (MUST WAIT) */
                sx_status = __atcam_insertion_current_rule_erps_calc(rule, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to calculate prune vector of rule 0x%" PRIx64 " for region %d\n",
                               rule->rule_id,
                               rule->region_id);
                    goto out;
                }

                /***********************/
                /*       A'->C*        */
                /***********************/
                /* Calculate prune ctcam bit. A* -> C - This should be done in a separate thread */
                /* This is done ONLY if eRP is used */
                sx_status = __atcam_insertion_current_rule_erp_to_ctcam_calc(rule);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed  to calculate prune ctcam bit of rule 0x%" PRIx64 " of region %d\n",
                               rule->rule_id,
                               rule->region_id);
                    goto out;
                }
            } else {
                /***********************/
                /*       A*->A'         */
                /***********************/

                /* If priority is raised for the given rule, it's actually like new rule insertion, apart from DB insertions */
                if (is_priority_raised) {
                    sx_status = __atcam_insertion_other_rules_erp_to_erp_calc(erps_ids[i], rule, TRUE);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Failed to calculate prune vector of other rules when handling rule 0x%" PRIx64 " for region %d\n",
                            rule->rule_id,
                            rule->region_id);
                        goto out;
                    }
                }
                /* Otherwise- it is like deletion */
                else {
                    sx_status = __atcam_deletion_other_rules_erp_to_erp_calc(erps_ids[i], rule, TRUE);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Failed to calculate prune vector of other rules when deleting rule 0x%" PRIx64 " from region %d\n",
                            rule->rule_id,
                            rule->region_id);
                        goto out;
                    }
                }
            }
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_prune_calc_ctcam_priority_update(const atcam_rules_db_rule_t      *rule,
                                                        const sx_flex_acl_rule_priority_t old_priority)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0, num_of_erps = 0;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRPs of region %d\n", rule->region_id);
        goto out;
    }

    if (num_of_erps) {
        /* ctcam update prune calculations - iterate over all rules in eRP(i), for all valid rules */
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erps_ids[i] != ATCAM_INVALID_ERP_ID) {
                sx_status = __update_prune_of_erp_rules_changed_priority(erps_ids[i], rule, old_priority);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to update prune between erp %d to ctcam, when inserting rule 0x%" PRIx64 " to region %d\n",
                        erps_ids[i],
                        rule->rule_id,
                        rule->region_id);
                    goto out;
                }
            }
        }
    }

    /* Note that it is possible that the Exact-match 'erp' hides here -
     * but we expect this flow not to happen regularly, and anyway, we don't support
     * prune in this case */

out:
    return sx_status;
}


/************************************************
 *  Local Function implementations
 ***********************************************/

static uint64_t __create_priority_rule_key(const uint64_t priority)
{
    /* This function is used to create a unique key from the priority of rules.
     * Since multiple rules can have the same priority we add a sequence number to make it unique.
     */
    static uint64_t unique_value = 0;
    uint64_t        return_key = priority << UNIQUE_PRIORITY_SHIFT;

    return_key |= unique_value & UNIQUE_VALUE_MASK;
    unique_value++;

    return return_key;
}


static sx_status_t __atcam_insertion_current_rule_erps_calc(atcam_rules_db_rule_t *rule, const boolean_t edit_flow)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *rule_erp = NULL;
    uint8_t              j;

    sx_status = atcam_erps_db_erp_get(rule->region_id, rule->erp_id, &rule_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d, when updating rule 0x%" PRIx64 ", offset %d\n",
                   rule->erp_id,
                   rule->region_id,
                   rule->rule_id,
                   rule->offset);
        goto out;
    }

    for (j = 0; j < SX_ATCAM_ERPS_PER_REGION; ++j) {
        /* Iterate only on valid tables in the form of eRP_i_j */
        /* Notice we iterate on prune_maps, not erp - thus erp_i_i won't be allocated. This is not a mistake */
        if (!rule_erp->prune_maps[j].allocated) {
            continue;
        }

        /* Calculate prune vector bit. A* -> A_j - This should be done in a separate thread */
        sx_status =
            __atcam_insertion_current_rule_erp_to_erp_calc(&(rule_erp->prune_maps[j]), rule,
                                                           edit_flow);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to calculate the %d-th bit of prune vector for rule 0x%" PRIx64 ", offset %d, of region %d\n",
                j,
                rule->rule_id,
                rule->offset,
                rule->region_id);
            goto out;
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_insertion_current_rule_erp_to_erp_calc(atcam_erps_db_prune_db_t *prune_map,
                                                                  atcam_rules_db_rule_t    *rule,
                                                                  const boolean_t           edit_flow)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_value_t            intersected_value;
    const cl_fmap_item_t           *rules_refs = NULL, *end = NULL;
    atcam_erps_db_prune_db_entry_t *prune_db_entry = NULL;
    atcam_rules_db_rule_t          *other_rule = NULL;
    atcam_rules_db_rule_entry_t    *rule_entry, *other_rule_entry = NULL;
    const cl_map_item_t            *other_rules_it = NULL, *other_rules_end = NULL;

    SX_LOG_ENTER();
    SX_MEM_CLR(intersected_value);

    sx_status = atcam_utils_intersect_val_n_mask((const sx_atcam_key_value_t*)&rule->key_value_blocks,
                                                 &prune_map->mask,
                                                 &intersected_value);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to intersect value of rule 0x%" PRIx64 " with intersection map (%d, %d)\n",
                   rule->rule_id,
                   prune_map->main_id,
                   prune_map->sec_id);
        goto out;
    }

    rules_refs = cl_fmap_get(&prune_map->rules_refs, (void*)&intersected_value);
    end = cl_fmap_end(&prune_map->rules_refs);

    /* Entry does not exist, first rule of that kind */
    if (rules_refs == end) {
        /* Sanity check - this shouldn't happen */
        if (edit_flow) {
            SX_LOG_ERR(
                "Prune db is inconsistent. When updating priority of rule 0x%" PRIx64 " that was inserted to region %d - entry wasn't found before\n",
                rule->rule_id,
                rule->region_id);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
        sx_status = atcam_erps_db_prune_entry_allocate(prune_map, &intersected_value, &prune_db_entry);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to allocate new prune db entry for erps (m: %d, s: %d), for region %d\n",
                       prune_map->main_id,
                       prune_map->sec_id,
                       rule->region_id);
            goto out;
        }
        /* If this is a newly created entry - then there are no 'other-rules' to iterate */
    }
    /* Iterate data normally */
    else {
        prune_db_entry = PARENT_STRUCT(rules_refs, atcam_erps_db_prune_db_entry_t, fmap_item);

        /*
         * Check if the highest priority rule in the other erp is higher
         * than the inserted rule. If so we need to zero the prune bit for the
         * currently inserted rule.
         */
        other_rules_it = cl_qmap_tail(&prune_db_entry->other_erp_rules);
        other_rules_end = cl_qmap_end(&prune_db_entry->other_erp_rules);
        if (other_rules_it != other_rules_end) {
            other_rule_entry =
                PARENT_STRUCT(other_rules_it, atcam_rules_db_rule_entry_t, per_prune_other_li[prune_map->main_id]);
            other_rule = &(other_rule_entry->data);

            /* Only if other rule has HIGHER priority we set this rule's prune bit to zero. */
            if (other_rule->priority > rule->priority) {
                /* no need to atomize this update, even in case of multi-threaded infra */
                rule->prune_vector &= ~(1 << prune_map->sec_id);
                /* Indicate that for this rule does not do pruning for the relevant erp */
            }
        }
    }

    /*
     * Add a reference to 'Rule' in this prune map, so when rule to erp[sec_id] will be entered,
     * we can apply the above to change the current rule (i.e. 'Rule') prune vector.
     * Note that if we got here - prune_db_entry is either set correctly, or just created - both are fine.
     */
    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    /* When editing a rule, the rule might change its priority, so we delete it and add it again in the correct location */
    if (edit_flow) {
        cl_qmap_remove_item(&prune_db_entry->current_erp_rules, &rule_entry->per_prune_curr_li[prune_map->sec_id]);
    }
    /* Add the rule to the current list of rules */
    cl_qmap_insert(&prune_db_entry->current_erp_rules, __create_priority_rule_key(rule_entry->data.priority),
                   &rule_entry->per_prune_curr_li[prune_map->sec_id]);
out:
    return sx_status;
}


static sx_status_t __atcam_insertion_current_rule_erp_to_ctcam_calc(atcam_rules_db_rule_t *rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_t       *ctcam = NULL;
    const cl_map_item_t         *it = NULL, *end = NULL;
    atcam_rules_db_rule_entry_t *ctcam_rule_entry = NULL;

    /* If no ctcam was allocated before */
    sx_status = atcam_erps_db_ctcam_get(rule->region_id, &ctcam);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        /* Nothing to do */
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    } else if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__update_current_a_to_c_prune: failed to get ctcam obj for region %d\n", rule->region_id);
        goto out;
    }

    /* Iterate over all ctcam rules for this region - at next stage we could optimize using priorities
     * Preferably, using ctcam-prio db for this job */
    it = cl_qmap_head(&(ctcam->rules));
    end = cl_qmap_end(&(ctcam->rules));
    while (it != end) {
        ctcam_rule_entry = PARENT_STRUCT(it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        __update_prune_to_ctcam(TRUE, FALSE, &ctcam_rule_entry->data, rule);

        it = cl_qmap_next(it);
    }

out:
    return sx_status;
}


static sx_status_t __atcam_insertion_other_rules_erp_to_erp_calc(sx_atcam_erp_id_t      other_erp_id,
                                                                 atcam_rules_db_rule_t *rule,
                                                                 boolean_t              edit_flow)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    uint32_t                        key_blocks_cnt = 0;
    sx_atcam_key_blocks_size_t      key_blocks_size;
    sx_atcam_key_value_t            intersected_value;
    const cl_fmap_item_t           *rules_refs = NULL, *end = NULL;
    atcam_erps_db_prune_db_entry_t *other_prune_db_entry = NULL;
    atcam_erps_db_erp_t            *other_erp = NULL;
    atcam_erps_db_prune_db_t       *other_prune_map = NULL;
    const cl_map_item_t            *other_rules_it = NULL, *other_rules_end = NULL;
    const cl_map_item_t            *current_rules_it = NULL, *current_rules_end = NULL;
    atcam_rules_db_rule_t          *other_rule = NULL;
    uint16_t                        other_rule_pv_tmp = 0;
    atcam_rules_db_rule_entry_t    *rule_entry = NULL, *other_rule_entry = NULL, *current_rule_entry = NULL;
    sx_atcam_large_entry_key_id_t   large_key_id = LARGE_KEY_HANDLE_INVALID;
    sx_flex_acl_rule_priority_t     max_current_rule_priority = 0;


    SX_LOG_ENTER();
    SX_MEM_CLR(intersected_value);

    sx_status = atcam_erps_db_erp_get(rule->region_id, other_erp_id, &other_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d, when updating rule 0x%" PRIx64 "\n",
                   rule->erp_id,
                   rule->region_id,
                   rule->rule_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_cnt_get(rule->region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks count for region %d\n", rule->region_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_size_get(rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks size for region %d\n", rule->region_id);
        goto out;
    }

    other_prune_map = &(other_erp->prune_maps[rule->erp_id]);
    sx_status = atcam_utils_intersect_val_n_mask(
        (const sx_atcam_key_value_t*)&rule->key_value_blocks.flex_value_blocks,
        &other_prune_map->mask,
        &intersected_value);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to intersect value of rule 0x%" PRIx64 " with intersection map (m:%d, s:%d)\n",
                   rule->rule_id,
                   other_prune_map->main_id,
                   other_prune_map->sec_id);
        goto out;
    }

    rules_refs = cl_fmap_get(&other_prune_map->rules_refs, (void*)&intersected_value);
    end = cl_fmap_end(&other_prune_map->rules_refs);

    /* Entry does not exist, first rule of that kind */
    if (rules_refs == end) {
        /* Sanity check - the entry must exist if we're editing */
        if (edit_flow) {
            SX_LOG_ERR(
                "Prune db is inconsistent: Entry should have been created when rule 0x%" PRIx64 " was inserted into region %d\n",
                rule->rule_id,
                rule->region_id);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
        sx_status = atcam_erps_db_prune_entry_allocate(other_prune_map, &intersected_value, &other_prune_db_entry);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to allocate new prune db entry for erps (m: %d, s: %d), for region %d\n",
                       other_prune_map->main_id,
                       other_prune_map->sec_id,
                       rule->region_id);
            goto out;
        }
    } else {
        /*
         * Iterate over all almost compatible rules to 'rule' in erp[sec_id], and update ALL those with
         * higher priority to 'Rule'
         */
        other_prune_db_entry = PARENT_STRUCT(rules_refs, atcam_erps_db_prune_db_entry_t, fmap_item);

        /* Get the maximum priority of the rules in the erp the current rule is inserted to */
        current_rules_it = cl_qmap_tail(&other_prune_db_entry->other_erp_rules);
        current_rules_end = cl_qmap_end(&other_prune_db_entry->other_erp_rules);
        if (current_rules_it != current_rules_end) {
            current_rule_entry =
                PARENT_STRUCT(current_rules_it, atcam_rules_db_rule_entry_t,
                              per_prune_other_li[other_prune_map->main_id]);
            max_current_rule_priority = current_rule_entry->data.priority;
        }

        other_rules_end = cl_qmap_end(&other_prune_db_entry->current_erp_rules);

        /* If the current maximum priority is higher than the inserted/updated
         * rule there is no change in the prune needed in other rules.
         * Equal comparison is not good for edit flow.
         */
        if (max_current_rule_priority > rule->priority) {
            /* NOTE: In this case we do not iterate at all! */
            other_rules_it = other_rules_end;
        } else {
            /* We need to update only rules that have smaller priorities than the inserted/updated rule.
             * We will start the iteration with the rule that has the closest priority to the rule inserted
             * and go through the lower priorities.
             */
            other_rules_it = cl_qmap_get_next(&other_prune_db_entry->current_erp_rules,
                                              __create_priority_rule_key(rule->priority - 1));
            /* If all rules have a lower priority we need to go over all of them */
            if (other_rules_it == other_rules_end) {
                other_rules_it = cl_qmap_tail(&other_prune_db_entry->current_erp_rules);
            }
        }

        /*
         * Don't get confused - these are the rules of eRP j when rule was inserted to i, but
         * within this context, it's erp j rules, thus 'current rules' - this is what we iterate here.
         * This is NOT a mistake.
         * We iterate from the highest rule with priority below/equal to the inserted rule.
         */
        while (other_rules_it != other_rules_end) {
            /*
             * Again - with respect to prune db - this is a 'current' rule, but we got here from
             * insertion of 'rule' - thus this rule is other.
             */
            other_rule_entry =
                PARENT_STRUCT(other_rules_it, atcam_rules_db_rule_entry_t, per_prune_curr_li[other_prune_map->sec_id]);
            other_rule = &(other_rule_entry->data);
            /* Check if the rule is already non-pruning. If so we can stop the loop since we know for certain
             * the following rules are also non-pruning.
             */
            if ((other_rule->prune_vector & (1 << other_prune_map->sec_id)) == 0) {
                break;
            }

            /* Only if other rule has LOWER priority, we need to update its prune vector */
            if (other_rule->priority < rule->priority) {
                other_rule_pv_tmp = other_rule->prune_vector;
                /* no need to atomize this update, even in case of multi-threaded infra */
                other_rule->prune_vector &= ~(1 << other_prune_map->sec_id);

                /*
                 * Now we need to update all those rules, so we don't break.
                 * We also update HW directly from here
                 */
                if (other_rule_pv_tmp != other_rule->prune_vector) {
                    large_key_id = LARGE_KEY_HANDLE_INVALID;
                    if (other_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                        sx_status = atcam_large_key_id_get(other_rule->large_key_handle,
                                                           &large_key_id,
                                                           NULL);
                        if (sx_status != SX_STATUS_SUCCESS) {
                            SX_LOG(SX_LOG_ERROR,
                                   "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                                   other_rule->rule_id);
                            goto out;
                        }
                    }
                    /* Do this only if the bit was actually changed from before */
                    sx_status = atcam_sxd_wrapper_set_rule_to_hw(other_rule,
                                                                 DEFAULT_DEV_ID,
                                                                 (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                                 TRUE,
                                                                 large_key_id,
                                                                 key_blocks_size);

                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Unable to update rule 0x%" PRIx64 " prune vector for region %d\n",
                                   rule->rule_id,
                                   rule->region_id);
                        goto out;
                    }

                    /* No need to use locks here, since we have a different value for each erp (in different context
                     * Also note - when adding a rule, we stop prune - thus decrease(!) the score.
                     */
                    sx_status = atcam_erps_opts_erp_update_score(other_rule->region_id,
                                                                 other_rule->erp_id,
                                                                 1,
                                                                 FALSE);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Unable to update prune score of erp %d when updating prune vector of rule 0x%" PRIx64 " in region %d\n",
                            other_rule->erp_id,
                            other_rule->rule_id,
                            other_rule->region_id);
                        goto out;
                    }
                }
            }
            other_rules_it = cl_qmap_prev(other_rules_it);
        }
    }

    /*
     * Add a reference to 'Rule' in prune map, so when rule to erp[sec_id] will be entered,
     * we can apply the above to change the Other rule prune vector.
     */
    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    if (edit_flow) {
        /* Remove from list in order to update priority */
        cl_qmap_remove_item(&other_prune_db_entry->other_erp_rules,
                            &rule_entry->per_prune_other_li[other_prune_map->main_id]);
    }
    cl_qmap_insert(&other_prune_db_entry->other_erp_rules, __create_priority_rule_key(rule_entry->data.priority),
                   &rule_entry->per_prune_other_li[other_prune_map->main_id]);

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __atcam_deletion_current_rule_erps_calc(atcam_rules_db_rule_t *rule)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *rule_erp = NULL;
    uint8_t              j;

    sx_status = atcam_erps_db_erp_get(rule->region_id, rule->erp_id, &rule_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d, when updating rule 0x%" PRIx64 ", offset %d\n",
                   rule->erp_id,
                   rule->region_id,
                   rule->rule_id,
                   rule->offset);
        goto out;
    }

    for (j = 0; j < SX_ATCAM_ERPS_PER_REGION; ++j) {
        /* Iterate only on valid tables in the form of eRP_i_j */
        /* Notice we iterate on prune_maps, not erp - thus erp_i_i won't be allocated. This is not a mistake */
        if (!rule_erp->prune_maps[j].allocated) {
            continue;
        }

        sx_status = __atcam_deletion_current_rule_erp_to_erp_calc(&(rule_erp->prune_maps[j]), rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to calculate the %d-th bit of prune vector for rule 0x%" PRIx64 ", offset %d, of region %d\n",
                j,
                rule->rule_id,
                rule->offset,
                rule->region_id);
            goto out;
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_deletion_current_rule_erp_to_erp_calc(atcam_erps_db_prune_db_t *prune_map,
                                                                 atcam_rules_db_rule_t    *rule)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_value_t            intersected_value;
    const cl_fmap_item_t           *rules_refs = NULL, *end = NULL;
    atcam_erps_db_prune_db_entry_t *prune_db_entry = NULL;
    atcam_rules_db_rule_entry_t    *rule_entry;

    SX_LOG_ENTER();
    SX_MEM_CLR(intersected_value);

    sx_status = atcam_utils_intersect_val_n_mask((const sx_atcam_key_value_t*)&rule->key_value_blocks,
                                                 &prune_map->mask,
                                                 &intersected_value);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to intersect value of rule 0x%" PRIx64 " with intersection map (%d, %d)\n",
                   rule->rule_id,
                   prune_map->main_id,
                   prune_map->sec_id);
        goto out;
    }

    rules_refs = cl_fmap_get(&prune_map->rules_refs, (void*)&intersected_value);
    end = cl_fmap_end(&prune_map->rules_refs);

    /* Entry does not exist, this shouldn't happen */
    if (rules_refs == end) {
        SX_LOG_ERR(
            "Prune calculation is inconsistent - rule 0x%" PRIx64 " was added to region %d, but when deleted later prune db isn't right.\n",
            rule->rule_id,
            rule->region_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /*
     * Remove the reference to 'Rule' in this prune map.
     */
    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    prune_db_entry = PARENT_STRUCT(rules_refs, atcam_erps_db_prune_db_entry_t, fmap_item);
    cl_qmap_remove_item(&prune_db_entry->current_erp_rules, &rule_entry->per_prune_curr_li[prune_map->sec_id]);

    if (cl_is_qmap_empty(&prune_db_entry->current_erp_rules) &&
        cl_is_qmap_empty(&prune_db_entry->other_erp_rules)) {
        sx_status = atcam_erps_db_prune_entry_deallocate(prune_map, prune_db_entry);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove prune entry of prune map (m:%d, s:%d)"
                       " when deleting rule 0x%" PRIx64 " from region %d\n",
                       prune_map->main_id,
                       prune_map->sec_id,
                       rule->rule_id,
                       rule->region_id);
            goto out;
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_deletion_other_rules_erp_to_erp_calc(const sx_atcam_erp_id_t other_erp_id,
                                                                atcam_rules_db_rule_t  *rule,
                                                                const boolean_t         edit_flow)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    uint32_t                        key_blocks_cnt;
    sx_atcam_key_blocks_size_t      key_blocks_size;
    sx_atcam_key_value_t            intersected_value;
    atcam_erps_db_prune_db_entry_t *other_prune_db_entry = NULL;
    atcam_erps_db_erp_t            *other_erp = NULL;
    atcam_erps_db_prune_db_t       *other_prune_map = NULL;
    const cl_fmap_item_t           *rules_refs = NULL, *end = NULL;
    const cl_map_item_t            *other_rules_it = NULL, *other_rules_end = NULL;
    const cl_map_item_t            *current_erp_rules_it = NULL, *current_erp_rules_end = NULL;
    atcam_rules_db_rule_t          *other_rule = NULL, *max_priority_rule = NULL;
    atcam_rules_db_rule_entry_t    *rule_entry = NULL, *other_rule_entry = NULL, *current_erp_rule_entry = NULL;
    boolean_t                       resume_prune = FALSE;
    sx_atcam_large_entry_key_id_t   large_key_id = LARGE_KEY_HANDLE_INVALID;

    SX_LOG_ENTER();
    SX_MEM_CLR(intersected_value);

    sx_status = atcam_erps_db_erp_get(rule->region_id, other_erp_id, &other_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d, when updating rule 0x%" PRIx64 "\n",
                   rule->erp_id,
                   rule->region_id,
                   rule->rule_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_cnt_get(rule->region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks count for region %d\n", rule->region_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_size_get(rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks size for region %d\n", rule->region_id);
        goto out;
    }

    other_prune_map = &(other_erp->prune_maps[rule->erp_id]);
    sx_status = atcam_utils_intersect_val_n_mask(
        (const sx_atcam_key_value_t*)&rule->key_value_blocks.flex_value_blocks,
        &other_prune_map->mask,
        &intersected_value);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to intersect value of rule 0x%" PRIx64 " with intersection map (m:%d, s:%d)\n",
                   rule->rule_id,
                   other_prune_map->main_id,
                   other_prune_map->sec_id);
        goto out;
    }

    rules_refs = cl_fmap_get(&other_prune_map->rules_refs, (void*)&intersected_value);
    end = cl_fmap_end(&other_prune_map->rules_refs);

    if (rules_refs == end) {
        /* No way this entry does not exist if we are in delete mode or edit mode */
        SX_LOG_ERR(
            "Prune calculation is inconsistent - rule 0x%" PRIx64 " was added to region %d, but when deleted later prune db isn't right.\n",
            rule->rule_id,
            rule->region_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* Remove the reference from other rules - only while deleting */
    other_prune_db_entry = PARENT_STRUCT(rules_refs, atcam_erps_db_prune_db_entry_t, fmap_item);

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    cl_qmap_remove_item(&other_prune_db_entry->other_erp_rules,
                        &rule_entry->per_prune_other_li[other_prune_map->main_id]);
    /* For edit flow insert the rule again with the new updated priority. */
    if (edit_flow) {
        cl_qmap_insert(&other_prune_db_entry->other_erp_rules, __create_priority_rule_key(rule_entry->data.priority),
                       &rule_entry->per_prune_other_li[other_prune_map->main_id]);
    }

    /* Get the highest priority rule remaining in the erp from the which the rule was removed.
     * This priority will be compared to the rules in the other erp.
     */
    current_erp_rules_it = cl_qmap_tail(&other_prune_db_entry->other_erp_rules);
    current_erp_rules_end = cl_qmap_end(&other_prune_db_entry->other_erp_rules);
    if (current_erp_rules_it != current_erp_rules_end) {
        current_erp_rule_entry =
            PARENT_STRUCT(current_erp_rules_it, atcam_rules_db_rule_entry_t,
                          per_prune_other_li[other_prune_map->main_id]);
        max_priority_rule = &(current_erp_rule_entry->data);
    }

    /*
     * Don't get confused - these are the rules of eRP j when rule was deleted from i, but
     * within this context, it's erp j rules, thus 'current rules' - this is what we iterate here.
     * This is NOT a mistake.
     * NOTE: We assume that the current_erp_rules are sorted by priority. Therefore we search from the lowest
     * priority rules and check if they are now higher/equal to the rules to now remaining in the other erps
     */
    other_rules_end = cl_qmap_end(&other_prune_db_entry->current_erp_rules);
    /* If the maximum remaining rule is higher than the removed rule there is actually
     * no change in the pruning hierarchy so we don't need to update any prunes.
     */
    if (!edit_flow && max_priority_rule && (max_priority_rule->priority >= rule->priority)) {
        /* There is no need to execute the loop. */
        other_rules_it = other_rules_end;
    } else {
        if (max_priority_rule) {
            /* We'll need to start checking for prune update only from rules that are equal/higher
             * from the current max priority.
             */
            other_rules_it = cl_qmap_get_next(&other_prune_db_entry->current_erp_rules,
                                              __create_priority_rule_key(max_priority_rule->priority - 1));
        } else {
            /* We're need to iterate all the rules from the lowest priority */
            other_rules_it = cl_qmap_head(&other_prune_db_entry->current_erp_rules);
        }
    }

    while (other_rules_it != other_rules_end) {
        /*
         * Again - with respect to prune db - this is a 'current' rule, but we got here from
         * insertion of 'rule' - thus this rule is other.
         */
        other_rule_entry =
            PARENT_STRUCT(other_rules_it, atcam_rules_db_rule_entry_t, per_prune_curr_li[other_prune_map->sec_id]);
        other_rule = &(other_rule_entry->data);
        /* Check if the rule is already pruning. If so we can stop the loop since we know for certain
         * the following rules are also pruning since the list is sorted by the pruning bit.
         */
        if (other_rule->prune_vector & (1 << other_prune_map->sec_id)) {
            break;
        }
        /* If the rule that was deleted had a lower priority than the other rule, it's impossible
         * that the 'other' rule will become pruning due to the delete. Not relevant for edit flow.
         */
        if (!edit_flow && (other_rule->priority > rule->priority)) {
            break;
        }
        resume_prune = TRUE;
        /* Compare with the highest priority rule remaining in the erp from which the rules was removed. */
        if (max_priority_rule && (other_rule->priority < max_priority_rule->priority)) {
            resume_prune = FALSE;
        }

        if (resume_prune) {
            /* no need to atomize this update, even in case of multi-threaded infra */
            other_rule->prune_vector |= (1 << other_prune_map->sec_id);

            large_key_id = LARGE_KEY_HANDLE_INVALID;
            if (other_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                sx_status = atcam_large_key_id_get(other_rule->large_key_handle,
                                                   &large_key_id,
                                                   NULL);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                           other_rule->rule_id);
                    goto out;
                }
            }
            sx_status = atcam_sxd_wrapper_set_rule_to_hw(other_rule,
                                                         DEFAULT_DEV_ID,
                                                         (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                         TRUE,
                                                         large_key_id,
                                                         key_blocks_size);

            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to change HW bit for for erp %d prune of rule 0x%" PRIx64 " for region %d\n",
                           other_prune_map->sec_id,
                           other_rule->rule_id,
                           other_rule->region_id);
                goto out;
            }

            /*
             * No need to use locks here, since we have a different value for each erp (in different context
             * Also note - when deleting a rule, we can reapply prune - thus increase(!) the score.
             */
            sx_status = atcam_erps_opts_erp_update_score(other_rule->region_id, other_rule->erp_id, 1, TRUE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Unable to update prune score of erp %d when updating prune vector of rule 0x%" PRIx64 " in region %d\n",
                    other_rule->erp_id,
                    other_rule->rule_id,
                    other_rule->region_id);
                goto out;
            }
        }
        other_rules_it = cl_qmap_next(other_rules_it);
    }

    if (cl_is_qmap_empty(&other_prune_db_entry->current_erp_rules) &&
        cl_is_qmap_empty(&other_prune_db_entry->other_erp_rules)) {
        sx_status = atcam_erps_db_prune_entry_deallocate(other_prune_map, other_prune_db_entry);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove prune entry of prune map (m:%d, s:%d)"
                       "when deleting rule 0x%" PRIx64 " from region %d\n",
                       other_prune_map->main_id,
                       other_prune_map->sec_id,
                       rule->rule_id,
                       rule->region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __atcam_erps_prune_calc_ctcam_update(const atcam_rules_db_rule_t *rule, const boolean_t is_deletion)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0, num_of_erps = 0;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRPs of region %d\n", rule->region_id);
        goto out;
    }

    if (num_of_erps) {
        /* ctcam update prune calculations - iterate over all rules in eRP(i), for all valid rules */
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erps_ids[i] != ATCAM_INVALID_ERP_ID) {
                sx_status = __update_prune_of_erp_rules(is_deletion, erps_ids[i], rule);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to update prune between erp %d to ctcam, when inserting rule 0x%" PRIx64 " to region %d\n",
                        erps_ids[i],
                        rule->rule_id,
                        rule->region_id);
                    goto out;
                }
            }
        }
    }

    /* Note that it is possible that the Exact-match 'erp' hides here -
     * but we expect this flow not to happen regularly, and anyway, we don't support
     * prune in this case */

out:
    return sx_status;
}


static sx_status_t __update_prune_of_erp_rules(const boolean_t              is_deletion,
                                               const sx_atcam_erp_id_t      erp_id,
                                               const atcam_rules_db_rule_t *rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t         *erp = NULL;
    const cl_map_item_t         *it = NULL, *end = NULL;
    atcam_rules_db_rule_entry_t *erp_rule_entry = NULL;

    sx_status = atcam_erps_db_erp_get(rule->region_id, erp_id, &erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRP %d for region %d\n", erp_id, rule->region_id);
        goto out;
    }

    it = cl_qmap_head(&(erp->rules));
    end = cl_qmap_end(&erp->rules);
    while (it != end) {
        erp_rule_entry = PARENT_STRUCT(it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        __update_prune_to_ctcam(FALSE, is_deletion, rule, &erp_rule_entry->data);

        it = cl_qmap_next(it);
    }

out:
    return sx_status;
}


static void __update_prune_to_ctcam(const boolean_t              main_flow,
                                    const boolean_t              is_deletion,
                                    const atcam_rules_db_rule_t *ctcam_rule,
                                    atcam_rules_db_rule_t       *erp_rule)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_blocks_size_t    key_blocks_size;
    boolean_t                     are_compatible;
    sx_atcam_large_entry_key_id_t large_key_id = LARGE_KEY_HANDLE_INVALID;

    /* The eRP rule will win anyway, no need to count for prune */
    if (ctcam_rule->priority <= erp_rule->priority) {
        return;
    }

    sx_status = atcam_regions_db_key_blocks_size_get(ctcam_rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error: Failed to get region key blocks size needed for prune calculations\n");
        return;
    }

    sx_status = atcam_utils_are_keys_compatible(&ctcam_rule->key_value_blocks,
                                                &erp_rule->key_value_blocks,
                                                &are_compatible);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__update_prune_ctcam: failed to check if rules 0x%" PRIx64 " and 0x%" PRIx64 " are compatible\n",
                   ctcam_rule->rule_id,
                   erp_rule->rule_id);
        return;
    }

    if (are_compatible) {
        if (is_deletion) {
            /* This shouldn't happen - but we perform this sanity check to make
             * sure system is consistent. Might prove especially useful for async-system
             */
            if (erp_rule->prune_ctcam_cnt == 0) {
                SX_LOG_ERR("When updating prune of rule 0x%" PRIx64 " after deletion of rule 0x%" PRIx64 " at region %d,"
                           "Prune wasn't set in the first place, even though rules are compatible\n",
                           erp_rule->rule_id,
                           ctcam_rule->rule_id,
                           ctcam_rule->region_id);
                return;
            }
            --erp_rule->prune_ctcam_cnt;
            /*
             * We send message to HW only if erp_rule is NOT the current rule being inserted, rather
             * this is a side effect of insertion of another rule (to ctcam)
             */
            if ((erp_rule->prune_ctcam_cnt == 0) && !main_flow) {
                /* If got here - this is an update to atcam(!) rule - which has large key id */
                if (erp_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                    sx_status = atcam_large_key_id_get(erp_rule->large_key_handle,
                                                       &large_key_id,
                                                       NULL);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                               erp_rule->rule_id);
                        return;
                    }
                }

                sx_status = atcam_sxd_wrapper_set_rule_to_hw(erp_rule,
                                                             DEFAULT_DEV_ID,
                                                             (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                             TRUE,
                                                             large_key_id,
                                                             key_blocks_size);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update to HW rule 0x%" PRIx64 " of region %d\n", erp_rule->rule_id,
                               erp_rule->region_id);
                    return;
                }
            }
        } else {
            ++erp_rule->prune_ctcam_cnt;
            if ((erp_rule->prune_ctcam_cnt == 1) && !main_flow) {
                /* If got here - this is an update to atcam(!) rule - which has large key id */
                if (erp_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                    sx_status = atcam_large_key_id_get(erp_rule->large_key_handle,
                                                       &large_key_id,
                                                       NULL);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                               erp_rule->rule_id);
                        return;
                    }
                }

                sx_status = atcam_sxd_wrapper_set_rule_to_hw(erp_rule,
                                                             DEFAULT_DEV_ID,
                                                             (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                             TRUE,
                                                             large_key_id,
                                                             key_blocks_size);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update to HW rule 0x%" PRIx64 " of region %d\n", erp_rule->rule_id,
                               erp_rule->region_id);
                    return;
                }
            }
        }
    }
}


/*
 * DO NOT parallelize
 */
static sx_status_t __atcam_erp_add_current_erp_update_db(const sx_atcam_region_id_t region_id,
                                                         const sx_atcam_erp_id_t    new_erp_id)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t      *current_erp = NULL;
    atcam_erps_db_prune_db_t *current_prune_map = NULL;
    uint8_t                   i = 0;

    sx_status = atcam_erps_db_erp_get(region_id, new_erp_id, &current_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d\n", new_erp_id, region_id);
        goto out;
    }

    /* All these updates (which are quite plenty), MUST stay within the context of the erp-thread */
    for (; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        /* Notice we iterate on prune_maps, not erp - thus erp_i_i won't be allocated. This is not a mistake */
        if (!current_erp->prune_maps[i].allocated) {
            continue;
        }

        current_prune_map = &current_erp->prune_maps[i];

        /* This is quite tricky - Although we're in the context of added erp, we still need to iterate over
         * the rules of the other erp - that is 'current_prune_map->sec_id'.
         */
        sx_status = __atcam_erp_add_update_db(region_id, current_prune_map->sec_id, current_prune_map, TRUE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update prune db of erp (M: %d, S: %d) for region %d\n",
                       current_prune_map->main_id,
                       current_prune_map->sec_id,
                       region_id);
            goto out;
        }
    }

out:
    return sx_status;
}


/*
 * parallelize!
 */
static sx_status_t __atcam_erp_add_other_erp_update_db(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    new_erp_id,
                                                       const sx_atcam_erp_id_t    other_erp_id)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t      *other_erp = NULL;
    atcam_erps_db_prune_db_t *other_prune_map = NULL;

    sx_status = atcam_erps_db_erp_get(region_id, other_erp_id, &other_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d\n", other_erp_id, region_id);
        goto out;
    }

    other_prune_map = &other_erp->prune_maps[new_erp_id];
    /* we need to iterate over
     * the rules of the other erp - that is 'other_prune_map->main_id = other_erp_id'. In this context, 'other' is the erp
     * that already existed before the new erp is created.
     */
    sx_status = __atcam_erp_add_update_db(region_id, other_erp_id, other_prune_map, FALSE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update prune db of erp (M: %d, S: %d) for region %d\n",
                   other_prune_map->main_id,
                   other_prune_map->sec_id,
                   region_id);
        goto out;
    }


out:
    return sx_status;
}


static sx_status_t __atcam_erp_add_update_db(const sx_atcam_region_id_t region_id,
                                             const sx_atcam_erp_id_t    erp_id,
                                             atcam_erps_db_prune_db_t  *prune_map,
                                             const boolean_t            added_erp_context)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t            *erp = NULL;
    uint32_t                        key_blocks_cnt = 0;
    const cl_map_item_t            *erp_rules_it = NULL, *erp_rules_it_end = NULL;
    const cl_fmap_item_t           *rules_refs = NULL, *rules_ref_end = NULL;
    atcam_rules_db_rule_entry_t    *rule_entry = NULL;
    sx_atcam_key_value_t            intersected_value;
    atcam_erps_db_prune_db_entry_t *prune_map_entry = NULL;

    SX_MEM_CLR(intersected_value);

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d\n", erp_id, region_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_cnt_get(region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks size for region %d\n", region_id);
        goto out;
    }

    /* The DB  entry should have been allocated prior this call */
    if (!prune_map->allocated) {
        SX_LOG_ERR("Entry (M: %d, S: %d) should have been allocated for region %d\n",
                   prune_map->main_id,
                   prune_map->sec_id,
                   region_id);
        goto out;
    }


    /*
     * We need to create an entry (surely it doesn't exist) within erp(sec, main) table, and add the secondary erp
     * rules there. Note that rules can be mapped to the same entry, so it's possible that the new entry was already
     * created from a previous iterated rule.
     */
    erp_rules_it = cl_qmap_head(&(erp->rules));
    erp_rules_it_end = cl_qmap_end(&erp->rules);
    while (erp_rules_it != erp_rules_it_end) {
        rule_entry = PARENT_STRUCT(erp_rules_it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        SX_MEM_CLR(intersected_value); /* Probably not needed, but to be on the safe side */
        sx_status = atcam_utils_intersect_val_n_mask(
            (const sx_atcam_key_value_t*)&rule_entry->data.key_value_blocks.flex_value_blocks,
            &prune_map->mask,
            &intersected_value);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to intersect value of rule 0x%" PRIx64 " with intersection map (m:%d, s:%d)\n",
                       rule_entry->data.rule_id,
                       prune_map->main_id,
                       prune_map->sec_id);
            goto out;
        }

        rules_refs = cl_fmap_get(&prune_map->rules_refs, (void*)&intersected_value);
        rules_ref_end = cl_fmap_end(&prune_map->rules_refs);
        /* Entry does not exist, first rule of that kind */
        if (rules_refs == rules_ref_end) {
            sx_status = atcam_erps_db_prune_entry_allocate(prune_map, &intersected_value, &prune_map_entry);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to allocate new prune db entry for erps (m: %d, s: %d), for region %d\n",
                           prune_map->main_id,
                           prune_map->sec_id,
                           region_id);
                goto out;
            }
        } else {
            prune_map_entry = PARENT_STRUCT(rules_refs, atcam_erps_db_prune_db_entry_t, fmap_item);
        }

        if (added_erp_context) {
            /* Insert entry to the right place */
            cl_qmap_insert(&prune_map_entry->other_erp_rules, __create_priority_rule_key(rule_entry->data.priority),
                           &(rule_entry->per_prune_other_li[prune_map->main_id]));
        } else {
            /* Insert entry to the right place
             * NOTE: Since the rules are inserted for a new erp (without rules) it is assumed
             * that all rules are pruning and therefore there is no need for sorting them in
             * pruning/non-pruning order.
             */
            cl_qmap_insert(&(prune_map_entry->current_erp_rules),
                           __create_priority_rule_key(rule_entry->data.priority),
                           &(rule_entry->per_prune_curr_li[prune_map->sec_id]));
        }

        /* move to next rule of this erp */
        erp_rules_it = cl_qmap_next(erp_rules_it);
    }


out:
    return sx_status;
}


static sx_status_t __update_prune_of_erp_rules_changed_priority(const sx_atcam_erp_id_t           erp_id,
                                                                const atcam_rules_db_rule_t      *rule,
                                                                const sx_flex_acl_rule_priority_t old_priority)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t         *erp = NULL;
    const cl_map_item_t         *it = NULL, *end = NULL;
    atcam_rules_db_rule_entry_t *erp_rule_entry = NULL;

    sx_status = atcam_erps_db_erp_get(rule->region_id, erp_id, &erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get eRP %d for region %d\n", erp_id, rule->region_id);
        goto out;
    }

    it = cl_qmap_head(&(erp->rules));
    end = cl_qmap_end(&erp->rules);
    while (it != end) {
        erp_rule_entry = PARENT_STRUCT(it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        __update_prune_to_ctcam_changed_priority(rule, &erp_rule_entry->data, old_priority);
        it = cl_qmap_next(it);
    }

out:
    return sx_status;
}


static void __update_prune_to_ctcam_changed_priority(const atcam_rules_db_rule_t      *ctcam_rule,
                                                     atcam_rules_db_rule_t            *erp_rule,
                                                     const sx_flex_acl_rule_priority_t old_priority)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_blocks_size_t    key_blocks_size;
    boolean_t                     are_compatible = FALSE;
    sx_atcam_large_entry_key_id_t large_key_id = LARGE_KEY_HANDLE_INVALID;

    /* Only if changed priority made a difference (that is, lower priority rule became higher priority or vice versa), there's a point in checking compatibility */
    if (((old_priority >= erp_rule->priority) && (ctcam_rule->priority >= erp_rule->priority)) ||
        ((old_priority < erp_rule->priority) && (ctcam_rule->priority < erp_rule->priority))) {
        return;
    }

    sx_status = atcam_regions_db_key_blocks_size_get(ctcam_rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error: Failed to get region key blocks size needed for prune calculations\n");
        return;
    }

    sx_status = atcam_utils_are_keys_compatible(&ctcam_rule->key_value_blocks,
                                                &erp_rule->key_value_blocks,
                                                &are_compatible);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error: failed to check if rules 0x%" PRIx64 " and 0x%" PRIx64 " are compatible\n",
                   ctcam_rule->rule_id,
                   erp_rule->rule_id);
        return;
    }

    if (are_compatible) {
        if (ctcam_rule->priority < erp_rule->priority) {
            /* This shouldn't happen - but we perform this sanity check to make
             * sure system is consistent. Might prove especially useful for async-system
             */
            if (erp_rule->prune_ctcam_cnt == 0) {
                SX_LOG_ERR("When updating prune of rule 0x%" PRIx64 " after deletion of rule 0x%" PRIx64 " at region %d,"
                           "Prune wasn't set in the first place, even though rules are compatible\n",
                           erp_rule->rule_id,
                           ctcam_rule->rule_id,
                           ctcam_rule->region_id);
                return;
            }
            --erp_rule->prune_ctcam_cnt;
            /*
             * We send message to HW only if erp_rule is NOT the current rule being inserted, rather
             * this is a side effect of insertion of another rule (to ctcam)
             */
            if (erp_rule->prune_ctcam_cnt == 0) {
                /* If got here - this is an update to atcam(!) rule - which has large key id */
                if (erp_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                    sx_status = atcam_large_key_id_get(erp_rule->large_key_handle,
                                                       &large_key_id,
                                                       NULL);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                               erp_rule->rule_id);
                        return;
                    }
                }

                sx_status = atcam_sxd_wrapper_set_rule_to_hw(erp_rule,
                                                             DEFAULT_DEV_ID,
                                                             (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                             TRUE,
                                                             large_key_id,
                                                             key_blocks_size);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update to HW rule 0x%" PRIx64 " of region %d\n",
                               erp_rule->rule_id, erp_rule->region_id);
                    return;
                }
            }
        } else {
            ++erp_rule->prune_ctcam_cnt;
            if (erp_rule->prune_ctcam_cnt == 1) {
                /* If got here - this is an update to atcam(!) rule - which has large key id */
                if (erp_rule->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
                    sx_status = atcam_large_key_id_get(erp_rule->large_key_handle,
                                                       &large_key_id,
                                                       NULL);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG(SX_LOG_ERROR,
                               "Failed to get large_key_id for rule_id 0x%" PRIx64 "\n",
                               erp_rule->rule_id);
                        return;
                    }
                }
                sx_status = atcam_sxd_wrapper_set_rule_to_hw(erp_rule,
                                                             DEFAULT_DEV_ID,
                                                             (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                             TRUE,
                                                             large_key_id,
                                                             key_blocks_size);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update to HW rule 0x%" PRIx64 " of region %d\n", erp_rule->rule_id,
                               erp_rule->region_id);
                    return;
                }
            }
        }
    }
}
