/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_OPTS_H__
#define __ATCAM_ERPS_OPTS_H__

#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"


/**
 * Initializes Erps Optimizations Module.
 *
 * @param[in]  num_of_regions - The total number of regions that should be supported.
 *
 * @return
 *    SX_STATUS_NO_MEMORY - if there's not enough memory to allocate the requested number of eRPS
 *    SX_STATUS_SUCCESS        - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_init(const uint32_t num_of_regions);


/**
 * De-Initializes Erps Optimizations Module.
 *
 * @param[in]  forced_deinit - If TRUE, deinitialize the module even if some resources are in use, otherwise function will fail.
 *
 * @return
 *    SX_STATUS_RESOURCE_IN_USE - If some regions are still not deleted (and not forced_deinit)
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_deinit(const boolean_t forced_deinit);


/**
 * Allocates a new region. This function should be called whenever a new region is allocated in the system.
 * It will allow the region to be sampled when future 'atcam_erps_opts_sample_counters' calls will be made.
 *
 * @param[in]  region_id - The id of the region.
 *
 * @return
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - If region id exceeds range (more than the number of regions)
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - If region was previously allocated
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_region_allocate(const sx_atcam_region_id_t region_id);


/**
 * Destroys an existing region. This function should be called whenever a new region is destroyed, or if one wishes not to
 * enable sampling (and possible optimizations) on this region.
 *
 * @param[in]  region_id - The id of the region.
 *
 * @return
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - If region id exceeds range (more than the number of regions)
 *    SX_STATUS_ENTRY_NOT_FOUND      - If region wasn't previously allocated
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_region_destroy(const sx_atcam_region_id_t region_id);


/**
 * Disables Sampling of all kind. All future calls atcam_erps_opts_sample_counters will return immediately, with nothing
 * be set or read.
 * This function should be used mainly for debug purposes, but could also be used to avoid transient-scenarios.
 *
 **/
void atcam_erps_opts_sampling_stop(void);


/**
 * Enabled sampling of all kind. The samples cycle will resume from the point it last stopped.
 *
 **/
void atcam_erps_opts_sampling_resume(void);


/**
 * Adds a new erp for a given region. This function will enable this erp to be sampled for this region sometime in the future.
 *
 * @param[in]  region_id - The id of the region.
 * @param[in]  erp_id - The id of the erp.
 * @param[in]  erp_bank - The bank of the erp.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND      - If region wasn't previously allocated
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - If this erp was already allocated for this region.
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_erp_add(const sx_atcam_region_id_t region_id,
                                    const sx_atcam_erp_id_t    erp_id,
                                    const uint8_t              erp_bank);


/**
 * Removes an erp from a given region. This mean that this erp (if still exists) won't be sampled for this region, unless re-added again.
 *
 * If this erp is currently be sampled, the result is disregarded.
 *
 * @param[in]  region_id - The id of the region.
 * @param[in]  erp_id - The id of the erp.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND  - If region or erp weren't wasn't previously allocated
 *    SX_STATUS_SUCCESS          - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_erp_delete(const sx_atcam_region_id_t region_id,
                                       const sx_atcam_erp_id_t    erp_id);


/**
 * Updates the prune score a specific erp of a region, according to the given prune vector.
 * The prune score of an erp, is the sum of all prune-score of rules in that erp.
 * A prune score of a rule, is the number of set bits in this rule's prune vector.
 *
 * Whenever we insert a rule, we add to the current score, and when we remove, we subtract from the current score.
 *
 * If this erp is currently be sampled, the result is disregarded.
 *
 * @param[in]  region_id    - The id of the region.
 * @param[in]  erp_id       - The id of the erp.
 * @param[in]  prune_vector - The prune vector of some rule
 * @param[in]  is_insertion - TRUE for insertion, FALSE otherwise.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND  - If region or erp weren't previously allocated
 *    SX_STATUS_SUCCESS          - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_erp_update_score(const sx_atcam_region_id_t region_id,
                                             const sx_atcam_erp_id_t    erp_id,
                                             const uint16_t             prune_vector,
                                             const boolean_t            is_insertion);


/**
 * Samples regions' and erps' counters.
 * Due to HW limitation, we can only utilize one counter. That is, we can't sample (precisely) more than one erp
 * at a time. This function will Iterate over all the known (added) region in the system, and test which are worthy
 * of sampling (erp sampling). An active region will be moved to the next stage - in which its erps will be sampled
 * one at a time. Once this is over - the region is considered ready, and can be optimized using atcam_erps_opts_reorder_erps.
 *
 * Important notes:
 *  1) This function does NOT optimize the region which are ready. Instead, some other caller should allocate resources for that.
 *  2) This function should not be called explicitly from any flows in the system, except for periodic call. It is best that this
 *     Function will be applied to some sort of timer (preferably, other than sx_api timer).
 *  3) Any previous calls to 'atcam_erps_opts_sampling_stop' will result in this function doing nothing. Only succeeding
 *     call to atcam_erps_opts_sampling_resume, will return this function normal flow.
 *
 */
void atcam_erps_opts_sample_counters(void);


/**
 * See notes @atcam_erps_opts_sample_counters.
 *
 * This difference between the functions, is that this function can overcome prevention from previous
 * 'atcam_erps_opts_sampling_stop' calls, and still operate normally.
 *
 * That is, this function will always continue with the sampling cycle, regardless of previous requests.
 *
 * Notes:
 *  This function is mainly used for debug purposes, and should not be called explicitly at any time, unless
 *  the caller knows what he/she's doing. Use at your own desertion.
 *  call to atcam_erps_opts_sampling_resume, will return this function normal flow.
 */
void atcam_erps_opts_sample_counters_debug(void);


/**
 * Reorders erps of a specific region, and returns the optimized order of those erps.
 * Decision which erps are preferred in order is documented in Optimizations Document (See PortalX) and ARCH.
 *
 * This function enables the caller 2 options:
 *  1) The caller can give a region_id, and that region is ready to be optimized - it will be and the new ordered set
 *     of erps is returned.
 *  2) The caller can let the function choose the first ready region (if any), and return its id, and list of ordered erps.
 *
 * @param[inout]  region_id  - A pointer to the id of a region, or SX_ATCAM_INVALID_REGION_ID if
 *                             one wishes the function will choose t region, in which case, the region is is returned.
 * @param[in]  erp_id        - A list of reordered erps. The list is only valid if 'completed' is TRUE. It is assumed that
 *                             this list is at least the size of SX_ATCAM_ERPS_PER_REGION.
 * @param[in]  completed     - TRUE if the operation was fully completed, FALSE otherwise. It is possible that a requested
 *                             region, or no region, is ready for optimization. In which case, we DON"T consider this is an error,
 *                             but instead, we signal that the process wasn't completed. In which case erp_ids is invalid, and should not be read.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND  - If region or erp weren't previously allocated
 *    SX_STATUS_SUCCESS          - if operation has finished successfully.
 */
sx_status_t atcam_erps_opts_reorder_erps(sx_atcam_region_id_t *region_id,
                                         sx_atcam_erp_id_t    *erp_ids,
                                         boolean_t            *completed);


#endif /* __ATCAM_ERPS_OPTS_H__ */
