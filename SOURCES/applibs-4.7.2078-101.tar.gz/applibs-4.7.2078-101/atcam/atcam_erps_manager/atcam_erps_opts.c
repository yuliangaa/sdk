/*
 * Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "atcam_erps_opts.h"
#include "atcam/atcam_sxd_wrapper/atcam_counters_sxd_wrapper.h"

#include "complib/sx_log.h"


/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/

#define ATCAM_OPTS_DB_REGION_HITS_MIN_FOR_SAMPLING 1

typedef enum atcam_opts_db_region_state {
    ATCAM_OPTS_REGION_NOT_READY       = 0,      /* A region will be in this state if it was allocated or reordered recently */
    ATCAM_OPTS_REGION_SAMPLE_CADIDATE = 1,      /* A region will be in this state to check if any traffic goes through it - to see if it needs to be optimized at all */
    ATCAM_OPTS_REGION_BEING_SAMPLED   = 2,      /* A region will be in this state when being sampled */
    ATCAM_OPTS_REGION_READY           = 3       /* Sampling has done, and region can be reordered. */

                                        /* Next stages will be more complex, so we need to support more states */
} atcam_opts_db_region_state_t;

typedef struct atcam_erps_stats {
    sx_atcam_erp_id_t erp_id;
    uint8_t           erp_bank; /* This is important - eventually, HW limits us to within bank reordering */
    boolean_t         valid;
    uint64_t          prune_score;
    uint64_t          hits_count;
} atcam_erps_stats_t;

typedef struct atcam_erps_opts_db_region {
    boolean_t                    valid;
    atcam_opts_db_region_state_t region_state;
    atcam_erps_stats_t           erps_samples[SX_ATCAM_ERPS_PER_REGION];
} atcam_erps_opts_db_region_t;

typedef struct atcam_erps_opts_db_regions_t {
    atcam_erps_opts_db_region_t *regions;
    uint32_t                     num_of_regions;
} atcam_erps_opts_db_regions_t;


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static atcam_erps_opts_db_regions_t regions_opts_db;
static uint32_t                     region_being_sampled;
static uint16_t                     erp_being_sampled;
static boolean_t                    dont_sample = TRUE; /* A flag (mainly for debuggability) to stop sampling erps using counters */

/************************************************
 *  Local function declarations
 ***********************************************/
/* static sx_status_t */
void __atcam_erps_opts_sample_counters(const boolean_t debug_call);
static sx_atcam_region_id_t __find_next_region_to_sample();
static void __find_new_candidate_region();
static void __find_next_erp_to_sample(const sx_atcam_region_id_t region_id, const boolean_t from_start);
static uint64_t __read_region_counter();
static uint64_t __read_erp_hits_counter();
static int __erp_comp_func(const void *erp_stat_a, const void *erp_stat_b);


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t atcam_erps_opts_init(const uint32_t num_of_regions)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    regions_opts_db.num_of_regions = num_of_regions;

    sx_status = utils_clr_memory_get((void**)(&(regions_opts_db.regions)),
                                     num_of_regions,
                                     sizeof(atcam_erps_opts_db_region_t),
                                     UTILS_MEM_TYPE_ID_ACL_E);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to allocate ATCAM regions opts db memory\n");
        goto error;
    }

    dont_sample = FALSE;
    region_being_sampled = SX_ATCAM_INVALID_REGION_ID;
    erp_being_sampled = ATCAM_INVALID_ERP_ID;


    goto out;

error:
    if (SX_CHECK_FAIL(rb_rc = utils_memory_put((void*)(regions_opts_db.regions), UTILS_MEM_TYPE_ID_ACL_E))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_opts_deinit(const boolean_t forced_deinit)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (!forced_deinit) {
        for (i = 0; i < regions_opts_db.num_of_regions; ++i) {
            if (regions_opts_db.regions[i].valid) {
                sx_status = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Region %u is still in use. Destroy it first, or force deinit\n", i);
                goto out;
            }
        }
    }

    dont_sample = TRUE;

    /* No need to delete rules or eRPs - they should be deleted explicitly before */
    /* DeAllocate ATCAM regions DB*/
    sx_status = utils_memory_put((void*)(regions_opts_db.regions), UTILS_MEM_TYPE_ID_ACL_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Deallocate ATCAM opt db memory, err [%s]\n", sx_status_str(sx_status));
    }

    regions_opts_db.regions = NULL;
    regions_opts_db.num_of_regions = 0;

out:
    SX_LOG_EXIT();
    return sx_status;
}

void atcam_erps_opts_sampling_stop(void)
{
    dont_sample = TRUE;
}

void atcam_erps_opts_sampling_resume(void)
{
    dont_sample = FALSE;
}


sx_status_t atcam_erps_opts_region_allocate(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (region_id >= regions_opts_db.num_of_regions) {
        SX_LOG_ERR("Region id exceeds range\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }


    if (regions_opts_db.regions[region_id].valid) {
        SX_LOG_ERR("Region %u already exists\n", region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    SX_MEM_CLR(regions_opts_db.regions[region_id]);
    regions_opts_db.regions[region_id].valid = TRUE;
    regions_opts_db.regions[region_id].region_state = ATCAM_OPTS_REGION_NOT_READY;

out:
    return sx_status;
}


sx_status_t atcam_erps_opts_region_destroy(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (region_id >= regions_opts_db.num_of_regions) {
        SX_LOG_ERR("Region id exceeds range\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!regions_opts_db.regions[region_id].valid) {
        SX_LOG_ERR("Region %u does not exist\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (region_id == region_being_sampled) {
        region_being_sampled = SX_ATCAM_INVALID_REGION_ID;
    }

    SX_MEM_CLR(regions_opts_db.regions[region_id]);
    regions_opts_db.regions[region_id].valid = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_opts_erp_add(const sx_atcam_region_id_t region_id,
                                    const sx_atcam_erp_id_t    erp_id,
                                    const uint8_t              erp_bank)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!regions_opts_db.regions[region_id].valid) {
        SX_LOG_ERR("Region %u wasn't allocated before\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (regions_opts_db.regions[region_id].erps_samples[erp_id].valid) {
        SX_LOG_ERR("Erp %u already exists in region %u\n", erp_id, region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    regions_opts_db.regions[region_id].erps_samples[erp_id].valid = TRUE;
    regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score = 0;
    regions_opts_db.regions[region_id].erps_samples[erp_id].erp_id = erp_id;
    regions_opts_db.regions[region_id].erps_samples[erp_id].erp_bank = erp_bank;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_opts_erp_delete(const sx_atcam_region_id_t region_id, const sx_atcam_erp_id_t erp_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!regions_opts_db.regions[region_id].valid) {
        SX_LOG_ERR("Region %u wasn't allocated before\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (!regions_opts_db.regions[region_id].erps_samples[erp_id].valid) {
        SX_LOG_ERR("Erp %u does not exist in region %u\n", erp_id, region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }


    /*
     * Even is this erp is currently being sampled (which should not happen - as this is a sync-flow,
     * we're ok - as we invalidate this erp, so it won't be taken into consideration when optimizing next.
     */
    regions_opts_db.regions[region_id].erps_samples[erp_id].valid = FALSE;
    regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score = 0;
    regions_opts_db.regions[region_id].erps_samples[erp_id].erp_id = ATCAM_INVALID_ERP_ID;
    regions_opts_db.regions[region_id].erps_samples[erp_id].erp_bank = 0;


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_opts_erp_update_score(const sx_atcam_region_id_t region_id,
                                             const sx_atcam_erp_id_t    erp_id,
                                             const uint16_t             prune_vector,
                                             const boolean_t            is_insertion)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     score = 0;

    SX_LOG_ENTER();

    if (!regions_opts_db.regions[region_id].valid) {
        SX_LOG_ERR("Region %u wasn't previously allocated to opt-db.\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (!regions_opts_db.regions[region_id].erps_samples[erp_id].valid) {
        SX_LOG_ERR("Erps %u wasn't previously allocated to opt-db.\n", erp_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    score = __builtin_popcount(prune_vector);

    if (is_insertion) {
        regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score += score;
    } else {
        /* Sanity check - this shouldn't happen */
        if (regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score < score) {
            SX_LOG_WRN(
                "Prune score of erp %u of region %u was calculated to be below 0. This means db is inconsistent, and should be checked.\n",
                erp_id,
                region_id);
            regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score = 0;
        } else {
            regions_opts_db.regions[region_id].erps_samples[erp_id].prune_score -= score;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

void atcam_erps_opts_sample_counters(void)
{
    __atcam_erps_opts_sample_counters(FALSE);
}

void atcam_erps_opts_sample_counters_debug(void)
{
    __atcam_erps_opts_sample_counters(TRUE);
}


sx_status_t atcam_erps_opts_reorder_erps(sx_atcam_region_id_t *region_id,
                                         sx_atcam_erp_id_t    *erp_ids,
                                         boolean_t            *completed)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_atcam_region_id_t region = SX_ATCAM_INVALID_REGION_ID;
    atcam_erps_stats_t   erps_samples_copy[SX_ATCAM_ERPS_PER_REGION];
    atcam_erps_stats_t  *current_stat = NULL;
    uint16_t             i = 0, index = 0;
    uint8_t              b1 = 0, b2 = 0, b3 = 0, b4 = 0;
    uint16_t             erps_per_bank = (SX_ATCAM_ERPS_PER_REGION / ATCAM_BF_NUM_OF_BANKS);

    SX_MEM_CLR(erps_samples_copy);

    if (!region_id || !erp_ids || !completed) {
        SX_LOG_ERR("Null param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *completed = FALSE;

    /* Pick the first one that's ready */
    if (*region_id == SX_ATCAM_INVALID_REGION_ID) {
        for (i = 0; i < regions_opts_db.num_of_regions; ++i) {
            if (regions_opts_db.regions[i].region_state == ATCAM_OPTS_REGION_READY) {
                region = i;
                break;
            }
        }
        if (region == SX_ATCAM_INVALID_REGION_ID) {
            SX_LOG_DBG("Currently no regions left to optimize\n");
            goto out;
        } else {
            *region_id = i;
        }
    }
    /* Choose the one given by the caller */
    else {
        region = *region_id;
        if (regions_opts_db.regions[region].region_state != ATCAM_OPTS_REGION_READY) {
            SX_LOG_DBG("Region %u is not ready for optimization.\n", region);
            goto out;
        }
    }


    SX_LOG_DBG("Optimizing region %u...\n", region);
    /* We take a snap shot of the status
     * so changes can go as we optimize next.
     * Changes will be taken in account in the next cycle.
     *
     * Also note - we have an HW limitation to re-arrange only within banks (See Opt. doc), so we
     * pack these blocks as we go.
     **/
    b1 = erps_per_bank * 0;
    b2 = erps_per_bank * 1;
    b3 = erps_per_bank * 2;
    b4 = erps_per_bank * 3;

    /* In order to sort each bank separately, we first need to rearrange each erp by its bank */
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        current_stat = &regions_opts_db.regions[region].erps_samples[i];
        switch (current_stat->erp_bank) {
        case (0):
            if (current_stat->valid) {
                memcpy(&erps_samples_copy[b1++], current_stat, sizeof(atcam_erps_stats_t));
            }
            break;

        case (1):
            if (current_stat->valid) {
                memcpy(&erps_samples_copy[b2++], current_stat, sizeof(atcam_erps_stats_t));
            }
            break;

        case (2):
            if (current_stat->valid) {
                memcpy(&erps_samples_copy[b3++], current_stat, sizeof(atcam_erps_stats_t));
            }
            break;

        case (3):
            if (current_stat->valid) {
                memcpy(&erps_samples_copy[b4++], current_stat, sizeof(atcam_erps_stats_t));
            }
            break;
        }
    }

    /* Sort each bank separately */
    qsort(erps_samples_copy, erps_per_bank, sizeof(atcam_erps_stats_t), __erp_comp_func);
    qsort(erps_samples_copy + erps_per_bank * 1, erps_per_bank, sizeof(atcam_erps_stats_t), __erp_comp_func);
    qsort(erps_samples_copy + erps_per_bank * 2, erps_per_bank, sizeof(atcam_erps_stats_t), __erp_comp_func);
    qsort(erps_samples_copy + erps_per_bank * 3, erps_per_bank, sizeof(atcam_erps_stats_t), __erp_comp_func);


    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        /* Unpacking - erps_samples is arranged by banks. If we're to think about it as an 2-d array,
         * then we actually transpose the matrix of erps
         */
        index = ATCAM_BF_NUM_OF_BANKS * (i % ATCAM_BF_NUM_OF_BANKS) + (i / ATCAM_BF_NUM_OF_BANKS);
        erp_ids[index] = erps_samples_copy[i].valid ? erps_samples_copy[i].erp_id : ATCAM_INVALID_ERP_ID;
    }

    regions_opts_db.regions[region].region_state = ATCAM_OPTS_REGION_NOT_READY;
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        regions_opts_db.regions[region].erps_samples[i].hits_count = 0;
    }


    *completed = TRUE;
out:
    SX_LOG_EXIT();
    return sx_status;
}


/************************************************
 *  Local Function implementations
 ***********************************************/

void __atcam_erps_opts_sample_counters(const boolean_t debug_call)
{
    if (dont_sample && !debug_call) {
        return;
    }

    if (region_being_sampled == SX_ATCAM_INVALID_REGION_ID) {
        __find_new_candidate_region();
        return;
    }

    if (regions_opts_db.regions[region_being_sampled].region_state == ATCAM_OPTS_REGION_SAMPLE_CADIDATE) {
        /* Only if region had sufficient traffic - we bother to sample it */
        if (__read_region_counter() > ATCAM_OPTS_DB_REGION_HITS_MIN_FOR_SAMPLING) {
            regions_opts_db.regions[region_being_sampled].region_state = ATCAM_OPTS_REGION_BEING_SAMPLED;
            __find_next_erp_to_sample(region_being_sampled, TRUE); /* If got here - there must be at least 1 erp */
        }
        /* Not enough traffic to bother sampling this region - move to the next region */
        else {
            /* Maybe in the next cycle this region will be active */
            regions_opts_db.regions[region_being_sampled].region_state = ATCAM_OPTS_REGION_NOT_READY;
            __find_new_candidate_region();
        }

        return;
    }

    if (regions_opts_db.regions[region_being_sampled].region_state == ATCAM_OPTS_REGION_BEING_SAMPLED) {
        regions_opts_db.regions[region_being_sampled].erps_samples[erp_being_sampled].hits_count =
            __read_erp_hits_counter();

        SX_LOG_DBG("Results: erp %u from region %u had %" PRIu64 " hits\n",
                   erp_being_sampled,
                   region_being_sampled,
                   regions_opts_db.regions[region_being_sampled].erps_samples[erp_being_sampled].hits_count);
        __find_next_erp_to_sample(region_being_sampled, FALSE);
        SX_LOG_DBG("Sampling erp %u from region %u\n", erp_being_sampled, region_being_sampled);

        /* No more erps for this region */
        if (erp_being_sampled == ATCAM_INVALID_ERP_ID) {
            regions_opts_db.regions[region_being_sampled].region_state = ATCAM_OPTS_REGION_READY;

            __find_new_candidate_region();
        }
    }
}


static sx_atcam_region_id_t __find_next_region_to_sample()
{
    uint16_t i = 0;

    if (region_being_sampled == SX_ATCAM_INVALID_REGION_ID) {
        for (i = 0; i < regions_opts_db.num_of_regions; ++i) {
            if (regions_opts_db.regions[i].valid &&
                (regions_opts_db.regions[i].region_state == ATCAM_OPTS_REGION_NOT_READY)) {
                return i;
            }
        }
    } else {
        for (i = (region_being_sampled + 1) % regions_opts_db.num_of_regions;
             i != region_being_sampled;
             i = (i + 1) % regions_opts_db.num_of_regions) {
            if (regions_opts_db.regions[i].valid &&
                (regions_opts_db.regions[i].region_state == ATCAM_OPTS_REGION_NOT_READY)) {
                return i;
            }
        }
    }

    return SX_ATCAM_INVALID_REGION_ID;
}


static void __find_new_candidate_region()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    do {
        region_being_sampled = __find_next_region_to_sample();
        if (region_being_sampled == SX_ATCAM_INVALID_REGION_ID) {
            return;
        }

        /* Before we sample a new region - we first clear the counters */
        sx_status = atcam_counters_sxd_wrapper_read_region_erps_counters(TRUE, NULL, NULL, NULL, NULL, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_NTC("Unable to initialize region counter before sampling region %u\n", region_being_sampled);
            continue;
        }

        /* Set a counter for the new candidate */
        sx_status = atcam_counters_sxd_wrapper_set_region_erps_counters(region_being_sampled,
                                                                        ATCAM_COUNTERS_SPECIFIC_REGION_BITMASK,
                                                                        0xFFFF,
                                                                        FALSE);
        if (sx_status == SX_STATUS_SUCCESS) {
            regions_opts_db.regions[region_being_sampled].region_state = ATCAM_OPTS_REGION_SAMPLE_CADIDATE;
        } else {
            SX_LOG_NTC("Unable to set counter on region %u\n", region_being_sampled);
        }
    } while (sx_status != SX_STATUS_SUCCESS);
}


static void __find_next_erp_to_sample(const sx_atcam_region_id_t region_id, const boolean_t from_start)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint16_t    i = 0;

    for (i = from_start ? 0 : erp_being_sampled + 1; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        if (regions_opts_db.regions[region_id].erps_samples[i].valid) {
            erp_being_sampled = i;
            sx_status =
                atcam_counters_sxd_wrapper_set_region_erps_counters(region_being_sampled,
                                                                    ATCAM_COUNTERS_SPECIFIC_REGION_BITMASK,
                                                                    (1 << erp_being_sampled),
                                                                    FALSE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("Unable to set counter of region %u on erp %u - moving to next erp \n",
                           region_being_sampled,
                           erp_being_sampled);
                continue; /* if we cant set this counter - we try on other erp for this region */
            }

            return;
        }
    }

    /* Note - it can happen that a 'later-comer' erp was allocated to an index lower than last previously known.
     * In which case - that erp won't be sampled for this cycle of optimization. But that's fine - it will sometime
     * in the future.
     */
    erp_being_sampled = ATCAM_INVALID_ERP_ID;
}


static uint64_t __read_region_counter()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint64_t    region_hits = 0;

    sx_status = atcam_counters_sxd_wrapper_read_region_erps_counters(TRUE, NULL, NULL, &region_hits, NULL, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Unable to read counter from region %u\n, ignoring\n", region_being_sampled);
        return 0;
    }

    return region_hits;
}


static uint64_t __read_erp_hits_counter()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint64_t    erp_hits = 0;

    sx_status = atcam_counters_sxd_wrapper_read_region_erps_counters(TRUE, NULL, NULL, NULL, NULL, &erp_hits);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Unable to read erp counter from region %u on erp %u ignoring\n",
                   region_being_sampled,
                   erp_being_sampled);
        return 0;
    }

    return erp_hits;
}


int __erp_comp_func(const void *erp_stat_a, const void *erp_stat_b)
{
    atcam_erps_stats_t *stat_a = (atcam_erps_stats_t*)erp_stat_a;
    atcam_erps_stats_t *stat_b = (atcam_erps_stats_t*)erp_stat_b;
    double              n1 = stat_a->hits_count * stat_a->prune_score;
    double              n2 = stat_b->hits_count * stat_b->prune_score;

    return (n1 < n2) - (n1 > n2);
}
