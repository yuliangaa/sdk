/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "utils/sx_mem.h"
#include "complib/sx_log.h"
#include "complib/cl_byteswap.h"

#include "atcam_erps_db.h"
#include "atcam_erps_selector.h"

#include "atcam/atcam_regions_manager/atcam_regions_db.h"
#include "atcam/atcam_erps_manager/atcam_erps_memory_manager.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"

/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/

#define MAX_UINT_16      0xFFFF
#define ALL_DELTA_VALUES MAX_UINT_16 + 1

typedef enum rule_erp_eq_state {
    RULE_ERP_EQUAL,       /* Exact match between rule and eRP */
    RULE_ERP_DELTA_EQUAL, /* delta-equivalence between rule and eRP */
    RULE_ERP_NOT_EQUAL    /* differ by more than 1 bytes, thus considered different */
} rule_erp_eq_state_e;

/* We'll check for erp delta in 64 bits chunks */
#define DELTA_CHUNK_SIZE (64)
/* The max key size in 64 bits chunks - used for delta calculation */
#define ATCAM_MAX_KEY_SIZE_64BIT ((ATCAM_MAX_KEY_SIZE / 8) - 1)
/* Bad collisions threshold values */
/* The bad collision tolerance is calculated as a percentage of the total kvd_size */
#define BAD_COLLISION_SPACE_SIZE (rm_resource_global.kvd_size)
/* Allowed single entries bad collision percentages */
#define S_NO_BAD_COLLISION_ALLOWED  (100)     /* No actual collision */
#define SS_BAD_COLLISIONS_ALLOWED   (100)     /* Two rules colliding */
#define SSS_BAD_COLLISIONS_ALLOWED  (50)      /* Three rules colliding */
#define SSSS_BAD_COLLISIONS_ALLOWED (10)      /* Four rules colliding */
/* Allowed double entries bad collision percentages */
#define D_NO_BAD_COLLISION_ALLOWED  (100)     /* No actual collision */
#define DD_BAD_COLLISIONS_ALLOWED   (10)      /* Two rules colliding */
#define DDD_BAD_COLLISIONS_ALLOWED  (0)       /* Three rules colliding */
#define DDDD_BAD_COLLISIONS_ALLOWED (0)       /* Four rules colliding */

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/* This array holds the offset in the atcam key (in 64 bit blocks) for each key blocks count. used for delta calculation */
static int8_t start_64bit_chunks[ATCAM_MAX_NUM_OF_HW_KEY_BLOCKS +
                                 1] = {0, 6, 5, 5, 4, 4, 3, 3, 2, 1, 1, 0, 0};
static atcam_erps_db_bad_collision_counters_t allowed_bad_collsions = {
    {S_NO_BAD_COLLISION_ALLOWED,
     SS_BAD_COLLISIONS_ALLOWED,
     SSS_BAD_COLLISIONS_ALLOWED,
     SSSS_BAD_COLLISIONS_ALLOWED,
     0},
    {D_NO_BAD_COLLISION_ALLOWED,
     DD_BAD_COLLISIONS_ALLOWED,
     DDD_BAD_COLLISIONS_ALLOWED,
     DDDD_BAD_COLLISIONS_ALLOWED,
     0}
};

/************************************************
 *  Local function declarations
 ***********************************************/

/*
 * ADD DOC
 */
static sx_status_t __atcam_erps_selector_is_rule_delta_eq_erp(const uint32_t             blocks_cnt,
                                                              const atcam_erps_db_erp_t *erp,
                                                              atcam_rules_db_rule_t     *rule,
                                                              boolean_t                 *delta_eq);
static sx_status_t __check_match_on_erp(atcam_rules_db_rule_t *rule,
                                        uint32_t               blocks_cnt,
                                        sx_atcam_erp_id_t      erps_id,
                                        boolean_t             *found);

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t atcam_erps_selector_init()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Next phase we will init a worker thread here to optimize eRP selection */
    goto out;
out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_selector_deinit()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* currently not much logic - next phases add more logic to this method */

    goto out;
out:
    SX_LOG_EXIT();
    return sx_status;
}

/**
 * Currently, the decision to create a new
 * erp is solely based on availability. Next stages, more complex
 * parameters will be taken into account. This is why we need this
 * function
 */
sx_status_t atcam_erps_selector_new_erp_needed(sx_atcam_region_id_t region_id, boolean_t *new_erp_needed)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION];
    uint8_t           i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(erps_ids);
    sx_status = atcam_erps_memory_manager_array_get(region_id, erps_ids, NULL, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        if (erps_ids[i] == ATCAM_INVALID_ERP_ID) {
            *new_erp_needed = TRUE;
            goto out;
        }
    }

    *new_erp_needed = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __check_match_on_erp(atcam_rules_db_rule_t *rule,
                                        uint32_t               blocks_cnt,
                                        sx_atcam_erp_id_t      erps_id,
                                        boolean_t             *found)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *current_erp = NULL;
    boolean_t            delta_eq = FALSE;

    SX_LOG_ENTER();
    sx_status = atcam_erps_db_erp_get(rule->region_id, erps_id, &current_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("While getting erp %d, from region %d\n", erps_id, rule->region_id);
        goto out;
    }

    sx_status = __atcam_erps_selector_is_rule_delta_eq_erp(blocks_cnt, current_erp, rule, &delta_eq);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Delta equal failed for erp %d, from region %d\n", erps_id, rule->region_id);
        goto out;
    }

    if (delta_eq) {
        /* We can stop the search - everything is updated for that rule */
        rule->erp_id = current_erp->erp_id;
        *found = TRUE;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_selector_find_matching_erp(atcam_rules_db_rule_t *rule,
                                                  boolean_t             *found_matching_erp,
                                                  boolean_t              predetermined,
                                                  sx_atcam_erp_id_t      predetermined_erp_id)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};
    uint32_t          key_blocks_cnt = 0;
    uint8_t           i = 0, num_of_erps = 0;

    SX_LOG_ENTER();

    if (!rule || !found_matching_erp) {
        SX_LOG_ERR("atcam_erps_selector_find_matching_eRP: Null params were given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *found_matching_erp = FALSE;

    /* If the rule is predetermined to go to the TCAM return a no match */
    if (predetermined && (predetermined_erp_id >= SX_ATCAM_ERPS_PER_REGION)) {
        goto out;
    }

    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erps_ids, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_erps_memory_manager_array_get: while getting erps ids of region %d\n", rule->region_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_cnt_get(rule->region_id, &key_blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_erps_selector_find_matching_eRP: while getting key blocks count for region %d\n",
                   rule->region_id);
        goto out;
    }

    /* Note: In case the erp is predetermined we only check there is a match on that specific erp */
    if (num_of_erps) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if ((erps_ids[i] != ATCAM_INVALID_ERP_ID) && ((!predetermined) || (predetermined_erp_id == erps_ids[i]))) {
                sx_status = __check_match_on_erp(rule, key_blocks_cnt, erps_ids[i], found_matching_erp);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("__check_match_on_erp: while checking erp %u region %d\n",
                               erps_ids[i],
                               rule->region_id);
                    goto out;
                }
                if (*found_matching_erp) {
                    break;
                }
            }
        }
    } else {
        /*check rp*/
        if ((!predetermined) || (predetermined_erp_id == FIRST_ERP_ID)) {
            sx_status = __check_match_on_erp(rule, key_blocks_cnt, FIRST_ERP_ID, found_matching_erp);
            if (sx_status != SX_STATUS_SUCCESS) {
                if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
                    SX_LOG_ERR("__check_match_on_erp: while checking erp %u region %d\n",
                               FIRST_ERP_ID,
                               rule->region_id);
                    goto out;
                } else {
                    sx_status = SX_STATUS_SUCCESS;
                }
            }
        }
    }
    /* Do a sanity check that if the erp is predetermined it was indeed found in this lookup */
    if (predetermined && ((*found_matching_erp) == FALSE)) {
        SX_LOG_ERR("Failed to find a match on predetermined erp %u for region %d\n",
                   predetermined_erp_id,
                   rule->region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

boolean_t atcam_erps_selector_are_masks_delta_eq(const uint32_t              blocks_cnt,
                                                 const sx_atcam_mask_byte_t *erp_mask,
                                                 const sx_atcam_mask_byte_t *rule_mask,
                                                 boolean_t                  *ret_delta_found,
                                                 int                        *ret_delta_start)
{
    boolean_t delta_found = FALSE;
    int8_t    i_chunk = 0;
    int8_t    start_chunk = start_64bit_chunks[blocks_cnt];
    uint64_t  rule_chunk = 0, erp_chunk = 0;
    int       delta_start = 0, delta_end = 0, chunk_offset = 0;

    for (i_chunk = ATCAM_MAX_KEY_SIZE_64BIT; i_chunk >= start_chunk; i_chunk--, chunk_offset += DELTA_CHUNK_SIZE) {
        rule_chunk = ((uint64_t*)rule_mask)[i_chunk];
        erp_chunk = ((uint64_t*)erp_mask)[i_chunk];

        /* chunks are equal, nothing to check */
        if ((rule_chunk ^ erp_chunk) == 0) {
            continue;
        }
        /* In order for a rule's mask to be compatible with an erp, it has to have all the 1 bits set
         * in the erp set as well. The following checks for this condition and returns if not.
         */
        if ((rule_chunk & erp_chunk) ^ erp_chunk) {
            goto not_eq;
        }
        /* Get only the delta bits from now on */
        rule_chunk ^= erp_chunk;
        /* Bits are counted in network order by the hw */
        rule_chunk = cl_hton64(rule_chunk);

        /* calculate in the chunk the location of the first bit set and the last bit set */
        if (delta_found == FALSE) {
            delta_start = __builtin_ffsll(rule_chunk) + chunk_offset - 1;
        }
        delta_end = (DELTA_CHUNK_SIZE - 1) + chunk_offset - __builtin_clzll(rule_chunk);

        /* Check if the delta is bigger than a byte size */
        if (delta_end - delta_start >= BYTE_SIZE) {
            goto not_eq;
        }
        delta_found = TRUE;
    }

    if (ret_delta_found) {
        *ret_delta_found = delta_found;
    }
    if (ret_delta_start) {
        *ret_delta_start = delta_start;
    }

    return TRUE;

not_eq:
    return FALSE;
}

/************************************************
 *  Local Functions implementations
 ***********************************************/
static sx_status_t __atcam_erps_selector_is_rule_delta_eq_erp(const uint32_t             blocks_cnt,
                                                              const atcam_erps_db_erp_t *erp,
                                                              atcam_rules_db_rule_t     *rule,
                                                              boolean_t                 *delta_eq)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    int                                    delta_start = 0;
    int                                    delta_boundry = ATCAM_KEY_BLOCK_BIT_SIZE * blocks_cnt - BYTE_SIZE;
    boolean_t                              delta_found = FALSE;
    uint8_t                                delta_value = 0, delta_mask = 0;
    uint32_t                               bad_collision_count = 0, exact_match_count = 0, i = 0;
    sx_atcam_key_delta_t                   preserve_delta = {0};
    uint16_t                               preserve_erp_id = 0;
    atcam_erps_db_bad_collision_counters_t collision_counters;
    uint32_t                               accumulate_collisions = 0;
    double                                 collision_percentage = 0, collisions_allowed_percentage = 0;
    uint32_t                              *counters_p = NULL;

    /* We compare the key/erp mask in 64 bits chunks. Since key blocks 0 is at the end of the key
     * we do the search in reverse. We stop when we don't have any more blocks to search.
     */
    *delta_eq = FALSE;
    SX_MEM_CLR(collision_counters);

    /* Check if the rule's mask is compatible with the erp's */
    if (!atcam_erps_selector_are_masks_delta_eq(blocks_cnt,
                                                erp->mask.flex_mask_blocks,
                                                rule->key_value_blocks.flex_mask_blocks,
                                                &delta_found,
                                                &delta_start)) {
        goto out;
    }
    /* If we're here, the rule provided is compatible with the provided erp's mask.
     * We need to check if there is a bad collision with existing rules' values.
     */

    /* We preserve the rule here if the collision is detected and we need to abort. */
    preserve_delta = rule->delta;
    preserve_erp_id = rule->erp_id;

    if (delta_found) {
        /* Check that the delta_start did not overflow the key block boundaries */
        if (delta_start > delta_boundry) {
            delta_start = delta_boundry;
        }
        /* If we're here, a delta was found. We have its location in delta_start */
        delta_mask = atcam_utils_get_delta_byte(rule->key_value_blocks.flex_mask_blocks, delta_start);
        /* We want the delta to include only the changed bits from the erp mask */
        delta_mask ^= atcam_utils_get_delta_byte(erp->mask.flex_mask_blocks, delta_start);
        delta_value = atcam_utils_get_delta_byte(rule->key_value_blocks.flex_value_blocks, delta_start);

        rule->delta.delta_start = delta_start;
        rule->delta.delta_value = delta_value & delta_mask;
        rule->delta.delta_mask = delta_mask;
    }

    rule->erp_id = erp->erp_id;
    sx_status = atcam_erps_db_bad_collision_check(rule, &bad_collision_count, &exact_match_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__atcam_erps_selector_is_rule_delta_eq_erp: failed while checking erp %u region %d\n",
                   erp->erp_id, rule->region_id);
        goto revert_erp;
    }
    /* If not bad collision we can approve this erp */
    if (bad_collision_count == 0) {
        *delta_eq = TRUE;
    } else if (exact_match_count > 0) {    /* We have an exact match we can't insert it to this erp */
        goto revert_erp;
    } else {
        /* Get the current bad collision counters */
        sx_status = atcam_erps_db_bad_collision_counters_get(&collision_counters);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to get collision counters while checking erp %u region %d\n",
                       erp->erp_id, rule->region_id);
            goto revert_erp;
        }
        /* Go over all the counters and check if we can add another rule or not */
        if (bad_collision_count >= BAD_COLLISION_COUNTERS_NUM) {
            bad_collision_count = BAD_COLLISION_COUNTERS_NUM - 1;
        }
        /* Determine if we have a single or double collision */
        if (blocks_cnt > ATCAM_SINGLE_ENTRY_BLOCK_CNT) {
            counters_p = collision_counters.double_bad_collision_count;
            collisions_allowed_percentage =
                (double)allowed_bad_collsions.double_bad_collision_count[bad_collision_count];
        } else {
            counters_p = collision_counters.single_bad_collision_count;
            collisions_allowed_percentage =
                (double)allowed_bad_collsions.single_bad_collision_count[bad_collision_count];
        }
        /* Accumulate the number of rules that are relevant to this bad collision check */
        for (i = bad_collision_count; i < BAD_COLLISION_COUNTERS_NUM; i++) {
            accumulate_collisions += counters_p[i];
        }
        /* Add to the calculation the rule itself that will be added and the rules that will be move from group to group */
        accumulate_collisions += bad_collision_count + 1;
        /* Calculate the percentage of colliding rules in respect to the kvd_size */
        collision_percentage = (((double)accumulate_collisions * 100) / (double)rm_resource_global.kvd_size);
        /* Check if we can accept the bad collision or not according to the percentage of bad collisions*/
        if (collision_percentage < collisions_allowed_percentage) {
            *delta_eq = TRUE;
        } else {
            goto revert_erp;
        }
    }

    goto out;

revert_erp:
    /* Do not change the rule if this erp is not a match */
    rule->delta = preserve_delta;
    rule->erp_id = preserve_erp_id;
out:
    return sx_status;
}
