/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_MANAGER_H__
#define __ATCAM_ERPS_MANAGER_H__

#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"


/**
 * Initializes eRP manager module.
 * All modules related to this module (i.e. - DB, selector, threads-infra) are initialized as well,
 * and should NOT be initialized in any other way.
 *
 * @param[in]  num_of_region           - Number of regions that should be supported
 * @param[in]  num_of_erps             - num of erps that should be supported (across all regions)
 * @param[in]  shadow_region_create_cb - callback function for creating a shadow region
 * @param[in]  shadow_region_remove_cb - callback function for removing a shadow region
 *
 * @return
 *              SX_STATUS_SUCCESS - if operation was successful
 */
sx_status_t atcam_erps_manager_init(const uint32_t                      num_of_regions,
                                    const uint32_t                      num_of_erps,
                                    const atcam_shadow_region_create_cb shadow_region_create_cb,
                                    const atcam_shadow_region_remove_cb shadow_region_remove_cb);
/**
 *
 *  De-initializes eRP manager module.
 *  All modules related to this module (i.e. - DB, selector, threads-infra) are also de-initialized,
 *  and should NOT be de-initialized in any other way.
 *  @return
 *              SX_STATUS_SUCCESS - if operation was successful
 */
sx_status_t atcam_erps_manager_deinit(const boolean_t forced_deinit);


/**
 * Creates a new region.
 * This function must be called whenever a new region is created, regardless if this region will
 * have some erp or not.
 *
 * @param[in] region_id - Region ID
 * @param[in] num_of_erps - Number of eRPs within the region
 * @param[in] key_blocks_count - The number of key-block count supported in atcam
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_ERROR - if one of the parameters is invalid
 *         SX_STATUS_ERROR - if unexpected behavior occurs
 *         other return codes are not provided
 */
sx_status_t atcam_erps_manager_region_create(const sx_atcam_region_id_t       region_id,
                                             const uint8_t                    num_of_erps,
                                             const sx_atcam_key_blocks_size_t key_blocks_count);

/**
 * Destroys a region.
 *
 * @param[in] region_id - Region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         other return codes are not provided
 */
sx_status_t atcam_erps_manager_region_destroy(const sx_atcam_region_id_t region_id);

/**
 * Create an erp in the region with the provided mask.
 * Note: This function should be used in special circumstances like erp re-compilation
 * and not in the normal rule insert procedure.
 *
 * @param[in]  region_id        - Region ID
 * @param[in]  flex_mask_blocks - The mask of the newly created erp
 * @param[out] erp_id           - The erp_id of the newly created erp
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *
 */
sx_status_t atcam_erps_manager_erp_create(const sx_acl_region_id_t    region_id,
                                          const sx_atcam_mask_byte_t *flex_mask_blocks,
                                          sx_atcam_erp_id_t          *erp_id);
/**
 * Delete an erp from region_id.
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id    - eRP ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         other return codes are not provided
 */
sx_status_t atcam_erps_manager_erp_delete(const sx_atcam_region_id_t region_id,
                                          const sx_atcam_erp_id_t    erp_id);

/**
 * Clear all the erps from the region. The erps must be empty.
 *
 * @param[in] region_id - Region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_DB_NOT_EMPTY - if one of the erps is not empty
 */
sx_status_t atcam_erps_manager_clear_region_erps(const sx_atcam_region_id_t region_id);

/**
 * Generates dump for erp module
 */
sx_status_t atcam_erps_manager_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);


#endif /* __ATCAM_ERPS_MANAGER_H__ */
