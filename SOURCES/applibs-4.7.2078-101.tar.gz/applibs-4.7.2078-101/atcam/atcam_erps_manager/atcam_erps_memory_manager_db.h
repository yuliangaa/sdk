/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_MEMORY_MANAGER_DB_H__
#define __ATCAM_ERPS_MEMORY_MANAGER_DB_H__

#include <sx/sdk/sx_types.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_list.h>

#include "atcam/common/atcam_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam_erps_linear_manager.h"

/************************************************
 * Defines
 ***********************************************/
#define SX_ATCAM_ERPS_HW_INDEX_MAX 128
/************************************************
 *  Type definitions
 ***********************************************/
typedef sx_status_t (*region_offset_pfn)(const void *region_offset_context);
typedef sx_status_t (*erp_vector_pfn)(const void *erp_vector_context);

/**
 *  * The number of rows per key_block
 *   */
typedef enum atcam_erps_memory_manager_rows_per_key_block_count {
    ROWS_PER_ONE_KEY_BLOCK  = 1,
    ROWS_PER_FOUR_KEY_BLOCK = 2,
    ROWS_PER_SIX_KEY_BLOCK  = 3
} atcam_erps_memory_manager_rows_per_key_block_count_t;

typedef enum perpt_key_size {
    PERPT_KEY_SIZE_ONE_KEY_BLOCK  = 0,
    PERPT_KEY_SIZE_TWO_KEY_BLOCK  = 1,
    PERPT_KEY_SIZE_FOUR_KEY_BLOCK = 2,
    PERPT_KEY_SIZE_SIX_KEY_BLOCK  = 3
} perpt_key_size_t;

/************************************************
 *  Global definitions
 ***********************************************/
typedef struct atcam_erps_memory_manager_db_erp_data {
    sx_atcam_erp_id_t      erp_id;
    sx_atcam_key_mask_t    mask;
    sx_atcam_erp_index_t   erp_index;
    sx_atcam_bank_number_t erp_bank;
    boolean_t              bf_bypass;
    boolean_t              is_enabled;
} atcam_erps_memory_manager_db_erp_data_t;

typedef struct atcam_erps_memory_manager_db_entry {
    cl_pool_item_t                          pool_item;
    cl_map_item_t                           region_map_item; /* To allow per region access */
    sx_atcam_region_id_t                    region_id;
    sx_atcam_key_blocks_size_t              key_blocks_count; /* The number of key-block count supported in atcam */
    sx_atcam_erp_index_t                    first_erp_index;
    uint16_t                                block_size;
    uint8_t                                 allocated_erps;
    atcam_erps_memory_manager_db_erp_data_t erp_arr[SX_ATCAM_ERPS_PER_REGION];
    atcam_erps_linear_manager_handle_t      handle;
} atcam_erps_memory_manager_db_entry_t;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes erps memory manager DB.
 * The erps memory manager DB holds all the relevant data bases to erp memory manager:
 * Region and its eRPs.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_ERROR if unexpected behavior occurs
 *
 */
sx_status_t atcam_erps_memory_manager_db_init();

/**
 * De-Initializes DBs
 *
 * @param[in] forced_deinit - indicates a forced deinit
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_DB_NOT_EMPTY if erps memory manager DB is not empty
 *
 */
sx_status_t atcam_erps_memory_manager_db_deinit(const boolean_t forced_deinit);

/**
 * Set the region DB - If we've already created this region we'll update it.
 *                     Otherwise, we'll create a new one and set it with the params
 * @param[in] region_id - The region ID
 * @param[in] key_blocks_count - The number of key-block count supported in atcam
 * @param[in] first_erp_index - The index where the region begins
 * @param[in] block_size - Num of blocks that were allocated to the region
 *                          Every block is in key_blocks_count size
 * @param[in] allocated_erps - Num of eRPs that were allocated to this region
 * @param[in] handle - The handle of the region. We get it from the linear manager.
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_EXCEEDS_RANGE if one of the parameters exceeds range
 *         SX_STATUS_ERROR if unexpected behavior occurs
 *         SX_STATUS_NO_RESOURCES if pool cannot provide object
 *         SX_STATUS_MEMORY_ERROR if we fail while allocating new region from pool
 */
sx_status_t atcam_erps_memory_manager_db_region_set(const sx_atcam_region_id_t               region_id,
                                                    const sx_atcam_key_blocks_size_t         key_blocks_count,
                                                    const sx_atcam_erp_index_t               first_erp_index,
                                                    const uint8_t                            block_size,
                                                    const uint8_t                            allocated_erps,
                                                    const atcam_erps_linear_manager_handle_t handle);

/**
 * Add erp_id to region_id
 * Delete erp from region_id
 * Set the erp data
 *
 * @param[in] cmd - ADD/DELETE/SET
 * @param[in] region_id - The region ID
 * @param[in] erp_id - The eRP ID
 * @param[in] mask_p - The eRP mask
 * @param[in] erp_index - The eRP index in the linear table
 * @param[in] erp_offset - The eRP offset within the region
 * @param[in] is_erp_enable - Is eRP enable
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_EXCEEDS_RANGE if one of the parameters exceeds range
 *         SX_STATUS_PARAM_ERROR if key_blocks_counts in the region isn't valid
 *         SX_STATUS_CMD_UNSUPPORTED if cmd is not ADD/DELETE/SET
 */
sx_status_t atcam_erps_memory_manager_db_erp_set(const sxd_access_cmd_t      cmd,
                                                 const sx_atcam_region_id_t  region_id,
                                                 const sx_atcam_erp_id_t     erp_id,
                                                 const sx_atcam_key_mask_t  *mask_p,
                                                 const sx_atcam_erp_index_t  erp_index,
                                                 const sx_atcam_erp_offset_t erp_offset,
                                                 const boolean_t             is_erp_enable);

/**
 * Get the info of region ID
 *
 * @param[in] region_id - The region ID
 * @param[out]  region_entry_p - The region info
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND if region id wasn't found
 */
sx_status_t atcam_erps_memory_manager_db_region_get(const sx_atcam_region_id_t             region_id,
                                                    atcam_erps_memory_manager_db_entry_t **region_entry_p);

/**
 * Get the info of erp_id in region_id and its position
 *
 * @param[in] region_id - The region ID
 * @param[in] erp_id - The eRP ID
 * @param[out] erp_data_p - The erp info
 * @param[out] erp_pos_p - The erp position (offset)
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL if erp_data_p or erp_pos_p is NULL
 *         SX_STATUS_ENTRY_NOT_FOUND if erp id wasn't found in the region
 */
sx_status_t atcam_erps_memory_manager_db_erp_get(const sx_atcam_region_id_t               region_id,
                                                 const sx_atcam_erp_id_t                  erp_id,
                                                 atcam_erps_memory_manager_db_erp_data_t *erp_data_p,
                                                 sx_atcam_erp_offset_t                   *erp_offset_p);

/**
 * Get the erp array in region_id
 *
 * @param[in] region_id - Region ID
 * @param[out] erp_order_arr_p     - eRPs array.
 *                                   Array size should be, at lease: SX_ATCAM_ERPS_PER_REGION
 * @param[out] num_of_erps         - The num of enabled + disabled eRPs
 * @param[out] num_of_enabled_erps - The num of enabled ERPs
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL - if erp_order_arr_p == NULL
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_db_array_get(const sx_atcam_region_id_t region_id,
                                                   sx_atcam_erp_id_t         *erp_order_arr_p,
                                                   uint8_t                   *num_of_erps,
                                                   uint8_t                   *num_of_enabled_erps);

/**
 * Delete region_id from the DB
 *
 * @param[in] region_id - The region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *      SX_STATUS_RESOURCE_IN_USE if not all the erps in the region were deleted
 */
sx_status_t atcam_erps_memory_manager_db_region_delete(const sx_atcam_region_id_t region_id);

/**
 * alloc_one_row contains the number of rows (1,2,3) in linear table
 *  per key_blocks_count
 * @param[in] key_blocks_count
 * @param[out] alloc_one_row
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL if alloc_one_row is NULL
 *         SX_STATUS_ERROR if key_blocks_count is invalid
 */
sx_status_t atcam_erps_memory_manager_db_one_row_size_get(
    const sx_atcam_key_blocks_size_t                      key_blocks_size,
    atcam_erps_memory_manager_rows_per_key_block_count_t *alloc_one_row,
    perpt_key_size_t                                     *perpt_key_size);

/**
 * Returns the status of a given erp (by its id) of a specific region.
 * An erp can be either ERP_STATE_DISABLED or ERP_STATE_ENABLED
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id    - The erp to query
 * @param[in] state     - The state of the erp.
 *
 * @return SX_STATUS_SUCCESS             - if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND - if no such erp was defined for the given region
 *
 */
sx_status_t atcam_erps_memory_manager_db_erp_state_set(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            is_enabled);

/**
 * Set the erp bf_bypass if erp is enabled.
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id    - The erp to query
 * @param[in] bf_bypass - bf_bypass value.
 *
 * @return SX_STATUS_SUCCESS         - if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND - if no such erp was defined for the given region
 *
 */
sx_status_t atcam_erps_memory_manager_db_bf_bypass_set(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            bf_bypass);

/**
 * Generate the erps memory manager DB dump
 * @param[in,out] stream    - Dump data
 * @param[in]     dump_all  - Dump all regions (TRUE) or the specified region_id (FALSE)
 * @param[in]     region_id - The region id to dump (ignored if dump_all is TRUE)
 * @return SX_STATUS_SUCCESS
 */
sx_status_t atcam_erps_memory_manager_db_dbg_generate_dump(dbg_dump_params_t         *dbg_dump_params_p,
                                                           const boolean_t            dump_all,
                                                           const sx_atcam_region_id_t region_id);

#endif /*__ATCAM_ERPS_MEMORY_MANAGER_DB_H__ */
