/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_MEMORY_MANAGER_H__
#define __ATCAM_ERPS_MEMORY_MANAGER_H__

#include "sx/sdk/sx_types.h"
#include "sx/utils/linear_manager.h"
#include "atcam/atcam_erps_manager/atcam_erps_linear_manager.h"
#include "atcam/atcam_regions_manager/atcam_regions_manager.h"
#include "sx/sdk/sx_api.h"
#include "atcam/common/atcam_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam_erps_memory_manager_db.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define FIRST_BANK_NUM   0
#define FIRST_ERP_ID     0
#define FIRST_ERP_OFFSET 0
/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef sx_status_t (*atcam_erps_memory_manager_region_cb_t)(const sx_acl_region_id_t region_id,
                                                             atcam_region_erp_data_t *region_erp_data);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes eRPs memory manager module.
 *
 * The eRPs memory manager connects between the eRP manager and .
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_ALREADY_INITIALIZED if the module already initialized
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_init(atcam_erps_memory_manager_region_cb_t region_cb);

/**
 * De-Initializes eRPs memory manager module.
 *
 * @param[in] forced_deinit - indicates a forced deinit
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_MODULE_UNINITIALIZED if the module is uninitialized and
 *                                        forced_deinit = FALSE
 *         other return codes are not provided
 *
 */
sx_status_t atcam_erps_memory_manager_deinit(const boolean_t forced_deinit);

/**
 * Init region with the number of eRPS within the region and
 * the number of key-block count supported in atcam
 *
 * @param[in] region_id - Region ID
 * @param[in] num_of_erps - Number of eRPs within the region
 * @param[in] key_blocks_size - The number of key-block count supported in atcam
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_ERROR - if one of the parameters is invalid
 *         SX_STATUS_ERROR - if unexpected behavior occurs
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_region_create(const sx_atcam_region_id_t       region_id,
                                                    const uint8_t                    num_of_erps,
                                                    const sx_atcam_key_blocks_size_t key_blocks_size);

/**
 * Remove the erps allocated for a specific region
 * @param[in] region_id - Region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *
 */
sx_status_t atcam_erps_memory_manager_clear_region_erps(const sx_atcam_region_id_t region_id);


/**
 * Delete the region and its DB
 * @param[in] region_id - Region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_DB_NOT_EMPTY if region is not empty from erps
 *         other return codes are not provided
 *
 */
sx_status_t atcam_erps_memory_manager_region_destroy(const sx_atcam_region_id_t region_id);


/**
 * Add erp to region
 *
 * @param[in] region_id - Region ID
 * @param[in, out] erp_id - eRP ID. If erp_id == ATCAM_INVALID_ERP_ID
 *                          the function will return the eRP ID
 * @param[in] mask_p - The eRP mask
 * @param[in] erp_offset - eRP offset. If erp_id == ATCAM_INVALID_ERP_ID
 *                              this parameter is unused
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL - if erp_id_p or mask_p are NULL
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - if the value of erp_id or erp_offset exceeds range,
 *                                         or the region is full.
 *         SX_STATUS_PARAM_ERROR - if erp id or erp offset are in use
 *         SX_STATUS_ERROR - if unexpected behavior occurs
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_erp_add(const sx_atcam_region_id_t  region_id,
                                              sx_atcam_erp_id_t          *erp_id_p,
                                              const sx_atcam_key_mask_t  *mask_p,
                                              const sx_atcam_erp_offset_t erp_offset);

/**
 * Delete erp_id from the region
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id - eRP ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - if erp_id >= SX_ATCAM_ERPS_PER_REGION
 *         other return codes are not provided
 *
 */
sx_status_t atcam_erps_memory_manager_erp_delete(const sx_atcam_region_id_t region_id,
                                                 const sx_atcam_erp_id_t    erp_id);

/**
 * Get the bank and offset of the erp_id in region_id
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id - eRP ID
 * @param[out] bank_p - Bank number
 * @param[out] erp_offset_p - erp offset in erp array
 *
 * @return  SX_STATUS_SUCCESS if operation completes successfully
 *          SX_STATUS_PARAM_NULL - if bank_p == NULL
 *          SX_STATUS_PARAM_EXCEEDS_RANGE - if erp_id >= SX_ATCAM_ERPS_PER_REGION
 *          other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_attr_get(const sx_atcam_region_id_t region_id,
                                               const sx_atcam_erp_id_t    erp_id,
                                               sx_atcam_bank_number_t    *bank_p,
                                               sx_atcam_erp_offset_t     *erp_offset_p);

/**
 * Get the erp array in region_id
 *
 * @param[in] region_id - Region ID
 * @param[out] erp_order_arr_p     - eRPs array.
 *                                   Array size should be, at lease: SX_ATCAM_ERPS_PER_REGION
 * @param[out] num_of_erps         - The num of enabled + disabled eRPs
 * @param[out] num_of_enabled_erps - The num of enabled ERPs
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL - if erp_order_arr_p == NULL
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_array_get(const sx_atcam_region_id_t region_id,
                                                sx_atcam_erp_id_t         *erp_order_arr_p,
                                                uint8_t                   *num_of_erps,
                                                uint8_t                   *num_of_enabled_erps);

/**
 * Create region_id with erp_id (in erp_id_p).
 * The main purpose of this function is to reproduce a region from the
 * persistent DB.
 *
 * @param[in] region_id - Region ID
 * @param[in] blocks_size - The number of key-block count supported in atcam
 * @param[in] num_of_erps - Number of eRPs in erp_id_p array
 * @param[in,out] erp_id_p - erp_id array
 * @param[in] mask_p - The eRP mask array according to erp_id array
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL if erp_id_p or mask_p  are NULL
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - if num_of_erps >= SX_ATCAM_ERPS_PER_REGION
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_predefined_region_create(const sx_atcam_region_id_t       region_id,
                                                               const sx_atcam_key_blocks_size_t blocks_size,
                                                               sx_atcam_erp_id_t               *erp_id_p,
                                                               const sx_atcam_key_mask_t       *mask_p);


/**
 * Replaces region erps with a new set of (ordered) erps. The bank of each erp is concluded from the order.
 * Note that a new allocation is required for this update, so this function might fail due to low resources.
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id_p - erp_id array - function assumes its size if SX_ATCAM_ERPS_PER_REGION
 * @param[in] mask_p - The eRP mask array according to erp_id array
 * @param[in] erps_enabled - eRPs enabled state.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         SX_STATUS_PARAM_NULL if erp_id_p or mask_p are NULL
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - if num_of_erps >= SX_ATCAM_ERPS_PER_REGION
 *         other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_region_update(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t   *erp_id_p,
                                                    const sx_atcam_key_mask_t *mask_p,
                                                    const boolean_t           *erps_enabled);
/**
 * Update the perpt register with erp_data
 *
 * @param[in] erp_id - eRP ID
 * @param[in] mask_p - eRP mask
 * @param[in] erp_index -eRP index in linear table
 * @param[in] erp_bank - eRP bank in linear table
 * @param[in] bf_bypass - eRP Bloom filter bypass
 * @param[in] key_blocks_count - The number of key-block count supported in atcam
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *                           other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_erp_hw_update(const sx_atcam_erp_id_t          erp_id,
                                                    const sx_atcam_key_mask_t       *mask_p,
                                                    const sx_atcam_erp_index_t       erp_index,
                                                    const sx_atcam_bank_number_t     erp_bank,
                                                    const boolean_t                  bf_bypass,
                                                    const sx_atcam_key_blocks_size_t key_blocks_size,
                                                    const uint8_t                    erp_index_in_vector,
                                                    const uint16_t                   erp_vector,
                                                    const sx_atcam_erp_index_t       erp_base_index,
                                                    const sx_atcam_bank_number_t     erp_base_bank);

/**
 * Returns the status of a given erp (by its id) of a specific region.
 * An erp can be either enabled(TRUE) or disabled(FALSE)
 *
 * @param[in] region_id      - Region ID
 * @param[in] erp_id         - The erp to query
 * @param[in] is_enabled     - TRUE for enable, FALSE for disable erp.
 *
 * @return SX_STATUS_SUCCESS         - if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND - if no such erp was defined for the given region
 *
 */
sx_status_t atcam_erps_memory_manager_erp_state_set(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t    erp_id,
                                                    const boolean_t            is_enabled);

/**
 * Returns the status of a given erp (by its id) of a specific region.
 * An erp can be either enabled(TRUE) or disabled(FALSE)
 *
 * @param[in] region_id      - Region ID
 * @param[in] erp_id         - The erp to query
 * @param[out] is_enabled_p  - Return TRUE for enable, FALSE for disable erp.
 *
 * @return SX_STATUS_SUCCESS         - if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND - if no such erp was defined for the given region
 *
 */

sx_status_t atcam_erps_memory_manager_erp_state_get(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t    erp_id,
                                                    boolean_t                 *is_enabled_p);

/**
 * The function will update all the PEREPT registers of the erp in region_id
 * @param[in] region_id - Region ID
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *                           other return codes are not provided
 */
sx_status_t atcam_erps_memory_manager_hw_update(const sx_atcam_region_id_t region_id);

/**
 * Set the erp bf_bypass if erp is enabled.
 *
 * @param[in] region_id - Region ID
 * @param[in] erp_id    - The erp to query
 * @param[in] bf_bypass - bf_bypass value.
 *
 * @return SX_STATUS_SUCCESS         - if operation completes successfully
 *         SX_STATUS_ENTRY_NOT_FOUND - if no such erp was defined for the given region
 *
 */
sx_status_t atcam_erps_memory_manager_bf_bypass_update(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            bf_bypass);

/**
 *  This function generates debug data dump for eRPs memory manager
 *
 * @param[in] stream - output stream
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR in case of error
 *
 */
sx_status_t atcam_erps_memory_manager_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

/**
 *  This function update the bank counters to rule the bank assignment
 *
 * @param[in] is_add - add to erp_bank
 * @param[in] erp_bank - The eRP's bank
 *
 */
void atcam_erps_memory_manager_banks_counters_update(const boolean_t              is_add,
                                                     const sx_atcam_bank_number_t erp_bank);


#endif /* __ATCAM_ERPS_MEMORY_MANAGER_H__ */
