/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_dbg.h>
#include <complib/sx_log.h>
#include <complib/cl_map.h>
#include "complib/cl_fcntl.h"
#include <sx/utils/sx_utils_status.h>
#include <utils/utils.h>
#include <sx/utils/debug_cmd.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sdk/sx_status_convertor.h>
#include <sx/sxd/sxd_access_register.h>

#include <atcam/common/atcam_types.h>
#include "atcam/atcam_regions_manager/atcam_regions_db.h"
#include "atcam/atcam_regions_manager/atcam_regions_manager.h"
#include "atcam_erps_db.h"
#include "atcam_erps_memory_manager_db.h"
#include "atcam_erps_linear_manager.h"
#include "issu/issu.h"

/************************************************
 *  Global variables
 ***********************************************/
static sx_atcam_erp_index_t g_atcam_erps_hw_index_min = 0;
static sx_atcam_erp_index_t g_atcam_erps_hw_index_max = SX_ATCAM_ERPS_HW_INDEX_MAX;

/************************************************
 *  Local definitions
 ***********************************************/
#define EPRS_MEMORY_MANAGER_POOL_MIN_SIZE  0
#define EPRS_MEMORY_MANAGER_POOL_MAX_SIZE  0
#define EPRS_MEMORY_MANAGER_POOL_GROW_SIZE 1000

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t g_erps_memory_manager_pool;
static cl_qmap_t  g_erps_memory_manager_map;


/************************************************
 *  Local function declarations
 ***********************************************/
static void __atcam_erps_memory_manager_db_regions_erp_debug_cmd(FILE       *stream,
                                                                 int         argc,
                                                                 const char *argv[],
                                                                 void       *handler_context);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t atcam_erps_memory_manager_db_init()
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    cl_status_t    cl_status = CL_SUCCESS;
    sx_boot_mode_e issu_boot_mode;
    sx_issu_bank_e issu_bank;

    SX_LOG_ENTER();

    cl_status = CL_QPOOL_INIT(&g_erps_memory_manager_pool,
                              EPRS_MEMORY_MANAGER_POOL_MIN_SIZE,
                              EPRS_MEMORY_MANAGER_POOL_MAX_SIZE,
                              EPRS_MEMORY_MANAGER_POOL_GROW_SIZE,
                              sizeof(atcam_erps_memory_manager_db_entry_t), NULL, NULL, NULL);

    if (cl_status != CL_SUCCESS) {
        sx_status = cl_status_to_sx_status(cl_status);
        SX_LOG_ERR("Failed to initialize erps memory manager qpool (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    cl_qmap_init(&g_erps_memory_manager_map);

    sx_utils_debug_cmd_register_path("atcam erp get region <id>",
                                     __atcam_erps_memory_manager_db_regions_erp_debug_cmd,
                                     (void*)FALSE);
    sx_utils_debug_cmd_register_path("atcam erp get region all",
                                     __atcam_erps_memory_manager_db_regions_erp_debug_cmd,
                                     (void*)TRUE);

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }
    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        sx_status = issu_bank_get(&issu_bank);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to issu_bank_get sx_status = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }
        g_atcam_erps_hw_index_max = (SX_ATCAM_ERPS_HW_INDEX_MAX / 2) * (1 + issu_bank);
        g_atcam_erps_hw_index_min = (SX_ATCAM_ERPS_HW_INDEX_MAX / 2) * issu_bank;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_deinit(const boolean_t forced_deinit)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t                        *map_item_p = NULL;
    const cl_map_item_t                  *map_end_p = NULL;
    atcam_erps_memory_manager_db_entry_t *region_entry = NULL;


    SX_LOG_ENTER();

    if (cl_is_qpool_inited(&g_erps_memory_manager_pool)) {
        /* Clear erps memory manager DB */
        map_item_p = cl_qmap_head(&g_erps_memory_manager_map);
        map_end_p = cl_qmap_end(&g_erps_memory_manager_map);
        if ((FALSE == forced_deinit) && (map_item_p != map_end_p)) {
            sx_status = SX_STATUS_DB_NOT_EMPTY;
            SX_LOG_ERR("Failed to deinit erps memory manager DB, there are still entries allocated\n");
            goto out;
        }

        while (map_item_p != map_end_p) {
            region_entry = PARENT_STRUCT(map_item_p, atcam_erps_memory_manager_db_entry_t, region_map_item);
            map_item_p = cl_qmap_next(map_item_p);

            cl_qmap_remove_item(&g_erps_memory_manager_map, &region_entry->region_map_item);
            cl_qpool_put(&g_erps_memory_manager_pool, &region_entry->pool_item);
        }

        CL_QPOOL_DESTROY(&g_erps_memory_manager_pool);

        sx_utils_debug_cmd_unregister_path("atcam erp");
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_region_set(const sx_atcam_region_id_t               region_id,
                                                    const sx_atcam_key_blocks_size_t         key_blocks_count,
                                                    const sx_atcam_erp_index_t               first_erp_index,
                                                    const uint8_t                            block_size,
                                                    const uint8_t                            allocated_erps,
                                                    const atcam_erps_linear_manager_handle_t handle)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry = NULL;
    cl_pool_item_t                                      *pool_item = NULL;
    cl_map_item_t                                       *region_map_item = NULL;
    uint8_t                                              i = 0;
    sx_atcam_erp_id_t                                    erp_order_arr[SX_ATCAM_ERPS_PER_REGION] = {0};
    uint8_t                                              num_of_enabled_erps = 0;
    atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
    boolean_t                                            update_bf = FALSE;


    SX_LOG_ENTER();


    sx_status = atcam_erps_memory_manager_db_one_row_size_get(key_blocks_count,
                                                              &rows_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (allocated_erps > 0) {
        if (((first_erp_index + rows_per_key_block) > g_atcam_erps_hw_index_max) ||
            (first_erp_index < g_atcam_erps_hw_index_min)) {
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("first_erp_index %d exceeds range\n", first_erp_index);
            goto out;
        }
    }

    if (allocated_erps > SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("Allocated erps %d out of range\n", allocated_erps);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    region_map_item = cl_qmap_get(&g_erps_memory_manager_map, region_id);
    if (region_map_item == cl_qmap_end(&g_erps_memory_manager_map)) {
        pool_item = cl_qpool_get(&g_erps_memory_manager_pool);
        if (pool_item == NULL) {
            SX_LOG_ERR("There are no more resources for region %d\n", region_id);
            sx_status = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        region_entry = PARENT_STRUCT(pool_item, atcam_erps_memory_manager_db_entry_t, pool_item);
        if (!region_entry) {
            sx_status = SX_STATUS_MEMORY_ERROR;
            SX_LOG(SX_LOG_ERROR, "Error while allocating new region from pool\n");
            goto out;
        }

        cl_qmap_insert(&g_erps_memory_manager_map, region_id, &(region_entry->region_map_item));

        region_entry->region_id = region_id;
        region_entry->key_blocks_count = key_blocks_count;
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
            SX_MEM_CLR(region_entry->erp_arr[i]);
            region_entry->erp_arr[i].erp_id = ATCAM_INVALID_ERP_ID;
        }
        region_entry->allocated_erps = 0;
    } else {
        region_entry = PARENT_STRUCT(region_map_item, atcam_erps_memory_manager_db_entry_t, region_map_item);
        region_entry->allocated_erps = allocated_erps;
    }

    region_entry->handle = handle;
    region_entry->first_erp_index = first_erp_index;
    region_entry->block_size = block_size;


    sx_status = atcam_erps_memory_manager_db_array_get(region_id, erp_order_arr, NULL, &num_of_enabled_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error while try to get region %d erps array\n", region_entry->region_id);
        goto out;
    }

    /* If we have more than MIN_ERPS_FOR_BF enabled eRPS so the bf_bypass = FALSE */
    sx_status = atcam_utils_need_to_update_bf(num_of_enabled_erps, &update_bf);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update res_index for"
                   " to region %d. [%s]\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        if ((region_entry->erp_arr[i].erp_id != ATCAM_INVALID_ERP_ID) &&
            (region_entry->erp_arr[i].is_enabled)) {
            sx_status = atcam_erps_memory_manager_db_bf_bypass_set(region_id,
                                                                   region_entry->erp_arr[i].erp_id,
                                                                   !update_bf);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed update erp memory manger db bf_bypass for erp_id = %u region = %u err %s\n",
                           region_entry->erp_arr[i].erp_id, region_id, sx_status_str(sx_status));
                goto out;
            }
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_erp_set(const sxd_access_cmd_t      cmd,
                                                 const sx_atcam_region_id_t  region_id,
                                                 const sx_atcam_erp_id_t     erp_id,
                                                 const sx_atcam_key_mask_t  *mask_p,
                                                 const sx_atcam_erp_index_t  erp_index,
                                                 const sx_atcam_erp_offset_t erp_offset,
                                                 const boolean_t             is_erp_enable)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
    sx_atcam_erp_id_t                                    erp_order_arr[SX_ATCAM_ERPS_PER_REGION] = {0};
    uint8_t                                              old_num_of_erps = 0, new_num_of_erps = 0;
    uint8_t                                              i = 0;
    boolean_t                                            is_add_erp = FALSE;
    boolean_t                                            update_all_bf_bypass = FALSE, bf_bypass = FALSE;

    SX_LOG_ENTER();

    switch (cmd) {
    case SXD_ACCESS_CMD_ADD:
    case SXD_ACCESS_CMD_DELETE:
        if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
            SX_LOG_ERR("erp_id %d given exceeds range.\n", erp_id);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        break;

    case SXD_ACCESS_CMD_SET:
        if (erp_id > SX_ATCAM_ERPS_PER_REGION) {     /*erp_id could be INVALID*/
            SX_LOG_ERR("erp_id %d given exceeds range.\n", erp_id);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        break;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported cmd\n");
        goto out;
    }

    if (erp_offset >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("eRP offset %d out of range\n", erp_offset);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region_id %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_array_get(region_id, erp_order_arr, NULL, &old_num_of_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error while try to get region %d erps array\n", region_id);
        goto out;
    }

    if ((cmd == SXD_ACCESS_CMD_ADD) || (cmd == SXD_ACCESS_CMD_SET)) {
        sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                                  &rows_per_key_block, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        if (erp_id != ATCAM_INVALID_ERP_ID) {
            if (((erp_index + rows_per_key_block) > g_atcam_erps_hw_index_max) ||
                (erp_index < g_atcam_erps_hw_index_min)) {
                sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
                SX_LOG_ERR("erp_index %d exceeds range\n", erp_index);
                goto out;
            }
        }
        region_entry_p->erp_arr[erp_offset].erp_id = erp_id;
        region_entry_p->erp_arr[erp_offset].erp_bank = erp_offset % ATCAM_NUM_OF_BANKS;
        region_entry_p->erp_arr[erp_offset].erp_index =
            (erp_id != ATCAM_INVALID_ERP_ID) ? erp_index : ATCAM_INVALID_ERP_INDEX;
        region_entry_p->erp_arr[erp_offset].is_enabled = is_erp_enable;
        if (cmd == SXD_ACCESS_CMD_ADD) {
            region_entry_p->allocated_erps = region_entry_p->allocated_erps + 1;
            if (mask_p == NULL) {
                sx_status = SX_STATUS_PARAM_NULL;
                SX_LOG_ERR("mask_p is NULL\n");
                goto out;
            }
        }
        if ((cmd == SXD_ACCESS_CMD_SET) && (mask_p == NULL)) {
            SX_MEM_CLR(region_entry_p->erp_arr[erp_offset].mask);
        } else {
            if (&(region_entry_p->erp_arr[erp_offset].mask) != mask_p) {
                memcpy(&(region_entry_p->erp_arr[erp_offset].mask), mask_p, sizeof(sx_atcam_key_mask_t));
            }
        }
        if (is_erp_enable) {
            is_add_erp = TRUE;
        }
    } else if (cmd == SXD_ACCESS_CMD_DELETE) {
        /*Check erp_id given is the same as expected */
        if (region_entry_p->erp_arr[erp_offset].erp_id != erp_id) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("erp_id doesn't match to erp_offset \n");
            goto out;
        }
        memset(&(region_entry_p->erp_arr[erp_offset]), 0, sizeof(region_entry_p->erp_arr[erp_offset]));
        region_entry_p->erp_arr[erp_offset].erp_id = ATCAM_INVALID_ERP_ID;
        region_entry_p->allocated_erps = region_entry_p->allocated_erps - 1;
        region_entry_p->erp_arr[erp_offset].is_enabled = is_erp_enable;
        SX_MEM_CLR(region_entry_p->erp_arr[erp_offset].mask);
    }

    /*
     * Now we have 2 option:
     * 1. If we moved from less than MIN_ERPS_FOR_BF enabled eRPS to
     *    MIN_ERPS_FOR_BF enabled eRPs , we need to change all the eRPs bf_bypass to FALSE.
     * 2. If we moved from  MIN_ERPS_FOR_BF enabled eRPS to less than
     *    MIN_ERPS_FOR_BF enabled eRPs , we need to change all the eRPs bf_bypass to TRUE.
     */
    sx_status = atcam_erps_memory_manager_db_array_get(region_id, erp_order_arr, NULL, &new_num_of_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error while try to get region %d erps array\n", region_id);
        goto out;
    }


    sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_erps,
                                                       new_num_of_erps,
                                                       is_add_erp,
                                                       &update_all_bf_bypass,
                                                       &bf_bypass);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update bf in bulk. [%s].\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (update_all_bf_bypass) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
            if (erp_order_arr[i] != ATCAM_INVALID_ERP_ID) {
                sx_status = atcam_erps_memory_manager_db_bf_bypass_set(region_id, erp_order_arr[i], bf_bypass);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("failed update erp memory manger db bf_bypass for erp_id = %u region = %u err %s\n",
                               erp_order_arr[i], region_id, sx_status_str(sx_status));
                    goto out;
                }
            }
        }
    } else {
        region_entry_p->erp_arr[erp_offset].bf_bypass = bf_bypass;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_region_get(const sx_atcam_region_id_t             region_id,
                                                    atcam_erps_memory_manager_db_entry_t **region_entry_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t *region_map_item = NULL;

    SX_LOG_ENTER();

    region_map_item = cl_qmap_get(&g_erps_memory_manager_map, region_id);
    if (region_map_item == cl_qmap_end(&g_erps_memory_manager_map)) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (region_entry_p) {
        *region_entry_p = PARENT_STRUCT(region_map_item, atcam_erps_memory_manager_db_entry_t, region_map_item);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_erp_get(const sx_atcam_region_id_t               region_id,
                                                 const sx_atcam_erp_id_t                  erp_id,
                                                 atcam_erps_memory_manager_db_erp_data_t *erp_data_p,
                                                 sx_atcam_erp_offset_t                   *erp_offset_p)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;
    uint16_t                              i;

    SX_LOG_ENTER();


    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        if (region_entry_p->erp_arr[i].erp_id == erp_id) {
            memcpy(erp_data_p, &(region_entry_p->erp_arr[i]), sizeof(atcam_erps_memory_manager_db_erp_data_t));
            *erp_offset_p = i;
            goto out;
        }
    }

    sx_status = SX_STATUS_ENTRY_NOT_FOUND;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_array_get(const sx_atcam_region_id_t region_id,
                                                   sx_atcam_erp_id_t         *erp_order_arr_p,
                                                   uint8_t                   *num_of_erps,
                                                   uint8_t                   *num_of_enabled_erps)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;
    uint8_t                               i = 0;

    SX_LOG_ENTER();


    if (num_of_erps) {
        *num_of_erps = 0;
    }

    if (num_of_enabled_erps) {
        *num_of_enabled_erps = 0;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d err = [%s]\n", region_id
                   , sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        erp_order_arr_p[i] = region_entry_p->erp_arr[i].erp_id;
        if (erp_order_arr_p[i] != ATCAM_INVALID_ERP_ID) {
            if (num_of_erps) {
                *num_of_erps += 1;
            }
            if (region_entry_p->erp_arr[i].is_enabled == TRUE) {
                if (num_of_enabled_erps) {
                    *num_of_enabled_erps += 1;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_region_delete(const sx_atcam_region_id_t region_id)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    if (region_entry_p->allocated_erps != 0) {
        SX_LOG_ERR("Region %d is not empty(%s)\n"
                   , region_id, sx_status_str(sx_status));
        goto out;
    }

    cl_qmap_remove(&g_erps_memory_manager_map, region_entry_p->region_id);
    cl_qpool_put(&g_erps_memory_manager_pool, &region_entry_p->pool_item);


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_one_row_size_get(
    const sx_atcam_key_blocks_size_t                      key_blocks_size,
    atcam_erps_memory_manager_rows_per_key_block_count_t *rows_per_key_block,
    perpt_key_size_t                                     *perpt_key_size)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (rows_per_key_block == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("rows_per_key_block is NULL\n");
        goto out;
    }

    switch (key_blocks_size) {
    case SX_ATCAM_ONE_KEY_BLOCK:
        *rows_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
        if (perpt_key_size != NULL) {
            *perpt_key_size = PERPT_KEY_SIZE_ONE_KEY_BLOCK;
        }
        break;

    case SX_ATCAM_TWO_KEY_BLOCKS:
        *rows_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
        if (perpt_key_size != NULL) {
            *perpt_key_size = PERPT_KEY_SIZE_TWO_KEY_BLOCK;
        }
        break;

    case SX_ATCAM_FOUR_KEY_BLOCKS:
        *rows_per_key_block = ROWS_PER_FOUR_KEY_BLOCK;
        if (perpt_key_size != NULL) {
            *perpt_key_size = PERPT_KEY_SIZE_FOUR_KEY_BLOCK;
        }
        break;

    case SX_ATCAM_SIX_KEY_BLOCKS:
        *rows_per_key_block = ROWS_PER_SIX_KEY_BLOCK;
        if (perpt_key_size != NULL) {
            *perpt_key_size = PERPT_KEY_SIZE_SIX_KEY_BLOCK;
        }
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid key_blocks_count\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_erp_state_set(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            is_enabled)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t   *region_entry_p = NULL;
    atcam_erps_memory_manager_db_erp_data_t erp_entry;
    sx_atcam_erp_offset_t                   erp_offset;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_erp_get(region_id,
                                                     erp_id,
                                                     &erp_entry,
                                                     &erp_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    region_entry_p->erp_arr[erp_offset].is_enabled = is_enabled;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_bf_bypass_set(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            bf_bypass)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t   *region_entry_p = NULL;
    atcam_erps_memory_manager_db_erp_data_t erp_entry;
    sx_atcam_erp_offset_t                   erp_offset;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_erp_get(region_id,
                                                     erp_id,
                                                     &erp_entry,
                                                     &erp_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    region_entry_p->erp_arr[erp_offset].bf_bypass = bf_bypass;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_db_dbg_generate_dump(dbg_dump_params_t         *dbg_dump_params_p,
                                                           const boolean_t            dump_all,
                                                           const sx_atcam_region_id_t region_id)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    uint32_t                              i = 0;
    const char                           *erp_invalid = NULL;
    char                                  snum[3 * SX_ATCAM_ERPS_PER_REGION];
    uint8_t                               erpt_vector[SX_ATCAM_ERPS_PER_REGION];
    cl_map_item_t                        *region_map_item = NULL;
    const cl_map_item_t                  *region_map_end = NULL;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;
    atcam_erps_db_erp_t                  *erp = NULL;
    unsigned int                          data_len = 0;
    dbg_utils_table_tlv_field_t           mask[7];
    dbg_utils_table_columns_t             erps_memory_manager_dump_clmns[] = {
        { "Region ID", 9, PARAM_UINT32_E, NULL},
        { "HW Index", 9, PARAM_UINT32_E, NULL},
        { "Block size", 15, PARAM_UINT16_E, NULL},
        { "eRP 0", 5, PARAM_STRING_E, NULL},
        { "eRP 1", 5, PARAM_STRING_E, NULL},
        { "eRP 2", 5, PARAM_STRING_E, NULL},
        { "eRP 3", 5, PARAM_STRING_E, NULL},
        { "eRP 4", 5, PARAM_STRING_E, NULL},
        { "eRP 5", 5, PARAM_STRING_E, NULL},
        { "eRP 6", 5, PARAM_STRING_E, NULL},
        { "eRP 7", 5, PARAM_STRING_E, NULL},
        { "eRP 8", 5, PARAM_STRING_E, NULL},
        { "eRP 9", 5, PARAM_STRING_E, NULL},
        { "eRP 10", 6, PARAM_STRING_E, NULL},
        { "eRP 11", 6, PARAM_STRING_E, NULL},
        { "eRP 12", 6, PARAM_STRING_E, NULL},
        { "eRP 13", 6, PARAM_STRING_E, NULL},
        { "eRP 14", 6, PARAM_STRING_E, NULL},
        { "eRP 15", 6, PARAM_STRING_E, NULL},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t             erps_dump_columns[] = {
        { "Region ID",      9,     PARAM_UINT32_E,      NULL},  /* 0 */
        { "ERP ID",         6,     PARAM_UINT8_E,       NULL }, /* 1 */
        { "ERP Index",      9,     PARAM_UINT32_E,       NULL }, /* 2 */
        { "ERP Bank",       8,     PARAM_UINT8_E,       NULL }, /* 3 */
        { "BF bypass",      9,     PARAM_BOOL_E,       NULL }, /* 4 */
        { "Is enabled",     10,     PARAM_BOOL_E,        NULL }, /* 5 */
        { "mask0",           24,     PARAM_HEX_STRING_E,     NULL}, /* 6 */
        { "mask1",           24,     PARAM_HEX_STRING_E,     NULL}, /* 7 */
        { "mask2",           24,     PARAM_HEX_STRING_E,     NULL}, /* 8 */
        { "mask3",           24,     PARAM_HEX_STRING_E,     NULL}, /* 9 */
        { "mask4",           24,     PARAM_HEX_STRING_E,     NULL}, /* 10 */
        { "mask5",           24,     PARAM_HEX_STRING_E,     NULL}, /* 11 */
        { "mask6",           24,     PARAM_HEX_STRING_E,     NULL}, /* 12 */
        {NULL, 0, 0, NULL}
    };
    FILE                                 *stream = NULL;

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    erp_invalid = "X";

    dbg_utils_pprinter_general_header_print(stream, "eRPs memory manager");
    dbg_utils_pprinter_table_headline_print(stream, erps_memory_manager_dump_clmns);

    region_map_item = cl_qmap_head(&g_erps_memory_manager_map);
    region_map_end = cl_qmap_end(&g_erps_memory_manager_map);
    while (region_map_item != region_map_end) {
        memset(erpt_vector, ATCAM_INVALID_ERP_ID, sizeof(erpt_vector));
        memset(snum, 0, sizeof(snum));
        region_entry_p = PARENT_STRUCT(region_map_item, atcam_erps_memory_manager_db_entry_t, region_map_item);
        /* Only dump the specified region id or all of them */
        if (dump_all || (region_id == region_entry_p->region_id)) {
            for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
                if (region_entry_p->erp_arr[i].erp_id != ATCAM_INVALID_ERP_ID) {
                    erpt_vector[i] = region_entry_p->erp_arr[i].erp_id;
                }
            }

            erps_memory_manager_dump_clmns[0].data = &(region_entry_p->region_id);
            erps_memory_manager_dump_clmns[1].data = &(region_entry_p->first_erp_index);
            erps_memory_manager_dump_clmns[2].data = &(region_entry_p->block_size);
            for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
                if (erpt_vector[i] != ATCAM_INVALID_ERP_ID) {
                    snprintf((snum + (3 * i)), 3, "%d", erpt_vector[i]);
                    erps_memory_manager_dump_clmns[i + 3].data = snum + (3 * i);
                } else {
                    erps_memory_manager_dump_clmns[i + 3].data = erp_invalid;
                }
            }

            dbg_utils_pprinter_table_data_line_print(stream, erps_memory_manager_dump_clmns);
        }

        region_map_item = cl_qmap_next(region_map_item);
    }

    dbg_utils_pprinter_table_headline_print(stream, erps_dump_columns);

    region_map_item = cl_qmap_head(&g_erps_memory_manager_map);
    while (region_map_item != region_map_end) {
        region_entry_p = PARENT_STRUCT(region_map_item, atcam_erps_memory_manager_db_entry_t, region_map_item);
        /* Only dump the specified region id or all of them */
        if (dump_all || (region_id == region_entry_p->region_id)) {
            for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
                if (region_entry_p->erp_arr[i].erp_id != ATCAM_INVALID_ERP_ID) {
                    data_len = sizeof(region_entry_p->erp_arr[i].mask.flex_mask_blocks) / 7;
                    erps_dump_columns[0].data = &(region_entry_p->region_id);
                    erps_dump_columns[1].data = &(region_entry_p->erp_arr[i].erp_id);
                    erps_dump_columns[2].data = &(region_entry_p->erp_arr[i].erp_index);
                    erps_dump_columns[3].data = &(region_entry_p->erp_arr[i].erp_bank);
                    erps_dump_columns[4].data = &(region_entry_p->erp_arr[i].bf_bypass);
                    erps_dump_columns[5].data = &(region_entry_p->erp_arr[i].is_enabled);
                    mask[0].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks;
                    mask[0].data_len = data_len;
                    mask[1].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len];
                    mask[1].data_len = data_len;
                    mask[2].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len * 2];
                    mask[2].data_len = data_len;
                    mask[3].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len * 3];
                    mask[3].data_len = data_len;
                    mask[4].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len * 4];
                    mask[4].data_len = data_len;
                    mask[5].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len * 5];
                    mask[5].data_len = data_len;
                    mask[6].data = &region_entry_p->erp_arr[i].mask.flex_mask_blocks[data_len * 6];
                    mask[6].data_len = data_len;
                    erps_dump_columns[6].data = &mask[0];
                    erps_dump_columns[7].data = &mask[1];
                    erps_dump_columns[8].data = &mask[2];
                    erps_dump_columns[9].data = &mask[3];
                    erps_dump_columns[10].data = &mask[4];
                    erps_dump_columns[11].data = &mask[5];
                    erps_dump_columns[12].data = &mask[6];


                    dbg_utils_pprinter_table_data_line_print(stream, erps_dump_columns);

                    sx_status = atcam_erps_db_erp_get(region_entry_p->region_id,
                                                      region_entry_p->erp_arr[i].erp_id,
                                                      &erp);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to get erp %d for region %d. [%s]\n",
                                   region_entry_p->erp_arr[i].erp_id,
                                   region_entry_p->region_id,
                                   sx_status_str(sx_status));
                        goto out;
                    }
                }
            }
        }
        region_map_item = cl_qmap_next(region_map_item);
    }


    goto out;

out:
    return sx_status;
}

static void __atcam_erps_memory_manager_db_regions_erp_debug_cmd(FILE       *stream,
                                                                 int         argc,
                                                                 const char *argv[],
                                                                 void       *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };
    uint32_t                    region_id = 0;
    boolean_t                   dump_all = (boolean_t)(intptr_t)handler_context;

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    if (dump_all) {
        atcam_erps_memory_manager_db_dbg_generate_dump(&dbg_dump_params, TRUE, 0);
    } else if ((argc > 0) && (sscanf(argv[0], "%u", &region_id) == 1)) {
        atcam_erps_memory_manager_db_dbg_generate_dump(&dbg_dump_params, FALSE, region_id);
    }

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}
