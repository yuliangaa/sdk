/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_SELECTOR_H__
#define __ATCAM_ERPS_SELECTOR_H__

#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"


/**
 * ---------
 */
sx_status_t atcam_erps_selector_init();

/**
 * ---------
 */
sx_status_t atcam_erps_selector_deinit();

/**
 * ---------
 */
sx_status_t atcam_erps_selector_new_erp_needed(sx_atcam_region_id_t region_id, boolean_t *new_erp_needed);

/**
 * ---------
 */
sx_status_t atcam_erps_selector_find_matching_erp(atcam_rules_db_rule_t *rule,
                                                  boolean_t             *found_matching_erp,
                                                  boolean_t              predetermined,
                                                  sx_atcam_erp_id_t      predetermined_erp_id);

boolean_t atcam_erps_selector_are_masks_delta_eq(const uint32_t              blocks_cnt,
                                                 const sx_atcam_mask_byte_t *erp_mask,
                                                 const sx_atcam_mask_byte_t *rule_mask,
                                                 boolean_t                  *ret_delta_found,
                                                 int                        *ret_delta_start);


#endif /* __ATCAM_ERPS_SELECTOR_H__ */
