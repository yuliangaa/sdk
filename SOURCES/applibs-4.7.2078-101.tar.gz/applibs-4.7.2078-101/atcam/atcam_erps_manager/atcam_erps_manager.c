/*
 * Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "atcam/common/atcam_ipc.h"
#include "complib/sx_log.h"
#include "utils/sx_mem.h"
#include "ethl2/brg.h"
#include "atcam_erps_manager.h"
#include "atcam_erps_db.h"
#include "atcam_erps_selector.h"
#include "atcam_erps_prune_calc.h"
#include "atcam_erps_memory_manager.h"
#include "atcam_erps_opts.h"
#include "atcam_erps_recalc.h"
#include "atcam/atcam_regions_manager/atcam_regions_db.h"
#include "atcam/atcam_sxd_wrapper/atcam_rules_manager_sxd_wrapper.h"
#include "atcam_bloom_filter.h"

/************************************************
 *  Global variables
 ***********************************************/
/* This parameter determines if always to calculate prune
 * or consider the predetermined parameter as well.
 */
boolean_t g_always_prune = TRUE;

extern sx_brg_context_t brg_context;
/************************************************
 *  Local definitions
 ***********************************************/
/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_initialized = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/

/**************************** Rules Manager Requests *******************************/
static sx_status_t __atcam_erps_manager_handle_add_rule(atcam_rules_db_rule_t *rule,
                                                        boolean_t              predetermined,
                                                        sx_atcam_erp_id_t      predetermined_erp_id);
static sx_status_t __atcam_erps_manager_handle_delete_rule(atcam_rules_db_rule_t *rule, boolean_t predetermined);
static sx_status_t __atcam_erps_manager_handle_update_priority(atcam_rules_db_rule_t      *rule,
                                                               sx_flex_acl_rule_priority_t old_priority);

/**************************** erps related functions *******************************/
static sx_status_t __atcam_erps_manager_db_add_erp(const sx_acl_region_id_t    region_id,
                                                   const sx_atcam_erp_id_t     erp_id,
                                                   const sx_atcam_mask_byte_t *flex_mask_blocks,
                                                   const uint8_t               bf_bank);
static sx_status_t __atcam_erps_manager_add_new_erp(const sx_acl_region_id_t    region_id,
                                                    const boolean_t             update_hw,
                                                    const sx_atcam_mask_byte_t *flex_mask_blocks,
                                                    sx_atcam_erp_id_t          *erp_id);

/***********************************************************************************/
static sx_status_t __atcam_erp_manager_region_update_cb(const sx_acl_region_id_t region_id,
                                                        atcam_region_erp_data_t *region_erp_data);
static sx_status_t __rp_to_erp_change(sx_atcam_region_id_t region_id);

/*********************************Bloom Filter related *******************************/
static sx_status_t __update_bloom_filter(atcam_rules_db_rule_t     *rule,
                                         const atcam_erps_db_erp_t *erp,
                                         const boolean_t            is_insertion);
static sx_status_t __update_bf_rule_res_index(atcam_rules_db_rule_t     *rule,
                                              const atcam_erps_db_erp_t *erp,
                                              const boolean_t            is_insertion);
static sx_status_t __update_erp_bf_enable(const sx_acl_region_id_t region_id,
                                          const sx_atcam_erp_id_t  erp_id,
                                          const boolean_t          bf_enabled);
static sx_status_t __update_bloom_filter_in_bulk_for_erp_array(const sx_atcam_region_id_t region_id,
                                                               const sx_atcam_erp_id_t   *erp_array,
                                                               const boolean_t            is_increase);

/************************************************
 *  Function implementations
 ***********************************************/


sx_status_t atcam_erps_manager_init(const uint32_t                      num_of_regions,
                                    const uint32_t                      num_of_erps,
                                    const atcam_shadow_region_create_cb shadow_region_create_cb,
                                    const atcam_shadow_region_remove_cb shadow_region_remove_cb)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_status_t                 rb_status = SX_STATUS_SUCCESS;
    atcam_bloom_filter_params_t bloom_filter_params;

    SX_LOG_ENTER();
    SX_MEM_CLR(bloom_filter_params);

    if (g_initialized) {
        SX_LOG_ERR("atcam_erps_manager_init: module is already initialized\n");
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    if (brg_context.spec_cb_g.atcam_bloom_filter_assign_ops_cb == NULL) {
        SX_LOG_ERR("Atcam bloom filter assign ops cb is undefined\n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    sx_status = brg_context.spec_cb_g.atcam_bloom_filter_assign_ops_cb(&bloom_filter_params);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Atcam bloom filter assign ops failed.\n");
        goto out;
    }

    sx_status = atcam_erps_db_init(num_of_regions, num_of_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_erps_manager_init: failed to init erps_db (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_init(__atcam_erp_manager_region_update_cb);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_erps_manager_init: failed to init erps memory manager(%s)\n", sx_status_str(sx_status));
        goto erps_db_init_err;
    }

    sx_status = atcam_erps_selector_init();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_erps_manager failed to init erps-selector(%s)\n", sx_status_str(sx_status));
        goto mem_man_init_err;
    }

    sx_status = atcam_bloom_filter_init(&bloom_filter_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("erps-manager: Failed to init bloom-filter. [%s]\n", sx_status_str(sx_status));
        goto selector_init_err;
    }

    sx_status = atcam_erps_opts_init(num_of_regions);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init erps optimization module. [%s]\n", sx_status_str(sx_status));
        goto bloom_init_err;
    }

    sx_status = atcam_erps_recalc_init(num_of_regions, shadow_region_create_cb, shadow_region_remove_cb);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("sx_atcam_api_init: Failed to initialize erps recalculation manager. [%s]\n",
                   sx_status_str(sx_status));
        goto erps_opts_err;
    }

    g_initialized = TRUE;
    goto out;

erps_opts_err:
    rb_status = atcam_erps_opts_deinit(FALSE);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Atcam_erps_manager fatal error at rollback - failed to deinit erps opts. (%s)\n",
                   sx_status_str(sx_status));
    }

bloom_init_err:
    rb_status = atcam_bloom_filter_deinit();
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Atcam_erps_manager fatal error at rollback - failed to deinit bloom filter. (%s)\n",
                   sx_status_str(sx_status));
    }

selector_init_err:
    rb_status = atcam_erps_selector_deinit();
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Atcam_erps_manager fatal error at rollback - failed to deinit erps selector. (%s)\n",
                   sx_status_str(sx_status));
    }

mem_man_init_err:
    rb_status = atcam_erps_memory_manager_deinit(FALSE);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Atcam_erps_manager fatal error at rollback - failed to deinit erps memory manager. (%s)\n",
                   sx_status_str(sx_status));
    }
erps_db_init_err:
    rb_status = atcam_erps_db_deinit(FALSE);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Atcam_erps_manager fatal error at rollback - failed to deinit erps_db. (%s)\n",
                   sx_status_str(sx_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_manager_deinit(const boolean_t forced_deinit)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("atcam_erps_manager module is not initialized\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    sx_status = atcam_erps_recalc_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit erps recalculation module. [%s]\n", sx_status_str(sx_status));
    }

    sx_status = atcam_erps_opts_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit erps optimizations module. [%s]\n", sx_status_str(sx_status));
    }

    sx_status = atcam_bloom_filter_deinit();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to de-init bloom-filter. [%s]\n", sx_status_str(sx_status));
    }

    sx_status = atcam_erps_selector_deinit();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to de-init eRPs memory manager(%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to de-init erps memory manager(%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_db_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to de-init erps db (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_manager_region_create(const sx_atcam_region_id_t       region_id,
                                             const uint8_t                    num_of_erps,
                                             const sx_atcam_key_blocks_size_t key_blocks_count)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    sx_status_t rb_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_region_create(region_id, num_of_erps, key_blocks_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create region %d. [%s]\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_opts_region_allocate(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate region %d for optimization module. [%s].\n", region_id,
                   sx_status_str(sx_status));
        goto erps_opts_err;
    }

    sx_status = atcam_erps_recalc_region_allocate(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate region %d for optimization module. [%s].\n", region_id,
                   sx_status_str(sx_status));
        goto erps_recalc_err;
    }


    goto out;

erps_recalc_err:
    rb_status = atcam_erps_opts_region_destroy(region_id);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error at roll-back. Failed to deallocate opts region %d. [%s]\n", region_id,
                   sx_status_str(rb_status));
    }

erps_opts_err:
    rb_status = atcam_erps_memory_manager_region_destroy(region_id);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error at roll-back. Failed to deallocate region %d. [%s]\n", region_id,
                   sx_status_str(rb_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_manager_clear_region_erps(const sx_atcam_region_id_t region_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t    erp_array[SX_ATCAM_ERPS_PER_REGION] = {0};
    uint8_t              num_of_erps;
    atcam_erps_db_erp_t *erp_db = NULL;
    uint8_t              i = 0;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_array_get(region_id, erp_array, &num_of_erps, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /* Do a validation that the erps are empty from rules */
    if (num_of_erps) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erp_array[i] != ATCAM_INVALID_ERP_ID) {
                sx_status = atcam_erps_db_erp_get(region_id, erp_array[i], &erp_db);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get eRP %u for region %d from db\n", erp_array[i], region_id);
                    goto out;
                }
                if (cl_qmap_count(&erp_db->rules) > 0) {
                    sx_status = SX_STATUS_DB_NOT_EMPTY;
                    SX_LOG_ERR("Trying to remove eRP %u from region %d which still has rules\n",
                               erp_array[i],
                               region_id);
                    goto out;
                }
            }
        }
    }
    /* Maybe this region had RP on it */
    else {
        sx_status = atcam_erps_db_erp_get(region_id, FIRST_ERP_ID, &erp_db);
        if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
            sx_status = atcam_erps_db_erp_deallocate(region_id, FIRST_ERP_ID);
            if (sx_status != SX_STATUS_SUCCESS) {
                if (cl_qmap_count(&erp_db->rules) > 0) {
                    sx_status = SX_STATUS_DB_NOT_EMPTY;
                    SX_LOG_ERR("Trying to remove eRP %u from region %d which still has rules\n",
                               erp_array[i],
                               region_id);
                    goto out;
                }
            }
        }
    }

    /* Go clear the erps */
    if (num_of_erps) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (erp_array[i] != ATCAM_INVALID_ERP_ID) {
                sx_status = atcam_erps_db_erp_deallocate(region_id, erp_array[i]);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to de-allocate eRP with id %d for region %d (%s)\n",
                               erp_array[i],
                               region_id,
                               sx_status_str(sx_status));
                }
                sx_status = atcam_erps_opts_erp_delete(region_id, erp_array[i]);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed erp opts delete eRP with id %d for region %d (%s)\n",
                               erp_array[i],
                               region_id,
                               sx_status_str(sx_status));
                }
            }
        }
    }
    /* Maybe this region had RP on it */
    else {
        sx_status = atcam_erps_db_erp_get(region_id, FIRST_ERP_ID, NULL);
        if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
            sx_status = atcam_erps_db_erp_deallocate(region_id, FIRST_ERP_ID);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to de-allocate RP with id %d for region %d (%s)\n",
                           FIRST_ERP_ID,
                           region_id,
                           sx_status_str(sx_status));
            }
        }
    }
    /* Clear the erps from the erp manager as well */
    sx_status = atcam_erps_memory_manager_clear_region_erps(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed clearing erps while try to delete region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_manager_region_destroy(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_erps_manager_clear_region_erps(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear erps for region %d. [%s].\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    /*
     * This is purely DB module. So we don't care about destroying
     * the erps for this region before destroying the region itself
     */
    sx_status = atcam_erps_recalc_region_destroy(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy region %d in optimization module. [%s].\n", region_id, sx_status_str(sx_status));
        goto out;
    }
    sx_status = atcam_erps_opts_region_destroy(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy region %d in optimization module. [%s].\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    /* Delete ctcam object for this region */
    sx_status = atcam_erps_db_ctcam_get(region_id, NULL);
    if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        sx_status = atcam_erps_db_ctcam_deallocate(region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to de-allocate ctcam for region %d (%s)\n",
                       region_id,
                       sx_status_str(sx_status));
        }
    }

    sx_status = atcam_erps_memory_manager_region_destroy(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to destroy region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_manager_erp_create(const sx_acl_region_id_t    region_id,
                                          const sx_atcam_mask_byte_t *flex_mask_blocks,
                                          sx_atcam_erp_id_t          *erp_id)
{
    return __atcam_erps_manager_add_new_erp(region_id, TRUE, flex_mask_blocks, erp_id);
}

sx_status_t atcam_erps_manager_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "SDK ATCAM (SpACE) Erps manager Module");
    dbg_utils_pprinter_field_print(stream, "Module Initialized :",  &g_initialized, PARAM_BOOL_E);

    if (g_initialized) {
        status = atcam_erps_memory_manager_dbg_generate_dump(dbg_dump_params_p);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to generate debug dump for erps memory manager.\n");
            goto out;
        }
    }

out:
    return status;
}


/************************************************
 *  Local Functions implementations
 ***********************************************/

#if ASYNC_INFRA_SUPPORTED
static
#endif
sx_status_t atcam_erp_manager_send_msg(const atcam_ipc_msg_t *msg)
{
    UNUSED_PARAM(msg);

    return SX_STATUS_SUCCESS;
}

#if ASYNC_INFRA_SUPPORTED
static
#endif
sx_status_t atcam_erp_manager_recv_msg(const atcam_ipc_msg_t *ipc_msg)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("eRP Manager cannot receive messages as module wasn't properly initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (!ipc_msg) {
        SX_LOG_ERR("eRPS Manager: NULL message received.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (ipc_msg->event) {
    case (ATCAM_REQ_ADD_RULE_E):
        sx_status = __atcam_erps_manager_handle_add_rule(ipc_msg->msg.rule_ptr,
                                                         ipc_msg->msg.command_extra_info.erp_extra_info.predetermined,
                                                         ipc_msg->msg.command_extra_info.erp_extra_info.predetermined_erp_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Erps Manager: error while adding rule id 0x%" PRIx64 " to region %d (%s)\n",
                       ipc_msg->msg.rule_id,
                       ipc_msg->msg.rule_ptr->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        break;

    case (ATCAM_REQ_DELETE_RULE_E):
        sx_status = __atcam_erps_manager_handle_delete_rule(ipc_msg->msg.rule_ptr,
                                                            ipc_msg->msg.command_extra_info.erp_extra_info.predetermined);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Erps Manager: error while deleting rule with id 0x%" PRIx64 " to region %d (%s)\n",
                       ipc_msg->msg.rule_id,
                       ipc_msg->msg.rule_ptr->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        break;

    case (ATCAM_REQ_PRIO_CHANGE_E):
        sx_status = __atcam_erps_manager_handle_update_priority(ipc_msg->msg.rule_ptr,
                                                                ipc_msg->msg.command_extra_info.prio_change.old_prio);

        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("eRP Manager: error while updating priority of rule with id 0x%" PRIx64 " at region %d (%s)\n",
                       ipc_msg->msg.rule_id,
                       ipc_msg->msg.rule_ptr->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported event received\n");
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __rp_to_erp_change(sx_atcam_region_id_t region_id)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t            new_erp_id = FIRST_ERP_ID;
    sx_atcam_key_mask_t          mask;
    atcam_erps_db_erp_t         *erp_p = NULL;
    const cl_map_item_t         *it = NULL, *end = NULL;
    atcam_rules_db_rule_entry_t *erp_rule_entry = NULL;
    boolean_t                    update_in_bulk = FALSE, update_bf = TRUE;

    SX_LOG_ENTER();
    SX_MEM_CLR(mask);

    sx_status = atcam_erps_db_erp_get(region_id, FIRST_ERP_ID, &erp_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("While getting erp %d, from region %d (%s)\n",
                   FIRST_ERP_ID,
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }


    /*
     * We don't update bloom-filter when using single RP on a region. Thus,
     * when we change from RP to eRP, we should also update bloom-filter with all
     * rules that were previously on that RP.
     */
    sx_status = atcam_utils_need_to_update_all_erps_bf(0,
                                                       1,
                                                       TRUE,
                                                       &update_in_bulk,
                                                       NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update bf in bulk. [%s].\n",
                   sx_status_str(sx_status));
        goto out;
    }
    if (update_in_bulk) {
        erp_p->bf_enabled = TRUE;
    } else {
        erp_p->bf_enabled = FALSE;
    }

    memcpy(&(mask.flex_mask_blocks), &(erp_p->mask.flex_mask_blocks),
           sizeof(erp_p->mask.flex_mask_blocks));
    /* First - request memory from memory manager for the change to erp */
    sx_status = atcam_erps_memory_manager_erp_add(region_id, &new_erp_id,
                                                  &mask,
                                                  ATCAM_INVALID_ERP_OFFSET /* Note this special case:
                                                                            *  we know the id, but we let manager
                                                                            *  decide best offset for BF optimization */);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_DBG("No resources to allocate memory for the change RP -ERP for region %d (%s)\n",
                       region_id, sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Failed to allocate memory for the change RP -ERP for region %d (%s)\n",
                       region_id, sx_status_str(sx_status));
        }

        goto out;
    }

    /* This wasn't done before - since it wasn't allocated in HW memory before */
    sx_status = atcam_erps_memory_manager_attr_get(region_id, new_erp_id, &erp_p->bf_bank, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp attributes for region %d erp %d (%s)\n",
                   region_id, new_erp_id, sx_status_str(sx_status));
        goto out;
    }


    /* Don't forget to do this also - when we move from RP to eRP flow*/
    sx_status = atcam_erps_opts_erp_add(region_id, new_erp_id, erp_p->bf_bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to add erp %d at region %d for optimization module. [%s].\n",
                   new_erp_id,
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_utils_need_to_update_bf(1,
                                              &update_bf);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update res_index for"
                   " to region %d. [%s]\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    it = cl_qmap_head(&(erp_p->rules));
    end = cl_qmap_end(&erp_p->rules);
    while (it != end) {
        erp_rule_entry = PARENT_STRUCT(it, atcam_rules_db_rule_entry_t, per_erp_ctcam_mi);
        /* If we move from RP to ERP - then we currently update the res_index in any case */
        if (!update_bf) {
            sx_status = __update_bf_rule_res_index(&erp_rule_entry->data,
                                                   erp_p,
                                                   TRUE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update rule res_index. [%s].\n",
                           sx_status_str(sx_status));
                goto out;
            }
        } else {
            sx_status = __update_bloom_filter(&erp_rule_entry->data, erp_p, TRUE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update bloom-filter for rule id 0x%" PRIx64 " of region %d [%s]\n",
                           erp_rule_entry->data.rule_id, FIRST_ERP_ID, sx_status_str(sx_status));
                goto out;
            }
        }

        /* Currently - We switch from RP to eRP only for first pattern. This means that
         * all rules of this erp would naturally prune all other (non-existing) erps,
         *  so we can update using prune_vector max size.
         *  But since we want to be able to support 'bf-update' to other erps (other than RP) - we use
         *  the prune vector of the rule.
         */

        sx_status = atcam_erps_opts_erp_update_score(region_id, new_erp_id, erp_rule_entry->data.prune_vector, TRUE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update prune score of erp %d of region %d, when moving from RP to eRP flow.\n",
                       new_erp_id, region_id);
            goto out;
        }

        it = cl_qmap_next(it);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __atcam_erps_manager_erp_state_set(sx_atcam_region_id_t region_id,
                                                      sx_atcam_erp_id_t    erp_id,
                                                      boolean_t            enable_state)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_offset_t erp_offset = 0;
    atcam_region_params_t region_params;
    sx_atcam_erp_id_t     erp_order_arr[SX_ATCAM_ERPS_PER_REGION] = {0};
    uint8_t               old_num_of_enabled_erps = 0, new_num_of_enabled_erps = 0;
    boolean_t             need_to_update_bf = FALSE;

    SX_LOG_ENTER();
    SX_MEM_CLR(region_params);

    /* We want to check the num of enabled eRPs before and after the state_set
     * function. There are 2 options:
     * 1. If we enable the erp so we can get more than MIN_ERPS_FOR_BF enabled eRPs
     *    and we will need to update all the relevant eRPs registers with
     *    bf_bypass = FALSE.
     * 2. If we disabled the erp so we can get less than MIN_ERPS_FOR_BF enabled eRPs
     *    and we will need to update all the relevant eRPs registers with
     *    bf_bypass = TRUE.
     */
    sx_status = atcam_erps_memory_manager_array_get(region_id, erp_order_arr,
                                                    NULL,
                                                    &old_num_of_enabled_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_erp_state_set(region_id, erp_id, enable_state);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set ERp %u state in region %d (%s) \n",
                   erp_id,
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_array_get(region_id, erp_order_arr,
                                                    NULL,
                                                    &new_num_of_enabled_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /* After the state was changed we check if we need to update the HW according
     * to the comment above.
     */
    sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_enabled_erps,
                                                       new_num_of_enabled_erps,
                                                       enable_state,
                                                       &need_to_update_bf,
                                                       NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update bf in bulk. [%s].\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (need_to_update_bf) {
        for (erp_offset = 0; erp_offset < SX_ATCAM_ERPS_PER_REGION; erp_offset++) {
            if (erp_order_arr[erp_offset] != ATCAM_INVALID_ERP_ID) {
                sx_status = atcam_erps_memory_manager_bf_bypass_update(region_id,
                                                                       erp_order_arr[erp_offset],
                                                                       !enable_state);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update bf_bypass in eRP %u DB . [%s].\n",
                               erp_order_arr[erp_offset],
                               sx_status_str(sx_status));
                    goto out;
                }
            }
        }
        /* We update the HW only for the delete operations.
         * For the add operation we need to insert the BF entries first
         * and only then we can enable the ERPs to do BF lookup.
         */
        if (enable_state == FALSE) {
            sx_status = atcam_erps_memory_manager_hw_update(region_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update erp HW. [%s].\n",
                           sx_status_str(sx_status));
                goto out;
            }
        }
    }

    /*change region with the new erp state*/
    sx_status = atcam_regions_manager_region_get(region_id, &region_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d params (%s)\n", region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_attr_get(region_id, erp_id, NULL, &erp_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get bank num for erp id %d at region %d (%s)\n", erp_id,
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    region_params.erp_data.erpt_vector[erp_offset] = (enable_state == TRUE) ? 1 : 0;

    sx_status = atcam_regions_manager_erp_data_update(region_id, &region_params.erp_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __atcam_erps_manager_handle_add_rule(atcam_rules_db_rule_t *rule,
                                                        boolean_t              predetermined,
                                                        sx_atcam_erp_id_t      predetermined_erp_id)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    boolean_t             found_erp = FALSE, new_erp_needed = FALSE, atcam_insertion = FALSE;
    boolean_t             has_ctcam = FALSE, rp_exist = TRUE;
    boolean_t             is_erp_enabled = FALSE, update_hw = TRUE;
    sx_atcam_erp_id_t     erp_array[SX_ATCAM_ERPS_PER_REGION] = {0};
    atcam_erps_db_erp_t  *erp = NULL;
    atcam_region_params_t region_params;
    uint8_t               old_num_of_erps = 0, new_num_of_erps = 0, num_of_erps = 0;
    boolean_t             update_in_bulk = TRUE, update_bf = TRUE;
    boolean_t             update_all = FALSE, bf_disabled = FALSE;
    boolean_t             update_after_erp_enable = FALSE;
    uint8_t               i = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(region_params);

    sx_status = atcam_erps_selector_find_matching_erp(rule, &found_erp, predetermined, predetermined_erp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("While trying to identify eRP-to-rule, of rule id 0x%" PRIx64 ", offset %d, at region %d (%s)\n",
                   rule->rule_id,
                   rule->offset,
                   rule->region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /*check if erp memory is empty for this region*/
    sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erp_array, &num_of_erps, &old_num_of_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   rule->region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /*check if rp exist*/
    sx_status = atcam_erps_db_erp_get(rule->region_id, FIRST_ERP_ID, &erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("While getting erp %d, from region %d\n", FIRST_ERP_ID, rule->region_id);
        if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("atcam_erps_db_erp_get: while getting erp %u region %d (%s)\n",
                       FIRST_ERP_ID,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        } else {
            rp_exist = FALSE;
            sx_status = SX_STATUS_SUCCESS;
        }
    }

    /*
     * When we get back from the above function - if found_erp, then the rule is classified
     * to the matching eRP (erp_id is set accordingly), otherwise, we have 2 choices - we either
     * create an eRP for the rule (depending the answer from eRP selector) or we classify this rule as ctcam.
     */

    if (found_erp) {
        if (!num_of_erps) {
            if (rp_exist && (rule->delta.delta_mask)) {
                /*Rp - erp insert erp_id FIRST_ERP_ID to memory manager*/
                sx_status = __rp_to_erp_change(rule->region_id);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to change RP to ERp while inserting rule id 0x%" PRIx64 ", offset %d to region %d (%s)\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id,
                        sx_status_str(sx_status));
                    goto out;
                }
            }
        } else {
            /*check erp enabled*/
            sx_status = atcam_erps_memory_manager_erp_state_get(rule->region_id, rule->erp_id, &is_erp_enabled);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to get ERp state while inserting rule id 0x%" PRIx64 ", offset %d to region %d (%s)\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }

            if (!is_erp_enabled) {
                sx_status = __atcam_erps_manager_erp_state_set(rule->region_id, rule->erp_id, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to set ERp state while inserting rule id 0x%" PRIx64 ", offset %d, to region %d (%s)\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id,
                        sx_status_str(sx_status));
                    goto out;
                }
                /* Indicate that we might need to update all ERP with BF enable */
                update_after_erp_enable = TRUE;
            }
        }
        atcam_insertion = TRUE;
    } else if (!predetermined) { /* If erp predefined there is no case we create a new erp */
        sx_status = atcam_erps_selector_new_erp_needed(rule->region_id, &new_erp_needed);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("eRP selector failed when trying to decide if new eRP needs to be allocated for region %d"
                       "while inserting rule id 0x%" PRIx64 ", offset %d, (%s)\n",
                       rule->region_id,
                       rule->rule_id,
                       rule->offset,
                       sx_status_str(sx_status));
            goto out;
        }
        if (new_erp_needed) {
            if (!num_of_erps) {
                if (rp_exist) {
                    /*Rp - erp insert FIRST_ERP_ID to memory manager*/
                    sx_status = __rp_to_erp_change(rule->region_id);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        /* If we can't switch from RP to eRP - then we're in low resources,
                         * In this case - we currently prevent insertion, as inserted rule's mask MUST
                         * be a subset of GM in RP.
                         */
                        SX_LOG_ERR(
                            "Failed to change RP to ERp while inserting rule id 0x%" PRIx64 ", offset %d, to region %d (%s)\n",
                            rule->rule_id,
                            rule->offset,
                            rule->region_id,
                            sx_status_str(sx_status));
                        goto out;
                    }
                } else {
                    /*first RP*/
                    rule->erp_id = FIRST_ERP_ID;
                    update_hw = FALSE;
                }
            }

            atcam_insertion = TRUE;
            sx_status = __atcam_erps_manager_add_new_erp(rule->region_id,
                                                         update_hw,
                                                         rule->key_value_blocks.flex_mask_blocks,
                                                         &rule->erp_id);
            if (sx_status == SX_STATUS_NO_RESOURCES) {
                /*
                 * If, somehow, we can't create a new eRP,
                 * due to limited resources, we will insert the rule to the ctcam
                 */
                SX_LOG_DBG(
                    "erps manager: No more erps resources when inserting rule id 0x%" PRIx64 " to region %d. Using ctcam instead.\n",
                    rule->rule_id,
                    rule->region_id);
                atcam_insertion = FALSE;
            } else if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to create new eRP while inserting rule id 0x%" PRIx64 ", offset %d, to region %d (%s)\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        }
    } else { /* Sanity check: validate that predetermined should be inserted to CTCAM */
        if (predetermined_erp_id < SX_ATCAM_ERPS_PER_REGION) {
            SX_LOG_ERR("A predefined erp %u for region %d inserted to CTCAM\n", predetermined_erp_id, rule->region_id);
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }

    rule->is_atcam = atcam_insertion;
    if (atcam_insertion) {
        /*
         * ATCAM insertion flow
         *
         * Before we send jobs to working queues, we first insert the rule to the right eRP.
         * This has to happen from this context, so we won't miss any rules if new rules comes which
         * requires new eRP.
         */
        sx_status = atcam_erps_db_erp_add_rule(rule->region_id, rule->erp_id, rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to insert rule id 0x%" PRIx64 ", offset %d, to erp %d in region %d (%s)\n",
                       rule->rule_id,
                       rule->offset,
                       rule->erp_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /* Add this rule to the bad collision database. */
        sx_status = atcam_erps_db_bad_collision_add_rule(rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to insert bad collision: rule id 0x%" PRIx64 ", offset %d, erp %d, region %d (%s)\n",
                       rule->rule_id,
                       rule->offset,
                       rule->erp_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = atcam_erps_db_erp_get(rule->region_id, rule->erp_id, &erp);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get erp %d for region %d. [%s]\n", rule->erp_id, rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /*check the num of eRPs after we added the new rule*/
        sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erp_array, &num_of_erps, &new_num_of_erps);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /* If we have more than MIN_ERPS_FOR_BF new_num_of_erps so we will
         * enable their bf_enabled
         */
        sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_erps,
                                                           new_num_of_erps,
                                                           TRUE,
                                                           &update_all,
                                                           &bf_disabled);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if we need to update all the erp.bf_enabled. [%s].\n",
                       sx_status_str(sx_status));
            goto out;
        }

        if (update_all) {
            for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
                if (erp_array[i] != ATCAM_INVALID_ERP_ID) {
                    sx_status = __update_erp_bf_enable(rule->region_id, erp_array[i], !bf_disabled);
                    if (SX_STATUS_SUCCESS != sx_status) {
                        SX_LOG_ERR("Error when update erp bf with id %d, of region %d\n", erp_array[i],
                                   rule->region_id);
                        goto out;
                    }
                }
            }
        }

        /* If we have a predetermined erp we don't do the prune calculation (can be overridden by global configuration) */
        if (g_always_prune || !predetermined) {
            sx_status = atcam_erps_prune_calc_atcam_insertion(rule);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to handle prune vector calculations when inserting rule id 0x%" PRIx64 ", offset %d, to region %d. (%s)\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        } else {
            rule->prune_vector = 0;
            rule->prune_ctcam_cnt = 1;
        }

        /* In this part we have two choices:
         * 1. If the new_num_of_erps is less than MIN_ERPS_FOR_BF so we don't
         *    want to update the bloom filter (because we don't use bloom filter
         *    for less than MIN_ERPS_FOR_BF). The only thing we'll do here is to
         *    save the bf res_index in the rule DB.
         * 2. If the new_num_of_erps is equal or greater than MIN_ERPS_FOR_BF
         *    we have 2 choices:
         *    a. If the old_num_of_erps is less than MIN_ERPS_FOR_BF and the
         *       new_num_of_erps is equal or greater than MIN_ERPS_FOR_BF we
         *       want to enable the bf and update it with all the existing eRPs
         *       in a bulk.
         *    b. If the old_num_of_erps is greater than MIN_ERPS_FOR_BF so we
         *       want to add only the new rule to the bf
         *
         */
        sx_status = atcam_utils_need_to_update_bf(new_num_of_erps,
                                                  &update_bf);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if we need to update res_index for"
                       " rule id 0x%" PRIx64 ", to region %d. [%s]\n",
                       rule->rule_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        if (!update_bf) {
            sx_status = __update_bf_rule_res_index(rule,
                                                   erp,
                                                   TRUE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update rule res_index. [%s].\n",
                           sx_status_str(sx_status));
                goto out;
            }
        } else {
            sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_erps,
                                                               new_num_of_erps,
                                                               TRUE,
                                                               &update_in_bulk,
                                                               NULL);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to check if we need to update bf in bulk. [%s].\n",
                           sx_status_str(sx_status));
                goto out;
            }

            /*  If the old_num_of_erps is less than MIN_ERPS_FOR_BF and the
             * new_num_of_erps is equal or greater than MIN_ERPS_FOR_BF we
             * want to enable the bf and update it with all the existing eRPs
             * in a bulk.
             */
            if (update_in_bulk) {
                sx_status = __update_bf_rule_res_index(rule,
                                                       erp,
                                                       TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update rule res_index. [%s].\n",
                               sx_status_str(sx_status));
                    goto out;
                }

                sx_status = __update_bloom_filter_in_bulk_for_erp_array(rule->region_id, erp_array, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to update bf in bulk in region %d (%s)\n",
                        rule->region_id,
                        sx_status_str(sx_status));
                    goto out;
                }
                /* After the erp enable it's possible that the HW is not updated with
                 * the BF enable correctly. We update it now.
                 */
                if (update_after_erp_enable == TRUE) {
                    sx_status = atcam_erps_memory_manager_hw_update(rule->region_id);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to update erp HW. [%s].\n",
                                   sx_status_str(sx_status));
                        goto out;
                    }
                }
            } else {
                /* Else, if the old_num_of_erps is greater than MIN_ERPS_FOR_BF so we
                 * want to add only the new rule to the bf
                 */
                sx_status = __update_bloom_filter(rule, erp, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to update bloom filter when inserting rule id 0x%" PRIx64 ", offset %d, to region %d. [%s]\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id,
                        sx_status_str(sx_status));
                    goto out;
                }
            }
        }
    } else {
        /*
         * CTCAM insertion flow
         */
        /* Allocate ctcam entry if this wasn't done before */
        sx_status = atcam_erps_db_has_ctcam(rule->region_id, &has_ctcam);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if region %d has ctcam allocated (%s)\n",
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        if (!has_ctcam) {
            sx_status = atcam_erps_db_ctcam_allocate(rule->region_id, NULL);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to allocate ctcam for region %d when inserting rule id 0x%" PRIx64 ", offset %d, (%s)\n",
                    rule->region_id,
                    rule->rule_id,
                    rule->offset,
                    sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_regions_manager_region_get(rule->region_id, &region_params);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get region %d params when inserting rule id 0x%" PRIx64 ", offset %d, (%s)\n",
                       rule->region_id,
                       rule->rule_id,
                       rule->offset,
                       sx_status_str(sx_status));
            goto out;
        }

        /*enable ctcam lookup in region hw*/
        if (!region_params.erp_data.is_ctcam_enabled) {
            /* update region - update HW */
            region_params.erp_data.is_ctcam_enabled = TRUE;
            sx_status = atcam_regions_manager_erp_data_update(rule->region_id, &region_params.erp_data);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed while try to update region manager for region %d (%s) \n",
                           rule->region_id, sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_erps_db_ctcam_add_rule(rule->region_id, rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to insert rule id 0x%" PRIx64 ", offset %d, for ctcam of region %d (%s)\n",
                       rule->rule_id,
                       rule->offset,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /* If we have a predetermined erp we don't do the prune calculation (can be overridden by global configuration) */
        if (g_always_prune || !predetermined) {
            sx_status = atcam_erps_prune_calc_ctcam_insertion(rule);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to handle prune vector calculations when inserting rule id 0x%" PRIx64 ", offset %d, to region %d. (%s)\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_erps_manager_handle_delete_rule(atcam_rules_db_rule_t *rule, boolean_t predetermined)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    atcam_region_params_t region_params;
    boolean_t             is_empty = TRUE;
    sx_atcam_erp_id_t     erp_array[SX_ATCAM_ERPS_PER_REGION] = {0};
    atcam_erps_db_erp_t  *erp = NULL;
    uint8_t               old_num_of_erps = 0, new_num_of_erps = 0, num_of_erps = 0;
    uint8_t               i = 0;
    boolean_t             update_bf = FALSE, update_in_bulk = FALSE;
    boolean_t             update_all = FALSE, bf_disabled = FALSE;

    SX_MEM_CLR(region_params);


    if (rule->is_atcam) {
        /* If we have a predetermined erp we don't do the prune calculation (can be overridden by global configuration) */
        if (g_always_prune || !predetermined) {
            sx_status = atcam_erps_prune_calc_atcam_deletion(rule);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update prune vector when deleting rule id 0x%" PRIx64 ", offset %d, from region %d. (%s)\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_erps_db_erp_get(rule->region_id, rule->erp_id, &erp);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get erp %d for region %d. [%s]\n", rule->erp_id, rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erp_array, &num_of_erps, &old_num_of_erps);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /* In this part we have two choices:
         * 1. If the old_num_of_erps is less than MIN_ERPS_FOR_BF so we don't
         *    want to update the bloom filter (because we don't use bloom filter
         *    for less than MIN_ERPS_FOR_BF). The only thing we'll do here is to
         *    update the bf res_index in the rule DB.
         * 2. If the old_num_of_erps is equal or greater than MIN_ERPS_FOR_BF
         *    so we want to delete only the new rule to the bf
         *
         */
        sx_status = atcam_utils_need_to_update_bf(old_num_of_erps,
                                                  &update_bf);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if we need to update res_index for"
                       " rule id 0x%" PRIx64 ", to region %d. [%s]\n",
                       rule->rule_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        if ((!update_bf) || (old_num_of_erps == 0)) {
            sx_status = __update_bf_rule_res_index(rule,
                                                   erp,
                                                   FALSE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update rule res_index. [%s].\n",
                           sx_status_str(sx_status));
                goto out;
            }
        } else {
            sx_status = __update_bloom_filter(rule, erp, FALSE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update bloom filter when deleting rule id 0x%" PRIx64 ", offset %d, to region %d. [%s]\n",
                    rule->rule_id,
                    rule->offset,
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_erps_db_bad_collision_remove_rule(rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Unable to remove from bad collision: rule id 0x%" PRIx64 ", offset %d, erp %d, region %d (%s)\n",
                rule->rule_id,
                rule->offset,
                rule->erp_id,
                rule->region_id,
                sx_status_str(sx_status));
            goto out;
        }

        /* We save this info because the pointer may not be valid if done in parallel */
        sx_status = atcam_erps_db_erp_delete_rule(rule->region_id, rule->erp_id, rule->rule_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Unable to remove rule id 0x%" PRIx64 ", offset %d, from erp %d of region %d (%s)\n",
                       rule->rule_id,
                       rule->offset,
                       rule->erp_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        /* Note that we don't delete this erp - this will be done only if needed after optimization */
        sx_status = atcam_erps_db_is_erp_empty(rule->region_id, rule->erp_id, &is_empty);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get erp status for erp %d of region %d (%s)\n",
                       rule->erp_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }
        if (is_empty) {
            /*check if erp memory is empty for this region (that means that the erp is rp)*/
            sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erp_array, &num_of_erps, NULL);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                           rule->region_id,
                           sx_status_str(sx_status));
                goto out;
            }

            if (num_of_erps) {
                /*change erp to state disabled*/
                sx_status = __atcam_erps_manager_erp_state_set(rule->region_id, rule->erp_id, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Failed to set ERp state while deleting rule id 0x%" PRIx64 ", offset %d, from region %d (%s)\n",
                        rule->rule_id,
                        rule->offset,
                        rule->region_id,
                        sx_status_str(sx_status));
                    goto out;
                }
            }
        }

        sx_status = atcam_erps_memory_manager_array_get(rule->region_id, erp_array, &num_of_erps, &new_num_of_erps);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_erps,
                                                           new_num_of_erps,
                                                           FALSE,
                                                           &update_in_bulk,
                                                           NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if we need to update bf in bulk. [%s].\n",
                       sx_status_str(sx_status));
            goto out;
        }
        /*
         * If the deleted rule changed the new_num_of_erps to be less than MIN_ERPS_FOR_BF
         * and the old_num_of_erps was equal or greater than MIN_ERPS_FOR_BF so
         * we want to update the exist bf (with less than MIN_ERPS_FOR_BF eRPS)
         * in bulk , because now we will not use the bf (we don't use the bf
         * if we have less than MIN_ERPS_FOR_BF eRPS)
         *
         */
        if (update_in_bulk) {
            sx_status = __update_bloom_filter_in_bulk_for_erp_array(rule->region_id, erp_array, FALSE);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update bf in bulk in region %d (%s)\n",
                    rule->region_id,
                    sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_utils_need_to_update_all_erps_bf(old_num_of_erps,
                                                           new_num_of_erps,
                                                           FALSE,
                                                           &update_all,
                                                           &bf_disabled);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to check if we need to update all the erp.bf_enabled. [%s].\n",
                       sx_status_str(sx_status));
            goto out;
        }

        if (update_all) {
            for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
                if (erp_array[i] != ATCAM_INVALID_ERP_ID) {
                    sx_status = __update_erp_bf_enable(rule->region_id, erp_array[i], !bf_disabled);
                    if (SX_STATUS_SUCCESS != sx_status) {
                        SX_LOG_ERR("Error when update erp bf with id %d, of region %d\n", erp_array[i],
                                   rule->region_id);
                        goto out;
                    }
                }
            }
            sx_status = atcam_erps_memory_manager_hw_update(rule->region_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update erp hw for region %d after bf update all. [%s].\n",
                           rule->region_id, sx_status_str(sx_status));
                goto out;
            }
        }
    } else {
        /* If we have a predetermined erp we don't do the prune calculation (can be overridden by global configuration) */
        if (g_always_prune || !predetermined) {
            sx_status = atcam_erps_prune_calc_ctcam_deletion(rule);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("while handling ctcam deletion for rule id 0x%" PRIx64 ", offset %d, at region %d. (%s)\n",
                           rule->rule_id,
                           rule->offset,
                           rule->region_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }

        sx_status = atcam_erps_db_ctcam_delete_rule(rule->region_id, rule->rule_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Unable to remove rule id 0x%" PRIx64 ", offset %d from ctcam of region %d (%s)\n",
                       rule->rule_id,
                       rule->offset,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }


        sx_status = atcam_erps_db_is_ctcam_empty(rule->region_id, &is_empty);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get erp status for erp %d of region %d (%s)\n",
                       rule->erp_id,
                       rule->region_id,
                       sx_status_str(sx_status));
            goto out;
        }

        if (is_empty) {
            /*change CTCAM to disable*/
            sx_status = atcam_regions_manager_region_get(rule->region_id, &region_params);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get region %d params when deleting rule id 0x%" PRIx64 ", offset %d (%s)\n",
                           rule->region_id,
                           rule->rule_id,
                           rule->offset,
                           sx_status_str(sx_status));
                goto out;
            }

            region_params.erp_data.is_ctcam_enabled = FALSE;

            sx_status = atcam_regions_manager_erp_data_update(rule->region_id, &region_params.erp_data);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed while try to update region manager for region %d (%s) \n",
                           rule->region_id, sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_erps_manager_handle_update_priority(atcam_rules_db_rule_t      *rule,
                                                               sx_flex_acl_rule_priority_t old_priority)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (rule->is_atcam) {
        sx_status = atcam_erps_prune_calc_atcam_priority_update(rule, old_priority);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed while trying to update prune vectors due to atcam-rule 0x%" PRIx64 " priority changed in region %d (%s) \n",
                rule->rule_id,
                rule->region_id,
                sx_status_str(sx_status));
            goto out;
        }
    } else {
        sx_status = atcam_erps_prune_calc_ctcam_priority_update(rule, old_priority);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed while trying to update prune vectors due to ctcam-rule 0x%" PRIx64 " priority changed in region %d (%s) \n",
                rule->rule_id,
                rule->region_id,
                sx_status_str(sx_status));
            goto out;
        }
    }

out:
    return sx_status;
}


static sx_status_t __atcam_erps_manager_db_add_erp(const sx_acl_region_id_t    region_id,
                                                   const sx_atcam_erp_id_t     erp_id,
                                                   const sx_atcam_mask_byte_t *flex_mask_blocks,
                                                   const uint8_t               bf_bank)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t          temp_erps_ids[SX_ATCAM_ERPS_PER_REGION] = {};
    atcam_erps_db_erp_params_t new_erp_params;
    uint8_t                    num_of_valid_erps = 0, num_of_erps = 0;
    boolean_t                  update_bf = TRUE, update_all = FALSE, bf_disabled = FALSE;
    uint8_t                    i = 0;


    SX_MEM_CLR(new_erp_params);
    SX_MEM_SET(new_erp_params.region_erps, ATCAM_INVALID_ERP_ID);


    /*
     *  Next, we need the get the new set of eRPs, the order matter,
     *  so we ask the memory manager for the IDs list.
     *  Also, memory can return a list with invalid IDs (where free slots are available),
     *  DB-wise, we don't care about it, so we condense the data
     */
    SX_MEM_CLR(temp_erps_ids);
    sx_status = atcam_erps_memory_manager_array_get(region_id, temp_erps_ids, &num_of_erps, &num_of_valid_erps);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erps list of ids from memory manager, for region %d (%s)\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_utils_need_to_update_bf(num_of_valid_erps,
                                              &update_bf);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update res_index for"
                   " to region %d. [%s]\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    if (num_of_erps) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
            if (temp_erps_ids[i] != ATCAM_INVALID_ERP_ID) {
                new_erp_params.region_erps[new_erp_params.region_erps_num++] = temp_erps_ids[i];
            }
        }
    }

    /*
     * Allocate the new eRP as a DB entry
     * At this stage - we set the new eRP mask equal that of the rule that caused its creation.
     * This should change at advanced stages.
     */
    memcpy(new_erp_params.mask.flex_mask_blocks,
           flex_mask_blocks,
           sizeof(new_erp_params.mask.flex_mask_blocks));

    new_erp_params.bf_bank = bf_bank;
    if ((!update_bf) || (num_of_valid_erps == 0)) {
        new_erp_params.bf_enabled = FALSE;
    } else {
        new_erp_params.bf_enabled = TRUE;
    }

    sx_status = atcam_erps_db_erp_allocate(region_id, erp_id, &new_erp_params, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_DBG("No more resources to allocate new eRP with id %d for region %d (%s)\n",
                       erp_id,
                       region_id,
                       sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Failed to allocate new eRP with id %d for region %d (%s)\n",
                       erp_id,
                       region_id,
                       sx_status_str(sx_status));
        }

        goto out;
    }

    sx_status = __update_erp_bf_enable(region_id, erp_id, new_erp_params.bf_enabled);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when update erp bf with id %d, of region %d\n", new_erp_params.region_erps[i],
                   region_id);
        goto out;
    }

    sx_status = atcam_utils_need_to_update_all_erps_bf(num_of_valid_erps - 1,
                                                       num_of_valid_erps,
                                                       TRUE,
                                                       &update_all,
                                                       &bf_disabled);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if we need to update all the erp.bf_enabled. [%s].\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /*
     * Now we need to add the new eRP to each of the other eRPs.
     */
    for (i = 0; i < new_erp_params.region_erps_num; ++i) {
        if (new_erp_params.region_erps[i] == erp_id) {
            continue;
        }

        if (update_all) {
            sx_status = __update_erp_bf_enable(region_id, new_erp_params.region_erps[i], !bf_disabled);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("Error when update erp bf with id %d, of region %d\n", new_erp_params.region_erps[i],
                           region_id);
                goto out;
            }
        }

        sx_status = atcam_erps_db_erp_add_prune_map(region_id, new_erp_params.region_erps[i], erp_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to init new prune map between eRPS (%d,%d) for region %d (%s)\n",
                       new_erp_params.region_erps[i],
                       erp_id,
                       region_id,
                       sx_status_str(sx_status));
            goto erp_db_alloc_err;
        }
    }

    sx_status = atcam_erps_prune_calc_new_erp(region_id, erp_id, &new_erp_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Failed to calculate prune vector changes due to erp %d added to region %d - inconsistent state. (%s)\n",
            erp_id,
            region_id,
            sx_status_str(sx_status));
        goto erp_db_alloc_err;
    }

    goto out;

erp_db_alloc_err:
    /* This would also take care of removing prune-maps that were allocated, if any */
    sx_status = atcam_erps_db_erp_deallocate(region_id, erp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error at rollback: Failed to de-allocate eRP with id %d for region %d (%s)\n",
                   erp_id,
                   region_id,
                   sx_status_str(sx_status));
    }


out:
    return sx_status;
}

static sx_status_t __update_erp_bf_enable(const sx_acl_region_id_t region_id,
                                          const sx_atcam_erp_id_t  erp_id,
                                          const boolean_t          bf_enabled)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    sx_status = atcam_erps_db_update_bf_enable(region_id, erp_id, bf_enabled);

    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d, of region %d\n", erp_id, region_id);
        goto out;
    }

out:
    return sx_status;
}


static sx_status_t __atcam_erps_manager_add_new_erp(const sx_acl_region_id_t    region_id,
                                                    const boolean_t             update_hw,
                                                    const sx_atcam_mask_byte_t *flex_mask_blocks,
                                                    sx_atcam_erp_id_t          *erp_id)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    sx_status_t            rb_sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t      new_erp_id = ATCAM_INVALID_ERP_ID;
    sx_atcam_bank_number_t bank = 0;
    sx_atcam_key_mask_t    mask;

    SX_MEM_CLR(mask);

    if (utils_check_pointer(erp_id, "erp_id")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* We create a new erp */
    if (update_hw) {
        memcpy(&(mask.flex_mask_blocks), flex_mask_blocks,
               sizeof(mask.flex_mask_blocks));
        /* First - request memory from memory manager for the new eRP */
        sx_status = atcam_erps_memory_manager_erp_add(region_id, &new_erp_id,
                                                      &mask,
                                                      ATCAM_INVALID_ERP_OFFSET);
        if (sx_status != SX_STATUS_SUCCESS) {
            /* Message already printed */
            goto out;
        }
        sx_status = atcam_erps_memory_manager_attr_get(region_id, new_erp_id, &bank, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get erp attributes for region %d erp %d (%s)\n",
                       region_id, new_erp_id, sx_status_str(sx_status));
            goto out;
        }
        *erp_id = new_erp_id;

        /* Only when we actually allocate erp in HW, we can start sample it*/
        sx_status = atcam_erps_opts_erp_add(region_id, new_erp_id, bank);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add erp %d at region %d for optimization module. [%s].\n",
                       new_erp_id,
                       region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = __atcam_erps_manager_db_add_erp(region_id, *erp_id, flex_mask_blocks, bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_DBG("No resources to create new eRP in db for region %d (%s)\n",
                       region_id, sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Failed to create new eRP in db for region %d (%s)\n",
                       region_id, sx_status_str(sx_status));
        }

        goto erp_mem_alloc_err;
    }

    goto out;

    /* cascade down */
erp_mem_alloc_err:
    if (update_hw) {
        rb_sx_status = atcam_erps_memory_manager_erp_delete(region_id, *erp_id);
        if (rb_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fatal error at rollback - unable to delete memory for new erp %d at region %d\n",
                       *erp_id,
                       region_id);
        }

        rb_sx_status = atcam_erps_opts_erp_delete(region_id, *erp_id);
        if (rb_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fatal error at rollback - unable to delete erp %d of region %d from optimization module.\n",
                       *erp_id,
                       region_id);
        }
    }

out:
    return sx_status;
}

static sx_status_t __atcam_erp_manager_region_update_cb(const sx_acl_region_id_t region_id,
                                                        atcam_region_erp_data_t *region_erp_data)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   is_empty = TRUE, has_ctcam = TRUE, is_ctcam_enabled = FALSE;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_has_ctcam(region_id, &has_ctcam);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if region %d has ctcam allocated\n", region_id);
        goto out;
    }

    if (has_ctcam) {
        sx_status = atcam_erps_db_is_ctcam_empty(region_id, &is_empty);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ctcam state for region %d \n", region_id);
            goto out;
        }

        if (!is_empty) {
            is_ctcam_enabled = TRUE;
        }
    }

    region_erp_data->is_ctcam_enabled = is_ctcam_enabled;

    sx_status = atcam_regions_manager_erp_data_update(region_id, region_erp_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __update_bloom_filter(atcam_rules_db_rule_t     *rule,
                                         const atcam_erps_db_erp_t *erp,
                                         const boolean_t            is_insertion)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_value_t rule_key_values;

    SX_MEM_CLR(rule_key_values);

    if (erp->bf_enabled) {
        memcpy(rule_key_values.flex_value_blocks, rule->key_value_blocks.flex_value_blocks,
               sizeof(rule_key_values.flex_value_blocks));
        /* The delta is not part of the bloom filter calculation and therefore should be removed */
        if (rule->delta.delta_mask) {
            atcam_utils_clear_delta_mask(rule_key_values.flex_value_blocks,
                                         rule->delta.delta_start,
                                         rule->delta.delta_mask);
        }

        if (is_insertion) {
            atcam_erps_memory_manager_banks_counters_update(TRUE,
                                                            erp->bf_bank);
            sx_status = atcam_bloom_filter_insert_rule(DEFAULT_DEV_ID,
                                                       erp->bf_bank,
                                                       rule->region_id,
                                                       rule->erp_id,
                                                       &rule_key_values,
                                                       &(rule->bf_res_index));
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to set BF for rule id 0x%" PRIx64 ", offset %d, region %d\n",
                       rule->rule_id, rule->offset, rule->region_id);
                goto out;
            }
        } else {
            atcam_erps_memory_manager_banks_counters_update(FALSE,
                                                            erp->bf_bank);
            sx_status = atcam_bloom_filter_delete_rule(DEFAULT_DEV_ID,
                                                       erp->bf_bank,
                                                       rule->region_id,
                                                       rule->erp_id,
                                                       &rule_key_values,
                                                       &(rule->bf_res_index));
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to delete BF for rule id 0x%" PRIx64 ", offset %d, region %d\n",
                       rule->rule_id, rule->offset, rule->region_id);
                goto out;
            }
        }
    }


out:
    return sx_status;
}

static sx_status_t __update_bf_rule_res_index(atcam_rules_db_rule_t     *rule,
                                              const atcam_erps_db_erp_t *erp,
                                              const boolean_t            is_insertion)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_atcam_key_value_t rule_key_values;

    SX_MEM_CLR(rule_key_values);

    memcpy(rule_key_values.flex_value_blocks, rule->key_value_blocks.flex_value_blocks,
           sizeof(rule_key_values.flex_value_blocks));
    /* The delta is not part of the bloom filter calculation and therefore should be removed */
    if (rule->delta.delta_mask) {
        atcam_utils_clear_delta_mask(rule_key_values.flex_value_blocks,
                                     rule->delta.delta_start,
                                     rule->delta.delta_mask);
    }
    atcam_erps_memory_manager_banks_counters_update(is_insertion,
                                                    erp->bf_bank);

    sx_status = atcam_bloom_filter_calculate_res_index(erp->bf_bank,
                                                       rule->region_id,
                                                       rule->erp_id,
                                                       &rule_key_values,
                                                       &(rule->bf_res_index));
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to calculate res_index for rule id 0x%" PRIx64 ", offset %d, region %d\n",
               rule->rule_id, rule->offset, rule->region_id);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __update_bloom_filter_in_bulk_for_erp_array(const sx_atcam_region_id_t region_id,
                                                               const sx_atcam_erp_id_t   *erp_array,
                                                               const boolean_t            is_increase)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp = NULL;
    boolean_t            is_erp_enabled = FALSE;
    uint8_t              i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        if (erp_array[i] != ATCAM_INVALID_ERP_ID) {
            /*check if erp enabled*/
            sx_status = atcam_erps_memory_manager_erp_state_get(region_id,
                                                                erp_array[i],
                                                                &is_erp_enabled);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to get ERp state in region %d (%s)\n",
                    region_id,
                    sx_status_str(sx_status));
                goto out;
            }
            if (is_erp_enabled) {
                sx_status = atcam_erps_db_erp_get(region_id, erp_array[i], &erp);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_DBG("While getting erp %d, from region %d\n", erp_array[i], region_id);
                }
                sx_status = atcam_bloom_filter_update_erp_in_bulk(erp,
                                                                  is_increase);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_DBG("While update bf in bulk, erp %d, from region %d\n",
                               erp_array[i],
                               region_id);
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
