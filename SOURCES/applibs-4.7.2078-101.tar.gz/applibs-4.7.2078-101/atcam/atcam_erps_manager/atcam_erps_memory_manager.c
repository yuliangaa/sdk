/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "atcam_erps_memory_manager.h"
#include "atcam_erps_memory_manager_db.h"
#include "utils/sx_mem.h"
#include "sx/sxd/sxd_access_register.h"
#include "complib/sx_log.h"
#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ ATCAM_ERPS_MEMORY_MANAGER
/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
int banks_rules_counters[ATCAM_NUM_OF_BANKS] = {0};
/************************************************
 *  Local Macros
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/
/************************************************
 *  Local variables
 ***********************************************/
static boolean_t                             g_initialized = FALSE;
static atcam_erps_memory_manager_region_cb_t region_update_cb;
/************************************************
 *  Local function declarations
 ***********************************************/
uint8_t __min_array(int     arr[],
                    uint8_t len);
static sx_status_t __atcam_erps_memory_manager_region_update(const atcam_erps_linear_manager_handle_t       handle,
                                                             const atcam_erps_linear_manager_block_length_t size,
                                                             const sx_acl_region_id_t                       region_id,
                                                             const atcam_erps_linear_manager_index_t        new_index,
                                                             const sx_atcam_erp_id_t                        erp_id);
static sx_status_t __atcam_single_erp_hw_update(const sx_atcam_region_id_t  region_id,
                                                const sx_atcam_erp_offset_t erp_offset,
                                                const sx_atcam_erp_id_t     erp_id);

sx_status_t __atcam_erps_memory_manager_region_set(const sx_atcam_region_id_t       region_id,
                                                   const uint8_t                    num_of_erps,
                                                   const sx_atcam_key_blocks_size_t key_blocks_count);

static sx_status_t __atcam_erps_memory_manager_increase_region(const sx_atcam_region_id_t               region_id,
                                                               atcam_erps_linear_manager_block_length_t num_of_blocks_needed,
                                                               const sx_atcam_erp_id_t                  erp_id,
                                                               const sx_atcam_erp_offset_t              erp_offset,
                                                               const sx_atcam_key_mask_t               *mask_p);
static sx_status_t __atcam_erps_memory_manager_decrease_region(
    atcam_erps_linear_manager_block_length_t num_of_blocks_needed,
    const sx_atcam_region_id_t               region_id,
    const uint8_t                            delete_row_offset);
static sx_status_t __atcam_erps_memory_manager_update_region_without_resize(const sx_atcam_region_id_t region_id);
static sx_status_t __atcam_erps_memory_manager_update_region_with_resize(
    const sx_atcam_region_id_t                     region_id,
    const atcam_erps_linear_manager_block_length_t num_of_blocks_needed,
    const uint8_t                                  delete_row_offset);
static sx_atcam_erp_offset_t __find_new_erp_offset(
    const atcam_erps_memory_manager_db_entry_t * const         region_entry_p,
    const atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block);
static sx_atcam_erp_id_t __find_new_erp_id(const atcam_erps_memory_manager_db_entry_t * const region_entry_p);

/************************************************
 *  Function implementations
 ***********************************************/
uint8_t __min_array(int arr[], uint8_t len)
{
    int     min = INT32_MAX;
    int     i = 0;
    uint8_t index = 0;

    for (i = 0; i < len; i++) {
        if ((arr[i] < min) && (arr[i] != -1)) {
            min = arr[i];
            index = i;
        }
    }

    return index;
}
void atcam_erps_memory_manager_banks_counters_update(const boolean_t is_add, const sx_atcam_bank_number_t erp_bank)
{
    if (is_add) {
        banks_rules_counters[erp_bank]++;
    } else {
        banks_rules_counters[erp_bank]--;
    }

    return;
}
static sx_status_t __atcam_erps_memory_manager_region_update(const atcam_erps_linear_manager_handle_t       handle,
                                                             const atcam_erps_linear_manager_block_length_t size,
                                                             const sx_acl_region_id_t                       region_id,
                                                             const atcam_erps_linear_manager_index_t        new_index,
                                                             const sx_atcam_erp_id_t                        erp_id)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_region_erp_data_t                              region_erps_data;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
    uint16_t                                             erp_offset = 0;
    sx_atcam_erp_index_t                                 erp_index = 0;
    uint16_t                                             erp_vector = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(region_erps_data);

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region_id %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_set(region_id,
                                                        region_entry_p->key_blocks_count,
                                                        new_index,
                                                        size,
                                                        region_entry_p->allocated_erps,
                                                        handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set region_id %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &row_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    for (erp_offset = 0; erp_offset < SX_ATCAM_ERPS_PER_REGION; erp_offset++) {
        if (region_entry_p->erp_arr[erp_offset].erp_id != ATCAM_INVALID_ERP_ID) {
            region_erps_data.erpt_vector[erp_offset] = 1;
            if (region_entry_p->erp_arr[erp_offset].erp_id != erp_id) {
                erp_vector |= (1 << erp_offset);
            }

            /* Calculate the index of the  erp  */
            erp_index = ((erp_offset / ATCAM_NUM_OF_BANKS) * row_per_key_block) + new_index;
            sx_status = atcam_erps_memory_manager_db_erp_set(SXD_ACCESS_CMD_SET,
                                                             region_id,
                                                             region_entry_p->erp_arr[erp_offset].erp_id,
                                                             &(region_entry_p->erp_arr[erp_offset].mask),
                                                             erp_index,
                                                             erp_offset,
                                                             region_entry_p->erp_arr[erp_offset].is_enabled);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set erp %d DB (%s)\n", region_entry_p->erp_arr[erp_offset].erp_id,
                           sx_status_str(sx_status));
                goto out;
            }


            sx_status = atcam_erps_memory_manager_erp_hw_update(region_entry_p->erp_arr[erp_offset].erp_id,
                                                                &(region_entry_p->erp_arr[erp_offset].mask),
                                                                erp_index,
                                                                region_entry_p->erp_arr[erp_offset].erp_bank,
                                                                region_entry_p->erp_arr[erp_offset].bf_bypass,
                                                                region_entry_p->key_blocks_count,
                                                                erp_offset,
                                                                erp_vector,
                                                                region_entry_p->first_erp_index,
                                                                FIRST_BANK_NUM);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update erp %d (%s)\n", region_entry_p->erp_arr[erp_offset].erp_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
    }
    region_erps_data.valid_erps_num = region_entry_p->allocated_erps;
    region_erps_data.eprt_bank_pointer = FIRST_BANK_NUM;
    region_erps_data.erpt_pointer = region_entry_p->first_erp_index;

    sx_status = region_update_cb(region_id, &region_erps_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("region_update_cb Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_single_erp_hw_update(const sx_atcam_region_id_t  region_id,
                                                const sx_atcam_erp_offset_t erp_offset,
                                                const sx_atcam_erp_id_t     erp_id)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;
    uint16_t                              offset = 0;
    atcam_region_erp_data_t               region_erps_data;
    uint16_t                              erp_vector = 0;


    SX_LOG_ENTER();

    SX_MEM_CLR(region_erps_data);

    sx_status = atcam_erps_memory_manager_db_region_get(region_id,
                                                        &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region_id %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    for (offset = 0; offset < SX_ATCAM_ERPS_PER_REGION; offset++) {
        if (region_entry_p->erp_arr[offset].erp_id != ATCAM_INVALID_ERP_ID) {
            region_erps_data.erpt_vector[offset] = 1;
            if (region_entry_p->erp_arr[offset].erp_id != erp_id) {
                erp_vector |= (1 << offset);
            }
        }
    }

    sx_status = atcam_erps_memory_manager_erp_hw_update(region_entry_p->erp_arr[erp_offset].erp_id,
                                                        &(region_entry_p->erp_arr[erp_offset].mask),
                                                        region_entry_p->erp_arr[erp_offset].erp_index,
                                                        region_entry_p->erp_arr[erp_offset].erp_bank,
                                                        region_entry_p->erp_arr[erp_offset].bf_bypass,
                                                        region_entry_p->key_blocks_count,
                                                        erp_offset,
                                                        erp_vector,
                                                        region_entry_p->first_erp_index,
                                                        FIRST_BANK_NUM);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update erp %d (%s)\n", region_entry_p->erp_arr[erp_offset].erp_id,
                   sx_status_str(sx_status));
        goto out;
    }


    region_erps_data.valid_erps_num = region_entry_p->allocated_erps;
    region_erps_data.eprt_bank_pointer = FIRST_BANK_NUM;
    region_erps_data.erpt_pointer = region_entry_p->first_erp_index;

    sx_status = region_update_cb(region_id, &region_erps_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("region_update_cb Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __atcam_erps_memory_manager_region_set(const sx_atcam_region_id_t       region_id,
                                                   const uint8_t                    num_of_erps,
                                                   const sx_atcam_key_blocks_size_t key_blocks_count)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    uint8_t                                              rows_count = 0;
    atcam_erps_linear_manager_block_length_t             block_size = 0;
    atcam_erps_linear_manager_handle_t                   handle;
    atcam_erps_linear_manager_index_t                    linear_manager_index = ATCAM_INVALID_ERP_INDEX;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;


    SX_LOG_ENTER();

    if (num_of_erps > SX_ATCAM_ERPS_PER_REGION) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Num of eRPs must be less or equal to %d \n",
                   SX_ATCAM_ERPS_PER_REGION);
        goto out;
    }

    if (num_of_erps > 0) {
        rows_count = ((num_of_erps - 1) / ATCAM_NUM_OF_BANKS) + 1;

        sx_status = atcam_erps_memory_manager_db_one_row_size_get(key_blocks_count,
                                                                  &row_per_key_block, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        block_size = rows_count * row_per_key_block;

        sx_status = atcam_erps_linear_manager_block_add(region_id,
                                                        block_size,
                                                        &handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to add block to region_id %d (%s)\n",
                       region_id, sx_status_str(sx_status));
            goto out;
        }
        /*Lock and release to get the linear_manager_index*/
        sx_status = atcam_erps_linear_manager_handle_lock(handle,
                                                          &linear_manager_index,
                                                          NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock erp linear manager (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = atcam_erps_linear_manager_handle_release(handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to release linear manager (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
    } else { /*num_of_erps = 0 */
        block_size = 0;
        handle = 0;
    }

    sx_status = atcam_erps_memory_manager_db_region_set(region_id,
                                                        key_blocks_count,
                                                        linear_manager_index,
                                                        block_size,
                                                        num_of_erps,
                                                        handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to set region_id %d in erps_memory_manager_db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_memory_manager_init(atcam_erps_memory_manager_region_cb_t region_cb)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    atcam_erps_linear_manager_params_t user_params;

    SX_LOG_ENTER();
    SX_MEM_CLR(user_params);

    if (g_initialized) {
        SX_LOG_ERR("Atcam erps_memory_manager was already initialized\n");
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }


    sx_status = atcam_erps_memory_manager_db_init();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize erp_memory_manager DB, err = [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

    region_update_cb = region_cb;
    user_params.relocate_cb = __atcam_erps_memory_manager_region_update;
    sx_status = atcam_erps_linear_manager_init(&user_params);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("eRP linear manager init failed\n");
        goto error;
    }

    g_initialized = TRUE;

    goto out;

error:
    sx_status = atcam_erps_memory_manager_db_deinit(TRUE);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("RB: When deinitialize erps memory manager db err = [%s]\n", sx_status_str(sx_status));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}
sx_status_t atcam_erps_memory_manager_deinit(const boolean_t forced_deinit)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_initialized) { /* Nothing to do */
        if (!forced_deinit) {
            sx_status = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("erp memory manager is not initialized  err = [%s]\n", sx_status_str(sx_status));
            goto out;
        } else {
            goto out;
        }
    }

    sx_status = atcam_erps_linear_manager_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("eRP linear manager deinit failed err = [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinitialize erp_memory_manager DB, err = [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_region_create(const sx_atcam_region_id_t       region_id,
                                                    const uint8_t                    num_of_erps,
                                                    const sx_atcam_key_blocks_size_t key_blocks_count)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, NULL);
    if (sx_status == SX_STATUS_SUCCESS) { /* The region has already been created */
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("Region %d is already exist (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    } else if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_ERR("Failed to get region %d (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }
    sx_status = SX_STATUS_SUCCESS;


    sx_status = __atcam_erps_memory_manager_region_set(region_id, num_of_erps, key_blocks_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate a new region %d\n", region_id);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_clear_region_erps(const sx_atcam_region_id_t region_id)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;
    sx_atcam_erp_id_t                     erps_ids[SX_ATCAM_ERPS_PER_REGION];
    uint8_t                               i = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(erps_ids);

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    /* Copy erp ids, because deletion might change DB*/
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        erps_ids[i] = region_entry_p->erp_arr[i].erp_id;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        if (erps_ids[i] != ATCAM_INVALID_ERP_ID) {
            sx_status = atcam_erps_memory_manager_erp_delete(region_id, erps_ids[i]);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("When clearing erps for region %d, failed to delete erp %d\n",
                           region_id,
                           erps_ids[i]);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_region_destroy(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    sx_status = atcam_erps_memory_manager_clear_region_erps(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed clearing erps while try to delete region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_delete(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to delete region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_erp_add(const sx_atcam_region_id_t  region_id,
                                              sx_atcam_erp_id_t          *erp_id_p,
                                              const sx_atcam_key_mask_t  *mask_p,
                                              const sx_atcam_erp_offset_t erp_offset)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    uint16_t                                             i = 0;
    atcam_erps_linear_manager_block_length_t             num_of_blocks_needed = 0;
    atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block;
    sx_atcam_erp_offset_t                                new_offset = ATCAM_INVALID_ERP_OFFSET;

    SX_LOG_ENTER();

    if (erp_id_p == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("erp_id_p is NULL\n");
        goto out;
    }

    if (mask_p == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("mask_p is NULL\n");
        goto out;
    }
    if (*erp_id_p > SX_ATCAM_ERPS_PER_REGION) { /*erp_id can be ATCAM_INVALID_ERP_ID*/
        SX_LOG_ERR("erp_id %d given exceeds range.\n", *erp_id_p);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    if (region_entry_p->allocated_erps >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_NTC("There is no more space left in region %d.\n", region_id);
        sx_status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &rows_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (*erp_id_p != ATCAM_INVALID_ERP_ID) {
        for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) { /* check the erp id is free */
            if (region_entry_p->erp_arr[i].erp_id == *erp_id_p) {
                SX_LOG_ERR("erp_id %d given is in use.\n", *erp_id_p);
                sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }
        }
    } else {
        *erp_id_p = __find_new_erp_id(region_entry_p);
    }


    if (erp_offset != ATCAM_INVALID_ERP_OFFSET) {
        if (erp_offset >= SX_ATCAM_ERPS_PER_REGION) {
            SX_LOG_ERR("erp_offset %d given exceeds range.\n", erp_offset);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        if (region_entry_p->erp_arr[erp_offset].erp_id != ATCAM_INVALID_ERP_ID) { /* check the offset is free */
            SX_LOG_ERR("erp_offset %d given is in use.\n", erp_offset);
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        new_offset = erp_offset;
    } else {
        new_offset = __find_new_erp_offset(region_entry_p, rows_per_key_block);
    }

    num_of_blocks_needed = ((new_offset / ATCAM_NUM_OF_BANKS) + 1) * rows_per_key_block;

    sx_status = __atcam_erps_memory_manager_increase_region(region_id,
                                                            num_of_blocks_needed,
                                                            *erp_id_p,
                                                            new_offset,
                                                            mask_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_DBG("No resources while trying to increase region %d (%s)\n", region_id, sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Error while trying to increase region %d (%s)\n", region_id, sx_status_str(sx_status));
        }

        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_erp_delete(const sx_atcam_region_id_t region_id, const sx_atcam_erp_id_t erp_id)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_erps_memory_manager_db_erp_data_t              erp_entry;
    uint8_t                                              erp_offset;
    uint8_t                                              start_block_offset = 0, end_block_offset = 0;
    uint8_t                                              i = 0;
    atcam_erps_linear_manager_block_length_t             blocks_indication = 0;
    uint8_t                                              delete_row_offset = 0;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;


    SX_LOG_ENTER();

    if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("erp_id given exceeds range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db err = [%s]\n"
                   , region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_erp_get(region_id,
                                                     erp_id,
                                                     &erp_entry,
                                                     &erp_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_erp_set(SXD_ACCESS_CMD_DELETE,
                                                     region_id,
                                                     erp_id,
                                                     NULL,
                                                     erp_entry.erp_index,
                                                     erp_offset,
                                                     FALSE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to set erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    start_block_offset = (erp_offset / ATCAM_NUM_OF_BANKS) * ATCAM_NUM_OF_BANKS;
    end_block_offset = ((erp_offset / ATCAM_NUM_OF_BANKS) + 1) * ATCAM_NUM_OF_BANKS;
    for (i = start_block_offset; i < end_block_offset; i++) {
        if (region_entry_p->erp_arr[i].erp_id != ATCAM_INVALID_ERP_ID) {
            break;
        }
    }
    if (i == end_block_offset) { /*The block is empty */
        sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                                  &row_per_key_block, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        blocks_indication = region_entry_p->block_size - row_per_key_block;
    }

    delete_row_offset = (erp_offset / ATCAM_NUM_OF_BANKS) * ATCAM_NUM_OF_BANKS;

    sx_status = __atcam_erps_memory_manager_decrease_region(blocks_indication,
                                                            region_id,
                                                            delete_row_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to decrease region %d (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_attr_get(const sx_atcam_region_id_t region_id,
                                               const sx_atcam_erp_id_t    erp_id,
                                               sx_atcam_bank_number_t    *bank_p,
                                               sx_atcam_erp_offset_t     *erp_offset_p)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_erp_data_t erp;
    uint8_t                                 erp_pos;

    SX_LOG_ENTER();

    if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("erp_id given exceeds range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }


    sx_status = atcam_erps_memory_manager_db_erp_get(region_id,
                                                     erp_id,
                                                     &erp,
                                                     &erp_pos);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d err = [%s]\n", erp_id, region_id
                   , sx_status_str(sx_status));
        goto out;
    }
    if (erp_offset_p != NULL) {
        *erp_offset_p = erp_pos;
    }
    if (bank_p != NULL) {
        *bank_p = erp.erp_bank;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_array_get(const sx_atcam_region_id_t region_id,
                                                sx_atcam_erp_id_t         *erp_order_arr_p,
                                                uint8_t                   *num_of_erps,
                                                uint8_t                   *num_of_enabled_erps)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_atcam_erp_id_t temp_erp_ids[SX_ATCAM_ERPS_PER_REGION];

    SX_LOG_ENTER();

    /* If the array is not provided we use a temporary one here */
    if (erp_order_arr_p == NULL) {
        erp_order_arr_p = temp_erp_ids;
    }

    sx_status = atcam_erps_memory_manager_db_array_get(region_id,
                                                       erp_order_arr_p,
                                                       num_of_erps,
                                                       num_of_enabled_erps);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d array. err = [%s]\n", region_id
                   , sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_predefined_region_create(const sx_atcam_region_id_t       region_id,
                                                               const sx_atcam_key_blocks_size_t blocks_size,
                                                               sx_atcam_erp_id_t               *erp_id_p,
                                                               const sx_atcam_key_mask_t       *mask_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     offset_idx = 0;
    int         i = 0;
    uint8_t     space_needed = 0;

    SX_LOG_ENTER();

    if (!erp_id_p || !mask_p) {
        SX_LOG_ERR("NULL param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (i = SX_ATCAM_ERPS_PER_REGION - 1; i >= 0; --i) {
        if (erp_id_p[i] != ATCAM_INVALID_ERP_ID) {
            space_needed = i;
            break;
        }
    }

    sx_status = atcam_erps_memory_manager_region_create(region_id, space_needed + 1, blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init region %d (%s)\n", region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    for (offset_idx = 0; offset_idx < SX_ATCAM_ERPS_PER_REGION; offset_idx++) {
        if (erp_id_p[offset_idx] != ATCAM_INVALID_ERP_ID) {
            sx_status = atcam_erps_memory_manager_erp_add(region_id,
                                                          &erp_id_p[offset_idx],
                                                          &mask_p[offset_idx],
                                                          offset_idx);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to add erp %d to region %d err = [%s]\n", erp_id_p[offset_idx], region_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_memory_manager_region_update(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t   *erps_ids,
                                                    const sx_atcam_key_mask_t *erps_masks,
                                                    const boolean_t           *erps_enabled)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    int                                                  i = 0;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;
    atcam_erps_linear_manager_block_length_t             num_of_blocks_needed = 0;
    atcam_erps_linear_manager_handle_t                   handle = 0, old_handle = 0;
    atcam_erps_linear_manager_index_t                    new_index = 0;
    sx_atcam_erp_index_t                                 erp_index = 0;
    uint8_t                                              erp_offset = 0;
    uint16_t                                             erp_vector = 0;
    atcam_region_erp_data_t                              region_erps_data;

    SX_LOG_ENTER();
    SX_MEM_CLR(region_erps_data);

    if (!erps_ids || !erps_masks) {
        SX_LOG_ERR("NULL param was given.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) { /* The region has already been created */
        SX_LOG_ERR("Unable to update - Region %d. Region not found. (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &row_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    for (i = SX_ATCAM_ERPS_PER_REGION - 1; i >= 0; --i) {
        if (erps_ids[i] != ATCAM_INVALID_ERP_ID) {
            num_of_blocks_needed = ((i / ATCAM_NUM_OF_BANKS) + 1) * row_per_key_block;
            break;
        }
    }

    sx_status = atcam_erps_linear_manager_block_add(region_id,
                                                    num_of_blocks_needed,
                                                    &handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_DBG("No resources while trying to add block to region %d (%s)\n", region_id, sx_status_str(
                           sx_status));
        } else {
            SX_LOG_ERR("Error while trying to add block to region %d (%s)\n", region_id, sx_status_str(sx_status));
        }
        goto out;
    }


    /*Lock region handle*/
    sx_status = atcam_erps_linear_manager_handle_lock(handle, &new_index, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to lock linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /* Release region handle */
    sx_status = atcam_erps_linear_manager_handle_release(handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to release linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    old_handle = region_entry_p->handle; /* Save old handle - so we can release this block later */
    sx_status = atcam_erps_memory_manager_db_region_set(region_id,
                                                        region_entry_p->key_blocks_count,
                                                        new_index,
                                                        num_of_blocks_needed,
                                                        region_entry_p->allocated_erps,
                                                        handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set region_id %d (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }
    /* We need to clean junk before we reorder erps */
    SX_MEM_CLR(region_entry_p->erp_arr);
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        region_entry_p->erp_arr[i].erp_id = ATCAM_INVALID_ERP_ID;
    }


    for (erp_offset = 0; erp_offset < SX_ATCAM_ERPS_PER_REGION; ++erp_offset) {
        if (erps_ids[erp_offset] != ATCAM_INVALID_ERP_ID) {
            region_erps_data.erpt_vector[erp_offset] = 1;
            erp_vector |= (1 << erp_offset);

            /* Calculate the index of the  erp  */
            erp_index = ((erp_offset / ATCAM_NUM_OF_BANKS) * row_per_key_block) + new_index;
            sx_status = atcam_erps_memory_manager_db_erp_set(SXD_ACCESS_CMD_SET,
                                                             region_id,
                                                             erps_ids[erp_offset],
                                                             &erps_masks[erp_offset],
                                                             erp_index,
                                                             erp_offset,
                                                             erps_enabled[erp_offset]);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set erp %d DB (%s)\n", erps_ids[erp_offset], sx_status_str(sx_status));
                goto out;
            }


            /* Once DB is updated, we can actually take info straight from DB*/
            sx_status = atcam_erps_memory_manager_erp_hw_update(region_entry_p->erp_arr[erp_offset].erp_id,
                                                                &(region_entry_p->erp_arr[erp_offset].mask),
                                                                erp_index,
                                                                region_entry_p->erp_arr[erp_offset].erp_bank,
                                                                region_entry_p->erp_arr[erp_offset].bf_bypass,
                                                                region_entry_p->key_blocks_count,
                                                                erp_offset,
                                                                erp_vector,
                                                                region_entry_p->first_erp_index,
                                                                FIRST_BANK_NUM);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update erp %d (%s)\n", region_entry_p->erp_arr[erp_offset].erp_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
    }

    region_erps_data.valid_erps_num = region_entry_p->allocated_erps;
    region_erps_data.eprt_bank_pointer = FIRST_BANK_NUM;
    region_erps_data.erpt_pointer = region_entry_p->first_erp_index;

    sx_status = region_update_cb(region_id, &region_erps_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("region_update_cb Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }


    /*Delete old block*/
    sx_status = atcam_erps_linear_manager_block_delete(old_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to delete old_handle (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_memory_manager_erp_hw_update(const sx_atcam_erp_id_t          erp_id,
                                                    const sx_atcam_key_mask_t       *mask_p,
                                                    const sx_atcam_erp_index_t       erp_index,
                                                    const sx_atcam_bank_number_t     erp_bank,
                                                    const boolean_t                  bf_bypass,
                                                    const sx_atcam_key_blocks_size_t key_blocks_size,
                                                    const uint8_t                    erp_index_in_vector,
                                                    const uint16_t                   erp_vector,
                                                    const sx_atcam_erp_index_t       erp_base_index,
                                                    const sx_atcam_bank_number_t     erp_base_bank)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    sxd_status_t                                         sxd_status = SXD_STATUS_SUCCESS;
    atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block = ROWS_PER_ONE_KEY_BLOCK;
    perpt_key_size_t                                     key_size = PERPT_KEY_SIZE_ONE_KEY_BLOCK;
    struct ku_perpt_reg                                  perpt;
    sxd_reg_meta_t                                       meta;

    SX_LOG_ENTER();
    SX_MEM_CLR(perpt);

    SX_MEM_CLR(meta);
    meta.swid = 0;
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.dev_id = 1;

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(key_blocks_size,
                                                              &rows_per_key_block, &key_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    perpt.erpt_bank = erp_bank;
    perpt.erpt_index = erp_index;
    perpt.key_size = key_size;
    perpt.bf_bypass = bf_bypass;

    perpt.erp_id = erp_id;
    perpt.erp_index_in_vector = erp_index_in_vector;
    perpt.erp_vector = erp_vector;
    perpt.erpt_base_bank = erp_base_bank;
    perpt.erpt_base_index = erp_base_index;
    memcpy(&(perpt.mask),
           &(mask_p->flex_mask_blocks),
           sizeof(mask_p->flex_mask_blocks));

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PERPT_E, &perpt, &meta, 1, NULL, NULL);
    sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to set PERPT (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_memory_manager_increase_region(const sx_atcam_region_id_t               region_id,
                                                               atcam_erps_linear_manager_block_length_t num_of_blocks_needed,
                                                               const sx_atcam_erp_id_t                  erp_id,
                                                               const sx_atcam_erp_offset_t              erp_offset,
                                                               const sx_atcam_key_mask_t               *mask_p)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;
    atcam_erps_linear_manager_index_t                    index;
    atcam_erps_linear_manager_handle_t                   handle = 0;
    atcam_erps_linear_manager_handle_t                   old_handle = 0;
    boolean_t                                            is_new_region = FALSE;
    sx_atcam_erp_index_t                                 erp_index;


    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    if (region_entry_p->block_size >= num_of_blocks_needed) {
        num_of_blocks_needed = 0;
    } /*Else we need num_of_blocks_needed for the region */

    if (region_entry_p->block_size != 0) { /*This is not a new region */
        old_handle = region_entry_p->handle;
    } else {
        is_new_region = TRUE;
    }

    if (num_of_blocks_needed > 0) {
        sx_status = atcam_erps_linear_manager_block_add(region_id,
                                                        num_of_blocks_needed,
                                                        &handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            if (sx_status == SX_STATUS_NO_RESOURCES) {
                SX_LOG_DBG("No resources while trying to add block to region %d (%s)\n", region_id,
                           sx_status_str(sx_status));
            } else {
                SX_LOG_ERR("Error while trying to add block to region %d (%s)\n", region_id, sx_status_str(sx_status));
            }

            goto out;
        }
    } else {
        handle = region_entry_p->handle;
    }

    /*Lock region handle*/
    sx_status = atcam_erps_linear_manager_handle_lock(handle,
                                                      &index,
                                                      NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to lock linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &row_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    /* Calculate the index of the  erp  */
    erp_index = ((erp_offset / ATCAM_NUM_OF_BANKS) * row_per_key_block) + index;
    sx_status = atcam_erps_memory_manager_db_erp_set(SXD_ACCESS_CMD_ADD,
                                                     region_id,
                                                     erp_id,
                                                     mask_p,
                                                     erp_index,
                                                     erp_offset,
                                                     TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to set erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    /* Update HW and region DB */
    if (num_of_blocks_needed > 0) { /* We need to update all the erps - because the block was moved */
        sx_status = __atcam_erps_memory_manager_region_update(handle,
                                                              num_of_blocks_needed,
                                                              region_id,
                                                              index,
                                                              erp_id);

        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to relocate block for region %d (%s)\n", region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    } else {
        sx_status = __atcam_single_erp_hw_update(region_id, erp_offset, erp_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try update erp %d in region %d (%s)\n", erp_id, region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    }

    /* Release region handle */
    sx_status = atcam_erps_linear_manager_handle_release(handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to release linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /*Delete old block*/
    if ((num_of_blocks_needed > 0) && (is_new_region == FALSE)) {
        sx_status = atcam_erps_linear_manager_block_delete(old_handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to delete old_handle (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __atcam_erps_memory_manager_decrease_region(atcam_erps_linear_manager_block_length_t blocks_indication,
                                                        const sx_atcam_region_id_t               region_id,
                                                        const uint8_t                            delete_row_offset)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t *region_entry_p = NULL;


    SX_LOG_ENTER();

    if (delete_row_offset >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("delete_row_offset exceeds range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db (%s)\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    if ((blocks_indication == 0) || (region_entry_p->allocated_erps == 0)) { /*This was the last eRP or we don't need to resize*/
        sx_status = __atcam_erps_memory_manager_update_region_without_resize(region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update region %d without resize (%s)\n", region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    } else {
        sx_status = __atcam_erps_memory_manager_update_region_with_resize(region_id,
                                                                          blocks_indication,
                                                                          delete_row_offset);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update region %d with resize (%s)\n", region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_memory_manager_update_region_without_resize(const sx_atcam_region_id_t region_id)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    uint8_t                                              i = 0;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_erps_linear_manager_index_t                    index;
    atcam_region_erp_data_t                              region_erps_data;
    atcam_erps_linear_manager_handle_t                   handle;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;
    atcam_erps_linear_manager_block_length_t             blocks_needed = 0;


    SX_LOG_ENTER();

    SX_MEM_CLR(region_erps_data);

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db err = [%s]\n"
                   , region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &row_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (region_entry_p->allocated_erps == 0) {
        blocks_needed = 0;
    } else {
        blocks_needed = region_entry_p->block_size;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        if ((region_entry_p->erp_arr[i].erp_id != ATCAM_INVALID_ERP_ID) &&
            (region_entry_p->erp_arr[i].is_enabled)) {
            region_erps_data.erpt_vector[i] = 1;
        }
    }

    handle = region_entry_p->handle;
    /*Lock region handle*/
    sx_status = atcam_erps_linear_manager_handle_lock(handle,
                                                      &index,
                                                      NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to lock linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (blocks_needed == 0) {
        sx_status = atcam_erps_memory_manager_db_region_set(region_id,
                                                            region_entry_p->key_blocks_count,
                                                            index,
                                                            0,
                                                            region_entry_p->allocated_erps,
                                                            region_entry_p->handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to update region DB for region %d (%s)  \n",
                       region_id, sx_status_str(sx_status));
            goto out;
        }
    }

    region_erps_data.valid_erps_num = region_entry_p->allocated_erps;
    region_erps_data.eprt_bank_pointer = 0;
    region_erps_data.erpt_pointer = region_entry_p->first_erp_index;

    sx_status = atcam_regions_manager_erp_data_update(region_id, &region_erps_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to update region manager for region %d (%s)  \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

    /* Release region handle */
    sx_status = atcam_erps_linear_manager_handle_release(handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to release linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    /*Delete the block if it was the last eRP*/
    if (blocks_needed == 0) {
        sx_status = atcam_erps_linear_manager_block_delete(handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to delete handle (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_memory_manager_update_region_with_resize(
    const sx_atcam_region_id_t                     region_id,
    const atcam_erps_linear_manager_block_length_t num_of_blocks_needed,
    const uint8_t                                  delete_row_offset)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_entry_t                *region_entry_p = NULL;
    atcam_erps_linear_manager_handle_t                   handle;
    atcam_erps_linear_manager_handle_t                   old_handle;
    atcam_erps_linear_manager_index_t                    index;
    uint8_t                                              old_offset = 0, new_offset = 0;
    uint8_t                                              erp_offset = 0;
    sx_atcam_erp_id_t                                    erp_id;
    sx_atcam_erp_index_t                                 erp_index;
    atcam_region_erp_data_t                              region_erps_data;
    atcam_erps_memory_manager_rows_per_key_block_count_t row_per_key_block;
    boolean_t                                            will_block_move = TRUE;
    uint16_t                                             erp_vector = 0;


    SX_LOG_ENTER();

    SX_MEM_CLR(region_erps_data);

    sx_status = atcam_erps_memory_manager_db_region_get(region_id, &region_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get region %d db err = [%s]\n"
                   , region_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_one_row_size_get(region_entry_p->key_blocks_count,
                                                              &row_per_key_block, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get one row size(%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    old_handle = region_entry_p->handle;
    /*Resize the block*/

    sx_status = atcam_erps_linear_manager_block_add(region_id,
                                                    num_of_blocks_needed,
                                                    &handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            will_block_move = FALSE;
            handle = old_handle;
            sx_status = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("Failed while try to add block to region %d (%s)\n", region_id,
                       sx_status_str(sx_status));
            goto out;
        }
    }
    /*Lock region handle*/
    sx_status = atcam_erps_linear_manager_handle_lock(handle,
                                                      &index,
                                                      NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to lock linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (will_block_move == TRUE) {
        /* Copy to the new indexes - the code assumes that we have only one row (per key blocks size) gap */
        for (new_offset = 0; new_offset < SX_ATCAM_ERPS_PER_REGION; new_offset++) {
            if (new_offset >= delete_row_offset) {
                old_offset = new_offset + ATCAM_NUM_OF_BANKS;
            } else {
                old_offset = new_offset;
            }
            if (new_offset >= SX_ATCAM_ERPS_PER_REGION - ATCAM_NUM_OF_BANKS) {
                erp_id = ATCAM_INVALID_ERP_ID;
                old_offset = new_offset;
            } else {
                erp_id = region_entry_p->erp_arr[old_offset].erp_id;
            }
            erp_index = ((new_offset / ATCAM_NUM_OF_BANKS) * row_per_key_block) + index;
            sx_status = atcam_erps_memory_manager_db_erp_set(SXD_ACCESS_CMD_SET,
                                                             region_id,
                                                             erp_id,
                                                             &(region_entry_p->erp_arr[old_offset].mask),
                                                             erp_index,
                                                             new_offset,
                                                             region_entry_p->erp_arr[old_offset].is_enabled);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed while try to update erp_id %d in region %d (%s)\n",
                           region_entry_p->erp_arr[new_offset].erp_id,
                           region_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }

        /* Update the erp HW - Max rows we could hold is 3 (per key block)*/
        for (erp_offset = 0; erp_offset < SX_ATCAM_ERPS_PER_REGION - ATCAM_NUM_OF_BANKS; erp_offset++) {
            if (region_entry_p->erp_arr[erp_offset].erp_id != ATCAM_INVALID_ERP_ID) {
                region_erps_data.erpt_vector[erp_offset] = 1;
                erp_vector |= (1 << erp_offset);

                sx_status = atcam_erps_memory_manager_erp_hw_update(region_entry_p->erp_arr[erp_offset].erp_id,
                                                                    &(region_entry_p->erp_arr[erp_offset].mask),
                                                                    region_entry_p->erp_arr[erp_offset].erp_index,
                                                                    region_entry_p->erp_arr[erp_offset].erp_bank,
                                                                    region_entry_p->erp_arr[erp_offset].bf_bypass,
                                                                    region_entry_p->key_blocks_count,
                                                                    erp_offset,
                                                                    erp_vector,
                                                                    index,
                                                                    FIRST_BANK_NUM);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update erp %d (%s)\n", region_entry_p->erp_arr[erp_offset].erp_id,
                               sx_status_str(sx_status));
                    goto out;
                }
            }
        }

        /* Update the region DB */
        sx_status = atcam_erps_memory_manager_db_region_set(region_id,
                                                            region_entry_p->key_blocks_count,
                                                            index,
                                                            num_of_blocks_needed,
                                                            region_entry_p->allocated_erps,
                                                            handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set region_id %d (%s)\n", region_id, sx_status_str(sx_status));
            goto out;
        }
    }

    /* Update the region HW */
    region_erps_data.valid_erps_num = region_entry_p->allocated_erps;
    region_erps_data.eprt_bank_pointer = FIRST_BANK_NUM;
    region_erps_data.erpt_pointer = region_entry_p->first_erp_index;

    sx_status = region_update_cb(region_id, &region_erps_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to update region manager for region %d (%s) \n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }


    /* Release region handle */
    sx_status = atcam_erps_linear_manager_handle_release(handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to release linear manager (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (will_block_move == TRUE) {
        sx_status = atcam_erps_linear_manager_block_delete(old_handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed while try to delete old_handle (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_erp_state_set(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t    erp_id,
                                                    const boolean_t            is_enabled)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_erp_state_set(region_id, erp_id, is_enabled);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed update erp memory manger db with new state = %u for erp_id = %u region = %u err %s\n",
                   is_enabled, erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_erp_state_get(const sx_atcam_region_id_t region_id,
                                                    const sx_atcam_erp_id_t    erp_id,
                                                    boolean_t                 *is_enabled_p)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    atcam_erps_memory_manager_db_erp_data_t erp_entry;
    sx_atcam_erp_offset_t                   erp_offset;

    SX_LOG_ENTER();

    if (is_enabled_p == NULL) {
        SX_LOG_ERR("is_enabled_p is NULL\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = atcam_erps_memory_manager_db_erp_get(region_id,
                                                     erp_id,
                                                     &erp_entry,
                                                     &erp_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while try to get erp %d in region %d (%s)\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }

    *is_enabled_p = erp_entry.is_enabled;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_hw_update(const sx_atcam_region_id_t region_id)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint8_t           i = 0;
    sx_atcam_erp_id_t erp_order_arr[SX_ATCAM_ERPS_PER_REGION] = {0};

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_array_get(region_id, erp_order_arr,
                                                    NULL, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed While trying to get eRP order, in region %d err = %s\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) {
        if (erp_order_arr[i] != ATCAM_INVALID_ERP_ID) {
            sx_status = __atcam_single_erp_hw_update(region_id, i, erp_order_arr[i]);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed while try update erp %d in region %d (%s)\n", erp_order_arr[i], region_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_bf_bypass_update(const sx_atcam_region_id_t region_id,
                                                       const sx_atcam_erp_id_t    erp_id,
                                                       const boolean_t            bf_bypass)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_erps_memory_manager_db_bf_bypass_set(region_id, erp_id, bf_bypass);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed update erp memory manger db bf_bypass for erp_id = %u region = %u err %s\n",
                   erp_id, region_id, sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_memory_manager_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    return atcam_erps_memory_manager_db_dbg_generate_dump(dbg_dump_params_p, TRUE, 0);
}


static sx_atcam_erp_offset_t __find_new_erp_offset(
    const atcam_erps_memory_manager_db_entry_t * const         region_entry_p,
    const atcam_erps_memory_manager_rows_per_key_block_count_t rows_per_key_block)
{
    sx_atcam_erp_offset_t new_erp_offset = ATCAM_INVALID_ERP_OFFSET;
    uint16_t              i = 0, j = 0;
    uint8_t               rows_count = 0;
    int                   bank_counter_temp[ATCAM_NUM_OF_BANKS];
    uint8_t               bank_num = 0, end_index = 0;
    uint8_t               first_erp_invalid[ATCAM_NUM_OF_BANKS] = {0};

    SX_MEM_CLR(bank_counter_temp);


    rows_count = region_entry_p->block_size / rows_per_key_block;

    if ((rows_count * ATCAM_NUM_OF_BANKS) == region_entry_p->allocated_erps) { /* We need to enlarge the region */
        bank_num = __min_array(banks_rules_counters, ATCAM_NUM_OF_BANKS);
        new_erp_offset = bank_num + (rows_count * ATCAM_NUM_OF_BANKS);
    } else {
        for (i = 0; i < ATCAM_NUM_OF_BANKS; i++) {
            end_index = i + (rows_count * ATCAM_NUM_OF_BANKS);
            for (j = i; j < end_index; j += ATCAM_NUM_OF_BANKS) {
                if (region_entry_p->erp_arr[j].erp_id == ATCAM_INVALID_ERP_ID) {
                    bank_counter_temp[i] = banks_rules_counters[i];
                    first_erp_invalid[i] = j;
                    break;
                }
            }
            if (j == end_index) { /*In this region the minimum bank is full so we want to get the next min bank*/
                bank_counter_temp[i] = -1;
            }
        }
        bank_num = __min_array(bank_counter_temp, ATCAM_NUM_OF_BANKS);
        new_erp_offset = first_erp_invalid[bank_num];
    }

    return new_erp_offset;
}


static sx_atcam_erp_id_t __find_new_erp_id(const atcam_erps_memory_manager_db_entry_t * const region_entry_p)
{
    uint16_t i = 0, j = 0;

    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; i++) { /*find erp_id*/
        for (j = 0; j < SX_ATCAM_ERPS_PER_REGION; j++) {
            if ((region_entry_p->erp_arr[j].erp_id == i)) {
                break;
            }
        }
        if (j == SX_ATCAM_ERPS_PER_REGION) {
            return i;
        }
    }

    return ATCAM_INVALID_ERP_ID;
}
