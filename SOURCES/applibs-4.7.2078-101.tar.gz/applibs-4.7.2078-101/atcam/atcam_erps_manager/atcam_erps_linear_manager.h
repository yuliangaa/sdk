/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ERP_LINEAR_MANAGER_H_INCL__
#define __ERP_LINEAR_MANAGER_H_INCL__

/**
 * erp Linear manager module responsible for management of erp linear tables
 * The module has the following operations:
 *  - Init/Deinit.
 *  - Add block/Delete block
 *  - Lock/Release
 */

#include "sx/utils/linear_manager.h"
#include "sx/sdk/sx_types.h"
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum atcam_erps_linear_manager_block_size {
    BLOCK_SIZE_ONE    = 1,
    BLOCK_SIZE_TWO    = 2,
    BLOCK_SIZE_THREE  = 3,
    BLOCK_SIZE_FOUR   = 4,
    BLOCK_SIZE_SIX    = 6,
    BLOCK_SIZE_EIGHT  = 8,
    BLOCK_SIZE_NINE   = 9,
    BLOCK_SIZE_TWELVE = 12,
    BLOCK_SIZE_MIN    = BLOCK_SIZE_ONE,
    BLOCK_SIZE_MAX    = BLOCK_SIZE_TWELVE,
    BLOCK_SIZE_NUM    = 8
} atcam_erps_linear_manager_block_size_e;

typedef uint32_t atcam_erps_linear_manager_handle_t;

typedef linear_manager_index_t atcam_erps_linear_manager_index_t;

typedef linear_manager_block_length_t atcam_erps_linear_manager_block_length_t;

/**
 * Callback function.
 * Copies contents of block from old index to new index and changes all references to the block
 * This callback is called when erp linear manager relocates a block
 * @param[in] handle                - The handle to the block which is being relocated
 * @param[in] size                  - The block size
 * @param[in] region_id             - The region id of entry in data block to relocate
 * @param[in] old_index             - index to relocate from
 * @param[in] new_index             - new index to relocate to
 */
typedef sx_status_t (*atcam_erps_linear_manager_block_relocate_t)(atcam_erps_linear_manager_handle_t       handle,
                                                                  atcam_erps_linear_manager_block_length_t size,
                                                                  sx_acl_region_id_t                       region_id,
                                                                  atcam_erps_linear_manager_index_t        new_index,
                                                                  uint8_t                                  erp_id);

typedef linear_manager_block_type_e atcam_erps_linear_manager_block_type_e;

typedef linear_manager_allocation_types_t atcam_erps_linear_manager_allocation_types_t;

typedef struct atcam_erps_linear_manager_params {
    atcam_erps_linear_manager_block_relocate_t relocate_cb;
} atcam_erps_linear_manager_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize erp linear manager module
 * *
 * @return SX_STATUS_DB_ALREADY_INITIALIZED if db was already initialized
 * @return SX_STATUS_MEMORY_ERROR if no space for allocation
 */

sx_status_t atcam_erps_linear_manager_init(atcam_erps_linear_manager_params_t *user_params);

/**
 * Deinitialize erp linear manager module
 *
 *@return SX_STATUS_ERROR if there are still users which didn't do deinit
 */

sx_status_t atcam_erps_linear_manager_deinit(const boolean_t forced_deinit);


/**
 * Add block to erp linear manager table
 * A user calls this function to add new block.
 * The allocated block is either contiguous or linked-list, according to the user.
 * Further operations on the block are done using the returned handle.
 *
 * @param[in] region_id             - The region id which describes which entry is added
 * @param[in] size                  - Size of block
 * @param[out] handle               - Returns a handle to the new block
 *
 * @return SX_STATUS_PARAM_NULL if handle param is NULL
 * @return SX_STATUS_NO_RESOURCES if linear table is full
 *
 */
sx_status_t atcam_erps_linear_manager_block_add(sx_acl_region_id_t                       region_id,
                                                atcam_erps_linear_manager_block_length_t size,
                                                atcam_erps_linear_manager_handle_t     * handle);

/**
 * Delete a block from erp linear table
 *
 * @param[in] handle               - A handle to a block
 * If there are references to block function will return error
 *
 * @return SX_STATUS_PARAM_ERROR if handle is invalid
 */
sx_status_t atcam_erps_linear_manager_block_delete(atcam_erps_linear_manager_handle_t handle);


/**
 * Lock a block in order to perform HW operations
 * Call this function to prevent relocation of the block until it is released.
 * @param[in] handle               - A handle to the block
 * @param[out] index_p             - Caller-provided index pointer to be filled with index where the block is located
 * @param[out] size                - Returns the actual size of the block
 *
 * @return SX_STATUS_PARAM_ERROR if handle is invalid
 * @return SX_STATUS_PARAM_NULL if size or index param is null
 */
sx_status_t atcam_erps_linear_manager_handle_lock(atcam_erps_linear_manager_handle_t        handle,
                                                  atcam_erps_linear_manager_index_t        *index_p,
                                                  atcam_erps_linear_manager_block_length_t *size_p);

/**
 * Release a locked block, so it can be relocated again
 *
 * @param[in] handle               - A handle to block
 *
 * @return SX_STATUS_PARAM_ERROR if handle is invalid
 */
sx_status_t atcam_erps_linear_manager_handle_release(atcam_erps_linear_manager_handle_t handle);


sx_status_t atcam_erps_linear_manager_dump(dbg_dump_params_t *dbg_dump_params_p);


#endif /* __ERP_LINEAR_MANAGER_H_INCL__ */
