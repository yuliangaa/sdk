/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_DB_H__
#define __ATCAM_ERPS_DB_H__

#include "sx/sdk/sx_types.h"
#include "complib/cl_fleximap.h"
#include "complib/cl_qmap.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"


/************************************************
 *  Global definitions
 ***********************************************/

/* Define the number of counter we keep for single/double bad collisions */
#define BAD_COLLISION_COUNTERS_NUM 5

/**
 * When defining a new eRP, we must know all other eRPs that exist for the
 * same region.
 */
typedef struct atcam_erps_db_erp_params {
    sx_atcam_key_mask_t mask;         /* the mask of that eRP */
    sx_atcam_erp_id_t   region_erps[SX_ATCAM_ERPS_PER_REGION];         /* the ids of other eRPs within that region */
    uint8_t             region_erps_num;
    boolean_t           bf_enabled;
    uint8_t             bf_bank;
} atcam_erps_db_erp_params_t;

typedef struct atcam_erps_db_prune_db_entry {
    cl_pool_item_t       pool_item;                   /* These entries are allocated from a pool (across regions and eRPS) */
    cl_fmap_item_t       fmap_item;
    sx_atcam_key_value_t key;
    cl_qmap_t            current_erp_rules;
    cl_qmap_t            other_erp_rules;
} atcam_erps_db_prune_db_entry_t;

typedef struct atcam_erps_db_prune_db {
    uint8_t             main_id, sec_id;
    boolean_t           allocated;
    sx_atcam_key_mask_t mask;
    cl_fmap_t           rules_refs;
} atcam_erps_db_prune_db_t;

typedef struct atcam_erps_db_erp {
    sx_atcam_region_id_t     region_id;     /* Id of the region this eRP belongs to */
    sx_atcam_erp_id_t        erp_id;        /* id among all other erp's (for that region) */
    boolean_t                allocated;
    sx_atcam_key_mask_t      mask;
    cl_qmap_t                rules;
    atcam_erps_db_prune_db_t prune_maps[SX_ATCAM_ERPS_PER_REGION];
    boolean_t                bf_enabled;   /* determines if bf changes per insert / delete to this erp */
    uint8_t                  bf_bank;   /* This never changes once this erp is created (including (!) reordering) */
} atcam_erps_db_erp_t;

typedef struct atcam_erps_db_ctcam {
    sx_atcam_region_id_t region_id;
    boolean_t            allocated;
    cl_qmap_t            rules;
} atcam_erps_db_ctcam_t;

/* Counters for the total number of bad collisions we have. We count for single/double kvd bank separately.
 * We count if we have one, two, three or four+ collisions for each type (a.k.a SS, SSS, SSSS, DD, DDD etc.)
 */
typedef struct atcam_erps_db_bad_collision_counters {
    uint32_t single_bad_collision_count[BAD_COLLISION_COUNTERS_NUM];
    uint32_t double_bad_collision_count[BAD_COLLISION_COUNTERS_NUM];
} atcam_erps_db_bad_collision_counters_t;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes eRP db.
 *
 * @param[in]  num_of_regions - The total number of regions that should be supported.
 * @param[in]  num_of_erps        - The total number of eRP that should be supported.
 *
 * Note: This should be the max number, and function itself will allocate the actual necessary size.
 *
 * @return
 *    SX_STATUS_NO_MEMORY - if there's not enough memory to allocate the requested number of eRPS
 *    SX_STATUS_SUCCESS   - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_init(const uint32_t num_of_regions,
                               const uint32_t num_of_erps);


/**
 * De-Initializes eRP db.
 *
 * @param[in]  forced_deinit - If true, deleted all eRPs, even those not deleted
 *                             explicitly before. Otherwise, function will fail.
 *
 * @return
 *    SX_STATUS_RESOURCE_IN_USE    - if not forced to de-init, and some eRP were not freed.
 *    SX_STATUS_SUCCESS            - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_deinit(const boolean_t forced_deinit);


/**
 * Allocates a new eRP for the given region with the given id. Also returns a pointer
 * for the new eRP if requested.
 *
 * @param[in]     region_id - The id of the region this eRP belongs to.
 * @param[in]     erp_id    - The id of the new eRP to allocate (within that region)
 * @param[in]     params    - The additional parameters needed to complete this creation.
 * @param[inout]  erp       - If not null, a pointer to the newly allocated eRP
 *
 * Note: params may contain the id of the erp that is about to be allocated, but cannot
 *               contain invalid eRP id, duplicates values, or out of range ids.
 *
 * @return
 *    SX_STATUS_PARAM_NULL          - if NULL params were given
 *    SX_STATUS_PARAM_EXCEEDS_RANGE - if eRP id exceeds range (either erp_id, or within params)
 *    SX_STATUS_ALREADY_EXISTS      - if this id for that region was already allocated, or if params contains the same id more than once.
 *    SX_STATUS_NO_RESOURCES        - if no more eRPs can be allocated.
 *    SX_STATUS_SUCCESS             - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_allocate(const sx_atcam_region_id_t        region_id,
                                       const sx_atcam_erp_id_t           erp_id,
                                       const atcam_erps_db_erp_params_t *params,
                                       atcam_erps_db_erp_t             **erp);


/**
 * De-Allocates the eRP with id 'erp_id'. Once deallocated, this eRP is free to used by any
 * other region.
 *
 * Note: Caller MUST first remove all rules associated with this eRP before deleting
 * this eRP or function will fail.
 *
 * @param[in]  region_id - The id of the region this eRP belongs to.
 * @param[in]  erp_id    - The id of the eRP to de-allocate.
 *
 * @return
 *    SX_STATUS_RESOURCE_IN_USE - if not all rules were explicitly deleted from that eRP before.
 *    SX_STATUS_ENTRY_NOT_FOUND - if no such eRP exists
 *    SX_STATUS_PARAM_ERROR     - if eRP blocks count differ from the blocks count of other eRPs of that region
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_deallocate(const sx_atcam_region_id_t region_id,
                                         const sx_atcam_erp_id_t    erp_id);


/**
 * Checks if specific eRP exists within a region, and returns a reference to it if requested.
 *
 * @param[in]  region_id - The region of the eRP
 * @param[in]  erp_id    - The id of the eRP
 * @param[in]  erp       - If not NULL, a pointer to that eRP.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if no such eRP exists
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_erp_get(const sx_atcam_region_id_t region_id,
                                  const sx_atcam_erp_id_t    erp_id,
                                  atcam_erps_db_erp_t      **erp);


/**
 * Adds a rule to an eRP
 *
 * @param[in]  region_id - The id of the region this rule belongs to.
 * @param[in]  erp_id    - The id of the eRP.
 * @param[in]  rule      - A pointer to the rule to add.
 *
 * @return
 *    SX_STATUS_PARAM_NULL           - if a NULL pointer to that rule was passed
 *    SX_STATUS_ENTRY_NOT_FOUND      - if not such eRP exists for that region
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - if the rule was already inserted
 *    SX_STATUS_MEMORY_ERROR         - if unable to insert new rule
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_add_rule(const sx_atcam_region_id_t   region_id,
                                       const sx_atcam_erp_id_t      erp_id,
                                       const atcam_rules_db_rule_t* rule);


/**
 * deletes a rule from an eRP
 *
 * @param[in]  region_id - The id of the region this rule belongs to.
 * @param[in]  erp_id    - The id of the eRP.
 * @param[in]  rule_id   - The id of the rule to delete.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if not such eRP exists for that region, or no such rule within that eRP
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_delete_rule(const sx_atcam_region_id_t region_id,
                                          const sx_atcam_erp_id_t    erp_id,
                                          const sx_atcam_rule_id_t   rule_id);


/**
 * Checks if a specific erp (per region) is empty or not.
 *
 * @param[in]  region_id - The region of the erp
 * @param[in]  erp_id    - The erp to check
 * @param[in]  boolean_t - TRUE if erp is empty, FALSE otherwise
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if no such erp exists
 *    SX_STATUS_PARAM_NULL      - if at least one of input params is null
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_is_erp_empty(const sx_atcam_region_id_t region_id,
                                       const sx_atcam_erp_id_t    erp_id,
                                       boolean_t                 *is_empty);


/**
 * Allocates DB entry for ctcam rules for a specific region. Logically, ctcam is divided for different
 * regions.
 *
 * @param[in]     region_id                     - The id of the region to allocate ctcam entry for.
 * @param[inout]  atcam_erps_db_ctcam_t - If not null, a pointer to the newly allocated ctcam object
 *
 * @return
 *    SX_STATUS_MEMORY_ERROR   - if no more memory is left
 *    SX_STATUS_ALREADY_EXISTS - if ctcam object was already allocated for the given region
 *    SX_STATUS_SUCCESS        - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_ctcam_allocate(const sx_atcam_region_id_t region_id,
                                         atcam_erps_db_ctcam_t    **ctcam);

/**
 * De-allocates ctcam object from a given region (DB-wise)
 *
 * Note: Caller MUST first remove all rules associated with this region's ctcam before deleting
 * this ctcam or function will fail.
 *
 * @param[in]  region_id - The id of the region this ctcam object belongs to.
 *
 * @return
 *    SX_STATUS_RESOURCE_IN_USE - if not all rules were explicitly deleted from that ctcam before.
 *    SX_STATUS_ENTRY_NOT_FOUND - if no ctcam was allocated for that region before
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_ctcam_deallocate(const sx_atcam_region_id_t region_id);


/**
 * Checks if ctcam was allocated for a specific region, and returns a reference to it if requested.
 *
 * @param[in]   region_id                               - The region of the eRP
 * @param[out]  atcam_erps_db_ctcam_t   - If not NULL, a pointer to that eRP.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if ctcam wasn't allocated for the given region before
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_ctcam_get(const sx_atcam_region_id_t region_id,
                                    atcam_erps_db_ctcam_t    **ctcam);


/**
 * Checks if ctcam of a specific region is empty (does not contain any rules)
 *
 * @param[in]  region_id - The region of the ctcam
 * @param[in]  boolean_t - TRUE is ctcam is empty, FALSE otherwise
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if ctcam wasn't allocated for the given region before
 *    SX_STATUS_PARAM_NULL      - if at least one of input params is null
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_is_ctcam_empty(const sx_atcam_region_id_t region_id, boolean_t *is_empty);


/**
 * Checks if ctcam was allocated for the given region
 *
 * @param[in]  region_id - The region of the ctcam
 * @param[in]  has_ctcam - TRUE is ctcam was allocated , FALSE otherwise
 *
 * @return
 *    SX_STATUS_PARAM_NULL      - if at least one of input params is null
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_has_ctcam(const sx_atcam_region_id_t region_id, boolean_t *has_ctcam);


/**
 * Adds rule to ctcam for the given region
 *
 * @param[in]  region_id - The id of the region this belongs to.
 * @param[in]  rule      - Pointer to the rule to add.
 *
 * @return
 *    SX_STATUS_PARAM_NULL           - if NULL pointer to the rule was given
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - if the given rule was already inserted to this region's ctcam
 *    SX_STATUS_MEMORY_ERROR         - if unable to insert due to memory error
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_ctcam_add_rule(const sx_atcam_region_id_t   region_id,
                                         const atcam_rules_db_rule_t *rule);

/**
 * Deletes rule from the ctcam for the given region
 *
 * @param[in]  region_id - The id of the region this belongs to.
 * @param[in]  rule_id   - The id of the rule to delete.
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if the given rule wasn't inserted into this region ctcam
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_ctcam_delete_rule(const sx_atcam_region_id_t region_id,
                                            const sx_atcam_rule_id_t   rule_id);


/**
 * Adds a prune map for an eRP with id 'erp_id' of region 'region_id'. The DB will
 * be built using the other_erp_id info.
 *
 * Note: in order to keep the prune DB as efficient and as accurate as possible, one must update
 * other eRPs of a region when changes has been made (a new eRP was formed, or one was deleted).
 * The update is done using the function below, and 'atcam_erps_db_erp_remove_prune_map' as well.
 *
 * @param[in]  region_id      - The id of the region this eRP belongs to.
 * @param[in]  erp_id         - The id of the eRP.
 * @param[in]  other_erp_id   - The id of the other eRP
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if not such eRP exists for that region (either erp_id or other_erp_id)
 *    SX_STATUS_PARAM_ERROR     - if other_erp == erp_id
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_add_prune_map(const sx_atcam_region_id_t region_id,
                                            const sx_atcam_erp_id_t    erp_id,
                                            const sx_atcam_erp_id_t    other_erp_id);

/**
 * Removes a prune map for an eRP with id 'erp_id' of region 'region_id'.
 *
 * @param[in]  region_id      - The id of the region this eRP belongs to.
 * @param[in]  erp_id         - The id of the eRP.
 * @param[in]  other_erp_id   - The id of the other eRP
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if not such eRP exists for that region (either erp_id or other_erp_id)
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_erp_remove_prune_map(const sx_atcam_region_id_t region_id,
                                               const sx_atcam_erp_id_t    erp_id,
                                               const sx_atcam_erp_id_t    other_erp_id);

/**
 * Validates a list of eRP. Makes sure that all eRP_ids are valid, within range, of eRP that
 * were actually allocated, and that no duplicate entries appear.
 * Use this function to validate the list of eRP before storing them within a region, for any region.
 *
 * @param[in]  region_id      - The id of the region this eRP belongs to.
 * @param[in]  erps_ids       - A list of eRP ids
 * @param[in]  valid_erps_num - The size of the list above. max size cannot exceed SX_ATCAM_ERPS_PER_REGION
 *
 * @return
 *    SX_STATUS_PARAM_NULL           - if a NULL erp_ids were passed
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - if num of erps exceeds the range, or if any of the erps within the list exceed that range.
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - if the same eRP id appears more than once within erps_ids
 *    SX_STATUS_ENTRY_NOT_FOUND      - if one of the ids within erps_ids does not exist for the given region
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_check_erps_ids(const sx_atcam_region_id_t region_id,
                                         const sx_atcam_erp_id_t   *erps_ids,
                                         const uint8_t              valid_erps_num);

/**
 * Allocates a new entry for prune-db.
 * The new entry is identified using the given key 'intersected-value', and should only be access
 * via this key.
 *
 * Also return the new entry if requested.
 *
 * @param[in]     prune_map           - The prune map to allocate the entry to.
 * @param[in]     intersected_value   - The key of the new entry
 * @param[inout]  prune_db_entry      - If not NULL, pointer to the new entry allocated
 *
 * @return
 *    SX_STATUS_PARAM_NULL - if prune_map or intersected values are NULL
 *    SX_STATUS_SUCCESS    - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_prune_entry_allocate(atcam_erps_db_prune_db_t        *prune_map,
                                               const sx_atcam_key_value_t      *intersected_value,
                                               atcam_erps_db_prune_db_entry_t **prune_db_entry);
/**
 * De-allocates an entry from prune-db.
 *
 *
 * @param[in]     prune_map      - The prune map to delete the given entry from.
 * @param[in]     prune_db_entry - The entry to delete.
 *
 * @return
 *    SX_STATUS_PARAM_NULL      - if prune_map or prune_db_entry are NULL
 *    SX_STATUS_RESOURCE_IN_USE - if not all references from the entry were deleted before
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_db_prune_entry_deallocate(atcam_erps_db_prune_db_t       *prune_map,
                                                 atcam_erps_db_prune_db_entry_t *prune_db_entry);

/**
 * Check if an intended rule has bad collision or exact match in the specific region & erp.
 * Bad collision - two rules in the same region&erp are considered as bad collision if the value
 *                 bits specified by the erp mask are the same in both rules.
 * Exact match   - two rules in the same region&erp are considered as exact match if their
 *                 key value&mask bits are exactly the same.
 * Exact match rule is also a bad collision rule i.e. bad_collision_count >= exact_match_count.
 *
 * NOTE: It is assumed that the rule has all its info updated: region_id, erp_id, delta, key&mask.
 *
 * @param[in]   rule                  - Pointer to the rule which should be entered to the bad collision db.
 * @param[out]  bad_collision_count_p - Return the number of bad collisions found.
 * @param[out]  exact_match_count_p   - Return the number of exact matches found.
 *
 * @return
 *    SX_STATUS_PARAM_NULL            - if a parameter is NULL.
 *    SX_STATUS_ERROR                 - internal problem searching the db.
 *    SX_STATUS_SUCCESS               - if operation has finished successfully. *
 */
sx_status_t atcam_erps_db_bad_collision_check(atcam_rules_db_rule_t *rule,
                                              uint32_t              *bad_collision_count_p,
                                              uint32_t              *exact_match_count_p);

/**
 * Add rule to the bad collision db.
 * Note: no validation is done if the added rule has bad collisions with existing entries.
 *
 * @param[in]   rule   - Pointer to the rule which should be entered to the bad collision db.
 *
 * @return
 *    SX_STATUS_PARAM_NULL            - if rule is NULL.
 *    SX_STATUS_ERROR                 - internal problem searching the db.
 *    SX_STATUS_SUCCESS               - if operation has finished successfully. *
 */
sx_status_t atcam_erps_db_bad_collision_add_rule(atcam_rules_db_rule_t *rule);

/**
 * Remove rule from the bad collision db..
 *
 * @param[in]   rule       - Pointer to the rule db entry which should be removed from the bad collision db.
 *
 * @return
 *    SX_STATUS_PARAM_NULL - if rule is NULL.
 *    SX_STATUS_ERROR      - internal problem searching the db.
 *    SX_STATUS_SUCCESS    - if operation has finished successfully. *
 */
sx_status_t atcam_erps_db_bad_collision_remove_rule(atcam_rules_db_rule_t* rule);


/**
 * Get the counters of bad collisions in the ATCAM.
 *
 * @param[in]   counters_p - Pointer to the structure to be filled with the collision counters.
 *
 * @return
 *    SX_STATUS_PARAM_NULL - if the provided param is null.
 *    SX_STATUS_ERROR      - internal problem searching the db.
 *    SX_STATUS_SUCCESS    - if operation has finished successfully. *
 */
sx_status_t atcam_erps_db_bad_collision_counters_get(atcam_erps_db_bad_collision_counters_t *counters_p);

/**
 * Update the bf_enabled field for erp_id
 *
 * @param[in] region_id - The id of the region this eRP belongs to.
 * @param[in] erp_id - The id of the eRP to update
 * @param[in] bf_enabled - the bf_enabled field value
 *
 * @return
 *    SX_STATUS_ENTRY_NOT_FOUND - if no such eRP exists
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 *
 */
sx_status_t atcam_erps_db_update_bf_enable(const sx_acl_region_id_t region_id,
                                           const sx_atcam_erp_id_t  erp_id,
                                           const boolean_t          bf_enabled);

#endif /* __ATCAM_ERPS_DB_H__ */
