/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef ATCAM_ATCAM_RULES_MANAGER_ATCAM_LARGE_KEY_DB_H_
#define ATCAM_ATCAM_RULES_MANAGER_ATCAM_LARGE_KEY_DB_H_

#include "complib/cl_types.h"
#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_types.h"
#include <utils/utils.h>

/************************************************
 * Defines
 ***********************************************/
#define LARGE_KEY_HANDLE_INVALID 0
#define NUM_OF_LARGE_KEY_IDS     64000


/************************************************
 *  Type definitions
 ***********************************************/

typedef void* sx_atcam_large_entry_key_handle_t;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  Init Large Key DB
 *
 * @param[in] large_key_entries_num - Number of large key entry IDs
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_NO_MEMORY if memory allocation fails.
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_db_init(const uint32_t large_key_entries_num);

/**
 *  DeInit Large Key DB
 *
 * @param[in] is_forced - controls deinit type
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_NO_MEMORY if memory allocation fails.
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_db_deinit(const boolean_t is_forced);

/**
 *  Insert a rule to large key DB
 *  User provides a Rule key & Mask for convenient usage
 *  DB actually holds a key in size of LARGE_KEY_PREFIX_BYTES which
 *  is the result of a bitwise AND of key and erp mask
 *
 * @param[in]  region_id             - region ID of this rule
 * @param[in]  erp_id                - eRP ID for this rule
 * @param[in]  rule_key_p            - Rule Key and mask fields
 * @param[in]  rule_delta_p          - Rule delta related to the rule's erp
 * @param[out] large_key_handle      - Returned large key handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_NO_RESOURCES if DB is exhausted
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_db_rule_insert(const sx_atcam_region_id_t         region_id,
                                           const sx_atcam_erp_id_t            erp_id,
                                           const sx_atcam_key_t              *rule_key_p,
                                           const sx_atcam_key_delta_t        *rule_delta_p,
                                           sx_atcam_large_entry_key_handle_t *large_key_handle);

/**
 *  Delete a rule from large key DB
 *
 * @param[in] large_key_handle - Rule's large key handle
 * @param[out] is_single       - True if usage_count of large key handle is 1
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_db_rule_del(sx_atcam_large_entry_key_handle_t large_key_handle, boolean_t *is_single);

/**
 * Get large key ID from large key handle
 *
 * @param[in]   large_key_handle  - Rule's large key handle
 * @param[out]  large_key_id      - Large key ID for that handle
 * @param[out]  is_single        - This is the only handle using this large key handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_id_get(const sx_atcam_large_entry_key_handle_t large_key_handle,
                                   sx_atcam_large_entry_key_id_t          *large_key_id,
                                   boolean_t                              *is_single);

/**
 *  Generate dump for this DB
 *
 * @param[in] stream         - output stream
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR otherwise.
 */
sx_status_t atcam_large_key_db_generate_dump(dbg_dump_params_t *dbg_dump_params_p);


#endif /* ATCAM_ATCAM_RULES_MANAGER_ATCAM_LARGE_KEY_DB_H_ */
