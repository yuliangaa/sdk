/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_RULES_CTCAM_PRIO_DB_H__
#define __ATCAM_RULES_CTCAM_PRIO_DB_H__

/************************************************
 *  Includes
 ***********************************************/
#include "complib/sx_log.h"
#include "sx/sdk/sx_status.h"
#include "sx/utils/psort.h"
#include "atcam_rules_db.h"
#include <stdio.h>

/************************************************
 *  Global definitions
 ***********************************************/

typedef sx_status_t (*move_cb_t)(sx_atcam_region_id_t region_id,
                                 uint16_t             size,
                                 uint16_t             dest_offset,
                                 uint16_t             source_offset);

typedef struct {
    uint32_t region_id;
    uint32_t region_ctcam_size;
    uint32_t ctcam_num_of_rules;
} ctcam_rules_db_region_info_t;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes ctcam rules db.
 * This DB holds ctcam rules sorted by priority.
 *
 * @param[in] num_of_ctcam_regions - number of regions supported by this module
 * @param[in] movc_cb - cb which will be called upon rule movement
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_init(const uint32_t num_of_ctcam_regions, const move_cb_t move_cb);

/**
 * Destroy ctcam rules db.
 *
 * @param[in] is_forced - should force delete. if is_forced = FALSE destroy will fail
 *                        if DB is not empty
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_deinit(const boolean_t is_forced);

/**
 * Add new region to CTCAM DB.
 *
 * @param[in] region_id - region id
 * @param[in] region_size - region CTCAM size
 * @param[in] max_priority - region maximum supported priority
 * @param[in] min_priority - region minimum supported priority
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_add_region(const uint32_t                    region_id,
                                                 const uint32_t                    region_size,
                                                 const sx_flex_acl_rule_priority_t max_priority,
                                                 const sx_flex_acl_rule_priority_t min_priority);

/**
 * Remove region from CTCAM DB.
 *
 * @param[in] region_id - region id
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_del_region(const uint32_t region_id);


/**
 * Change region size.
 *
 * @param[in] region_id - region id
 * @param[in] new_size - region updated size
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_resize_region(const uint32_t region_id, const uint32_t new_size);


/**
 * Add new (pre-allocated) rule.
 *
 * @param[in] region_id - region id
 * @param[in][out] rule_p - rule pointer - priority must be updated.
 *                          ctcam_index will be updated as output
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_add_rule(const uint32_t region_id, atcam_rules_db_rule_t *rule_p);

/**
 * Delete (pre-allocated) rule.
 *
 * @param[in] region_id - region id
 * @param[in] rule_p - rule pointer
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_del_rule(const uint32_t region_id,  atcam_rules_db_rule_t *rule_p);


/**
 * Get region info.
 *
 * @param[in] region_id - region id
 * @param[out] region_info_p - region information, must not be NULL
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_get_region_info(const uint32_t                region_id,
                                                      ctcam_rules_db_region_info_t *region_info_p);

/**
 * Change psort region priority
 *
 * @param[in] region_id - region id
 * @param[in] old_prio - old psort region priority
 * @param new_prio - new  psort region priority
 * @return
 */
sx_status_t atcam_rules_ctcam_prio_db_change_prio(const uint32_t              region_id,
                                                  sx_flex_acl_rule_priority_t min_prio,
                                                  sx_flex_acl_rule_priority_t max_prio,
                                                  int32_t                     prio_change);
/**
 * Dump ctcam rules db info
 *
 * @param[in] fl - destination file
 *
 * @return sx_status
 */
sx_status_t atcam_rules_ctcam_prio_db_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* ifndef __ATCAM_RULES_CTCAM_PRIO_DB_H__ */
