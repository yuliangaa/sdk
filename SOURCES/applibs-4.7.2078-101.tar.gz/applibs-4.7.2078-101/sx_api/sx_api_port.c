/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_port.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>
#include <include/resource_manager/resource_manager.h>

#undef __MODULE__
#define __MODULE__ SX_API_PORT

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_port_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_PORT_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_PORT_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_device_set(const sx_api_handle_t handle,
                                   const sx_access_cmd_t cmd,
                                   const sx_device_id_t  device_id,
                                   const sx_mac_addr_t  *base_mac_addr_p,
                                   sx_port_attributes_t *port_attributes_list_p,
                                   const uint32_t        port_cnt)
{
    sx_status_t                      api_rc = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size = 0;
    sx_api_port_device_set_params_t *cmd_body;
    uint32_t                         i = 0;

    SX_API_LOG_ENTER();

    if (FALSE == SX_DEVICE_ID_CHECK_RANGE(device_id)) {
        SX_LOG_ERR("Device ID (%u) exceeds range (%u-%u).\n", device_id,
                   SX_DEVICE_ID_MIN_MAX);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_size = sizeof(sx_api_port_device_set_params_t);
    if (SX_ACCESS_CMD_ADD == cmd) {
        cmd_size += (sizeof(sx_port_attributes_t) * port_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body = (sx_api_port_device_set_params_t*)cl_malloc(cmd_size);
    if (!cmd_body) {
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_MEMORY;
    }

    SX_MEM_CLR_TYPE(cmd_body, sx_api_port_device_set_params_t);

    cmd_body->cmd = cmd;
    cmd_body->device_id = device_id;
    cmd_body->swid = SX_SWID_ID_DONTCARE;
    cmd_body->port_cnt = port_cnt;

    /* O/W: */
    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (NULL == port_attributes_list_p) {
            CL_FREE_N_NULL(cmd_body);
            SX_LOG_ERR("Port attribute list is NULL.\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
        /* O/W: */
        SX_MEM_CPY_ARRAY(cmd_body->port_attributes, port_attributes_list_p,
                         port_cnt, sx_port_attributes_t);
        SX_MEM_CPY_TYPE(&(cmd_body->base_mac_addr), base_mac_addr_p,
                        sx_mac_addr_t);

        break;

    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        CL_FREE_N_NULL(cmd_body);
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_DEVICE_SET_E,
                                         (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        if (SX_ACCESS_CMD_ADD == cmd) {
            for (i = 0; i < cmd_body->port_cnt; i++) {
                port_attributes_list_p[i].log_port =
                    cmd_body->port_attributes[i].log_port;
            }
        }
    }

    CL_FREE_N_NULL(cmd_body);
    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_device_get(const sx_api_handle_t handle,
                                   const sx_device_id_t  device_id,
                                   const sx_swid_t       swid,
                                   sx_port_attributes_t *port_attributes_list_p,
                                   uint32_t             *port_cnt_p)
{
    sx_status_t                      api_rc = SX_STATUS_SUCCESS;
    sx_api_port_device_get_params_t *cmd_body = NULL;
    uint32_t                         cmd_size = 0;

    SX_API_LOG_ENTER();

    if (NULL == port_cnt_p) {
        SX_LOG_ERR("Ports list length is NULL.\n");
        api_rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (NULL == port_attributes_list_p) {
        *port_cnt_p = 0;
    }

    cmd_size = sizeof(sx_api_port_device_set_params_t)
               + sizeof(sx_port_attributes_t) * (*port_cnt_p);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body = (sx_api_port_device_get_params_t*)cl_malloc(cmd_size);
    if (!cmd_body) {
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_MEMORY;
    }
    memset(cmd_body, 0, cmd_size);

    cmd_body->cmd = SX_ACCESS_CMD_GET;

    if (FALSE == SX_DEVICE_ID_CHECK_RANGE(device_id)) {
        SX_LOG_ERR("Device ID (%u) exceeds range (%u-%u).\n", device_id,
                   SX_DEVICE_ID_MIN_MAX);
        api_rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* O/W: */
    cmd_body->device_id = device_id;
    if ((SX_SWID_ID_DONTCARE != swid) && (FALSE
                                          == SX_DEVICE_ID_CHECK_RANGE(device_id))) {
        SX_LOG_ERR("SwID ID (%u) exceeds range (%u-%u).\n", swid,
                   SX_SWID_ID_MIN_MAX);
        api_rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* O/W: */
    cmd_body->swid = swid;

    /* O/W: */
    if ((NULL == port_attributes_list_p) || (0 == *port_cnt_p)) {
        cmd_body->cmd = SX_ACCESS_CMD_COUNT;
        port_attributes_list_p = NULL;
    } else {
        cmd_body->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body->port_cnt = *port_cnt_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_DEVICE_GET_E,
                                         (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *port_cnt_p = cmd_body->port_cnt;
        if (NULL != port_attributes_list_p) {
            SX_MEM_CPY_ARRAY(port_attributes_list_p, cmd_body->port_attributes,
                             *port_cnt_p, sx_port_attributes_t);
        }
    }

out:
    if (cmd_body) {
        CL_FREE_N_NULL(cmd_body);
    }
    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_device_base_mac_get(const sx_api_handle_t handle,
                                            const sx_device_id_t  device_id,
                                            sx_mac_addr_t        *base_mac_addr_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_port_device_mac_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(base_mac_addr_p, "base_mac_addr_p")) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("base_mac_addr_p is NULL.\n");
        goto out;
    }

    cmd_body.device_id = device_id;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_PORT_DEVICE_MAC_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_device_mac_get_params_t));

    SX_MEM_CPY(*base_mac_addr_p, cmd_body.base_mac_addr);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_mapping_set(const sx_api_handle_t    handle,
                                    const sx_port_log_id_t  *log_port_list_p,
                                    const sx_port_mapping_t *port_mapping_list_p,
                                    const uint32_t           port_cnt)
{
    sx_status_t                  api_rc = SX_STATUS_SUCCESS;
    sx_api_port_map_set_params_t cmd_body;
    uint8_t                     *cmd_body_buffer = NULL;
    uint32_t                     cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_api_port_map_set_params_t);

    if ((sizeof(sx_port_mapping_t) + sizeof(sx_port_log_id_t)) * port_cnt > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* Allocate the port mapping list and log port list arrays in the command body */
    cmd_body.port_mapping_list = (sx_port_mapping_t*)cl_malloc(
        sizeof(sx_port_mapping_t) * port_cnt);
    if (!cmd_body.port_mapping_list) {
        SX_LOG_ERR(
            "Failed to allocate memory for the port mapping list array.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body.log_port_list = (sx_port_log_id_t*)cl_malloc(
        sizeof(sx_port_log_id_t) * port_cnt);
    if (!cmd_body.log_port_list) {
        SX_LOG_ERR("Failed to allocate memory for the log port list array.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_num = port_cnt;

    if (NULL == log_port_list_p) {
        SX_LOG_ERR("Logical Ports List is NULL.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == port_mapping_list_p) {
        SX_LOG_ERR("Ports mapping List is NULL.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    SX_MEM_CPY_ARRAY(cmd_body.log_port_list, log_port_list_p, port_cnt,
                     sx_port_log_id_t);
    SX_MEM_CPY_ARRAY(cmd_body.port_mapping_list, port_mapping_list_p, port_cnt,
                     sx_port_mapping_t);

    /* Buffer size =
     * 4 bytes                              : cmd
     * 4 bytes                              : port_num
     * port_num * sizeof(sx_port_mapping_t) : port_mapping_list
     * port_num * sizeof(sx_port_log_id_t)  : log_port_list */
    cmd_body_buffer_size = 2 * sizeof(uint32_t) +
                           cmd_body.port_num * sizeof(sx_port_mapping_t) +
                           cmd_body.port_num * sizeof(sx_port_log_id_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);

    if (!cmd_body_buffer) {
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    sx_api_serialize_port_map_set_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MAPPING_SET_E,
                                         (uint8_t*)cmd_body_buffer,
                                         cmd_body_buffer_size);

    CL_FREE_N_NULL(cmd_body.port_mapping_list);
    CL_FREE_N_NULL(cmd_body.log_port_list);
    CL_FREE_N_NULL(cmd_body_buffer);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_mapping_get(const sx_api_handle_t   handle,
                                    const sx_port_log_id_t *log_port_list_p,
                                    sx_port_mapping_t      *port_mapping_list_p,
                                    const uint32_t          port_cnt)
{
    sx_status_t                  api_rc = SX_STATUS_SUCCESS;
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_api_port_map_get_params_t cmd_body;
    uint8_t                     *cmd_body_buffer = NULL;
    uint32_t                     cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_api_port_map_get_params_t);

    if ((sizeof(sx_port_mapping_t) + sizeof(sx_port_log_id_t)) * port_cnt > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* Allocate the port mapping list and log port list arrays in the command body */
    cmd_body.port_mapping_list = (sx_port_mapping_t*)cl_malloc(
        sizeof(sx_port_mapping_t) * port_cnt);
    if (!cmd_body.port_mapping_list) {
        SX_LOG_ERR(
            "Failed to allocate memory for the port mapping list array.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body.log_port_list = (sx_port_log_id_t*)cl_malloc(
        sizeof(sx_port_log_id_t) * port_cnt);
    if (!cmd_body.log_port_list) {
        SX_LOG_ERR("Failed to allocate memory for the log port list array.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);

        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_num = port_cnt;

    if (NULL == log_port_list_p) {
        SX_LOG_ERR("Logical Ports List is NULL.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == port_mapping_list_p) {
        SX_LOG_ERR("Ports mapping List is NULL.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    SX_MEM_CPY_ARRAY(cmd_body.log_port_list, log_port_list_p, port_cnt,
                     sx_port_log_id_t);
    SX_MEM_CPY_ARRAY(cmd_body.port_mapping_list, port_mapping_list_p, port_cnt,
                     sx_port_mapping_t);

    /* Buffer size =
     * 4 bytes                              : cmd
     * 4 bytes                              : port_num
     * port_num * sizeof(sx_port_mapping_t) : port_mapping_list
     * port_num * sizeof(sx_port_log_id_t)  : log_port_list */
    cmd_body_buffer_size = 2 * sizeof(uint32_t) +
                           cmd_body.port_num * sizeof(sx_port_mapping_t) +
                           cmd_body.port_num * sizeof(sx_port_log_id_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);

    if (!cmd_body_buffer) {
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        CL_FREE_N_NULL(cmd_body.port_mapping_list);
        CL_FREE_N_NULL(cmd_body.log_port_list);

        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    sx_api_serialize_port_map_set_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);

    CL_FREE_N_NULL(cmd_body.port_mapping_list);
    CL_FREE_N_NULL(cmd_body.log_port_list);

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MAPPING_GET_E,
                                         (uint8_t*)cmd_body_buffer,
                                         cmd_body_buffer_size);

    err = sx_api_deserialize_port_map_set_params(cmd_body_buffer, &cmd_body);
    if (SX_CHECK_FAIL(err)) {
        CL_FREE_N_NULL(cmd_body_buffer);
        SX_API_LOG_EXIT();
        return err;
    }

    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_ARRAY(port_mapping_list_p, cmd_body.port_mapping_list,
                         cmd_body.port_num, sx_port_mapping_t);
    }

    CL_FREE_N_NULL(cmd_body.port_mapping_list);
    CL_FREE_N_NULL(cmd_body.log_port_list);
    CL_FREE_N_NULL(cmd_body_buffer);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_device_list_get(const sx_api_handle_t handle,
                                        sx_device_info_t     *device_info_list_p,
                                        uint32_t             *device_info_cnt_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_status_t                           api_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                       cmd;
    sx_api_port_device_list_get_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = sizeof(sx_api_port_device_list_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == device_info_cnt_p) {
        SX_LOG_ERR("Devices list length is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == device_info_list_p) {
        cmd = SX_ACCESS_CMD_COUNT;
        *device_info_cnt_p = 0;
    } else {
        cmd = SX_ACCESS_CMD_GET;
        if (0 == *device_info_cnt_p) {
            SX_LOG_ERR("Devices list length is 0 (zero).\n");

            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd_size += (*device_info_cnt_p) * sizeof(sx_device_info_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    /* O/W: */
    cmd_body_p->cmd = cmd;
    cmd_body_p->device_info_num = *device_info_cnt_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_DEVICE_LIST_GET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *device_info_cnt_p = cmd_body_p->device_info_num;
        if (NULL != device_info_list_p) {
            SX_MEM_CPY_ARRAY(device_info_list_p, cmd_body_p->device_info_list,
                             *device_info_cnt_p, sx_dev_info_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_swid_set(const sx_api_handle_t handle, const sx_access_cmd_t cmd, const sx_swid_t swid)
{
    sx_status_t                   api_rc = SX_STATUS_SUCCESS;
    sx_api_port_swid_set_params_t cmd_body;
    uint32_t                      cmd_size = sizeof(sx_api_port_swid_set_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.swid_id = swid;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        cmd_body.cmd = SX_ACCESS_CMD_ADD;
        break;

    case SX_ACCESS_CMD_DELETE:
        cmd_body.cmd = SX_ACCESS_CMD_DELETE;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_SWID_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_swid_list_get(const sx_api_handle_t handle, sx_swid_t *swid_list_p, uint32_t *swid_cnt_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                     cmd;
    sx_api_port_swid_list_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_port_swid_list_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == swid_cnt_p) {
        SX_LOG_ERR("SwIDs list length is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == swid_list_p) {
        cmd = SX_ACCESS_CMD_COUNT;
        *swid_cnt_p = 0;
    } else {
        cmd = SX_ACCESS_CMD_GET;
        if (0 == *swid_cnt_p) {
            SX_LOG_ERR("SwIDs list length is 0 (zero).\n");

            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd_size += (*swid_cnt_p) * sizeof(sx_swid_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_num = *swid_cnt_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SWID_LIST_GET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *swid_cnt_p = cmd_body_p->swid_num;
        if (NULL != swid_list_p) {
            SX_MEM_CPY_ARRAY(swid_list_p, cmd_body_p->swid_list, *swid_cnt_p,
                             sx_swid_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_swid_bind_set(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      const sx_swid_t        swid)
{
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_swid_alloc_set_params_t cmd_body =
    { .cmd = SX_ACCESS_CMD_ADD, .port_id = log_port, .swid_id = swid };
    uint32_t cmd_size = sizeof(sx_api_port_swid_alloc_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SWID_BIND_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_swid_bind_get(const sx_api_handle_t handle, const sx_port_log_id_t log_port, sx_swid_t *swid_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_swid_alloc_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                            cmd_size = sizeof(sx_api_port_swid_alloc_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(swid_p, "SwID"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body.swid_id = *swid_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SWID_BIND_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *swid_p = cmd_body.swid_id;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_swid_port_list_get(const sx_api_handle_t handle,
                                           const sx_swid_t       swid,
                                           sx_port_log_id_t     *log_port_list_p,
                                           uint32_t             *port_cnt_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    api_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                cmd;
    sx_api_port_swid_get_params_t *cmd_body_p = NULL;
    uint32_t                       cmd_size = sizeof(sx_api_port_swid_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == port_cnt_p) {
        SX_LOG_ERR("Ports list length is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == log_port_list_p) {
        cmd = SX_ACCESS_CMD_COUNT;
        *port_cnt_p = 0;
    } else {
        cmd = SX_ACCESS_CMD_GET;
        if (0 == *port_cnt_p) {
            SX_LOG_ERR("Ports list length is 0 (zero).\n");

            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd_size += (*port_cnt_p) * sizeof(sx_port_log_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_id = swid;
    cmd_body_p->port_num = *port_cnt_p;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_SWID_GET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *port_cnt_p = cmd_body_p->port_num;
        if (NULL != log_port_list_p) {
            SX_MEM_CPY_ARRAY(log_port_list_p, cmd_body_p->port_list,
                             *port_cnt_p, sx_port_log_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_vlans_get(const sx_api_handle_t  handle,
                                  const sx_swid_t        swid,
                                  const sx_port_log_id_t log_port_id,
                                  sx_port_vlans_t       *port_vlan_list_p,
                                  uint16_t              *vlan_cnt_p)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_status_t                     api_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                 cmd;
    sx_api_port_vlans_get_params_t *cmd_body_p = NULL;
    uint32_t                        cmd_size = sizeof(sx_api_port_vlans_get_params_t);

    SX_API_LOG_ENTER();

    if (vlan_cnt_p == NULL) {
        SX_LOG_ERR("vlan_cnt_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (port_vlan_list_p == NULL) {
        cmd = SX_ACCESS_CMD_COUNT;
        *vlan_cnt_p = 0;
    } else {
        cmd = SX_ACCESS_CMD_GET;
        if (*vlan_cnt_p == 0) {
            SX_LOG_ERR("Port VLANs list length is 0 (zero).\n");
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        cmd_size += (*vlan_cnt_p) * sizeof(sx_port_vlans_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_id = swid;
    cmd_body_p->log_port_id = log_port_id;
    cmd_body_p->vlan_num = *vlan_cnt_p;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_VLANS_GET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *vlan_cnt_p = cmd_body_p->vlan_num;
        if ((port_vlan_list_p != NULL) && (*vlan_cnt_p != 0)) {
            SX_MEM_CPY_ARRAY(port_vlan_list_p, cmd_body_p->port_vlan_list,
                             *vlan_cnt_p, sx_port_vlans_t);
        }
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", rc);
    }

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_mode_set(const sx_api_handle_t  handle,
                                 const sx_port_log_id_t log_port,
                                 const sx_port_mode_t   mode)
{
    sx_status_t                   api_rc = SX_STATUS_SUCCESS;
    sx_api_port_mode_set_params_t cmd_body = { .cmd = SX_ACCESS_CMD_SET, .port_id = log_port, .mode = mode, };
    uint32_t                      cmd_size = sizeof(sx_api_port_mode_set_params_t);

    SX_API_LOG_ENTER();

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_STACKING_MODE_SET_E,
        (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_mode_get(const sx_api_handle_t handle, const sx_port_log_id_t log_port, sx_port_mode_t *mode_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_status_t                   api_rc = SX_STATUS_SUCCESS;
    sx_api_port_mode_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                      cmd_size = sizeof(sx_api_port_mode_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(mode_p, "Port Stacking Mode"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_STACKING_MODE_GET_E,
        (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *mode_p = cmd_body.mode;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_mtu_set(const sx_api_handle_t  handle,
                                const sx_port_log_id_t log_port,
                                const sx_port_mtu_t    mtu_size)
{
    sx_status_t                  api_rc = SX_STATUS_SUCCESS;
    sx_api_port_mtu_set_params_t cmd_body = { .cmd = SX_ACCESS_CMD_SET, .port_id = log_port,
                                              .admin_mtu = mtu_size };
    uint32_t                     cmd_size = sizeof(sx_api_port_mtu_set_params_t);

    SX_API_LOG_ENTER();

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MTU_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_mtu_get(const sx_api_handle_t  handle,
                                const sx_port_log_id_t log_port,
                                sx_port_mtu_t         *max_mtu_size_p,
                                sx_port_mtu_t         *oper_mtu_size_p)
{
    sx_status_t                  api_rc = SX_STATUS_SUCCESS;
    sx_api_port_mtu_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port,
                                              .admin_mtu = 0, .oper_mtu = 0, .max_mtu = 0 };
    uint32_t                     cmd_size = sizeof(sx_api_port_mtu_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            api_rc = utils_check_pointer(max_mtu_size_p, "Port Maximum MTU"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }
    /* O/W: */
    if (SX_CHECK_FAIL(
            api_rc = utils_check_pointer(oper_mtu_size_p,
                                         "Port Operational MTU"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }
    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MTU_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *max_mtu_size_p = cmd_body.max_mtu;
        *oper_mtu_size_p = cmd_body.oper_mtu;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_ingress_truncation_set(const sx_api_handle_t       handle,
                                               const sx_access_cmd_t       cmd,
                                               const sx_port_log_id_t      log_port,
                                               const sx_port_truncation_t *truncation_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_api_port_ingress_truncation_set_params_t cmd_body = { .cmd = cmd, .port_id = log_port,
                                                             .truncation = *truncation_p };
    uint32_t                                    cmd_size = sizeof(sx_api_port_ingress_truncation_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(truncation_p, "Port truncation size"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if ((truncation_p->truncation_size < SX_PORT_INGRESS_TRUNCATION_MIN) ||
            ((truncation_p->truncation_size - SX_PORT_INGRESS_TRUNCATION_MIN) %
             SX_PORT_INGRESS_TRUNCATION_GRANULARITY != 0)) {
            SX_LOG_ERR("Invalid truncation value\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_UNSET:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_INGRESS_TRUNCATION_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_ingress_truncation_get(const sx_api_handle_t  handle,
                                               const sx_access_cmd_t  cmd,
                                               const sx_port_log_id_t log_port,
                                               sx_port_truncation_t  *truncation_p)
{
    sx_status_t                                 api_rc = SX_STATUS_SUCCESS;
    sx_api_port_ingress_truncation_get_params_t cmd_body = { .cmd = cmd, .port_id = log_port};
    uint32_t                                    cmd_size = sizeof(sx_api_port_ingress_truncation_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            api_rc = utils_check_pointer(truncation_p, "Port truncation size"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_INGRESS_TRUNCATION_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        truncation_p->truncation_size = cmd_body.truncation.truncation_size;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_speed_admin_set(const sx_api_handle_t             handle,
                                        const sx_port_log_id_t            log_port,
                                        const sx_port_speed_capability_t *admin_speed_p)
{
    sx_status_t                    api_rc = SX_STATUS_SUCCESS;
    sx_api_port_speed_set_params_t cmd_body = { .cmd = SX_ACCESS_CMD_SET, .port_id = log_port, };
    uint32_t                       cmd_size = sizeof(sx_api_port_speed_set_params_t);

    SX_API_LOG_ENTER();

    if (NULL == admin_speed_p) {
        SX_LOG_ERR("Admin Speed Set failed: null pointer\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (SX_CHECK_BOOLEAN(admin_speed_p->force) != TRUE) {
        SX_LOG_ERR("Admin Speed Set failed: the force parameter[%u] of boolean "
                   "type exceeds range (True / False).\n",
                   admin_speed_p->force);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.admin_speed = *admin_speed_p;
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SPEED_PROTO_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_speed_get(const sx_api_handle_t       handle,
                                  const sx_port_log_id_t      log_port,
                                  sx_port_speed_capability_t *admin_speed_p,
                                  sx_port_oper_speed_t       *oper_speed_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    api_rc = SX_STATUS_SUCCESS;
    sx_api_port_speed_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                       cmd_size = sizeof(sx_api_port_speed_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if ((NULL == admin_speed_p) && (NULL == oper_speed_p)) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("NULL params: admin_speed_p and oper_speed_p\n");

        SX_API_LOG_EXIT();
        return rc;
    }

    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SPEED_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        if (NULL != admin_speed_p) {
            *admin_speed_p = cmd_body.admin_speed;
        }
        if (NULL != oper_speed_p) {
            *oper_speed_p = cmd_body.oper_speed;
        }
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_capability_get(const sx_api_handle_t  handle,
                                       const sx_port_log_id_t log_port,
                                       sx_port_capability_t  *capability_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_capability_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                            cmd_size = sizeof(sx_api_port_capability_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(capability_p, "Port Speed Capabilities"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Port capability speed is not supported for LAG.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }


    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_CAPABILITY_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        capability_p->speed_capability = cmd_body.speed_capability;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_fec_capability_get(const sx_api_handle_t     handle,
                                           const sx_port_log_id_t    log_port,
                                           sx_port_fec_capability_t *fec_capability_list_p,
                                           uint32_t                 *fec_cnt_p)
{
    sx_api_command_head_t                    cmd_head;
    sx_api_port_fec_capability_get_params_t  cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_api_port_fec_capability_get_params_t *reply_body = NULL;
    uint32_t                                 reply_body_size;
    sx_status_t                              rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);


    if (fec_cnt_p == NULL) {
        SX_LOG_ERR("fec_cnt_p is NULL\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*fec_cnt_p == 0) || (fec_capability_list_p == NULL)) {
        *fec_cnt_p = 0;
        fec_capability_list_p = NULL;
        cmd_body.cmd = SX_ACCESS_CMD_COUNT;
    } else {
        cmd_body.cmd = SX_ACCESS_CMD_GET;
    }


    reply_body_size = sizeof(sx_api_port_fec_capability_get_params_t) +
                      (*fec_cnt_p * sizeof(sx_port_fec_capability_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                              UTILS_MEM_TYPE_ID_API_E);

    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_PORT_FEC_CAPABILITY_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_port_fec_capability_get_params_t);
    cmd_head.list_size = *fec_cnt_p * sizeof(sx_port_fec_capability_t);

    cmd_body.port_id = log_port;
    cmd_body.fec_cnt = *fec_cnt_p;

    rc = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                       &reply_head, (uint8_t*)reply_body,
                                       reply_body_size);

    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    *fec_cnt_p = reply_body->fec_cnt;
    if (reply_body->fec_cnt && (fec_capability_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(fec_capability_list_p, reply_body->fec_list,
                         reply_body->fec_cnt, sx_port_fec_capability_t);
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_phys_addr_get(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      sx_mac_addr_t         *port_mac_addr_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        api_rc = SX_STATUS_SUCCESS;
    sx_api_port_phys_addr_get_params_t cmd_body =
    { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t cmd_size = sizeof(sx_api_port_phys_addr_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(port_mac_addr_p, "Port Physical Address"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_PHYS_ADDR_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_LOG_DBG("api_rc=%d, mac= %x:%x:%x:%x:%x:%x \n", api_rc,
               cmd_body.mac_addr.ether_addr_octet[0],
               cmd_body.mac_addr.ether_addr_octet[1],
               cmd_body.mac_addr.ether_addr_octet[2],
               cmd_body.mac_addr.ether_addr_octet[3],
               cmd_body.mac_addr.ether_addr_octet[4],
               cmd_body.mac_addr.ether_addr_octet[5]);

    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_TYPE(port_mac_addr_p, cmd_body.mac_addr.ether_addr_octet,
                        sx_mac_addr_t);
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_phys_addr_set(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      const sx_mac_addr_t   *port_mac_addr_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_port_phys_addr_set_params_t cmd_body;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(port_mac_addr_p, "Port Physical Address"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;
    SX_MEM_CPY_TYPE(cmd_body.mac_addr.ether_addr_octet, port_mac_addr_p, sx_mac_addr_t);

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_PORT_PHYS_ADDR_SET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_phys_addr_set_params_t));

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_phys_loopback_set(const sx_api_handle_t         handle,
                                          const sx_port_log_id_t        log_port,
                                          const sx_port_phys_loopback_t phys_loopback)
{
    sx_status_t                            api_rc = SX_STATUS_SUCCESS;
    sx_api_port_phys_loopback_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (FALSE == SX_PORT_PHYS_LOOPBACK_CHECK_RANGE(phys_loopback)) {
        SX_LOG_ERR("phys_loopback (%u) exceeds range.\n", phys_loopback);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.log_port = log_port;
    cmd_body.phys_loopback = phys_loopback;

    uint32_t cmd_size = sizeof(sx_api_port_phys_loopback_set_params_t);

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_PHYS_LOOPBACK_SET_E,
        (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_phys_loopback_get(const sx_api_handle_t    handle,
                                          const sx_port_log_id_t   log_port,
                                          sx_port_phys_loopback_t *phys_loopback_p)
{
    sx_status_t                            api_rc = SX_STATUS_SUCCESS;
    sx_api_port_phys_loopback_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .log_port = log_port };
    uint32_t                               cmd_size = sizeof(sx_api_port_phys_loopback_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            api_rc = utils_check_pointer(phys_loopback_p,
                                         "Port Physical Loopback"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_PHYS_LOOPBACK_GET_E,
        (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *phys_loopback_p = cmd_body.phys_loopback;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_state_set(const sx_api_handle_t       handle,
                                  const sx_port_log_id_t      log_port,
                                  const sx_port_admin_state_t admin_state)
{
    sx_status_t                    api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_set_params_t cmd_body =
    { .cmd = SX_ACCESS_CMD_SET, .port_id = log_port, .admin_state =
          admin_state, };
    uint32_t cmd_size = sizeof(sx_api_port_state_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_port_admin_state(admin_state))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_STATE_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_state_get(const sx_api_handle_t   handle,
                                  const sx_port_log_id_t  log_port,
                                  sx_port_oper_state_t   *oper_state_p,
                                  sx_port_admin_state_t  *admin_state_p,
                                  sx_port_module_state_t *module_state_p)
{
    sx_status_t                    api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_get_params_t cmd_body =
    { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t cmd_size = sizeof(sx_api_port_state_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == oper_state_p) {
        SX_LOG_ERR("Port Operational Status is NULL\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == admin_state_p) {
        SX_LOG_ERR("Port Administrative Status is NULL\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == module_state_p) {
        SX_LOG_ERR("Module Operational Status is NULL\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_STATE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *module_state_p = cmd_body.module_state;
        *admin_state_p = cmd_body.admin_state;
        *oper_state_p = cmd_body.oper_state;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_global_fc_enable_set(const sx_api_handle_t          handle,
                                             const sx_port_log_id_t         log_port,
                                             const sx_port_flow_ctrl_mode_t fc_mode)
{
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_port_flow_ctrl_conf_set_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_set_params_t);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;
    cmd_body.prio_mask_tx = SX_PORT_FLOW_CTRL_PRIO_NO_MASK;
    cmd_body.prio_mask_rx = SX_PORT_FLOW_CTRL_PRIO_NO_MASK;

    switch (fc_mode) {
    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS:
        cmd_body.pause_policy_tx = SX_PORT_PAUSE_POLICY_TX_DISABLE;
        cmd_body.pause_policy_rx = SX_PORT_PAUSE_POLICY_RX_DISABLE;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS:
        cmd_body.pause_policy_tx = SX_PORT_PAUSE_POLICY_TX_ENABLE;
        cmd_body.pause_policy_rx = SX_PORT_PAUSE_POLICY_RX_DISABLE;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN:
        cmd_body.pause_policy_tx = SX_PORT_PAUSE_POLICY_TX_DISABLE;
        cmd_body.pause_policy_rx = SX_PORT_PAUSE_POLICY_RX_ENABLE;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN:
        cmd_body.pause_policy_tx = SX_PORT_PAUSE_POLICY_TX_ENABLE;
        cmd_body.pause_policy_rx = SX_PORT_PAUSE_POLICY_RX_ENABLE;
        break;

    default:
        SX_LOG_ERR("Wrong fc_mode: %d (allowed 0..3)\n", fc_mode);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_SET_E,
        (uint8_t*)&cmd_body, cmd_size);
    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_global_fc_enable_get(const sx_api_handle_t     handle,
                                             const sx_port_log_id_t    log_port,
                                             sx_port_flow_ctrl_mode_t *fc_mode_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_port_flow_ctrl_conf_get_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_get_params_t);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_id = log_port;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(fc_mode_p, "Pause Policy"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_GET_E,
        (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (!cmd_body.pause_policy_tx && !cmd_body.pause_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS;
    } else if (!cmd_body.pause_policy_tx && cmd_body.pause_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN;
    } else if (cmd_body.pause_policy_tx && !cmd_body.pause_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS;
    } else {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_pfc_enable_set(const sx_api_handle_t          handle,
                                       const sx_port_log_id_t         log_port,
                                       const sx_port_flow_ctrl_prio_t pfc_prio,
                                       const sx_port_flow_ctrl_mode_t fc_mode)
{
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_port_flow_ctrl_conf_set_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_set_params_t);
    uint8_t                                 prio_bitmask = (1 << pfc_prio);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;

    switch (fc_mode) {
    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS:
        cmd_body.prio_policy_tx = 0;
        cmd_body.prio_policy_rx = 0;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS:
        cmd_body.prio_policy_tx = prio_bitmask;
        cmd_body.prio_policy_rx = 0;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN:
        cmd_body.prio_policy_tx = 0;
        cmd_body.prio_policy_rx = prio_bitmask;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN:
        cmd_body.prio_policy_tx = prio_bitmask;
        cmd_body.prio_policy_rx = prio_bitmask;
        break;

    default:
        SX_LOG_ERR("Wrong fc_mode: %d (allowed 0..3)\n", fc_mode);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (!SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(pfc_prio)) {
        SX_LOG_ERR("Wrong pfc_prio: %d (allowed 0..%d)\n", pfc_prio,
                   SX_PORT_FLOW_CTRL_PRIO_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.prio_mask_tx = prio_bitmask;
    cmd_body.prio_mask_rx = prio_bitmask;

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_SET_E,
        (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_pfc_enable_get(const sx_api_handle_t          handle,
                                       const sx_port_log_id_t         log_port,
                                       const sx_port_flow_ctrl_prio_t pfc_prio,
                                       sx_port_flow_ctrl_mode_t      *fc_mode_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    uint8_t                                 prio_bitmask = (1 << pfc_prio);
    sx_api_port_flow_ctrl_conf_get_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_get_params_t);

    SX_API_LOG_ENTER();

    if (((int)pfc_prio < SX_PORT_FLOW_CTRL_PRIO_MIN) || (pfc_prio
                                                         > SX_PORT_FLOW_CTRL_PRIO_MAX)) {
        SX_LOG_ERR("Invalid pfc_prio value\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    SX_MEM_CLR(cmd_body);
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_id = log_port;
    cmd_body.prio_mask_tx = prio_bitmask;
    cmd_body.prio_mask_rx = prio_bitmask;

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(fc_mode_p,
                                     "Priority based Flow Control Policy"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_GET_E,
        (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.prio_policy_tx &= prio_bitmask;
    cmd_body.prio_policy_rx &= prio_bitmask;
    if (!cmd_body.prio_policy_tx && !cmd_body.prio_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS;
    } else if (!cmd_body.prio_policy_tx && cmd_body.prio_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN;
    } else if (cmd_body.prio_policy_tx && !cmd_body.prio_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS;
    } else {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_fc_credit_enable_set(const sx_api_handle_t          handle,
                                             const sx_port_log_id_t         log_port,
                                             const sx_port_flow_ctrl_prio_t cbfc_prio,
                                             const sx_port_flow_ctrl_mode_t fc_mode)
{
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_port_flow_ctrl_conf_set_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_set_params_t);
    uint8_t                                 prio_bitmask = (1 << cbfc_prio);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;

    switch (fc_mode) {
    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS:
        cmd_body.cb_policy_tx = 0;
        cmd_body.cb_policy_rx = 0;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS:
        cmd_body.cb_policy_tx = prio_bitmask;
        cmd_body.cb_policy_rx = 0;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN:
        cmd_body.cb_policy_tx = 0;
        cmd_body.cb_policy_rx = prio_bitmask;
        break;

    case SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN:
        cmd_body.cb_policy_tx = prio_bitmask;
        cmd_body.cb_policy_rx = prio_bitmask;
        break;

    default:
        SX_LOG_ERR("Wrong fc_mode: %d (allowed 0..3)\n", fc_mode);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (!SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(cbfc_prio)) {
        SX_LOG_ERR("Wrong cbfc_prio: %d (allowed 0..%d)\n", cbfc_prio,
                   SX_PORT_FLOW_CTRL_PRIO_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.prio_mask_tx = prio_bitmask;
    cmd_body.prio_mask_rx = prio_bitmask;

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_SET_E,
        (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_fc_credit_enable_get(const sx_api_handle_t          handle,
                                             const sx_port_log_id_t         log_port,
                                             const sx_port_flow_ctrl_prio_t cbfc_prio,
                                             sx_port_flow_ctrl_mode_t      *fc_mode_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    uint8_t                                 prio_bitmask = (1 << cbfc_prio);
    sx_api_port_flow_ctrl_conf_get_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_port_flow_ctrl_conf_get_params_t);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_id = log_port;
    cmd_body.prio_mask_tx = prio_bitmask;
    cmd_body.prio_mask_rx = prio_bitmask;

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(fc_mode_p,
                                     "Credit based Flow Control Policy"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_GET_E,
        (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cb_policy_tx &= prio_bitmask;
    cmd_body.cb_policy_rx &= prio_bitmask;
    if (!cmd_body.cb_policy_tx && !cmd_body.cb_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS;
    } else if (!cmd_body.cb_policy_tx && cmd_body.cb_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN;
    } else if (cmd_body.cb_policy_tx && !cmd_body.cb_policy_rx) {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS;
    } else {
        *fc_mode_p = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN;
    }

    if (FALSE == SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(cbfc_prio)) {
        SX_LOG_ERR("Wrong cbfc_prio: %d (allowed 0..%d)\n", cbfc_prio,
                   SX_PORT_FLOW_CTRL_PRIO_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.prio_mask_tx = prio_bitmask;
    cmd_body.prio_mask_rx = prio_bitmask;

    api_rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_FLOW_CTRL_CONF_GET_E,
        (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_phy_layer_get(const sx_api_handle_t     handle,
                                              const sx_access_cmd_t     cmd,
                                              const sx_port_log_id_t    log_port,
                                              sx_port_cntr_phy_layer_t *cntr_phy_layer_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_PHY_LAYER_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_PHY_LAYER_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_phy_layer_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_PHY_LAYER;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_PHY_LAYER_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_phy_layer_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_phy_layer_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_phy_layer_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_phy_layer_statistics_get(const sx_api_handle_t                handle,
                                                         const sx_access_cmd_t                cmd,
                                                         const sx_port_log_id_t               log_port,
                                                         const sx_port_phys_link_side_t       link_side,
                                                         sx_port_cntr_phy_layer_statistics_t *cntr_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_PHY_STATISTICS_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (cntr_p == NULL) {
        SX_LOG_ERR("Counters entry is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body_p->port_id = log_port;
    cmd_body_p->link_side = link_side;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_PHY_LAYER_STATISTICS;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_PHY_STATISTICS_SIZE;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_PHY_LAYER_STATISTICS_GET_E,
                                         (uint8_t*)cmd_body_p,
                                         cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        if (sizeof(sx_port_cntr_phy_layer_statistics_t) != cmd_body_p->cntr_num * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR("Counters entry size (%u) != Counters array size (%u).\n",
                       (uint32_t)sizeof(sx_port_cntr_phy_layer_statistics_t),
                       cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
            goto out;
        } else {
            SX_MEM_CPY_ARRAY(cntr_p, cmd_body_p->cntr_list, cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", rc);
    }

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_counter_phy_layer_internal_link_get(const sx_api_handle_t                   handle,
                                                            const sx_access_cmd_t                   cmd,
                                                            const sx_port_log_id_t                  log_port,
                                                            const sx_port_phys_link_side_t          link_side,
                                                            sx_port_cntr_phy_layer_internal_link_t *cntr_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_PHY_INTERNAL_LINK_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (cntr_p == NULL) {
        SX_LOG_ERR("Counters entry is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body_p->port_id = log_port;
    cmd_body_p->link_side = link_side;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_PHY_LAYER_INTERNAL_LINK;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_PHY_INTERNAL_LINK_SIZE;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_COUNTER_PHY_LAYER_INTERNAL_LINK_GET_E,
                                         (uint8_t*)cmd_body_p,
                                         cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        if (sizeof(sx_port_cntr_phy_layer_internal_link_t) != cmd_body_p->cntr_num * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR("Counters entry size (%u) != Counters array size (%u).\n",
                       (uint32_t)sizeof(sx_port_cntr_phy_layer_internal_link_t),
                       cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
            goto out;
        } else {
            SX_MEM_CPY_ARRAY(cntr_p, cmd_body_p->cntr_list, cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", rc);
    }

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}


sx_status_t sx_api_port_counter_ext_get(const sx_api_handle_t      handle,
                                        const sx_access_cmd_t      cmd,
                                        const sx_port_cntrs_key_t *cntr_key_p,
                                        sx_port_cntrs_data_t      *cntr_data_p)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_api_port_cntr_ext_get_params_t cmd_body;
    uint32_t                          cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    if (cntr_key_p == NULL) {
        SX_LOG_ERR("cntr_key_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cntr_data_p == NULL) {
        SX_LOG_ERR("cntr_data_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.port_cntrs_key = *cntr_key_p;
    cmd_body.port_cntrs_data = *cntr_data_p;

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_PORT_COUNTER_EXT_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("counter ext get API failed. rc:%s\n", sx_status_str(rc));
        goto out;
    }

    *cntr_data_p = cmd_body.port_cntrs_data;

out:

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_counter_ieee_802_dot_3_get(const sx_api_handle_t          handle,
                                                   const sx_access_cmd_t          cmd,
                                                   const sx_port_log_id_t         log_port,
                                                   sx_port_cntr_ieee_802_dot_3_t *cntr_ieee_802_dot_3_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_IEEE_802_DOT_3_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_IEEE_802_DOT_3_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_ieee_802_dot_3_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_IEEE_802_DOT_3;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_IEEE_802_DOT_3_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_ieee_802_dot_3_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_ieee_802_dot_3_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_ieee_802_dot_3_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_rfc_2863_get(const sx_api_handle_t    handle,
                                             const sx_access_cmd_t    cmd,
                                             const sx_port_log_id_t   log_port,
                                             sx_port_cntr_rfc_2863_t *cntr_rfc_2863_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_RFC_2863_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_RFC_2863_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_rfc_2863_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_RFC_2863;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_RFC_2863_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_rfc_2863_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_rfc_2863_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_rfc_2863_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_rfc_2819_get(const sx_api_handle_t    handle,
                                             const sx_access_cmd_t    cmd,
                                             const sx_port_log_id_t   log_port,
                                             sx_port_cntr_rfc_2819_t *cntr_rfc_2819_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_RFC_2819_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_RFC_2819_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_rfc_2819_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_RFC_2819;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_RFC_2819_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_rfc_2819_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_rfc_2819_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_rfc_2819_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_rfc_3635_get(const sx_api_handle_t    handle,
                                             const sx_access_cmd_t    cmd,
                                             const sx_port_log_id_t   log_port,
                                             sx_port_cntr_rfc_3635_t *cntr_rfc_3635_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_RFC_3635_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_RFC_3635_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_rfc_3635_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_RFC_3635;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_RFC_3635_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_rfc_3635_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_rfc_3635_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_rfc_3635_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_cli_get(const sx_api_handle_t  handle,
                                        const sx_access_cmd_t  cmd,
                                        const sx_port_log_id_t log_port,
                                        sx_port_cntr_cli_t    *cntr_cli_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_CLI_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_CLI_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (NULL == cntr_cli_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_CLI;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_CLI_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_cli_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_cli_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_cli_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_prio_get(const sx_api_handle_t    handle,
                                         const sx_access_cmd_t    cmd,
                                         const sx_port_log_id_t   log_port,
                                         const sx_cos_ieee_prio_t prio_id,
                                         sx_port_cntr_prio_t     *cntr_prio_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_port_per_prio_cntr_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == cntr_prio_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (prio_id > SX_PORT_PRIO_ID_MAX) {
        SX_LOG_ERR("Counters priority exceeds range (%u-%u).\n",
                   SX_PORT_PRIO_ID_MIN_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.cmd = cmd;
    cmd_body.port_id = log_port;
    cmd_body.prio_id = prio_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_COUNTER_PRIO_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_per_prio_cntr_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(cntr_prio_p, &cmd_body.cntr_prio);
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_counter_tc_get(const sx_api_handle_t   handle,
                                       const sx_access_cmd_t   cmd,
                                       const sx_port_log_id_t  log_port,
                                       const sx_port_tc_id_t   tc_id,
                                       sx_port_traffic_cntr_t *cntr_tc_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_api_port_cntr_tc_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    /* validate port is not a member of a lag */
    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Port TC counters are not supported for LAG.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (NULL == cntr_tc_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (FALSE == SX_PORT_TC_ID_CHECK_RANGE(tc_id)) {
        SX_LOG_ERR("Traffic class exceeds range (%u-%u).\n", SX_PORT_TC_ID_MIN,
                   SX_PORT_TC_ID_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    cmd_body.traffic_class = tc_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_COUNTER_TC_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_cntr_tc_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(cntr_tc_p, &cmd_body.cntr_tc_p);
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_counter_buff_get(const sx_api_handle_t         handle,
                                         const sx_access_cmd_t         cmd,
                                         const sx_port_log_id_t        log_port,
                                         const sx_cos_priority_group_t buff_id,
                                         sx_port_cntr_buff_t          *cntr_buff_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_port_cntr_buff_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == cntr_buff_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (buff_id >= RM_API_COS_BUFFERS_NUM) {
        SX_LOG_ERR("Counters buffer_id (%u) exceeds range\n", buff_id);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    cmd_body.log_port = log_port;
    cmd_body.buff_id = buff_id;
    cmd_body.cmd = cmd;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BUFFER_CNTR_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_cntr_buff_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(cntr_buff_p, &cmd_body.cntr_buff);
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_counter_perf_get(const sx_api_handle_t   handle,
                                         const sx_access_cmd_t   cmd,
                                         const sx_port_log_id_t  log_port,
                                         const sx_port_prio_id_t prio_id,
                                         sx_port_cntr_perf_t    *cntr_perf_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_PERF_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_PERF_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Port performance counters are not supported for LAG.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (NULL == cntr_perf_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    /* O/W: */
    if (FALSE == SX_PORT_PRIO_ID_CHECK_RANGE(prio_id)) {
        SX_LOG_ERR("Counters priority exceeds range (%u-%u).\n",
                   SX_PORT_PRIO_ID_MIN_MAX);

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_PERFORMANCE;
    cmd_body_p->cntr_prio = prio_id;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_PERF_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_perf_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_perf_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_perf_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_discard_get(const sx_api_handle_t   handle,
                                            const sx_access_cmd_t   cmd,
                                            const sx_port_log_id_t  log_port,
                                            sx_port_cntr_discard_t *cntr_discard_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_perf_cntr_get_params_t *cmd_body_p = NULL;
    sx_api_int_cmd_e                    int_cmd = SX_API_INT_CMD_PORT_COUNTER_DISCARD_GET_E;
    uint32_t                            cmd_size = sizeof(sx_api_port_perf_cntr_get_params_t)
                                                   + SX_PORT_CNTR_GRP_DISCARD_SIZE * sizeof(sx_port_cntr_t);

    SX_API_LOG_ENTER();

    /* Check input params */
    if (!handle) {
        SX_LOG_ERR("Invalid handle: handle is NULL\n");
        return SX_STATUS_INVALID_HANDLE;
    }

    if (NULL == cntr_discard_p) {
        SX_LOG_ERR("Counters entry is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* Allocate memory and init allocated memory */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    /* Send read command */
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        cmd_body_p->cmd = SX_ACCESS_CMD_READ_CLEAR;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }
    cmd_body_p->port_id = log_port;
    cmd_body_p->cntr_grp = SX_PORT_CNTR_GRP_DISCARD;
    cmd_body_p->cntr_num = SX_PORT_CNTR_GRP_DISCARD_SIZE;

    if (SX_CHECK_PASS(
            api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                                 (uint8_t*)cmd_body_p,
                                                 cmd_size))) {
        if (sizeof(sx_port_cntr_discard_t) != cmd_body_p->cntr_num
            * sizeof(sx_port_cntr_t)) {
            SX_LOG_ERR(
                "Counters entry size (%u) != Counters array size (%u).\n",
                (uint32_t)sizeof(sx_port_cntr_discard_t),
                cmd_body_p->cntr_num * (uint32_t)sizeof(sx_port_cntr_t));
            api_rc = SX_STATUS_ERROR;
        } else {
            SX_MEM_CPY_ARRAY(cntr_discard_p, cmd_body_p->cntr_list,
                             cmd_body_p->cntr_num, sx_port_cntr_t);
        }
    }

    /* Free allocated memory */
    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", rc);

    if (SX_CHECK_PASS(api_rc) && SX_CHECK_FAIL(rc)) {
        api_rc = rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_counter_clear_set(const sx_api_handle_t    handle,
                                          const sx_port_log_id_t   log_port,
                                          const boolean_t          all_ports,
                                          const sx_port_cntr_grp_t cntr_grp)
{
    sx_status_t api_rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    switch (cntr_grp) {
    case SX_PORT_CNTR_GRP_IEEE_802_DOT_3:
    case SX_PORT_CNTR_GRP_RFC_2863:
    case SX_PORT_CNTR_GRP_RFC_2819:
    case SX_PORT_CNTR_GRP_RFC_3635:
    case SX_PORT_CNTR_GRP_CLI:
    case SX_PORT_CNTR_GRP_PERFORMANCE:
    case SX_PORT_CNTR_GRP_DISCARD:
    case SX_PORT_CNTR_GRP_CONGESTION_PER_TC:
    case SX_PORT_CNTR_GRP_PHY_LAYER:
    case SX_PORT_CNTR_GRP_PER_TC:
    case SX_PORT_CNTR_GRP_PER_TC_0:
    case SX_PORT_CNTR_GRP_PER_TC_1:
    case SX_PORT_CNTR_GRP_PER_TC_2:
    case SX_PORT_CNTR_GRP_PER_TC_3:
    case SX_PORT_CNTR_GRP_PER_TC_4:
    case SX_PORT_CNTR_GRP_PER_TC_5:
    case SX_PORT_CNTR_GRP_PER_TC_6:
    case SX_PORT_CNTR_GRP_PER_TC_7:
    case SX_PORT_CNTR_GRP_PER_PRIO:
    case SX_PORT_CNTR_GRP_PER_PRIO_0:
    case SX_PORT_CNTR_GRP_PER_PRIO_1:
    case SX_PORT_CNTR_GRP_PER_PRIO_2:
    case SX_PORT_CNTR_GRP_PER_PRIO_3:
    case SX_PORT_CNTR_GRP_PER_PRIO_4:
    case SX_PORT_CNTR_GRP_PER_PRIO_5:
    case SX_PORT_CNTR_GRP_PER_PRIO_6:
    case SX_PORT_CNTR_GRP_PER_PRIO_7:
    case SX_PORT_CNTR_GRP_PER_BUFF:
    case SX_PORT_CNTR_GRP_PER_BUFF_0:
    case SX_PORT_CNTR_GRP_PER_BUFF_1:
    case SX_PORT_CNTR_GRP_PER_BUFF_2:
    case SX_PORT_CNTR_GRP_PER_BUFF_3:
    case SX_PORT_CNTR_GRP_PER_BUFF_4:
    case SX_PORT_CNTR_GRP_PER_BUFF_5:
    case SX_PORT_CNTR_GRP_PER_BUFF_6:
    case SX_PORT_CNTR_GRP_PER_BUFF_7:
    case SX_PORT_CNTR_GRP_ALL:
        break;

    default:
        SX_LOG_ERR("Invalid cntr_grp value\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    sx_api_port_cntr_clear_set_params_t cmd_body =
    { .port_id = log_port, .cntr_grp = cntr_grp, .all_ports = all_ports };
    uint32_t cmd_size = sizeof(sx_api_port_cntr_clear_set_params_t);

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_COUNTER_CLEAR_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_init_set(const sx_api_handle_t handle, const sx_port_log_id_t log_port)
{
    sx_status_t                   api_rc = SX_STATUS_SUCCESS;
    sx_api_port_init_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_INIT_E,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_port_init_set_params_t));
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_deinit_set(const sx_api_handle_t handle, const sx_port_log_id_t log_port)
{
    sx_status_t                     api_rc = SX_STATUS_SUCCESS;
    sx_api_port_deinit_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_DEINIT_E,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_port_deinit_set_params_t));
    if (!SX_CHECK_PASS(api_rc)) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_storm_control_set(const sx_api_handle_t                 handle,
                                          const sx_access_cmd_t                 cmd,
                                          const sx_port_log_id_t                log_port,
                                          const sx_port_storm_control_id_t      storm_control_id,
                                          const sx_port_storm_control_params_t *storm_control_params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    sx_api_port_storm_control_set_params_t cmd_body =
    { .cmd = cmd, .log_port = log_port, .storm_control_id = storm_control_id, };

    if ((cmd == SX_ACCESS_CMD_ADD) || (SX_ACCESS_CMD_EDIT == cmd)) {
        if (SX_CHECK_FAIL(
                rc = utils_check_pointer(storm_control_params_p,
                                         "Storm Control Params"))) {
            SX_API_LOG_EXIT();
            return rc;
        }
        SX_MEM_CPY_P(&(cmd_body.storm_control_params), storm_control_params_p);
    }

    rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_STORM_CONTROL_SET_E,
        (uint8_t*)&cmd_body,
        sizeof(sx_api_port_storm_control_set_params_t));

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_storm_control_get(const sx_api_handle_t            handle,
                                          const sx_port_log_id_t           log_port,
                                          const sx_port_storm_control_id_t storm_control_id,
                                          sx_port_storm_control_params_t  *storm_control_params_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_port_storm_control_set_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .log_port = log_port,
                                                        .storm_control_id = storm_control_id, };

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            rc = utils_check_pointer(storm_control_params_p,
                                     "Storm Control Params"))) {
        SX_API_LOG_EXIT();
        return rc;
    }


    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_STORM_CONTROL_GET_E, (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_storm_control_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(storm_control_params_p, &(cmd_body.storm_control_params));
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_sflow_set(const sx_api_handle_t   handle,
                                  const sx_access_cmd_t   cmd,
                                  const sx_port_log_id_t  log_port,
                                  sx_port_sflow_params_t *sflow_params_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_api_port_sflow_set_params_t cmd_body =
    { .cmd = cmd, .log_port = log_port, };

    SX_API_LOG_ENTER();

    if (!handle) {
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    if (cmd != SX_ACCESS_CMD_DELETE) {
        if ((sflow_params_p->deviation > SX_PORT_SFLOW_DEVIATION_MAX) || (sflow_params_p
                                                                          ->ratio
                                                                          == 0)) {
            SX_LOG_ERR("Invalid Sflow parameters: deviation > %d or ratio=0\n",
                       SX_PORT_SFLOW_DEVIATION_MAX);

            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
    }

    SX_MEM_CPY_P(&(cmd_body.sflow_params), sflow_params_p);
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_SFLOW_SET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_sflow_set_params_t));
    sflow_params_p->deviation = cmd_body.sflow_params.deviation;
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_sflow_get(const sx_api_handle_t   handle,
                                  const sx_port_log_id_t  log_port,
                                  sx_port_sflow_params_t *sflow_params_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_api_port_sflow_get_params_t cmd_body =
    { .log_port = log_port, };

    SX_API_LOG_ENTER();

    if (!handle) {
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_SFLOW_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_sflow_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(sflow_params_p, &(cmd_body.sflow_params));
    }
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_sflow_statistics_get(const sx_api_handle_t       handle,
                                             const sx_access_cmd_t       cmd,
                                             const sx_port_log_id_t      log_port,
                                             sx_port_sflow_statistics_t *sflow_stat_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_api_port_sflow_get_statistics_params_t cmd_body =
    {  .cmd = cmd, .log_port = log_port, };

    SX_API_LOG_ENTER();

    if (!handle) {
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_SFLOW_STATISTICS_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_sflow_get_statistics_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(sflow_stat_p, &(cmd_body.sflow_stat));
    }
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_loopback_filter_set(const sx_api_handle_t                handle,
                                            const sx_port_log_id_t               log_port,
                                            const sx_port_loopback_filter_mode_t lbf_mode)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_port_loopback_filter_set_params_t cmd_body =
    { .log_port = log_port, .lbf_mode = lbf_mode, };

    SX_API_LOG_ENTER();

    if (!handle) {
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_LOOPBACK_FILTER_SET_E,
        (uint8_t*)&cmd_body,
        sizeof(sx_api_port_loopback_filter_set_params_t));
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_loopback_filter_get(const sx_api_handle_t           handle,
                                            const sx_port_log_id_t          log_port,
                                            sx_port_loopback_filter_mode_t *lbf_mode_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_port_loopback_filter_get_params_t cmd_body =
    { .log_port = log_port, };

    SX_API_LOG_ENTER();

    if (!handle) {
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    if (lbf_mode_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    rc = sx_api_send_command_wrapper(
        handle, SX_API_INT_CMD_PORT_LOOPBACK_FILTER_GET_E,
        (uint8_t*)&cmd_body,
        sizeof(sx_api_port_loopback_filter_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        *lbf_mode_p = cmd_body.lbf_mode;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_isolate_set(const sx_api_handle_t   handle,
                                    const sx_access_cmd_t   cmd,
                                    const sx_port_log_id_t  log_port,
                                    const sx_port_log_id_t *log_port_list_p,
                                    const uint32_t          log_port_cnt)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_port_isolate_set_params_t *cmd_body_p = NULL;
    uint32_t                          cmd_size = sizeof(sx_api_port_isolate_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        if (NULL == log_port_list_p) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
        /* O/W: */
        if (0 == log_port_cnt) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd_size += (log_port_cnt) * sizeof(sx_port_log_id_t);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size,
                            UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", rc)
        ;
        if (SX_CHECK_FAIL(rc)) {
            SX_API_LOG_EXIT();
            return rc;
        }
        cmd_body_p->log_port_num = log_port_cnt;
        SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list_p,
                         log_port_cnt, sx_port_log_id_t);
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size,
                            UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", rc)
        ;
        if (SX_CHECK_FAIL(rc)) {
            SX_API_LOG_EXIT();
            return rc;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        rc = mem_rc;
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_isolate_get(const sx_api_handle_t  handle,
                                    const sx_port_log_id_t log_port,
                                    sx_port_log_id_t      *log_port_list_p,
                                    uint32_t              *log_port_cnt_p)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                   cmd;
    sx_api_port_isolate_get_params_t *cmd_body_p = NULL;
    uint32_t                          cmd_size = sizeof(sx_api_port_isolate_set_params_t);

    SX_API_LOG_ENTER();

    cmd = SX_ACCESS_CMD_GET;

    /* O/W: */
    if (NULL == log_port_cnt_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (NULL == log_port_list_p) {
        *log_port_cnt_p = 0;
    }
    if (0 == *log_port_cnt_p) {
        log_port_list_p = NULL;
    } else {
        cmd_size += (*log_port_cnt_p) * sizeof(sx_port_log_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->log_port = log_port;
    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port_num = *log_port_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *log_port_cnt_p = cmd_body_p->log_port_num;
        if (NULL != log_port_list_p) {
            SX_MEM_CPY_ARRAY(log_port_list_p, cmd_body_p->log_port_list,
                             *log_port_cnt_p, sx_port_log_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_isolate_mode_set(const sx_api_handle_t         handle,
                                         const sx_port_isolate_mode_t *port_isolate_mode_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_status_t                            mem_rc = SX_STATUS_SUCCESS;
    sx_api_port_isolate_mode_set_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = sizeof(sx_api_port_isolate_mode_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(port_isolate_mode_p, "port_isolate_mode_p"))) {
        SX_API_LOG_EXIT();
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->sx_port_isolate_mode = *port_isolate_mode_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_MODE_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);
out:
    if (cmd_body_p) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Error on cmd_body_p memory free", mem_rc);
        if (SX_CHECK_FAIL(mem_rc)) {
            SX_API_LOG_EXIT();
            return mem_rc;
        }
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_isolate_mode_get(const sx_api_handle_t handle, sx_port_isolate_mode_t *port_isolate_mode_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_port_isolate_mode_get_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = sizeof(sx_api_port_isolate_mode_get_params_t);
    sx_status_t                            mem_rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(port_isolate_mode_p, "port_isolate_mode_p"))) {
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_MODE_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    *port_isolate_mode_p = cmd_body_p->sx_port_isolate_mode;

out:
    if (cmd_body_p) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Error on cmd_body_p memory free", mem_rc);
        if (SX_CHECK_FAIL(mem_rc)) {
            SX_API_LOG_EXIT();
            return mem_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_isolate_bridge_set(const sx_api_handle_t    handle,
                                           const sx_access_cmd_t    cmd,
                                           const sx_port_log_id_t   log_port,
                                           sx_port_isolation_cfg_t *isolation_cfg_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_port_isolate_bridge_set_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_port_isolate_bridge_set_params_t);

    SX_API_LOG_ENTER();

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        if (SX_CHECK_FAIL(rc = utils_check_pointer(isolation_cfg_p, "isolation_cfg_p"))) {
            SX_API_LOG_EXIT();
            M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                            "Error on cmd_body_p memory free", mem_rc);
            return rc;
        }

        SX_MEM_CPY(cmd_body_p->isolation_cfg, *isolation_cfg_p);

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Error on cmd_body_p memory free", mem_rc);
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_BRIDGE_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        rc = mem_rc;
    }

    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_port_isolate_bridge_get(const sx_api_handle_t    handle,
                                           const sx_port_log_id_t   log_port,
                                           sx_port_isolation_cfg_t *isolation_cfg_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_port_isolate_bridge_get_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_port_isolate_bridge_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(isolation_cfg_p, "isolation_cfg_p"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->log_port = log_port;

    cmd_body_p->isolation_cfg.log_port_cnt = isolation_cfg_p->log_port_cnt;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ISOLATE_BRIDGE_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY(*isolation_cfg_p, cmd_body_p->isolation_cfg);
    }
    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_swid_type_get(const sx_api_handle_t handle, const sx_swid_t swid, sx_swid_type_t *swid_type_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        api_rc = SX_STATUS_SUCCESS;
    sx_api_port_swid_type_get_params_t cmd_body = { .swid_id = swid };
    uint32_t                           cmd_size = sizeof(sx_api_port_swid_type_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(swid_type_p, "SwID_type"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body.swid_type = *swid_type_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_SWID_TYPE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *swid_type_p = cmd_body.swid_type;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_vport_set(const sx_api_handle_t  handle,
                                  const sx_access_cmd_t  cmd,
                                  const sx_port_log_id_t log_port,
                                  const sx_vlan_id_t     vlan_id,
                                  sx_port_log_id_t      *log_vport_p)
{
    sx_api_port_vport_set_params_t cmd_body;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);


    if (log_vport_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    cmd_body.vlan_id = vlan_id;
    cmd_body.log_vport = *log_vport_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_VPORT_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_vport_set_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_ADD) {
        *log_vport_p = cmd_body.log_vport;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_vport_get(const sx_api_handle_t  handle,
                                  const sx_port_log_id_t log_port,
                                  sx_vlan_id_t          *vlan_id_list_p,
                                  uint32_t              *vport_vlan_cnt_p)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_port_vport_get_params_t *cmd_body_p = NULL;
    uint32_t                        cmd_size = sizeof(sx_api_port_vport_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == vport_vlan_cnt_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (NULL == vlan_id_list_p) {
        *vport_vlan_cnt_p = 0;
    }
    if (0 == *vport_vlan_cnt_p) {
        vlan_id_list_p = NULL;
    } else {
        cmd_size += (*vport_vlan_cnt_p) * sizeof(sx_vlan_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->log_port = log_port;
    cmd_body_p->vport_vlan_cnt = *vport_vlan_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_VPORT_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *vport_vlan_cnt_p = cmd_body_p->vport_vlan_cnt;
        if (NULL != vlan_id_list_p) {
            SX_MEM_CPY_ARRAY(vlan_id_list_p, cmd_body_p->vlan_id_list,
                             *vport_vlan_cnt_p, sx_vlan_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_vport_base_get(const sx_api_handle_t  handle,
                                       const sx_port_log_id_t vport,
                                       sx_vlan_id_t          *vlan_id_p,
                                       sx_port_log_id_t      *log_port_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_port_vport_base_get_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(sx_api_port_vport_base_get_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_vport = vport;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_VPORT_BASE_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        if (vlan_id_p) {
            *vlan_id_p = cmd_body.vlan_id;
        }
        if (log_port_p) {
            *log_port_p = cmd_body.log_port;
        }
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_vport_counter_bind_set(const sx_api_handle_t      handle,
                                               const sx_access_cmd_t      cmd,
                                               const sx_port_log_id_t     virtual_port,
                                               const sx_flow_counter_id_t flow_counter_id)
{
    sx_api_port_vport_counter_bind_set_params_t cmd_body;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);


    cmd_body.cmd = cmd;
    cmd_body.virtual_port = virtual_port;
    cmd_body.flow_counter_id = flow_counter_id;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_PORT_VPORT_COUNTER_BIND_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_vport_counter_bind_set_params_t));

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_port_vport_counter_bind_get(const sx_api_handle_t  handle,
                                               const sx_port_log_id_t virtual_port,
                                               sx_flow_counter_id_t  *flow_counter_id_p)
{
    sx_api_port_vport_counter_bind_get_params_t cmd_body;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == flow_counter_id_p) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.virtual_port = virtual_port;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_PORT_VPORT_COUNTER_BIND_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_vport_counter_bind_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *flow_counter_id_p = cmd_body.flow_counter_id;


out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_port_phy_mode_set(const sx_api_handle_t     handle,
                                     const sx_port_log_id_t    log_port,
                                     const sx_port_phy_speed_t speed,
                                     const sx_port_phy_mode_t  admin_mode)
{
    sx_api_port_phy_mode_set_params_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;
    cmd_body.speed = speed;
    cmd_body.admin_mode = admin_mode;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_PORT_PHY_MODE_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_phy_mode_set_params_t));

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_port_phy_mode_get(const sx_api_handle_t     handle,
                                     const sx_port_log_id_t    log_port,
                                     const sx_port_phy_speed_t speed,
                                     sx_port_phy_mode_t      * admin_mode_p,
                                     sx_port_phy_mode_t      * oper_mode_p)
{
    sx_api_port_phy_mode_get_params_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((NULL == admin_mode_p) || (NULL == oper_mode_p)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_id = log_port;
    cmd_body.speed = speed;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_PORT_PHY_MODE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_port_phy_mode_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *admin_mode_p = cmd_body.admin_mode;
    *oper_mode_p = cmd_body.oper_mode;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_storm_control_counters_get(const sx_api_handle_t            handle,
                                                   const sx_port_log_id_t           log_port,
                                                   const sx_port_storm_control_id_t storm_control_id,
                                                   sx_policer_counters_t           *policer_counters_p)
{
    sx_status_t                                     rc = SX_STATUS_SUCCESS;
    sx_api_port_storm_control_counters_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (policer_counters_p == NULL) {
        SX_LOG_ERR("policer_counters_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.log_port = log_port;
    cmd_body.storm_control_id = storm_control_id;

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_storm_control_counters_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(policer_counters_p, &(cmd_body.policer_counters));
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_storm_control_counters_clear_set(const sx_api_handle_t              handle,
                                                         const sx_port_log_id_t             log_port,
                                                         const sx_port_storm_control_id_t   storm_control_id,
                                                         const sx_policer_counters_clear_t *clear_counters_p)
{
    sx_status_t                                           rc = SX_STATUS_SUCCESS;
    sx_api_port_storm_control_counters_clear_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (clear_counters_p == NULL) {
        SX_LOG_ERR("counters_clear_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.log_port = log_port;
    cmd_body.storm_control_id = storm_control_id;
    cmd_body.policer_counters_clear.clear_violation_counter = clear_counters_p->clear_violation_counter;


    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_CLEAR_SET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_port_storm_control_counters_clear_set_params_t));

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_port_discard_reason_get(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           sx_port_discard_reason_t *discard_reason_list_p,
                                           const uint32_t            list_count)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_port_discard_reason_get_params_t *cmd_body;
    uint32_t                                 cmd_size = 0;

    SX_API_LOG_ENTER();

    if (discard_reason_list_p == NULL) {
        SX_LOG_ERR("discard_reason_list_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }


    cmd_size = sizeof(sx_api_port_discard_reason_get_params_t) +
               (sizeof(sx_port_discard_reason_t) * list_count);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body = (sx_api_port_discard_reason_get_params_t*)cl_malloc(cmd_size);
    if (!cmd_body) {
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_MEMORY;
    }


    SX_MEM_CLR_TYPE(cmd_body, sx_api_port_discard_reason_get_params_t);
    cmd_body->cmd = cmd;
    cmd_body->list_count = list_count;

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        SX_MEM_CPY_ARRAY(cmd_body->discard_reason, discard_reason_list_p,
                         list_count, sx_port_discard_reason_t);
        break;

    default:
        CL_FREE_N_NULL(cmd_body);
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_PORT_DISCARD_REASON_GET_E,
                                     (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_ARRAY(discard_reason_list_p, cmd_body->discard_reason,
                         list_count, sx_port_discard_reason_t);
    }

    CL_FREE_N_NULL(cmd_body);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_forwarding_mode_set(const sx_api_handle_t           handle,
                                            const sx_port_log_id_t          log_port,
                                            const sx_port_forwarding_mode_t admin_fwd_mode)
{
    sx_status_t                              api_rc = SX_STATUS_SUCCESS;
    sx_api_port_forwarding_mode_set_params_t cmd_body =
    { .cmd = SX_ACCESS_CMD_SET, .port_id = log_port, .admin_fwd_mode = admin_fwd_mode};
    uint32_t cmd_size = sizeof(sx_api_port_forwarding_mode_set_params_t);

    SX_API_LOG_ENTER();

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_FORWARDING_MODE_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_forwarding_mode_get(const sx_api_handle_t      handle,
                                            const sx_port_log_id_t     log_port,
                                            sx_port_forwarding_mode_t *admin_fwd_mode_p)
{
    sx_status_t                              api_rc = SX_STATUS_SUCCESS;
    sx_api_port_forwarding_mode_get_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                                 cmd_size = sizeof(sx_api_port_forwarding_mode_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(
            api_rc = utils_check_pointer(admin_fwd_mode_p, "Port Administrative Forwarding Mode"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_FORWARDING_MODE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *admin_fwd_mode_p = cmd_body.admin_fwd_mode;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_parsing_depth_set(const sx_api_handle_t handle, const uint16_t parsing_depth)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               cmd_size;
    sx_api_port_parsing_depth_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_LOG_DEPRECATED_FUNC_ERR(sx_api_port_parser_attr_set)


    if (parsing_depth == 0) {
        SX_LOG(SX_LOG_ERROR, "parsing_depth 0 is not supported\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.parsing_depth = parsing_depth;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PARSING_DEPTH_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_parsing_depth_get(const sx_api_handle_t handle, uint16_t                   *parsing_depth_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               cmd_size;
    sx_api_port_parsing_depth_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_LOG_DEPRECATED_FUNC_ERR(sx_api_port_parser_attr_get)


    if (parsing_depth_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "parsing_depth_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PARSING_DEPTH_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    *parsing_depth_p = cmd_body.parsing_depth;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_port_parser_attr_set(const sx_api_handle_t handle, const sx_parser_attributes_t    *parser_attr_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_body_size = sizeof(sx_api_port_parser_attr_set_params_t);
    sx_api_port_parser_attr_set_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();

    if (parser_attr_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "parser_attr_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (parser_attr_p->parsing_depth_valid && (parser_attr_p->parsing_depth == 0)) {
        SX_LOG(SX_LOG_ERROR, "parsing_depth 0 is not supported\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }
    SX_MEM_CPY(cmd_body_p->parser_attributes, *parser_attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PARSER_ATTR_SET_E,
                                      (uint8_t*)cmd_body_p, cmd_body_size);

out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_port_parser_attr_get(const sx_api_handle_t handle, sx_parser_attributes_t   *parser_attr_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_body_size = sizeof(sx_api_port_parser_attr_set_params_t);
    sx_api_port_parser_attr_get_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();
    if (parser_attr_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "parser_attr_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PARSER_ATTR_GET_E,
                                      (uint8_t*)cmd_body_p, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY_P(parser_attr_p, &(cmd_body_p->parser_attributes));
    }

out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_port_vlan_ethertype_set(const sx_api_handle_t handle,
                                           const sx_access_cmd_t cmd,
                                           sx_vlan_ethertype_t  *ether_types_list_p,
                                           uint32_t              ether_type_count)
{
    sx_api_port_ethertype_set_params_t *cmd_body = NULL;
    uint32_t                            i = 0, cmd_body_size = 0;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (ether_types_list_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ether_types_list_p is NULL\n");
        goto out;
    }

    if (ether_type_count == 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ether_type_count is 0\n");
        goto out;
    }


    cmd_body_size = sizeof(sx_api_port_ethertype_set_params_t) +
                    (ether_type_count * sizeof(sx_vlan_ethertype_t));

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }


    cmd_body->cmd = cmd;
    cmd_body->ether_type_cnt = ether_type_count;
    for (i = 0; i < ether_type_count; i++) {
        cmd_body->ether_type_list[i].ethertype = ether_types_list_p[i].ethertype;
        cmd_body->ether_type_list[i].ethertype_function = ether_types_list_p[i].ethertype_function;
    }


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_ETHERTYPE_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);


out:
    if (cmd_body != NULL) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_port_vlan_ethertype_get(const sx_api_handle_t handle,
                                           sx_vlan_ethertype_t  *ether_types_list_p,
                                           uint32_t             *ether_type_count_p)
{
    sx_api_command_head_t               cmd_head;
    sx_api_port_ethertype_get_params_t  cmd_body;
    sx_api_reply_head_t                 reply_head;
    sx_api_port_ethertype_get_params_t* reply_body = NULL;
    uint32_t                            reply_body_size;
    sx_status_t                         err = SX_STATUS_SUCCESS;
    uint32_t                            i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);


    if (ether_type_count_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ether_type_count is NULL\n");
        goto out;
    }


    if ((*ether_type_count_p != 0) && (ether_types_list_p == NULL)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ether_types_list_p is NULL\n");
        goto out;
    }


    reply_body_size = sizeof(sx_api_port_ethertype_get_params_t) +
                      (*ether_type_count_p * sizeof(sx_vlan_ethertype_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_PORT_ETHERTYPE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_port_ethertype_get_params_t);
    cmd_head.list_size = *ether_type_count_p * sizeof(sx_vlan_ethertype_t);

    cmd_body.ether_type_cnt = *ether_type_count_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (ether_types_list_p != NULL) {
        for (i = 0; i < reply_body->ether_type_cnt; i++) {
            ether_types_list_p[i].ethertype = reply_body->ether_type_list[i].ethertype;
            ether_types_list_p[i].ethertype_function = reply_body->ether_type_list[i].ethertype_function;
        }
    }

    *ether_type_count_p = reply_body->ether_type_cnt;

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ber_threshold_set(sx_api_handle_t                          handle,
                                          sx_port_log_id_t                         log_port,
                                          sx_port_ber_fec_profile_e                fec_profile,
                                          sx_port_ber_fec_profile_threshold_data_t threshold_data)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               cmd_size;
    sx_api_port_ber_threshold_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.log_port = log_port;
    cmd_body.fec_profile = fec_profile;
    cmd_body.threshold_data = threshold_data;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BER_THRESHOLD_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ber_threshold_get(const sx_api_handle_t                     handle,
                                          const sx_port_log_id_t                    log_port,
                                          const sx_port_ber_fec_profile_e           fec_profile,
                                          sx_port_ber_fec_profile_threshold_data_t *threshold_data_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               cmd_size;
    sx_api_port_ber_threshold_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (threshold_data_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "threshold_data_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.log_port = log_port;
    cmd_body.fec_profile = fec_profile;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BER_THRESHOLD_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(err)) {
        *threshold_data_p = cmd_body.threshold_data;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ber_monitor_set(sx_api_handle_t            handle,
                                        sx_port_log_id_t           log_port,
                                        sx_port_ber_monitor_data_t monitor_data)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    uint32_t                                    cmd_size;
    sx_api_port_ber_monitor_config_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.log_port = log_port;
    cmd_body.monitor_data = monitor_data;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BER_MONITOR_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ber_monitor_get(sx_api_handle_t             handle,
                                        sx_port_log_id_t            log_port,
                                        sx_port_ber_monitor_data_t *monitor_data_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    uint32_t                                    cmd_size;
    sx_api_port_ber_monitor_config_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (monitor_data_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "monitor_data_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BER_MONITOR_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(err)) {
        *monitor_data_p = cmd_body.monitor_data;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ber_monitor_operational_get(sx_api_handle_t                  handle,
                                                    sx_port_log_id_t                 log_port,
                                                    sx_port_ber_monitor_oper_data_t *monitor_oper_data_p)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    uint32_t                                         cmd_size;
    sx_api_port_ber_monitor_operational_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (monitor_oper_data_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "monitor_oper_data_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);
    cmd_body.log_port = log_port;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_BER_MONITOR_OPERATIONAL_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        *monitor_oper_data_p = cmd_body.monitor_oper_data;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_sll_set(const sx_api_handle_t handle, const uint64_t sll_max_time)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_api_sys_sll_set_params_t cmd_body;
    uint32_t                    cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.sll_time_usec = sll_max_time;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SLL_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_sll_get(const sx_api_handle_t handle, uint64_t                *sll_max_time_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    cmd_size;
    sx_api_sys_sll_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (sll_max_time_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "sll_max_time_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    cmd_size = sizeof(cmd_body);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SLL_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *sll_max_time_p = cmd_body.sll_time_usec;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_hll_set(const sx_api_handle_t  handle,
                                const sx_port_log_id_t log_port,
                                const uint32_t         hll_max_time,
                                const uint32_t         hll_stall_cnt)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_api_port_hll_set_params_t cmd_body;
    uint32_t                     cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.hll_time_usec = hll_max_time;
    cmd_body.port_id = log_port;
    if (hll_stall_cnt) {
        cmd_body.hll_stall_en = TRUE;
        cmd_body.hll_stall_cnt = hll_stall_cnt;
    } else {
        cmd_body.hll_stall_en = FALSE;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_HLL_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_hll_get(const sx_api_handle_t  handle,
                                const sx_port_log_id_t log_port,
                                uint32_t              *hll_max_time_p,
                                uint32_t              *hll_stall_cnt_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     cmd_size;
    sx_api_port_hll_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (hll_max_time_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "hll_max_time_p == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (hll_stall_cnt_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "hll_num_pkts_to_stall == NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_size = sizeof(cmd_body);

    cmd_body.port_id = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_HLL_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *hll_max_time_p = cmd_body.hll_time_usec;

        if (cmd_body.hll_stall_en) {
            *hll_stall_cnt_p = cmd_body.hll_stall_cnt;
        } else {
            *hll_stall_cnt_p = 0;
        }
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_crc_params_set(const sx_api_handle_t       handle,
                                       const sx_port_log_id_t      log_port,
                                       const sx_port_crc_params_t *crc_params_p)
{
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_crc_params_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (crc_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "CRC options ptr is NULL\n");
        api_rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.log_port = log_port;
    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.crc_params = *crc_params_p;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_CRC_PARAMS_SET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));
out:
    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_crc_params_get(const sx_api_handle_t  handle,
                                       const sx_port_log_id_t log_port,
                                       sx_port_crc_params_t  *crc_params_p)
{
    sx_status_t                         api_rc = SX_STATUS_SUCCESS;
    sx_api_port_crc_params_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (crc_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "crc_params_p == NULL\n");
        api_rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(cmd_body));
    cmd_body.log_port = log_port;
    cmd_body.cmd = SX_ACCESS_CMD_GET;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_CRC_PARAMS_GET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_PASS(api_rc)) {
        *crc_params_p = cmd_body.crc_params;
    }

out:
    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_ptp_params_set(const sx_api_handle_t       handle,
                                       const sx_access_cmd_t       cmd,
                                       const sx_port_log_id_t      log_port,
                                       const sx_port_ptp_params_t *port_ptp_params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    uint32_t                           cmd_body_size = 0;
    sx_api_port_ptp_params_set_param_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (port_ptp_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "port ptp params ptr is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_EDIT) {
        SX_LOG_ERR("sx_api_port_ptp_params_set failed. unsupported command. cmd:%d \n", cmd);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_port_ptp_params_set_param_t);

    cmd_body.log_port = log_port;
    cmd_body.cmd = cmd;
    cmd_body.role_params.cmd = port_ptp_params_p->cmd;
    cmd_body.role_params.low_speed_rx_role = port_ptp_params_p->low_speed_rx_role;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PTP_PARAMS_SET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set ptp port params\n");
        goto out;
    }

out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_port_ptp_params_get(const sx_api_handle_t  handle,
                                       const sx_access_cmd_t  cmd,
                                       const sx_port_log_id_t log_port,
                                       sx_port_ptp_params_t  *port_ptp_params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    uint32_t                           cmd_body_size = 0;
    sx_api_port_ptp_params_get_param_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (port_ptp_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "port ptp params ptr is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("sx_api_port_ptp_params_get failed. unsupported command. cmd:%d \n", cmd);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_port_ptp_params_get_param_t);

    cmd_body.log_port = log_port;
    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PTP_PARAMS_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ptp port params\n");
        goto out;
    }

    port_ptp_params_p->low_speed_rx_role = cmd_body.role_params.low_speed_rx_role;

out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_port_rate_set(const sx_api_handle_t         handle,
                                 const sx_port_log_id_t        log_port,
                                 const sx_port_rate_bitmask_t *rate_p)
{
    sx_status_t               api_rc = SX_STATUS_SUCCESS;
    sx_api_port_rate_params_t cmd_body;
    uint32_t                  cmd_size = sizeof(sx_api_port_rate_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == rate_p) {
        SX_LOG_ERR("Rate Set failed: rate_p is null pointer.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.port_id = log_port;
    cmd_body.admin_rate = *rate_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_RATE_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_rate_get(const sx_api_handle_t  handle,
                                 const sx_port_log_id_t log_port,
                                 sx_port_rate_e        *oper_rate_p)
{
    sx_status_t               api_rc = SX_STATUS_SUCCESS;
    sx_api_port_rate_params_t cmd_body = { .cmd = SX_ACCESS_CMD_GET, .port_id = log_port };
    uint32_t                  cmd_size = sizeof(sx_api_port_rate_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(oper_rate_p, "Port Operational Rate"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_RATE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        *oper_rate_p = cmd_body.oper_rate;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_rate_capability_get(const sx_api_handle_t              handle,
                                            const sx_port_log_id_t             log_port,
                                            sx_port_rate_bitmask_t            *admin_rate_p,
                                            sx_port_rate_bitmask_t            *capab_rate_p,
                                            sx_port_phy_module_type_bitmask_t *capab_type_p)
{
    sx_status_t               api_rc = SX_STATUS_SUCCESS;
    sx_api_port_rate_params_t cmd_body = {.cmd = SX_ACCESS_CMD_GET, .port_id = log_port};
    uint32_t                  cmd_size = sizeof(sx_api_port_rate_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(admin_rate_p, "Admin Rate"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(capab_rate_p, "Capability Rate"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(capab_type_p, "Capability Module Type"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_RATE_CAPAB_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *admin_rate_p = cmd_body.admin_rate;
        *capab_rate_p = cmd_body.capab_rate;
        *capab_type_p = cmd_body.capab_module_type;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_phy_info_get(const sx_api_handle_t  handle,
                                     const sx_access_cmd_t  cmd,
                                     const sx_port_log_id_t log_port,
                                     sx_port_phy_stat_t    *phy_stat_p)
{
    sx_status_t                       api_rc = SX_STATUS_SUCCESS;
    sx_api_port_phy_info_get_params_t cmd_body = { .cmd = cmd, .log_port = log_port };
    uint32_t                          cmd_size = sizeof(sx_api_port_phy_info_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(phy_stat_p, "phy_stat_p"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_PHY_INFO_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *phy_stat_p = cmd_body.phy_stat;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_user_memory_set(const sx_api_handle_t               handle,
                                        const sx_access_cmd_t               cmd,
                                        const sx_port_user_memory_params_t *port_params_list_p,
                                        const uint32_t                      port_cnt)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_status_t                           api_rc = SX_STATUS_SUCCESS;
    sx_api_port_user_memory_set_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = sizeof(sx_api_port_user_memory_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(port_params_list_p, "port_params_list_p"))) {
        SX_LOG_ERR("port_params_list_p is NULL for port user memory set.\n");
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_ERR("Ports list length is zero for port user memory set.\n");
        api_rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_size += port_cnt * sizeof(sx_port_user_memory_params_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        api_rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E, "port user memory set cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        api_rc = rc;
        SX_LOG_ERR("Failed allocating memory for port user memory set. %u ports \n", port_cnt);
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->port_cnt = port_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->port_user_memory_list, port_params_list_p,
                     port_cnt, sx_port_user_memory_params_t);

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_USER_MEM_SET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p free port user memory set", rc);

out:
    SX_API_LOG_EXIT();
    return api_rc;
}


sx_status_t sx_api_port_user_memory_get(const sx_api_handle_t         handle,
                                        sx_port_user_memory_params_t *port_params_list_p,
                                        const uint32_t                port_cnt)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_status_t                           api_rc = SX_STATUS_SUCCESS;
    sx_api_port_user_memory_set_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = sizeof(sx_api_port_user_memory_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(port_params_list_p, "port_params_list_p"))) {
        SX_LOG_ERR("port_params_list_p is NULL for port user memory get.\n");
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_ERR("Ports list length is zero for port user memory get.\n");
        api_rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_size += port_cnt * sizeof(sx_port_user_memory_params_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        api_rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E, "port user memory get cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        api_rc = rc;
        SX_LOG_ERR("Failed allocating memory for port user memory get. %u ports \n", port_cnt);
        goto out;
    }

    cmd_body_p->port_cnt = port_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->port_user_memory_list, port_params_list_p,
                     port_cnt, sx_port_user_memory_params_t);

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_USER_MEM_GET_E,
                                         (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_ARRAY(port_params_list_p, cmd_body_p->port_user_memory_list,
                         port_cnt, sx_port_user_memory_params_t);
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p free port user memory get", rc);

out:
    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_device_mapping_get(const sx_api_handle_t handle,
                                           const sx_device_id_t  device_id,
                                           sx_port_attributes_t *port_attributes_list_p,
                                           uint32_t             *port_attr_list_size_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_port_device_mapping_get_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_port_device_mapping_get_params_t);

    SX_API_LOG_ENTER();

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (port_attr_list_size_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to retrieve device port mapping, port_attr_list_size_p param error[%s]\n",
                   SX_STATUS_MSG(rc));
        goto out;
    }

    if (*port_attr_list_size_p != 0) {
        if (port_attributes_list_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed to retrieve device port mapping, port_attr_list param error[%s]\n", SX_STATUS_MSG(rc));
            goto out;
        }
    }

    cmd_size += (*port_attr_list_size_p) * sizeof(sx_port_attributes_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_port_device_mapping_get_params_t*)cl_calloc(1, cmd_size);
    if (cmd_body_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for port attribute list array.\n");
        goto out;
    }

    cmd_body_p->port_attr_list_size = *port_attr_list_size_p;
    cmd_body_p->device_id = device_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_DEVICE_MAPPING_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve device port mapping, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (*port_attr_list_size_p) {
        SX_MEM_CPY_ARRAY(port_attributes_list_p, cmd_body_p->port_attr_list,
                         cmd_body_p->port_attr_list_size, sx_port_attributes_t);
    }

    *port_attr_list_size_p = cmd_body_p->port_count;

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_port_profile_set(const sx_api_handle_t           handle,
                                    const sx_access_cmd_t           cmd,
                                    const sx_port_profile_params_t *params_p,
                                    sx_port_log_id_t               *port_profile_id_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_api_port_profile_set_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(cmd_body);

    SX_MEM_CLR(cmd_body);


    if (port_profile_id_p == NULL) {
        SX_LOG_ERR("port_profile_id_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (params_p == NULL) {
            SX_LOG_ERR("params_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.params.profile_type = params_p->profile_type;
        cmd_body.params.width = params_p->width;
    }

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        if (port_profile_id_p == NULL) {
            SX_LOG_ERR("port_profile_id_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.port_profile_id = *port_profile_id_p;
    }

    cmd_body.cmd = cmd;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PROFILE_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (cmd == SX_ACCESS_CMD_CREATE) {
        *port_profile_id_p = cmd_body.port_profile_id;
    }

out:
    return rc;
}

sx_status_t sx_api_port_profile_apply_set(const sx_api_handle_t                 handle,
                                          const sx_port_log_id_t                port_profile_id,
                                          const sx_port_profile_apply_params_t *params_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_port_profile_apply_set_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(cmd_body);

    SX_MEM_CLR(cmd_body);

    if (params_p == NULL) {
        SX_LOG_ERR("params_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.port_profile_id = port_profile_id;


    cmd_body.params.port_list_cnt = params_p->port_list_cnt;
    SX_MEM_CPY_ARRAY(cmd_body.params.port_list, params_p->port_list,
                     params_p->port_list_cnt, sx_port_log_id_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_PROFILE_APPLY_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);
out:
    return rc;
}
sx_status_t sx_api_port_connector_type_get(const sx_api_handle_t            handle,
                                           const sx_port_log_id_t           log_port,
                                           sx_port_connector_type_params_t *connector_type_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_port_connector_type_get_params_t cmd_body = { .log_port = log_port };
    uint32_t                                cmd_size = sizeof(sx_api_port_connector_type_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(connector_type_p, "Port connector type"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_CONNECTOR_TYPE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        connector_type_p->port_connector_type = cmd_body.connector_type.port_connector_type;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_remote_capability_get(const sx_api_handle_t             handle,
                                              const sx_port_log_id_t            log_port,
                                              sx_port_remote_port_capability_t *remote_port_capability_p)
{
    sx_status_t                                rc = SX_STATUS_SUCCESS;
    sx_status_t                                api_rc = SX_STATUS_SUCCESS;
    sx_api_port_remote_capability_get_params_t cmd_body = { .log_port = log_port };
    uint32_t                                   cmd_size = sizeof(sx_api_port_remote_capability_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(remote_port_capability_p, "Port remote capability"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_REMOTE_CAPABILITY_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        remote_port_capability_p->remote_speed = cmd_body.remote_port_capability.remote_speed;
        remote_port_capability_p->remote_fc_advertisement = cmd_body.remote_port_capability.remote_fc_advertisement;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_state_ext_get(const sx_api_handle_t     handle,
                                      const sx_port_log_id_t    log_port,
                                      sx_port_ext_port_state_t *port_state_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_ext_get_params_t cmd_body = { .log_port = log_port };
    uint32_t                           cmd_size = sizeof(sx_api_port_state_ext_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(port_state_p, "Port enhanced state"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_STATE_EXT_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_P(port_state_p, &cmd_body.port_state);
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_port_group_get(const sx_api_handle_t handle,
                                  const sx_access_cmd_t cmd,
                                  sx_port_group_cfg_t  *port_group_cfg_list_p,
                                  uint32_t             *port_group_cfg_cnt_p,
                                  sx_port_group_attr_t *group_attr_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     err_free = SX_STATUS_SUCCESS;
    sx_api_port_group_get_params_t *cmd_body_p = NULL;
    uint32_t                        cmd_size = sizeof(sx_api_port_group_get_params_t);

    SX_API_LOG_ENTER();

    if (port_group_cfg_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("port_group_cfg_cnt_p parameter is NULL\n");
        goto out;
    }

    if ((*port_group_cfg_cnt_p != 0) && (port_group_cfg_list_p == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("port_group_cfg_list_p is NULL while port_group_cfg_cnt_p != 0\n");
        goto out;
    }

    if (group_attr_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("group_attr_p parameter is NULL\n");
        goto out;
    }

    cmd_size += (*port_group_cfg_cnt_p) * sizeof(sx_port_group_cfg_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "cmd_body_p", err);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    if (port_group_cfg_list_p) {
        SX_MEM_CPY_ARRAY(cmd_body_p->port_group_cfg_list,
                         port_group_cfg_list_p,
                         *port_group_cfg_cnt_p,
                         sx_port_group_cfg_t);
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->port_group_cfg_cnt = *port_group_cfg_cnt_p;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_GROUP_GET_E,
                                      (uint8_t*)cmd_body_p, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        SX_MEM_CPY_P(group_attr_p, &cmd_body_p->group_attr);
        if (cmd_body_p->port_group_cfg_cnt && port_group_cfg_list_p) {
            *port_group_cfg_cnt_p = cmd_body_p->port_group_cfg_cnt;
            SX_MEM_CPY_ARRAY(port_group_cfg_list_p,
                             cmd_body_p->port_group_cfg_list,
                             cmd_body_p->port_group_cfg_cnt,
                             sx_port_group_cfg_t);
        }
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Error on cmd_body_p memory free", err_free);
        if ((err_free != SX_STATUS_SUCCESS) && (err == SX_STATUS_SUCCESS)) {
            err = err_free;
        }
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_state_event_delay_set(const sx_api_handle_t        handle,
                                              const sx_access_cmd_t        cmd,
                                              const sx_port_log_id_t       log_port,
                                              const sx_port_state_delay_t *port_state_delay_p)
{
    sx_status_t                                api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_event_delay_set_params_t cmd_body;
    uint32_t                                   cmd_size = sizeof(sx_api_port_state_event_delay_set_params_t);

    SX_API_LOG_ENTER();


    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(port_state_delay_p, "Port State Delay"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&(cmd_body.port_state_delay), port_state_delay_p);

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_STATE_EVENT_DELAY_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_state_event_delay_get(const sx_api_handle_t  handle,
                                              const sx_port_log_id_t log_port,
                                              sx_port_state_delay_t *port_state_delay_p)
{
    sx_status_t                                api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_event_delay_set_params_t cmd_body;
    uint32_t                                   cmd_size = sizeof(sx_api_port_state_event_delay_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(port_state_delay_p, "Port State Delay"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.log_port = log_port;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_STATE_EVENT_DELAY_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_P(port_state_delay_p, &(cmd_body.port_state_delay));
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_state_event_delay_counter_get(const sx_api_handle_t                 handle,
                                                      const sx_access_cmd_t                 cmd,
                                                      const sx_port_log_id_t                log_port,
                                                      sx_port_state_event_delay_counters_t *cntr_delay_state_p)
{
    sx_status_t                                        api_rc = SX_STATUS_SUCCESS;
    sx_api_port_state_event_delay_counter_get_params_t cmd_body;
    uint32_t                                           cmd_size =
        sizeof(sx_api_port_state_event_delay_counter_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(cntr_delay_state_p, "Port State Delay Counters"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_PORT_STATE_EVENT_DELAY_COUNTER_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY_P(cntr_delay_state_p, &(cmd_body.cntr_delay_state_t));
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_port_media_settings_set(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           const sx_port_log_id_t    log_port,
                                           sx_port_media_settings_t *media_settings_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_port_media_settings_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (media_settings_p == NULL) {
        SX_LOG_ERR("media_settings_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_SET) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.media_settings, media_settings_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MEDIA_SETTINGS_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set media setting for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_media_settings_get(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           const sx_port_log_id_t    log_port,
                                           sx_port_media_settings_t *media_settings_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_port_media_settings_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (media_settings_p == NULL) {
        SX_LOG_ERR("media_settings_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.media_settings, media_settings_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MEDIA_SETTINGS_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get media setting for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(media_settings_p, &cmd_body.media_settings);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_media_settings_bulk_set(const sx_api_handle_t     handle,
                                                const sx_access_cmd_t     cmd,
                                                const sx_port_log_id_t   *log_port_list_p,
                                                sx_port_media_settings_t *media_settings_list_p,
                                                const uint32_t            port_cnt)
{
    sx_status_t                                   rc = SX_STATUS_SUCCESS;
    sx_status_t                                   utils_rc = SX_STATUS_SUCCESS;
    sx_api_port_media_settings_bulk_set_params_t *cmd_body_p = NULL;
    uint8_t                                      *buffer_p = NULL;
    void                                         *current_p = NULL;
    uint32_t                                      buffer_size = 0;
    sx_port_media_settings_t                     *media_settings_p = NULL;

    SX_API_LOG_ENTER();

    if (log_port_list_p == NULL) {
        SX_LOG_ERR("Failed to set media settings: log_port_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (media_settings_list_p == NULL) {
        SX_LOG_ERR("Failed to set media settings: media_settings_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_NTC("Bulk media settings set: empty port list, port_cnt is 0.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_SET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

    buffer_size = sizeof(sx_api_port_media_settings_bulk_set_params_t) +
                  port_cnt * sizeof(sx_port_log_id_t) +
                  port_cnt * sizeof(sx_port_media_settings_t);

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed to get port media settings: Message size %d exceeds limit %d\n",
                   buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate buffer_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p = (sx_api_port_media_settings_bulk_set_params_t*)buffer_p;
    cmd_body_p->cmd = cmd;
    cmd_body_p->port_cnt = port_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list_p, port_cnt, sx_port_log_id_t);

    current_p = cmd_body_p->log_port_list;
    current_p += cmd_body_p->port_cnt * sizeof(sx_port_log_id_t);
    media_settings_p = (sx_port_media_settings_t *)current_p;

    SX_MEM_CPY_ARRAY(media_settings_p, media_settings_list_p, port_cnt, sx_port_media_settings_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MEDIA_SETTINGS_BULK_SET_E,
                                     buffer_p, buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    if (buffer_p != NULL) {
        M_UTILS_MEM_PUT(buffer_p, UTILS_MEM_TYPE_ID_API_E, "Error on buffer_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_media_settings_bulk_get(const sx_api_handle_t     handle,
                                                const sx_access_cmd_t     cmd,
                                                const sx_port_log_id_t   *log_port_list_p,
                                                sx_port_media_settings_t *media_settings_list_p,
                                                const uint32_t            port_cnt)
{
    sx_status_t                                   rc = SX_STATUS_SUCCESS;
    sx_status_t                                   utils_rc = SX_STATUS_SUCCESS;
    sx_api_port_media_settings_bulk_get_params_t *cmd_body_p = NULL;
    uint8_t                                      *buffer_p = NULL;
    void                                         *current_p = NULL;
    uint32_t                                      buffer_size = 0;
    sx_port_media_settings_t                     *media_settings_p = NULL;

    SX_API_LOG_ENTER();

    if (log_port_list_p == NULL) {
        SX_LOG_ERR("Failed to get media settings: log_port_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (media_settings_list_p == NULL) {
        SX_LOG_ERR("Failed to get media settings: media_settings_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_NTC("Bulk media settings get: empty port list, port_cnt is 0.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

    buffer_size = sizeof(sx_api_port_media_settings_bulk_get_params_t) +
                  port_cnt * sizeof(sx_port_log_id_t) +
                  port_cnt * sizeof(sx_port_media_settings_t);

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed to get port media settings: Message size %d exceeds limit %d\n",
                   buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate buffer_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p = (sx_api_port_media_settings_bulk_get_params_t*)buffer_p;
    cmd_body_p->cmd = cmd;
    cmd_body_p->port_cnt = port_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list_p, port_cnt, sx_port_log_id_t);

    current_p = cmd_body_p->log_port_list;
    current_p += cmd_body_p->port_cnt * sizeof(sx_port_log_id_t);
    media_settings_p = (sx_port_media_settings_t *)current_p;

    SX_MEM_CPY_ARRAY(media_settings_p, media_settings_list_p, port_cnt, sx_port_media_settings_t);


    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_MEDIA_SETTINGS_BULK_GET_E,
                                     buffer_p, buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    SX_MEM_CPY_ARRAY(media_settings_list_p, media_settings_p, port_cnt, sx_port_media_settings_t);

out:
    if (buffer_p != NULL) {
        M_UTILS_MEM_PUT(buffer_p, UTILS_MEM_TYPE_ID_API_E, "Error on buffer_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_tx_signal_set(const sx_api_handle_t  handle,
                                      const sx_access_cmd_t  cmd,
                                      const sx_port_log_id_t log_port,
                                      sx_port_tx_signal_t   *tx_signal_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_port_tx_signal_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (tx_signal_p == NULL) {
        SX_LOG_ERR("tx_signal_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.tx_signal, tx_signal_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_TX_SIGNAL_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set TX signal for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_tx_signal_attr_get(const sx_api_handle_t  handle,
                                           const sx_access_cmd_t  cmd,
                                           const sx_port_log_id_t log_port,
                                           sx_port_tx_signal_t   *tx_signal_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_port_tx_signal_attr_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (tx_signal_p == NULL) {
        SX_LOG_ERR("tx_signal_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_TX_SIGNAL_ATTR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get TX signal attributes for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(tx_signal_p, &cmd_body.tx_signal);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_tx_signal_oper_get(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           const sx_port_log_id_t    log_port,
                                           sx_port_tx_signal_oper_t *tx_signal_oper_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_port_tx_signal_oper_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (tx_signal_oper_p == NULL) {
        SX_LOG_ERR("tx_signal_oper_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_TX_SIGNAL_OPER_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get TX signal oper state for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(tx_signal_oper_p, &cmd_body.tx_signal_oper);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ext_params_set(const sx_api_handle_t      handle,
                                       const sx_access_cmd_t      cmd,
                                       const sx_port_log_id_t     log_port,
                                       sx_port_ext_port_params_t *extended_params_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_port_ext_params_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (extended_params_p == NULL) {
        SX_LOG_ERR("extended_params_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.extended_params, extended_params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_EXT_PARAMS_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ext_params_get(const sx_api_handle_t      handle,
                                       const sx_access_cmd_t      cmd,
                                       const sx_port_log_id_t     log_port,
                                       sx_port_ext_port_params_t *extended_params_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_port_ext_params_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (extended_params_p == NULL) {
        SX_LOG_ERR("extended_params_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.extended_params, extended_params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_EXT_PARAMS_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CPY_P(extended_params_p, &cmd_body.extended_params);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_port_ext_params_bulk_set(const sx_api_handle_t            handle,
                                            const sx_access_cmd_t            cmd,
                                            const sx_port_log_id_t          *log_port_list_p,
                                            const sx_port_ext_port_params_t *extended_params_list_p,
                                            const uint32_t                   port_cnt)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_status_t                               utils_rc = SX_STATUS_SUCCESS;
    sx_api_port_ext_params_bulk_set_params_t *cmd_body_p = NULL;
    uint8_t                                  *buffer_p = NULL;
    void                                     *current_p = NULL;
    uint32_t                                  buffer_size = 0;
    sx_port_ext_port_params_t                *ext_settings_p = NULL;

    SX_API_LOG_ENTER();

    if (log_port_list_p == NULL) {
        SX_LOG_ERR("Failed to set extended param settings: log_port_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (extended_params_list_p == NULL) {
        SX_LOG_ERR("Failed to set extended param settings: extended_params_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_NTC("Bulk extended param settings set: empty port list, port_cnt is 0.\n");
        goto out;
    }

    buffer_size = sizeof(sx_api_port_ext_params_bulk_set_params_t) +
                  port_cnt * sizeof(sx_port_log_id_t) +
                  port_cnt * sizeof(sx_port_ext_port_params_t);

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed to get port extended param settings: Message size %d exceeds limit %d\n",
                   buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate buffer_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p = (sx_api_port_ext_params_bulk_set_params_t *)buffer_p;
    cmd_body_p->cmd = cmd;
    cmd_body_p->port_cnt = port_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list_p, log_port_list_p, port_cnt, sx_port_log_id_t);

    current_p = cmd_body_p->log_port_list_p;
    current_p += cmd_body_p->port_cnt * sizeof(sx_port_log_id_t);
    ext_settings_p = (sx_port_ext_port_params_t *)current_p;

    SX_MEM_CPY_ARRAY(ext_settings_p, extended_params_list_p, port_cnt, sx_port_ext_port_params_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_EXT_PARAMS_BULK_SET_E,
                                     buffer_p, buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    if (buffer_p != NULL) {
        M_UTILS_MEM_PUT(buffer_p, UTILS_MEM_TYPE_ID_API_E, "Error on buffer_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_ext_params_bulk_get(const sx_api_handle_t      handle,
                                            const sx_access_cmd_t      cmd,
                                            const sx_port_log_id_t    *log_port_list_p,
                                            sx_port_ext_port_params_t *extended_params_list_p,
                                            const uint32_t             port_cnt)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_status_t                               utils_rc = SX_STATUS_SUCCESS;
    sx_api_port_ext_params_bulk_get_params_t *cmd_body_p = NULL;
    uint8_t                                  *buffer_p = NULL;
    void                                     *current_p = NULL;
    uint32_t                                  buffer_size = 0;
    sx_port_ext_port_params_t                *ext_settings_p = NULL;

    SX_API_LOG_ENTER();

    if (log_port_list_p == NULL) {
        SX_LOG_ERR("Failed to get extended param settings: log_port_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (extended_params_list_p == NULL) {
        SX_LOG_ERR("Failed to get extended param settings: extended_params_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (port_cnt == 0) {
        SX_LOG_NTC("Bulk extended param settings get: empty port list, port_cnt is 0.\n");
        goto out;
    }

    buffer_size = sizeof(sx_api_port_ext_params_bulk_get_params_t) +
                  port_cnt * sizeof(sx_port_log_id_t) +
                  port_cnt * sizeof(sx_port_ext_port_params_t);

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed to get port extended param settings: Message size %d exceeds limit %d\n",
                   buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate buffer_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p = (sx_api_port_ext_params_bulk_get_params_t *)buffer_p;
    cmd_body_p->cmd = cmd;
    cmd_body_p->port_cnt = port_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list_p, log_port_list_p, port_cnt, sx_port_log_id_t);

    current_p = cmd_body_p->log_port_list_p;
    current_p += cmd_body_p->port_cnt * sizeof(sx_port_log_id_t);
    ext_settings_p = (sx_port_ext_port_params_t *)current_p;

    SX_MEM_CPY_ARRAY(ext_settings_p, extended_params_list_p, port_cnt, sx_port_ext_port_params_t);


    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_EXT_PARAMS_BULK_GET_E,
                                     buffer_p, buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    SX_MEM_CPY_ARRAY(extended_params_list_p, ext_settings_p, port_cnt, sx_port_ext_port_params_t);

out:
    if (buffer_p != NULL) {
        M_UTILS_MEM_PUT(buffer_p, UTILS_MEM_TYPE_ID_API_E, "Error on buffer_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_port_ext_capability_get(const sx_api_handle_t     handle,
                                           const sx_port_log_id_t    log_port,
                                           sx_port_ext_capability_t *capability_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_port_ext_capability_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (capability_p == NULL) {
        SX_LOG_ERR("capability_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.log_port = log_port;
    SX_MEM_CPY_P(&cmd_body.capability, capability_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_PORT_EXT_CAPABILITY_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get extended capability params for port 0x%x, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(capability_p, &cmd_body.capability);

out:
    SX_API_LOG_EXIT();
    return err;
}
