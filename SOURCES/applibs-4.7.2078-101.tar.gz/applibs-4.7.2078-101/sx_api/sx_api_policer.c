/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_policer.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_POLICER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/***********************************************
*  API Functions Implementation
***********************************************/

sx_status_t sx_api_policer_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                   const sx_log_verbosity_target_t verbosity_target,
                                                   const sx_verbosity_level_t      module_verbosity_level,
                                                   const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_POLICER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_policer_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                   const sx_log_verbosity_target_t verbosity_target,
                                                   sx_verbosity_level_t           *module_verbosity_level_p,
                                                   sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_POLICER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_policer_set(const sx_api_handle_t          handle,
                               const sx_access_cmd_t          cmd,
                               const sx_policer_attributes_t *policer_attr_p,
                               sx_policer_id_t               *policer_id_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_api_policer_set_params_t cmd_body;
    sx_log_severity_t           log_level = SX_LOG_ERROR;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (policer_id_p == NULL) {
        SX_LOG_ERR("Policer ID is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((policer_attr_p == NULL) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("policer_info is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = cmd;
    cmd_body.policer_id = *policer_id_p;

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        SX_MEM_CPY(cmd_body.policer_attr, *policer_attr_p);
    }

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_POLICER_SET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_policer_set_params_t));
    if (SX_CHECK_FAIL(rc)) {
        if (rc == SX_STATUS_NO_RESOURCES) {
            log_level = SX_LOG_NOTICE;
        } else {
            log_level = SX_LOG_ERROR;
        }
        SX_LOG(log_level, "%s\n", sx_status_str(rc));
    } else {
        *policer_id_p = cmd_body.policer_id;
    }

    SX_API_LOG_EXIT();

    return rc;
}


sx_status_t sx_api_policer_get(const sx_api_handle_t    handle,
                               const sx_policer_id_t    policer_id,
                               sx_policer_attributes_t *policer_attr_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_api_policer_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (policer_attr_p == NULL) {
        SX_LOG_ERR("policer_info_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.policer_id = policer_id;


    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_POLICER_GET_E,
                                     (uint8_t*)&cmd_body,
                                     sizeof(sx_api_policer_set_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(policer_attr_p, &(cmd_body.policer_attr));
    }

    SX_API_LOG_EXIT();

    return rc;
}


sx_status_t sx_api_policer_iter_get(const sx_api_handle_t   handle,
                                    const sx_access_cmd_t   cmd,
                                    const sx_policer_id_t   policer_id_key,
                                    sx_policer_id_filter_t *policer_id_filter_p,
                                    sx_policer_id_t        *policer_id_list_p,
                                    uint32_t               *policer_id_cnt_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_policer_id_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                  reply_head;
    sx_api_policer_id_iter_get_params_t *reply_body = NULL;
    uint32_t                             reply_body_size;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (policer_id_cnt_p == NULL) {
        SX_LOG_ERR("policer_id_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*policer_id_cnt_p == 0) {
            SX_LOG_ERR("policer_id_cnt_p is 0\n");
            policer_id_list_p = NULL;
            goto out;
        }
        if (policer_id_list_p == NULL) {
            SX_LOG_ERR("policer_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*policer_id_cnt_p == 0) {
            policer_id_list_p = NULL;
        } else if (policer_id_list_p == NULL) {
            SX_LOG_ERR("policer_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_policer_id_iter_get_params_t) +
                      (*policer_id_cnt_p * sizeof(sx_policer_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_POLICER_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_policer_id_iter_get_params_t);
    cmd_head.list_size = *policer_id_cnt_p * sizeof(sx_policer_id_t);


    cmd_body.policer_id_key = policer_id_key;
    cmd_body.cmd = cmd;
    cmd_body.policer_id_cnt = *policer_id_cnt_p;
    if (policer_id_filter_p != NULL) {
        cmd_body.policer_id_filter = *policer_id_filter_p;
    }

    *policer_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->policer_id_cnt) {
        *policer_id_cnt_p = reply_body->policer_id_cnt;
        if (policer_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(policer_id_list_p, reply_body->policer_id_list,
                             reply_body->policer_id_cnt, sx_policer_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_policer_counters_get(const sx_api_handle_t  handle,
                                        const sx_policer_id_t  policer_id,
                                        sx_policer_counters_t *policer_counters_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    sx_api_policer_counters_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (policer_counters_p == NULL) {
        SX_LOG_ERR("policer_counters_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.policer_id = policer_id;


    rc =
        sx_api_send_command_wrapper(handle,
                                    SX_API_INT_CMD_POLICER_COUNTERS_GET_E,
                                    (uint8_t*)&cmd_body,
                                    sizeof(sx_api_policer_counters_get_params_t));
    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(policer_counters_p, &(cmd_body.policer_counters));
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_policer_counters_clear_set(const sx_api_handle_t              handle,
                                              const sx_policer_id_t              policer_id,
                                              const sx_policer_counters_clear_t *clear_counters_p)
{
    sx_status_t                                rc = SX_STATUS_SUCCESS;
    sx_api_policer_counters_clear_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (clear_counters_p == NULL) {
        SX_LOG_ERR("counters_clear_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.policer_id = policer_id;
    cmd_body.policer_counters_clear.clear_violation_counter = clear_counters_p->clear_violation_counter;


    rc =
        sx_api_send_command_wrapper(handle,
                                    SX_API_INT_CMD_POLICER_COUNTERS_CLEAR_SET_E,
                                    (uint8_t*)&cmd_body,
                                    sizeof(sx_api_policer_counters_clear_set_params_t));

    SX_API_LOG_EXIT();

    return rc;
}
