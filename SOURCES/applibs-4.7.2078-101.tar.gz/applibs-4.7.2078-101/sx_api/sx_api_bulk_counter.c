/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <sx/sdk/sx_bulk_counter.h>
#include <sx/sdk/sx_api_bulk_counter.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_BULK_COUNTER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define SX_BULK_CNTR_PORT_GRP_BITMAP_FULL         \
    (                                             \
        SX_BULK_CNTR_PORT_GRP_IEEE_802_DOT_3_E |  \
        SX_BULK_CNTR_PORT_GRP_RFC_2863_E |        \
        SX_BULK_CNTR_PORT_GRP_RFC_2819_E |        \
        SX_BULK_CNTR_PORT_GRP_RFC_3635_E |        \
        SX_BULK_CNTR_PORT_GRP_PRIO_E |            \
        SX_BULK_CNTR_PORT_GRP_TC_E |              \
        SX_BULK_CNTR_PORT_GRP_BUFF_E |            \
        SX_BULK_CNTR_PORT_GRP_PERF_E |            \
        SX_BULK_CNTR_PORT_GRP_DISCARD_E |         \
        SX_BULK_CNTR_PORT_GRP_PHY_LAYER_E |       \
        SX_BULK_CNTR_PORT_GRP_PHY_LAYER_STATS_E | \
        SX_BULK_CNTR_PORT_GRP_IB_PACKETS_E |      \
        SX_BULK_CNTR_PORT_GRP_PLR_E |             \
        SX_BULK_CNTR_PORT_GRP_RS_FEC_E |          \
        SX_BULK_CNTR_PORT_GRP_IB_EXT_E |          \
        SX_BULK_CNTR_PORT_GRP_IB_GENERAL_E        \
    )

#define SX_KEY_ARR_SIZE(arr) (sizeof(arr) / sizeof(*(arr)))

static uint32_t hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_COUNT][
    SX_BULK_CNTR_HFT_SAMPLE_PER_INFO_SUBTYPE_COUNT_MAX] = {
    {
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E */
        SX_BULK_CNTR_HFT_SIZE_32         /* SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E */
    },
    {
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_TRANSMIT_OK_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_RECEIVED_OK_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_TRANSMITTED_OK_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_RECEIVED_OK_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_2863_GROUP_IF_IN_DISCARDS_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_RECEIVED_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_TX_OCTETS_E  */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_CONG_ECN_MARKED_E  */
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_WATERMARK_E */
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_CURRENT_OCCUPANCY_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_WATERMARK_E */
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_CURRENT_OCCUPANCY_E */
        SX_BULK_CNTR_HFT_SIZE_64,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_WATERMARK_E */
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_OCCUPANCY_E */
        SX_BULK_CNTR_HFT_SIZE_32,        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_LOW_E */
        SX_BULK_CNTR_HFT_SIZE_32        /* SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_HIGH_E */
    },
    {
        SX_BULK_CNTR_HFT_SIZE_128,       /* SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_0_E */
        SX_BULK_CNTR_HFT_SIZE_128        /* SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_1_E */
    }
};

#ifndef BYTES_IN_MB
#define BYTES_IN_MB (1024 * 1024)
#endif
/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_bulk_counter_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        const sx_verbosity_level_t      module_verbosity_level,
                                                        const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BULK_COUNTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bulk_counter_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        sx_verbosity_level_t           *module_verbosity_level_p,
                                                        sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BULK_COUNTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

int __comp_func(const void * a, const void * b)
{
    return (*(int*)a - *(int*)b);
}

int __comp_flow_counter_func(const void * a, const void * b)
{
    sx_bulk_cntr_hft_sample_flow_counter_config_t *ptr1 = (sx_bulk_cntr_hft_sample_flow_counter_config_t *)a;
    sx_bulk_cntr_hft_sample_flow_counter_config_t *ptr2 = (sx_bulk_cntr_hft_sample_flow_counter_config_t *)b;

    return (ptr1->flow_counter_type - ptr2->flow_counter_type);
}


static sx_status_t __validate_key(const sx_bulk_cntr_buffer_key_t *key_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_bulk_cntr_hft_sample_config_t *hft_sample_cfg_p = NULL;
    uint32_t                          i = 0;

    switch (key_p->type) {
    case SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E:
        if (key_p->key.macsec_port_key.grp_bitmap == 0) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid value of port counter-groups bitmap [0x%x]\n", key_p->key.macsec_port_key.grp_bitmap);
            goto out;
        }
        if ((key_p->key.macsec_port_key.port_list_cnt == 0) ||
            (key_p->key.macsec_port_key.port_list_cnt > SX_KEY_ARR_SIZE(key_p->key.macsec_port_key.port_list))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port list count [%u]\n", key_p->key.macsec_port_key.port_list_cnt);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E:
        if ((key_p->key.macsec_acl_flow_key.port_list_cnt == 0) ||
            (key_p->key.macsec_acl_flow_key.port_list_cnt >
             SX_KEY_ARR_SIZE(key_p->key.macsec_acl_flow_key.port_list))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port list count [%u]\n", key_p->key.macsec_acl_flow_key.port_list_cnt);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_PORT_E:
        if ((key_p->key.port_key.grp_bitmap == 0) ||
            (key_p->key.port_key.grp_bitmap > SX_BULK_CNTR_PORT_GRP_BITMAP_FULL)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid value of port counter-groups bitmap [0x%x]\n", key_p->key.port_key.grp_bitmap);
            goto out;
        }

        if ((key_p->key.port_key.port_list_cnt == 0) ||
            (key_p->key.port_key.port_list_cnt > SX_KEY_ARR_SIZE(key_p->key.port_key.port_list))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port list count [%u]\n", key_p->key.port_key.port_list_cnt);
            goto out;
        }

        if (key_p->key.port_key.grp_bitmap & SX_BULK_CNTR_PORT_GRP_PRIO_E) {
            if ((key_p->key.port_key.prio_id_list_cnt == 0) ||
                (key_p->key.port_key.prio_id_list_cnt > SX_KEY_ARR_SIZE(key_p->key.port_key.prio_id_list))) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid prio_id list count [%u]\n", key_p->key.port_key.prio_id_list_cnt);
                goto out;
            }

            for (i = 0; i < key_p->key.port_key.prio_id_list_cnt; i++) {
                if ((key_p->key.port_key.prio_id_list[i]) > SX_PORT_PRIO_ID_MAX) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Invalid priority ID [%u]\n", key_p->key.port_key.prio_id_list[i]);
                    goto out;
                }
            }
        }

        if (key_p->key.port_key.grp_bitmap & SX_BULK_CNTR_PORT_GRP_TC_E) {
            if ((key_p->key.port_key.tc_id_list_cnt == 0) ||
                (key_p->key.port_key.tc_id_list_cnt > SX_KEY_ARR_SIZE(key_p->key.port_key.tc_id_list))) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid tc_id list count [%u]\n", key_p->key.port_key.tc_id_list_cnt);
                goto out;
            }

            for (i = 0; i < key_p->key.port_key.tc_id_list_cnt; i++) {
                if (!SX_PORT_TC_ID_CHECK_RANGE(key_p->key.port_key.tc_id_list[i])) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Invalid TC ID [%u]\n", key_p->key.port_key.tc_id_list[i]);
                    goto out;
                }
            }
        }

        if (key_p->key.port_key.grp_bitmap & SX_BULK_CNTR_PORT_GRP_BUFF_E) {
            if ((key_p->key.port_key.prio_group_list_cnt == 0) ||
                (key_p->key.port_key.prio_group_list_cnt > SX_KEY_ARR_SIZE(key_p->key.port_key.prio_group_list))) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid prio_group list count [%u]\n", key_p->key.port_key.prio_group_list_cnt);
                goto out;
            }

            for (i = 0; i < key_p->key.port_key.prio_group_list_cnt; i++) {
                if (key_p->key.port_key.prio_group_list[i] >= RM_API_COS_BUFFERS_NUM) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Invalid priority group [%u]\n", key_p->key.port_key.prio_group_list[i]);
                    goto out;
                }
            }
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E:
    case SX_BULK_CNTR_KEY_TYPE_FLOW_E:
    case SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E:
        /* no validation so far on flow counters, estimator counters and macsec SA counters.*/
        break;

    case SX_BULK_CNTR_KEY_TYPE_SHARED_BUFFER_E:
        if ((key_p->key.shared_buffer_key.type != SX_BULK_CNTR_SHARED_BUFFER_CURRENT_E) &&
            (key_p->key.shared_buffer_key.type != SX_BULK_CNTR_SHARED_BUFFER_SNAPSHOT_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid shared buffer key type [%u]\n", key_p->key.shared_buffer_key.type);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_HEADROOM_E:
        if ((key_p->key.headroom_key.port_list_cnt == 0) ||
            (key_p->key.headroom_key.port_list_cnt > SX_KEY_ARR_SIZE(key_p->key.headroom_key.port_list))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port list count [%u]\n", key_p->key.headroom_key.port_list_cnt);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_ELEPHANT_E:
        if ((key_p->key.elephant_key.port_list_cnt == 0) ||
            (key_p->key.elephant_key.port_list_cnt > SX_KEY_ARR_SIZE(key_p->key.elephant_key.port_list))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid elephant key: port_list_cnt list count [%u]\n",
                       key_p->key.elephant_key.port_list_cnt);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E:

        if (key_p->key.stateful_db_key.partition_id > SX_STATEFUL_DB_PARTITION_MAX_E) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid stateful DB key: partition ID [%u]\n",
                       key_p->key.stateful_db_key.partition_id);
            goto out;
        }

        if (key_p->key.stateful_db_key.entries_num_max > STATEFUL_DB_DUMP_NUM_MAX) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid stateful DB key: entries_num_max [%u] exceed max value [%d]\n",
                       key_p->key.stateful_db_key.entries_num_max, STATEFUL_DB_DUMP_NUM_MAX);
            goto out;
        }

        break;

    case SX_BULK_CNTR_KEY_TYPE_HFT_E:
        hft_sample_cfg_p = (sx_bulk_cntr_hft_sample_config_t *)&(key_p->key.hft_key.hft_config);

        if (key_p->key.hft_key.sample_count > SX_BULK_CNTR_HFT_SAMPLE_COUNT_MAX) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Sample count too large [%u], max is [%u]\n",
                       key_p->key.hft_key.sample_count,
                       SX_BULK_CNTR_HFT_SAMPLE_COUNT_MAX);
            goto out;
        }

        if ((key_p->key.hft_key.min_sample_interval != SX_BULK_CNTR_HFT_AFAP_SAMPLING_INTERVAL) &&
            (key_p->key.hft_key.min_sample_interval < SX_BULK_CNTR_HFT_MIN_SAMPLING_INTERVAL)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Inter sample gap too less [%u], min is [%u]\n",
                       key_p->key.hft_key.min_sample_interval, SX_BULK_CNTR_HFT_MIN_SAMPLING_INTERVAL);
            goto out;
        }

        if (key_p->key.hft_key.min_sample_interval > SX_BULK_CNTR_HFT_MAX_SAMPLING_INTERVAL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Inter sample gap too large [%u], max is [%u]\n",
                       key_p->key.hft_key.min_sample_interval, SX_BULK_CNTR_HFT_MAX_SAMPLING_INTERVAL);
            goto out;
        }

        /* when in hft wait mode, total time cannot exceed 30 secs. */
        if (key_p->key.hft_key.sample_count * key_p->key.hft_key.min_sample_interval >
            SX_BULK_CNTR_HFT_TOTAL_SAMPLING_DURATION) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Total sample duration too large [%u], max is [%u]\n",
                       (key_p->key.hft_key.sample_count * key_p->key.hft_key.min_sample_interval),
                       SX_BULK_CNTR_HFT_TOTAL_SAMPLING_DURATION);
            goto out;
        }

        if (hft_sample_cfg_p->port_counter_config.port_counter_list_size >
            SX_BULK_CNTR_HFT_SAMPLE_PORT_COUNTER_COUNT) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port counter list size is too large [%u], max is [%u]\n",
                       (hft_sample_cfg_p->port_counter_config.port_counter_list_size),
                       SX_BULK_CNTR_HFT_SAMPLE_PORT_COUNTER_COUNT);
            goto out;
        }

        if (hft_sample_cfg_p->metadata_config.metadata_list_size > SX_BULK_CNTR_HFT_SAMPLE_METADATA_COUNT) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Metadata list size is too large [%u], max is [%u]\n",
                       (hft_sample_cfg_p->metadata_config.metadata_list_size),
                       SX_BULK_CNTR_HFT_SAMPLE_METADATA_COUNT);
            goto out;
        }

        if (hft_sample_cfg_p->global_counter_config.global_counter_list_size >
            SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_COUNTER_COUNT) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Global counter list size is too large [%u], max is [%u]\n",
                       (hft_sample_cfg_p->global_counter_config.global_counter_list_size),
                       SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_COUNTER_COUNT);
            goto out;
        }

        if (hft_sample_cfg_p->global_counter_config.flow_counter_list_size >
            SX_BULK_CNTR_HFT_SAMPLE_FLOW_COUNTER_COUNT) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Global flow counter list size is too large [%u], max is [%u]\n",
                       (hft_sample_cfg_p->global_counter_config.flow_counter_list_size),
                       SX_BULK_CNTR_HFT_SAMPLE_FLOW_COUNTER_COUNT);
            goto out;
        }

        /* Sort the meta data, port counter list and global counter list. */
        if (hft_sample_cfg_p->port_counter_config.port_counter_list_size > 0) {
            qsort(hft_sample_cfg_p->port_counter_config.port_counter_list,
                  hft_sample_cfg_p->port_counter_config.port_counter_list_size,
                  sizeof(sx_bulk_cntr_hft_sample_port_counter_e),
                  __comp_func);

            for (i = 0; i < hft_sample_cfg_p->port_counter_config.port_counter_list_size - 1; i++) {
                if (hft_sample_cfg_p->port_counter_config.port_counter_list[i] ==
                    hft_sample_cfg_p->port_counter_config.port_counter_list[i + 1]) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Duplicate port counter type[%u]\n",
                               hft_sample_cfg_p->port_counter_config.port_counter_list[i]);
                    goto out;
                }
            }
        }

        if (hft_sample_cfg_p->metadata_config.metadata_list_size > 0) {
            qsort(hft_sample_cfg_p->metadata_config.metadata_list,
                  hft_sample_cfg_p->metadata_config.metadata_list_size,
                  sizeof(sx_bulk_cntr_hft_sample_metadata_e),
                  __comp_func);

            for (i = 0; i < hft_sample_cfg_p->metadata_config.metadata_list_size - 1; i++) {
                if (hft_sample_cfg_p->metadata_config.metadata_list[i] ==
                    hft_sample_cfg_p->metadata_config.metadata_list[i + 1]) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Duplicate meta information type[%u]\n",
                               hft_sample_cfg_p->metadata_config.metadata_list[i]);
                    goto out;
                }
            }
        }

        if (hft_sample_cfg_p->global_counter_config.global_counter_list_size > 0) {
            qsort(hft_sample_cfg_p->global_counter_config.global_counter_list,
                  hft_sample_cfg_p->global_counter_config.global_counter_list_size,
                  sizeof(sx_bulk_cntr_hft_sample_global_counter_e),
                  __comp_func);

            for (i = 0; i < hft_sample_cfg_p->global_counter_config.global_counter_list_size - 1; i++) {
                if (hft_sample_cfg_p->global_counter_config.global_counter_list[i] ==
                    hft_sample_cfg_p->global_counter_config.global_counter_list[i + 1]) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Duplicate global counter type[%u]\n",
                               hft_sample_cfg_p->global_counter_config.global_counter_list[i]);
                    goto out;
                }
            }
        }

        if (hft_sample_cfg_p->global_counter_config.flow_counter_list_size > 0) {
            qsort(hft_sample_cfg_p->global_counter_config.flow_counter_list,
                  hft_sample_cfg_p->global_counter_config.flow_counter_list_size,
                  sizeof(sx_bulk_cntr_hft_sample_flow_counter_config_t),
                  __comp_flow_counter_func);

            for (i = 0; i < hft_sample_cfg_p->global_counter_config.flow_counter_list_size - 1; i++) {
                if (hft_sample_cfg_p->global_counter_config.flow_counter_list[i].flow_counter_type ==
                    hft_sample_cfg_p->global_counter_config.flow_counter_list[i + 1].flow_counter_type) {
                    err = SX_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Duplicate flow counter type [%u]\n",
                               hft_sample_cfg_p->global_counter_config.flow_counter_list[i].flow_counter_type);
                    goto out;
                }
            }
        }

        qsort(hft_sample_cfg_p->port_counter_config.port_list,
              hft_sample_cfg_p->port_counter_config.port_list_size,
              sizeof(sx_port_log_id_t),
              __comp_func);

        if (hft_sample_cfg_p->port_counter_config.port_list_size >
            SX_KEY_ARR_SIZE(hft_sample_cfg_p->port_counter_config.port_list)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port counter list count [%u]\n",
                       hft_sample_cfg_p->port_counter_config.port_list_size);
            goto out;
        }


        if (hft_sample_cfg_p->port_counter_config.prio_id_list_size >
            SX_KEY_ARR_SIZE(hft_sample_cfg_p->port_counter_config.prio_id_list)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid prio_id list count [%u]\n", hft_sample_cfg_p->port_counter_config.prio_id_list_size);
            goto out;
        }

        for (i = 0; i < hft_sample_cfg_p->port_counter_config.prio_id_list_size; i++) {
            if ((hft_sample_cfg_p->port_counter_config.prio_id_list[i]) > SX_PORT_PRIO_ID_MAX) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid priority ID [%u]\n", hft_sample_cfg_p->port_counter_config.prio_id_list[i]);
                goto out;
            }
        }

        if (hft_sample_cfg_p->port_counter_config.tc_id_list_size >
            SX_KEY_ARR_SIZE(key_p->key.port_key.tc_id_list)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid tc_id list count [%u]\n", hft_sample_cfg_p->port_counter_config.tc_id_list_size);
            goto out;
        }

        for (i = 0; i < hft_sample_cfg_p->port_counter_config.tc_id_list_size; i++) {
            if (!SX_PORT_TC_ID_CHECK_RANGE(hft_sample_cfg_p->port_counter_config.tc_id_list[i])) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid TC ID [%u]\n", hft_sample_cfg_p->port_counter_config.tc_id_list[i]);
                goto out;
            }
        }

        if (hft_sample_cfg_p->port_counter_config.pg_id_list_size >
            SX_KEY_ARR_SIZE(hft_sample_cfg_p->port_counter_config.pg_id_list)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid prio_group list count [%u]\n",
                       hft_sample_cfg_p->port_counter_config.pg_id_list_size);
            goto out;
        }

        for (i = 0; i < hft_sample_cfg_p->port_counter_config.pg_id_list_size; i++) {
            if (hft_sample_cfg_p->port_counter_config.pg_id_list[i] >= RM_API_COS_BUFFERS_NUM) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid priority group [%u]\n", hft_sample_cfg_p->port_counter_config.pg_id_list[i]);
                goto out;
            }
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid key type [%u]\n", key_p->type);
        goto out;
    }

out:
    return err;
}
static sx_status_t __get_hft_sample_buffer_size(sx_bulk_cntr_hft_sample_config_t *hft_sample_cfg_p,
                                                uint64_t                         *buff_size_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    uint32_t                                 hft_meta_data_size = 0;
    uint32_t                                 hft_port_counter_size = 0;
    uint32_t                                 hft_global_counter_size = 0;
    uint32_t                                 i = 0;
    sx_bulk_cntr_hft_sample_port_counter_e   port_counter_type;
    sx_bulk_cntr_hft_sample_global_counter_e global_counter_type;
    sx_bulk_cntr_hft_sample_metadata_e       metadata_type;

    for (i = 0; i < hft_sample_cfg_p->metadata_config.metadata_list_size; i++) {
        metadata_type = hft_sample_cfg_p->metadata_config.metadata_list[i];
        switch (metadata_type) {
        case SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E:
        case SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E:
            hft_meta_data_size +=
                hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_METADATA][metadata_type];
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid metadata type [%u]\n", metadata_type);
            goto out;
        }
    }

    for (i = 0; i < hft_sample_cfg_p->global_counter_config.flow_counter_list_size; i++) {
        global_counter_type = hft_sample_cfg_p->global_counter_config.global_counter_list[i];
        switch (global_counter_type) {
        case SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_0_E:
        case SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_1_E:
            hft_global_counter_size +=
                (hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_GLOBAL_COUNTER][global_counter_type] *
                 hft_sample_cfg_p->global_counter_config.flow_counter_list[i].flow_counter_count);
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid global counter type [%u]\n", global_counter_type);
            goto out;
        }
    }

    for (i = 0; i < hft_sample_cfg_p->port_counter_config.port_counter_list_size; i++) {
        port_counter_type = hft_sample_cfg_p->port_counter_config.port_counter_list[i];
        switch (port_counter_type) {
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E:
            /* user can request counter for multiple priority. */
            hft_port_counter_size +=
                (hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_PORT_COUNTER][port_counter_type] *
                 hft_sample_cfg_p->port_counter_config.prio_id_list_size);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_TX_OCTETS_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_CONG_ECN_MARKED_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_WATERMARK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_CURRENT_OCCUPANCY_E:
            /* user can request counter for multiple tc. */
            hft_port_counter_size +=
                (hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_PORT_COUNTER][port_counter_type] *
                 hft_sample_cfg_p->port_counter_config.tc_id_list_size);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_WATERMARK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_CURRENT_OCCUPANCY_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_WATERMARK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_OCCUPANCY_E:
            /* user can request counter for multiple pg. */
            hft_port_counter_size +=
                (hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_PORT_COUNTER][port_counter_type] *
                 hft_sample_cfg_p->port_counter_config.pg_id_list_size);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_TRANSMIT_OK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_RECEIVED_OK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_TRANSMITTED_OK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_RECEIVED_OK_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_2863_GROUP_IF_IN_DISCARDS_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_RECEIVED_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_LOW_E:
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_HIGH_E:
            hft_port_counter_size +=
                hft_entry_size[SX_BULK_CNTR_HFT_SAMPLE_INFO_TYPE_PORT_COUNTER][port_counter_type];
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port counter type [%u]\n", port_counter_type);
            goto out;
        }
    }
    /* Account for multiple port counter information in a sample. */
    hft_port_counter_size *= hft_sample_cfg_p->port_counter_config.port_list_size;
    *buff_size_p = hft_meta_data_size + hft_global_counter_size + hft_port_counter_size;
out:
    return err;
}

static sx_status_t __get_buffer_size_from_key(const sx_bulk_cntr_buffer_key_t *key_p,
                                              uint64_t                        *buff_size_p,
                                              uint32_t                        *num_of_counters_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         port_cnt = 0;
    sx_bulk_cntr_hft_sample_config_t hft_sample_cfg;

    switch (key_p->type) {
    case SX_BULK_CNTR_KEY_TYPE_PORT_E:
        /* The real expected number of counters for port will be calculated/updated
         * when the transaction is started by user.
         */
        *num_of_counters_p = key_p->key.port_key.port_list_cnt;
        *buff_size_p = sizeof(sxd_bulk_cntr_buffer_layout_port_t) +
                       (key_p->key.port_key.port_list_cnt) * sizeof(sxd_port_cntr_composition_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_FLOW_E:
        *num_of_counters_p = key_p->key.flow_key.num_of_counters;
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_flow) +
                       (*num_of_counters_p) * sizeof(sx_flow_counter_set_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_SHARED_BUFFER_E:
        *num_of_counters_p = 0xFFFFFFFF;        /* Will be updated in transaction set */
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_shared_buffer);
        break;

    case SX_BULK_CNTR_KEY_TYPE_HEADROOM_E:
        *num_of_counters_p = key_p->key.headroom_key.port_list_cnt;     /* Will be updated in transaction set */
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_headroom);
        break;

    case SX_BULK_CNTR_KEY_TYPE_ELEPHANT_E:
        *num_of_counters_p = 0;
        port_cnt = key_p->key.elephant_key.port_list_cnt;
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_elephant) +
                       SXD_COS_ELEPHANT_FLOW_ID_NUM_MAX * port_cnt * sizeof(sx_cos_elephant_flow_data_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E:
        *num_of_counters_p = key_p->key.stateful_db_key.entries_num_max;
        *buff_size_p = sizeof(sxd_bulk_cntr_buffer_layout_stateful_db_t) +
                       key_p->key.stateful_db_key.entries_num_max * sizeof(sx_stateful_db_entry_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E:
        *num_of_counters_p = key_p->key.flow_estimator_key.num_of_counters;
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_flow_estimator) +
                       (*num_of_counters_p) * sizeof(sx_flow_estimator_counter_set_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E:
        *num_of_counters_p = key_p->key.macsec_port_key.port_list_cnt;
        *buff_size_p = sizeof(sxd_bulk_cntr_buffer_layout_macsec_port_t) +
                       (*num_of_counters_p) * sizeof(sxd_macsec_port_cntr_composition_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E:
        *num_of_counters_p = key_p->key.macsec_acl_flow_key.port_list_cnt; /* number of reg tlvs expected */
        *buff_size_p = sizeof(struct sx_bulk_cntr_buffer_key_macsec_acl_flow) +
                       (*num_of_counters_p) * key_p->key.macsec_acl_flow_key.num_of_counters *
                       sizeof(sxd_macsec_acl_counter_set_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E:
        *num_of_counters_p = key_p->key.macsec_sa_key.num_of_counters;
        *buff_size_p = sizeof(struct sxd_bulk_cntr_buffer_layout_macsec_sa) +
                       (*num_of_counters_p) * sizeof(sxd_macsec_cntr_sa_stats_t);
        break;

    case SX_BULK_CNTR_KEY_TYPE_HFT_E:
        hft_sample_cfg = key_p->key.hft_key.hft_config;
        err = __get_hft_sample_buffer_size(&hft_sample_cfg, buff_size_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve HFT size with given key and params, err(%s)\n",
                       sx_status_str(err));
            goto out;
        }
        *buff_size_p = (*buff_size_p * key_p->key.hft_key.sample_count);
        /* Add space for meta information. */
        *buff_size_p += sizeof(struct sxd_bulk_cntr_buffer_layout_hft);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid key type [%u]\n", key_p->type);
        goto out;
        break;
    }

out:
    return err;
}


static void __fill_metadata(const sx_bulk_cntr_buffer_key_t *key_p,
                            void                            *buff,
                            uint32_t                         buff_size,
                            uint32_t                         num_of_counters,
                            sx_bulk_cntr_buffer_t           *buffer_p)
{
    sxd_bulk_cntr_buffer_layout_common_t          *layout_common;
    sxd_bulk_cntr_buffer_layout_port_t            *layout_port;
    sxd_bulk_cntr_buffer_layout_macsec_port_t     *layout_macsec_port;
    sxd_bulk_cntr_buffer_layout_macsec_acl_flow_t *layout_macsec_acl_flow;
    sxd_bulk_cntr_buffer_layout_macsec_sa_t       *layout_macsec_sa;

    layout_common = (sxd_bulk_cntr_buffer_layout_common_t*)buff;
    layout_common->type = key_p->type;
    layout_common->buff_size = buff_size;
    layout_common->num_of_counters = num_of_counters;
    layout_common->counters_received_so_far = 0;
    layout_common->cookie = buffer_p->cookie;

    switch (key_p->type) {
    case SX_BULK_CNTR_KEY_TYPE_PORT_E:
        layout_port = (sxd_bulk_cntr_buffer_layout_port_t*)buff;
        layout_port->counters_size = key_p->key.port_key.port_list_cnt;
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E:
        layout_macsec_port = (sxd_bulk_cntr_buffer_layout_macsec_port_t*)buff;
        layout_macsec_port->counters_size = key_p->key.macsec_port_key.port_list_cnt;
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E:
        layout_macsec_acl_flow = (sxd_bulk_cntr_buffer_layout_macsec_acl_flow_t*)buff;
        /* Actual number of counters held in shared memory. */
        layout_macsec_acl_flow->number_of_counters =
            key_p->key.macsec_acl_flow_key.port_list_cnt * key_p->key.macsec_acl_flow_key.num_of_counters;
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E:
        layout_macsec_sa = (sxd_bulk_cntr_buffer_layout_macsec_sa_t*)buff;
        /* Actual number of counters held in shared memory. */
        layout_macsec_sa->number_of_counters = key_p->key.macsec_sa_key.num_of_counters;
        break;

    default:
        break;
    }
}

static sx_status_t __validate_buffer_availability(const sx_api_handle_t handle,
                                                  uint64_t              size,
                                                  boolean_t            *is_mem_available)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sxd_ctrl_pack_t                 ctrl_pack;
    const sx_api_user_ctxt_t       *user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    struct ku_bulk_cntr_buffer_info buffer_info;
    sxd_status_t                    sxd_err = SXD_STATUS_SUCCESS;

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR(buffer_info);


    ctrl_pack.ctrl_cmd = CTRL_CMD_BULK_CNTR_BUFFER_INFO_GET;
    ctrl_pack.cmd_body = &buffer_info;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_BULK_CNTR_BUFFER_INFO_GET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* when buffer limit is not unlimited, impose buffer allocation limits. */
    if ((buffer_info.max_size != 0) &&
        (buffer_info.current_utilization + size > (((uint64_t)buffer_info.max_size) * BYTES_IN_MB))) {
        SX_LOG_NTC(
            "Insufficient buffer for bulk transaction current utilization=%f MB,  max=%u MB, required =%lu bytes\n",
            ((float)buffer_info.current_utilization / BYTES_IN_MB),
            buffer_info.max_size,
            size);
        *is_mem_available = FALSE;
    } else {
        *is_mem_available = TRUE;
    }

out:
    return err;
}

static sx_status_t __update_buffer_utilization(const sx_api_handle_t handle,
                                               uint64_t              size,
                                               boolean_t             is_alloc,
                                               unsigned long         buffer_id)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    struct ku_client_pid_get         client_pid;
    sxd_ctrl_pack_t                  ctrl_pack;
    const sx_api_user_ctxt_t        *user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    struct ku_bulk_cntr_buffer_stats buffer_stats;
    sxd_status_t                     sxd_err = SXD_STATUS_SUCCESS;

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR(buffer_stats);

    ctrl_pack.ctrl_cmd = CTRL_CMD_CLIENT_PID_GET;
    ctrl_pack.cmd_body = &client_pid;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_CLIENT_PID_GET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    buffer_stats.is_allocated = is_alloc;
    buffer_stats.size = size;
    buffer_stats.user_ptr = buffer_id;
    buffer_stats.pid = client_pid.pid;
    ctrl_pack.ctrl_cmd = CTRL_CMD_BULK_CNTR_BUFFER_STATS_SET;
    ctrl_pack.cmd_body = &buffer_stats;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_BULK_CNTR_BUFFER_INFO_SET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    return err;
}

sx_status_t sx_api_bulk_counter_buffer_set(const sx_api_handle_t            handle,
                                           const sx_access_cmd_t            cmd,
                                           const sx_bulk_cntr_buffer_key_t *key_p,
                                           sx_bulk_cntr_buffer_t           *buffer_p)
{
    const sx_api_user_ctxt_t * user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    sx_status_t                err = SX_STATUS_SUCCESS;
    sxd_status_t               sxd_err = SXD_STATUS_SUCCESS;
    uint64_t                   buff_size = 0;
    uint32_t                   num_of_counters = 0;
    void                      *buff = NULL;
    boolean_t                  is_mem_available = FALSE;

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        err = utils_check_pointer(key_p, "key");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        err = utils_check_pointer(buffer_p, "buffer");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        /* validate user key */
        err = __validate_key(key_p);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        /* calculate required buffer size and number of counters for user key */
        err = __get_buffer_size_from_key(key_p, &buff_size, &num_of_counters);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        /* Buffer limits are imposed only on high frequency telemetry buffers. */
        if (key_p->type == SX_BULK_CNTR_KEY_TYPE_HFT_E) {
            err = __validate_buffer_availability(handle, buff_size, &is_mem_available);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }

            if (is_mem_available == FALSE) {
                err = SX_STATUS_ERROR;
                SX_LOG_ERR("Bulk buffer size=[%lu] bytes not available.\n", buff_size);
                goto out;
            }
        }

        /* create a shared memory between driver and user process */
        sxd_err = sxd_memory_map(user_ctx->dev, buff_size, &buff);
        if (sxd_err) {
            err = sxd_status_to_sx_status(sxd_err);
            goto out;
        }

        /* Buffer accounting is done only for high frequency telemetry buffer. */
        if (key_p->type == SX_BULK_CNTR_KEY_TYPE_HFT_E) {
            err = __update_buffer_utilization(handle, buff_size, TRUE, (unsigned long)buff);
            if (SX_CHECK_FAIL(err)) {
                sxd_err = sxd_memory_unmap((void*)buff, buff_size);
                goto out;
            }
        }

        /* fill meta-data in shared memory for buffer management in driver */
        __fill_metadata(key_p, buff, buff_size, num_of_counters, buffer_p);

        buffer_p->buffer_id = (unsigned long)buff;     /* user's mmap() pointer */
        buffer_p->buffer_size = buff_size;     /* shared memory size */
        SX_MEM_CPY(buffer_p->key, *key_p);
        if (buffer_p->key.type == SX_BULK_CNTR_KEY_TYPE_ELEPHANT_E) {
            qsort(buffer_p->key.key.elephant_key.port_list, buffer_p->key.key.elephant_key.port_list_cnt,
                  sizeof(sx_port_log_id_t), __comp_func);
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = utils_check_pointer(buffer_p, "buffer");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        /* deallocate shared memory with driver */
        sxd_err = sxd_memory_unmap((void*)buffer_p->buffer_id, buffer_p->buffer_size);
        err = sxd_status_to_sx_status(sxd_err);

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bulk_counter_transaction_set(const sx_api_handle_t        handle,
                                                const sx_access_cmd_t        cmd,
                                                const sx_bulk_cntr_buffer_t *buffer_p)
{
    sx_api_bulk_counter_transaction_set_params_t cmd_body;
    struct ku_client_pid_get                     client_pid;
    sxd_ctrl_pack_t                              ctrl_pack;
    const sx_api_user_ctxt_t                    *user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sxd_status_t                                 sxd_err = SXD_STATUS_SUCCESS;

    UNUSED_PARAM(handle);

    SX_API_LOG_ENTER();

    err = utils_check_pointer(buffer_p, "buffer");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        break;

    case SX_ACCESS_CMD_READ_FLUSH:
    case SX_ACCESS_CMD_READ_CLEAR_FLUSH:
        if (buffer_p->key.type != SX_BULK_CNTR_KEY_TYPE_FLOW_E) {
            err = SX_STATUS_CMD_UNSUPPORTED;
            SX_LOG_ERR("Access command: [%s] only supported for flow counter type.\n", sx_access_cmd_str(cmd));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DISABLE:
        break;

    case SX_ACCESS_CMD_CLEAR:
    case SX_ACCESS_CMD_READ_NEXT:
    case SX_ACCESS_CMD_READ_CLEAR_NEXT:
        if (buffer_p->key.type != SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E) {
            err = SX_STATUS_CMD_UNSUPPORTED;
            SX_LOG_ERR("Access command: [%s] only supported for stateful DB type.\n", sx_access_cmd_str(cmd));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    err = __validate_key(&(buffer_p->key));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /*
     * 1. When client calls sxd_memory_map to create shared memory between kernel and application,
     *    the kernel mmap implementation is using current->pid, which is the real PID of the client
     *    process, no matter the client process is inside a docker container or on a host.
     * 2. Inside a docker container, the getpid system call returns PID from the docker
     *    PID name space, but not the real PID. Here we call this IOCTL command to get the real PID
     *    from kernel, so as to locate the shared memory. This works for both docker and non-docker
     *    scenarios.
     */
    ctrl_pack.ctrl_cmd = CTRL_CMD_CLIENT_PID_GET;
    ctrl_pack.cmd_body = &client_pid;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_CLIENT_PID_GET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.buffer_id = buffer_p->buffer_id;
    cmd_body.client_pid = client_pid.pid;
    SX_MEM_CPY(cmd_body.key, buffer_p->key);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_BULK_COUNTER_TRANSACTION_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_bulk_counter_transaction_set_params_t));

out:
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __bulk_counter_shared_buffer_get(const struct sxd_bulk_cntr_buffer_layout_common *layout_common_p,
                                                    const sx_bulk_cntr_read_key_t                   *key_p,
                                                    sx_bulk_cntr_data_t                             *counter_data_p)
{
    sx_status_t                                             err = SX_STATUS_SUCCESS;
    uint16_t                                                local_port = 0;
    const struct sxd_bulk_cntr_buffer_layout_shared_buffer *layout_shared_buffer_p =
        (struct sxd_bulk_cntr_buffer_layout_shared_buffer*)layout_common_p;

    if ((key_p->key.shared_buffer_key.type == SX_BULK_CNTR_SHARED_BUFFER_PORT_ATTR_E) ||
        (key_p->key.shared_buffer_key.type == SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_PORT_ATTR_E)) {
        local_port = SX_PORT_PHY_ID_GET(key_p->key.shared_buffer_key.attr.log_port);
        if ((local_port < SXD_BULK_CNTR_PHY_PORT_MIN) || (local_port > SXD_BULK_CNTR_PORT_NUM)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Port 0x%x is out of range\n", key_p->key.shared_buffer_key.attr.log_port);
            goto out;
        }

        if (SX_BITMAP_ARR_BIT_GET(layout_shared_buffer_p->port_mask, local_port - 1) == 0) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%x is not valid\n", key_p->key.shared_buffer_key.attr.log_port);
            goto out;
        }
    }

    switch (key_p->key.shared_buffer_key.type) {
    case SX_BULK_CNTR_SHARED_BUFFER_PORT_ATTR_E:
        counter_data_p->data.shared_buffer_counters.port_p =
            (const sx_bulk_cntr_shared_buffer_port_t*)&layout_shared_buffer_p->port[local_port - 1];
        break;

    case SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_ATTR_E:
        counter_data_p->data.shared_buffer_counters.mc_switch_prio_p =
            (const sx_bulk_cntr_shared_buffer_mc_switch_prio_t*)&(layout_shared_buffer_p->mc_switch_prio);
        break;

    case SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_PORT_ATTR_E:
        counter_data_p->data.shared_buffer_counters.mc_port_p =
            (const sx_bulk_cntr_shared_buffer_mc_port_t*)
            &layout_shared_buffer_p->mc_port[local_port - 1];
        break;

    case SX_BULK_CNTR_SHARED_BUFFER_POOL_ATTR_E:
        counter_data_p->data.shared_buffer_counters.pool_p =
            (const sx_bulk_cntr_shared_buffer_pool_t*)&(layout_shared_buffer_p->pool);
        break;

    default:
        break;
    }

out:
    return err;
}

static sx_status_t __bulk_counter_port_get(const sx_bulk_cntr_read_key_t *key_p,
                                           const sx_bulk_cntr_buffer_t   *buffer_p,
                                           sx_bulk_cntr_data_t           *counter_data_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_port_type_t                      port_type;
    uint16_t                            local_port;
    sx_lag_id_t                         lag_id;
    sxd_bulk_cntr_buffer_layout_port_t *layout_port;
    uint16_t                            cntr_index;

    layout_port = (sxd_bulk_cntr_buffer_layout_port_t*)(buffer_p->buffer_id);
    port_type = SX_PORT_TYPE_ID_GET(key_p->key.port_key.log_port);
    switch (port_type) {
    case SX_PORT_TYPE_NETWORK:
        local_port = SX_PORT_PHY_ID_GET(key_p->key.port_key.log_port);
        /* The valid range for local port is [1-MAX_PHYPORT_NUM] */
        if ((local_port < SXD_BULK_CNTR_PHY_PORT_MIN) || (local_port > MAX_PHYPORT_NUM)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%08X invalid (local port %u is out of range)\n",
                       key_p->key.port_key.log_port,
                       local_port);
            goto out;
        }
        cntr_index = layout_port->mappings.port_index_map[local_port];
        if (cntr_index >= layout_port->counters_size) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%08X of the read key doesn't exist in the buffer key\n", key_p->key.port_key.log_port);
            goto out;
        }
        break;

    case SX_PORT_TYPE_LAG:
        lag_id = SX_PORT_LAG_ID_GET(key_p->key.port_key.log_port);
        /* The valid range for lag ID is [0-MAX_LAG_NUM) */
        if (lag_id >= MAX_LAG_NUM) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("LAG 0x%08X invalid (LAG ID %u is out of range)\n", key_p->key.port_key.log_port, lag_id);
            goto out;
        }
        cntr_index = layout_port->mappings.lag_index_map[lag_id];
        if (cntr_index >= layout_port->counters_size) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("LAG 0x%08X of the read key doesn't exist in the buffer key\n", key_p->key.port_key.log_port);
            goto out;
        }
        break;


    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port 0x%08X invalid (port type %s is unsupported)\n",
                   key_p->key.port_key.log_port, sx_port_type_str(port_type));
        goto out;
    }

    if (!(key_p->key.port_key.grp & layout_port->mappings.counter_set_bitmap)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Port counter group [%u] of the read key is not set in the port counter group bitmap [%u] of the buffer key\n",
            key_p->key.port_key.grp,
            buffer_p->key.key.port_key.grp_bitmap);
        goto out;
    }

    switch (key_p->key.port_key.grp) {
    case SX_BULK_CNTR_PORT_GRP_IEEE_802_DOT_3_E:
        counter_data_p->data.port_counters.port_cntr_ieee_802_p =
            (const sx_port_cntr_ieee_802_dot_3_t*)&(layout_port->counters[cntr_index].ieee_802_dot_3);
        break;

    case SX_BULK_CNTR_PORT_GRP_RFC_2863_E:
        counter_data_p->data.port_counters.port_cntr_rfc_2863_p =
            (const sx_port_cntr_rfc_2863_t*)&(layout_port->counters[cntr_index].rfc_2863);
        break;

    case SX_BULK_CNTR_PORT_GRP_RFC_2819_E:
        counter_data_p->data.port_counters.port_cntr_rfc_2819_p =
            (const sx_port_cntr_rfc_2819_t*)&(layout_port->counters[cntr_index].rfc_2819);
        break;

    case SX_BULK_CNTR_PORT_GRP_RFC_3635_E:
        counter_data_p->data.port_counters.port_cntr_rfc_3635_p =
            (const sx_port_cntr_rfc_3635_t*)&(layout_port->counters[cntr_index].rfc_3635);
        break;

    case SX_BULK_CNTR_PORT_GRP_PRIO_E:
        if ((key_p->key.port_key.grp_ex_param.prio_id) > SX_PORT_PRIO_ID_MAX) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid priority ID [%u]\n", key_p->key.port_key.grp_ex_param.prio_id);
            goto out;
        }

        if (!SXD_BULK_CNTR_PORT_BITMAP_GET_PRIO(layout_port->mappings.counter_set_bitmap,
                                                key_p->key.port_key.grp_ex_param.prio_id)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Priority ID [%u] of the read key doesn't exist in the buffer key\n",
                       key_p->key.port_key.grp_ex_param.prio_id);
            goto out;
        }

        counter_data_p->data.port_counters.port_cntr_prio_p =
            (const sx_port_cntr_prio_t*)&(layout_port->counters[cntr_index].prio[key_p->key.port_key.grp_ex_param.
                                                                                 prio_id]);
        break;

    case SX_BULK_CNTR_PORT_GRP_TC_E:
        if (!SX_PORT_TC_ID_CHECK_RANGE(key_p->key.port_key.grp_ex_param.tc_id)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid TC ID [%u]\n", key_p->key.port_key.grp_ex_param.tc_id);
            goto out;
        }

        if (!SXD_BULK_CNTR_PORT_BITMAP_GET_TC(layout_port->mappings.counter_set_bitmap,
                                              key_p->key.port_key.grp_ex_param.tc_id)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("TC ID [%u] of the read key doesn't exist in the buffer key\n",
                       key_p->key.port_key.grp_ex_param.tc_id);
            goto out;
        }

        counter_data_p->data.port_counters.port_cntr_tc_p =
            (const sx_port_traffic_cntr_t*)&(layout_port->counters[cntr_index].tc[key_p->key.port_key.grp_ex_param.
                                                                                  tc_id]);
        break;

    case SX_BULK_CNTR_PORT_GRP_BUFF_E:
        if (key_p->key.port_key.grp_ex_param.prio_group >= RM_API_COS_BUFFERS_NUM) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid priority group [%u]\n", key_p->key.port_key.grp_ex_param.prio_group);
            goto out;
        }

        if (!SXD_BULK_CNTR_PORT_BITMAP_GET_PG(layout_port->mappings.counter_set_bitmap,
                                              key_p->key.port_key.grp_ex_param.prio_group)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Priority group [%u] of the read key doesn't exist in the buffer key\n",
                       key_p->key.port_key.grp_ex_param.prio_group);
            goto out;
        }

        counter_data_p->data.port_counters.port_cntr_buff_p =
            (const sx_port_cntr_buff_t*)&(layout_port->counters[cntr_index].pg[key_p->key.port_key.grp_ex_param.
                                                                               prio_group]);
        break;

    case SX_BULK_CNTR_PORT_GRP_PERF_E:
        counter_data_p->data.port_counters.port_cntr_perf_p =
            (const sx_port_cntr_perf_t*)&(layout_port->counters[cntr_index].perf);
        break;

    case SX_BULK_CNTR_PORT_GRP_DISCARD_E:
        counter_data_p->data.port_counters.port_cntr_discard_p =
            (const sx_port_cntr_discard_t*)&(layout_port->counters[cntr_index].discard);
        break;

    case SX_BULK_CNTR_PORT_GRP_PHY_LAYER_E:
        counter_data_p->data.port_counters.port_cntr_phy_p =
            (const sx_port_cntr_phy_layer_t*)&(layout_port->counters[cntr_index].phy_layer);
        break;

    case SX_BULK_CNTR_PORT_GRP_PHY_LAYER_STATS_E:
        counter_data_p->data.port_counters.port_cntr_phy_stats_p =
            (const sx_port_cntr_phy_layer_statistics_t*)&(layout_port->counters[cntr_index].phy_layer_stats);
        break;

    case SX_BULK_CNTR_PORT_GRP_IB_PACKETS_E:
        counter_data_p->data.port_counters.port_cntr_ib_packets_counters_p =
            (const sx_port_cntr_ib_packets_counters_t*)&(layout_port->counters[cntr_index].infiniband_packets);
        break;

    case SX_BULK_CNTR_PORT_GRP_PLR_E:
        counter_data_p->data.port_counters.port_cntr_plr_p =
            (const sx_port_cntr_plr_t*)&(layout_port->counters[cntr_index].plr);
        break;

    case SX_BULK_CNTR_PORT_GRP_RS_FEC_E:
        counter_data_p->data.port_counters.port_cntr_rs_fec_p =
            (const sx_port_cntr_rs_fec_t*)&(layout_port->counters[cntr_index].rs_fec);
        break;

    case SX_BULK_CNTR_PORT_GRP_IB_EXT_E:
        counter_data_p->data.port_counters.port_cntr_ib_ext_p =
            (const sx_port_cntr_ib_ext_t*)&(layout_port->counters[cntr_index].ib_ext);
        break;

    case SX_BULK_CNTR_PORT_GRP_IB_GENERAL_E:
        counter_data_p->data.port_counters.port_cntr_ib_general_p =
            (const sx_port_cntr_ib_general_t*)&(layout_port->counters[cntr_index].ib_general);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid port counter group [%u]\n", key_p->key.port_key.grp);
        goto out;
    }

out:
    return err;
}

static sx_status_t __bulk_counter_macsec_port_get(const sx_bulk_cntr_read_key_t *key_p,
                                                  const sx_bulk_cntr_buffer_t   *buffer_p,
                                                  sx_bulk_cntr_data_t           *counter_data_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_port_type_t                             port_type;
    uint16_t                                   local_port;
    sxd_bulk_cntr_buffer_layout_macsec_port_t *layout_macsec_port;
    uint16_t                                   cntr_index;

    layout_macsec_port = (sxd_bulk_cntr_buffer_layout_macsec_port_t*)(buffer_p->buffer_id);
    port_type = SX_PORT_TYPE_ID_GET(key_p->key.macsec_port_key.log_port);
    switch (port_type) {
    case SX_PORT_TYPE_NETWORK:
        local_port = SX_PORT_PHY_ID_GET(key_p->key.macsec_port_key.log_port);
        /* The valid range for local port is [1-MAX_PHYPORT_NUM] */
        if ((local_port < SXD_BULK_CNTR_PHY_PORT_MIN) || (local_port > MAX_PHYPORT_NUM)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%08X invalid (local port %u is out of range)\n",
                       key_p->key.macsec_port_key.log_port,
                       local_port);
            goto out;
        }
        cntr_index = layout_macsec_port->mappings.port_index_map[local_port];
        if (cntr_index >= layout_macsec_port->counters_size) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%08X of the read key doesn't exist in the buffer key\n",
                       key_p->key.macsec_port_key.log_port);
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port 0x%08X invalid (port type %s is unsupported)\n",
                   key_p->key.macsec_port_key.log_port, sx_port_type_str(port_type));
        goto out;
    }

    if (!(key_p->key.macsec_port_key.type & buffer_p->key.key.macsec_port_key.grp_bitmap)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Port counter group [%u] of the read key is not set in the port counter group bitmap [%u] of the buffer key\n",
            key_p->key.macsec_port_key.type,
            buffer_p->key.key.macsec_port_key.grp_bitmap);
        goto out;
    }

    switch (key_p->key.macsec_port_key.type) {
    case SX_BULK_CNTR_MACSEC_PORT_GRP_0:
        counter_data_p->data.macsec_port_counters.port_stats_grp0_p =
            (const sx_macsec_cntr_port_group0_stats_t*)&(layout_macsec_port->counters[cntr_index].port_group0_stats);
        break;

    case SX_BULK_CNTR_MACSEC_PORT_GRP_1:
        counter_data_p->data.macsec_port_counters.port_stats_grp1_p =
            (const sx_macsec_cntr_port_group1_stats_t*)&(layout_macsec_port->counters[cntr_index].port_group1_stats);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid port counter group [%u]\n", key_p->key.macsec_port_key.type);
        goto out;
    }

out:
    return err;
}
static sx_status_t __elephant_key_port_index_get(const sx_port_log_id_t *port_list_p,
                                                 const uint32_t          port_list_cnt,
                                                 const sx_port_log_id_t  log_port,
                                                 uint32_t               *idx_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_port_log_id_t *log_port_p = NULL;

    log_port_p = (sx_port_log_id_t*)bsearch(&log_port,
                                            port_list_p,
                                            port_list_cnt,
                                            sizeof(sx_port_log_id_t),
                                            __comp_func);
    if (log_port_p == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    } else {
        *idx_p = log_port_p - port_list_p;
    }

    return err;
}

static sx_status_t __fill_hft_metadata(const sxd_bulk_cntr_buffer_layout_hft_t           *layout_hft,
                                       const sx_bulk_cntr_hft_read_key_sample_metadata_t *metadata_key_p,
                                       const sx_bulk_cntr_buffer_t                       *buffer_p,
                                       sx_bulk_cntr_data_t                               *counter_data_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_bulk_cntr_hft_sample_config_t hft_sample_cfg;
    uint32_t                         sample_idx;
    uint32_t                         sample_offset;
    uint32_t                         idx;

    SX_MEM_CLR(counter_data_p->data);

    hft_sample_cfg = buffer_p->key.key.hft_key.hft_config;
    sample_idx = metadata_key_p->sample_key.sample_iteration;
    if (sample_idx < 1) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid sample index [%d] given for meta information retrieval\n", sample_idx);
        goto out;
    }
    sample_offset = (sample_idx - 1) * layout_hft->sample_buffer_size;
    for (idx = 0; idx < hft_sample_cfg.metadata_config.metadata_list_size; idx++) {
        switch (hft_sample_cfg.metadata_config.metadata_list[idx]) {
        case SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_SECS_E:
            counter_data_p->data.hft_data.meta_data_info.start_ts_secs_p =
                (sx_hft_ts_32_t *)(&layout_hft->buffer[0] +
                                   sample_offset + layout_hft->metadata_map.start_ts_secs_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_METADATA_TIME_STAMP_NANO_SECS_E:
            counter_data_p->data.hft_data.meta_data_info.start_ts_nsecs_p =
                (sx_hft_ts_32_t *)(&layout_hft->buffer[0] +
                                   sample_offset + layout_hft->metadata_map.start_ts_nsecs_offset);
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid meta information type given, param[%d]\n",
                       hft_sample_cfg.metadata_config.metadata_list[idx]);
            goto out;
            break;
        }
    }

out:
    return err;
}

static sx_status_t __fill_hft_port_counters(const sxd_bulk_cntr_buffer_layout_hft_t               *layout_hft,
                                            const sx_bulk_cntr_hft_read_key_sample_port_counter_t *port_counter_key_p,
                                            const sx_bulk_cntr_buffer_t                           *buffer_p,
                                            sx_bulk_cntr_data_t                                   *counter_data_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         sample_idx = 0;
    sx_bulk_cntr_hft_sample_config_t hft_sample_cfg;
    uint32_t                         sample_offset, port_list_counter_offset = 0;
    uint32_t                         idx;
    uint16_t                         local_port;
    uint16_t                         cntr_index;

    SX_MEM_CLR(counter_data_p->data);

    hft_sample_cfg = buffer_p->key.key.hft_key.hft_config;
    sample_idx = port_counter_key_p->sample_key.sample_iteration;
    if (sample_idx < 1) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid sample index [%d] given for port counter retrieval\n", sample_idx);
        goto out;
    }
    sample_offset = (sample_idx - 1) * layout_hft->sample_buffer_size;

    /* check if the given port in key is valid. */
    local_port = SX_PORT_PHY_ID_GET(port_counter_key_p->port);
    if ((local_port < SXD_BULK_CNTR_PHY_PORT_MIN) || (local_port > MAX_PHYPORT_NUM)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port 0x%08X invalid (local port %u is out of range)\n",
                   port_counter_key_p->port,
                   local_port);
        goto out;
    }

    if (layout_hft->port_map.port_index_map[local_port] == 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to retrieve HFT config params with given port 0x%08X, err(%s)\n",
                   port_counter_key_p->port, sx_status_str(err));
        goto out;
    }

    cntr_index = layout_hft->port_map.port_index_map[local_port] - 1;
    /* port is stored after metadata in HFT sample layout . */
    port_list_counter_offset = layout_hft->metadata_map.metadata_buffer_size;
    /* position cursor to the respective port counter buffer. */
    port_list_counter_offset += (cntr_index * layout_hft->port_map.port_counter_buffer_size);

    for (idx = 0; idx < hft_sample_cfg.port_counter_config.port_counter_list_size; idx++) {
        switch (hft_sample_cfg.port_counter_config.port_counter_list[idx]) {
        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_TRANSMIT_OK_E:
            counter_data_p->data.hft_data.port_cntr_info.if_out_octets_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.if_out_octets_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_BYTE_RECEIVED_OK_E:
            counter_data_p->data.hft_data.port_cntr_info.if_in_octets_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.if_in_octets_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_TRANSMITTED_OK_E:
            counter_data_p->data.hft_data.port_cntr_info.a_frames_transmitted_ok_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset +
                                         layout_hft->port_map.a_frames_transmitted_ok_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PACKET_RECEIVED_OK_E:
            counter_data_p->data.hft_data.port_cntr_info.a_frames_received_ok_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.a_frames_received_ok_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_2863_GROUP_IF_IN_DISCARDS_E:
            counter_data_p->data.hft_data.port_cntr_info.if_in_discards_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.if_in_discards_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED_E:
            counter_data_p->data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_transmitted_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset +
                                         layout_hft->port_map.a_pause_mac_ctrl_frames_transmitted_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_RFC_802_3_GROUP_PAUSE_MAC_CTRL_FRAMES_RECEIVED_E:
            counter_data_p->data.hft_data.port_cntr_info.a_pause_mac_ctrl_frames_received_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset +
                                         layout_hft->port_map.a_pause_mac_ctrl_frames_received_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_TX_PAUSE_E:
            counter_data_p->data.hft_data.port_cntr_info.tx_pause_per_prio_list_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset +
                                         layout_hft->port_map.tx_pause_per_prio_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_PAUSE_E:
            counter_data_p->data.hft_data.port_cntr_info.rx_pause_per_prio_list_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset +
                                         layout_hft->port_map.rx_pause_per_prio_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_PRIO_GROUP_RX_OCTETS_E:
            counter_data_p->data.hft_data.port_cntr_info.rx_octets_list_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.rx_octets_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_TX_OCTETS_E:
            counter_data_p->data.hft_data.port_cntr_info.tx_octets_list_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.tx_octets_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_PER_TRAFFIC_CLASS_CONG_ECN_MARKED_E:
            counter_data_p->data.hft_data.port_cntr_info.ecn_marked_tc_list_p =
                (sx_hft_port_ctr_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.ecn_marked_tc_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_WATERMARK_E:
            counter_data_p->data.hft_data.port_cntr_info.headroom_watermark_list_p =
                (sx_hft_buffer_unit_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset +
                                            layout_hft->port_map.headroom_watermark_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_BUFFER_CURRENT_OCCUPANCY_E:
            counter_data_p->data.hft_data.port_cntr_info.headroom_curr_occupancy_list_p =
                (sx_hft_buffer_unit_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset +
                                            layout_hft->port_map.headroom_curr_occupancy_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_WATERMARK_E:
            counter_data_p->data.hft_data.port_cntr_info.tc_watermark_list_p =
                (sx_hft_buffer_unit_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset + layout_hft->port_map.tc_watermark_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_EGRESS_PORT_TRAFFIC_CLASS_BUFFER_CURRENT_OCCUPANCY_E:
            counter_data_p->data.hft_data.port_cntr_info.tc_curr_occupancy_list_p =
                (sx_hft_buffer_unit_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset +
                                            layout_hft->port_map.tc_curr_occupancy_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_WATERMARK_E:
            counter_data_p->data.hft_data.port_cntr_info.pg_watermark_list_p =
                (sx_hft_buffer_unit_64_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset + layout_hft->port_map.pg_watermark_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_INGRESS_PORT_PRIORITY_GROUP_BUFFER_OCCUPANCY_E:
            counter_data_p->data.hft_data.port_cntr_info.pg_curr_occupancy_list_p =
                (sx_hft_buffer_unit_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                            port_list_counter_offset +
                                            layout_hft->port_map.pg_curr_occupancy_list_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_LOW_E:
            counter_data_p->data.hft_data.port_cntr_info.ar_grades_low_p =
                (sx_hft_port_ctr_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.ar_grades_low_offset);
            break;

        case SX_BULK_CNTR_HFT_SAMPLE_COUNTER_PORT_AR_GRADE_HIGH_E:
            counter_data_p->data.hft_data.port_cntr_info.ar_grades_high_p =
                (sx_hft_port_ctr_32_t *)(&layout_hft->buffer[0] + sample_offset +
                                         port_list_counter_offset + layout_hft->port_map.ar_grades_high_offset);
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid port counter type given, param[%d]\n",
                       hft_sample_cfg.port_counter_config.port_counter_list[idx]);
            goto out;
            break;
        }
    }

    counter_data_p->data.hft_data.port_cntr_info.prio_list_cnt_p = (uint32_t *)&layout_hft->port_map.prio_list_cnt;
    counter_data_p->data.hft_data.port_cntr_info.pg_list_cnt_p = (uint32_t *)&layout_hft->port_map.pg_list_cnt;
    counter_data_p->data.hft_data.port_cntr_info.tc_list_cnt_p = (uint32_t *)&layout_hft->port_map.tc_list_cnt;
out:
    return err;
}

static sx_status_t __fill_hft_global_counters(const sxd_bulk_cntr_buffer_layout_hft_t                 *layout_hft,
                                              const sx_bulk_cntr_hft_read_key_sample_global_counter_t *global_counter_key_p,
                                              const sx_bulk_cntr_buffer_t                             *buffer_p,
                                              sx_bulk_cntr_data_t                                     *counter_data_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    uint32_t                                 sample_idx;
    sx_bulk_cntr_hft_sample_global_counter_e global_counter_type;
    sx_bulk_cntr_hft_sample_config_t         hft_sample_cfg;
    uint32_t                                 sample_offset;
    uint32_t                                 counter_offset;
    uint32_t                                 counter_set_offset;
    uint32_t                                 idx;
    uint32_t                                 base_counter_id;
    boolean_t                                counter_type_found = FALSE;


    hft_sample_cfg = buffer_p->key.key.hft_key.hft_config;
    SX_MEM_CLR(counter_data_p->data);
    sample_idx = global_counter_key_p->sample_key.sample_iteration;
    if (sample_idx < 1) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid sample index [%d] given for global  counter retrieval\n", sample_idx);
        goto out;
    }
    sample_offset = (sample_idx - 1) * layout_hft->sample_buffer_size;
    global_counter_type = global_counter_key_p->global_counter_type;

    for (idx = 0; idx < hft_sample_cfg.global_counter_config.global_counter_list_size; idx++) {
        if (hft_sample_cfg.global_counter_config.global_counter_list[idx] == global_counter_type) {
            counter_type_found = TRUE;
            break;
        }
    }

    if (counter_type_found == FALSE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid global counter type given, param[%d]\n",
                   global_counter_type);
        goto out;
    }

    counter_set_offset = layout_hft->metadata_map.metadata_buffer_size +
                         (layout_hft->port_map.port_counter_buffer_size * layout_hft->port_map.count_port_expected);
    switch (global_counter_type) {
    case SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_0_E:
        counter_set_offset += layout_hft->global_map.flow_counter_base_0_offset;
        break;

    case SX_BULK_CNTR_HFT_SAMPLE_GLOBAL_FLOW_COUNTER_PACKETS_AND_BYTES_BASE_1_E:
        counter_set_offset += layout_hft->global_map.flow_counter_base_1_offset;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid global counter type given, param[%d]\n",
                   global_counter_type);
        goto out;
        break;
    }

    base_counter_id = layout_hft->global_map.flow_info[global_counter_type].base_counter_id;
    counter_offset = global_counter_key_p->global_counter_data.flow_key.cntr_id - base_counter_id;
    counter_data_p->data.hft_data.global_data_info.flow_cntr_p =
        (sx_flow_counter_set_t *)(&layout_hft->buffer[0] + sample_offset +
                                  counter_set_offset + (counter_offset * sizeof(sx_flow_counter_set_t)));
out:
    return err;
}

static sx_status_t __bulk_counter_hft_get(const sx_bulk_cntr_read_key_t *key_p,
                                          const sx_bulk_cntr_buffer_t   *buffer_p,
                                          sx_bulk_cntr_data_t           *counter_data_p)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sxd_bulk_cntr_buffer_layout_hft_t                *layout_hft;
    sx_bulk_cntr_hft_read_key_sample_metadata_t       metadata_key;
    sx_bulk_cntr_hft_read_key_sample_port_counter_t   port_counter_key;
    sx_bulk_cntr_hft_read_key_sample_global_counter_t global_counter_key;

    layout_hft = (sxd_bulk_cntr_buffer_layout_hft_t*)(buffer_p->buffer_id);

    switch (key_p->key.hft_key.key_type) {
    case SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_METADATA_E:
        SX_MEM_CLR(metadata_key);
        metadata_key = key_p->key.hft_key.hft_key_data.metadata_key;
        err = __fill_hft_metadata(layout_hft, &metadata_key, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to fetch hft metadata with given key\n");
            goto out;
        }
        break;

    case SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_PORT_E:
        SX_MEM_CLR(port_counter_key);
        port_counter_key = key_p->key.hft_key.hft_key_data.port_counter_key;
        err = __fill_hft_port_counters(layout_hft, &port_counter_key, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to fetch hft port counter with given key\n");
            goto out;
        }
        break;

    case SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_GLOBAL_COUNTER_E:
        SX_MEM_CLR(global_counter_key);
        global_counter_key = key_p->key.hft_key.hft_key_data.global_counter_key;
        err = __fill_hft_global_counters(layout_hft, &global_counter_key, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to fetch hft global counter with given key\n");
            goto out;
        }
        break;
    }

out:
    return err;
}
sx_status_t sx_api_bulk_counter_transaction_get(const sx_api_handle_t          handle,
                                                const sx_bulk_cntr_read_key_t *key_p,
                                                const sx_bulk_cntr_buffer_t   *buffer_p,
                                                sx_bulk_cntr_data_t           *counter_data_p)
{
    const struct sxd_bulk_cntr_buffer_layout_common          *layout_common;
    const struct sxd_bulk_cntr_buffer_layout_flow            *layout_flow;
    const struct sxd_bulk_cntr_buffer_layout_flow_estimator  *layout_flow_estimator;
    const struct sxd_bulk_cntr_buffer_layout_headroom        *layout_headroom;
    const sxd_bulk_cntr_buffer_layout_elephant_t             *layout_elph;
    const sxd_bulk_cntr_buffer_layout_stateful_db_t          *layout_stateful_db;
    const struct sxd_bulk_cntr_buffer_layout_macsec_acl_flow *layout_macsec_acl_flow;
    const struct sxd_bulk_cntr_buffer_layout_macsec_sa       *layout_macsec_sa;
    const struct sxd_bulk_cntr_buffer_layout_hft             *layout_hft;
    sx_cos_elephant_flow_data_t                              *data_p = NULL;
    uint32_t                                                  idx = 0;
    uint32_t                                                  local_port = 0;
    sx_status_t                                               err = SX_STATUS_SUCCESS;
    uint16_t                                                  entity_id, hw_entity_id, base_hw_entity_id;
    sx_macsec_direction_e                                     direction;
    uint16_t                                                  cntr_index;

    UNUSED_PARAM(handle);

    SX_API_LOG_ENTER();

    err = utils_check_pointer(key_p, "key");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = utils_check_pointer(buffer_p, "buffer");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = utils_check_pointer(counter_data_p, "counter_data");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (key_p->type != buffer_p->key.type) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("The read key type [%u] is different with buffer key type [%u]\n", key_p->type, buffer_p->key.type);
        goto out;
    }

    /* get the header of shared memory */
    layout_common = (void*)buffer_p->buffer_id;

    /* make sure number of counters received from FW is the number we expect for this transaction.
     * if not, transaction is assumed to be partially completed */
    if ((layout_common->num_of_counters != layout_common->counters_received_so_far) &&
        ((key_p->type != SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E) &&
         (key_p->type != SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E) &&
         (key_p->type != SX_BULK_CNTR_KEY_TYPE_HFT_E))) {
        SX_LOG_ERR("num_of_counters=%d, counters_received_so_far=%d.\n",
                   layout_common->num_of_counters, layout_common->counters_received_so_far);
        err = SX_STATUS_PARTIALLY_COMPLETE;
        goto out;
    }

    switch (key_p->type) {
    case SX_BULK_CNTR_KEY_TYPE_PORT_E:
        err = __bulk_counter_port_get(key_p, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get counter for port.\n");
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_FLOW_E:
        /* make sure user input for counter_id is in the range of the original request for
         * bulk counters. */
        if ((key_p->key.flow_key.cntr_id < buffer_p->key.key.flow_key.base_counter_id) ||
            (key_p->key.flow_key.cntr_id >= buffer_p->key.key.flow_key.base_counter_id +
             buffer_p->key.key.flow_key.num_of_counters)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flow counter-ID %u is out of range [%u counters from base-id %u]\n",
                       key_p->key.flow_key.cntr_id,
                       buffer_p->key.key.flow_key.num_of_counters,
                       buffer_p->key.key.flow_key.base_counter_id);
            goto out;
        }

        /* return to user with a pointer to the flow counter within the shared memory */
        layout_flow = (struct sxd_bulk_cntr_buffer_layout_flow*)layout_common;
        idx = key_p->key.flow_key.cntr_id - buffer_p->key.key.flow_key.base_counter_id;
        counter_data_p->data.flow_counters.flow_cntr_p =
            (const sx_flow_counter_set_t*)&layout_flow->counters[idx];
        break;

    case SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E:
        /* make sure user input for counter_id is in the range of the original request for
         * bulk counters. */
        if ((key_p->key.flow_estimator_key.cntr_id < buffer_p->key.key.flow_estimator_key.base_counter_id) ||
            (key_p->key.flow_estimator_key.cntr_id >= buffer_p->key.key.flow_estimator_key.base_counter_id +
             buffer_p->key.key.flow_estimator_key.num_of_counters)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flow counter-ID %u is out of range [%u counters from base-id %u]\n",
                       key_p->key.flow_estimator_key.cntr_id,
                       buffer_p->key.key.flow_estimator_key.num_of_counters,
                       buffer_p->key.key.flow_estimator_key.base_counter_id);
            goto out;
        }

        /* return to user with a pointer to the flow counter within the shared memory */
        layout_flow_estimator = (struct sxd_bulk_cntr_buffer_layout_flow_estimator*)layout_common;
        idx = key_p->key.flow_estimator_key.cntr_id - buffer_p->key.key.flow_estimator_key.base_counter_id;
        counter_data_p->data.flow_estimator_data.flow_counter_estimator_p =
            (const sx_flow_estimator_counter_set_t*)&layout_flow_estimator->counter_sets[idx];
        break;

    case SX_BULK_CNTR_KEY_TYPE_SHARED_BUFFER_E:
        err = __bulk_counter_shared_buffer_get(layout_common, key_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get counter for shared buffer.\n");
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_HEADROOM_E:
        layout_headroom = (struct sxd_bulk_cntr_buffer_layout_headroom*)layout_common;
        local_port = SX_PORT_PHY_ID_GET(key_p->key.headroom_key.log_port);
        if ((local_port < SXD_BULK_CNTR_PHY_PORT_MIN) || (local_port > SXD_BULK_CNTR_PORT_NUM)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Port 0x%x is out of range\n", key_p->key.headroom_key.log_port);
            goto out;
        }
        if (SX_BITMAP_ARR_BIT_GET(layout_headroom->port_mask, local_port - 1) == 0) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port 0x%x is not valid\n", key_p->key.headroom_key.log_port);
            goto out;
        }

        counter_data_p->data.headroom_counters.headroom_p =
            (const sx_bulk_cntr_headroom_t*)&layout_headroom->headroom[local_port - 1];
        break;

    case SX_BULK_CNTR_KEY_TYPE_ELEPHANT_E:
        layout_elph = (sxd_bulk_cntr_buffer_layout_elephant_t*)layout_common;
        err = __elephant_key_port_index_get(buffer_p->key.key.elephant_key.port_list,
                                            buffer_p->key.key.elephant_key.port_list_cnt,
                                            key_p->key.elephant_key.read_key.flow_data.log_port,
                                            &idx);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Invalid elephant read key: log port 0x%x not found in buffer key.\n",
                       key_p->key.elephant_key.read_key.flow_data.log_port);
            goto out;
        }

        if (key_p->key.elephant_key.type == SX_BULK_CNTR_READ_KEY_TYPE_ELEPHANT_FLOWS_GET_E) {
            counter_data_p->data.elephant_flow_data.flow_id_list_p =
                (const sx_cos_elephant_flow_ids_list_t*)&layout_elph->port_flows[idx];
        } else if (key_p->key.elephant_key.type == SX_BULK_CNTR_READ_KEY_TYPE_ELEPHANT_FLOWS_DATA_GET_E) {
            if (key_p->key.elephant_key.read_key.flow_data.flow_id >= SXD_COS_ELEPHANT_FLOW_ID_NUM_MAX) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid elephant read key: flow ID %d\n",
                           key_p->key.elephant_key.read_key.flow_data.flow_id);
                goto out;
            }
            idx = SXD_COS_ELEPHANT_FLOW_ID_NUM_MAX * idx + key_p->key.elephant_key.read_key.flow_data.flow_id;
            data_p = (sx_cos_elephant_flow_data_t*)&layout_elph->data[idx];
            data_p->data_key.flow_id = key_p->key.elephant_key.read_key.flow_data.flow_id;
            counter_data_p->data.elephant_flow_data.elephant_flow_data_p =
                (const sx_cos_elephant_flow_data_t*)&layout_elph->data[idx];
        } else {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid elephant read key type [%u]\n", key_p->key.elephant_key.type);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_STATEFUL_DB_E:
        layout_stateful_db = (sxd_bulk_cntr_buffer_layout_stateful_db_t*)layout_common;

        if (key_p->key.stateful_db_key.type == SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_NUM_ENTRIES_GET_E) {
            counter_data_p->data.stateful_db_entry_data.stateful_db_entries_num_p =
                (const sx_stateful_db_entries_num_t *)&layout_stateful_db->meta_layout.number_of_entries;
        } else if (key_p->key.stateful_db_key.type == SX_BULK_CNTR_READ_KEY_TYPE_STATEFUL_DB_ENTRY_DATA_GET_E) {
            if (key_p->key.stateful_db_key.read_key.entry_access.entry_index >=
                layout_stateful_db->meta_layout.number_of_entries) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Entry index [%d] exceeds the number of entries read from stateful DB  [%d]\n",
                           key_p->key.stateful_db_key.read_key.entry_access.entry_index,
                           layout_stateful_db->meta_layout.number_of_entries);
                goto out;
            }

            counter_data_p->data.stateful_db_entry_data.stateful_db_entry_p =
                (const sx_stateful_db_entry_t *)&layout_stateful_db->data[key_p->key.stateful_db_key.read_key.
                                                                          entry_access.entry_index];
        } else {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid stateful DB read key type [%u]\n", key_p->key.stateful_db_key.type);
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_PORT_E:
        err = __bulk_counter_macsec_port_get(key_p, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get macsec counter for port.\n");
            goto out;
        }
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_ACL_FLOW_E:
        /* make sure user input for counter_id is in the range of the original request for
         * bulk counters. */
        SX_MACSEC_GET_ID_FROM_OBJ_ID(key_p->key.macsec_acl_flow_key.counter_id, entity_id);
        SX_MACSEC_GET_PORT_FROM_OBJ_ID(key_p->key.macsec_acl_flow_key.counter_id, local_port);
        SX_MACSEC_GET_DIR_FROM_OBJ_ID(key_p->key.macsec_acl_flow_key.counter_id, direction);

        if (direction != buffer_p->key.key.macsec_acl_flow_key.direction) {
            SX_LOG_ERR("MACSec ACL counter entity ID %u direction [%u] is not same as buffer direction[%u] \n",
                       entity_id, direction,
                       buffer_p->key.key.macsec_acl_flow_key.direction);
            goto out;
        }

        if ((entity_id < buffer_p->key.key.macsec_acl_flow_key.base_entity_id) ||
            (entity_id > buffer_p->key.key.macsec_acl_flow_key.base_entity_id +
             buffer_p->key.key.macsec_acl_flow_key.num_of_counters)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("MACSec ACL counter entity ID %u is out of range [%u counters from base-id 0x%X]\n",
                       entity_id,
                       buffer_p->key.key.macsec_acl_flow_key.num_of_counters,
                       buffer_p->key.key.macsec_acl_flow_key.base_entity_id);
            goto out;
        }


        /* return to user with a pointer to the ACL flow counter within the shared memory */
        hw_entity_id = SX_MACSEC_ACL_FLOW_COUNTER_ENTITY_ID_TO_HW_ENTITY_ID(entity_id);
        base_hw_entity_id = SX_MACSEC_ACL_FLOW_COUNTER_ENTITY_ID_TO_HW_ENTITY_ID(
            buffer_p->key.key.macsec_acl_flow_key.base_entity_id);
        layout_macsec_acl_flow = (struct sxd_bulk_cntr_buffer_layout_macsec_acl_flow*)layout_common;
        cntr_index = layout_macsec_acl_flow->port_index_map[local_port];
        idx =
            (cntr_index *
             (layout_macsec_acl_flow->number_of_counters / buffer_p->key.key.macsec_acl_flow_key.num_of_counters))
            + (hw_entity_id - base_hw_entity_id);
        counter_data_p->data.macsec_acl_flow_counters.acl_counter_data_p =
            (const sx_macsec_acl_counter_set_t*)&layout_macsec_acl_flow->counter_sets[idx];
        break;

    case SX_BULK_CNTR_KEY_TYPE_MACSEC_SA_E:
        /* make sure user input for sa_id is in the range of the original request for
         * bulk counters. */
        SX_MACSEC_GET_ID_FROM_OBJ_ID(key_p->key.macsec_sa_key.sa_id, entity_id);
        SX_MACSEC_GET_PORT_FROM_OBJ_ID(key_p->key.macsec_sa_key.sa_id, local_port);
        SX_MACSEC_GET_DIR_FROM_OBJ_ID(key_p->key.macsec_sa_key.sa_id, direction);

        if (direction != buffer_p->key.key.macsec_sa_key.direction) {
            SX_LOG_ERR("MACSec SA entity ID %u direction [%u] is not same as buffer direction[%u] \n",
                       entity_id, direction,
                       buffer_p->key.key.macsec_sa_key.direction);
            goto out;
        }

        if (local_port != SX_PORT_PHY_ID_GET(buffer_p->key.key.macsec_sa_key.port)) {
            SX_LOG_ERR("MACSec SA entity ID %u port [%u] is not same as buffer port [%u] \n",
                       entity_id, local_port,
                       SX_PORT_PHY_ID_GET(buffer_p->key.key.macsec_sa_key.port));
            goto out;
        }

        if ((entity_id < buffer_p->key.key.macsec_sa_key.base_entity_id) ||
            (entity_id > buffer_p->key.key.macsec_sa_key.base_entity_id +
             buffer_p->key.key.macsec_sa_key.num_of_counters)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("MACSec SA entity ID %u is out of range [%u counters from base-id 0x%X]\n",
                       entity_id,
                       buffer_p->key.key.macsec_sa_key.num_of_counters,
                       buffer_p->key.key.macsec_sa_key.base_entity_id);
            goto out;
        }


        hw_entity_id = SX_MACSEC_SA_COUNTER_ENTITY_ID_TO_HW_ENTITY_ID(entity_id);
        base_hw_entity_id = SX_MACSEC_SA_COUNTER_ENTITY_ID_TO_HW_ENTITY_ID(
            buffer_p->key.key.macsec_sa_key.base_entity_id);
        /* return to user with a pointer to the ACL flow counter within the shared memory */
        layout_macsec_sa = (struct sxd_bulk_cntr_buffer_layout_macsec_sa*)layout_common;
        counter_data_p->data.macsec_sa_counters.sa_stats_data_p =
            (const sx_macsec_cntr_sa_stats_t*)&layout_macsec_sa->counter_sets[hw_entity_id - base_hw_entity_id];
        break;

    case SX_BULK_CNTR_KEY_TYPE_HFT_E:
        layout_hft = (struct sxd_bulk_cntr_buffer_layout_hft*)layout_common;
        if (layout_hft->samples_expected != layout_hft->samples_received) {
            SX_LOG_ERR("num_of_samples_expected=%d, num_of_samples_received=%d.\n",
                       layout_hft->samples_expected, layout_hft->samples_received);
            err = SX_STATUS_ERROR;
            goto out;
        }
        err = __bulk_counter_hft_get(key_p, buffer_p, counter_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get hft counter for port.\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid key type [%u]\n", key_p->type);
        goto out;
        break;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bulk_counter_refresh_set(const sx_api_handle_t               handle,
                                            const sx_access_cmd_t               cmd,
                                            const sx_bulk_cntr_refresh_attr_t * counter_refresh_attr_p)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_api_bulk_counter_refresh_params_t cmd_body;
    sx_api_int_cmd_e                     int_cmd = SX_API_INT_CMD_BULK_CNTR_REFRESH_SET_E;
    uint32_t                             cmd_size = sizeof(sx_api_bulk_counter_refresh_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    /* Check the pointer is valid */
    if (counter_refresh_attr_p == NULL) {
        SX_LOG_ERR("Pointer counter_refresh_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Validate user command */
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        /* Initiate refresh request */
        break;

    default:
        /* Other commands not supported */
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command %d (%s) unsupported. Error: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    /* Prepare SDK call parameters */
    cmd_body.cmd = cmd;
    cmd_body.refresh_attr = *counter_refresh_attr_p;

    /* Call SDK function */
    err = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        /* SDK call failed */
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bulk_counter_attr_set(const sx_api_handle_t handle, const sx_bulk_cntr_attr_t *bulk_cntr_attr_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sxd_ctrl_pack_t                 ctrl_pack;
    const sx_api_user_ctxt_t       *user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    struct ku_bulk_cntr_buffer_info buffer_info;
    sxd_status_t                    sxd_err = SXD_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(bulk_cntr_attr_p, "bulk_cntr_attr_p")) {
        SX_LOG_ERR("bulk_cntr_attr_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (bulk_cntr_attr_p->buffer_type != SX_BULK_CNTR_BUFFER_TYPE_HFT) {
        SX_LOG_ERR("API - sx_api_bulk_counter_attr_set is only supported for high frequency telemetry buffer\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR(buffer_info);

    buffer_info.max_size = bulk_cntr_attr_p->max_buffer_limit;
    ctrl_pack.ctrl_cmd = CTRL_CMD_BULK_CNTR_BUFFER_INFO_SET;
    ctrl_pack.cmd_body = &buffer_info;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_BULK_CNTR_BUFFER_INFO_SET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bulk_counter_attr_get(const sx_api_handle_t handle, sx_bulk_cntr_attr_t *bulk_cntr_attr_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sxd_ctrl_pack_t                 ctrl_pack;
    const sx_api_user_ctxt_t       *user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    struct ku_bulk_cntr_buffer_info buffer_info;
    sxd_status_t                    sxd_err = SXD_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(bulk_cntr_attr_p, "bulk_cntr_attr_p")) {
        SX_LOG_ERR("bulk_cntr_attr_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (bulk_cntr_attr_p->buffer_type != SX_BULK_CNTR_BUFFER_TYPE_HFT) {
        SX_LOG_ERR("API - sx_api_bulk_counter_attr_get is only supported for high frequency telemetry buffer\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR(buffer_info);


    ctrl_pack.ctrl_cmd = CTRL_CMD_BULK_CNTR_BUFFER_INFO_GET;
    ctrl_pack.cmd_body = &buffer_info;
    sxd_err = sxd_ioctl(user_ctx->dev, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("CTRL_CMD_BULK_CNTR_BUFFER_INFO_GET ioctl failed error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    bulk_cntr_attr_p->max_buffer_limit = buffer_info.max_size;
    bulk_cntr_attr_p->current_buffer_utilization = ((float)buffer_info.current_utilization / BYTES_IN_MB);

out:
    SX_API_LOG_EXIT();
    return err;
}
