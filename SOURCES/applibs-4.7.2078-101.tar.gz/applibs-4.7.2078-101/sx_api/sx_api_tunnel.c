/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_tunnel.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_TUNNEL

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_tunnel_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TUNNEL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  sx_verbosity_level_t           *module_verbosity_level_p,
                                                  sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TUNNEL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_init_set(const sx_api_handle_t handle, sx_tunnel_general_params_t *params_p)
{
    sx_api_tunnel_init_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(params_p, "tunnel_general_params")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY_P(&cmd_body.general_params, params_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_init_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_DEINIT_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_set(const sx_api_handle_t        handle,
                              const sx_access_cmd_t        cmd,
                              const sx_tunnel_attribute_t *tunnel_attr_p,
                              sx_tunnel_id_t              *tunnel_id_p)
{
    sx_api_tunnel_set_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(tunnel_id_p, "tunnel_id")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (utils_check_pointer(tunnel_attr_p, "tunnel_attr")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.tunnel_attr, tunnel_attr_p);
        break;

    case SX_ACCESS_CMD_DESTROY:
        if (SX_TUNNEL_ID_INVALID == (*tunnel_id_p)) {
            SX_LOG_ERR("Failed to destroy a tunnel with invalid id: %d.\n", SX_TUNNEL_ID_INVALID);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        if (SX_TUNNEL_ID_INVALID == (*tunnel_id_p)) {
            SX_LOG_ERR("Failed to edit a tunnel with invalid id: %d.\n", SX_TUNNEL_ID_INVALID);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.tunnel_attr, tunnel_attr_p);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.tunnel_id = *tunnel_id_p;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_set_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_ACCESS_CMD_CREATE == cmd) {
        *tunnel_id_p = cmd_body.tunnel_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_get(const sx_api_handle_t  handle,
                              const sx_tunnel_id_t   tunnel_id,
                              sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_api_tunnel_get_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_ID_INVALID == tunnel_id) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.tunnel_id = tunnel_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(tunnel_attr_p, &cmd_body.tunnel_attr);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_counter_get(const sx_api_handle_t handle,
                                      const sx_access_cmd_t cmd,
                                      const sx_tunnel_id_t  tunnel_id,
                                      sx_tunnel_counter_t  *counter)
{
    sx_api_tunnel_counter_get_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(counter, "counter")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_ID_INVALID == tunnel_id) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) &&
        (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.tunnel_id = tunnel_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_COUNTER_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_counter_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(counter, &cmd_body.counter);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_decap_rules_set(const sx_api_handle_t               handle,
                                          const sx_access_cmd_t               cmd,
                                          const sx_tunnel_decap_entry_key_t  *decap_key_p,
                                          const sx_tunnel_decap_entry_data_t *decap_data_p)
{
    sx_api_tunnel_decap_rules_set_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_CREATE) &&
        (cmd != SX_ACCESS_CMD_DESTROY) &&
        (cmd != SX_ACCESS_CMD_EDIT)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (utils_check_pointer(decap_key_p, "decap_key")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_CREATE) ||
        (cmd == SX_ACCESS_CMD_EDIT)) {
        if (utils_check_pointer(decap_data_p, "decap_data")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.entry_data_params, decap_data_p);
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.entry_key_params, decap_key_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_DECAP_RULES_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_decap_rules_set_params_t));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_decap_rules_get(const sx_api_handle_t              handle,
                                          const sx_tunnel_decap_entry_key_t *decap_key_p,
                                          sx_tunnel_decap_entry_data_t      *decap_data_p)
{
    sx_api_tunnel_decap_rules_get_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(decap_key_p, "decap_key")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(decap_data_p, "decap_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY_P(&cmd_body.entry_key_params, decap_key_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_DECAP_RULES_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_decap_rules_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(decap_data_p, &cmd_body.entry_data_params);

out:
    SX_API_LOG_EXIT();
    return err;
}
sx_status_t sx_api_tunnel_map_set(const sx_api_handle_t         handle,
                                  const sx_access_cmd_t         cmd,
                                  const sx_tunnel_id_t          tunnel_id,
                                  const sx_tunnel_map_entry_t * map_entries_p,
                                  const uint32_t                map_entries_cnt)
{
    sx_api_tunnel_map_set_params_t *cmd_body = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     free_err = SX_STATUS_SUCCESS;
    uint32_t                        cmd_size = 0;

    SX_API_LOG_ENTER();
    cmd_size = sizeof(sx_api_tunnel_map_set_params_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        if (utils_check_pointer(map_entries_p, "map_entries_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        if ((map_entries_cnt == 0) ||
            (map_entries_cnt > TUNNEL_MAP_ENTRIES_SET_MAX_NUM)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("the map_entries_cnt parameter exceeds range.[1-%u]\n",
                       TUNNEL_MAP_ENTRIES_SET_MAX_NUM);
            goto out;
        }
        cmd_size += (sizeof(sx_tunnel_map_entry_t) * map_entries_cnt);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_size,
                                   UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != err) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for command params.\n");
            goto out;
        }
        SX_MEM_CPY_ARRAY(cmd_body->map_entries_p, map_entries_p,
                         map_entries_cnt, sx_tunnel_map_entry_t);
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_size,
                                   UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != err) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for command params.\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    cmd_body->cmd = cmd;
    cmd_body->tunnel_id = tunnel_id;
    cmd_body->map_entries_cnt = map_entries_cnt;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_MAP_SET_E,
                                      (uint8_t*)cmd_body,
                                      cmd_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    if (NULL != cmd_body) {
        free_err = utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_map_get(const sx_api_handle_t   handle,
                                  const sx_access_cmd_t   cmd,
                                  const sx_tunnel_id_t    tunnel_id,
                                  sx_tunnel_map_entry_t   map_entry_key,
                                  sx_tunnel_map_entry_t * map_entries_p,
                                  uint32_t              * map_entries_cnt_p)
{
    sx_api_tunnel_map_get_params_t *cmd_body = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     free_err = SX_STATUS_SUCCESS;
    uint32_t                        cmd_size = 0;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(map_entries_cnt_p, "map_entries_cnt_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size = sizeof(sx_api_tunnel_map_get_params_t);
    cmd_size += (sizeof(sx_tunnel_map_entry_t) * (*map_entries_cnt_p));
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    if (*map_entries_cnt_p > 0) {
        if (utils_check_pointer(map_entries_p, "map_entries_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        if (*map_entries_cnt_p > MAX_NUM_ENRTY_GET) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    cmd_body->map_entries_cnt = *map_entries_cnt_p;

    cmd_body->tunnel_id = tunnel_id;
    cmd_body->map_entry_key.type = map_entry_key.type;
    cmd_body->map_entry_key.params.nve.bridge_id = map_entry_key.params.nve.bridge_id;
    cmd_body->map_entry_key.params.nve.vni = map_entry_key.params.nve.vni;
    cmd_body->cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_MAP_GET_E,
                                      (uint8_t*)cmd_body, cmd_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*map_entries_cnt_p != 0) {
        SX_MEM_CPY_ARRAY(map_entries_p, cmd_body->map_entries_p,
                         cmd_body->map_entries_cnt, sx_tunnel_map_entry_t);
    }
    *map_entries_cnt_p = cmd_body->map_entries_cnt;


out:
    if (NULL != cmd_body) {
        free_err = utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_ttl_set(const sx_api_handle_t       handle,
                                  const sx_tunnel_id_t        tunnel_id,
                                  const sx_tunnel_ttl_data_t *ttl_data_p)
{
    sx_api_tunnel_ttl_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.tunnel_id = tunnel_id;
    SX_MEM_CPY_P(&cmd_body.ttl_data, ttl_data_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_TTL_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_ttl_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_ttl_get(const sx_api_handle_t handle,
                                  const sx_tunnel_id_t  tunnel_id,
                                  sx_tunnel_ttl_data_t *ttl_data_p)
{
    sx_api_tunnel_ttl_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    cmd_body.tunnel_id = tunnel_id;
    SX_MEM_CPY_P(&cmd_body.ttl_data, ttl_data_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_TTL_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_ttl_params_t));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(ttl_data_p, &cmd_body.ttl_data);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_cos_set(const sx_api_handle_t       handle,
                                  const sx_tunnel_id_t        tunnel_id,
                                  const sx_tunnel_cos_data_t *cos_data_p)
{
    sx_api_tunnel_cos_set_params_t cmd_body;
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       cmd_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);
    cmd_size = sizeof(cmd_body);


    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY_P(&cmd_body.cos_data, cos_data_p);
    cmd_body.tunnel_id = tunnel_id;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_COS_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_hash_set(const sx_api_handle_t        handle,
                                   const sx_tunnel_id_t         tunnel_id,
                                   const sx_tunnel_hash_data_t *hash_data_p)
{
    sx_api_tunnel_hash_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    cmd_body.tunnel_id = tunnel_id;
    SX_MEM_CPY_P(&cmd_body.hash_data, hash_data_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_HASH_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_hash_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tunnel_hash_get(const sx_api_handle_t  handle,
                                   const sx_tunnel_id_t   tunnel_id,
                                   sx_tunnel_hash_data_t *hash_data_p)
{
    sx_api_tunnel_hash_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.tunnel_id = tunnel_id;
    SX_MEM_CPY_P(&cmd_body.hash_data, hash_data_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_HASH_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tunnel_hash_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(hash_data_p, &cmd_body.hash_data);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_cos_get(const sx_api_handle_t handle,
                                  const sx_tunnel_id_t  tunnel_id,
                                  sx_tunnel_cos_data_t *cos_data_p)
{
    sx_api_tunnel_cos_get_params_t *cmd_body = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     free_err = SX_STATUS_SUCCESS;
    uint32_t                        cmd_size = 0;

    SX_API_LOG_ENTER();


    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    cmd_size = sizeof(sx_api_tunnel_cos_get_params_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    SX_MEM_CPY(cmd_body->cos_data, *cos_data_p);
    cmd_body->tunnel_id = tunnel_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TUNNEL_COS_GET_E,
                                      (uint8_t*)cmd_body, cmd_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY(*cos_data_p, cmd_body->cos_data);

out:
    if (NULL != cmd_body) {
        free_err = utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_iter_get(const sx_api_handle_t     handle,
                                   const sx_access_cmd_t     cmd,
                                   const sx_tunnel_id_t      tunnel_id,
                                   const sx_tunnel_filter_t *filter_p,
                                   sx_tunnel_id_t           *tunnel_id_list_p,
                                   uint32_t                 *tunnel_id_cnt_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_tunnel_iter_get_params_t  cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_api_tunnel_iter_get_params_t *reply_body = NULL;
    uint32_t                         reply_body_size;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (utils_check_pointer(tunnel_id_cnt_p, "tunnel_id_cnt_p")) {
        SX_LOG_ERR("tunnel_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*tunnel_id_cnt_p > 0) && (tunnel_id_list_p == NULL)) {
        SX_LOG_ERR("*tunnel_id_cnt_p is not 0 but tunnel_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*tunnel_id_cnt_p == 0) {
            tunnel_id_list_p = NULL;
        } else {
            *tunnel_id_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*tunnel_id_cnt_p == 0) {
            SX_LOG_DBG("Tunnel ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_tunnel_iter_get_params_t) +
                      (*tunnel_id_cnt_p * sizeof(sx_tunnel_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_TUNNEL_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_tunnel_iter_get_params_t);
    cmd_head.list_size = *tunnel_id_cnt_p * sizeof(sx_tunnel_id_t);

    cmd_body.cmd = cmd;
    cmd_body.tunnel_id = tunnel_id;
    cmd_body.tunnel_id_cnt = *tunnel_id_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_tunnel_filter_t);
    }

    *tunnel_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->tunnel_id_cnt != 0) {
        *tunnel_id_cnt_p = reply_body->tunnel_id_cnt;
        if (tunnel_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(tunnel_id_list_p, reply_body->tunnel_id_list_p,
                             reply_body->tunnel_id_cnt, sx_tunnel_id_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_decap_rule_iter_get(const sx_api_handle_t                 handle,
                                              const sx_access_cmd_t                 cmd,
                                              const sx_tunnel_decap_entry_key_t    *decap_rule_key_p,
                                              const sx_tunnel_decap_entry_filter_t *decap_filter_p,
                                              sx_tunnel_decap_entry_key_t          *decap_rule_list_p,
                                              uint32_t                             *decap_rule_cnt_p)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_tunnel_decap_rule_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                         reply_head;
    sx_api_tunnel_decap_rule_iter_get_params_t *reply_body = NULL;
    uint32_t                                    reply_body_size;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (utils_check_pointer(decap_rule_cnt_p, "decap_rule_cnt_p")) {
        SX_LOG_ERR("decap_key_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*decap_rule_cnt_p > 0) && (decap_rule_list_p == NULL)) {
        SX_LOG_ERR("*decap_key_cnt_p is not 0 but decap_rule_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*decap_rule_cnt_p == 0) {
            decap_rule_list_p = NULL;
        } else {
            *decap_rule_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*decap_rule_cnt_p == 0) {
            SX_LOG_NTC("Rule count is 0 with cmd = %s\n", sx_access_cmd_str(cmd));
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is not supported, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_tunnel_decap_rule_iter_get_params_t) +
                      (*decap_rule_cnt_p * sizeof(sx_tunnel_decap_entry_key_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_TUNNEL_DECAP_RULE_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_tunnel_decap_rule_iter_get_params_t);
    cmd_head.list_size = *decap_rule_cnt_p * sizeof(sx_tunnel_decap_entry_key_t);

    cmd_body.cmd = cmd;
    cmd_body.decap_rule_cnt = *decap_rule_cnt_p;
    if (decap_rule_key_p) {
        SX_MEM_CPY_TYPE(&(cmd_body.rule_key), decap_rule_key_p, sx_tunnel_decap_entry_key_t);
    }
    if (decap_filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), decap_filter_p, sx_tunnel_decap_entry_filter_t);
    }
    /* clear out the return count */
    *decap_rule_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->decap_rule_cnt != 0) {
        *decap_rule_cnt_p = reply_body->decap_rule_cnt;
        if (decap_rule_list_p != NULL) {
            SX_MEM_CPY_ARRAY(decap_rule_list_p, reply_body->decap_rule_list_p,
                             reply_body->decap_rule_cnt, sx_tunnel_decap_entry_key_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_flex_header_set(const sx_api_handle_t              handle,
                                          const sx_access_cmd_t              cmd,
                                          const sx_tunnel_flex_header_cfg_t *tunnel_flex_header_cfg_p,
                                          sx_tunnel_flex_header_id_t        *tunnel_flex_header_id_p)
{
    sx_api_tunnel_flex_header_set_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(tunnel_flex_header_id_p, "tunnel_flex_header_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_EDIT:
        if (utils_check_pointer(tunnel_flex_header_cfg_p, "tunnel_flex_header_cfg_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.header_cfg, tunnel_flex_header_cfg_p);
        break;

    case SX_ACCESS_CMD_DESTROY:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is not supported, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.header_id = *tunnel_flex_header_id_p;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_FLEX_HEADER_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_ACCESS_CMD_CREATE == cmd) {
        *tunnel_flex_header_id_p = cmd_body.header_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tunnel_flex_header_get(const sx_api_handle_t            handle,
                                          const sx_access_cmd_t            cmd,
                                          const sx_tunnel_flex_header_id_t tunnel_flex_header_id,
                                          sx_tunnel_flex_header_cfg_t     *tunnel_flex_header_cfg_p)
{
    sx_api_tunnel_flex_header_get_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(tunnel_flex_header_cfg_p, "tunnel_flex_header_cfg_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        break;


    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is not supported, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.header_id = tunnel_flex_header_id;


    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TUNNEL_FLEX_HEADER_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *tunnel_flex_header_cfg_p = cmd_body.header_cfg;


out:
    SX_API_LOG_EXIT();
    return err;
}
