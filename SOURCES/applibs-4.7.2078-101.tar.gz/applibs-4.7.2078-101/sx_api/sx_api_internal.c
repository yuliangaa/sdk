/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <errno.h>
#include <complib/sx_log.h>
#include "sx_api_internal.h"
#include <sys/types.h>
#include <unistd.h>
#include "ethl2/cos_sb.h"

#undef  __MODULE__
#define __MODULE__ SX_API_INTERNAL

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/
boolean_t                  g_sx_log_api_func_enabled = FALSE;
boolean_t                  sx_api_sniffer_enabled = FALSE;
sx_api_sniffer_api_reply_t sx_api_sniffer_api_reply = NULL;

/************************************************
 *  Functions declaration
 ***********************************************/
static sx_status_t __send_message(cl_commchnl_t *commchnl,
                                  uint8_t       *header,
                                  uint32_t       header_size,
                                  uint8_t       *body,
                                  uint32_t       body_size,
                                  const int     *fd);
static sx_status_t __receive_message(cl_commchnl_t       *commchnl,
                                     sx_api_reply_head_t *reply_head,
                                     uint8_t             *reply_body,
                                     uint32_t             reply_body_size,
                                     int                 *fd);


/************************************************
 *  Functions implementation
 ***********************************************/
void sx_api_sniffer_enabled_set(boolean_t enabled)
{
    sx_api_sniffer_enabled = enabled;
}

void sx_api_sniffer_api_reply_set(sx_api_sniffer_api_reply_t func)
{
    sx_api_sniffer_api_reply = func;
}

static sx_status_t __send_message(cl_commchnl_t *commchnl,
                                  uint8_t       *header,
                                  uint32_t       header_size,
                                  uint8_t       *body,
                                  uint32_t       body_size,
                                  const int     *fd)
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!fd) {
        cl_err = cl_commchnl_send(commchnl, header, &header_size);
    } else {
        cl_err = cl_commchnl_send_fd(commchnl, header, &header_size, *fd);
    }
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed message send at communication channel: %s\n", strerror(errno));
        err = SX_STATUS_COMM_ERROR;
        goto out;
    }

    if (body != NULL) {
        cl_err = cl_commchnl_send(commchnl, body, &body_size);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed message send at communication channel: %s\n", strerror(errno));
            err = SX_STATUS_COMM_ERROR;
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __receive_message(cl_commchnl_t       *commchnl,
                                     sx_api_reply_head_t *reply_head,
                                     uint8_t             *reply_body,
                                     uint32_t             reply_body_size,
                                     int                 *fd)
{
    uint32_t    buffer_size = 0;
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    buffer_size = sizeof(sx_api_reply_head_t);
    if (!fd) {
        cl_err = cl_commchnl_recv(commchnl, TRUE, (uint8_t*)reply_head,
                                  &buffer_size);
    } else {
        cl_err = cl_commchnl_recv_fd(commchnl, TRUE, (uint8_t*)reply_head,
                                     &buffer_size, fd);
    }
    if (cl_err == CL_DISCONNECT) {
        SX_LOG(SX_LOG_DEBUG, "Connection closed\n");
        err = SX_STATUS_COMM_ERROR;
        goto out;
    } else if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed message receive at communication channel: %s\n",
               strerror(errno));
        err = SX_STATUS_COMM_ERROR;
        goto out;
    }

    buffer_size = reply_head->msg_size - sizeof(sx_api_reply_head_t);
    if (buffer_size) {
        /* SX SDK server may choose to reply shorter message */
        if (buffer_size > reply_body_size) {
            SX_LOG(SX_LOG_ERROR, "Message size overflow.\n");
            err = SX_STATUS_COMM_ERROR;
            goto out;
        }

        cl_err = cl_commchnl_recv(commchnl, TRUE, reply_body, &buffer_size);
        if (cl_err == CL_DISCONNECT) {
            SX_LOG(SX_LOG_DEBUG, "Connection closed\n");
            err = SX_STATUS_COMM_ERROR;
            goto out;
        } else if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed message receive at communication channel: %s\n",
                   strerror(errno));
            err = SX_STATUS_COMM_ERROR;
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_internal_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    SX_API_LOG_EXIT();

    return err;
}

static sx_status_t __send_command_decoupled(sx_api_handle_t        handle,
                                            sx_api_command_head_t *cmd_head,
                                            uint8_t               *cmd_body,
                                            sx_api_reply_head_t   *reply_head,
                                            uint8_t               *reply_body,
                                            uint32_t               reply_body_size,
                                            int32_t               *fd)
{
    sx_api_user_ctxt_t *ctxt = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    sx_status_t         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!ctxt) {
        SX_LOG_ERR("Invalid handle: handle is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }
    if (ctxt->valid == FALSE) {
        SX_LOG_ERR("Invalid handle: handle is not valid.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    err = utils_check_msg_size(cmd_head->msg_size, SX_API_MESSAGE_SIZE_LIMIT);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cl_spinlock_acquire(&(ctxt->mutex));
    cmd_head->pid = ctxt->commchnl.pid;
    /* Send command */
    err = __send_message(&(ctxt->commchnl), (uint8_t*)cmd_head, sizeof(sx_api_command_head_t),
                         cmd_body, cmd_head->msg_size - sizeof(sx_api_command_head_t),
                         NULL);
    if (err != SX_STATUS_SUCCESS) {
        ctxt->valid = FALSE;
        goto out;
    }

    err = __receive_message(&(ctxt->commchnl), reply_head, reply_body,
                            reply_body_size, fd);
    if (err != SX_STATUS_SUCCESS) {
        /* Receive reply */
        ctxt->valid = FALSE;
        goto out;
    }

    err = (sx_status_t)(reply_head->retcode);

out:
    cl_spinlock_release(&(ctxt->mutex));
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_command_decoupled(sx_api_handle_t        handle,
                                          sx_api_command_head_t *cmd_head,
                                          uint8_t               *cmd_body,
                                          sx_api_reply_head_t   *reply_head,
                                          uint8_t               *reply_body,
                                          uint32_t               reply_body_size)
{
    return __send_command_decoupled(handle,
                                    cmd_head,
                                    cmd_body,
                                    reply_head,
                                    reply_body,
                                    reply_body_size,
                                    NULL);
}

sx_status_t sx_api_send_command_decoupled_fd(sx_api_handle_t        handle,
                                             sx_api_command_head_t *cmd_head,
                                             uint8_t               *cmd_body,
                                             sx_api_reply_head_t   *reply_head,
                                             uint8_t               *reply_body,
                                             uint32_t               reply_body_size,
                                             int32_t               *fd)
{
    return __send_command_decoupled(handle,
                                    cmd_head,
                                    cmd_body,
                                    reply_head,
                                    reply_body,
                                    reply_body_size,
                                    fd);
}

sx_status_t sx_api_receive_command(cl_commchnl_t *commchnl, uint8_t **buffer, uint32_t *buffer_position)
{
    uint32_t    i = 0, msg_size = 0, buffer_size = 0;
    uint8_t    *buffer_tmp = NULL;
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    for (i = 0; i < 2; ++i) {
        if (i == 0) {
            msg_size = sizeof(sx_api_command_head_t);
            buffer_tmp = cl_malloc(msg_size);
            if (buffer_tmp == NULL) {
                SX_LOG(SX_LOG_ERROR, "Failed to allocate temporary receive buffer\n");
                err = SX_STATUS_NO_MEMORY;
                goto out;
            }
            *buffer = buffer_tmp;
        } else {
            msg_size = ((sx_api_command_head_t*)(buffer_tmp))->msg_size;
            if (msg_size > SX_API_MESSAGE_SIZE_LIMIT) {
                SX_LOG(SX_LOG_ERROR, "message size is too large %d\n", msg_size);
                err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
                cl_free(buffer_tmp);
                goto out;
            }
            *buffer = cl_malloc(msg_size + ((sx_api_command_head_t*)(buffer_tmp))->list_size);
            if (*buffer == NULL) {
                SX_LOG(SX_LOG_ERROR, "Failed to allocate receive buffer\n");
                err = SX_STATUS_NO_MEMORY;
                goto out;
            }
            SX_MEM_CPY_BUF(*buffer, buffer_tmp, sizeof(sx_api_command_head_t));
            cl_free(buffer_tmp);
            buffer_tmp = *buffer;
        }

        if (*buffer_position < msg_size) {
            buffer_size = msg_size - *buffer_position;
            cl_err = cl_commchnl_recv(commchnl, TRUE, buffer_tmp + *buffer_position, &buffer_size);
            if (cl_err == CL_DISCONNECT) {
                SX_LOG(SX_LOG_DEBUG, "Connection closed\n");
                err = SX_STATUS_COMM_ERROR;
                goto out;
            } else if (cl_err != CL_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed command read at communication channel: %s\n",
                       strerror(errno));
                err = SX_STATUS_COMM_ERROR;
                goto out;
            }

            *buffer_position += buffer_size;
            if (*buffer_position < msg_size) {
                err = SX_STATUS_CMD_INCOMPLETE;
                goto out;
            }
        }
    }

    *buffer_position = 0;
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_reply(cl_commchnl_t *commchnl, sx_api_reply_head_t *reply_head, uint8_t *reply_body)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    header_size = sizeof(sx_api_reply_head_t);
    uint32_t    body_size = reply_head->msg_size - sizeof(sx_api_reply_head_t);

    SX_API_LOG_ENTER();

    if (sx_api_sniffer_enabled != FALSE) {
        if (sx_api_sniffer_api_reply != NULL) {
            sx_api_sniffer_api_reply(reply_head, header_size, reply_body, body_size);
        }
    }

    err = __send_message(commchnl, (uint8_t*)reply_head, header_size,
                         reply_body, body_size, NULL);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_reply_fd(cl_commchnl_t       *commchnl,
                                 sx_api_reply_head_t *reply_head,
                                 uint8_t             *reply_body,
                                 int32_t              fd)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    header_size = sizeof(sx_api_reply_head_t);
    uint32_t    body_size = reply_head->msg_size - sizeof(sx_api_reply_head_t);


    SX_API_LOG_ENTER();

    if (sx_api_sniffer_enabled != FALSE) {
        if (sx_api_sniffer_api_reply != NULL) {
            sx_api_sniffer_api_reply(reply_head, header_size, reply_body, body_size);
        }
    }

    err = __send_message(commchnl, (uint8_t*)reply_head, header_size,
                         reply_body, body_size, &fd);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_command_wrapper(sx_api_handle_t handle, uint32_t opcode, uint8_t *cmd_body_p,
                                        uint32_t cmd_size)
{
    sx_api_command_head_t cmd_head;
    sx_api_reply_head_t   reply_head;
    sx_status_t           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = opcode;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_size;

    err = utils_check_msg_size(cmd_head.msg_size, SX_API_MESSAGE_SIZE_LIMIT);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, cmd_body_p, &reply_head, cmd_body_p, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_reply_wrapper(cl_commchnl_t *commchnl,
                                      sx_status_t    retcode,
                                      uint8_t       *reply_body,
                                      uint32_t       reply_body_size)
{
    sx_api_reply_head_t reply_head;
    sx_status_t         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(reply_head);
    reply_head.retcode = retcode;
    reply_head.version = SX_API_INT_VERSION;
    reply_head.msg_size = sizeof(sx_api_reply_head_t) + reply_body_size;

    err = sx_api_send_reply(commchnl, &reply_head, reply_body);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_send_reply_wrapper_fd(cl_commchnl_t *commchnl,
                                         sx_status_t    retcode,
                                         uint8_t       *reply_body,
                                         uint32_t       reply_body_size,
                                         int32_t        fd)
{
    sx_api_reply_head_t reply_head;
    sx_status_t         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(reply_head);
    reply_head.retcode = retcode;
    reply_head.version = SX_API_INT_VERSION;
    reply_head.msg_size = sizeof(sx_api_reply_head_t) + reply_body_size;

    err = sx_api_send_reply_fd(commchnl, &reply_head, reply_body, fd);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_serialize_port_map_set_params(sx_api_port_map_set_params_t * cmd_body,
                                                 uint8_t                      * out_buffer,
                                                 uint32_t                       buffer_size)
{
    sx_api_port_map_set_params_t * cmd_buffer_p = (sx_api_port_map_set_params_t*)out_buffer;
    uint32_t                       total_size = 0, i = 0;
    uint8_t                      * current_p = out_buffer;

    SX_API_LOG_ENTER();

    if (!cmd_body) {
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (!out_buffer) {
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Write the command ID and array size */
    cmd_buffer_p->cmd = cmd_body->cmd;
    cmd_buffer_p->port_num = cmd_body->port_num;
    current_p += offsetof(sx_api_port_map_set_params_t, port_mapping_list);
    total_size += offsetof(sx_api_port_map_set_params_t, port_mapping_list);

    /* Check if array will fit in buffer size */
    if ((total_size + cmd_body->port_num * sizeof(sx_port_mapping_t)) > buffer_size) {
        SX_LOG_ERR("The provided buffer size[%u] does not fit\n", buffer_size);
        goto out;
    }

    /* Write the port mapping list */
    for (i = 0; i < cmd_body->port_num; i++) {
        SX_MEM_CPY_TYPE(current_p, &cmd_body->port_mapping_list[i], sx_port_mapping_t);
        current_p += sizeof(sx_port_mapping_t);
        total_size += sizeof(sx_port_mapping_t);
    }

    /* Check if array will fit in buffer size */
    if ((total_size + cmd_body->port_num * sizeof(sx_port_log_id_t)) > buffer_size) {
        SX_LOG_ERR("The provided buffer size[%u] does not fit\n", buffer_size);
        goto out;
    }

    /* Write the log port list */
    for (i = 0; i < cmd_body->port_num; i++) {
        SX_MEM_CPY_TYPE(current_p, &cmd_body->log_port_list[i], sx_port_log_id_t);
        current_p += sizeof(sx_port_log_id_t);
        total_size += sizeof(sx_port_log_id_t);
    }

out:
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t sx_api_deserialize_port_map_set_params(uint8_t * in_buffer, sx_api_port_map_set_params_t * out_cmd_body)
{
    sx_api_port_map_set_params_t * cmd_buffer_p = (sx_api_port_map_set_params_t*)in_buffer;
    uint32_t                       total_size = 0, i = 0;
    uint8_t                      * current_p = in_buffer;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (!out_cmd_body) {
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Read the command ID and array size */
    out_cmd_body->cmd = cmd_buffer_p->cmd;
    out_cmd_body->port_num = cmd_buffer_p->port_num;
    current_p += offsetof(sx_api_port_map_set_params_t, port_mapping_list);
    total_size += offsetof(sx_api_port_map_set_params_t, port_mapping_list);

    /* Allocate port_mapping list buffer */
    out_cmd_body->port_mapping_list = (sx_port_mapping_t*)cl_malloc(sizeof(sx_port_mapping_t) *
                                                                    out_cmd_body->port_num);
    if (!out_cmd_body->port_mapping_list) {
        SX_LOG_ERR("Failed to allocate memory for the port mapping list array.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    /* Write the port mapping list */
    for (i = 0; i < out_cmd_body->port_num; i++) {
        SX_MEM_CPY_TYPE(&out_cmd_body->port_mapping_list[i], current_p, sx_port_mapping_t);
        current_p += sizeof(sx_port_mapping_t);
        total_size += sizeof(sx_port_mapping_t);
    }

    /* Allocate log_port list buffer */
    out_cmd_body->log_port_list = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) *
                                                               out_cmd_body->port_num);
    if (!out_cmd_body->log_port_list) {
        SX_LOG_ERR("Failed to allocate memory for the log port list array.\n");
        CL_FREE_N_NULL(out_cmd_body->port_mapping_list);
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    /* Write the log port list */
    for (i = 0; i < out_cmd_body->port_num; i++) {
        SX_MEM_CPY_TYPE(&out_cmd_body->log_port_list[i], current_p, sx_port_log_id_t);
        current_p += sizeof(sx_port_log_id_t);
        total_size += sizeof(sx_port_log_id_t);
    }

    SX_API_LOG_EXIT();

    return SX_STATUS_SUCCESS;
}

sx_status_t sx_cos_port_buff_type_serialize_params(sx_api_cos_buff_type_statistics_get_params_t *cmd_body,
                                                   uint32_t                                     *out_buffer)
{
    uint32_t i = 0, buf_loc = 0, port_index, params_index;

    SX_API_LOG_ENTER();

    if (!cmd_body) {
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (!out_buffer) {
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Write the command ID and array size */
    out_buffer[buf_loc++] = cmd_body->cmd;
    out_buffer[buf_loc++] = cmd_body->statistics_cnt;
    out_buffer[buf_loc++] = cmd_body->usage_cnt;

    /* Write the statistic_param list - port count */
    for (i = 0; i < cmd_body->statistics_cnt; i++, buf_loc++) {
        out_buffer[buf_loc] = cmd_body->statistics_params_port_cnt_list[i];
    }

    /* Write the statistic_param list - Union count */
    for (i = 0; i < cmd_body->statistics_cnt; i++, buf_loc++) {
        out_buffer[buf_loc] = cmd_body->statistics_params_union_cnt_list[i];
    }

    /* Write the statistic_param_list */
    for (i = 0; i < cmd_body->statistics_cnt; i++) {
        /* Write port list */
        for (port_index = 0; port_index < cmd_body->statistic_param_list[i].port_cnt; port_index++, buf_loc++) {
            out_buffer[buf_loc] = cmd_body->statistic_param_list[i].log_port_list_p[port_index];
        }

        /* Write the port count */
        out_buffer[buf_loc] = cmd_body->statistic_param_list[i].port_cnt;
        buf_loc++;

        /* Write the port params type */
        out_buffer[buf_loc] = cmd_body->statistic_param_list[i].sx_port_params.port_params_type;
        buf_loc++;

        /* Write the port params count */
        out_buffer[buf_loc] = cmd_body->statistic_param_list[i].sx_port_params.port_params_cnt;
        buf_loc++;

        /* Write the port params union */
        for (params_index = 0;
             params_index < cmd_body->statistic_param_list[i].sx_port_params.port_params_cnt;
             params_index++, buf_loc++) {
            if (cmd_body->statistic_param_list[i].sx_port_params.port_param.port_pg_list_p) {
                if ((SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E ==
                     cmd_body->statistic_param_list[i].sx_port_params.port_params_type) ||
                    (SX_COS_MULTICAST_ATTR_E ==
                     cmd_body->statistic_param_list[i].sx_port_params.port_params_type) ||
                    (SX_COS_EGRESS_PORT_TRAFFIC_CLASS_DESC_ATTR_E ==
                     cmd_body->statistic_param_list[i].sx_port_params.port_params_type)) {
                    out_buffer[buf_loc] =
                        (uint32_t)cmd_body->statistic_param_list[i].sx_port_params.port_param.mc_switch_prio[
                            params_index];
                } else {
                    out_buffer[buf_loc] =
                        cmd_body->statistic_param_list[i].sx_port_params.port_param.port_pg_list_p[params_index];
                }
            }
        }
    }

    /* Write the usage_list */
    for (i = 0; i < cmd_body->usage_cnt; i++) {
        out_buffer[buf_loc] = cmd_body->usage_list[i].log_port;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].sx_port_params.port_params_type;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].sx_port_params.port_param.port_pg;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].statistics.curr_occupancy;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].statistics.watermark;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].shared_headroom_usage.curr_occupancy;
        buf_loc++;
        out_buffer[buf_loc] = cmd_body->usage_list[i].shared_headroom_usage.watermark;
        buf_loc++;
    }

    SX_API_LOG_EXIT();

    return SX_STATUS_SUCCESS;
}

sx_status_t sx_cos_port_buff_type_deserialize_params(uint32_t                                     *in_buffer,
                                                     sx_api_cos_buff_type_statistics_get_params_t *out_cmd_body)
{
    uint32_t i = 0, buf_loc = 0, port_index, params_index;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (!out_cmd_body) {
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Write the command ID and array size */
    out_cmd_body->cmd = in_buffer[buf_loc++];
    out_cmd_body->statistics_cnt = in_buffer[buf_loc++];
    out_cmd_body->usage_cnt = in_buffer[buf_loc++];

    /* Write the 2 * counters list */
    for (i = 0; i < out_cmd_body->statistics_cnt; i++, buf_loc++) {
        out_cmd_body->statistics_params_port_cnt_list[i] = in_buffer[buf_loc];
    }
    for (i = 0; i < out_cmd_body->statistics_cnt; i++, buf_loc++) {
        out_cmd_body->statistics_params_union_cnt_list[i] = in_buffer[buf_loc];
    }

    /* Write the statistic_param_list */
    for (i = 0; i < out_cmd_body->statistics_cnt; i++) {
        /* Write the port list */
        for (port_index = 0; port_index < out_cmd_body->statistics_params_port_cnt_list[i]; port_index++, buf_loc++) {
            out_cmd_body->statistic_param_list[i].log_port_list_p[port_index] = in_buffer[buf_loc];
        }

        /* Write the port count */
        out_cmd_body->statistic_param_list[i].port_cnt = in_buffer[buf_loc];
        buf_loc++;

        /* Write the port params type */
        out_cmd_body->statistic_param_list[i].sx_port_params.port_params_type = in_buffer[buf_loc];
        buf_loc++;

        /* Write the port params count */
        out_cmd_body->statistic_param_list[i].sx_port_params.port_params_cnt = in_buffer[buf_loc];
        buf_loc++;

        /* Write the port params UNION */
        for (params_index = 0;
             params_index < out_cmd_body->statistics_params_union_cnt_list[i];
             params_index++, buf_loc++) {
            if (out_cmd_body->statistic_param_list[i].sx_port_params.port_param.port_pg_list_p) {
                if ((SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E ==
                     out_cmd_body->statistic_param_list[i].sx_port_params.port_params_type) ||
                    (SX_COS_MULTICAST_ATTR_E ==
                     out_cmd_body->statistic_param_list[i].sx_port_params.port_params_type) ||
                    (SX_COS_EGRESS_PORT_TRAFFIC_CLASS_DESC_ATTR_E ==
                     out_cmd_body->statistic_param_list[i].sx_port_params.port_params_type)) {
                    out_cmd_body->statistic_param_list[i].sx_port_params.port_param.mc_switch_prio[params_index] =
                        (uint8_t)in_buffer[buf_loc];
                } else {
                    out_cmd_body->statistic_param_list[i].sx_port_params.port_param.port_pg_list_p[params_index] =
                        in_buffer[buf_loc];
                }
            }
        }
    }

    /* Write the usage_list */
    for (i = 0; i < out_cmd_body->usage_cnt; i++) {
        out_cmd_body->usage_list[i].log_port = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].sx_port_params.port_params_type = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].sx_port_params.port_param.port_pg = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].statistics.curr_occupancy = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].statistics.watermark = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].shared_headroom_usage.curr_occupancy = in_buffer[buf_loc];
        buf_loc++;
        out_cmd_body->usage_list[i].shared_headroom_usage.watermark = in_buffer[buf_loc];
        buf_loc++;
    }


    SX_API_LOG_EXIT();

    return SX_STATUS_SUCCESS;
}

/* Function serialize cmd_body to the buffer or calculate serialized buffer size.
 *  - If out_buffer pointer is NULL - return serialized buffer size only.
 *  - If buffer provided - serialize cmd_body and check that size is equal to the *buffer_size.
 *
 * The rules in the sequence should be in a consistent layout:
 * [params_header | offsets_array | rules_array], where rule = [rule_header | keys_arr | action_array]
 */
sx_status_t sx_api_serialize_flex_acl_rule_set_params(sx_api_flex_acl_rules_set_params_t *cmd_body,
                                                      uint8_t                            *out_buffer,
                                                      uint32_t                           *buffer_size,
                                                      rule_get_cmd_e                      get_cmd)
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    sx_api_flex_acl_rules_set_params_internal_t *params = NULL;
    sx_api_flex_acl_rule_header_t               *rule_header = NULL;
    uint8_t                                     *current_p = out_buffer;
    uint32_t                                     total_size = 0, i = 0;
    uint32_t                                     key_arr_size = 0, action_arr_size = 0;
    uint32_t                                     rules_alignment_bytes = 0;

    SX_API_LOG_ENTER();

    if (!cmd_body) {
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Copy parameters header */
    if (out_buffer != NULL) {
        if (*buffer_size < sizeof(sx_api_flex_acl_rules_set_params_internal_t)) {
            SX_LOG_ERR("The provided buffer size[%u] are not fit\n", *buffer_size);
            goto out;
        }
        params = (sx_api_flex_acl_rules_set_params_internal_t*)out_buffer;
        params->cmd = cmd_body->cmd;
        params->region_id = cmd_body->region_id;
        params->offset_count = cmd_body->rules_count;
        params->rules_count = cmd_body->rules_count;
        params->start_offset = cmd_body->start_offset;
        params->get_cmd = get_cmd;
    }
    SX_LOG_DBG("sx_api_serialize_flex_acl_rule_set_params cmd_body->rules_count %u\n", cmd_body->rules_count);

    /* Increase total parameters' size by the size of header and shift the pointer to the offsets list */
    total_size += offsetof(sx_api_flex_acl_rules_set_params_internal_t, offsets_list);
    current_p = (uint8_t*)params->offsets_list;

    /* If there is no offset list - nothing to do */
    if (cmd_body->offsets_list_p == NULL) {
        goto out;
    }

    /* Copy offsets list */
    if (out_buffer != NULL) {
        if (*buffer_size < (total_size + cmd_body->rules_count * sizeof(sx_acl_rule_offset_t))) {
            SX_LOG_ERR("The provided buffer size[%u] are not fit\n", *buffer_size);
            goto out;
        }
        memcpy(current_p, cmd_body->offsets_list_p, cmd_body->rules_count * sizeof(sx_acl_rule_offset_t));
    }

    /* Increase total size by size of offsets list and shift the pointer to the rules array */
    total_size += cmd_body->rules_count * sizeof(sx_acl_rule_offset_t);
    current_p += cmd_body->rules_count * sizeof(sx_acl_rule_offset_t);

    if ((cmd_body->rules == NULL) || (cmd_body->cmd == SX_ACCESS_CMD_DELETE)) {
        if (out_buffer != NULL) {
            /* Serialization only for offsets list */
            params->rules_count = 0;
        }
        goto out;
    }

    /* Align ACL rules inside the buffer */
    if (total_size % alignof(sx_api_flex_acl_rule_t) != 0) {
        /* ACL rules are aligned by 8 bytes now. But copying this
         * data to the buffer does not take care of the alignment.
         * Thus, we artificially align buffer size and pointer for
         * correct data alignment in the buffer.
         */
        rules_alignment_bytes = alignof(sx_api_flex_acl_rule_t) - (total_size % alignof(sx_api_flex_acl_rule_t));
        total_size += rules_alignment_bytes;
        current_p += rules_alignment_bytes;
    }

    /* Copy rules to the out buffer */
    for (i = 0; i < cmd_body->rules_count; i++) {
        key_arr_size = 0;
        action_arr_size = 0;

        if (out_buffer != NULL) {
            /* Copy the ACL rule header */
            if (*buffer_size < (total_size + sizeof(sx_api_flex_acl_rule_header_t))) {
                SX_LOG_ERR("The provided buffer size[%u] does not fit ACL rule\n", *buffer_size);
                goto out;
            }

            rule_header = (sx_api_flex_acl_rule_header_t*)current_p;
            rule_header->valid = cmd_body->rules[i].valid;
            rule_header->priority = cmd_body->rules[i].priority;
            rule_header->key_desc_count = cmd_body->rules[i].key_desc_count;
            rule_header->action_count = cmd_body->rules[i].action_count;
        }

        current_p += sizeof(sx_api_flex_acl_rule_header_t);

        if (cmd_body->rules[i].key_desc_list_p != NULL) {
            /* Copy the ACL rule key descriptors */
            key_arr_size = sizeof(sx_flex_acl_key_desc_t) * cmd_body->rules[i].key_desc_count;

            if (out_buffer != NULL) {
                if (*buffer_size < (total_size + sizeof(sx_api_flex_acl_rule_header_t) + key_arr_size)) {
                    SX_LOG_ERR("The provided buffer size[%u] does not fit ACL rule\n", *buffer_size);
                    goto out;
                }
                memcpy(current_p, cmd_body->rules[i].key_desc_list_p, key_arr_size);
            }

            current_p += key_arr_size;
        }

        if (cmd_body->rules[i].action_list_p != NULL) {
            /* Copy the ACL rule actions */
            action_arr_size = sizeof(sx_flex_acl_flex_action_t) * cmd_body->rules[i].action_count;

            if (out_buffer != NULL) {
                if (*buffer_size <
                    (total_size + sizeof(sx_api_flex_acl_rule_header_t) + key_arr_size + action_arr_size)) {
                    SX_LOG_ERR("The provided buffer size[%u] does not fit ACL rule\n", *buffer_size);
                    goto out;
                }
                memcpy(current_p, cmd_body->rules[i].action_list_p, action_arr_size);
            }

            current_p += action_arr_size;
        }

        /* Increase total buffer size by ACL rule header, keys and actions */
        total_size += sizeof(sx_api_flex_acl_rule_header_t) + key_arr_size + action_arr_size;
    }

    SX_LOG_DBG("sx_api_serialize_flex_acl_rule_set_params end of serialize: total_size  %u\n", total_size);

out:
    if (params != NULL) {
        params->total_rules_size = total_size;
    } else {
        *buffer_size = total_size;
    }
    SX_API_LOG_EXIT();
    return rc;
}

/* The function deserializes in_buffer into the rules params.
 * The out_cmd_body should hold key_desc_count and actions_count of target rules.
 * If out_cmd_body inner arrays are null - only counters will be updated
 */
sx_status_t sx_api_deserialize_flex_acl_rule_set_params(uint8_t                            *in_buffer,
                                                        sx_api_flex_acl_rules_set_params_t *out_cmd_body,
                                                        uint32_t                           *buffer_size,
                                                        rule_get_cmd_e                      get_cmd,
                                                        uint32_t                            max_num_key_desc)
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    sx_api_flex_acl_rules_set_params_internal_t *params = (sx_api_flex_acl_rules_set_params_internal_t*)in_buffer;
    sx_api_flex_acl_rule_header_t               *rule_header = NULL;
    uint8_t                                     *current_p = in_buffer;
    uint32_t                                     total_size = 0, i = 0;
    uint32_t                                     key_arr_size = 0, action_arr_size = 0;
    uint16_t                                     in_rules_cnt = 0;
    uint32_t                                     rules_alignment_bytes = 0;


    SX_API_LOG_ENTER();

    if (!in_buffer) {
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!out_cmd_body) {
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Copy the header and const objects */
    SX_LOG_DBG("DEBUG 1 RULES params->rules_count  %u\n", params->rules_count);
    in_rules_cnt = out_cmd_body->rules_count;
    out_cmd_body->cmd = params->cmd;
    out_cmd_body->region_id = params->region_id;
    out_cmd_body->rules_count = params->rules_count;
    out_cmd_body->start_offset = params->start_offset;

    /* Increase total parameters' size by the size of header and shift the pointer to the offsets list */
    total_size += offsetof(sx_api_flex_acl_rules_set_params_internal_t, offsets_list);
    current_p += offsetof(sx_api_flex_acl_rules_set_params_internal_t, offsets_list);

    /* If no rules allocated in params we return just counters */
    if ((out_cmd_body->offsets_list_p == NULL) || (params->offset_count == 0)) {
        goto out;
    }

    /* Copy rules offsets from the in_buffer to the out_cmd_body */
    if (in_rules_cnt < params->offset_count) {
        SX_LOG_ERR("The expected offset count[%u] is less than real[%u]\n", in_rules_cnt, params->offset_count);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    memcpy(out_cmd_body->offsets_list_p, current_p, params->offset_count * sizeof(sx_acl_rule_offset_t));

    /* Increase total size by size of offsets list and shift the pointer to the rules array */
    total_size += params->offset_count * sizeof(sx_acl_rule_offset_t);
    current_p += params->offset_count * sizeof(sx_acl_rule_offset_t);

    /* If there are no rules - return offsets list with rules count updated to offsets count */
    if ((out_cmd_body->rules == NULL) || (params->rules_count == 0)) {
        out_cmd_body->rules_count = params->offset_count;
        goto out;
    }

    /* Check rules number fit the buffer */
    if (in_rules_cnt < params->rules_count) {
        SX_LOG_ERR("The expected rules count[%u] is less than real[%u]\n", in_rules_cnt, params->rules_count);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_LOG_DBG("DEBUG 2 RULES out_cmd_body->rules_count  %u\n", out_cmd_body->rules_count);

    /* Align ACL rules inside the buffer */
    if (total_size % alignof(sx_api_flex_acl_rule_t) != 0) {
        /* ACL rules are aligned by 8 bytes now. But copying this
         * data to the buffer does not take care of the alignment.
         * Thus, we artificially align buffer size and pointer for
         * correct data alignment in the buffer.
         */
        rules_alignment_bytes = alignof(sx_api_flex_acl_rule_t) - (total_size % alignof(sx_api_flex_acl_rule_t));
        total_size += rules_alignment_bytes;
        current_p += rules_alignment_bytes;
    }

    for (i = 0; i < params->rules_count; i++) {
        /* Copy ACL rule header */
        rule_header = (sx_api_flex_acl_rule_header_t*)current_p;
        if (rule_header->key_desc_count > max_num_key_desc) {
            SX_LOG_ERR("Rule (offset [%d]) requires more keys [%d] than exist in region's key handle [%d] \n",
                       i, rule_header->key_desc_count, max_num_key_desc);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        out_cmd_body->rules[i].key_desc_count = rule_header->key_desc_count;
        out_cmd_body->rules[i].action_count = rule_header->action_count;
        out_cmd_body->rules[i].valid = rule_header->valid;
        out_cmd_body->rules[i].priority = rule_header->priority;

        /* Increase total buffer size by the size of ACL rule header and shift pointer */
        total_size += sizeof(sx_api_flex_acl_rule_header_t);
        current_p += sizeof(sx_api_flex_acl_rule_header_t);

        /* Copy ACL keys from the buffer */
        key_arr_size = sizeof(sx_flex_acl_key_desc_t) * rule_header->key_desc_count;

        if ((rule_header->key_desc_count != 0) && (out_cmd_body->rules[i].key_desc_list_p != NULL)) {
            if (out_cmd_body->rules[i].key_desc_count < rule_header->key_desc_count) {
                SX_LOG_ERR("the key desc count exceeds range\n");
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            memcpy(out_cmd_body->rules[i].key_desc_list_p, current_p, key_arr_size);
        }

        if (get_cmd == RULES_GET_FULL_E) {
            /* If get full - the inner arrays have weight */
            total_size += key_arr_size;
            current_p += key_arr_size;
        }

        /* Copy ACL actions from the buffer */
        action_arr_size = sizeof(sx_flex_acl_flex_action_t) * rule_header->action_count;

        if ((rule_header->action_count != 0) && (out_cmd_body->rules[i].action_list_p != NULL)) {
            if (out_cmd_body->rules[i].action_count < rule_header->action_count) {
                SX_LOG_ERR("the actions count exceeds range\n");
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            memcpy(out_cmd_body->rules[i].action_list_p, current_p, action_arr_size);
        }

        if (get_cmd == RULES_GET_FULL_E) {
            /* If full rules - increase ptr and size with size of array */
            total_size += action_arr_size;
            current_p += action_arr_size;
        }
    }

    /* Check received buffer is fully proceed */
    if (params->total_rules_size != total_size) {
        SX_LOG_ERR("Error in deserialization, expected[%u] != real[%u]\n", params->total_rules_size,
                   total_size);
        rc = SX_STATUS_ERROR;
    }

out:
    *buffer_size = total_size;
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_serialize_slot_info_get_params(sx_mgmt_slot_info_get_params_t *cmd_body_p,
                                                  uint8_t                        *out_buffer,
                                                  uint32_t                        buffer_size)
{
    sx_mgmt_slot_info_get_params_t *cmd_buffer_p = (sx_mgmt_slot_info_get_params_t*)out_buffer;
    uint32_t                        total_size = 0, i = 0;
    uint8_t                        *current_p = out_buffer;
    sx_status_t                     rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    total_size = sizeof(sx_mgmt_slot_info_get_params_t) +
                 cmd_body_p->slot_list_size * sizeof(sx_slot_id_t) +
                 cmd_body_p->slot_list_size * sizeof(sx_mgmt_slot_info_t);
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("The provided buffer size[%u] does not fit total size [%u]\n", buffer_size, total_size);
        goto out;
    }

    cmd_buffer_p->slot_list_size = cmd_body_p->slot_list_size;
    cmd_buffer_p->slot_count = cmd_body_p->slot_count;

    current_p += offsetof(sx_mgmt_slot_info_get_params_t, slot_id_list_p);
    /* Write the slot id list */
    for (i = 0; i < cmd_body_p->slot_list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->slot_id_list_p[i], sizeof(cmd_body_p->slot_id_list_p[i]));
        current_p += sizeof(cmd_body_p->slot_id_list_p[i]);
    }

    /* Write the slot info list */
    for (i = 0; i < cmd_body_p->slot_list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->slot_info_list_p[i], sizeof(cmd_body_p->slot_info_list_p[i]));
        current_p += sizeof(cmd_body_p->slot_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_deserialize_slot_info_get_params(uint8_t * in_buffer, sx_mgmt_slot_info_get_params_t *out_cmd_body)
{
    sx_mgmt_slot_info_get_params_t *cmd_buffer_p = (sx_mgmt_slot_info_get_params_t*)in_buffer;
    uint32_t                        i = 0;
    uint8_t                        *current_p = in_buffer;
    sx_status_t                     rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body->slot_list_size = cmd_buffer_p->slot_list_size;
    out_cmd_body->slot_count = cmd_buffer_p->slot_count;

    /* Write the slot id list */
    current_p += offsetof(sx_mgmt_slot_info_get_params_t, slot_id_list_p);
    for (i = 0; i < out_cmd_body->slot_list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->slot_id_list_p[i], current_p, sizeof(out_cmd_body->slot_id_list_p[i]));
        current_p += sizeof(out_cmd_body->slot_id_list_p[i]);
    }

    /* Write the slot info list */
    for (i = 0; i < out_cmd_body->slot_list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->slot_info_list_p[i], current_p, sizeof(out_cmd_body->slot_info_list_p[i]));
        current_p += sizeof(out_cmd_body->slot_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_serialize_slot_state_info_get_params(sx_mgmt_slot_state_info_get_params_t *cmd_body_p,
                                                        uint8_t                              *out_buffer,
                                                        uint32_t                              buffer_size)
{
    sx_mgmt_slot_state_info_get_params_t *cmd_buffer_p = (sx_mgmt_slot_state_info_get_params_t*)out_buffer;
    uint32_t                              total_size = 0, i = 0;
    uint8_t                              *current_p = out_buffer;
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    /* check if there is enough space in buffer */
    total_size = sizeof(sx_mgmt_slot_state_info_get_params_t) +
                 cmd_body_p->slot_list_size * sizeof(sx_slot_id_t) +
                 cmd_body_p->slot_list_size * sizeof(sx_mgmt_slot_state_info_t);
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("The provided buffer size[%u] does not fit total size [%u]\n", buffer_size, total_size);
        goto out;
    }

    cmd_buffer_p->slot_list_size = cmd_body_p->slot_list_size;
    cmd_buffer_p->slot_count = cmd_body_p->slot_count;

    /* Write the slot id list */
    current_p += offsetof(sx_mgmt_slot_state_info_get_params_t, slot_id_list_p);
    for (i = 0; i < cmd_body_p->slot_list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->slot_id_list_p[i], sizeof(cmd_body_p->slot_id_list_p[i]));
        current_p += sizeof(cmd_body_p->slot_id_list_p[i]);
    }

    /* Write the slot state info list */
    for (i = 0; i < cmd_body_p->slot_list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->slot_state_info_list_p[i],
                       sizeof(cmd_body_p->slot_state_info_list_p[i]));
        current_p += sizeof(cmd_body_p->slot_state_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_deserialize_slot_state_info_get_params(uint8_t                             * in_buffer,
                                                          sx_mgmt_slot_state_info_get_params_t *out_cmd_body)
{
    sx_mgmt_slot_state_info_get_params_t *cmd_buffer_p = (sx_mgmt_slot_state_info_get_params_t*)in_buffer;
    uint32_t                              i = 0;
    uint8_t                              *current_p = in_buffer;
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body->slot_list_size = cmd_buffer_p->slot_list_size;
    out_cmd_body->slot_count = cmd_buffer_p->slot_count;

    /* Write the slot id list */
    current_p += offsetof(sx_mgmt_slot_state_info_get_params_t, slot_id_list_p);
    for (i = 0; i < out_cmd_body->slot_list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->slot_id_list_p[i], current_p, sizeof(out_cmd_body->slot_id_list_p[i]));
        current_p += sizeof(out_cmd_body->slot_id_list_p[i]);
    }

    /* Write the slot state info list */
    for (i = 0; i < out_cmd_body->slot_list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->slot_state_info_list_p[i], current_p,
                       sizeof(out_cmd_body->slot_state_info_list_p[i]));
        current_p += sizeof(out_cmd_body->slot_state_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_serialize_slot_ini_oper_set_params(sx_mgmt_slot_ini_operation_set_params_t *cmd_body_p,
                                                      uint8_t                                 *out_buffer,
                                                      uint32_t                                 buffer_size)
{
    sx_mgmt_slot_ini_operation_set_params_t *cmd_buffer_p = (sx_mgmt_slot_ini_operation_set_params_t*)out_buffer;
    uint32_t                                 total_size = 0, i = 0, list_size = 0;
    uint8_t                                 *current_p = out_buffer;
    sx_status_t                              rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }

    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    list_size = cmd_body_p->ini_operation_result.port_info.port_attr_list_size;
    total_size = sizeof(sx_mgmt_slot_ini_operation_set_params_t) +
                 (list_size * sizeof(sx_port_attributes_t));
    /* Check if there is enough buffer size */
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("The provided buffer size[%u] does not fit total size [%u] \n", buffer_size, total_size);
        goto out;
    }

    cmd_buffer_p->slot_id = cmd_body_p->slot_id;
    cmd_buffer_p->operation = cmd_body_p->operation;

    current_p += offsetof(sx_mgmt_slot_ini_operation_set_params_t, ini_operation_result);

    cmd_buffer_p->ini_operation_result.ini_status = cmd_body_p->ini_operation_result.ini_status;
    cmd_buffer_p->ini_operation_result.slot_state_info = cmd_body_p->ini_operation_result.slot_state_info;

    current_p += offsetof(sx_mgmt_slot_ini_operation_result_t, port_info);

    cmd_buffer_p->ini_operation_result.port_info.port_attr_list_size =
        cmd_body_p->ini_operation_result.port_info.port_attr_list_size;
    cmd_buffer_p->ini_operation_result.port_info.port_count = cmd_body_p->ini_operation_result.port_info.port_count;

    current_p += offsetof(sx_mgmt_slot_port_change_info_t, port_attr_list_p);
    /* Write the port attribute list */
    for (i = 0; i < cmd_body_p->ini_operation_result.port_info.port_attr_list_size; i++) {
        SX_MEM_CPY_BUF(current_p,
                       &cmd_body_p->ini_operation_result.port_info.port_attr_list_p[i],
                       sizeof(cmd_body_p->ini_operation_result.port_info.port_attr_list_p[i]));
        current_p += sizeof(cmd_body_p->ini_operation_result.port_info.port_attr_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_deserialize_slot_ini_oper_set_params(uint8_t                                * in_buffer,
                                                        sx_mgmt_slot_ini_operation_set_params_t *out_cmd_body)
{
    sx_mgmt_slot_ini_operation_set_params_t *cmd_buffer_p = (sx_mgmt_slot_ini_operation_set_params_t*)in_buffer;
    uint32_t                                 i = 0;
    uint8_t                                 *current_p = in_buffer;
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    uint32_t                                 attr_list_size = 0;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body->slot_id = cmd_buffer_p->slot_id;
    out_cmd_body->operation = cmd_buffer_p->operation;

    current_p += offsetof(sx_mgmt_slot_ini_operation_set_params_t, ini_operation_result);

    out_cmd_body->ini_operation_result.ini_status = cmd_buffer_p->ini_operation_result.ini_status;
    out_cmd_body->ini_operation_result.slot_state_info = cmd_buffer_p->ini_operation_result.slot_state_info;


    current_p += offsetof(sx_mgmt_slot_ini_operation_result_t, port_info);

    out_cmd_body->ini_operation_result.port_info.port_attr_list_size =
        cmd_buffer_p->ini_operation_result.port_info.port_attr_list_size;
    out_cmd_body->ini_operation_result.port_info.port_count = cmd_buffer_p->ini_operation_result.port_info.port_count;

    current_p += offsetof(sx_mgmt_slot_port_change_info_t, port_attr_list_p);

    attr_list_size = out_cmd_body->ini_operation_result.port_info.port_attr_list_size;
    /* Write the port attribute list */
    for (i = 0; i < attr_list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->ini_operation_result.port_info.port_attr_list_p[i],
                       current_p,
                       sizeof(out_cmd_body->ini_operation_result.port_info.port_attr_list_p[i]));
        current_p += sizeof(out_cmd_body->ini_operation_result.port_info.port_attr_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_serialize_phy_module_info_get_params(sx_mgmt_phy_module_info_get_params_t *cmd_body_p,
                                                        uint8_t                              *out_buffer,
                                                        uint32_t                              buffer_size)
{
    sx_mgmt_phy_module_info_get_params_t *cmd_buffer_p = (sx_mgmt_phy_module_info_get_params_t*)out_buffer;
    uint32_t                              total_size = 0, i = 0;
    uint8_t                              *current_p = out_buffer;
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    /* Check if there is enough buffer size */
    total_size = sizeof(sx_mgmt_phy_module_info_get_params_t) +
                 (cmd_body_p->list_size * sizeof(sx_mgmt_module_id_info_t)) +
                 (cmd_body_p->list_size * sizeof(sx_mgmt_phy_module_info_t));
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Serialize phy module info failed, provided buffer size[%u] does not fit total size[%u]\n",
                   buffer_size,
                   total_size);
        goto out;
    }

    cmd_buffer_p->list_size = cmd_body_p->list_size;

    current_p += offsetof(sx_mgmt_phy_module_info_get_params_t, module_id_info_list_p);
    /* Write the module id info list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->module_id_info_list_p[i], sizeof(cmd_body_p->module_id_info_list_p[i]));
        current_p += sizeof(cmd_body_p->module_id_info_list_p[i]);
    }

    /* Write the module id info list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->module_info_list_p[i], sizeof(cmd_body_p->module_info_list_p[i]));
        current_p += sizeof(cmd_body_p->module_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_deserialize_phy_module_info_get_params(uint8_t                             * in_buffer,
                                                          sx_mgmt_phy_module_info_get_params_t *out_cmd_body)
{
    sx_mgmt_phy_module_info_get_params_t *cmd_buffer_p = (sx_mgmt_phy_module_info_get_params_t*)in_buffer;
    uint32_t                              i = 0;
    uint8_t                              *current_p = in_buffer;
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body->list_size = cmd_buffer_p->list_size;

    /* Write the module id info list */
    current_p += offsetof(sx_mgmt_phy_module_info_get_params_t, module_id_info_list_p);
    for (i = 0; i < out_cmd_body->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->module_id_info_list_p[i], current_p,
                       sizeof(out_cmd_body->module_id_info_list_p[i]));
        current_p += sizeof(out_cmd_body->module_id_info_list_p[i]);
    }

    /* Write the module info list */
    for (i = 0; i < out_cmd_body->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->module_info_list_p[i], current_p, sizeof(out_cmd_body->module_info_list_p[i]));
        current_p += sizeof(out_cmd_body->module_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_serialize_log_port_info_get_params(sx_mgmt_port_info_get_params_t *cmd_body_p,
                                                      uint8_t                        *out_buffer,
                                                      uint32_t                        buffer_size)
{
    sx_mgmt_port_info_get_params_t *cmd_buffer_p = (sx_mgmt_port_info_get_params_t*)out_buffer;
    uint32_t                        total_size = 0, i = 0;
    uint8_t                        *current_p = out_buffer;
    sx_status_t                     rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    /* Check if there is enough buffer size */
    total_size = sizeof(sx_mgmt_port_info_get_params_t) +
                 (cmd_body_p->list_size * sizeof(sx_port_log_id_t)) +
                 (cmd_body_p->list_size * sizeof(sx_mgmt_port_info_t));
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Serialize log port info failed, provided buffer size[%u] does not fit total size [%u]\n",
                   buffer_size,
                   total_size);
        goto out;
    }

    cmd_buffer_p->list_size = cmd_body_p->list_size;

    current_p += offsetof(sx_mgmt_port_info_get_params_t, log_port_list_p);
    /* Write the log port list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->log_port_list_p[i], sizeof(cmd_body_p->log_port_list_p[i]));
        current_p += sizeof(cmd_body_p->log_port_list_p[i]);
    }

    /* Write the log port info list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->log_port_info_list_p[i], sizeof(cmd_body_p->log_port_info_list_p[i]));
        current_p += sizeof(cmd_body_p->log_port_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_deserialize_log_port_info_get_params(uint8_t                       * in_buffer,
                                                        sx_mgmt_port_info_get_params_t *out_cmd_body)
{
    sx_mgmt_port_info_get_params_t *cmd_buffer_p = (sx_mgmt_port_info_get_params_t*)in_buffer;
    uint32_t                        i = 0;
    uint8_t                        *current_p = in_buffer;
    sx_status_t                     rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body->list_size = cmd_buffer_p->list_size;
    current_p += offsetof(sx_mgmt_port_info_get_params_t, log_port_list_p);

    /* Write the log port list */
    for (i = 0; i < out_cmd_body->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->log_port_list_p[i], current_p, sizeof(out_cmd_body->log_port_list_p[i]));
        current_p += sizeof(out_cmd_body->log_port_list_p[i]);
    }

    /* Write the log port info list */
    for (i = 0; i < out_cmd_body->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body->log_port_info_list_p[i], current_p,
                       sizeof(out_cmd_body->log_port_info_list_p[i]));
        current_p += sizeof(out_cmd_body->log_port_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_serialize_temp_sensor_get_params(sx_mgmt_temp_sensor_get_params_t *cmd_body_p,
                                                    uint8_t                          *out_buffer,
                                                    uint32_t                          buffer_size)
{
    sx_mgmt_temp_sensor_get_params_t *cmd_buffer_p = (sx_mgmt_temp_sensor_get_params_t*)out_buffer;
    uint32_t                          total_size = 0, i = 0;
    uint8_t                          *current_p = out_buffer;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    /* Check if there is enough buffer size */
    total_size = sizeof(sx_mgmt_temp_sensor_get_params_t) +
                 (cmd_body_p->list_size * sizeof(sx_sensor_id_t)) +
                 (cmd_body_p->list_size * sizeof(sx_mgmt_temp_sensor_info_t));
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Serialize temp sensor get params failed, provided buffer size[%u] does not fit total size [%u]\n",
                   buffer_size,
                   total_size);
        goto out;
    }

    cmd_buffer_p->cmd = cmd_body_p->cmd;
    cmd_buffer_p->slot_id = cmd_body_p->slot_id;
    cmd_buffer_p->list_size = cmd_body_p->list_size;

    current_p += offsetof(sx_mgmt_temp_sensor_get_params_t, sensor_id_list_p);
    /* Write the sensor id list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->sensor_id_list_p[i], sizeof(cmd_body_p->sensor_id_list_p[i]));
        current_p += sizeof(cmd_body_p->sensor_id_list_p[i]);
    }

    /* Write the temp sensor info list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->temp_sensor_info_list_p[i],
                       sizeof(cmd_body_p->temp_sensor_info_list_p[i]));
        current_p += sizeof(cmd_body_p->temp_sensor_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_deserialize_temp_sensor_get_params(uint8_t                         * in_buffer,
                                                      sx_mgmt_temp_sensor_get_params_t *out_cmd_body_p)
{
    sx_mgmt_temp_sensor_get_params_t *cmd_buffer_p = (sx_mgmt_temp_sensor_get_params_t*)in_buffer;
    uint32_t                          i = 0;
    uint8_t                          *current_p = in_buffer;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body_p->cmd = cmd_buffer_p->cmd;
    out_cmd_body_p->slot_id = cmd_buffer_p->slot_id;
    out_cmd_body_p->list_size = cmd_buffer_p->list_size;
    current_p += offsetof(sx_mgmt_temp_sensor_get_params_t, sensor_id_list_p);

    /* Write the sensor id list */
    for (i = 0; i < out_cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body_p->sensor_id_list_p[i], current_p, sizeof(out_cmd_body_p->sensor_id_list_p[i]));
        current_p += sizeof(out_cmd_body_p->sensor_id_list_p[i]);
    }

    /* Write the temp sensor info list */
    for (i = 0; i < out_cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body_p->temp_sensor_info_list_p[i], current_p,
                       sizeof(out_cmd_body_p->temp_sensor_info_list_p[i]));
        current_p += sizeof(out_cmd_body_p->temp_sensor_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_serialize_temp_sensor_set_params(sx_mgmt_temp_sensor_set_params_t *cmd_body_p,
                                                    uint8_t                          *out_buffer,
                                                    uint32_t                          buffer_size)
{
    sx_mgmt_temp_sensor_set_params_t *cmd_buffer_p = (sx_mgmt_temp_sensor_set_params_t*)out_buffer;
    uint32_t                          total_size = 0, i = 0;
    uint8_t                          *current_p = out_buffer;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid cmd_body: cmd_body is NULL\n");
        goto out;
    }
    if (!out_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_buffer: out_buffer is NULL\n");
        goto out;
    }

    /* Check if there is enough buffer size */
    total_size = sizeof(sx_mgmt_temp_sensor_set_params_t) +
                 (cmd_body_p->list_size * sizeof(sx_sensor_id_t)) +
                 (cmd_body_p->list_size * sizeof(sx_mgmt_temp_sensor_ctrl_info_t));
    if (total_size > buffer_size) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Serialize temp sensor set params failed, provided buffer size[%u] does not fit total size [%u]\n",
                   buffer_size,
                   total_size);
        goto out;
    }

    cmd_buffer_p->cmd = cmd_body_p->cmd;
    cmd_buffer_p->slot_id = cmd_body_p->slot_id;
    cmd_buffer_p->list_size = cmd_body_p->list_size;

    current_p += offsetof(sx_mgmt_temp_sensor_set_params_t, sensor_id_list_p);
    /* Write the sensor id list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->sensor_id_list_p[i], sizeof(cmd_body_p->sensor_id_list_p[i]));
        current_p += sizeof(cmd_body_p->sensor_id_list_p[i]);
    }

    /* Write the temp sensor ctrl info list */
    for (i = 0; i < cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(current_p, &cmd_body_p->temp_sensor_ctrl_info_list_p[i],
                       sizeof(cmd_body_p->temp_sensor_ctrl_info_list_p[i]));
        current_p += sizeof(cmd_body_p->temp_sensor_ctrl_info_list_p[i]);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_deserialize_temp_sensor_set_params(uint8_t                         * in_buffer,
                                                      sx_mgmt_temp_sensor_set_params_t *out_cmd_body_p)
{
    sx_mgmt_temp_sensor_set_params_t *cmd_buffer_p = (sx_mgmt_temp_sensor_set_params_t*)in_buffer;
    uint32_t                          i = 0;
    uint8_t                          *current_p = in_buffer;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!in_buffer) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid in_buffer: in_buffer is NULL\n");
        goto out;
    }

    if (!out_cmd_body_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid out_cmd_body: out_cmd_body is NULL\n");
        goto out;
    }

    out_cmd_body_p->cmd = cmd_buffer_p->cmd;
    out_cmd_body_p->slot_id = cmd_buffer_p->slot_id;
    out_cmd_body_p->list_size = cmd_buffer_p->list_size;
    current_p += offsetof(sx_mgmt_temp_sensor_set_params_t, sensor_id_list_p);

    /* Write the sensor id list */
    for (i = 0; i < out_cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body_p->sensor_id_list_p[i], current_p, sizeof(out_cmd_body_p->sensor_id_list_p[i]));
        current_p += sizeof(out_cmd_body_p->sensor_id_list_p[i]);
    }

    /* Write the temp sensor info list */
    for (i = 0; i < out_cmd_body_p->list_size; i++) {
        SX_MEM_CPY_BUF(&out_cmd_body_p->temp_sensor_ctrl_info_list_p[i], current_p,
                       sizeof(out_cmd_body_p->temp_sensor_ctrl_info_list_p[i]));
        current_p += sizeof(out_cmd_body_p->temp_sensor_ctrl_info_list_p[i]);
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

void player_send_bpf_stub_func(IN const sx_api_command_head_t * const pCmd)
{
    UNUSED_PARAM(pCmd);
}

void player_recv_bpf_stub_func(void)
{
}
