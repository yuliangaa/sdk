/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_cos.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ SX_API_COS

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  DEFINES
 ***********************************************/

/************************************************
 *  DECLARATIONS
 ***********************************************/

/************************************************
 *  LOCAL FUNCTIONS
 ***********************************************/

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_cos_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_COS_LOG_VERBOSITY_LEVEL_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_COS_LOG_VERBOSITY_LEVEL_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_default_prio_set(const sx_api_handle_t   handle,
                                             const sx_port_log_id_t  log_port,
                                             const sx_cos_priority_t priority)
{
    sx_api_command_head_t             cmd_head;
    sx_api_cos_port_prio_set_params_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t               reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_DEFAULT_PRIO_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_port_prio_set_params_t);

    cmd_body.port_priority = priority;
    cmd_body.port_log_id = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_default_prio_get(const sx_api_handle_t  handle,
                                             const sx_port_log_id_t log_port,
                                             sx_cos_priority_t     *priority_p)
{
    sx_api_command_head_t             cmd_head;
    sx_api_cos_port_prio_get_params_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    /* pointer check */
    rc = utils_check_pointer(priority_p, "priority_p");
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_DEFAULT_PRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_port_prio_get_params_t);

    cmd_body.port_log_id = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)priority_p,
                                        sizeof(sx_cos_priority_t));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_tc_prio_map_set(const sx_api_handle_t        handle,
                                            const sx_access_cmd_t        cmd,
                                            const sx_port_log_id_t       log_port,
                                            const sx_cos_priority_t      priority,
                                            const sx_cos_traffic_class_t traffic_class)
{
    sx_api_command_head_t           cmd_head;
    sx_api_cos_tc_prio_map_params_t cmd_body;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t             reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_TC_PRIO_MAP_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_tc_prio_map_params_t);

    cmd_body.access_cmd = cmd;
    cmd_body.port_log_id = log_port;
    cmd_body.port_priority = priority;
    cmd_body.traffic_class = traffic_class;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_tc_prio_map_get(const sx_api_handle_t   handle,
                                            const sx_port_log_id_t  log_port,
                                            const sx_cos_priority_t priority,
                                            sx_cos_traffic_class_t *traffic_class_p)
{
    sx_api_command_head_t               cmd_head;
    sx_api_cos_tc_prio_map_get_params_t cmd_body;
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                 reply_head;
    sx_status_t                         rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    /* pointer check */
    rc = utils_check_pointer(traffic_class_p, "traffic_class_p");
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return err;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_TC_PRIO_MAP_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_tc_prio_map_get_params_t);

    cmd_body.port_log_id = log_port;
    cmd_body.port_priority = priority;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)traffic_class_p,
                                        sizeof(sx_cos_traffic_class_t));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_trust_set(const sx_api_handle_t      handle,
                                      const sx_port_log_id_t     log_port,
                                      const sx_cos_trust_level_t trust_level)
{
    sx_api_command_head_t        cmd_head;
    sx_api_cos_tc_trust_params_t cmd_body;
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t          reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_TRUST_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_tc_trust_params_t);

    cmd_body.port_log_id = log_port;
    cmd_body.trust_level = (sxd_cos_trust_level_e)trust_level;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_trust_get(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      sx_cos_trust_level_t  *trust_level_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_cos_tc_trust_get_params_t cmd_body;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    /* pointer check */
    rc = utils_check_pointer(trust_level_p, "trust_level_p");
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_TRUST_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_cos_tc_trust_get_params_t);

    cmd_body.port_log_id = log_port;

    err
        = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)trust_level_p,
                                        sizeof(sx_cos_trust_level_t));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_prio_buff_map_set(const sx_api_handle_t    handle,
                                              const sx_access_cmd_t    cmd,
                                              const sx_port_log_id_t   log_port,
                                              sx_cos_port_prio_buff_t *prio_to_buff_p)
{
    sx_status_t                           api_rc = SX_STATUS_SUCCESS;
    uint32_t                              i;
    uint32_t                              cmd_size = sizeof(sx_api_cos_port_buff_map_set_params_t);
    sx_api_cos_port_buff_map_set_params_t cmd_body;
    sx_api_int_cmd_e                      int_cmd = SX_API_INT_CMD_COS_PORT_PRIO_BUFF_MAP_SET_E;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_api_cos_port_buff_map_set_params_t);

    /* IN param validation */
    if (cmd != SX_ACCESS_CMD_SET) {
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (prio_to_buff_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    for (i = 0; i < (RM_API_COS_PORT_PRIO_MAX + 1); i++) {
        if (prio_to_buff_p->prio_to_buff[i] >= (SXD_PORT_PBMC_NUM_BUFF - 2)) {
            SX_LOG_ERR("Buffer [%d] Exceeds Buffers Range [0-7] (Param Exceeds Range).\n",
                       prio_to_buff_p->prio_to_buff[i]);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
    }

    cmd_body.cmd = cmd;
    cmd_body.port_id = log_port;

    SX_MEM_CPY_ARRAY(cmd_body.prio_to_buff, prio_to_buff_p->prio_to_buff,
                     (RM_API_COS_PORT_PRIO_MAX + 1), sx_cos_port_buff_t);

    api_rc = sx_api_send_command_wrapper(handle, int_cmd,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_cos_port_prio_buff_map_get(const sx_api_handle_t    handle,
                                              const sx_port_log_id_t   log_port,
                                              sx_cos_port_prio_buff_t *prio_to_buff_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_status_t                           api_rc = SX_STATUS_SUCCESS;
    uint8_t                               i;
    sx_api_cos_port_buff_map_get_params_t cmd_body;
    sx_api_int_cmd_e                      int_cmd = SX_API_INT_CMD_COS_PORT_PRIO_BUFF_MAP_GET_E;
    uint32_t                              cmd_size = sizeof(sx_api_cos_port_buff_map_get_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_api_cos_port_buff_map_get_params_t);

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.port_id = log_port;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(prio_to_buff_p, "prio_to_buff_p - PPTB"))) {
        SX_API_LOG_EXIT();
        return rc;
    }

    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Port buffers configuration is not supported for LAG.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    api_rc = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);

    for (i = 0; i < (RM_API_COS_PORT_PRIO_MAX + 1); i++) {
        prio_to_buff_p->prio_to_buff[i] = cmd_body.prio_to_buff[i];
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_cos_shared_buff_pool_set(const sx_api_handle_t handle,
                                            const sx_access_cmd_t cmd,
                                            sx_cos_pool_attr_t   *sx_cos_pool_attr,
                                            uint32_t             *pool_id)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     cmd_size;
    sx_api_cos_pool_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (pool_id == NULL) {
        SX_LOG_ERR("NULL pool_id\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (sx_cos_pool_attr == NULL)) {
        SX_LOG_ERR("NULL sx_cos_pool_attr\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_size = sizeof(sx_api_cos_pool_set_params_t);

    if ((cmd == SX_ACCESS_CMD_DESTROY) || (cmd == SX_ACCESS_CMD_EDIT)) {
        cmd_body.pool_id = *pool_id;
    }
    cmd_body.cmd = cmd;

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        cmd_body.pool_size = sx_cos_pool_attr->pool_size;
        cmd_body.mode = sx_cos_pool_attr->mode;
        cmd_body.direction = sx_cos_pool_attr->pool_dir;
        cmd_body.buffer_type = sx_cos_pool_attr->buffer_type;
        cmd_body.infinite_size = sx_cos_pool_attr->infinite_size;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_SHARED_BUFF_POOL_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_OR_WRN(err, "sx_api_cos_pool_set failed. err: %d \n", err);
        SX_API_LOG_EXIT();
        return err;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        *pool_id = cmd_body.pool_id;
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_shared_buff_pool_get(const sx_api_handle_t handle,
                                            const uint32_t        pool_id,
                                            sx_cos_pool_attr_t  * sx_cos_pool_attr_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     cmd_size;
    sx_api_cos_pool_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (sx_cos_pool_attr_p == NULL) {
        SX_LOG_ERR("NULL sx_cos_pool_attr_p\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_size = sizeof(sx_api_cos_pool_get_params_t);
    cmd_body.pool_id = pool_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_SHARED_BUFF_POOL_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        if (err != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("sx_api_cos_pool_get failed. err: %d \n", err);
        }
        SX_API_LOG_EXIT();
        return err;
    }

    sx_cos_pool_attr_p->pool_size = cmd_body.pool_size;
    sx_cos_pool_attr_p->mode = cmd_body.mode;
    sx_cos_pool_attr_p->pool_dir = cmd_body.direction;
    sx_cos_pool_attr_p->buffer_type = cmd_body.buffer_type;
    sx_cos_pool_attr_p->infinite_size = cmd_body.infinite_size;
    sx_cos_pool_attr_p->pool_info = cmd_body.pool_info;

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_buff_type_set(const sx_api_handle_t            handle,
                                          const sx_access_cmd_t            cmd,
                                          const sx_port_log_id_t           log_port,
                                          const sx_cos_port_buffer_attr_t *port_buffer_attr_list_p,
                                          const uint32_t                   port_buffer_attr_cnt)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_api_cos_port_buffer_type_set_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_cos_port_buffer_type_set_params_t);

    SX_API_LOG_ENTER();

    if ((cmd == SX_ACCESS_CMD_SET) ||
        (cmd == SX_ACCESS_CMD_DELETE)) {
        if (0 == port_buffer_attr_cnt) {
            SX_LOG_ERR("sx_api_cos_port_buff_type_set port_buffer_attr_cnt equal to zero.\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }

        if (NULL == port_buffer_attr_list_p) {
            SX_LOG_ERR("port_buffer_attr_list_p is NULL\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
    }

    cmd_size += sizeof(sx_cos_port_buffer_attr_t) * port_buffer_attr_cnt;
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);

    if (NULL == cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_port_buffer_type_set_params_t);
    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;
    cmd_body_p->buffers_num = port_buffer_attr_cnt;

    /*Typed buffers list*/
    if ((cmd == SX_ACCESS_CMD_SET) ||
        (cmd == SX_ACCESS_CMD_DELETE)) {
        SX_MEM_CPY_ARRAY(cmd_body_p->typed_buffers_list,
                         port_buffer_attr_list_p,
                         cmd_body_p->buffers_num,
                         sx_cos_port_buffer_attr_t);
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_BUFF_TYPE_SET_E, (uint8_t*)cmd_body_p, cmd_size);

    /*Release allocated memory*/
    cl_free(cmd_body_p);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_port_buff_type_get(const sx_api_handle_t      handle,
                                          const sx_port_log_id_t     log_port,
                                          sx_cos_port_buffer_attr_t *port_buffer_attr_list_p,
                                          uint32_t                  *port_buffer_attr_cnt)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_api_cos_port_buffer_type_get_params_t *cmd_body_p = NULL;

    /* The command size is fixed since the lists are dynamically allocated*/
    uint32_t cmd_size = sizeof(sx_api_cos_port_buffer_type_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == port_buffer_attr_cnt) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    /* output list is empty and the command is not COUNT */
    if ((NULL == port_buffer_attr_list_p) && (0 != *port_buffer_attr_cnt)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }


    /*Count number of initialized buffers*/
    if (0 != *port_buffer_attr_cnt) {
        cmd_size += sizeof(sx_cos_port_buffer_attr_t) * (*port_buffer_attr_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);
    if (NULL == cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_port_buffer_type_get_params_t);

    if (0 == *port_buffer_attr_cnt) {
        cmd_body_p->cmd = SX_ACCESS_CMD_COUNT;
        port_buffer_attr_list_p = NULL;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body_p->buffers_num = *port_buffer_attr_cnt;
    cmd_body_p->log_port = log_port;
    if (NULL != port_buffer_attr_list_p) {
        SX_MEM_CPY_ARRAY(cmd_body_p->typed_buffers_list,
                         port_buffer_attr_list_p,
                         (*port_buffer_attr_cnt),
                         sx_cos_port_buffer_attr_t);
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_BUFF_TYPE_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        CL_FREE_N_NULL(cmd_body_p);
        SX_API_LOG_EXIT();
        return rc;
    }

    /*Typed buffers list*/
    if (NULL != port_buffer_attr_list_p) {
        SX_MEM_CPY_ARRAY(port_buffer_attr_list_p,
                         cmd_body_p->typed_buffers_list,
                         cmd_body_p->buffers_num,
                         sx_cos_port_buffer_attr_t);
    }

    *port_buffer_attr_cnt = cmd_body_p->buffers_num;


    /*Release allocated memory*/
    CL_FREE_N_NULL(cmd_body_p);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_port_shared_buff_type_set(const sx_api_handle_t                   handle,
                                                 const sx_access_cmd_t                   cmd,
                                                 const sx_port_log_id_t                  log_port,
                                                 const sx_cos_port_shared_buffer_attr_t *port_shared_buffer_attr_list_p,
                                                 const uint32_t                          port_shared_buffer_attr_cnt)
{
    sx_status_t                                      rc = SX_STATUS_SUCCESS;
    sx_api_cos_port_shared_buffer_type_set_params_t *cmd_body_p = NULL;
    uint32_t                                         cmd_size =
        sizeof(sx_api_cos_port_shared_buffer_type_set_params_t);

    SX_API_LOG_ENTER();

    if ((cmd == SX_ACCESS_CMD_SET) ||
        (cmd == SX_ACCESS_CMD_DELETE)) {
        if (0 == port_shared_buffer_attr_cnt) {
            SX_LOG_ERR("sx_api_cos_port_shared_buff_type_set port_buffer_attr_cnt equal to zero.\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }

        if (NULL == port_shared_buffer_attr_list_p) {
            SX_LOG_ERR("NULL port_buffer_attr_list_p\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
    }

    cmd_size += sizeof(sx_cos_port_shared_buffer_attr_t) * port_shared_buffer_attr_cnt;
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);

    if (NULL == cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_port_shared_buffer_type_set_params_t);
    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;
    cmd_body_p->buffers_num = port_shared_buffer_attr_cnt;

    /*Typed buffers list*/
    if ((cmd == SX_ACCESS_CMD_SET) ||
        (cmd == SX_ACCESS_CMD_DELETE)) {
        SX_MEM_CPY_ARRAY(cmd_body_p->typed_buffers_list,
                         port_shared_buffer_attr_list_p,
                         cmd_body_p->buffers_num,
                         sx_cos_port_shared_buffer_attr_t);
    }

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_COS_PORT_SHARED_BUFF_TYPE_SET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    /*Release allocated memory*/
    cl_free(cmd_body_p);

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_port_shared_buff_type_get(const sx_api_handle_t             handle,
                                                 const sx_port_log_id_t            log_port,
                                                 sx_cos_port_shared_buffer_attr_t *port_shared_buffer_attr_list_p,
                                                 uint32_t                         *port_shared_buffer_attr_cnt)
{
    sx_status_t                                      rc = SX_STATUS_SUCCESS;
    sx_api_cos_port_shared_buffer_type_get_params_t *cmd_body_p = NULL;

    /* The command size is fixed since the lists are dynamically allocated*/
    uint32_t cmd_size = sizeof(sx_api_cos_port_shared_buffer_type_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == port_shared_buffer_attr_cnt) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if ((NULL == port_shared_buffer_attr_list_p) && (0 != *port_shared_buffer_attr_cnt)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    /*Count number of initialized buffers*/
    if ((NULL != port_shared_buffer_attr_list_p) && (0 != *port_shared_buffer_attr_cnt)) {
        cmd_size += sizeof(sx_cos_port_shared_buffer_attr_t) * (*port_shared_buffer_attr_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);
    if (NULL == cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_port_shared_buffer_type_get_params_t);

    if (0 == *port_shared_buffer_attr_cnt) {
        cmd_body_p->cmd = SX_ACCESS_CMD_COUNT;
        port_shared_buffer_attr_list_p = NULL;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body_p->buffers_num = *port_shared_buffer_attr_cnt;
    cmd_body_p->log_port = log_port;
    SX_MEM_CPY_ARRAY(cmd_body_p->typed_buffers_list,
                     port_shared_buffer_attr_list_p,
                     (*port_shared_buffer_attr_cnt),
                     sx_cos_port_shared_buffer_attr_t);

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_COS_PORT_SHARED_BUFF_TYPE_GET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        CL_FREE_N_NULL(cmd_body_p);
        SX_API_LOG_EXIT();
        return rc;
    }

    /*Typed buffers list*/
    if (0 != *port_shared_buffer_attr_cnt) {
        SX_MEM_CPY_ARRAY(port_shared_buffer_attr_list_p,
                         cmd_body_p->typed_buffers_list,
                         cmd_body_p->buffers_num,
                         sx_cos_port_shared_buffer_attr_t);
    }

    *port_shared_buffer_attr_cnt = cmd_body_p->buffers_num;


    /*Release allocated memory*/
    CL_FREE_N_NULL(cmd_body_p);

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_buff_status_get(const sx_api_handle_t handle, sx_buffer_status_t          *status)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    sx_api_cos_buff_status_get_params_t *cmd_body_p = NULL;

    /* The command size is fixed since the lists are dynamically allocated*/
    uint32_t cmd_size = sizeof(sx_api_cos_buff_status_get_params_t);

    SX_API_LOG_ENTER();

    if (NULL == status) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);
    if (NULL == cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_buff_status_get_params_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_BUFF_STATUS_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        CL_FREE_N_NULL(cmd_body_p);
        SX_API_LOG_EXIT();
        return rc;
    }

    /*Typed buffers list*/
    if (NULL != status) {
        memcpy(status,
               &cmd_body_p->status,
               sizeof(sx_buffer_status_t));
    }

    /*Release allocated memory*/
    CL_FREE_N_NULL(cmd_body_p);

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_pools_list_get(const sx_api_handle_t handle,
                                      uint32_t             *pool_cnt,
                                      sx_cos_pool_id_t     *pool_list_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_cos_pools_list_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = 0;

    SX_API_LOG_ENTER();

    if (NULL == pool_cnt) {
        SX_LOG_ERR("Pools list length is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((NULL == pool_list_p) && (0 != *pool_cnt)) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size = sizeof(sx_api_cos_pools_list_get_params_t)
               + sizeof(sx_cos_pool_id_t) * (*pool_cnt);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_cos_pools_list_get_params_t*)cl_malloc(cmd_size);
    if (!cmd_body_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_MEMORY;
    }
    memset(cmd_body_p, 0, cmd_size);

    /* O/W: */
    if (0 == *pool_cnt) {
        cmd_body_p->cmd = SX_ACCESS_CMD_COUNT;
        pool_list_p = NULL;
    } else {
        cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    }

    cmd_body_p->pools_cnt = *pool_cnt;

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_COS_POOLS_LIST_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        if (0 != *pool_cnt) {
            SX_MEM_CPY_ARRAY(pool_list_p, cmd_body_p->pools_list,
                             *pool_cnt, sx_cos_pool_id_t);
        }
        *pool_cnt = cmd_body_p->pools_cnt;
    }

out:
    if (cmd_body_p) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_cos_port_buff_type_statistic_get(const sx_api_handle_t                   handle,
                                                    const sx_access_cmd_t                   cmd,
                                                    const sx_port_statistic_usage_params_t *statistic_param_list_p,
                                                    const uint32_t                          statistics_cnt,
                                                    sx_port_occupancy_statistics_t         *usage_list_p,
                                                    uint32_t                               *usage_cnt)
{
    sx_status_t                                  api_rc = SX_STATUS_SUCCESS;
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    sx_api_cos_buff_type_statistics_get_params_t cmd_body;
    uint32_t                                    *cmd_body_buffer = NULL;
    uint32_t                                     cmd_body_buffer_size = 0;
    uint32_t                                     cmd_size_base = 0;
    uint32_t                                     cmd_size_params = 0;
    uint32_t                                     cmd_size_usage = 0;
    uint32_t                                     cmd_size_port_count = 0;
    uint32_t                                     cmd_size_union_count = 0;
    uint32_t                                     i = 0, curr_num_usage_to_ret = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_api_cos_buff_type_statistics_get_params_t);

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command cmd = %d.\n", cmd);
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (usage_cnt == NULL) {
        SX_LOG_ERR("usage_cnt is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (statistic_param_list_p == NULL) {
        SX_LOG_ERR("statistic_param_list_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (*usage_cnt != 0) {
        if (NULL == usage_list_p) {
            SX_LOG_ERR("usage_list_p is NULL.\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
    }

    if (*usage_cnt == 0) {
        for (i = 0; i < statistics_cnt; i++) { /*Query block loop*/
            curr_num_usage_to_ret += statistic_param_list_p[i].port_cnt *
                                     statistic_param_list_p[i].sx_port_params.port_params_cnt;
        }
        *usage_cnt = curr_num_usage_to_ret;
        SX_API_LOG_EXIT();
        return rc;
    }

    /* Size calculation */
    cmd_size_base = sizeof(sx_api_cos_buff_type_statistics_get_params_t);

    for (i = 0; i < statistics_cnt; i++) {
        cmd_size_params += sizeof(sx_port_statistic_usage_params_t);
        /* port_list */
        cmd_size_params += statistic_param_list_p[i].port_cnt * sizeof(sx_port_log_id_t);
        /* Union size */
        cmd_size_params += statistic_param_list_p[i].sx_port_params.port_params_cnt * sizeof(uint32_t);
    }

    cmd_size_usage = (*usage_cnt) * sizeof(sx_port_occupancy_statistics_t);
    cmd_size_port_count = statistics_cnt * sizeof(uint32_t);
    cmd_size_union_count = statistics_cnt * sizeof(uint32_t);

    cmd_body_buffer_size = cmd_size_base + cmd_size_params + cmd_size_usage + cmd_size_port_count +
                           cmd_size_union_count;

    /* Check that API message size is not too long
     * In case it is, user should be prompted about it
     */
    rc = utils_check_msg_size((cmd_body_buffer_size + sizeof(sx_api_command_head_t)), SX_API_MESSAGE_SIZE_LIMIT);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Request to get statistics for %d elements exceeds API limits.\n", *usage_cnt);
        goto out;
    }

    cmd_body.usage_list = (sx_port_occupancy_statistics_t*)cl_malloc(cmd_size_usage);
    if (!cmd_body.usage_list) {
        SX_LOG_ERR("Failed to allocate memory for the usage_list_p.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body.statistic_param_list = (sx_port_statistic_usage_params_t*)cl_malloc(cmd_size_params);
    if (!cmd_body.statistic_param_list) {
        SX_LOG_ERR("Failed to allocate memory for the statistic_param_list_p.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body.statistics_params_port_cnt_list = (uint32_t*)cl_malloc(cmd_size_port_count);
    if (!cmd_body.statistics_params_port_cnt_list) {
        SX_LOG_ERR("Failed to allocate memory for the statistics_params_port_cnt_list.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body.statistics_params_union_cnt_list = (uint32_t*)cl_malloc(cmd_size_union_count);
    if (!cmd_body.statistics_params_union_cnt_list) {
        SX_LOG_ERR("Failed to allocate memory for the statistics_params_union_cnt_list.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.statistics_cnt = statistics_cnt;
    cmd_body.usage_cnt = *usage_cnt;

    SX_MEM_CPY_ARRAY(cmd_body.statistic_param_list,
                     statistic_param_list_p,
                     statistics_cnt,
                     sx_port_statistic_usage_params_t);

    /* Collect params 2 * count from complex structure */
    for (i = 0; i < statistics_cnt; i++) {
        cmd_body.statistics_params_port_cnt_list[i] = statistic_param_list_p[i].port_cnt;
        cmd_body.statistics_params_union_cnt_list[i] = statistic_param_list_p[i].sx_port_params.port_params_cnt;
    }

    cmd_body_buffer = (uint32_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer) {
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    memset(cmd_body_buffer, 0, cmd_body_buffer_size);

    /* Serialize */
    rc = sx_cos_port_buff_type_serialize_params(&cmd_body, cmd_body_buffer);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to sx_cos_port_buff_type_serialize_params.\n");
        goto out;
    }

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_BUFF_TYPE_STATISTIC_GET_E,
                                         (uint8_t*)cmd_body_buffer,
                                         cmd_body_buffer_size);

    /* De-Serialize */
    rc = sx_cos_port_buff_type_deserialize_params(cmd_body_buffer, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (SX_CHECK_PASS(api_rc)) {
        *usage_cnt = cmd_body.usage_cnt;
        if (NULL != usage_list_p) {
            SX_MEM_CPY_ARRAY(usage_list_p, cmd_body.usage_list,
                             *usage_cnt, sx_port_occupancy_statistics_t);
        }
    } else {
        rc = api_rc;
    }


out:
    if (cmd_body_buffer != NULL) {
        CL_FREE_N_NULL(cmd_body_buffer);
    }
    if (cmd_body.usage_list != NULL) {
        CL_FREE_N_NULL(cmd_body.usage_list);
    }
    if (cmd_body.statistic_param_list != NULL) {
        CL_FREE_N_NULL(cmd_body.statistic_param_list);
    }
    if (cmd_body.statistics_params_port_cnt_list != NULL) {
        CL_FREE_N_NULL(cmd_body.statistics_params_port_cnt_list);
    }
    if (cmd_body.statistics_params_union_cnt_list != NULL) {
        CL_FREE_N_NULL(cmd_body.statistics_params_union_cnt_list);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_cos_pool_statistic_get(const sx_api_handle_t               handle,
                                          const sx_access_cmd_t               cmd,
                                          const sx_cos_pool_id_t             *pool_id_list_p,
                                          const uint32_t                      pool_id_cnt,
                                          sx_cos_pool_occupancy_statistics_t *usage_list_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_cos_pool_statistics_get_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size, i;

    SX_API_LOG_ENTER();

    cmd_size = sizeof(sx_api_cos_pool_statistics_get_params_t);

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command cmd = %d.\n", cmd);
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (NULL == pool_id_list_p) {
        SX_LOG_ERR("NULL pool_id_list_p\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (NULL == usage_list_p) {
        SX_LOG_ERR("NULL usage_list_p\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (pool_id_cnt == 0) {
        SX_LOG_ERR("pool id count  = 0\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    cmd_size += sizeof(sx_cos_pool_occupancy_statistics_t) * pool_id_cnt;
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = cl_malloc(cmd_size);
    if (cmd_body_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for the usage_list_p.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_cos_pool_statistics_get_params_t);

    cmd_body_p->cmd = cmd;
    cmd_body_p->pool_id_cnt = pool_id_cnt;

    for (i = 0; i < pool_id_cnt; i++) {
        cmd_body_p->usage_list[i].pool_id = pool_id_list_p[i];
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_POOL_STATISTIC_GET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_ARRAY(usage_list_p,
                         cmd_body_p->usage_list,
                         cmd_body_p->pool_id_cnt,
                         sx_cos_pool_occupancy_statistics_t);
    }

    cl_free(cmd_body_p);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_cos_port_default_color_set(const sx_api_handle_t  handle,
                                              const sx_port_log_id_t log_port,
                                              const sx_cos_color_t   color)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_cos_port_default_color_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;
    cmd_body.color = color;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_DEFAULT_COLOR_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_default_color_get(const sx_api_handle_t  handle,
                                              const sx_port_log_id_t log_port,
                                              sx_cos_color_t        *color_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_cos_port_default_color_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (color_p == NULL) {
        SX_LOG_ERR("color is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_ERROR;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_DEFAULT_COLOR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (!SX_CHECK_FAIL(err)) {
        *color_p = cmd_body.color;
    }


    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_default_pcpdei_set(const sx_api_handle_t  handle,
                                               const sx_port_log_id_t log_port,
                                               const sx_cos_pcp_dei_t pcp_dei)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_cos_port_default_pcpdei_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;
    cmd_body.pcp_dei = pcp_dei;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_DEFAULT_PCPDEI_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_default_pcpdei_get(const sx_api_handle_t  handle,
                                               const sx_port_log_id_t log_port,
                                               sx_cos_pcp_dei_t      *pcp_dei_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_cos_port_default_pcpdei_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (pcp_dei_p == NULL) {
        SX_LOG_ERR("pcp_dei is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_DEFAULT_PCPDEI_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (!SX_CHECK_FAIL(err)) {
        *pcp_dei_p = cmd_body.pcp_dei;
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_pcpdei_to_prio_set(const sx_api_handle_t          handle,
                                               const sx_port_log_id_t         log_port,
                                               const sx_cos_pcp_dei_t        *pcp_dei_p,
                                               const sx_cos_priority_color_t *switch_priority_color_p,
                                               const uint32_t                 element_cnt)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     i = 0, cmd_body_size;
    sx_api_cos_port_pcpdei_to_prio_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((pcp_dei_p == NULL) || (switch_priority_color_p == NULL)) {
        SX_LOG_ERR("pcp_dei_p or switch_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_pcpdei_switch_prio_color_t) +
                    sizeof(sx_api_cos_port_pcpdei_to_prio_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->pcpdei_prio_color_p[i].pcp_dei.pcp = pcp_dei_p[i].pcp;
        cmd_body->pcpdei_prio_color_p[i].pcp_dei.dei = pcp_dei_p[i].dei;
        cmd_body->pcpdei_prio_color_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->pcpdei_prio_color_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_PCPDEI_TO_PRIO_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_pcpdei_to_prio_get(const sx_api_handle_t    handle,
                                               const sx_port_log_id_t   log_port,
                                               sx_cos_pcp_dei_t        *pcp_dei_p,
                                               sx_cos_priority_color_t *switch_priority_color_p,
                                               uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                        cmd_head;
    sx_api_cos_port_pcpdei_to_prio_get_params_t *cmd_body = NULL;
    uint32_t                                     cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                          reply_head;
    sx_api_cos_port_pcpdei_to_prio_get_params_t *reply_body = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!pcp_dei_p || !switch_priority_color_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        pcp_dei_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_pcpdei_to_prio_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_pcpdei_switch_prio_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }


    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_PCPDEI_TO_PRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            pcp_dei_p[i].pcp = reply_body->pcpdei_prio_color_p[i].pcp_dei.pcp;
            pcp_dei_p[i].dei = reply_body->pcpdei_prio_color_p[i].pcp_dei.dei;
            switch_priority_color_p[i].priority =
                reply_body->pcpdei_prio_color_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->pcpdei_prio_color_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_prio_to_ieeeprio_set(const sx_api_handle_t     handle,
                                            const sx_cos_priority_t  *switch_priority_p,
                                            const sx_cos_ieee_prio_t *ieee_priority_p,
                                            const uint32_t            element_cnt)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    uint32_t                                  i = 0, cmd_body_size;
    sx_api_cos_prio_to_ieeeprio_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((switch_priority_p == NULL) || (ieee_priority_p == NULL)) {
        SX_LOG_ERR("prio_ieee_prio_p or ieee_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_priority_ieee_priority_t) +
                    sizeof(sx_api_cos_prio_to_ieeeprio_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->prio_ieee_prio_p[i].priority = switch_priority_p[i];
        cmd_body->prio_ieee_prio_p[i].ieee_priority = ieee_priority_p[i];
    }

    cmd_body->element_cnt = element_cnt;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PRIO_TO_IEEEPRIO_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_prio_to_ieeeprio_get(const sx_api_handle_t handle,
                                            sx_cos_priority_t    *switch_priority_p,
                                            sx_cos_ieee_prio_t   *ieee_priority_p,
                                            uint32_t             *element_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_cos_prio_to_ieeeprio_get_params_t *cmd_body = NULL;
    uint32_t                                  cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                       reply_head;
    sx_api_cos_prio_to_ieeeprio_get_params_t *reply_body = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!switch_priority_p || !ieee_priority_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        switch_priority_p = NULL;
        ieee_priority_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_prio_to_ieeeprio_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_priority_ieee_priority_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }


    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PRIO_TO_IEEEPRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            switch_priority_p[i] = reply_body->prio_ieee_prio_p[i].priority;
            ieee_priority_p[i] = reply_body->prio_ieee_prio_p[i].ieee_priority;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_exp_to_prio_set(const sx_api_handle_t          handle,
                                            const sx_port_log_id_t         log_port,
                                            const sx_cos_exp_t            *exp_p,
                                            const sx_cos_priority_color_t *switch_priority_color_p,
                                            const sx_cos_ecn_t            *ecn_p,
                                            const uint32_t                 element_cnt)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    uint32_t                                  i = 0, cmd_body_size;
    sx_api_cos_port_exp_to_prio_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((exp_p == NULL) || (ecn_p == NULL) || (switch_priority_color_p == NULL)) {
        SX_LOG_ERR("exp_p or ecn_p or switch_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_exp_ecn_priority_color_t) +
                    sizeof(sx_api_cos_port_exp_to_prio_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->exp_ecn_prio_p[i].exp = exp_p[i];
        cmd_body->exp_ecn_prio_p[i].ecn = ecn_p[i];
        cmd_body->exp_ecn_prio_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->exp_ecn_prio_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_EXP_TO_PRIO_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_exp_to_prio_get(const sx_api_handle_t    handle,
                                            const sx_port_log_id_t   log_port,
                                            sx_cos_exp_t            *exp_p,
                                            sx_cos_priority_color_t *switch_priority_color_p,
                                            sx_cos_ecn_t            *ecn_p,
                                            uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_cos_port_exp_to_prio_get_params_t *cmd_body = NULL;
    uint32_t                                  cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                       reply_head;
    sx_api_cos_port_exp_to_prio_get_params_t *reply_body = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!exp_p || !switch_priority_color_p || !ecn_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        ecn_p = NULL;
        exp_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_exp_to_prio_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_exp_ecn_priority_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_EXP_TO_PRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            exp_p[i] = reply_body->exp_ecn_prio_p[i].exp;
            ecn_p[i] = reply_body->exp_ecn_prio_p[i].ecn;
            switch_priority_color_p[i].priority =
                reply_body->exp_ecn_prio_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->exp_ecn_prio_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_dscp_to_prio_set(const sx_api_handle_t          handle,
                                             const sx_port_log_id_t         log_port,
                                             const sx_cos_dscp_t           *dscp_p,
                                             const sx_cos_priority_color_t *switch_priority_color_p,
                                             const uint32_t                 element_cnt)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    uint32_t                                   i = 0, cmd_body_size;
    sx_api_cos_port_dscp_to_prio_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((dscp_p == NULL) || (switch_priority_color_p == NULL)) {
        SX_LOG_ERR("dscp_p or switch_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_dscp_switch_prio_color_t) +
                    sizeof(sx_api_cos_port_dscp_to_prio_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->dscp_prio_p[i].dscp = dscp_p[i];
        cmd_body->dscp_prio_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->dscp_prio_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_DSCP_TO_PRIO_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_dscp_to_prio_get(const sx_api_handle_t    handle,
                                             const sx_port_log_id_t   log_port,
                                             sx_cos_dscp_t           *dscp_p,
                                             sx_cos_priority_color_t *switch_priority_color_p,
                                             uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_cos_port_dscp_to_prio_get_params_t *cmd_body = NULL;
    uint32_t                                   cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                        reply_head;
    sx_api_cos_port_dscp_to_prio_get_params_t *reply_body = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!dscp_p || !switch_priority_color_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        dscp_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_dscp_to_prio_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_dscp_switch_prio_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_DSCP_TO_PRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            dscp_p[i] = reply_body->dscp_prio_p[i].dscp;
            switch_priority_color_p[i].priority =
                reply_body->dscp_prio_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->dscp_prio_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_rewrite_enable_set(const sx_api_handle_t         handle,
                                               const sx_port_log_id_t        log_port,
                                               const sx_cos_rewrite_enable_t rewrite)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_cos_port_rewrite_enable_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;
    cmd_body.rewrite_enable.rewrite_pcp_dei = rewrite.rewrite_pcp_dei;
    cmd_body.rewrite_enable.rewrite_dscp = rewrite.rewrite_dscp;
    cmd_body.rewrite_enable.rewrite_exp = rewrite.rewrite_exp;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_REWRITE_ENABLE_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_rewrite_enable_get(const sx_api_handle_t    handle,
                                               const sx_port_log_id_t   log_port,
                                               sx_cos_rewrite_enable_t *rewrite_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_cos_port_rewrite_enable_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (rewrite_p == NULL) {
        SX_LOG_ERR("rewrite is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_REWRITE_ENABLE_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (!SX_CHECK_FAIL(err)) {
        rewrite_p->rewrite_pcp_dei = cmd_body.rewrite_enable.rewrite_pcp_dei;
        rewrite_p->rewrite_dscp = cmd_body.rewrite_enable.rewrite_dscp;
        rewrite_p->rewrite_exp = cmd_body.rewrite_enable.rewrite_exp;
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_prio_to_pcpdei_rewrite_set(const sx_api_handle_t          handle,
                                                       const sx_port_log_id_t         log_port,
                                                       const sx_cos_priority_color_t *switch_priority_color_p,
                                                       const sx_cos_pcp_dei_t        *pcp_dei_p,
                                                       const uint32_t                 element_cnt)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    uint32_t                                             i = 0, cmd_body_size;
    sx_api_cos_port_prio_to_pcpdei_rewrite_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((pcp_dei_p == NULL) || (switch_priority_color_p == NULL)) {
        SX_LOG_ERR("pcp_dei_p or switch_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_pcpdei_switch_prio_color_t) +
                    sizeof(sx_api_cos_port_prio_to_pcpdei_rewrite_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->pcpdei_prio_color_p[i].pcp_dei.pcp = pcp_dei_p[i].pcp;
        cmd_body->pcpdei_prio_color_p[i].pcp_dei.dei = pcp_dei_p[i].dei;
        cmd_body->pcpdei_prio_color_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->pcpdei_prio_color_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_PRIO_TO_PCPDEI_REWRITE_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_port_prio_to_pcpdei_rewrite_get(const sx_api_handle_t    handle,
                                                       const sx_port_log_id_t   log_port,
                                                       sx_cos_priority_color_t *switch_priority_color_p,
                                                       sx_cos_pcp_dei_t        *pcp_dei_p,
                                                       uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                                cmd_head;
    sx_api_cos_port_prio_to_pcpdei_rewrite_get_params_t *cmd_body = NULL;
    uint32_t                                             cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                                  reply_head;
    sx_api_cos_port_prio_to_pcpdei_rewrite_get_params_t *reply_body = NULL;
    sx_status_t                                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!switch_priority_color_p || !pcp_dei_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        pcp_dei_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_prio_to_pcpdei_rewrite_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_pcpdei_switch_prio_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_PRIO_TO_PCPDEI_REWRITE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            pcp_dei_p[i].pcp = reply_body->pcpdei_prio_color_p[i].pcp_dei.pcp;
            pcp_dei_p[i].dei = reply_body->pcpdei_prio_color_p[i].pcp_dei.dei;
            switch_priority_color_p[i].priority =
                reply_body->pcpdei_prio_color_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->pcpdei_prio_color_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_port_prio_to_dscp_rewrite_set(const sx_api_handle_t          handle,
                                                     const sx_port_log_id_t         log_port,
                                                     const sx_cos_priority_color_t *switch_priority_color_p,
                                                     const sx_cos_dscp_t           *dscp_p,
                                                     const uint32_t                 element_cnt)
{
    sx_status_t                                        err = SX_STATUS_SUCCESS;
    uint32_t                                           i = 0, cmd_body_size;
    sx_api_cos_port_prio_to_dscp_rewrite_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((dscp_p == NULL) || (switch_priority_color_p == NULL)) {
        SX_LOG_ERR("dscp_p or switch_priority_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_dscp_switch_prio_color_t) +
                    sizeof(sx_api_cos_port_prio_to_dscp_rewrite_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->dscp_prio_p[i].dscp = dscp_p[i];
        cmd_body->dscp_prio_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->dscp_prio_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_PRIO_TO_DSCP_REWRITE_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_prio_to_dscp_rewrite_get(const sx_api_handle_t    handle,
                                                     const sx_port_log_id_t   log_port,
                                                     sx_cos_priority_color_t *switch_priority_color_p,
                                                     sx_cos_dscp_t           *dscp_p,
                                                     uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                              cmd_head;
    sx_api_cos_port_prio_to_dscp_rewrite_get_params_t *cmd_body = NULL;
    uint32_t                                           cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                                reply_head;
    sx_api_cos_port_prio_to_dscp_rewrite_get_params_t *reply_body = NULL;
    sx_status_t                                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!switch_priority_color_p || !dscp_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        dscp_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_prio_to_dscp_rewrite_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_dscp_switch_prio_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_PRIO_TO_DSCP_REWRITE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            dscp_p[i] = reply_body->dscp_prio_p[i].dscp;
            switch_priority_color_p[i].priority =
                reply_body->dscp_prio_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->dscp_prio_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_prio_to_exp_rewrite_set(const sx_api_handle_t          handle,
                                                    const sx_port_log_id_t         log_port,
                                                    const sx_cos_priority_color_t *switch_priority_color_p,
                                                    const sx_cos_ecn_t            *ecn_p,
                                                    const sx_cos_exp_t            *exp_p,
                                                    const uint32_t                 element_cnt)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    uint32_t                                          i = 0, cmd_body_size;
    sx_api_cos_port_prio_to_exp_rewrite_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((ecn_p == NULL) || (switch_priority_color_p == NULL) || (exp_p == NULL)) {
        SX_LOG_ERR("exp_p or switch_priority_p or ecn_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_exp_ecn_priority_color_t) +
                    sizeof(sx_api_cos_port_prio_to_exp_rewrite_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->exp_ecn_priority_p[i].exp = exp_p[i];
        cmd_body->exp_ecn_priority_p[i].ecn = ecn_p[i];
        cmd_body->exp_ecn_priority_p[i].priority_color.priority =
            switch_priority_color_p[i].priority;
        cmd_body->exp_ecn_priority_p[i].priority_color.color =
            switch_priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_PRIO_TO_EXP_REWRITE_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_prio_to_exp_rewrite_get(const sx_api_handle_t    handle,
                                                    const sx_port_log_id_t   log_port,
                                                    sx_cos_priority_color_t *switch_priority_color_p,
                                                    sx_cos_ecn_t            *ecn_p,
                                                    sx_cos_exp_t            *exp_p,
                                                    uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                             cmd_head;
    sx_api_cos_port_prio_to_exp_rewrite_get_params_t *cmd_body = NULL;
    uint32_t                                          cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                               reply_head;
    sx_api_cos_port_prio_to_exp_rewrite_get_params_t *reply_body = NULL;
    sx_status_t                                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!switch_priority_color_p || !ecn_p || !exp_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        exp_p = NULL;
        ecn_p = NULL;
        switch_priority_color_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_prio_to_exp_rewrite_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_exp_ecn_priority_color_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_PRIO_TO_EXP_REWRITE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            exp_p[i] = reply_body->exp_ecn_priority_p[i].exp;
            ecn_p[i] = reply_body->exp_ecn_priority_p[i].ecn;
            switch_priority_color_p[i].priority =
                reply_body->exp_ecn_priority_p[i].priority_color.priority;
            switch_priority_color_p[i].color =
                reply_body->exp_ecn_priority_p[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_ets_element_set(const sx_api_handle_t              handle,
                                            const sx_access_cmd_t              cmd,
                                            const sx_port_log_id_t             log_port,
                                            const sx_cos_ets_element_config_t *ets_element_p,
                                            const uint32_t                     element_cnt)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    uint32_t                                  i = 0, cmd_body_size;
    sx_api_cos_port_ets_element_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (ets_element_p == NULL)) {
        SX_LOG_ERR("ets_element_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_ets_element_config_t) +
                    sizeof(sx_api_cos_port_ets_element_set_params_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        SX_MEM_CPY_TYPE(&(cmd_body->ets_element_p[i]), &(ets_element_p[i]), sx_cos_ets_element_config_t);
    }

    cmd_body->element_cnt = element_cnt;
    cmd_body->log_port = log_port;
    cmd_body->cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_ETS_ELEMENT_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_ets_element_get(const sx_api_handle_t        handle,
                                            const sx_port_log_id_t       log_port,
                                            sx_cos_ets_element_config_t *ets_element_p,
                                            uint32_t                    *element_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_cos_port_ets_element_get_params_t *cmd_body = NULL;
    uint32_t                                  cmd_body_size = 0, reply_body_size = 0;
    sx_api_reply_head_t                       reply_head;
    sx_api_cos_port_ets_element_get_params_t *reply_body = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!ets_element_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        ets_element_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_cos_port_ets_element_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_ets_element_config_t));
    reply_body_size = cmd_body_size;

    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_PORT_ETS_ELEMENT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;
    cmd_body->log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p > 0) {
        SX_MEM_CPY_ARRAY(ets_element_p, reply_body->ets_element_p, reply_body->element_cnt,
                         sx_cos_ets_element_config_t);
    }
    *element_cnt_p = reply_body->element_cnt;

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_port_tc_mcaware_set(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t log_port,
                                           const boolean_t        mc_aware)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_cos_port_tc_mcaware_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;
    cmd_body.mc_aware = mc_aware;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_TC_MCAWARE_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_port_tc_mcaware_get(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t log_port,
                                           boolean_t             *mc_aware_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_cos_port_tc_mcaware_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (mc_aware_p == NULL) {
        SX_LOG_ERR("mc_aware_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_PORT_TC_MCAWARE_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (!SX_CHECK_FAIL(err)) {
        *mc_aware_p = cmd_body.mc_aware;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_buff_consumption_get(const sx_api_handle_t      handle,
                                            sx_cos_buff_consumption_t *buff_consumption_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_cos_buff_consumption_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (buff_consumption_p == NULL) {
        SX_LOG_ERR("buff_consumption_p is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_BUFF_CONSUMPTION_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (!SX_CHECK_FAIL(err)) {
        buff_consumption_p->pipeline_latency = cmd_body.pipeline_latency;
        buff_consumption_p->reserved_ingress = cmd_body.reserved_ingress;
        buff_consumption_p->reserved_egress = cmd_body.reserved_egress;
        buff_consumption_p->management_ingress = cmd_body.management_ingress;
        buff_consumption_p->management_egress = cmd_body.management_egress;
    }


    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_ets_ptp_shaper_param_set(const sx_api_handle_t          handle,
                                                const sx_access_cmd_t          cmd,
                                                sx_cos_ets_ptp_port_speed_e    port_speed,
                                                sx_cos_ets_ptp_shaper_params_t shaper_params)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     cmd_body_size = 0;
    sx_api_cos_ets_ptp_shaper_param_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("Unsupported command \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_cos_ets_ptp_shaper_param_set_params_t);

    cmd_body.port_speed = port_speed;
    cmd_body.shaper_params.time_exp = shaper_params.time_exp;
    cmd_body.shaper_params.time_mantissa = shaper_params.time_mantissa;
    cmd_body.shaper_params.shaper_inc = shaper_params.shaper_inc;
    cmd_body.shaper_params.shaper_bs = shaper_params.shaper_bs;
    cmd_body.shaper_params.port_to_shaper_credits = shaper_params.port_to_shaper_credits;
    cmd_body.shaper_params.ing_timestamp_inc = shaper_params.ing_timestamp_inc;
    cmd_body.shaper_params.egr_timestamp_inc = shaper_params.egr_timestamp_inc;
    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ETS_PTP_SHAPER_PARAM_SET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to set ptp shaper params.\n");
        goto out;
    }
out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_ets_ptp_shaper_param_get(const sx_api_handle_t           handle,
                                                const sx_access_cmd_t           cmd,
                                                sx_cos_ets_ptp_port_speed_e     port_speed,
                                                sx_cos_ets_ptp_shaper_params_t *shaper_params_p)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     cmd_body_size = 0;
    sx_api_cos_ets_ptp_shaper_param_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (shaper_params_p == NULL) {
        SX_LOG_ERR("shaper_params_p is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    cmd_body_size = sizeof(sx_api_cos_ets_ptp_shaper_param_get_params_t);

    cmd_body.port_speed = port_speed;
    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ETS_PTP_SHAPER_PARAM_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ptp shaper params\n");
        goto out;
    }

    memcpy(shaper_params_p, &(cmd_body.shaper_params), sizeof(sx_cos_ets_ptp_shaper_params_t));

out:
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_elephant_detection_config_set(const sx_api_handle_t                   handle,
                                                     const sx_cos_elephant_config_attribs_t *config_attribs_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_body_size = 0;
    sx_cos_elephant_config_attribs_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (config_attribs_p == NULL) {
        SX_LOG_ERR("config_attribs_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_cos_elephant_config_attribs_t);
    SX_MEM_CPY(cmd_body, *config_attribs_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_CONFIG_SET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set elephant detection configuration.\n");
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_elephant_detection_config_get(const sx_api_handle_t             handle,
                                                     sx_cos_elephant_config_attribs_t *config_attribs_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_body_size = 0;
    sx_cos_elephant_config_attribs_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (config_attribs_p == NULL) {
        SX_LOG_ERR("config_attribs_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_cos_elephant_config_attribs_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_CONFIG_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get elephant detection configuration.\n");
        goto out;
    }

    memcpy(config_attribs_p, &(cmd_body), sizeof(sx_cos_elephant_config_attribs_t));

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_elephant_detection_port_state_set(const sx_api_handle_t   handle,
                                                         const sx_access_cmd_t   cmd,
                                                         const sx_port_log_id_t *log_ports_list_p,
                                                         const uint32_t          log_ports_cnt)
{
    sx_status_t                                            err = SX_STATUS_SUCCESS;
    uint32_t                                               cmd_body_size = 0;
    sx_api_cos_elephant_detection_port_state_set_params_t *cmd_body_p = NULL;
    sx_status_t                                            utils_rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (log_ports_list_p == NULL) {
        SX_LOG_ERR("log_ports_list_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (log_ports_cnt == 0) {
        SX_LOG_ERR("log_ports_cnt is zero\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (log_ports_cnt > MAX_PHYPORT_NUM) {
        SX_LOG_ERR("log_ports_cnt (%d) exceeds maximum physical ports (%u).\n", log_ports_cnt, MAX_PHYPORT_NUM);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    cmd_body_size = sizeof(sx_api_cos_elephant_detection_port_state_set_params_t)
                    + log_ports_cnt * sizeof(sx_port_log_id_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        err = utils_rc;
        goto out;
    }
    cmd_body_p->cmd = cmd;
    cmd_body_p->log_ports_cnt = log_ports_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->log_ports_list_p, log_ports_list_p, log_ports_cnt, sx_port_log_id_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_PORT_STATE_SET_E,
                                      (uint8_t*)cmd_body_p, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set elephant detection state for the given ports.\n");
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            err = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_elephant_detection_port_state_get(const sx_api_handle_t              handle,
                                                         const sx_port_log_id_t             log_port,
                                                         sx_cos_elephant_detection_state_e *state_p)
{
    sx_status_t                                           err = SX_STATUS_SUCCESS;
    uint32_t                                              cmd_body_size = 0;
    sx_api_cos_elephant_detection_port_state_get_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (state_p == NULL) {
        SX_LOG_ERR("state_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_cos_elephant_detection_port_state_get_params_t);
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_PORT_STATE_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get elephant detection state for the given port.\n");
        goto out;
    }

    *state_p = cmd_body.state;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_elephant_detection_port_flows_get(const sx_api_handle_t      handle,
                                                         const sx_access_cmd_t      cmd,
                                                         const sx_port_log_id_t     log_port,
                                                         sx_cos_elephant_flow_id_t *flow_ids_list_p,
                                                         uint32_t                  *flow_ids_cnt_p)
{
    sx_status_t                                            err = SX_STATUS_SUCCESS;
    uint32_t                                               cmd_body_size = 0, flow_ids_cnt = 0;
    sx_status_t                                            utils_rc = SX_STATUS_SUCCESS;
    sx_api_cos_elephant_detection_port_flows_get_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_READ) {
        if ((flow_ids_list_p == NULL) || (flow_ids_cnt_p == NULL)) {
            SX_LOG_ERR("NULL pointer is passed as input.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        flow_ids_cnt = *flow_ids_cnt_p;
        if (*flow_ids_cnt_p == 0) {
            flow_ids_cnt = SX_COS_ELEPHANT_FLOW_ID_NUM_MAX;
        } else if (*flow_ids_cnt_p > SX_COS_ELEPHANT_FLOW_ID_NUM_MAX) {
            SX_LOG_ERR("Requested flow IDs number (%u) exceeds maximum number of flow IDs per port (%u).\n",
                       *flow_ids_cnt_p,
                       SX_COS_ELEPHANT_FLOW_ID_NUM_MAX);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    cmd_body_size = sizeof(sx_api_cos_elephant_detection_port_flows_get_params_t) +
                    (flow_ids_cnt) * sizeof(sx_cos_elephant_flow_id_t);

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        err = utils_rc;
        goto out;
    }
    cmd_body_p->flow_ids_cnt = flow_ids_cnt;
    cmd_body_p->log_port = log_port;
    cmd_body_p->cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_PORT_FLOWS_GET_E,
                                      (uint8_t*)cmd_body_p, cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get elephant detection flows for the given port.\n");
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_READ) {
        SX_MEM_CPY_ARRAY(flow_ids_list_p, cmd_body_p->flow_ids_list_p, cmd_body_p->flow_ids_cnt,
                         sx_cos_elephant_flow_id_t);
        *flow_ids_cnt_p = cmd_body_p->flow_ids_cnt;
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            err = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_elephant_detection_port_flows_data_get(const sx_api_handle_t            handle,
                                                              const sx_access_cmd_t            cmd,
                                                              const sx_port_log_id_t           log_port,
                                                              const sx_cos_elephant_flow_id_t *flow_ids_list_p,
                                                              sx_cos_elephant_flow_data_t     *flow_data_list_p,
                                                              uint32_t                        *list_cnt_p)
{
    sx_status_t                                                 rc = SX_STATUS_SUCCESS;
    sx_status_t                                                 utils_rc = SX_STATUS_SUCCESS;
    sx_api_cos_elephant_detection_port_flows_data_get_params_t *cmd_body_p = NULL;
    uint8_t                                                    *buffer_p = NULL, *current_p = NULL;
    uint32_t                                                    buffer_size = 0;

    SX_API_LOG_ENTER();

    if (flow_ids_list_p == NULL) {
        SX_LOG_ERR("Failed to read elephant flows data: flow_ids_list_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (flow_data_list_p == NULL) {
        SX_LOG_ERR("Failed to read elephant flows data: flow_data_list_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (list_cnt_p == NULL) {
        SX_LOG_ERR("Failed to read elephant flows data: list_cnt_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (*list_cnt_p == 0) {
        SX_LOG_NTC("Elephant flows data read: No flows to read: list_cnt_p is 0\n");
        goto out;
    }

    buffer_size = sizeof(sx_api_cos_elephant_detection_port_flows_data_get_params_t) +
                  (*list_cnt_p) * sizeof(sx_cos_elephant_flow_id_t) +
                  (*list_cnt_p) * sizeof(sx_cos_elephant_flow_data_t);

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed to read elephant flows data: Message size %d exceeds limit %d\n",
                   buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate buffer_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p = (sx_api_cos_elephant_detection_port_flows_data_get_params_t*)buffer_p;
    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;
    cmd_body_p->flow_ids_cnt = *list_cnt_p;
    cmd_body_p->flow_data_cnt = 0;

    SX_MEM_CPY_ARRAY(cmd_body_p->flow_ids_list, flow_ids_list_p, *list_cnt_p, sx_cos_elephant_flow_id_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_ELEPHANT_DETECTION_PORT_FLOWS_DATA_GET_E,
                                     buffer_p, buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    current_p = cmd_body_p->flow_ids_list;
    current_p += (*list_cnt_p) * sizeof(sx_cos_elephant_flow_id_t);

    *list_cnt_p = cmd_body_p->flow_data_cnt;

    SX_MEM_CPY_ARRAY(flow_data_list_p, current_p, *list_cnt_p, sx_cos_elephant_flow_data_t);

out:
    if (buffer_p != NULL) {
        M_UTILS_MEM_PUT(buffer_p, UTILS_MEM_TYPE_ID_API_E, "Error on buffer_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_cos_tq_profile_set(const sx_api_handle_t           handle,
                                      const sx_access_cmd_t           cmd,
                                      const sx_cos_tq_profile_key_t  *profile_key_p,
                                      const sx_cos_tq_profile_data_t *params_data_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_cos_tq_profile_set_params_t cmd_body;
    sx_api_command_head_t              cmd_head;
    sx_api_reply_head_t                reply_head;

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("sx_api_cos_tq_profile_set supports the SET access command only \n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (params_data_p == NULL) {
        SX_LOG_ERR("Failed: params_data_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_key_p == NULL) {
        SX_LOG_ERR("Failed: profile_key_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (profile_key_p->profile_id) {
    case SX_COS_TQ_PROFILE_ID_0_E:
    case SX_COS_TQ_PROFILE_ID_1_E:
        SX_LOG_ERR("TQ Profile ID 0 and TQ Profile ID 1 are not supported\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;

    case SX_COS_TQ_PROFILE_ID_2_E:
    case SX_COS_TQ_PROFILE_ID_3_E:
        break;

    default:
        SX_LOG_ERR("TQ Profile ID %u is invalid\n", profile_key_p->profile_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.profile_key.profile_id = profile_key_p->profile_id;
    cmd_body.profile_data_type = params_data_p->profile_params_data_type;

    switch (params_data_p->profile_params_data_type) {
    case SX_COS_TQ_PROFILE_PARAMS_DATA_TYPE_TTL_E:
        if (params_data_p->profile_params_data.ttl_params_p == NULL) {
            SX_LOG_ERR("Failed: params_data_p->profile_params_data.ttl_params_p is NULL\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }

        SX_MEM_CPY_P(&cmd_body.profile_data.ttl_params, params_data_p->profile_params_data.ttl_params_p);
        break;

    case SX_COS_TQ_PROFILE_PARAMS_DATA_TYPE_QOS_E:
        if (params_data_p->profile_params_data.qos_params_p == NULL) {
            SX_LOG_ERR("Failed: params_data_p->profile_params_data.qos_params_p is NULL\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }

        SX_MEM_CPY_P(&cmd_body.profile_data.qos_params, params_data_p->profile_params_data.qos_params_p);
        break;

    case SX_COS_TQ_PROFILE_PARAMS_DATA_TYPE_ECN_E:
        if (params_data_p->profile_params_data.ecn_params_p == NULL) {
            SX_LOG_ERR("Failed: params_data_p->profile_params_data.ecn_params_p is NULL\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }

        SX_MEM_CPY_P(&cmd_body.profile_data.ecn_params, params_data_p->profile_params_data.ecn_params_p);
        break;

    default:
        SX_LOG_ERR("Unsupported TQ Profile data type\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_COS_TQ_PROFILE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    rc = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_cos_tq_profile_get(const sx_api_handle_t           handle,
                                      const sx_cos_tq_profile_key_t  *profile_key_p,
                                      sx_cos_tq_profile_entry_type_t *profile_entry_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_cos_tq_profile_get_params_t cmd_body;
    sx_api_command_head_t              cmd_head;
    sx_api_reply_head_t                reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (profile_entry_p == NULL) {
        SX_LOG_ERR("Failed: profile_entry_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_key_p == NULL) {
        SX_LOG_ERR("Failed: profile_key_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (profile_key_p->profile_id) {
    case SX_COS_TQ_PROFILE_ID_0_E:
    case SX_COS_TQ_PROFILE_ID_1_E:
        SX_LOG_ERR("TQ Profile ID 0 and TQ Profile ID 1 are not supported\n");
        rc = SX_STATUS_ERROR;
        goto out;

    case SX_COS_TQ_PROFILE_ID_2_E:
    case SX_COS_TQ_PROFILE_ID_3_E:
        break;

    default:
        SX_LOG_ERR("TQ Profile ID %u is invalid\n", profile_key_p->profile_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    cmd_body.profile_key.profile_id = profile_key_p->profile_id;

    cmd_head.opcode = SX_API_INT_CMD_COS_TQ_PROFILE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    rc = sx_api_send_command_decoupled(handle,
                                       &cmd_head,
                                       (uint8_t*)&cmd_body,
                                       &reply_head,
                                       (uint8_t*)profile_entry_p,
                                       sizeof(*profile_entry_p));

    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_cos_sb_snapshot_trigger_set(const sx_api_handle_t                         handle,
                                               const sx_access_cmd_t                         cmd,
                                               const sx_sb_snapshot_trigger_enable_object_t *object_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_api_cos_sb_snapshot_trigger_set_params_t cmd_body;
    uint32_t                                    cmd_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_cos_sb_snapshot_trigger_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.object = *object_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_SB_SNAPSHOT_TRIGGER_SET_E,
                                     (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to configure snapshot trigger.\n");
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_cos_sb_snapshot_trigger_iter_get(const sx_api_handle_t                        handle,
                                                    const sx_access_cmd_t                        cmd,
                                                    sx_sb_snapshot_trigger_enable_object_t      *object_key_p,
                                                    sx_sb_snapshot_trigger_enable_iter_filter_t *filter_p,
                                                    sx_sb_snapshot_trigger_enable_object_t      *object_list_p,
                                                    uint32_t                                    *object_cnt_p)
{
    sx_api_cos_sb_snapshot_trigger_iter_get_params_t *cmd_body = NULL;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    uint32_t                                          reply_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (object_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Snapshot trigger enable counter pointer is NULL. cannot proceed\n");
        goto out;
    }
    if (object_key_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Snapshot trigger enable object key pointer is NULL. cannot proceed\n");
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*object_cnt_p > 1) {
            *object_cnt_p = 1;
            SX_LOG(SX_LOG_NOTICE, "Force count to be 1 for %s \n",
                   sx_access_cmd_str(cmd));
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
        break;
    }

    /* malloc the cmd body. We will use the same body for the reply also*/
    reply_body_size = sizeof(sx_api_cos_sb_snapshot_trigger_iter_get_params_t) +
                      ((*object_cnt_p) * sizeof(sx_sb_snapshot_trigger_enable_object_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for Snapshot trigger enable object list reply msg.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->object_cnt = *object_cnt_p;
    cmd_body->object_key = *object_key_p;

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body->filter), filter_p, sx_sb_snapshot_trigger_enable_iter_filter_t);
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_COS_SB_SNAPSHOT_TRIGGER_ITER_GET_E,
                                      (uint8_t*)cmd_body,
                                      reply_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_cos_sb_snapshot_trigger_iter_get failed. err: %d \n", err);
        goto out;
    }

    *object_cnt_p = cmd_body->object_cnt;

    if (*object_cnt_p != 0) {
        if (object_list_p != NULL) {
            SX_MEM_CPY_ARRAY(object_list_p, cmd_body->object_list,
                             cmd_body->object_cnt, sx_sb_snapshot_trigger_enable_object_t);
        }
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_sb_snapshot_action_set(const sx_api_handle_t handle, const sx_sb_snapshot_action_e action)
{
    sx_status_t                                rc = SX_STATUS_SUCCESS;
    sx_api_cos_sb_snapshot_action_set_params_t cmd_body;
    uint32_t                                   cmd_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body_size = sizeof(sx_api_cos_sb_snapshot_action_set_params_t);

    cmd_body.action = action;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_SB_SNAPSHOT_ACTION_SET_E,
                                     (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set snapshot action.\n");
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_cos_sb_snapshot_info_get(const sx_api_handle_t         handle,
                                            sx_sb_snapshot_information_t *snapshot_info_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_cos_sb_snapshot_info_get_params_t cmd_body;
    uint32_t                                 cmd_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (snapshot_info_p == NULL) {
        SX_LOG_ERR("snapshot_info_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }


    cmd_body_size = sizeof(sx_api_cos_sb_snapshot_info_get_params_t);


    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_COS_SB_SNAPSHOT_INFO_GET_E,
                                     (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get snapshot information.\n");
        goto out;
    }

    memcpy(snapshot_info_p, &(cmd_body.snapshot_info), sizeof(sx_sb_snapshot_information_t));

out:
    SX_API_LOG_EXIT();
    return rc;
}
