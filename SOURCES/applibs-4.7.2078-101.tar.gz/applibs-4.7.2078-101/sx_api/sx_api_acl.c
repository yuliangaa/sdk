/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_acl.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>

#undef  __MODULE__
#define __MODULE__ SX_API_ACL

sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_acl_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ACL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ACL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_region_set(const sx_api_handle_t      handle,
                                  const sx_access_cmd_t      cmd,
                                  const sx_acl_key_type_t    key_type,
                                  const sx_acl_action_type_t action_type,
                                  const sx_acl_size_t        region_size,
                                  sx_acl_region_id_t        *region_id_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       cmd_size;
    sx_api_acl_region_set_params_t cmd_body = {
        .cmd = cmd,
        .key_type = key_type,
        .action_type = action_type,
        .region_size = region_size,
    };

    SX_API_LOG_ENTER();

    if (region_id_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.region_id = *region_id_p;
    cmd_size = sizeof(sx_api_acl_region_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_REGION_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *region_id_p = cmd_body.region_id;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_region_get(const sx_api_handle_t    handle,
                                  const sx_acl_region_id_t region_id,
                                  sx_acl_key_type_t       *key_type_p,
                                  sx_acl_action_type_t    *action_type_p,
                                  sx_acl_size_t           *region_size_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       cmd_size;
    sx_api_acl_region_set_params_t cmd_body = {
        .key_type = 0,
        .action_type = 0,
        .region_size = 0,
        .region_id = region_id
    };

    SX_API_LOG_ENTER();

    if ((key_type_p == NULL) || (action_type_p == NULL) || (region_size_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_size = sizeof(sx_api_acl_region_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_REGION_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *key_type_p = cmd_body.key_type;
        *action_type_p = cmd_body.action_type;
        *region_size_p = cmd_body.region_size;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_set(const sx_api_handle_t        handle,
                           const sx_access_cmd_t        cmd,
                           const sx_acl_type_t          acl_type,
                           const sx_acl_direction_t     acl_direction,
                           const sx_acl_region_group_t *acl_region_group_p,
                           sx_acl_id_t                 *acl_id_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                cmd_size;
    sx_api_acl_set_params_t cmd_body = {
        .acl_type = acl_type,
        .cmd = cmd,
        .acl_direction = acl_direction,
    };

    SX_API_LOG_ENTER();
    if (((cmd != SX_ACCESS_CMD_DESTROY) && (acl_region_group_p == NULL)) || (acl_id_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (acl_direction > SX_ACL_DIRECTION_MAX)) {
        SX_LOG_ERR("Illegal direction value %u\n", acl_direction);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (acl_type > SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC)) {
        SX_LOG_ERR("ACL type %u not supported\n", acl_type);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        cmd_body.region_group = *acl_region_group_p;
    }

    cmd_body.acl_id = *acl_id_p;
    cmd_size = sizeof(sx_api_acl_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *acl_id_p = cmd_body.acl_id;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_get(const sx_api_handle_t  handle,
                           const sx_acl_id_t      acl_id,
                           sx_acl_type_t         *acl_type_p,
                           sx_acl_direction_t    *acl_direction_p,
                           sx_acl_region_group_t *acl_region_group_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                cmd_size;
    sx_api_acl_set_params_t cmd_body = {
        .acl_type = 0,
        .acl_id = acl_id,
    };

    SX_API_LOG_ENTER();
    if ((acl_type_p == NULL) || (acl_region_group_p == NULL) || (acl_direction_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }


    cmd_size = sizeof(sx_api_acl_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *acl_type_p = cmd_body.acl_type;
        *acl_direction_p = cmd_body.acl_direction;
        *acl_region_group_p = cmd_body.region_group;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_iter_get(const sx_api_handle_t  handle,
                                const sx_access_cmd_t  cmd,
                                const sx_acl_id_t      acl_id_key,
                                const sx_acl_filter_t *acl_filter_p,
                                sx_acl_id_t           *acl_id_list_p,
                                uint32_t              *acl_id_cnt_p)
{
    sx_api_command_head_t         cmd_head;
    sx_api_acl_iter_get_params_t  cmd_body;
    sx_api_reply_head_t           reply_head;
    sx_api_acl_iter_get_params_t* reply_body = NULL;
    uint32_t                      reply_body_size;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (acl_id_cnt_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("acl_id_cnt_p is NULL\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*acl_id_cnt_p == 0) {
            SX_LOG_ERR("acl_id_cnt_p is 0\n");
            acl_id_list_p = NULL;
            goto out;
        }
        if (acl_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("acl_id_list_p is NULL\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*acl_id_cnt_p == 0) {
            acl_id_list_p = NULL;
        } else if (acl_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("acl_id_list_p is NULL\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_acl_iter_get_params_t) +
                      (*acl_id_cnt_p * sizeof(sx_acl_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ACL_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_acl_iter_get_params_t);
    cmd_head.list_size = *acl_id_cnt_p * sizeof(sx_acl_id_t);

    cmd_body.acl_id_key = acl_id_key;
    cmd_body.cmd = cmd;
    cmd_body.acl_id_cnt = *acl_id_cnt_p;
    if (acl_filter_p != NULL) {
        cmd_body.acl_id_filter = *acl_filter_p;
    }

    *acl_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->acl_id_cnt) {
        *acl_id_cnt_p = reply_body->acl_id_cnt;
        if (acl_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(acl_id_list_p, reply_body->acl_id_list,
                             reply_body->acl_id_cnt, sx_acl_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_group_set(const sx_api_handle_t    handle,
                                 const sx_access_cmd_t    cmd,
                                 const sx_acl_direction_t acl_direction,
                                 const sx_acl_id_t       *acl_id_list_p,
                                 const uint32_t           acl_id_cnt,
                                 sx_acl_id_t             *group_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    uint32_t                   cmd_size = 0, i = 0;
    sx_api_acl_group_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if (NULL == group_id_p) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_group_params_t);
    if (SX_ACCESS_CMD_SET == cmd) {
        cmd_size += (sizeof(sx_acl_id_t) * acl_id_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body = (sx_api_acl_group_params_t*)cl_malloc(cmd_size);
    if (!cmd_body) {
        SX_LOG_ERR("Failed to allocate memory for command body\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    SX_MEM_CLR_TYPE(cmd_body, sx_api_acl_group_params_t);
    cmd_body->cmd = cmd;
    cmd_body->group_id = *group_id_p;
    cmd_body->acl_ids_num = acl_id_cnt;
    cmd_body->acl_direction = acl_direction;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if ((acl_direction > SX_ACL_DIRECTION_MAX) || (acl_direction == SX_ACL_DIRECTION_MULTI_POINTS_E)) {
            SX_LOG_ERR("ACL direction is not supported: %s\n", sx_acl_direction_str(acl_direction));
            CL_FREE_N_NULL(cmd_body);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
    }

    if (SX_ACCESS_CMD_SET == cmd) {
        if (NULL == acl_id_list_p) {
            SX_LOG_ERR("NULL params\n");
            CL_FREE_N_NULL(cmd_body);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }

        for (i = 0; i < acl_id_cnt; i++) {
            cmd_body->acl_ids[i] = acl_id_list_p[i];
        }
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_GROUP_SET_E, (uint8_t*)cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *group_id_p = cmd_body->group_id;
    }

    CL_FREE_N_NULL(cmd_body);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_group_get(const sx_api_handle_t handle,
                                 const sx_acl_id_t     group_id,
                                 sx_acl_direction_t   *acl_direction_p,
                                 sx_acl_id_t          *acl_id_list_p,
                                 uint32_t             *acl_id_cnt_p)
{
    SX_API_LOG_ENTER();

    sx_status_t                rc = SX_STATUS_SUCCESS;
    uint32_t                   cmd_size = 0;
    sx_api_acl_group_params_t *cmd_body = NULL;
    boolean_t                  get_count = FALSE;

    if ((acl_id_cnt_p == NULL) || (acl_direction_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((*acl_id_cnt_p != 0) && (acl_id_list_p == NULL)) {
        SX_LOG_ERR("*acl_id_cnt_p is not 0 but acl_id_list_p is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (*acl_id_cnt_p == 0) {
        get_count = TRUE;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_group_params_t) + (sizeof(sx_acl_id_t) * (*acl_id_cnt_p));
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body = (sx_api_acl_group_params_t*)cl_malloc(cmd_size);
    if (!cmd_body) {
        SX_LOG_ERR("Failed to allocate memory for command body\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    SX_MEM_CLR_TYPE(cmd_body, sx_api_acl_group_params_t);
    cmd_body->cmd = SX_ACCESS_CMD_GET;
    cmd_body->group_id = group_id;
    cmd_body->acl_ids_num = *acl_id_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_GROUP_GET_E, (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *acl_id_cnt_p = cmd_body->acl_ids_num;
        if (!get_count) {
            SX_MEM_CPY_ARRAY(acl_id_list_p, cmd_body->acl_ids, *acl_id_cnt_p, sx_acl_id_t);
        }
        *acl_direction_p = cmd_body->acl_direction;
    }

    CL_FREE_N_NULL(cmd_body);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_acl_group_iter_get(const sx_api_handle_t  handle,
                                      const sx_access_cmd_t  cmd,
                                      const sx_acl_id_t      group_id_key,
                                      const sx_acl_filter_t *acl_filter_p,
                                      sx_acl_id_t           *acl_id_list_p,
                                      uint32_t              *acl_id_cnt_p)
{
    sx_api_command_head_t               cmd_head;
    sx_api_acl_group_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                 reply_head;
    sx_api_acl_group_iter_get_params_t* reply_body = NULL;
    uint32_t                            reply_body_size;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (acl_id_cnt_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("acl_id_cnt_p is NULL\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*acl_id_cnt_p == 0) {
            SX_LOG_ERR("acl_id_cnt_p is 0\n");
            acl_id_list_p = NULL;
            goto out;
        }
        if (acl_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("acl_id_list_p is NULL\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*acl_id_cnt_p == 0) {
            acl_id_list_p = NULL;
        } else if (acl_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("acl_id_list_p is NULL\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_acl_group_iter_get_params_t) +
                      (*acl_id_cnt_p * sizeof(sx_acl_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ACL_GROUP_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_acl_group_iter_get_params_t);
    cmd_head.list_size = *acl_id_cnt_p * sizeof(sx_acl_id_t);

    cmd_body.acl_id_key = group_id_key;
    cmd_body.cmd = cmd;
    cmd_body.acl_id_cnt = *acl_id_cnt_p;
    if (acl_filter_p != NULL) {
        cmd_body.acl_id_filter = *acl_filter_p;
    }

    *acl_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->acl_id_cnt) {
        *acl_id_cnt_p = reply_body->acl_id_cnt;
        if (acl_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(acl_id_list_p, reply_body->acl_id_list,
                             reply_body->acl_id_cnt, sx_acl_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_policy_based_switching_set(const sx_api_handle_t     handle,
                                                  const sx_access_cmd_t     cmd,
                                                  const sx_swid_t           swid,
                                                  const sx_acl_pbs_entry_t *pbs_entry_p,
                                                  sx_acl_pbs_id_t          *pbs_id_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    cmd_size, port_idx, idx = 0, total_ports = 0;
    sx_api_acl_pbs_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((pbs_id_p == NULL) || ((pbs_entry_p == NULL) && (cmd != SX_ACCESS_CMD_DELETE))) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (cmd != SX_ACCESS_CMD_DELETE) {
        total_ports = pbs_entry_p->port_num;
        if ((total_ports > 0) && (pbs_entry_p->log_ports == NULL)) {
            SX_LOG_ERR("NULL params\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
        /* avoid duplicate ports */
        for (port_idx = 0; port_idx < total_ports; port_idx++) {
            for (idx = 0; idx < total_ports; idx++) {
                if ((idx != port_idx) && (pbs_entry_p->log_ports[idx] == pbs_entry_p->log_ports[port_idx])) {
                    SX_LOG_ERR("using the same port [0x%x] is not allowed\n", pbs_entry_p->log_ports[idx]);
                    SX_API_LOG_EXIT();
                    return SX_STATUS_PARAM_ERROR;
                }
            }
        }
        if (pbs_entry_p->entry_type > SX_ACL_PBS_ENTRY_TYPE_MAX) {
            SX_LOG_ERR("Error in entry type [%u]\n", pbs_entry_p->entry_type);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        cmd_body.entry_type = pbs_entry_p->entry_type;
        if ((pbs_entry_p->entry_type != SX_ACL_PBS_ENTRY_TYPE_MULTICAST) &&
            (pbs_entry_p->entry_type != SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST) &&
            (pbs_entry_p->port_num > 1)) {
            /* only one port maximum is allowed */
            SX_LOG_ERR("%u ports exceed allowed port number in PBS unicast entry type \n", pbs_entry_p->port_num);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* Validate Routing PBS does not have ports*/
        if ((pbs_entry_p->entry_type == SX_ACL_PBS_ENTRY_TYPE_ROUTING) &&
            (pbs_entry_p->port_num > 0)) {
            SX_LOG_ERR("%u ports exceed allowed port number in PBS routing entry type\n", pbs_entry_p->port_num);
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
    }

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.pbs_id = *pbs_id_p;
    cmd_size = sizeof(sx_api_acl_pbs_set_params_t);
    idx = 0;
    port_idx = 0;
    /* if we got more than maximal ports per command,
     *   we split the request to multiple requests */
    while (idx < total_ports || (idx == 0)) {
        cmd_body.port_num =
            ((total_ports - idx) > SX_ACL_PBS_MAX_GET_ENTRIES) ? SX_ACL_PBS_MAX_GET_ENTRIES : (total_ports - idx);
        for (port_idx = 0; port_idx < cmd_body.port_num; port_idx++) {
            cmd_body.log_ports[port_idx] = pbs_entry_p->log_ports[idx++];
        }
        err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PBS_SET_E, (uint8_t*)&cmd_body, cmd_size);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error in sending command RC = %u \n", err);
            SX_API_LOG_EXIT();
            return err;
        }
        /* in case the command was add we need to change it to add ports for next round */
        if (cmd == SX_ACCESS_CMD_ADD) {
            *pbs_id_p = cmd_body.pbs_id;
            cmd_body.cmd = SX_ACCESS_CMD_ADD_PORTS;
        }
        /* zero port termination */
        if (idx == 0) {
            break;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_policy_based_switching_get(const sx_api_handle_t handle,
                                                  const sx_access_cmd_t cmd,
                                                  const sx_swid_t       swid,
                                                  const sx_acl_pbs_id_t pbs_id,
                                                  sx_acl_pbs_entry_t   *pbs_entry_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    cmd_size, total_port_num = 0, idx = 0;
    sx_api_acl_pbs_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (pbs_entry_p == NULL) {
        SX_LOG_ERR("NULL param (pbs_entry)\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_COUNT)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GET) &&
        (pbs_entry_p->port_num != 0) && (pbs_entry_p->log_ports == NULL)) {
        SX_LOG_ERR("NULL params (pbs_entry->log_ports), port_num = %d\n", pbs_entry_p->port_num);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.pbs_id = pbs_id;
    cmd_body.entry_type = pbs_entry_p->entry_type;
    cmd_body.port_num = pbs_entry_p->port_num;
    cmd_size = sizeof(sx_api_acl_pbs_get_params_t);
    cmd_body.start_at_port = 0;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PBS_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to Get PBS ports \n");
        goto out;
    }
    if (pbs_entry_p->port_num == 0) {
        pbs_entry_p->port_num = cmd_body.port_num;
        pbs_entry_p->entry_type = cmd_body.entry_type;
        goto out;
    }
    pbs_entry_p->port_num = cmd_body.port_num;
    pbs_entry_p->entry_type = cmd_body.entry_type;

    idx = 0;
    if ((cmd == SX_ACCESS_CMD_GET) && (pbs_entry_p->log_ports != NULL)) {
        for (idx = 0; idx < cmd_body.port_num && idx < SX_ACL_PBS_MAX_GET_ENTRIES; idx++) {
            pbs_entry_p->log_ports[total_port_num++] = cmd_body.log_ports[idx];
        }
        /* If number of ports > message size */
        while (total_port_num < pbs_entry_p->port_num) {
            /* There are more ports in the PBS entry */
            cmd_body.start_at_port = total_port_num;
            err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PBS_GET_E, (uint8_t*)&cmd_body, cmd_size);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to Get PBS ports \n");
                goto out;
            }
            for (idx = 0; total_port_num < cmd_body.port_num && idx < SX_ACL_PBS_MAX_GET_ENTRIES; idx++) {
                pbs_entry_p->log_ports[total_port_num++] = cmd_body.log_ports[idx];
            }
        }
    }
out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_acl_policy_based_switching_iter_get(const sx_api_handle_t      handle,
                                                       const sx_access_cmd_t      cmd,
                                                       const sx_swid_t            swid,
                                                       const sx_acl_pbs_id_t      pbs_id_key,
                                                       const sx_acl_pbs_filter_t *pbs_id_filter_p,
                                                       sx_acl_pbs_id_t           *pbs_id_list_p,
                                                       uint32_t                  *pbs_id_cnt_p)
{
    sx_api_command_head_t              cmd_head;
    sx_api_acl_pbs_iter_get_params_t   cmd_body;
    sx_api_reply_head_t                reply_head;
    sx_api_acl_pbs_iter_get_params_t * reply_body = NULL;
    uint32_t                           reply_body_size;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (pbs_id_cnt_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("pbs_id_cnt_p is NULL\n");

        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*pbs_id_cnt_p == 0) {
            SX_LOG_INF("pbs_id_cnt_p is 0\n");
            goto out;
        }
        if (pbs_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("pbs_id_list_p is NULL\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*pbs_id_cnt_p == 0) {
            pbs_id_list_p = NULL;
        } else if (pbs_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("pbs_id_list_p is NULL\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_acl_pbs_iter_get_params_t) +
                      (*pbs_id_cnt_p * sizeof(sx_acl_pbs_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ACL_PBS_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_acl_pbs_iter_get_params_t);
    cmd_head.list_size = *pbs_id_cnt_p * sizeof(sx_acl_pbs_id_t);

    cmd_body.pbs_id_key = pbs_id_key;
    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.pbs_id_cnt = *pbs_id_cnt_p;
    if (pbs_id_filter_p != NULL) {
        cmd_body.pbs_id_filter = *pbs_id_filter_p;
    }

    *pbs_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->pbs_id_cnt) {
        *pbs_id_cnt_p = reply_body->pbs_id_cnt;
        if (pbs_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(pbs_id_list_p, reply_body->pbs_id_list,
                             reply_body->pbs_id_cnt, sx_acl_pbs_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


/*----------------------- */

sx_status_t sx_api_acl_l4_port_range_set(const sx_api_handle_t            handle,
                                         const sx_access_cmd_t            cmd,
                                         const sx_acl_port_range_entry_t *l4_port_range_p,
                                         sx_acl_port_range_id_t          *range_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();
    if ((NULL == l4_port_range_p) || (NULL == range_id_p)) {
        SX_LOG_ERR("NULL param\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    sx_api_acl_l4_range_params_t cmd_body = {
        .cmd = cmd,
        .range_id = *range_id_p
    };

    SX_MEM_CPY(cmd_body.l4_port_range, *l4_port_range_p);

    cmd_size = sizeof(sx_api_acl_l4_range_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_L4_PORT_RANGE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *range_id_p = cmd_body.range_id;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_l4_port_range_get(const sx_api_handle_t        handle,
                                         const sx_acl_port_range_id_t range_id,
                                         sx_acl_port_range_entry_t   *l4_port_range_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();
    if (NULL == l4_port_range_p) {
        SX_LOG_ERR("NULL param\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    sx_api_acl_l4_range_params_t cmd_body = {
        .range_id = range_id
    };

    cmd_size = sizeof(sx_api_acl_l4_range_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_L4_PORT_RANGE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        SX_MEM_CPY(*l4_port_range_p, cmd_body.l4_port_range);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_l4_port_range_iter_get(const sx_api_handle_t             handle,
                                              const sx_access_cmd_t             cmd,
                                              const sx_acl_port_range_id_t      range_id_key,
                                              const sx_acl_port_range_filter_t *range_id_filter_p,
                                              sx_acl_port_range_id_t           *range_id_list_p,
                                              uint32_t                         *range_id_cnt_p)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_acl_l4_port_range_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                         reply_head;
    sx_api_acl_l4_port_range_iter_get_params_t* reply_body = NULL;
    uint32_t                                    reply_body_size;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (range_id_cnt_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("range_id_cnt_p is NULL\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*range_id_cnt_p == 0) {
            SX_LOG_ERR("range_id_cnt_p is 0\n");
            range_id_list_p = NULL;
            goto out;
        }
        if (range_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("range_id_list_p is NULL\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*range_id_cnt_p == 0) {
            range_id_list_p = NULL;
        } else if (range_id_list_p == NULL) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("range_id_list_p is NULL\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_acl_l4_port_range_iter_get_params_t) +
                      (*range_id_cnt_p * sizeof(sx_acl_port_range_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ACL_L4_PORT_RANGE_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_acl_l4_port_range_iter_get_params_t);
    cmd_head.list_size = *range_id_cnt_p * sizeof(sx_acl_port_range_id_t);

    cmd_body.range_id_key = range_id_key;
    cmd_body.cmd = cmd;
    cmd_body.range_id_cnt = *range_id_cnt_p;
    if (range_id_filter_p != NULL) {
        cmd_body.range_id_filter = *range_id_filter_p;
    }

    *range_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->range_id_cnt) {
        *range_id_cnt_p = reply_body->range_id_cnt;
        if (range_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(range_id_list_p, reply_body->range_id_list,
                             reply_body->range_id_cnt, sx_acl_port_range_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_range_set(const sx_api_handle_t       handle,
                                 const sx_access_cmd_t       cmd,
                                 const sx_acl_range_entry_t *range_entry_p,
                                 sx_acl_port_range_id_t     *range_id_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  cmd_size = 0;
    sx_api_acl_range_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if ((NULL == range_entry_p) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("range_entry_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == range_id_p) {
        SX_LOG_ERR("range_id_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DELETE) {
        SX_MEM_CPY(cmd_body.range_entry, *range_entry_p);
    }

    cmd_body.cmd = cmd;
    cmd_body.range_id = *range_id_p;
    cmd_size = sizeof(sx_api_acl_range_params_t);
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_RANGE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *range_id_p = cmd_body.range_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_range_get(const sx_api_handle_t        handle,
                                 const sx_acl_port_range_id_t range_id,
                                 sx_acl_range_entry_t        *range_entry_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  cmd_size = 0;
    sx_api_acl_range_params_t cmd_body = {
        .range_id = range_id
    };

    SX_API_LOG_ENTER();

    if (NULL == range_entry_p) {
        SX_LOG_ERR("NULL param\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_size = sizeof(sx_api_acl_range_params_t);
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_RANGE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        SX_MEM_CPY(*range_entry_p, cmd_body.range_entry);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rule_activity_get(const sx_api_handle_t      handle,
                                         const sx_access_cmd_t      cmd,
                                         const sx_acl_region_id_t   region_id,
                                         const sx_acl_rule_offset_t rule_offset,
                                         boolean_t                 *activity_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_acl_rule_activity_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (activity_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = cmd;
    cmd_body.region_id = region_id;
    cmd_body.rule_offset = rule_offset;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_RULE_ACTIVITY_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_acl_rule_activity_get_params_t));
    if (err == SX_STATUS_SUCCESS) {
        *activity_p = cmd_body.activity;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rule_block_move_set(const sx_api_handle_t      handle,
                                           const sx_acl_region_id_t   region_id,
                                           const sx_acl_rule_offset_t block_start,
                                           const sx_acl_size_t        block_size,
                                           const sx_acl_rule_offset_t new_block_start)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_acl_block_move_params_t cmd_body = {
        .region_id = region_id,
        .block_start = block_start,
        .block_size = block_size,
        .new_block_start = new_block_start
    };

    SX_API_LOG_ENTER();

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ACL_RULES_MOVE_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_acl_block_move_params_t));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_port_bind_set(const sx_api_handle_t  handle,
                                     const sx_access_cmd_t  cmd,
                                     const sx_port_log_id_t log_port,
                                     const sx_acl_id_t      acl_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();

    sx_api_acl_bind_params_t cmd_body = {
        .cmd = cmd,
        .acl_id = acl_id,
        .log_port = log_port,
        .vlan_group = 0
    };

    cmd_size = sizeof(sx_api_acl_bind_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PORT_BIND_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_port_bind_get(const sx_api_handle_t    handle,
                                     const sx_port_log_id_t   log_port,
                                     const sx_acl_direction_t acl_direction,
                                     sx_acl_id_t             *acl_id_p)
{
    uint32_t acl_num = 1;

    return sx_api_acl_port_bindings_get(handle, log_port, acl_direction, acl_id_p, &acl_num);
}

sx_status_t sx_api_acl_port_bindings_get(const sx_api_handle_t    handle,
                                         const sx_port_log_id_t   log_port,
                                         const sx_acl_direction_t acl_direction,
                                         sx_acl_id_t             *acl_id_p,
                                         uint32_t                *acl_cnt_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    uint32_t                      cmd_size = 0;
    uint32_t                      i = 0;
    sx_api_acl_bind_get_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();

    if ((acl_direction > SX_ACL_DIRECTION_MAX) || (acl_direction == SX_ACL_DIRECTION_MULTI_POINTS_E)) {
        SX_LOG_ERR("ACL direction is not supported: %s\n", sx_acl_direction_str(acl_direction));
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (acl_cnt_p == NULL) {
        SX_LOG_ERR("NULL ACL IDs count\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (acl_id_p == NULL) {
        *acl_cnt_p = 0;
    }

    cmd_size = sizeof(sx_api_acl_bind_get_params_t) + sizeof(sx_acl_id_t) * *acl_cnt_p;

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_acl_bind_get_params_t*)cl_calloc(1, cmd_size);
    if (cmd_body_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for command body\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body_p->acl_direction = acl_direction;
    cmd_body_p->log_port = log_port;
    cmd_body_p->acl_ids_num = *acl_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PORT_BIND_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *acl_cnt_p = cmd_body_p->acl_ids_num;

        if (acl_id_p) {
            for (i = 0; i < *acl_cnt_p; i++) {
                acl_id_p[i] = cmd_body_p->acl_id[i];
            }
        }
    }

    CL_FREE_N_NULL(cmd_body_p);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_vlan_group_map_set(const sx_api_handle_t handle,
                                          const sx_access_cmd_t cmd,
                                          const sx_swid_id_t    swid,
                                          const sx_vlan_id_t   *vlan_list_p,
                                          const uint32_t        vlan_cnt,
                                          sx_acl_vlan_group_t  *group_id_p)
{
    sx_status_t                         mem_err, err = SX_STATUS_SUCCESS;
    sx_api_acl_vlan_group_set_params_t *cmd_body_p = NULL;
    uint32_t                            idx = 0, curr_vlan_cnt;
    uint32_t                            cmd_size = sizeof(sx_api_acl_vlan_group_set_params_t);

    SX_API_LOG_ENTER();

    if ((SX_ACCESS_CMD_CREATE != cmd) && (SX_ACCESS_CMD_DESTROY != cmd)) {
        if (NULL == vlan_list_p) {
            SX_LOG_ERR("NULL params\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
    } else { /* create or destroy*/
        if (0 != vlan_cnt) {
            SX_LOG_ERR("While creating or deleting vlan group, vlan count must be 0\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
    }

    if (SX_ACCESS_CMD_CREATE == cmd) {
        if (0 != vlan_cnt) {
            SX_LOG_ERR("While creating vlan group, vlan count must be 0\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
    }

    if (group_id_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_DESTROY:
        curr_vlan_cnt = 0;
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", mem_err);
        if (SX_CHECK_FAIL(mem_err)) {
            SX_API_LOG_EXIT();
            return mem_err;
        }

        break;

    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        curr_vlan_cnt = vlan_cnt;
        cmd_size += (curr_vlan_cnt) * sizeof(sx_vlan_id_t);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", mem_err);
        if (SX_CHECK_FAIL(mem_err)) {
            SX_API_LOG_EXIT();
            return mem_err;
        }

        for (idx = 0; idx < curr_vlan_cnt; idx++) {
            cmd_body_p->vlan_list[idx] = vlan_list_p[idx];
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->vlan_group_id = *group_id_p;
    cmd_body_p->swid = swid;
    cmd_body_p->vlan_num = curr_vlan_cnt;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_VLAN_GROUP_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if ((cmd == SX_ACCESS_CMD_CREATE) && (err == SX_STATUS_SUCCESS)) {
        *group_id_p = cmd_body_p->vlan_group_id;
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_err);
    if (mem_err != SX_STATUS_SUCCESS) {
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_vlan_group_map_get(const sx_api_handle_t     handle,
                                          const sx_swid_id_t        swid,
                                          const sx_acl_vlan_group_t group_id,
                                          sx_vlan_id_t             *vlan_list_p,
                                          uint32_t                 *vlan_cnt_p)
{
    SX_API_LOG_ENTER();

    sx_status_t                         mem_rc, rc = SX_STATUS_SUCCESS;
    sx_api_acl_vlan_group_set_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_acl_vlan_group_set_params_t);
    uint32_t                            max_vlan_ids = 0;

    if ((vlan_list_p == NULL) || (vlan_cnt_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (*vlan_cnt_p == 0) {
        SX_LOG_ERR("Vlan num should be at least 1\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_size += *vlan_cnt_p * sizeof(sx_vlan_id_t);

    if (cmd_size > MAX_CMD_SIZE) {
        max_vlan_ids = ((MAX_CMD_SIZE -
                         sizeof(sx_api_acl_vlan_group_set_params_t)) /
                        sizeof(sx_vlan_id_t));

        cmd_size = sizeof(sx_api_acl_vlan_group_set_params_t) +
                   (max_vlan_ids * sizeof(sx_vlan_id_t));
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->cmd = SX_ACCESS_CMD_GET;
    cmd_body_p->swid = swid;
    cmd_body_p->vlan_group_id = group_id;
    cmd_body_p->vlan_num = *vlan_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_VLAN_GROUP_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *vlan_cnt_p = cmd_body_p->vlan_num;
        SX_MEM_CPY_ARRAY(vlan_list_p, cmd_body_p->vlan_list, *vlan_cnt_p, sx_vlan_id_t);
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (mem_rc != SX_STATUS_SUCCESS) {
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_acl_vlan_group_bind_set(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           const sx_acl_vlan_group_t vlan_group,
                                           const sx_acl_id_t         acl_id)
{
    SX_API_LOG_ENTER();

    sx_status_t              err = SX_STATUS_SUCCESS;
    uint32_t                 cmd_size;
    sx_api_acl_bind_params_t cmd_body = {
        .cmd = cmd,
        .acl_id = acl_id,
        .log_port = 0,
        .vlan_group = vlan_group
    };

    cmd_size = sizeof(sx_api_acl_bind_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_VLAN_GROUP_BIND_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_vlan_group_bind_get(const sx_api_handle_t     handle,
                                           const sx_acl_vlan_group_t vlan_group,
                                           const sx_acl_direction_t  acl_direction,
                                           sx_acl_id_t              *acl_id_p)
{
    uint32_t acl_num = 1;

    return sx_api_acl_vlan_group_bindings_get(handle, vlan_group, acl_direction, acl_id_p, &acl_num);
}


sx_status_t sx_api_acl_vlan_group_bindings_get(const sx_api_handle_t     handle,
                                               const sx_acl_vlan_group_t vlan_group,
                                               const sx_acl_direction_t  acl_direction,
                                               sx_acl_id_t              *acl_id_p,
                                               uint32_t                 *acl_cnt_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    uint32_t                      cmd_size = 0;
    uint32_t                      i = 0;
    sx_api_acl_bind_get_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();

    if ((acl_direction > SX_ACL_DIRECTION_MAX) || (acl_direction == SX_ACL_DIRECTION_MULTI_POINTS_E)) {
        SX_LOG_ERR("ACL direction is not supported: %s\n", sx_acl_direction_str(acl_direction));
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (acl_cnt_p == NULL) {
        SX_LOG_ERR("NULL ACL IDs count\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (acl_id_p == NULL) {
        *acl_cnt_p = 0;
    }

    cmd_size = sizeof(sx_api_acl_bind_get_params_t) + sizeof(sx_acl_id_t) * *acl_cnt_p;

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_acl_bind_get_params_t*)cl_calloc(1, cmd_size);
    if (cmd_body_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for command body\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body_p->acl_direction = acl_direction;
    cmd_body_p->vlan_group = vlan_group;
    cmd_body_p->acl_ids_num = *acl_cnt_p;

    err =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_VLAN_GROUP_BIND_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *acl_cnt_p = cmd_body_p->acl_ids_num;

        if (acl_id_p) {
            for (i = 0; i < *acl_cnt_p; i++) {
                acl_id_p[i] = cmd_body_p->acl_id[i];
            }
        }
    }
    CL_FREE_N_NULL(cmd_body_p);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_region_hw_size_get(const sx_api_handle_t    handle,
                                          const sx_acl_region_id_t region_id,
                                          sx_acl_size_t           *region_size_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();

    if (region_size_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    sx_api_acl_region_hw_size_get_params_t cmd_body = {
        .hw_size = 0,
        .region_id = region_id
    };

    cmd_size = sizeof(sx_api_acl_region_hw_size_get_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_REGION_HW_SIZE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *region_size_p = cmd_body.hw_size;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_policy_based_ilm_set(const sx_api_handle_t       handle,
                                            const sx_access_cmd_t       cmd,
                                            const sx_acl_pbilm_entry_t *pbilm_entry_p,
                                            sx_acl_pbilm_id_t          *pbilm_id_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_api_acl_pbilm_set_params_t cmd_body;
    uint32_t                      cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if ((pbilm_id_p == NULL) || ((pbilm_entry_p == NULL) && (cmd != SX_ACCESS_CMD_DESTROY))) {
        SX_LOG_ERR("PBILM set NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (cmd != SX_ACCESS_CMD_DESTROY) {
        if (pbilm_entry_p->pbilm_params.action != SX_ROUTER_ACTION_FORWARD) {
            SX_LOG_ERR("Only forward action is allowed for ACL PBILM\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
        if (pbilm_entry_p->pbilm_params.ilm_fwd_action > SX_MPLS_ILM_MAX) {
            SX_LOG_ERR("Illegal ILM forwarding action for ACL PBILM\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
    }

    cmd_body.cmd = cmd;
    cmd_body.pbilm_id = *pbilm_id_p;
    if (pbilm_entry_p != NULL) {
        cmd_body.pbilm_params = pbilm_entry_p->pbilm_params;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PBILM_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if ((cmd == SX_ACCESS_CMD_CREATE) && (err == SX_STATUS_SUCCESS)) {
        *pbilm_id_p = cmd_body.pbilm_id;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_policy_based_ilm_get(const sx_api_handle_t   handle,
                                            const sx_acl_pbilm_id_t pbilm_id,
                                            sx_acl_pbilm_entry_t   *pbilm_entry_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_api_acl_pbilm_get_params_t cmd_body;
    uint32_t                      cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (pbilm_entry_p == NULL) {
        SX_LOG_ERR("NULL param (pbs_entry)\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.pbilm_id = pbilm_id;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ACL_PBILM_GET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}
