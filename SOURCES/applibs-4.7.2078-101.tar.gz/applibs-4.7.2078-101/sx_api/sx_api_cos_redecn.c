/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_cos_redecn.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ SX_API_COS_REDECN


/************************************************
 *  DEFINES
 ***********************************************/

/************************************************
 *  DECLARATIONS
 ***********************************************/

/************************************************
 *  LOCAL FUNCTIONS
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  API Functions Implementation
 ***********************************************/
sx_status_t sx_api_cos_redecn_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_LOG_DEPRECATED_FUNC_ERR(sx_api_cos_redecn_log_verbosity_level_set);

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_COS_REDECN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                      const sx_log_verbosity_target_t verbosity_target,
                                                      const sx_verbosity_level_t      module_verbosity_level,
                                                      const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_COS_REDECN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                      const sx_log_verbosity_target_t verbosity_target,
                                                      sx_verbosity_level_t           *module_verbosity_level_p,
                                                      sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_COS_REDECN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err =
            sx_api_send_command_wrapper(handle,
                                        cmd_head.opcode,
                                        (uint8_t*)&cmd_body,
                                        sizeof(sx_api_command_log_verbosity_t));
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_general_param_set(const sx_api_handle_t         handle,
                                                const sx_cos_redecn_global_t *configuration_p)
{
    sx_api_command_head_t  cmd_head;
    sx_cos_redecn_global_t cmd_body;
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t    reply_head;

    SX_API_LOG_ENTER();

    /* pointer check */
    err = utils_check_pointer(configuration_p, "sx_api_cos_redecn_general_param_set configuration_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_GENERAL_PARAM_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_cos_redecn_global_t);

    cmd_body.source_congestion_detection_only = configuration_p->source_congestion_detection_only;
    cmd_body.weight = configuration_p->weight;
    cmd_body.ece_inner_enable = configuration_p->ece_inner_enable;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_general_param_get(const sx_api_handle_t handle, sx_cos_redecn_global_t *configuration_p)
{
    sx_api_command_head_t  cmd_head;
    sx_cos_redecn_global_t reply_body;
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t    reply_head;

    SX_API_LOG_ENTER();

    /* pointer check */
    err = utils_check_pointer(configuration_p, "configuration_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_GENERAL_PARAM_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        NULL, &reply_head, (uint8_t*)&reply_body, sizeof(sx_cos_redecn_global_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    configuration_p->source_congestion_detection_only = reply_body.source_congestion_detection_only;
    configuration_p->weight = reply_body.weight;
    configuration_p->ece_inner_enable = reply_body.ece_inner_enable;

out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_profile_set(const sx_api_handle_t                     handle,
                                          const sx_access_cmd_t                     cmd,
                                          const sx_cos_redecn_profile_attributes_t *params_p,
                                          sx_cos_redecn_profile_t                  *profile_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_redecn_profile_params_internal_t cmd_body;
    sx_api_reply_head_t                     reply_head;
    sx_api_command_head_t                   cmd_head;

    /* pointer check */

    SX_API_LOG_ENTER();

    err = utils_check_pointer(profile_p, "configuration_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = utils_check_pointer(params_p, "params_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = utils_check_pointer(profile_p, "profile_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_LOG_DBG("mode = %d high drop = %d min = %d max = %d\n", params_p->mode, params_p->high_drop_percent,
               (params_p->mode ==
                SX_COS_REDECN_MODE_ABSOLUTE ? params_p->values.absolute_mode.min : params_p->values.relative_mode.min),
               (params_p->mode ==
                SX_COS_REDECN_MODE_ABSOLUTE ? params_p->values.absolute_mode.max : params_p->values.relative_mode.max));

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(cmd_head);

    cmd_head.opcode = SX_API_COS_REDECN_PROFILE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_profile_params_internal_t);

    SX_MEM_CPY_BUF(&cmd_body.attributes, params_p, sizeof(sx_cos_redecn_profile_attributes_t));

    cmd_body.command = cmd;
    cmd_body.attributes.high_drop_percent = params_p->high_drop_percent;
    cmd_body.attributes.mode = params_p->mode;
    cmd_body.profile = *profile_p;

    if (params_p->mode == SX_COS_REDECN_MODE_ABSOLUTE) {
        cmd_body.attributes.values.absolute_mode.max = params_p->values.absolute_mode.max;
        cmd_body.attributes.values.absolute_mode.min = params_p->values.absolute_mode.min;
    } else {
        cmd_body.attributes.values.relative_mode.max = params_p->values.relative_mode.max;
        cmd_body.attributes.values.relative_mode.min = params_p->values.relative_mode.min;
    }

    err =
        sx_api_send_command_decoupled(handle,
                                      &cmd_head,
                                      (uint8_t*)&cmd_body,
                                      &reply_head,
                                      (uint8_t*)profile_p,
                                      sizeof(sx_cos_redecn_profile_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_profile_get(const sx_api_handle_t               handle,
                                          const sx_cos_redecn_profile_t       profile,
                                          sx_cos_redecn_profile_attributes_t *params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_cos_redecn_profile_attributes_t reply_body;
    sx_api_reply_head_t                reply_head;
    sx_api_command_head_t              cmd_head;

    SX_API_LOG_ENTER();

    /* pointer check */
    err = utils_check_pointer(params_p, "params_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(cmd_head);

    cmd_head.opcode = SX_API_COS_REDECN_PROFILE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_cos_redecn_profile_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&profile, &reply_head, (uint8_t*)&reply_body,
                                        sizeof(sx_cos_redecn_profile_attributes_t));

    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CPY_BUF(params_p, &reply_body, sizeof(sx_cos_redecn_profile_attributes_t));
out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_tc_enable_set(const sx_api_handle_t                handle,
                                            const sx_port_log_id_t               log_port,
                                            const sx_cos_traffic_class_t        *traffic_classes_p,
                                            const uint8_t                        traffic_classes_cnt,
                                            const sx_cos_redecn_enable_params_t *params_p)
{
    sx_api_redecn_tc_enable_params_internal_t *cmd_body_p = NULL;
    sx_api_command_head_t                      cmd_head;
    sx_status_t                                err = SX_STATUS_SUCCESS, alloc_err;
    uint32_t                                   cmd_size = 0;
    sx_api_reply_head_t                        reply_head;

    SX_API_LOG_ENTER();

    if (traffic_classes_cnt == 0) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = utils_check_pointer(traffic_classes_p, "traffic_classes_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = utils_check_pointer(params_p, "params_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_size = sizeof(sx_api_redecn_tc_enable_params_internal_t) + traffic_classes_cnt *
               sizeof(sx_cos_traffic_class_t);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p,
                        1,
                        cmd_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        SX_API_LOG_EXIT();
        return err;
    }
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_TC_ENABLE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = cmd_size + sizeof(sx_api_command_head_t);

    cmd_body_p->egress_port = log_port;
    cmd_body_p->traffic_classes_cnt = traffic_classes_cnt;
    SX_MEM_CPY_BUF(&cmd_body_p->params, params_p, sizeof(sx_cos_redecn_enable_params_t));
    SX_MEM_CPY_BUF(cmd_body_p->traffic_classes, traffic_classes_p, traffic_classes_cnt *
                   sizeof(sx_cos_traffic_class_t));

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", alloc_err);
        if (SX_CHECK_FAIL(alloc_err)) {
            SX_LOG_ERR("M_UTILS_MEM_PUT failed\n");
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_tc_enable_get(const sx_api_handle_t          handle,
                                            const sx_port_log_id_t         log_port,
                                            const sx_cos_traffic_class_t   traffic_class,
                                            sx_cos_redecn_enable_params_t *params_p)
{
    uint8_t buff[sizeof(sx_api_redecn_tc_enable_params_internal_t) +
                 sizeof(sx_cos_traffic_class_t)];
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_redecn_tc_enable_params_internal_t *cmd_body_p = (sx_api_redecn_tc_enable_params_internal_t*)buff;
    sx_api_reply_head_t                        reply_head;
    sx_api_command_head_t                      cmd_head;

    SX_API_LOG_ENTER();

    /* pointer check */
    err = utils_check_pointer(params_p, "params_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(buff);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(cmd_head);

    cmd_head.opcode = SX_API_COS_REDECN_TC_ENABLE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_tc_enable_params_internal_t) +
                        sizeof(sx_cos_traffic_class_t);

    cmd_body_p->egress_port = log_port;
    cmd_body_p->traffic_classes_cnt = 1;
    cmd_body_p->traffic_classes[0] = traffic_class;

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)cmd_body_p,
                                        &reply_head,
                                        (uint8_t*)params_p,
                                        sizeof(sx_cos_redecn_enable_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_profile_tc_bind_set(const sx_api_handle_t              handle,
                                                  const sx_port_log_id_t             log_port,
                                                  const sx_access_cmd_t              command,
                                                  const sx_cos_traffic_class_t      *traffic_classes_p,
                                                  const uint8_t                      traffic_classes_cnt,
                                                  const sx_cos_redecn_flow_type_e    flow_type,
                                                  const sx_cos_redecn_bind_params_t *params_p)
{
    sx_api_redecn_bind_params_internal_t *cmd_body_p = NULL;
    sx_api_command_head_t                 cmd_head;
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_status_t                           alloc_err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_size = 0;
    uint32_t                              pad_sz = 0;
    uint32_t                              tc_buff_sz = 0;
    sx_api_reply_head_t                   reply_head;

    SX_API_LOG_ENTER();

    if (traffic_classes_cnt == 0) {
        err = SX_STATUS_PARAM_ERROR;
        goto cleanup;
    }

    err = utils_check_pointer(traffic_classes_p, "traffic_classes_p");
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    /* cmd_size = sizeof(sx_api_redecn_bind_params_internal_t) + traffic_classes_cnt * sizeof(sx_cos_traffic_class_t); */

    /* Buffer size calculation
     * -----------------------
     * pad_sz - number of aligned bytes at the end of the structure.
     * tc_buff_sz - size of buffer required for traffic classes buffer.
     *
     * Command body buffer size should be at least of sx_api_redecn_bind_params_internal_t type size.
     * There is a padding at the end of sx_api_redecn_bind_params_internal_t, and few last bytes can
     * be used by dynamic array. So, we need to allocate additional bytes for the dynamic array minus
     * number of padding bytes.
     */
    pad_sz = sizeof(sx_api_redecn_bind_params_internal_t) -
             offsetof(sx_api_redecn_bind_params_internal_t, flow_data) -
             offsetof(sx_api_redecn_flow_data_tc_t, traffic_classes_p);
    tc_buff_sz = traffic_classes_cnt * sizeof(sx_cos_traffic_class_t);

    cmd_size = sizeof(sx_api_redecn_bind_params_internal_t) + (tc_buff_sz > pad_sz ? tc_buff_sz - pad_sz : 0);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto cleanup;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("alloc failed\n");
        goto cleanup;
    }

    cmd_head.opcode = SX_API_COS_REDECN_PROFILE_TC_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_size;

    cmd_body_p->bind_params = *params_p;
    cmd_body_p->flow_type = flow_type;
    cmd_body_p->command = command;
    cmd_body_p->flow_data_type = SX_COS_REDECN_FLOW_DATA_TYPE_TC_E;
    cmd_body_p->flow_data.tc.egress_port = log_port;
    cmd_body_p->flow_data.tc.traffic_classes_cnt = traffic_classes_cnt;
    SX_MEM_CPY_BUF(cmd_body_p->flow_data.tc.traffic_classes_p,
                   traffic_classes_p,
                   sizeof(sx_cos_traffic_class_t) * traffic_classes_cnt);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", alloc_err);
        if (SX_CHECK_FAIL(alloc_err)) {
            SX_LOG_ERR("free failed\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_profile_tc_bind_get(const sx_api_handle_t           handle,
                                                  const sx_port_log_id_t          log_port,
                                                  const sx_cos_traffic_class_t    traffic_class,
                                                  const sx_cos_redecn_flow_type_e flow_type,
                                                  sx_cos_redecn_bind_params_t    *bind_params_p)
{
    sx_api_redecn_bind_params_internal_t *cmd_body_p = NULL;
    sx_api_command_head_t                 cmd_head;
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_status_t                           alloc_err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_size = 0;
    uint32_t                              pad_sz = 0;
    uint32_t                              tc_buff_sz = 0;
    sx_api_reply_head_t                   reply_head;

    SX_API_LOG_ENTER();

    err = utils_check_pointer(bind_params_p, "bind_params_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("utils_check_pointer failed rc = %d\n", err);
        goto cleanup;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    /* Buffer size calculation
     * -----------------------
     * pad_sz - number of aligned bytes at the end of the structure.
     * tc_buff_sz - size of buffer required for traffic classes buffer.
     *
     * Command body buffer size should be at least of sx_api_redecn_bind_params_internal_t type size.
     * There is a padding at the end of sx_api_redecn_bind_params_internal_t, and few last bytes can
     * be used by dynamic array. So, we need to allocate additional bytes for the dynamic array minus
     * number of padding bytes.
     */
    pad_sz = sizeof(sx_api_redecn_bind_params_internal_t) -
             offsetof(sx_api_redecn_bind_params_internal_t, flow_data) -
             offsetof(sx_api_redecn_flow_data_tc_t, traffic_classes_p);
    tc_buff_sz = 1 * sizeof(sx_cos_traffic_class_t);

    cmd_size = sizeof(sx_api_redecn_bind_params_internal_t) + (tc_buff_sz > pad_sz ? tc_buff_sz - pad_sz : 0);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto cleanup;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("alloc failed\n");
        goto cleanup;
    }

    cmd_head.opcode = SX_API_COS_REDECN_PROFILE_TC_BIND_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_size;

    cmd_body_p->flow_type = flow_type;
    cmd_body_p->flow_data_type = SX_COS_REDECN_FLOW_DATA_TYPE_TC_E;
    cmd_body_p->flow_data.tc.egress_port = log_port;
    cmd_body_p->flow_data.tc.traffic_classes_cnt = 1;
    cmd_body_p->flow_data.tc.traffic_classes_p[0] = traffic_class;

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)cmd_body_p,
                                        &reply_head,
                                        (uint8_t*)bind_params_p,
                                        sizeof(sx_cos_redecn_bind_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", alloc_err);
        if (SX_CHECK_FAIL(alloc_err)) {
            SX_LOG_ERR("free failed\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_rate_based_set(const sx_api_handle_t                    handle,
                                             const boolean_t                          enabled,
                                             const sx_port_log_id_t                   log_port,
                                             const sx_cos_redecn_rate_based_params_t *params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_command_head_t              cmd_head;
    sx_api_redecn_rb_params_internal_t cmd_body;
    sx_api_reply_head_t                reply_head;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(params_p, "params_p"))) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_RATE_BASED_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_rb_params_internal_t);

    cmd_body.egress_port = log_port;
    cmd_body.enabled = enabled;
    SX_MEM_CPY_P(&cmd_body.params, params_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_cos_redecn_rate_based_get(const sx_api_handle_t              handle,
                                             const sx_port_log_id_t             log_port,
                                             sx_cos_redecn_rate_based_params_t *params_p,
                                             boolean_t                         *enabled_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_command_head_t              cmd_head;
    sx_api_redecn_rb_params_internal_t cmd_body;
    sx_api_reply_head_t                reply_head;
    sx_api_redecn_rb_params_internal_t reply_body;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(params_p, "params_p"))) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (SX_CHECK_FAIL(utils_check_pointer(enabled_p, "enabled_p"))) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    cmd_head.opcode = SX_API_COS_REDECN_RATE_BASED_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_rb_params_internal_t);

    cmd_body.egress_port = log_port;

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)&cmd_body,
                                        &reply_head,
                                        (uint8_t*)&reply_body,
                                        sizeof(reply_body));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    SX_MEM_CPY_P(params_p, &reply_body.params);
    *enabled_p = reply_body.enabled;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_cos_redecn_mirroring_set(const sx_api_handle_t      handle,
                                            const sx_access_cmd_t      command,
                                            const sx_port_log_id_t     ingress_port,
                                            const sx_span_session_id_t span_session_id)
{
    sx_api_redecn_mirroring_params_internal_t cmd_body;
    sx_api_command_head_t                     cmd_head;
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                       reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_MIRRORING_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_mirroring_params_internal_t);

    cmd_body.command = command;
    cmd_body.ingress_port = ingress_port;
    cmd_body.span_session_id = span_session_id;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_redecn_mirroring_get(const sx_api_handle_t  handle,
                                            const sx_port_log_id_t ingress_port,
                                            boolean_t             *enabled_p)
{
    sx_api_redecn_mirroring_params_internal_t cmd_body;
    sx_api_command_head_t                     cmd_head;
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                       reply_head;
    boolean_t                                 reply_body;

    SX_API_LOG_ENTER();

    err = utils_check_pointer(enabled_p, "enabled_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("utils_check_pointer failed rc = %d\n", err);
        goto cleanup;
    }
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_MIRRORING_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_mirroring_params_internal_t);

    cmd_body.ingress_port = ingress_port;

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)&cmd_body,
                                        &reply_head,
                                        (uint8_t*)&reply_body,
                                        sizeof(reply_body));
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_cos_redecn_counters_get(const sx_api_handle_t          handle,
                                           const sx_access_cmd_t          command,
                                           const sx_port_log_id_t         log_port,
                                           sx_cos_redecn_port_counters_t *counters_p)
{
    sx_api_command_head_t                    cmd_head;
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                      reply_head;
    sx_api_redecn_counters_params_internal_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    err = utils_check_pointer(counters_p, "counters_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("utils_check_pointer failed rc = %d\n", err);
        goto cleanup;
    }

    cmd_body.command = command;
    cmd_body.egress_port = log_port;

    cmd_head.opcode = SX_API_COS_REDECN_COUNTERS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_redecn_counters_params_internal_t);

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)&cmd_body,
                                        &reply_head,
                                        (uint8_t*)counters_p,
                                        sizeof(sx_cos_redecn_port_counters_t));
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }
cleanup:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_red_counter_per_port_tc_get(const sx_api_handle_t         handle,
                                                          const sx_access_cmd_t         cmd,
                                                          const sx_port_log_id_t        log_port,
                                                          const sx_cos_traffic_class_t *tc_list_p,
                                                          const uint8_t                 tc_list_cnt,
                                                          sx_port_cntr_t               *red_counters_p)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                        cmd_head;
    sx_api_reply_head_t                          reply_head;
    sx_api_redecn_tc_counters_params_internal_t *cmd_body_p = NULL;
    uint32_t                                     cmd_body_size = 0;

    SX_API_LOG_ENTER();

    if (tc_list_cnt == 0) {
        SX_LOG_ERR("Zero Traffic Class count\n");
        err = SX_STATUS_PARAM_ERROR;
        goto cleanup;
    }

    err = utils_check_pointer(tc_list_p, "tc_list_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Null Pointer Check for tc_list_p failed; rc = %d\n", err);
        goto cleanup;
    }
    err = utils_check_pointer(red_counters_p, "red_counters_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Null Pointer Check for red_counters_p failed; rc = %d\n", err);
        goto cleanup;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported cmd = %s\n", sx_access_cmd_str(cmd));
        goto cleanup;
    }

    cmd_body_size = sizeof(sx_api_redecn_tc_counters_params_internal_t) +
                    tc_list_cnt * sizeof(sx_cos_traffic_class_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto cleanup;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("alloc failed\n");
        goto cleanup;
    }

    SX_MEM_CLR_P(cmd_body_p);

    cmd_head.opcode = SX_API_COS_REDECN_RED_COUNTER_PER_PORT_TC_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body_p->command = cmd;
    cmd_body_p->egress_port = log_port;
    cmd_body_p->traffic_classes_cnt = tc_list_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->traffic_classes_p, tc_list_p,
                     tc_list_cnt, sx_cos_traffic_class_t);

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)cmd_body_p,
                                        &reply_head,
                                        (uint8_t*)red_counters_p,
                                        (tc_list_cnt * sizeof(uint64_t)));
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to Free cmd_body_p memory\n", err);
    }
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_cos_redecn_ecn_counter_per_port_get(const sx_api_handle_t  handle,
                                                       const sx_access_cmd_t  cmd,
                                                       const sx_port_log_id_t log_port,
                                                       sx_port_cntr_t        *ecn_counter_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_reply_head_t                      reply_head;
    sx_api_redecn_counters_params_internal_t cmd_body;

    SX_API_LOG_ENTER();

    err = utils_check_pointer(ecn_counter_p, "ecn_counter_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Null Pointer Check for ecn_counter_p failed; rc = %d\n", err);
        goto cleanup;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported cmd = %s\n", sx_access_cmd_str(cmd));
        goto cleanup;
    }
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_ECN_COUNTER_PER_PORT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_redecn_counters_params_internal_t);
    cmd_body.command = cmd;
    cmd_body.egress_port = log_port;

    err = sx_api_send_command_decoupled(handle,
                                        &cmd_head,
                                        (uint8_t*)&cmd_body,
                                        &reply_head,
                                        (uint8_t*)ecn_counter_p,
                                        sizeof(sx_port_cntr_t));
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }
cleanup:
    SX_API_LOG_EXIT();

    return err;
}
/**
 * This function is used to configure whether ecn marking should be counted
 *
 * @param[in] handle SX-API handle
 * @param[in] enabled true for counting, false to not count
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_CMD_UNSUPPORTED if the function is being called in an unsupported chip
 */
sx_status_t sx_api_cos_redecn_counters_count_marked_set(const sx_api_handle_t handle, const boolean_t enabled)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                cmd_head;
    sx_api_cos_redecn_counters_count_marked_set_params_t cmd_body;
    sx_api_reply_head_t                                  reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_COS_REDECN_COUNTERS_COUNT_MARKED_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_cos_redecn_counters_count_marked_set_params_t);

    cmd_body.enabled = enabled;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto cleanup;
    }

cleanup:
    SX_API_LOG_EXIT();

    return err;
}

/**
 * This function is used to get whether ecn marking should be counted
 *
 * @param[in] handle SX-API handle
 * @param[in] enabled_p true for counting, false to not count
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_CMD_UNSUPPORTED if the function is being called in an unsupported chip
 */
sx_status_t sx_api_cos_redecn_counters_count_marked_get(const sx_api_handle_t handle, const boolean_t *enabled_p)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                cmd_head;
    sx_api_reply_head_t                                  reply_head;
    sx_api_cos_redecn_counters_count_marked_get_params_t reply_body;

    SX_API_LOG_ENTER();

    err = utils_check_pointer(enabled_p, "enabled_p");
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("utils_check_pointer failed rc = %d\n", err);
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    cmd_head.opcode = SX_API_COS_REDECN_COUNTERS_COUNT_MARKED_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        NULL, &reply_head, (uint8_t*)&reply_body.enabled,
                                        sizeof(sx_api_cos_redecn_counters_count_marked_get_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}
