/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_mpls.h>
#include <sx/sdk/sx_mpls_ilm.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_MPLS

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_DEBUG;

/************************************************
 *  API Functions Implementation
 ***********************************************/
sx_status_t sx_api_mpls_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        status = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(status)) {
            goto out;
        }
        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        status = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(status)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MPLS_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        status = sx_api_send_command_decoupled(handle, &cmd_head,
                                               (uint8_t*)&cmd_body,
                                               &reply_head,
                                               NULL,
                                               0);
    }

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        status = utils_check_pointer(api_verbosity_level_p,
                                     "api_verbosity_level");
        if (SX_CHECK_FAIL(status)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        status = utils_check_pointer(module_verbosity_level_p,
                                     "module_verbosity_level");
        if (SX_CHECK_FAIL(status)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MPLS_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        status = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_init_set(const sx_api_handle_t handle, const sx_mpls_general_params_t *general_params_p)
{
    sx_api_mpls_init_params_t cmd_body;
    sx_status_t               status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(general_params_p, "MPLS general parameters")) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "general_params_p == NULL\n");
        goto out;
    }

    if (SX_MPLS_IS_LABEL_ID_IN_RANGE(general_params_p->label_id_range_min) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "Label ID min is out of range\n");
        goto out;
    }

    if (SX_MPLS_IS_LABEL_ID_IN_RANGE(general_params_p->label_id_range_max) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "Label ID max is out of range\n");
        goto out;
    }

    if (general_params_p->label_id_range_max <= general_params_p
        ->label_id_range_min) {
        status = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Label ID min is greater or equal from label ID max\n");
        goto out;
    }

    if (SX_MPLS_IS_LABEL_ID_IN_RANGE(general_params_p->reserved_label_id_max) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "Reserved label ID max is out of range\n");
        goto out;
    }

    if (SX_CHECK_MAX(general_params_p->ttl_model, SX_MPLS_TTL_MODEL_TYPE_MAX) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "TTL model is out of range\n");
        goto out;
    }

    SX_MEM_CPY_P(&cmd_body.mpls_general_params, general_params_p);

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_INIT_SET_E,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_mpls_init_params_t));
out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_DEINIT_SET_E,
                                         NULL, 0);

    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_ilm_init_set(const sx_api_handle_t  handle,
                                     const sx_access_cmd_t  cmd,
                                     sx_mpls_ilm_table_id_t ilm_table)
{
    sx_api_mpls_ilm_init_set_params_t cmd_body;
    sx_status_t                       status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(handle);
    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_ADD) &&
        (cmd != SX_ACCESS_CMD_DELETE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "Command is not supported.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.ilm_table = ilm_table;

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_ILM_INIT_SET,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_mpls_ilm_init_set_params_t));

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_in_segment_set(const sx_api_handle_t              handle,
                                       const sx_access_cmd_t              cmd,
                                       const sx_mpls_in_segment_key_t    *in_segment_key_p,
                                       const sx_mpls_in_segment_params_t *in_segment_params_p)
{
    sx_api_mpls_in_segment_set_params_t cmd_body;
    sx_status_t                         status = SX_STATUS_SUCCESS;
    int                                 i;

    UNUSED_PARAM(handle);
    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "Command is not supported.\n");
        goto out;
    }

    if (SX_MPLS_IN_SEGMENT_LABEL_COUNT_RANGE(in_segment_key_p->label_cnt) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "label_cnt (%u) is out of range\n", in_segment_key_p->label_cnt);
        goto out;
    }

    if (SX_ROUTER_ACTION_CHECK_RANGE(in_segment_params_p->action) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "action (%u) is out of range\n", in_segment_params_p->action);
        goto out;
    }

    if (in_segment_params_p->action == SX_ROUTER_ACTION_SPAN) {
        status = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "Router action %s is not supported\n",
               sx_router_action_str(in_segment_params_p->action));
        goto out;
    }

    if (SX_MPLS_ILM_FORWARD_ACTION_CHECK_RANGE(in_segment_params_p->ilm_fwd_action) != TRUE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "ilm_fwd_action (%u) is out of range\n", in_segment_params_p->ilm_fwd_action);
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.in_segment_key, *in_segment_key_p);
    SX_MEM_CPY(cmd_body.in_segment_params, *in_segment_params_p);

    /*
     *  'in_segment_key' is a key of many DBs in the SDK. Some of the DBs keep this key as an opaque value.
     *  We must make sure that any redundant information in this struct is reset to 0.
     */
    for (i = cmd_body.in_segment_key.label_cnt; i < SX_MPLS_MAX_LABELS_TO_MATCH; i++) {
        cmd_body.in_segment_key.in_label[i] = 0;
    }

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_IN_SEGMENT_SET,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_mpls_in_segment_set_params_t));

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_in_segment_get(const sx_api_handle_t           handle,
                                       const sx_mpls_in_segment_key_t *in_segment_key_p,
                                       sx_mpls_in_segment_params_t    *in_segment_params_p)
{
    sx_api_mpls_in_segment_get_params_t cmd_body;
    int                                 i;
    sx_status_t                         status = SX_STATUS_SUCCESS;


    UNUSED_PARAM(handle);
    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (utils_check_pointer(in_segment_key_p, "in_segment_key")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY_P(&(cmd_body.in_segment_key), in_segment_key_p);

    /*
     *  'in_segment_key' is a key of many DBs in the SDK. Some of the DBs keep this key as an opaque value.
     *  We must make sure that any redundant information in this struct is reset to 0.
     */
    for (i = cmd_body.in_segment_key.label_cnt; i < SX_MPLS_MAX_LABELS_TO_MATCH; i++) {
        cmd_body.in_segment_key.in_label[i] = 0;
    }

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_IN_SEGMENT_GET,
                                         (uint8_t*)&cmd_body,
                                         sizeof(sx_api_mpls_in_segment_get_params_t));
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Failed to send command wrapper. error:  %s\n", sx_status_str(status));
        goto out;
    }

    SX_MEM_CPY_P(in_segment_params_p,
                 &(cmd_body.in_segment_params));

out:
    SX_API_LOG_EXIT();
    return status;
}
sx_status_t sx_api_mpls_in_segment_iter_get(const sx_api_handle_t             handle,
                                            const sx_access_cmd_t             cmd,
                                            const sx_mpls_in_segment_key_t   *in_segment_key_p,
                                            const sx_in_segment_key_filter_t *filter_p,
                                            sx_mpls_in_segment_key_t         *in_segment_key_list_p,
                                            uint32_t                         *in_segment_get_entries_cnt_p)
{
    sx_api_mpls_in_segment_iter_get_params_t *cmd_body = NULL;
    sx_status_t                               status = SX_STATUS_SUCCESS;
    int                                       i;
    uint32_t                                  cmd_size = 0;

    UNUSED_PARAM(handle);

    SX_API_LOG_ENTER();


    if (utils_check_pointer(in_segment_get_entries_cnt_p, "in_segment_get_entries_cnt_p")) {
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GETNEXT) || (cmd == SX_ACCESS_CMD_GET)) {
        if ((*in_segment_get_entries_cnt_p > 0) && (in_segment_key_p == NULL)) {
            /* get next requires non null rif key */
            status = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid! Key is NULL for Cmd = %s\n",
                       sx_access_cmd_str(cmd));
            goto out;
        }
    }

    if ((cmd == SX_ACCESS_CMD_GET) && (*in_segment_get_entries_cnt_p == 0)) {
        in_segment_key_list_p = NULL;
    }

    if (*in_segment_get_entries_cnt_p > MAX_IN_SEGMENT_GET_ALL_ENTRIES) {
        if (cmd == SX_ACCESS_CMD_GET) {
            *in_segment_get_entries_cnt_p = 1;
        } else {
            status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("uc_route_get_entries_num (%d) > MAX_GET_ALL_ENTRIES (%d)  error:  %s.\n",
                       *in_segment_get_entries_cnt_p, MAX_GET_ALL_ENTRIES, sx_status_str(status));
            goto out;
        }
    }

    cmd_size = sizeof(sx_api_mpls_in_segment_iter_get_params_t);
    cmd_size += ((*in_segment_get_entries_cnt_p) * sizeof(sx_mpls_in_segment_key_t));

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", status);

    SX_MEM_CPY(cmd_body->cmd, cmd);
    if (in_segment_key_p != NULL) {
        SX_MEM_CPY(cmd_body->in_segment_key, *in_segment_key_p);
    }
    if (filter_p != NULL) {
        /* coverity[unsigned_compare]*/
        SX_MEM_CPY(cmd_body->filter, *filter_p);
    }
    cmd_body->in_segment_get_entries_cnt = *in_segment_get_entries_cnt_p;

    /*
     *  'in_segment_key' is a key of many DBs in the SDK. Some of the DBs keep this key as an opaque value.
     *  We must make sure that any redundant information in this struct is reset to 0.
     */
    for (i = cmd_body->in_segment_key.label_cnt; i < SX_MPLS_MAX_LABELS_TO_MATCH; i++) {
        cmd_body->in_segment_key.in_label[i] = 0;
    }

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_IN_SEGMENT_ITER_GET,
                                         (uint8_t*)cmd_body,
                                         cmd_size);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Failed to send command wrapper. error:  %s\n", sx_status_str(status));
        goto out;
    }


    *in_segment_get_entries_cnt_p = cmd_body->in_segment_get_entries_cnt;

    if ((*in_segment_get_entries_cnt_p != 0) && (in_segment_key_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(in_segment_key_list_p,
                         cmd_body->in_segment_key_list,
                         *in_segment_get_entries_cnt_p,
                         sx_mpls_in_segment_key_t);
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_router_interface_attributes_set(const sx_api_handle_t                 handle,
                                                        const sx_router_interface_t           rif,
                                                        const sx_mpls_router_interface_attr_t rif_mpls_attr)
{
    sx_api_mpls_router_interface_attributes_params_t cmd_body;
    sx_status_t                                      status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.rif_id = rif;
    cmd_body.rif_mpls_attr.mpls_enabled =
        (rif_mpls_attr.mpls_enabled == TRUE ? SX_ROUTER_ENABLE_STATE_ENABLE : SX_ROUTER_ENABLE_STATE_DISABLE);
    cmd_body.rif_mpls_attr.ilm_table_id = rif_mpls_attr.ilm_table_id;
    cmd_body.rif_mpls_attr.mpls_mtu = rif_mpls_attr.mpls_mtu;

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_ROUTER_INTERFACE_ATTRIBUTES_SET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_router_interface_attributes_get(const sx_api_handle_t            handle,
                                                        const sx_router_interface_t      rif,
                                                        sx_mpls_router_interface_attr_t *rif_mpls_attr_p)
{
    sx_api_mpls_router_interface_attributes_params_t cmd_body;
    sx_status_t                                      status = SX_STATUS_SUCCESS;
    sx_mpls_router_interface_attr_t                  rif_mpls_attr;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(rif_mpls_attr);

    if (utils_check_pointer(rif_mpls_attr_p, "MPLS rif attributes parameters")) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "rif_mpls_attr_p == NULL\n");
        goto out;
    }

    rif_mpls_attr = *rif_mpls_attr_p;

    cmd_body.rif_id = rif;

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_ROUTER_INTERFACE_ATTRIBUTES_GET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));

    rif_mpls_attr.mpls_enabled = (cmd_body.rif_mpls_attr.mpls_enabled == SX_ROUTER_ENABLE_STATE_ENABLE ? TRUE : FALSE);
    rif_mpls_attr.ilm_table_id = cmd_body.rif_mpls_attr.ilm_table_id;
    rif_mpls_attr.mpls_mtu = cmd_body.rif_mpls_attr.mpls_mtu;

    SX_MEM_CPY(*rif_mpls_attr_p, rif_mpls_attr);

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_mpls_ilm_counter_bind_set(const sx_api_handle_t           handle,
                                             const sx_access_cmd_t           cmd,
                                             const sx_mpls_in_segment_key_t *in_segment_key_p,
                                             const sx_flow_counter_id_t      counter_id)
{
    sx_mpls_ilm_counter_params_t cmd_body;
    sx_status_t                  status = SX_STATUS_SUCCESS;
    int                          i;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (utils_check_pointer(in_segment_key_p, "In segment key")) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "in_segment_key_p == NULL\n");
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "Command is not supported.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.counter_id = counter_id;
    cmd_body.in_segment_key = *in_segment_key_p;

    /*
     *  'in_segment_key' is a key of many DBs in the SDK. Some of the DBs keep this key as an opaque value.
     *  We must make sure that any redundant information in this struct is reset to 0.
     */
    for (i = cmd_body.in_segment_key.label_cnt; i < SX_MPLS_MAX_LABELS_TO_MATCH; i++) {
        cmd_body.in_segment_key.in_label[i] = 0;
    }

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_ILM_COUNTER_BIND_SET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return status;
}


sx_status_t sx_api_mpls_ilm_counter_bind_get(const sx_api_handle_t           handle,
                                             const sx_access_cmd_t           cmd,
                                             const sx_mpls_in_segment_key_t *in_segment_key_p,
                                             sx_flow_counter_id_t           *counter_id_p)
{
    sx_mpls_ilm_counter_params_t cmd_body;
    sx_status_t                  status = SX_STATUS_SUCCESS;
    int                          i;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (utils_check_pointer(in_segment_key_p, "In segment key")) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "in_segment_key_p == NULL\n");
        goto out;
    }

    if (utils_check_pointer(counter_id_p, "Flow counter id")) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "counter_id_p == NULL\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "Command is not supported.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.in_segment_key = *in_segment_key_p;

    /*
     *  'in_segment_key' is a key of many DBs in the SDK. Some of the DBs keep this key as an opaque value.
     *  We must make sure that any redundant information in this struct is reset to 0.
     */
    for (i = cmd_body.in_segment_key.label_cnt; i < SX_MPLS_MAX_LABELS_TO_MATCH; i++) {
        cmd_body.in_segment_key.in_label[i] = 0;
    }

    status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MPLS_ILM_COUNTER_BIND_GET_E,
                                         (uint8_t*)&cmd_body, sizeof(cmd_body));

    SX_MEM_CPY(*counter_id_p, cmd_body.counter_id);

out:
    SX_API_LOG_EXIT();
    return status;
}
