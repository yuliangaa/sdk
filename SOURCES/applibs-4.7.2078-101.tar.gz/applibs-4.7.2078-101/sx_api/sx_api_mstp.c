/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>

#include <sx/sdk/sx_api_mstp.h>

#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_mstp.h>

#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_MSTP

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_mstp_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MSTP_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mstp_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MSTP_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mstp_mode_set(const sx_api_handle_t handle, const sx_swid_t swid, const sx_mstp_mode_t mode)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_api_mstp_mode_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .swid_id = swid,
        .mstp_mode = mode
    };
    uint32_t                      cmd_size = sizeof(sx_api_mstp_mode_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (FALSE == SX_MSTP_MODE_CHECK_RANGE(mode)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_MODE_SET_E, (uint8_t*)&cmd_body, cmd_size);
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_mode_get(const sx_api_handle_t handle, const sx_swid_t swid, sx_mstp_mode_t    *mode_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_api_mstp_mode_get_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .swid_id = swid,
        .mstp_mode = 0
    };
    uint32_t                      cmd_size = sizeof(sx_api_mstp_mode_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == mode_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_MODE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *mode_p = cmd_body.mstp_mode;
    }

    SX_API_LOG_EXIT();

    return rc;
}


sx_status_t sx_api_mstp_inst_set(const sx_api_handle_t   handle,
                                 const sx_access_cmd_t   cmd,
                                 const sx_swid_t         swid,
                                 const sx_mstp_inst_id_t inst_id)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_api_mstp_inst_set_params_t cmd_body = {
        .cmd = cmd,
        .swid_id = swid,
        .inst_id = inst_id
    };
    uint32_t                      cmd_size = sizeof(sx_api_mstp_inst_set_params_t);

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:

        /* O/W: */
        if (FALSE == SX_MSTP_INST_ID_CHECK_RANGE(inst_id)) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_inst_iter_get(const sx_api_handle_t        handle,
                                      const sx_access_cmd_t        cmd,
                                      const sx_swid_t              swid,
                                      const sx_mstp_inst_id_t      inst_key,
                                      const sx_mstp_inst_filter_t *inst_filter_p,
                                      sx_mstp_inst_id_t           *inst_list_p,
                                      uint32_t                    *inst_cnt_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    mem_rc = SX_STATUS_SUCCESS;
    sx_api_mstp_inst_get_params_t *cmd_body_p = NULL;
    uint32_t                       cmd_size = sizeof(*cmd_body_p);
    uint32_t                       req_count = 0;

    UNUSED_PARAM(inst_filter_p);

    SX_API_LOG_ENTER();

    if (inst_cnt_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    req_count = *inst_cnt_p;
    /* O/W: */
    if ((inst_list_p == NULL) && (req_count > 0)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }
    /* O/W: */
    if (req_count > SX_MSTP_INST_ID_MAX) {
        req_count = SX_MSTP_INST_ID_MAX;
    }

    /* O/W: */
    cmd_size += req_count * sizeof(sx_mstp_inst_id_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    /* O/W: */
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_id = swid;
    cmd_body_p->inst_key = inst_key;
    cmd_body_p->inst_num = req_count;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_ITER_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_PASS(rc)) {
        *inst_cnt_p = cmd_body_p->inst_num;
        if ((inst_list_p != NULL) && (*inst_cnt_p > 0) && (req_count > 0)) {
            SX_MEM_CPY_ARRAY(inst_list_p, cmd_body_p->inst_list, *inst_cnt_p, sx_mstp_inst_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_inst_vlan_list_set(const sx_api_handle_t   handle,
                                           const sx_access_cmd_t   cmd,
                                           const sx_swid_t         swid,
                                           const sx_mstp_inst_id_t inst_id,
                                           const sx_vlan_id_t     *vlan_list_p,
                                           const uint32_t          vlan_cnt)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_mstp_inst_vlan_list_set_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_mstp_inst_vlan_list_set_params_t);

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:


        /* O/W: */
        if (NULL == vlan_list_p) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }

        cmd_size += (vlan_cnt) * sizeof(sx_vlan_id_t);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", rc);
        if (SX_CHECK_FAIL(rc)) {
            SX_API_LOG_EXIT();
            return rc;
        }

        /* O/W: */
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_id = swid;
    cmd_body_p->inst_id = inst_id;
    cmd_body_p->vlan_num = vlan_cnt;

    SX_MEM_CPY_ARRAY(cmd_body_p->vlan_list, vlan_list_p, vlan_cnt, sx_vlan_id_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_VLAN_LIST_SET_E, (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_inst_vlan_list_get(const sx_api_handle_t   handle,
                                           const sx_swid_t         swid,
                                           const sx_mstp_inst_id_t inst_id,
                                           sx_vlan_id_t           *vlan_list_p,
                                           uint32_t               *vlan_cnt_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                          cmd;
    sx_api_mstp_inst_vlan_list_get_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_mstp_inst_vlan_list_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (FALSE == SX_MSTP_INST_ID_CHECK_RANGE(inst_id)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */
    if (NULL == vlan_cnt_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == vlan_list_p) {
        cmd = SX_ACCESS_CMD_COUNT;
    } else {
        if (0 == *vlan_cnt_p) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd = SX_ACCESS_CMD_GET;
        cmd_size += (*vlan_cnt_p) * sizeof(sx_vlan_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid_id = swid;
    cmd_body_p->inst_id = inst_id;
    cmd_body_p->vlan_num = *vlan_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_VLAN_LIST_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *vlan_cnt_p = cmd_body_p->vlan_num;
        if (NULL != vlan_list_p) {
            SX_MEM_CPY_ARRAY(vlan_list_p, cmd_body_p->vlan_list, *vlan_cnt_p, sx_vlan_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_inst_port_state_set(const sx_api_handle_t           handle,
                                            const sx_swid_t                 swid,
                                            const sx_mstp_inst_id_t         inst_id,
                                            const sx_port_log_id_t          log_port,
                                            const sx_mstp_inst_port_state_t port_state)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_mstp_inst_port_state_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .swid_id = swid,
        .inst_id = inst_id,
        .port_id = log_port,
        .port_state = port_state
    };
    uint32_t                                 cmd_size = sizeof(sx_api_mstp_inst_port_state_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (FALSE == SX_MSTP_INST_PORT_STATE_CHECK_RANGE(port_state)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_PORT_STATE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_inst_port_state_get(const sx_api_handle_t      handle,
                                            const sx_swid_t            swid,
                                            const sx_mstp_inst_id_t    inst_id,
                                            const sx_port_log_id_t     log_port,
                                            sx_mstp_inst_port_state_t *port_state_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_api_mstp_inst_port_state_get_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .swid_id = swid,
        .inst_id = inst_id,
        .port_id = log_port,
        .port_state = 0
    };
    uint32_t                                 cmd_size = sizeof(sx_api_mstp_inst_port_state_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == port_state_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MSTP_INST_PORT_STATE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *port_state_p = cmd_body.port_state;
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_rstp_port_state_set(const sx_api_handle_t           handle,
                                       const sx_port_log_id_t          log_port,
                                       const sx_mstp_inst_port_state_t port_state)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_rstp_port_state_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .port_id = log_port,
        .port_state = port_state,
    };
    uint32_t                            cmd_size = sizeof(sx_api_rstp_port_state_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (FALSE == SX_MSTP_INST_PORT_STATE_CHECK_RANGE(port_state)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_RSTP_PORT_STATE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_rstp_port_state_get(const sx_api_handle_t      handle,
                                       const sx_port_log_id_t     log_port,
                                       sx_mstp_inst_port_state_t *port_state_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_rstp_port_state_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .port_id = log_port,
        .port_state = 0
    };
    uint32_t                            cmd_size = sizeof(sx_api_rstp_port_state_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == port_state_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_RSTP_PORT_STATE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *port_state_p = cmd_body.port_state;
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_exclude_port_state_set(const sx_api_handle_t              handle,
                                               const sx_port_log_id_t             log_port,
                                               const sx_mstp_exclude_port_state_t port_state)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_mstp_excluded_port_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .port_id = log_port,
        .state = port_state
    };
    uint32_t                               cmd_size = sizeof(sx_api_mstp_excluded_port_set_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MSTP_EXCLUDE_PORT_STATE_SET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_mstp_exclude_port_state_get(const sx_api_handle_t         handle,
                                               const sx_port_log_id_t        log_port,
                                               sx_mstp_exclude_port_state_t *port_state_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_mstp_excluded_port_get_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .port_id = log_port,
        .state = SX_MSTP_EXCLUDE_PORT_STATE_NORMAL_E
    };
    uint32_t                               cmd_size = sizeof(sx_api_mstp_excluded_port_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == port_state_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MSTP_EXCLUDE_PORT_STATE_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *port_state_p = cmd_body.state;
    }

    SX_API_LOG_EXIT();

    return rc;
}
