/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

/*
 *                  - Mellanox Proprietary -
 *
 *  Copyright (C) January 2010, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein, no portion of the information,
 *  including but not limited to object code and source code, may be reproduced,
 *  modified, distributed, republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "LICENSE.txt".
 */

#include "sx_api_internal.h"
#include <sx/sdk/sx_flex_acl.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <fcntl.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_shared_memory.h>

#undef  __MODULE__
#define __MODULE__ SX_API_ACL

extern sx_verbosity_level_t LOG_VAR_NAME(__MODULE__);

/************************************************
 *  MACROS
 ***********************************************/

#define BASIC_ACL_LEGACY_KEYS_NUM 20
/************************************************
 *  GLOBAL VARIABLES
 ***********************************************/


/************************************************
 *  LOCAL VARIABLES
 ***********************************************/
static sx_acl_drop_wjh_trap_index_t *wjh_acl_drp_shm_db_p = NULL;


/************************************************
 *  API functions
 ***********************************************/

sx_status_t sx_api_acl_flex_key_set(const sx_api_handle_t handle,
                                    const sx_access_cmd_t cmd,
                                    const sx_acl_key_t  * key_list_p,
                                    const uint32_t        key_count,
                                    sx_acl_key_type_t   * key_handle_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size;
    sx_api_flex_acl_key_set_params_t cmd_body = {
        .cmd = cmd,
        .keys_count = key_count,
    };

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        SX_LOG_ERR("cmd %u is set supported\n", SX_ACCESS_CMD_CREATE);
        SX_LOG_ERR("cmd %u is des supported\n", SX_ACCESS_CMD_DESTROY);

        SX_API_LOG_EXIT();

        return SX_STATUS_CMD_UNSUPPORTED;
    }

    if (key_handle_p == NULL) {
        SX_LOG_ERR("key_handle_p is NULL \n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.key_handle = *key_handle_p;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (NULL == key_list_p) {
            SX_LOG_ERR("key_list_p is NULL \n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
        if (0 == key_count) {
            SX_LOG_ERR(" key_count is 0 \n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
        if (RM_API_ACL_MAX_FIELDS_IN_KEY < key_count) {
            SX_LOG_ERR(" key_count is bigger then max \n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
        memcpy(&cmd_body.keys[0], &key_list_p[0], sizeof(cmd_body.keys[0]) * key_count);
    }

    cmd_size = sizeof(sx_api_flex_acl_key_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_KEY_SET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *key_handle_p = cmd_body.key_handle;
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_flex_key_get(const sx_api_handle_t   handle,
                                    const sx_acl_key_type_t key_handle,
                                    sx_acl_key_t           *key_list_p,
                                    uint32_t              * key_count_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size;
    sx_api_flex_acl_key_get_params_t cmd_body = {
        .key_handle = key_handle,
        .keys_count = 0
    };

    SX_API_LOG_ENTER();

    if (NULL == key_count_p) {
        SX_LOG_ERR("key_count_p is NULL \n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((NULL == key_list_p) && (*key_count_p != 0)) {
        SX_LOG_ERR("key_list_p is NULL \n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_size = sizeof(sx_api_flex_acl_key_get_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_KEY_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *key_count_p = cmd_body.keys_count;
        if (NULL != key_list_p) {
            memcpy(&key_list_p[0], &cmd_body.keys[0], sizeof(cmd_body.keys[0]) * cmd_body.keys_count);
        }
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_acl_flex_rules_set(const sx_api_handle_t          handle,
                                      const sx_access_cmd_t          cmd,
                                      const sx_acl_region_id_t       region_id,
                                      sx_acl_rule_offset_t          *offsets_list_p,
                                      const sx_flex_acl_flex_rule_t *rules_list_p,
                                      const uint32_t                 rules_cnt)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    uint32_t                           buffer_size = 0;
    uint8_t                           *buffer = NULL;
    sx_api_flex_acl_rules_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(sx_api_flex_acl_rules_set_params_t));

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (0 == rules_cnt) {
        SX_LOG_ERR("rules_cnt is 0\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (RM_API_ACL_FLEX_RULES_BLOCK_MAX < rules_cnt) {
        SX_LOG_ERR("rules_cnt %d is bigger than max %d\n", rules_cnt, RM_API_ACL_FLEX_RULES_BLOCK_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == offsets_list_p) {
        SX_LOG_ERR("offsets_list_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Initialize cmd_body */
    cmd_body.cmd = cmd;
    cmd_body.region_id = region_id;
    cmd_body.rules_count = rules_cnt;
    cmd_body.offsets_list_p = offsets_list_p;
    cmd_body.rules = (sx_flex_acl_flex_rule_t*)rules_list_p;
    SX_LOG_DBG("rules count %u\n", rules_cnt);

    /* Decide which serialization cmd to use  */
    if (cmd == SX_ACCESS_CMD_SET) {
        if (NULL == rules_list_p) {
            SX_LOG_ERR("rules_list_p is NULL \n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    /* Get size of the buffer needed for parameters serialization */
    err = sx_api_serialize_flex_acl_rule_set_params(&cmd_body, NULL, &buffer_size, RULES_GET_FULL_E);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed serialize rules \n");
        goto free_res;
    }

    if (buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed serialize rules, message size %d exceeds limit %d\n", buffer_size,
                   SX_API_MESSAGE_SIZE_LIMIT);
        err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto free_res;
    }

    /* Allocate and clean the buffer for cmd_body */
    buffer = (uint8_t*)cl_malloc(buffer_size);
    if (buffer == NULL) {
        SX_LOG_ERR("Error at memory allocation\n");
        err = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    SX_MEM_CLR_BUF(buffer, buffer_size);
    SX_LOG_DBG("DEBUG  RULES count %u\n", rules_cnt);

    /* Serialize all the rules into the allocated buffer */
    err = sx_api_serialize_flex_acl_rule_set_params(&cmd_body, buffer, &buffer_size, RULES_GET_FULL_E);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed serialize rules \n");
        goto free_res;
    }

    /* Send call to the SDK */
    err = sx_api_send_command_wrapper(handle, SX_API_ACL_FLEX_RULES_SET_E, (uint8_t*)buffer, buffer_size);

free_res:
    cl_free(buffer);

out:
    SX_API_LOG_EXIT();
    return err;
}

/* the function returns buffer size and block size according to message size limit */
static sx_status_t __get_buffer_size_limit(sx_api_flex_acl_rules_set_params_t *rules_params,
                                           uint32_t                            remained_rules,
                                           uint32_t                           *buffer_size,
                                           uint32_t                           *block_size,
                                           rule_get_cmd_e                      get_cmd)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t    *original_offsets_list_p = rules_params->offsets_list_p;
    sx_flex_acl_flex_rule_t *original_rules = rules_params->rules;
    uint32_t                 rule_offset = 0;
    uint32_t                 rule_size = 0;
    uint32_t                 global_header_size = (uint32_t)offsetof(sx_api_flex_acl_rules_set_params_internal_t,
                                                                     offsets_list);
    uint32_t total_size = global_header_size;

    SX_API_LOG_ENTER();

    *block_size = 0;

    /* Go over all the rules and collect their sizes one by one
     * till we  don't have enough room in the message size.
     */
    for (rule_offset = 0; rule_offset < remained_rules; rule_offset++) {
        /* We only want to calculate the size of a single rule here so we send to
         * the serialization API the info of a single rule.
         */
        rules_params->rules_count = 1;
        rules_params->offsets_list_p = &(original_offsets_list_p[rule_offset]);
        rules_params->rules = &(original_rules[rule_offset]);

        err = sx_api_serialize_flex_acl_rule_set_params(rules_params, NULL, &rule_size, get_cmd);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fail at get rule size for buffer size limit, rc = %s\n", sx_status_str(err));
            goto out;
        }

        /* The above API always includes the size of the global header.
         * This should be counted only once and therefore subtracted here.
         */
        total_size += rule_size - global_header_size;
        if (total_size > SX_API_MESSAGE_SIZE_LIMIT) {
            break;
        }
    }

    /* Store the maximum number of rules we can get and restore the original pointers */
    *block_size = rule_offset;
    rules_params->rules_count = rule_offset;
    rules_params->offsets_list_p = original_offsets_list_p;
    rules_params->rules = original_rules;

    /* Get the buffer size for the number of rules that can actually fit in a single message */
    err = sx_api_serialize_flex_acl_rule_set_params(rules_params, NULL, buffer_size, get_cmd);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail at get serialization size for %u rules for buffer size, rc = %s\n",
                   rules_params->rules_count, sx_status_str(err));
        goto out;
    }

    /* Do a double check of the buffer size */
    if (*buffer_size > SX_API_MESSAGE_SIZE_LIMIT) {
        SX_LOG_ERR("Failed buffer size calculation for %u rules. Buffer size %u exceeds allowed %u\n",
                   rules_params->rules_count, *buffer_size, SX_API_MESSAGE_SIZE_LIMIT);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    /* In any case we want to restore the original pointers of the rule params */
    rules_params->offsets_list_p = original_offsets_list_p;
    rules_params->rules = original_rules;

    SX_API_LOG_EXIT();
    return err;
}


/*sx_flex_acl_flex_rule_t* rules_list_p should be allocated with rules init structure */
sx_status_t sx_api_acl_flex_rules_get(const sx_api_handle_t    handle,
                                      const sx_acl_region_id_t region_id,
                                      sx_acl_rule_offset_t   * offsets_list_p,
                                      sx_flex_acl_flex_rule_t* rules_list_p,
                                      uint32_t               * rules_cnt_p)
{
    uint32_t                                     buffer_size = 0;
    uint32_t                                     current_num_rules = 0;
    uint32_t                                     i = 0, rule_count = 0;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sx_api_flex_acl_rules_set_params_internal_t *set_params = NULL;
    rule_get_cmd_e                               get_cmd = RULES_GET_FULL_E;
    sx_api_flex_acl_rules_set_params_t           deserialized_params;
    uint8_t                                     *buffer = NULL;
    uint32_t                                     null_ptr_keys_cnt = 0;
    uint32_t                                     zero_offset_cnt = 0;

    SX_API_LOG_ENTER();

    buffer = (uint8_t*)cl_malloc(SX_API_MESSAGE_SIZE_LIMIT);
    if (buffer == NULL) {
        SX_LOG_ERR("Error at memory allocation\n");
        err = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    memset(&deserialized_params, 0, sizeof(deserialized_params));
    memset(buffer, 0, SX_API_MESSAGE_SIZE_LIMIT);

    if (rules_cnt_p == NULL) {
        SX_LOG_ERR("NULL param rules_cnt_p \n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*rules_cnt_p != 0) && ((rules_list_p == NULL) || (offsets_list_p == NULL))) {
        SX_LOG_ERR("NULL params\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Get rules count flow - partial serialization */
    if ((rules_list_p == NULL) || (*rules_cnt_p == 0)) {
        set_params = (sx_api_flex_acl_rules_set_params_internal_t*)buffer;
        set_params->region_id = region_id;
        set_params->rules_count = 0;
        set_params->offset_count = 0;
        set_params->get_cmd = RULES_GET_COUNT_E;
        set_params->total_rules_size = offsetof(sx_api_flex_acl_rules_set_params_internal_t, offsets_list);

        /* Send API call */
        buffer_size = set_params->total_rules_size;
        err = sx_api_send_command_wrapper(handle, SX_API_ACL_FLEX_RULES_GET_E, (uint8_t*)buffer, buffer_size);
        if (err != SX_STATUS_SUCCESS) {
            if (err != SX_STATUS_ENTRY_NOT_FOUND) {
                SX_LOG_ERR("sx_api_send_command_wrapper failed rc = %s\n", sx_status_str(err));
            }
            goto out;
        }

        *rules_cnt_p = set_params->rules_count;
        goto out;
    }

    /* Decide which type of rules_get should be chosen */
    for (i = 0; i < *rules_cnt_p; i++) {
        SX_LOG_DBG("rules_list_p[i].action_list_p = %p\n", rules_list_p[i].action_list_p);
        SX_LOG_DBG("rules_list_p[i].key_desc_list_p  = %p \n", rules_list_p[i].key_desc_list_p);

        if (rules_list_p[i].key_desc_list_p == NULL) {
            null_ptr_keys_cnt++;
        }

        if (offsets_list_p[i] == 0) {
            zero_offset_cnt++;
        }
    }

    if (null_ptr_keys_cnt == 0) {
        /* All keys are allocated */
        if (zero_offset_cnt > 1) {
            /* The offset list should be full*/
            SX_LOG_ERR("Offset list cannot be empty and should be filled with valid rules offsets \n");
            err = SX_STATUS_ERROR;
            goto out;
        } else {
            get_cmd = RULES_GET_FULL_E;
        }
    } else {
        /* Exist one or more empty rules */
        if (zero_offset_cnt > 1) {
            get_cmd = RULES_GET_INNER_COUNTS_AND_OFFSET_LIST_E;
            if (zero_offset_cnt != *rules_cnt_p) {
                /* The offset list should be empty */
                SX_LOG_ERR("Error: The offset list is not empty \n");
                err = SX_STATUS_ERROR;
                goto out;
            }
        } else {
            get_cmd = RULES_GET_INNER_COUNTS_BY_OFFSET_LIST_E;
        }

        /* The case of get one rule from offset 0 or first valid rule */
        if ((zero_offset_cnt == 1) && (*rules_cnt_p == 1)) {
            get_cmd = RULES_GET_INNER_COUNTS_AND_OFFSET_LIST_E;
        }

        if (null_ptr_keys_cnt != *rules_cnt_p) {
            SX_LOG_ERR("Error: part of rules in array aren't empty \n");
            err = SX_STATUS_ERROR;
            goto out;
        }
    }


    while (rule_count < *rules_cnt_p) {
        memset(buffer, 0, SX_API_MESSAGE_SIZE_LIMIT);
        /* Go to the next rules chunk location in rules and offsets array */
        deserialized_params.rules = rules_list_p + rule_count;
        deserialized_params.offsets_list_p = offsets_list_p + rule_count;

        /* Get buffer size and chunk size for current transaction IF the number of rules exceeds the range*/
        err = __get_buffer_size_limit(&deserialized_params,
                                      (*rules_cnt_p - rule_count),
                                      &buffer_size,
                                      &current_num_rules,
                                      get_cmd);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Fail at get size, rc = %s\n", sx_status_str(err));
            goto out;
        }

        set_params = (sx_api_flex_acl_rules_set_params_internal_t*)buffer;
        set_params->region_id = region_id;

        if ((get_cmd == RULES_GET_INNER_COUNTS_BY_OFFSET_LIST_E) || (get_cmd == RULES_GET_FULL_E)) {
            /* Copy offset list as input parameter */
            memcpy(set_params->offsets_list, deserialized_params.offsets_list_p,
                   sizeof(sx_acl_rule_offset_t) * current_num_rules);
        } else {
            /* Take next to the last returned offset */
            set_params->start_offset = (rule_count == 0) ? 0 : offsets_list_p[rule_count - 1] + 1;
        }

        set_params->get_cmd = get_cmd;
        set_params->rules_count = current_num_rules;
        err = sx_api_send_command_wrapper(handle, SX_API_ACL_FLEX_RULES_GET_E, (uint8_t*)buffer, buffer_size);
        if (err != SX_STATUS_SUCCESS) {
            if (err != SX_STATUS_ENTRY_NOT_FOUND) {
                SX_LOG_ERR("sx_api_send_command_wrapper failed rc = %s\n", sx_status_str(err));
            }
            goto out;
        }

        deserialized_params.rules_count = current_num_rules;
        err = sx_api_deserialize_flex_acl_rule_set_params(buffer, &deserialized_params, &buffer_size,
                                                          get_cmd, RM_API_ACL_MAX_FIELDS_IN_KEY);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed deserialize rules \n");
            goto out;
        }
        rule_count += deserialized_params.rules_count;

        /* If we didn't get any rules back we need to end the query */
        if (deserialized_params.rules_count == 0) {
            break;
        }
    }
    *rules_cnt_p = rule_count;

out:
    if (buffer) {
        cl_free(buffer);
        buffer = NULL;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rif_bind_set(const sx_api_handle_t handle,
                                    const sx_access_cmd_t cmd,
                                    const sx_rif_id_t     rif_id,
                                    const sx_acl_id_t     acl_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();
    sx_api_flex_acl_bind_params_t cmd_body = {
        .cmd = cmd,
        .rif = rif_id,
        .acl_id = acl_id,
    };

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
    case SX_ACCESS_CMD_UNBIND:
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(sx_api_flex_acl_bind_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RIF_BIND_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rif_bindings_get(const sx_api_handle_t    handle,
                                        const sx_rif_id_t        rif_id,
                                        const sx_acl_direction_t acl_direction,
                                        sx_acl_id_t             *acl_id_p,
                                        uint32_t                *acl_cnt_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    uint32_t                      cmd_size = 0;
    uint32_t                      i = 0;
    sx_api_acl_bind_get_params_t *cmd_body_p = NULL;

    SX_API_LOG_ENTER();

    if (acl_cnt_p == NULL) {
        SX_LOG_ERR("NULL ACL IDs count\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((acl_direction > SX_ACL_DIRECTION_MAX) || (acl_direction == SX_ACL_DIRECTION_MULTI_POINTS_E)) {
        SX_LOG_ERR("ACL direction is not supported: %s\n", sx_acl_direction_str(acl_direction));
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (acl_id_p == NULL) {
        *acl_cnt_p = 0;
    }

    cmd_size = sizeof(sx_api_acl_bind_get_params_t) + sizeof(sx_acl_id_t) * *acl_cnt_p;

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_acl_bind_get_params_t*)cl_calloc(1, cmd_size);
    if (cmd_body_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for command body\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_NO_RESOURCES;
    }

    cmd_body_p->acl_direction = acl_direction;
    cmd_body_p->rif = rif_id;
    cmd_body_p->acl_ids_num = *acl_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RIF_BIND_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *acl_cnt_p = cmd_body_p->acl_ids_num;

        if (acl_id_p) {
            for (i = 0; i < *acl_cnt_p; i++) {
                acl_id_p[i] = cmd_body_p->acl_id[i];
            }
        }
    }
    CL_FREE_N_NULL(cmd_body_p);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rif_bind_get(const sx_api_handle_t    handle,
                                    const sx_rif_id_t        rif_id,
                                    const sx_acl_direction_t acl_direction,
                                    sx_acl_id_t             *acl_id_p)
{
    uint32_t acl_num = 1;

    return sx_api_acl_rif_bindings_get(handle, rif_id, acl_direction, acl_id_p, &acl_num);
}

sx_status_t sx_api_acl_group_bind_set(sx_api_handle_t       handle,
                                      const sx_access_cmd_t cmd,
                                      sx_acl_id_t           group_id,
                                      sx_acl_id_t           next_group_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();
    sx_api_flex_acl_group_bind_params_t cmd_body = {
        .cmd = cmd,
        .group_id = group_id,
        .next_group_id = next_group_id,
    };

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(sx_api_flex_acl_group_bind_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GROUP_BIND_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_group_bind_get(sx_api_handle_t handle, sx_acl_id_t group_id, sx_acl_id_t*  group_id_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    uint32_t                            cmd_size;
    sx_api_flex_acl_group_bind_params_t cmd_body = {
        .cmd = 0,
        .group_id = group_id,
        .next_group_id = 0,
    };

    SX_API_LOG_ENTER();

    if (NULL == group_id_p) {
        SX_LOG_ERR("group_id_p is NULL \n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_size = sizeof(sx_api_flex_acl_group_bind_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GROUP_BIND_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        *group_id_p = cmd_body.next_group_id;
    }


    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_lib_flex_acl_rule_init(const sx_acl_key_type_t  key_handle,
                                      uint32_t                 num_of_actions,
                                      sx_flex_acl_flex_rule_t *rule)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    keys_count = 0;

    SX_API_LOG_ENTER();

    keys_count = GET_NUM_OF_KEYS(key_handle);
    if (key_handle < SX_ACL_KEY_TYPE_LAST) {
        keys_count = BASIC_ACL_LEGACY_KEYS_NUM;
    }

    if (NULL == rule) {
        SX_LOG(SX_LOG_ERROR, "Null ptr for rule\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rule->priority = FLEX_ACL_INVALID_RULE_PRIORITY;

    /* allocate place for keys */
    rule->key_desc_list_p = (sx_flex_acl_key_desc_t*)cl_malloc(
        sizeof(sx_flex_acl_key_desc_t) * keys_count);
    if (NULL == rule->key_desc_list_p) {
        SX_LOG(SX_LOG_ERROR, "Failed memory allocation for flex rule keys\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(rule->key_desc_list_p, 0, sizeof(sx_flex_acl_key_desc_t) * keys_count);
    rule->key_desc_count = keys_count;

    /* allocate place for actions */
    rule->action_list_p = (sx_flex_acl_flex_action_t*)cl_malloc(
        sizeof(sx_flex_acl_flex_action_t) * num_of_actions);
    if (NULL == rule->action_list_p) {
        SX_LOG(SX_LOG_ERROR, "Failed memory allocation for flex rule actions\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto rollback_keys_alloc;
    }
    memset(rule->action_list_p, 0, sizeof(sx_flex_acl_flex_action_t) * num_of_actions);
    rule->action_count = num_of_actions;

    goto out;

rollback_keys_alloc:
    cl_free(rule->key_desc_list_p);
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_lib_flex_acl_rule_deinit(sx_flex_acl_flex_rule_t *rule)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (NULL == rule) {
        SX_LOG(SX_LOG_ERROR, "Null ptr for rule\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL != rule->key_desc_list_p) {
        cl_free(rule->key_desc_list_p);
        rule->key_desc_list_p = NULL;
        rule->key_desc_count = 0;
    }
    if (NULL != rule->action_list_p) {
        cl_free(rule->action_list_p);
        rule->action_list_p = NULL;
        rule->action_count = 0;
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_acl_port_list_set(const sx_api_handle_t     handle,
                                     const sx_access_cmd_t     cmd,
                                     sx_acl_port_list_entry_t *port_list_p,
                                     const uint32_t            port_list_cnt,
                                     sx_acl_port_list_id_t    *port_list_id_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    cmd_size;
    sx_api_rx_list_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(sx_api_rx_list_set_params_t));
    cmd_body.cmd = cmd;

    if (port_list_cnt > RM_API_ACL_PORT_LIST_MAX) {
        SX_LOG_ERR("port list count:%d out of range:%d\n", port_list_cnt, RM_API_ACL_PORT_LIST_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_DESTROY) || (cmd == SX_ACCESS_CMD_SET)) {
        if (NULL == port_list_id_p) {
            SX_LOG_ERR("port_list_id_p is NULL \n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.port_list_id = *port_list_id_p;
    }

    if (NULL != port_list_p) {
        memcpy(&cmd_body.port_list, port_list_p, sizeof(sx_acl_port_list_entry_t) * port_list_cnt);
    }

    cmd_body.port_list_count = port_list_cnt;
    cmd_size = sizeof(sx_api_rx_list_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_PORT_LIST_SET_E, (uint8_t*)&cmd_body, cmd_size);

    /* in case the command was add we need to change it to add ports for next round */
    if (cmd == SX_ACCESS_CMD_CREATE) {
        *port_list_id_p = cmd_body.port_list_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_port_list_get(const sx_api_handle_t       handle,
                                     const sx_acl_port_list_id_t port_list_id,
                                     sx_acl_port_list_entry_t   *port_list_p,
                                     uint32_t                   *port_list_cnt_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    cmd_size;
    sx_api_rx_list_set_params_t cmd_body;
    uint32_t                    entry_to_copy_count;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(sx_api_rx_list_set_params_t));
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_size = sizeof(sx_api_rx_list_set_params_t);
    cmd_body.port_list_id = port_list_id;

    if (port_list_p == NULL) {
        SX_LOG_DBG("Return port list counter \n");
        err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_PORT_LIST_GET_E, (uint8_t*)&cmd_body, cmd_size);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
        *port_list_cnt_p = cmd_body.port_list_count;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_PORT_LIST_GET_E, (uint8_t*)&cmd_body, cmd_size);

    entry_to_copy_count = (cmd_body.port_list_count < *port_list_cnt_p) ? cmd_body.port_list_count : *port_list_cnt_p;
    *port_list_cnt_p = entry_to_copy_count;
    memcpy(port_list_p, &cmd_body.port_list, sizeof(sx_acl_port_list_entry_t) * entry_to_copy_count);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_custom_bytes_set(const sx_api_handle_t                       handle,
                                        const sx_access_cmd_t                       cmd,
                                        const sx_acl_custom_bytes_set_attributes_t *custom_bytes_set_attributes,
                                        sx_acl_key_t                               *custom_bytes_set_key_id_p,
                                        uint32_t                                   *custom_bytes_set_key_id_cnt_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size, i;
    sx_api_custom_bytes_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    cmd_size = sizeof(sx_api_custom_bytes_set_params_t);
    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;

    if (NULL == custom_bytes_set_key_id_p) {
        SX_LOG_ERR("custom_bytes_set_key_id_p is NULL \n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_DESTROY:
        cmd_body.custom_bytes_set_key_id_p[0] = custom_bytes_set_key_id_p[0];
        break;

    case SX_ACCESS_CMD_EDIT:
        cmd_body.custom_bytes_set_key_id_p[0] = custom_bytes_set_key_id_p[0];
        cmd_body.custom_bytes_set_attributes = *custom_bytes_set_attributes;
        break;

    case SX_ACCESS_CMD_CREATE:
        cmd_body.custom_bytes_set_key_id_count = MIN(*custom_bytes_set_key_id_cnt_p,
                                                     RM_API_ACL_MAX_BYTES_IN_CUSTOM_BYTES_SET);
        cmd_body.custom_bytes_set_attributes = *custom_bytes_set_attributes;
        if (cmd_body.custom_bytes_set_key_id_count > 0) {
            cmd_body.custom_bytes_set_key_id_p[0] = custom_bytes_set_key_id_p[0];
        }
        break;

    default:
        SX_LOG_ERR("cmd %u is not supported\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_CUSTOM_BYTES_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (cmd == SX_ACCESS_CMD_CREATE) {
        for (i = 0; i < cmd_body.custom_bytes_set_key_id_count; i++) {
            custom_bytes_set_key_id_p[i] = cmd_body.custom_bytes_set_key_id_p[i];
        }
        *custom_bytes_set_key_id_cnt_p = cmd_body.custom_bytes_set_key_id_count;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_custom_bytes_get(const sx_api_handle_t                 handle,
                                        const sx_acl_key_t                   *custom_bytes_set_key_id_p,
                                        sx_acl_custom_bytes_set_attributes_t *custom_bytes_set_attributes_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size;
    sx_api_custom_bytes_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, sizeof(sx_api_custom_bytes_set_params_t));
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_size = sizeof(sx_api_custom_bytes_set_params_t);
    cmd_body.custom_bytes_set_key_id_p[0] = custom_bytes_set_key_id_p[0];

    if (custom_bytes_set_attributes_p == NULL) {
        SX_LOG_ERR("custom_bytes_set_attributes_p is NULL \n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_CUSTOM_BYTES_GET_E, (uint8_t*)&cmd_body, cmd_size);

    *custom_bytes_set_attributes_p = cmd_body.custom_bytes_set_attributes;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_flex_key_attr_get(const sx_api_handle_t    handle,
                                         const sx_acl_key_type_t  key_handle,
                                         sx_acl_flex_key_attr_t * key_attr_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_size;
    sx_api_acl_flex_key_attr_get_params_t cmd_body;

    SX_API_LOG_ENTER();
    if (NULL == key_attr_p) {
        SX_LOG(SX_LOG_ERROR, "Null ptr for key attributes\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(sx_api_acl_flex_key_attr_get_params_t));
    cmd_size = sizeof(sx_api_acl_flex_key_attr_get_params_t);
    cmd_body.key_handle = key_handle;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_KEY_ATTR_GET_E, (uint8_t*)&cmd_body, cmd_size);

    *key_attr_p = cmd_body.key_attr;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_flex_rules_priority_set(const sx_api_handle_t             handle,
                                               const sx_acl_region_id_t          region_id,
                                               const sx_flex_acl_rule_priority_t min_priority,
                                               const sx_flex_acl_rule_priority_t max_priority,
                                               const int32_t                     priority_change)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_acl_flex_rules_priority_set_params_t cmd_body;
    uint32_t                                    cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (min_priority > max_priority) {
        SX_LOG(SX_LOG_ERROR, "Min priority is bigger than max priority\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.region_id = region_id;
    cmd_body.min_priority = min_priority;
    cmd_body.max_priority = max_priority;
    cmd_body.priority_change = priority_change;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RULES_PRIORITY_SET_E, (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_attributes_set(const sx_api_handle_t     handle,
                                      const sx_access_cmd_t     cmd,
                                      const sx_acl_id_t         acl_id,
                                      const sx_acl_attributes_t acl_attributes)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       cmd_size;
    uint32_t                       acl_description_len = acl_attributes.acl_desc.acl_name_str_len;
    sx_api_acl_attrib_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("unsupported command\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (acl_description_len > SX_API_ACL_DESCRIPTION_STR_LEN_MAX) {
        SX_LOG_ERR("ACL Name String Len [%u] Too Long. Max Len = %u chars\n",
                   acl_description_len, SX_API_ACL_DESCRIPTION_STR_LEN_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    memset(&cmd_body, 0, sizeof(cmd_body));

    cmd_body.cmd = cmd;
    cmd_body.acl_id = acl_id;
    cmd_body.acl_attributes.disable_acl_drop_monitoring_trap = acl_attributes.disable_acl_drop_monitoring_trap;

    if (acl_description_len) {
        SX_MEM_CPY(cmd_body.acl_attributes.acl_desc, acl_attributes.acl_desc);
    }

    SX_MEM_CPY(cmd_body.acl_attributes.multi_direction, acl_attributes.multi_direction);

    if (acl_attributes.macsec_attr.log_port_valid) {
        cmd_body.acl_attributes.macsec_attr.log_port_valid = acl_attributes.macsec_attr.log_port_valid;
        cmd_body.acl_attributes.macsec_attr.log_port = acl_attributes.macsec_attr.log_port;
    }

    cmd_size = sizeof(sx_api_acl_attrib_set_params_t);
    err = sx_api_send_command_wrapper(handle, SX_API_ACL_ATTRIBUTES_SET_E, (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_attributes_get(const sx_api_handle_t handle,
                                      const sx_acl_id_t     acl_id,
                                      sx_acl_attributes_t  *acl_attributes_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       cmd_size;
    sx_api_acl_attrib_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (acl_attributes_p == NULL) {
        SX_LOG_ERR("Null ptr for acl attributes\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(sx_api_acl_attrib_get_params_t));

    cmd_body.acl_id = acl_id;
    cmd_size = sizeof(sx_api_acl_attrib_get_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_ACL_ATTRIBUTES_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        acl_attributes_p->disable_acl_drop_monitoring_trap = cmd_body.acl_attributes.disable_acl_drop_monitoring_trap;

        if (cmd_body.acl_attributes.acl_desc.acl_name_str_len) {
            SX_MEM_CPY(acl_attributes_p->acl_desc, cmd_body.acl_attributes.acl_desc);
        } else {
            acl_attributes_p->acl_desc.acl_name_str_len = 0;
            acl_attributes_p->acl_desc.acl_name_str[0] = '\0';
        }

        SX_MEM_CPY(acl_attributes_p->multi_direction, cmd_body.acl_attributes.multi_direction);
    } else {
        SX_LOG_ERR("sx_api_send_command_wrapper failed rc = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}
sx_status_t sx_api_acl_global_attributes_set(const sx_api_handle_t            handle,
                                             const sx_access_cmd_t            cmd,
                                             const sx_acl_global_attributes_t global_acl_attributes)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_size;
    sx_api_global_acl_attrib_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("unsupported command\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(sx_api_global_acl_attrib_set_params_t));

    cmd_body.cmd = cmd;
    cmd_body.global_acl_attr.disable_acl_drop_trap = global_acl_attributes.disable_acl_drop_trap;

    cmd_size = sizeof(cmd_body);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GLOBAL_ATTR_SET_E, (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_acl_global_attributes_get(const sx_api_handle_t       handle,
                                             sx_acl_global_attributes_t *global_acl_attributes_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    uint32_t                              cmd_size;
    sx_api_global_acl_attrib_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (global_acl_attributes_p == NULL) {
        SX_LOG_ERR("Null ptr for global acl attributes\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&cmd_body, 0, sizeof(sx_api_global_acl_attrib_get_params_t));

    cmd_size = sizeof(cmd_body);
    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GLOBAL_ATTR_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        SX_MEM_CPY(*global_acl_attributes_p, cmd_body.global_acl_attr);
    } else {
        SX_LOG_ERR("sx_api_send_command_wrapper failed rc = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_group_attributes_set(const sx_api_handle_t            handle,
                                            const sx_access_cmd_t            cmd,
                                            const sx_acl_id_t                acl_group_id,
                                            const sx_acl_group_attributes_t *acl_group_attr_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    uint32_t                           cmd_size;
    uint32_t                           acl_grp_description_len = acl_group_attr_p->acl_group_desc.acl_name_str_len;
    sx_api_acl_grp_attrib_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("unsupported command\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (acl_grp_description_len > SX_API_ACL_DESCRIPTION_STR_LEN_MAX) {
        SX_LOG_ERR("ACL Name String Len [%u] Too Long. Max Len = %u chars\n",
                   acl_grp_description_len, SX_API_ACL_DESCRIPTION_STR_LEN_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if ((acl_group_attr_p->priority > FLEX_ACL_GROUP_PRIORITY_MAX) ||
        (acl_group_attr_p->priority < FLEX_ACL_GROUP_PRIORITY_MIN)) {
        SX_LOG(SX_LOG_ERROR, "Group priority out of range\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.acl_grp_id = acl_group_id;
    cmd_body.acl_grp_attributes.priority = acl_group_attr_p->priority;

    if (acl_grp_description_len) {
        SX_MEM_CPY(cmd_body.acl_grp_attributes.acl_group_desc, acl_group_attr_p->acl_group_desc);
    }

    cmd_size = sizeof(cmd_body);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GRP_ATTR_SET_E, (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_group_attributes_get(const sx_api_handle_t      handle,
                                            const sx_acl_id_t          acl_group_id,
                                            sx_acl_group_attributes_t *acl_group_attr_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    uint32_t                           cmd_size;
    sx_api_acl_grp_attrib_get_params_t cmd_body;
    uint32_t                           acl_grp_description_len = 0;
    char                               acl_grp_name[SX_API_ACL_DESCRIPTION_STR_LEN_MAX];

    SX_API_LOG_ENTER();
    SX_MEM_CLR(acl_grp_name);

    if (acl_group_attr_p == NULL) {
        SX_LOG_ERR("Null ptr for acl group_attributes\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.acl_grp_id = acl_group_id;
    cmd_body.acl_grp_attributes.acl_group_desc.acl_name_str_len = 0;

    cmd_size = sizeof(cmd_body);
    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_GRP_ATTR_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (err == SX_STATUS_SUCCESS) {
        acl_grp_description_len = cmd_body.acl_grp_attributes.acl_group_desc.acl_name_str_len;
        if (acl_grp_description_len) {
            SX_MEM_CPY(acl_group_attr_p->acl_group_desc,
                       cmd_body.acl_grp_attributes.acl_group_desc);
        } else {
            acl_group_attr_p->acl_group_desc.acl_name_str_len = 0;
            acl_group_attr_p->acl_group_desc.acl_name_str[0] = '\0';
        }
        acl_group_attr_p->priority = cmd_body.acl_grp_attributes.priority;
    } else {
        SX_LOG_ERR("sx_api_send_command_wrapper failed rc = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_lib_flex_acl_drop_pkt_acl_data_get(const uint32_t                acl_drop_trap_token,
                                                  sx_acl_pkt_drop_attributes_t *acl_drop_trap_acl_attrib_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    static int  rc, shmid = -1;

    SX_API_LOG_ENTER();

    if (acl_drop_trap_token > SX_ACL_USER_ID_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("acl drop token %u is greater than Max %u rc = %s\n", acl_drop_trap_token,
                   SX_ACL_USER_ID_MAX, sx_status_str(err));
        goto out;
    }
    if (acl_drop_trap_acl_attrib_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("acl_drop_trap_acl_attrib_p param is NULL rc = %s\n", sx_status_str(err));
        goto out;
    }

    /* access the SHM DPT table and get the data acc to ACL drop trap token */
    if (wjh_acl_drp_shm_db_p == NULL) {
        rc = cl_shm_open(WJH_ACL_SHM_PATH, &shmid);
        if (rc) {
            SX_LOG_ERR("Failed to open the WJH ACL shared memory\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        wjh_acl_drp_shm_db_p = mmap(NULL, sizeof(sx_acl_drop_wjh_trap_index_t),
                                    PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
        close(shmid);
        if (wjh_acl_drp_shm_db_p == MAP_FAILED) {
            SX_LOG_ERR("Failed to map the WJH ACL shared memory\n");
            wjh_acl_drp_shm_db_p = NULL;
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    cl_plock_acquire(&wjh_acl_drp_shm_db_p->p_lock);
    if (wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].trap_usr_def_val
        != acl_drop_trap_token) {
        /* coverity[lock_order] */
        SX_LOG_ERR("Invalid mapping between index[%u] and usr-def-val[%u] in WJH ACL shared memory\n",
                   acl_drop_trap_token,
                   wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].trap_usr_def_val);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto release_lock;
    }

    if (wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].valid == FALSE) {
        /* coverity[lock_order] */
        SX_LOG_NTC(" ACL data at index [%u] is not valid, Monitoring may be disabled.Please use data with caution \n",
                   acl_drop_trap_token);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto release_lock;
    }
    acl_drop_trap_acl_attrib_p->valid
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].valid;
    acl_drop_trap_acl_attrib_p->acl_direction
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].acl_direction;
    acl_drop_trap_acl_attrib_p->trap_usr_def_val
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].trap_usr_def_val;
    acl_drop_trap_acl_attrib_p->acl_id
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].acl_id;
    acl_drop_trap_acl_attrib_p->acl_region_id
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].acl_region_id;
    acl_drop_trap_acl_attrib_p->acl_rule_offset
        = wjh_acl_drp_shm_db_p->acl_drp_trap_mapping[acl_drop_trap_token].acl_rule_offset;

release_lock:
    cl_plock_release(&wjh_acl_drp_shm_db_p->p_lock);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_activity_notify(const sx_api_handle_t                     handle,
                                       const sx_access_cmd_t                     cmd,
                                       const sx_flex_acl_activity_notify_attr_t *activity_attr_p)
{
    sx_api_acl_activity_notify_params_t cmd_body;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (activity_attr_p != NULL) {
        cmd_body.activity_notify_attr.filter_by_region_id = activity_attr_p->filter_by_region_id;
        cmd_body.activity_notify_attr.region_id = activity_attr_p->region_id;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_ACL_ACTIVITY_NOTIFY_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_rules_set(const sx_api_handle_t       handle,
                                     const sx_access_cmd_t       cmd,
                                     const sx_acl_rbb_rule_id_t *rules_id_list_p,
                                     const uint32_t              rules_id_cnt)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_rule_set_params_t *cmd_body_p = NULL;
    uint32_t                          cmd_size = 0;

    SX_API_LOG_ENTER();

    if (rules_id_list_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer RBB rule set list\n");
        goto out;
    }

    if (rules_id_cnt == 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Zero RBB rule set count\n");
        goto out;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_rbb_rule_set_params_t) + (sizeof(sx_acl_rbb_rule_id_t) * rules_id_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for RBB rule set exceeds maximum size of [%lu].\n", cmd_size, MAX_CMD_SIZE);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rule set\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body_p = (sx_api_acl_rbb_rule_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for RBB rule set\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->rbb_rules_cnt = rules_id_cnt;
    SX_MEM_CPY_ARRAY(&cmd_body_p->rbb_rules_list[0], rules_id_list_p, rules_id_cnt, sx_acl_rbb_rule_id_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_RULES_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }


out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_bind_set(const sx_api_handle_t               handle,
                                    const sx_access_cmd_t               cmd,
                                    const sx_acl_rbb_rule_id_t          rule_id,
                                    const sx_acl_rbb_classifier_attr_t *classifier_attr_p,
                                    const sx_acl_id_t                   group_id)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_bind_set_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB binding set\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (classifier_attr_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer RBB binding set list\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.group_id = group_id;
    cmd_body.rbb_classifier = *classifier_attr_p;
    cmd_body.rbb_rule_id = rule_id;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_BIND_SET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_bind_get(const sx_api_handle_t         handle,
                                    const sx_access_cmd_t         cmd,
                                    const sx_acl_rbb_rule_id_t    rule_id,
                                    sx_acl_rbb_classifier_attr_t *classifier_attr_p,
                                    sx_acl_id_t                  *group_id_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_bind_get_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB binding get\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((classifier_attr_p == NULL) || (group_id_p == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer RBB binding get list\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.rbb_rule_id = rule_id;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_BIND_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

    *classifier_attr_p = cmd_body.rbb_classifier;
    *group_id_p = cmd_body.group_id;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_acl_rbb_ports_group_set(const sx_api_handle_t               handle,
                                           const sx_access_cmd_t               cmd,
                                           const sx_acl_rbb_ports_group_cfg_t *rbb_ports_group_cfg_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_port_group_set_params_t *cmd_body_p = NULL;
    uint32_t                                cmd_size = 0;

    SX_API_LOG_ENTER();

    if (rbb_ports_group_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer RBB ports group set\n");
        goto out;
    }

    if (rbb_ports_group_cfg_p->port_list_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer list RBB ports group set\n");
        goto out;
    }

    if (rbb_ports_group_cfg_p->port_list_cnt == 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Zero RBB ports count\n");
        goto out;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_rbb_port_group_set_params_t) +
               (sizeof(sx_port_log_id_t) * rbb_ports_group_cfg_p->port_list_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for RBB ports group set exceeds maximum size of [%lu].\n", cmd_size,
                   MAX_CMD_SIZE);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB ports group set\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body_p = (sx_api_acl_rbb_port_group_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for RBB ports group set set\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->direction = rbb_ports_group_cfg_p->direction;
    cmd_body_p->port_cnt = rbb_ports_group_cfg_p->port_list_cnt;
    cmd_body_p->port_group = rbb_ports_group_cfg_p->port_group;
    SX_MEM_CPY_ARRAY(&cmd_body_p->port_list,
                     rbb_ports_group_cfg_p->port_list_p,
                     rbb_ports_group_cfg_p->port_list_cnt,
                     sx_port_log_id_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_PORT_GROUP_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_ports_group_get(const sx_api_handle_t         handle,
                                           const sx_access_cmd_t         cmd,
                                           sx_acl_rbb_ports_group_cfg_t *rbb_ports_group_cfg_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_port_group_get_params_t *cmd_body_p = NULL;
    uint32_t                                cmd_size = 0;

    SX_API_LOG_ENTER();

    if (rbb_ports_group_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL port list count pointer RBB ports group get\n");
        goto out;
    }


    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB ports group get\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* If the pointer to the list is NULL is equals to zero count */
    if (rbb_ports_group_cfg_p->port_list_p == NULL) {
        rbb_ports_group_cfg_p->port_list_cnt = 0;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_rbb_port_group_get_params_t) +
               (sizeof(sx_port_log_id_t) * rbb_ports_group_cfg_p->port_list_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for RBB ports group get exceeds maximum size of [%lu].\n", cmd_size,
                   MAX_CMD_SIZE);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_acl_rbb_port_group_get_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for RBB ports group set set\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->direction = rbb_ports_group_cfg_p->direction;
    cmd_body_p->port_group = rbb_ports_group_cfg_p->port_group;
    cmd_body_p->port_cnt = rbb_ports_group_cfg_p->port_list_cnt;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_PORT_GROUP_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

    if (rbb_ports_group_cfg_p->port_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(rbb_ports_group_cfg_p->port_list_p, &cmd_body_p->port_list, cmd_body_p->port_cnt,
                         sx_port_log_id_t);
    }
    rbb_ports_group_cfg_p->port_list_cnt = cmd_body_p->port_cnt;

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_rifs_group_set(const sx_api_handle_t              handle,
                                          const sx_access_cmd_t              cmd,
                                          const sx_acl_rbb_rifs_group_cfg_t *rbb_rifs_group_cfg_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_rif_group_set_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = 0;

    SX_API_LOG_ENTER();

    if (rbb_rifs_group_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer RBB rifs group set\n");
        goto out;
    }

    if (rbb_rifs_group_cfg_p->rif_list_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer list RBB rifs group set\n");
        goto out;
    }

    if (rbb_rifs_group_cfg_p->rif_list_cnt == 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Zero RBB rifs count\n");
        goto out;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_rbb_rif_group_set_params_t) +
               (sizeof(sx_rif_id_t) * rbb_rifs_group_cfg_p->rif_list_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for RBB rifs group set exceeds maximum size of [%lu].\n", cmd_size,
                   MAX_CMD_SIZE);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rifs group set\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body_p = (sx_api_acl_rbb_rif_group_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for RBB rifs group set set\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->direction = rbb_rifs_group_cfg_p->direction;
    cmd_body_p->rif_cnt = rbb_rifs_group_cfg_p->rif_list_cnt;
    cmd_body_p->rif_group = rbb_rifs_group_cfg_p->rif_group;
    SX_MEM_CPY_ARRAY(&cmd_body_p->rif_list,
                     rbb_rifs_group_cfg_p->rif_list_p,
                     rbb_rifs_group_cfg_p->rif_list_cnt,
                     sx_rif_id_t);

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_RIF_GROUP_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_rbb_rifs_group_get(const sx_api_handle_t        handle,
                                          const sx_access_cmd_t        cmd,
                                          sx_acl_rbb_rifs_group_cfg_t *rbb_rifs_group_cfg_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_api_acl_rbb_rif_group_get_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = 0;

    SX_API_LOG_ENTER();

    if (rbb_rifs_group_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL rif list count pointer RBB rifs group get\n");
        goto out;
    }


    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rifs group get\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* If the pointer to the list is NULL is equals to zero count */
    if (rbb_rifs_group_cfg_p->rif_list_p == NULL) {
        rbb_rifs_group_cfg_p->rif_list_cnt = 0;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_acl_rbb_rif_group_get_params_t) +
               (sizeof(sx_rif_id_t) * rbb_rifs_group_cfg_p->rif_list_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for RBB rifs group get exceeds maximum size of [%lu].\n", cmd_size,
                   MAX_CMD_SIZE);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_acl_rbb_rif_group_get_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for RBB rifs group set set\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->direction = rbb_rifs_group_cfg_p->direction;
    cmd_body_p->rif_group = rbb_rifs_group_cfg_p->rif_group;
    cmd_body_p->rif_cnt = rbb_rifs_group_cfg_p->rif_list_cnt;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_RBB_RIF_GROUP_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed RBB rule set - [%s]\n", sx_status_str(err));
        goto out;
    }

    if (rbb_rifs_group_cfg_p->rif_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(rbb_rifs_group_cfg_p->rif_list_p, &cmd_body_p->rif_list, cmd_body_p->rif_cnt, sx_rif_id_t);
    }
    rbb_rifs_group_cfg_p->rif_list_cnt = cmd_body_p->rif_cnt;

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_acl_flex_default_action_set(const sx_api_handle_t        handle,
                                               const sx_access_cmd_t        cmd,
                                               const sx_acl_region_id_t     region_id,
                                               sx_acl_default_action_cfg_t *default_action_cfg_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_acl_flex_default_action_set_params_t cmd_body;
    uint32_t                                    cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);


    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        SX_LOG_ERR("Unsupported command: [%s] for default action set\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_UNSET) {
        if (NULL == default_action_cfg_p) {
            SX_LOG(SX_LOG_ERROR, "Null ptr for configured default actions\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((default_action_cfg_p->action_count < 1) ||
            (default_action_cfg_p->action_count > SX_ACL_DEFAULT_ACTION_CNT_MAX)) {
            SX_LOG_ERR("Number of actions [%d] exceeds the range of [1-%d]\n",
                       default_action_cfg_p->action_count,
                       SX_ACL_DEFAULT_ACTION_CNT_MAX);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    cmd_body.cmd = cmd;
    cmd_body.region_id = region_id;

    if (cmd != SX_ACCESS_CMD_UNSET) {
        cmd_body.default_action_cfg.action_count = default_action_cfg_p->action_count;
        SX_MEM_CPY_ARRAY(&cmd_body.default_action_cfg.action_list,
                         default_action_cfg_p->action_list,
                         default_action_cfg_p->action_count,
                         sx_flex_acl_flex_action_t);
    }

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_DEFAULT_ACTION_SET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed default action set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_acl_flex_default_action_get(const sx_api_handle_t        handle,
                                               const sx_access_cmd_t        cmd,
                                               const sx_acl_region_id_t     region_id,
                                               sx_acl_default_action_cfg_t *default_action_cfg_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_acl_flex_default_action_get_params_t cmd_body;
    uint32_t                                    cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (NULL == default_action_cfg_p) {
        SX_LOG(SX_LOG_ERROR, "Null ptr for configured default actions\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for default action get\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.region_id = region_id;

    err = sx_api_send_command_wrapper(handle, SX_API_FLEX_ACL_DEFAULT_ACTION_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed default action get region_id [%d] - [%s]\n", region_id, sx_status_str(err));
        goto out;
    }

    if (default_action_cfg_p->action_count > SX_ACL_DEFAULT_ACTION_CNT_MAX) {
        SX_LOG_ERR("Number of actions [%d] exceeds the range of [0-%d]\n",
                   default_action_cfg_p->action_count,
                   SX_ACL_DEFAULT_ACTION_CNT_MAX);
        err = SX_STATUS_ERROR;
        goto out;
    }

    default_action_cfg_p->action_count = cmd_body.default_action_cfg.action_count;

    if (default_action_cfg_p->action_count > 0) {
        SX_MEM_CPY_ARRAY(default_action_cfg_p->action_list,
                         cmd_body.default_action_cfg.action_list,
                         cmd_body.default_action_cfg.action_count,
                         sx_flex_acl_flex_action_t);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}
