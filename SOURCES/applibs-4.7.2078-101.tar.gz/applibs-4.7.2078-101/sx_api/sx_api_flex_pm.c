/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_flex_pm.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_FLEX_PM


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_flex_pm_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                   const sx_log_verbosity_target_t verbosity_target,
                                                   const sx_verbosity_level_t      module_verbosity_level,
                                                   const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLEX_PM_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_pm_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                   const sx_log_verbosity_target_t verbosity_target,
                                                   sx_verbosity_level_t           *module_verbosity_level_p,
                                                   sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLEX_PM_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_pm_app_set(const sx_api_handle_t        handle,
                                   const sx_access_cmd_t        cmd,
                                   sx_flex_pm_app_key_t        *key_p,
                                   const sx_flex_pm_app_attr_t *attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_set_params_t* cmd_body_p = NULL;
    uint32_t                         cmd_size = 0;

    SX_API_LOG_ENTER();

    if (key_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("The given key_p is NULL\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_EDIT:
        if (attr_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given attr_p is NULL\n");
            goto out;
        }
        if (attr_p->app_resources.resources_list_cnt > 0) {
            if (SX_CHECK_FAIL(err = utils_check_pointer(attr_p->app_resources.resources_list, "resources_list"))) {
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        break;

    default:
        SX_LOG_ERR("Unsupported command: [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_flex_pm_app_set_params_t) +
               (sizeof(sx_flex_pm_app_resource_t) * attr_p->app_resources.resources_list_cnt);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex_pm_app_set exceeds range.\n", cmd_size);
        err = SX_STATUS_ERROR;
        goto out;
    }

    cmd_body_p = (sx_api_flex_pm_app_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex_pm_app_set command body\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->key = *key_p;
    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_EDIT:
        cmd_body_p->attr_resources_list_cnt = attr_p->app_resources.resources_list_cnt;
        SX_MEM_CPY_ARRAY(cmd_body_p->attr_resources_list,
                         attr_p->app_resources.resources_list,
                         attr_p->app_resources.resources_list_cnt,
                         sx_flex_pm_app_resource_t);
        break;

    default:
        break;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PM_APP_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex_pm_app_set - [%s]\n", sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        *key_p = cmd_body_p->key;
        break;

    default:
        break;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_pm_app_get(const sx_api_handle_t      handle,
                                   const sx_access_cmd_t      cmd,
                                   const sx_flex_pm_app_key_t key,
                                   sx_flex_pm_app_attr_t     *attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_set_params_t* cmd_body_p = NULL;
    uint32_t                         cmd_size = 0;
    sx_access_cmd_t                  internal_cmd = cmd;

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (attr_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given attr_p is NULL\n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command: [%s] \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_size = sizeof(sx_api_flex_pm_app_get_params_t);
    if ((attr_p->app_resources.resources_list == NULL)) {
        internal_cmd = SX_ACCESS_CMD_COUNT;
    } else {
        cmd_size += (sizeof(sx_flex_pm_app_resource_t) * attr_p->app_resources.resources_list_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex_pm_app_get exceeds range.\n", cmd_size);
        err = SX_STATUS_ERROR;
        goto out;
    }

    cmd_body_p = (sx_api_flex_pm_app_get_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex_pm_app_get command body\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }
    cmd_body_p->cmd = internal_cmd;
    cmd_body_p->key = key;
    cmd_body_p->attr_resources_list_cnt = attr_p->app_resources.resources_list_cnt;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PM_APP_GET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex_pm_app_get - [%s]\n", sx_status_str(err));
        goto out;
    }

    attr_p->app_resources.resources_list_cnt = cmd_body_p->attr_resources_list_cnt;
    if (attr_p->app_resources.resources_list != NULL) {
        SX_MEM_CPY_ARRAY(attr_p->app_resources.resources_list,
                         cmd_body_p->attr_resources_list,
                         cmd_body_p->attr_resources_list_cnt,
                         sx_flex_pm_app_resource_t);
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_pm_app_state_set(const sx_api_handle_t              handle,
                                         const sx_access_cmd_t              cmd,
                                         const sx_flex_pm_app_key_t        *key_p,
                                         const sx_flex_pm_app_state_attr_t *attr_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_state_set_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (attr_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given attr_p is NULL\n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command: [%s] \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.key, key_p);
    SX_MEM_CPY_P(&cmd_body.attr, attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PM_APP_STATE_SET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex_pm_app_state_set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_pm_app_program_context_set(const sx_api_handle_t                          handle,
                                                   const sx_access_cmd_t                          cmd,
                                                   const sx_flex_pm_app_program_context_key_t    *key_list,
                                                   const sx_flex_pm_app_program_context_config_t *config_list,
                                                   const uint32_t                                 context_cnt)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_program_context_set_params_t *cmd_body_p = NULL;
    uint32_t                                         cmd_size = 0, i = 0;

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (config_list == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given config_list is NULL\n");
            goto out;
        }

    /* fallthrough */
    case SX_ACCESS_CMD_DELETE:
        if (key_list == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given key_list is NULL\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        break;

    default:
        SX_LOG_ERR("Unsupported command: [%s] \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        /* Allocate command body */
        cmd_size = sizeof(sx_api_flex_pm_app_program_context_set_params_t) +
                   (sizeof(sx_flex_pm_app_program_context_t) * context_cnt);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size [%u] for sx_api_flex_pm_app_program_context_set exceeds range.\n", cmd_size);
            err = SX_STATUS_ERROR;
            goto out;
        }

        cmd_body_p = (sx_api_flex_pm_app_program_context_set_params_t*)cl_calloc(1, cmd_size);
        if (!cmd_body_p) {
            SX_LOG_ERR("Failed to allocate memory for sx_api_flex_pm_app_program_context_set command body\n");
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }

        cmd_body_p->cmd = cmd;
        cmd_body_p->contexts_list_cnt = context_cnt;
        for (i = 0; i < cmd_body_p->contexts_list_cnt; i++) {
            cmd_body_p->contexts_list[i].key = key_list[i];
            if (cmd == SX_ACCESS_CMD_ADD) {
                cmd_body_p->contexts_list[i].config = config_list[i];
            }
        }
    } else {
        /* Allocate command body */
        cmd_size = sizeof(sx_api_flex_pm_app_program_context_set_params_t);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size [%u] for sx_api_flex_pm_app_program_context_set exceeds range.\n", cmd_size);
            err = SX_STATUS_ERROR;
            goto out;
        }

        cmd_body_p = (sx_api_flex_pm_app_program_context_set_params_t*)cl_calloc(1, cmd_size);
        if (!cmd_body_p) {
            SX_LOG_ERR("Failed to allocate memory for sx_api_flex_pm_app_program_context_set command body\n");
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }

        cmd_body_p->cmd = cmd;
        cmd_body_p->contexts_list_cnt = 0;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FLEX_PM_APP_PROGRAM_CONTEXT_SET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex_pm_app_program_context_set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_flex_pm_app_program_set(const sx_api_handle_t                handle,
                                           const sx_access_cmd_t                cmd,
                                           const sx_flex_pm_app_key_t           key,
                                           const sx_flex_pm_app_program_attr_t *attr_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_program_set_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_DELETE) && (attr_p == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("attr_p parameter is NULL\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.key = key;
    cmd_body.attr = *attr_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PM_APP_PROGRAM_SET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set APP Program in Flex PM - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_flex_pm_app_program_get(const sx_api_handle_t          handle,
                                           const sx_access_cmd_t          cmd,
                                           const sx_flex_pm_app_key_t     key,
                                           sx_flex_pm_app_program_attr_t *attr_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_flex_pm_app_program_get_params_t cmd_body;
    uint32_t                                cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (attr_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("The given attr_p is NULL\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.key = key;
    SX_MEM_CPY_P(&cmd_body.attr, attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PM_APP_PROGRAM_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get APP Program in Flex PM - [%s]\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(attr_p, &cmd_body.attr);

out:
    SX_API_LOG_EXIT();
    return err;
}
