/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_router.h>
#include <include/resource_manager/resource_manager.h>
#include "utils/sx_router_utils_validate.h"
#include "sx_api_internal.h"
#include "utils/sx_ip_utils.h"

#undef __MODULE__
#define __MODULE__ SX_API_ROUTER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __sdk_router_ecmp_next_hop_key_ip_next_hop_addr_validate(const sx_next_hop_t *next_hop_list_p,
                                                                            const uint32_t       num_entries)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_API_LOG_ENTER();

    if (NULL == next_hop_list_p) {
        SX_LOG_ERR("next_hop_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (i = 0; i < num_entries; i++) {
        switch (next_hop_list_p[i].next_hop_key.type) {
        case SX_NEXT_HOP_TYPE_IP:
            if (!IS_IP_ADDR_UNICAST(next_hop_list_p[i].next_hop_key.next_hop_key_entry.ip_next_hop.address)) {
                SX_LOG_ERR("Next hop address %x not in UC address range.\n",
                           next_hop_list_p[i].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv4.s_addr);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        case SX_NEXT_HOP_TYPE_TUNNEL_ENCAP:
            /* Checking for a UC address is done at the back-end as it also depends on the type of the container. */
            break;

        case SX_NEXT_HOP_TYPE_MPLS:
            if (SX_MPLS_IP_NEXT_HOP_TYPE == next_hop_list_p[i].next_hop_key.next_hop_key_entry.mpls_next_hop.type) {
                if (!IS_IP_ADDR_UNICAST(next_hop_list_p[i].next_hop_key.next_hop_key_entry.mpls_next_hop.
                                        mpls_next_hop_entry.ip_next_hop_data.ip_next_hop.address)) {
                    SX_LOG_ERR("Next hop address %x not in UC address range.\n",
                               next_hop_list_p[i].next_hop_key.next_hop_key_entry.mpls_next_hop.mpls_next_hop_entry.ip_next_hop_data.ip_next_hop.address.addr.ipv4.s_addr);
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
            break;

        case SX_NEXT_HOP_TYPE_RELOOKUP:
            break;

        default:
            SX_LOG_ERR("Invalid next hop key type is specified. (type = %u).\n", next_hop_list_p[i].next_hop_key.type);
            err = SX_STATUS_ERROR;
            break;
        }
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_router_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
        err = sx_router_utils_log_verbosity_set(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ROUTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  sx_verbosity_level_t           *module_verbosity_level_p,
                                                  sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ROUTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_hash_params_set(const sx_api_handle_t               handle,
                                               const sx_router_ecmp_hash_params_t *ecmp_hash_params_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_ecmp_hash_set_params_t cmd_body;
    sx_api_reply_head_t                  reply_head;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (ecmp_hash_params_p == NULL) {
        SX_LOG_ERR("ecmp_hash_params_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_HASH_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_ecmp_hash_set_params_t);

    cmd_body.ecmp_hash_params = *ecmp_hash_params_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_port_hash_params_set(const sx_api_handle_t                     handle,
                                                    const sx_access_cmd_t                     cmd,
                                                    const sx_port_log_id_t                    log_port,
                                                    const sx_router_ecmp_port_hash_params_t  *ecmp_hash_params_p,
                                                    const sx_router_ecmp_hash_field_enable_t *hash_field_enable_list_p,
                                                    const uint32_t                            hash_field_enable_list_cnt,
                                                    const sx_router_ecmp_hash_field_t        *hash_field_list_p,
                                                    const uint32_t                            hash_field_list_cnt)
{
    sx_api_router_ecmp_port_hash_set_params_t *cmd_body = NULL;
    sx_api_command_head_t                      cmd_head;
    uint32_t                                   cmd_body_size = 0;
    uint32_t                                   dynamic_size = 0;
    sx_api_reply_head_t                        reply_head;
    sx_status_t                                out_err = SX_STATUS_SUCCESS;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((hash_field_list_cnt > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_list_p param is NULL.\n");
        goto out;
    }

    if ((hash_field_enable_list_cnt > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_enable_list_p param is NULL.\n");
        goto out;
    }
    if (hash_field_enable_list_cnt > FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_enable_list_cnt exceeds range.\n");
        goto out;
    }
    if (hash_field_list_cnt > FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_list_cnt exceeds range.\n");
        goto out;
    }

    dynamic_size = hash_field_list_cnt * sizeof(sx_router_ecmp_hash_field_t);
    if ((sizeof(sx_api_router_ecmp_port_hash_set_params_t) + dynamic_size) > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        sizeof(sx_api_router_ecmp_port_hash_set_params_t) + dynamic_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for ECMP port hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    /* Allocate the field list and field list arrays in the command body */
    if (hash_field_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_list_p,
                         hash_field_list_p,
                         hash_field_list_cnt,
                         sx_router_ecmp_hash_field_t);
    }

    if (hash_field_enable_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_enable_list_p,
                         hash_field_enable_list_p,
                         hash_field_enable_list_cnt,
                         sx_router_ecmp_hash_field_enable_t);
    }

    cmd_body->cmd = cmd;
    cmd_body->log_port = log_port;
    if (ecmp_hash_params_p != NULL) {
        cmd_body->ecmp_hash_params = *ecmp_hash_params_p;
    }
    cmd_body->hash_field_enable_list_cnt = hash_field_enable_list_cnt;
    cmd_body->hash_field_list_cnt = hash_field_list_cnt;
    cmd_body_size = sizeof(*cmd_body) + dynamic_size;

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_PARAMS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free ECMP port hash API params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_router_ecmp_hash_params_get(const sx_api_handle_t         handle,
                                               sx_router_ecmp_hash_params_t *ecmp_hash_params_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_reply_head_t                  reply_head;
    sx_api_router_ecmp_hash_get_params_t reply_body;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (ecmp_hash_params_p == NULL) {
        SX_LOG_ERR("ecmp_hash_params_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_HASH_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, NULL,
                                        &reply_head, (uint8_t*)&reply_body,
                                        sizeof(sx_api_router_ecmp_hash_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *ecmp_hash_params_p = reply_body.ecmp_hash_params;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_ecmp_port_hash_params_get(const sx_api_handle_t               handle,
                                                    const sx_port_log_id_t              log_port,
                                                    sx_router_ecmp_port_hash_params_t  *ecmp_hash_params_p,
                                                    sx_router_ecmp_hash_field_enable_t *hash_field_enable_list_p,
                                                    uint32_t                           *hash_field_enable_list_cnt_p,
                                                    sx_router_ecmp_hash_field_t        *hash_field_list_p,
                                                    uint32_t                           *hash_field_list_cnt_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_router_ecmp_port_hash_get_params_t  cmd_body;
    sx_api_router_ecmp_port_hash_get_params_t *reply_body = NULL;
    sx_api_reply_head_t                        reply_head;
    uint32_t                                   reply_body_size = 0;
    sx_status_t                                out_err = SX_STATUS_SUCCESS;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == hash_field_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_list_cnt param is NULL.\n");
        goto out;
    }

    if ((*hash_field_list_cnt_p > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_list_p param is NULL.\n");
        goto out;
    }

    if (NULL == hash_field_enable_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_enable_list_cnt param is NULL.\n");
        goto out;
    }

    if ((*hash_field_enable_list_cnt_p > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_enable_list_p param is NULL.\n");
        goto out;
    }

    if (*hash_field_enable_list_cnt_p > FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_enable_list_cnt_p exceeds range.\n");
        goto out;
    }

    if (*hash_field_list_cnt_p > FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_list_cnt_p exceeds range.\n");
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_ecmp_port_hash_get_params_t) +
                      ((*hash_field_list_cnt_p) * sizeof(sx_router_ecmp_hash_field_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Allocate the field list and field list arrays in the command body */
    M_UTILS_CLR_MEM_GET(&reply_body,
                        1,
                        reply_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for ECMP port hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    cmd_body.log_port = log_port;
    cmd_body.hash_field_enable_list_cnt = *hash_field_enable_list_cnt_p;
    cmd_body.hash_field_list_cnt = *hash_field_list_cnt_p;

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_PORT_HASH_PARAMS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_ecmp_port_hash_get_params_t);
    cmd_head.list_size = (*hash_field_list_cnt_p) * sizeof(sx_router_ecmp_hash_field_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body, reply_body_size);

    *ecmp_hash_params_p = reply_body->ecmp_hash_params;
    *hash_field_list_cnt_p = reply_body->hash_field_list_cnt;
    if ((*hash_field_list_cnt_p > 0) && (hash_field_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(hash_field_list_p,
                         reply_body->hash_field_list_p,
                         *hash_field_list_cnt_p,
                         sx_router_ecmp_hash_field_t);
    }
    *hash_field_enable_list_cnt_p = reply_body->hash_field_enable_list_cnt;
    if ((*hash_field_enable_list_cnt_p > 0) && (hash_field_enable_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(hash_field_enable_list_p,
                         reply_body->hash_field_enable_list_p,
                         *hash_field_enable_list_cnt_p,
                         sx_router_ecmp_hash_field_enable_t);
    }

out:
    if (NULL != reply_body) {
        M_UTILS_MEM_PUT(reply_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free ECMP port hash API params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_router_init_set(const sx_api_handle_t              handle,
                                   const sx_router_general_param_t   *general_params_p,
                                   const sx_router_resources_param_t *router_resource_p)
{
    sx_api_router_init_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((general_params_p == NULL) || (router_resource_p == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ROUTER_ENABLE_STATE_CHECK_RANGE(general_params_p->ipv4_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "ipv4_enable parameter exceeds range.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_ROUTER_ENABLE_STATE_CHECK_RANGE(general_params_p->ipv6_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "ipv6_enable parameter exceeds range.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_ROUTER_ENABLE_STATE_CHECK_RANGE(general_params_p->ipv4_mc_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "ipv4_mc_enable parameter exceeds range.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_ROUTER_ENABLE_STATE_CHECK_RANGE(general_params_p->ipv6_mc_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "ipv6_mc_enable parameter exceeds range.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_CHECK_BOOLEAN(general_params_p->rpf_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "rpf_enable of boolean type exceeds range (True / False).\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_CHECK_BOOLEAN(general_params_p->disable_l3_nh_list) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "disable_l3_nh_list of boolean type exceeds range (True / False).\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_CHECK_BOOLEAN(router_resource_p->ipinip_ipv6_loopback_rif_enable) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "ipinip_ipv6_loopback_rif_enable of boolean type exceeds range (True / False).\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    cmd_body.general_params_p = *general_params_p;
    cmd_body.router_resource_p = *router_resource_p;


    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ROUTER_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_init_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ROUTER_DEINIT_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_set(const sx_api_handle_t         handle,
                              const sx_access_cmd_t         cmd,
                              const sx_router_attributes_t *router_attr,
                              sx_router_id_t               *vrid)
{
    sx_api_router_set_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (vrid == NULL) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_DELETE) && (router_attr == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.vrid = *vrid;
    if (cmd != SX_ACCESS_CMD_DELETE) {
        cmd_body.router_attr = *router_attr;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ROUTER_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_set_params_t));

    if (cmd == SX_ACCESS_CMD_ADD) {
        *vrid = cmd_body.vrid;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_get(const sx_api_handle_t   handle,
                              const sx_router_id_t    vrid,
                              sx_router_attributes_t *router_attr)
{
    sx_api_router_get_params_t cmd_body;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (router_attr == NULL) {
        SX_LOG_ERR("router_attr param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.vrid = vrid;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    router_attr->ipv4_enable = cmd_body.router_attr.ipv4_enable;
    router_attr->ipv6_enable = cmd_body.router_attr.ipv6_enable;
    router_attr->ipv4_mc_enable = cmd_body.router_attr.ipv4_mc_enable;
    router_attr->ipv6_mc_enable = cmd_body.router_attr.ipv6_mc_enable;
    router_attr->uc_default_rule_action = cmd_body.router_attr.uc_default_rule_action;
    router_attr->mc_default_rule_action = cmd_body.router_attr.mc_default_rule_action;
    router_attr->uc_default_rule_counter = cmd_body.router_attr.uc_default_rule_counter;
    router_attr->ipv4_tree_id = cmd_body.router_attr.ipv4_tree_id;
    router_attr->ipv6_tree_id = cmd_body.router_attr.ipv6_tree_id;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_vrid_iter_get(const sx_api_handle_t   handle,
                                        const sx_access_cmd_t   cmd,
                                        const sx_router_id_t    vrid_key,
                                        const sx_vrid_filter_t *vrid_filter_p,
                                        sx_router_id_t         *vrid_list_p,
                                        uint32_t               *vrid_cnt_p)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_router_vrid_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_api_router_vrid_iter_get_params_t* reply_body = NULL;
    uint32_t                              reply_body_size;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (vrid_cnt_p == NULL) {
        SX_LOG_ERR("vrid_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*vrid_cnt_p == 0) {
            SX_LOG_ERR("vrid_cnt_p is 0.\n");
            vrid_list_p = NULL;
            goto out;
        }
        if (vrid_list_p == NULL) {
            SX_LOG_ERR("vrid_list_p is NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*vrid_cnt_p == 0) {
            vrid_list_p = NULL;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_router_vrid_iter_get_params_t) +
                      (*vrid_cnt_p * sizeof(sx_router_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_VRID_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_router_vrid_iter_get_params_t);
    cmd_head.list_size = *vrid_cnt_p * sizeof(sx_router_id_t);

    cmd_body.vrid_key = vrid_key;
    cmd_body.cmd = cmd;
    cmd_body.vrid_cnt = *vrid_cnt_p;
    if (vrid_filter_p != NULL) {
        cmd_body.vrid_filter = *vrid_filter_p;
    }

    *vrid_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->vrid_cnt) {
        *vrid_cnt_p = reply_body->vrid_cnt;
        if (vrid_list_p != NULL) {
            SX_MEM_CPY_ARRAY(vrid_list_p, reply_body->vrid_list,
                             reply_body->vrid_cnt, sx_router_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_set(const sx_api_handle_t              handle,
                                        const sx_access_cmd_t              cmd,
                                        const sx_router_id_t               vrid,
                                        const sx_router_interface_param_t *ifc_p,
                                        const sx_interface_attributes_t   *ifc_attr_p,
                                        sx_router_interface_t             *rif_p)
{
    sx_api_router_interface_set_params_t cmd_body;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_DELETE_ALL) && (rif_p == NULL)) {
        SX_LOG_ERR("rif_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) &&
        ((ifc_p == NULL) || (ifc_attr_p == NULL))) {
        SX_LOG_ERR("ifc_p or ifc_attr_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.vrid = vrid;
    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) {
        cmd_body.ifc = *ifc_p;
        cmd_body.ifc_attr = *ifc_attr_p;
    }
    if (rif_p) {
        cmd_body.rif = *rif_p;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_interface_set_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_ADD) && (rif_p != NULL)) {
        *rif_p = cmd_body.rif;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_get(const sx_api_handle_t        handle,
                                        const sx_router_interface_t  rif,
                                        sx_router_id_t              *vrid_p,
                                        sx_router_interface_param_t *ifc_p,
                                        sx_interface_attributes_t   *ifc_attr_p)
{
    sx_api_router_interface_get_params_t cmd_body;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.rif = rif;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_interface_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (vrid_p != NULL) {
        *vrid_p = cmd_body.vrid;
    }
    if (ifc_p != NULL) {
        *ifc_p = cmd_body.ifc;
    }
    if (ifc_attr_p != NULL) {
        *ifc_attr_p = cmd_body.ifc_attr;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_interface_iter_get(const sx_api_handle_t        handle,
                                             const sx_access_cmd_t        cmd,
                                             const sx_router_interface_t *rif_key_p,
                                             const sx_rif_filter_t       *filter_p,
                                             sx_router_interface_t       *rif_list_p,
                                             uint32_t                    *rif_cnt_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    uint32_t                                   reply_body_size = 0;
    sx_api_router_interface_iter_get_params_t *cmd_body = NULL;
    uint32_t                                   rif_iter_cnt = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (rif_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("rif_cnt_p param is null.\n");
        goto out;
    }
    rif_iter_cnt = *rif_cnt_p;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:

        if (*rif_cnt_p > 1) {
            rif_iter_cnt = 1;
            SX_LOG(SX_LOG_DEBUG, "Force count to be 1 for %s.\n",
                   sx_access_cmd_str(cmd));
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if ((*rif_cnt_p > 0) && (rif_key_p == NULL)) {
            /* get next requires non null rif key */
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("rif_key_p param is NULL for Cmd = %s.\n",
                       sx_access_cmd_str(cmd));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
        break;
    }

    /* malloc the cmd body. We will use the same body for the reply also*/
    reply_body_size = sizeof(sx_api_router_interface_iter_get_params_t) +
                      ((rif_iter_cnt) * sizeof(sx_router_interface_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for Rif List reply msg.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->rif_list_cnt = rif_iter_cnt;

    if (rif_key_p == NULL) {
        cmd_body->rif_key = RM_API_ROUTER_RIF_KEY_NULL;
        SX_LOG(SX_LOG_DEBUG, "Rif Key is Null. Set cmd rif key %d.\n", cmd_body->rif_key);
    } else {
        cmd_body->rif_key = *rif_key_p;
    }

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body->filter), filter_p, sx_rif_filter_t);
    } else {
        cmd_body->filter.filter_by_vrid = SX_KEY_FILTER_FIELD_NOT_VALID;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ROUTER_INTERFACE_ITER_GET_E,
                                      (uint8_t*)cmd_body,
                                      reply_body_size);

    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    *rif_cnt_p = cmd_body->rif_list_cnt;

    if (*rif_cnt_p != 0) {
        if (rif_list_p != NULL) {
            SX_MEM_CPY_ARRAY(rif_list_p, cmd_body->rif_list,
                             cmd_body->rif_list_cnt, sx_router_interface_t);
        }
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_state_set(const sx_api_handle_t              handle,
                                              const sx_router_interface_t        rif,
                                              const sx_router_interface_state_t *rif_state_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_router_interface_state_set_params_t cmd_body;
    sx_api_reply_head_t                        reply_head;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (rif_state_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("rif_state_p param is NULL.\n");
        goto out;
    }

    if ((!SX_CHECK_MAX(rif_state_p->ipv4_enable, SX_ROUTER_ENABLE_STATE_MAX)) ||
        (!SX_CHECK_MAX(rif_state_p->ipv4_mc_enable, SX_ROUTER_ENABLE_STATE_MAX)) ||
        (!SX_CHECK_MAX(rif_state_p->ipv6_enable, SX_ROUTER_ENABLE_STATE_MAX)) ||
        (!SX_CHECK_MAX(rif_state_p->ipv6_mc_enable, SX_ROUTER_ENABLE_STATE_MAX))) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Failed to set the state of router interface,"
                   " the given state is out of range, err %s.\n", sx_status_str(err));
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_INTERFACE_STATE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_interface_state_set_params_t);

    cmd_body.rif = rif;
    cmd_body.rif_state = *rif_state_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_state_get(const sx_api_handle_t        handle,
                                              const sx_router_interface_t  rif,
                                              sx_router_interface_state_t *rif_state_p)
{
    sx_api_router_interface_state_get_params_t cmd_body;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (rif_state_p == NULL) {
        SX_LOG_ERR("rif_state_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.rif = rif;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_STATE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_interface_state_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *rif_state_p = cmd_body.rif_state;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_mac_set(const sx_api_handle_t       handle,
                                            const sx_access_cmd_t       cmd,
                                            const sx_router_interface_t rif,
                                            const sx_mac_addr_t        *mac_addr_list_p,
                                            const uint32_t              mac_addr_cnt)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_router_interface_mac_set_params_t *cmd_body = NULL;
    uint32_t                                  cmd_body_size = 0;
    sx_api_reply_head_t                       reply_head;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_DELETE_ALL) && (mac_addr_list_p == NULL)) {
        SX_LOG_ERR("mac_addr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_interface_mac_set_params_t) +
                    (mac_addr_cnt * sizeof(sx_mac_addr_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }


    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_INTERFACE_MAC_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body->cmd = cmd;
    cmd_body->rif = rif;
    cmd_body->mac_addr_num = mac_addr_cnt;
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        SX_MEM_CPY_ARRAY(cmd_body->mac_addr_arr, mac_addr_list_p,
                         mac_addr_cnt, sx_mac_addr_t);
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_mac_get(const sx_api_handle_t       handle,
                                            const sx_router_interface_t rif,
                                            sx_mac_addr_t              *mac_addr_list_p,
                                            uint32_t                  * mac_addr_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_router_interface_mac_get_params_t  cmd_body;
    uint32_t                                  reply_body_size = 0;
    sx_api_reply_head_t                       reply_head;
    sx_api_router_interface_mac_get_params_t *reply_body = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (mac_addr_cnt_p == NULL) {
        SX_LOG_ERR("mac_addr_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (mac_addr_list_p == NULL) {
        *mac_addr_cnt_p = 0;
    }
    if (*mac_addr_cnt_p == 0) {
        mac_addr_list_p = NULL;
    }

    reply_body_size = sizeof(sx_api_router_interface_mac_get_params_t) +
                      ((*mac_addr_cnt_p) * sizeof(sx_mac_addr_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_INTERFACE_MAC_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_interface_mac_get_params_t);
    cmd_head.list_size = (*mac_addr_cnt_p) * sizeof(sx_mac_addr_t);

    cmd_body.cmd = (*mac_addr_cnt_p == 0) ? SX_ACCESS_CMD_COUNT : SX_ACCESS_CMD_GET;
    cmd_body.rif = rif;
    cmd_body.mac_addr_num = *mac_addr_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);


    if (*mac_addr_cnt_p == 0) {
        *mac_addr_cnt_p = reply_body->mac_addr_num;
    } else if ((mac_addr_list_p != NULL) && (*mac_addr_cnt_p >= reply_body->mac_addr_num)) {
        SX_MEM_CPY_ARRAY(mac_addr_list_p, reply_body->mac_addr_arr,
                         reply_body->mac_addr_num, sx_mac_addr_t);
        *mac_addr_cnt_p = reply_body->mac_addr_num;
    } else {
        SX_LOG_ERR("mac_addr_list_p - Insufficient memory to hold all the mac-address.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_neigh_set(const sx_api_handle_t       handle,
                                    const sx_access_cmd_t       cmd,
                                    const sx_router_interface_t rif,
                                    const sx_ip_addr_t         *ip_addr_p,
                                    const sx_neigh_data_t      *neigh_data_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_router_neigh_set_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_DELETE_ALL) && (ip_addr_p == NULL)) {
        SX_LOG_ERR("ip_addr_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (neigh_data_p == NULL) {
        if (cmd == SX_ACCESS_CMD_ADD) {
            SX_LOG_ERR("neigh_data_p param is NULL and command is %s.\n", sx_access_cmd_str(cmd));
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }


    cmd_head.opcode = SX_API_INT_CMD_ROUTER_NEIGH_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_neigh_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.rif = rif;
    if (ip_addr_p != NULL) {
        cmd_body.ip_addr = *ip_addr_p;
    }

    if (neigh_data_p != NULL) {
        cmd_body.neigh_data = *neigh_data_p;
    } else {
        cmd_body.neigh_data.rif = RM_API_ROUTER_RIF_KEY_NULL;
    }


    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_neigh_get(const sx_api_handle_t       handle,
                                    const sx_access_cmd_t       cmd,
                                    const sx_router_interface_t rif,
                                    const sx_ip_addr_t        * neigh_key_p,
                                    const sx_neigh_filter_t   * filter_p,
                                    sx_neigh_get_entry_t       *neigh_entry_list_p,
                                    uint32_t                  * neigh_entry_cnt_p)
{
    sx_api_command_head_t             cmd_head;
    sx_api_router_neigh_get_params_t  cmd_body;
    uint32_t                          reply_body_size = 0;
    sx_api_reply_head_t               reply_head;
    sx_api_router_neigh_get_params_t *reply_body = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((neigh_key_p == NULL) && (cmd != SX_ACCESS_CMD_GET_FIRST)) {
        SX_LOG_ERR("neigh_key_p param is NULL, cmd:%s.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((filter_p != NULL) && (cmd != SX_ACCESS_CMD_GET) &&
        (SX_KEY_FILTER_VALID_CHECK_RANGE(filter_p->filter_by_rif) != TRUE)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("key_filter filter_by_rif (%d) err: %s.\n",
                   filter_p->filter_by_rif, sx_status_str(err));
        goto out;
    }

    if (neigh_entry_cnt_p == NULL) {
        SX_LOG_ERR("neigh_entry_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
        if (neigh_entry_list_p == NULL) {
            *neigh_entry_cnt_p = 0;
        }
        if (*neigh_entry_cnt_p == 0) {
            neigh_entry_list_p = NULL;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (neigh_entry_list_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("neigh_entry_list_p param is NULL.\n");
            goto out;
        }
        if (*neigh_entry_cnt_p == 0) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("neigh_entry_cnt is 0.\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        *neigh_entry_cnt_p = 1;

        if (neigh_entry_list_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("neigh_entry_list_p param is NULL.\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    if (*neigh_entry_cnt_p > MAX_GET_ALL_ENTRIES) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("neigh_entry_cnt_p (%d) > MAX_GET_ALL_ENTRIES (%d)  error:  %s.\n",
                   *neigh_entry_cnt_p, MAX_GET_ALL_ENTRIES, sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_neigh_get_params_t) +
                      ((*neigh_entry_cnt_p) * sizeof(sx_neigh_get_entry_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_NEIGH_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_neigh_get_params_t);
    cmd_head.list_size = (*neigh_entry_cnt_p) * sizeof(sx_neigh_get_entry_t);

    cmd_body.cmd = cmd;
    cmd_body.rif = rif;
    cmd_body.neigh_entry_cnt = *neigh_entry_cnt_p;
    if (neigh_key_p != NULL) {
        cmd_body.neigh_key = *neigh_key_p;
    }
    if (filter_p != NULL) {
        cmd_body.filter = *filter_p;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*neigh_entry_cnt_p == 0) {
        *neigh_entry_cnt_p = reply_body->neigh_entry_cnt;
    } else {
        SX_MEM_CPY_ARRAY(neigh_entry_list_p, reply_body->neigh_entry_list,
                         reply_body->neigh_entry_cnt, sx_neigh_get_entry_t);
        *neigh_entry_cnt_p = reply_body->neigh_entry_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_neigh_activity_get(const sx_api_handle_t       handle,
                                             const sx_access_cmd_t       cmd,
                                             const sx_router_interface_t rif,
                                             const sx_ip_addr_t        * ip_addr_p,
                                             boolean_t                  *activity_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_router_neigh_get_activity_params_t  cmd_body;
    uint32_t                                   reply_body_size = 0;
    sx_api_reply_head_t                        reply_head;
    sx_api_router_neigh_get_activity_params_t *reply_body = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (ip_addr_p == NULL) {
        SX_LOG_ERR("ip_addr_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (activity_p == NULL) {
        SX_LOG_ERR("activity_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_neigh_get_activity_params_t);
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_neigh_get_activity_params_t);

    cmd_body.cmd = cmd;
    cmd_body.rif = rif;
    cmd_body.ip_addr = *ip_addr_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *activity_p = reply_body->activity;

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_uc_route_set(const sx_api_handle_t handle,
                                       const sx_access_cmd_t cmd,
                                       const sx_router_id_t  vrid,
                                       const sx_ip_prefix_t *network_addr,
                                       sx_uc_route_data_t   *uc_route_data_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_uc_route_set_params_t *cmd_body = NULL;
    uint32_t                             cmd_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_api_router_uc_route_set_params_t *reply_body = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (((cmd != SX_ACCESS_CMD_DELETE_ALL) && (cmd != SX_ACCESS_CMD_DELETE)) &&
        ((network_addr == NULL) || (uc_route_data_p == NULL))) {
        SX_LOG_ERR("network_addr or uc_route_data_p param is NULL, cmd:%s.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_DELETE) && (network_addr == NULL)) {
        SX_LOG_ERR("network_addr param is NULL, cmd:%s.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        /* validate prefix ip address is valid */
        if (SX_IP_VERSION_CHECK_RANGE(network_addr->version) != TRUE) {
            SX_LOG_ERR("IP version exceeds range.\n");
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        if (!SX_IP_PREFIX_VALID(*network_addr)) {
            SX_LOG_ERR("Prefix is not valid.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (!IS_IP_UNICAST(*network_addr) &&
            (network_addr->prefix.ipv4.addr.s_addr != INADDR_BROADCAST)) {
            SX_LOG_ERR("Given address %x is not in UC/BC address range.\n",
                       network_addr->prefix.ipv4.addr.s_addr);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    if (((cmd != SX_ACCESS_CMD_DELETE_ALL) && (cmd != SX_ACCESS_CMD_DELETE)) &&
        ((uc_route_data_p->type == SX_UC_ROUTE_TYPE_NEXT_HOP) || (uc_route_data_p->type == SX_UC_ROUTE_TYPE_LOCAL)) &&
        (!SX_ROUTER_ACTION_CHECK_RANGE(uc_route_data_p->action))) {
        SX_LOG_ERR("sx_api_uc_route_set: Trying to set sx_router_action_t with action (%d) "
                   "outside the range (%d-%d).\n",
                   uc_route_data_p->action,
                   SX_ROUTER_ACTION_MIN,
                   SX_ROUTER_ACTION_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (((cmd != SX_ACCESS_CMD_DELETE_ALL) && (cmd != SX_ACCESS_CMD_DELETE)) &&
        (uc_route_data_p->action == SX_ROUTER_ACTION_TRAP) &&
        (!SX_TRAP_PRIORITY_CHECK_RANGE(uc_route_data_p->trap_attr.prio))) {
        SX_LOG_ERR("sx_api_uc_route_set: Trying to set SX_ROUTER_ACTION_TRAP with trap priority (%d) "
                   "outside the range (%d-%d).\n",
                   uc_route_data_p->trap_attr.prio,
                   SX_TRAP_PRIORITY_MIN,
                   SX_TRAP_PRIORITY_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (((cmd != SX_ACCESS_CMD_DELETE_ALL) && (cmd != SX_ACCESS_CMD_DELETE)) &&
        ((uc_route_data_p->action == SX_ROUTER_ACTION_FORWARD) ||
         (uc_route_data_p->action == SX_ROUTER_ACTION_TRAP_FORWARD)) &&
        (uc_route_data_p->type == SX_UC_ROUTE_TYPE_NEXT_HOP)) {
        if (uc_route_data_p->next_hop_cnt > 0) {
            SX_LOG_DEPRECATED_PARAM_ERR("uc_route_data_p->next_hop_list_p", "uc_route_data_p->uc_route_param.ecmp_id");
            SX_LOG_DEPRECATED_PARAM_ERR("uc_route_data_p->next_hop_cnt", "NULL");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (uc_route_data_p->uc_route_param.ecmp_id == SX_ROUTER_ECMP_ID_INVALID) {
            SX_LOG_ERR("Next hop UC route must have a valid ECMP ID.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    cmd_body_size = sizeof(sx_api_router_uc_route_set_params_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_UC_ROUTE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->cmd = cmd;
    cmd_body->vrid = vrid;
    cmd_body->next_hop.next_hop_cnt = (uc_route_data_p ? uc_route_data_p->next_hop_cnt : 0);

    if (network_addr != NULL) {
        cmd_body->network_addr = *network_addr;
    }

    if (uc_route_data_p != NULL) {
        cmd_body->next_hop.action = uc_route_data_p->action;
        cmd_body->next_hop.trap_attr = uc_route_data_p->trap_attr;
        cmd_body->next_hop.type = uc_route_data_p->type;
        cmd_body->next_hop.uc_route_param = uc_route_data_p->uc_route_param;
        cmd_body->user_cookie = uc_route_data_p->user_cookie;
        cmd_body->next_hop.ar_classifier_action.ar_flow_classification =
            uc_route_data_p->ar_classifier_action.ar_flow_classification;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body, cmd_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    if (cmd_body != NULL) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_uc_route_get(const sx_api_handle_t     handle,
                                       const sx_access_cmd_t     cmd,
                                       const sx_router_id_t      vrid,
                                       const sx_ip_prefix_t     *network_addr,
                                       sx_uc_route_key_filter_t *filter_p,
                                       sx_uc_route_get_entry_t * uc_route_get_entries_list_p,
                                       uint32_t                 *uc_route_get_entries_cnt_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_uc_route_get_params_t  cmd_body;
    uint32_t                             reply_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_api_router_uc_route_get_params_t *reply_body = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_access_cmd_t                      curr_cmd = cmd;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (filter_p != NULL) {
        if ((SX_KEY_FILTER_VALID_CHECK_RANGE(filter_p->filter_by_nexthop) != TRUE) ||
            (SX_KEY_FILTER_VALID_CHECK_RANGE(filter_p->filter_by_prefix) != TRUE)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("key_filter filter_by_nexthop (%d), key_filter->filter_by_prefix (%d) err: %s.\n",
                       filter_p->filter_by_nexthop, filter_p->filter_by_prefix, sx_status_str(err));
            goto out;
        }
        if (filter_p->filter_by_prefix == SX_KEY_FILTER_FIELD_VALID) {
            if (SX_IP_VERSION_CHECK_RANGE(filter_p->prefix.version) != TRUE) {
                SX_LOG_ERR("key_filter->prefix.version exceeds range.\n");
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
            if (!SX_IP_PREFIX_VALID(filter_p->prefix)) {
                SX_LOG_ERR("Key_filter prefix is not valid !.\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            if (!IS_IP_UNICAST(filter_p->prefix)) {
                SX_LOG_ERR("Given key_filter->prefix address %x is not in UC address range.\n",
                           filter_p->prefix.prefix.ipv4.addr.s_addr);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }
    }

    if (uc_route_get_entries_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GETNEXT) {
        if (uc_route_get_entries_list_p == NULL) {
            *uc_route_get_entries_cnt_p = 0;
        }

        if (*uc_route_get_entries_cnt_p == 0) {
            uc_route_get_entries_list_p = NULL;
            curr_cmd = SX_ACCESS_CMD_COUNT;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (uc_route_get_entries_list_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("uc_route_get_entry_arr is NULL.\n");
            goto out;
        }

        if (*uc_route_get_entries_cnt_p == 0) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("uc_route_get_entries_num is 0.\n");
            goto out;
        }

    /* fall through */
    case SX_ACCESS_CMD_GET:

        if (network_addr == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("cmd %d (%s) failed, should accept key != NULL.\n",
                       cmd, sx_access_cmd_str(cmd));
            goto out;
        }
        if (SX_IP_VERSION_CHECK_RANGE(network_addr->version) != TRUE) {
            SX_LOG_ERR("key->network_addr.version exceeds range.\n");
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (*uc_route_get_entries_cnt_p != 0) {
            if (!SX_IP_PREFIX_VALID(*network_addr)) {
                SX_LOG_ERR("Prefix is not valid.\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            if (!IS_IP_UNICAST(*network_addr) &&
                (network_addr->prefix.ipv4.addr.s_addr != INADDR_BROADCAST)) {
                SX_LOG_ERR("Given address %x is not in UC/BC address range.\n",
                           network_addr->prefix.ipv4.addr.s_addr);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    if (*uc_route_get_entries_cnt_p > MAX_GET_ALL_ENTRIES) {
        if (cmd == SX_ACCESS_CMD_GET) {
            *uc_route_get_entries_cnt_p = 1;
        } else {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("uc_route_get_entries_num (%d) > MAX_GET_ALL_ENTRIES (%d)  error:  %s.\n",
                       *uc_route_get_entries_cnt_p, MAX_GET_ALL_ENTRIES, sx_status_str(err));
            goto out;
        }
    }

    reply_body_size = sizeof(sx_api_router_uc_route_get_params_t) +
                      ((*uc_route_get_entries_cnt_p) * sizeof(sx_uc_route_get_entry_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_UC_ROUTE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_uc_route_get_params_t);
    cmd_head.list_size = (*uc_route_get_entries_cnt_p) * sizeof(sx_uc_route_get_entry_t);

    cmd_body.cmd = curr_cmd;
    cmd_body.vrid = vrid;

    if (network_addr != NULL) {
        cmd_body.network_addr = *network_addr;
    }

    if (filter_p != NULL) {
        cmd_body.filter = *filter_p;
    }

    cmd_body.uc_route_get_entries_cnt = *uc_route_get_entries_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*uc_route_get_entries_cnt_p == 0) {
        *uc_route_get_entries_cnt_p = reply_body->uc_route_get_entries_cnt;
    } else if ((uc_route_get_entries_list_p != NULL) &&
               (*uc_route_get_entries_cnt_p >= reply_body->uc_route_get_entries_cnt)) {
        SX_MEM_CPY_ARRAY(uc_route_get_entries_list_p, reply_body->uc_route_get_entries_list,
                         reply_body->uc_route_get_entries_cnt, sx_uc_route_get_entry_t);
        *uc_route_get_entries_cnt_p = reply_body->uc_route_get_entries_cnt;
    } else {
        SX_LOG_ERR("uc_route_get_entries_list_p - Insufficient memory to hold uc routes.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_uc_route_operational_ecmp_get(const sx_api_handle_t    handle,
                                                        const sx_router_id_t     vrid,
                                                        const sx_ip_prefix_t    *network_addr,
                                                        sx_uc_route_get_entry_t *oper_uc_route_entries_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_uc_route_get_params_t  cmd_body;
    uint32_t                             reply_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_api_router_uc_route_get_params_t *reply_body = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_LOG_DEPRECATED_FUNC_ERR(NULL);

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (oper_uc_route_entries_p == NULL) {
        SX_LOG_ERR("oper_uc_route_entries_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (network_addr == NULL) {
        SX_LOG_ERR("network_addr param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* validate prefix ip address is valid */
    if (SX_IP_VERSION_CHECK_RANGE(network_addr->version) != TRUE) {
        SX_LOG_ERR("network address version exceeds range.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (!SX_IP_PREFIX_VALID(*network_addr)) {
        SX_LOG_ERR("network address prefix is not valid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (!IS_IP_UNICAST(*network_addr)) {
        SX_LOG_ERR("Given address %x is not in UC address range.\n",
                   network_addr->prefix.ipv4.addr.s_addr);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_uc_route_get_params_t) +
                      sizeof(sx_uc_route_get_entry_t);
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_UC_ROUTE_OPERATIONAL_ECMP_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_uc_route_get_params_t);
    cmd_head.list_size = sizeof(sx_uc_route_get_entry_t);

    cmd_body.cmd = (oper_uc_route_entries_p->route_data.next_hop_cnt == 0) ? SX_ACCESS_CMD_COUNT : SX_ACCESS_CMD_GET;
    cmd_body.vrid = vrid;
    cmd_body.network_addr = *network_addr;
    cmd_body.uc_route_get_entries_cnt = 1;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (oper_uc_route_entries_p->route_data.next_hop_cnt == 0) {
        oper_uc_route_entries_p->route_data.next_hop_cnt =
            reply_body->uc_route_get_entries_list[0].route_data.next_hop_cnt;
    } else {
        oper_uc_route_entries_p->route_data.next_hop_cnt =
            reply_body->uc_route_get_entries_list[0].route_data.next_hop_cnt;
        oper_uc_route_entries_p->network_addr = reply_body->uc_route_get_entries_list[0].network_addr;
        oper_uc_route_entries_p->route_data.action = reply_body->uc_route_get_entries_list[0].route_data.action;
        oper_uc_route_entries_p->route_data.trap_attr = reply_body->uc_route_get_entries_list[0].route_data.trap_attr;
        SX_MEM_CPY_ARRAY(oper_uc_route_entries_p->route_data.next_hop_list_p,
                         reply_body->uc_route_get_entries_list[0].route_data.next_hop_list_p,
                         reply_body->uc_route_get_entries_list[0].route_data.next_hop_cnt,
                         sx_ip_addr_t);
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_counter_set(const sx_api_handle_t   handle,
                                      const sx_access_cmd_t   cmd,
                                      sx_router_counter_id_t *counter_p)
{
    sx_api_router_cntr_alloc_set_params_t cmd_body;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_p == NULL) {
        SX_LOG_ERR("counter_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.cntr = *counter_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_CNTR_ALLOC_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_cntr_alloc_set_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *counter_p = cmd_body.cntr;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_counter_extended_set(const sx_api_handle_t                handle,
                                               const sx_access_cmd_t                cmd,
                                               const sx_router_counter_attributes_t cntr_attributes,
                                               sx_router_counter_id_t              *counter_p)
{
    sx_api_router_cntr_extended_alloc_set_params_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_p == NULL) {
        SX_LOG_ERR("counter_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ROUTER_COUNTER_TYPE_CHECK_RANGE(cntr_attributes.type) != TRUE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Counter type is out of range.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.cntr = *counter_p;
    cmd_body.cntr_attributes = cntr_attributes;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_ALLOC_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_cntr_extended_alloc_set_params_t));

    if (err != SX_STATUS_SUCCESS) {
        if ((err == SX_STATUS_PARAM_NULL) || (err == SX_STATUS_PARAM_EXCEEDS_RANGE)) {
            SX_LOG(SX_LOG_ERROR, "Counter type is out of range.\n");
            err = SX_STATUS_PARAM_ERROR;
        }
        goto out;
    }

    *counter_p = cmd_body.cntr;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_counter_bind_set(const sx_api_handle_t        handle,
                                                     const sx_access_cmd_t        cmd,
                                                     const sx_router_counter_id_t counter,
                                                     const sx_router_interface_t  rif)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_cntr_bind_set_params_t cmd_body;
    sx_api_reply_head_t                  reply_head;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_cntr_bind_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.cntr = counter;
    cmd_body.rif = rif;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_counter_bind_get(const sx_api_handle_t        handle,
                                                     const sx_router_counter_id_t counter,
                                                     sx_router_interface_t       *rif_p)
{
    sx_api_router_cntr_bind_get_params_t cmd_body;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (rif_p == NULL) {
        SX_LOG_ERR("rif_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cntr = counter;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_cntr_bind_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *rif_p = cmd_body.rif;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_counter_get(const sx_api_handle_t        handle,
                                      const sx_access_cmd_t        cmd,
                                      const sx_router_counter_id_t counter,
                                      sx_router_counter_set_t     *counter_set_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_router_cntr_get_params_t  cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_api_router_cntr_get_params_t *reply_body = NULL;
    uint32_t                         reply_body_size = 0;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (counter_set_p == NULL) {
        SX_LOG_ERR("counter_set_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_cntr_get_params_t) +
                      sizeof(sx_router_counter_set_t);
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_CNTR_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_cntr_get_params_t);
    cmd_head.list_size = sizeof(sx_router_counter_set_t);

    cmd_body.cmd = cmd;
    cmd_body.cntr = counter;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY(*counter_set_p, reply_body->cntr_set[0]);

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_counter_extended_get(const sx_api_handle_t             handle,
                                               const sx_access_cmd_t             cmd,
                                               const sx_router_counter_id_t      counter_id,
                                               sx_router_counter_set_extended_t *counter_data_p)
{
    sx_api_router_cntr_extended_get_params_t cmd_body;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_data_p == NULL) {
        SX_LOG_ERR("counter_data_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ROUTER_COUNTER_TYPE_CHECK_RANGE(counter_data_p->type) != TRUE) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Counter type is out of range.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.cntr = counter_id;
    cmd_body.cntr_data.type = counter_data_p->type;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_CNTR_EXTENDED_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (err != SX_STATUS_SUCCESS) {
        if ((err == SX_STATUS_PARAM_NULL) || (err == SX_STATUS_PARAM_EXCEEDS_RANGE)) {
            SX_LOG_ERR("router counter extended get failed %s.\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
        }
        goto out;
    }

    SX_MEM_CPY(*counter_data_p, cmd_body.cntr_data);

out:
    SX_API_LOG_EXIT();
    return err;
}
sx_status_t sx_api_router_counter_attr_get(const sx_api_handle_t           handle,
                                           const sx_router_counter_id_t    counter_id,
                                           sx_router_counter_attributes_t *counter_attr_p)
{
    sx_api_router_interface_cntr_attr_get_params_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (counter_attr_p == NULL) {
        SX_LOG_ERR("counter_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    SX_MEM_CLR(cmd_body);

    cmd_body.cntr_id = counter_id;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_ATTR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (err != SX_STATUS_SUCCESS) {
        if ((err == SX_STATUS_PARAM_NULL) || (err == SX_STATUS_PARAM_EXCEEDS_RANGE)) {
            SX_LOG_ERR("router counter attribute get failed %s.\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
        }
        goto out;
    }

    SX_MEM_CPY(*counter_attr_p, cmd_body.cntr_attributes);

out:
    SX_API_LOG_EXIT();
    return err;
}
sx_status_t sx_api_router_counter_clear_set(const sx_api_handle_t        handle,
                                            const sx_router_counter_id_t counter,
                                            const boolean_t              all)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_router_cntr_clear_set_params_t cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);


    if (SX_CHECK_BOOLEAN(all) != TRUE) {
        SX_LOG(SX_LOG_ERROR, "all param of boolean type exceeds range (True / False).\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_CNTR_CLEAR_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_cntr_clear_set_params_t);

    cmd_body.cntr = counter;
    cmd_body.all = all;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_interface_counter_ext_get(const sx_api_handle_t             handle,
                                                    const sx_access_cmd_t             cmd,
                                                    const sx_router_interface_t       rif,
                                                    sx_router_counter_id_t           *counter_id_p,
                                                    sx_router_counter_set_extended_t *counter_data_p)
{
    sx_api_command_head_t                         cmd_head;
    sx_api_router_interface_cntr_ext_get_params_t cmd_body;
    sx_api_reply_head_t                           reply_head;
    sx_status_t                                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (counter_id_p == NULL) {
        SX_LOG_ERR("counter_id_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (counter_data_p == NULL) {
        SX_LOG_ERR("counter_data_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("%s is an unsupported command for the sx_api_router_interface_counter_ext_get API.\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.rif = rif;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_INTERFACE_CNTR_EXT_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("router interface counter extended get failed %s.\n", sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* if no router counter is bound to the RIF, SDK will return SX_ROUTER_COUNTER_ID_INVALID*/
    *counter_id_p = cmd_body.cntr_id;
    if (cmd_body.cntr_id != SX_ROUTER_COUNTER_ID_INVALID) {
        SX_MEM_CPY(*counter_data_p, cmd_body.cntr_data);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_set(const sx_api_handle_t            handle,
                                       const sx_access_cmd_t            cmd,
                                       const sx_router_id_t             vrid,
                                       const sx_mc_route_key_t        * mc_route_key_p,
                                       const sx_mc_route_attributes_t * mc_route_attr_p,
                                       const sx_mc_route_data_t       * mc_route_data_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_mc_route_set_params_t *cmd_body = NULL;
    uint32_t                             cmd_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_DELETE_ALL) &&
        (mc_route_key_p == NULL)) {
        SX_LOG_ERR("<mc_route_key_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) &&
        (mc_route_attr_p == NULL)) {
        SX_LOG_ERR("<mc_router_attr_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) &&
        (mc_route_data_p == NULL)) {
        SX_LOG_ERR("<mc_route_data_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Verify parameters that aren't supported yet aren't configured */
    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) {
        if (mc_route_data_p->action == SX_ROUTER_ACTION_SPAN) {
            SX_LOG_ERR("Router action %s is not supported.\n",
                       sx_router_action_str(mc_route_data_p->action));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    err = sx_router_utils_validate_mc_route_set(cmd, vrid, mc_route_key_p,
                                                mc_route_attr_p, mc_route_data_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_mc_route_set_params_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body->cmd = cmd;
    cmd_body->vrid = vrid;
    if (mc_route_key_p != NULL) {
        cmd_body->ingress_rif = mc_route_key_p->ingress_rif;
    } else {
        cmd_body->ingress_rif = RM_API_ROUTER_RIF_KEY_NULL;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        cmd_body->source_addr = mc_route_key_p->source_addr;
        cmd_body->mc_group_addr = mc_route_key_p->mc_group_addr;
        cmd_body->ingress_rif = mc_route_key_p->ingress_rif;
        cmd_body->mc_route_data = *mc_route_data_p;
        cmd_body->mc_router_attr = *mc_route_attr_p;
        break;

    case SX_ACCESS_CMD_EDIT:
        cmd_body->source_addr = mc_route_key_p->source_addr;
        cmd_body->mc_group_addr = mc_route_key_p->mc_group_addr;
        cmd_body->ingress_rif = mc_route_key_p->ingress_rif;
        cmd_body->mc_route_data = *mc_route_data_p;
        cmd_body->mc_router_attr = *mc_route_attr_p;
        break;

    case SX_ACCESS_CMD_DELETE:
        cmd_body->source_addr = mc_route_key_p->source_addr;
        cmd_body->mc_group_addr = mc_route_key_p->mc_group_addr;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        if (mc_route_key_p != NULL) {
            cmd_body->source_addr = mc_route_key_p->source_addr;
            cmd_body->mc_group_addr = mc_route_key_p->mc_group_addr;
        }
        break;

    default:
        SX_LOG_ERR("Invalid command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_get(const sx_api_handle_t     handle,
                                       const sx_access_cmd_t     cmd,
                                       const sx_router_id_t      vrid,
                                       const sx_mc_route_key_t * mc_route_key_p,
                                       sx_mc_route_key_filter_t *filter_p,
                                       sx_mc_route_get_entry_t  *mc_route_get_entries_list_p,
                                       uint32_t                 *mc_route_get_entries_cnt_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_router_mc_route_get_params_t  cmd_body;
    uint32_t                             reply_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_api_router_mc_route_get_params_t *reply_body = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    uint32_t                             i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT) && (cmd != SX_ACCESS_CMD_COUNT)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_COUNT) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (mc_route_key_p == NULL)) {
        SX_LOG_ERR("<mc_route_key_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (mc_route_get_entries_cnt_p == NULL) {
        SX_LOG_ERR("<mc_route_get_entries_cnt_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_COUNT) {
        if (mc_route_get_entries_list_p == NULL) {
            SX_LOG_ERR("<mc_route_get_entries_list_p> parameter is NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    err = sx_router_utils_validate_mc_route_get(cmd, vrid, mc_route_key_p,
                                                filter_p, mc_route_get_entries_list_p, mc_route_get_entries_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_mc_route_get_params_t) +
                      (sizeof(sx_mc_route_get_entry_t) * *mc_route_get_entries_cnt_p);
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_mc_route_get_params_t);
    cmd_head.list_size = sizeof(sx_mc_route_get_entry_t) * *mc_route_get_entries_cnt_p;

    cmd_body.cmd = cmd;
    cmd_body.vrid = vrid;
    if (mc_route_key_p) {
        cmd_body.ingress_rif = mc_route_key_p->ingress_rif;
        cmd_body.source_addr = mc_route_key_p->source_addr;
        cmd_body.mc_group_addr = mc_route_key_p->mc_group_addr;
    }
    if (filter_p) {
        cmd_body.filter = *filter_p;
    }
    cmd_body.mc_route_get_entries_cnt_p =
        (cmd == SX_ACCESS_CMD_GET) ? 1 : *mc_route_get_entries_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_GET) {
        *mc_route_get_entries_cnt_p = 1;
        mc_route_get_entries_list_p[0].mc_route_key = reply_body->mc_route_get_entries_list_p[0].mc_route_key;
        mc_route_get_entries_list_p[0].mc_route_attr = reply_body->mc_route_get_entries_list_p[0].mc_route_attr;
        mc_route_get_entries_list_p[0].mc_route_data = reply_body->mc_route_get_entries_list_p[0].mc_route_data;
    } else if (cmd != SX_ACCESS_CMD_COUNT) {
        if (reply_body->mc_route_get_entries_cnt_p > *mc_route_get_entries_cnt_p) {
            SX_LOG_ERR("Number of entries returned %u is larger than output buffer size %u.\n",
                       reply_body->mc_route_get_entries_cnt_p, *mc_route_get_entries_cnt_p);
            err = SX_STATUS_ERROR;
            goto out;
        }
        for (i = 0; i < reply_body->mc_route_get_entries_cnt_p; i++) {
            mc_route_get_entries_list_p[i].mc_route_key = reply_body->mc_route_get_entries_list_p[i].mc_route_key;
            mc_route_get_entries_list_p[i].mc_route_attr = reply_body->mc_route_get_entries_list_p[i].mc_route_attr;
            mc_route_get_entries_list_p[i].mc_route_data = reply_body->mc_route_get_entries_list_p[i].mc_route_data;
        }
        *mc_route_get_entries_cnt_p = reply_body->mc_route_get_entries_cnt_p;
    } else { /* SX_ACCESS_CMD_COUNT */
        *mc_route_get_entries_cnt_p = reply_body->mc_route_get_entries_cnt_p;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_activity_get(const sx_api_handle_t     handle,
                                                const sx_access_cmd_t     cmd,
                                                const sx_router_id_t      vrid,
                                                const sx_mc_route_key_t * mc_route_key_p,
                                                boolean_t                *activity_p)
{
    sx_api_command_head_t                         cmd_head;
    sx_api_router_mc_route_activity_get_params_t  cmd_body;
    uint32_t                                      reply_body_size = 0;
    sx_api_reply_head_t                           reply_head;
    sx_api_router_mc_route_activity_get_params_t *reply_body = NULL;
    sx_status_t                                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (mc_route_key_p == NULL) {
        SX_LOG_ERR("mc_route_key_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (activity_p == NULL) {
        SX_LOG_ERR("activity_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_router_utils_validate_mc_route_activity_get(cmd, vrid, mc_route_key_p,
                                                         activity_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_mc_route_activity_get_params_t);
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_mc_route_activity_get_params_t);

    cmd_body.cmd = cmd;
    cmd_body.vrid = vrid;
    cmd_body.source_addr = mc_route_key_p->source_addr;
    cmd_body.mc_group_addr = mc_route_key_p->mc_group_addr;
    cmd_body.ingress_rif = mc_route_key_p->ingress_rif;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *activity_p = reply_body->activity;

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_activity_notify(const sx_api_handle_t                       handle,
                                                   const sx_access_cmd_t                       cmd,
                                                   const sx_mc_route_activity_notify_filter_t *filter_p)
{
    sx_api_router_mc_route_activity_notify_params_t cmd_body;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (filter_p != NULL) {
        cmd_body.filter.filter_by_vrid = filter_p->filter_by_vrid;
        cmd_body.filter.vrid = filter_p->vrid;
        cmd_body.filter.filter_by_type = filter_p->filter_by_type;
        cmd_body.filter.type = filter_p->type;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_NOTIFY_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_egress_rif_set(const sx_api_handle_t        handle,
                                            const sx_access_cmd_t        cmd,
                                            const sx_router_id_t         vrid,
                                            const sx_mc_route_key_t     *mc_route_key_p,
                                            const sx_router_interface_t *egress_rif_list_p,
                                            const uint32_t               egress_rif_cnt)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_router_mc_egress_rifs_set_params_t *cmd_body = NULL;
    uint32_t                                   cmd_body_size = 0;
    sx_api_reply_head_t                        reply_head;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_SET) &&
        (cmd != SX_ACCESS_CMD_DELETE) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (mc_route_key_p == NULL) {
        SX_LOG_ERR("<mc_route_key_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_DELETE)) &&
        (egress_rif_list_p == NULL)) {
        SX_LOG_ERR("<egress_rif_list_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_router_utils_validate_mc_egress_rif_set(cmd, vrid, mc_route_key_p,
                                                     egress_rif_list_p, egress_rif_cnt);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_DELETE_ALL) {
        cmd_body_size = sizeof(sx_api_router_mc_egress_rifs_set_params_t);
    } else {
        cmd_body_size = sizeof(sx_api_router_mc_egress_rifs_set_params_t) +
                        (egress_rif_cnt * sizeof(sx_router_interface_t));
    }

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body->cmd = cmd;
    cmd_body->vrid = vrid;
    cmd_body->ingress_rif = mc_route_key_p->ingress_rif;
    cmd_body->source_addr = mc_route_key_p->source_addr;
    cmd_body->mc_group_addr = mc_route_key_p->mc_group_addr;
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        cmd_body->egress_rifs_num = egress_rif_cnt;
        SX_MEM_CPY_ARRAY(cmd_body->egress_rifs_arr, egress_rif_list_p,
                         egress_rif_cnt, sx_router_interface_t);
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_egress_rif_get(const sx_api_handle_t    handle,
                                            const sx_router_id_t     vrid,
                                            const sx_mc_route_key_t *mc_route_key_p,
                                            sx_router_interface_t   *egress_rif_list_p,
                                            uint32_t                *egress_rif_cnt)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_router_mc_egress_rifs_get_params_t  cmd_body;
    uint32_t                                   reply_body_size = 0;
    sx_api_reply_head_t                        reply_head;
    sx_api_router_mc_egress_rifs_get_params_t *reply_body = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (mc_route_key_p == NULL) {
        SX_LOG_ERR("<mc_route_key_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (egress_rif_cnt == NULL) {
        SX_LOG_ERR("<egress_rif_cnt> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (egress_rif_list_p == NULL) {
        *egress_rif_cnt = 0;
    }
    if (*egress_rif_cnt == 0) {
        egress_rif_list_p = NULL;
    }

    err = sx_router_utils_validate_mc_egress_rif_get(vrid, mc_route_key_p, egress_rif_list_p,
                                                     egress_rif_cnt);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_mc_egress_rifs_get_params_t) +
                      ((*egress_rif_cnt) * sizeof(sx_router_interface_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_mc_egress_rifs_get_params_t);
    cmd_head.list_size = (*egress_rif_cnt) * sizeof(sx_router_interface_t);

    cmd_body.vrid = vrid;
    cmd_body.ingress_rif = mc_route_key_p->ingress_rif;
    cmd_body.source_addr = mc_route_key_p->source_addr;
    cmd_body.mc_group_addr = mc_route_key_p->mc_group_addr;
    cmd_body.egress_rifs_num = *egress_rif_cnt;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*egress_rif_cnt == 0) {
        *egress_rif_cnt = reply_body->egress_rifs_num;
    } else if (*egress_rif_cnt >= reply_body->egress_rifs_num) {
        SX_MEM_CPY_ARRAY(egress_rif_list_p, reply_body->egress_rifs_arr,
                         reply_body->egress_rifs_num, sx_router_interface_t);
        *egress_rif_cnt = reply_body->egress_rifs_num;
    } else {
        SX_LOG_ERR("Number of entries returned %u is larger than output buffer size %u.\n",
                   reply_body->egress_rifs_num, *egress_rif_cnt);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_set(const sx_api_handle_t handle,
                                   const sx_access_cmd_t cmd,
                                   sx_ecmp_id_t         *ecmp_id_p,
                                   sx_next_hop_t        *next_hop_list_p,
                                   uint32_t             *next_hop_cnt_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_router_ecmp_set_params_t *cmd_body = NULL;
    uint32_t                         cmd_body_size = 0;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      free_err = SX_STATUS_SUCCESS;
    uint32_t                         i = 0;
    boolean_t                        use_next_hops_list = FALSE;
    sx_next_hop_type_t               next_hop_type = SX_NEXT_HOP_TYPE_MAX + 1;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);

    /* validations */
    if (NULL == ecmp_id_p) {
        SX_LOG_ERR("<ecmp_id> param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == next_hop_cnt_p) {
        SX_LOG_ERR("<next_hop_cnt> param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* for CREATE/SET you might have an empty list, thus enforce next_hop_list_p != NULL
     * only when next_hop_cnt != 0 */
    if ((SX_ACCESS_CMD_CREATE == cmd) || (SX_ACCESS_CMD_SET == cmd)) {
        if ((0 != *next_hop_cnt_p) && (NULL == next_hop_list_p)) {
            SX_LOG_ERR("<next_hop_list_p> param is NULL.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* for DESTROY, or if *next_hop_cnt_p = 0, no need to allocate
     * body size space for next hops */
    if ((SX_ACCESS_CMD_DESTROY == cmd) ||
        (0 == *next_hop_cnt_p)) {
        cmd_body_size = sizeof(sx_api_router_ecmp_set_params_t);
    } else {
        use_next_hops_list = TRUE;
        cmd_body_size = sizeof(sx_api_router_ecmp_set_params_t) +
                        *next_hop_cnt_p * sizeof(sx_next_hop_t);
    }
    if (TRUE == use_next_hops_list) {
        next_hop_type = next_hop_list_p[0].next_hop_key.type;

        for (i = 0; i < *next_hop_cnt_p; i++) {
            if (next_hop_list_p[i].next_hop_data.weight < 1) {
                SX_LOG_ERR("Next hop at index %u has a bad weight value %u.\n",
                           i, next_hop_list_p[i].next_hop_data.weight);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            /* Validate that all next hops are of the same type for MPLS and
             *  no mixing MPLS next hops with IP and IPinIP tunnel next hops*/
            switch (next_hop_type) {
            case SX_NEXT_HOP_TYPE_IP:
            case SX_NEXT_HOP_TYPE_RELOOKUP:
            case SX_NEXT_HOP_TYPE_TUNNEL_ENCAP:
                if (next_hop_list_p[i].next_hop_key.type == SX_NEXT_HOP_TYPE_MPLS) {
                    SX_LOG_ERR("Mixing SX_NEXT_HOP_TYPE_TUNNEL_ENCAP and SX_NEXT_HOP_TYPE_IP next hops "
                               "with SX_NEXT_HOP_TYPE_MPLS type is not supported.\n");
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
                break;

            case SX_NEXT_HOP_TYPE_MPLS:
                /* Check that we do not exceed the maximum next hops for a MPLS ecmp container */
                if (*next_hop_cnt_p > SX_MAX_ECMP_MPLS_NEXT_HOPS) {
                    SX_LOG_ERR("Up to %d MPLS next hops are supported.\n", SX_MAX_ECMP_MPLS_NEXT_HOPS);
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
                if (next_hop_type != next_hop_list_p[i].next_hop_key.type) {
                    SX_LOG_ERR("Mixing next hop types in MPLS container is not supported.\n");
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
                break;

            default:
                SX_LOG_ERR("Invalid next hop type %d.\n", next_hop_list_p[i].next_hop_key.type);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
                break;
            }
        }

        err = __sdk_router_ecmp_next_hop_key_ip_next_hop_addr_validate(next_hop_list_p, *next_hop_cnt_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
    }
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* end of validations */
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body->cmd = cmd;

    if (SX_ACCESS_CMD_CREATE != cmd) {
        cmd_body->ecmp_id = *ecmp_id_p;
    }

    /* for destroy - pass list_len 0 */
    if (SX_ACCESS_CMD_DESTROY == cmd) {
        cmd_body->next_hop_cnt = 0;
    } else {
        cmd_body->next_hop_cnt = *next_hop_cnt_p;
    }
    if (TRUE == use_next_hops_list) {
        SX_MEM_CPY_ARRAY(cmd_body->next_hop_list, next_hop_list_p,
                         *next_hop_cnt_p, sx_next_hop_t);
    }

    err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)cmd_body,
                                      cmd_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (((SX_ACCESS_CMD_CREATE == cmd) || (SX_ACCESS_CMD_SET == cmd)) &&
        (*next_hop_cnt_p > 0) && (next_hop_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(next_hop_list_p, cmd_body->next_hop_list,
                         cmd_body->next_hop_cnt, sx_next_hop_t);
    }

    if (SX_ACCESS_CMD_CREATE == cmd) {
        *ecmp_id_p = cmd_body->ecmp_id;
    }

    *next_hop_cnt_p = cmd_body->next_hop_cnt;

out:
    if (cmd_body) {
        free_err = utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free cmd_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

/* this function merges both sx_api_router_ecmp_get and sx_api_router_operational_ecmp_get
 * implementation, according to opcode*/
static sx_status_t __sx_api_router_ecmp_get_common(const sx_api_handle_t handle,
                                                   const sx_ecmp_id_t    ecmp_id,
                                                   sx_next_hop_t        *next_hop_list_p,
                                                   uint32_t             *next_hop_cnt_p,
                                                   uint32_t              opcode)
{
    sx_api_command_head_t            cmd_head;
    sx_api_router_ecmp_get_params_t  cmd_body;
    uint32_t                         reply_body_size = 0;
    sx_api_reply_head_t              reply_head;
    sx_api_router_ecmp_get_params_t *reply_body = NULL;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      free_err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == next_hop_cnt_p) {
        SX_LOG_ERR("<next_hop_cnt_p> param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == next_hop_list_p) {
        *next_hop_cnt_p = 0;
    }
    if (0 == *next_hop_cnt_p) {
        /* if this case the user request to get the number of next hop without getting the actual list */
        next_hop_list_p = NULL;
    }

    reply_body_size = sizeof(sx_api_router_ecmp_get_params_t) +
                      ((*next_hop_cnt_p) * sizeof(sx_next_hop_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = opcode;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_router_ecmp_get_params_t);
    cmd_head.list_size = (*next_hop_cnt_p) * sizeof(sx_next_hop_t);

    cmd_body.ecmp_id = ecmp_id;
    cmd_body.next_hop_cnt = *next_hop_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    if (0 == *next_hop_cnt_p) {
        *next_hop_cnt_p = reply_body->next_hop_cnt;
    } else if ((NULL != next_hop_list_p) && (*next_hop_cnt_p >= reply_body->next_hop_cnt)) {
        SX_MEM_CPY_ARRAY(next_hop_list_p, reply_body->next_hop_list,
                         reply_body->next_hop_cnt, sx_next_hop_t);
        *next_hop_cnt_p = reply_body->next_hop_cnt;
    } else {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Given next hop count is too short. Required %d elements.\n", reply_body->next_hop_cnt);
        goto out;
    }

out:
    if (NULL != reply_body) {
        free_err = utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
        reply_body = NULL;
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_get(const sx_api_handle_t handle,
                                   const sx_ecmp_id_t    ecmp_id,
                                   sx_next_hop_t        *next_hop_list_p,
                                   uint32_t             *next_hop_cnt_p)
{
    return __sx_api_router_ecmp_get_common(handle,
                                           ecmp_id,
                                           next_hop_list_p,
                                           next_hop_cnt_p,
                                           SX_API_INT_CMD_ROUTER_ECMP_GET_E);
}

sx_status_t sx_api_router_ecmp_iter_get(const sx_api_handle_t   handle,
                                        const sx_access_cmd_t   cmd,
                                        const sx_ecmp_id_t      ecmp_id,
                                        const sx_ecmp_filter_t *filter_p,
                                        sx_ecmp_id_t           *ecmp_list_p,
                                        uint32_t               *ecmp_cnt_p)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_router_ecmp_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_api_router_ecmp_iter_get_params_t* reply_body = NULL;
    uint32_t                              reply_body_size;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (ecmp_cnt_p == NULL) {
        SX_LOG_ERR("ecmp_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*ecmp_cnt_p > 0) && (ecmp_list_p == NULL)) {
        SX_LOG_ERR("*ecmp_cnt_p is not 0 but ecmp_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*ecmp_cnt_p == 0) {
            ecmp_list_p = NULL;
        } else {
            *ecmp_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*ecmp_cnt_p == 0) {
            SX_LOG_DBG("ECMP count is 0.\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_router_ecmp_iter_get_params_t) +
                      (*ecmp_cnt_p * sizeof(sx_ecmp_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_router_ecmp_iter_get_params_t);
    cmd_head.list_size = *ecmp_cnt_p * sizeof(sx_ecmp_id_t);

    cmd_body.ecmp_key = ecmp_id;
    cmd_body.cmd = cmd;
    cmd_body.ecmp_list_cnt = *ecmp_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_ecmp_filter_t);
    }

    *ecmp_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->ecmp_list_cnt != 0) {
        *ecmp_cnt_p = reply_body->ecmp_list_cnt;
        if (ecmp_list_p != NULL) {
            SX_MEM_CPY_ARRAY(ecmp_list_p, reply_body->ecmp_list,
                             reply_body->ecmp_list_cnt, sx_ecmp_id_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_operational_ecmp_get(const sx_api_handle_t handle,
                                               const sx_ecmp_id_t    ecmp_id,
                                               sx_next_hop_t        *next_hop_list_p,
                                               uint32_t             *next_hop_cnt_p)
{
    return __sx_api_router_ecmp_get_common(handle,
                                           ecmp_id,
                                           next_hop_list_p,
                                           next_hop_cnt_p,
                                           SX_API_INT_CMD_ROUTER_ECMP_OPERATIONAL_GET_E);
}


sx_status_t sx_api_router_ecmp_counter_bind_set(const sx_api_handle_t       handle,
                                                const sx_access_cmd_t       cmd,
                                                const sx_ecmp_id_t          ecmp_id,
                                                const sx_flow_counter_id_t *counter_id_list_p,
                                                const uint32_t             *offset_list_p,
                                                const uint32_t              elements_cnt)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_ecmp_counter_bind_set_params_t cmd_body;
    uint32_t                              curr_offset = 0;
    uint32_t                             *cmd_body_buffer = NULL;
    uint32_t                              cmd_body_buffer_size = 0;
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_status_t                           free_err = SX_STATUS_SUCCESS;
    uint32_t                              i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    /* validations */

    if (0 == elements_cnt) {
        SX_LOG_ERR("<elements_cnt> is 0.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((NULL == offset_list_p)) {
        SX_LOG_ERR("<offset_list_p> param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /*only need to check counter_id_list_p when doing bind*/
    if ((NULL == counter_id_list_p) && (cmd == SX_ACCESS_CMD_BIND)) {
        SX_LOG_ERR("<counter_id_list_p> param is NULL when doing bind.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (elements_cnt > 1) {
        for (i = 0; i < elements_cnt; i++) {
            if (INVALID_NEXT_HOP_OFFSET == offset_list_p[i]) {
                SX_LOG_ERR("Given INVALID_NEXT_HOP_OFFSET for a list with more than 1 entry.\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }
    /* end of validations */

    cmd_body_buffer_size = sizeof(sx_api_ecmp_counter_bind_set_params_t) +
                           elements_cnt * sizeof(uint32_t) +
                           elements_cnt * sizeof(sx_flow_counter_id_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body_buffer), 1, cmd_body_buffer_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params buffer.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ECMP_CNTR_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_buffer_size;

    /* serialize cmd body */
    cmd_body.cmd = cmd;
    cmd_body.ecmp_id = ecmp_id;
    cmd_body.elements_cnt = elements_cnt;
    SX_MEM_CPY_BUF(cmd_body_buffer, &cmd_body, sizeof(cmd_body));

    if (elements_cnt > 0) {
        curr_offset = sizeof(cmd_body);
        /* counter ids list */
        if (cmd == SX_ACCESS_CMD_BIND) {
            SX_MEM_CPY_ARRAY((uint8_t*)cmd_body_buffer + curr_offset, counter_id_list_p, elements_cnt,
                             counter_id_list_p[0]);
        }
        curr_offset += elements_cnt * sizeof(counter_id_list_p[0]);
        /* offsets list */
        SX_MEM_CPY_ARRAY((uint8_t*)cmd_body_buffer + curr_offset, offset_list_p, elements_cnt, offset_list_p[0]);
        curr_offset += elements_cnt * sizeof(offset_list_p[0]);
    }
    /*done*/


    err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)cmd_body_buffer,
                                      cmd_body_buffer_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    if (cmd_body_buffer) {
        free_err = utils_memory_put(cmd_body_buffer, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free cmd_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_fine_grain_counter_bind_set(const sx_api_handle_t      handle,
                                                           const sx_access_cmd_t      cmd,
                                                           const sx_ecmp_id_t         ecmp_id,
                                                           const sx_flow_counter_id_t counter_id,
                                                           const uint32_t            *offset_list_p,
                                                           const uint32_t             elements_cnt)
{
    sx_api_command_head_t                            cmd_head;
    sx_api_ecmp_fine_grain_counter_bind_set_params_t cmd_body;
    uint32_t                                         curr_offset = 0;
    uint32_t                                        *cmd_body_buffer = NULL;
    uint32_t                                         cmd_body_buffer_size = 0;
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_status_t                                      free_err = SX_STATUS_SUCCESS;
    uint32_t                                         i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);

    /* validations */
    if (0 == elements_cnt) {
        SX_LOG_ERR("<elements_cnt> is 0.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (offset_list_p == NULL) {
        SX_LOG_ERR("<offset_list_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (i = 0; i < elements_cnt; i++) {
        if (offset_list_p[i] == INVALID_NEXT_HOP_OFFSET) {
            SX_LOG_ERR("Given INVALID_NEXT_HOP_OFFSET.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
    /* end of validations */

    cmd_body_buffer_size = sizeof(sx_api_ecmp_fine_grain_counter_bind_set_params_t) +
                           elements_cnt * sizeof(offset_list_p[0]);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_buffer), 1, cmd_body_buffer_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params buffer.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_FINE_GRAIN_COUNTER_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_buffer_size;

    /* serialize cmd body */
    cmd_body.cmd = cmd;
    cmd_body.ecmp_id = ecmp_id;
    cmd_body.counter_id = counter_id;
    cmd_body.elements_cnt = elements_cnt;
    SX_MEM_CPY_BUF(cmd_body_buffer, &cmd_body, sizeof(cmd_body));

    if (elements_cnt > 0) {
        curr_offset = sizeof(cmd_body);
        /* offsets list */
        SX_MEM_CPY_ARRAY((uint8_t*)cmd_body_buffer + curr_offset, offset_list_p, elements_cnt, offset_list_p[0]);
    }

    err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)cmd_body_buffer,
                                      cmd_body_buffer_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    if (cmd_body_buffer) {
        free_err = utils_memory_put(cmd_body_buffer, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free cmd_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_cos_rewrite_pcpdei_enable_set(const sx_api_handle_t          handle,
                                                        const sx_cos_pcp_dei_rewrite_e rewrite_pcp_dei)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    sx_api_router_cos_rewrite_pcpdei_enable_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (rewrite_pcp_dei > SX_COS_PCP_DEI_REWRITE_MAX_E) {
        SX_LOG_ERR("Out of range rewrite_pcp_dei.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    cmd_body.rewrite_pcp_dei = rewrite_pcp_dei;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_cos_rewrite_pcpdei_enable_get(const sx_api_handle_t     handle,
                                                        sx_cos_pcp_dei_rewrite_e *rewrite_pcp_dei_p)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    sx_api_router_cos_rewrite_pcpdei_enable_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (rewrite_pcp_dei_p == NULL) {
        SX_LOG_ERR("rewrite_pcp_dei_p is NULL.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COS_REWRITE_PCPDEI_ENABLE_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    *rewrite_pcp_dei_p = cmd_body.rewrite_pcp_dei;
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_cos_prio_update_enable_set(const sx_api_handle_t handle,
                                                     const boolean_t       update_priority_color)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_cos_prio_update_enable_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.update_priority_color = update_priority_color;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_cos_prio_update_enable_get(const sx_api_handle_t handle,
                                                     boolean_t            *update_priority_color_p)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_router_cos_prio_update_enable_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (update_priority_color_p == NULL) {
        SX_LOG_ERR("update_priority_color_p is NULL.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COS_PRIO_UPDATE_ENABLE_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    *update_priority_color_p = cmd_body.update_priority_color;
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_cos_dscp_to_prio_set(const sx_api_handle_t          handle,
                                               const sx_cos_dscp_t           *dscp_p,
                                               const sx_cos_priority_color_t *priority_color_p,
                                               const uint32_t                 element_cnt)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     i = 0, cmd_body_size = 0;
    sx_api_router_cos_dscp_to_prio_set_params_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((priority_color_p == NULL) || (dscp_p == NULL)) {
        SX_LOG_ERR("priority_color_p or dscp_p is NULL.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    cmd_body_size = element_cnt * sizeof(sx_cos_dscp_switch_prio_color_t) +
                    sizeof(sx_api_router_cos_dscp_to_prio_set_params_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    for (i = 0; i < element_cnt; i++) {
        cmd_body->dscp_switch_prio_list[i].dscp = dscp_p[i];
        cmd_body->dscp_switch_prio_list[i].priority_color.priority = priority_color_p[i].priority;
        cmd_body->dscp_switch_prio_list[i].priority_color.color = priority_color_p[i].color;
    }

    cmd_body->element_cnt = element_cnt;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_SET_E,
                                      (uint8_t*)cmd_body, cmd_body_size);
out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_router_cos_dscp_to_prio_get(const sx_api_handle_t    handle,
                                               sx_cos_dscp_t           *dscp_p,
                                               sx_cos_priority_color_t *priority_color_p,
                                               uint32_t                *element_cnt_p)
{
    sx_api_command_head_t                        cmd_head;
    sx_api_router_cos_dscp_to_prio_get_params_t *cmd_body = NULL;
    uint32_t                                     cmd_body_size = 0, reply_body_size = 0, i = 0;
    sx_api_reply_head_t                          reply_head;
    sx_api_router_cos_dscp_to_prio_get_params_t *reply_body = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (element_cnt_p == NULL) {
        SX_LOG_ERR("element_cnt_p is NULL.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (!priority_color_p || !dscp_p) {
        *element_cnt_p = 0;
    }
    if (*element_cnt_p == 0) { /* only the port count is needed */
        priority_color_p = NULL;
        dscp_p = NULL;
    }

    cmd_body_size = sizeof(sx_api_router_cos_dscp_to_prio_get_params_t) +
                    ((*element_cnt_p) * sizeof(sx_cos_dscp_switch_prio_color_t));
    reply_body_size = cmd_body_size;
    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for reply body.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_COS_DSCP_TO_PRIO_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body->element_cnt = *element_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*element_cnt_p == 0) {
        *element_cnt_p = reply_body->element_cnt;
    } else {
        for (i = 0; i < reply_body->element_cnt; i++) {
            dscp_p[i] = reply_body->dscp_switch_prio_list[i].dscp;
            priority_color_p[i].priority = reply_body->dscp_switch_prio_list[i].priority_color.priority;
            priority_color_p[i].color = reply_body->dscp_switch_prio_list[i].priority_color.color;
        }
        *element_cnt_p = reply_body->element_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_neigh_activity_notify(const sx_api_handle_t                    handle,
                                                const sx_access_cmd_t                    cmd,
                                                const sx_router_neigh_activity_filter_t *filter_p)
{
    sx_api_router_neigh_activity_notify_params_t cmd_body;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;

    if (filter_p != NULL) {
        cmd_body.filter.filter_by_rif = filter_p->filter_by_rif;
        cmd_body.filter.rif = filter_p->rif;
        cmd_body.filter.filter_by_type = filter_p->filter_by_type;
        cmd_body.filter.type = filter_p->type;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_NOTIFY_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_uc_route_counter_bind_set(const sx_api_handle_t      handle,
                                                    const sx_access_cmd_t      cmd,
                                                    const sx_router_id_t       vrid,
                                                    const sx_ip_prefix_t      *network_addr_p,
                                                    const sx_flow_counter_id_t counter_id)
{
    sx_api_router_uc_route_counter_bind_set_params_t cmd_body;
    sx_status_t                                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (network_addr_p == NULL) {
        SX_LOG_ERR("Network address must not be NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (SX_IP_VERSION_CHECK_RANGE(network_addr_p->version) != TRUE) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (!SX_IP_PREFIX_VALID(*network_addr_p)) {
        SX_LOG_ERR("Prefix is not valid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (!IS_IP_UNICAST(*network_addr_p)) {
        SX_LOG_ERR("Specified network address is not unicast.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (cmd == SX_ACCESS_CMD_BIND) {
        if (counter_id == SX_FLOW_COUNTER_ID_INVALID) {
            SX_LOG_ERR("counter_id must be valid when binding.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.vrid = vrid;
    cmd_body.network_addr = *network_addr_p;
    cmd_body.counter_id = counter_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_SET_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_uc_route_counter_bind_get(const sx_api_handle_t handle,
                                                    const sx_router_id_t  vrid,
                                                    const sx_ip_prefix_t *network_addr_p,
                                                    sx_flow_counter_id_t *counter_id_p)
{
    sx_api_router_uc_route_counter_bind_get_params_t cmd_body;
    sx_status_t                                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (network_addr_p == NULL) {
        SX_LOG_ERR("Network address must not be NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (SX_IP_VERSION_CHECK_RANGE(network_addr_p->version) != TRUE) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (!SX_IP_PREFIX_VALID(*network_addr_p)) {
        SX_LOG_ERR("Prefix is not valid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (!IS_IP_UNICAST(*network_addr_p)) {
        SX_LOG_ERR("Specified network address is not unicast.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (counter_id_p == NULL) {
        SX_LOG_ERR("counter_id_p must not be NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.vrid = vrid;
    cmd_body.network_addr = *network_addr_p;
    cmd_body.counter_id = *counter_id_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_UC_ROUTE_COUNTER_BIND_GET_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *counter_id_p = cmd_body.counter_id;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_attributes_set(const sx_api_handle_t       handle,
                                              const sx_ecmp_id_t          ecmp_id,
                                              const sx_ecmp_attributes_t *attr_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_router_ecmp_attributes_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.ecmp_id = ecmp_id;
    SX_MEM_CPY(cmd_body.attr, *attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_counter_bind_set(const sx_api_handle_t      handle,
                                                    const sx_access_cmd_t      cmd,
                                                    const sx_router_id_t       vrid,
                                                    const sx_mc_route_key_t   *mc_route_key_p,
                                                    const sx_flow_counter_id_t counter_id)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                            cmd_head;
    sx_api_router_mc_route_counter_bind_set_params_t cmd_body;
    uint32_t                                         cmd_body_size = 0;
    sx_api_reply_head_t                              reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (mc_route_key_p == NULL) {
        SX_LOG_ERR("<mc_route_key_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_router_utils_validate_mc_route_counter_bind_set(cmd, vrid, mc_route_key_p,
                                                             counter_id);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_mc_route_counter_bind_set_params_t);

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body.cmd = cmd;
    cmd_body.ingress_rif = mc_route_key_p->ingress_rif;
    cmd_body.mc_group_addr = mc_route_key_p->mc_group_addr;
    cmd_body.flow_counter_id = counter_id;
    cmd_body.source_addr = mc_route_key_p->source_addr;
    cmd_body.vrid = vrid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_attributes_get(const sx_api_handle_t handle,
                                              const sx_ecmp_id_t    ecmp_id,
                                              sx_ecmp_attributes_t *attr_p)
{
    sx_api_router_ecmp_attributes_get_params_t cmd_body;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.ecmp_id = ecmp_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_ECMP_ATTRIBUTES_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    SX_MEM_CPY(*attr_p, cmd_body.attr);
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_route_counter_bind_get(const sx_api_handle_t    handle,
                                                    const sx_router_id_t     vrid,
                                                    const sx_mc_route_key_t *mc_route_key_p,
                                                    sx_flow_counter_id_t    *counter_id_p)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                            cmd_head;
    sx_api_router_mc_route_counter_bind_get_params_t cmd_body;
    uint32_t                                         cmd_body_size = 0;
    uint32_t                                         reply_body_size = 0;
    sx_api_reply_head_t                              reply_head;
    sx_api_router_mc_route_counter_bind_get_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (mc_route_key_p == NULL) {
        SX_LOG_ERR("<mc_route_key_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (counter_id_p == NULL) {
        SX_LOG_ERR("<counter_id_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_router_utils_validate_mc_route_counter_bind_get(vrid, mc_route_key_p,
                                                             counter_id_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_mc_route_counter_bind_get_params_t);

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_ROUTE_COUNTER_BIND_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body.vrid = vrid;
    cmd_body.source_addr = mc_route_key_p->source_addr;
    cmd_body.ingress_rif = mc_route_key_p->ingress_rif;
    cmd_body.mc_group_addr = mc_route_key_p->mc_group_addr;

    reply_body_size = sizeof(sx_api_router_mc_route_counter_bind_get_params_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *counter_id_p = reply_body.flow_counter_id;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_rpf_group_set(const sx_api_handle_t   handle,
                                           const sx_access_cmd_t   cmd,
                                           sx_rpf_group_id_t      *rpf_group_id_p,
                                           sx_router_vinterface_t *rpf_vif_list_p,
                                           uint32_t                rpf_vif_cnt)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_router_mc_rpf_group_set_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_body_size = 0;


    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_SET) &&
        (cmd != SX_ACCESS_CMD_DESTROY) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_DELETE_ALL) && (rpf_group_id_p == NULL)) {
        SX_LOG_ERR("<rpf_group_id_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_CREATE) || (cmd == SX_ACCESS_CMD_SET)) &&
        (rpf_vif_list_p == NULL)) {
        SX_LOG_ERR("<rpf_vif_list_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_router_utils_validate_mc_rpf_group_set(cmd, rpf_group_id_p,
                                                    rpf_vif_list_p, rpf_vif_cnt);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_mc_rpf_group_set_params_t) +
                    (rpf_vif_cnt * sizeof(sx_router_vinterface_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_body_p->cmd = cmd;
    if ((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_DESTROY)) {
        cmd_body_p->rpf_group_id = *rpf_group_id_p;
    }
    cmd_body_p->rpf_vif_cnt = rpf_vif_cnt;
    if ((cmd == SX_ACCESS_CMD_CREATE) || (cmd == SX_ACCESS_CMD_SET)) {
        SX_MEM_CPY_ARRAY(cmd_body_p->rpf_vif_list_p, rpf_vif_list_p, rpf_vif_cnt,
                         sx_router_vinterface_t);
    }


    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_SET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_body_size);


    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        *rpf_group_id_p = cmd_body_p->rpf_group_id;
    }

out:
    if (cmd_body_p) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_mc_rpf_group_get(const sx_api_handle_t   handle,
                                           const sx_access_cmd_t   cmd,
                                           sx_rpf_group_id_t      *rpf_group_id_p,
                                           sx_router_vinterface_t *rpf_vif_list_p,
                                           uint32_t               *rpf_vif_cnt_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_router_mc_rpf_group_get_params_t  cmd_body;
    uint32_t                                 cmd_body_size = 0;
    uint32_t                                 reply_body_size = 0;
    sx_api_reply_head_t                      reply_head;
    sx_api_router_mc_rpf_group_get_params_t *reply_body = NULL;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT) && (cmd != SX_ACCESS_CMD_COUNT)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_COUNT) && (rpf_group_id_p == NULL)) {
        SX_LOG_ERR("<rpf_group_id_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (rpf_vif_cnt_p == NULL) {
        SX_LOG_ERR("<rpf_vif_cnt_p> parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (rpf_vif_list_p == NULL) {
        *rpf_vif_cnt_p = 0;
    }

    if (*rpf_vif_cnt_p == 0) {
        rpf_vif_list_p = NULL;
    }

    err = sx_router_utils_validate_mc_rpf_group_get(cmd, rpf_group_id_p,
                                                    rpf_vif_list_p, rpf_vif_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_mc_rpf_group_get_params_t);

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_MC_RPF_GROUP_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;
    cmd_head.list_size = *rpf_vif_cnt_p * sizeof(sx_router_vinterface_t);

    cmd_body.cmd = cmd;
    if (cmd == SX_ACCESS_CMD_GET) {
        cmd_body.rpf_group_id = *rpf_group_id_p;
    }
    cmd_body.rpf_vif_cnt = *rpf_vif_cnt_p;

    reply_body_size = sizeof(sx_api_router_mc_rpf_group_get_params_t) +
                      (*rpf_vif_cnt_p * sizeof(sx_router_vinterface_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GET_FIRST) || (cmd == SX_ACCESS_CMD_GETNEXT)) {
        *rpf_group_id_p = reply_body->rpf_group_id;
    }

    if (rpf_vif_list_p) {
        if (reply_body->rpf_vif_cnt > *rpf_vif_cnt_p) {
            SX_LOG_ERR("Number of RIFs returned %u is larger than given buffer size %u.\n",
                       reply_body->rpf_vif_cnt, *rpf_vif_cnt_p);
            err = SX_STATUS_ERROR;
            goto out;
        }

        SX_MEM_CPY_ARRAY(rpf_vif_list_p, reply_body->rpf_vif_list_p,
                         reply_body->rpf_vif_cnt, sx_router_vinterface_t);
    }

    *rpf_vif_cnt_p = reply_body->rpf_vif_cnt;

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
sx_status_t sx_api_router_ecmp_clone_set(const sx_api_handle_t handle,
                                         const sx_ecmp_id_t    old_ecmp_id,
                                         sx_ecmp_id_t         *new_ecmp_id_p)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_router_ecmp_clone_set_params_t *cmd_body = NULL;
    uint32_t                               cmd_body_size = 0;
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_status_t                            free_err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);

    /* Validations */
    if (new_ecmp_id_p == NULL) {
        SX_LOG_ERR("new_ecmp_id_p param is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (old_ecmp_id == 0) {
        SX_LOG_ERR("new_ecmp_id params illegal ID.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_ecmp_clone_set_params_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                              UTILS_MEM_TYPE_ID_API_E);
    if (rc != SX_STATUS_SUCCESS) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_CLONE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body->old_ecmp_id = old_ecmp_id;
    rc = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)cmd_body,
                                     cmd_body_size);

    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    *new_ecmp_id_p = cmd_body->new_ecmp_id;


out:
    if (cmd_body) {
        free_err = utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free cmd_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_router_ecmp_action_set(const sx_api_handle_t                 handle,
                                          const sx_access_cmd_t                 cmd,
                                          const sx_router_ecmp_action_cfg_t    *action_p,
                                          const sx_router_ecmp_action_filter_t *action_filter_p,
                                          sx_router_ecmp_action_stat_t         *action_stat_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                  cmd_head;
    sx_api_router_ecmp_action_set_params_t cmd_body;
    uint32_t                               cmd_body_size = 0;
    uint32_t                               reply_body_size = 0;
    sx_api_reply_head_t                    reply_head;
    sx_api_router_ecmp_action_set_params_t reply_body;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    cmd_body_size = sizeof(sx_api_router_ecmp_action_set_params_t);

    if (action_filter_p->filter_type == SX_ROUTER_ECMP_FILTER_TYPE_BY_ID_E) {
        cmd_body_size += action_filter_p->filter_data.filter_by_id.ecmp_id_cnt *
                         sizeof(sx_ecmp_id_t);
    }
    if (action_p->action_data_type == SX_ROUTER_ECMP_ACTION_DATA_TYPE_RIF_E) {
        cmd_body_size += action_p->action_data.rif_data.rif_cnt *
                         sizeof(sx_router_interface_t);
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_ACTION_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.action, action_p);
    SX_MEM_CPY_P(&cmd_body.action_filter, action_filter_p);
    if (action_filter_p->filter_type == SX_ROUTER_ECMP_FILTER_TYPE_BY_ID_E) {
        SX_MEM_CPY_ARRAY(cmd_body.action_filter.filter_data.filter_by_id.ecmp_id_list,
                         action_filter_p->filter_data.filter_by_id.ecmp_id_list,
                         action_filter_p->filter_data.filter_by_id.ecmp_id_cnt, sx_ecmp_id_t);
    }
    if (action_p->action_data_type == SX_ROUTER_ECMP_ACTION_DATA_TYPE_RIF_E) {
        SX_MEM_CPY_ARRAY(cmd_body.action.action_data.rif_data.rif_list,
                         action_p->action_data.rif_data.rif_list,
                         action_p->action_data.rif_data.rif_cnt, sx_router_interface_t);
    }
    reply_body_size = sizeof(sx_api_router_ecmp_action_set_params_t);
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(action_stat_p, &reply_body.action_stat);

out:
    return err;
}

sx_status_t sx_api_router_ecmp_action_suppress_filter_iter_get(const sx_api_handle_t                 handle,
                                                               const sx_access_cmd_t                 cmd,
                                                               const sx_router_ecmp_action_cfg_t    *action_p,
                                                               const sx_router_ecmp_action_filter_t *action_filter_key_p,
                                                               sx_router_ecmp_action_filter_t       *action_filter_list_p,
                                                               uint32_t                             *action_filter_cnt_p)
{
    sx_status_t                                                  err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                        cmd_head;
    sx_api_router_ecmp_action_suppress_filter_iter_get_params_t  cmd_body;
    uint32_t                                                     cmd_body_size = 0;
    uint32_t                                                     reply_body_size = 0;
    sx_api_reply_head_t                                          reply_head;
    sx_api_router_ecmp_action_suppress_filter_iter_get_params_t *reply_body = NULL;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) && (cmd != SX_ACCESS_CMD_GETNEXT)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((action_p == NULL) || (action_filter_cnt_p == NULL) ||
        ((cmd == SX_ACCESS_CMD_GET) && (action_filter_key_p == NULL) && (*action_filter_cnt_p != 0)) ||
        ((*action_filter_cnt_p != 0) && (action_filter_list_p == NULL)) ||
        ((cmd == SX_ACCESS_CMD_GETNEXT) && (action_filter_key_p == NULL))) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL parameter given.\n");
        goto out;
    }

    if ((*action_filter_cnt_p == 0) && (cmd != SX_ACCESS_CMD_GET)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid filter action count [0].\n");
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GET) && (*action_filter_cnt_p != 0)) {
        *action_filter_cnt_p = 1;
    }

    cmd_body_size = sizeof(sx_api_router_ecmp_action_suppress_filter_iter_get_params_t);

    reply_body_size = sizeof(sx_api_router_ecmp_action_suppress_filter_iter_get_params_t) +
                      (*action_filter_cnt_p * sizeof(sx_router_ecmp_action_filter_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_ACTION_SUPPRESS_FILTER_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;
    cmd_head.list_size = *action_filter_cnt_p * sizeof(sx_router_ecmp_action_filter_t);

    cmd_body.cmd = cmd;
    if ((*action_filter_cnt_p == 0) && (cmd == SX_ACCESS_CMD_GET)) {
        cmd_body.cmd = SX_ACCESS_CMD_COUNT;
    }
    cmd_body.action_cnt = *action_filter_cnt_p;
    SX_MEM_CPY(cmd_body.action, *action_p);
    if (action_filter_key_p) {
        SX_MEM_CPY(cmd_body.action_filter, *action_filter_key_p);
    }
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }
    if (reply_body->cmd != SX_ACCESS_CMD_COUNT) {
        SX_MEM_CPY_ARRAY(action_filter_list_p, &reply_body->action_list_p,
                         reply_body->action_cnt, sx_router_ecmp_action_filter_t);
    }

    *action_filter_cnt_p = reply_body->action_cnt;

out:
    if (reply_body) {
        err = utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to clear RIF bind memory: [%u]\n", err);
        }
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_redirect_set(const sx_api_handle_t handle,
                                            const sx_access_cmd_t cmd,
                                            const sx_ecmp_id_t    ecmp,
                                            const sx_ecmp_id_t    redirect_ecmp)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_router_ecmp_redirect_set_params_t cmd_body;
    uint32_t                                 cmd_body_size = 0;
    uint32_t                                 reply_body_size = 0;
    sx_api_reply_head_t                      reply_head;
    sx_api_router_ecmp_redirect_set_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_ecmp_redirect_set_params_t);
    reply_body_size = cmd_body_size;

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;
    cmd_body.ecmp = ecmp;
    if (cmd == SX_ACCESS_CMD_CREATE) {
        cmd_body.redirect_ecmp = redirect_ecmp;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_redirect_get(const sx_api_handle_t handle,
                                            const sx_ecmp_id_t    ecmp,
                                            boolean_t            *is_redirected_p,
                                            sx_ecmp_id_t         *redirect_ecmp_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_router_ecmp_redirect_get_params_t cmd_body;
    uint32_t                                 cmd_body_size = 0;
    uint32_t                                 reply_body_size = 0;
    sx_api_reply_head_t                      reply_head;
    sx_api_router_ecmp_redirect_get_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (is_redirected_p == NULL) {
        SX_LOG_ERR("is_redirected_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (redirect_ecmp_p == NULL) {
        SX_LOG_ERR("redirected_ecmp_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_router_ecmp_redirect_get_params_t);
    reply_body_size = cmd_body_size;

    cmd_head.opcode = SX_API_INT_CMD_ROUTER_ECMP_REDIRECT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.ecmp = ecmp;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *is_redirected_p = reply_body.is_redirected;
    *redirect_ecmp_p = reply_body.redirect_ecmp;

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_req_completion_info_get(const sx_api_handle_t                      handle,
                                                  sx_router_req_completion_info_get_entry_t* completion_info_p)
{
    sx_api_router_completion_info_get_params_t cmd_body;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (completion_info_p == NULL) {
        SX_LOG_ERR("completion_info_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_COMPLETION_INFO_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_router_completion_info_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    completion_info_p->uc_route_info.user_cookie = cmd_body.uc_route_info.user_cookie;


out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_user_defined_lpm_tree_set(const sx_api_handle_t                 handle,
                                                    const sx_access_cmd_t                 cmd,
                                                    const sx_lpm_tree_node_t            * nodes_list_p,
                                                    const uint8_t                         nodes_cnt,
                                                    const sx_router_lpm_tree_attributes_t sx_lpm_tree_attributes,
                                                    sx_lpm_tree_id_t                    * sx_tree_id_p)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_status_t                                       out_err = SX_STATUS_SUCCESS;
    uint32_t                                          cmd_body_size = 0;
    uint32_t                                          dynamic_size = 0;
    sx_api_router_user_defined_lpm_tree_set_params_t* cmd_body = NULL;

    SX_API_LOG_ENTER();

    if (NULL == nodes_list_p) {
        SX_LOG_ERR("nodes_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (NULL == sx_tree_id_p) {
        SX_LOG_ERR("sx_tree_id_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (0 == nodes_cnt) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    dynamic_size = nodes_cnt * sizeof(sx_lpm_tree_node_t);
    cmd_body_size = sizeof(sx_api_router_user_defined_lpm_tree_set_params_t) + dynamic_size;
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        cmd_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for user defined lpm tree params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->nodes_cnt = nodes_cnt;
    cmd_body->tree_id = *sx_tree_id_p;

    SX_MEM_CPY(cmd_body->lpm_tree_attributes, sx_lpm_tree_attributes);

    SX_MEM_CPY_ARRAY(cmd_body->nodes_list_p,
                     nodes_list_p,
                     nodes_cnt,
                     sx_lpm_tree_node_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_SET_E,
                                      (uint8_t*)cmd_body,
                                      cmd_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *sx_tree_id_p = cmd_body->tree_id;

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free memory for user defined lpm tree params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_user_defined_lpm_tree_get(const sx_api_handle_t  handle,
                                                    const sx_lpm_tree_id_t tree_id,
                                                    sx_lpm_tree_node_t   * nodes_list_p,
                                                    uint8_t              * nodes_cnt_p)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_status_t                                       out_err = SX_STATUS_SUCCESS;
    uint32_t                                          cmd_body_size = 0;
    uint32_t                                          dynamic_size = 0;
    sx_api_router_user_defined_lpm_tree_get_params_t* cmd_body = NULL;

    SX_API_LOG_ENTER();

    if (nodes_cnt_p == NULL) {
        SX_LOG_ERR(" nodes cnt param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (nodes_list_p == NULL) {
        *nodes_cnt_p = 0;
    }
    if (*nodes_cnt_p == 0) {
        nodes_list_p = NULL;
    }

    dynamic_size = *nodes_cnt_p * sizeof(sx_lpm_tree_node_t);
    cmd_body_size = sizeof(sx_api_router_user_defined_lpm_tree_get_params_t) + dynamic_size;
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        cmd_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for user defined lpm tree params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->tree_id = tree_id;
    cmd_body->nodes_cnt = *nodes_cnt_p;

    SX_MEM_CPY_ARRAY(cmd_body->nodes_list_p,
                     nodes_list_p,
                     *nodes_cnt_p,
                     sx_lpm_tree_node_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_USER_DEFINED_LPM_TREE_GET_E,
                                      (uint8_t*)cmd_body,
                                      cmd_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*nodes_cnt_p == 0) {
        *nodes_cnt_p = cmd_body->nodes_cnt;
    } else if (*nodes_cnt_p >= cmd_body->nodes_cnt) {
        SX_MEM_CPY_ARRAY(nodes_list_p, cmd_body->nodes_list_p,
                         cmd_body->nodes_cnt, sx_lpm_tree_node_t);
        *nodes_cnt_p = cmd_body->nodes_cnt;
    } else {
        SX_LOG_ERR("Number of nodes returned %u is larger than output buffer size %u.\n",
                   cmd_body->nodes_cnt, *nodes_cnt_p);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free memory for user defined lpm tree params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_ecmp_update_set(const sx_api_handle_t   handle,
                                          const sx_access_cmd_t   cmd,
                                          const sx_ecmp_id_t      ecmp_id,
                                          sx_ecmp_update_entry_t *next_hop_update_list_p,
                                          uint32_t                next_hop_update_list_cnt)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_status_t                             out_err = SX_STATUS_SUCCESS;
    uint32_t                                cmd_body_size = 0;
    uint32_t                                dynamic_size = 0;
    sx_api_router_ecmp_update_set_params_t* cmd_body = NULL;

    SX_API_LOG_ENTER();

    if (next_hop_update_list_p == NULL) {
        SX_LOG_ERR("next hop list parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (next_hop_update_list_cnt == 0) {
        goto out;
    }


    dynamic_size = next_hop_update_list_cnt * sizeof(sx_ecmp_update_entry_t);
    cmd_body_size = sizeof(sx_api_router_ecmp_update_set_params_t) + dynamic_size;
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        cmd_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for user defined ECMP update params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->ecmp_id = ecmp_id;
    cmd_body->next_hop_update_list_cnt = next_hop_update_list_cnt;

    SX_MEM_CPY_ARRAY(cmd_body->next_hop_update_list_p,
                     next_hop_update_list_p,
                     next_hop_update_list_cnt,
                     sx_ecmp_update_entry_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_ECMP_UPDATE_SET_E,
                                      (uint8_t*)cmd_body,
                                      cmd_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free memory for user defined ECMP update params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_nat_set(const sx_api_handle_t handle,
                                  const sx_access_cmd_t cmd,
                                  sx_router_nat_cfg_t * nat_cfg_p,
                                  sx_nat_id_t         * nat_id_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_router_nat_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (nat_id_p == NULL) {
        SX_LOG_ERR("nat_id_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((nat_cfg_p == NULL) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("nat_cfg_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    if (cmd != SX_ACCESS_CMD_DESTROY) {
        cmd_body.nat_cfg = *nat_cfg_p;
    }
    if (cmd != SX_ACCESS_CMD_CREATE) {
        cmd_body.nat_id = *nat_id_p;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_NAT_SET_E, (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set NAT - [%s]\n", sx_status_str(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        *nat_id_p = cmd_body.nat_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_nat_get(const sx_api_handle_t handle,
                                  const sx_access_cmd_t cmd,
                                  const sx_nat_id_t     nat_id,
                                  sx_router_nat_cfg_t * nat_cfg_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_router_nat_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (nat_cfg_p == NULL) {
        SX_LOG_ERR("nat_cfg_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.nat_id = nat_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ROUTER_NAT_GET_E, (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get NAT - [%s]\n", sx_status_str(err));
        goto out;
    }

    *nat_cfg_p = cmd_body.nat_cfg;


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_lpm_tree_optimize_set(const sx_api_handle_t             handle,
                                                const sx_access_cmd_t             cmd,
                                                sx_router_tree_optimize_params_t *tree_params_p,
                                                sx_router_tree_optimize_data_t   *opt_data_p)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_optimize_set_params_t cmd_body;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.tree_params, tree_params_p);
    SX_MEM_CPY_P(&cmd_body.opt_data, opt_data_p);

    err =
        sx_api_send_command_wrapper(handle,
                                    SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_SET_E,
                                    (uint8_t*)&cmd_body,
                                    sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set LPM's optimize parameters - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_router_lpm_tree_optimize_trigger(const sx_api_handle_t             handle,
                                                    const sx_access_cmd_t             cmd,
                                                    sx_router_tree_optimize_params_t *tree_params_p)
{
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_optimize_trigger_params_t cmd_body;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.tree_params, tree_params_p);

    err =
        sx_api_send_command_wrapper(handle,
                                    SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_E,
                                    (uint8_t*)&cmd_body,
                                    sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to trigger LPM optimize - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_router_lpm_tree_balance_factor_get(const sx_api_handle_t                 handle,
                                                      sx_router_tree_optimize_params_t     *tree_params_p,
                                                      sx_router_tree_balance_factor_data_t *balance_data_p)
{
    sx_status_t                                        err = SX_STATUS_SUCCESS;
    sx_api_router_lpm_tree_balance_factor_get_params_t cmd_body;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);
    SX_MEM_CPY_P(&cmd_body.tree_params, tree_params_p);

    err =
        sx_api_send_command_wrapper(handle,
                                    SX_API_INT_CMD_ROUTER_LPM_TREE_BALANCE_FACTOR_GET_E,
                                    (uint8_t*)&cmd_body,
                                    sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set LPM's optimize parameters - [%s]\n", sx_status_str(err));
        goto out;
    }
    SX_MEM_CPY_P(balance_data_p, &cmd_body.balance_data);
out:
    SX_API_LOG_EXIT();
    return err;
}
