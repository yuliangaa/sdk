/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_stateful_db.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_STATEFUL_DB
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t sx_api_stateful_db_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                       const sx_log_verbosity_target_t verbosity_target,
                                                       const sx_verbosity_level_t      module_verbosity_level,
                                                       const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_STATEFUL_DB_VERBOSITY_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                       const sx_log_verbosity_target_t verbosity_target,
                                                       sx_verbosity_level_t           *module_verbosity_level_p,
                                                       sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_STATEFUL_DB_VERBOSITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_init_set(const sx_api_handle_t handle, const sx_stateful_db_init_param_t *init_param_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_stateful_db_init_param_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);


    if (SX_CHECK_FAIL(
            err = utils_check_pointer(init_param_p,
                                      "Stateful DB Init Params"))) {
        goto out;
    }
    SX_MEM_CPY_P(&cmd_body, init_param_p);


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_INIT_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_stateful_db_init_param_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB init set - [%s]\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_DEINIT_SET_E, NULL, 0);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB deinit set - [%s]\n", sx_status_str(err));
    }
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_stateful_db_attr_set(const sx_api_handle_t        handle,
                                        const sx_access_cmd_t        cmd,
                                        sx_stateful_db_attributes_t *attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_attr_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);


    if (cmd != SX_ACCESS_CMD_EDIT) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(
            err = utils_check_pointer(attr_p, "Stateful DB Attributes"))) {
        goto out;
    }
    SX_MEM_CPY(cmd_body.attr, *attr_p);
    cmd_body.cmd = cmd;


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ATTR_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB attribute set - [%s]\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_attr_get(const sx_api_handle_t        handle,
                                        const sx_access_cmd_t        cmd,
                                        sx_stateful_db_attributes_t *attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_attr_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (NULL == attr_p) {
        SX_LOG_ERR("Attributes pointer is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }


    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ATTR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Stateful DB attribute get API failed  (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY(*attr_p, cmd_body.attr);


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_ordering_set(const sx_api_handle_t          handle,
                                            const sx_access_cmd_t          cmd,
                                            sx_stateful_db_ordering_cfg_t *ordering_cfg_list_p,
                                            const uint32_t                 list_cnt)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_ordering_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;

    SX_API_LOG_ENTER();


    if (NULL == ordering_cfg_list_p) {
        SX_LOG_ERR("Ordering config list pointer is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (0 == list_cnt) {
        SX_LOG_ERR("Ordering count is zero\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_SET) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    cmd_size = sizeof(sx_api_stateful_db_ordering_params_t) +
               list_cnt * sizeof(sx_stateful_db_ordering_cfg_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->list_cnt = list_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->ordering_cfg_list_p, ordering_cfg_list_p,
                     list_cnt, sx_stateful_db_ordering_cfg_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ORDERING_SET_E,
                                      (uint8_t*)cmd_body_p, cmd_size);


    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB ordering set - [%s]\n", sx_status_str(err));
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_ordering_get(const sx_api_handle_t          handle,
                                            const sx_access_cmd_t          cmd,
                                            sx_stateful_db_ordering_cfg_t *ordering_cfg_list_p,
                                            const uint32_t                 list_cnt)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_ordering_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;

    SX_API_LOG_ENTER();


    if (NULL == ordering_cfg_list_p) {
        SX_LOG_ERR("Ordering config list pointer is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (0 == list_cnt) {
        SX_LOG_ERR("Ordering count is zero\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    cmd_size = sizeof(sx_api_stateful_db_ordering_params_t) + (list_cnt) * sizeof(sx_stateful_db_ordering_cfg_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->list_cnt = list_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->ordering_cfg_list_p, ordering_cfg_list_p,
                     list_cnt, sx_stateful_db_ordering_cfg_t);

    err =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ORDERING_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY_ARRAY(ordering_cfg_list_p, cmd_body_p->ordering_cfg_list_p,
                         list_cnt, sx_stateful_db_ordering_cfg_t);
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_failure_handler_set(const sx_api_handle_t                 handle,
                                                   const sx_access_cmd_t                 cmd,
                                                   const sx_stateful_db_status_e         failure_type,
                                                   sx_stateful_db_failure_handler_cfg_t *failure_handler_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_failure_handler_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_CHECK_FAIL(
                err = utils_check_pointer(failure_handler_p, "Stateful DB failure handler"))) {
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.failure_handler, failure_handler_p);
    }

    cmd_body.cmd = cmd;
    cmd_body.failure_type = failure_type;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_FAILURE_HANDLER_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB failure action set - [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_failure_handler_get(const sx_api_handle_t                 handle,
                                                   const sx_access_cmd_t                 cmd,
                                                   const sx_stateful_db_status_e         failure_type,
                                                   sx_stateful_db_failure_handler_cfg_t *failure_handler_p)
{
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_failure_handler_params_t cmd_body;


    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(
            err = utils_check_pointer(failure_handler_p, "Stateful DB failure handler"))) {
        goto out;
    }


    cmd_body.cmd = cmd;
    cmd_body.failure_type = failure_type;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_FAILURE_HANDLER_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB failure action get - [%s]\n", sx_status_str(err));
        goto out;
    }


    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY_P(failure_handler_p, &cmd_body.failure_handler);
    }


out:
    SX_API_LOG_ENTER();
    return err;
}


sx_status_t sx_api_stateful_db_partition_set(const sx_api_handle_t           handle,
                                             const sx_access_cmd_t           cmd,
                                             sx_stateful_db_partition_id_e   partition_id,
                                             sx_stateful_db_partition_cfg_t *partition_cfg_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_partition_set_params_t cmd_body;


    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);


    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY) && (cmd != SX_ACCESS_CMD_EDIT)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_CREATE) || (cmd == SX_ACCESS_CMD_EDIT)) {
        if (SX_CHECK_FAIL(
                err = utils_check_pointer(partition_cfg_p, "Stateful DB partition"))) {
            goto out;
        }

        SX_MEM_CPY(cmd_body.partition_cfg, *partition_cfg_p);
    }


    cmd_body.cmd = cmd;
    cmd_body.partition_id = partition_id;


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_PARTITION_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB partition set - [%s]\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_partition_get(const sx_api_handle_t              handle,
                                             const sx_access_cmd_t              cmd,
                                             sx_stateful_db_partition_id_e      partition_id,
                                             sx_stateful_db_partition_status_t *partition_status_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_partition_get_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);


    if (NULL == partition_status_p) {
        SX_LOG_ERR("Partition status pointer is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }


    cmd_body.cmd = cmd;
    cmd_body.partition_id = partition_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_PARTITION_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Stateful DB partition get API failed  (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(partition_status_p, &cmd_body.partition_status);


out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_stateful_db_partition_iter_get(const sx_api_handle_t                    handle,
                                                  const sx_access_cmd_t                    cmd,
                                                  const sx_stateful_db_partition_id_e      partition_id,
                                                  const sx_stateful_db_partition_filter_t *filter_p,
                                                  sx_stateful_db_partition_id_e           *partition_id_list_p,
                                                  uint32_t                                *partition_id_cnt_p)
{
    sx_status_t                                     err = SX_STATUS_SUCCESS;
    sx_status_t                                     utils_err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_partition_iter_get_params_t *cmd_body_p = NULL;
    uint32_t                                        cmd_size = sizeof(sx_api_stateful_db_partition_iter_get_params_t);

    SX_API_LOG_ENTER();

    /* parameter validation */
    err = utils_check_pointer(partition_id_cnt_p, "partition_id_cnt_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*partition_id_cnt_p == 0) {
            goto out;
        } else if (partition_id_list_p == NULL) {
            SX_LOG_ERR("partition_id_list_p must be valid for cmd (%s).\n", sx_access_cmd_str(cmd));
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*partition_id_cnt_p > 0) {
            if (partition_id_list_p == NULL) {
                SX_LOG_ERR("partition_id_list_p must be valid for cmd (%s) and partition_id_cnt_p > 0.\n",
                           sx_access_cmd_str(cmd));
                err = SX_STATUS_PARAM_NULL;
                goto out;
            }
            *partition_id_cnt_p = 1;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, error: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    cmd_size += (*partition_id_cnt_p) * sizeof(sx_stateful_db_partition_id_e);

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_err);
    if (SX_CHECK_FAIL(utils_err)) {
        err = utils_err;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->partition_id = partition_id;
    if (filter_p != NULL) {
        memcpy(&cmd_body_p->filter, filter_p, sizeof(sx_stateful_db_partition_filter_t));
    }
    cmd_body_p->partition_id_cnt = *partition_id_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_PARTITION_ITER_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed partition iter get - [%s]\n", sx_status_str(err));
        goto out;
    }

    *partition_id_cnt_p = cmd_body_p->partition_id_cnt;

    if ((partition_id_list_p != NULL) && (*partition_id_cnt_p > 0)) {
        SX_MEM_CPY_ARRAY(partition_id_list_p,
                         cmd_body_p->partition_id_list_p,
                         *partition_id_cnt_p,
                         sx_stateful_db_partition_id_e);
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_err);
        if (SX_CHECK_FAIL(utils_err)) {
            err = utils_err;
        }
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_key_set(const sx_api_handle_t    handle,
                                       const sx_access_cmd_t    cmd,
                                       sx_stateful_db_key_t    *key_desc_p,
                                       sx_stateful_db_key_id_t *key_id_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_key_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Unsupported access-command (%s)\n",
                   sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    err = utils_check_pointer(key_id_p, "Stateful DB Key ID");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.cmd = cmd;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        err = utils_check_pointer(key_desc_p, "Stateful DB Key description");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        SX_MEM_CPY_P(&cmd_body.key_desc, key_desc_p);
    } else {
        cmd_body.key_id = *key_id_p;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_KEY_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set (cmd %s) stateful DB key, err %s\n", sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        *key_id_p = cmd_body.key_id;
        key_desc_p->key_size = cmd_body.key_desc.key_size;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_key_get(const sx_api_handle_t         handle,
                                       const sx_access_cmd_t         cmd,
                                       const sx_stateful_db_key_id_t key_id,
                                       sx_stateful_db_key_t         *key_desc_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_key_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(key_desc_p, "Stateful DB Key Description");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.key_id = key_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_KEY_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get stateful DB key, err: %s\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(key_desc_p, &cmd_body.key_desc);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_key_iter_get(const sx_api_handle_t              handle,
                                            const sx_access_cmd_t              cmd,
                                            const sx_stateful_db_key_id_t      key_id,
                                            const sx_stateful_db_key_filter_t *filter_p,
                                            sx_stateful_db_key_id_t           *key_id_list_p,
                                            uint32_t                          *key_id_cnt_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_status_t                               utils_err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_key_iter_get_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_stateful_db_key_iter_get_params_t);

    SX_API_LOG_ENTER();

    /* parameter validation */
    err = utils_check_pointer(key_id_cnt_p, "key_id_cnt_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*key_id_cnt_p == 0) {
            goto out;
        } else if (key_id_list_p == NULL) {
            SX_LOG_ERR("key_id_list_p must be valid for cmd (%s).\n", sx_access_cmd_str(cmd));
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*key_id_cnt_p > 0) {
            if (key_id_list_p == NULL) {
                SX_LOG_ERR("key_id_list_p must be valid for cmd (%s) and key_id_cnt_p > 0.\n",
                           sx_access_cmd_str(cmd));
                err = SX_STATUS_PARAM_NULL;
                goto out;
            }
            *key_id_cnt_p = 1;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, error: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    cmd_size += (*key_id_cnt_p) * sizeof(sx_stateful_db_key_id_t);

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_err);
    if (SX_CHECK_FAIL(utils_err)) {
        err = utils_err;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->key_id = key_id;
    if (filter_p != NULL) {
        memcpy(&cmd_body_p->filter, filter_p, sizeof(sx_stateful_db_key_filter_t));
    }
    cmd_body_p->key_id_cnt = *key_id_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_KEY_ITER_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed stateful DB key iter get - [%s]\n", sx_status_str(err));
        goto out;
    }

    *key_id_cnt_p = cmd_body_p->key_id_cnt;

    if ((key_id_list_p != NULL) && (*key_id_cnt_p > 0)) {
        SX_MEM_CPY_ARRAY(key_id_list_p, cmd_body_p->key_id_list_p, *key_id_cnt_p, sx_stateful_db_key_id_t);
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_err);
        if (SX_CHECK_FAIL(utils_err)) {
            err = utils_err;
        }
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_entry_set(const sx_api_handle_t            handle,
                                         const sx_access_cmd_t            cmd,
                                         sx_stateful_db_sw_access_key_t  *access_key_p,
                                         sx_stateful_db_sw_access_data_t *access_data_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_entry_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(access_key_p, "access_key_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = utils_check_pointer(access_data_p, "access_data_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.access_key, access_key_p);
    SX_MEM_CPY_P(&cmd_body.access_data, access_data_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ENTRY_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to preform SW access to stateful DB, err: %s\n", sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(access_data_p, &cmd_body.access_data);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_stateful_db_entry_meta_get(const sx_api_handle_t            handle,
                                              const sx_access_cmd_t            cmd,
                                              sx_stateful_db_sw_access_key_t  *access_key_p,
                                              sx_stateful_db_sw_access_data_t *access_data_p,
                                              sx_stateful_db_entry_meta_t     *access_meta_p)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_stateful_db_entry_meta_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(access_key_p, "access_key_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = utils_check_pointer(access_data_p, "access_data_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = utils_check_pointer(access_meta_p, "access_meta_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.access_key, access_key_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_STATEFUL_DB_ENTRY_META_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to preform SW access and get meta data entry from stateful DB, err: %s\n",
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(access_data_p, &cmd_body.access_data);
    SX_MEM_CPY_P(access_meta_p, &cmd_body.access_meta);

out:
    SX_API_LOG_EXIT();
    return err;
}
