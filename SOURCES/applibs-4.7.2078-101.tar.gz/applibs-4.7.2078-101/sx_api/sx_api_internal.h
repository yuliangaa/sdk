/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SX_API_INTERNAL_H__
#define __SX_API_INTERNAL_H__

#include <limits.h>
#include "sx_api_internal_auto.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/
#define SX_API_LOG_ENTER() SX_LOG_TARGET_VERBOSITY(SX_LOG_VERBOSITY_TARGET_API, "%s - entered \n")
#define SX_API_LOG_EXIT()  SX_LOG_TARGET_VERBOSITY(SX_LOG_VERBOSITY_TARGET_API, "%s - left \n")

#define alignof(type) offsetof(struct { char a; type b; }, b)

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define SDK_SYS_INFO_PATH_DEFAULT "/var/log/sdk_dbg"

#define SX_PRIO_BUFF_SX_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_CORE_MAX_NON_HIGH_PRIO_BUF_E)

#define SX_BITMAP_ARR_SIZE(num, type)    \
    ((num / (sizeof(type) * CHAR_BIT)) + \
     !!(num % (sizeof(type) * CHAR_BIT)))
#define SX_BITMAP_ARR_ENTRY_SIZE(bitmap_arr) (sizeof((bitmap_arr)[0]) * CHAR_BIT)
#define SX_BITMAP_ARR_BIT_GET(bitmap_arr, bit)                      \
    (((bitmap_arr)[(bit) / SX_BITMAP_ARR_ENTRY_SIZE(bitmap_arr)] >> \
      ((bit) % SX_BITMAP_ARR_ENTRY_SIZE(bitmap_arr))) & 0x1)
#define SX_BITMAP_ARR_BIT_SET(bitmap_arr, bit)                     \
    ((bitmap_arr)[(bit) / SX_BITMAP_ARR_ENTRY_SIZE(bitmap_arr)] |= \
         (1 << ((bit) % SX_BITMAP_ARR_ENTRY_SIZE(bitmap_arr))))

#define IS_SPECTRUM_FAMILY(chip_type)            \
    ((chip_type == SXD_CHIP_TYPE_SPECTRUM) ||    \
     (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1) || \
     (chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||   \
     (chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||   \
     (chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||   \
     (chip_type == SXD_CHIP_TYPE_SPECTRUM5))

/* #defines to group ASIC family bitmaps*/
/* QM1, QM2, QM3 */
#define ALL_QTM_IB_ASIC_BITMAP (SX_CHIP_TYPE_QUANTUM_BIT_E | SX_CHIP_TYPE_QUANTUM2_BIT_E | SX_CHIP_TYPE_QUANTUM3_BIT_E)
/* SIB1, SIB2 */
#define ALL_SWIB_ASIC_BITMAP (SX_CHIP_TYPE_SWITCH_IB_BIT_E | SX_CHIP_TYPE_SWITCH_IB2_BIT_E)
/* SIB1, SIB2, QM1, QM2, QM3 */
#define ALL_ACTIVE_IB_ASIC_BITMAP (ALL_QTM_IB_ASIC_BITMAP)
/* None as of now*/
#define ALL_EOL_IB_ASIC_BITMAP (ALL_SWIB_ASIC_BITMAP)
/* SIB1, SIB2, QM1, QM2, QM3 */
#define ALL_IB_ASIC_BITMAP (ALL_ACTIVE_IB_ASIC_BITMAP | ALL_EOL_IB_ASIC_BITMAP)

/* SX, SX_A0, SX_A1, SX_A2 */
#define ALL_SX_ETH_ASIC_BITMAP                                    \
    (SX_CHIP_TYPE_SWITCHX_BIT_E | SX_CHIP_TYPE_SWITCHX_A0_BIT_E | \
     SX_CHIP_TYPE_SWITCHX_A1_BIT_E | SX_CHIP_TYPE_SWITCHX_A2_BIT_E)
/*SPC1, SPC_A1, SPC2, SPC3, SPC4, SPC5 */
#define ALL_SPC_ETH_ASIC_BITMAP                                      \
    (SX_CHIP_TYPE_SPECTRUM1_BIT_E | SX_CHIP_TYPE_SPECTRUM_A1_BIT_E | \
     SX_CHIP_TYPE_SPECTRUM2_BIT_E | SX_CHIP_TYPE_SPECTRUM3_BIT_E |   \
     SX_CHIP_TYPE_SPECTRUM4_BIT_E | SX_CHIP_TYPE_SPECTRUM5_BIT_E)
/*SPC1, SPC_A1, SPC2, SPC3, SPC4, SPC5 */
#define ALL_ACTIVE_ETH_ASIC_BITMAP                                   \
    (SX_CHIP_TYPE_SPECTRUM1_BIT_E | SX_CHIP_TYPE_SPECTRUM_A1_BIT_E | \
     SX_CHIP_TYPE_SPECTRUM2_BIT_E | SX_CHIP_TYPE_SPECTRUM3_BIT_E |   \
     SX_CHIP_TYPE_SPECTRUM4_BIT_E | SX_CHIP_TYPE_SPECTRUM5_BIT_E)

#define ALL_ACTIVE_ETH_EXCEPT_SPECTRUM5_BITMAP                       \
    (SX_CHIP_TYPE_SPECTRUM1_BIT_E | SX_CHIP_TYPE_SPECTRUM_A1_BIT_E | \
     SX_CHIP_TYPE_SPECTRUM2_BIT_E | SX_CHIP_TYPE_SPECTRUM3_BIT_E |   \
     SX_CHIP_TYPE_SPECTRUM4_BIT_E)

/* SX, SX_A0, SX_A1, SX_A2 */
#define ALL_EOL_ETH_ASIC_BITMAP (ALL_SX_ETH_ASIC_BITMAP)
/* SX, SX_A0, SX_A1, SX_A2, SPC1, SPC_A1, SPC2, SPC3, SPC4 */
#define ALL_ETH_ASIC_BITMAP (ALL_SX_ETH_ASIC_BITMAP | ALL_SPC_ETH_ASIC_BITMAP)

/* SIB1, SIB2, QM1, QM2, QM3 , SPC1, SPC_A1, SPC2, SPC3, SPC4 */
#define ALL_ACTIVE_ASIC_BITMAP (ALL_ACTIVE_ETH_ASIC_BITMAP | ALL_ACTIVE_IB_ASIC_BITMAP)
/* SX, SX_A0, SX_A1, SX_A2, SIB, SIB2 */
#define ALL_EOL_ASIC_BITMAP (ALL_EOL_ETH_ASIC_BITMAP | ALL_EOL_IB_ASIC_BITMAP)
/* SPL case to init API */
#define ALL_ASIC_BITMAP (ALL_ACTIVE_ASIC_BITMAP | ALL_EOL_ASIC_BITMAP)
/* Remove after testing*/
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)       \
    ((byte) & 0x8000 ? '1' : '0'), \
    ((byte) & 0x4000 ? '1' : '0'), \
    ((byte) & 0x2000 ? '1' : '0'), \
    ((byte) & 0x1000 ? '1' : '0'), \
    ((byte) & 0x0800 ? '1' : '0'), \
    ((byte) & 0x0400 ? '1' : '0'), \
    ((byte) & 0x0200 ? '1' : '0'), \
    ((byte) & 0x0100 ? '1' : '0'), \
    ((byte) & 0x0080 ? '1' : '0'), \
    ((byte) & 0x0040 ? '1' : '0'), \
    ((byte) & 0x0020 ? '1' : '0'), \
    ((byte) & 0x0010 ? '1' : '0'), \
    ((byte) & 0x0008 ? '1' : '0'), \
    ((byte) & 0x0004 ? '1' : '0'), \
    ((byte) & 0x0002 ? '1' : '0'), \
    ((byte) & 0x0001 ? '1' : '0')
/* end test code */
typedef void (*sx_core_td_event_src_handler_t) (uint32_t idx);

typedef void (*sdk_connector_cb_t)(void);
typedef int (*sdk_connector_deinit_cb_t)(void);

typedef void (*sx_issu_pause_cb_t)(void);
typedef void (*sx_issu_resume_cb_t)(void);

typedef void (*sx_api_sniffer_api_reply_t)(const sx_api_reply_head_t *reply_head,
                                           uint32_t                   head_size,
                                           const uint8_t             *reply_body,
                                           uint32_t                   reply_body_size);

/**
 * sx_core_cli_settings_t structure is used to store command
 * line parameters of SDK process invocation.
 */
typedef struct sx_core_cli_settings {
    sx_verbosity_level_t      verbosity_level;
    sx_log_cb_t               log_cb;
    sx_issu_pause_cb_t        log_pause_cb;
    sx_issu_resume_cb_t       log_resume_cb;
    sdk_connector_cb_t        connector_cb;
    sx_issu_pause_cb_t        connector_pause_cb;
    sx_issu_resume_cb_t       connector_resume_cb;
    sdk_connector_deinit_cb_t connector_deinit_cb;
} sx_core_cli_settings_t;

typedef struct sx_core_td_event_src {
    const char                    *desc;
    sx_event_src_state_e           state;
    uint8_t                       *buffer;
    uint32_t                       pos;
    cl_commchnl_t                  commchnl;
    sx_core_td_event_src_handler_t handler;
    pid_t                          sender_pid;
#ifdef TIME_DEBUG
    struct timespec tms_start;
#endif
} sx_core_td_event_src_t;

#if 0
/**
 * sx_api_span_session_get_params_t structure is used to store
 * SPAN session Get function parameters.
 */
typedef struct sx_api_span_session_get_params {
    sx_span_session_id_t     span_session_id;
    sx_span_session_params_t span_session_params;
    sx_port_log_id_t         analyzer_port;
    uint32_t                 mirrors_num;
    sx_span_mirror_t         mirrors_arr[0];
} sx_api_span_session_get_params_t;
#endif

/**
 * sx_api_user_ctxt_t structure is used to store user data.
 */
typedef struct sx_api_user_ctxt {
    cl_commchnl_t commchnl;
    cl_spinlock_t mutex;
    sxd_handle    dev;      /**< handle descriptor for SXD device */
    boolean_t     valid;
} sx_api_user_ctxt_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of SX API INTERNAL MODULE
 * @param[inout] verbosity_level - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *         SX_STATUS_ERROR   general error
 */
sx_status_t sx_api_internal_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

/**
 *  This function sends a command to SX-API server and waits for
 *  the reply.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd_head - command head structure.
 * @param[in] cmd_body - command body buffer.
 * @param[out] reply_head - reply head buffer.
 * @param[out] reply_body - reply body buffer.
 * @param[in] reply_body_size - reply body size.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_command_decoupled(sx_api_handle_t        handle,
                                          sx_api_command_head_t *cmd_head,
                                          uint8_t               *cmd_body,
                                          sx_api_reply_head_t   *reply_head,
                                          uint8_t               *reply_body,
                                          uint32_t               reply_body_size);

/**
 *  This function sends a command to SX-API server and waits for
 *  the reply. The reply should include an open file descriptor to the device.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd_head - command head structure.
 * @param[in] cmd_body - command body buffer.
 * @param[out] reply_head - reply head buffer.
 * @param[out] reply_body - reply body buffer.
 * @param[in] reply_body_size - reply body size.
 * @param[out] fd - open file descriptor to device
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_command_decoupled_fd(sx_api_handle_t        handle,
                                             sx_api_command_head_t *cmd_head,
                                             uint8_t               *cmd_body,
                                             sx_api_reply_head_t   *reply_head,
                                             uint8_t               *reply_body,
                                             uint32_t               reply_body_size,
                                             int32_t               *fd);

/**
 *  This function receives a command from SX-API client. Partial command receive
 *  is supported and the function should be called with the returned buffer
 *  position until successful completion.
 *
 * @param[in] commchnl - client's communication channel.
 * @param[inout] buffer - buffer to store command.
 * @param[inout] buffer_position - buffer position
 *
 * @return sx_status_t
 */
sx_status_t sx_api_receive_command(cl_commchnl_t *commchnl,
                                   uint8_t      **buffer,
                                   uint32_t      *buffer_position);

/**
 *  This function sends a reply from SX-API server to one of its
 *  its clients.
 *
 * @param[in] commchnl - client's communication channel.
 * @param[out] reply_head - reply head buffer.
 * @param[out] reply_body - reply body buffer.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_reply(cl_commchnl_t       *commchnl,
                              sx_api_reply_head_t* reply_head,
                              uint8_t             *reply_body);

/**
 *  This function sends a reply from SX-API server to one of its
 *  its clients. The reply will include an open file descriptor to the device.
 *
 * @param[in] commchnl - client's communication channel.
 * @param[out] reply_head - reply head buffer.
 * @param[out] reply_body - reply body buffer.
 * @param[in] fd - open file descriptor to device, to be sent to client
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_reply_fd(cl_commchnl_t *commchnl,
                                 sx_api_reply_head_t *reply_head,
                                 uint8_t *reply_body, int32_t fd);

/**
 *  This function is a wrapper for sx_api_send_command_decoupled
 *  function. The hidden assumptions are:
 *  1. The "cmd-body" & the "reply-body" are the same (also size
 *     wise).
 *  2. The "reply-head" is redundant & therefore not retrieved.
 *
 * @param[in] handle - SX-API handle.
 * @param[in] cmd_code - command op code.
 * @param[inout] cmd_body_p - command body buffer.
 * @param[in] cmd_size - command body size.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_command_wrapper(sx_api_handle_t handle,
                                        uint32_t        cmd_code,
                                        uint8_t        *cmd_body_p,
                                        uint32_t        cmd_size);

/**
 *  This function is a wrapper for sx_api_send_reply function.
 *  The "reply-head" structure is replaced with return code of
 *  the operation alone.
 * @param[in] commchnl - client's communication channel.
 * @param[in] retcode - client operation's return code.
 * @param[in] reply_body - reply body buffer.
 * @param[in] reply_body_size - reply body size.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_reply_wrapper(cl_commchnl_t *commchnl,
                                      sx_status_t    retcode,
                                      uint8_t       *reply_body,
                                      uint32_t       reply_body_size);

/**
 *  This function is a wrapper for sx_api_send_reply_fd function.
 *  The "reply-head" structure is replaced with return code of
 *  the operation alone.
 * @param[in] commchnl - client's communication channel.
 * @param[in] retcode - client operation's return code.
 * @param[in] reply_body - reply body buffer.
 * @param[in] reply_body_size - reply body size.
 * @param[in] fd - open file descriptor to device, to be sent to client
 *
 * @return sx_status_t
 */
sx_status_t sx_api_send_reply_wrapper_fd(cl_commchnl_t *commchnl,
                                         sx_status_t    retcode,
                                         uint8_t       *reply_body,
                                         uint32_t       reply_body_size,
                                         int32_t        fd);

/**
 *  This function is a serialize function for the sx_api_port_map_set_params_t
 *  and sx_api_port_map_get_params_t structures
 * @param[in]  cmd_body - the command structure to serialize.
 * @param[out] out_buffer - the serialized buffer.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_serialize_port_map_set_params(sx_api_port_map_set_params_t * cmd_body,
                                                 uint8_t                      * out_buffer,
                                                 uint32_t                       buffer_size);

/**
 *  This function is a deserialize function for the sx_api_port_map_set_params_t
 *  and sx_api_port_map_get_params_t structures
 * @param[in]  in_buffer - the serialized buffer.
 * @param[out] out_cmd_body - the command structure to deserialize to.
 *
 * @return sx_status_t
 */
sx_status_t sx_api_deserialize_port_map_set_params(uint8_t                      *in_buffer,
                                                   sx_api_port_map_set_params_t *out_cmd_body);

sx_status_t sx_cos_port_buff_type_serialize_params(sx_api_cos_buff_type_statistics_get_params_t *cmd_body,
                                                   uint32_t                                     *out_buffer);

sx_status_t sx_cos_port_buff_type_deserialize_params(uint32_t                                     *in_buffer,
                                                     sx_api_cos_buff_type_statistics_get_params_t *out_cmd_body);

sx_status_t sx_api_serialize_flex_acl_rule_set_params(sx_api_flex_acl_rules_set_params_t *cmd_body,
                                                      uint8_t                            *out_buffer,
                                                      uint32_t                           *buffer_size,
                                                      rule_get_cmd_e                      get_cmd);
sx_status_t sx_api_deserialize_flex_acl_rule_set_params(uint8_t                            *in_buffer,
                                                        sx_api_flex_acl_rules_set_params_t *out_cmd_body,
                                                        uint32_t                           *buffer_size,
                                                        rule_get_cmd_e                      get_cmd,
                                                        uint32_t                            max_num_key_desc);

void sx_api_sniffer_enabled_set(boolean_t enabled);
void sx_api_sniffer_api_reply_set(sx_api_sniffer_api_reply_t func);

sx_status_t sx_api_serialize_slot_info_get_params(sx_mgmt_slot_info_get_params_t *cmd_body_p,
                                                  uint8_t                        *out_buffer,
                                                  uint32_t                        buffer_size);
sx_status_t sx_api_deserialize_slot_info_get_params(uint8_t * in_buffer, sx_mgmt_slot_info_get_params_t *out_cmd_body);
sx_status_t sx_api_serialize_slot_state_info_get_params(sx_mgmt_slot_state_info_get_params_t *cmd_body_p,
                                                        uint8_t                              *out_buffer,
                                                        uint32_t                              buffer_size);
sx_status_t sx_api_deserialize_slot_state_info_get_params(uint8_t                             * in_buffer,
                                                          sx_mgmt_slot_state_info_get_params_t *out_cmd_body);
sx_status_t sx_api_serialize_slot_ini_oper_set_params(sx_mgmt_slot_ini_operation_set_params_t *cmd_body_p,
                                                      uint8_t                                 *out_buffer,
                                                      uint32_t                                 buffer_size);
sx_status_t sx_api_deserialize_slot_ini_oper_set_params(uint8_t                                * in_buffer,
                                                        sx_mgmt_slot_ini_operation_set_params_t *out_cmd_body);
sx_status_t sx_api_serialize_phy_module_info_get_params(sx_mgmt_phy_module_info_get_params_t *cmd_body_p,
                                                        uint8_t                              *out_buffer,
                                                        uint32_t                              buffer_size);

sx_status_t sx_api_deserialize_phy_module_info_get_params(uint8_t                             * in_buffer,
                                                          sx_mgmt_phy_module_info_get_params_t *out_cmd_body);

sx_status_t sx_api_serialize_log_port_info_get_params(sx_mgmt_port_info_get_params_t *cmd_body_p,
                                                      uint8_t                        *out_buffer,
                                                      uint32_t                        buffer_size);
sx_status_t sx_api_deserialize_log_port_info_get_params(uint8_t                       * in_buffer,
                                                        sx_mgmt_port_info_get_params_t *out_cmd_body);
sx_status_t sx_api_serialize_temp_sensor_set_params(sx_mgmt_temp_sensor_set_params_t *cmd_body_p,
                                                    uint8_t                          *out_buffer,
                                                    uint32_t                          buffer_size);
sx_status_t sx_api_deserialize_temp_sensor_set_params(uint8_t                         * in_buffer,
                                                      sx_mgmt_temp_sensor_set_params_t *out_cmd_body);
sx_status_t sx_api_serialize_temp_sensor_get_params(sx_mgmt_temp_sensor_get_params_t *cmd_body_p,
                                                    uint8_t                          *out_buffer,
                                                    uint32_t                          buffer_size);
sx_status_t sx_api_deserialize_temp_sensor_get_params(uint8_t                         * in_buffer,
                                                      sx_mgmt_temp_sensor_get_params_t *out_cmd_body);

sx_status_t host_ifc_user_channel_init(void);
void host_ifc_user_channel_deinit(void);

sx_status_t generate_dump_file(const char *path,
                               sx_dev_id_t dev_id,
                               const char *dump_prefix,
                               const char *dump_suffix,
                               FILE      **f_ret);

sx_status_t dbg_generate_dump_ext(sx_dbg_extra_info_t *dbg_params);
sx_status_t dbg_generate_amber_dump(const char               *path,
                                    sx_dev_id_t               dev_id,
                                    const struct ku_dev_info *dev_info,
                                    uint32_t                 *total_fw_time_msec);

void player_send_bpf_stub_func(IN const sx_api_command_head_t * const pCmd);
void player_recv_bpf_stub_func(void);

#endif /* __SX_API_INTERNAL_H__ */
